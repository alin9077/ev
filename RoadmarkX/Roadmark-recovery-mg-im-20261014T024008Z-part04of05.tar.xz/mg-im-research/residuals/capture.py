import urllib.request, concurrent.futures, json, datetime, hashlib, pathlib,sys
from html.parser import HTMLParser
root=pathlib.Path('/tmp/mg-im-research/residuals/sources')
class Text(HTMLParser):
 def __init__(self):super().__init__();self.x=[];self.ignore=0
 def handle_starttag(self,t,a):
  if t in ['script','style']:self.ignore+=1
 def handle_endtag(self,t):
  if t in ['script','style']:self.ignore-=1
 def handle_data(self,s):
  if self.ignore<=0 and s.strip():self.x.append(s.strip())
def f(it):
 k,u=it;m={'key':k,'url':u,'accessed_date':'2026-10-14','retrievedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  r=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=20);b=r.read();p=root/(k+'.html');p.write_bytes(b);t=Text();t.feed(b.decode('utf-8','replace'));p2=root/(k+'.txt');p2.write_text('\n'.join(t.x));m.update(status=r.status,file=str(p),textFile=str(p2),sha256=hashlib.sha256(b).hexdigest(),textSha256=hashlib.sha256(p2.read_bytes()).hexdigest());print(k,r.status,len(b),flush=True)
 except Exception as e:m['error']=str(e);print(k,str(e),flush=True)
 return m
urls=json.loads(pathlib.Path(sys.argv[1]).read_text())
out=list(concurrent.futures.ThreadPoolExecutor().map(f,urls.items()))
(root/(sys.argv[2]+'.json')).write_text(json.dumps(out,indent=2))
