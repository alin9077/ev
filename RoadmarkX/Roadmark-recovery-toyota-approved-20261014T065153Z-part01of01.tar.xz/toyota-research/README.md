# Toyota M1 dated research

Checked 14 October 2026. Research/staging only; do not register before independent review.

Scope: current Australian Tier 1 Toyota BEVs and independently established residual-new exact identities. Toyota bZ4X, bZ4X Touring and HiLux BEV. Vans/trucks and all other brands remain untouched. Current and inherited observations stay distinct; no physical stock claim follows from a listing.

All source capture copies must exclude authentication/cookie/session/CSRF/client-secret data before durable backup. Factual content and source URLs are retained; redaction records identify original and sanitized hashes where a capture needed sanitizing. No CAPTCHA solving is authorized.
