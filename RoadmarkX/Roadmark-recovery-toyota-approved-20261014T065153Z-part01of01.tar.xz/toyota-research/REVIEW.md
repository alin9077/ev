# Toyota Australian M1 research review

Checked 14 October 2026. Candidate prepared, staged and independently approved for guarded integration. Root registered the approved packet and reconciliation at 06:40 UTC after independent approval. This research task did not edit either registry. No historical research/source records or other-brand data were edited.

## Current and residual-new scope

Six current official Australian configurations are established: bZ4X 2WD and AWD, bZ4X Touring AWD, HiLux BEV SR Double-Cab Cab-Chassis, SR Double-Cab Pick-Up and SR5 Double-Cab Pick-Up. The current Australian maker pages/specification tables do not establish formal model years, so existing identity labels are retained rather than inferring a model year from a calendar date. Four current-version reviews preserve the separate SUV and ute body scopes.

Both independent Toyota brand directories were fully transcribed: CarsGuide has 22 current cards and 42 older links; CarExpert has 16 unmarked current cards and eight discontinued cards. Their Glass's and JATO dataset families are distinct. Every difference has a source-bound disposition in the companion brand reconciliation. These are mixed-powertrain Toyota-only lists, not complete Australian BEV market lists, and do not populate global publishedLists.

No genuine current original-71.4-kWh residual-New advertisement was established. Exact old Ulladulla URLs return 404; Carsales New-car-to-order pages expressly identify themselves as generic Carsales templates; the reviewed remaining original-model units are used, demonstrator or test-drive listings. No low odometer or historical maker price is used to invent current new supply. Failed/redirected current-model stock candidates remain documented without sold or physical-stock claims. C-HR BEV remains an official mid-2027 announcement without a current exact Australian grade/order offer; Urban Cruiser has no established current Australian official new supply. Existing supplier-branded HiLux/LandCruiser conversion records are outside this Toyota OEM pass.

## Facts buyers can use

- All six current maker list prices are Confirmed at rung 1, before on-road costs: A$55,990 / 67,990 / 69,990 / 74,990 / 76,490 / 82,990. No finance contribution, novated incentive or charging benefit is subtracted
- Every one of 102 core cells has an earned review: 90 Confirmed, four Check, three Reported and five Not published. The five gaps are enclosed-boot litres for all three HiLux bodies and published 0–100 km/h figures for the two SR versions. The SR5's 8.85 seconds is explicitly a CarSauce road-test measurement, not a Toyota claim or a sibling-wide figure
- bZ4X 2WD's 167 kW figure follows the current June technical sheet and landing page; the 165 kW grade-card claim remains an explicit Check conflict. AWD/Touring/HiLux system outputs are directly published, never sums of component motor peaks
- Current SUV pages say 28 minutes for 10–80%, while bZ4X's June sheet says 45 minutes and its earlier launch says 30; Touring's May sheet says 30. The 28-minute current-page values remain Check and unranked with each exact alternative/test condition retained. HiLux's 30-minute 10–80% figure is Confirmed. Station power is not substituted for vehicle DC peak; Touring 150 kW vehicle peak is Reported from an Australian review
- bZ4X 2WD's 750 kg braked limit is Reported from its exact Australian CarExpert specification. Toyota's sheet itself only gives an unclassified 750 kg maximum. Current AWD/Touring 1,500 kg and HiLux 2,000 kg braked figures are Confirmed
- bZ4X/Touring 74.7 kWh is gross; HiLux 59.2 kWh is not labelled gross or usable. Usable capacity is not imported from overseas or Subaru. HiLux 245/315/315 km NEDC claims remain separate from SUV WLTP claims
- Published 452 L bZ4X and 603 L VDA Max Touring cargo values remain visible, but all are unranked because complete loading/method scopes are not established. The generic bZ4X 422 L promotional paragraph is recorded rather than silently substituted for the repeated exact-grade 452 L figure. Width mirror inclusion is not invented

## Ownership and equipment

Five-year unlimited-kilometre private-use vehicle cover is separate from the conditional seven-year motor/driveline and ten-year battery-defect extensions. The battery fact distinguishes five-year defect cover from eight-year/160,000 km capacity assurance below 70%, retaining health-check/operating requirements and specified commercial-use exclusions. Toyota's current legal terms plus the HiLux launch explicitly support HiLux capacity cover despite a narrower parenthetical on the warranty landing page.

Toyota Roadside Assist is a paid optional membership. Warranty Advantage covered-failure towing/loan-car support is a different benefit. The canonical roadside fact retains its Confirmed grade and explicit roadsideFitment: optional. The small separately reviewed importer fix projects optional fitment without weakening source grades or historical packet guards.

339 guarded equipment replacements plus six canonical roadside projections use exact source-linked dependencies. Known heating, ventilation, displays, smartphone integration, V2L, cargo, power and charging answers stay consistent with canonical facts. Missing objective answers have their own matching null feature facts and two inspected source URLs; subjective/personal-cost questions remain outside this data pass. ANCAP scope is Reported under the maker-only Confirmed framework and correctly distinguishes current bZ4X/Touring and HiLux BEV applicability. No phone-key, navigation-triggered preconditioning or sibling heat-pump assumption is invented.

The conditional Toyota Go charging benefit is retained separately for eligible production/purchase periods: 7 kW wall charger excluding installation, or up to 12 months Chargefox capped at 625 kWh. The purchase, vehicle, buyer-category, account and redemption requirements are explicit. It is not a cash discount.

The existing A$73,690 South Nowra AWD dealer observation remains unchanged at its 10 October date. Only a two-month-old indexed page was retrieved in this pass, so neither its price nor Coming Soon/past-July-ETA stock claim receives a fresh observation date or canonical driveaway promotion.

## Validation and honest completion status

Self-staging passes exact before states, identity/source/dependency guards, the actual detail-pack path against explicit feature replay, citable source parity, optional roadside projection and exact portable roundtrip. Input objects and every other brand are unchanged. All 87 pre-existing data files retained their hashes at independent self-stage. After root registration, the only permitted existing-data delta is appending the approved Toyota basename to the brand registry; the other 86 pre-existing data files retain their hashes. The unchanged candidate bytes are now registered by root; its post-registration checks are tracked separately.

Staged Toyota researchCompleted is true, with zero unreviewed core cells, missing summaries or aged/invalid claims. Strict criteria: C1 false, C2 false, C3 true, C4 true, C5 false, C6 true. Research completion allows a bounded two-source Not published outcome; it does not waive strict coverage targets or global C1.

Ranking coverage is range 6/6, price 6/6, seats 6/6, 10–80% time 3/6, cargo 0/6, braked towing 5/6. Charging conflicts, cargo-method/load gaps and Reported towing remain excluded honestly. Two complete whole-market lists are still required globally.

Research used public web retrieval and dot's own cloud Chrome browser for visual specification-table checks. Direct Toyota HTTP routes sometimes returned 403/outage pages; public readable text and five saved PDF screenshots established the reviewed table columns. Search-index-only observations are labelled. No CAPTCHA, dealer enquiry, order, publication or account action was performed.

## Review artifacts

- Toyota dated packet and typed reconciliation, with stable hashes in integration-readiness.json
- core-matrix.json: all 102 core cells, source URLs, grades, basis and limitations
- source-index.json and source-hash-manifest.json: 48 source observations and full capture locators/hashes
- residual/brand-model-list-reconciliation.json and residual/residual-closure.json: complete directory and finite stock audit
- evidence-completeness-audit.json: prior populated facts, preserved historical observation and immutable-data audit
- redaction-audit.json: no captured authentication/cookie/session/CSRF/client-secret values found; no headers were saved and no factual redaction was required
- stage-validation.log, staged-report.json and staged-packs.json: reproducible pre-registration replay

Independent evidence review passes on the frozen hashes, including all guarded before states, 618 citable facts, 339 equipment answers, 415 equipment dependencies, source capture hashes, actual pack parity, optional roadside, portable roundtrip and ten negative mutation categories. The approved scope is guarded integration of these six established versions. No global C1 closure, M1 milestone checkpoint or publication is implied.
