from pathlib import Path
import json,re,hashlib,datetime
P=Path('/tmp/toyota-research/terms')
urls=json.loads((P/'source-urls.json').read_text())
# Retrieval captures contain only public source text and URLs; remove tool-reference control glyphs.
for p in P.glob('*.txt'):
 s=p.read_text()
 s=re.sub(r'\ue200cite\ue202(?:[^\ue201]*†)?([^\ue201]*)\ue201',lambda m:m.group(1) if 'turn' not in m.group(1) else '',s)
 s=s.replace('\x00','')
 p.write_text(s)
sourcekeys=['warranty','warranty_terms','roadside','bz4x_specs','bz4x_range','touring_specs','touring_range','hilux_specs','bz4x_launch','touring_launch','hilux_pricing','hilux_launch','bz4x_product','touring_product','connected','connected_faq','bz4x_feb26','bz4x_preconditioning','touring_preconditioning','ancap_bz4x','ancap_bz4x_release','ancap_hilux','ancap_hilux_release','service_faq','bz4x_original','bz4x_old_specs','carexpert_bz4x_awd','carexpert_bz4x_2wd','tesla_other_ev']
sources=[]
for k in sourcekeys:
 p=P/(k+'.txt');s=p.read_text();assessor=k.startswith('ancap');secondary=k.startswith('carexpert')
 sources.append(dict(key=k,url=urls[k],title=s.splitlines()[0].split(' (http')[0],publisher='ANCAP' if assessor else 'CarExpert' if secondary else 'Tesla Australia' if k=='tesla_other_ev' else 'Toyota Australia',source_type='independent_assessment' if assessor else 'reputable_au_publication' if secondary else 'official_network_operator' if k=='tesla_other_ev' else 'official_au_manufacturer',market='AU',accessed_date='2026-10-14',retrievedAt='2026-10-14',textFile='terms/'+p.name,textSha256=hashlib.sha256(s.encode()).hexdigest(),retrieval='Official web text retrieval' if ('Total lines:' in s and 'Failed to fetch' not in s) else 'Public search-index text of named publisher URL',supports='Specific feature, warranty or ownership scope identified in each row. Search-index captures are identified, not represented as direct HTTP downloads.'))
terms={
'warranty':dict(value='5 years / unlimited km',grade='Confirmed',status='standard',condition='Ordinary private-use new-vehicle cover from first delivery; specified commercial uses are capped at 5 years/160,000 km, whichever first.',sourceKeys=['warranty','warranty_terms'],reason='Current Australian brand terms: base vehicle period is separate from conditional extensions.',locator='Warranty terms PDF printed p3 table; p2 Commercial application; p4 note 1',years=5,kilometres=None,commercialYears=5,commercialKilometres=160000),
'battery_warranty':dict(value='5 years/unlimited km defects; 8 years/160,000 km capacity assurance below 70%',grade='Confirmed',status='standard',condition='Capacity assurance requires specified battery-health checks and compliance with operating, charging and maintenance instructions; specified commercial use is excluded. Defect cover can renew annually up to 10 years/unlimited km after checks; that extension is not standard and excludes specified commercial use.',sourceKeys=['warranty','warranty_terms','hilux_launch'],reason='Battery manufacturing-defect warranty, conditional defect extension and capacity assurance are distinct. HiLux is explicitly included in its AU launch notwithstanding the warranty landing-page parenthetical naming only bZ4X/Touring.',locator='Warranty terms PDF printed p3 traction battery rows; p4 notes 5a/5b; HiLux July press-kit warranty paragraphs and notes 7/8',defectYears=5,defectKilometres=None,conditionalDefectYears=10,capacityYears=8,capacityKilometres=160000,capacityThresholdPercent=70),
'roadside_assistance':dict(value='Paid Toyota Roadside Assist membership; warranty-covered towing/loan car separately',grade='Confirmed',status='optional',condition='Roadside Assist starts at A$99/year; Plus at A$139/year. The included Warranty Advantage transport/loan-car benefit only applies to a covered failure: 5 years, with conditional 2-year extension. This is not general breakdown, flat-tyre or depleted-charge roadside cover.',sourceKeys=['roadside','warranty_terms'],reason='Toyota roadside FAQ explicitly says Warranty Advantage mobility assistance is not Toyota Roadside Assist.',locator='Roadside page Memberships and FAQ Is Toyota Warranty Advantage...the same as Toyota Roadside Assist?; warranty PDF printed p3 table, p4 note 4',includedGeneralRoadsideYears=None),
'electric_motor_driveline_extension':dict(value='Up to 7 years/unlimited km',grade='Check',status='conditional',condition='Base 5 years plus 2 years only when properly serviced and maintained as required in vehicle Warranty and Service Book. Specified commercial use excluded; traction battery is covered separately.',sourceKeys=['warranty_terms'],locator='PDF printed p2 Keep it serviced; printed p3 engine/electric motor/driveline row')}
base=json.loads(Path('/tmp/toyota-research/toyota-feature-before.json').read_text())
ids=list(dict.fromkeys(x['variant_id'] for x in base));keys=list(dict.fromkeys(x['criterion'] for x in base))
skip={'alert_sound_quality','ride_control_subjective','interior_fit_finish_subjective','style_refinement','paint_options_quality','novated_fbt','insurance_cost','resale_value','real_world_range','driveaway_price','storage','energy_use','performance_rear_motor','home_charging','warranty_service'}
reason={
'phone_key':'Smart entry/start and connected app services are listed, but phone-as-driving-key eligibility is not established for this exact BEV; brand-wide Digital Key availability is model dependent.',
'cloud_profile_transfer':'Multimedia services do not establish transfer of a complete driving/seat profile between compatible vehicles.',
'automatic_start':'Smart entry/start is listed, but no start-button-free driving workflow is established.',
'automatic_shutdown':'No exit/lock-triggered power-down workflow is published in the reviewed exact-model sources.',
'walk_away_lock':'Smart entry/start does not establish automatic locking when the key leaves.',
'automatic_seat_climate':'Seat heating/ventilation hardware does not establish temperature- or occupancy-triggered automatic operation.',
'media_resume':'No exact source/account automatic media-resume behaviour is documented.',
'garage_integration':'No vehicle-integrated garage-door opener is specified.',
'auto_shift':'An automatic transmission or rotary/shift-by-wire selector does not establish predictive Drive/Reverse selection.',
'adas_optional':'No separately purchasable Australian driver-assistance package is specified for this exact grade.',
'sentry_parked_recording':'Cameras, alarm and connected security do not establish parked-event video recording.',
'dashcam':'The exact-model specification and companion Australian maker page do not establish built-in recording or a grade-specific supported accessory.',
'pet_mode':'No dedicated pet-specific retained-climate/display mode is published.',
'camp_utility_mode':'No retained-climate camping/utility mode with its operating and locking conditions is established.',
'cabin_overheat_protection':'Remote climate is not evidence of automatic parked cabin-overheat protection.',
'remote_summon':'Intelligent parking assist, where fitted, is not evidence of phone-controlled parking or pathfinding summon.',
'phone_contacts':'Bluetooth/phone integration is specified, but exact contact-sync permissions and native phonebook scope are not established.',
'traffic_light_chime':'No traffic-signal green-light departure chime is specified; road-sign recognition is a different feature.',
'charge_port_operation':'Charging connector types are listed, but no powered-cover or automatic port-opening/closing workflow is specified.',
'navigation_route_planner':'Embedded/connected navigation and charging-station search do not establish automatic charging itineraries with arrival state of charge.',
'battery_preconditioning_navigation':'Thermal pre-conditioning is described for updated bZ4X/Touring in preview material, but navigation-triggered operation is not established in current exact-model equipment documents.',
'battery_density':'No pack mass or volume energy-density value on an explicit Wh/kg or Wh/L basis was found; battery kWh capacity is a different measurement.',
'referral_program':'No current Australian purchaser referral programme with eligible rewards and terms is specified.',
'heat_pump':'Dual-zone climate control does not establish heat-pump hardware; no explicit current Australian maker claim was found in the reviewed sources.',
'remote_preconditioning':'Connected services are fitted, but exact-grade remote cabin-temperature control and operation are not itemised in the two current model sources.',
'driver_profiles_local':'Power adjustment does not establish memory; no local driver-setting memory scope is itemised for this exact grade.',
'rear_heated_seats':'No rear-seat heating fitment is specified for this exact grade in the reviewed documents.',
'front_ventilated_seats':'No front-seat ventilation fitment is specified for this exact grade in the reviewed documents.',
'bidirectional_v2g':'A 1500 W AC appliance inverter does not establish vehicle-to-grid or vehicle-to-home capability.',
'glass_roof':'No glass roof option or standard glass roof is specified for this exact grade.'}
variants=[]
for vid in ids:
 bz=vid.startswith('toyota_bz4x_current');tw=bz and '__2wd__' in vid;aw=bz and not tw;tr='touring' in vid;hi='hilux' in vid;sr5='__sr5_' in vid;cc='cab_chassis' in vid
 spec='hilux_specs' if hi else 'touring_specs' if tr else 'bz4x_specs'
 companion='hilux_pricing' if hi else 'touring_range' if tr else 'bz4x_range'
 reviewed=[spec,companion]
 rows={}
 for key in keys:
  if key in skip:continue
  rows[key]=dict(criterion=key,value=None,grade='Not published',status='not_verified',condition=None,sourceKeys=reviewed,reason=reason.get(key,'No exact-grade claim found after inspecting the Australian specification and companion maker page.'),locator='Complete current AU specification table and exact-grade equipment lists searched',attemptedSourceUrls=[urls[s] for s in reviewed])
 def put(k,value,status='standard',grade='Confirmed',condition=None,sources=None,locator=None,reason=None):
  rows[k]=dict(criterion=k,value=value,grade=grade,status=status,condition=condition,sourceKeys=sources or [spec],reason=reason,locator=locator or ('PDF p3/p4 equipment table' if hi else 'PDF p2/p3 equipment table'))
 put('passive_unlock','Smart entry using the proximity key fob',locator='Smart entry and smart start / Smart entry and start system row',reason='Fob-based smart entry; no phone credential asserted.')
 put('carplay_android_auto','Wired and wireless Apple CarPlay and Android Auto' if hi else 'Wireless Apple CarPlay and Android Auto')
 put('voice_assistant','Embedded voice commands' if hi else 'Voice assistant; native vehicle/multimedia commands',reason='No generative assistant claimed.')
 put('v2l','220 V / 1500 W AC appliance outlet',condition='Combined appliance load limit 1500 W; powered from traction battery.',locator='HiLux PDF p3 AC inverter row; launch interior paragraph' if hi else 'PDF p3 V2L row and final-page footnote',sources=[spec,companion])
 put('charging_cable','Mode 2 and Mode 3 cables included',locator='PDF p1 battery and charging table')
 put('battery_chemistry','Lithium-ion; cathode chemistry not specified',locator='PDF p1 battery type row')
 put('app_connectivity','myToyota Connect; Essentials, Connect+ and Connected Multimedia',status='conditional',grade='Check',condition='Connect+ and Connected Multimedia include 1 year complimentary access from delivery, then fees. Essentials remain complimentary until the stated 4G sunset/service termination; compatible device, enabled DCM and coverage required.',locator='PDF final-page Connected Services rows and footnotes')
 put('ota_capability_scope','Connected Multimedia head-unit software and firmware OTA updates',sources=[spec,'connected_faq'],condition='Owner consent required; no broader propulsion/ADAS OTA scope asserted.',locator='Connected FAQs: How are my Connected Services updated?; exact-grade Connected Multimedia row')
 put('roadside_assistance',terms['roadside_assistance']['value'],status='optional',condition=terms['roadside_assistance']['condition'],sources=terms['roadside_assistance']['sourceKeys'],locator=terms['roadside_assistance']['locator'])
 put('service_network','Toyota dealer service centres across Australia (300+)',sources=['service_faq'],locator='Servicing FAQs: over 300 Toyota Dealer Service Centres; centre-level BEV capability and booking to be checked')
 put('supercharger_access','Selected Australian CCS Supercharger sites open to other EVs',grade='Reported',status='conditional',condition='Use Tesla app to check site/vehicle eligibility, price and cable reach; access is not to every Supercharger and Toyota-specific route integration is not established.',sources=[spec,'tesla_other_ev'],locator='Toyota CCS2 row; Tesla AU support General, Tesla App and On Site FAQs')
 if not hi:
  put('front_heated_seats','Heated driver and front-passenger seats')
  put('front_ventilated_seats','Not fitted to 2WD' if tw else 'Ventilated driver and front-passenger seats',status='unavailable' if tw else 'standard',sources=[spec,companion])
  put('heated_steering_wheel','Heated steering wheel')
  put('folding_mirrors','Auto-retractable exterior mirrors')
  put('power_tailgate','Powered tailgate with kick sensor',condition='Fitting a towbar requires the kick sensor to be deactivated.',locator='PDF p3 power back door row and towing footnote')
  put('glass_roof','Not fitted to 2WD' if tw else 'Fixed panoramic moonroof',status='unavailable' if tw else 'standard',sources=[spec,companion])
  put('wireless_charging','Two Qi-compatible wireless phone chargers',condition='Compatible Qi device required.')
  put('audio_system','6 speakers' if tw else '9-speaker JBL premium audio')
  put('screens_hud','14-inch centre touchscreen; 7-inch driver information display',reason='No head-up display claim established.')
  put('spare_tyre','Tyre repair kit',reason='Spare-wheel fitment not inferred beyond the published repair kit.')
  put('child_seats','Two ISOFIX positions at the rear outer seats',locator='PDF final-page safety row')
  put('parking_cameras','Panoramic View Monitor; front/rear parking sensors and Parking Support Brake'+('' if tw else '; Intelligent Parking Assist'),locator='PDF safety table and instruments: Intelligent Parking Assist row')
  put('adas_standard','Toyota Safety Sense: adaptive cruise, Lane Trace Assist, AEB, Emergency Steering Assist, Emergency Driving Stop, blind-spot and rear cross-traffic alerts',locator='PDF final-page safety table',reason='Driver assistance only; no autonomous-driving claim.')
  put('driver_alerts','Driver monitoring camera; rear occupant reminder; road-sign speed recognition; blind-spot/rear-cross-traffic alerts',locator='PDF safety table')
  put('bidirectional_v2g','V2H and V2G not supported by the V2L system',status='unavailable',locator='V2L footnote on PDF final page')
  put('safety_ancap','5-star ANCAP; 2025 assessment',grade='Reported',sources=['ancap_bz4x','ancap_bz4x_release'],condition='Current bZ4X October 2025-onward builds; rating expressly includes Touring. Earlier bZ4X has a separate 2022 assessment.',locator='ANCAP current bZ4X application paragraph; February 2026 media release')
  if not tw: put('driver_profiles_local','Driver-seat and exterior-mirror memory',locator='PDF p2 powered front seats with memory; exterior mirrors with memory and reverse adjust')
  if tr:put('rear_heated_seats','Heated rear seats',locator='PDF p2 Heated front and rear seats row',reason='Exact rear positions are not specified in the maker sheet.')
  if aw:put('rear_heated_seats','Heated rear seats',sources=['bz4x_range'],locator='AWD Comfort and convenience equipment list',reason='Maker grade page explicitly lists rear-seat heating. Its combined heating/ventilation wording is not used to claim rear ventilation; June PDF only details front ventilation.')
  if bz:
   put('remote_preconditioning','Remote cabin climate control through myToyota Connect',status='conditional',grade='Check',condition='Requires eligible Connect+ access; 1-year complimentary period then fees, enabled DCM and mobile coverage.',sources=['bz4x_specs','bz4x_feb26','connected'],locator='February 2026 exact-grade Connected Services table; June table retains Connect+ package')
   put('heat_pump','Heat pump',grade='Reported',sources=['carexpert_bz4x_2wd' if tw else 'carexpert_bz4x_awd'],locator='Ventilation System > Heat Pump: yes',reason='Exact 2026 AU FWD/AWD price-guide page; maker spec and range page do not explicitly name heat-pump hardware.')
 else:
  put('front_heated_seats','Heated driver and front-passenger seats' if sr5 else 'Not fitted to SR',status='standard' if sr5 else 'unavailable',sources=[spec,companion],locator='PDF p3 seat-heater row and March AU launch SR5 additions')
  put('heated_steering_wheel','Leather-accented heated steering wheel' if sr5 else 'Urethane steering wheel; not heated',status='standard' if sr5 else 'unavailable',sources=[spec,companion])
  put('folding_mirrors','Auto-retractable, heated exterior mirrors' if sr5 else 'Auto-retractable mirrors not fitted to SR',status='standard' if sr5 else 'unavailable',sources=[spec,companion],locator='PDF p2 exterior mirrors row; launch SR5 additions')
  put('wireless_charging','Qi-compatible wireless phone charger' if sr5 else 'Not fitted to SR',status='standard' if sr5 else 'unavailable',sources=[spec,companion])
  put('audio_system','8 speakers' if sr5 else '4 speakers')
  put('screens_hud','12.3-inch touchscreen; 12.3-inch driver display',reason='No head-up display claim established.')
  put('spare_tyre','Full-size spare alloy wheel',locator='PDF p2 wheels and tyres')
  put('child_seats','Rear outer ISOFIX and top-tether anchors; no centre rear top tether',grade='Reported',sources=[spec,'ancap_hilux'],condition='ANCAP does not recommend a child restraint in the dual-cab centre rear seating position because it has no top-tether anchorage.',locator='PDF p4 child seat anchors; ANCAP child-restraint application paragraph')
  put('parking_cameras','Analogue Panoramic View Monitor and reversing camera' if cc else 'Digital Panoramic View Monitor, reversing camera and front/rear parking sensors',locator='PDF p4 Safety rows')
  put('adas_standard','Toyota Safety Sense: dynamic radar cruise, Lane Trace Assist, AEB, Emergency Driving Stop, blind-spot and rear cross-traffic alerts'+('' if cc else '; rear parking support brake'),sources=[spec,companion],locator='PDF p4 safety; launch safety paragraph',reason='Rear parking support brake and parking sensors are pickup-only; no autonomous-driving claim.')
  put('driver_alerts','Lane-departure, blind-spot, rear-cross-traffic and seatbelt alerts; rear-seat reminder; tyre-pressure monitor',locator='PDF p4 Safety rows')
  put('power_tailgate','Cab-chassis has no pickup tailgate' if cc else 'Manual-lock tailgate with damper and lift assist',status='not_applicable' if cc else 'unavailable',locator='PDF p2 rear tailgate handle and tailgate damper rows')
  put('safety_ancap','5-star ANCAP; 2025 assessment extended to BEV',grade='Reported',sources=['ancap_hilux','ancap_hilux_release'],locator='ANCAP HiLux application paragraph; 3 June 2026 BEV extension announcement',reason='Applies to diesel and BEV variants except Rugged X; all three current BEV grades are covered.')
 variants.append(dict(variantId=vid,features=list(rows.values()),excludedCriteria=sorted(skip),sourceScan=dict(sourceKeys=reviewed,sourceUrls=[urls[s] for s in reviewed],reviewedAt='2026-10-14')))
notes=[
'Current versus outgoing bZ4X: do not inherit 2026 equipment backwards. Original AU launch lists 12.3-inch multimedia, 20-inch wheels and seven airbags; AWD alone gets heated steering wheel, front ventilation, memory and kick sensor. Current June 2026 sheet confirms 14-inch screen, eight airbags, twin wireless chargers and 1500 W V2L for both grades, with 18-inch wheels on 2WD. Current 2WD also has panoramic cameras/blind-spot safety not established on the original base trim.',
'Current official roadside membership page positively states Warranty Advantage mobility benefit is distinct from Roadside Assist. A covered warranty failure enables towing and loan car, not every roadside incident.',
'Warranty legal commercial-use definition is use-based (examples taxis, hire, transport of people/goods for payment including rideshare), not an automatic exclusion of every privately bought HiLux because its body is a ute.',
'Legal terms apply to new Toyota first registered in Australia from 1 January 2019. Used/ex-demonstrator remainder and WA start-date rules are specified in note 1; no model-year waiver should be invented. Actual earlier-delivery booklet still governs that vehicle.',
'Heat pump for current bZ4X 2WD/AWD is Reported from exact AU CarExpert specification pages. Touring and HiLux stay researched Not published rather than inheriting sibling/overseas hardware.',
'Navigation-triggered preconditioning remains researched Not published. Toyota AU preview announcements confirm thermal preconditioning improvements/general battery preparation, not the navigation trigger requested by this criterion.',
'ANCAP is direct assessment authority but Reported under the requested maker-only Confirmed framework.',
'Public Toyota direct curl returned Website Outage HTML; web retrieval supplied current/recently crawled official text. No CAPTCHA was solved. Search-index-only captures (HiLux pressroom, February bZ4X table, Tesla help) are separately identified. June warranty alternate URL returned404; the April PDF linked by the current warranty page was successfully read.'
]
out=dict(reviewedAt='2026-10-14',sources=sources,terms=terms,variants=variants,familyNotes=notes,scopeExclusions='No judgments invented for subjective experience, insurance quotes, personal FBT eligibility, resale or real-world range. Parent assembles numeric-derived storage/power/energy/home charging/warranty feature rows. Paint choices and quality are excluded here because the criterion combines paid paint options with subjective finish quality.')
(P/'normalized-evidence.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print('Wrote',len(sources),'sources,',len(terms),'terms,',sum(len(v['features']) for v in variants),'features')
print('Feature grades:',{g:sum(f['grade']==g for v in variants for f in v['features']) for g in ['Confirmed','Check','Reported','Not published']})
