import json, pathlib, hashlib
P=pathlib.Path('/tmp/toyota-research/current')
sources=json.loads((P/'sources.json').read_text())
before=json.load(open('/tmp/toyota-research/toyota-live-before.json'))
S={s['key']:s for s in sources}
B='toyota_bz4x_spec_20261014';BR='toyota_bz4x_range_20261014';BP='toyota_bz4x_page_20261014';PR='toyota_bz4x_prices_20261014';BL='toyota_bz4x_launch_20261014'
T='toyota_touring_spec_20261014';TR='toyota_touring_range_20261014';TP='toyota_touring_page_20261014';TL='toyota_touring_launch_20261014'
H='toyota_hilux_spec_20261014';HP='toyota_hilux_prices_20261014';HL='toyota_hilux_launch_20261014';W='toyota_warranty_20261014'
CT='carexpert_bz4x_2wd_towing_20261014';CD='carexpert_touring_dc_peak_20261014';CS='carsauce_hilux_sr5_test_20261014';N='toyota_bz4x_awd_nowra_20261014'
for s in sources:
 s['supports']=s.get('supports','Current named Australian version or inherited Toyota warranty evidence; source-specific locators are retained per fact.')
 for name in ('file','textFile'):
  p=pathlib.Path(s[name]);s[name+'Sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
 s['published_date']=s.get('published_date')
 s['source_capture_note']='Sanitized publicly visible source text; no response headers, cookies, scripts, CSRF, session or authentication values retained.'
S[B]['finalUrl']='https://www.toyota.com.au/-/media/toyota/main-site/vehicle-hubs/bz4x/files/20260619-bz4x_spec_table_gtp-010030.pdf?rev=2babd36c148f48e1a6a3a03cc2cbeaa7'
S[T]['finalUrl']='https://www.toyota.com.au/-/media/toyota/main-site/vehicle-hubs/bz4x-touring/file/20260507_bz4x_touring-_spec_table_gtp-009807.pdf?rev=d5fb9de5f1284d06bc4a57abe9a74cf4'
for key,files,pages,note in [(B,['bz4x-spec-p1.png','bz4x-spec-p2.png'],[1,2],'Named 2WD/AWD columns, motor maxima, AC/DC windows, range, seats, cargo, dimensions, towing, wheels and acceleration visually checked.'),(H,['hilux-spec-p2.png','hilux-spec-p3.png'],[2,3],'Three body/grade columns and SR/SR5 equipment columns visually checked; cab-chassis 245 versus pick-ups 315 NEDC; exact weights/dimensions and SR5 heated steering wheel.'),(T,['touring-spec-p2.png'],[2],'Touring single column checked: 4.4 seconds, 603 L VDA Max, 488 WLTP, 1500/750 kg towing, weights and wheels.')]:
 S[key]['visualReview']={'browser':'dot cloud Chrome browser, selected browser ID 1; CUA tab 17','checkedAt':'2026-10-14','pages':pages,'note':note,'artifacts':[{'path':str(P/f),'sha256':hashlib.sha256((P/f).read_bytes()).hexdigest()} for f in files]}

def fact(key,value,src,basis,comparison='',grade='confirmed',reason=None,qualifications=None,condition=None,pointer=None,**extra):
 if isinstance(src,str):src=[src]
 d=dict(key=key,value=value,sourceKeys=src,grade=grade,basis=basis,comparison=comparison,reason=reason or 'Current Australian maker material names this exact configuration and directly publishes this value; generic laboratory/build notes do not reduce the grade.',qualifications=qualifications or [],sourcePointer=pointer or 'Current named configuration row/section in linked source')
 if condition:d['condition']=condition
 d['evidenceScope']='searched_not_found' if value is None else ('secondary_or_sibling' if grade=='reported' else 'exact_au_version')
 d.update(extra);return d
def missing(key,src,reason,basis='Not published for this Australian configuration'):
 return fact(key,None,src,basis,grade='not_published',reason=reason)
out=[]
for i,old in enumerate(before):
 hilux=i>=3;touring=i==2;sr5=i==5;cab=i==3;awd=i in (1,2) or hilux
 sp=H if hilux else T if touring else B;page=HP if hilux else TP if touring else BP;rg=HP if hilux else TR if touring else BR
 src=[sp]; v={k:old[k] for k in ['id','modelId','model','trim','vehicleClass']};v.update(modelYear=None,drive='AWD' if awd else 'FWD')
 v['metadataReason']='Maker current Australian named versions and 2026 revision/launch dates are established; no formal MY designation inferred from calendar dates.'
 fs=[];v['facts']=fs
 def add(*a,**kw):fs.append(fact(*a,**kw))
 prices=[55990,67990,69990,74990,76490,82990];ranges=[591,517,488,245,315,315]
 add('price_aud',prices[i],HP if hilux else PR,'Maker’s list price · before on-road costs','Before on-road costs',priceRung=1,qualifications=['AUD; excludes on-road costs, optional paint and optional equipment. No financing bonus or charger offer deducted.'],pointer='Manufacturer list-price table and price-basis footnote')
 add('range_km',ranges[i],sp,'NEDC combined' if hilux else 'WLTP','NEDC combined' if hilux else 'WLTP',qualifications=[('17-inch wheels; cab-chassis' if cab else '17-inch wheels; pick-up') if hilux else ('20-inch wheels' if awd else '18-inch wheels'),'Laboratory figure; not a real-world guarantee.'],pointer='PDF page 2, named grade/body column, BEV driving test range; footnote specifies cycle')
 add('battery_kwh',59.2 if hilux else 74.7,sp if hilux or touring else [sp,BP],'Manufacturer battery capacity; gross/usable split not specified' if hilux else 'Gross battery capacity','Manufacturer capacity; gross/usable unspecified' if hilux else 'Gross battery capacity',qualifications=['Usable capacity not published in audited Australian maker material.'],pointer='PDF page 1 battery table; bZ4X main page GROSS BATTERY CAPACITY for gross label')
 fs.append(missing('battery_usable_kwh',[sp,page],'Australian specification sheet and model/launch page do not state usable capacity; overseas or Subaru figures are not imported.'))
 add('ac_kw',10 if hilux else 22,sp,'Maximum three-phase AC charging power','Maximum AC charging power',pointer='PDF page 1, Max AC charging power')
 if touring:
  add('dc_peak_kw',150,[CD,TL],'Maximum DC charging rate reported by CarExpert','',grade='reported',reason='Toyota describes support for 150 kW charging but its table labels station output. The local Australian CarExpert review explicitly labels 150 kW as Max DC charge rate.',qualifications=['Toyota primary launch confirms 150 kW charging capability; exact maximum vehicle intake wording comes from CarExpert.'],pointer='CarExpert local Touring review drivetrain table and paragraph: DC fast-charging tops out at 150 kW')
 else:add('dc_peak_kw',150,HP if hilux else BP,'Manufacturer stated vehicle DC capability','Maximum DC charging power',pointer='HiLux official press release caption says up to 150 kW DC fast charging; bZ4X main page explicitly says maximum intake 150 kW')
 if hilux:add('dc_charge_time_min',30,[sp,HP],'10–80%; 150 kW DC charger; Toyota approximate claim','10–80% DC charging',qualifications=['10–80% state of charge; 150 kW DC charger; environmental and battery conditions affect time.'],pointer='PDF page 1, 150 kW DC charging – 10–80%')
 else:
  conflict='May specification table says 30 minutes; current model/range pages and 2 July launch say 28 minutes.' if touring else 'June specification table says 45 minutes; December launch says 30 minutes; current model/range pages say 28 minutes.'
  add('dc_charge_time_min',28,[page,rg,sp,TL if touring else BL],'10–80%; 150 kW DC charger; current Toyota page claim','',grade='check',reason='Show the current model-page figure with its stated test condition while preserving an unresolved conflicting official PDF duration; no average or correction invented.',qualifications=[('Room-temperature charging' if touring else '25°C ambient environment'),conflict],condition=conflict,pointer='Current model page charging section and range-page 150 kW 10–80% row; compare PDF page 1')
 add('seats',5,sp,'Seating positions','Seating positions',pointer='PDF page 3 Capacity for HiLux; page 2 Seating capacity for SUVs')
 if hilux:fs.append(missing('boot_l',[sp,HL],'Neither the exact Australian specification sheet nor launch press kit publishes enclosed-boot volume in litres. Cab-chassis/tray or pick-up tub must not be normalised to passenger-boot litres.','Open ute load body; no enclosed passenger boot volume published'))
 else:
  qb=['VDA; row labelled Max; seats/load line not explicit.'] if touring else ['Seat/load line and cargo measurement method are not specified.','Generic main-page styling paragraph says 422 L; current exact-version sheet and grade card consistently say 452 L, also repeated in current Touring comparison.']
  add('boot_l',603 if touring else 452,[sp,rg], 'VDA cargo capacity, labelled Max; loading configuration unspecified' if touring else 'Manufacturer cargo volume; measurement/load configuration unspecified', 'VDA Max; loading configuration unspecified' if touring else 'Manufacturer cargo; measurement/load configuration unspecified',reason='Current exact-version technical and grade material has priority over a generic promotional paragraph; no folded-seat or roof-height basis inferred.',qualifications=qb,pointer='PDF page 2 named column: Cargo space (L), or Cargo capacity (VDA) (Max) (L)')
 if hilux:
  if sr5:add('zero_to_100_s',8.85,CS,'CarSauce Australian SR5 road-test measurement','',grade='reported',reason='Independent Australian SR5 test explicitly reports 8.85 seconds; this is a measured review result, not a manufacturer claim.',qualifications=['Exact SR5 Double-Cab Pick-Up tested; test load, surface and instrument protocol not fully specified.'],pointer='CarSauce review: Electric shove makes this the quickest HiLux section, indexed full article body')
  else:fs.append(missing('zero_to_100_s',[sp,HL],'Exact SR body/grade acceleration is absent from Australian specification sheet and launch press kit; a tested SR5 result is not silently assigned to lighter SR versions.'))
 else:add('zero_to_100_s',[7.4,5.1,4.4][i],sp,'Manufacturer 0–100 km/h claim','Manufacturer 0–100 km/h claim',pointer='PDF page 2, Acceleration 0 to 100 km/h; Touring 4.4 also in official range-expansion release')
 power=[167,252,280,144,144,144][i]
 add('power_kw',power,[sp,BP,BR] if i==0 else BL if i==1 else sp,'Front motor maximum output' if i==0 else 'Manufacturer combined system output','' if i==0 else 'Combined motor power',grade='check' if i==0 else 'confirmed',reason='June specification sheet and current landing page publish 167 kW; current range-page Max Power card and older launch retain 165 kW. Use 167 with explicit conflict; do not sum motor maxima.' if i==0 else 'System output is explicitly published by Toyota; individual motor peaks are not added.',condition='Current Toyota material differs: 167 kW on technical sheet and landing page versus 165 kW in grade-card Max Power.' if i==0 else None,pointer='June bZ4X page 1 motor table/main page; AWD combined 252 kW launch paragraph; Touring/HiLux page 1 Maximum output – system')
 add('drive_type',v['drive'],sp,'Manufacturer driven-wheel configuration','Drive type',pointer='PDF drivetrain table, FWD or AWD row')
 dims=[(4690,1860,1650,2850),(4690,1860,1650,2850),(4830,1860,1675,2850),(5080,1855,1865,3085),(5320,1855,1845,3085),(5320,1855,1845,3085)][i]
 for k,val in zip(['length_mm','width_mm','height_mm','wheelbase_mm'],dims):
  q=['Published cab-chassis length; completed vehicle length depends on fitted tray/body.'] if cab and k=='length_mm' else ['Mirror-inclusion basis not explicitly labelled.'] if k=='width_mm' else []
  add(k,val,sp,'Published cab-chassis length before final tray/body' if cab and k=='length_mm' else 'Manufacturer exterior dimension','Manufacturer exterior dimension',qualifications=q,pointer='PDF page 1 dimension drawing; HiLux page 2 exact body/grade dimension column')
 if i==0:
  add('towing_braked_kg',750,[CT,B],'Braked towing reported by CarExpert','',grade='reported',reason='Maker current sheet gives a 750 kg maximum without brake classification; exact Australian FWD CarExpert entry explicitly lists 750 kg braked.',qualifications=['Toyota Genuine towbar and vehicle/load limits apply.'],pointer='CarExpert exact FWD model overview and Gross Trailer Weight Braked; Toyota June PDF page 2 max towing row')
  add('towing_unclassified_kg',750,B,'Manufacturer maximum towing; brake classification unstated','Manufacturer unclassified maximum towing',pointer='PDF page 2 bZ4X 2WD: 750 (Max Towing Capacity)')
 else:add('towing_braked_kg',2000 if hilux else 1500,sp,'Maximum braked towing','Maximum braked towing',qualifications=['Towbar, vehicle, payload, axle, GVM/GCM and legal limits apply. For bZ4X, fitting towbar disables kick sensor.'],pointer='PDF page 2 exact towing row')
 if touring or hilux:add('towing_unbraked_kg',750,sp,'Maximum unbraked towing','Maximum unbraked towing',pointer='PDF page 2 Unbraked towing / Without brakes')
 elif i==0:add('towing_unbraked_kg',750,CT,'Unbraked towing reported by CarExpert','',grade='reported',reason='Exact Australian FWD CarExpert model page states 750 kg unbraked; current maker technical sheet does not split the figure.',pointer='CarExpert exact FWD model overview and Gross Trailer Weight Unbraked')
 add('warranty','5 years / unlimited km',W,'Australian private-use vehicle warranty','Vehicle warranty',reason='Current Toyota Australian brand-wide terms apply to all six versions and are inherited as Confirmed.',qualifications=['From first delivery; specified commercial use is 5 years/160,000 km. Separate electric-motor/driveline extension subject to prescribed maintenance.'],pointer='Warranty PDF printed page 3 warranty table; commercial-use note and printed page 4 notes')
 add('battery_warranty','8 years / 160,000 km',W,'Battery capacity guarantee below 70%; whichever comes first','Battery capacity warranty',reason='Current Toyota Australian brand-wide capacity warranty applies to BEVs; warranty terms are confirmed, with use conditions retained.',qualifications=['Repair/replacement if battery energy storage falls below 70% of original; prescribed battery-health checks, operation, charging and maintenance required. Specified commercial uses excluded.'],pointer='Warranty PDF printed page 3 table and page 4 note 5b')
 add('battery_defect_warranty','5 years base; conditional extension up to 10 years',W,'Battery defects; capacity degradation covered separately','Battery defect warranty',reason='The term itself is confirmed under Toyota Australian brand-wide terms; annual extension conditions remain explicit.',qualifications=['Base 5 years/unlimited km for ordinary private use; annual health inspections plus operation/charging/maintenance conditions extend each year to 10. Specified commercial use capped at 5 years/160,000 km and excluded from extension.'],pointer='Warranty PDF printed page 3 traction battery table and page 4 note 5a')
 add('battery_capacity_retention_percent',70,W,'Capacity guarantee threshold','Battery capacity guarantee threshold',pointer='Warranty PDF page 3 warranty table and page 4 note 5b')
 add('kerb_weight_kg',[1905,2035,2065,2280,2420,2455][i],sp,'Manufacturer maximum kerb weight','Maximum kerb weight',pointer='PDF page 2 named body/grade Maximum curb/kerb weight column')
 add('gvm_kg',[2465,2560,2560,3135,3145,3170][i],sp,'Manufacturer gross vehicle mass','Gross vehicle mass',pointer='PDF page 2 Gross vehicle weight / Gross Vehicle Mass')
 if hilux:
  add('gross_combination_mass_kg',4670,sp,'Gross combined mass','Gross combination mass',pointer='PDF page 2 merged Gross Combined Mass row applies to all three columns')
  add('body_configuration','Double-Cab Cab-Chassis' if cab else 'Double-Cab Pick-Up',sp,'Exact Australian body configuration','Body configuration',pointer='PDF page 2 body and tray-type column headings')
  if cab:add('payload_kg',855,HL,'Manufacturer advertised SR cab-chassis payload','Published payload',qualifications=['Fitted tray/body, occupants, accessories and towball load consume payload.'],pointer='July launch press kit explicitly gives 855 kg for SR cab-chassis')
  else:fs.append(missing('payload_kg',[sp,HL],'Official launch gives up to 725 kg depending on grade without assigning SR versus SR5; technical sheet publishes GVM/kerb, not a grade-labelled payload. Arithmetic not substituted for a published figure.'))
 else:add('ground_clearance_mm',211 if touring else 212,sp,'Manufacturer running ground clearance','Running ground clearance',pointer='PDF page 2 Running ground clearance')
 add('body_style','Double-Cab Cab-Chassis' if cab else 'Double-Cab Pick-Up' if hilux else 'SUV',sp,'Manufacturer body configuration','Body style',pointer='Current exact model/grade identity')
 add('wheel_size_in',17 if hilux else 20 if awd else 18,sp,'Standard alloy-wheel diameter','Wheel diameter',pointer='PDF page 2 Wheels design/size')
 add('battery_chemistry','Lithium-ion',sp,'Maker battery type; cathode subtype not specified','Battery chemistry',pointer='PDF page 1 battery type')
 add('charging_connector_ac','Type 2',sp,'Australian AC connector','AC connector',pointer='PDF page 1 AC input')
 add('charging_connector_dc','CCS2',sp,'Australian DC connector','DC connector',pointer='PDF page 1 DC input')
 add('ac_charge_time10to100',390 if hilux else 210,sp,'10–100%; 10 kW three-phase AC' if hilux else '10–100%; 22 kW three-phase AC','10–100% AC charging',qualifications=['Exact hours-to-minutes conversion of 6 h 30 min' if hilux else 'Exact hours-to-minutes conversion of 3 h 30 min'],pointer='PDF page 1 AC charging duration')
 add('v2l','Standard 220 V / 1500 W AC inverter',sp,'Manufacturer fitted AC inverter','V2L equipment',qualifications=['1.5 kW combined load; uses traction battery and reduces driving range. Not V2H or V2G.'] if not hilux else ['Traction battery supplies fitted 220 V/1500 W AC inverter.'],pointer='PDF page 3 Interior AC inverter row')
 add('v2l_output_kw',1.5,sp,'1500 W stated maximum AC inverter output','V2L power',pointer='PDF page 3 inverter row; exact W-to-kW conversion')
 add('apple_carplay','Wired and wireless' if hilux else 'Wireless',sp,'Standard smartphone connectivity','Smartphone connectivity',pointer='PDF page 3 Multimedia')
 add('android_auto','Wired and wireless' if hilux else 'Wireless',sp,'Standard smartphone connectivity','Smartphone connectivity',pointer='PDF page 3 Multimedia')
 add('screen_size_in',12.3 if hilux else 14,sp,'Multimedia touchscreen diagonal','Multimedia display size',pointer='PDF page 3 Multimedia touchscreen row')
 add('instrument_display_in',12.3 if hilux else 7,sp,'Driver information display diagonal','Instrument display size',pointer='PDF page 3 Multi Information Display')
 add('climate_control','Dual-zone automatic climate control',sp,'Standard climate equipment','Climate equipment',pointer='Comfort/Features table: dual-zone climate/air conditioning')
 add('airbags',8,sp,'Number of standard SRS airbags','Airbags',pointer='PDF safety table: 8x SRS airbags')
 add('heated_front_seats','Standard' if not hilux or sr5 else 'Not listed as standard',sp,'Exact grade equipment table','Heated front seats',pointer='SUV page 2 heated front seats; HiLux page 3 driver and passenger seat heater SR5 only')
 if not hilux or sr5:add('heated_steering_wheel','Heated steering wheel',sp,'Standard grade equipment','Heated steering wheel',pointer='PDF page 3 heated steering wheel row; SR5 column for HiLux')
 if not hilux:
  add('wireless_phone_chargers',2,sp,'Standard Qi-compatible wireless charging pads','Wireless charging pads',pointer='PDF page 3 two wireless phone chargers')
  add('power_tailgate','Power tailgate with kick sensor',sp,'Standard equipment','Tailgate equipment',pointer='PDF page 3 Power back door with kick sensor')
  add('roof_rails','Ladder-style roof rails' if touring else 'Roof rails',sp,'Standard equipment','Roof rails',pointer='PDF page 2 exterior')
  add('speaker_count',9 if awd else 6,sp,'Standard grade speaker count','Speakers',pointer='PDF page 3 Multimedia; 6x speakers 2WD, 9-speaker JBL AWD/Touring')
  add('tyre_repair','Tyre repair kit',sp,'Standard tyre mobility equipment','Tyre mobility equipment',pointer='PDF page 2 Wheels')
  if awd:
   add('panoramic_roof','Fixed panoramic glass roof',sp,'Standard grade equipment','Panoramic roof',pointer='PDF page 3 fixed panoramic moon roof')
   add('ventilated_front_seats','Standard',sp,'Standard grade equipment','Front seat ventilation',pointer='PDF page 2 ventilated driver/passenger seats')
   add('parking_assist','Intelligent Parking Assist',sp,'Standard grade equipment','Parking assist',pointer='PDF page 3 intelligent parking assist AWD/Touring column')
  if touring:add('heated_rear_seats','Standard',sp,'Standard equipment','Heated rear seats',pointer='PDF page 2 heated front and rear seats')
 else:
  add('speaker_count',8 if sr5 else 4,sp,'Standard grade speaker count','Speakers',pointer='PDF page 3 number of speakers SR/SR5')
  add('spare_wheel','Full-size spare alloy wheel',sp,'Standard tyre mobility equipment','Spare wheel',pointer='PDF page 2 Wheels and tyres')
  add('floor_covering','Carpet' if sr5 else 'Durable vinyl',sp,'Standard grade equipment','Cabin flooring',pointer='PDF page 3 Interior grade columns')
  if sr5:add('wireless_phone_chargers',1,sp,'Standard Qi-compatible phone charger','Wireless charging pads',pointer='PDF page 3 Qi Wireless phone charger SR5 column')
 if i==1:add('driveaway_price_aud',73690,N,'Specific dealer advertised driveaway · South Nowra NSW','',grade='reported',reason='The exact dealer advertisement still displays A$73,690 driveaway for AWD stock 13026009; this is not manufacturer pricing or proof of physical stock.',qualifications=['Advertisement still says Coming Soon with past ETA 30 July 2026; actual arrival and stock not verified.'],pointer='Dealer title/price/Drive Away, stock 13026009 and AWD dealer comments')
 v['availability']={'state':'current_or_order_listed','sourceKeys':[sp,HL if hilux else TL if touring else BL,rg],'orderStatus':'listed_unconfirmed','stockStatus':'unverified','qualifications':['Current Australian maker range plus completed Australian launch; physical stock, individual factory-order acceptance and delivery date are not independently verified.'],'reason':'Current Australian specification lists the exact version; maker launch establishes market release and HiLux release explicitly includes private buyers.'}
 if i==0:v['summary']={'strength':{'label':'591 km WLTP range','text':'The 2WD has a published 591 km WLTP range on its standard 18-inch wheels.','keys':['range_km','wheel_size_in']},'tradeoff':{'label':'Light towing only','text':'Braked towing is reported at 750 kg, limiting the size of trailer it can take.','keys':['towing_braked_kg']}}
 elif i==1:v['summary']={'strength':{'label':'AWD towing capability','text':'All-wheel drive, 252 kW system output and 1,500 kg braked towing suit buyers who need more traction and trailer capacity.','keys':['drive_type','power_kw','towing_braked_kg']},'tradeoff':{'label':'A$67,990 before on-roads','text':'The maker’s list price is A$67,990 before registration, delivery and other on-road costs.','keys':['price_aud']}}
 elif i==2:v['summary']={'strength':{'label':'Strong acceleration','text':'Toyota quotes 280 kW and a 4.4-second 0–100 km/h time.','keys':['power_kw','zero_to_100_s']},'tradeoff':{'label':'Longer parking footprint','text':'Its 4,830 mm length is worth checking against a tight garage or parking space.','keys':['length_mm']}}
 else:v['summary']={'strength':{'label':'2,000 kg braked towing','text':'The dual-motor AWD ute has a published 2,000 kg braked towing rating.','keys':['drive_type','towing_braked_kg']},'tradeoff':{'label':'Plan the charging stops','text':f'Its {ranges[i]} km NEDC laboratory range needs careful checking against the load and daily route.','keys':['range_km']}}
 out.append(v)

for i,v in enumerate(out):
 hilux=i>=3;touring=i==2;col=v['trim'];revision='May 2026' if hilux or touring else 'June 2026'
 # Do not redate a stale indexed dealer advertisement as a fresh live price.
 v['facts']=[f for f in v['facts'] if f['key']!='driveaway_price_aud']
 fm={f['key']:f for f in v['facts']}
 pointers={
  'price_aud':f"HiLux March 31 official release, 2026 Toyota HiLux BEV pricing table, {col}, and footnote 1" if hilux else f"Toyota three-grade bZ4X pricing release, 2026 Toyota bZ4X pricing table, {'Touring' if touring else col}, and footnote 1",
  'range_km':f'{revision} PDF page 2, {col} column, BEV driving test range (km); NEDC footnote 5' if i==3 else f'{revision} PDF page 2, {col} column, BEV driving test range (km); NEDC footnote 4' if hilux else f'{revision} PDF page 2, {col} column, BEV driving test range (km), WLTP footnote',
  'battery_kwh': 'HiLux May 2026 PDF page 1, Battery and Charging, Total power (kWh) 59.2' if hilux else 'Touring May 2026 PDF page 1, Battery Capacity (kWh) - Gross 74.7' if touring else 'bZ4X June 2026 PDF page 1 Total power (kWh) and current bZ4X main page GROSS BATTERY CAPACITY 74.7 kWh',
  'seats':f'HiLux May 2026 PDF page 3, Seating / Capacity, {"SR5 BEV" if i==5 else "SR BEV"} column' if hilux else f'{revision} PDF page 2, Weights and Capacities / Seating capacity - persons, {col} column',
  'length_mm':f'{revision} PDF page 2, Dimensions / Length-width-height, {col} body column' if hilux else f'{revision} PDF page 1, dimension drawing / overall length',
  'width_mm':f'{revision} PDF page 2, Dimensions / Length-width-height, {col} body column' if hilux else f'{revision} PDF page 1, dimension drawing / overall width',
  'height_mm':f'{revision} PDF page 2, Dimensions / Length-width-height, {col} body column' if hilux else f'{revision} PDF page 1, dimension drawing / overall height',
  'wheelbase_mm':f'{revision} PDF page 2, Dimensions / Wheelbase, {col} body column' if hilux else f'{revision} PDF page 1, dimension drawing / wheelbase',
  'kerb_weight_kg':f'{revision} PDF page 2, Weight / Maximum kerb weight automatic, {col} body column' if hilux else f'{revision} PDF page 2, Weights and Capacities / Maximum curb weight, {col} column',
  'gvm_kg':f'{revision} PDF page 2, Weight / Gross Vehicle Mass, {col} body column' if hilux else f'{revision} PDF page 2, Weights and Capacities / Gross vehicle weight, {col} column',
  'climate_control':f'HiLux May 2026 PDF page 3, Features / Front dual-zone air conditioning, {"SR5 BEV" if i==5 else "SR BEV"} column' if hilux else f'{revision} PDF page 2, Comfort and Convenience / Dual-zone climate control auto air conditioning, {col} column',
  'airbags':f'{revision} PDF page {3 if touring else 4}, {"Safety" if hilux else "Safety and Security"} / 8x SRS airbags, {col} column',
  'heated_front_seats':f'HiLux May 2026 PDF page 3, Seating / Driver and passenger seat heater, {"SR5 BEV marked standard" if i==5 else "SR BEV blank"}' if hilux else f'{revision} PDF page 2, Comfort and Convenience / Heated front {"and rear " if touring else ""}seats, {col} column',
  'body_style':f'HiLux May 2026 PDF page 2, Body type and Tray type headers, {col} column' if hilux else f'Current Toyota Australia {v["model"]} vehicle page and technical-sheet body dimensions',
 }
 if 'heated_steering_wheel' in fm:pointers['heated_steering_wheel']='HiLux May 2026 PDF page 3, Interior / Leather accented heated steering wheel, SR5 BEV column' if hilux else f'{revision} PDF page 3, Instruments and Controls / Heated steering wheel, {col} column'
 if i==0:pointers['power_kw']='bZ4X June 2026 PDF page 1, Electric motor / Maximum (kW) / Front motor, bZ4X 2WD column 167; current bZ4X main page Motor Max Output 167; current 2WD range card Max Power 165'
 elif i==1:pointers['power_kw']='Toyota 10 December 2025 upgraded bZ4X launch release, AWD paragraph explicitly publishing combined 252 kW output'
 else:pointers['power_kw']=f'{revision} {v["model"]} PDF page 1, {"Drivetrain and Transmission" if hilux else "Electric motor"} / Maximum output - system (kW), {280 if touring else 144}'
 pointers['drive_type']=f'{revision} PDF page {1 if hilux else 2}, Drivetrain and Transmission / {"AWD" if hilux else "All wheel drive" if i in (1,2) else "Front wheel drive"}, {col} column'
 if 'towing_unbraked_kg' in fm and (hilux or touring):pointers['towing_unbraked_kg']=f'{revision} PDF page 2, {"Towing capacity / Without brakes" if hilux else "Weights and Capacities / Unbraked towing capacity"}, {col} column'
 if not hilux:pointers['boot_l']=f'{revision} PDF page 2, Weights and Capacities / {"Cargo capacity (VDA) (Max) (L)" if touring else "Cargo space (L)"}, {col} column'
 if i<2:pointers['dc_peak_kw']='Current bZ4X main vehicle page, Improved Features / Faster charging, explicit maximum DC intake 150 kW'
 elif hilux:pointers['dc_peak_kw']='HiLux 31 March 2026 official press release, battery charging-capability paragraph and media caption stating up to 150 kW DC fast charging'
 if i<3:pointers['zero_to_100_s']=f'{revision} {v["model"]} PDF page 2, Performance / Acceleration 0 to 100 km/h, {col} column'
 if i>0:
  pointers['towing_braked_kg']=f'{revision} PDF page 2, Towing capacity / With brakes, shared across {col} body column' if hilux else f'{revision} PDF page 2, Weights and Capacities / Braked towing capacity, {col} column'
  fm['towing_braked_kg']['qualifications']=['Towbar, vehicle, payload, axle, GVM/GCM and legal limits apply.']
  if i==1:fm['towing_braked_kg']['qualifications'].append('June bZ4X specification footnote 4 says fitting the towbar requires deactivation of the kick boot sensor.')
 for key,pointer in pointers.items():
  if key in fm:fm[key]['sourcePointer']=pointer
sources=[s for s in sources if s['key']!=N]
report={'checkedAt':'2026-10-14','sources':sources,'variants':out,'lineup':{'current_configurations':6,'families':['bZ4X','bZ4X Touring','HiLux BEV'],'excluded':[{'model':'C-HR Electric / C-HR+','state':'Future Australian model; no current exact AU grades/order acceptance established','sourceKeys':['toyota_chr_future_20261014'],'reason':'Official Australian announcement gives first-half/mid-2027 arrival, with final grade specifications and prices to follow. Old Carsales future-order-book claim is insufficient current order evidence.'},{'model':'Urban Cruiser BEV','state':'Not confirmed for new official Australian sale','reason':'No current official Australian model/grade listing found; overseas-only specifications not admitted.'}],'notes':['Do not add WorkMate/Rogue/Rugged X diesel HiLux grades as BEVs. Only SR cab-chassis, SR pick-up and SR5 pick-up appear in current BEV sheet.','Do not add overseas Touring FWD, C-HR+ grades or Urban Cruiser variants.','Current wheels: 2WD18in, AWD20in, Touring20in, all HiLuxBEV17in. Published ranges belong to those exact combinations.']},'limitations':['Primary Toyota text was freshly rechecked through web.run. Direct raw HTTP requests returned403; official PDFs were independently rendered in dot cloud Chrome and visual table captures saved. No CAPTCHA solved.','Pressroom pages returned empty direct web extraction; current public indexed source bodies were captured with their crawl metadata.','Formal model-year identity not inferred from a 2026 launch or PDF revision.','HiLux exact SR acceleration, all HiLux boot litres and all usable battery capacities remain Not published; no estimates or sibling values substituted.','Charging conflicts are retained and the 28-minute display claim is explicitly unranked; no inferred reconciliation.','South Nowra A$73,690 ad was only retrieved from a two-month-old web index, not independently verified live. No fresh dealer-price fact is supplied; preserve the immutable earlier observation only.']}
(P/'normalized-evidence.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('Wrote',len(out),'variants,',sum(len(v['facts']) for v in out),'facts,',len(sources),'sources')
for v in out:print(v['id'],len(v['facts']))
