import json,pathlib,hashlib,re,collections
R=pathlib.Path('/tmp/toyota-research');D='2026-10-14';load=lambda p:json.loads((R/p).read_text());hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=load('toyota-2026-10-14.json');e=load('toyota-effective-facts.json');src={s['id']:s for s in p['sources']};before=load('toyota-live-before.json')
core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty','battery_warranty']
mat=[]
for c in before:
 fs={}
 for k in core:
  f=e[c['id']][k];fs[k]={x:f.get(x) for x in ['value','unit','basis','comparisonBasis','status','buyerGrade','conditionExplanation','qualifications','date','validUntil']};fs[k].update(reviewReason=f['gradeReview']['reason'],sourceIds=f['sourceIds'],sourceUrls=[src[x]['url'] for x in f['sourceIds']])
 mat.append(dict(variantId=c['id'],model=c['model'],trim=c['trim'],modelYear=c['year'],fields=fs))
(R/'core-matrix.json').write_text(json.dumps(dict(checkedAt=D,coreFieldCount=17,cells=len(mat)*17,rows=mat),indent=2,ensure_ascii=False)+'\n')
for s in p['sources']:
 for l,h in [('capture_locator','capture_sha256'),('capture_text_locator','capture_text_sha256')]:
  if s.get(l):assert hashfile(R/s[l])==s[h],s['id']
(R/'source-index.json').write_text(json.dumps(dict(checkedAt=D,scope='Current Toyota Australian Tier 1 BEV source observations, kept separate from immutable historical sources. Brand directories are in the companion reconciliation; they are not global C1 lists.',sources=p['sources']),indent=2,ensure_ascii=False)+'\n')
captures=[];findings=[];pats=[r'(?im)^set-cookie\s*:',r'(?im)^cookie\s*:',r'(?i)(?:csrf[_-]?token|requestverificationtoken|client_secret|access_token|refresh_token)["\x27]?\s*[:=]\s*["\x27][^"\x27\n]+']
for d in ['current','terms','residual','offers']:
 for f in sorted((R/d).rglob('*')):
  if not f.is_file() or '__pycache__' in f.parts:continue
  rel=str(f.relative_to(R));captures.append(dict(path=rel,bytes=f.stat().st_size,sha256=hashfile(f)))
  if f.suffix in ['.txt','.json','.html']:
   text=f.read_text(errors='replace');n=sum(len(re.findall(pat,text)) for pat in pats)
   if n:findings.append(dict(path=rel,matches=n))
assert not findings,findings
red=dict(checkedAt=D,policy='Do not save authentication headers, cookies, session tokens, CSRF tokens or client secrets in durable evidence copies. Public factual text, URLs and relevant PDF visuals retained.',scannedFiles=len(captures),detectedSensitiveCaptureValues=0,modifiedCaptureFiles=[],notes=['No authentication or cookie response headers were saved. Captures use public visible text and PDF page visuals. Failed public requests are documented and not factual evidence of absence.','No content redaction was required by the final scan, so no original/sanitized hash divergence is claimed. Individual raw/normalized capture hashes in source manifests are preserved.'])
(R/'redaction-audit.json').write_text(json.dumps(red,indent=2)+'\n')
(R/'source-hash-manifest.json').write_text(json.dumps(dict(checkedAt=D,scope='All source research files/captures in the four Toyota research folders; generated packet artifacts indexed separately.',files=captures),indent=2,ensure_ascii=False)+'\n')
missing=[];retained=[]
for c in before:
 for k,f in c['facts'].items():
  if f['value'] is not None and k not in e[c['id']]:
   if k=='driveaway_price_aud':retained.append(dict(variantId=c['id'],key=k,value=f['value'],date=f['date'],reason='Prior dealer advertisement remains an unchanged dated observation. Fresh live verification was unavailable; indexed page not used to refresh price or stock.'))
   else:missing.append(dict(variantId=c['id'],key=k))
assert not missing,missing
allf=[f for x in e.values() for f in x.values()]
assert all(all(s in src for s in f['sourceIds']) for f in allf)
assert all(f['value'] is None and len(set(src[s]['url'].split('#')[0] for s in f['sourceIds']))>=2 for f in allf if f['buyerGrade']=='not_published')
original=[];authorizedRegistration=[]
repo=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104')
for row in load('immutable-data-before.json'):
 f=repo/row['path']
 if hashfile(f)!=row['sha256']:
  assert row['path']=='data/m1-brand-updates/registry.json',row['path']
  current=json.loads(f.read_text());assert current['packets'][-1]=='toyota-2026-10-14.json'
  prior=json.loads(f.read_text());prior['packets'].pop()
  assert hashlib.sha256((json.dumps(prior,indent=2)+'\n').encode()).hexdigest()==row['sha256'],'Registry delta must be only appended approved Toyota packet'
  authorizedRegistration.append(dict(path=row['path'],beforeSha256=row['sha256'],afterSha256=hashfile(f),reason='Root registered the independently approved Toyota packet at 06:40 UTC; original packet/source files remain unchanged.'))
 else:original.append(row['path'])
checks=dict(checkedAt=D,originalDataFilesUnchanged=len(original),authorizedRootRegistrationChanges=authorizedRegistration,currentVersions=6,newVersions=0,coreCells=102,coreGradeCounts=dict(collections.Counter(v[k]['buyerGrade'] for v in e.values() for k in core)),allReviewedFactCount=len(allf),guardedFactEdits=len(p['facts']),brandTerms=len(p['brandTerms']),guardedEquipmentRows=len(p['features']),summaries=len(p['summaries']),retainedHistoricObservations=retained,sourceSnapshots=len(p['sources']),captureFiles=len(captures),allSourceCaptureHashesMatch=True,allNegativeFactsHaveTwoUsableUrls=True,unreviewedPriorNonNullFacts=missing,registered=bool(authorizedRegistration),registeredByResearchTask=False)
(R/'evidence-completeness-audit.json').write_text(json.dumps(checks,indent=2,ensure_ascii=False)+'\n')
names=['toyota-2026-10-14.json','toyota-reconciliation-2026-10-14.json','brand-model-list-reconciliation.json','source-index.json','source-hash-manifest.json','core-matrix.json','redaction-audit.json','evidence-completeness-audit.json','toyota-live-before.json','toyota-feature-before.json','toyota-source-before.json','immutable-data-before.json','normalized-evidence.json','terms-normalized.json','stage-validation.log','stage-validation.exit','staged-report.json','integration-readiness.json','REVIEW.md','independent-review-replay.json','independent-review-replay.log','independent-review-replay.exit','independent-review-supplement.json','independent-evidence-review.json','INDEPENDENT-REVIEW.md']
manifest=[]
for n in names:
 f=R/n
 if f.is_file():manifest.append(dict(path=n,bytes=f.stat().st_size,sha256=hashfile(f)))
(R/'artifact-hash-manifest.json').write_text(json.dumps(dict(checkedAt=D,files=manifest),indent=2,ensure_ascii=False)+'\n')
print(json.dumps(checks,indent=2))
