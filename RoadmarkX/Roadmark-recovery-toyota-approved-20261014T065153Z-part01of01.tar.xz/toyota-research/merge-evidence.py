import json,pathlib,copy
R=pathlib.Path('/tmp/toyota-research');load=lambda p:json.loads((R/p).read_text())
current=load('current/normalized-evidence.json');terms=load('terms/normalized-evidence.json');offers=load('offers/normalized-evidence.json')
gradeMap={'Confirmed':'confirmed','Check':'check','Reported':'reported','Not published':'not_published'}
def normalizeTerms(o):
 if isinstance(o,dict):
  for k,v in list(o.items()):
   if k=='grade':o[k]=gradeMap.get(v,v)
   elif k=='sourceKeys':o[k]=['terms_'+x for x in v]
   else:normalizeTerms(v)
 elif isinstance(o,list):
  for v in o:normalizeTerms(v)
normalizeTerms(terms)
sourceTitles={'hilux_pricing':'Toyota Australia HiLux BEV pricing and launch announcement','hilux_launch':'Toyota Australia HiLux BEV July 2026 press kit','bz4x_feb26':'Toyota bZ4X February 2026 Australian specification table','bz4x_old_specs':'Toyota bZ4X February 2025 Australian specification table','tesla_other_ev':'Tesla Australia Supercharging other electric vehicles'}
for s in terms['sources']:
 if not s.get('title'):s['title']=sourceTitles[s['key']]
 s['key']='terms_'+s['key']
for v in terms['variants']:
 v['id']=v.pop('variantId')
 for f in v['features']:
  if f['grade']=='not_published':f['value']='Not published'
  if f['grade'] in ['check','reported'] and f.get('status')=='standard':f['status']='conditional'
  if f.get('locator'):f.setdefault('qualifications',[]).append(f['locator'])
  if not f.get('reason'):
   authority='The named Australian maker grade table' if f['grade'] in ['confirmed','check'] else 'The cited independent Australian source'
   f['reason']=authority+' establishes '+str(f['value'])+' for this exact configuration. Evidence locator: '+str(f.get('locator') or 'the cited exact-version entry')+'.'
   if f.get('condition'):f['reason']+=' The specific eligibility or operating condition is retained separately.'
for k,t in terms['terms'].items():
 t['qualifications']=[x for x in [t.get('condition'),t.get('locator')] if x]
 if not t.get('reason'):t['reason']='Current Toyota Australia warranty terms expressly establish this conditional extension.'
 if k=='roadside_assistance':t['roadsideFitment']='optional'
ext=terms['terms']['electric_motor_driveline_extension']
terms['sharedAdditionalFacts']=[{**ext,'key':'warranty_extension','basis':'Australian electric-motor/driveline extension','comparison':''},
 {'key':'battery_defect_warranty','value':'5 years / unlimited km base; renewable annually after battery-health checks up to 10 years / unlimited km','grade':'check','sourceKeys':terms['terms']['battery_warranty']['sourceKeys'],'basis':'Australian traction-battery manufacturing-defect cover; capacity assurance separate','comparison':'','condition':terms['terms']['battery_warranty']['condition'],'qualifications':terms['terms']['battery_warranty']['qualifications'],'reason':'Base battery-defect cover is distinct from the genuinely conditional annual extension and capacity-assurance policy.'}]
pe=copy.deepcopy(current)
for v in pe['variants']:
 for f in v['facts']:
  if f['key']=='drive_type':f['key']='drive'
  if f['key'] in ['boot_l','width_mm']:f['comparison']=''
  if f['key']=='seats':f['comparison']='Seats'
  if f.get('sourcePointer'):f.setdefault('qualifications',[]).append('Source locator: '+f['sourcePointer'])
 for clause in v.get('summary',{}).values():clause['keys']=['drive' if k=='drive_type' else k for k in clause['keys']]
 if v['vehicleClass']=='ute':v['summary']['strength']['text']=v['summary']['strength']['text'].replace('dual-motor AWD ute','AWD ute')
 v['facts']=[f for f in v['facts'] if f['key']!='battery_defect_warranty']
pe['sources']+=terms['sources']+offers['sources']
res=load('residual/normalized-evidence.json') if (R/'residual/normalized-evidence.json').exists() else {'sources':[],'variants':[]}
pe['sources']+=res.get('sources',[]);pe['variants']+=res.get('variants',[])
keys={}
for s in pe['sources']:
 if s['key'] in keys:assert keys[s['key']]==s,('Source key conflict',s['key'])
 else:keys[s['key']]=s
pe['sources']=list(keys.values())
(R/'terms-normalized.json').write_text(json.dumps(terms['terms'],indent=2,ensure_ascii=False)+'\n')
termrows={r['id']:r for r in terms.get('variants',[])}
for v in pe['variants']:
 id=v['id'];facts=v.setdefault('facts',[]);features=v.setdefault('features',[]);existing={f['key']:f for f in facts};row=termrows.get(id,{})
 for f in row.get('facts',[]):
  if f['key'] in existing:
   assert existing[f['key']]['value']==f['value'],(id,f['key'],'conflict')
   continue
  facts.append(f);existing[f['key']]=f
 for f in terms.get('sharedAdditionalFacts',[]):
  if f['key'] not in existing:facts.append(copy.deepcopy(f));existing[f['key']]=f
 if v.get('availability',{}).get('state')=='current_or_order_listed':
  f=copy.deepcopy(offers['chargingOfferFact']);facts.append(f);existing[f['key']]=f
 used={r['criterion'] for r in features}
 for f in row.get('features',[]):
  if f['criterion'] in ['roadside_assistance','driveaway_price']:continue
  if f['criterion'] in used:raise ValueError(('Duplicate feature',id,f['criterion']))
  aliases={'battery_chemistry':['battery_chemistry'],'heated_steering_wheel':['heated_steering_wheel'],'v2l':['v2l','v2l_output_kw'],'front_heated_seats':['heated_front_seats'],'front_ventilated_seats':['ventilated_front_seats'],'rear_heated_seats':['heated_rear_seats'],'glass_roof':['panoramic_roof'],'power_tailgate':['power_tailgate'],'wireless_charging':['wireless_phone_chargers'],'carplay_android_auto':['apple_carplay','android_auto'],'audio_system':['speaker_count'],'screens_hud':['screen_size_in','instrument_display_in']}
  canonical=aliases.get(f['criterion'],[])
  if 'keys' not in f:
   key='feature_'+f['criterion'];rf=dict(key=key,value=None if f.get('grade')=='not_published' else f['value'],sourceKeys=f['sourceKeys'],grade=f.get('grade','confirmed'),basis='Australian exact-version '+f['criterion'].replace('_',' ')+' evidence',comparison='',reason=f['reason'],qualifications=f.get('qualifications',[]))
   if f.get('condition') or f.get('conditions'):rf['condition']=f.get('condition',f.get('conditions'))
   if f.get('evidenceScope'):rf['evidenceScope']=f['evidenceScope']
   facts.append(rf);existing[key]=rf;f={**f,'keys':[key]+([k for k in canonical if k in existing and existing[k]['value'] is not None] if f['grade']!='not_published' else [])}
  features.append(f);used.add(f['criterion'])
 # Numeric answers use canonical facts instead of parallel unguarded prose.
 def add(criterion,value,keys,**kw):
  if criterion not in used:features.append(dict(criterion=criterion,value=value,keys=keys,**kw));used.add(criterion)
 b=existing.get('boot_l')
 if b:
  if b['value'] is not None:add('storage',str(b['value'])+' L rear luggage volume; '+b['basis'],['boot_l'],conditions=' '.join(b.get('qualifications',[])))
  elif v.get('vehicleClass')=='ute':add('storage','Enclosed-boot litres are not published for this '+v['trim']+' body',['boot_l'],grade='not_published',conditions=b['reason'])
 # A wholly missing feature row must depend on its own null criterion fact; numeric gap alone does not qualify.
 if features and features[-1].get('criterion')=='storage' and features[-1].get('grade')=='not_published':
  features.pop();used.remove('storage')
 if 'ac_kw' in existing and existing['ac_kw']['value'] is not None:
  ac=existing['ac_kw'];add('home_charging',str(ac['value'])+' kW maximum AC charging input',['ac_kw'],conditions=' '.join(ac.get('qualifications',[])))
 if 'power_kw' in existing and existing['power_kw']['value'] is not None:
  pw=existing['power_kw'];add('performance_rear_motor',str(pw['value'])+' kW '+pw['basis'],['power_kw'],conditions=pw.get('condition',''))
 for criterion,key in [('energy_use','energy_use_wh_km'),('battery_chemistry','battery_chemistry')]:
  if key in existing and existing[key]['value'] is not None:add(criterion,str(existing[key]['value'])+' '+existing[key].get('unit','')+'; '+existing[key]['basis'],[key],conditions=' '.join(existing[key].get('qualifications',[])))
 if 'warranty_service' not in used:
  termsbase=terms['terms']['warranty'];ext=existing.get('warranty_extension');ks=['warranty']+(['warranty_extension'] if ext else [])
  add('warranty_service',termsbase['value']+('; '+ext['value'] if ext else ''),ks,grade='check' if ext and ext.get('grade')=='check' else termsbase.get('grade','confirmed'),conditions=ext.get('condition','') if ext else ' '.join(termsbase.get('qualifications',[])))
pe['notes']=pe.get('notes',[])+[offers['priceReview']]
(R/'normalized-evidence.json').write_text(json.dumps(pe,indent=2,ensure_ascii=False)+'\n')
print('Merged',len(pe['variants']),'versions;',len(pe['sources']),'source observations')
