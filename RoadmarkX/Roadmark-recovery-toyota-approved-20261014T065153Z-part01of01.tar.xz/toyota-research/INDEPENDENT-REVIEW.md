# Toyota M1 independent evidence audit

Reviewed 14 October 2026. Decision: approved for guarded integration of the six established Toyota versions, with the reviewed optional-roadside support present. No registry was edited by this review. This is not global C1 completion, an M1 release, or publication approval.

## Approved artifacts

- `toyota-2026-10-14.json`: `57ed2251d6e4f6e4bae3b5bb68390083e2f090336ef0b5f800c10c1e49f75e52`
- `toyota-reconciliation-2026-10-14.json`: `ed067827768e44729436205661d449af9b9ac688f02d81ed042441940d44c93d`
- `brand-model-list-reconciliation.json`: `d6f2f4b032cd98cd5a6260be266ed098660f3e4ef393dad187613a452853aed4`
- `residual/residual-closure.json`: `da1bb48d7e79231ede1de546c66d409645a6a29d3742fec831ce0dc696e783fe`

Approval applies to these exact bytes. A changed packet needs renewed review.

## Evidence judgment

- Current scope is bZ4X 2WD/AWD, bZ4X Touring AWD, and HiLux BEV SR double-cab cab-chassis, SR double-cab pickup and SR5 double-cab pickup. Formal model years are not inferred from launch or PDF dates. I independently reopened the official bZ4X/Touring specifications, current vehicle pages, Australian pricing announcement, warranty and roadside pages, and visually checked the saved specification tables.
- All six primary prices use the maker list-price rung: A$55,990, A$67,990, A$69,990, A$74,990, A$76,490 and A$82,990 before on-road costs. Conditional finance and charging benefits are separate. The charging offer retains vehicle/customer eligibility, deadlines, installation exclusion and 625 kWh cap. The cached South Nowra A$73,690 observation is retained at its original 10 October date; it is neither refreshed nor promoted to physical stock.
- Vehicle DC intake is not inferred from a charging-station rating. Touring peak DC remains Reported. Current 28-minute SUV charging claims preserve conflicting official 30/45-minute material, the 10–80% window, and stay unranked. HiLux's sourced 30-minute 10–80% claim is distinct. bZ4X 2WD's 167/165 kW conflict remains Check; combined motor outputs are not sums of motor peaks.
- Cargo values remain visible with their published method/limits, but unspecified load configuration is not silently converted to comparable boot capacity. HiLux boot litres and both SR acceleration values remain researched Not published; SR5 measured acceleration and 2WD braked towing remain Reported. Generic laboratory/build warnings do not cause per-fact downgrades.
- Base vehicle cover, battery defects, conditional annual extension and capacity assurance are distinguished, including specified commercial-use exclusions. The composite battery-defect extension is Check. Paid roadside membership is Confirmed evidence with optional fitment; warranty-covered towing/loan-car benefit is separate.
- Both brand directories are fully transcribed: CarsGuide 64 entries and CarExpert 24 entries, plus separate introductory names and reasoned differences. They are brand-only lists, with no global published-list claim. Previous-model residual candidates have bounded exclusions for removed exact ads, generic templates, used/demo/test-drive listings, or missing New evidence. No nationwide absence or sold-stock claim is made. C-HR remains a 2027 Australian lead; Urban Cruiser is not converted into an Australian on-sale version.

## Independent execution

`review-toyota-independent.ts` passed against the real application source, exit 0. It checked all before snapshots, 600 fact edits plus three shared terms (618 citable facts), 339 feature replacements, 415 exact post-fact dependencies, 65 capture references across 48 distinct files, actual pack/citation consistency, optional-roadside projection and exact portable pack equality. Other-brand cars, prior sources and 87 existing data files remained unchanged.

Ten negative mutation categories failed closed: version, fact, complete brand-term scope, feature before state, feature dependency, summary dependency, availability before state, price basis, invalid roadside enum, and roadside metadata on an unrelated fact. A separate existing-source collision failed closed. Eighteen actual Toyota roadside withdrawal/re-review cases preserved content and fitment while correctly removing/restoring evidence grades. All 119 source-manifest file hashes and byte sizes passed. The narrow roadside code change was inspected; no guard or existing test was weakened.

Evidence: `independent-review-replay.json`, `independent-review-replay.log`, `independent-review-supplement.json`; harness in the QA sibling directory. This review did not run a full production build or aggregate suite.

## Remaining limits

No integration blocker remains for the approved bytes. Toyota research is complete, but strict completion remains honest: C1, C2 and C5 fail; C3, C4 and C6 pass. The 102 core cells comprise 90 Confirmed, four Check, three Reported and five Not published. Ranked Toyota versions: price 6/6, range 6/6, seats 6/6, DC time 3/6, boot 0/6 and towing 5/6. Missing published facts, uncertain measurement bases and whole-market list reconciliation must not be hidden to make targets pass.
