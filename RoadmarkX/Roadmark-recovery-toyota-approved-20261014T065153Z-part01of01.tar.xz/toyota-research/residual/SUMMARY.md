# Toyota source-bound supply and model-list reconciliation

Checked 14 October 2026 UTC. Research only; repository source was not edited.

## Result

- Retain six current configurations: bZ4X 2WD and AWD, bZ4X Touring AWD, HiLux BEV SR double-cab cab-chassis, SR pickup and SR5 pickup
- No genuine current residual-New original 71.4 kWh bZ4X was established. Do not add old FWD/AWD versions from historical MSRPs, generic templates, low kilometres or old search snippets
- Toyota formally holds all-electric C-HR for 2027. Urban Cruiser is currently supported as a European-market model, not an Australian new-sale entry in the inspected sources
- Three existing Toyota inventory records; zero Toyota unverifiedLeads; one already-reconciled bZ4X/Touring umbrella lead. No fabricated lead IDs

## Residual-new decisions

Ulladulla #11541321 has old indexed New/MY24 metadata, but its correct root detail URL now returns direct HTTP 404. Its 2023 heading, MY24, January 2024 build and February 2024 compliance claims remain distinct. Ulladulla #11708400 AWD is another old New card; correct root detail returns 404. Neither establishes new stock today or proves sold.

Carsales SHRM-AD-6450882 (original AWD) and SHRM-AD-6476103 (original FWD) explicitly identify themselves as Carsales-created generic templates, not dealer/manufacturer listings. The indexed New collection has sixteen New-car-to-order cards and no Dealer-new label. A 13 km AWD in the 2025 collection is explicitly Dealer used. Kelly’s original AWD is a demonstrator and Kyneton’s original FWD is a test-drive car.

The six-kilometre 2024 2WD at Morningside is a Toyota used-collection card; its exact detail did not retrieve. No New classification or proven stock/VIN is available. It is not admitted.

## Two independent directories

CarsGuide/Glass’s: all 22 current cards and 42 older links transcribed. Only BZ4X and HiLux are tagged Electric. CarExpert/JATO: all 16 current-unmarked and eight Discontinued cards transcribed, plus three names appearing only in introduction. Each row has a finite disposition. bZ4X includes Touring under both directory umbrellas; HiLux mixes powertrains. Fortuner and Supra current/discontinued disagreements do not add BEVs.

These are brand-only mixed lists. They support Toyota scope closure but are not two complete Australian market lists and must not populate global publishedLists.

## Previous current-stock candidates

Downtown VIN JTMACDEB10J032091 now redirects to a generic model page with no stock listing and a different test-drive VIN. Warragul Touring and three CMI HiLux URLs return web Internal Error. Preserve unresolved retrieval/cache-only states. Nowra #13026009 still appears New in a two-month-old web cache with A$73,690 driveaway and a past 30 July ETA; this worker did not perform a new direct-live refresh of that ad.

## Files

- brand-model-list-reconciliation.json: complete directory transcriptions and every difference
- residual-closure.json: integration summary and residual decisions
- m1-toyota-market-reconciliation.json: four typed current reviews, three existing record resolutions, empty global lists
- residual-new-audit.json: original specification/price boundaries and exact candidate decisions
- lead-dispositions.json: existing record/lead IDs, prose-only future leads and stock-candidate status
- manifest.json: SHA-256 evidence file hashes

Saved captures contain public rendered text/status information only. No cookies, credentials, CSRF values or browser-session data were saved. No CAPTCHA solved, enquiry sent, dealer contacted or order initiated.
