#!/usr/bin/env python3
"""Pure closing-adapter metadata and AST mutations; no normalize/scan/archive work."""
import ast,collections,copy,hashlib,importlib.util,json,pathlib,resource,sys
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent
ADAPTER={'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/nissan_closing_adapter_v5.py', 'bytes': 36401, 'sha256': '8bc24997dfb2726c090c4a86538eaf8682ee6dd51a0639322fc7af48e4d245e0'}
def pin(p):
    b=P(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def checked(r):
    assert pin(r['path'])==r;return P(r['path']).read_bytes()
def encoded(d):return (json.dumps(d,indent=2)+'\n').encode()
def main():
    resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456));checked(ADAPTER)
    spec=importlib.util.spec_from_file_location('nissan_closing_pure_fixture',ADAPTER['path']);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    counts=collections.Counter()
    def reject(name,fn):
        try:fn()
        except (AssertionError,ValueError,KeyError,TypeError,IndexError):counts[name]+=1
        else:raise AssertionError('Unexpected mutation acceptance: '+name)
    raw=checked(m.PINS['rawResponse']);request=checked(m.PINS['rawRequest']);selection=checked(m.PINS['activeSelection'])
    view=m.one_row_view(raw,request,selection);assert view['structuredContent']=={'results':[json.loads(raw)['structuredContent']]};assert 'results' not in json.loads(raw)['structuredContent'];counts['exact_active_direct_view']=1
    for label,args in [('raw_hash',(raw+b' ',request,selection)),('request_hash',(raw,request+b' ',selection)),('selection_hash',(raw,request,selection+b' '))]:reject(label,lambda args=args:m.one_row_view(*args))
    req=json.loads(request);res=json.loads(raw);expected=copy.deepcopy(res['structuredContent']);pkg={'file':req['file'],'filename':expected['file_name'],'bytes':expected['file_size_bytes']}
    assert m.create_tuple(req,res,pkg,'direct-single',expected)==expected;counts['correction_direct_single']=1
    batch_expected={k:v for k,v in expected.items() if k!='external_connectors_accessed'}
    batch={**res,'structuredContent':{'results':[copy.deepcopy(batch_expected)],'warnings':[],'external_connectors_accessed':False}}
    assert m.create_tuple(req,batch,pkg,'batch-single',batch_expected)==batch_expected;counts['correction_batch_single']=1
    for shape,base in [('direct-single',res),('batch-single',batch)]:
        nominated=expected if shape=='direct-single' else batch_expected
        for field in nominated:
            changed=copy.deepcopy(base);row=changed['structuredContent'] if shape=='direct-single' else changed['structuredContent']['results'][0];del row[field]
            reject('missing_'+shape,lambda changed=changed,shape=shape,nominated=nominated:m.create_tuple(req,changed,pkg,shape,nominated))
            changed=copy.deepcopy(base);row=changed['structuredContent'] if shape=='direct-single' else changed['structuredContent']['results'][0];row[field]='changed'
            reject('changed_'+shape,lambda changed=changed,shape=shape,nominated=nominated:m.create_tuple(req,changed,pkg,shape,nominated))
        changed=copy.deepcopy(base);changed['isError']=True;reject('create_error',lambda changed=changed,shape=shape,nominated=nominated:m.create_tuple(req,changed,pkg,shape,nominated))
        for q in ({'file':'/wrong'},{'files':[req['file'],req['file']]},{'files':[req['file']],'file':req['file']}):reject('wrong_request',lambda q=q,shape=shape,base=base,nominated=nominated:m.create_tuple(q,base,pkg,shape,nominated))
    for body in ({'results':[batch_expected]},{'results':[],'warnings':[],'external_connectors_accessed':False},{'results':[batch_expected,batch_expected],'warnings':[],'external_connectors_accessed':False},{'results':[batch_expected],'warnings':['warning'],'external_connectors_accessed':False},{'results':[batch_expected],'warnings':[],'external_connectors_accessed':True},{'results':[batch_expected],'warnings':[],'external_connectors_accessed':False,'operation':'create_library_file'},{}):
        wrong={**res,'structuredContent':body};reject('batch_mixed_extra_missing',lambda wrong=wrong:m.create_tuple(req,wrong,pkg,'batch-single',batch_expected))
    reject('direct_rejects_batch',lambda:m.create_tuple(req,batch,pkg,'direct-single',expected));reject('batch_rejects_direct',lambda:m.create_tuple(req,res,pkg,'batch-single',expected))
    for field,value in [('operation','other'),('status','failed'),('path','/wrong'),('file_name','wrong'),('file_size_bytes',0),('library_file_id','wrong'),('file_id','wrong'),('current_version_number',True),('current_version_number',-1),('xattrs',[{'name':'user.library-file-id','value':'fake'}])]:
        row=copy.deepcopy(expected);row[field]=value;wrong={**res,'structuredContent':row}
        reject('invalid_even_if_nominated',lambda row=row,wrong=wrong:m.create_tuple(req,wrong,pkg,'direct-single',row))
    for mode in ('documents','active'):
        refs=m.PRIOR[mode];d=json.loads(checked(refs['receipt']));c=json.loads(checked(refs['contract']));r=json.loads(checked(refs['review']))
        m.validate_prior(mode,d,c,r,ADAPTER);counts['exact_prior_v7']+=1
        for obj,field in [('receipt','checkerScript'),('runtime','checker'),('review','checker')]:
            dd,cc,rr=copy.deepcopy(d),copy.deepcopy(c),copy.deepcopy(r);{'receipt':dd,'runtime':cc,'review':rr}[obj][field]=ADAPTER
            reject('prior_wrong_checker',lambda dd=dd,cc=cc,rr=rr,mode=mode:m.validate_prior(mode,dd,cc,rr,ADAPTER))
        for obj,field,value in [('runtime','mode','terminal'),('review','mode','terminal'),('review','result','wrong'),('review','contract',refs['receipt']),('receipt','runtimeInputContract',refs['receipt']),('receipt','runtimeInputContractReview',refs['receipt'])]:
            dd,cc,rr=copy.deepcopy(d),copy.deepcopy(c),copy.deepcopy(r);{'receipt':dd,'runtime':cc,'review':rr}[obj][field]=value
            reject('prior_wrong_runtime_binding',lambda dd=dd,cc=cc,rr=rr,mode=mode:m.validate_prior(mode,dd,cc,rr,ADAPTER))
    d={'checkerScript':ADAPTER,'runtimeInputContract':{'path':str(C/'pure-fixture-persisted.json'),'bytes':0,'sha256':'0'*64}};c={'checker':ADAPTER,'mode':'persisted'};r={'checker':ADAPTER,'mode':'persisted','contract':d['runtimeInputContract'],'result':'ACCEPTED_EXACT_NISSAN_DELIVERY_RUNTIME_CONTRACT'}
    m.validate_prior('persisted',d,c,r,ADAPTER);counts['persisted_current_adapter']=1
    dd=copy.deepcopy(d);dd['checkerScript']=m.PINS['checker'];reject('persisted_rejects_v7',lambda:m.validate_prior('persisted',dd,c,r,ADAPTER))
    bases=[]
    for kind,key in [('checker','checker'),('producer','producer')]:
        b=checked(m.PINS[key]);before=ast.parse(b);after=m.transform(b,kind);bases.append(m.PINS[key]);counts['exact_base_transform']+=1
        # The same final-accounting literal in active() must stay untouched.
        names=('active','documents') if kind=='checker' else ('active','docs','normalize')
        for name in names:
            f=next(x for x in before.body if isinstance(x,ast.FunctionDef) and x.name==name);g=next(x for x in after.body if isinstance(x,ast.FunctionDef) and x.name==name);assert ast.dump(f)==ast.dump(g);counts['unaffected_function_unchanged']+=1
        reject('changed_base_source_hash',lambda b=b,kind=kind:m.transform(b+b' ',kind))
        wrong=ast.parse(b);target=next(x for x in wrong.body if isinstance(x,ast.FunctionDef) and x.name==('final_receipt' if kind=='checker' else 'final'))
        literals=[x for x in ast.walk(target) if isinstance(x,ast.Constant) and x.value=='SEED-READ-ACCOUNTING-after-active-v1.json'];assert len(literals)==1;literals[0].value='unexpected-accounting.json';bad=ast.unparse(wrong).encode();old=m.PINS[key];m.PINS[key]={'path':old['path'],**m.bp(bad)}
        try:reject('wrong_transform_occurrence',lambda bad=bad,kind=kind:m.transform(bad,kind))
        finally:m.PINS[key]=old
    # Independent replay runtime/command and correction-accounting checks use ordinary in-memory metadata.
    def fixture(label):return {'path':str(C/(label+'.json')),'bytes':1,'sha256':'0'*64}
    d={'package':fixture('package'),'inventory':fixture('inventory'),'selection':fixture('selection'),'privacy':{'report':fixture('scan-report'),'invocation':fixture('scan-delivery-correction-v1.resources.invocation'),'terminal':fixture('scan-delivery-correction-v1.resources')}}
    packaging={'helper':fixture('different-package-helper'),'independentReview':fixture('packaging-review')};pkgmeta={'contract':fixture('packaging-contract')}
    replay={'verifierScript':m.PINS['correctionVerifier'],'runtimeInputContract':fixture('replay-contract'),'runtimeInputContractReview':fixture('replay-review')}
    rc={'schemaVersion':1,'verifier':m.PINS['correctionVerifier'],'package':d['package'],'inventory':d['inventory'],'privacySelection':d['selection'],'packagingContract':pkgmeta['contract'],'packagingReview':packaging['independentReview'],'privacy':d['privacy'],'outsideRecoveryArchiveSet':True,'unchangedRecoveryArchiveCount':145,'nativeByteReadbackVerified':False}
    rr={'verifier':m.PINS['correctionVerifier'],'result':'ACCEPTED_EXACT_NISSAN_CORRECTION_REPLAY_CONTRACT','contract':replay['runtimeInputContract']}
    command=['python',m.PINS['correctionVerifier']['path'],'--contract',replay['runtimeInputContract']['path'],'--contract-sha256',replay['runtimeInputContract']['sha256'],'--review',replay['runtimeInputContractReview']['path'],'--review-sha256',replay['runtimeInputContractReview']['sha256']]
    m.validate_replay_binding(replay,rc,rr,command,d,pkgmeta,packaging);counts['exact_independent_replay_binding']=1
    for obj,field,value in [('replay','verifierScript',packaging['helper']),('runtime','verifier',packaging['helper']),('review','verifier',packaging['helper']),('review','contract',fixture('wrong-contract')),('review','result','wrong'),('runtime','package',fixture('wrong-package')),('runtime','outsideRecoveryArchiveSet',False),('runtime','unchangedRecoveryArchiveCount',146)]:
        a,b,c=copy.deepcopy(replay),copy.deepcopy(rc),copy.deepcopy(rr);{'replay':a,'runtime':b,'review':c}[obj][field]=value
        reject('independent_replay_wrong_binding',lambda a=a,b=b,c=c:m.validate_replay_binding(a,b,c,command,d,pkgmeta,packaging))
    wrong=command[:-1]+['f'*64];reject('independent_replay_wrong_command',lambda:m.validate_replay_binding(replay,rc,rr,wrong,d,pkgmeta,packaging))
    name=P(d['privacy']['invocation']['path']).relative_to(C).as_posix();ac={'phases':[{'invocation':{'path':name},'outcome':'PASS'}],'stages':{k:{'records':[{'phaseInvocation':{'path':name},'scanOutcome':'PASS'}]} for k in ('historical','audi','deepal')}}
    m.correction_stage_accounting(ac,d);counts['exact_correction_accounting']=1
    for k in ('historical','audi','deepal'):
        changed=copy.deepcopy(ac);changed['stages'][k]['records']=[];reject('missing_correction_stage',lambda changed=changed:m.correction_stage_accounting(changed,d))
        changed=copy.deepcopy(ac);changed['stages'][k]['records']*=2;reject('duplicate_correction_stage',lambda changed=changed:m.correction_stage_accounting(changed,d))
    changed=copy.deepcopy(ac);changed['phases'][0]['outcome']='UNKNOWN';reject('correction_scan_not_pass',lambda:m.correction_stage_accounting(changed,d))
    checked_identity={'normalizationContract':fixture('create-contract'),'normalizationReview':fixture('create-review')};closing=fixture('closing-contract')
    command=['python',ADAPTER['path'],'normalize-correction','--closing-contract-sha256',closing['sha256'],'--create-contract-sha256',checked_identity['normalizationContract']['sha256'],'--create-review-sha256',checked_identity['normalizationReview']['sha256']]
    m.validate_identity_command(command,closing,checked_identity);counts['exact_identity_normalization_command']=1
    wrong=command[:-1]+['f'*64];reject('wrong_identity_normalization_command',lambda:m.validate_identity_command(wrong,closing,checked_identity))
    reject('unsupported_transform_kind',lambda:m.transform(checked(m.PINS['producer']),'unsupported'))
    result={'result':'PASS_NISSAN_CLOSING_ADAPTER_PURE_TESTS','adapter':ADAPTER,'testScript':pin(P(__file__).resolve()),'proposal':m.PINS['proposal'],'baseCodeFixtures':bases,'cases':dict(counts),'caseCount':sum(counts.values()),'scope':{'pureMetadataAndAstOnly':True,'normalizeCalled':False,'producerOrCheckerExecuted':False,'scanConfiguration':False,'seedLoading':False,'archiveOpening':False,'xattrWrites':False,'hostCreate':False,'sourceMutation':False}}
    target=C/'NISSAN-CLOSING-ADAPTER-PURE-TEST-RESULT-v1.json'
    with target.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({'result':result['result'],'output':pin(target),'cases':dict(counts),'caseCount':result['caseCount']}))
if __name__=='__main__':main()
