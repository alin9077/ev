#!/usr/bin/env python3
"""Exact active single-create view and separately retained Nissan closing checks."""
import argparse,ast,copy,hashlib,json,os,pathlib,stat,sys,types
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent
# Constants are replaced with exact metadata pins by the immutable preparation writer.
PINS={'rawRequest': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/library-active-host-create-request.json', 'bytes': 226, 'sha256': 'd9f28cfc52af5fa17165b0eda5b21eacf5243bd3d632635bfe1bc776984a6dc5'}, 'rawResponse': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/library-active-provider-results.json', 'bytes': 879, 'sha256': '5bb3bdef736801b04cdb1092bc694cecfd896cc566404203d425d50ac2d66bd1'}, 'staticHold': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/ACTIVE-SINGLE-CREATE-SHAPE-HOLD-v1.json', 'bytes': 1154, 'sha256': '3c145497f3ffae66b3349cc3016a42c8f8a3f392e149b2d8fb1ec510aa4aaba3'}, 'activeSelection': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/ACTIVE-PRIVACY-SELECTION-v1.json', 'bytes': 334, 'sha256': 'e7ac0d131a409a4b29b380e3535bec2e27fcb24d7283d4f16eeffd88b79a4093'}, 'activeCheck': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/INDEPENDENT-NISSAN-ACTIVE-CHECK-v1.json', 'bytes': 105317, 'sha256': '5980915f56e348998119fa4463cb3e96394fa44792b8f97fd051b32a5ad1730f'}, 'activePrivacy': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/scan-active-v1.json', 'bytes': 1623, 'sha256': '08ae322d15215e2ae3969ce1ea78cd8e737c2ddd2b049374982285c597cdc852'}, 'sixScanAccounting': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/SEED-READ-ACCOUNTING-after-active-v1.json', 'bytes': 20748, 'sha256': '1be5b3c6e43f180a55c74a2bb267aff5eec9d43b568b7086cf97855fde33ad07'}, 'producer': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/nissan_delivery_v3.py', 'bytes': 16490, 'sha256': 'e65fd17136f06032dced858053d61ad7365fca47acd5a969b351e37e6196857f'}, 'producerContract': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/NISSAN-DELIVERY-CONTRACT-v3.json', 'bytes': 1042, 'sha256': '144218a51468aa9f2d08808a386ab15b2af23a0d080080103b51d39a4331af5f'}, 'checker': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/independent_nissan_delivery_v7.py', 'bytes': 46199, 'sha256': 'ac1652f80f0aaf8113120a431c4eecbb392f6ceed68e7074be5f7914258ebd1a'}, 'normalizer': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/renault-working-20261015T2040/delivery_native_adapter_v3.py', 'bytes': 12641, 'sha256': 'f5bec06d762fca6b3d34ea13f7e7f17d2f5353dbbd379a5e1b13e967aabbc474'}, 'proposal': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/NISSAN-ACTIVE-SINGLE-CREATE-CLOSING-ADAPTER-PROPOSAL-v1.json', 'bytes': 10808, 'sha256': '03ee9db10c32702de2ba55893aac61bc41437c835c31c1703729db2a1cbb2b44'}, 'activeFile': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/deliverables/Roadmark-RECOVERY-ACTIVE-STATE-NISSAN-WORKING-20261015.json', 'bytes': 636622, 'sha256': '3eb850e43be61d699f7af984b608a65638b310fc0e4f42d620d05539db2a1eb5'}}
PINS['correctionVerifier']={'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/independent_nissan_correction_replay_v2.py', 'bytes': 9146, 'sha256': 'e595f272ad4d7630747d9b3bf6ebdfe46058df0aa6fee92722305c73a1c8f2b2'}
PRIOR={'documents': {'receipt': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/INDEPENDENT-NISSAN-DOCUMENT-CHECK-v1.json', 'bytes': 87641, 'sha256': 'a088d6c9516af1f3ee9ccdf3c01c8837fe1587770acc1716438949a08ae3b774'}, 'contract': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/NISSAN-DELIVERY-DOCUMENTS-RUNTIME-CONTRACT-v1.json', 'bytes': 81104, 'sha256': '89c12266baa14584791f9d56ab0c4d8a11b12fc155b2810dad4833053ce70f3e'}, 'review': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/INDEPENDENT-NISSAN-DELIVERY-DOCUMENTS-RUNTIME-REVIEW-v1.json', 'bytes': 4858, 'sha256': '0a58b344aa89309f7684b16b5b61284a5ceed3ae9a9bbc6aef3419a65124bcf2'}}, 'active': {'receipt': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/INDEPENDENT-NISSAN-ACTIVE-CHECK-v1.json', 'bytes': 105317, 'sha256': '5980915f56e348998119fa4463cb3e96394fa44792b8f97fd051b32a5ad1730f'}, 'contract': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/NISSAN-DELIVERY-ACTIVE-RUNTIME-CONTRACT-v1.json', 'bytes': 96017, 'sha256': 'f2f4964b57ec342049aafd88074711e5f98f55791e32285bebe8a6bebc56846e'}, 'review': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/INDEPENDENT-NISSAN-DELIVERY-ACTIVE-RUNTIME-REVIEW-v1.json', 'bytes': 3238, 'sha256': '201a66d0da94fec79dfc79173d6be53fbd00b5445fed2c73b193196d011a9af7'}}}
ACTIVE_ROW={'operation': 'create_library_file', 'status': 'succeeded', 'path': '/Roadmark-RECOVERY-ACTIVE-STATE-NISSAN-WORKING-20261015.json', 'file_id': 'file_00000000779081fa91dad954354e0376', 'library_file_id': 'libfile_a136100e2ba88191a01643d14b319972', 'file_name': 'Roadmark-RECOVERY-ACTIVE-STATE-NISSAN-WORKING-20261015.json', 'current_version_number': 0, 'restored_from_version_number': None, 'xattrs': [{'name': 'user.library-file-version', 'value': '0'}], 'directory_id': 'libdir_61ac34c5ff288191949e460201b51f34', 'mime_type': 'application/json', 'library_artifact_type': 'report', 'file_size_bytes': 636622, 'external_connectors_accessed': False}
VIEW_RULE='EXACT_PINNED_ACTIVE_DIRECT_OBJECT_TO_IN_MEMORY_RESULTS_SINGLETON_ONLY'
ACCOUNTING=C/'SEED-READ-ACCOUNTING-after-correction-v1.json'
RETENTION=C/'NISSAN-CLOSING-RETENTION-v1.json'
CONTRACT_PATH=C/'NISSAN-CLOSING-ADAPTER-CONTRACT-v1.json'

def ck(ok,message):
    if not ok:raise ValueError(message)
def sh(r):return {k:r[k] for k in ('bytes','sha256')}
def bp(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def ref(p):return {'path':str(p),**bp(P(p).read_bytes())}
def read_exact(r):
    p=P(r['path']);ck(p.is_absolute() and '..' not in p.parts and p.suffix in ('.json','.jsonl','.md','.txt','.log','.py'),'Metadata/code path only')
    for q in (p,*p.parents):ck(not q.is_symlink(),'Symlink rejected')
    s=p.stat();ck(stat.S_ISREG(s.st_mode) and 0<=r['bytes']<=33554432,'Nonregular/oversized input')
    before=(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    with p.open('rb') as f:b=f.read(r['bytes']+1)
    s=p.stat();ck(before==(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns) and bp(b)==sh(r),'Exact input changed')
    return b
def load_exact(r):return json.loads(read_exact(r))
def one_row_view(raw,request,selection):
    for b,key in ((raw,'rawResponse'),(request,'rawRequest'),(selection,'activeSelection')):ck(bp(b)==sh(PINS[key]),'Unreviewed single-create bytes: '+key)
    d=json.loads(raw);q=json.loads(request);s=json.loads(selection)
    ck(set(d)=={'content','structuredContent','isError'} and d['isError'] is False and d['content']==[{'type':'text','text':'Action completed.'}],'Single-create envelope differs')
    ck(d['structuredContent']==ACTIVE_ROW and 'results' not in d['structuredContent'],'Exact direct single-create tuple differs')
    ck(q=={'file':PINS['activeFile']['path'],'library_artifact_type':'report'},'Exact single-file request differs')
    ck(s=={'files':[{'localPath':PINS['activeFile']['path'],**sh(PINS['activeFile'])}]},'Exact active selection differs')
    return {**d,'structuredContent':{'results':[copy.deepcopy(d['structuredContent'])]}}
def validate_prior(mode,receipt,runtime,review,own):
    ck(mode in ('documents','active','persisted'),'Unsupported prior-check mode')
    expected=PINS['checker'] if mode in PRIOR else own
    ck(receipt['checkerScript']==runtime['checker']==review['checker']==expected,'Prior checker identity differs')
    ck(runtime['mode']==review['mode']==mode and review['contract']==receipt['runtimeInputContract']
       and review['result']=='ACCEPTED_EXACT_NISSAN_DELIVERY_RUNTIME_CONTRACT','Prior exact runtime review differs')
    if mode in PRIOR:
        ck(receipt['runtimeInputContract']==PRIOR[mode]['contract'] and receipt['runtimeInputContractReview']==PRIOR[mode]['review'],'Observed v7 prior seals differ')
def transform(raw,kind):
    key='checker' if kind=='checker' else 'producer';ck(bp(raw)==sh(PINS[key]),'Unreviewed base source')
    tree=ast.parse(raw,filename=PINS[key]['path']);counts={}
    def hit(name):counts[name]=counts.get(name,0)+1
    class Narrow(ast.NodeTransformer):
        def __init__(self):self.function=None
        def visit_FunctionDef(self,node):
            before=self.function;self.function=node.name;node=self.generic_visit(node);self.function=before;return node
        def visit_Name(self,node):
            if kind=='checker' and node.id=='OWN' and self.function=='restore':hit('restoreBaseIdentity');return ast.copy_location(ast.Name(id='_BASE_CHECKER',ctx=node.ctx),node)
            if kind=='checker' and node.id=='OWN' and self.function=='previous':hit('priorModeIdentity');return ast.copy_location(ast.Call(func=ast.Name(id='_prior_checker',ctx=ast.Load()),args=[ast.Name(id='mode',ctx=ast.Load())],keywords=[]),node)
            return node
        def visit_Constant(self,node):
            if node.value=='SEED-READ-ACCOUNTING-after-active-v1.json' and self.function==('final_receipt' if kind=='checker' else 'final'):
                hit('finalAccountingOnly');return ast.copy_location(ast.Constant(value=ACCOUNTING.name),node)
            return node
        def visit_Assign(self,node):
            node=self.generic_visit(node)
            if kind=='checker' and self.function=='main' and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id=='out':
                ck(isinstance(node.value,ast.Dict),'Unexpected checker output shape');hit('closingOutputProvenance')
                node.value.keys.extend([ast.Constant(value='closingAdapterProvenance'),ast.Constant(value='baseCheckerScript'),ast.Constant(value='deliveryOnlyClosingArtifact')])
                node.value.values.extend([ast.Call(func=ast.Name(id='_closing_provenance',ctx=ast.Load()),args=[ast.Attribute(value=ast.Name(id='args',ctx=ast.Load()),attr='mode',ctx=ast.Load())],keywords=[]),ast.Name(id='_BASE_CHECKER',ctx=ast.Load()),ast.Call(func=ast.Name(id='_closing_retention',ctx=ast.Load()),args=[],keywords=[])])
            return node
    tree=Narrow().visit(tree)
    expected={'restoreBaseIdentity':2,'priorModeIdentity':1,'finalAccountingOnly':1,'closingOutputProvenance':1} if kind=='checker' else {'finalAccountingOnly':1}
    ck(counts==expected,'Narrow source-transform location/count differs');ast.fix_missing_locations(tree);return tree

def module_from(refpin,tree=None,name='nissan_closing_base',own_file=False):
    raw=read_exact(refpin);m=types.ModuleType(name);m.__file__=str(P(__file__).resolve()) if own_file else refpin['path'];m.__dict__['__name__']=name
    exec(compile(tree if tree is not None else ast.parse(raw),refpin['path'],'exec'),m.__dict__);return m

def approval(contract_pin,load=load_exact):
    ck(contract_pin['path']==str(CONTRACT_PATH),'Closing contract path differs')
    d=load(contract_pin);own=ref(P(__file__).resolve())
    ck(d['result']=='ACCEPTED_EXACT_NISSAN_CLOSING_ADAPTER' and d['adapter']==own and d['proposal']==PINS['proposal']
       and d['finalAccountingPath']==str(ACCOUNTING),'Closing exact authority differs')
    review=load(d['review']);tests=load(d['tests']);load(PINS['proposal'])
    ck(review['result']=='ACCEPTED_EXACT_NISSAN_CLOSING_ADAPTER' and review['adapter']==own and review['proposal']==PINS['proposal'] and review['tests']==d['tests'],'Independent closing code/test review differs')
    ck(tests['result']=='PASS_NISSAN_CLOSING_ADAPTER_PURE_TESTS' and tests['adapter']==own,'Exact pure tests required')
    for key in ('producer','producerContract','checker','normalizer','correctionVerifier'):ck(d[key]==PINS[key],'Closing base authority differs: '+key)
    ck(d['nativeByteReadbackVerified'] is False and d['currentMaterializeAttempts']==0 and d['currentAlternateReadRoutes']==0,'Closing native boundary differs')
    return d

def provenance(mode,cp,authority):
    return {'adapter':ref(P(__file__).resolve()),'contract':cp,'review':authority['review'],'proposal':PINS['proposal'],
        'baseProducer':PINS['producer'],'baseChecker':PINS['checker'],'baseNormalizer':PINS['normalizer'],
        'rawResponse':PINS['rawResponse'],'rawRequest':PINS['rawRequest'],'activeSelection':PINS['activeSelection'],
        'viewRule':VIEW_RULE,'executionMode':mode,'nativeByteReadbackVerified':False,'currentMaterializeAttempts':0}

def normalize_active(cp,authority):
    for key in ('producerContract','activeCheck','activePrivacy','sixScanAccounting'):read_exact(PINS[key])
    view=one_row_view(read_exact(PINS['rawResponse']),read_exact(PINS['rawRequest']),read_exact(PINS['activeSelection']))
    producer=module_from(PINS['producer'],name='nissan_closing_producer_normalize');original_loader=producer.load_reference
    expected={C/'ACTIVE-UPLOAD-IDENTITIES.json',C/'library-active-results.json',C/'ACTIVE-NATIVE-READBACK-v1.json'};written=set()
    ck(not any(p.exists() for p in expected|{C/'library-active-verified.jsonl'}),'Immutable active normalization output exists')
    def loader(name,path,pin,*args):
        ck(name=='nissan_prior_native_normalizer' and str(path)==PINS['normalizer']['path'] and pin==sh(PINS['normalizer']) and not args,'Unexpected normalizer load')
        m=original_loader(name,path,pin);oldload=m.load;olddump=m.dump
        def load(path):return copy.deepcopy(view) if P(path)==P(PINS['rawResponse']['path']) else oldload(path)
        def dump(path,data):
            path=P(path);ck(path in expected and path not in written,'Unexpected active normalization write');written.add(path)
            data={**data,'closingAdapterProvenance':provenance('normalize-active',cp,authority)};return olddump(path,data)
        m.load=load;m.dump=dump;return m
    producer.load_reference=loader;producer.normalize('active');ck(written==expected,'Missing active normalization provenance output')

def phase(spec,load):
    i=load(spec['invocation']);t=load(spec['terminal']);ip=P(spec['invocation']['path'])
    ck(ip.parent==C and ip.name.endswith('.resources.invocation.json') and spec['terminal']['path']==str(ip.with_name(ip.name.replace('.invocation.json','.json'))),'Closing phase receipt paths differ')
    ck(t['exitCode']==0 and not t['timedOut'] and all(t[k]==i[k] for k in ('command','childPid','startedAt','addressSpaceLimitBytes','wallLimitSeconds'))
       and i['addressSpaceLimitBytes']==268435456 and i['wallLimitSeconds']==600,'Closing phase not successful/bounded')
    return i

def validate_replay_binding(replay,rc,rr,command,d,pkg,package_contract):
    verifier=PINS['correctionVerifier']
    ck(replay['verifierScript']==rc['verifier']==rr['verifier']==verifier and verifier!=package_contract['helper'],'Independent replay verifier differs')
    ck(rr['result']=='ACCEPTED_EXACT_NISSAN_CORRECTION_REPLAY_CONTRACT' and rr['contract']==replay['runtimeInputContract'],'Independent replay review differs')
    ck(rc['schemaVersion']==1 and rc['package']==d['package'] and rc['inventory']==d['inventory'] and rc['privacySelection']==d['selection']
       and rc['packagingContract']==pkg['contract'] and rc['packagingReview']==package_contract['independentReview'] and rc['privacy']==d['privacy']
       and rc['outsideRecoveryArchiveSet'] is True and rc['unchangedRecoveryArchiveCount']==145 and rc['nativeByteReadbackVerified'] is False,'Independent replay runtime scope differs')
    argv=[verifier['path'],'--contract',replay['runtimeInputContract']['path'],'--contract-sha256',replay['runtimeInputContract']['sha256'],
          '--review',replay['runtimeInputContractReview']['path'],'--review-sha256',replay['runtimeInputContractReview']['sha256']]
    ck(isinstance(command,list) and command[-len(argv):]==argv,'Independent replay exact command differs')

def correction_stage_accounting(accounting,retained):
    name=P(retained['privacy']['invocation']['path']).relative_to(C).as_posix()
    phases=[p for p in accounting['phases'] if p['invocation']['path']==name]
    ck(len(phases)==1 and phases[0]['outcome']=='PASS','Correction privacy absent or not successful in current accounting')
    for key in ('historical','audi','deepal'):
        hits=[r for r in accounting['stages'][key]['records'] if r['phaseInvocation']['path']==name]
        ck(len(hits)==1 and hits[0]['scanOutcome']=='PASS','Correction privacy missing exact seed-stage completion')

def retention(rp,cp,authority,load=load_exact):
    ck(rp['path']==str(RETENTION),'Closing retention path differs');d=load(rp)
    ck(d['result']=='EXACT_NISSAN_CLOSING_RETENTION' and d['outsideRecoveryArchiveSet'] is True and d['unchangedRecoveryArchiveCount']==145
       and d['nativeByteReadbackVerified'] is False,'Closing retention boundary differs')
    pkg=load(d['package']);inv=load(d['inventory']);sel=load(d['selection']);replay=load(d['replay']['report']);identity=load(d['identity'])
    ck(pkg['inventory']==d['inventory'] and pkg['privacy']==d['privacy'] and pkg['outsideRecoveryArchiveSet'] is True
       and inv['outsideRecoveryArchiveSet'] is True and pkg['unchangedRecoveryArchiveCount']==inv['unchangedRecoveryArchiveCount']==145
       and pkg['nativeByteReadbackVerified'] is inv['nativeByteReadbackVerified'] is False,'Correction package/inventory boundary differs')
    rows=inv['files'];ck(len({r['member'] for r in rows})==len(rows)==len({r['path'] for r in rows}),'Duplicate correction row')
    for r in rows:
        p=P(r['path']);ck(p.is_relative_to(C) and p.suffix in ('.py','.json','.jsonl','.log','.txt','.md') and not any(v in p.parts for v in ('payload','payloads','source-payload','proof-payload','support-staging-v1','node_modules','.git')) and r['member']=='nissan-delivery-single-create-correction/'+p.relative_to(C).as_posix(),'Correction exact member mapping differs')
    selfrow={'path':d['inventory']['path'],'member':'nissan-delivery-single-create-correction/'+P(d['inventory']['path']).relative_to(C).as_posix(),**sh(d['inventory'])}
    ck(selfrow['member'] not in {r['member'] for r in rows},'Inventory self-member duplicated')
    full=rows+[selfrow]
    ck(pkg['members']==full and pkg['memberCount']==len(full) and pkg['uncompressedBytes']==sum(r['bytes'] for r in full)
       and inv['filesInInventory']==len(rows) and inv['bytesInInventory']==sum(r['bytes'] for r in rows),'Exact inventory-plus-self package differs')
    package_contract=load(pkg['contract']);package_review=load(package_contract['independentReview']);selection=load(package_contract['selection'])
    ck(package_contract['result']==package_review['result']=='ACCEPTED_EXACT_NISSAN_DELIVERY_CORRECTION_PACKAGING'
       and package_review['helper']==package_contract['helper'] and package_review['selection']==package_contract['selection']
       and inv['contract']==pkg['contract'],'Exact package acceptance differs')
    originals=selection['files'];added=[{'path':r['path'],'member':'nissan-delivery-single-create-correction/'+P(r['path']).relative_to(C).as_posix(),**sh(r)} for r in (package_contract['selection'],package_contract['independentReview'],pkg['contract'])]
    ck(sorted(originals+added,key=lambda r:r['member'])==rows,'Finite correction selection differs')
    required=[ref(P(__file__).resolve()),cp,authority['review'],authority['tests'],authority['testScript'],PINS['proposal'],PINS['rawRequest'],PINS['rawResponse'],PINS['staticHold'],PINS['correctionVerifier']]
    for want in required:ck(sum(r['path']==want['path'] and sh(r)==sh(want) for r in rows)==1,'Missing exact new adapter/evidence retention')
    ck(sel['files']==[{'localPath':r['path'],**sh(r)} for r in full],'Correction full-member privacy selection differs')
    g=load(d['privacy']['report']);pi=phase(d['privacy'],load)
    ck(g['status']=='clean' and not g['findings'] and not g['errors'] and g['selectionPin']==sh(d['selection'])
       and g['fileCount']==len(full) and [{k:r[k] for k in ('path','bytes','sha256')} for r in g['files']]==[{'path':r['path'],**sh(r)} for r in full],'Exact correction privacy coverage differs')
    ck(d['selection']['path'] in pi['command'] and d['privacy']['report']['path'] in pi['command'],'Correction privacy command differs')
    ri=phase(d['replay'],load)
    archive={'path':pkg['file'],**sh(pkg)}
    ck(replay['result']=='PASS_EXACT_NISSAN_DELIVERY_CORRECTION_REPLAY' and replay['package']==d['package'] and replay['inventory']==d['inventory']
       and replay['archive']==archive and replay['members']==full and replay['memberCount']==len(full) and replay['memberBytes']==pkg['uncompressedBytes']
       and replay['tarAndXzEofVerified'] is True and replay['privacy']==d['privacy'] and replay['outsideRecoveryArchiveSet'] is True
       and replay['unchangedRecoveryArchiveCount']==145 and replay['nativeByteReadbackVerified'] is False,'Exact correction replay differs')
    rc=load(replay['runtimeInputContract']);rr=load(replay['runtimeInputContractReview'])
    validate_replay_binding(replay,rc,rr,ri['command'],d,pkg,package_contract)
    for r in replay['inputPins']:
        ck(sum(r==x for x in rc['metadata'])==1,'Independent replay input not identically admitted');load(r)
    ck(identity['status']=='CREATE_CONFIRMED_NATIVE_BYTE_READBACK_UNPASSED' and identity['nativeByteReadbackVerified'] is False and identity['currentMaterializeAttempts']==0
       and identity['outsideRecoveryArchiveSet'] is True and identity['unchangedRecoveryArchiveCount']==145 and len(identity['files'])==1,'Correction identity qualification differs')
    cc,created_pkg,created_row=create_authority(identity['normalizationContract'],identity['normalizationReview'],cp,load)
    ck(cc['package']==d['package'] and created_pkg==pkg and identity['exactHostRequest']==cc['rawRequest'] and identity['exactProviderResponse']==cc['rawResponse']
       and identity['closingAdapterProvenance']==provenance('normalize-correction',cp,authority) and identity['route']=='OFFICIAL_ABSOLUTE_PATH_HOST_CREATE'
       and identity['localBytesVerified'] is identity['providerCreateConfirmed'] is True,'Correction normalization provenance differs')
    a=identity['files'][0];server=created_row
    ck(a=={'filename':pkg['filename'],'localPath':pkg['file'],**sh(pkg),'library_file_id':server['library_file_id'],'file_id':server['file_id'],'version':server['current_version_number']},'Correction normalized identity differs')
    return {'retention':rp,'package':d['package'],'inventory':d['inventory'],'privacy':d['privacy'],'replay':d['replay'],'identity':d['identity'],'artifact':a,'outsideRecoveryArchiveSet':True,'unchangedRecoveryArchiveCount':145,'nativeByteReadbackVerified':False}

def create_tuple(request,response,pkg,shape,expected):
    ck(shape in ('direct-single','batch-single'),'Unsupported create shape')
    ck(not ('files' in request and 'file' in request),'Ambiguous create request')
    paths=request['files'] if 'files' in request else [request['file']]
    ck(paths==[pkg['file']] and response['isError'] is False,'Exact correction create request differs')
    ck(set(response)=={'content','structuredContent','isError'},'Correction create envelope fields differ')
    body=response['structuredContent']
    if shape=='batch-single':
        ck(isinstance(body,dict) and set(body)=={'results','warnings','external_connectors_accessed'} and body['warnings']==[] and body['external_connectors_accessed'] is False and isinstance(body['results'],list) and len(body['results'])==1,'Expected exact batch singleton');row=body['results'][0]
    else:ck(isinstance(body,dict) and 'results' not in body,'Expected exact direct singleton');row=body
    fields=set(ACTIVE_ROW) if shape=='direct-single' else set(ACTIVE_ROW)-{'external_connectors_accessed'}
    ck(row==expected and set(row)==fields and (shape!='direct-single' or row['external_connectors_accessed'] is False),'Exact reviewed successful row or field set differs')
    ck(row['operation']=='create_library_file' and row['status']=='succeeded' and row['path']=='/'+pkg['filename']
       and row['file_name']==pkg['filename'] and row['file_size_bytes']==pkg['bytes'] and type(row['current_version_number']) is int
       and row['current_version_number']>=0 and row['library_file_id'].startswith('libfile_') and row['file_id'].startswith('file_')
       and row['xattrs']==[{'name':'user.library-file-version','value':str(row['current_version_number'])}],'Correction successful tuple differs')
    return row

def create_authority(contract_pin,review_pin,cp,load=load_exact):
    ck(contract_pin['path']==str(C/'NISSAN-CORRECTION-CREATE-CONTRACT-v1.json') and review_pin['path']==str(C/'INDEPENDENT-NISSAN-CORRECTION-CREATE-REVIEW-v1.json'),'Correction create authority paths differ')
    c=load(contract_pin);r=load(review_pin);own=ref(P(__file__).resolve())
    ck(c['result']==r['result']=='ACCEPTED_EXACT_NISSAN_CORRECTION_CREATE_NORMALIZATION' and c['adapter']==r['adapter']==own
       and c['closingContract']==cp and r['contract']==contract_pin and c['nativeByteReadbackVerified'] is False
       and c['currentMaterializeAttempts']==0,'Exact correction create approval differs')
    pkg=load(c['package']);row=create_tuple(load(c['rawRequest']),load(c['rawResponse']),pkg,c['shape'],c['expectedResult'])
    return c,pkg,row

def normalize_correction(cp,authority,contract_pin,review_pin):
    target=C/'DELIVERY-CORRECTION-UPLOAD-IDENTITIES-v1.json';ck(not target.exists(),'Immutable correction identity exists')
    c,pkg,row=create_authority(contract_pin,review_pin,cp);p=P(pkg['file'])
    ck(p==C.parents[1]/'Roadmark-NISSAN-delivery-single-create-correction-20261016.tar.xz'
       and pkg['filename']==p.name and pkg['outsideRecoveryArchiveSet'] is True and pkg['unchangedRecoveryArchiveCount']==145,'Correction archive scope differs')
    for q in (p,*p.parents):ck(not q.is_symlink(),'Correction archive symlink')
    before=p.stat();ck(stat.S_ISREG(before.st_mode) and before.st_size==pkg['bytes']<=16777216,'Correction archive bound')
    digest=hashlib.sha256();total=0
    with p.open('rb') as f:
        while True:
            b=f.read(65536)
            if not b:break
            digest.update(b);total+=len(b)
    after=p.stat();ck((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
       and total==pkg['bytes'] and digest.hexdigest()==pkg['sha256'],'Correction local archive hash changed')
    ck('user.library-file-id' not in os.listxattr(p),'Unreturned identity attribute exists')
    for x in row['xattrs']:os.setxattr(p,x['name'],x['value'].encode())
    ck(os.getxattr(p,'user.library-file-version').decode()==str(row['current_version_number']),'Returned version attribute differs')
    out={'status':'CREATE_CONFIRMED_NATIVE_BYTE_READBACK_UNPASSED','files':[{'filename':pkg['filename'],'localPath':pkg['file'],**sh(pkg),'library_file_id':row['library_file_id'],'file_id':row['file_id'],'version':row['current_version_number']}],
         'exactHostRequest':c['rawRequest'],'exactProviderResponse':c['rawResponse'],'normalizationContract':contract_pin,'normalizationReview':review_pin,
         'closingAdapterProvenance':provenance('normalize-correction',cp,authority),'nativeByteReadbackVerified':False,'currentMaterializeAttempts':0,
         'outsideRecoveryArchiveSet':True,'unchangedRecoveryArchiveCount':145,'route':'OFFICIAL_ABSOLUTE_PATH_HOST_CREATE','localBytesVerified':True,'providerCreateConfirmed':True}
    data=(json.dumps(out,indent=2)+'\n').encode();fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o444)
    with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
    print(json.dumps({'result':out['status'],'identity':ref(target),'nativeByteReadbackVerified':False}))

def produce_final(cp,authority,rp,accounting_pin):
    ck(accounting_pin['path']==str(ACCOUNTING),'Final accounting target differs');accounting=load_exact(accounting_pin)
    ck(accounting['status']=='EXPLICIT_STAGE_AND_TERMINAL_ACCOUNTING','Final accounting is not actual explicit accounting')
    retained=retention(rp,cp,authority);correction_stage_accounting(accounting,retained);raw=read_exact(PINS['producer']);producer=module_from(PINS['producer'],transform(raw,'producer'),name='nissan_closing_producer_final')
    olddump=producer.dump;target=C/'FINAL-NISSAN-UPLOAD-RECEIPTS.json';ck(not target.exists(),'Immutable final receipt exists')
    def dump(path,data):
        ck(P(path)==target and data['seedReadAccounting']==accounting,'Final-only write/accounting differs')
        data={**data,'closingAdapterProvenance':provenance('final',cp,authority),'seedReadAccountingPin':accounting_pin,'deliveryOnlyClosingArtifact':retained};return olddump(path,data)
    producer.dump=dump;producer.final()

def check_closing(mode):
    ck(mode in ('persisted','terminal'),'Only closing checker modes supported')
    raw=read_exact(PINS['checker']);m=module_from(PINS['checker'],transform(raw,'checker'),name='nissan_closing_independent_checker',own_file=True);state={}
    m._BASE_CHECKER=PINS['checker'];m._prior_checker=lambda name:PINS['checker'] if name in PRIOR else m.OWN
    oldcontext=m.context
    def context(args):
        result=oldcontext(args);c=m.CONTRACT;ck(set(c['closing'])=={'contract','retention'},'Closing runtime fields differ')
        cp=c['closing']['contract'];authority=approval(cp,m.load);rp=c['closing']['retention'];retained=retention(rp,cp,authority,m.load)
        ck(c['inputs']['deliveryHelper']==PINS['producer'] and c['inputs']['deliveryContract']==PINS['producerContract']
           and c['inputs']['accounting']['path']==str(ACCOUNTING),'Current producer or final accounting role differs')
        for key in ('producer','normalizer','checker','correctionVerifier'):ck(m.ref(PINS[key]['path'])==PINS[key],'Base source not exactly sealed');m.raw(PINS[key])
        correction_stage_accounting(m.load(c['inputs']['accounting']),retained)
        state.update(cp=cp,authority=authority,retained=retained)
        return result
    m.context=context;oldget=m.get
    def get(path):
        if P(path)==P(PINS['rawResponse']['path']):
            return one_row_view(m.raw(PINS['rawResponse']),m.raw(PINS['rawRequest']),m.raw(PINS['activeSelection']))
        return oldget(path)
    m.get=get;oldnormalized=m.normalized
    def normalized(phase,want,denial):
        result=oldnormalized(phase,want,denial)
        if phase=='active':
            expected=provenance('normalize-active',state['cp'],state['authority'])
            for name in ('ACTIVE-UPLOAD-IDENTITIES.json','library-active-results.json','ACTIVE-NATIVE-READBACK-v1.json'):ck(oldget(C/name)['closingAdapterProvenance']==expected,'Active normalization provenance differs')
        return result
    m.normalized=normalized;oldprevious=m.previous
    def previous(name,counts,documents):
        rp=oldprevious(name,counts,documents)
        if name in PRIOR:ck(rp==PRIOR[name]['receipt'],'Observed v7 receipt pin differs')
        d=m.load(rp);runtime=m.load(d['runtimeInputContract']);review=m.load(d['runtimeInputContractReview']);validate_prior(name,d,runtime,review,m.OWN)
        if name=='persisted':ck(d['baseCheckerScript']==PINS['checker'] and d['closingAdapterProvenance']==provenance('persisted',state['cp'],state['authority']) and d['deliveryOnlyClosingArtifact']==state['retained'],'Prior persisted closing provenance differs')
        return rp
    m.previous=previous;oldcompare=m.compare_json
    def compare(path,expected):
        if P(path)==C/'FINAL-NISSAN-UPLOAD-RECEIPTS.json':expected={**expected,'closingAdapterProvenance':provenance('final',state['cp'],state['authority']),'seedReadAccountingPin':m.CONTRACT['inputs']['accounting'],'deliveryOnlyClosingArtifact':state['retained']}
        return oldcompare(path,expected)
    m.compare_json=compare;m._closing_provenance=lambda name:provenance(name,state['cp'],state['authority']);m._closing_retention=lambda:state['retained'];m.main()

def main():
    ck(len(sys.argv)>1,'Closing mode required');mode=sys.argv[1]
    if mode in ('persisted','terminal'):return check_closing(mode)
    a=argparse.ArgumentParser();a.add_argument('mode',choices=['normalize-active','normalize-correction','final']);a.add_argument('--closing-contract-sha256',required=True);a.add_argument('--retention-sha256');a.add_argument('--accounting-sha256');a.add_argument('--create-contract-sha256');a.add_argument('--create-review-sha256');args=a.parse_args()
    cp={'path':str(CONTRACT_PATH),'bytes':CONTRACT_PATH.stat().st_size,'sha256':args.closing_contract_sha256};authority=approval(cp)
    if mode=='normalize-active':ck(args.retention_sha256 is args.accounting_sha256 is args.create_contract_sha256 is args.create_review_sha256 is None,'Unexpected normalization inputs');normalize_active(cp,authority)
    elif mode=='normalize-correction':
        ck(args.create_contract_sha256 and args.create_review_sha256 and args.retention_sha256 is args.accounting_sha256 is None,'Correction create seals required')
        cpath=C/'NISSAN-CORRECTION-CREATE-CONTRACT-v1.json';rpath=C/'INDEPENDENT-NISSAN-CORRECTION-CREATE-REVIEW-v1.json'
        normalize_correction(cp,authority,{'path':str(cpath),'bytes':cpath.stat().st_size,'sha256':args.create_contract_sha256},{'path':str(rpath),'bytes':rpath.stat().st_size,'sha256':args.create_review_sha256})
    else:
        ck(args.retention_sha256 and args.accounting_sha256 and args.create_contract_sha256 is args.create_review_sha256 is None,'Final retention/accounting seals required')
        produce_final(cp,authority,{'path':str(RETENTION),'bytes':RETENTION.stat().st_size,'sha256':args.retention_sha256},{'path':str(ACCOUNTING),'bytes':ACCOUNTING.stat().st_size,'sha256':args.accounting_sha256})
if __name__=='__main__':main()
