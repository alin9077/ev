#!/usr/bin/env python3
"""Finite delivery-only artifact staging, packaging and replay; never recovery-chain mutation."""
import argparse, datetime, hashlib, io, json, lzma, pathlib, stat, tarfile
P=pathlib.Path; C=P(__file__).resolve().parent; R=C.parent.parent
PREFIX='nissan-delivery-single-create-correction/'
ARCHIVE=R/'Roadmark-NISSAN-delivery-single-create-correction-20261016.tar.xz'
INVENTORY=C/'DELIVERY-SINGLE-CREATE-CORRECTION-MEMBER-INVENTORY-v1.json'
PRIVACY_SELECTION=C/'DELIVERY-SINGLE-CREATE-CORRECTION-PRIVACY-SELECTION-v1.json'
PACKAGE=C/'DELIVERY-SINGLE-CREATE-CORRECTION-PACKAGE-v1.json'
REPLAY=C/'INDEPENDENT-DELIVERY-SINGLE-CREATE-CORRECTION-REPLAY-v1.json'
GATE=C/'scan-delivery-correction-v1.json'
MAX_BYTES=16*1024*1024

def require(value,why):
 if not value:raise AssertionError(why)
def sha(b):return hashlib.sha256(b).hexdigest()
def identity(p):
 require(p.is_absolute() and p==p.resolve() and not p.is_symlink(),'noncanonical/symlink path')
 for q in p.parents:require(not q.is_symlink(),'symlink ancestor')
 s=p.stat();require(stat.S_ISREG(s.st_mode),'nonregular input');return (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_mode)
def read(p):
 p=P(p);before=identity(p);require(before[2]<=MAX_BYTES,'input bound');b=p.read_bytes();require(identity(p)==before,'input changed');return b
def pin(p):
 p=P(p);b=read(p);return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def check(r):
 p=P(r['path']);b=read(p);require({'bytes':len(b),'sha256':sha(b)}=={k:r[k] for k in ('bytes','sha256')},'pin mismatch: '+str(p));return b
def load(p):return json.loads(read(p))
def dump(p,d):
 raw=(json.dumps(d,indent=2)+'\n').encode();p.open('xb').write(raw);return pin(p)
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def member(p):
 p=P(p);require(p.is_relative_to(C),'outside current metadata root')
 rel=p.relative_to(C);require(not any(x in rel.parts for x in ('payload','payloads','source-payload','proof-payload','node_modules','.git')),'payload scope')
 require(p.suffix in ('.py','.json','.jsonl','.log','.txt','.md'),'unsupported metadata type');return PREFIX+rel.as_posix()
def context(args):
 cp=P(args.contract);require(cp.parent==C and cp.suffix=='.json','contract scope');cr=pin(cp);require(cr['sha256']==args.contract_sha256,'contract seal');c=load(cp)
 require(c['result']=='ACCEPTED_EXACT_NISSAN_DELIVERY_CORRECTION_PACKAGING','contract status');require(c['helper']==pin(P(__file__).resolve()),'helper pin')
 review=json.loads(check(c['independentReview']));require(review['result']=='ACCEPTED_EXACT_NISSAN_DELIVERY_CORRECTION_PACKAGING' and review['helper']==c['helper'] and review['selection']==c['selection'],'independent exact acceptance')
 require(c['outsideRecoveryArchiveSet'] is True and c['unchangedRecoveryArchiveCount']==145 and c['nativeByteReadbackVerified'] is False,'scope boundary')
 selection=json.loads(check(c['selection']));rows=selection['files'];require(0<len(rows)<=100,'finite selection count')
 files=[];seen=set()
 for r in rows:
  p=P(r['path']);require(r['member']==member(p),'member mapping');check(r).decode('utf8');require(r['member'] not in seen,'duplicate member');seen.add(r['member']);files.append({k:r[k] for k in ('path','member','bytes','sha256')})
 for r in (c['selection'],c['independentReview'],cr):
  m=member(r['path']);require(m not in seen,'implicit member duplicates selection');seen.add(m);check(r).decode('utf8');files.append({'path':r['path'],'member':m,'bytes':r['bytes'],'sha256':r['sha256']})
 require(sum(r['bytes'] for r in files)<=MAX_BYTES,'aggregate member bound')
 return c,cr,sorted(files,key=lambda r:r['member'])
def expected(c,cr,files):
 inv=load(INVENTORY);require(inv['files']==files and inv['contract']==cr and inv['outsideRecoveryArchiveSet'] is True and inv['unchangedRecoveryArchiveCount']==145,'exact inventory')
 ip=pin(INVENTORY);rows=files+[{'path':str(INVENTORY),'member':member(INVENTORY),'bytes':ip['bytes'],'sha256':ip['sha256']}]
 selection=load(PRIVACY_SELECTION);require(selection['files']==[{'localPath':r['path'],'bytes':r['bytes'],'sha256':r['sha256']} for r in rows],'full-member privacy selection')
 return rows
def privacy(rows):
 s=load(GATE);t=load(C/'scan-delivery-correction-v1.resources.json');i=load(C/'scan-delivery-correction-v1.resources.invocation.json')
 require(s['status']=='clean' and not s['findings'] and not s['errors'] and s['fileCount']==len(rows),'full-member privacy gate')
 require(s['selectionPin']=={k:pin(PRIVACY_SELECTION)[k] for k in ('bytes','sha256')},'privacy selection seal')
 require([{k:x[k] for k in ('path','bytes','sha256')} for x in s['files']]==[{k:r[k] for k in ('path','bytes','sha256')} for r in rows],'scanned exact members')
 require(t['exitCode']==0 and not t['timedOut'] and all(t[k]==i[k] for k in ('command','childPid','startedAt','addressSpaceLimitBytes','wallLimitSeconds')),'privacy terminal')
 require(t['addressSpaceLimitBytes']==268435456 and t['wallLimitSeconds']==600 and str(PRIVACY_SELECTION) in t['command'] and str(GATE) in t['command'],'privacy envelope/paths')
 return {'report':pin(GATE),'invocation':pin(C/'scan-delivery-correction-v1.resources.invocation.json'),'terminal':pin(C/'scan-delivery-correction-v1.resources.json')}
def main():
 a=argparse.ArgumentParser();a.add_argument('mode',choices=['stage','build','replay']);a.add_argument('--contract',required=True);a.add_argument('--contract-sha256',required=True);args=a.parse_args();c,cr,files=context(args)
 if args.mode=='stage':
  require(not INVENTORY.exists() and not PRIVACY_SELECTION.exists(),'stage output exists')
  dump(INVENTORY,{'schemaVersion':1,'createdAt':stamp(),'files':files,'filesInInventory':len(files),'bytesInInventory':sum(r['bytes'] for r in files),'contract':cr,'outsideRecoveryArchiveSet':True,'unchangedRecoveryArchiveCount':145,'nativeByteReadbackVerified':False,'scope':'Exact new delivery correction metadata/code only; recovery archives and delivered document bytes unchanged.'})
  ip=pin(INVENTORY);rows=files+[{'path':str(INVENTORY),'member':member(INVENTORY),'bytes':ip['bytes'],'sha256':ip['sha256']}]
  dump(PRIVACY_SELECTION,{'files':[{'localPath':r['path'],'bytes':r['bytes'],'sha256':r['sha256']} for r in rows]});print(json.dumps({'stage':'PASS','members':len(rows)}));return
 rows=expected(c,cr,files);gate=privacy(rows)
 if args.mode=='build':
  require(not ARCHIVE.exists() and not PACKAGE.exists(),'package output exists');buf=io.BytesIO()
  with tarfile.open(fileobj=buf,mode='w',format=tarfile.USTAR_FORMAT) as tar:
   for r in rows:
    b=check(r);info=tarfile.TarInfo(r['member']);info.size=len(b);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(b))
  raw=buf.getvalue();require(len(raw)<=MAX_BYTES+1024*1024,'tar bound');packed=lzma.compress(raw,format=lzma.FORMAT_XZ,preset=6);ARCHIVE.open('xb').write(packed)
  dump(PACKAGE,{'schemaVersion':1,'filename':ARCHIVE.name,'file':str(ARCHIVE),'bytes':len(packed),'sha256':sha(packed),'memberCount':len(rows),'uncompressedBytes':sum(r['bytes'] for r in rows),'members':rows,'inventory':pin(INVENTORY),'contract':cr,'privacy':gate,'outsideRecoveryArchiveSet':True,'unchangedRecoveryArchiveCount':145,'nativeByteReadbackVerified':False});print(json.dumps({'package':'PASS','archiveBytes':len(packed),'members':len(rows)}));return
 require(not REPLAY.exists(),'replay output exists');pkg=load(PACKAGE);require(pkg['members']==rows and pkg['contract']==cr and pkg['privacy']==gate and pkg['filename']==ARCHIVE.name and pkg['file']==str(ARCHIVE),'package binding')
 packed=check({'path':str(ARCHIVE),'bytes':pkg['bytes'],'sha256':pkg['sha256']});decompressor=lzma.LZMADecompressor(format=lzma.FORMAT_XZ);raw=decompressor.decompress(packed,max_length=MAX_BYTES+1024*1024+1)
 require(decompressor.eof and not decompressor.unused_data and len(raw)<=MAX_BYTES+1024*1024,'exact single XZ stream EOF')
 want={r['member']:r for r in rows};observed=[];end=0
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as tar:
  for m in tar:
   require(m.isfile() and m.name in want and m.name not in {r['member'] for r in observed},'unexpected/duplicate/nonregular member');r=want[m.name];b=tar.extractfile(m).read();require(len(b)==r['bytes'] and sha(b)==r['sha256'],'member hash');observed.append(r);end=m.offset_data+((m.size+511)//512)*512
 require(len(observed)==len(rows) and set(r['member'] for r in observed)==set(want) and len(raw)-end>=1024 and not any(raw[end:]),'complete tar members and EOF padding')
 dump(REPLAY,{'result':'PASS_EXACT_NISSAN_DELIVERY_CORRECTION_REPLAY','completedAt':stamp(),'helper':pin(P(__file__).resolve()),'package':pin(PACKAGE),'inventory':pin(INVENTORY),'archive':pin(ARCHIVE),'members':rows,'memberCount':len(rows),'memberBytes':sum(r['bytes'] for r in rows),'tarAndXzEofVerified':True,'privacy':gate,'outsideRecoveryArchiveSet':True,'unchangedRecoveryArchiveCount':145,'nativeByteReadbackVerified':False,'archivePayloadReads':1,'priorArchivePayloadReads':0,'seedPayloadReads':0});print(json.dumps({'replay':'PASS','members':len(rows)}))
if __name__=='__main__':main()
