#!/usr/bin/env python3
"""Independent exact replay of the one new delivery correction artifact only."""
import argparse, datetime, hashlib, io, json, lzma, os, pathlib, resource, stat, tarfile
P=pathlib.Path
C=P('/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220')
R=C.parent.parent
ARCHIVE=R/'Roadmark-NISSAN-delivery-single-create-correction-20261016.tar.xz'
OUTPUT=C/'INDEPENDENT-NISSAN-DELIVERY-CORRECTION-VERIFICATION-v1.json'
PREFIX='nissan-delivery-single-create-correction/'
LIMIT=268435456; MAX=16777216; TARMAX=MAX+1048576

def require(ok,why):
 if not ok:raise AssertionError(why)
def digest(b):return hashlib.sha256(b).hexdigest()
def core(r):return {k:r[k] for k in ('path','bytes','sha256')}
def identity(p):
 require(p.is_absolute() and p==p.resolve() and not p.is_symlink(),'noncanonical input')
 require(all(not q.is_symlink() for q in p.parents),'symlink ancestor')
 s=p.stat();require(stat.S_ISREG(s.st_mode),'nonregular input')
 return (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_mode)
def exact(r,archive=False):
 p=P(r['path']);require((p==ARCHIVE) if archive else (p.is_relative_to(C) and p.suffix in ('.json','.jsonl','.py','.log','.md','.txt')),'read scope')
 require(not any(x in p.parts for x in ('payload','payloads','source-payload','proof-payload','support-staging-v1','node_modules','.git')),'payload tree')
 require(type(r['bytes']) is int and 0<=r['bytes']<=MAX and len(r['sha256'])==64,'pin bound')
 before=identity(p);require(before[2]==r['bytes'],'size mismatch')
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as f:
  fs=os.fstat(f.fileno());require((fs.st_dev,fs.st_ino)==before[:2],'file descriptor identity');b=f.read(r['bytes']+1)
 require(identity(p)==before and len(b)==r['bytes'] and digest(b)==r['sha256'],'changed input or hash mismatch')
 return b
def ref(p):
 p=P(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':digest(b)}
def mapped(r):
 p=P(r['path']);require(p.is_relative_to(C) and p.suffix in ('.py','.json','.jsonl','.log','.txt','.md'),'ordinary member original scope')
 require(not any(x in p.relative_to(C).parts for x in ('payload','payloads','source-payload','proof-payload','support-staging-v1','node_modules','.git')),'ordinary member payload scope')
 require(r['member']==PREFIX+p.relative_to(C).as_posix() and '..' not in pathlib.PurePosixPath(r['member']).parts,'exact member mapping')
 return {k:r[k] for k in ('path','member','bytes','sha256')}
def main():
 resource.setrlimit(resource.RLIMIT_AS,(LIMIT,LIMIT))
 parser=argparse.ArgumentParser();parser.add_argument('--contract',required=True);parser.add_argument('--contract-sha256',required=True);parser.add_argument('--review',required=True);parser.add_argument('--review-sha256',required=True);a=parser.parse_args()
 require(not OUTPUT.exists(),'immutable output already exists')
 cp=P(a.contract);rp=P(a.review);require(cp.parent==rp.parent==C and cp.suffix==rp.suffix=='.json','contract/review scope')
 cr={'path':str(cp),'bytes':identity(cp)[2],'sha256':a.contract_sha256};rr={'path':str(rp),'bytes':identity(rp)[2],'sha256':a.review_sha256}
 c=json.loads(exact(cr));review=json.loads(exact(rr));own=ref(P(__file__).resolve())
 require(c['schemaVersion']==1 and c['verifier']==own and c['outsideRecoveryArchiveSet'] is True and c['unchangedRecoveryArchiveCount']==145 and c['nativeByteReadbackVerified'] is False,'runtime scope')
 require(review['result']=='ACCEPTED_EXACT_NISSAN_CORRECTION_REPLAY_CONTRACT' and review['verifier']==own and review['contract']==cr,'exact independent invocation approval')
 allowed={}
 for r in c['metadata']:
  require(r['path'] not in allowed,'duplicate metadata admission');allowed[r['path']]=core(r)
 seen={}
 def load(r):
  require(allowed.get(r['path'])==core(r),'unsealed metadata read');b=exact(r);seen[r['path']]=core(r);return json.loads(b)
 pkg=load(c['package']);inv=load(c['inventory']);selection=load(c['privacySelection']);pc=load(c['packagingContract']);pr=load(c['packagingReview']);original=load(pc['selection'])
 require(pc['result']==pr['result']=='ACCEPTED_EXACT_NISSAN_DELIVERY_CORRECTION_PACKAGING' and pc['independentReview']==c['packagingReview'] and pr['helper']==pc['helper'] and pr['selection']==pc['selection'],'packaging approvals')
 require(pc['outsideRecoveryArchiveSet'] is True and pc['unchangedRecoveryArchiveCount']==145 and pc['nativeByteReadbackVerified'] is False,'packaging boundary')
 ordinary=[mapped(r) for r in original['files']]
 for q in (pc['selection'],c['packagingReview'],c['packagingContract']):ordinary.append(mapped({**q,'member':PREFIX+P(q['path']).relative_to(C).as_posix()}))
 ordinary.sort(key=lambda r:r['member']);require(len(ordinary)==len({r['member'] for r in ordinary}) and 0<len(ordinary)<=103,'ordinary member count/duplicates')
 require(inv['files']==ordinary and inv['contract']==c['packagingContract'] and inv['filesInInventory']==len(ordinary) and inv['bytesInInventory']==sum(r['bytes'] for r in ordinary),'ordinary inventory equality')
 require(inv['outsideRecoveryArchiveSet'] is True and inv['unchangedRecoveryArchiveCount']==145 and inv['nativeByteReadbackVerified'] is False,'inventory boundary')
 rows=ordinary+[mapped({**c['inventory'],'member':PREFIX+P(c['inventory']['path']).relative_to(C).as_posix()})]
 require(len(rows)==len({r['member'] for r in rows}) and sum(r['bytes'] for r in rows)<=TARMAX,'full member scope')
 require(pkg['members']==rows and pkg['memberCount']==len(rows) and pkg['uncompressedBytes']==sum(r['bytes'] for r in rows) and pkg['inventory']==c['inventory'] and pkg['contract']==c['packagingContract'],'package membership')
 require(pkg['file']==str(ARCHIVE) and pkg['filename']==ARCHIVE.name and pkg['outsideRecoveryArchiveSet'] is True and pkg['unchangedRecoveryArchiveCount']==145 and pkg['nativeByteReadbackVerified'] is False,'package boundary')
 require(sum(r['path']==own['path'] and r['bytes']==own['bytes'] and r['sha256']==own['sha256'] for r in ordinary)==1,'independent verifier retained exactly once')
 expectedSelection=[{'localPath':r['path'],'bytes':r['bytes'],'sha256':r['sha256']} for r in rows];require(selection['files']==expectedSelection,'full-byte privacy selection')
 gate=pkg['privacy'];require(gate==c['privacy'],'privacy triple binding');g=load(gate['report']);i=load(gate['invocation']);t=load(gate['terminal'])
 require(g['status']=='clean' and g['fileCount']==len(rows) and not g['findings'] and not g['errors'] and g['selectionPin']=={k:c['privacySelection'][k] for k in ('bytes','sha256')},'privacy gate')
 require([{k:r[k] for k in ('path','bytes','sha256')} for r in g['files']]==[core(r) for r in rows],'privacy exact file pins')
 require(t['exitCode']==0 and not t['timedOut'] and all(t[k]==i[k] for k in ('command','childPid','startedAt','addressSpaceLimitBytes','wallLimitSeconds')) and t['addressSpaceLimitBytes']==LIMIT and t['wallLimitSeconds']==600,'privacy terminal')
 require(c['privacySelection']['path'] in t['command'] and gate['report']['path'] in t['command'],'privacy invocation scope')
 ar={'path':str(ARCHIVE),'bytes':pkg['bytes'],'sha256':pkg['sha256']};packed=exact(ar,archive=True);xz=lzma.LZMADecompressor(format=lzma.FORMAT_XZ);raw=xz.decompress(packed,max_length=TARMAX+1)
 require(xz.eof and not xz.unused_data and len(raw)<=TARMAX,'single exact XZ stream and EOF')
 expected={r['member']:r for r in rows};observed=[];end=0
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as tar:
  for m in tar:
   require(m.isfile() and m.name in expected and m.name not in {r['member'] for r in observed},'unexpected duplicate/nonregular tar member');r=expected[m.name]
   require(m.size==r['bytes'] and m.mode==0o644 and m.uid==m.gid==m.mtime==0 and m.uname==m.gname=='','member header')
   b=tar.extractfile(m).read(r['bytes']+1);require(len(b)==r['bytes'] and digest(b)==r['sha256'],'member bytes')
   observed.append(r);end=m.offset_data+((m.size+511)//512)*512
 require(observed==rows and len(raw)-end>=1024 and not any(raw[end:]),'exact member order/set and tar EOF padding')
 prior=load(c['priorReplay']);require(prior['result']=='PASS_EXACT_NISSAN_DELIVERY_CORRECTION_REPLAY' and prior['package']==c['package'] and prior['inventory']==c['inventory'] and prior['archive']==ar and prior['members']==rows and prior['tarAndXzEofVerified'] is True,'same-helper replay corroboration')
 out={'result':'PASS_INDEPENDENT_NISSAN_DELIVERY_CORRECTION_REPLAY','verifiedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verifier':own,'runtimeContract':cr,'runtimeReview':rr,'inputPins':list(seen.values()),'package':c['package'],'inventory':c['inventory'],'archive':ar,'members':rows,'memberCount':len(rows),'memberBytes':sum(r['bytes'] for r in rows),'tarAndXzEofVerified':True,'privacy':gate,'priorSameHelperReplay':c['priorReplay'],'outsideRecoveryArchiveSet':True,'unchangedRecoveryArchiveCount':145,'nativeByteReadbackVerified':False,'scope':{'currentCorrectionArchivePayloadReads':1,'priorArchivePayloadReads':0,'seedPayloadReads':0,'originalMemberPayloadReads':0,'externalOperations':0}}
 data=(json.dumps(out,indent=2)+'\n').encode();fd=os.open(OUTPUT,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o444)
 with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 print(json.dumps({'result':out['result'],'output':{'path':str(OUTPUT),'bytes':len(data),'sha256':digest(data)},'members':len(rows)}))
if __name__=='__main__':main()
