from pathlib import Path
import hashlib,json,subprocess,os,time,sys
from datetime import datetime,timezone

# Versioned extension of the preserved root wrapper. No validation logic lives here.
root=Path('/workspace/scratch/586427eef9f2/roadmark-104')
out=root.parent/'roadmark-104-qa'/'mercedes-sequential-checks'
manifest_path,manifest_sha,review_path,review_sha=sys.argv[1:]
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(65536),b''):h.update(block)
 return h.hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def durable(p,value):
 with p.open('x') as f:
  json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
def source_names():
 result=set();excluded={'public/index.html','public/index-b.html'}
 def walk(relative):
  for p in (root/relative).iterdir():
   name=p.relative_to(root).as_posix()
   if p.is_symlink():raise ValueError('Source-tree symlink: '+name)
   if p.is_dir():walk(name)
   elif p.is_file() and name not in excluded:result.add(name)
 for directory in ['src','scripts','tests','data','media','public']:walk(directory)
 for p in root.iterdir():
  if p.suffix in {'.ts','.js','.mjs','.json','.yaml','.yml'} and p.name!='SOURCE-FILE-MANIFEST.json':
   if p.is_symlink():raise ValueError('Root source symlink: '+p.name)
   if p.is_file():result.add(p.name)
 return sorted(result)
def checked_pin(row):
 p=Path(row['path'])
 if p.is_symlink() or not p.is_file():raise ValueError('Not a regular pinned file: '+str(p))
 actual={'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p)}
 if actual['bytes']!=row['bytes'] or actual['sha256']!=row['sha256']:raise ValueError('Pin drift: '+str(p))
 return actual
if digest(Path(manifest_path))!=manifest_sha:raise ValueError('Manifest hash mismatch')
manifest=json.loads(Path(manifest_path).read_text())
if digest(Path(review_path))!=review_sha:raise ValueError('Review hash mismatch')
if manifest['runName']!='fresh-validation-v2' or manifest['cwd']!=str(root):raise ValueError('Exclusive target mismatch')
if 'NODE_OPTIONS' in os.environ:raise ValueError('NODE_OPTIONS must be absent')
for row in manifest['controlPins']:checked_pin(row)
expected=json.loads(Path(manifest['expectedSources']['path']).read_text())['files']
if len(expected)!=524 or len({r['file'] for r in expected})!=524:raise ValueError('Expected source inventory must contain 524 unique paths')
status_rows=json.loads(Path(manifest['statusTransition']['path']).read_text())['after']
cmd=manifest['validationArgv'];target=out/manifest['runName'];target.mkdir(exist_ok=False)
durable(target/'invocation.json',{'at':now(),'command':cmd,'cwd':str(root),'manifest':{'path':manifest_path,'sha256':manifest_sha},'review':{'path':review_path,'sha256':review_sha},'timeoutSeconds':900,'killAfterSeconds':10,'originalRunOutcome':'unknown; no inference that its process ended','rootAcceptedOverlapRisk':True,'NODE_OPTIONS':'absent','sourceScope':manifest['sourceScope']})
def capture_inputs(filename):
 names=source_names()
 if names!=[r['file'] for r in expected]:raise ValueError('Source path set changed')
 rows=[checked_pin({'path':str(root/r['file']),'bytes':r['bytes'],'sha256':r['sha256']}) for r in expected]
 status=[checked_pin(row) for row in status_rows]
 durable(target/filename,{'at':now(),'sourceCount':len(rows),'sources':rows,'separatelyApprovedStatusDocuments':status})
try:capture_inputs('inputs-before.json')
except Exception as e:
 durable(target/'preflight-error.json',{'at':now(),'error':repr(e),'validationLaunched':False});raise
# The gate process becomes the timeout supervisor via exec; EOF never launches Node.
gate_code='import os,sys; fd=int(sys.argv[1]); token=os.read(fd,1); os.close(fd); os.execv(sys.argv[2],sys.argv[2:]) if token==b"G" else sys.exit(125)'
supervised=['/usr/bin/timeout','--signal=TERM','--kill-after=10s','900s',*cmd]
start=time.monotonic();release_error=None
with (target/'stdout.log').open('x') as so,(target/'stderr.log').open('x') as se:
 read_fd,write_fd=os.pipe()
 try:
  p=subprocess.Popen([sys.executable,'-c',gate_code,str(read_fd),*supervised],cwd=root,stdout=so,stderr=se,start_new_session=True,pass_fds=(read_fd,))
 except Exception as e:
  os.close(read_fd);os.close(write_fd)
  durable(target/'launch-error.json',{'at':now(),'error':repr(e),'validationLaunched':False});raise
 os.close(read_fd)
 try:
  pgid=os.getpgid(p.pid)
  if pgid!=p.pid:raise ValueError('New supervisor must own its process group')
  durable(target/'started.json',{'at':now(),'wrapperPid':os.getpid(),'supervisorPid':p.pid,'ownedProcessGroup':pgid,'pidScope':'Current execution PID namespace only','launchState':'Gated; Node not yet released','supervisedArgv':supervised,'timeoutOwner':'GNU timeout in this new owned group only','originalRunOutcome':'unknown; original PID is neither inspected nor signalled'})
  os.write(write_fd,b'G')
 except Exception as e:release_error=repr(e)
 finally:os.close(write_fd)
 _,status,usage=os.wait4(p.pid,0);code=os.waitstatus_to_exitcode(status);p.returncode=code
 so.flush();se.flush();os.fsync(so.fileno());os.fsync(se.fileno())
 receipt={'at':now(),'command':cmd,'supervisedArgv':supervised,'supervisorPid':p.pid,'rawWaitStatus':status,'exitCode':code,'signal':-code if code<0 else None,'elapsedSeconds':time.monotonic()-start,'maxRssKiB':usage.ru_maxrss,'releaseError':release_error,'timeoutSeconds':900,'killAfterSeconds':10,'timeoutInterpretation':('GNU timeout returned 124; conventionally expiry, but child exit 124 cannot be distinguished solely by this status' if code==124 else 'Signal or exit 137 preserved; no timeout, OOM or other cause inferred' if code<0 or code==137 else 'No timeout convention reported by supervisor'),'measuredProcess':'GNU timeout supervisor and waited children; raw wait4 rusage','postInputCheck':'pending in separate post-input-check.json'}
 durable(target/'terminal.json',receipt)
post_error=None
try:capture_inputs('inputs-after.json')
except Exception as e:post_error=repr(e)
accepted=code==0 and release_error is None and post_error is None
durable(target/'post-input-check.json',{'at':now(),'sourceCount':524,'statusDocumentCount':len(status_rows),'error':post_error,'rawTerminalPreserved':True,'validationAccepted':accepted,'scope':manifest['sourceScope'],'installedDependencyBytesChecked':False})
print(json.dumps({'terminal':str(target/'terminal.json'),'postInputCheck':str(target/'post-input-check.json'),'validationAccepted':accepted},indent=2))
sys.exit(0 if accepted else 1)
