from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,copy
repo=Path('/workspace/scratch/586427eef9f2/roadmark-104');qa=repo.parent/'roadmark-104-qa'
base=Path('/tmp/mercedes-towing-correction');out=base/'status-transition-v1';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
accept=Path('/tmp/mercedes-review/towing-correction-v2-final-report-acceptance.json')
assert sha(accept)=='73a4ef98e27c221e716a20fc9b2a44c0759fb48a97e25bf43dab5fe2852c8fc2'
now=datetime.now(timezone.utc).isoformat();docs=repo/'docs/M1_PROGRESS.md';status=qa/'work-status.json'
for p,name in [(docs,'M1_PROGRESS.before.md'),(status,'work-status.before.json')]:
 (out/name).write_bytes(p.read_bytes())
before_pins=[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in [docs,status]]
report_path=base/'runs/full-coverage-asof-2026-10-15-v2/stdout.log';report=json.load(report_path.open());mercedes=next(b for b in report['brandProgress'] if b['brand']=='Mercedes-Benz')
append='''\n\n## Mercedes-Benz corrected working report — 15 October 2026, 00:34 UTC

- A guarded supplemental packet corrects the EQA 250+ towing basis to the retained explicit 0 kg braked source. The original packet stays immutable. The exact `braked_trailer_mass` token is recognized without accepting unknown/unbraked/total near matches, mining review prose or inventing a zero from categorical “No Towing”
- Earned evidence reviews are now counted independently from strict measurement fill. Mercedes C3 passes: all 170 on-sale core cells have earned reviews, with 158 filled and twelve strict gaps. C1/C2/C5 remain open; C4/C6 still pass. Both City Edition charging windows remain unknown and their Reported durations remain unranked
- Complete before/after reporting classifies all 102 changes: three Mercedes towing gaps close and 27 existing grades are counted correctly (Mercedes five; Alfa Romeo one, Deepal three, KGM three, Leapmotor six, Mazda two and Renault seven). Global review coverage is 4,787/5,168 and strict gaps fall from 431 to 428. Every ranking, catalogue denominator, census/reconciliation result, availability-related report field and unrelated core field remains unchanged. The 27 original reviews were checked against retained facts; no fresh whole-catalogue recapture is claimed
- Current correction checks cover all 98 tests across six complete files: 83 passed in the first run; its remaining grading file hit explicit V8 heap exhaustion at 448/1 and then passed all fifteen unchanged tests alone at 512/1. The failed attempt is retained. Changed-file lint, fresh structural validation and the entire normal coverage CLI pass. These results are distinct from the pre-correction Mercedes 214 relevant tests passed across 193+21 runs; neither is a current full-project aggregate
- All original reports, source records, accepted/failed attempts and before copies remain preserved. Independent final acceptance is `towing-correction-v2-final-report-acceptance.json` in the Mercedes review evidence. A small incremental safety save follows. Standard TypeScript, production build, full-suite aggregate and real-device mobile checks remain open. M1 is unfinished; checkpoint 103 remains the latest delivered milestone. The Model Y hero/nine selling points are unchanged; no M2 or publication
'''
assert '## Mercedes-Benz corrected working report — 15 October 2026, 00:34 UTC' not in docs.read_text()
docs.write_bytes(docs.read_bytes()+append.encode())
s=json.load(status.open());previous={}
changes={
 'updatedAt':now,
 'state':'Mercedes-Benz corrected working report independently accepted; fresh validation/coverage and98 relevant tests across83+15 pass; M1 census/coverage and standard release gates remain open',
 'coverageReport':str(report_path),
 'coverageReportScope':'Entire fresh normal registered CLI report after exact towing/reporting correction; all102 changes classified against immutable pre-correction report, not byte parity to that old report',
 'latestFreshRegisteredCoverageReport':str(report_path),
 'currentIntegrationBlocker':'M1 C1/C2/C5 remain open. No current correction runtime blocker; standard TypeScript, full-suite aggregate, production build and real-device mobile checks remain unverified. Original session-loss and failed test attempts stay historical.',
 'currentWorkingSourceSnapshotScope':'Exact six-file towing/reporting correction applied and independently accepted. Later docs/status transition is recorded separately. New incremental recovery pending; existing Library source IDs remain historical until delivery.',
 'latestFreshRelevantTests':{'brand':'Mercedes-Benz','scope':'Six complete relevant files after towing/reporting correction','distinctTestsPassed':98,'firstRunPassed':83,'firstRunFailedFiles':1,'firstRunFailure':'Explicit V8 JavaScript heap out of memory in m1-evidence-grading.test.ts at448/1','isolatedUnchangedRetryPassed':15,'retryHeap':'512/1','singleCleanAggregate':False,'fullProjectSuite':False,'directory':str(base/'runs'),'acceptance':'/tmp/mercedes-review/towing-correction-v2-tests-lint-acceptance.json'},
 'openCurrentGates':['Standard TypeScript','Production build','Current full-suite aggregate','Real-device mobile checks','M1 market/coverage closure'],
}
latest={'brand':'Mercedes-Benz','researchCompleted':False,'releaseReady':False,'originalPacketSha256':'a2b0859623539166e51fd1808e7cd4fbeb7314ae7dd91a11334cf66e057265f4','supplementalPacket':'data/m1-brand-updates/mercedes-benz-towing-basis-2026-10-15.json','supplementalPacketSha256':sha(repo/'data/m1-brand-updates/mercedes-benz-towing-basis-2026-10-15.json'),'relevantTests':changes['latestFreshRelevantTests'],'validateExit':0,'coverageExit':0,'changedFileLintExit':0,'fullTypecheck':'Unverified; no new current full standard compiler pass','fullProjectSuite':'No current clean full-suite aggregate','productionBuild':'Unverified current source','realDeviceMobile':'Unverified','successfulRunDirectory':str(base/'runs'),'coverage':{'catalogue':report['allCatalogueVersions'],'tier1':report['tierOneVersions'],'onSale':report['onSaleVersions'],'coreReviewed':report['grading']['reviewedCoreCells'],'coreDenominator':report['grading']['totalCoreCells'],'strictGaps':len(report['gaps'])},'mercedesCoverage':{'onSale':mercedes['onSaleVersions'],'strictCoreFilled':sum(x['filled'] for x in mercedes['core']),'strictCoreTotal':170,'strictCoreGaps':mercedes['coreGaps'],'unreviewedCoreGrades':mercedes['unreviewedCoreGrades'],'criteria':mercedes['criteria']},'finalAcceptance':str(accept),'finalAcceptanceSha256':sha(accept),'wholeReportComparison':str(base/'report-comparison-v2/comparison-artifact-manifest.json'),'newCanonicalCapture':False,'currentWholeCatalogueValueEqualityClaimed':False}
changes['latestWorkingBrandChecks']=latest
for key,value in changes.items():
 previous[key]=copy.deepcopy(s.get(key));s[key]=value
s.setdefault('workStatusHistory',[]).append({'supersededAt':now,'scope':'Current working-state/report/check fields only; all earlier transition and recovery records retained','previous':previous,'beforeSnapshot':str(out/'work-status.before.json'),'beforeSha256':sha(out/'work-status.before.json')})
s['mercedesCorrectedWorking']=copy.deepcopy(latest)
s['preCorrectionMercedesIntegrationGate']={'scope':'Historical registered source before towing/reporting correction','relevantTests':{'passedAcrossSeparateRuns':214,'runs':[193,21],'singleCleanAggregate':False,'initialFeatureFileSIGKILLRetained':True},'review':'/tmp/mercedes-review/precorrection-registered-mercedes-integration-gate-v1.json','reviewSha256':'91d8f950c98adf31809feca0ce0c291282caef6a5f915fcbaa469d3d5a7e425a','separateFromCurrent98Tests':True}
s['mercedesCorrectionRecovery']={'state':'Bounded incremental safety save pending; prior recovery records remain unchanged','applicationTransition':str(base/'application-v2.json'),'statusTransition':str(out/'transition.json'),'publicationAuthorized':False}
status.write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
(out/'M1_PROGRESS.after.md').write_bytes(docs.read_bytes());(out/'work-status.after.json').write_bytes(status.read_bytes())
transition={'at':now,'scope':'Docs append plus current QA status update only, separate from six-file reviewed application','priorHistoryPreserved':True,'runtimeSourceChanges':False,'before':before_pins,'after':[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in [docs,status]],'frozenBeforeAndAfterDirectory':str(out),'finalAcceptance':{'path':str(accept),'sha256':sha(accept)}}
(out/'transition.json').write_text(json.dumps(transition,indent=2)+'\n')
print(json.dumps(transition,indent=2))
