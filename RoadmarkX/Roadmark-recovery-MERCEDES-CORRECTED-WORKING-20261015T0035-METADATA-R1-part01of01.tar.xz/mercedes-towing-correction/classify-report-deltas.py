from pathlib import Path
import json,hashlib,re
base=Path('/tmp/mercedes-towing-correction/report-comparison-v2')
b=json.load(open('/tmp/mercedes-staging-plan/consumer-preparation/consumer-artifacts/report-v5/staged-report.json'))
a=json.load(open('/tmp/mercedes-towing-correction/runs/full-coverage-asof-2026-10-15-v2/stdout.log'))
delta=json.load((base/'complete-semantic-delta.json').open())
expected={
 ('Alfa Romeo','dc_charge_time_min'):{'Check':1},
 ('Deepal','dc_charge_time_min'):{'Check':3},
 ('KGM','towing_braked_kg'):{'Check':3},
 ('Leapmotor','dc_charge_time_min'):{'Check':6},
 ('Mazda','towing_braked_kg'):{'Check':2},
 ('Mercedes-Benz','dc_charge_time_min'):{'Reported':2},
 ('Mercedes-Benz','towing_braked_kg'):{'Reported':3},
 ('Renault','dc_charge_time_min'):{'Check':3},
 ('Renault','towing_braked_kg'):{'Confirmed':4},
}
removed_ids={
 'mercedes_benz_eqa_current__eqa_250_plus__20261010',
 'mercedes_benz_eqa_city_edition__eqa_250_plus_city_edition__20261015',
 'mercedes_benz_eqb_city_edition__eqb_250_plus_city_edition__20261015',
}
removed={(id,'towing_braked_kg') for id in removed_ids}
assert a['gaps']==[g for g in b['gaps'] if (g['carId'],g['key']) not in removed]
assert len(b['gaps'])-len(a['gaps'])==3
assert a['rankings']==b['rankings']
assert [(c['id'],c['pass']) for c in a['criteria']]==[(c['id'],c['pass']) for c in b['criteria']]
changed_fields=[];cells=[]
for brand in a['brandProgress']:
 prior=next(x for x in b['brandProgress'] if x['brand']==brand['brand'])
 total_delta=0
 for f in brand['core']:
  old=next(x for x in prior['core'] if x['key']==f['key']);expected_grades=expected.get((brand['brand'],f['key']))
  if not expected_grades:
   assert f==old,(brand['brand'],f['key']);continue
  n=sum(expected_grades.values());total_delta+=n
  assert {k:f['grades'][k]-old['grades'][k] for k in f['grades']}=={k:(-n if k=='Unreviewed' else expected_grades.get(k,0)) for k in f['grades']}
  assert f['reviewed']-old['reviewed']==n
  filldelta=3 if brand['brand']=='Mercedes-Benz' and f['key']=='towing_braked_kg' else 0
  assert f['filled']-old['filled']==filldelta
  for fixed in ['key','label','target','total','passes']:assert f[fixed]==old[fixed]
  # The previous strict issue identifies exactly the non-null, measurement-mismatched cells.
  affected=[g for g in b['gaps'] if g['brand']==brand['brand'] and g['key']==f['key'] and g['reason'].startswith('Published ')]
  assert len(affected)==n,(brand['brand'],f['key'],len(affected),n)
  for g in affected:
   assert (g['carId'] in next(r for r in a['rankings'] if r['key']==f['key'])['rankedIds']) is False
   cells.append({**g,'countedGrade':next(iter(expected_grades)), 'strictGapRemains':(g['carId'],g['key']) not in removed,'numericValueChanged':False,'evidence':'Existing accepted strict-gap record and newly correct earned-grade aggregate; exact nonmutation is established by source transition/fixtures, not a fresh full-catalogue equality proof'})
  changed_fields.append({'brand':brand['brand'],'key':f['key'],'earnedGradeIncreases':expected_grades,'strictFilledIncrease':filldelta,'strictGapsRetained':len(affected)-filldelta})
 assert brand['unreviewedCoreGrades']==prior['unreviewedCoreGrades']-total_delta
 assert brand['coreGaps']==prior['coreGaps']-(3 if brand['brand']=='Mercedes-Benz' else 0)
 for c in ['C1','C2','C4','C5','C6']:assert brand['criteria'][c]==prior['criteria'][c]
 assert brand['criteria']['C3']==(prior['criteria']['C3'] or brand['brand'] in ['Mercedes-Benz','Deepal'])
assert len(cells)==27
assert a['grading']['reviewedCoreCells']-b['grading']['reviewedCoreCells']==27
assert a['grading']['totalCoreCells']==b['grading']['totalCoreCells']==5168
assert sum(c['strictGapRemains'] for c in cells)==24
classifications=[]
for row in delta:
 p=row['path'];category=None
 if p.startswith('$.gaps['):category='Three source-backed Mercedes towing measurement-basis gaps removed'
 elif p=='$.gradeNote':category='Reviewed count updated and approved grade/fill explanation added'
 elif p.startswith('$.criteria[C2]'):category='Derived global strict-gap count only; C2 flag unchanged'
 elif p.startswith('$.criteria[C3]') or p.startswith('$.grading.'):category='Derived global earned-review total; C3 flag unchanged'
 elif p.startswith('$.core['):category='Derived global core aggregates: three towing fills and 27 existing earned reviews'
 elif p.startswith('$.brandProgress['):
  if '.core[' in p:
   if any(x in p for x in ['.filled','.filledPercent']):category='Mercedes towing strict fill increases by three; all other strict fill unchanged'
   elif p.endswith('.explanation'):category='Existing report pattern rule: Mercedes towing now uses review reasons; Renault100% Confirmed needs no below-half explanation'
   else:category='Earned-review counts/percentages/pass markers follow unchanged fact review grades'
  elif p.endswith('.criteria.C3'):category='Deepal and Mercedes now have all core grades reviewed; other completion criteria stay open'
  elif p.endswith('.coreGaps'):category='Derived Mercedes strict-gap count15 to12'
  elif p.endswith('.unreviewedCoreGrades'):category='Derived brand unreviewed total subtracts existing valid reviews'
  elif any(p.endswith('.'+k) for k in ['reason','remaining','researchRemaining']):category='Derived brand progress prose reconciles corrected grade/gap counts; brand completion lists unchanged'
 assert category,p
 classifications.append({**row,'classification':category})
summary={'schemaVersion':1,'status':'all_102_complete_semantic_deltas_classified','totalDeltas':len(delta),'changedFields':changed_fields,'reviewCells':27,'retainedStrictGapsAmongReviewedCells':24,'strictGapsRemoved':3,'globalGradesIncrease':{'Confirmed':4,'Check':18,'Reported':5},'allRankingsExactlyUnchanged':True,'allExistingGapRecordsUnchangedExceptExactThreeRemovals':True,'allOtherCoreFieldsExactlyUnchanged':True,'allGlobalCriterionPassFlagsUnchanged':True,'onlyBrandCriterionChanges':['Mercedes-Benz C3 false to true','Deepal C3 false to true'],'allDenominatorsAndCatalogueCountsUnchanged':True,'brandCompletionListsUnchanged':True,'unexplainedDeltas':[],'sourceMutationScope':'Exact reviewed six-file transition only; original packet retained','limit':'No fresh complete-catalogue/raw-field/feature equality recapture was authorized or performed. Current proof consists of exact source pins, guarded packet/full-target behavioral equality, structural validation and complete whole-report comparison.'}
for filename,data in [('classified-deltas.json',classifications),('affected-review-cells.json',cells),('classification-summary.json',summary)]:
 with (base/filename).open('x') as f:json.dump(data,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
