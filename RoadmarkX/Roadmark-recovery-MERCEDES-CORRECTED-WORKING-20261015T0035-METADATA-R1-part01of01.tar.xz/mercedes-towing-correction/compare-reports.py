from pathlib import Path
import json,hashlib,sys
before_path=Path('/tmp/mercedes-staging-plan/consumer-preparation/consumer-artifacts/report-v5/staged-report.json')
after_path=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(exist_ok=False)
before=json.loads(before_path.read_text());after=json.loads(after_path.read_text());changes=[]
MISSING={'$missing':True}
def record(path,a,b):changes.append({'path':path,'before':a,'after':b})
def keyer(a,b):
 if not a and not b:return None
 if not all(isinstance(x,dict) for x in a+b):return None
 for keys in [('carId','key'),('key',),('id',),('brand',)]:
  if all(all(k in x for k in keys) for x in a+b):
   key=lambda x: '|'.join(str(x[k]) for k in keys)
   if len({key(x) for x in a})==len(a) and len({key(x) for x in b})==len(b):return key
 return None
def walk(a,b,path='$'):
 if a==b:return
 if isinstance(a,dict) and isinstance(b,dict):
  for k in sorted(set(a)|set(b)):
   if k not in a:record(path+'.'+k,MISSING,b[k])
   elif k not in b:record(path+'.'+k,a[k],MISSING)
   else:walk(a[k],b[k],path+'.'+k)
 elif isinstance(a,list) and isinstance(b,list):
  key=keyer(a,b)
  if key:
   aa={key(x):x for x in a};bb={key(x):x for x in b}
   common=set(aa)&set(bb)
   if [key(x) for x in a if key(x) in common]!=[key(x) for x in b if key(x) in common]:record(path+'.$order',[key(x) for x in a],[key(x) for x in b])
   for k in sorted(set(aa)|set(bb)):
    if k not in aa:record(path+'['+k+']',MISSING,bb[k])
    elif k not in bb:record(path+'['+k+']',aa[k],MISSING)
    else:walk(aa[k],bb[k],path+'['+k+']')
  else:record(path,a,b)
 else:record(path,a,b)
walk(before,after)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
changed_tops=[k for k in sorted(set(before)|set(after)) if before.get(k,MISSING)!=after.get(k,MISSING)]
brands=[]
bb={b['brand']:b for b in before['brandProgress']};ab={b['brand']:b for b in after['brandProgress']}
for brand in sorted(set(bb)|set(ab)):
 a=bb.get(brand);b=ab.get(brand)
 if a!=b:
  brands.append({'brand':brand,'before':{'coreGaps':a['coreGaps'],'unreviewedCoreGrades':a['unreviewedCoreGrades'],'criteria':a['criteria']},'after':{'coreGaps':b['coreGaps'],'unreviewedCoreGrades':b['unreviewedCoreGrades'],'criteria':b['criteria']},'changedCoreFields':[f['key'] for f in a['core'] if f!=next(g for g in b['core'] if g['key']==f['key'])]})
summary={'schemaVersion':1,'before':pin(before_path),'after':pin(after_path),'changedTopLevelFields':changed_tops,'unchangedTopLevelFields':[k for k in before if k not in changed_tops],'completeSemanticDeltaCount':len(changes),'brandsChanged':brands,'coreBeforeAfter':[{'key':a['key'],'before':a,'after':b} for a,b in zip(before['core'],after['core']) if a!=b],'globalGapCount':{'before':len(before['gaps']),'after':len(after['gaps'])},'grading':{'before':before['grading'],'after':after['grading']},'allRankingsExactlyUnchanged':before['rankings']==after['rankings'],'note':'Both complete unfiltered raw reports are retained; the semantic diff keys structured lists only for comparison. No catalogue full-value equality is claimed.'}
(out/'complete-semantic-delta.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n')
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
