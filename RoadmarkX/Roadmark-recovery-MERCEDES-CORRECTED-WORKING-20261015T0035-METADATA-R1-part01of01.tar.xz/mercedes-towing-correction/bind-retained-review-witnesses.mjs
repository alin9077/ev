import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readJson, locate, pin, streamRows, digestRows, fileHash } from '/tmp/xpeng-staging-plan/baseline-io.mjs';
const base='/tmp/mercedes-towing-correction/report-comparison-v2';
const manifestPath='/tmp/mercedes-staging-plan/consumer-preparation/v5/manifests/report-v5.json';
assert.equal(fileHash(manifestPath),'70564bf4cdc4e367d59d98fe49026af93727532937470111b26fa4fb3b3c5bde');
const manifest=readJson(manifestPath),anchors=manifest.anchors;
const acceptedPins=new Map(manifest.inputPins.map(row=>[`${row.anchor}\0${row.file}`,row]));
const touched=new Map();
function checked(ref){
 const approved=acceptedPins.get(`${ref.anchor}\0${ref.file}`);assert(approved,'No accepted retained input pin');
 if(ref.sha256)assert.equal(ref.sha256,approved.sha256);
 const actual=pin(anchors,approved);touched.set(`${actual.anchor}\0${actual.file}`,actual);return locate(anchors,approved);
}
const receipt=readJson(checked(manifest.coreReceipt));
const index=readJson(checked(receipt.storageIndex));
assert.equal(index.cars.rows,409);
const cells=readJson(path.join(base,'affected-review-cells.json'));
assert.equal(cells.length,27);
const ids=new Set(cells.map(row=>row.carId));
const selected=new Map();
async function select(wanted,ref){
 const current=readJson(checked(ref)),d=current.cars;
 const replacements=readJson(checked(d.replacements));
 for(const car of replacements)if(wanted.has(car.id)){selected.set(car.id,car);wanted.delete(car.id);}
 if(!wanted.size)return;
 checked(d.baseline);
 if(d.baseline.format==='storage-index')await select(wanted,d.baseline);
 else await streamRows(anchors,d.baseline,car=>{if(wanted.has(car.id)){selected.set(car.id,car);wanted.delete(car.id);}});
}
await select(new Set(ids),receipt.storageIndex);
assert.equal(selected.size,ids.size);
const sources=[];checked(index.research.sources);
await streamRows(anchors,index.research.sources,row=>sources.push(row));
const correction=readJson('/workspace/scratch/586427eef9f2/roadmark-104/data/m1-brand-updates/mercedes-benz-towing-basis-2026-10-15.json');
const edit=correction.facts[0];
const beforeModule=fs.readFileSync('/tmp/mercedes-towing-correction/v2/before/src/lib/evidence-grading.ts','utf8');
const liveModule=fs.readFileSync('/workspace/scratch/586427eef9f2/roadmark-104/src/lib/evidence-grading.ts','utf8');
assert.equal(beforeModule.split('/** A trailer-total observation')[0],liveModule.split('/** A trailer-total observation')[0]);
const require=createRequire('/workspace/scratch/586427eef9f2/roadmark-104/package.json');
const {hasEarnedBuyerGrade}=require('./src/lib/evidence-grading.ts');
const witnesses=cells.map(cell=>{
 const car=selected.get(cell.carId),expected=index.cars.carHashes.find(row=>row.id===cell.carId),digest=digestRows([car]);
 assert.equal(digest.sha256,expected.afterSha256);assert.equal(digest.bytes,expected.bytes);
 const fact=car.facts[cell.key];assert(fact);assert.notEqual(fact.value,null);assert.notEqual(fact.value,undefined);
 assert.equal(fact.buyerGrade,{Confirmed:'confirmed',Check:'check',Reported:'reported'}[cell.countedGrade]);
 assert.equal(hasEarnedBuyerGrade(fact,sources,'2026-10-15'),true);
 const corrected=cell.carId===edit.variantId&&cell.key===edit.after.key;
 if(corrected)assert.deepEqual(fact,edit.before);
 const effective=corrected?edit.after:fact;
 assert.equal(hasEarnedBuyerGrade(effective,sources,'2026-10-15'),true);
 const cited=effective.sourceIds.map(id=>{const source=sources.find(row=>row.id===id);assert(source);return source;});
 return {...cell,retainedCompleteCarDigest:digest,acceptedCompleteCarIndexRow:expected,priorFact:fact,expectedPostCorrectionFact:effective,exactSupplementalCorrection:corrected,sources:cited,existingReviewEarned:true};
});
assert.equal(witnesses.filter(row=>row.exactSupplementalCorrection).length,1);
for(const ref of touched.values())pin(anchors,ref);
const result={schemaVersion:1,status:'all27_retained_fact_review_witnesses_bound_without_hydration',acceptedManifest:{path:manifestPath,sha256:fileHash(manifestPath)},retainedInputPins:[...touched.values()],witnesses,pureHasEarnedBuyerGradePrefixUnchanged:true,productionCatalogueLoaderCalls:0,newCanonicalCapture:false,limit:'Retained accepted facts plus the exact approved supplemental replacement only; this is not a fresh whole-catalogue value-equality result.'};
fs.writeFileSync(path.join(base,'retained-fact-review-witnesses.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:result.status,witnesses:witnesses.length,retainedCars:selected.size,retainedInputs:touched.size,productionCatalogueLoaderCalls:0,newCanonicalCapture:false}));
