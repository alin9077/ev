from pathlib import Path
import hashlib,json,subprocess,os,time,sys
from datetime import datetime,timezone
root=Path('/workspace/scratch/586427eef9f2/roadmark-104')
base=Path('/tmp/mercedes-towing-correction/runs');base.mkdir(exist_ok=True)
name=sys.argv[1];command=sys.argv[2:];target=base/name;target.mkdir(exist_ok=False)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def write(name,data):
 with (target/name).open('x') as f:
  json.dump(data,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def inventory():
 paths=[]
 for directory in ['src','scripts','tests','data','media','public','docs']:
  paths += [p for p in (root/directory).rglob('*') if p.is_file()]
 paths += [p for p in root.iterdir() if p.is_file() and p.suffix in {'.ts','.js','.mjs','.json','.yaml','.yml'} and p.name!='SOURCE-FILE-MANIFEST.json']
 return [{'file':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(set(paths))]
write('invocation.json',{'at':now(),'cwd':str(root),'command':command,'nodeOptions':os.environ.get('NODE_OPTIONS'),'timeoutSeconds':900,'killAfterSeconds':10,'wrapper':{'path':__file__,'sha256':sha(Path(__file__))}})
before=inventory();write('inputs-before.json',before)
wrapped=['/usr/bin/timeout','--signal=TERM','--kill-after=10s','900s',*command]
start=time.monotonic()
with (target/'stdout.log').open('x') as so,(target/'stderr.log').open('x') as se:
 p=subprocess.Popen(wrapped,cwd=root,stdout=so,stderr=se,start_new_session=True)
 write('started.json',{'at':now(),'supervisorPid':p.pid,'processGroup':os.getpgid(p.pid),'supervisedArgv':wrapped})
 _,status,usage=os.wait4(p.pid,0);code=os.waitstatus_to_exitcode(status);p.returncode=code
 so.flush();se.flush();os.fsync(so.fileno());os.fsync(se.fileno())
 receipt={'at':now(),'command':command,'supervisedArgv':wrapped,'exitCode':code,'signal':-code if code<0 else None,'rawWaitStatus':status,'elapsedSeconds':time.monotonic()-start,'maxRssKiB':usage.ru_maxrss,'stdout':{'bytes':(target/'stdout.log').stat().st_size,'sha256':sha(target/'stdout.log')},'stderr':{'bytes':(target/'stderr.log').stat().st_size,'sha256':sha(target/'stderr.log')},'timeoutInterpretation':'No timeout convention' if code not in [124,137] and code>=0 else 'Raw status preserved; no cause inferred','inputVerification':'pending separate receipt'}
 write('terminal.json',receipt)
after=inventory();write('inputs-after.json',after)
check={'at':now(),'unchanged':before==after,'beforeCount':len(before),'afterCount':len(after),'beforeHash':sha(target/'inputs-before.json'),'afterHash':sha(target/'inputs-after.json'),'allSourceDataMediaPublicDocsAndRootConfiguration':'pinned; installed dependency bytes excluded'}
write('input-verification.json',check)
print(json.dumps({'run':name,**receipt,'inputUnchanged':before==after},indent=2))
print((target/'stdout.log').read_text()[-4500:]);print((target/'stderr.log').read_text()[-2000:])
sys.exit(0 if code==0 and before==after else 1)
