from pathlib import Path
import json,hashlib,difflib,copy
repo=Path('/workspace/scratch/586427eef9f2/roadmark-104')
root=Path('/tmp/mercedes-towing-correction/v1')
files=['src/lib/evidence-grading.ts','scripts/reporting/reports.ts','data/m1-brand-updates/registry.json','tests/m1-coverage-tracking.test.ts','tests/brand-updates.test.ts']
for name in files:
 for side in ('before','after'):
  p=root/side/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((repo/name).read_bytes())
p=root/'after/src/lib/evidence-grading.ts';s=p.read_text();old='  return /\\bbraked\\b/i.test(basis) && !unclear.test(context);';assert s.count(old)==1
s=s.replace(old,'''  // Preserve the exact structured source label without normalising arbitrary
  // underscore tokens or inferring a measurement basis from review prose.
  const knownBrakedToken = [fact.basis, fact.comparisonBasis].includes(
    "braked_trailer_mass",
  );
  return (/\\bbraked\\b/i.test(basis) || knownBrakedToken) && !unclear.test(context);''');p.write_text(s)
p=root/'after/scripts/reporting/reports.ts';s=p.read_text();old='''      const grade = existingGrade(
        cell.fact,
        present,''';assert s.count(old)==1
s=s.replace(old,'''      // An earned review describes the published fact, independently of whether
      // its measurement basis fills this strict core field.
      const grade = existingGrade(
        cell.fact,
        hasValue(cell.fact?.value),''');p.write_text(s)
original=json.loads((repo/'data/m1-brand-updates/mercedes-benz-2026-10-15.json').read_text())
vid='mercedes_benz_eqa_current__eqa_250_plus__20261010'
original_fact=next(x['after'] for x in original['facts'] if x['variantId']==vid and x['after']['key']=='towing_braked_kg')
guard=next(x['after'] for x in original['versionUpdates'] if x['variantId']==vid)
packet_id='m1-mercedes-benz-towing-basis-2026-10-15'
after=copy.deepcopy(original_fact);after['basis']='CarsGuide 2026 EQA 250+: explicitly published 0 kg braked towing';after['gradeReview']['overlayId']=packet_id
packet={'schemaVersion':1,'id':packet_id,'brand':'Mercedes-Benz','reviewedAt':'2026-10-15','reviewedBy':'Roadmark independently reviewed Australian Mercedes-Benz towing-basis correction','sources':[copy.deepcopy(next(s for s in original['sources'] if s['id']==id)) for id in original_fact['sourceIds']],'models':[],'variants':[],'versionGuards':[{'variantId':vid,'before':copy.deepcopy(guard)}],'versionUpdates':[],'facts':[{'variantId':vid,'before':copy.deepcopy(original_fact),'after':after}],'availability':[],'summaries':[]}
packet_name='data/m1-brand-updates/mercedes-benz-towing-basis-2026-10-15.json'
p=root/'after'/packet_name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n')
p=root/'after/data/m1-brand-updates/registry.json';r=json.loads(p.read_text());i=r['packets'].index('mercedes-benz-2026-10-15.json');r['packets'].insert(i+1,Path(packet_name).name);p.write_text(json.dumps(r,indent=2)+'\n')
