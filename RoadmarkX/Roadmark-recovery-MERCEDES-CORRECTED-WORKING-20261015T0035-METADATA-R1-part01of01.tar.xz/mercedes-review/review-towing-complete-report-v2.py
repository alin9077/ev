import pathlib,json,hashlib,datetime,collections
P=pathlib.Path('/tmp/mercedes-towing-correction'); R=pathlib.Path('/tmp/mercedes-review'); D=P/'report-comparison-v2'; RUN=P/'runs/full-coverage-asof-2026-10-15-v2'
def read(p):return json.loads(pathlib.Path(p).read_text())
def pin(p):
 p=pathlib.Path(p);h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for x in iter(lambda:f.read(65536),b''):h.update(x);n+=len(x)
 return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
old=pathlib.Path('/tmp/mercedes-staging-plan/consumer-preparation/consumer-artifacts/report-v5/staged-report.json');new=RUN/'stdout.log'
assert pin(old)['sha256']=='8125170d5f37a4d4e79b8dfb78e244e7ecf3df2083dac301510c15116ab2507b';assert pin(new)['sha256']=='95f3e8135a0b375e39d032f0697d1ff0064161132dc33dea0953f526002342c8'
b,a=read(old),read(new);cm=read(D/'comparison-artifact-manifest.json');assert pin(D/'comparison-artifact-manifest.json')['sha256']=='54a1266d9f49d15361b7f4b75d9577ce5a7b56bc3d96358b03eec012efb81d18'
for x in cm['files']:assert pin(x['path'])==x
w=read(D/'retained-fact-review-witnesses.json')['witnesses'];assert len(w)==27
removed={(x['carId'],x['key']) for x in w if not x['strictGapRemains']};assert len(removed)==3
assert a['gaps']==[x for x in b['gaps'] if (x['carId'],x['key']) not in removed]
assert [x['brand'] for x in b['brandProgress']]==[x['brand'] for x in a['brandProgress']]
assert [x['key'] for x in b['core']]==[x['key'] for x in a['core']]
assert [x['id'] for x in b['criteria']]==[x['id'] for x in a['criteria']]
assert b['rankings']==a['rankings'];unchanged=[k for k in b if b[k]==a[k]]
assert set(b)==set(a) and set(b)-set(unchanged)=={'gradeNote','core','gaps','grading','brandProgress','criteria'}
missing={'$missing':True};ds=[]
def walk(x,y,p='$'):
 if x==y:return
 if isinstance(x,dict) and isinstance(y,dict):
  for k in sorted(set(x)|set(y)):
   if k not in x or k not in y:ds.append({'path':p+'.'+k,'before':x.get(k,missing),'after':y.get(k,missing)})
   else:walk(x[k],y[k],p+'.'+k)
 elif isinstance(x,list) and isinstance(y,list):
  key=(lambda q:q['brand']) if p.endswith('.brandProgress') else (lambda q:q['key']) if p.endswith('.core') else (lambda q:q['id']) if p.endswith('.criteria') else (lambda q:q['carId']+'|'+q['key']) if p=='$.gaps' else None
  if key:
   xx={key(v):v for v in x};yy={key(v):v for v in y};assert len(xx)==len(x) and len(yy)==len(y)
   for k in sorted(set(xx)|set(yy)):
    if k not in xx or k not in yy:ds.append({'path':p+'['+k+']','before':xx.get(k,missing),'after':yy.get(k,missing)})
    else:walk(xx[k],yy[k],p+'['+k+']')
  else:ds.append({'path':p,'before':x,'after':y})
 else:ds.append({'path':p,'before':x,'after':y})
walk(b,a);assert len(ds)==102 and ds==read(D/'complete-semantic-delta.json')
classified=read(D/'classified-deltas.json');assert [{k:v for k,v in row.items() if k!='classification'} for row in classified]==ds
assert all(x['classification'] for x in classified)
counts=collections.Counter((x['brand'],x['key'],x['countedGrade']) for x in w)
assert collections.Counter(x['brand'] for x in w)=={'Alfa Romeo':1,'Deepal':3,'KGM':3,'Leapmotor':6,'Mazda':2,'Mercedes-Benz':5,'Renault':7}
assert collections.Counter(x['countedGrade'] for x in w)=={'Confirmed':4,'Check':18,'Reported':5}
for before,after in zip(b['brandProgress'],a['brandProgress']):
 assert [x['key'] for x in before['core']]==[x['key'] for x in after['core']]
 n=sum(v for (brand,key,grade),v in counts.items() if brand==before['brand']);assert before['unreviewedCoreGrades']-after['unreviewedCoreGrades']==n
 for bf,af in zip(before['core'],after['core']):
  dn=sum(v for (brand,key,grade),v in counts.items() if brand==before['brand'] and key==bf['key'])
  for grade in bf['grades']:
   expected=-dn if grade=='Unreviewed' else counts[(before['brand'],bf['key'],grade)]
   assert af['grades'][grade]-bf['grades'][grade]==expected
  assert af['reviewed']-bf['reviewed']==dn
  assert af['filled']-bf['filled']==(3 if before['brand']=='Mercedes-Benz' and bf['key']=='towing_braked_kg' else 0)
 assert before['coreGaps']-after['coreGaps']==(3 if before['brand']=='Mercedes-Benz' else 0)
 for k in before['criteria']:
  assert after['criteria'][k]==(True if k=='C3' and before['brand'] in ['Mercedes-Benz','Deepal'] else before['criteria'][k])
for x in w:
 rank=next(q for q in a['rankings'] if q['key']==x['key']);assert (x['carId'] in rank['rankedIds'])==x['rankedBeforeAndAfter']
 assert ((x['carId'],x['key']) in {(q['carId'],q['key']) for q in a['gaps']})==x['strictGapRemains']
for x in b['criteria']:assert x['pass']==next(q for q in a['criteria'] if q['id']==x['id'])['pass']
assert a['grading']['reviewedCoreCells']-b['grading']['reviewedCoreCells']==27
assert a['grading']['totalCoreCells']==b['grading']['totalCoreCells']==5168
assert len(a['gaps'])==428 and len(b['gaps'])==431
mb=next(x for x in a['brandProgress'] if x['brand']=='Mercedes-Benz');assert mb['coreGaps']==12 and mb['unreviewedCoreGrades']==0
assert mb['criteria']=={'C1':False,'C2':False,'C3':True,'C4':True,'C5':False,'C6':True}
for x in w:
 if x['brand']=='Mercedes-Benz':assert not x['rankedBeforeAndAfter']
 if x['brand']=='Renault' and x['key']=='towing_braked_kg':assert x['priorFact']['buyerGrade']=='confirmed' and x['strictGapRemains'] and not x['rankedBeforeAndAfter']
t=read(RUN/'terminal.json');iv=read(RUN/'input-verification.json');ins=read(RUN/'inputs-before.json');assert t['exitCode']==t['rawWaitStatus']==0 and t['signal'] is None and t['stderr']['bytes']==0
assert len(ins)==632 and ins==read(RUN/'inputs-after.json')==read(P/'runs/focused-fixtures-v2/inputs-before.json');assert iv['unchanged'] and pin(RUN/'inputs-before.json')['sha256']==iv['beforeHash']==iv['afterHash']==pin(RUN/'inputs-after.json')['sha256']
for stream in ['stdout','stderr']:
 x=pin(RUN/(stream+'.log'));assert {k:x[k] for k in ['bytes','sha256']}==t[stream]
assert t['command'][-4:]==['scripts/report-coverage.ts','--as-of','2026-10-15','--json']
refs=['towing-coverage-correction-v2-static-review.json','towing-correction-v2-application-review.json','towing-correction-v2-tests-lint-acceptance.json','towing-correction-v2-structural-acceptance.json','towing-correction-v2-retained-witnesses-review.json','precorrection-registered-mercedes-integration-gate-v1.json']
r={'schemaVersion':1,'reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'accepted_exact_registered_towing_correction_and_complete_global_report_delta','beforeReport':pin(old),'afterReport':pin(new),'comparisonManifest':pin(D/'comparison-artifact-manifest.json'),'comparisonArtifacts':cm['files'],'priorIndependentReviews':[pin(R/x) for x in refs],'runArtifacts':[pin(RUN/x) for x in ['invocation.json','started.json','terminal.json','inputs-before.json','inputs-after.json','input-verification.json','stdout.log','stderr.log']],'measured':t,'checks':{'all102SemanticDeltasIndependentlyReproduced':True,'completeChangedAndUnchangedArraysAndOrderChecked':True,'all27ReviewWitnessesMatchRetainedPriorFactsAndCompleteCarDigests':True,'allChangedGradeCountsReconcileExactlyTo27UnchangedUnderlyingBuyerGrades':True,'onlyThreeExactMercedesTowingGapsRemoved':True,'all428RemainingGapObjectsAndOrderUnchanged':True,'allRankingsExactlyUnchanged':True,'allGlobalCriterionPassFlagsUnchanged':True,'onlyBrandCriterionChangesMercedesAndDeepalC3':True,'all632RecordedBeforeAfterInputsEqualAcceptedCorrectionState':True,'unexplainedDeltas':[]},'unchangedTopLevelFields':unchanged,'earnedReviewAccounting':{'total':27,'byBrand':dict(collections.Counter(x['brand'] for x in w)),'byExistingGrade':{'Confirmed':4,'Check':18,'Reported':5},'priorReviewedCells':4760,'currentReviewedCells':4787,'totalCoreCells':5168,'retainedStrictGapsAmong27':24,'note':'These existing fact grades are now correctly counted independently of strict measurement fill. No underlying fact grade was promoted.'},'mercedes':{'onSaleVersions':10,'strictCoreSlots':170,'strictFilled':158,'strictGaps':12,'reviewedCells':170,'unreviewedCells':0,'criteria':mb['criteria'],'remainingGapRecords':[x for x in a['gaps'] if x['brand']=='Mercedes-Benz'],'city':'Both Reported charging durations retain genuinely unknown windows, exact strict-gap records and no ranking membership. Three Reported towing figures now fill strict slots; all three remain unranked.','availabilityAndCensus':'No GLC or City availability changes; census/reconciliation objects and counts are exact. C1, C2 and C5 remain open.'},'knownWindowQualification':'Twelve existing Deepal/Leapmotor/Renault charging entries already rank in compatible published-window groups while remaining strict10–80% gaps. Their full ranking objects and membership are unchanged. The earlier author analysis assertion that all27 were unranked is explicitly preserved as rejected.','preservedAnalysisAttempt':pin(P/'classification-attempt-v1.json'),'limits':['The exact source transition, full-target guarded fixture and complete report proof are accepted; no fresh whole-catalogue/raw-field/feature equality recapture was authorized or claimed.','The98 correction-related tests passed across83 initial passes and15 unchanged-file retry passes; original explicit heap-OOM invocation remains failed. Prior214 integration cases were also split across two runs and refer to the pre-correction state.','Original canonical, packet, pre-correction report/parity and first outcome-unknown validation remain immutable.','Standard TypeScript, production build, current full-suite aggregate and mobile gates remain open.','M1 whole-market and Mercedes C1/C2/C5 closure remain open; no M2, publication or release-ready claim.'],'releaseReady':False}
out=R/'towing-correction-v2-final-report-acceptance.json';assert not out.exists();out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(pin(out)))
