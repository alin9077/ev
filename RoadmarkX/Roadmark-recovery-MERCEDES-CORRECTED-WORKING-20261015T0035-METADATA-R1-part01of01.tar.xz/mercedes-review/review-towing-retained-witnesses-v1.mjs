import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import readline from 'node:readline';
const root='/tmp/mercedes-towing-correction/report-comparison-v2';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const small=p=>{const b=fs.readFileSync(p);return {path:p,bytes:b.length,sha256:hash(b),value:p.endsWith(".jsonl")?b.toString("utf8").trimEnd().split("\n").map(x=>JSON.parse(x)):JSON.parse(b)}};
const wp=small(path.join(root,'retained-fact-review-witnesses.json'));
assert.equal(wp.sha256,'2970d1e7852697c4d5fbfde212dd53e50883dc1b6b92ed2ee4122c68172874c1');
const w=wp.value;const mp=small(w.acceptedManifest.path);assert.equal(mp.sha256,w.acceptedManifest.sha256);
const m=mp.value, anchors=m.anchors;const approved=new Map(m.inputPins.map(x=>[`${x.anchor}\0${x.file}`,x]));
const wanted=new Set(w.witnesses.map(x=>x.carId));assert.equal(wanted.size,22);assert.equal(w.witnesses.length,27);
const picked=new Map(),checked=[],retained=[];let baseDescriptor;
for(const r of w.retainedInputPins){
 const ap=approved.get(`${r.anchor}\0${r.file}`);assert(ap);assert.equal(ap.sha256,r.sha256);assert.equal(ap.bytes,r.bytes);
 const p=path.join(anchors[r.anchor],r.file);
 if(r.file.endsWith('/cars.jsonl')){baseDescriptor={...r,path:p};continue;}
 const got=small(p);assert.equal(got.sha256,r.sha256);assert.equal(got.bytes,r.bytes);checked.push({path:p,bytes:got.bytes,sha256:got.sha256});retained.push([r,got.value]);
}
const index=retained.find(([r])=>r.anchor==='staging'&&r.file.endsWith('staged-storage-index.json'))[1];
for(const anchor of ['staging','xpeng','stage']){
 const entry=retained.find(([r])=>r.anchor===anchor&&(r.file.endsWith('selected-complete-after-cars.json')||r.file.endsWith('staged-after.json')));
 for(const car of entry[1])if(wanted.has(car.id)){picked.set(car.id,car);wanted.delete(car.id);}
}
assert(baseDescriptor);const stream=fs.createReadStream(baseDescriptor.path,{highWaterMark:65536});
const h=crypto.createHash('sha256');let bytes=0,rows=0;stream.on('data',chunk=>{h.update(chunk);bytes+=chunk.length});
for await(const line of readline.createInterface({input:stream,crlfDelay:Infinity})){
 assert(line.length);rows++;const car=JSON.parse(line);
 if(wanted.has(car.id)){picked.set(car.id,car);wanted.delete(car.id);}
}
const sha=h.digest('hex');assert.equal(bytes,baseDescriptor.bytes);assert.equal(sha,baseDescriptor.sha256);assert.equal(rows,397);assert.equal(wanted.size,0);
checked.push({path:baseDescriptor.path,bytes,sha256:sha,rows});
const sources=retained.find(([r])=>r.file.endsWith('raw-research-sources.jsonl'))[1];const sm=new Map(sources.map(x=>[x.id,x]));
const edit=small('/tmp/mercedes-towing-correction/v2/after/data/m1-brand-updates/mercedes-benz-towing-basis-2026-10-15.json').value.facts[0];
const verified=[];const cars=new Map(index.cars.carHashes.map(x=>[x.id,x]));
for(const x of w.witnesses){
 const car=picked.get(x.carId),b=Buffer.from(JSON.stringify(car)+'\n');const digest={rows:1,bytes:b.length,sha256:hash(b)};
 assert.deepEqual(digest,x.retainedCompleteCarDigest);assert.deepEqual(cars.get(x.carId),x.acceptedCompleteCarIndexRow);assert.equal(digest.sha256,cars.get(x.carId).afterSha256);assert.equal(digest.bytes,cars.get(x.carId).bytes);
 const f=car.facts[x.key];assert.deepEqual(f,x.priorFact);assert.equal(f.buyerGrade,{Confirmed:'confirmed',Check:'check',Reported:'reported'}[x.countedGrade]);
 const changed=x.carId===edit.variantId&&x.key===edit.before.key;
 if(changed)assert.deepEqual(f,edit.before);
 assert.equal(changed,x.exactSupplementalCorrection);assert.deepEqual(x.expectedPostCorrectionFact,changed?edit.after:f);
 assert.deepEqual(x.sources,x.expectedPostCorrectionFact.sourceIds.map(id=>{assert(sm.has(id));return sm.get(id)}));
 assert.equal(x.expectedPostCorrectionFact.value,f.value);assert.equal(x.expectedPostCorrectionFact.buyerGrade,f.buyerGrade);
 verified.push({carId:x.carId,key:x.key,grade:x.countedGrade,priorCompleteCarDigest:digest,priorFactSha256:hash(Buffer.from(JSON.stringify(f)+'\n')),exactSupplementalCorrection:changed});
}
assert.equal(verified.filter(x=>x.exactSupplementalCorrection).length,1);
const out='/tmp/mercedes-review/towing-correction-v2-retained-witnesses-review.json';
const receipt={schemaVersion:1,status:'accepted_27_exact_prior_fact_witnesses_from_22_retained_cars',authorization:'Root explicitly authorized one streaming pass over the accepted retained cars.jsonl, selecting only the27 witnesses and22 cars; no hydration or recapture.',witnessFile:{path:wp.path,bytes:wp.bytes,sha256:wp.sha256},acceptedManifest:{path:mp.path,bytes:mp.bytes,sha256:mp.sha256},checkedRetainedInputs:checked,verified,checks:{singleBaseStreamPass:true,streamBufferBytes:65536,baseRows:397,selectedCompleteCars:22,exactFactWitnesses:27,allFullCarDigestsMatchAcceptedIndex:true,allPriorFactsAndSourcesExactlyEqualRetainedValues:true,onlyExpectedFactDeltaIsApprovedSupplementalBasisAndOverlayId:true,productionImports:0,newCanonicalCaptures:0},limit:'Exact retained prior-value provenance, not a fresh current catalogue equality result. Existing grading-validator behavior is covered by the accepted fixture suite and unchanged validator code; this reviewer did not execute production functions.'};
fs.writeFileSync(out,JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});const ob=fs.readFileSync(out);console.log(JSON.stringify({path:out,bytes:ob.length,sha256:hash(ob)}));
