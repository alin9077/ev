/** Immutable accepted-baseline and Subaru staging pins, separate from every historical proof. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {roots,readJson,fileHash,verifyPins} from '/tmp/subaru-derived-proof-plan/helpers.mjs';
import {openConsumerPhaseInputs} from '/tmp/subaru-derived-proof-plan/consumer-transition-helpers.mjs';
export const stageRoot='/tmp/subaru-staging-plan',candidateRoot=stageRoot+'/candidate';
export function openSubaruStageInputs(){
 const consumer=openConsumerPhaseInputs(),manifestFile=stageRoot+'/stage-inputs.json',manifestSha256=fileHash(manifestFile),manifest=readJson(manifestFile);
 assert.equal(manifest.schemaVersion,1);assert.equal(manifest.mode,'derived-only-subaru-staging');assert.equal(manifest.asOf,'2026-10-15');
 assert.equal(manifest.registeredPacketCount,17);assert.equal(manifest.candidateRegistered,false);assert.equal(manifest.candidateId,'m1-subaru-2026-10-15');
 for(const key of ['freshLoaderValidation','currentFullTypecheckVerified','registryEditsAuthorized'])assert.equal(manifest[key],false);
 const pins=new Map(manifest.executionInputs.map(row=>[row.path,row]));assert.equal(pins.size,manifest.executionInputs.length);
 for(const name of ['stage_inputs.py','build-packet-derived-v2.py','stage-proof-helpers.mjs','compose-subaru-research.mjs','composition-17-to-18.md','capture-canonical-subaru.mjs','stage-core-subaru.mjs','staged-values.mjs','stage-selected-consumers-subaru.mjs','stage-negative-guards-subaru.mjs','stage-full-feature-stream-subaru.mjs','stage-complete-report-subaru.mjs','prepare-stage-inputs.py','run-stage-measured.py'])assert(pins.has(stageRoot+'/'+name),'Missing mandatory stage harness pin: '+name);
 const artifacts={};
 for(const key of ['baselineAcceptance','baselineIndex','consumerPhaseManifest','sourceTransitionReview','compositionReview','harnessReview']){
  const row=manifest[key];assert(row);assert.equal(pins.get(row.path)?.sha256,row.sha256);assert.equal(fileHash(row.path),row.sha256);artifacts[key]=readJson(row.path);
 }
 const {baselineAcceptance,baselineIndex,compositionReview,harnessReview}=artifacts;
 assert.equal(harnessReview.status,'approved_for_pinned_subaru_staging');const reviewedScripts=new Map(harnessReview.scriptPins.map(row=>[row.file,row.sha256]));assert.equal(reviewedScripts.size,harnessReview.scriptPins.length);for(const row of harnessReview.scriptPins){assert.equal(fileHash(stageRoot+'/'+row.file),row.sha256);assert.equal(pins.get(stageRoot+'/'+row.file)?.sha256,row.sha256)}
 for(const name of ['stage_inputs.py','build-packet-derived-v2.py','stage-proof-helpers.mjs','compose-subaru-research.mjs','composition-17-to-18.md','capture-canonical-subaru.mjs','stage-core-subaru.mjs','staged-values.mjs','stage-selected-consumers-subaru.mjs','stage-negative-guards-subaru.mjs','stage-full-feature-stream-subaru.mjs','stage-complete-report-subaru.mjs','prepare-stage-inputs.py','run-stage-measured.py'])assert(reviewedScripts.has(name),'Every phase harness requires independent static review: '+name);
 assert.equal(baselineAcceptance.status,'accepted_derived_only_baseline_for_subaru_staging');assert.equal(baselineAcceptance.acceptedIndexSha256,manifest.baselineIndex.sha256);assert.equal(baselineAcceptance.asOf,'2026-10-15');
 assert.equal(baselineIndex.schemaVersion,2);assert.equal(baselineIndex.acceptance,'accepted_derived_only');assert.equal(baselineIndex.asOf,'2026-10-15');assert.equal(baselineIndex.cars.rows,397);assert.equal(Object.keys(baselineIndex.research).length,14);assert.equal(baselineIndex.originalSubaruCars,9);assert.equal(baselineIndex.proposedSubaruCars,11);
 assert.equal(baselineIndex.consumerPhaseManifestSha256,manifest.consumerPhaseManifest.sha256);assert.equal(baselineIndex.reviewedSourceTransitionSha256,manifest.sourceTransitionReview.sha256);assert.equal(consumer.manifestSha256,manifest.consumerPhaseManifest.sha256);
 for(const key of ['freshV2Capture','finalLoaderEquivalence','currentFullTypecheckVerified','subaruRegistrationAuthorized'])assert.equal(baselineIndex[key],false);
 assert.equal(compositionReview.status,'approved_for_hypothetical_subaru_staging');assert.equal(compositionReview.scriptSha256,fileHash(stageRoot+'/compose-subaru-research.mjs'));assert.equal(compositionReview.proofSha256,fileHash(stageRoot+'/composition-17-to-18.md'));
 const verify=()=>{assert.equal(fileHash(manifestFile),manifestSha256,'Stage pin manifest unchanged');consumer.verify();verifyPins(manifest);for(const row of manifest.executionInputs)if(row.bytes!==undefined)assert.equal(fs.statSync(row.path).size,row.bytes)};
 verify();return {manifest,manifestSha256,consumer,baselineAcceptance,index:baselineIndex,verify};
}
export function candidateFile(name){assert.equal(path.basename(name),name,'Candidate output must be a single filename');return path.join(candidateRoot,name)}
export function writeCandidate(name,value){const file=candidateFile(name);assert(!fs.existsSync(file),'Never overwrite a canonical or staged artifact: '+name);fs.mkdirSync(candidateRoot,{recursive:true});fs.writeFileSync(file,JSON.stringify(value,null,2)+'\n',{flag:'wx'});return {file,sha256:fileHash(file),bytes:fs.statSync(file).size}}
