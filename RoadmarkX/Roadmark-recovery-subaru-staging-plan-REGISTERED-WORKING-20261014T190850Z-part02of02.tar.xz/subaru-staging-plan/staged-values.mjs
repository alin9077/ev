/** Full staged values reconstructed from explicitly anchored immutable storage only. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {roots,readJson,fileHash,readRows,digestRows} from '/tmp/subaru-derived-proof-plan/helpers.mjs';
import {openSubaruStageInputs,stageRoot,candidateFile} from './stage-proof-helpers.mjs';
export function stagedLocate(row){const anchors={...roots,stage:stageRoot};assert(Object.hasOwn(anchors,row.anchor));const file=path.resolve(anchors[row.anchor],row.file);assert(file.startsWith(anchors[row.anchor]+'/'));return file}
export function openStagedCore(){
 const proof=openSubaruStageInputs(),receiptFile=candidateFile('staged-core-receipt.json'),receiptHash=fileHash(receiptFile),receipt=readJson(receiptFile);
 assert.equal(receipt.status,'passed_pending_actual_pack_and_complete_report_phases');assert.equal(receipt.stageInputManifestSha256,proof.manifestSha256);assert.equal(receipt.beforeCars,397);assert.equal(receipt.afterCars,399);assert.equal(receipt.subaruCars,11);assert.equal(receipt.newSubaruCars,2);
 assert(receipt.allCompleteInputCarsAnd14ResearchFieldsUnchanged&&receipt.allNonSubaruAndLowerTierCarsExactlyUnchanged&&receipt.allCanonicalSelectedCarsExactlyEqual&&receipt.rawSinglePacketOutputPreserved);
 const indexFile=receipt.storageIndex.file;assert.equal(indexFile,candidateFile('staged-storage-index.json'));assert.equal(fileHash(indexFile),receipt.storageIndex.sha256);const index=readJson(indexFile);
 assert.equal(index.stageInputManifestSha256,proof.manifestSha256);assert.equal(index.asOf,'2026-10-15');assert.equal(index.cars.rows,399);assert.equal(index.cars.carHashes.length,399);assert.equal(new Set(index.cars.carHashes.map(row=>row.id)).size,399);assert.equal(Object.keys(index.research).length,14);
 const packetFile=candidateFile('subaru-2026-10-15.json');assert.equal(fileHash(packetFile),receipt.packetSha256);assert.equal(index.packetSha256,receipt.packetSha256);
 const selectedFile=stagedLocate(index.cars.replacements);assert.equal(selectedFile,receipt.selectedCars.file);assert.equal(fileHash(selectedFile),receipt.selectedCars.sha256);assert.equal(index.cars.replacements.sha256,receipt.selectedCars.sha256);
 const verify=()=>{assert.equal(fileHash(receiptFile),receiptHash);assert.equal(fileHash(indexFile),receipt.storageIndex.sha256);assert.equal(fileHash(packetFile),receipt.packetSha256);for(const row of receipt.generatedPins)assert.equal(fileHash(row.file),row.sha256);for(const row of Object.values(index.research)){const file=stagedLocate(row);assert.equal(fileHash(file),row.sha256);assert.equal(fs.statSync(file).size,row.bytes)}assert.equal(fileHash(selectedFile),receipt.selectedCars.sha256);proof.verify()};
 verify();return {proof,receipt,receiptHash,index,packet:readJson(packetFile),selected:readJson(selectedFile),verify};
}
export async function readStagedResearch(index){const data={};for(const[key,row]of Object.entries(index.research)){const file=stagedLocate(row);assert.equal(fileHash(file),row.sha256);assert.equal(fs.statSync(file).size,row.bytes);assert(!row.format||row.format==='jsonl');const list=await readRows(file);assert.equal(list.length,row.rows);assert(row.array||list.length===1);data[key]=row.array?list:list[0]}return data}
export function assertStagedResearchUnchanged(data,index){assert.deepEqual(Object.keys(data).sort(),Object.keys(index.research).sort());for(const[key,value]of Object.entries(data)){const actual=digestRows(Array.isArray(value)?value:[value]),expected=index.research[key];assert.deepEqual(actual,{rows:expected.rows,bytes:expected.bytes,sha256:expected.sha256},'Every complete staged Research field unchanged: '+key);global.gc?.()}}
