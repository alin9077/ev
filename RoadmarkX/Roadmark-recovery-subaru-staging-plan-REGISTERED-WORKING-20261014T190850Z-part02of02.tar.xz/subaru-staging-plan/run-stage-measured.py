"""Measured staging commands; logs live outside every frozen proof/input scan root."""
import os,sys,pathlib,json,time,datetime,subprocess,re
root=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104-qa/subaru-derived-staging-checks')
name=sys.argv[1];command=sys.argv[2:]
assert re.fullmatch(r'[a-z0-9][a-z0-9_-]*',name) and command
assert pathlib.Path.cwd()==pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104')
root.mkdir(exist_ok=True);out=root/name;out.mkdir(exist_ok=False)
started=time.time();started_iso=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/'stdout.log').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
 process=subprocess.Popen(command,stdout=stdout,stderr=stderr)
 _,status,usage=os.wait4(process.pid,0);code=os.waitstatus_to_exitcode(status);process.returncode=code
result={'command':command,'returncode':code,'signal':-code if code<0 else None,'startedAt':started_iso,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsedSeconds':time.time()-started,'maxRssKiB':usage.ru_maxrss,'userSeconds':usage.ru_utime,'systemSeconds':usage.ru_stime,'inheritedNodeOptions':os.environ.get('NODE_OPTIONS'),'mode':'Derived-only Subaru staging; no fresh full-loader validation or registry change','outputRoot':str(root)}
with (out/'terminal.json').open('x') as receipt:json.dump(result,receipt,indent=2);receipt.write('\n')
print(json.dumps(result,indent=2));sys.exit(0 if code==0 else 1)
