/**
 * PREPARED ONLY: execute under the root's separately measured, serialized slot.
 * Example (from roots.repo): node --expose-gc --import tsx /tmp/subaru-staging-plan/stage-negative-guards-subaru.mjs
 *
 * Required immutable inputs:
 * - openStagedCore()'s accepted baseline, complete staged 14-field Research index,
 *   final unregistered candidate, complete selected 11 cars, and generated pins;
 * - the original pinned nine Subaru cars used by the canonical capture;
 * - the successful selected-consumer receipt and its 759-row feature output;
 * - the exact production registry of 17 packets, with the candidate appended
 *   only inside compiledSource's module override, never in a registry file.
 *
 * No data.ts import, normal loader, catalogue construction, 397-car retention,
 * canonical recapture or expectation regeneration occurs. The one expressly
 * labelled synthetic foreign-source test changes an isolated source clone;
 * that clone never enters canonical evidence or a registered packet.
 * All mutations are isolated copies. An unexpected acceptance/error aborts.
 * A missing real-candidate category is explicitly reported as INCOMPLETE, never
 * silently skipped, supplied by a generic fixture, or counted as a passing test.
 */
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {roots,readJson,fileHash,digestRows} from '/tmp/subaru-derived-proof-plan/helpers.mjs';
import {candidateFile,writeCandidate} from './stage-proof-helpers.mjs';
import {openStagedCore,readStagedResearch,assertStagedResearchUnchanged} from './staged-values.mjs';

assert.equal(process.cwd(),roots.repo);
assert.equal(typeof global.gc,'function','The measured invocation must expose GC');
const stage=openStagedCore(),{packet,index,selected}=stage;
assert.equal(stage.receipt.all14CanonicalResearchFieldsExactlyEqual,true);
assert.equal(packet.id,'m1-subaru-2026-10-15');
assert.equal(packet.brand,'Subaru');
assert.equal(packet.facts.length,646);
assert.equal(packet.brandTerms.length,3);
assert.equal(packet.features.length,293);
assert.equal(packet.variants.length,2);
assert.equal(selected.length,11);
assert.equal(new Set(selected.map(car=>car.id)).size,11);
const newIds=new Set(packet.variants.map(variant=>variant.id));
assert.equal(newIds.size,2);

const selectedReceiptFile=candidateFile('staged-selected-consumer-receipt.json');
const selectedReceiptSha256=fileHash(selectedReceiptFile),selectedReceipt=readJson(selectedReceiptFile);
assert.equal(selectedReceipt.status,'passed_pending_negative_guards_and_complete_reports');
assert.equal(selectedReceipt.packetSha256,stage.receipt.packetSha256);
assert.equal(selectedReceipt.coreReceiptSha256,stage.receiptHash);
assert.equal(selectedReceipt.stageInputManifestSha256,stage.proof.manifestSha256);
for(const key of ['actualPackPipelineMatches','actualPortableExact','fullCanonicalFeatureFixtureEqual','fullResearchAndSelectedCarsUnchanged'])assert.equal(selectedReceipt[key],true);
assert.equal(selectedReceipt.features.file,candidateFile('features-after.json'));
assert.equal(fileHash(selectedReceipt.features.file),selectedReceipt.features.sha256);
assert.equal(fs.statSync(selectedReceipt.features.file).size,selectedReceipt.features.bytes);
const expectedFeatures=readJson(selectedReceipt.features.file);
assert.equal(expectedFeatures.length,11*69);

const require=createRequire(roots.repo+'/package.json');
const scriptFile='/tmp/subaru-staging-plan/stage-negative-guards-subaru.mjs',scriptSha256=fileHash(scriptFile);
const {applyBrandUpdates,applyBrandFeatureUpdates,applyBrandTermFeatures}=require('./src/lib/brand-updates.ts');
const {sameReviewedState}=require('./src/lib/correction-guards.ts');
const {hasEarnedBuyerGrade}=require('./src/lib/evidence-grading.ts');
const {isRetainedAUMakerSource}=require('./src/lib/evidence-regrade-policy.ts');
const {priceCandidateRejection}=require('./src/lib/price-ladder.ts');
const {createEvidenceConsumers}=require('./src/lib/evidence-consumers.ts');
const {brandUpdatePackets}=require('./src/lib/brand-update-registry.ts');
const {compiledSource}=require('./tests/helpers/compiled-source.ts');
assert(!Object.hasOwn(require.cache,roots.repo+'/src/lib/data.ts'),'The normal data loader must not be imported');
assert.equal(brandUpdatePackets.length,17);
assert.equal(new Set(brandUpdatePackets.map(row=>row.id)).size,17);
assert(!brandUpdatePackets.some(row=>row.id===packet.id||row.brand==='Subaru'));
for(let i=1;i<brandUpdatePackets.length;i++)assert(brandUpdatePackets[i].reviewedAt>=brandUpdatePackets[i-1].reviewedAt);
assert(packet.reviewedAt>=brandUpdatePackets.at(-1).reviewedAt);
const registeredIds=brandUpdatePackets.map(row=>row.id);
const registeredDigests=brandUpdatePackets.map(row=>digestRows([row]));

const data=await readStagedResearch(index);
assert.equal(Object.keys(data).length,14);
assert.deepEqual(data.metadata.brand_update_packet_ids,[...registeredIds,packet.id]);
assertStagedResearchUnchanged(data,index);
// The full original nine are independently pinned by the same stage contract
// as capture-canonical-subaru.mjs. No car is reconstructed from after-values.
const beforeFile=roots.research+'/capture-attempt640-original/subaru-live-before.json';
const beforeFileSha256=fileHash(beforeFile),before=readJson(beforeFile);
assert.equal(before.length,9);
assert.equal(new Set(before.map(car=>car.id)).size,9);
for(const car of before){
  const expected=stage.proof.consumer.coreReceipt.carHashes.find(row=>row.id===car.id);
  const measured=digestRows([car]);
  assert(expected,'Pinned baseline car missing: '+car.id);
  assert.equal(measured.sha256,expected.afterSha256);
  assert.equal(measured.bytes,expected.bytes);
  assert.equal(car.brand,'Subaru');
  assert(!newIds.has(car.id));
}
assert.deepEqual(selected.map(car=>car.id),[...before.map(car=>car.id),...packet.variants.map(row=>row.id)]);
const packetDigest=digestRows([packet]),selectedDigests=selected.map(car=>digestRows([car]));
const beforeDigests=before.map(car=>digestRows([car])),expectedFeaturesDigest=digestRows(expectedFeatures);
for(let i=0;i<selected.length;i++){
  const expected=index.cars.carHashes.find(row=>row.id===selected[i].id);
  assert(expected);assert.equal(selectedDigests[i].sha256,expected.afterSha256);assert.equal(selectedDigests[i].bytes,expected.bytes);
}

function freeze(value){
  if(value&&typeof value==='object'&&!Object.isFrozen(value)){
    for(const part of Object.values(value))freeze(part);
    Object.freeze(value);
  }
  return value;
}
// Frozen complete original inputs also detect an attempted write which would
// otherwise happen to leave the final digest unchanged.
for(const value of [packet,selected,before,data,expectedFeatures,brandUpdatePackets])freeze(value);
let loaderCalls=0;
const forbidden=()=>{loaderCalls++;throw new Error('SUBARU_NEGATIVE_GUARD_FORBIDDEN_LOADER');};
const defaults={sourceResearch:forbidden,research:forbidden,catalogue:forbidden};
const baseConsumer=createEvidenceConsumers(defaults);
// Only this module binding changes between isolated candidate mutations. The
// production function bodies and every registered predecessor remain intact.
const registryBinding={brandUpdatePackets:Object.freeze([...brandUpdatePackets,packet])};
const stagedConsumer=compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':registryBinding}).createEvidenceConsumers(defaults);
function withCandidate(candidate,fn){
  assert.equal(candidate.id,packet.id);
  const previous=registryBinding.brandUpdatePackets;
  registryBinding.brandUpdatePackets=Object.freeze([...brandUpdatePackets,candidate]);
  assert.deepEqual(registryBinding.brandUpdatePackets.slice(0,17).map(row=>row.id),registeredIds);
  try{return fn();}finally{registryBinding.brandUpdatePackets=previous;}
}
function pack(carId,cars=selected,research=data,candidate=packet){
  assert.equal(cars.length,11,'Every consumer snapshot supplies all selected cars');
  assert.deepEqual(Object.keys(research).sort(),Object.keys(data).sort(),'Every consumer receives all 14 Research fields');
  return withCandidate(candidate,()=>stagedConsumer.pack(carId,{data:research,cars}));
}
const caseResults=[],unsupportedCategories=[];
function reject(name,category,expectedMessage,inputs,fn){
  assert(!caseResults.some(row=>row.name===name));
  freeze(inputs);
  const inputDigest=digestRows([inputs]);
  let caught;
  try{fn();}catch(error){caught=error;}
  assert(caught instanceof Error,name+': production accepted the mutation');
  assert.equal(caught.message,expectedMessage,name+': rejected by an unintended guard');
  assert.deepEqual(digestRows([inputs]),inputDigest,name+': complete isolated mutation inputs changed');
  assert.equal(loaderCalls,0,name+': fallback loader invoked');
  caseResults.push({name,category,expectedMessage,actualMessage:caught.message,inputDigest,isolatedInputsUnchanged:true});
  console.log('Rejected isolated Subaru mutation:',name);
  global.gc();
}
function mutateCandidate(edit){const changed=structuredClone(packet);edit(changed);return changed;}
function changeCar(cars,id,edit){
  assert.equal(cars.filter(car=>car.id===id).length,1);
  return cars.map(car=>{if(car.id!==id)return car;const changed=structuredClone(car);edit(changed);return changed;});
}
function changedSources(id,edit){
  assert.equal(data.sources.filter(source=>source.id===id).length,1);
  return data.sources.map(source=>{if(source.id!==id)return source;const changed=structuredClone(source);edit(changed);return changed;});
}
function coreReject(name,category,expectedMessage,candidate=packet,cars=before,research=data){
  reject(name,category,expectedMessage,{candidate,cars,sources:research.sources},()=>applyBrandUpdates(cars,research,[candidate]));
}
function corePacketReject(name,category,expectedMessage,edit){
  coreReject(name,category,expectedMessage,mutateCandidate(edit));
}
function consumerPacketReject(name,category,expectedMessage,carId,edit){
  const candidate=mutateCandidate(edit);
  reject(name,category,expectedMessage,{candidate},()=>pack(carId,selected,data,candidate));
}
function missingCategory(category,detail){
  unsupportedCategories.push({category,detail});
  console.log('UNSUPPORTED REAL-CANDIDATE CATEGORY:',category,detail);
}

// Positive controls run before mutation tests: otherwise an unrelated baseline
// failure could be mistaken for a successful negative guard.
{
  const actual=applyBrandUpdates(before,data,[packet]);
  assert.equal(actual.length,11);
  assert.deepEqual(actual.map(car=>digestRows([car])),selectedDigests,'Unmodified actual core replay equals every complete staged car');
}
const baseFeatures=new Map();
for(const car of selected){
  const initial=baseConsumer.effectiveFeatures(car,data);
  assert.equal(initial.length,69);assert.equal(new Set(initial.map(row=>row.criterion)).size,69);
  freeze(initial);baseFeatures.set(car.id,initial);
  for(const row of packet.features.filter(row=>row.variantId===car.id)){
    const matches=initial.filter(feature=>feature.criterion===row.criterion);
    assert.equal(matches.length,1);assert(sameReviewedState(matches[0],row.before),'Original complete feature before-value differs: '+car.id+'/'+row.criterion);
  }
  const view=pack(car.id);
  assert.equal(view.features.length,69);
  assert.deepEqual(digestRows(view.features),digestRows(expectedFeatures.filter(row=>row.variant_id===car.id)),'Unmodified actual consumer differs from verified selected feature output');
  assert.deepEqual(view.features,applyBrandTermFeatures(car,applyBrandFeatureUpdates(car,initial,data,[packet])));
  global.gc();
}
assert.equal(loaderCalls,0);
assert.deepEqual(digestRows([packet]),packetDigest,'Positive actual functions changed the complete packet');

// Complete source-record equality includes capture provenance, not just URL/ID.
const source=packet.sources[0];assert(source);
for(const field of ['supports','capture_sha256']){
  const target=field==='supports'?source:packet.sources.find(row=>typeof row.capture_sha256==='string');
  assert(target,'Actual retained source capture hash is required');
  const sources=changedSources(target.id,row=>{row[field]=field==='supports'?row[field]+' [isolated source drift]':(row[field][0]==='0'?'1':'0')+row[field].slice(1);});
  coreReject('complete_source_record_drift_'+field,'source_record_drift','Brand update: source snapshot changed: '+target.id,packet,before,{...data,sources});
}
{
  const sources=data.sources.filter(row=>row.id!==source.id);
  coreReject('missing_packet_source','missing_source','Brand update: research is missing packet sources: '+packet.id,packet,before,{...data,sources});
}
{
  const sources=[...data.sources,structuredClone(source)];
  coreReject('duplicate_packet_source','duplicate_source','Brand update: source snapshot changed: '+source.id,packet,before,{...data,sources});
}

const firstFeature=packet.features[0];assert(firstFeature);
const firstCar=selected.find(car=>car.id===firstFeature.variantId);assert(firstCar);
const beforeFactIndex=packet.facts.findIndex(row=>row.before!==null&&before.some(car=>car.id===row.variantId));
assert(beforeFactIndex>=0);
{
  const row=packet.facts[beforeFactIndex];
  const cars=changeCar(before,row.variantId,car=>{car.facts[row.after.key].qualifications.push('Isolated before-value drift');});
  coreReject('full_fact_before_value_drift','fact_before_drift','Brand update: fact before snapshot changed: '+row.variantId+'/'+row.after.key,packet,cars);
}
{
  const row=packet.versionGuards[0];assert(row);
  const cars=changeCar(before,row.variantId,car=>{car.trim+=' [isolated identity drift]';});
  coreReject('full_version_identity_drift','identity_drift','Brand update: reviewed version changed: '+row.variantId,packet,cars);
}

// Preserve all genuine source records, including sourceOriginMarket, while
// attempting to turn an actually Reported fact/feature into Confirmed.
const sourceById=new Map(packet.sources.map(row=>[row.id,row]));
const isForeign=source=>source&&typeof source.sourceOriginMarket==='string'&&!['AU','Australia','AU/NZ'].includes(source.sourceOriginMarket);
const candidateForeignSources=packet.sources.filter(isForeign);
const candidateForeignSourceCount=candidateForeignSources.length;
for(const retained of packet.sources){
  if(/overseas|foreign|non_au/i.test(retained.source_type))assert(isForeign(retained),'A foreign-labelled retained source needs explicit foreign origin metadata: '+retained.id);
  if(!isForeign(retained))continue;
  assert.equal(isRetainedAUMakerSource(retained),false,'A retained foreign origin must never be classified as an AU maker: '+retained.id);
  assert(!packet.facts.some(row=>['confirmed','check'].includes(row.after.buyerGrade)&&row.after.sourceIds.includes(retained.id)),'Foreign origin may not support Confirmed/Check candidate facts');
  assert(!packet.features.some(row=>['confirmed','check'].includes(row.after.buyerGrade)&&row.after.source_ids.includes(retained.id)),'Foreign origin may not support Confirmed/Check candidate features');
}
const secondarySourceCoverage=[];
function promotionCase(label,sourcePredicate,{requireFact=true,requireFeature=true}={}){
  const factIndex=packet.facts.findIndex(row=>row.after.buyerGrade==='reported'&&row.after.sourceIds.some(id=>sourcePredicate(sourceById.get(id))));
  if(factIndex<0){if(requireFact)missingCategory(label+'_confirmed_fact_promotion','No actually Reported candidate fact cites this retained source; no source was invented or relabelled.');}
  else{
    const original=packet.facts[factIndex].after;
    assert.equal(hasEarnedBuyerGrade(original,data.sources,packet.reviewedAt),true);
    const candidate=mutateCandidate(value=>{
      const fact=value.facts[factIndex].after;
      fact.buyerGrade='confirmed';fact.status='standard';fact.gradeReview.evidenceScope='exact_au_version';
    });
    assert.deepEqual(candidate.sources,packet.sources,'Promotion may not rewrite a source or sourceOriginMarket');
    assert.equal(hasEarnedBuyerGrade(candidate.facts[factIndex].after,data.sources,packet.reviewedAt),false,'Actual source-authority guard must reject promotion independently');
    coreReject(label+'_confirmed_fact_promotion','secondary_or_foreign_confirmed_promotion','Brand update: invalid fact or unearned grade: '+original.key,candidate);
  }
  const featureIndex=packet.features.findIndex(row=>row.after.buyerGrade==='reported'&&row.after.source_ids.some(id=>sourcePredicate(sourceById.get(id))));
  if(featureIndex<0){if(requireFeature)missingCategory(label+'_confirmed_feature_promotion','No actually Reported candidate feature cites this retained source.');}
  else{
    const row=packet.features[featureIndex];
    assert.equal(hasEarnedBuyerGrade(row.after,data.sources,packet.reviewedAt),true);
    consumerPacketReject(label+'_confirmed_feature_promotion','secondary_or_foreign_confirmed_promotion','Brand update: invalid feature or unearned grade: '+row.variantId+'/'+row.criterion,row.variantId,value=>{
      const after=value.features[featureIndex].after;
      after.buyerGrade='confirmed';after.status='standard';after.gradeReview.evidenceScope='exact_au_version';
      assert.deepEqual(value.sources,packet.sources);
      assert.equal(hasEarnedBuyerGrade(after,data.sources,packet.reviewedAt),false);
    });
  }
  return{factIndex,featureIndex};
}
const secondarySources=packet.sources.filter(source=>!isForeign(source)&&!isRetainedAUMakerSource(source)&&(
  packet.facts.some(row=>row.after.buyerGrade==='reported'&&row.after.sourceIds.includes(source.id))||
  packet.features.some(row=>row.after.buyerGrade==='reported'&&row.after.source_ids.includes(source.id))
));
assert(secondarySources.length,'At least one genuine secondary candidate source is required');
for(const source of secondarySources){
  const result=promotionCase('secondary_source_'+source.id,row=>row?.id===source.id,{requireFact:false,requireFeature:false});
  assert(result.factIndex>=0||result.featureIndex>=0);
  secondarySourceCoverage.push({sourceId:source.id,sourceDigest:digestRows([source]),factIndex:result.factIndex,featureIndex:result.featureIndex,sourceMetadataPreserved:true});
}
const foreignPromotion=candidateForeignSourceCount?'actual retained foreign-source promotions tested':'not applicable: no foreign source in candidate';
for(const source of candidateForeignSources)promotionCase('foreign_source_origin_retained_'+source.id,row=>row?.id===source.id,{requireFact:false,requireFeature:false});

// Deliberately synthetic negative input, requested separately by the reviewer.
// Keep the source's AU applicability and valid record shape; change its source
// authority and retained origin only. Update both isolated snapshots so source
// drift cannot mask the intended unearned-grade rejection.
let syntheticForeignPromotionRejected=false;
{
  const targetIndex=packet.facts.findIndex(row=>row.after.buyerGrade==='reported'&&row.after.sourceIds.some(id=>secondarySources.some(source=>source.id===id)));
  assert(targetIndex>=0);
  const target=packet.facts[targetIndex];
  const sourceId=target.after.sourceIds.find(id=>secondarySources.some(source=>source.id===id));
  const candidate=mutateCandidate(value=>{
    const source=value.sources.find(row=>row.id===sourceId);
    source.source_type='manufacturer_overseas_reported';source.sourceOriginMarket='DE';
    const fact=value.facts[targetIndex].after;
    fact.buyerGrade='confirmed';fact.status='standard';fact.gradeReview.evidenceScope='exact_au_version';
  });
  const syntheticSource=candidate.sources.find(row=>row.id===sourceId);
  const sources=changedSources(sourceId,source=>{source.source_type='manufacturer_overseas_reported';source.sourceOriginMarket='DE';});
  assert.deepEqual(sources.find(row=>row.id===sourceId),syntheticSource);
  assert.equal(syntheticSource.market,sourceById.get(sourceId).market);
  assert.equal(isRetainedAUMakerSource(syntheticSource),false);
  assert.equal(hasEarnedBuyerGrade(candidate.facts[targetIndex].after,sources,packet.reviewedAt),false);
  coreReject('synthetic_foreign_DE_confirmed_promotion','synthetic_foreign_confirmed_promotion','Brand update: invalid fact or unearned grade: '+target.after.key,candidate,before,{...data,sources});
  syntheticForeignPromotionRejected=true;
}

// Each dedicated price guard changes exactly one retained provenance label;
// the amount, rung, grade, comparison basis, sources and other label stay exact.
const priceIndex=packet.facts.findIndex(row=>row.after.key==='price_aud'&&typeof row.after.value==='number'&&['Before on-road costs','Driveaway'].includes(row.after.comparisonBasis)&&row.after.priceEvidence);
assert(priceIndex>=0,'A real price candidate is required');
function priceCandidate(fact){return{variantId:'packet',value:fact.value,sourceIds:fact.sourceIds,date:fact.date,...fact.priceEvidence,comparisonBasis:fact.comparisonBasis,qualifications:fact.qualifications,validUntil:fact.validUntil};}
const originalPrice=packet.facts[priceIndex].after;
assert.equal(priceCandidateRejection(priceCandidate(originalPrice),'packet',data.sources,packet.reviewedAt),null);
for(const field of ['basisTag','originalBasis']){
  const candidate=mutateCandidate(value=>{value.facts[priceIndex].after.priceEvidence[field]=originalPrice.comparisonBasis==='Before on-road costs'?'Driveaway':'Before on-road costs';});
  const expected='Price comparison basis contradicts retained price provenance ('+field+')';
  assert.equal(hasEarnedBuyerGrade(candidate.facts[priceIndex].after,data.sources,packet.reviewedAt),true,'Price contradiction must reach the dedicated price guard');
  assert.equal(priceCandidateRejection(priceCandidate(candidate.facts[priceIndex].after),'packet',data.sources,packet.reviewedAt),expected);
  coreReject('dedicated_price_'+field+'_contradiction','price_basis_contradiction','Brand update: '+expected,candidate);
}

consumerPacketReject('candidate_complete_before_feature_drift','feature_before_drift','Brand update: feature before snapshot changed: '+firstFeature.variantId+'/'+firstFeature.criterion,firstFeature.variantId,value=>{value.features[0].before.conditions+=' [isolated before-feature drift]';});
{
  const features=structuredClone(baseFeatures.get(firstCar.id));
  features.find(row=>row.criterion===firstFeature.criterion).conditions+=' [isolated effective-feature drift]';
  reject('actual_effective_before_feature_drift','feature_before_drift','Brand update: feature before snapshot changed: '+firstCar.id+'/'+firstFeature.criterion,{features},()=>applyBrandFeatureUpdates(firstCar,features,data,[packet]));
}
const featureDependency=firstFeature.dependencies[0];assert(featureDependency);
consumerPacketReject('feature_expected_fact_dependency_drift','feature_dependency_drift','Brand update: feature dependency changed: '+firstCar.id+'/'+firstFeature.criterion+'/'+featureDependency.key,firstCar.id,value=>{value.features[0].dependencies[0].expected.qualifications.push('Isolated expected-fact drift');});
for(const mode of ['missing','changed']){
  const cars=changeCar(selected,firstCar.id,car=>{if(mode==='missing')delete car.facts[featureDependency.key];else car.facts[featureDependency.key].qualifications.push('Isolated actual-fact drift');});
  reject('feature_actual_fact_'+mode,'feature_dependency_drift','Brand update: feature dependency changed: '+firstCar.id+'/'+firstFeature.criterion+'/'+featureDependency.key,{cars},()=>pack(firstCar.id,cars));
}
for(const mode of ['missing','empty','duplicate']){
  consumerPacketReject('feature_dependency_list_'+mode,'feature_dependency_schema','Brand update: invalid feature dependencies: '+firstCar.id+'/'+firstFeature.criterion,firstCar.id,value=>{
    const row=value.features[0];
    if(mode==='missing')delete row.dependencies;
    else if(mode==='empty')row.dependencies=[];
    else row.dependencies.push(structuredClone(row.dependencies[0]));
  });
}

// Numeric V2L output and voltage must remain exact live dependencies, rather
// than merely retaining a feature's prose or a broad V2L source citation.
const numericV2LClaims=[];
for(const row of packet.features.filter(row=>row.criterion==='v2l')){
  const text=row.after.value+' '+row.after.conditions,requiredKeys=[];
  if(/\d[\d,.]*\s*(?:kW|W)\b/i.test(text))requiredKeys.push('v2l_output_kw');
  if(/\d[\d,.]*\s*V\b/i.test(text))requiredKeys.push('v2l_voltage_v');
  for(const key of requiredKeys){
    const dependencies=row.dependencies.filter(dep=>dep.key===key);
    assert.equal(dependencies.length,1,'Every numeric V2L claim must explicitly name its exact numeric fact: '+row.variantId+'/'+key);
    assert.equal(typeof dependencies[0].expected.value,'number');
    assert(sameReviewedState(dependencies[0].expected,selected.find(car=>car.id===row.variantId).facts[key]),'Numeric V2L evidence must equal the complete live fact');
  }
  if(requiredKeys.length)numericV2LClaims.push({variantId:row.variantId,criterion:row.criterion,requiredKeys});
}
assert(numericV2LClaims.length,'Real candidate numeric V2L claims are required');
const numericV2L=packet.features.flatMap((row,rowIndex)=>row.dependencies.filter(dep=>/^v2l_.*(?:kw|voltage_v)$/.test(dep.key)&&typeof dep.expected.value==='number').map(dep=>({row,rowIndex,dep})));
if(!numericV2L.length)missingCategory('v2l_numeric_dependency','No candidate feature has an actual numeric V2L output/voltage dependency.');
for(const key of [...new Set(numericV2L.map(({dep})=>dep.key))]){
  const {row,dep}=numericV2L.find(item=>item.dep.key===key);
  // Find the first real feature using this key: its exact rejection must win.
  const earliest=packet.features.find(feature=>feature.variantId===row.variantId&&feature.dependencies.some(dependency=>dependency.key===key));
  assert(earliest);assert.equal(typeof dep.expected.value,'number');
  for(const mode of ['missing','changed']){
    const cars=changeCar(selected,row.variantId,car=>{assert.equal(car.facts[key].value,dep.expected.value);if(mode==='missing')delete car.facts[key];else car.facts[key].value+=0.125;});
    reject('v2l_numeric_'+key+'_'+mode,'v2l_numeric_dependency','Brand update: feature dependency changed: '+row.variantId+'/'+earliest.criterion+'/'+key,{cars},()=>pack(row.variantId,cars));
  }
}

const summary=packet.summaries[0];assert(summary?.strength?.dependencies?.length);
const summaryDependency=summary.strength.dependencies[0];
corePacketReject('summary_expected_fact_dependency_drift','summary_dependency_drift','Brand update: summary dependency changed: '+summary.variantId+'/'+summaryDependency.key,value=>{value.summaries[0].strength.dependencies[0].expected.qualifications.push('Isolated summary dependency drift');});
for(const mode of ['missing','empty','duplicate']){
  corePacketReject('summary_dependency_list_'+mode,'summary_dependency_schema','Brand update: invalid summary clause for '+summary.variantId,value=>{
    const clause=value.summaries[0].strength;
    if(mode==='missing')delete clause.dependencies;
    else if(mode==='empty')clause.dependencies=[];
    else clause.dependencies.push(structuredClone(clause.dependencies[0]));
  });
}

consumerPacketReject('duplicate_candidate_feature_target','duplicate_feature_target','Brand update: duplicate feature target in '+packet.id,firstCar.id,value=>{value.features.push(structuredClone(value.features[0]));});
// New-version rows cannot be masked by a historical approved correction.
const newFeature=packet.features.find(row=>newIds.has(row.variantId));assert(newFeature);
const newCar=selected.find(car=>car.id===newFeature.variantId);assert(newCar);
const rawMatches=data.feature_evidence.filter(row=>row.variant_id===newCar.id&&row.criterion===newFeature.criterion);assert.equal(rawMatches.length,1);
for(const mode of ['missing','duplicate']){
  const rows=mode==='missing'?data.feature_evidence.filter(row=>row!==rawMatches[0]):[...data.feature_evidence,structuredClone(rawMatches[0])];
  const research={...data,feature_evidence:rows};freeze(research);
  reject('canonical_feature_data_'+mode,'canonical_feature_cardinality','Brand update: invalid or canonical feature target: '+newCar.id+'/'+newFeature.criterion,{targetRows:rows.filter(row=>row.variant_id===newCar.id)},()=>applyBrandFeatureUpdates(newCar,baseFeatures.get(newCar.id),research,[packet]));
  reject('actual_consumer_feature_data_'+mode,'consumer_feature_cardinality','Brand update: feature before snapshot changed: '+newCar.id+'/'+newFeature.criterion,{targetRows:rows.filter(row=>row.variant_id===newCar.id)},()=>pack(newCar.id,selected,research));
}

const otherBrand=data.variants.find(row=>row.brand&&row.brand!==packet.brand)?.brand;assert(otherBrand);
for(const [name,edit,message]of [
  ['wrong_brand',car=>{car.brand=otherBrand;},'Brand update: wrong brand or unguarded feature version: '+firstCar.id],
  ['wrong_tier',car=>{car.vehicleClass='van';},'Brand update: feature version is outside Tier 1: '+firstCar.id],
  ['changed_final_identity',car=>{car.trim+=' [isolated final identity drift]';},'Brand update: reviewed feature version changed: '+firstCar.id],
]){
  const cars=changeCar(selected,firstCar.id,edit);
  reject(name,'brand_tier_identity',message,{cars},()=>pack(firstCar.id,cars));
}
consumerPacketReject('other_brand_packet_targeting_subaru','other_brand_targeting','Brand update: wrong brand or unguarded feature version: '+firstCar.id,firstCar.id,value=>{value.brand=otherBrand;});

// No intentional missing-default invocation is counted as a negative result:
// any such invocation during a real guard test is a failure of this harness.
assert.equal(loaderCalls,0);
assert.deepEqual(registryBinding.brandUpdatePackets.map(row=>row.id),[...registeredIds,packet.id]);
assert.equal(registryBinding.brandUpdatePackets.at(-1),packet);
assert.deepEqual(digestRows([packet]),packetDigest,'Every in-memory field of the original candidate packet is unchanged');
assert.deepEqual(selected.map(car=>digestRows([car])),selectedDigests,'All complete selected 11 cars are unchanged');
assert.deepEqual(before.map(car=>digestRows([car])),beforeDigests,'All complete original nine Subaru cars are unchanged');
assert.deepEqual(digestRows(expectedFeatures),expectedFeaturesDigest,'Verified feature output was not edited');
assert.deepEqual(brandUpdatePackets.map(row=>digestRows([row])),registeredDigests,'All 17 original registered packets are unchanged');
assertStagedResearchUnchanged(data,index);
assert.equal(fileHash(beforeFile),beforeFileSha256);
assert.equal(fileHash(selectedReceiptFile),selectedReceiptSha256);
assert.equal(fileHash(selectedReceipt.features.file),selectedReceipt.features.sha256);
stage.verify();
assert.equal(fileHash(scriptFile),scriptSha256,'The measured script itself is unchanged');
assert(!Object.hasOwn(require.cache,roots.repo+'/src/lib/data.ts'),'The normal data loader was never imported');
const receipt={
  status:unsupportedCategories.length?'incomplete_negative_guards_unsupported_real_candidate_categories':'passed_pending_complete_reports_and_independent_review',
  mode:'Actual guarded core and consumer functions on immutable complete derived inputs; hypothetical candidate only',
  asOf:'2026-10-15',versions:11,newVersions:2,originalSubaruVersions:9,researchFields:14,
  packetFacts:646,packetBrandTerms:3,packetFeatureReplacements:293,
  positiveCoreCompleteEquality:true,positiveActualSelectedConsumers:11,
  exactRegisteredPrefix:registeredIds,candidateId:packet.id,loaderCalls,
  categories:[...new Set(caseResults.map(row=>row.category))],caseCount:caseResults.length,cases:caseResults,unsupportedCategories,
  secondaryPromotionCoverage:'One real fact and/or feature per distinct retained secondary source; every Reported-source route is covered, not every claim separately',
  secondarySourceCoverage,candidateForeignSourceCount,foreignPromotion,
  syntheticForeignPromotionRejected,syntheticForeignOrigin:'DE',syntheticForeignInputNeverPublished:true,
  everyNumericV2LClaimHasExplicitExactDependencies:true,numericV2LClaims,
  numericV2LMutationCoverage:'One actual feature per numeric V2L fact key; missing and changed live fact each rejected',
  allMutationInputsUnchanged:true,allOriginalSelectedCarsUnchanged:true,allOriginalBeforeCarsUnchanged:true,
  all14ResearchFieldsUnchanged:true,allOriginalRegisteredPacketsUnchanged:true,fullOriginalPacketUnchanged:true,
  packetDigest,packetSha256:stage.receipt.packetSha256,coreReceiptSha256:stage.receiptHash,
  selectedConsumerReceiptSha256:selectedReceiptSha256,stageInputManifestSha256:stage.proof.manifestSha256,
  scriptSha256,freshLoaderValidation:false,currentFullTypecheckVerified:false,candidateRegistered:false,
  resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage(),
};
writeCandidate('staged-negative-guards-receipt.json',receipt);
assert.equal(unsupportedCategories.length,0,'Negative suite remains incomplete; see explicit unsupported real-candidate categories in the retained receipt');
console.log('All isolated Subaru negative guards passed; complete reports and independent acceptance remain pending');
