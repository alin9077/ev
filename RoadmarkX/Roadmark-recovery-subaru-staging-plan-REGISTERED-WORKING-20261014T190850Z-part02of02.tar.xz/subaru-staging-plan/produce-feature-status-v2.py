"""Produce only the independently approved seven-field feature-status packet copy."""
from pathlib import Path
import json,hashlib,copy,datetime
S=Path('/tmp/subaru-staging-plan');proposalFile=S/'feature-status-v2-transition-proposal.json';reviewFile=Path('/tmp/subaru-staging-review/feature-status-v2-proposal-review.json')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert h(proposalFile)=='312b89eda1a2676701c2ea98bb47faf240a52626e5e505299bcf334950ab5f50'
assert h(reviewFile)=='17cc9923d0b749d5e500e02ea7a63f3f84e089bf4cbe83c6deb506f71e53cd64'
proposal=json.loads(proposalFile.read_text());beforeFile=Path(proposal['beforePacket']['path']);afterFile=Path(proposal['proposedAfterPacket']['path']);assert not afterFile.exists()
assert h(beforeFile)==proposal['beforePacket']['sha256'];before=json.loads(beforeFile.read_text());after=copy.deepcopy(before)
for change in proposal['changes']:
 i=change['index'];assert before['features'][i]==change['beforeRow'];assert change['proposedAfterRow']['after']['status']=='conditional';after['features'][i]['after']['status']='conditional';assert after['features'][i]==change['proposedAfterRow']
def diff(a,b,path=''):
 if type(a)!=type(b):return [path]
 if isinstance(a,dict):
  assert list(a)==list(b),'No object key or property-order change allowed';return [p for k in a for p in diff(a[k],b[k],path+'.'+k if path else k)]
 if isinstance(a,list):
  assert len(a)==len(b),'No array/cardinality change allowed';return [p for i in range(len(a)) for p in diff(a[i],b[i],path+f'[{i}]')]
 return [] if a==b else [path]
paths=diff(before,after);assert paths==[row['path'] for row in proposal['changes']];assert len(paths)==7
for key in ['canonicalPacket','originalFeatureFixture']:assert h(proposal[key]['path'])==proposal[key]['sha256']
cleared=copy.deepcopy(after);cleared['features']=[];assert cleared==json.loads(Path(proposal['canonicalPacket']['path']).read_text())
serialized=(json.dumps(after,indent=2,ensure_ascii=False)+'\n').encode();assert hashlib.sha256(serialized).hexdigest()==proposal['proposedAfterPacket']['sha256'];assert len(serialized)==proposal['proposedAfterPacket']['bytes']
with afterFile.open('xb') as out:out.write(serialized)
assert h(afterFile)==proposal['proposedAfterPacket']['sha256'];assert h(beforeFile)==proposal['beforePacket']['sha256']
for key in ['canonicalPacket','originalFeatureFixture']:assert h(proposal[key]['path'])==proposal[key]['sha256']
receipt={'status':'produced_exact_independently_approved_feature_status_copy','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'beforePacket':proposal['beforePacket'],'afterPacket':{'path':str(afterFile),'sha256':h(afterFile),'bytes':afterFile.stat().st_size},'exhaustiveChangedPaths':paths,'fullChangedRows':proposal['changes'],'allOtherFullPacketValuesAndOrderUnchanged':True,'canonicalPacket':proposal['canonicalPacket'],'originalFeatureFixture':proposal['originalFeatureFixture'],'featureFreeFullPacketEqualsOriginalCanonical':True,'proposalSha256':h(proposalFile),'independentReviewSha256':h(reviewFile),'originalInputsNotOverwritten':True,'canonicalRecaptured':False,'registered':False}
with (S/'feature-status-v2-transition.json').open('x') as out:json.dump(receipt,out,indent=2,ensure_ascii=False);out.write('\n')
print(json.dumps({'status':receipt['status'],'packetSha256':h(afterFile),'changedFields':7,'canonicalRecaptured':False}))
