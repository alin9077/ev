"""Create one reviewed staging pin manifest; run only with the serialized heavy slot."""
import pathlib,json,hashlib,datetime
S=pathlib.Path('/tmp/subaru-staging-plan');P=pathlib.Path('/tmp/subaru-derived-proof-plan');R=pathlib.Path('/tmp/subaru-research');REPO=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104');QA=REPO.parent/'roadmark-104-qa'
roots={'repo':REPO,'qa':QA,'research':R,'polestar':pathlib.Path('/tmp/polestar-research'),'proof':P,'stage':S}
def load(path):return json.loads(pathlib.Path(path).read_text())
def sha(path):
 h=hashlib.sha256()
 with pathlib.Path(path).open('rb') as f:
  while b:=f.read(262144):h.update(b)
 return h.hexdigest()
def locate(row):
 root=roots[row['anchor']];file=(root/row['file']).resolve();assert file.is_relative_to(root) and file!=root;return file
pins={}
def add(path,expected=None,why=''):
 path=pathlib.Path(path).resolve();actual=sha(path)
 if expected is not None:assert actual==expected,'Pinned historical input changed: '+str(path)
 row={'path':str(path),'sha256':actual,'bytes':path.stat().st_size}
 if str(path) in pins:assert pins[str(path)]==row,'Conflicting phase pin: '+str(path)
 pins[str(path)]=row;return {'path':str(path),'sha256':actual}
assert not (S/'stage-inputs.json').exists(),'Never replace a stage-input manifest'
acceptance=load(P/'derived-baseline-acceptance.json');assert acceptance['status']=='accepted_derived_only_baseline_for_subaru_staging';assert acceptance['asOf']=='2026-10-15'
add(P/'derived-baseline-acceptance.json','b8138503a61635d79dbc862f212c2a911b2051c39d1ee981ab5005483c48554b')
add(P/'accepted-derived-index.json','551c8e651e392d1768ed0ea8d81ce65357050e3c5c4ab6074e9d2bc233e78234');assert acceptance['acceptedIndexSha256']==pins[str(P/'accepted-derived-index.json')]['sha256']
index=load(P/'accepted-derived-index.json');assert index['acceptance']=='accepted_derived_only';assert index['cars']['rows']==397 and len(index['research'])==14
consumer=load(P/'consumer-phase-manifest.json');add(P/'consumer-phase-manifest.json',acceptance['consumerPhaseManifestSha256'])
changes={str(REPO/row['file']):row for row in consumer['sourceChanges']}
original=load(locate(consumer['inputVerification']));assert original['status']=='passed_for_derived_only_replay'
for row in original['executionInputs']:
 change=changes.get(row['path'])
 if change:
  assert row['sha256']==change['beforeSha256'];add(locate(change['beforeFile']),row['sha256']);add(row['path'],change['afterSha256'])
 else:add(row['path'],row['sha256'])
for key in ['inputVerification','compositionInputs','coreReceipt','coreTerminal','storageIndex','sourceTransitionReview','beforeSourceInventory','currentSourceInventory']:
 row=consumer[key];add(locate(row),row['sha256'])
for row in load(locate(consumer['compositionInputs']))['executionInputs']:add(row['path'],row['sha256'])
for row in load(locate(consumer['currentSourceInventory']))['files']:add(REPO/row['file'],row['sha256'])
for row in consumer['extraPins']:add(locate(row),row['sha256'])
for key in ['phaseReceipts','terminalReceipts']:
 for row in acceptance[key].values():
  file=P/row['file'];add(file,row['sha256'])
  if key=='terminalReceipts':terminal=load(file);assert terminal['returncode']==0 and terminal['signal'] is None
for name,expected in [('feature-recovery-v3-inputs.json',acceptance['recoveryManifestSha256']),('final-verification-inputs.json',acceptance['finalVerificationInputsSha256'])]:
 add(P/name,expected)
 for row in load(P/name)['executionInputs']:add(row['path'],row['sha256'])
add(locate(index['cars']),index['cars']['sha256'])
for row in index['research'].values():add(locate(row),row['sha256'])
for root in [P,R]:
 for file in sorted(root.rglob('*')):
  if file.is_file():add(file)
required=['stage_inputs.py','build-packet-derived-v2.py','stage-proof-helpers.mjs','compose-subaru-research.mjs','composition-17-to-18.md','capture-canonical-subaru.mjs','stage-core-subaru.mjs','staged-values.mjs','stage-selected-consumers-subaru.mjs','stage-negative-guards-subaru.mjs','stage-full-feature-stream-subaru.mjs','stage-complete-report-subaru.mjs','prepare-stage-inputs.py','run-stage-measured.py']
reviewFile=S/'staging-harness-independent-review.json';review=load(reviewFile);assert review['status']=='approved_for_pinned_subaru_staging'
reviewPins={row['file']:row['sha256'] for row in review['scriptPins']};assert len(reviewPins)==len(review['scriptPins'])
for name in required:assert name in reviewPins,'Missing independent harness review: '+name;add(S/name,reviewPins[name])
compositionFile=S/'composition-17-to-18-independent-review.json';composition=load(compositionFile);assert composition['status']=='approved_for_hypothetical_subaru_staging';assert composition['scriptSha256']==sha(S/'compose-subaru-research.mjs');assert composition['proofSha256']==sha(S/'composition-17-to-18.md')
for file in sorted(S.rglob('*')):
 if file.is_file():
  assert not file.is_relative_to(S/'candidate'),'Candidate must not exist before the input manifest is created'
  assert not any(part.endswith('-attempt1') for part in file.relative_to(S).parts),'No staged execution should precede its input manifest'
  add(file)
registry=load(REPO/'data/m1-brand-updates/registry.json');assert len(registry['packets'])==17 and not any(name.startswith('subaru-') for name in registry['packets'])
manifest={'schemaVersion':1,'mode':'derived-only-subaru-staging','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'asOf':'2026-10-15','registeredPacketCount':17,'candidateId':'m1-subaru-2026-10-15','candidateRegistered':False,'freshLoaderValidation':False,'currentFullTypecheckVerified':False,'registryEditsAuthorized':False,'baselineAcceptance':add(P/'derived-baseline-acceptance.json'),'baselineIndex':add(P/'accepted-derived-index.json'),'consumerPhaseManifest':add(P/'consumer-phase-manifest.json'),'sourceTransitionReview':add(locate(consumer['sourceTransitionReview']),consumer['sourceTransitionReview']['sha256']),'compositionReview':add(compositionFile),'harnessReview':add(reviewFile),'executionInputs':sorted(pins.values(),key=lambda row:row['path']),'historicalOriginalPinCount':len(original['executionInputs']),'historicalExpectedHashesNotReset':True,'sourceChanges':consumer['sourceChanges'],'note':'Historical before hashes remain in the original immutable verification and exact reviewed transition. These explicit current execution pins only resolve that accepted transition for staged Subaru work.'}
for row in manifest['executionInputs']:assert sha(row['path'])==row['sha256'],'Input changed while stage manifest was being prepared'
with (S/'stage-inputs.json').open('x') as out:json.dump(manifest,out,indent=2);out.write('\n')
print(json.dumps({'status':'prepared_reviewed_stage_input_pins','files':len(pins),'manifestSha256':sha(S/'stage-inputs.json'),'candidateBuilt':False}))
