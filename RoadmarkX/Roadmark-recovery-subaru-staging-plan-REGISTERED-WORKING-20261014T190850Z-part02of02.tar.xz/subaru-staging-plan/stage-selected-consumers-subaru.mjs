/** Exact actual packs/citations/portable checks for the 11 staged Subaru versions. */
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {roots,readJson,fileHash,digestRows} from '/tmp/subaru-derived-proof-plan/helpers.mjs';
import {candidateFile,writeCandidate} from './stage-proof-helpers.mjs';
import {openStagedCore,readStagedResearch,assertStagedResearchUnchanged} from './staged-values.mjs';
assert.equal(process.cwd(),roots.repo);
const stage=openStagedCore(),{packet,index,selected}=stage;assert.equal(selected.length,11);const packetDigest=digestRows([packet]);
const require=createRequire(roots.repo+'/package.json');
const {createEvidenceConsumers}=require('./src/lib/evidence-consumers.ts'),{brandUpdatePackets}=require('./src/lib/brand-update-registry.ts'),{compiledSource}=require('./tests/helpers/compiled-source.ts');
const {applyBrandFeatureUpdates,applyBrandTermFeatures}=require('./src/lib/brand-updates.ts');
const {storePortablePacks,hydratePortablePacks}=require('./src/lib/portable-packs.ts'),{factClaim,featureClaim}=require('./src/lib/citable.ts'),{coreFacts}=require('./scripts/reporting/reports.ts');
assert.equal(brandUpdatePackets.length,17);assert(!brandUpdatePackets.some(p=>p.id===packet.id));
const forbidden=()=>{throw new Error('Staged Subaru consumers require complete explicit derived inputs')},defaults={sourceResearch:forbidden,research:forbidden,catalogue:forbidden};
const baseConsumer=createEvidenceConsumers(defaults),stagedFactory=compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets:[...brandUpdatePackets,packet]}}).createEvidenceConsumers,stagedConsumer=stagedFactory(defaults);
assert.equal(typeof global.gc,'function');global.gc();
const data=await readStagedResearch(index),originalSelectedDigests=selected.map(car=>digestRows([car])),beforeFeatures=readJson(candidateFile('new-feature-before.json')),packs={};
let citableFacts=0,citableFeatures=0,coreCells=0;const newIds=new Set(packet.variants.map(v=>v.id));assert.equal(newIds.size,2);
for(const car of selected){
 const expected=index.cars.carHashes.find(row=>row.id===car.id),before=digestRows([car]);assert(expected);assert.equal(before.sha256,expected.afterSha256);assert.equal(before.bytes,expected.bytes);
 for(const {key}of coreFacts){assert.equal(car.facts[key]?.gradeReview?.overlayId,packet.id,car.id+'/'+key);coreCells++}
 const baseFeatures=baseConsumer.effectiveFeatures(car,data);if(newIds.has(car.id))assert.deepEqual(JSON.parse(JSON.stringify(baseFeatures)),beforeFeatures.filter(row=>row.variant_id===car.id),'Complete immutable canonical new-version feature fixture');
 const expectedFeatures=applyBrandTermFeatures(car,applyBrandFeatureUpdates(car,baseFeatures,data,[packet])),view=stagedConsumer.pack(car.id,{data,cars:selected});assert.deepEqual(view.features,expectedFeatures,'Actual staged pack complete feature equality');assert.equal(view.features.length,69);assert.equal(new Set(view.features.map(f=>f.criterion)).size,69);
 packs[car.id]=view;
 for(const fact of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===packet.id)){const claim=factClaim(view,fact);assert.equal(claim.buyerGrade,fact.buyerGrade);assert.deepEqual(claim.sources.map(source=>source.id),fact.sourceIds);citableFacts++}
 for(const edit of packet.features.filter(row=>row.variantId===car.id)){const feature=view.features.find(row=>row.criterion===edit.criterion);assert(feature);assert.deepEqual(feature,edit.after);const claim=featureClaim(view,feature.criterion,feature.criterion);assert(claim);assert.deepEqual(claim.sources.map(source=>source.id),feature.source_ids);assert.equal(claim.gradeReview?.overlayId,packet.id);citableFeatures++}
 assert.equal(view.features.find(row=>row.criterion==='roadside_assistance')?.status,'standard');assert.equal(car.availabilityEvidence.physicalStockVerified,false);assert.equal(car.availabilityEvidence.factoryOrderAcceptanceVerified,false);
 assert(car.buyerSummary?.strength&&car.buyerSummary?.tradeoff);global.gc();console.log('Exact actual Subaru pack',car.id);
}
assert.equal(coreCells,187);assert.equal(Object.keys(packs).length,11);assert.equal(citableFeatures,packet.features.length);assert.deepEqual(hydratePortablePacks(storePortablePacks(packs),data.sources),packs,'Complete actual Subaru portable equality');
assert.throws(()=>stagedConsumer.pack('not-a-subaru-id',{data,cars:selected}));
for(let i=0;i<selected.length;i++)assert.deepEqual(digestRows([selected[i]]),originalSelectedDigests[i]);assertStagedResearchUnchanged(data,index);assert.deepEqual(digestRows([packet]),packetDigest,'Actual consumers did not mutate the complete candidate packet');stage.verify();
const packFile=writeCandidate('staged-packs.json',packs),features=writeCandidate('features-after.json',Object.values(packs).flatMap(pack=>pack.features));
writeCandidate('staged-selected-consumer-receipt.json',{status:'passed_pending_negative_guards_and_complete_reports',asOf:'2026-10-15',mode:'Actual reviewed consumer functions with explicit hypothetical candidate registry; no fresh hydration',versions:11,newVersions:2,coreCells,citableFacts,citableFeatures,actualPackPipelineMatches:true,actualPortableExact:true,fullCanonicalFeatureFixtureEqual:true,fullResearchAndSelectedCarsUnchanged:true,packFile,features,packetSha256:stage.receipt.packetSha256,coreReceiptSha256:stage.receiptHash,stageInputManifestSha256:stage.proof.manifestSha256,unknownPackFails:true,negativeGuardSuitePending:true,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log('All 11 actual packs, citations and portable values passed; negative guards and full report remain pending');
