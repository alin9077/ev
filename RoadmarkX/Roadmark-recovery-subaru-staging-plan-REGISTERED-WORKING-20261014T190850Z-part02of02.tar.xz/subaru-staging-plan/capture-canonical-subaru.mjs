/** Single canonical new-version feature capture after final facts, terms, prices and availability are stable. */
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {roots,readJson,fileHash,readResearch,digestRows} from '/tmp/subaru-derived-proof-plan/helpers.mjs';
import {openSubaruStageInputs,candidateFile,writeCandidate} from './stage-proof-helpers.mjs';
import {composeSubaruResearch,verifyRawOutputUnchanged} from './compose-subaru-research.mjs';
const proof=openSubaruStageInputs();
for(const name of ['canonical-packet-original.json','new-feature-before.json','canonical-baseline-meta.json','canonical-selected-cars.json','canonical-raw-metadata.json','canonical-composition-transition.json'])assert(!fs.existsSync(candidateFile(name)),'Canonical capture outputs must never be overwritten');
const initialFile=candidateFile('subaru-initial-2026-10-15.json'),initialSha256=fileHash(initialFile),packet=readJson(initialFile);packet.features=[];
const canonicalDigest=digestRows([packet]);assert.equal(packet.variants.length,2);assert.equal(packet.id,'m1-subaru-2026-10-15');
const require=createRequire(roots.repo+'/package.json');
const {prepareBrandResearch,applyBrandUpdates}=require('./src/lib/brand-updates.ts');
const {createEvidenceConsumers}=require('./src/lib/evidence-consumers.ts');
const forbidden=()=>{throw new Error('Canonical Subaru capture must use explicit accepted derived inputs')};
const {effectiveFeatures}=createEvidenceConsumers({sourceResearch:forbidden,research:forbidden,catalogue:forbidden});
assert.equal(typeof global.gc,'function');global.gc();
const beforeData=await readResearch(proof.index),before=readJson(roots.research+'/capture-attempt640-original/subaru-live-before.json');assert.equal(before.length,9);
const beforeDigests=Object.fromEntries(Object.entries(beforeData).map(([key,value])=>[key,digestRows(Array.isArray(value)?value:[value])])),carDigests=before.map(car=>digestRows([car]));
for(const[key,value]of Object.entries(beforeDigests)){const row=proof.index.research[key];assert.deepEqual(value,{rows:row.rows,bytes:row.bytes,sha256:row.sha256})}
for(let i=0;i<before.length;i++){const car=before[i],expected=proof.consumer.coreReceipt.carHashes.find(row=>row.id===car.id);assert(expected);assert.equal(carDigests[i].sha256,expected.afterSha256);assert.equal(carDigests[i].bytes,expected.bytes)}
const raw=prepareBrandResearch(beforeData,[packet]),composed=composeSubaruResearch(beforeData,packet,raw),data=composed.data;
const composedDigests=Object.fromEntries(Object.entries(data).map(([key,value])=>[key,digestRows(Array.isArray(value)?value:[value])]));
const cars=applyBrandUpdates(before,data,[packet]);assert.equal(cars.length,11);assert.equal(new Set(cars.map(car=>car.id)).size,11);
const newIds=packet.variants.map(v=>v.id),newCars=cars.filter(car=>newIds.includes(car.id));assert.equal(newCars.length,2);assert.deepEqual(newCars.map(car=>car.id),newIds);
const selectedDigests=cars.map(car=>digestRows([car]));
const fixture=newCars.flatMap(car=>effectiveFeatures(car,data));assert.equal(fixture.length,138);for(const car of newCars){const rows=fixture.filter(f=>f.variant_id===car.id);assert.equal(rows.length,69);assert.equal(new Set(rows.map(f=>f.criterion)).size,69)}
verifyRawOutputUnchanged(raw,composed.rawFieldDigests);
for(const[key,value]of Object.entries(data))assert.deepEqual(digestRows(Array.isArray(value)?value:[value]),composedDigests[key],'Complete composed Research unchanged: '+key);
for(let i=0;i<cars.length;i++)assert.deepEqual(digestRows([cars[i]]),selectedDigests[i],'Canonical consumer did not mutate any selected output car');
for(const[key,value]of Object.entries(beforeData))assert.deepEqual(digestRows(Array.isArray(value)?value:[value]),beforeDigests[key],'Complete baseline Research input unchanged: '+key);
for(let i=0;i<before.length;i++)assert.deepEqual(digestRows([before[i]]),carDigests[i],'Complete original Subaru input unchanged');
assert.deepEqual(digestRows([packet]),canonicalDigest);assert.equal(fileHash(initialFile),initialSha256);proof.verify();
const canonical=writeCandidate('canonical-packet-original.json',packet),originalFixture=writeCandidate('new-feature-before.json',fixture),selected=writeCandidate('canonical-selected-cars.json',cars),rawMetadata=writeCandidate('canonical-raw-metadata.json',raw.metadata),transition=writeCandidate('canonical-composition-transition.json',{...composed.transition,rawMetadata,independentReviewSha256:proof.manifest.compositionReview.sha256});
writeCandidate('canonical-baseline-meta.json',{status:'captured_once_pending_independent_review',createdAt:new Date().toISOString(),asOf:'2026-10-15',generationCount:1,baselineGenerationCount:1,canonical,newFeatureFixture:originalFixture,canonicalDigest,composedResearchDigests:composedDigests,newIds,featureRows:138,selectedCars:selected,rawMetadata,compositionTransition:transition,initialPacketSha256:initialSha256,acceptedBaselineSha256:proof.manifest.baselineIndex.sha256,stageInputManifestSha256:proof.manifestSha256,mode:'Actual reviewed lightweight consumer functions on accepted derived values; no fresh catalogue hydration',freshLoaderValidation:false,currentFullTypecheckVerified:false,candidateRegistered:false,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log('Captured the original two-car, 138-row canonical fixture once; final packet and independent staging checks remain pending');
