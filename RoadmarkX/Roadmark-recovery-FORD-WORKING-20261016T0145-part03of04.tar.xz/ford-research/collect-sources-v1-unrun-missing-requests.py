from pathlib import Path
import json,hashlib,requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin,urlparse
out=Path('/tmp/ford-research/sources-v1')
sources={
'ford-mach-e-overview':'https://www.ford.com.au/showroom/electric/mach-e/',
'ford-mach-e-specs':'https://www.ford.com.au/showroom/electric/mach-e/specs/',
'ford-mach-e-select':'https://www.ford.com.au/showroom/electric/mach-e/select/',
'ford-mach-e-premium':'https://www.ford.com.au/showroom/electric/mach-e/premium/',
'ford-mach-e-gt':'https://www.ford.com.au/showroom/electric/mach-e/gt/',
'ford-electric-range':'https://www.ford.com.au/showroom/electric/',
'ford-price':'https://www.ford.com.au/price/MustangMach-E',
'ford-current-brochure':'https://www.ford.com.au/content/dam/Ford/au/nameplate/mach-e/brochure/specs-brochure/fordvf1419-mustang-mach-e-spec-master-05-aug.pdf',
'ford-warranty-index':'https://www.ford.com.au/owners/warranties/',
'ford-warranty-sept2026':'https://www.ford.com.au/content/dam/na/ford/en_au/owners/warranties/ford-new-vehicle-7-year-warranty-sept-2026.pdf',
'ford-roadside':'https://www.ford.com.au/owners/service/roadside-assistance/',
'ford-service-terms':'https://www.ford.com.au/owners/service/t-and-c/',
'carexpert-2026-price-specs':'https://www.carexpert.com.au/car-news/2026-ford-mustang-mach-e-price-and-specs',
'redbook-model-list':'https://www.redbook.com.au/cars/results/?q=%28C.Make.Ford._.Model.Mustang+Mach-E.%29',
'redbook-my265-select':'https://www.redbook.com.au/cars/details/2026-ford-mustang-mach-e-select-auto-my26-50/SPOT-ITM-696881',
'redbook-my265-premium':'https://www.redbook.com.au/cars/details/2026-ford-mustang-mach-e-premium-auto-my26-50/SPOT-ITM-696882',
'redbook-my265-gt':'https://www.redbook.com.au/cars/details/2026-ford-mustang-mach-e-gt-auto-awd-my26-50/SPOT-ITM-696883',
}
receipts=[]
for name,url in sources.items():
 if (out/(name+'-receipt.json')).exists(): continue
 rec={'id':name,'url':url,'checkedAt':'2026-10-15','method':'public unauthenticated GET; save rendered factual text and allowlisted content links only; never retain scripts, runtime configuration, cookies or headers'}
 try:
  r=requests.get(url,timeout=22); rec.update({'status':r.status_code,'finalUrl':r.url})
  if r.status_code!=200: rec['result']='unavailable'; print(name,r.status_code)
  elif r.content[:4]==b'%PDF':
   p=out/(name+'.pdf'); p.write_bytes(r.content); rec.update({'result':'pdf','path':str(p),'bytes':len(r.content),'sha256':hashlib.sha256(r.content).hexdigest()}); print(name,'PDF',len(r.content))
  else:
   soup=BeautifulSoup(r.text,'html.parser')
   for t in soup(['script','style','noscript','template','svg','input','textarea']): t.decompose()
   text='\n'.join(x.strip() for x in soup.get_text('\n').splitlines() if x.strip()); p=out/(name+'.txt'); p.write_text(text+'\n')
   links=[]
   for a in soup.find_all('a',href=True):
    href=urljoin(r.url,a['href']); u=urlparse(href)
    if u.scheme=='https' and not u.query and any(k in href.lower() for k in ['mach-e','mustang','warrant','towing','electric','roadside','brochure']): links.append({'text':a.get_text(' ',strip=True),'url':href})
   lp=out/(name+'-links.json'); lp.write_text(json.dumps(links,indent=2)+'\n'); rec.update({'result':'sanitized-text','path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'linksPath':str(lp)}); print(name,'text',p.stat().st_size)
 except Exception as e: rec.update({'result':'fetch-failed','errorType':type(e).__name__}); print(name,type(e).__name__)
 (out/(name+'-receipt.json')).write_text(json.dumps(rec,indent=2)+'\n'); receipts.append(rec)
