import json,pathlib,hashlib,datetime,collections
P=pathlib.Path('/tmp/ford-packet/candidate-v3'); M=json.loads((P/'manifest.json').read_text());D=json.loads((P/'ford-2026-10-15.json').read_text());B={x['id']:x for x in json.load(open('/tmp/ford-research/retained-before-cars-v1.json'))};N={x['id']:x for x in D['variants']};S={x['id']:x for x in D['sources']};F={};checks=[]
def check(name,ok,detail=None): checks.append({'check':name,'passed':bool(ok),**({'detail':detail} if detail is not None else {})})
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
check('exact frozen manifest',sha(P/'manifest.json')=='723025848df117574a8c33c2b4747a17a3d71bb4560be530df05060aae1c398e')
check('exact frozen packet',sha(P/'ford-2026-10-15.json')=='ff948c2cb5f42e37925bdd8211ff2f13b6f64685e3afe9ee7a3be90653205da3')
pins={x['path']:x for x in M['files']}
for x in M['files']:
 p=pathlib.Path(x['path']);check('manifest member '+str(p),p.is_file() and p.stat().st_size==x['bytes'] and sha(p)==x['sha256'])
check('manifest path uniqueness',len(pins)==len(M['files']))
check('source ID uniqueness',len(S)==len(D['sources']))
for s in S.values():
 check('source capture '+s['id'],s['capturePath'] in pins and sha(s['capturePath'])==s['captureSha256'])
 c=json.load(open(s['capturePath']))
 check('source URL and publisher '+s['id'],c['url']==s['url'] and c['publisher']==s['publisher'])
 for q in c.get('supportingCaptures',[]):check('source input pin '+s['id']+' '+q['path'],q['path'] in pins and sha(q['path'])==q['sha256'])
for f in D['facts']:
 i=f['variantId'];a=f['after'];k=a['key'];key=(i,k)
 check('unique direct fact '+str(key),key not in F);F[key]=a
 check('exact fact before '+str(key),f['before']==(B[i]['facts'].get(k) if i in B else None))
 check('fact target '+str(key),i in B or i in N)
 check('fact source/grade review IDs '+str(key),len(a['sourceIds'])==len(set(a['sourceIds'])) and set(a['sourceIds'])<=S.keys() and a['sourceIds']==a['gradeReview']['sourceIds'])
 check('fact grade/status '+str(key),a['status']=={'confirmed':'standard','check':'conditional','reported':'conditional','not_published':'not_verified'}[a['buyerGrade']] and (a['buyerGrade']!='reported' or a['resolvedElsewhere'] is True) and (a['buyerGrade']!='not_published' or a['value'] is None))
for t in D['brandTerms']:
 check('shared term target/guard set '+t['key'],set(t['applicableVariantIds'])==set(B)|set(N) and set(t['before'])==set(B)|set(N))
 for i in t['applicableVariantIds']:
  k=t['key'];check('shared term exact before '+i+'/'+k,t['before'][i]==(B[i]['facts'].get(k) if i in B else None));check('no competing shared fact '+i+'/'+k,(i,k) not in F);F[(i,k)]=t['fact']
for g in D['versionGuards']:
 i=g['variantId'];check('version guard '+i,g['before']=={k:B[i][k] for k in g['before']})
accepted={x['id'] for x in json.load(open('/tmp/nissan-packet/full-stage-v1/output/car-digest-comparison.json'))['candidate31']}
check('three new IDs absent from accepted Nissan31',len(N)==3 and not(set(N)&accepted))
for i,v in N.items():
 check('new raw value nulls '+i,all(v[k] is None for k in ['price_aud','range_km','seats']))
 check('new availability producer ownership '+i,'availability_evidence' not in v and v['record_state']=='outgoing')
 check('new epoch explicit '+i,v['model_year']==2023 and v['configuration_evidence']['sourceEpoch']['modelYear']=='2023.75MY')
for a in D['availability']:
 i=a['variantId']
 if i in B:before={'availability':B[i]['availability'],'evidence':B[i]['availabilityEvidence']}
 else:
  v=N[i];before={'availability':v['record_state'],'evidence':{'checkedAt':v['variant_review_date'],'orderStatus':'unverified','stockStatus':'unverified','sourceIds':v['source_ids'],'qualifications':['Physical stock and factory-order acceptance have not been verified.']}}
 check('availability exact producer before '+i,a['before']==before)
 e=a['after']['evidence'];check('no physical/order certainty '+i,e['physicalStockVerified'] is False and e['factoryOrderAcceptanceVerified'] is False)
 check('availability review binding '+i,a['status']=='approved' and a['reviewedAt']==D['reviewedAt'] and a['reviewedBy']==D['reviewedBy'] and e['checkedAt']==a['evidenceDate'])
 check('recall epoch-scoped '+i,('m1_ford_20261015_rec_006648' in e['sourceIds'])==(i in B) and ('m1_ford_20261015_rec_006732' in e['sourceIds'])==(i in N))
mutable={'rankingEligible','projectionScope','sourceIds','requiredBuyerVisibleConditions','requiredNulls','countContribution','configurationReview'}
for c in D['configurationUpdates']:
 i=c['variantId'];old=c['before'];new=c['after'];check('configuration exact before '+i,old==B[i]['configurationEvidence'])
 check('configuration frozen fields '+i,{k:v for k,v in old.items() if k not in mutable}=={k:v for k,v in new.items() if k not in mutable})
 check('complete vehicle count remains held '+i,new['completeVehicleCountEligible'] is False)
 removed=set(old['requiredNulls'])-set(new['requiredNulls']);check('only permitted scalar null releases '+i,removed=={'price_aud','dc_peak_kw','zero_to_100_s'} and {x['key'] for x in new['configurationReview']['releasedNulls']}==removed)
 check('retained nulls exact '+i,all(k in old['requiredNulls'] and old['requiredNulls'][k]==v for k,v in new['requiredNulls'].items()))
 check('configuration source set exact '+i,c['sourceIds']==new['sourceIds'])
 for dep in c['dependencies']:
  a=dep['expected'];check('configuration exact dependency '+i+'/'+dep['key'],a==F[(i,dep['key'])] and a['value'] is not None and not a['issues'] and set(a['sourceIds'])<=set(c['sourceIds']))
for s in D['summaries']:
 for kind in ['strength','tradeoff']:
  for dep in s[kind]['dependencies']:check('summary exact dependency '+s['variantId']+'/'+kind+'/'+dep['key'],dep['expected']==F[(s['variantId'],dep['key'])])
core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty','battery_warranty']
for i in set(B)|set(N):check('seventeen core fields '+i,all((i,k) in F for k in core))
for epoch,ids,batt,ranges,power,height in [('current',list(B),[73,88,91],[470,615,515],[212,212,434],[1627,1627,1609]),('old',list(N),[72,91,91],[470,600,490],[198,216,358],[1634,1634,1623])]:
 for j,i in enumerate(ids):
  for k,values in [('battery_kwh',batt),('range_km',ranges),('power_kw',power),('height_mm',height)]:check('named-grade source value '+i+'/'+k,F[(i,k)]['value']==values[j])
for i in set(B)|set(N):
 check('reported prices unranked '+i,F[(i,'price_aud')]['value'] is None or (F[(i,'price_aud')]['buyerGrade']=='reported' and F[(i,'price_aud')]['priceEvidence']['rankingEligible'] is False))
 check('towing never zero '+i,F[(i,'towing_braked_kg')]['value'] is None)
 check('cargo protocol explicit '+i,'unknown' in F[(i,'boot_l')]['comparisonBasis'])
 check('mirror basis explicit '+i,'unknown' in F[(i,'width_mm')]['comparisonBasis'])
recon=json.load(open(P/'m1-ford-market-reconciliation-2026-10-15.json'))
check('scope remains unresolved',len(recon['inventoryResolutions'])==2 and all(x['outcome']=='unresolved' for x in recon['inventoryResolutions']) and not recon['publishedLists'])
check('reconciliation six exact IDs',set(v['carId'] for v in recon['currentVersionReviews'][0]['versions'])==set(B)|set(N))
result={'kind':'Independent Python static data/source/guard checks only; does not execute application or TypeScript','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifestSha256':sha(P/'manifest.json'),'packetSha256':sha(P/'ford-2026-10-15.json'),'checkCount':len(checks),'passed':sum(x['passed'] for x in checks),'failures':[x for x in checks if not x['passed']],'checks':checks,'executionStatus':'NOT RUN: catalogue hydration, application, test runner, compiler, coverage, build, server, browser, live edit, archive, publication'}
path=pathlib.Path('/tmp/ford-review/candidate-v3-review/static-results.json');path.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
