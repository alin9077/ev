import json,hashlib,re,datetime
from pathlib import Path
D=Path('/tmp/ford-packet/full-stage-v1');O=Path('/tmp/ford-review/full-stage-v1-readiness-review');m=json.loads((D/'manifest.json').read_text());checks=[]
def ck(name,test):
 checks.append({'check':name,'passed':bool(test)})
 if not test:raise AssertionError(name)
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def load(p):return json.loads(Path(p).read_text())
pins={r['path']:r for r in m['pins']};ck('unique386 pins',len(pins)==len(m['pins'])==386)
for p in m['pins']:
 ck('bytes '+p['path'],Path(p['path']).stat().st_size==p['bytes']);ck('sha '+p['path'],sha(p['path'])==p['sha256'])
ck('frozen manifest',sha(D/'manifest.json')=='a032104e62f9735f3c83e071ff3e06dd8331100581093f5b1be9c204f7ac3cc9')
for k,v in m.items():
 if isinstance(v,dict) and set(['path','bytes','sha256'])<=set(v):ck('direct pin '+k,pins.get(v['path'])==v)
for k in ['rawOverlayInputs','reconciliationInputs']:
 for p in m[k]:ck(k+' pin '+p['path'],pins.get(p['path'])==p)
for bundle in ['/tmp/ford-packet/selected-readiness-v1/output-manifest.json','/tmp/ford-review/selected-result-v1-review/manifest.json']:
 ck('bundle pinned '+bundle,bundle in pins)
 for p in load(bundle)['files']:ck('bundle member '+p['path'],pins.get(p['path'])==p)
for p in m['selectedArtifacts'].values():ck('selected artifact pin '+p['path'],pins[p['path']]==p)
accepted=load(m['acceptedManifest']['path']);acceptedpins={(str((Path(accepted['anchors'][p['anchor']])/p['file']).resolve()),p['bytes'],p['sha256']) for p in accepted['inputPins']};storage=load(m['storageClosure']['path']);ck('21 storage files',len(storage)==21)
for p in storage:ck('accepted retained storage '+p['path'],pins.get(p['path'])==p and (p['path'],p['bytes'],p['sha256']) in acceptedpins)
# Reconstruct only recursive storage descriptors and their named research file paths, without loading any car/research records.
actual=set()
def walk(ref):
 p=str((Path(accepted['anchors'][ref['anchor']])/ref['file']).resolve());actual.add(p);idx=load(p)
 for r in [idx['cars']['baseline'],idx['cars']['replacements']]:
  f=str((Path(accepted['anchors'][r['anchor']])/r['file']).resolve());actual.add(f)
  if r.get('format')=='storage-index':walk(r)
 return idx
idx=walk(m['storageIndex'])
for p in idx['research'].values():actual.add(str((Path(accepted['anchors'][p['anchor']])/p['file']).resolve()))
ck('actual recursive storage closure',actual=={p['path'] for p in storage});ck('14 research descriptors',len(idx['research'])==14)
c=load(m['importClosure']['path']);ck('321 import edges',len(c['edges'])==321)
for e in c['edges']:
 ck('importer pinned '+e['importer'],e['importer'] in pins);ck('edge pin '+e['importer']+' '+e['specifier'],pins.get(e['resolved']['path'])==e['resolved'])
for root in c['roots']:ck('closure root '+root,root in pins)
R=Path(m['repo']);loader=(R/'scripts/reporting/load.ts').read_text();paths=[str((R/'scripts/reporting'/p).resolve()) for p in re.findall(r'import \w+ from "(\.\./\.\./data/m1-[^"]+\.json)";',loader)]
ck('31 actual loader reconciliation paths',paths==[p['path'] for p in m['reconciliationInputs']] and len(paths)==31)
registry=load(R/'data/m1-brand-updates/registry.json');ck('31 registry IDs',['m1-'+n.removesuffix('.json') for n in registry['packets']]==m['registeredPacketIds'])
for n in registry['packets']:ck('dynamic registry packet '+n,str(R/'data/m1-brand-updates'/n) in pins)
ck('dynamic registry index',str(R/'data/m1-brand-updates/registry.json') in pins)
ck('dynamic regrading ledger',str(R/'data/m1-evidence-regrading-2026-10-13.json') in pins)
for binary in [m['nodeExecutable'],'/usr/bin/timeout']:ck('executable pinned '+binary,binary in pins or str(Path(binary).resolve()) in pins)
ck('all selected input pins retained',all(pins.get(p['path'])==p for p in load('/tmp/ford-packet/selected-readiness-v1/source-pins.json')))
s=(D/'stage.mjs').read_text();sel=Path('/tmp/ford-packet/selected-readiness-v1/check.mjs').read_text()
for start,end in [('function observePack(', 'function observeClaim('),('function observeClaim(', '\nfor(const car of before)'),('function pairCheck(', '\nfor(let i=0;')]:
 ck('accepted selected routine unchanged '+start,s[s.index(start):s.index(end,s.index(start))].strip()==sel[sel.index(start):sel.index(end,sel.index(start))].strip())
syntax=load(D/'syntax-only-check.json');ck('syntax-only receipt binding',syntax['scriptSha256']==sha(D/'stage.mjs') and syntax['exitCode']==0 and not syntax['runtimeExecuted'] and not syntax['importsExecuted'] and not syntax['typescriptCompilerAttempted'])
ck('execution output absent',not Path(m['output']).exists() and not Path(m['runOutput']).exists())
ck('bounds',m['execArgv']==['--max-old-space-size=448','--max-semi-space-size=1','--expose-gc','--import','tsx'] and m['timeoutSeconds']==420 and m['killAfterSeconds']==10 and not m['automaticRetry'])
ck('separate permission gates',m['rootExecutionGrantRequired'] and m['exclusiveHeavySlotRequired'] and not m['productionRegistrationAuthorized'] and not m['canonicalRecaptureAuthorized'] and not m['normalFullReportInStage'])
normal=load(m['acceptedNormalReport']['path']);c1=load(m['acceptedNissanC1']['path'])['after'];ck('accepted complete C1 baseline equality',normal['reconciliation']==c1)
ck('accepted C1 counts',(c1['reviewedModels'],c1['reviewedVersions'],len(c1['issues']),len(c1['settledInventory']))==(106,242,187,65))
rec=load(m['reconciliation']['path']);ck('3 maker list only',[v['carId'] for v in rec['currentVersionReviews'][0]['versions']]==m['selectedIds'])
ck('2 unresolved inventory',len(rec['inventoryResolutions'])==2 and all(x['outcome']=='unresolved' for x in rec['inventoryResolutions']))
ck('complete expected C1 code',"assert.deepStrictEqual(globalWritten,expectedGlobalWritten" in s and "assert.equal(expectedGlobalWritten.issues.length,186)" in s)
ck('full ranking object code',"assert.deepEqual(next.groups,expectedGroups" in s and "assert.deepEqual(next.excluded,expectedExcluded" in s and "assert.deepEqual(next.unranked,expectedUnranked" in s)
ck('no broad feature replay declaration',"broadFeatureReplay:false" in s and "normalFullReportRun:false" in s)
# Source-string comparator checks are exact guards in the stage; verify the pinned production expressions independently.
discovery=(R/'src/lib/discovery.ts').read_text()
ck('actual group comparator source',discovery.count('(a, b) =>\n        b.entries.length - a.entries.length || a.basis.localeCompare(b.basis)')==1)
ck('actual unranked comparator source',discovery.count('unranked.sort((a, b) =>\n    `${a.car.brand} ${a.car.model} ${a.car.trim}`.localeCompare(\n      `${b.car.brand} ${b.car.model} ${b.car.trim}`,\n    ),\n  );')==1)
output={'status':'PASS_STATIC_FULL_STAGE_READINESS_CHECKS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passedChecks':len(checks),'failedChecks':0,'inputFiles':len(pins),'inputBytes':sum(p['bytes'] for p in pins.values()),'localImportEdges':len(c['edges']),'method':'Static source/JSON inspection and streaming hashes only; no application imports, hydration, compiler or stage execution','checks':checks}
(O/'checks.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps({k:v for k,v in output.items() if k!='checks'}))
