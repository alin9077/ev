from pathlib import Path
import json,hashlib,ast,difflib,datetime,re
D=Path('/tmp/ford-packet/docs-status-v1');O=Path('/tmp/ford-review/docs-status-v1-review');checks=[]
def ck(n,v):
 checks.append(dict(check=n,passed=bool(v)))
 if not v:raise AssertionError(n)
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def check(p):ck('pin '+p['path'],pin(p['path'])==p)
m=read(D/'manifest.json');ck('frozen manifest',pin(D/'manifest.json')['sha256']=='9b63a80c29fc2295d888f119f119c09cbb4a95f122f95e970a39a2bcfd92c052')
for p in m['proofs']+[m[k]for k in ['applicator','preparer','applicatorPattern','patch']]:check(p)
ck('1047 unique proof inputs',len(m['proofs'])==len({p['path']for p in m['proofs']})==1047);ck('no mutable targets in unchanged proofs',not ({w['target']for w in m['writes']}&{p['path']for p in m['proofs']}))
patch=''
for w in m['writes']:
 check(w['after']);target=Path(w['target']);ck('exact target location '+w['relativePath'],target==Path(m['repo'])/w['relativePath'] and not target.is_symlink())
 if w['before']:
  check(w['before']);check(w['beforeCopy']);old=Path(w['beforeCopy']['path']).read_bytes();ck('exactbefore '+w['relativePath'],old==target.read_bytes())
 else:old=b'';ck('new target absent',not target.exists() and w['operation']=='create' and w['beforeCopy']is None)
 patch+=''.join(difflib.unified_diff(old.decode().splitlines(True),Path(w['after']['path']).read_text().splitlines(True),fromfile=w['relativePath']+' (before)',tofile=w['relativePath']+' (after)'))
ck('full patch independently recreated',patch==Path(m['patch']['path']).read_text())
for i,name in [(1,'progress-append.md'),(3,'backlog-append.md')]:
 w=m['writes'][i];ck('exact append-only '+name,Path(w['after']['path']).read_bytes()==Path(w['beforeCopy']['path']).read_bytes()+(D/name).read_bytes())
ck('buyer after exact',Path(m['writes'][0]['after']['path']).read_bytes()==(D/'buyer-update.md').read_bytes())
old=read(m['writes'][2]['beforeCopy']['path']);new=read(m['writes'][2]['after']['path']);changed=set(m['historyPreservation']['changedCurrentFields']);ck('history exact previous12',new['workStatusHistory'][:-1]==old['workStatusHistory'] and len(old['workStatusHistory'])==12)
ck('superseded current fields exact',new['workStatusHistory'][-1]['previous']=={k:old[k]for k in changed if k in old})
ck('exact changed field declaration',{k for k in set(new)|set(old) if new.get(k)!=old.get(k)}<=changed|{'workStatusHistory'})
for k in old:
 if k not in changed and k!='workStatusHistory':ck('historical field unchanged '+k,new[k]==old[k])
ck('exact old status snapshot',m['historyPreservation']['exactCompleteStatusBeforeSnapshot']==m['writes'][2]['beforeCopy'])
ck('Nissan historical working preserved',new['nissanWorking']==old['nissanWorking'] and new['nissanPendingRecovery']==old['nissanPendingRecovery'] and new['backup']==old['backup'])
n=read(m['reportEvidence']['normalReport']['path']);fc=next(x for x in n['brandProgress']if x['brand']=='Ford');w=new['latestWorkingBrandChecks'];rs=new['fordResearchStatus'];selected=read('/tmp/ford-packet/selected-readiness-v1/result.json');sel=selected['selectedCoverage'];packet=read('/tmp/ford-packet/candidate-v4/ford-2026-10-15.json');cars=read('/tmp/ford-packet/selected-readiness-v1/selected-after-cars.json')
ck('current identity status',new['currentBrand']=='Ford' and new['previousBrand']=='Nissan' and new['nextBrand']=='awaiting selection' and new['fordWorking']==w)
ck('completed dates separate',w['snapshotAsOf']==m['researchReportAsOf']==rs['snapshotAsOf']=='2026-10-15' and w['validationCompletedAt']==m['validationCompletedAt']==read(m['reportEvidence']['independentAcceptance']['path'])['at'])
cov=w['coverage'];expected=dict(asOf=n['asOf'],catalogue=n['allCatalogueVersions'],tier1=n['tierOneVersions'],onSale=n['onSaleVersions'],registeredPackets=32,coreReviewed=n['grading']['reviewedCoreCells'],coreDenominator=n['grading']['totalCoreCells'],strictGaps=len(n['gaps']),reviewedModels=n['reconciliation']['reviewedModels'],reviewedVersions=n['reconciliation']['reviewedVersions'],c1Issues=len(n['reconciliation']['issues']),settledInventory=len(n['reconciliation']['settledInventory']),unmatchedAuditModels=len(n['missingModels']),unresolvedLeads=len(n['unresolvedLeads']),researchCompletedBrands=len(n['brandsResearchCompleted']),researchRemainingBrands=len(n['brandsResearchRemaining']),rankings={x['key']:x['ranked']for x in n['rankings']},criteria=[dict(id=x['id'],**{'pass':x['pass']})for x in n['criteria']]);ck('full status coverage matches actual report',cov==expected)
ford=w['fordCoverage'];ck('Ford coverage actual criteria/closure/ranks',ford['criteria']==fc['criteria'] and ford['closureIssues']==fc['closureIssues'] and ford['rankings']==[dict(key=x['key'],ranked=x['ranked'],total=5,percent=x['percent'],passes=x['passes'])for x in sel['rankings']])
ck('Ford six versus five',ford['visible']==6 and ford['onSale']==5 and ford['currentMakerVersions']==3 and ford['currentMakerReviews']==1 and ford['onSaleCoreCells']==ford['onSaleReviewed']==85 and ford['onSaleFilled']==sum(x['filled']for x in sel['core'])==80 and ford['onSaleGaps']==len(sel['gaps'])==5)
ck('onSale grade counts',ford['onSaleCoreGrades']=={g:sum(x['grades'][g]for x in sel['core'])for g in sel['core'][0]['grades']});ck('all visible grade counts',ford['allVisibleCoreGrades']==selected['coreGradeCounts'] and ford['allVisibleCoreCells']==ford['allVisibleReviewed']==102 and ford['allVisibleFilled']==95)
ck('structural exact',w['structural']==read('/tmp/ford-packet/post-registration-checks-v1/run/structural-validation/stdout.log'));ck('tests scoped exact',w['relevantTests']==new['latestFreshRelevantTests'] and w['relevantTests']['distinctScopedTestsAcrossTheseRuns']==151 and not w['relevantTests']['fullProjectSuite'])
ctx=read('/tmp/ford-packet/report-comparison-plan-v2/typescript-failure-context.json');ck('compiler failures exact',w['fullTypecheck']['attempts']==ctx['attempts'] and not w['fullTypecheck']['passed'] and w['fullTypecheck']['fordCompilerAttempts']==0 and not w['fullTypecheck']['furtherRetryAuthorized'])
ck('research open',not w['researchCompleted'] and not w['releaseReady'] and not w['fullProjectTypecheckPassed'] and not rs['researchCompleted'] and not rs['wholeMarketC1Closed'] and not new['fordPendingRecovery']['releaseReady'])
for k,fk in [('currentGuidePricesAud','price_aud'),('currentWltpCombinedKm','range_km'),('currentUsableBatteryKwh','battery_kwh'),('currentDc10to80Minutes','dc_charge_time_min')]:ck('current factual status '+k,rs[k]==[c['facts'][fk]['value']for c in cars[:3]])
for k,fk in [('residualDealerPricesAud','price_aud'),('residualWltpCombinedKm','range_km'),('residualUsableBatteryKwh','battery_kwh'),('residualDc10to80Minutes','dc_charge_time_min')]:ck('residual factual status '+k,rs[k]==[c['facts'][fk]['value']for c in cars[3:]])
ck('census exact',rs['censusDispositions']==read('/tmp/ford-packet/reconciliation-v1/m1-ford-market-reconciliation-2026-10-15.json')['inventoryResolutions'])
ck('claims counts exact',rs['specificFactUpdates']==121 and rs['earnedFactAndTermCells']==selected['earnedPacketCells']==139 and rs['effectiveFeatureClaims']==selected['selectedFeatureClaims']==414 and rs['summaryPairs']==6)
# Every newly added documentary pin must name existing exact evidence.
def pins_in(x):
 if isinstance(x,dict):
  if {'path','bytes','sha256'}<=x.keys():yield {k:x[k]for k in ['path','bytes','sha256']}
  for v in x.values():yield from pins_in(v)
 elif isinstance(x,list):
  for v in x:yield from pins_in(v)
for k in changed:
 if k in new:
  for p in pins_in(new[k]):check(p)
buyer=(D/'buyer-update.md').read_text();progress=(D/'progress-append.md').read_text();ck('five buyer sections',len(re.findall(r'^## [1-5]\.',buyer,re.M))==5)
cores={x['key']:x for x in n['core']};cells=[str(n['onSaleVersions'])]+[f"{cores[k]['filledPercent']:.1f}% / {cores[k]['confirmedPercent']:.1f}%"for k in ['price_aud','range_km','battery_kwh','dc_charge_time_min','seats','boot_l','warranty']]+[f"{n['pairedOnSalePercent']:.1f}%",f"{n['inAllRankingsPercent']:.1f}%"];ck('buyer table exact actual report','| '+' | '.join(cells)+' |' in buyer)
ck('research complete list exact',', '.join(n['brandsResearchCompleted'])+'.' in buyer);ck('remaining brands exact',', '.join(n['brandsResearchRemaining'])+'.' in buyer)
ck('unknowns and no completion claims',all(t in buyer for t in ['C1/C2/C5 open','Not confirmed','unknown','official-importer eligibility','full-project TypeScript'.title().replace('Full-Project','Full-project')]) if False else all(t in buyer for t in ['C1/C2/C5 open','Not confirmed','official-importer eligibility','TypeScript and release remain UNPASSED','recovery delivery is pending']))
for p in D.glob('*.py'):ast.parse(p.read_text());ck('AST only '+p.name,True)
ref=Path(m['applicatorPattern']['path']).read_text().replace('three reviewed Nissan','four reviewed Ford').replace('/tmp/nissan-packet/docs-status-v2',str(D)).replace('NISSAN_M1_UPDATE','FORD_M1_UPDATE').replace('apply_exact_nissan_docs_status','apply_exact_ford_docs_status').replace("    'roadmark-104-qa/work-status.json',\n]","    'roadmark-104-qa/work-status.json',\n    'roadmark-104/docs/BACKLOG.md',\n]").replace("len(manifest['writes']) == 3","len(manifest['writes']) == 4").replace("old_status = json.loads", "backlog = manifest['writes'][3]\nassert Path(backlog['after']['path']).read_bytes().startswith(Path(backlog['beforeCopy']['path']).read_bytes())\nold_status = json.loads")
ck('applicator only exact reviewed adaptation',ref==Path(m['applicator']['path']).read_text());ck('not applied',not(D/'application').exists() and read(D/'root-grant-template.json')['status']=='NOT_GRANTED')
res=dict(status='PASS_DOCUMENTARY_BYTES_AND_HISTORY_WITH_BUYER_WARRANTY_HOLD',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),passedChecks=len(checks),failedChecks=0,hold='Buyer summary needs concise base/conditional warranty and residual-demo commencement caveat; full progress/status already accurate.',checks=checks);(O/'checks.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({k:v for k,v in res.items()if k!='checks'}))
