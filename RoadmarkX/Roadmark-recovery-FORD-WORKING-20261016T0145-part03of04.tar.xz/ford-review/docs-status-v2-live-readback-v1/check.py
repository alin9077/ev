from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,stat
B=Path('/tmp/ford-review/docs-status-v2-live-readback-v1');A=Path('/tmp/ford-packet/docs-status-v2')
checks=[]
def ck(v,n):
 assert v,n
 checks.append(n)
def pin(p):
 p=Path(p);d=p.read_bytes();return {'path':str(p),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
def verify(p,n):
 a=pin(p['path']);ck(all(a[k]==p[k] for k in ['path','bytes','sha256']),n);return a
mp=pin(A/'manifest.json');ck(mp['sha256']=='54938c201d4096fa6943363aa02370e0f0c7aa5cbfe9698f5415c64bf0e9a9a4','Exact accepted docs manifest')
m=json.loads((A/'manifest.json').read_text())
gp=pin(A/'root-application-grant-v1.json');ck(gp['sha256']=='1f531b5dacf701c97bf8b5116ac0321cf0b4a851cfaa7d0cb43c3dfe6932a7a7','Exact root grant')
g=json.loads(Path(gp['path']).read_text());verify(g['manifest'],'Grant binds manifest');verify(g['reviewerAcceptance'],'Grant binds independent acceptance')
ck(g['reviewerAcceptance']['sha256']=='0c8d8157cbe9e33506a5bcd39a1df82ce27f7d09374ade1ca0cad763bc0ef1f9','Exact independent acceptance')
ck(g['action']=='apply_exact_ford_docs_status' and g['status']=='root_application_granted','Exact action')
ck(not g['automaticRetry'] and not g['heavyExecutionAuthorized'],'Limited grant')
rp=pin(A/'application/result.json');r=json.loads(Path(rp['path']).read_text());st=json.loads((A/'application/started.json').read_text())
for x in [r,st]:
 ck(x['manifestSha256']==mp['sha256'] and x['grantSha256']==gp['sha256'],'Application binds exact manifest and grant')
 ck(x['heavyExecution'] is False,'Application has no heavy execution')
ck(st['beforeGuardsPassed'] is True and r['passed'] is True and r['automaticRetry'] is False,'Application completed once with beforeguards')
ck(st['at']>=g['at'] and r['at']>=st['at'],'Chronology')
ck(sorted(p.name for p in (A/'application').iterdir())==['result.json','started.json','write-1.json','write-2.json','write-3.json','write-4.json'],'Exact six application receipts; no failure journal')
ck(g['allowedTargets']==[x['target'] for x in m['writes']] and len(m['writes'])==4,'Exact four targets')
live=[]
for i,w in enumerate(m['writes'],1):
 p=Path(w['target']);s=p.lstat();ck(stat.S_ISREG(s.st_mode) and not p.is_symlink() and p.resolve()==p,'Regular exact live path '+str(p))
 verify(w['after'],'Retained accepted payload '+str(i))
 lp=pin(p);ck(lp['sha256']==w['after']['sha256'] and lp['bytes']==w['after']['bytes'],'Live hash and size '+str(i))
 ck(p.read_bytes()==Path(w['after']['path']).read_bytes(),'Live byte equality '+str(i))
 j=json.loads((A/f'application/write-{i}.json').read_text());ck(j=={'target':str(p),'sha256':lp['sha256']}==r['writes'][i-1],'Exact write journal '+str(i));live.append(dict(**lp,mode=s.st_mode,mtimeNs=s.st_mtime_ns))
 if w['beforeCopy']:
  verify(w['beforeCopy'],'Before snapshot '+str(i));ck(w['beforeCopy']['sha256']==w['before']['sha256'] and w['beforeCopy']['bytes']==w['before']['bytes'],'Original before pin retained '+str(i))
for i in [1,3]:
 w=m['writes'][i];ck(Path(w['target']).read_bytes().startswith(Path(w['beforeCopy']['path']).read_bytes()),'Live append-only prefix '+str(i))
w=m['writes'][2];old=json.loads(Path(w['beforeCopy']['path']).read_text());new=json.loads(Path(w['target']).read_text());changed=set(m['historyPreservation']['changedCurrentFields'])
ck(new['workStatusHistory'][:-1]==old['workStatusHistory'],'Exact all 12 historical entries')
ck(len(old['workStatusHistory'])==12 and len(new['workStatusHistory'])==13,'Exactly one new status history entry')
ck(new['workStatusHistory'][-1]['previous']=={k:old[k] for k in changed if k in old},'Every superseded current field archived exactly')
for k in old:
 if k not in changed and k!='workStatusHistory':ck(new[k]==old[k],'Preserved live status field '+k)
for k in m['historyPreservation']['unchangedHistoricalFields']:ck(new[k]==old[k],'Manifest-declared preserved historical field '+k)
for k in ['applicator','preparer','patch','applicatorPattern','preservedPreparation']:verify(m[k],'Accepted preparation helper '+k)
ck(not any(p['path'] in g['allowedTargets'] for p in m['proofs']),'No changing documentary target included in unchanged proof set')
ck(len(m['proofs'])==1062,'Same unchanged proof declaration count')
result=dict(status='passed',checkedAt=datetime.now(timezone.utc).isoformat(),checksPassed=len(checks),checks=checks,manifest=mp,rootGrant=gp,applicationReceipt=rp,liveTargets=live,applicationJournals=[pin(p) for p in sorted((A/'application').iterdir())],allFourLiveHashesAndBytesMatchAcceptedPayloads=True,allHistoricalStatusFieldsPreservedOrExactlyArchived=True,progressAndBacklogAppendOnly=True,unchangedProofCount=1062,unchangedProofRehashAtThisReadback=False,proofScope='Full 1,062 proofs independently verified in accepted static review and checked by pinned applicator before and after its writes. This live readback directly rechecks the four targets, exact historical snapshots, grant, acceptance, helper pins and six journals; it does not rerun the global proof hash pass.',projectModulesImported=False,compilerOrRuntimeRun=False,liveWritesPerformedByReviewer=False)
with (B/'checks.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['checks','applicationJournals','liveTargets']},indent=2))
