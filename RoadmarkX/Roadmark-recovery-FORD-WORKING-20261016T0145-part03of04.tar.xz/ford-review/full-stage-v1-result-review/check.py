import json,hashlib,copy,datetime
from pathlib import Path
D=Path('/tmp/ford-packet/full-stage-v1');P=D/'output';O=Path('/tmp/ford-review/full-stage-v1-result-review');checks=[]
def read(p):return json.loads(Path(p).read_text())
def ck(name,test):
 checks.append({'check':name,'passed':bool(test)})
 if not test:raise AssertionError(name)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def digest(x):
 b=(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n').encode();return {'rows':1,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
m=read(D/'manifest.json');om=read(D/'full-stage-result-manifest-v1.json');r=read(P/'stage-receipt.json');selected=read(P/'result.json')
ck('output manifest hash',sha(D/'full-stage-result-manifest-v1.json')=='c467702e0a5f97993e5ada23de10d98d6aa092c321e49451f1dc334b257a7c02')
for label,rows in [('output',om['files']),('input',m['pins'])]:
 for p in rows:ck(label+' bytes '+p['path'],Path(p['path']).stat().st_size==p['bytes']);ck(label+' hash '+p['path'],sha(p['path'])==p['sha256'])
term=read(D/'run/terminal.json');inv=read(D/'run/invocation.json');post=read(D/'run/after-pins.json');group=read(D/'run/process-group-complete.json')
ck('terminal success',term['exitCode']==0 and term['rawWaitStatus']==0 and term['elapsedSeconds']<420 and not term['automaticRetry'])
for s in ['stdout','stderr']:ck('terminal '+s,sha(D/f'run/{s}.log')==term[s+'Sha256'])
ck('stderr empty',(D/'run/stderr.log').stat().st_size==0)
ck('exact command manifest',inv['manifestSha256']==sha(D/'manifest.json')==r['manifestSha256'])
ck('postpins',post['passed'] and post['count']==386 and post['manifestSha256']==inv['manifestSha256'])
ck('exact packet',r['packetSha256']==m['packet']['sha256'])
stdout=read(D/'run/stdout.log') if False else json.loads((D/'run/stdout.log').read_text().splitlines()[-1]);ck('stdout definitive receipt',stdout['sha256']==sha(P/'stage-receipt.json') and stdout['status']=='passed')
for name,pin in m['selectedArtifacts'].items():ck('selected bytes identical '+name,sha(P/name)==pin['sha256'])
acceptedSelected=read(m['selectedResult']['path'])
for k in ['additionBuilderProof','comparisonProof','crossBasisProof','negativeProof','optionalFeaturePaths','optionalCitationPaths','selectedCoverage','rankCounts','producerProofs','untouchedFactProof']:
 ck('selected proof '+k,selected[k]==acceptedSelected[k])
cars=read(P/'car-digest-comparison.json');fields=read(P/'research-field-digests.json');ac=read(m['acceptedNissanCars']['path']);af=read(m['acceptedNissanFields']['path'])
ck('13 stages',len(cars)==len(fields)==13)
for stage in ac:ck('exact accepted car stage '+stage,cars[stage]==ac[stage])
for stage in af:ck('exact accepted fourteen-field stage '+stage,fields[stage]==af[stage] and len(fields[stage])==14)
b={c['id']:c for c in cars['candidate31']};a={c['id']:c for c in cars['candidate32']};old=set(m['selectedIds']);new=set(m['addedIds']);allids=old|new;peers=set(b)-old
ck('exact candidate count',len(a)==433 and len(b)==430 and len(peers)==427)
ck('exact ordered candidate IDs',list(a)==list(b)+m['addedIds'])
ck('exact changed retained IDs',{id for id in b if b[id]!=a[id]}==old)
for id in peers:ck('peer digest '+id,a[id]==b[id])
after={c['id']:c for c in read(P/'selected-after-cars.json')};before={c['id']:c for c in read(m['selectedBefore']['path'])}
for id,c in after.items():ck('complete selected digest '+id,{'id':id,**digest(c)}==a[id])
for id,c in before.items():ck('complete before digest '+id,{'id':id,**digest(c)}==b[id])
changed={'metadata','sources','variants','feature_evidence_variant_context','feature_evidence','trim_equipment','update_eligibility'}
for k,v in fields['candidate31'].items():
 if k not in changed:ck('unchanged research field '+k,fields['candidate32'][k]==v)
for k,delta in [('sources',27),('variants',3),('feature_evidence_variant_context',3),('feature_evidence',207),('trim_equipment',3),('update_eligibility',3)]:ck('research append '+k,fields['candidate32'][k]['rows']==fields['candidate31'][k]['rows']+delta)
trans=read(P/'metadata-composition.json');ck('12 metadata transitions',len(trans)==12)
for i,t in enumerate(trans):
 ck('only metadata composition '+t['packetId'],{k:v for k,v in t['rawMetadata'].items() if k!='brand_update_packet_ids'}=={k:v for k,v in t['composedMetadata'].items() if k!='brand_update_packet_ids'})
 ck('metadata singleton '+t['packetId'],t['rawMetadata']['brand_update_packet_ids']==[t['packetId']]);ck('metadata packet order '+t['packetId'],t['composedMetadata']['brand_update_packet_ids']==(m['registeredPacketIds']+['m1-ford-2026-10-15'])[:21+i])
 if i:ck('metadata chain '+t['packetId'],t['beforeMetadata']==digest(trans[i-1]['composedMetadata']))
ck('Ford metadata final digest',digest(trans[-1]['composedMetadata'])==fields['candidate32']['metadata'])
ck('Ford metadata exact increments',trans[-1]['composedMetadata']['added_variant_count']==trans[-2]['composedMetadata']['added_variant_count']+3 and trans[-1]['composedMetadata']['added_feature_row_count']==trans[-2]['composedMetadata']['added_feature_row_count']+207)
neutral=read(P/'source-reference-neutrality.json');ck('source neutrality scope',neutral['peerCars']==427 and neutral['sourceRowsAdded']==27 and not neutral['helperChanges'] and not neutral['broadFeatureReplay'] and len(neutral['inspections'])==12)
for n in neutral['inspections']:ck('source reference scan '+n['input'],n['newSourceReferences']==0 and n['nestedGradeReviewsAndKeysIncluded'])
closure=read(P/'retained-storage-read-closure.json');ck('actual21 closure',set(closure['actualReadFiles'])=={x['path'] for x in read(m['storageClosure']['path'])} and closure['all21FilesPinnedBeforeAndAfter'])
normal=read(m['acceptedNormalReport']['path'])
def tier(c):return not c.get('vehicleClass') or c['vehicleClass'] in ['passenger','ute']
def onSale(c):return c['availability']=='current_or_order_listed' or (c['availability']=='outgoing' and c.get('availabilityEvidence',{}).get('stockStatus')=='new_stock_listed' and bool(c.get('availabilityEvidence',{}).get('sourceIds')))
ck('accepted actual normal totals',(normal['allCatalogueVersions'],normal['tierOneVersions'],normal['onSaleVersions'])==(430,353,312))
ck('selected eligibility delta',sum(tier(c) for c in after.values())-sum(tier(c) for c in before.values())==3 and sum(tier(c) and onSale(c) for c in after.values())-sum(tier(c) and onSale(c) for c in before.values())==2)
ck('global actual counts plus exact peer preservation',(r['stagedCars'],r['tierOneVersions'],r['onSaleVersions'])==(433,356,314))
# Full written C1 reconstruction, independent of the emitted expectedCompleteAfter.
globalc1=read(P/'global-c1-comparison.json');c1b=globalc1['before'];c1a=globalc1['after'];rec=read(m['reconciliation']['path']);ck('baseline globalC1 exact',c1b==read(m['acceptedNissanC1']['path'])['after']==normal['reconciliation']==read(P/'baseline-global-c1.json'))
e=copy.deepcopy(c1b);e['registryCheckedAt']=max(e['registryCheckedAt'],rec['checkedAt']);e['reviewedModels']+=1;e['reviewedVersions']+=3;e['reviewedVersionIds']+=m['selectedIds'];e['validModelReviewIds'] += [x['id'] for x in rec['currentVersionReviews']]
e['issues']=[i for i in e['issues'] if not(i['code']=='version_unreviewed' and i.get('reference') in old)]
last=max(i for i,x in enumerate(e['issues']) if x['code']=='version_unreviewed');e['issues'][last+1:last+1]=[x for x in selected['currentListProof']['issues'] if x['code']=='version_unreviewed']
e['evidence']['checkedAt']=max(e['evidence']['checkedAt'],rec['checkedAt'])
for k in ['notes','publishedLists','currentVersionReviews','listResolutions','catalogueOnlyDifferences','inventoryResolutions']:e['evidence'][k]+=rec[k]
ck('independent complete C1 equality',e==c1a==globalc1['expectedCompleteAfter'])
ck('globalC1 exact totals',(c1a['reviewedModels'],c1a['reviewedVersions'],len(c1a['issues']),len(c1a['settledInventory']),c1a['pass'])==(107,245,186,65,False))
ck('selected C1 receipt exact',r['selectedC1']==selected['currentListProof'])
# Complete ranking content, arithmetic, membership and retained order checks. Actual ICU sorting is bound by pinned production-source and runtime assertions.
ranks=read(P/'global-ranking-comparison.json');ck('seven attributes',len(ranks)==7 and len({x['attribute'] for x in ranks})==7)
def gkey(g):return (g['vehicleClass'],g['basis'],g['unit'])
def striprank(e):return {k:v for k,v in e.items() if k not in ['rank','tied']}
for rank in ranks:
 k=rank['attribute'];oldr=rank['completeOrderedBefore'];newr=rank['completeOrderedAfter'];sr=rank['completeSelectedRecords'];lower=k in ['length_mm','price_aud','dc_charge_time_min']
 for phase,x,dg in [('before',oldr,b),('after',newr,a),('selected',sr,a)]:
  ordered=[row for g in x['groups'] for row in g['entries']];ids=[row['carId'] for row in ordered];ck('unique ranked '+k+phase,len(ids)==len(set(ids)))
  for row in ordered+x['excluded']+x['unranked']:ck('rank full digest '+k+phase+row['carId'],row['carDigest']==dg[row['carId']])
  for g in x['groups']:
   values=[row['fact']['value'] for row in g['entries']];ck('numeric ordering '+k+phase+str(gkey(g)),values==sorted(values,reverse=not lower))
   for row in g['entries']:
    val=row['fact']['value'];ck('rank tie arithmetic '+k+phase+row['carId'],row['rank']==values.index(val)+1 and row['tied']==(values.count(val)>1));ck('rank basis '+k+phase+row['carId'],row['fact']['comparisonBasis']==g['basis'] and row['fact']['unit']==g['unit'])
  ck('group size order '+k+phase,[len(g['entries']) for g in x['groups']]==sorted((len(g['entries']) for g in x['groups']),reverse=True))
  ck('rank partition '+k+phase,set(ids)|{x['carId'] for x in x['excluded']}==(set(b) if phase=='before' else set(a) if phase=='after' else allids))
 oldgroups={gkey(g):g for g in oldr['groups']};sgroups={gkey(g):g for g in sr['groups']};newgroups={gkey(g):g for g in newr['groups']}
 expectedkeys={key for key,g in oldgroups.items() if any(row['carId'] in peers for row in g['entries'])}|set(sgroups)
 ck('complete group identities '+k,set(newgroups)==expectedkeys)
 for key,g in newgroups.items():
  og=oldgroups.get(key,{'entries':[]});sg=sgroups.get(key,{'entries':[]});expectedrows=[striprank(row) for row in og['entries'] if row['carId'] in peers]+[striprank(row) for row in sg['entries']]
  ck('complete group entries '+k+str(key),{x['carId']:striprank(x) for x in g['entries']}=={x['carId']:x for x in expectedrows})
  ck('peer relative order '+k+str(key),[x['carId'] for x in g['entries'] if x['carId'] in peers]==[x['carId'] for x in og['entries'] if x['carId'] in peers])
 excluded={x['carId']:x for x in oldr['excluded'] if x['carId'] in peers};excluded.update({x['carId']:x for x in sr['excluded']})
 ck('complete ordered exclusions '+k,newr['excluded']==[excluded[id] for id in a if id in excluded])
 ck('complete unranked content '+k,{x['carId']:x for x in newr['unranked']}=={x['carId']:x for x in oldr['unranked'] if x['carId'] in peers}|{x['carId']:x for x in sr['unranked']})
 ck('peer unranked relative order '+k,[x for x in newr['unranked'] if x['carId'] in peers]==[x for x in oldr['unranked'] if x['carId'] in peers])
 ck('selected ranks exact '+k,{x['carId'] for g in newr['groups'] for x in g['entries'] if x['carId'] in allids}==set(selected['rankCounts'][k]['ranked']))
 for key in ['fullGroupsEqualUnchangedPeersPlusSelected','fullExcludedInCatalogueOrder','fullUnrankedEqualAlphabeticalPeersPlusSelected','fullCarDigestBindingsVerified','peerMembershipAndWithinGroupOrderExact','insertionTiesProvedFromActualInputOrder','selectedCountDeltasExact']:ck('actual rank assertion '+k+key,rank[key])
ck('scope fences',not r['broadFeatureReplay'] and not r['normalFullReportRun'] and r['normalFullReportRequiredAfterGuardedIntegration'] and not r['liveSourceEdits'] and not r['productionRegistration'] and r['defaultLoaderCalls']==0 and r['currentProjectTypeScript'].startswith('UNPASSED'))
res={'status':'PASS_STATIC_FULL_STAGE_OUTPUT_REVIEW','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passedChecks':len(checks),'failedChecks':0,'method':'Read-only output/data/digest/terminal verification; no app imports, hydration, stage rerun or compiler','checks':checks}
(O/'checks.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({k:v for k,v in res.items() if k!='checks'}));print(json.dumps({'processGroupReceipt':group}))
