"""Exact existing Ford source allowance; metadata plus eight small first-time history pins, no capture or scan."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,stat
B=Path('/tmp/ford-packet/source-retention-v1');R=Path('/tmp/ford-research')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
refs=[('/tmp/ford-packet/light-handoff-v1/manifest.json','files'),('/tmp/ford-packet/candidate-v3/manifest.json','files'),('/tmp/ford-packet/candidate-v4/manifest.json','files'),('/tmp/ford-packet/report-comparison-plan-v2/source-pins.json',None)]
declared={};origins={}
for path,key in refs:
 d=read(path);d=d if key is None else d[key]
 for p in d:
  if not p['path'].startswith(str(R)+'/'):continue
  if p['path'] in declared:assert declared[p['path']]==p,p['path']
  declared[p['path']]=p;origins.setdefault(p['path'],[]).append(path)
firstNames=['collect-sources-v1-unrun-missing-requests.py','collect-sources-v1.py','collect-sources-v2.py','factual-captures-v2/my2375-spec.json','factual-captures-v3/my2375-spec.json','residual-v2/epoch-search.txt','residual-v2/full-epoch-pdf-and-price-terms.txt','residual-v2/maker-my2375-full-brochure.txt']
firstPaths={str(R/n) for n in firstNames};assert not firstPaths.intersection(declared)
firstTotal=sum(Path(p).stat().st_size for p in firstPaths);assert firstTotal==77576 and len(firstPaths)==8
rows=[];seen=set();excluded=[]
for current,dirs,files in os.walk(R,followlinks=False):
 dirs.sort();files.sort();assert not any((Path(current)/name).is_symlink() for name in dirs)
 for name in files:
  p=Path(current)/name;s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink();assert p.suffix in ['.py','.json','.txt']
  sp=str(p);assert sp in declared or sp in firstPaths,sp
  fresh=sp in firstPaths
  d=pin(p) if fresh else declared[sp];assert d['bytes']==s.st_size
  rows.append(dict(**d,mode=s.st_mode,mtimeNs=s.st_mtime_ns,pinOrigins=origins.get(sp,['First explicit retention hash of bounded historical preparation/capture']),contentHashRecomputedAtThisPreparation=fresh,role='Superseded source/preparation history only; do not replace current candidate facts' if fresh else 'Retained factual text, source-specific observations, before-state or historical preparation; authority follows exact cited candidate'))
  seen.add(sp)
assert len(rows)==78 and seen==set(declared)|firstPaths
imageProvenance=read(B/'dealer-image-provenance.json')
image=Path(imageProvenance['path']);im=pin(image);s=image.lstat();assert im['sha256']==imageProvenance['sha256'] and im['bytes']==imageProvenance['bytes']
result=dict(schemaVersion=1,status='frozen_exact_source_allowlist_pending_independent_review',preparedAt=datetime.now(timezone.utc).isoformat(),sourceRoot=str(R),sourcePins=sorted(rows,key=lambda x:x['path']),allowlistedResearchFiles=78,priorDeclaredPins=70,firstExplicitHistoricalPins=8,firstExplicitHistoricalBytes=77576,sourceRole='Sanitized rendered public-source excerpts, factual JSON, retained before-state and preserved preparation/failure history; superseded observations retain their original role and are not current replacements.',authoritativeManifests=[pin(p) for p,k in refs],sourceImages=[],independentReviewImages=[dict(file=im,mode=s.st_mode,mtimeNs=s.st_mtime_ns,provenance=imageProvenance,kind='Existing public dealer artwork inspected for whether it contains a price; not an application/browser/phone screenshot',newRenderingPerformed=False)],publicPdfDocuments=0,retainedPublicPdfFiles=0,pdfEvidence='Current and old maker PDF content is retained as web-tool factual/indexed text or exact accepted earlier source anchors; no fresh local PDF bytes are claimed.',rawRuntimeExclusion=dict(rawRuntimeHTMLOrConfigurationPersisted=False,rawResponseHeadersOrCookiesPersisted=False,credentialOrClientKeyPayloadPersisted=False,locallyPresentExcludedOriginalPaths=[],basis='Capture scripts discard scripts/configuration and do not save response headers/cookies; completed direct attempts retained only small failure receipts. Factual captures and web excerpts are text/allowlisted JSON. This is implementation/provenance plus an exact path allowance, not an independent content privacy scan or global absence proof.',readRefetchOrRecoveryAuthorized=False),captureImplementations=[next(x for x in rows if x['path']==str(R/n)) for n in firstNames[:3]],excludedPathsOrClasses=[dict(path='Raw runtime HTML/configuration, response headers, cookies, credentials, tokens and client/API key payloads',reason='Excluded data classes; do not refetch, reconstruct or copy',deletionAuthorized=False)],metadataOnlyInventory=True,payloadHashSweepPerformed=False,targetedFirstTimeHistoricalHashingPerformed=True,targetedHashScope='Eight explicitly named historical source/preparation files totalling 77,576 bytes plus the existing dealer artwork and named metadata receipts; other source payload hashes reused from prior declarations.',payloadCopyOrCompressionPerformed=False,privacyScanClaim=False,productBrowserOrPhoneScreenshots=0,newSourceCaptureAuthorized=False,sourceFilesUnmodified=True,heldHistoryPolicy='Preserve all source/typed/selected/scoped/report/docs versions, original attempts and independent checker failures; old Lightning exclusion is superseded by unresolved v2, not an admission decision.',preparationDiagnostic=pin(B/'preparation-diagnostic-v1.json'),imageProvenance=pin(B/'dealer-image-provenance.json'),preparer=pin(__file__))
with (B/'manifest.json').open('x') as f:json.dump(result,f,indent=2,ensure_ascii=False);f.write('\n')
print(json.dumps(dict(manifest=pin(B/'manifest.json'),allowlistedFiles=78,firstTimeHistoricalBytes=77576,independentImages=1),indent=2))
