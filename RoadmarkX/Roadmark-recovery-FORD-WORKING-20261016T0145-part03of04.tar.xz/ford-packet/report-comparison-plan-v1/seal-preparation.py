"""Seal preparation artifacts only; no producer execution or live writes."""
from pathlib import Path
import ast,json,hashlib
B=Path('/tmp/ford-packet/report-comparison-plan-v1')
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def read(p):return json.loads(Path(p).read_text())
for p in B.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
r=read(B/'syntax-only-receipt.json');assert r['exitCode']==0 and r['runtimeExecuted']is False and r['importsExecuted']is False and r['scriptUnchanged']is True and r['scriptSha256']==pin(B/'compare-report.mjs')['sha256']
c=read(B/'preparation-input-closure.json');assert c['phase']=='preparation'and c['finalLiveAfterFreeze']is False and c['runtimeExecuted']is False
for p in c['files']:assert pin(p['path'])==p,p['path']
assert len(c['retainedStorageFiles'])==21 and len(c['registeredPackets'])==31 and len(c['priceSourcePointerFilenames'])==7
assert pin(B/'run.py')['sha256']==pin('/tmp/nissan-packet/report-comparison-plan-v2/run.py')['sha256']
for name in ['artifacts','normal-coverage-asof-2026-10-15','report-comparison','normal-coverage-asof-2026-10-15.json','report-comparison.json','source-pins.json','sequence.json']:assert not (B/name).exists()
x=dict(schemaVersion=1,status='immutable_preparation_only_pending_independent_review_registration_five_gates_and_final_live_after_freeze',files=[pin(p)for p in sorted(B.iterdir())if p.is_file()],acceptedComparator=pin('/tmp/nissan-packet/report-comparison-plan-v2/compare-report.mjs'),acceptedNissanReportReview=pin('/tmp/nissan-review/report-comparison-v2-results-v1.json'),acceptedNissanNormalReport=pin('/tmp/nissan-packet/report-comparison-plan-v2/normal-coverage-asof-2026-10-15/stdout.log'),fordDefinitiveStageReceipt=pin('/tmp/ford-packet/full-stage-v1/output/stage-receipt.json'),fordStageOutputManifest=pin('/tmp/ford-packet/full-stage-v1/full-stage-result-manifest-v1.json'),fordSelectedOutputReview=pin('/tmp/ford-review/selected-result-v1-review/manifest.json'),preparationInputClosure=pin(B/'preparation-input-closure.json'),currentInputFiles=len(c['files']),retainedStorageLeaves=21,registeredPacketsAtPreparation=31,sourcePointerTargets=7,normalInvocationsSoFar=0,comparatorInvocationsSoFar=0,syntaxOnlyPassed=True,syntaxReceipt=pin(B/'syntax-only-receipt.json'),executionAuthorized=False,liveSourceEdits=False,compilerRetryIncluded=False,fullProjectTypeScript='UNPASSED',releaseAcceptanceClaim=False,finalSourceClosureDeferredUntilActualRegistrationAndFiveGates=True,requiresAcceptedFordFullStageResultReview=True,plannedCommands=2,extraBroadFeatureReplay=False,automaticRetry=False)
with (B/'preparation-manifest-v1.json').open('x')as f:json.dump(x,f,indent=2);f.write('\n')
manifest=pin(B/'preparation-manifest-v1.json')
with (B/'preparation-manifest-v1.sha256').open('x')as f:f.write(manifest['sha256']+'  preparation-manifest-v1.json\n')
print(json.dumps(dict(preparationManifest=manifest,files=len(x['files']),inputFiles=x['currentInputFiles'],syntax=r['exitCode'],comparator=pin(B/'compare-report.mjs'),runtimeExecuted=False),indent=2))
