"""Static imports, saved bytes and named dynamic inputs only. No project execution."""
from pathlib import Path
import re,json,hashlib

def collect(R,B,phase='preparation',transitions=None,postGateDirectory=None):
 R=Path(R);B=Path(B);seen=set();edges=[];external=set();transitions=transitions or {};expectedPins={};cache={}
 def read(p):return json.loads(Path(p).read_text())
 def pin(p):
  p=Path(p);key=str(p)
  if key not in cache:
   h=hashlib.sha256()
   with p.open('rb') as f:
    for b in iter(lambda:f.read(65536),b''):h.update(b)
   cache[key]=dict(path=key,bytes=p.stat().st_size,sha256=h.hexdigest())
  return cache[key]
 def retained(p):
  original=p;replacement=transitions.get(p['path'])
  if replacement:
   after=dict(path=original['path'],bytes=replacement['after']['bytes'],sha256=replacement['after']['sha256'])
   if original!=after:
    assert replacement['before'] is not None
    assert {k:v for k,v in original.items()if k!='path'}==replacement['before'];assert pin(replacement['beforeCopy']['path'])==replacement['beforeCopy']
   p=after
  assert pin(p['path'])==p,('Pinned input drift',p['path'])
  prior=expectedPins.get(p['path']);assert prior is None or prior==p;expectedPins[p['path']]=p;seen.add(Path(p['path']))
 def visit(p):
  p=Path(p).resolve()
  if p in visited:return
  assert p.is_file(),p;visited.add(p);seen.add(p)
  if p.suffix not in ['.ts','.tsx','.mjs','.mts','.js']:return
  text=p.read_text();refs=[]
  for spec in re.findall(r'''(?:\bfrom\s*|\bimport\s*\(?\s*|\brequire\s*\(\s*|\bcompiledSource\s*\(\s*)["']([^"']+)["']''',text):refs.append((spec,'import-or-compiled-source'))
  for spec in re.findall(r'''["']((?:/tmp/|/workspace/)[A-Za-z0-9_./-]+\.(?:json|mjs|ts|tsx|log))["']''',text):refs.append((spec,'absolute-saved-input'))
  for spec in re.findall(r'''repo\s*\+\s*["'](/[^"']+\.(?:ts|tsx|json))["']''',text):refs.append((str(R/spec.lstrip('/')),'repo-source-excerpt'))
  for spec in re.findall(r'''["'](data/[A-Za-z0-9_./-]+\.json)["']''',text):refs.append((spec,'declared-data-read'))
  for spec,kind in refs:
   if spec.startswith('@/'):base=R/'src'/spec[2:]
   elif spec.startswith(('src/','tests/','scripts/','data/')):base=R/spec
   elif spec.startswith(('./src/','./tests/','./scripts/')) and p.parent==B:base=R/spec
   elif spec.startswith('.'):base=(p.parent/spec).resolve()
   elif spec.startswith('/'):base=Path(spec)
   else:external.add(spec);continue
   hit=next((f for f in [base,*[Path(str(base)+x) for x in ['.ts','.tsx','.mjs','.js','.json']],base/'index.ts'] if f.is_file()),None)
   assert hit,('Unresolved comparator input',str(p),spec,kind)
   edges.append(dict(importer=str(p),specifier=spec,kind=kind,resolved=pin(hit)));visit(hit)
 visited=set()
 for p in [B/'compare-report.mjs',R/'scripts/report-coverage.ts',R/'scripts/reporting/load.ts',R/'scripts/reporting/reports.ts']:visit(p)
 stagePath=Path('/tmp/ford-packet/full-stage-v1/manifest.json');stage=read(stagePath)
 assert pin(stagePath)['sha256']=='a032104e62f9735f3c83e071ff3e06dd8331100581093f5b1be9c204f7ac3cc9'
 for p in stage['pins']:retained(p)
 for p in read('/tmp/nissan-packet/report-comparison-plan-v2/source-pins.json'):retained(p)
 for file,key in [('/tmp/ford-packet/full-stage-v1/full-stage-result-manifest-v1.json','files'),('/tmp/ford-packet/selected-readiness-v1/output-manifest.json','files'),('/tmp/nissan-packet/report-comparison-plan-v2/results-manifest-v1.json','files')]:
  seen.add(Path(file))
  for p in read(file)[key]:retained(p)
 closure=read(stage['storageClosure']['path']);assert len(closure)==21
 for p in closure:retained(p)
 registry=R/'data/m1-brand-updates/registry.json';seen.add(registry);packets=read(registry)['packets'];count=31 if phase=='preparation' else 32
 assert len(packets)==count and packets[-1]==('nissan-2026-10-15.json'if phase=='preparation'else'ford-2026-10-15.json')
 for name in packets:seen.add(R/'data/m1-brand-updates'/name)
 inheritedClosure=Path('/tmp/nissan-packet/post-registration-checks-v1/static-input-closure.json');acceptedClosure=read(inheritedClosure);seen.add(inheritedClosure)
 pointerBindings=acceptedClosure['priceSourcePointerBindings'];pointerNames=acceptedClosure['priceSourcePointerFilenames'];assert len(pointerNames)==7
 for row in pointerBindings:retained(row['overlay']);retained(row['resolved'])
 for file in ['/tmp/nissan-review/report-comparison-v2-results-v1.json','/tmp/ford-review/selected-result-v1-review/manifest.json',str(stagePath),stage['storageClosure']['path'],stage['importClosure']['path'],'/tmp/ford-packet/selected-readiness-v1/input-closure.json']:seen.add(Path(file))
 if postGateDirectory:
  P=Path(postGateDirectory)
  for p in read(P/'source-pins.json'):retained(p)
  seen.add(P/'static-input-closure.json')
  postClosure=read(P/'static-input-closure.json');assert postClosure['priceSourcePointerFilenames']==pointerNames
  for row in postClosure['priceSourcePointerBindings']:retained(row['overlay']);retained(row['resolved'])
 generated=[str(B/'normal-coverage-asof-2026-10-15'/name) for name in ['stdout.log','terminal.json','result.json','after-pins.json','scope-verification.json','invocation.json']]
 value=dict(status='static_preparation_closure_not_final_live_after_freeze'if phase=='preparation'else'actual_live_after_static_closure',phase=phase,files=[pin(p)for p in sorted(seen)],edges=sorted(edges,key=lambda x:(x['importer'],x['specifier'],x['kind'])),packageOrNodeSpecifiers=sorted(external),retainedStorageFiles=closure,registeredPackets=packets,sourcePointerClosure=pin(inheritedClosure),priceSourcePointerFilenames=pointerNames,priceSourcePointerBindings=pointerBindings,runtimePackageClosure=pin('/tmp/ford-packet/selected-readiness-v1/input-closure.json'),acceptedNissanNormalResultReview=pin('/tmp/nissan-review/report-comparison-v2-results-v1.json'),fordSelectedReview=pin('/tmp/ford-review/selected-result-v1-review/manifest.json'),fordDefinitiveStageReceipt=pin('/tmp/ford-packet/full-stage-v1/output/stage-receipt.json'),fordStageOutputManifest=pin('/tmp/ford-packet/full-stage-v1/full-stage-result-manifest-v1.json'),generatedNormalInputs=generated,generatedNormalBinding='After one successful real report only: comparator validates terminal stdout hash, positive wrapper result against frozen command hash, after-pins and all six actual generated files before/after.',dynamicReadBindings=['21 retained storage leaves are explicit accepted anchor/descriptor inputs; complete car reconstruction uses saved replacements through Nissan31','Three prior Ford rows and207 raw feature rows are streamed from14 retained descriptors; no peer effective features','Current registry packet JSON, sourcePointer targets, regrading JSON and compiledSource targets are named and hashed','Installed TypeScript/tsx/esbuild closure and binaries retained from accepted Nissan and Ford selected closures; no project compiler execution','Exactly registry/load.ts may transition under accepted four-file registration; two new targets must equal accepted Ford bytes; final freeze requires actual readback and five gates'],runtimeExecuted=False,finalLiveAfterFreeze=phase!='preparation',pending=['accepted full-stage result review','authorized registration and exact live readback','five accepted serial scoped gates','final live-after reclosure','independent command review','root exclusive execution grant']if phase=='preparation'else[])
 target=B/('preparation-input-closure.json'if phase=='preparation'else'comparator-input-closure.json')
 with target.open('x')as f:json.dump(value,f,indent=2);f.write('\n')
 return value['files']
if __name__=='__main__':
 assert __import__('sys').argv[1:]==['--preparation-only']
 files=collect('/workspace/scratch/586427eef9f2/roadmark-104','/tmp/ford-packet/report-comparison-plan-v1');print(json.dumps(dict(status='preparation_only',files=len(files),runtimeExecuted=False)))
