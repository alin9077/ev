"""Deferred static final freeze only, after actual registration/readback and five gates.
No command executes here. Independent review and a separate exclusive root grant remain mandatory.
"""
from pathlib import Path
import hashlib,json,sys,ast,runpy
R=Path('/workspace/scratch/586427eef9f2/roadmark-104');B=Path('/tmp/ford-packet/report-comparison-plan-v2')
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def check(p):assert pin(p['path'])==p,p['path']
def read(p):return json.loads(Path(p).read_text())
def write(n,x):
 with (B/n).open('x')as f:json.dump(x,f,indent=2);f.write('\n')
assert len(sys.argv)==6,'prepare-manifests.py FIVE_GATE_DIRECTORY REGISTRATION_DIRECTORY FIVE_GATE_ACCEPTANCE LIVE_REGISTRATION_ACCEPTANCE FULL_STAGE_RESULT_ACCEPTANCE'
P,A=map(Path,sys.argv[1:3]);fivepin,registration,stageAcceptance=map(pin,sys.argv[3:6])
five=read(fivepin['path']);assert five['status']=='accepted';live=read(registration['path']);assert live['status']=='accepted'
# Accept only the reviewed Ford32 result receipt, or its exact containing manifest.
acceptedStageReview=Path('/tmp/ford-review/full-stage-v1-result-review/review.json')
acceptedStageReviewManifest=Path('/tmp/ford-review/full-stage-v1-result-review/manifest.json')
assert pin(acceptedStageReview)['sha256']=='e6e355d2e2023aadc09ae754da4f8a6a3e94e4d1aa01b10b4c2b6a4473d5dd8e'
assert pin(acceptedStageReviewManifest)['sha256']=='b0976c09fd6ccad290a22d7dfd69bea8a42538d48f34c0bec558d7fe8a8f5d0a'
assert stageAcceptance in [pin(acceptedStageReview),pin(acceptedStageReviewManifest)],'Wrong full-stage acceptance receipt'
reviewManifest=read(acceptedStageReviewManifest)
assert reviewManifest['status']=='PASS_BOUNDED_FULL_STAGE_RESULT_REVIEW_ONLY'
assert pin(acceptedStageReview) in reviewManifest['files']
for row in reviewManifest['files']:check(row)
review=read(acceptedStageReview)
assert review['status']=='PASS_BOUNDED_FULL_STAGE_RESULT_REVIEW_ONLY'
assert review['preparedManifestSha256']=='a032104e62f9735f3c83e071ff3e06dd8331100581093f5b1be9c204f7ac3cc9'
assert pin('/tmp/ford-packet/full-stage-v1/manifest.json')['sha256']==review['preparedManifestSha256']
assert review['resultManifest']=='/tmp/ford-packet/full-stage-v1/full-stage-result-manifest-v1.json'
assert review['resultManifestSha256']=='c467702e0a5f97993e5ada23de10d98d6aa092c321e49451f1dc334b257a7c02'
assert pin(review['resultManifest'])['sha256']==review['resultManifestSha256']
assert review['definitiveStageReceipt']=='/tmp/ford-packet/full-stage-v1/output/stage-receipt.json'
assert review['stageReceiptSha256']=='5b19f01990ab6096f77c81270d5bbc24b0a229a96a87d194d1657d673f5000bc'
assert pin(review['definitiveStageReceipt'])['sha256']==review['stageReceiptSha256']
stageOutputs=read(review['resultManifest']);stageReceipt=read(review['definitiveStageReceipt'])
assert stageOutputs['preparedManifestSha256']==review['preparedManifestSha256']
assert stageOutputs['definitiveReceipt']==pin(review['definitiveStageReceipt'])
assert stageReceipt['manifestSha256']==review['preparedManifestSha256']
assert stageReceipt['packetSha256']=='8d728412f21a36aac152357d04793fd38b5efc47438e5210af610f72e868ce00'
assert [stageReceipt['stagedCars'],stageReceipt['tierOneVersions'],stageReceipt['onSaleVersions']]==[433,356,314]
assert review['processGroupEmpty'] is True and review['terminal']['exitCode']==0
for row in stageOutputs['files']:check(row)
preparation=read(B/'preparation-manifest-v2.json')
for row in preparation['files']:check(row)
assert preparation['normalInvocationsSoFar']==0 and preparation['comparatorInvocationsSoFar']==0
syntax=read(B/'syntax-only-receipt.json');assert syntax['exitCode']==0 and syntax['runtimeExecuted']is False and syntax['importsExecuted']is False and syntax['scriptSha256']==pin(B/'compare-report.mjs')['sha256']
sequencePin=pin(P/'sequence.json');sequence=read(sequencePin['path']);assert len(sequence['sequence'])==5 and sequence['compilerIncluded']is False
expectedNames=['market-view','changed-file-lint','behavioural-suites','live-brand-safety','structural-validation']
# The independent acceptance must name this exact final Ford sequence and its actual five outputs.
assert five['sequence']==sequencePin,'Five-gate acceptance belongs to a different sequence'
assert five['registrationVerification']==registration,'Five-gate acceptance used a different registration readback'
assert five['allFiveScopedGatesPassed']is True and five['strictSerialInvocations']is True
assert five['failed']==five['cancelled']==five['skipped']==five['todo']==0
assert five['remainingProcesses']==[]
assert len(five['gates'])==5 and [gate['id']for gate in five['gates']]==expectedNames
assert five['resultManifest']==pin(P/'results-manifest-v1.json')
fiveOutputs=read(five['resultManifest']['path']);assert fiveOutputs['sequence']==sequencePin
assert len(fiveOutputs['checks'])==5 and [gate['name']for gate in fiveOutputs['checks']]==expectedNames
for output in fiveOutputs['files']:check(output)
assert len({output['path']for output in fiveOutputs['files']})==len(fiveOutputs['files'])
check(five['terminalSlotRelease'])
assert fiveOutputs['rootGrants']==five['rootGrants']
for grant in five['rootGrants']:check(grant)
proofs={}
def add(p):
 x=pin(p)
 if x['path']in proofs:assert proofs[x['path']]==x
 proofs[x['path']]=x
for p in [fivepin['path'],registration['path'],stageAcceptance['path'],A/'application/result.json',A/'manifest.json',P/'sequence.json',B/'preparation-manifest-v2.json',*[(B/n)for n in ['PLAN.md','compare-report.mjs','compose-comparator.py','nissan-to-ford-comparator.patch','check-syntax.py','syntax-only-receipt.json','syntax-only-stdout.log','syntax-only-stderr.log','prepare-manifests.py','close-comparator-inputs.py','preparation-input-closure.json','expected-deltas.json']]]:add(p)
for row in reviewManifest['files']:add(row['path'])
for p in [acceptedStageReview,acceptedStageReviewManifest,review['resultManifest'],review['definitiveStageReceipt'],five['resultManifest']['path'],five['terminalSlotRelease']['path']]:add(p)
for row in stageOutputs['files']+fiveOutputs['files']+five['rootGrants']:add(row['path'])
prerequisites=[]
for expected,row,acceptedGate,outputGate in zip(expectedNames,sequence['sequence'],five['gates'],fiveOutputs['checks']):
 check(row);m=read(row['path']);assert m['id']==expected
 d=P/'run'/expected;r=read(d/'result.json');t=read(d/'terminal.json');assert r['passed']is True and r['exitCode']==t['exitCode']==0 and r['manifestSha256']==row['sha256']
 assert acceptedGate['manifest']==outputGate['manifest']==row
 assert acceptedGate['result']==outputGate['result']==pin(d/'result.json')
 assert acceptedGate['terminal']==outputGate['terminal']==pin(d/'terminal.json')
 assert outputGate['passed']is True and outputGate['exitCode']==0
 assert r['pinsPassed']is True and r['scopePassed']is True and r['automaticRetry']is False
 assert read(d/'after-pins.json')['passed']is True and read(d/'scope-verification.json')['passed']is True
 assert t['watchdogFired']is False and t['stdoutSha256']==pin(d/'stdout.log')['sha256'] and t['stderrSha256']==pin(d/'stderr.log')['sha256']
 assert pin(d/'stderr.log')['bytes']==0
 assert read(d/'invocation.json')['manifestSha256']==row['sha256']
 for name in ['result.json','terminal.json','after-pins.json','scope-verification.json','stdout.log','stderr.log','invocation.json','registration-target-metadata-before.json']:
  assert pin(d/name) in fiveOutputs['files'],('Gate output missing accepted result-manifest binding',expected,name)
 add(row['path'])
 for name in ['result.json','terminal.json','after-pins.json','scope-verification.json','stdout.log','stderr.log','invocation.json','registration-target-metadata-before.json']:add(d/name)
 prerequisites.append(dict(manifest=row,resultPath=str(d/'result.json')))
base=read(P/'structural-validation.json');assert base['registrationManifest']==pin(A/'manifest.json')
assert base['registrationManifest']['sha256']=='6a7c6bfca208eb5940eba4cb6adfd52a2b55a97ca0802ef1f495c706feee58eb'
assert sequence['registrationManifest']==base['registrationManifest']
assert live['manifestSha256']==base['registrationManifest']['sha256'] and live['allFourLiveHashesAndBytesMatchAcceptedPayloads']is True
check(live['applicationReceipt']);application=read(live['applicationReceipt']['path']);assert application['passed']is True and application['manifestSha256']==base['registrationManifest']['sha256']
transitions={w['target']:w for w in read(A/'manifest.json')['writes']}
assert list(transitions)==[str(R/p)for p in ['data/m1-brand-updates/registry.json','scripts/reporting/load.ts','data/m1-brand-updates/ford-2026-10-15.json','data/m1-ford-market-reconciliation-2026-10-15.json']]
for w in transitions.values():
 check(w['after']);check(dict(path=w['target'],bytes=w['after']['bytes'],sha256=w['after']['sha256']))
assert [w['before']is None for w in transitions.values()]==[False,False,True,True]
assert transitions[str(R/'data/m1-brand-updates/ford-2026-10-15.json')]['after']['sha256']=='8d728412f21a36aac152357d04793fd38b5efc47438e5210af610f72e868ce00'
assert transitions[str(R/'data/m1-ford-market-reconciliation-2026-10-15.json')]['after']['sha256']=='07531bcbe9d57c9b89647313ced205a60a899dc2aa6c4655db161fec1debdf39'
assert len(base['registrationTargets'])==4
for target in base['registrationTargets']:check(target)
failure=Path('/tmp/kgm-packet/report-comparison-v2/typescript-failure-provenance.json');failureData=read(failure);assert failureData['fullProjectTypecheckPassed']is False;add(failure)
for p in failureData['proofPins']:check(p);add(p['path'])
for attempt in failureData['attempts']:
 assert attempt['exitCode']==-9 and attempt['cause']=='unknown' and attempt['fullProjectTypecheckPassed']is False
 assert not Path(attempt['freshCachePath']).exists()
write('typescript-failure-context.json',dict(status='current_full_project_typescript_unpassed',failureProvenance=pin(failure),attempts=failureData['attempts'],compilerRetriesAuthorized=False,releaseAcceptanceClaim=False,currentFiveGateAcceptance=fivepin,scope='Independent factual report/comparison only; metadata guards do not imply TypeScript success.'));add(B/'typescript-failure-context.json')
files=runpy.run_path(str(B/'close-comparator-inputs.py'))['collect'](R,B,'final',transitions,P)
write('source-pins.json',files)
changed=[]
for original in read('/tmp/ford-packet/full-stage-v1/manifest.json')['pins']:
 if original['path']in transitions:
  w=transitions[original['path']];assert w['before']is not None and {k:v for k,v in original.items()if k!='path'}==w['before']
  changed.append(dict(historical=original,retainedBefore=w['beforeCopy'],current=dict(path=w['target'],bytes=w['after']['bytes'],sha256=w['after']['sha256'])))
assert sorted(Path(x['current']['path']).name for x in changed)==['load.ts','registry.json']
write('source-transition-provenance.json',dict(stageManifest=pin('/tmp/ford-packet/full-stage-v1/manifest.json'),registrationManifest=pin(A/'manifest.json'),onlyHistoricalLiveInputTransitions=changed,allOtherStagePinsUnchanged=True,newTargets=[p for p in base['registrationTargets']if transitions[p['path']]['before']is None]))
for p in [B/'comparator-input-closure.json',B/'source-transition-provenance.json','/tmp/ford-packet/full-stage-v1/full-stage-result-manifest-v1.json','/tmp/ford-packet/selected-readiness-v1/output-manifest.json','/tmp/nissan-review/report-comparison-v2-results-v1.json']:add(p)
for key in ['id','kind','command','timeoutSeconds','expectedStructuralCounts','expectedSourceReferences','expectedPublicationIssues','expectedApprovedExternalAssets','immutableResearchSha256','runOutput','prerequisites','extraPins']:base.pop(key,None)
assert pin(B/'run.py')['sha256']==pin(P/'run.py')['sha256'],'Post-gate supervisor changed; independently review before adjusting report supervisor'
base.update(qaRoot=str(B),sourcePins=pin(B/'source-pins.json'),wrapper=pin(B/'run.py'),fullProjectTypecheckPassed=False,releaseAcceptanceClaim=False,independentCoverageException=pin(B/'typescript-failure-context.json'))
commonProofs=[proofs[k]for k in sorted(proofs)]
normal=dict(base,id='normal-coverage-asof-2026-10-15',kind='normal-report',command=['/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','--max-old-space-size=448','--max-semi-space-size=1','--import','tsx','scripts/report-coverage.ts','--as-of','2026-10-15','--json'],timeoutSeconds=900,runOutput=str(B/'normal-coverage-asof-2026-10-15'),prerequisites=prerequisites,extraPins=commonProofs,expectedReportCounts=[433,356,314],asOf='2026-10-15')
write('normal-coverage-asof-2026-10-15.json',normal)
comparison=dict(base,id='report-comparison',kind='comparison',command=['/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','--max-old-space-size=448','--max-semi-space-size=1','--import','tsx',str(B/'compare-report.mjs')],timeoutSeconds=180,runOutput=str(B/'report-comparison'),comparisonResult=str(B/'artifacts/result.json'),prerequisites=[dict(manifest=pin(B/'normal-coverage-asof-2026-10-15.json'),resultPath=str(B/'normal-coverage-asof-2026-10-15/result.json'))],extraPins=commonProofs)
write('report-comparison.json',comparison)
seq=dict(status='frozen_not_executed_requires_review_and_root_grant',sequence=[pin(B/'normal-coverage-asof-2026-10-15.json'),pin(B/'report-comparison.json')],sourcePins=base['sourcePins'],rootMetadata=base['rootMetadata'],qaRoot=str(B),registrationManifest=base['registrationManifest'],registrationTargets=base['registrationTargets'],normalReportRuns=1,normalReportSubstitutionAllowed=False,acceptedFiveChecksAndRegistrationRequired=True,fullProjectTypecheckPassed=False,releaseAcceptanceClaim=False,compilerRetryIncluded=False,independentCoverageException=base['independentCoverageException'],noAutomaticRetry=True,extraBroadFeatureReplay=False,coreReasonReconstruction='Actual coreCoverage over complete digest-verified cars/sources; three prior selected packs207 rows plus six accepted after packs414 rows; no peer feature replay',executionAuthorized=False)
write('sequence.json',seq)
g=read(P/'root-grant-template.json');g.update(sequence=pin(B/'sequence.json'),granted=seq['sequence'],reviewerAcceptance=None,registrationVerification=registration,fullProjectTypecheckPassed=False,releaseAcceptanceClaim=False);assert g['status']=='NOT_GRANTED'and g['heavySlotExclusive']is False;write('root-grant-template.json',g)
for m in [normal,comparison]:
 for p in [m['wrapper'],m['sourcePins'],m['rootMetadata'],m['testInventory'],m['registrationManifest'],*files,*m['extraPins']]:check(p)
for p in [B/'normal-coverage-asof-2026-10-15',B/'report-comparison',B/'artifacts']:assert not p.exists()
write('static-verification.json',dict(status='prepared_not_executed',sequence=pin(B/'sequence.json'),sourcePinCount=len(files),extraProofPins=len(proofs),all21RetainedStorageLeavesClosed=True,allStageAndSelectedOutputManifestLeavesClosed=True,onlyAcceptedTwoExistingLiveTransitions=True,twoNewTargetsExact=True,wrapperByteIdenticalToFiveGateWrapper=True,currentProjectTypeScript='UNPASSED',compilerRetriesIncluded=False,onlyPlannedHeavyExecutions=['one normal report','one saved-output comparator'],normalLimits='448/1 MiB;900+10 seconds',comparatorLimits='448/1 MiB;180+10 seconds'))
print(json.dumps(dict(sequence=pin(B/'sequence.json'),normal=pin(B/'normal-coverage-asof-2026-10-15.json'),comparison=pin(B/'report-comparison.json'),sourcePinCount=len(files),extraProofPins=len(proofs)),indent=2))
