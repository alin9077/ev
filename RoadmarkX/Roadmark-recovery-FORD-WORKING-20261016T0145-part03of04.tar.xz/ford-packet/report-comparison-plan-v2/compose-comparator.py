"""Bounded text composition from the accepted Nissan comparator; no imports or runtime."""
from pathlib import Path
import hashlib,difflib,ast
O=Path('/tmp/ford-packet/report-comparison-plan-v2');N=Path('/tmp/nissan-packet/report-comparison-plan-v2')
old=(N/'compare-report.mjs').read_text()
assert hashlib.sha256(old.encode()).hexdigest()=='6de62b99383d8197a1a3b6d4509e2f92824b697aa0c085b9a4164a0ecd005283'
s=old
# Keep every historical replacement through Renault, then append the actual accepted Nissan replacement.
s=s.replace(str(N),str(O))
s=s.replace('/tmp/renault-packet/report-comparison-v4/normal-coverage-asof-2026-10-15/stdout.log',str(N/'normal-coverage-asof-2026-10-15/stdout.log'))
s=s.replace('093e0d243e89173bd39d03d8f5e1948c550df09d37b435b018213f895b9894a6','61b497fb9f1e1f7683b07e9040638c781ff4e8c597ca507f9afd5b2205ad9768')
s=s.replace('/tmp/nissan-packet/selected-preflight-v4/','/tmp/ford-packet/selected-readiness-v1/').replace('/tmp/nissan-research/retained-before-cars-v1.json','/tmp/ford-research/retained-before-cars-v1.json')
s=s.replace('/tmp/nissan-packet/full-stage-v1/','/tmp/ford-packet/full-stage-v1/')
s=s.replace('/tmp/renault-packet/full-stage-v1/output/car-digest-comparison.json','/tmp/nissan-packet/full-stage-v1/output/car-digest-comparison.json')
s=s.replace('/tmp/renault-packet/full-stage-v1/output/research-field-digests.json','/tmp/nissan-packet/full-stage-v1/output/research-field-digests.json')
s=s.replace('acceptedRenaultDigests','acceptedNissanDigests')
s=s.replace('candidate31','CANDIDATE32').replace('candidate30','candidate31').replace('CANDIDATE32','candidate32')
# Restore the historical Renault replacement stage key changed by the token progression.
s=s.replace("['candidate31','/tmp/renault-packet/full-stage-v1/output/selected-after-cars.json'],","['candidate30','/tmp/renault-packet/full-stage-v1/output/selected-after-cars.json'],\n ['candidate31','/tmp/nissan-packet/full-stage-v1/output/selected-after-cars.json'],")
s=s.replace('Nissan','Ford').replace('nissanInventory','fordInventory').replace('oldFord','oldFord').replace('liveFord','liveFord').replace('expectedLiveFord','expectedLiveFord').replace('newFord','newFord')
# Prior Nissan stage is intentionally retained, rather than renamed as Ford.
s=s.replace('acceptedFordDigests','acceptedNissanDigests')
s=s.replace('One saved normal report versus accepted Renault30; exact core reasons and four selected prior Ford packs.','One saved normal report versus accepted Nissan31; exact core reasons, three prior Ford packs and three added residual cars.')
s=s.replace('exhaustive-normal-versus-renault-diff','exhaustive-normal-versus-nissan-diff')
s=s.replace("'m1-nissan-2026-10-15'","'m1-ford-2026-10-15'")
s=s.replace('assert.equal(selectedIds.size,4);','const addedIds=new Set(after.filter(car=>!selectedIds.has(car.id)).map(car=>car.id)),allSelectedIds=new Set(after.map(car=>car.id));\nassert.equal(selectedIds.size,3);assert.equal(addedIds.size,3);assert.equal(allSelectedIds.size,6);')
s=s.replace('selectedResult.selectedFeatureClaims,276','selectedResult.selectedFeatureClaims,414').replace('6aa651b6932721365dfdee38c92fd19d9dd62cf50cb42ec6c348d495f00c9585','8d728412f21a36aac152357d04793fd38b5efc47438e5210af610f72e868ce00')
a=s.index('const acceptedSelectedPacks=');b=s.index('const selectedSnapshots=',a)
s=s[:a]+'''const acceptedSelectedPacks=readJson('/tmp/ford-packet/selected-readiness-v1/selected-packs.json'),canonicalProjectionProof=[];
assert.equal(selectedResult.roadsideRefreshes,6);assert.equal(selectedResult.driveawayRefreshes,2);
assert.deepEqual(packs,acceptedSelectedPacks);
for(const car of after){
 const acceptedPack=acceptedSelectedPacks[car.id],pack=packs[car.id];assert(acceptedPack&&pack);assert.deepEqual(car,pack.car);
 const criteria=[['roadside_assistance','roadside_assistance']];
 if(addedIds.has(car.id)&&car.facts.price_aud.value!==null)criteria.push(['driveaway_price','price_aud']);
 for(const [criterion,factKey]of criteria){
  const fact=car.facts[factKey],feature=pack.features.find(row=>row.criterion===criterion),acceptedFeature=acceptedPack.features.find(row=>row.criterion===criterion);
  assert(fact&&feature&&acceptedFeature);assert.deepEqual(fact,acceptedPack.car.facts[factKey]);assert.deepEqual(feature,acceptedFeature);assert.deepEqual(feature.source_ids,fact.sourceIds);
  for(const condition of fact.qualifications)assert(feature.conditions.includes(condition));
  if(criterion==='roadside_assistance'){
   assert.equal(feature.value,String(fact.value));assert.equal(feature.buyerGrade,'confirmed');assert.equal(feature.status,'standard');assert.equal(feature.verification_state,'reviewed_brand_au_terms');
  }else{
   assert.equal(fact.comparisonBasis,'Driveaway');assert.equal(feature.value,`A$${Number(fact.value).toLocaleString('en-AU')}`);assert.equal(feature.buyerGrade,'reported');assert.equal(feature.verification_state,'reviewed_canonical_driveaway_price');
  }
  canonicalProjectionProof.push({variantId:car.id,criterion,factKey,acceptedFactAndFeatureExact:true,sourceIds:fact.sourceIds,value:feature.value,buyerGrade:feature.buyerGrade,conditions:feature.conditions,validUntil:feature.validUntil??null});
 }
}
assert.equal(canonicalProjectionProof.length,8);write('canonical-replacement-projection-proof',canonicalProjectionProof);
''' + s[b:]
s=s.replace('acceptedStageDigests.candidate32.length,430','acceptedStageDigests.candidate32.length,433')
s=s.replace('candidate32.filter(c=>!selectedIds.has(c.id))','candidate32.filter(c=>!allSelectedIds.has(c.id))')
s=s.replace('oldPeerDigests.length,426','oldPeerDigests.length,427').replace('exactCompletePeerCars:426','exactCompletePeerCars:427')
s=s.replace('base.variants.length,4','base.variants.length,3').replace('base.feature_evidence.length,276','base.feature_evidence.length,207')
s=s.replace('brandUpdatePackets.length,31','brandUpdatePackets.length,32').replace('brandUpdatePackets.slice(0,30)','brandUpdatePackets.slice(0,31)')
s=s.replace('const afterMap=new Map(after.map(car=>[car.id,car])),completeAfter=completeBefore.map(car=>afterMap.get(car.id)??car);','const afterMap=new Map(after.map(car=>[car.id,car])),completeAfter=[...completeBefore.map(car=>afterMap.get(car.id)??car),...after.filter(car=>addedIds.has(car.id))];\nassert.equal(completeAfter.length,433);assert.deepEqual(completeAfter.slice(-3).map(car=>car.id),[...addedIds]);')
s=s.replace('beforeFeatures.length,276','beforeFeatures.length,207')
s=s.replace("new Set(['roadside_assistance','driveaway_price'])","new Set(['roadside_assistance'])")
s=s.replace('unchangedRetainedFeatureRows,268','unchangedRetainedFeatureRows,204')
s=s.replace("const peer=(rows,key='carId')=>rows.filter(r=>!selectedIds.has(r[key]));","const peer=(rows,key='carId')=>rows.filter(r=>!allSelectedIds.has(r[key]));")
s=s.replace("const deep=(rows,key='carId')=>rows.filter(r=>selectedIds.has(r[key]));","const deep=(rows,key='carId')=>rows.filter(r=>allSelectedIds.has(r[key]));")
s=s.replace('new Map(completeBefore.map((car,index)=>[car.id,index]))','new Map(completeAfter.map((car,index)=>[car.id,index]))')
s=s.replace('assert.equal(catalogueOrder.size,430);assert.deepStrictEqual(completeAfter.map(car=>car.id),completeBefore.map(car=>car.id));','assert.equal(catalogueOrder.size,433);assert.deepStrictEqual(completeAfter.map(car=>car.id),[...completeBefore.map(car=>car.id),...addedIds]);')
s=s.replace('const expected=structuredClone(baseline);','const expected={...structuredClone(baseline),allCatalogueVersions:433,tierOneVersions:356,onSaleVersions:314};\nassert.deepEqual([baseline.allCatalogueVersions,baseline.tierOneVersions,baseline.onSaleVersions],[430,353,312]);')
s=s.replace('normal.onSaleVersions],[430,353,312]','normal.onSaleVersions],[433,356,314]')
s=s.replace('onSaleAfter.length,312','onSaleAfter.length,314')
s=s.replace('assert.equal(next.total,old.total);','assert.equal(next.total,old.total-b.total+a.total);assert.equal(next.total,314);')
# Complete ranking proofs include all six selected identities, while normal report projects only five on-sale ones.
start=s.index('const stageRankings=');end=s.index("write('ranking-group-order-and-peer-proof'",start)
chunk=s[start:end].replace('!selectedIds.has(row.carId)','!allSelectedIds.has(row.carId)')
chunk=chunk.replace('projectRecords(stage.completeSelectedRecords,after)','projectRecords(stage.completeSelectedRecords,after.filter(reports.isOnSale))')
chunk=chunk.replace('a.excluded.length,312','a.excluded.length,314').replace('pct(a.rankedIds.length,312)','pct(a.rankedIds.length,314)').replace('a.rankedIds.length/312','a.rankedIds.length/314')
s=s[:start]+chunk+s[end:]
s=s.replace('peerCompleteCarDigestsExact:426','peerCompleteCarDigestsExact:427').replace('selectedOldFeatureProducers:276','selectedOldFeatureProducers:207').replace('counts:{catalogue:430,tierOne:353,onSale:312}','counts:{catalogue:433,tierOne:356,onSale:314}')
s=s.replace('const c1=readJson(',"const c1=readJson(")
# Explicit binding of definitive full-stage receipt and conservative current-list scope.
a=s.index('const selectedResult=')
s=s[:a]+'''const stageReceipt=readJson('/tmp/ford-packet/full-stage-v1/output/stage-receipt.json');
assert.equal(fileHash('/tmp/ford-packet/full-stage-v1/output/stage-receipt.json'),'5b19f01990ab6096f77c81270d5bbc24b0a229a96a87d194d1657d673f5000bc');
assert.deepEqual(stageReceipt.globalC1Counts,{reviewedModels:107,reviewedVersions:245,issues:186,settledInventory:65,pass:false});
assert.equal(stageReceipt.normalFullReportRun,false);assert.equal(stageReceipt.untouchedPeerCars,427);
''' + s[a:]
s=s.replace("assert.deepEqual(baseline.reconciliation,c1.before);expected.reconciliation=c1.after;","assert.deepEqual(baseline.reconciliation,c1.before);assert.deepEqual(c1.after,c1.expectedCompleteAfter);assert.equal(c1.after.pass,false);assert.equal(c1.after.reviewedModels,107);assert.equal(c1.after.reviewedVersions,245);assert.equal(c1.after.issues.length,186);assert.equal(c1.after.settledInventory.length,65);expected.reconciliation=c1.after;")
assert 'selected-preflight' not in s and 'candidate30.length' not in s
with (O/'compare-report.mjs').open('x') as f:f.write(s)
with (O/'nissan-to-ford-comparator.patch').open('x') as f:f.write(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile=str(N/'compare-report.mjs'),tofile=str(O/'compare-report.mjs'))))
with (O/'run.py').open('xb') as f:f.write((N/'run.py').read_bytes())
check=(N/'check-syntax.py').read_text().replace(str(N),str(O)).replace('this Nissan comparator','this Ford comparator')
with (O/'check-syntax.py').open('x') as f:f.write(check)
for p in O.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
print('Composed Ford comparator and byte-identical accepted supervisor; no project imports or runtime')
