"""Preserve v1 and tighten only deferred receipt binding in an immutable successor."""
from pathlib import Path
import hashlib,json,ast,difflib
P=Path('/tmp/ford-packet/report-comparison-plan-v1');B=Path('/tmp/ford-packet/report-comparison-plan-v2')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
prior=pin(P/'preparation-manifest-v1.json');assert prior['sha256']=='7650581628020fb25410994aef945b626bfb70e33764f09b9b6cebe2926e8593'
for p in json.loads((P/'preparation-manifest-v1.json').read_text())['files']:assert pin(p['path'])==p
for name in ['PLAN.md','compose-comparator.py','compare-report.mjs','run.py','check-syntax.py','close-comparator-inputs.py','prepare-manifests.py','prepare-expectations.py','seal-preparation.py']:
 s=(P/name).read_text().replace(str(P),str(B))
 if name in ['prepare-manifests.py','seal-preparation.py']:s=s.replace('preparation-manifest-v1','preparation-manifest-v2')
 with (B/name).open('x')as f:f.write(s)
p=B/'prepare-manifests.py';s=p.read_text()
old="""five=read(fivepin['path']);assert five['status']=='accepted';live=read(registration['path']);assert live['status']=='accepted'
review=read(stageAcceptance['path']);assert review['status']=='accepted' or review['status'].startswith('PASS_')
for row in review.get('files',[]):check(row)"""
new="""five=read(fivepin['path']);assert five['status']=='accepted';live=read(registration['path']);assert live['status']=='accepted'
# Accept only the reviewed Ford32 result receipt, or its exact containing manifest.
acceptedStageReview=Path('/tmp/ford-review/full-stage-v1-result-review/review.json')
acceptedStageReviewManifest=Path('/tmp/ford-review/full-stage-v1-result-review/manifest.json')
assert pin(acceptedStageReview)['sha256']=='e6e355d2e2023aadc09ae754da4f8a6a3e94e4d1aa01b10b4c2b6a4473d5dd8e'
assert pin(acceptedStageReviewManifest)['sha256']=='b0976c09fd6ccad290a22d7dfd69bea8a42538d48f34c0bec558d7fe8a8f5d0a'
assert stageAcceptance in [pin(acceptedStageReview),pin(acceptedStageReviewManifest)],'Wrong full-stage acceptance receipt'
reviewManifest=read(acceptedStageReviewManifest)
assert reviewManifest['status']=='PASS_BOUNDED_FULL_STAGE_RESULT_REVIEW_ONLY'
assert pin(acceptedStageReview) in reviewManifest['files']
for row in reviewManifest['files']:check(row)
review=read(acceptedStageReview)
assert review['status']=='PASS_BOUNDED_FULL_STAGE_RESULT_REVIEW_ONLY'
assert review['preparedManifestSha256']=='a032104e62f9735f3c83e071ff3e06dd8331100581093f5b1be9c204f7ac3cc9'
assert pin('/tmp/ford-packet/full-stage-v1/manifest.json')['sha256']==review['preparedManifestSha256']
assert review['resultManifest']=='/tmp/ford-packet/full-stage-v1/full-stage-result-manifest-v1.json'
assert review['resultManifestSha256']=='c467702e0a5f97993e5ada23de10d98d6aa092c321e49451f1dc334b257a7c02'
assert pin(review['resultManifest'])['sha256']==review['resultManifestSha256']
assert review['definitiveStageReceipt']=='/tmp/ford-packet/full-stage-v1/output/stage-receipt.json'
assert review['stageReceiptSha256']=='5b19f01990ab6096f77c81270d5bbc24b0a229a96a87d194d1657d673f5000bc'
assert pin(review['definitiveStageReceipt'])['sha256']==review['stageReceiptSha256']
stageOutputs=read(review['resultManifest']);stageReceipt=read(review['definitiveStageReceipt'])
assert stageOutputs['preparedManifestSha256']==review['preparedManifestSha256']
assert stageOutputs['definitiveReceipt']==pin(review['definitiveStageReceipt'])
assert stageReceipt['manifestSha256']==review['preparedManifestSha256']
assert stageReceipt['packetSha256']=='8d728412f21a36aac152357d04793fd38b5efc47438e5210af610f72e868ce00'
assert [stageReceipt['stagedCars'],stageReceipt['tierOneVersions'],stageReceipt['onSaleVersions']]==[433,356,314]
assert review['processGroupEmpty'] is True and review['terminal']['exitCode']==0
for row in stageOutputs['files']:check(row)"""
assert old in s;s=s.replace(old,new)
old="""sequence=read(P/'sequence.json');assert len(sequence['sequence'])==5 and sequence['compilerIncluded']is False
expectedNames=['market-view','changed-file-lint','behavioural-suites','live-brand-safety','structural-validation']"""
new="""sequencePin=pin(P/'sequence.json');sequence=read(sequencePin['path']);assert len(sequence['sequence'])==5 and sequence['compilerIncluded']is False
expectedNames=['market-view','changed-file-lint','behavioural-suites','live-brand-safety','structural-validation']
# The independent acceptance must name this exact final Ford sequence and its actual five outputs.
assert five['sequence']==sequencePin,'Five-gate acceptance belongs to a different sequence'
assert five['registrationVerification']==registration,'Five-gate acceptance used a different registration readback'
assert five['allFiveScopedGatesPassed']is True and five['strictSerialInvocations']is True
assert five['failed']==five['cancelled']==five['skipped']==five['todo']==0
assert five['remainingProcesses']==[]
assert len(five['gates'])==5 and [gate['id']for gate in five['gates']]==expectedNames
assert five['resultManifest']==pin(P/'results-manifest-v1.json')
fiveOutputs=read(five['resultManifest']['path']);assert fiveOutputs['sequence']==sequencePin
assert len(fiveOutputs['checks'])==5 and [gate['name']for gate in fiveOutputs['checks']]==expectedNames
for output in fiveOutputs['files']:check(output)
assert len({output['path']for output in fiveOutputs['files']})==len(fiveOutputs['files'])
check(five['terminalSlotRelease'])
assert fiveOutputs['rootGrants']==five['rootGrants']
for grant in five['rootGrants']:check(grant)"""
assert old in s;s=s.replace(old,new)
s=s.replace("for row in review.get('files',[]):add(row['path'])","for row in reviewManifest['files']:add(row['path'])\nfor p in [acceptedStageReview,acceptedStageReviewManifest,review['resultManifest'],review['definitiveStageReceipt'],five['resultManifest']['path'],five['terminalSlotRelease']['path']]:add(p)\nfor row in stageOutputs['files']+fiveOutputs['files']+five['rootGrants']:add(row['path'])")
s=s.replace('for expected,row in zip(expectedNames,sequence[\'sequence\']):',"for expected,row,acceptedGate,outputGate in zip(expectedNames,sequence['sequence'],five['gates'],fiveOutputs['checks']):")
needle=" d=P/'run'/expected;r=read(d/'result.json');t=read(d/'terminal.json');assert r['passed']is True and r['exitCode']==t['exitCode']==0 and r['manifestSha256']==row['sha256']"
replacement=needle+"""
 assert acceptedGate['manifest']==outputGate['manifest']==row
 assert acceptedGate['result']==outputGate['result']==pin(d/'result.json')
 assert acceptedGate['terminal']==outputGate['terminal']==pin(d/'terminal.json')
 assert outputGate['passed']is True and outputGate['exitCode']==0
 assert r['pinsPassed']is True and r['scopePassed']is True and r['automaticRetry']is False
 assert read(d/'after-pins.json')['passed']is True and read(d/'scope-verification.json')['passed']is True
 assert t['watchdogFired']is False and t['stdoutSha256']==pin(d/'stdout.log')['sha256'] and t['stderrSha256']==pin(d/'stderr.log')['sha256']
 assert pin(d/'stderr.log')['bytes']==0
 assert read(d/'invocation.json')['manifestSha256']==row['sha256']
 for name in ['result.json','terminal.json','after-pins.json','scope-verification.json','stdout.log','stderr.log','invocation.json','registration-target-metadata-before.json']:
  assert pin(d/name) in fiveOutputs['files'],('Gate output missing accepted result-manifest binding',expected,name)"""
assert needle in s;s=s.replace(needle,replacement)
s=s.replace("base=read(P/'structural-validation.json');assert base['registrationManifest']==pin(A/'manifest.json')","base=read(P/'structural-validation.json');assert base['registrationManifest']==pin(A/'manifest.json')\nassert base['registrationManifest']['sha256']=='6a7c6bfca208eb5940eba4cb6adfd52a2b55a97ca0802ef1f495c706feee58eb'\nassert sequence['registrationManifest']==base['registrationManifest']")
p.write_text(s)
plan=B/'PLAN.md';plan.write_text(plan.read_text()+'''\n## Version2 receipt-binding amendment\n\nVersion1 is preserved. Final preparation now accepts only the exact independently accepted Ford full-stage review.json (SHA256e6e355d2e2023aadc09ae754da4f8a6a3e94e4d1aa01b10b4c2b6a4473d5dd8e) or its exact manifest (SHA256b0976c09fd6ccad290a22d7dfd69bea8a42538d48f34c0bec558d7fe8a8f5d0a), then verifies stage manifest, output manifest, definitive receipt, packet, totals and all output pins. A generic PASS status cannot authorize preparation.\n\nThe eventual independent five-gate acceptance must identify the exact P/sequence.json, this registration readback and P/results-manifest-v1.json; both reviewer and producer records must contain the same five ordered command/result/terminal pins. Each actual receipt must be positive with matching command hash, successful after-pins/scope proof, exact logs, no watchdog and accepted output-manifest membership. The exact accepted Ford registration manifest is also required. No eventual gate acceptance is invented during this preparation.\n\nComparator semantics are unchanged from version1; only its own output-directory literal advances to version2.\n''')
for name in ['prepare-manifests.py','compare-report.mjs']:
 a=(P/name).read_text();b=(B/name).read_text()
 with (B/('v1-to-v2-'+name+'.patch')).open('x')as f:f.write(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=str(P/name),tofile=str(B/name))))
with (B/'nissan-to-ford-comparator.patch').open('x')as f:f.write(''.join(difflib.unified_diff(Path('/tmp/nissan-packet/report-comparison-plan-v2/compare-report.mjs').read_text().splitlines(True),(B/'compare-report.mjs').read_text().splitlines(True),fromfile='/tmp/nissan-packet/report-comparison-plan-v2/compare-report.mjs',tofile=str(B/'compare-report.mjs'))))
with (B/'successor-provenance.json').open('x')as f:json.dump(dict(priorPreparation=prior,changes=['Exact Ford full-stage result acceptance and stage/output/receipt/packet binding','Exact final five-gate sequence, registration readback, result manifest and five actual output receipt bindings','Exact Ford registration manifest guard','Comparator own output paths only'],comparatorSemanticBodyUnchanged=(P/'compare-report.mjs').read_text().replace(str(P),str(B))==(B/'compare-report.mjs').read_text(),runtimeExecuted=False),f,indent=2);f.write('\n')
for p in B.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
print('Preserved v1; prepared exact receipt-binding successor and parsed Python syntax only')
