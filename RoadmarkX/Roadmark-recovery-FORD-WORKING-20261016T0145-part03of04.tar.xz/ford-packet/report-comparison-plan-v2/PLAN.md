# Ford32 normal report and exhaustive saved-output comparison

Preparation only. This bundle does not authorize registration, report/comparator execution, project imports, a compiler retry or release. Full-project TypeScript remains UNPASSED after the two preserved KGM SIGKILLs of unknown cause. Ford full-stage definitive receipt is stage-receipt.json; its output/result.json is only the selected subreport. Independent full-stage output acceptance is a prerequisite, not inferred from a runtime exit.

## Separate serial prerequisites

1. Accept the Ford full-stage result independently and retain its exact receipt/output-manifest closure
2. Authorize and apply the exact four-file Ford registration, then accept actual live readback: append registry packet, append report reconciliation import/combine argument, create the exact candidate-v4 packet and reconciliation-v1 successor
3. Complete and independently accept the existing five distinct serial gates: market view, loader-only lint, behavioral suites, separate live-brand safety, structural validation. Those gates must retain original configured-root identities, runtime/configuration metadata and four-target before/after nonmutation guards
4. Freeze actual post-registration source/import/data/sourcePointer/runtime closure with the supplied prepare-manifests.py; no predicted live-after hashes are command inputs
5. Independently review the final two command manifests and exact supervisor. Obtain a separate exclusive heavy-slot root grant. No parallel execution or automatic retry

The preparation-input-closure.json names the current real imports, saved inputs, accepted Nissan report, Ford selected/full-stage outputs, retained21 storage leaves,31 registered packets,31 reconciliation inputs, the seven price sourcePointer target files and their individual overlay-row bindings, plus installed TypeScript/tsx/esbuild dependencies and executables. It is a present-state preparation closure. Final reclosure must replace only the accepted historical registry/load.ts input pins, retain their exact before copies, and verify the two new live targets against accepted bytes. The old closure is never rewritten.

## Exact later commands

Working directory: /workspace/scratch/586427eef9f2/roadmark-104

First, one unchanged production report:
/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node --max-old-space-size=448 --max-semi-space-size=1 --import tsx scripts/report-coverage.ts --as-of 2026-10-15 --json

Only after that report passes its positive receipt, one saved-output comparison:
/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node --max-old-space-size=448 --max-semi-space-size=1 --import tsx /tmp/ford-packet/report-comparison-plan-v2/compare-report.mjs

The normal report receives900 seconds plus10-second TERM-to-KILL grace; comparator180 seconds plus10-second grace. The unchanged accepted supervisor has a20-second margin, exact exclusive lock, environment cleanup, raw wait status, wait4 peak RSS, elapsed time, stdout/stderr hashes, watchdog state and source/metadata before-after verification. Each invocation uses run.py MANIFEST MANIFEST_SHA ROOT_GRANT ROOT_GRANT_SHA, with actual independently reviewed manifest hashes, never placeholders. Command outputs are one-shot directories; no overwrites/retries.

Final static preparation invocation, only after its prerequisites exist:
python /tmp/ford-packet/report-comparison-plan-v2/prepare-manifests.py FIVE_GATE_DIRECTORY REGISTRATION_DIRECTORY FIVE_GATE_ACCEPTANCE LIVE_REGISTRATION_ACCEPTANCE FULL_STAGE_RESULT_ACCEPTANCE

Expected directories are /tmp/ford-packet/post-registration-checks-v1 and /tmp/ford-packet/registration-v1; acceptance paths are explicit arguments. This static script emits the normal command, comparison command, sequence, NOT_GRANTED template, transition provenance and final closure. It executes neither command. Any supervisor/schema change requires review instead of silent adaptation.

## Baseline, reconstruction and scope

Use the actual accepted Nissan31 normal JSON report at /tmp/nissan-packet/report-comparison-plan-v2/normal-coverage-asof-2026-10-15/stdout.log, SHA25661b497fb9f1e1f7683b07e9040638c781ff4e8c597ca507f9afd5b2205ad9768, and its independent accepted result review.

Restore retained409/prefix20 once using the accepted21-file storage closure. Reconstruct complete cars by applying the one EQA21 fact and saved accepted replacements/additions through Leapmotor22, Mazda23, Skoda24, Audi25, Deepal26, MINI27, KGM28, CUPRA29, Renault30 and Nissan31. Require every ordered full-car digest at every step. Replace only three old Ford rows and append three accepted residual rows in exact producer order. Require all433 final complete-car digests to equal Ford full-stage; all427 existing peers remain exact.

Stream all14 retained descriptors while retaining only three Ford variants and207 raw feature rows, and preserve complete sources/issues/criteria context. Compose sources through Nissan31, append exactly27 Ford sources, and check complete ordered before/after source-array digests. Replay only the three prior Ford feature packs to produce exact old coverage/freshness controls. Use the accepted six after packs and414 feature claims. No peer feature replay, default catalogue hydration, second broad report or duplicate full-stage execution.

## Complete report accounting

- Catalogue430→433, Tier1 353→356, on-sale312→314. Three old current Ford versions become six visible Ford versions, five on sale. All global percentages and denominators must change correctly; never copy Nissan's fixed-denominator assumption
- Recompute all17 full coreCoverage objects using actual unchanged producers over digest-verified complete cars and sources. First prove old core/gaps match Nissan's complete report; then verify selected subtraction/addition for filled/grade counts and total312→314. Preserve every ordered reason, gap and explanation
- Preserve every complete non-Ford brandProgress object. Replace Ford's complete object using accepted selected coverage. Ford remains research-incomplete and not done, with C1/C2/C5 open; its on-sale core has85 reviewed cells. The six-car102-cell selected claim inventory is separate
- Rebuild every normal ranking from digest-bound full-stage complete groups, exclusions and unranked records. Prove exact numeric interleaving, rank/tie fields, measurement-group insertion/tie order, peer relative order and every fact/car digest. Normal report projects only the five on-sale Ford rows; residual GT remains visible but outside this denominator
- Range ranked231→236, price177→177, DC time174→179, seats210→213, boot48→48, towing159→159, all over314 after. Source-labelled Reported prices stay unranked; unknown cargo methods and towing remain exclusions. Numeric expectations are planning evidence, not a normal-report pass
- All summary gaps remain in full Tier1 catalogue order. Missing models/leads follow exact inherited inventoryRecordId traversal. Overdue/invalid/excluded-history arrays preserve actual freshnessEntries fact/availability phase before equipment phase and same-car order
- Require whole global C1 equality with accepted Ford full-stage:106→107 reviewed models,242→245 reviewed versions,187→186 issues,65 settled records unchanged,pass false. Remove only three current MY26 membership gaps and insert the two residual Select/Premium membership gaps at the actual version-issue position. Preserve both unresolved Mach-E and Lightning inventory dispositions; Q3GN and Lightning remain unresolved
- Reconstruct paired-summary counts, all-ranking intersection, all17-field grading totals/percentages/note, brand completion arrays, freshness totals and every C1–C6 detail
- Deep-equal every leaf of the final expected report with actual normal output, with no ignored paths. Save complete baseline-vs-normal and expected-vs-normal diffs, full core-reason inventory, complete ranking/array-order proof and exact six-file generated-normal-input closure

## Producer-owned optional witnesses

Reuse the accepted Nissan witness implementation unchanged. It observes actual sourceEffectiveFeatures→applyFeatureRegrading→applyBrandFeatureUpdates→applyBrandTermFeatures output; permits only producer-proven optional own-undefined properties and requires exact match with accepted Ford before witnesses. For Ford those three prior observations are novated_fbt confirmation_needed created by actual auditedFeature, not assumed omissions. Require all204 other retained feature rows exact, excluding only the three roadside projections. Bind six roadside and two new residual driveaway projections to complete accepted fact/feature objects, source IDs, conditions, status and any expiry. Bind whole accepted after packs as well.

The old selected report's independent_lists brand/reference omissions are permitted only after actual buildMarketReconciliation creates the same own/enumerable undefined properties. No blanket JSON roundtrip normalization, deleting arbitrary undefined fields or whitelist by guessed path. Mutated input snapshots, changed ownership, unexpected omissions and extra loader calls fail.

## Boundaries and stopping

The only execution in this preparation is Node --check,64MiB old space/1MiB semi-space,10-second timeout plus2-second kill grace, with no imports or comparator body. Syntax success is not semantic comparison, full-project TypeScript, test, build or release success.

A normal report failure stops and preserves all evidence. A comparator failure preserves the successful normal report; diagnose and independently review the comparator without rerunning the report. No compiler, server, browser, mobile QA, publication, archive, live source edit or automatic retry is included. Current normal/comparator Ford invocations: zero.

## Version2 receipt-binding amendment

Version1 is preserved. Final preparation now accepts only the exact independently accepted Ford full-stage review.json (SHA256e6e355d2e2023aadc09ae754da4f8a6a3e94e4d1aa01b10b4c2b6a4473d5dd8e) or its exact manifest (SHA256b0976c09fd6ccad290a22d7dfd69bea8a42538d48f34c0bec558d7fe8a8f5d0a), then verifies stage manifest, output manifest, definitive receipt, packet, totals and all output pins. A generic PASS status cannot authorize preparation.

The eventual independent five-gate acceptance must identify the exact P/sequence.json, this registration readback and P/results-manifest-v1.json; both reviewer and producer records must contain the same five ordered command/result/terminal pins. Each actual receipt must be positive with matching command hash, successful after-pins/scope proof, exact logs, no watchdog and accepted output-manifest membership. The exact accepted Ford registration manifest is also required. No eventual gate acceptance is invented during this preparation.

Comparator semantics are unchanged from version1; only its own output-directory literal advances to version2.
