"""Planning arithmetic over existing saved reports only; no producer execution."""
from pathlib import Path
import json,hashlib
B=Path('/tmp/ford-packet/report-comparison-plan-v2')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
normal='/tmp/nissan-packet/report-comparison-plan-v2/normal-coverage-asof-2026-10-15/stdout.log';selected='/tmp/ford-packet/selected-readiness-v1/result.json';baseline=read(normal);r=read(selected);after=r['selectedCoverage'];before=next(b for b in baseline['brandProgress']if b['brand']=='Ford')
assert before['onSaleVersions']==3 and after['onSaleVersions']==5 and after['allCatalogueVersions']==6
core=[]
for g,b,a in zip(baseline['core'],before['core'],after['core']):
 assert g['key']==b['key']==a['key'];grades={k:g['grades'][k]-b['grades'][k]+a['grades'][k]for k in g['grades']}
 core.append(dict(key=g['key'],totalBefore=312,totalAfter=314,filledBefore=g['filled'],filledAfter=g['filled']-b['filled']+a['filled'],gradesBefore=g['grades'],gradesAfter=grades,selectedBefore=b,selectedAfter=a,explanation='Must be recomputed by actual coreCoverage/gradePattern; numeric planning subtraction does not prove reason order'))
ranked=[]
for g,b,a in zip(baseline['rankings'],before['rankings'],after['rankings']):
 assert g['key']==b['key']==a['key'];n=g['ranked']-b['ranked']+a['ranked'];ranked.append(dict(key=g['key'],before=g['ranked'],after=n,denominatorBefore=312,denominatorAfter=314,percentAfter=round(n/314*100,1),membershipAndOrder='Deferred exact proof from accepted full-stage complete ranking records'))
assert [r['after']for r in ranked]==[236,177,179,213,48,159]
packs=read('/tmp/ford-packet/selected-readiness-v1/selected-packs.json');assert packs==read('/tmp/ford-packet/full-stage-v1/output/selected-packs.json');assert len(packs)==6
for p in packs.values():
 assert len(p['features'])==69
 for criterion,factKey in [('roadside_assistance','roadside_assistance')]+([('driveaway_price','price_aud')]if '2023_75'in p['car']['id']and p['car']['facts']['price_aud']['value']is not None else []):
  f=p['car']['facts'][factKey];feature=next(x for x in p['features']if x['criterion']==criterion);assert feature['source_ids']==f['sourceIds'];assert all(q in feature['conditions']for q in f['qualifications'])
x=dict(status='static_planning_projection_not_runtime_result',baseline=pin(normal),acceptedNissanReview=pin('/tmp/nissan-review/report-comparison-v2-results-v1.json'),selected=pin(selected),definitiveFordStageReceipt=pin('/tmp/ford-packet/full-stage-v1/output/stage-receipt.json'),countsBefore=[430,353,312],countsAfter=[433,356,314],unchangedExistingPeers=427,changedExistingCars=3,newVersions=3,fordVisible=6,fordOnSale=5,coreCellsAllSelected=102,coreGradeCountsAllSelected=r['coreGradeCounts'],coreCellsOnSale=85,core=core,rankings=ranked,C1Before=dict(models=106,versions=242,issues=187,settled=65,pass_=False),C1After=dict(models=107,versions=245,issues=186,settled=65,pass_=False),unresolved=['MY23.75 Select official current-list membership','MY23.75 Premium official current-list membership','record:ford-mustang-mach-e','record:ford-f-150-lightning','Q3GN identity/supply boundary'],residualGTOnSale=False,fordResearchCompleted=False,fordDone=False,compilerPass=False,releasePass=False,normalReportRuns=0,comparatorRuns=0,selectedArtifactLightReadbackExact=True)
with (B/'expected-deltas.json').open('x')as f:json.dump(x,f,indent=2);f.write('\n')
print('Saved conservative numerical expectations and exact selected written projection checks; no project imports or runtime')
