from pathlib import Path
import json,hashlib,re,sys,ast,shutil
O=Path('/tmp/ford-packet/selected-readiness-v1');R=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def put(n,x):
 with (O/n).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
for p in O.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
expected=json.loads((O/'expected-review.json').read_text())
files={p for p in O.iterdir() if p.is_file()}
manifest=Path('/tmp/ford-packet/candidate-v4/manifest.json');m=json.loads(manifest.read_text());assert pin(manifest)['sha256']=='3d6a95722662241657a187681638baaeab2b80e0b01d4339b7768d7ce34575bc';files.add(manifest)
for entry in m['files']:assert pin(entry['path'])==entry;files.add(Path(entry['path']))
for root in [Path('/tmp/ford-packet/reconciliation-v1'),Path('/tmp/ford-review/candidate-v4-review')]:files.update(p for p in root.iterdir() if p.is_file())
files.update(Path(p) for p in ['/tmp/xpeng-staging-plan/baseline-io.mjs','/tmp/mercedes-staging-plan/consumer-preparation/v5/feature-json-parity.mjs','/tmp/nissan-packet/selected-preflight-v4/check.mjs','/tmp/nissan-packet/selected-preflight-v4/prepare-command.py','/tmp/nissan-packet/selected-preflight-v4/run.py','/tmp/nissan-packet/selected-preflight-v4/check-syntax.py','/tmp/nissan-packet/selected-preflight-v4/result.json'])
files.update(R/p for p in ['src/lib/brand-updates.ts','src/lib/availability-corrections.ts','src/lib/evidence-consumers.ts','src/lib/evidence-regrading.ts','src/lib/launch-evidence.ts','src/lib/portable-packs.ts','src/lib/citable.ts','src/lib/compare.ts','src/lib/discovery.ts','src/lib/market-inventory-data.ts','scripts/reporting/reports.ts','scripts/reporting/m1-reconciliation.ts','tests/helpers/compiled-source.ts','src/lib/brand-update-registry.ts','tsconfig.json','data/m1-evidence-regrading-2026-10-13.json','package.json','pnpm-lock.yaml','data/m1-brand-updates/registry.json'])
registry=json.loads((R/'data/m1-brand-updates/registry.json').read_text());assert len(registry['packets'])==31 and registry['packets'][-1]=='nissan-2026-10-15.json'
for name in registry['packets']:files.add(R/'data/m1-brand-updates'/name)
anchorsPath=Path('/tmp/mercedes-staging-plan/consumer-preparation/v5/manifests/report-v5.json');storagePath=Path('/tmp/mercedes-staging-plan/staging-preparation/staging-artifacts/canonical-v1/staged-storage-index.json');files.update([anchorsPath,storagePath]);anchors=json.loads(anchorsPath.read_text())['anchors'];storage=json.loads(storagePath.read_text());assert len(storage['research'])==14
storagePins=[]
for k,ref in storage['research'].items():
 root=Path(anchors[ref['anchor']]);p=root/ref['file'];assert p.resolve()==p and p.is_file() and p.is_relative_to(root);actual=pin(p);assert actual['bytes']==ref['bytes'] and actual['sha256']==ref['sha256'];files.add(p);storagePins.append({'field':k,'rows':ref['rows'],**actual})
queue=[p for p in files if p.suffix in ['.ts','.tsx','.mts','.mjs'] and (p.is_relative_to(R) or p.parent==O)];seen=set();edges=[];bare=set()
while queue:
 p=queue.pop()
 if p in seen:continue
 seen.add(p)
 for spec in re.findall(r'''(?:from\s*|import\s*\(?\s*|require\(\s*)["']([^"']+)["']''',p.read_text()):
  if spec.startswith('node:'):continue
  if spec.startswith('@/'):root=R/'src'/spec[2:]
  elif spec.startswith(('./src/','./tests/','./scripts/')) and p.parent==O:root=R/spec
  elif spec.startswith('.'):root=(p.parent/spec).resolve()
  elif spec.startswith('/'):root=Path(spec)
  else:bare.add(spec);continue
  choices=[root,Path(str(root)+'.ts'),Path(str(root)+'.tsx'),Path(str(root)+'.json'),root/'index.ts'];hit=next((x for x in choices if x.is_file()),None)
  assert hit is not None,(str(p),spec)
  files.add(hit);edges.append({'from':str(p),'specifier':spec,'to':str(hit)})
  if hit.suffix in ['.ts','.tsx','.mts','.mjs']:queue.append(hit)
# Pin installed runtime package code without importing it or resolving via executable code.
# tsx runtime loads esbuild, get-tsconfig and resolve-pkg-maps; optional native platform package is included when installed.
packageRoots=set();todo=[R/'node_modules'/x for x in ['tsx','typescript','esbuild']];packageEdges=[]
for spec in bare:
 name='/'.join(spec.split('/')[:2]) if spec.startswith('@') else spec.split('/')[0]
 p=R/'node_modules'/name
 if p.exists():todo.append(p)
 elif name not in ['fs','path','vm','assert','module','crypto','readline','url','util','os','stream','buffer','events','child_process','worker_threads']:raise AssertionError(('unresolved package',spec))
while todo:
 logical=todo.pop();root=logical.resolve()
 if root in packageRoots:continue
 packageRoots.add(root);meta=root/'package.json';assert meta.is_file();obj=json.loads(meta.read_text())
 for p in root.rglob('*'):
  if not p.is_file() or 'node_modules' in p.relative_to(root).parts:continue
  if p.suffix in ['.js','.mjs','.cjs','.json','.node'] or p.name in ['esbuild','tsc','tsserver']:files.add(p)
 for name in set(obj.get('dependencies',{}))|set(obj.get('optionalDependencies',{})):
  dep=root.parent/name
  if dep.exists():todo.append(dep);packageEdges.append({'from':str(root),'name':name,'to':str(dep.resolve())})
  elif name in obj.get('dependencies',{}):raise AssertionError(('missing runtime dependency',str(root),name))
for name in ['node','timeout']:
 p=shutil.which(name);assert p and Path(p).is_file();files.add(Path(p).resolve())
files.add(Path(sys.executable).resolve())
put('input-closure.json',{'status':'Static filesystem resolution only; no runtime imports','retainedStorage':storagePins,'selectedRetention':'Future stream retains only three existing Ford variants, one model, 207 feature rows and three feature contexts; 3 new variants / 207 additional feature rows come from the actual builder. All fourteen accepted streams hashed; no complete catalogue hydration.','relativeImportEdges':edges,'bareSpecifiers':sorted(bare),'runtimePackageRoots':[str(p) for p in sorted(packageRoots)],'runtimePackageEdges':packageEdges,'dynamicInputs':['Current registry JSON and all 31 packet files pinned explicitly','compiledSource reads actual brand-updates.ts and evidence-consumers.ts; both seeds and source import graphs pinned','Actual availability-corrections.ts interception delegates to the real function; it does not replace the builder or construct a guessed new car','Accepted Nissan31 car digest index, exact selected before objects and selection proof pinned','Fourteen storage locators validated against exact accepted anchors and descriptor byte/hash pins','Source-pins.json and prepared-command.json separately pinned by execution wrapper','Future runtime outputs and explicit root grant are not generated proof inputs'],'noImportsExecuted':True})
files.add(O/'input-closure.json');put('source-pins.json',[pin(p) for p in sorted(files)])
prepared={'status':'prepared_not_executed','script':pin(O/'check.mjs'),'sourcePins':pin(O/'source-pins.json'),'packet':expected['packet'],'reconciliation':expected['reconciliation'],'expectedReview':pin(O/'expected-review.json'),'wrapper':pin(O/'run.py'),'typedReview':pin('/tmp/ford-review/candidate-v4-review/manifest.json'),'inputClosure':pin(O/'input-closure.json'),'syntaxOnly':pin(O/'syntax-only-check.json'),'plan':pin(O/'PLAN.md'),'command':[str(Path(shutil.which('node')).resolve()),'--max-old-space-size=448','--max-semi-space-size=1','--import','tsx',str(O/'check.mjs'),'--root-execution-granted'],'workdir':str(R),'timeoutSeconds':180,'killGraceSeconds':10,'automaticRetry':False,'rootExecutionGrantRequired':True,'exclusiveHeavySlotRequired':True,'scope':'Exactly 3 retained Ford current refreshes plus 3 real-builder residual additions; six packs and 414 features. 121 fact edits, 18 shared-term cells, 139 earned packet cells, 102 core cells, exact configuration/null-release/source/availability/summary guards and 11 negative-guard cases. Actual zero-fact and new-availability producer interception; 294 actual comparisons and 9 supplementary unknown-cargo cases; actual range/DC/seats rankings, cargo/mirror exclusions, residual GT on-sale exclusion, current3 official-list review and two residual version-list gaps. Live/written/citable/portable parity with exact optional producer witnesses. No full catalogue, live mutation, project compiler, build/server/browser/archive or automatic retry.','currentProjectTypeScript':'UNPASSED; no retry'}
put('prepared-command.json',prepared)
put('root-grant-template.json',{'authorized':False,'exclusiveHeavySlotGranted':False,'action':'run_single_selected_ford_preflight','preparedManifestSha256':pin(O/'prepared-command.json')['sha256'],'command':prepared['command'],'automaticRetry':False,'note':'Template only; independent readiness and separate root exclusive-slot grant required.'})
print(json.dumps({'manifest':pin(O/'prepared-command.json'),'sourcePins':len(files),'researchStorageBytes':sum(x['bytes'] for x in storagePins),'runtimePackages':len(packageRoots),'executed':False},indent=2))
