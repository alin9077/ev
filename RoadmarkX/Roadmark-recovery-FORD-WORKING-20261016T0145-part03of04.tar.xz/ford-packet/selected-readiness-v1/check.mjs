/** Prepared only. Actual selected Ford builders/consumers; execution needs a separate root grant. */
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readJson,fileHash,streamRows,digestRows} from '/tmp/xpeng-staging-plan/baseline-io.mjs';
import {assertDeclaredJson} from '/tmp/mercedes-staging-plan/consumer-preparation/v5/feature-json-parity.mjs';
const repo='/workspace/scratch/586427eef9f2/roadmark-104',out='/tmp/ford-packet/selected-readiness-v1';
assert.equal(process.argv[2],'--root-execution-granted');assert.equal(process.cwd(),repo);assert(!fs.existsSync(out+'/result.json'));
const pins=readJson(out+'/source-pins.json');
function checkPins(){for(const p of pins){assert.equal(fs.statSync(p.path).size,p.bytes);assert.equal(fileHash(p.path),p.sha256,p.path);}}
checkPins();
const expected=readJson(out+'/expected-review.json'),packetPath=expected.packet.path;
assert.equal(fileHash(packetPath),expected.packet.sha256);
const packet=readJson(packetPath),packetSnapshot=structuredClone(packet);
const accepted=readJson('/tmp/mercedes-staging-plan/consumer-preparation/v5/manifests/report-v5.json');
const index=readJson('/tmp/mercedes-staging-plan/staging-preparation/staging-artifacts/canonical-v1/staged-storage-index.json');
const before=readJson('/tmp/ford-research/retained-before-cars-v1.json'),receipt=readJson('/tmp/ford-packet/baseline-proof-v2/proof.json');
assert.equal(fileHash(receipt.nissanDigestFile),receipt.nissanDigestFileSha256);
const acceptedDigests=readJson(receipt.nissanDigestFile).candidate31;
const beforeSnapshot=structuredClone(before),selected=new Set(before.map(c=>c.id)),added=new Set(packet.variants.map(v=>v.id)),allIds=new Set([...selected,...added]),modelIds=new Set(before.map(c=>c.modelId));
assert.deepEqual([...selected],expected.existingIds);assert.deepEqual([...added],expected.addedIds);assert.equal(before.length,3);assert.equal(acceptedDigests.length,430);
for(const car of before){const acceptedRow=acceptedDigests.find(x=>x.id===car.id),proof=receipt.selected.find(x=>x.id===car.id),actual=digestRows([car]);assert(acceptedRow&&proof);assert.equal(actual.sha256,acceptedRow.sha256);assert.equal(actual.bytes,acceptedRow.bytes);assert.equal(actual.sha256,proof.sha256);assert.equal(actual.bytes,proof.lineBytes);}
for(const id of added)assert(!acceptedDigests.some(x=>x.id===id));
const base={},reads=[];
for(const [key,ref]of Object.entries(index.research)){
 const values=[];await streamRows(accepted.anchors,ref,row=>{
  const keep=['variants','feature_evidence_variant_context'].includes(key)?selected.has(row.id):['feature_evidence','trim_equipment','update_eligibility'].includes(key)?selected.has(row.variant_id):key==='models'?modelIds.has(row.id):true;
  if(keep)values.push(row);
 });base[key]=ref.array?values:values[0];reads.push({field:key,inputRows:ref.rows,selectedRows:values.length,sha256:ref.sha256});
}
assert.equal(base.variants.length,3);assert.equal(base.feature_evidence.length,207);assert.equal(base.feature_evidence_variant_context.length,3);assert.equal(base.criteria.length,69);
const require=createRequire(repo+'/package.json');
const brand=require('./src/lib/brand-updates.ts');
const {prepareBrandResearch,applyBrandUpdates,brandVersionSnapshot,applyBrandFeatureUpdates,applyBrandTermFeatures}=brand;
const {brandUpdatePackets}=require('./src/lib/brand-update-registry.ts');
assert.equal(brandUpdatePackets.length,31);assert.equal(brandUpdatePackets.at(-1).id,'m1-nissan-2026-10-15');
for(const prior of brandUpdatePackets){assert.notEqual(prior.brand,'Ford');for(const row of [...prior.facts,...prior.variants,...prior.versionGuards,...prior.availability,...prior.summaries,...(prior.features??[]),...(prior.configurationUpdates??[])])assert(!allIds.has(row.variantId??row.id));for(const term of prior.brandTerms??[])assert(term.applicableVariantIds.every(id=>!allIds.has(id)));}
const {compiledSource}=require('./tests/helpers/compiled-source.ts');
const actualAvailability=require('./src/lib/availability-corrections.ts');
// Observe the private real newVariantCar result at its actual pre-availability boundary.
// No reconstructed zero-fact Car and no guessed new-availability baseline may satisfy this proof.
let capturedBuilderCars=null,probeAvailabilityCalls=0;
const probeBrand=compiledSource('src/lib/brand-updates.ts',{'./availability-corrections':{...actualAvailability,applyAvailabilityCorrections(cars,edits,sources){probeAvailabilityCalls++;assert.equal(probeAvailabilityCalls,1);capturedBuilderCars=structuredClone(cars);for(const car of cars.filter(c=>added.has(c.id)))assert.deepStrictEqual(car.facts,{});return actualAvailability.applyAvailabilityCorrections(cars,edits,sources);}}});
const probePacket={...structuredClone(packet),facts:[],brandTerms:[],features:[],configurationUpdates:[],summaries:[]};
const probePacketSnapshot=structuredClone(probePacket),baseSnapshot=structuredClone(base);
const probeData=probeBrand.prepareBrandResearch(base,[probePacket]),probeDataSnapshot=structuredClone(probeData);
const probeAfter=probeBrand.applyBrandUpdates(before,probeData,[probePacket]);
assert.equal(probeAvailabilityCalls,1);assert(capturedBuilderCars);assert.equal(capturedBuilderCars.length,6);assert.equal(probeAfter.length,6);
const additionBuilderProof=[];
for(const id of added){const raw=capturedBuilderCars.find(c=>c.id===id),declared=packet.availability.find(a=>a.variantId===id).before;assert.deepStrictEqual(raw.facts,{});assert.deepStrictEqual({availability:raw.availability,evidence:raw.availabilityEvidence},declared);assert.deepStrictEqual(declared,expected.additionDeclaredAvailabilityBefore[id]);assert.deepStrictEqual(raw.configurationEvidence,packet.variants.find(v=>v.id===id).configuration_evidence);additionBuilderProof.push({variantId:id,actualProducer:'src/lib/brand-updates.ts private newVariantCar, intercepted at actual applyAvailabilityCorrections boundary before unknownFacts',facts:raw.facts,availabilityBefore:{availability:raw.availability,evidence:raw.availabilityEvidence},version:brandVersionSnapshot(raw),zeroFactsVerified:true,declaredAvailabilityGuardExact:true});}
assert.deepStrictEqual(base,baseSnapshot);assert.deepStrictEqual(before,beforeSnapshot);assert.deepStrictEqual(probePacket,probePacketSnapshot);assert.deepStrictEqual(probeData,probeDataSnapshot);
const guardCars=new Map(capturedBuilderCars.map(c=>[c.id,c]));
const data=prepareBrandResearch(base,[packet]),dataSnapshot=structuredClone(data),after=applyBrandUpdates(before,data,[packet]),afterSnapshot=structuredClone(after);
assert.equal(after.length,6);assert.equal(data.variants.length,6);assert.equal(data.feature_evidence.length,414);assert.equal(data.feature_evidence_variant_context.length,6);
assert.equal(packet.facts.length,121);assert.equal(packet.brandTerms.length,3);assert.equal(packet.configurationUpdates.length,3);assert.equal(packet.availability.length,6);assert.equal(packet.summaries.length,6);
for(const guard of packet.versionGuards)assert.deepStrictEqual(brandVersionSnapshot(before.find(c=>c.id===guard.variantId)),guard.before);
for(const edit of packet.facts){assert.deepStrictEqual(guardCars.get(edit.variantId).facts[edit.after.key]??null,edit.before);assert.deepStrictEqual(after.find(c=>c.id===edit.variantId).facts[edit.after.key],edit.after);}
for(const term of packet.brandTerms)for(const id of term.applicableVariantIds){assert.deepStrictEqual(guardCars.get(id).facts[term.key]??null,term.before[id]);assert.deepStrictEqual(after.find(c=>c.id===id).facts[term.key],term.fact);}
const untouchedFactProof=[];
for(const car of after){const prior=before.find(c=>c.id===car.id);if(!prior)continue;const updatedKeys=new Set(packet.facts.filter(e=>e.variantId===car.id).map(e=>e.after.key));for(const t of packet.brandTerms)if(t.applicableVariantIds.includes(car.id))updatedKeys.add(t.key);const exactKeys=[...new Set([...Object.keys(prior.facts),...updatedKeys])].sort();assert.deepStrictEqual(Object.keys(car.facts).sort(),exactKeys);const untouched=Object.keys(prior.facts).filter(k=>!updatedKeys.has(k));for(const key of untouched)assert.deepStrictEqual(car.facts[key],prior.facts[key]);untouchedFactProof.push({variantId:car.id,untouchedKeys:untouched.sort(),fullKeySetExact:true,untouchedFactObjectsExact:true});assert.deepStrictEqual(brandVersionSnapshot(car),brandVersionSnapshot(prior));}
const mutable=new Set(['rankingEligible','projectionScope','sourceIds','requiredBuyerVisibleConditions','requiredNulls','countContribution','configurationReview']);
for(const edit of packet.configurationUpdates){const b=before.find(c=>c.id===edit.variantId),a=after.find(c=>c.id===edit.variantId);assert.deepStrictEqual(b.configurationEvidence,edit.before);assert.deepStrictEqual(a.configurationEvidence,edit.after);assert.deepStrictEqual(Object.fromEntries(Object.entries(edit.before).filter(([k])=>!mutable.has(k))),Object.fromEntries(Object.entries(edit.after).filter(([k])=>!mutable.has(k))));assert.equal(edit.before.rankingEligible,false);assert.equal(edit.after.rankingEligible,true);assert.equal(edit.after.completeVehicleCountEligible,false);assert.deepStrictEqual(Object.keys(edit.before.requiredNulls).filter(k=>!(k in edit.after.requiredNulls)).sort(),['dc_peak_kw','price_aud','zero_to_100_s']);for(const k of ['current_manufacturer_base_price_aud','current_manufacturer_driveaway_price_aud','current_national_price_aud'])assert.deepStrictEqual(edit.after.requiredNulls[k],edit.before.requiredNulls[k]);for(const d of edit.dependencies)assert.deepStrictEqual(a.facts[d.key],d.expected);}
for(const edit of packet.availability){const b=guardCars.get(edit.variantId),a=after.find(c=>c.id===edit.variantId);assert.deepStrictEqual({availability:b.availability,evidence:b.availabilityEvidence},edit.before);assert.deepStrictEqual({availability:a.availability,evidence:a.availabilityEvidence},edit.after);}
for(const edit of packet.summaries){const car=after.find(c=>c.id===edit.variantId);for(const side of ['strength','tradeoff']){assert.equal(car.buyerSummary[side].label,edit[side].label);assert.equal(car.buyerSummary[side].text,edit[side].text);for(const d of edit[side].dependencies){assert.deepStrictEqual(car.facts[d.key],d.expected);assert.notEqual(d.expected.value,null);assert.deepStrictEqual(d.expected.issues,[]);}const fresh=edit[side].dependencies.flatMap(({expected:f})=>[f.date,...f.sourceIds.map(id=>data.sources.find(s=>s.id===id).accessed_date)].map(checkedAt=>({checkedAt,key:f.key,...(f.modelYearChangedAt?{modelYearChangedAt:f.modelYearChangedAt}:{})})));assert.deepStrictEqual(car.buyerSummary[side].freshness,fresh);assert.deepStrictEqual(car.buyerSummary[side].sourceIds,[...new Set(edit[side].dependencies.flatMap(d=>d.expected.sourceIds))]);}const ids=[...new Set(['strength','tradeoff'].flatMap(side=>edit[side].dependencies.flatMap(d=>d.expected.sourceIds)))];assert.deepStrictEqual(car.buyerSummary.guardSourceIds,ids);assert.deepStrictEqual(car.buyerSummary.expectedSourceSnapshots,packet.sources.filter(s=>ids.includes(s.id)));assert.deepStrictEqual(car.buyerSummary.conditions,edit.conditions);assert.deepStrictEqual(car.configurationEvidence.requiredBuyerVisibleConditions,edit.conditions);}
const negativeProof=[];
function rejectMutation(name,mutate,pattern){const input={cars:structuredClone(before),research:structuredClone(data),packet:structuredClone(packet)};mutate(input);const snap=structuredClone(input);let error;try{applyBrandUpdates(input.cars,input.research,[input.packet]);}catch(e){error=e;}assert(error instanceof Error,name+' accepted');assert.match(error.message,pattern,name+' wrong rejection');assert.deepStrictEqual(input,snap);negativeProof.push({name,actualError:error.message,expectedErrorPattern:pattern.source,rejected:true,inputsUnchanged:true});}
rejectMutation('exact identity',({packet:p})=>{p.versionGuards[0].before.trim+=' changed';},/Brand update: reviewed version changed:/);
rejectMutation('retained fact beforeguard',({packet:p})=>{p.facts[0].before.qualifications.push('changed');},/Brand update: fact before snapshot changed:.*\/price_aud$/);
rejectMutation('new fact zero baseline',({packet:p})=>{p.facts.find(f=>added.has(f.variantId)).before={...p.facts[0].after};},/Brand update: fact before snapshot changed:/);
rejectMutation('shared warranty beforeguard',({packet:p})=>{p.brandTerms[0].before[p.versionGuards[0].variantId].value='changed';},/Brand update: fact before snapshot changed:.*\/warranty$/);
rejectMutation('addition availability baseline',({packet:p})=>{p.availability.find(a=>added.has(a.variantId)).before.evidence.stockStatus='new_stock_listed';},/Availability correction conflict .*reviewed snapshot changed or variant missing/);
rejectMutation('summary exact dependency',({packet:p})=>{p.summaries[0].strength.dependencies[0].expected.value=999;},/Brand update: summary dependency changed:.*\/range_km$/);
rejectMutation('source exact snapshot',({packet:p})=>{p.sources[0].title+=' changed';},/Brand update: source snapshot changed:/);
rejectMutation('earned grade provenance',({packet:p})=>{p.facts.find(f=>f.after.key==='range_km').after.gradeReview.overlayId='wrong';},/Brand update: invalid fact or unearned grade: range_km/);
rejectMutation('configuration beforeguard',({packet:p})=>{p.configurationUpdates[0].before.projectionScope+=' changed';},/Brand update: configuration before snapshot changed:/);
rejectMutation('frozen complete count',({packet:p})=>{p.configurationUpdates[0].after.completeVehicleCountEligible=true;},/Brand update: configuration historical source\/build boundary changed:/);
rejectMutation('maker price hold cannot use guide alias',({packet:p})=>{const c=p.configurationUpdates[0];delete c.after.requiredNulls.current_manufacturer_base_price_aud;c.after.configurationReview.releasedNulls.push({key:'current_manufacturer_base_price_aud',factKeys:['price_aud']});},/Brand update: configuration null release proof has wrong measurement:/);
assert.equal(negativeProof.length,11);
let defaultCalls=0;const forbidden=()=>{defaultCalls++;throw new Error('FORBIDDEN_DEFAULT_CATALOGUE_LOADER');};
const defaults={sourceResearch:forbidden,research:forbidden,catalogue:forbidden};
const factory=packets=>compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets:packets}}).createEvidenceConsumers(defaults);
const initial=factory(brandUpdatePackets),final=factory([...brandUpdatePackets,packet]);
const {hasEarnedBuyerGrade}=require('./src/lib/evidence-grading.ts');
const {factClaim,featureClaim,makeReport,reportMarkdown}=require('./src/lib/citable.ts');
const {availabilityReportClaim}=actualAvailability;
const {buyerAvailabilityText}=require('./src/lib/buyer-availability.ts');
const {isOnSale,isCurrentListEligible,buildCoverageReport}=require('./scripts/reporting/reports.ts');
const {auditedFeature}=require('./src/lib/launch-evidence.ts');
const {applyFeatureRegrading}=require('./src/lib/evidence-regrading.ts');
const beforePacks={},afterPacks={},observations=[],claims=[],featureClaims=[],claimOmissions=[],producerProofs=[],frames=new Map();
for(const [phase,cars,consumer,research,packets]of [['before',before,initial,base,brandUpdatePackets],['after',after,final,data,[...brandUpdatePackets,packet]]])for(const car of cars){const input=consumer.sourceEffectiveFeatures(car,research),snap=structuredClone(input),regraded=applyFeatureRegrading(car,input,research.sources);assert.deepStrictEqual(input,snap);const branded=applyBrandFeatureUpdates(car,regraded,research,packets),projected=applyBrandTermFeatures(car,branded,research.sources);frames.set(phase+'\0'+car.id,{input,regraded,branded,projected,research});producerProofs.push({phase,variantId:car.id,producer:'Actual sourceEffectiveFeatures -> applyFeatureRegrading -> applyBrandFeatureUpdates -> applyBrandTermFeatures',inputRows:input.length,outputRows:projected.length,inputUnchanged:true});}
for(const id of added){const rows=data.feature_evidence.filter(f=>f.variant_id===id);assert.equal(rows.length,69);for(const row of rows)for(const key of ['buyerGrade','gradeReview','gradeReviewStatus','condition_label','confirmation_needed'])assert(!Object.hasOwn(row,key));const raw=rows.find(f=>f.criterion==='novated_fbt'),snap=structuredClone(raw),audited=auditedFeature(raw);assert.deepStrictEqual(raw,snap);const d=Object.getOwnPropertyDescriptor(audited,'confirmation_needed');assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);producerProofs.push({variantId:id,producer:'Actual prepareBrandResearch generated 69 rows and auditedFeature raw novated_fbt branch',generatedOptionalFieldsAbsent:true,rawNovatedRow:raw,auditedNovatedOwnUndefined:true});}
function observePack(car,pack,phase){
 const pointers=[];
 function visit(value,pointer){
  if(value===undefined){
   const match=pointer.match(/\/features\/(\d+)\/([^/]+)$/);assert(match,'Unexpected undefined outside feature: '+pointer);
   const rowIndex=Number(match[1]),property=match[2],feature=pack.features[rowIndex],descriptor=Object.getOwnPropertyDescriptor(feature,property);
   assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value')&&descriptor.value===undefined);
   const frame=frames.get(phase+'\0'+car.id),sourceRow=frame.input.find(f=>f.criterion===feature.criterion),regraded=frame.regraded.find(f=>f.criterion===feature.criterion),projected=frame.projected.find(f=>f.criterion===feature.criterion);
   assert(sourceRow&&regraded&&projected);assert.deepEqual(feature,projected);
   let producer;
   if(property==='gradeReviewStatus'){
    assert(feature.gradeReview);assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts earned retained-feature branch explicitly sets gradeReviewStatus undefined';
   }else if(property==='condition_label'){
    assert.equal(feature.buyerGrade,'check');assert(!Object.hasOwn(sourceRow,property)||sourceRow[property]===undefined);assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts Check branch retains source optional condition_label';
   }else if(property==='confirmation_needed'){
    assert.equal(feature.criterion,'novated_fbt');
    for(const row of [sourceRow,regraded]){const d=Object.getOwnPropertyDescriptor(row,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);}
    const raw=frame.research.feature_evidence.find(f=>f.variant_id===car.id&&f.criterion===feature.criterion);assert(raw);
    const snap=structuredClone(raw),audited=auditedFeature(raw);assert.deepEqual(raw,snap);
    const d=Object.getOwnPropertyDescriptor(audited,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);
    producer='launch-evidence.ts actual auditedFeature(raw exact novated_fbt row) creates confirmation_needed undefined';
   }else if(['buyerGrade','gradeReview'].includes(property)){
    assert.equal(feature.gradeReviewStatus,'review_required');assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts unmatched retained-feature branch withdraws optional review';
   }else assert.fail('Unclassified optional undefined: '+pointer);
   observations.push({phase,variantId:car.id,pointer,rowIndex,criterion:feature.criterion,property,ownUndefined:true,enumerable:true,producer,sourceProperty:{own:Object.hasOwn(sourceRow,property),valueKind:sourceRow[property]===undefined?'undefined':typeof sourceRow[property]},regradedProperty:{own:Object.hasOwn(regraded,property),valueKind:regraded[property]===undefined?'undefined':typeof regraded[property]},actualFinalProjectionMatched:true});
   pointers.push(pointer);return;
  }
  if(!value||typeof value!=='object')return;
  for(const key of Object.keys(value))visit(value[key],pointer+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));
 }
 visit(pack,'/packs/'+car.id);assertDeclaredJson(pack,'/packs/'+car.id,new Set(pointers));
}
function observeClaim(claim,pack,pointer,replay,record=true){
 assert.deepEqual(replay(),claim,'Actual citable producer replay must match');
 const clone=structuredClone(claim),pointers=[];
 function visit(value,path){
  if(value===undefined){
   const match=path.match(/\/sources\/(\d+)\/(limitation|checked)$/);assert(match,'Unclassified citable undefined: '+path);
   const i=Number(match[1]),key=match[2],citation=claim.sources[i],source=pack.sources.find(s=>s.id===citation.id);assert(source);
   const d=Object.getOwnPropertyDescriptor(citation,key);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);
   assert(!source[key==='limitation'?'access_limitation':'full_text_checked_date']);
   pointers.push(path);if(record)claimOmissions.push({pointer:path,sourceId:source.id,property:key,ownUndefined:true,enumerable:true,producer:'Actual citable.ts citations() falsey source-metadata branch; actual factClaim/featureClaim replay matches'});
   delete clone.sources[i][key];return;
  }
  if(!value||typeof value!=='object')return;
  for(const key of Object.keys(value))visit(value[key],path+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));
 }
 visit(claim,pointer);assertDeclaredJson(claim,pointer,new Set(pointers));assert.deepEqual(JSON.parse(JSON.stringify(claim)),clone);return clone;
}

for(const car of before){const pack=initial.pack(car.id,{data:base,cars:before});beforePacks[car.id]=pack;assert.equal(pack.features.length,69);observePack(car,pack,'before');}
let earnedCells=0,roadsideRefreshes=0,driveawayRefreshes=0;const gradeCounts={},availabilityClaims=[];
for(const car of after){
 const pack=final.pack(car.id,{data,cars:after});afterPacks[car.id]=pack;assert.equal(pack.features.length,69);assert.equal(new Set(pack.features.map(f=>f.criterion)).size,69);observePack(car,pack,'after');
 for(const feature of pack.features){
  if(feature.criterion==='roadside_assistance'){const f=car.facts.roadside_assistance;assert.equal(feature.value,String(f.value));assert.equal(feature.buyerGrade,'confirmed');assert.equal(feature.status,'standard');assert.equal(feature.verification_state,'reviewed_brand_au_terms');assert.deepStrictEqual(feature.source_ids,f.sourceIds);for(const q of f.qualifications)assert(feature.conditions.includes(q));roadsideRefreshes++;}
  else if(feature.criterion==='driveaway_price'&&added.has(car.id)&&car.facts.price_aud.value!==null){const f=car.facts.price_aud;assert.equal(f.comparisonBasis,'Driveaway');assert.equal(feature.value,`A$${Number(f.value).toLocaleString('en-AU')}`);assert.equal(feature.buyerGrade,'reported');assert.deepStrictEqual(feature.source_ids,f.sourceIds);assert.equal(feature.verification_state,'reviewed_canonical_driveaway_price');driveawayRefreshes++;}
  else if(selected.has(car.id))assert.deepStrictEqual(feature,beforePacks[car.id].features.find(f=>f.criterion===feature.criterion),'Unrelated retained feature changed: '+car.id+'/'+feature.criterion);
  else assert(['not_verified','not_applicable'].includes(feature.status),'Unreviewed new equipment was promoted: '+car.id+'/'+feature.criterion);
 }
 for(const f of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===packet.id)){assert(hasEarnedBuyerGrade(f,data.sources,packet.reviewedAt));const claim=factClaim(pack,f,packet.reviewedAt);assert.equal(claim.buyerGrade,f.buyerGrade);assert.deepStrictEqual(claim.sources.map(s=>s.id),f.sourceIds);if(f.buyerGrade==='not_published'){assert.equal(f.value,null);assert.equal(claim.value,'Not published');}observeClaim(claim,pack,'/claims/'+claims.length+'/claim',()=>factClaim(pack,f,packet.reviewedAt));claims.push({variantId:car.id,key:f.key,claim});earnedCells++;}
 for(const feature of pack.features){const claim=featureClaim(pack,feature.criterion,feature.criterion,packet.reviewedAt);assert.deepStrictEqual(claim.sources.map(s=>s.id),[...new Set(feature.source_ids)]);observeClaim(claim,pack,'/feature-claims/'+featureClaims.length+'/claim',()=>featureClaim(pack,feature.criterion,feature.criterion,packet.reviewedAt));featureClaims.push({variantId:car.id,criterion:feature.criterion,claim});}
 const residualGT=car.id===expected.residualGT;assert.equal(isOnSale(car),!residualGT);assert.equal(isCurrentListEligible(car,data.sources,packet.reviewedAt),!residualGT);assert.equal(buyerAvailabilityText(car),residualGT?'Not confirmed':'On sale now');
 assert.equal(car.availabilityEvidence.physicalStockVerified,false);assert.equal(car.availabilityEvidence.factoryOrderAcceptanceVerified,false);
 for(const key of expected.coreKeys){const f=car.facts[key];assert(hasEarnedBuyerGrade(f,data.sources,packet.reviewedAt));gradeCounts[f.buyerGrade]=(gradeCounts[f.buyerGrade]??0)+1;}
 const claim=factClaim(pack,availabilityReportClaim(car),packet.reviewedAt);observeClaim(claim,pack,'/availability-claims/'+availabilityClaims.length+'/claim',()=>factClaim(pack,availabilityReportClaim(car),packet.reviewedAt));availabilityClaims.push({variantId:car.id,claim});assert.deepStrictEqual(claim.sources.map(s=>s.id),car.availabilityEvidence.sourceIds);
 assert.equal(car.facts.boot_l.value,402);assert.equal(car.facts.boot_l.buyerGrade,'confirmed');assert.equal(car.facts.boot_l.comparisonBasis,'Behind second row to package tray; method not stated');assert.equal(car.facts.width_mm.buyerGrade,'confirmed');assert.equal(car.facts.width_mm.comparisonBasis,'Overall width; mirror basis unknown');
 if(selected.has(car.id)){assert.equal(car.configurationEvidence.rankingEligible,true);assert.equal(car.configurationEvidence.completeVehicleCountEligible,false);assert.equal(car.facts.price_aud.buyerGrade,'reported');assert.equal(car.facts.price_aud.priceEvidence.rankingEligible,false);}
}
assert.equal(earnedCells,139);assert.equal(featureClaims.length,414);assert.equal(roadsideRefreshes,6);assert.equal(driveawayRefreshes,2);assert.equal(after.filter(isOnSale).length,5);assert.equal(after.filter(isOnSale).length-before.filter(isOnSale).length,2);
const {exclusionReason,rankAttribute,attributes}=require('./src/lib/discovery.ts');const policy={asOf:packet.reviewedAt},rankingProof=[],rankCounts={};
for(const attribute of attributes){const ranks=rankAttribute(after,data.sources,attribute.key,policy),ranked=ranks.groups.flatMap(g=>g.entries.map(e=>e.car.id));assert.deepStrictEqual(new Set(ranked),new Set(expected.rankingIds[attribute.key]));assert.equal(ranks.excluded.length,6-ranked.length);for(const group of ranks.groups)for(const entry of group.entries){assert.equal(entry.fact.comparisonBasis,group.basis);assert.equal(entry.fact.unit,group.unit);}rankCounts[attribute.key]={ranked,excluded:ranks.excluded};}
for(const car of after){for(const key of ['boot_l','price_aud','towing_braked_kg']){const reason=exclusionReason(car,car.facts[key],data.sources,policy);assert(reason);if(key==='boot_l'&&car.id!==expected.residualGT)assert.equal(reason,'Cargo measurement method is not established');rankingProof.push({variantId:car.id,key,reason});}if(car.id!==expected.residualGT){assert.equal(exclusionReason(car,car.facts.range_km,data.sources,policy),null);assert.equal(exclusionReason(car,car.facts.dc_charge_time_min,data.sources,policy),null);}else for(const k of ['range_km','dc_charge_time_min','seats'])assert.equal(exclusionReason(car,car.facts[k],data.sources,policy),'Not current/order-listed or evidenced outgoing new stock');}
for(const o of observations.filter(x=>x.phase==='after'&&selected.has(x.variantId))){assert(!['roadside_assistance'].includes(o.criterion));const prior=observations.find(x=>x.phase==='before'&&x.pointer===o.pointer&&x.criterion===o.criterion&&x.property===o.property);assert(prior,'Retained omission lacks exact before witness');if(o.property==='gradeReviewStatus')assert.deepStrictEqual(afterPacks[o.variantId].features[o.rowIndex].gradeReview,beforePacks[o.variantId].features[o.rowIndex].gradeReview);}
const {compareFacts}=require('./src/lib/compare.ts');const comparisonProof=[];
function pairCheck(a,b,key,state){const left=a.facts[key],right=b.facts[key],result=compareFacts(left,right);assert.equal(result.state,state,a.id+'/'+b.id+'/'+key);if(state==='comparable'){assert.equal(result.delta,right.value-left.value);}else{assert(!Object.hasOwn(result,'delta'));assert.equal(result.delta,undefined);}comparisonProof.push({left:a.id,right:b.id,key,leftBasis:left.comparisonBasis,rightBasis:right.comparisonBasis,result});}
for(let i=0;i<after.length;i++)for(let j=i;j<after.length;j++){const a=after[i],b=after[j];for(const k of ['boot_l','width_mm'])pairCheck(a,b,k,'different_basis');for(const k of ['range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','power_kw','length_mm','height_mm'])pairCheck(a,b,k,'comparable');pairCheck(a,b,'towing_braked_kg','unknown');pairCheck(a,b,'seats',added.has(a.id)||added.has(b.id)?'conditional':'comparable');pairCheck(a,b,'price_aud',a.facts.price_aud.value===null||b.facts.price_aud.value===null?'unknown':'conditional');pairCheck(a,b,'zero_to_100_s','conditional');}
assert.equal(comparisonProof.length,294);
const crossBasisProof=[];
for(const car of after.filter(c=>added.has(c.id))){for(const k of ['frunk_l','cargo_behind_first_row_roof_l','cargo_behind_second_row_roof_l']){const result=compareFacts(car.facts[k],car.facts[k]);assert.equal(result.state,'different_basis');assert(!Object.hasOwn(result,'delta'));crossBasisProof.push({variantId:car.id,key:k,result});}}
assert.equal(crossBasisProof.length,9);
const reconciliation=readJson(expected.reconciliation.path),allInventory=require('./src/lib/market-inventory-data.ts').default;
const inventory={...allInventory,records:allInventory.records.filter(r=>r.brand==='Ford'&&(!r.vehicleClass||['passenger','ute'].includes(r.vehicleClass))),unverifiedLeads:allInventory.unverifiedLeads.filter(r=>r.brand==='Ford'&&(!r.vehicleClass||['passenger','ute'].includes(r.vehicleClass)))};
const {buildMarketReconciliation,inventoryRecordId}=require('./scripts/reporting/m1-reconciliation.ts');
assert.deepStrictEqual(new Set(inventory.records.map(inventoryRecordId)),new Set(expected.inventoryIds));assert.equal(inventory.unverifiedLeads.length,0);
for(const review of reconciliation.currentVersionReviews)for(const v of review.versions){const c=after.find(c=>c.id===v.carId);assert(c);assert.equal(c.modelId,review.modelId);assert.equal(c.trim,v.trim);assert.equal(c.year,v.modelYear);}
const eligible=after.filter(c=>isCurrentListEligible(c,data.sources,packet.reviewedAt));assert.equal(eligible.length,5);
const c1=buildMarketReconciliation(reconciliation,eligible,inventory,packet.reviewedAt);assert.equal(c1.pass,false);assert.deepStrictEqual(c1.settledInventory,[]);assert.equal(c1.reviewedModels,1);assert.equal(c1.reviewedVersions,3);assert.deepStrictEqual(new Set(c1.reviewedVersionIds),selected);assert(!c1.issues.some(i=>i.code==='version_review'));assert.deepStrictEqual(new Set(c1.issues.filter(i=>i.code==='version_unreviewed').map(i=>i.reference)),new Set(expected.residualOnSaleIds));assert.equal(c1.issues.filter(i=>i.code==='inventory_unresolved').length,2);assert(c1.issues.some(i=>i.code==='independent_lists'));
const selectedCoverage=buildCoverageReport({cars:after,sources:data.sources,features:Object.values(afterPacks).flatMap(p=>p.features),inventory,m1Reconciliation:reconciliation},packet.reviewedAt);assert.equal(selectedCoverage.allCatalogueVersions,6);assert.equal(selectedCoverage.tierOneVersions,6);assert.equal(selectedCoverage.onSaleVersions,5);const progress=selectedCoverage.brandProgress.find(b=>b.brand==='Ford');assert(progress);assert.equal(progress.unreviewedCoreGrades,0);assert.equal(progress.missingSummaries,0);assert.equal(progress.criteria.C1,false);
const {storePortablePacks,hydratePortablePacks}=require('./src/lib/portable-packs.ts');
const snapshot=structuredClone(afterPacks),writtenExpected=structuredClone(afterPacks);
const stored=storePortablePacks(afterPacks);
assert.deepStrictEqual(afterPacks,snapshot);
assert.deepEqual(hydratePortablePacks(stored,data.sources),afterPacks);
for(const o of observations.filter(x=>x.phase==='after')){const row=writtenExpected[o.variantId].features[o.rowIndex];assert(Object.hasOwn(row,o.property));assert.equal(row[o.property],undefined);delete row[o.property];}
assert.deepEqual(JSON.parse(JSON.stringify(afterPacks)),writtenExpected);
assert.deepEqual(hydratePortablePacks(JSON.parse(JSON.stringify(stored)),data.sources),writtenExpected);assert.deepEqual(afterPacks,snapshot);
for(const [name,obj]of Object.entries({'selected-after-cars':after,'selected-packs':afterPacks,portable:stored,claims,'feature-claims':featureClaims,'availability-claims':availabilityClaims,'undefined-witnesses':observations,'claim-undefined-witnesses':claimOmissions}))fs.writeFileSync(out+'/'+name+'.json',JSON.stringify(obj,null,2)+'\n',{flag:'wx'});
const writtenPacks=readJson(out+'/selected-packs.json'),hydrated=hydratePortablePacks(readJson(out+'/portable.json'),data.sources);
assert.deepEqual(writtenPacks,writtenExpected);assert.deepEqual(hydrated,writtenExpected);
// Actual citable producers must agree for live packs and serialized/re-hydrated packs.
for(const row of claims){const fact=after.find(c=>c.id===row.variantId).facts[row.key];assert.deepEqual(factClaim(hydrated[row.variantId],fact,packet.reviewedAt),row.claim);}
for(const row of featureClaims)assert.deepEqual(featureClaim(hydrated[row.variantId],row.criterion,row.criterion,packet.reviewedAt),row.claim);
for(const row of availabilityClaims)assert.deepEqual(factClaim(hydrated[row.variantId],availabilityReportClaim(after.find(c=>c.id===row.variantId)),packet.reviewedAt),row.claim);
for(const [name,rows]of [['claims',claims],['feature-claims',featureClaims],['availability-claims',availabilityClaims]]){
 const written=readJson(out+'/'+name+'.json');
 for(let i=0;i<rows.length;i++){
  const pack=afterPacks[rows[i].variantId],replay=()=>name==='claims'?factClaim(pack,after.find(c=>c.id===rows[i].variantId).facts[rows[i].key],packet.reviewedAt):name==='availability-claims'?factClaim(pack,availabilityReportClaim(after.find(c=>c.id===rows[i].variantId)),packet.reviewedAt):featureClaim(pack,rows[i].criterion,rows[i].criterion,packet.reviewedAt);
  const clone=observeClaim(rows[i].claim,pack,'/'+name+'/'+i+'/claim',replay,false);assert.deepEqual(written[i],{...rows[i],claim:clone});
 }
}
const reportProof=[];
for(const car of after){
 const pack=afterPacks[car.id],path='/cars/'+car.family+'/'+car.slug,report=makeReport([pack],path,packet.reviewedAt),markdown=reportMarkdown(report);
 assert.deepEqual(makeReport([hydrated[car.id]],path,packet.reviewedAt),report);assert.equal(reportMarkdown(makeReport([writtenPacks[car.id]],path,packet.reviewedAt)),markdown);
 fs.writeFileSync(out+'/'+car.id+'-report.md',markdown,{flag:'wx'});assert.equal(fs.readFileSync(out+'/'+car.id+'-report.md','utf8'),markdown);
 reportProof.push({variantId:car.id,path,markdownFile:out+'/'+car.id+'-report.md',actualLiveWrittenHydratedReportEqual:true});
}
assert.equal(defaultCalls,0);for(const f of ['src/lib/data.ts','src/lib/catalogue.ts','src/lib/research.ts'])assert(!require.cache[repo+'/'+f]);
assert.deepStrictEqual(base,baseSnapshot);assert.deepStrictEqual(before,beforeSnapshot);assert.deepStrictEqual(data,dataSnapshot);assert.deepStrictEqual(after,afterSnapshot);assert.deepStrictEqual(packet,packetSnapshot);assert.deepStrictEqual(afterPacks,snapshot);checkPins();

const result={status:'selected_actual_consumers_and_exact_serialization_witness_pass',packetSha256:fileHash(packetPath),beforeCars:3,afterCars:6,coreCells:102,coreGradeCounts:gradeCounts,earnedPacketCells:earnedCells,selectedFeatureClaims:featureClaims.length,roadsideRefreshes,driveawayRefreshes,additionBuilderProof,reportProof,otherRetainedFeaturesUnchanged:true,readInputs:reads,currentListProof:c1,selectedCoverage,rankingProof,rankCounts,untouchedFactProof,comparisonProof,crossBasisProof,negativeProof,producerProofs,optionalFeaturePaths:observations,optionalCitationPaths:claimOmissions,inMemoryPortableExact:true,writtenPortableExact:true,writtenClaimReadback:true,livePacksUnchanged:true,productionCatalogueHydration:false,defaultLoaderCalls:defaultCalls,sourceEdits:false,scopeTargetNeutrality:{selectedTierOneOnly:true,tierTwoTargets:0,nonFordTargets:0,fullCataloguePeerEquality:'NOT RUN; later full-stage gate'},expectedOnSaleDelta:2,fullProjectTypeScript:'UNPASSED; no compiler retry'};
assert.deepStrictEqual(buildMarketReconciliation(reconciliation,eligible,inventory,packet.reviewedAt),c1);assert.deepStrictEqual(selectedCoverage.reconciliation,c1);
const resultSnapshot=structuredClone(result),resultWritten=structuredClone(result),reportOmissions=[];
function reportShape(value,path,clone,parent){if(value===undefined){assert(/\/(brand|reference)$/.test(path),'Unexpected report undefined: '+path);const issue=c1.issues.find(i=>i.code==='independent_lists');assert(issue);assert.deepStrictEqual(parent,issue);assert.deepStrictEqual(Object.keys(issue).sort(),['brand','code','reason','reference']);const property=path.split('/').at(-1),d=Object.getOwnPropertyDescriptor(parent,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);reportOmissions.push({pointer:path,property,ownUndefined:true,enumerable:true,producer:'Actual buildMarketReconciliation independent_lists issue, exact replay; absent optional brand/reference'});return;}if(!value||typeof value!=='object')return;for(const key of Object.keys(value)){reportShape(value[key],path+'/'+key.replaceAll('~','~0').replaceAll('/','~1'),clone?.[key],value);if(value[key]===undefined)delete clone[key];}}
reportShape(result,'/result',resultWritten,null);assertDeclaredJson(result,'/result',new Set(reportOmissions.map(x=>x.pointer)));assert.deepStrictEqual(JSON.parse(JSON.stringify(result)),resultWritten);assert.deepStrictEqual(result,resultSnapshot);
fs.writeFileSync(out+'/report-undefined-witnesses.json',JSON.stringify(reportOmissions,null,2)+'\n',{flag:'wx'});fs.writeFileSync(out+'/addition-builder-proof.json',JSON.stringify(additionBuilderProof,null,2)+'\n',{flag:'wx'});fs.writeFileSync(out+'/result.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});assert.deepStrictEqual(readJson(out+'/result.json'),resultWritten);assert.deepStrictEqual(result,resultSnapshot);assert.deepStrictEqual(base,baseSnapshot);assert.deepStrictEqual(before,beforeSnapshot);assert.deepStrictEqual(data,dataSnapshot);assert.deepStrictEqual(after,afterSnapshot);assert.deepStrictEqual(packet,packetSnapshot);assert.deepStrictEqual(afterPacks,snapshot);checkPins();console.log(JSON.stringify({status:result.status,result:out+'/result.json',sha256:fileHash(out+'/result.json')}));
