from pathlib import Path
import sys,json,hashlib,subprocess,os,time
from datetime import datetime,timezone
manifest=Path(sys.argv[1]);expected=sys.argv[2];grantpath=Path(sys.argv[3])
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(manifest)==expected
m=json.loads(manifest.read_text());grant=json.loads(grantpath.read_text())
assert grant['authorized'] is True and grant['exclusiveHeavySlotGranted'] is True
assert grant['action']=='run_single_selected_ford_preflight'
assert grant['preparedManifestSha256']==expected
assert grant['command']==m['command']
assert grant['automaticRetry'] is False
assert m['timeoutSeconds']==180 and m['automaticRetry'] is False
assert m['command'][1:3]==['--max-old-space-size=448','--max-semi-space-size=1']
assert sha(__file__)==m['wrapper']['sha256']
pins=[m[k] for k in ['script','sourcePins','packet','reconciliation','expectedReview']]+json.loads(Path(m['sourcePins']['path']).read_text())
def checkpins():
 for p in pins:
  f=Path(p['path']);assert f.stat().st_size==p['bytes'];assert sha(f)==p['sha256'],str(f)
 assert sha(manifest)==expected
checkpins();out=manifest.parent/'run';out.mkdir(exist_ok=False)
def now():return datetime.now(timezone.utc).isoformat()
def write(name,value):
 with (out/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
cmd=m['command'];wrapped=['/usr/bin/timeout','--signal=TERM','--kill-after=10s','180s',*cmd]
write('invocation.json',{'at':now(),'cwd':m['workdir'],'command':cmd,'supervisedCommand':wrapped,'manifestSha256':expected,'grantSha256':sha(grantpath),'wrapperSha256':sha(__file__),'beforePinsPassed':True,'automaticRetry':False,'liveSourceMutationsAuthorized':False})
start=time.monotonic()
with (out/'stdout.log').open('x') as so,(out/'stderr.log').open('x') as se:
 p=subprocess.Popen(wrapped,cwd=m['workdir'],stdout=so,stderr=se,start_new_session=True)
 write('started.json',{'at':now(),'pid':p.pid,'processGroup':os.getpgid(p.pid)})
 _,status,usage=os.wait4(p.pid,0);code=os.waitstatus_to_exitcode(status);p.returncode=code
 so.flush();se.flush();os.fsync(so.fileno());os.fsync(se.fileno())
terminal={'at':now(),'exitCode':code,'rawWaitStatus':status,'elapsedSeconds':time.monotonic()-start,'maxRssKiB':usage.ru_maxrss,'stdoutSha256':sha(out/'stdout.log'),'stderrSha256':sha(out/'stderr.log'),'automaticRetry':False,'timeoutInterpretation':'Raw wait status retained; cause not inferred'}
write('terminal.json',terminal)
try:checkpins();write('after-pins.json',{'at':now(),'passed':True,'count':len(pins),'manifestSha256':expected})
except Exception as error:write('after-pins.json',{'at':now(),'passed':False,'error':repr(error)});raise
print(json.dumps(terminal));print((out/'stdout.log').read_text()[-3500:]);print((out/'stderr.log').read_text()[-4500:]);sys.exit(0 if code==0 else 1)
