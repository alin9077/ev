from pathlib import Path
import ast,difflib,hashlib,json,sys
R=Path('/workspace/scratch/586427eef9f2/roadmark-104');B=Path('/tmp/ford-packet/registration-v1')
assert len(sys.argv)==2,'prepare.py INDEPENDENT_FULL_STAGE_OUTPUT_ACCEPTANCE'
accepted=Path(sys.argv[1]);assert accepted.is_file()
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def put(p,b):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
def write(n,x):put(B/n,(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode())
packet=Path('/tmp/ford-packet/candidate-v4/ford-2026-10-15.json');recon=Path('/tmp/ford-packet/reconciliation-v1/m1-ford-market-reconciliation-2026-10-15.json')
assert pin(packet)['sha256']=='8d728412f21a36aac152357d04793fd38b5efc47438e5210af610f72e868ce00'
registry='data/m1-brand-updates/registry.json';loader='scripts/reporting/load.ts'
old=json.loads((R/registry).read_text());assert len(old['packets'])==31 and old['packets'][-1]=='nissan-2026-10-15.json'
new={**old,'packets':[*old['packets'],'ford-2026-10-15.json']};assert new['packets'][:-1]==old['packets']
s=(R/loader).read_text();imp='import nissanReconciliation from "../../data/m1-nissan-market-reconciliation-2026-10-15.json";';arg='      nissanReconciliation as M1MarketReconciliation,'
assert s.count(imp)==1 and s.count(arg)==1 and 'fordReconciliation' not in s
newload=s.replace(imp,imp+'\nimport fordReconciliation from "../../data/m1-ford-market-reconciliation-2026-10-15.json";').replace(arg,arg+'\n      fordReconciliation as M1MarketReconciliation,')
proposals={registry:(json.dumps(new,indent=2)+'\n').encode(),loader:newload.encode(),'data/m1-brand-updates/ford-2026-10-15.json':packet.read_bytes(),'data/m1-ford-market-reconciliation-2026-10-15.json':recon.read_bytes()}
rows=[];patch=''
for index,(rel,after) in enumerate(proposals.items()):
 p=R/rel;before=p.read_bytes() if p.exists() else None;assert (before is None)==(index>=2)
 put(B/'after'/rel,after)
 if before is not None:put(B/'before'/rel,before)
 rows.append(dict(relativePath=rel,target=str(p),operation='create' if before is None else 'replace',before=None if before is None else {k:v for k,v in pin(p).items() if k!='path'},after=pin(B/'after'/rel),beforeCopy=None if before is None else pin(B/'before'/rel)))
 patch+=''.join(difflib.unified_diff((before or b'').decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+rel if before is not None else '/dev/null',tofile='b/'+rel))
assert [r['operation'] for r in rows]==['replace','replace','create','create']
write('prepared-writes.json',rows);put(B/'registration.patch',patch.encode())
app=Path('/tmp/nissan-packet/registration-v1/apply.py').read_text().replace('apply_exact_nissan_registration','apply_exact_ford_registration')
ast.parse(app);put(B/'apply.py',app.encode())
write('applicator-syntax-check.json',dict(status='passed_python_ast_parse_only',applicator=pin(B/'apply.py'),executed=False,compilerRun=False))
proofpaths=[str(accepted),'/tmp/ford-packet/full-stage-v1/manifest.json','/tmp/ford-packet/full-stage-v1/full-stage-result-manifest-v1.json','/tmp/ford-review/full-stage-v1-readiness-review/manifest.json','/tmp/ford-packet/selected-readiness-v1/output-manifest.json','/tmp/ford-review/selected-result-v1-review/manifest.json','/tmp/ford-review/candidate-v4-review/manifest.json','/tmp/ford-packet/candidate-v4/manifest.json','/tmp/ford-packet/reconciliation-v1/manifest.json',str(packet),str(recon),'/tmp/kgm-packet/full-project-typescript-v1/run/terminal.json','/tmp/kgm-packet/full-project-typescript-v2/run/terminal.json','/tmp/kgm-packet/report-comparison-v2/typescript-failure-provenance.json']
proofs={}
def add(p):
 x=pin(p);prev=proofs.get(x['path']);assert not prev or prev==x;proofs[x['path']]=x
for p in proofpaths:add(p)
for p,key in [('/tmp/ford-packet/full-stage-v1/manifest.json','pins'),('/tmp/ford-packet/full-stage-v1/full-stage-result-manifest-v1.json','files'),('/tmp/ford-packet/selected-readiness-v1/output-manifest.json','files'),(str(accepted),'files')]:
 for x in json.loads(Path(p).read_text())[key]:
  assert pin(x['path'])==x,(x['path'],'retained proof drift');add(x['path'])
helper=['src/lib/brand-updates.ts','src/lib/brand-update-registry.ts','src/lib/evidence-consumers.ts','src/lib/discovery.ts','src/lib/data.ts','scripts/reporting/reports.ts','scripts/reporting/m1-reconciliation.ts','tests/brand-updates.test.ts']
m=dict(schemaVersion=1,status='frozen_preparation_only_requires_bundle_review_backup_freeze_release_and_root_application_grant',repo=str(R),writes=rows,proofs=list(proofs.values()),unchangedHelperPins=[pin(R/p) for p in helper],patch=pin(B/'registration.patch'),applicator=pin(B/'apply.py'),preparation=[pin(B/'prepare.py'),pin(B/'README.md'),pin(B/'prepared-writes.json'),pin(B/'applicator-syntax-check.json')],expected=dict(catalogue=433,tierOne=356,onSale=314,packets=32,changedExistingCars=3,unchangedPeers=427,newModels=0,newVersions=3,configurationUpdates=3,newSources=27,generatedFeatureRows=207,manualFeatureUpdates=0,C1=dict(pass_=False,reviewedModels=107,reviewedVersions=245,issues=186,settledInventory=65)),scope=dict(existingFiles=2,newFiles=2,helperSemantics='Unchanged accepted live helpers',packet='Exact accepted candidate-v4 packet',reconciliation='Exact accepted reconciliation-v1 successor',registry='Append only; preserve first31 ordered entries',reportLoader='One import and one last combineM1Reconciliations argument',reportImplementationChanged=False,testsChanged=False,heroChanged=False,immutableSnapshotChanged=False,sourceCapturesAddedToRepository=False),currentProjectTypeScript='UNPASSED: two preserved unknown-cause KGM SIGKILL failures; no compiler retry',automaticRetry=False,rootGrantRequired=True,backupFreezeReleaseRequired=True,heavyChecksAllowed=False,rollback='No automatic rollback or deletion; retain journal and exact before copies for separately authorised recovery')
m['expected']['C1']['pass']=m['expected']['C1'].pop('pass_')
write('manifest.json',m)
write('root-grant-template.json',dict(status='NOT_GRANTED',action='apply_exact_ford_registration',manifest=pin(B/'manifest.json'),reviewerAcceptance=None,backupLiveSourceFreezeReleased=False,allowedTargets=[x['target'] for x in rows],automaticRetry=False,heavyExecutionAuthorized=False))
print(json.dumps(dict(manifest=pin(B/'manifest.json'),proofs=len(proofs),writes=rows),indent=2))
