# Deferred work

- M4: Profile repeated catalogue/brand-packet replay and large evidence payloads on the expanded catalogue before claiming mobile performance; the through-Kia full suite took 16 minutes, which is a test-runtime measure rather than a mobile benchmark.

- Deferred read-only audit: inspect older registered packets for empty comparison-basis fallbacks in battery, cargo and mirror-width fields; document exact affected claims before proposing separately reviewed fixes. No affected-packet or correction claim is made before inspection.
