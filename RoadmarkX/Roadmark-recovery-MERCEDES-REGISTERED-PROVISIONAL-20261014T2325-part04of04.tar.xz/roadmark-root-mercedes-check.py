from pathlib import Path
import hashlib,json,subprocess,os,time,sys
root=Path('/workspace/scratch/586427eef9f2/roadmark-104'); out=root.parent/'roadmark-104-qa'/'mercedes-sequential-checks'
name=sys.argv[1]; cmd=sys.argv[2:]; target=out/name;target.mkdir(exist_ok=False)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
paths=sorted(p for d in ['src','scripts','tests','data'] for p in (root/d).rglob('*') if p.is_file())+[root/'tsconfig.json',root/'package.json',root/'pnpm-lock.yaml']
pins={str(p.relative_to(root)):digest(p) for p in paths};(target/'inputs-before.json').write_text(json.dumps(pins,indent=2)+'\n')
start=time.time()
with (target/'stdout.log').open('w') as so,(target/'stderr.log').open('w') as se:
 p=subprocess.Popen(cmd,cwd=root,stdout=so,stderr=se)
 _,status,usage=os.wait4(p.pid,0);code=os.waitstatus_to_exitcode(status);p.returncode=code
changed=[str(p.relative_to(root)) for p in paths if digest(p)!=pins[str(p.relative_to(root))]]
receipt={'command':cmd,'exitCode':code,'signal':-code if code<0 else None,'elapsedSeconds':time.time()-start,'maxRssKiB':usage.ru_maxrss,'inputCount':len(pins),'changedInputs':changed,'scope':'All src/scripts/tests/data files plus package/lock/tsconfig, not installed dependency bytes'}
(target/'terminal.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));print((target/'stdout.log').read_text()[-7000:]);print((target/'stderr.log').read_text()[-3000:]);sys.exit(0 if code==0 else 1)
