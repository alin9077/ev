import pathlib,json
R=pathlib.Path('/tmp/chery-research');p=json.loads((R/'normalized-evidence.json').read_text())
p['sources'].append(dict(key='service',url='https://cherymotor.com.au/owners/capped-price-service',title='Chery Australia capped-price servicing, MY25 and MY26 E5 range',publisher='Chery Australia',source_type='manufacturer_au_service_terms',published_date=None,file='current/service.html',textFile='current/service.txt'))
for s in p['sources']:
 if s['key']=='my27_release':s['published_date']='2026-09-14'
for r in p['variants']:
 r['facts'].append(dict(key='service_interval',value='Every 12 months or 20,000 km, whichever first; initial check at 1 month/1,000 km',sourceKeys=['service'],evidenceScope='explicit_au_range',label='Service interval',basis='Current Australian E5 service schedule',comparison='Scheduled service interval',reason='Maker current schedule explicitly covers MY25 and MY26 Omoda E5/Chery E5 and lists the initial 1-month/1,000-km check then 12-month/20,000-km increments.',qualifications=['The first seven scheduled services are capped for up to 7 years/140,000 km under the program terms.']))
 for f in r['features']:
  if f['criterion']=='voice_assistant':f['value']='Native Hello CHERY voice commands are listed. Command coverage and connectivity should be checked in the vehicle.'
  if f['criterion']=='warranty_service':f['value']+=' Scheduled servicing is every 12 months or 20,000 km, whichever first, after the initial 1-month/1,000-km check.';f['keys'].append('service_interval')
(R/'normalized-evidence.json').write_text(json.dumps(p,indent=2,ensure_ascii=False)+'\n')
