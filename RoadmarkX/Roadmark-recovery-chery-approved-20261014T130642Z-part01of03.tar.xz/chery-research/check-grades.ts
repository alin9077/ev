import fs from 'node:fs';
import {hasEarnedBuyerGrade} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/evidence-grading.ts';
const p=JSON.parse(fs.readFileSync('/tmp/chery-research/chery-2026-10-14.json','utf8'));
for(const f of [...p.facts.map((x:any)=>x.after),...p.brandTerms.map((x:any)=>x.fact),...p.features.map((x:any)=>x.after)])if(!hasEarnedBuyerGrade(f,p.sources,'2026-10-14'))console.log('BAD',f.key||f.criterion,f.buyerGrade,f.sourceIds||f.source_ids);
