import pathlib,json
R=pathlib.Path('/tmp/chery-research');p=json.loads((R/'normalized-evidence.json').read_text())
for r in p['variants']:
 fs=r['features'];urban='Urban' in r['trim'];my26=r['modelYear']==2026
 def feat(c,v,keys,**kw):fs.append(dict(criterion=c,value=v,keys=keys,**kw))
 feat('battery_chemistry','Lithium iron phosphate (LFP) battery; published capacity is 58.9 kWh with gross/usable basis unspecified.',['battery_chemistry','battery_kwh'])
 feat('spare_tyre','Full-size spare wheel is standard.',['equipment_full_size_spare_wheel','spare_wheel'])
 feat('audio_system','Six-speaker sound system.' if urban else 'Eight-speaker Sony sound system (four speakers and four tweeters).',['equipment_audio_speakers']+([] if urban else ['equipment_audio_brand']))
 feat('screens_hud','12.3-inch instrument display and 12.3-inch infotainment touchscreen. No head-up-display claim is established here.',['equipment_driver_display_in','equipment_infotainment_in'])
 if not urban:feat('glass_roof','Powered slide-and-tilt sunroof with a retractable sunshade.',['equipment_power_sunroof','equipment_roof_type'])
 feat('child_seats','Two ISOFIX positions and three top-tether anchors are listed.',['equipment_isofix_positions','equipment_top_tether_positions'])
 feat('home_charging','Type 2 AC charging: up to 6.6 kW on single phase or 10.3 kW on three phase.',['ac_single_phase_kw','ac_kw','charge_connector_ac'],grade='check',conditions='The 10.3 kW figure requires suitable three-phase supply; home wiring and charging equipment determine available power.')
 if my26:feat('charging_cable','Portable IC-CPD/trickle-charger inclusion needs confirmation: the MY26 sheet says included, while the current model-page footnote says not included.',['equipment_portable_evse_status'],grade='check',conditions='Two current maker sources disagree; confirm the supplied charging equipment on the purchase contract.')
 else:feat('charging_cable','The MY25.5 sheet explicitly says the portable IC-CPD/trickle charger is not included with the vehicle.',['equipment_portable_evse_included'])
(R/'normalized-evidence.json').write_text(json.dumps(p,indent=2,ensure_ascii=False)+'\n')
print([(r['trim'],len(r['facts']),len(r['features'])) for r in p['variants']])
