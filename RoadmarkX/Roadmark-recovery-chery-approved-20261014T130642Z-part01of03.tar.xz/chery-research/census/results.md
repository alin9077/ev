# Australian Chery BEV census

Checked: **14 October 2026**, approximately 12:05–12:14 UTC. Scope: Chery-badged Australian passenger cars/SUVs/utes, including former Chery Omoda E5. Excludes vans/trucks, hybrids/PHEVs, used cars and demonstrators. Chery Group sibling brands are separate marques and are not silently folded into Chery.

## Decision-ready result

- **Current manufacturer range: one BEV model, E5; one current MY26 grade, Ultimate.** Chery's live range navigation distinguishes E5 “Available Now” from New E5 “Coming soon.” The current E5 page has a single Ultimate grade card and a colour configurator. Its linked specification sheet explicitly says MY26, Ultimate Variant. [S1–S4]
- **MY27 E5: announced/forthcoming, not verified orderable.** The live new-model page remains coming soon. Chery's 14 September release defers pricing and availability until closer to dealer arrival. It does not explicitly establish the MY27 trim name as Ultimate. Do not carry the MY26 price or trim assumption into an orderable MY27 record. [S5–S6]
- **Residual/earlier-version NEW advertising exists for E5 Urban MY25.5 and E5 Ultimate MY25.5.** Exact dealer listing fields and status are below. These establish advertised supply, not physical stock inspection or a guarantee the car remains unsold. Calendar/build year is not the same as MY designation. [S7–S11]
- **No fresh, specific Australian dealer NEW Omoda E5 BX/EX listing was verified.** Search still returns old NEW BX advertising, but the important Footscray page is now 404 and Northern Beaches Carsales listing is 410 Gone. Do not count either as current. EX examples found were demo/used, not new. This is an unresolved nationwide residual-stock census, not proof that zero new BX/EX remain.
- **Q/QQ3 is future, not a verified Australian order-list entry.** September independent reporting says 2027; August reporting points to mid-2027. No current AU maker model/configurator/order-list entry, local grade list or confirmed AUD price was found. [S12–S14]

## Recommended version records

| Version | Census treatment | Price basis established | Availability evidence |
|---|---|---|---|
| E5 Ultimate MY26 | Current orderable manufacturer version | Chery's 8 April 2026 announcement: from AUD 37,990 driveaway. Fresh Brisbane City specific NEW vehicle: AUD 37,990 driveaway. Current maker price field is postcode-dependent, so no fresh national price quote is claimed | Maker expressly says sole MY26 grade and available to order; live model, October offer and current MY26 sheet remain active |
| E5 Urban MY25.5 | Include as earlier-version NEW advertised supply | Portside: AUD 36,990 driveaway for its specific listed vehicle | Fresh dealer detail page: NEW, 2025/MY25.5, C11257 |
| E5 Ultimate MY25.5 | Include as earlier-version NEW advertised supply, with dealer MY-label caveat | Wakeling: **AUD 39,840 driveaway** at fresh fetch, not indexed AUD 38,490 | Fresh dealer detail page: NEW, advertised 2026/MY25.5, stock 618777, 9 km, build May 2026/compliance June 2026 |
| E5 Urban MY25 | Historical; current NEW unverified | No current price established | Search examples were demos or generic model/broker descriptions |
| E5 Ultimate MY25 | Historical; current NEW unverified | No current price established | Search examples were demos |
| Omoda E5 BX MY24 / EX MY24 | Historical; current NEW unverified | No current price established | Stale, gone or demo/used leads; see exclusions |
| E5 MY27, final grade name unconfirmed | Forthcoming; do not count as current orderable | Not announced in inspected maker sources | Coming-soon maker page and September announcement |
| Q / QQ3, AU MY/grades unconfirmed | Future watchlist; do not count as current orderable | No confirmed AUD amount | 2027/mid-2027 reporting, absent from current AU maker range |

A listing's asserted MY25.5 is preserved as advertised. It should not be automatically changed to MY26 merely because the title/build year is 2026, nor treated as engineering authentication of the individual VIN. Dealer boilerplate often mixes old and new specs.

## Fresh NEW dealer evidence

All URLs below were checked 14 October 2026. A 200 response only matters when the final URL remains the specific vehicle and the body retains its listing.

1. **Portside Chery Adelaide West, Albert Park SA**: 2025 Chery E5 Urban MY25.5; NEW; Titan Green; stock **C11257**; VIN **LNNABDCX2TD210911**; odometer not supplied; **AUD 36,990 Drive Away**, with on-road/government charges included. Specific page remained live. Dealer comments incorrectly/at least inconsistently say 150 kW, whereas official MY25.5 sheet says 155 kW. Use maker sheet for version specs, and obtain individual-car verification before purchase. Capture: `portside-urban-new.txt`. [S7]
2. **Wakeling Automotive / Paul Wakeling Motor Group, Campbelltown NSW**: 2026 Chery E5 Ultimate Auto MY25.5; **Category: New**; Space Black; 9 km; stock **618777**; VIN **LNNABDCX1TD209684**; build May 2026; compliance June 2026. Fresh price **AUD 39,840 Drive Away**. Search extraction still advertises AUD 38,490, demonstrating why cached search price is not the current verified figure. Capture: `wakeling-ultimate-new-2026.txt`. [S8]
3. **Brisbane City Chery, Bowen Hills QLD**: 2026 E5 Ultimate MY26; NEW; Lunar White/Black Roof; 3 km; stock **C259076**; VIN **LNNABDCX8TD259076**; **AUD 37,990 Drive Away**. Specific live page provides current vehicle-level corroboration of MY26 supply/price. Capture: `brisbane-ultimate-my26-new.txt`. [S9]
4. **Chery Bartons, Wynnum QLD**: 2026 E5 Urban; NEW; Lunar White; 25 km; **D174515**, VIN **LNNABDCXXTD174515**; **AUD 35,990 Drive Away**. Direct dealer page is live; direct title does not establish MY. CarsGuide maps same VIN/stock to MY25.5. Treat as additional Urban NEW supply, with MY25.5 assignment corroborated only by the third-party listing. Capture: `bartons-urban-new.txt`. [S10]
5. **Chery Townsville / Q Automotive**: 2026 E5 Urban; NEW in dealer model stock card and page title; Titan Green; 24 km; **D22272**; VIN **LNNABDCX7TD174505**; build/compliance year 2026; **AUD 36,990 Drive Away**. No MY code visible on inspected direct detail page. Additional Urban supply; do not invent MY26. Capture: `townsville-urban-new.txt`. [S11]

No enquiry, test-drive booking, finance application, reservation, account action or CAPTCHA was performed.

## MY25.5 specification authority and trim split

Official **edition 1.13 / September 2025**, expressly **MY25.5 effective from May 2025 production**, is saved intact as `e5-my25-5-spec-v113.pdf`; matching layout-preserving text and page 3/page 6 PNG captures are supplied. [S15]

- Both grades: FWD, permanent-magnet motor, 155 kW, 288 Nm; 58.9 kWh LFP battery; 430 km WLTP / 505 km NEDC; Type 2 AC, CCS2 DC; 6.6 kW single-phase / 10.3 kW three-phase AC
- **Heat pump: Ultimate only**; Urban has 19 L front storage, unavailable on Ultimate because of heat pump location
- Urban: manual front-seat adjustment, fabric with synthetic-leather bolsters; Ultimate: powered front seats, synthetic leather, heated front and rear outboard seats, heated steering wheel and ambient lighting
- The charger row specifies **30–80% in 30 minutes using a 130 kW charger**; it does not by itself prove vehicle maximum DC acceptance or a 10–80% time
- Towing table explicitly gives **750 kg non-braked**, not a separate braked figure

The MY26 sheet is `e5-my26-spec-v115.pdf`, edition 1.15 / April 2026, cover “Ultimate Variant.” It preserves the common powertrain values above, specifies a heat pump, and says an IC-CPD/trickle charger is included; MY25.5 says not included. No verified current maker MY25.5 list-price terms were found. Retain dealer asking-price basis rather than adopting a historical RRP as current.

## Stale/conflicting leads and exclusions

- Footscray old `https://cheryfootscray.com.au/models/chery-omodae5/` search snapshot: 2025 BX NEW, 10 km, AUD 42,990 driveaway (variant-query snapshot AUD 44,602); **fresh HTTP 404**. Current Footscray homepage has the newer E5 range, not that listing. Exclude current NEW claim.
- Northern Beaches BX MY24, stock 107214, Carsales OAG-AD-24137826: old search says dealer NEW and an expired February clearance; **fresh web open returns 410 Gone**. Exclude.
- Wakeling 2025 Ultimate MY25.5 OAG-AD-26245575, stock 297022: indexed NEW/AUD 35,990, but fresh detail URL redirects to `/stock`. Exclude current specific listing.
- Chery Rockhampton OAG-AD-26063189: indexed 2026 Ultimate MY25.5 NEW, AUD 38,490; fresh fetch redirects to `/search/new-used-and-demo-cars`. Exclude current specific listing despite retained search snippet.
- Lander Blacktown Autotrader 15342635: indexed 2025 Ultimate MY25.5 NEW, stock D209724, AUD 32,990 driveaway; text instead calls it Urban and an “advanced hybrid powertrain.” Direct vehicle detail not independently verified. **Unresolved exact trim/year and current availability**, not preferred evidence.
- Sutherland EX MY24 stock CHC39877 and Hoppers Crossing EX stock 438932 are explicitly demos. Low mileage alone does not make them new.
- Generic CarsGuide “New: Available to order”/RRP entries and leasing/broker catalogues do not prove a specific official dealer still supplies a discontinued version.
- Current Chery maker navigation includes petrol/hybrid C5 and Tiggo models, Tiggo 7/8/9 Super Hybrid PHEVs and Stockman diesel PHEV. They are excluded from BEV scope. Chery Group Jaecoo, Omoda, Lepas, iCAUR, Jetour and Freelander need their own marque census; global Chery EVs do not establish AU availability.

## Remaining uncertainty / completion boundary

Manufacturer-range completeness is well supported by live navigation, model/grade card, current spec sheet and September independent reporting that E5 is Chery Australia's only showroom EV. **Nationwide residual NEW-stock completeness remains unresolved**: this was a targeted public-source check, not every authorised dealer's inventory or a dealer contact exercise. In particular, fresh BX/EX NEW supply and pre-May-2025 E5 MY25 NEW supply remain unverified. MY25.5 dealer titles/build years and boilerplate should be verified against individual vehicle documentation if exact physical specification matters. No positive MY27 or Q orderability evidence was found, and future announcements should be rechecked before changing their status.

## Sources

S1. https://cherymotor.com.au/ — live range navigation, captured `homepage.txt`

S2. https://cherymotor.com.au/models/chery-e5-electric-suv — single current Ultimate grade, colour configurator and live specification download; `current-e5.txt`

S3. https://cherymotor.com.au/news/chery-strengthens-ev-value-my26-e5-ultimate-now-priced-37990-driveaway — maker 8 Apr 2026, sole MY26 variant/orderability and announced driveaway price; `my26-release.txt`

S4. https://cherymotor.com.au/sites/default/files/2026-04/233_25_Chery_E5_Spec_Sheet_2025_Rebrand_v115%20%282%29%20%281%29.pdf — current linked MY26 sheet, edition 1.15; `e5-my26-spec-v115.pdf`

S5. https://cherymotor.com.au/models/new-e5 — live MY27 coming-soon page; `new-e5.txt`

S6. https://cherymotor.com.au/news/my-27-chery-e5-updated-enhanced-comfort-technology-and-convenience-features — maker 14 Sep 2026 announcement; `my27-release.txt`

S7. https://www.portsidecheryadelaidewest.com.au/new-cars/for-sale/chery/e5/2025/urban/my25.5/4092096/

S8. https://wakelingautomotive.com.au/stock/details/OAG-AD-26178986/2026-chery-e5-new

S9. https://www.brisbanecitychery.com.au/new-cars/for-sale/chery/e5/2026/ultimate/my26/4078187/

S10. https://www.bartons.net.au/cars/new-lunar-white-2026-chery-e5-d174515 ; matching third-party MY25.5 record https://www.carsguide.com.au/car/15220848/chery/e5/qld/wynnum/suv

S11. https://www.qautomotive.com.au/cars/new-titan-green-2026-chery-e5-c22272 ; explicit NEW stock card https://www.qautomotive.com.au/models/e5

S12. https://www.carexpert.com.au/car-news/chery-shrugs-off-geely-surge-as-stockman-ute-other-new-models-loom — 16 Sep 2026, Q on sale next year; separate brand/range context

S13. https://www.buzzsprout.com/2574843/episodes/19655289-episode-85-quick-charge-tesla-expands-v2l-denza-z9gt-approved-and-chery-q-timing-locked-in?t=0 — 17 Aug 2026 independent secondary reporting, mid-2027 target; not an official order list

S14. https://www.drive.com.au/news/chery-q-electric-hatch-coming-to-australia-mid-2027/ — exact link recovered from Reddit news link; direct source could not be opened. Do not imply full article verified

S15. https://cherymotor.com.au/sites/default/files/2025-09/233_25_Chery_E5_Spec_Sheet_2025_Rebrand_v113.pdf — official MY25.5 technical/equipment authority

S16. https://www.carexpert.com.au/car-news/2027-chery-e5-electric-suv-refresh-brings-bolder-styling-more-luxury-features — 15 Sep 2026 independent corroboration of sole current Ultimate and pending MY27 price/availability

S17. https://www.whichcar.com.au/news/chery-e5-smaller-lineup-sharper-pricing-stylish-small-electric-suv — 8 Apr 2026 independent corroboration that Urban was removed for MY26

S18. https://cherymotor.com.au/buying/offers — October 2026 current Ultimate offer; dynamic/postcode-dependent price not recovered; `offers-october.txt`

`capture_manifest.json` records exact fetch times, original/final URLs, status, body byte count and SHA-256. Sanitised text captures omit scripts, hidden-input values and all HTTP cookie/auth headers. PDFs are original source files. `independent-web-captures.json` preserves public web-tool extractions where direct site retrieval was unavailable. No authenticated content or token headers were saved.
