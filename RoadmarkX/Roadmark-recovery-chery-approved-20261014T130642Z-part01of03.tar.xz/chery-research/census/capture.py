import urllib.request, pathlib, json, hashlib, datetime, concurrent.futures
from html.parser import HTMLParser
root=pathlib.Path('/tmp/chery-research/census')
class Txt(HTMLParser):
 def __init__(self): super().__init__();self.ignore=0;self.out=[];self.links=[]
 def handle_starttag(self,tag,attrs):
  if tag in ('script','style','noscript'): self.ignore+=1
  if tag=='a':
   d=dict(attrs)
   if d.get('href','').startswith(('http','/')): self.links.append(d['href'])
  if tag in ('p','div','section','li','h1','h2','h3','tr','br'): self.out.append('\n')
  if tag=='img' and not self.ignore:
   alt=dict(attrs).get('alt');
   if alt:self.out.append('[Image: '+alt+']')
 def handle_endtag(self,tag):
  if tag in ('script','style','noscript') and self.ignore:self.ignore-=1
 def handle_data(self,data):
  if not self.ignore: self.out.append(data)
def save(item):
 name,url=item
 rec={'name':name,'url':url,'checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  r=urllib.request.urlopen(url,timeout=35);data=r.read();rec.update(status=r.status,final_url=r.url,byte_count=len(data),raw_sha256=hashlib.sha256(data).hexdigest())
  if name.endswith('.pdf'): out=data
  else:
   p=Txt();p.feed(data.decode('utf-8','replace'));text='\n'.join(' '.join(x.split()) for x in ''.join(p.out).splitlines() if x.strip());out=(json.dumps(rec,ensure_ascii=False)+'\n\n'+text+'\n\nLINKS\n'+'\n'.join(dict.fromkeys(p.links))).encode()
  (root/name).write_bytes(out);rec['capture_file']=name
 except Exception as e:rec['error']=str(e)
 return rec
items=[
('homepage.txt','https://cherymotor.com.au/'),
('current-e5.txt','https://cherymotor.com.au/models/chery-e5-electric-suv'),
('new-e5.txt','https://cherymotor.com.au/models/new-e5'),
('my26-release.txt','https://cherymotor.com.au/news/chery-strengthens-ev-value-my26-e5-ultimate-now-priced-37990-driveaway'),
('my27-release.txt','https://cherymotor.com.au/news/my-27-chery-e5-updated-enhanced-comfort-technology-and-convenience-features'),
('e5-my26-spec-v115.pdf','https://cherymotor.com.au/sites/default/files/2026-04/233_25_Chery_E5_Spec_Sheet_2025_Rebrand_v115%20%282%29%20%281%29.pdf'),
('e5-my25-5-spec-v113.pdf','https://cherymotor.com.au/sites/default/files/2025-09/233_25_Chery_E5_Spec_Sheet_2025_Rebrand_v113.pdf'),
('portside-urban-new.txt','https://www.portsidecheryadelaidewest.com.au/new-cars/for-sale/chery/e5/2025/urban/my25.5/4092096/'),
('wakeling-ultimate-new-2025.txt','https://www.wakelingautomotive.com.au/stock/details/OAG-AD-26245575/2025-chery-e5-new'),
('wakeling-ultimate-new-2026.txt','https://wakelingautomotive.com.au/stock/details/OAG-AD-26178986/2026-chery-e5-new'),
('footscray-omoda-e5.txt','https://cheryfootscray.com.au/models/chery-omodae5/'),
('carexpert-my27.txt','https://www.carexpert.com.au/car-news/2027-chery-e5-electric-suv-refresh-brings-bolder-styling-more-luxury-features'),
('carexpert-q.txt','https://www.carexpert.com.au/car-news/chery-q-electric-hatch-set-for-australia-as-cut-price-byd-atto-1-rival')]
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
 records=list(ex.map(save,items))
(root/'capture_manifest.json').write_text(json.dumps(records,indent=2))
print(json.dumps(records,indent=2))
