import urllib.request,pathlib,json,re,html,sys,hashlib,datetime
from lxml import html as lh
R=pathlib.Path('/tmp/chery-research');(R/'current').mkdir(exist_ok=True)
manifest=[]
def capture(key,url):
 p=R/'current'/key
 try:
  with urllib.request.urlopen(url,timeout=65) as r:b=r.read();final=r.url;status=r.status
  rawhash=hashlib.sha256(b).hexdigest(); note='No response headers or cookies persisted.'
  if not key.endswith('.pdf'):
   root=lh.fromstring(b)
   for x in root.xpath('//script|//style|//input[@type="hidden"]|//iframe'):x.getparent().remove(x)
   for x in root.iter():
    for a in list(x.attrib):
     if a.lower().startswith('on') or any(s in a.lower() for s in ['token','csrf','nonce','session']):del x.attrib[a]
   b=lh.tostring(root,encoding='utf-8',method='html'); note+=' Scripts, styles, iframes, hidden input values and runtime capability attributes removed before persistence; visible factual content retained.'
   txt='\n'.join(x.strip() for x in root.text_content().splitlines() if x.strip());p.with_suffix('.txt').write_text(txt)
  p.write_bytes(b)
  row=dict(key=key,url=url,finalUrl=final,status=status,bytes=len(b),checkedAt='2026-10-14',sha256=hashlib.sha256(b).hexdigest(),originalResponseSha256=rawhash,redactionNote=note);manifest.append(row)
  print(key,status,len(b),final,flush=True)
 except Exception as e:manifest.append(dict(key=key,url=url,error=str(e)));print(key,type(e).__name__,str(e),flush=True)
if __name__=='__main__':
 for key,url in json.loads(sys.argv[1]):capture(key,url)
 f=R/'capture-log.json';old=json.loads(f.read_text()) if f.exists() else [];f.write_text(json.dumps(old+manifest,indent=2)+'\n')
