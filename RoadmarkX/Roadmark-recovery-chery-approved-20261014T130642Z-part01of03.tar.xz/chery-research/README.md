# Chery M1 research packet — 14 October 2026

## Result and boundary

Three exact Australian E5 versions: current MY26 Ultimate plus MY25.5 Urban and Ultimate with specific dealer NEW advertisements. The two MY25.5 records preserve the advertised model-year designation separately from calendar/build year. Advertising does not verify physical stock, an unsold car or accepted orders.

All 51 on-sale core cells have earned reviews: 34 Confirmed, 3 Check, 11 Reported, 3 Not published (exact 10–80% duration). The packet has 312 specific fact edits, three shared brand terms, 72 guarded equipment replacements and three supported strength/trade-off pairs.

Current MY26 price is AUD 37,990, Reported by RedBook as its exact driveaway new-price guide, corroborated by a live NEW dealer advertisement. The maker's postcode selector stalled and its April launch price is not assumed to extend a current offer. MY25.5 Urban uses Portside's AUD 36,990 driveaway advertisement; Ultimate uses Wakeling's freshly observed AUD 39,840, not the older indexed price. No prices were converted or estimated.

MY26 and MY25.5 maker sheets specify 30 minutes from 30–80% using a 130 kW charger. That station rating is kept separate from a Reported vehicle maximum, and no 10–80% conversion was made. Braked towing is Reported from exact RedBook entries; maker non-braked figures remain separate. The MY26 portable charger conflict is explicit. MY25.5 heat pump and 19-litre front-storage differences are trim-specific.

C3/C4/C6 pass in the staged brand report. C1/C2/C5 and research closure remain open. Nationwide older Omoda E5 BX/EX and pre-May MY25 residual NEW supply is unresolved. MY27 E5 remains coming soon without a confirmed final grade list; Q is future 2027. No new orderable identities were invented for those leads. Brand directories are not presented as the two whole-market independent lists.

## Review and recovery inputs

- Source packet: data/m1-brand-updates/chery-2026-10-14.json
- Reconciliation: data/m1-chery-market-reconciliation-2026-10-14.json
- Complete research work directory: /tmp/chery-research
- Source map/capture hashes, exact core matrix, census report and sanitisation audit are present there; current source captures and original PDFs are retained
- Original complete pre-Chery research/catalogue NDJSON input snapshot is in replay-snapshot, with its original index and hash manifest. It was captured after registered BMW
- Existing full before fixtures are separate. The complete new-version feature baseline was produced once after canonical facts, prices and brand terms were stable: 138 rows, generation count 1. It has not been refreshed to mask mismatches
- Full self-stage report passed. Four later feature wording simplifications did not change the canonical hash, facts, grades, summaries or report counts; final actual-pack/citable/portable replay passed again. Both receipts and original pre-wording packet are preserved
- Independent reviewer result remains the integration gate. Neither packet registry nor report loader has been changed by the research worker

## Verification performed before independent review

Initial live capture: exit 0, 134.8 seconds, peak RSS 846,016 KiB at 768 MiB Node heap. Stable canonical new-feature baseline: exit 0, 6.2 seconds, peak RSS 774,916 KiB. Full self-stage: exit 0, 147.5 seconds, peak RSS 916,920 KiB. Final wording replay: exit 0, 12.2 seconds, peak RSS 774,544 KiB. All runs were serialized.

Actual pack pipeline, citable sources, full baseline equality, portable round-trip equality, unchanged inputs and unchanged other-brand catalogue passed. No full aggregate suite, production build, public publication or real-device verification is claimed.

No login/account action, dealer enquiry, test-drive booking, order, CAPTCHA solve or user-computer operation occurred. Dot cloud-browser quote attempts are recorded factually without runtime identifiers or screenshots. Public captures have no response-cookie/authentication headers, scripts, hidden form fields or runtime-capability values. PDF page renderings are source-review evidence, not browser screenshots.
