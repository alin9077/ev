"""Independent bounded immutable-output inspection; no production imports or regeneration."""
from pathlib import Path
import json, hashlib, datetime, collections
ROOT=Path('/tmp/xpeng-staging-plan')
M=json.loads((ROOT/'manifests/canonical-v1.json').read_text())
A=M['anchors']
def digest(p):
    p=Path(p); h=hashlib.sha256(); size=0
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk); size+=len(chunk)
    return {'path':str(p),'bytes':size,'sha256':h.hexdigest()}
def locate(r):
    p=Path(A[r['anchor']])/r['file']; assert p.resolve()==p and p.is_file(); return p
def read(r):
    p=locate(r); d=digest(p); assert d['sha256']==r['sha256']; assert r.get('bytes',d['bytes'])==d['bytes']; return json.loads(p.read_text())
def rowdigest(rows):
    h=hashlib.sha256();size=0
    for row in rows:
        b=(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n').encode();h.update(b);size+=len(b)
    return {'rows':len(rows),'bytes':size,'sha256':h.hexdigest()}
OUT=ROOT/'staging-artifacts/canonical-v1'
receipt=json.loads((OUT/'core-phase-receipt.json').read_text())
assert digest(OUT/'core-phase-receipt.json')['sha256']=='ac6c4157bc8813f1028932f43573f38cbd8e0246ccb2a04ab350c6e9061f6884'
meta=read(receipt['canonicalMeta']); idx=read(meta['storageIndex']); rawidx=read(meta['rawResearchIndex']); trans=read(meta['transition']);claim=read(meta['originalCaptureClaim'])
assert receipt['status']==meta['status']=='captured_once_pending_independent_review'
assert meta['captureGenerationCount']==meta['generationCount']==meta['baselineGenerationCount']==1
assert claim['generationCount']==1 and claim['manifestSha256']==receipt['inputManifestSha256']==meta['inputManifestSha256']=='f9055d81d9e29d21a0a4efbca4e48ac1b1e2760ca314404d40a7ced59c0e54d0'
assert claim['independentReviewSha256']==receipt['independentReviewSha256']==meta['independentReviewSha256']=='c13cea9d065f39b770f63dfd9f7497cea5822f1d2ae8e305beca618962a5e18d'
assert claim['featureFreePacketSha256']==receipt['packetSha256']==M['packet']['sha256'];assert claim['outputDirectory']==M['output']['directory']
packet=read(meta['featureFreePacket']); original=read(M['featureFreePacket']); assert packet==original and packet['features']==[]
assert locate(meta['featureFreePacket']).read_bytes()==locate(M['featureFreePacket']).read_bytes();assert rowdigest([packet])==meta['featureFreePacketDigest']
cars=read(meta['selectedCars']);assert len(cars)==11;assert [c['id'] for c in cars]==M['existingIds']+M['newIds'];assert rowdigest(cars)==meta['selectedCarsDigest']
byid={c['id']:c for c in cars}; before={c['id']:c for c in read(M['selectedBeforeCars'])}
for f in packet['facts']:
    assert f['before']==before.get(f['variantId'],{}).get('facts',{}).get(f['after']['key']);assert byid[f['variantId']]['facts'][f['after']['key']]==f['after']
for t in packet['brandTerms']:
    for id in t['applicableVariantIds']:assert byid[id]['facts'][t['key']]==t['fact']
    for ex in t['exceptions']:
        f=byid[ex['variantId']]['facts'][t['key']];assert f!=t['fact']
for av in packet['availability']:
    c=byid[av['variantId']];assert c['availability']==av['after']['availability'];assert c['availabilityEvidence']==av['after']['evidence']
for s in packet['summaries']:
    c=byid[s['variantId']]
    for side in ['strength','tradeoff']:
        assert c['buyerSummary'][side]['label']==s[side]['label'];assert c['buyerSummary'][side]['text']==s[side]['text']
        for dep in s[side]['dependencies']:assert c['facts'][dep['key']]==dep['expected']
baseidx=read(M['baselineStorageIndex']);allhash=idx['cars']['carHashes'];assert len(allhash)==405 and len({r['id'] for r in allhash})==405
assert [r['id'] for r in allhash]==[r['id'] for r in baseidx['cars']['carHashes']]+M['newIds']
assert idx['cars']['baseline']==dict(M['baselineStorageIndex'],format='storage-index',rows=399)
assert idx['cars']['newIds']==M['newIds']; unchanged=0
for old,new in zip(baseidx['cars']['carHashes'],allhash):
    assert old['id']==new['id'] and old['afterSha256']==new['beforeSha256']
    if new['id'] not in byid: assert new['beforeSha256']==new['afterSha256'] and old['bytes']==new['bytes'];unchanged+=1
assert unchanged==394
for r in allhash:
    if r['id'] in byid:
        dg=rowdigest([byid[r['id']]]);assert dg['sha256']==r['afterSha256'] and dg['bytes']==r['bytes']
for r in allhash[399:]:assert r['beforeSha256'] is None
assert set(rawidx['research'])==set(idx['research'])==set(M['researchFields']) and len(idx['research'])==14
verified={}
for fields,wanted in [(rawidx['research'],meta['rawFieldDigests']),(idx['research'],meta['composedFieldDigests'])]:
    for key,r in fields.items():
        assert {k:r[k] for k in ['rows','bytes','sha256']}==wanted[key]
        p=locate(r)
        if str(p) not in verified:
            h=hashlib.sha256();size=0;count=0
            with p.open('rb') as f:
                for line in f:
                    assert line.endswith(b'\n') and line.strip();json.loads(line);h.update(line);size+=len(line);count+=1
            assert {'rows':count,'bytes':size,'sha256':h.hexdigest()}==wanted[key]
            verified[str(p)]={'path':str(p),**wanted[key]}
for key in M['researchFields']:
    if key!='metadata':assert rawidx['research'][key]==idx['research'][key]
rawmeta=json.loads(locate(rawidx['research']['metadata']).read_text());compmeta=json.loads(locate(idx['research']['metadata']).read_text());assert rawmeta==meta['rawMetadata']==trans['rawMetadata'];assert compmeta==meta['composedMetadata']==trans['composedMetadata'];assert list(rawmeta)==list(compmeta)
assert rawmeta['brand_update_packet_ids']==[packet['id']];assert compmeta['brand_update_packet_ids']==[p['id'] for p in M['registeredPackets']]+[packet['id']]
assert {k:v for k,v in rawmeta.items() if k!='brand_update_packet_ids'}=={k:v for k,v in compmeta.items() if k!='brand_update_packet_ids'}
assert trans['onlyChangedPath']=='metadata.brand_update_packet_ids';assert trans['compositionReviewSha256']==M['compositionReview']['sha256'];assert trans['phaseReviewSha256']==receipt['independentReviewSha256']
criteria=[json.loads(line)['key'] for line in locate(idx['research']['criteria']).read_text().splitlines()]
features=read(meta['newFeatures']);assert len(features)==414;assert len({(f['variant_id'],f['criterion']) for f in features})==414
assert list(dict.fromkeys(f['variant_id'] for f in features))==M['newIds']
for row in meta['perCar']:
    fs=[f for f in features if f['variant_id']==row['id']];assert len(fs)==69;assert sorted(f['criterion'] for f in fs)==sorted(criteria);assert all(f['model_id']==byid[row['id']]['modelId'] for f in fs);assert rowdigest(fs)=={k:row[k] for k in ['rows','bytes','sha256']}
assert collections.Counter((f.get('buyerGrade'),f['status']) for f in features)=={(None,'not_verified'):409,('confirmed','standard'):3,('reported','conditional'):2}
for f in features:
    if f.get('buyerGrade')=='confirmed':assert f['criterion']=='roadside_assistance' and f['variant_id'].startswith('xpeng_l03_')
    if f.get('buyerGrade')=='reported':assert f['criterion']=='driveaway_price' and f['variant_id'].startswith('xpeng_g6_gen1__my2025_')
assert meta['existingBeforeFeatures']==M['existingBeforeFeatures'];assert len(read(meta['existingBeforeFeatures']))==345
run=ROOT/'runs/canonical-v1';terminal=json.loads((run/'terminal.json').read_text());inv=json.loads((run/'invocation.json').read_text());assert all(terminal[k]==v for k,v in inv.items());assert terminal['returncode']==0 and terminal['signal'] is None and not terminal['timeoutReported'];assert (run/'stderr.log').read_text()==''
stdout=json.loads((run/'stdout.log').read_text());assert stdout['receipt']['sha256']==digest(OUT/'core-phase-receipt.json')['sha256']
assert meta['defaultLoaderCalls']==0 and not meta['freshFullValueLoaderExport'] and not meta['candidateRegistered']
result={'status':'accepted_original_xpeng_canonical_baseline','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'canonicalMetaSha256':receipt['canonicalMeta']['sha256'],'captureGenerationCount':1,'fullPacketAndSelectedCarsVerified':True,'all14RawAndComposedFieldsVerified':True,'all414OriginalFeatureRowsVerified':True,'packetSha256':M['packet']['sha256'],'manifestSha256':receipt['inputManifestSha256'],'phaseReviewSha256':receipt['independentReviewSha256'],'reconciliationSha256':'9f1f1342daf6fc6c27ab12600e2358ffe1c0bfdc4d24033dec45dc86fa42d11b','outputReceipt':digest(OUT/'core-phase-receipt.json'),'canonicalMeta':digest(locate(receipt['canonicalMeta'])),'canonicalOriginalPacket':digest(locate(meta['featureFreePacket'])),'canonicalSelectedCars':digest(locate(meta['selectedCars'])),'canonicalOriginalNewFeatures':digest(locate(meta['newFeatures'])),'originalCaptureClaim':digest(locate(meta['originalCaptureClaim'])),'verifiedUniqueFieldFiles':list(verified.values()),'all405CarHashesAndOrderClosedToAcceptedBaseline':True,'all394OtherBrandHashesUnchanged':True,'canonicalUnreviewedRows':409,'canonicalBrandRoadsideRows':3,'canonicalReportedDealerDriveawayRows':2,'terminal':terminal,'runPins':[digest(run/n) for n in ['terminal.json','invocation.json','stdout.log','stderr.log']],'reviewScript':digest(__file__),'limitations':['Only the original canonical feature-free fixture is accepted; do not recapture.','No final guarded feature packet, final actual consumers, negative mutations, full report or source registration approved.','Full current tsc/build/aggregate/mobile gates and whole-market census closure remain open.']}
p=ROOT/'reviews/canonical-acceptance-v1.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(digest(p)));print('Field files',len(verified),'bytes',sum(r['bytes'] for r in verified.values()))
