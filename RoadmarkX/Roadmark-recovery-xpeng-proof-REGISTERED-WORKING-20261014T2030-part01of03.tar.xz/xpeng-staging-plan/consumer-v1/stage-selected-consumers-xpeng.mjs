/** Actual final 11-pack/citation/portable proof, adapted from the accepted Subaru proof. */
import assert from 'node:assert/strict';
import {digestRows,readResearch,assertResearchUnchanged} from '../baseline-io.mjs';
import {openConsumerInputs,visitCompleteCars,actualConsumers} from './open-consumer-inputs.mjs';
const proof=openConsumerInputs('selected'),{packet,selected,index}=proof,out=proof.createOutput();
let verifiedCars=0;await visitCompleteCars(proof,()=>{verifiedCars++;});assert.equal(verifiedCars,405);
const api=actualConsumers(proof),{require}=api;
const {applyBrandFeatureUpdates,applyBrandTermFeatures}=require('./src/lib/brand-updates.ts');
const {applyFeatureRegrading}=require('./src/lib/evidence-regrading.ts');
const {storePortablePacks,hydratePortablePacks}=require('./src/lib/portable-packs.ts');
const {factClaim,featureClaim}=require('./src/lib/citable.ts');
const {coreFacts,hasValue,existingGrade,isOnSale}=require('./scripts/reporting/reports.ts');
const {isBrakedTowingBasisEstablished}=require('./src/lib/evidence-grading.ts');
const {rankAttribute,exclusionReason}=require('./src/lib/discovery.ts');
// Reproduce original existing-five features under their original complete Research
// snapshot, then release it before loading the final 405-version Research snapshot.
const originalIndex=proof.read(proof.coreManifest.baselineStorageIndex);
for(const ref of Object.values(originalIndex.research))proof.assertPinned(ref);
let originalData=await readResearch(proof.anchors,originalIndex,proof.coreManifest.researchFields);
assert.equal(originalData.variants.length,399);assert.deepEqual(originalData.metadata.brand_update_packet_ids,api.brandUpdatePackets.map(row=>row.id));
for(const car of proof.before){const originalFeatures=api.base.effectiveFeatures(car,originalData);assert.deepEqual(JSON.parse(JSON.stringify(originalFeatures)),proof.beforeFeatures.filter(row=>row.variant_id===car.id),'All 345 original existing features under their actual original five-car snapshot');}
assertResearchUnchanged(originalData,originalIndex);originalData=null;global.gc();
const data=await proof.readData(),sourceById=new Map(data.sources.map(row=>[row.id,row]));
assert.equal(sourceById.size,data.sources.length);const packs={},policy={asOf:proof.manifest.asOf};
let citableFacts=0,citableFeatures=0,allCitableFeatureRows=0,coreCells=0,filledCoreCells=0;const gaps=[];
for(const car of selected){
  const before=digestRows([car]);
  // Existing 345 rows belong to the accepted pre-packet snapshot; the boundary
  // binds their original complete cars/feature digests to that successful receipt.
  // Only the six new canonical sets were captured under these post-core cars.
  if(proof.coreManifest.newIds.includes(car.id))assert.deepEqual(JSON.parse(JSON.stringify(api.base.effectiveFeatures(car,data))),proof.beforeFeatures.filter(row=>row.variant_id===car.id),'All 414 original new canonical rows under their original post-core snapshot');
  const baseFeatures=applyFeatureRegrading(car,api.base.sourceEffectiveFeatures(car,data),data.sources);
  const expectedFeatures=applyBrandTermFeatures(car,applyBrandFeatureUpdates(car,baseFeatures,data,[...api.brandUpdatePackets,packet]));
  const view=api.staged.pack(car.id,{data,cars:selected});assert.deepEqual(view.car,car);assert.deepEqual(view.features,expectedFeatures);assert.equal(view.features.length,69);assert.equal(new Set(view.features.map(row=>row.criterion)).size,69);assert(view.features.every(row=>row.variant_id===car.id));assert.deepEqual([...view.features.map(row=>row.criterion)].sort(),[...data.criteria.map(row=>row.key)].sort());packs[car.id]=view;
  for(const feature of view.features){const claim=featureClaim(view,feature.criterion,feature.criterion,proof.manifest.asOf);assert(claim);assert.deepEqual(claim.sources.map(row=>row.id),[...new Set(feature.source_ids)]);for(const citation of claim.sources){assert(sourceById.has(citation.id));assert.deepEqual(view.sources.find(row=>row.id===citation.id),sourceById.get(citation.id));}allCitableFeatureRows++;}
  for(const {key}of coreFacts){
    const fact=car.facts[key];assert(fact);assert.equal(fact.gradeReview?.overlayId,packet.id);coreCells++;
    const known=hasValue(fact.value);assert.notEqual(existingGrade(fact,known,data.sources,proof.manifest.asOf),'Unreviewed');
    if(known)filledCoreCells++;else gaps.push({carId:car.id,key,grade:fact.buyerGrade,value:fact.value});
  }
  for(const fact of Object.values(car.facts).filter(row=>row.gradeReview?.overlayId===packet.id)){
    const claim=factClaim(view,fact,proof.manifest.asOf);assert.equal(claim.buyerGrade,fact.buyerGrade);assert.deepEqual(claim.sources.map(row=>row.id),fact.sourceIds);
    for(const citation of claim.sources){const source=sourceById.get(citation.id);assert(source);for(const key of ['title','url','publisher','accessed_date','published_date','market'])assert.equal(citation[key],source[key]);assert.deepEqual(view.sources.find(row=>row.id===source.id),source);}citableFacts++;
  }
  for(const edit of packet.features.filter(row=>row.variantId===car.id)){
    const feature=view.features.find(row=>row.criterion===edit.criterion);assert.deepEqual(feature,edit.after);
    const claim=featureClaim(view,feature.criterion,feature.criterion,proof.manifest.asOf);assert(claim);assert.equal(claim.gradeReview?.overlayId,packet.id);assert.deepEqual(claim.sources.map(row=>row.id),feature.source_ids);for(const citation of claim.sources){const source=sourceById.get(citation.id);assert(source);for(const key of ['title','url','publisher','accessed_date','published_date','market'])assert.equal(citation[key],source[key]);assert.deepEqual(view.sources.find(row=>row.id===source.id),source);}citableFeatures++;
  }
  assert.equal(car.availabilityEvidence.physicalStockVerified,false);assert.equal(car.availabilityEvidence.factoryOrderAcceptanceVerified,false);assert(car.buyerSummary?.strength&&car.buyerSummary?.tradeoff);
  assert.deepEqual(digestRows([car]),before);global.gc();console.log('Exact actual XPENG pack',car.id);
}
assert.equal(coreCells,187);assert.equal(filledCoreCells,186);assert.deepEqual(gaps,[{carId:'xpeng_g6_gen1__my2024_rwd_standard_range__20261015',key:'price_aud',grade:'not_published',value:null}]);
assert.equal(Object.keys(packs).length,11);assert.equal(citableFeatures,124);assert.equal(citableFeatures,packet.features.length);assert.equal(allCitableFeatureRows,759);
const portable=storePortablePacks(packs);assert.deepEqual(hydratePortablePacks(portable,data.sources),packs,'Every complete portable pack roundtrips exactly');
assert.throws(()=>api.staged.pack('not-an-xpeng-id',{data,cars:selected}),{message:'Unknown variant'});
const x9=packs.xpeng_x9_launch__fwd_standard_range__20261010.car,towing=x9.facts.towing_braked_kg;
assert.equal(towing.value,'Not approved for towing');assert.equal(typeof towing.value,'string');assert.equal(towing.unit,'');assert.equal(towing.comparisonBasis,'');assert.equal(towing.buyerGrade,'confirmed');assert.equal(hasValue(towing.value),true);assert.equal(isBrakedTowingBasisEstablished(towing),true);assert.equal(existingGrade(towing,true,data.sources,proof.manifest.asOf),'Confirmed');assert.equal(exclusionReason(x9,towing,data.sources,policy),'No finite numeric value');
const towingRanking=rankAttribute(selected,data.sources,'towing_braked_kg',policy);assert(!towingRanking.groups.flatMap(group=>group.entries).some(row=>row.car.id===x9.id));assert(towingRanking.excluded.some(row=>row.carId===x9.id&&row.reason==='No finite numeric value'));
for(const [id,value]of [['xpeng_g6_my26__rwd_standard_range__20261010',51800],['xpeng_g6_my26__rwd_long_range__20261010',56800],['xpeng_g6_my26__awd_performance__20261010',63800]]){
  const car=packs[id].car,fact=car.facts.price_aud;assert.equal(fact.value,value);assert.equal(fact.buyerGrade,'confirmed');assert.equal(fact.priceEvidence.rung,3);assert.equal(fact.priceEvidence.basisTag,'Maker configurator price · on-road/tax basis not stated');assert.equal(fact.comparisonBasis,'');assert.equal(fact.priceEvidence.rankingEligible,false);assert.deepEqual(fact.sourceIds,[packet.id+'-g6-config']);assert.equal(exclusionReason(car,fact,data.sources,policy),'Price basis or conditions do not support a like-for-like ranking');
}
const residual=packs.xpeng_g6_gen1__my2024_rwd_standard_range__20261015.car;assert.equal(residual.facts.price_aud.value,null);assert.equal(residual.facts.price_aud.buyerGrade,'not_published');assert.equal(residual.facts.price_when_new_aud.value,54800);assert.equal(residual.facts.price_when_new_aud.comparisonBasis,'');assert.equal(residual.facts.price_when_new_aud.buyerGrade,'reported');
const arriving=selected.filter(car=>car.id.startsWith('xpeng_l03_'));assert.equal(arriving.length,3);for(const car of arriving){assert.equal(car.availability,'announced_provisional');assert.equal(isOnSale(car),false);}assert.equal(selected.filter(isOnSale).length,8);
for(const car of arriving){const mixed=packet.features.filter(row=>row.variantId===car.id&&row.dependencies.some(dep=>dep.key==='boot_l')&&row.dependencies.some(dep=>dep.key==='boot_excluding_underfloor_l'||dep.key==='boot_including_underfloor_reported_l'));assert(mixed.length>0,'Every L03 mixed-source cargo feature is represented');for(const edit of mixed){assert(edit.dependencies.some(dep=>dep.expected.buyerGrade==='check'));assert(edit.dependencies.some(dep=>dep.expected.buyerGrade==='reported'));const feature=packs[car.id].features.find(row=>row.criterion===edit.criterion);assert.equal(feature.buyerGrade,'reported');assert.equal(feature.gradeReview.evidenceScope,'secondary_or_sibling');}}
api.verify();proof.verifyData(data);proof.verify();
const packFile=proof.write(out,'staged-packs.json',packs),features=proof.write(out,'features-after.json',Object.values(packs).flatMap(pack=>pack.features)),portableFile=proof.write(out,'portable-packs.json',portable);
proof.write(out,'selected-consumer-receipt.json',{...proof.receiptBase(),status:'passed_selected_xpeng_consumers_pending_remaining_gates',versions:11,newVersions:6,all405CompleteCarsVerified:true,all14ResearchFieldsUnchanged:true,allSelectedCarsAndPacketUnchanged:true,coreCells,filledCoreCells,coreGaps:gaps,citableFacts,citableFeatures,allCitableFeatureRows,l03MixedSourceCargoRemainsReported:true,actualPackPipelineMatches:true,actualPortableExact:true,all759OriginalCanonicalFeatureRowsEqual:true,original345RowsMatchAcceptedBeforeSnapshot:true,actual345OriginalRowsReplayedUnderOriginalSnapshot:true,all414NewCanonicalFeatureRowsEqual:true,x9CategoricalTowingReviewedAndExcludedFromNumericDiscovery:true,g6ConfiguratorPricesRetainUnstatedBasis:true,patrickCurrentPriceRemainsUnpublished:true,l03ExcludedFromOnSaleDenominator:true,onSaleXpengVersions:8,defaultLoaderCalls:api.loaderCalls(),packFile,features,portableFile,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log('All 11 actual XPENG packs, citations, portable roundtrip and explicit buyer distinctions passed; remaining gates stay open');
