/** Complete original 405-car report through actual unchanged loader/builder; final CLI parity remains root-owned. */
import assert from 'node:assert/strict';
import path from 'node:path';
import {createRequire} from 'node:module';
import {digestRows,streamRows} from '../baseline-io.mjs';
import {openConsumerInputs} from './open-consumer-inputs.mjs';
const proof=openConsumerInputs('report'),{index,selected}=proof,out=proof.createOutput();
const featureReceipt=proof.readPhaseReceipt(proof.manifest.featureReceipt,'passed_complete_xpeng_features_pending_report_and_review');
for(const key of ['all405CompleteCarHashesVerified','all14ResearchFieldsUnchanged','packetAndSelectedCarsUnchanged','all11ActualPackFeaturesExactlyEqual','all394OtherCarFeatureSetsExactlyUnchanged','strictCompleteOrderAndUniqueness'])assert.equal(featureReceipt[key],true);
assert.equal(featureReceipt.cars,405);assert.equal(featureReceipt.featureRows,27945);assert.equal(featureReceipt.defaultLoaderCalls,0);
const negativeReceipt=proof.readPhaseReceipt(proof.manifest.negativeReceipt,'passed_xpeng_negative_guards_pending_remaining_gates');assert.equal(negativeReceipt.loaderCalls,0);assert.deepEqual(negativeReceipt.unsupportedCategories,[]);
for(const key of ['all405CompleteCarsVerified','positiveCoreCompleteEquality','allMutationInputsUnchanged','allOriginalSelectedCarsUnchanged','allOriginalBeforeCarsUnchanged','all14ResearchFieldsUnchanged','allOriginalRegisteredPacketsUnchanged','fullOriginalPacketUnchanged'])assert.equal(negativeReceipt[key],true);
const featureIndex=proof.read(featureReceipt.index);assert.equal(featureIndex.cars,405);assert.equal(featureIndex.features.rows,27945);assert.equal(featureIndex.packetSha256,proof.coreManifest.packet.sha256);assert.equal(featureIndex.coreReceiptSha256,proof.receiptHash);
assert.deepEqual(featureIndex.perCar.map(row=>row.id),index.cars.carHashes.map(row=>row.id));assert.equal(new Set(featureIndex.perCar.map(row=>row.id)).size,405);
const cars=await proof.readCars(),data=await proof.readData(),features=[];proof.assertPinned(featureIndex.features);
await streamRows(proof.anchors,featureIndex.features,(feature,ordinal)=>{
  const carIndex=Math.floor(ordinal/69);assert(carIndex<405);assert.equal(feature.variant_id,cars[carIndex].id,'Strict 69-row contiguous per-car feature order');features.push(feature);
});assert.equal(features.length,27945);
const perCar=new Map();for(let i=0;i<405;i++){const rows=features.slice(i*69,(i+1)*69);assert.equal(new Set(rows.map(row=>row.criterion)).size,69);perCar.set(cars[i].id,rows);}
const carDigests=cars.map(car=>digestRows([car]));
function verifiedFeatures(car){
  const ordinal=cars.findIndex(row=>row.id===car.id);assert(ordinal>=0);const carProof=index.cars.carHashes[ordinal],featureProof=featureIndex.perCar[ordinal],rows=perCar.get(car.id);assert(rows);
  const cd=digestRows([car]),fd=digestRows(rows);assert.deepEqual(cd,carDigests[ordinal]);assert.equal(cd.sha256,carProof.afterSha256);assert.equal(cd.bytes,carProof.bytes);assert.equal(cd.sha256,featureProof.carSha256);assert.equal(cd.bytes,featureProof.carBytes);assert.equal(fd.sha256,featureProof.featureSha256);assert.equal(fd.bytes,featureProof.featureBytes);assert.equal(fd.rows,featureProof.featureRows);assert.equal(fd.rows,69);return rows;
}
for(const car of cars)verifiedFeatures(car);global.gc();
const require=createRequire(path.join(proof.anchors.repo,'package.json')),{compiledSource}=require('./tests/helpers/compiled-source.ts');
const {buildCoverageReport,coreFacts,existingGrade,hasValue,isOnSale}=require('./scripts/reporting/reports.ts');
const {combineM1Reconciliations}=require('./scripts/reporting/m1-reconciliation.ts');let loaderCalls=0;
// The unchanged report loader receives the complete explicit snapshot. Its feature function
// is the already proved full actual stream, verified against every full car/feature digest.
const loader=compiledSource('scripts/reporting/load.ts',{'../../src/lib/data':{catalogueSnapshot:()=>{loaderCalls++;throw new Error('XPENG_REPORT_FORBIDDEN_FRESH_LOADER');},effectiveFeatures:(car,supplied)=>{assert.equal(supplied,data);return verifiedFeatures(car);}}});
const input=loader.loadReportInput({data,cars});assert.equal(input.cars,cars);assert.equal(input.sources,data.sources);assert.deepEqual(input.features,features);
const reconciliation=proof.read(proof.manifest.reconciliation);assert.equal(reconciliation.checkedAt,proof.manifest.asOf);
input.m1Reconciliation=combineM1Reconciliations(input.m1Reconciliation,reconciliation);
const inputDigests=Object.fromEntries(Object.entries(input).map(([key,value])=>[key,digestRows(Array.isArray(value)?value:[value])]));
const report=buildCoverageReport(input,proof.manifest.asOf);assert.equal(report.asOf,proof.manifest.asOf);assert.equal(report.allCatalogueVersions,405);
const brand=report.brandProgress.find(row=>row.brand==='XPENG');assert(brand);assert.equal(brand.onSaleVersions,8);assert.equal(brand.missingSummaries,0);assert.equal(brand.agedOrInvalidClaims,0);assert.equal(brand.coreGaps,1);assert.equal(brand.unreviewedCoreGrades,0);assert.equal(brand.criteria.C2,false);assert.equal(brand.criteria.C5,false);
const onSale=selected.filter(isOnSale);assert.equal(onSale.length,8);assert(!onSale.some(car=>car.id.startsWith('xpeng_l03_')));
for(const {key}of coreFacts){const actual=brand.core.find(row=>row.key===key);assert(actual);const expectedGrades={Confirmed:0,Check:0,Reported:0,'Not published':0,Unreviewed:0};let filled=0;
  for(const car of onSale){const fact=car.facts[key],present=hasValue(fact.value);if(present)filled++;expectedGrades[existingGrade(fact,present,data.sources,proof.manifest.asOf)]++;}
  assert.equal(actual.total,8);assert.equal(actual.filled,filled);assert.deepEqual(actual.grades,expectedGrades);assert.equal(actual.reviewed,8);
}
assert.equal(brand.core.reduce((sum,row)=>sum+row.total,0),136);assert.equal(brand.core.reduce((sum,row)=>sum+row.filled,0),135);assert.equal(brand.core.find(row=>row.key==='price_aud').filled,7);assert.equal(brand.core.find(row=>row.key==='towing_braked_kg').filled,8);
assert(report.gaps.some(row=>row.carId==='xpeng_g6_gen1__my2024_rwd_standard_range__20261015'&&row.key==='price_aud'));
const towingRanking=report.rankings.find(row=>row.key==='towing_braked_kg');assert(!towingRanking.rankedIds.includes('xpeng_x9_launch__fwd_standard_range__20261010'));
assert.deepEqual(Object.keys(input),Object.keys(inputDigests));for(const [key,value]of Object.entries(input))assert.deepEqual(digestRows(Array.isArray(value)?value:[value]),inputDigests[key]);
for(const car of cars)verifiedFeatures(car);assert.equal(loaderCalls,0);assert(!require.cache[path.join(proof.anchors.repo,'src/lib/data.ts')]);proof.verifyData(data);proof.verify();
// Preserve the exact original report, never filter, normalize, sort or substitute fields.
const reportFile=proof.write(out,'staged-report.json',report);
proof.write(out,'complete-report-receipt.json',{...proof.receiptBase(),status:'passed_complete_xpeng_staged_report_pending_independent_review_and_fresh_registered_parity',cars:405,xpengCars:11,onSaleXpengCars:8,features:27945,sources:data.sources.length,all14ResearchFieldsUnchanged:true,all405CompleteCarsUnchanged:true,allReportInputFieldsUnchanged:true,completeReportInputFieldDigests:inputDigests,actualReportLoaderUsed:true,actualCoverageBuilderUsed:true,actualFullFeatureStreamUsed:true,reportFile,brand,featureReceiptSha256:proof.manifest.featureReceipt.sha256,negativeReceiptSha256:proof.manifest.negativeReceipt.sha256,reconciliation:proof.manifest.reconciliation,accepted399BaselineWholeJsonParity:proof.baselineManifest.approved.freshRegisteredParity,full405FreshRegisteredJsonParity:false,filteredOrNormalized:false,defaultLoaderCalls:loaderCalls,openGates:['Independent staged candidate review','Root-authorized production registration','Fresh normal CLI entire unmodified JSON equality to this original staged report','Current TypeScript/build/aggregate/mobile release checks'],resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log('Original complete 405-car staged report preserved; fresh registered full-JSON parity remains explicitly unverified');
