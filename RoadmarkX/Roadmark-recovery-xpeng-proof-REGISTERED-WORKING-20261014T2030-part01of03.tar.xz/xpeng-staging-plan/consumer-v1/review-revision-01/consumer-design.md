# XPENG post-core proofs, consumer-v1

Prepared only. These files have not been executed, imported, syntax-checked, tested, or used to produce phase artifacts. No source edit, hydration, test, report run, registry change, full source scan, cloud task, or user-computer action was performed while preparing them. Root owns every measured execution slot and production registration. Unknown future hashes are never filled with guessed or newly observed expectations.

## Minimal reuse

The four phase drivers adapt the accepted Subaru selected-consumer, negative-guard, full-feature-stream and complete-report scripts. The existing XPENG `baseline-io.mjs` and `staging-v1/read-complete-storage.mjs` are reused unchanged. One XPENG-specific boundary file admits pinned final-core outputs and serves the four drivers; it is not a general framework. `visitCompleteCars` mirrors the recursive reader's exact per-layer before/after hashes, full values, complete replacement consumption, brand, identity and order assertions while retaining one effective car at a time. The report uses the original complete recursive reader for its explicit 405-car snapshot.

Files:
- `open-consumer-inputs.mjs`
- `stage-selected-consumers-xpeng.mjs`
- `stage-negative-guards-xpeng.mjs`
- `stage-full-feature-stream-xpeng.mjs`
- `stage-complete-report-xpeng.mjs`
- `consumer-design.md`

## Immutable phase manifest

Every invocation takes exactly four explicit argument/value pairs: `--manifest`, `--manifest-sha256`, `--review`, `--review-sha256`. A versioned manifest has:

- `schemaVersion: 1`, `mode: "reviewed-xpeng-consumers-v1"`, `phase: "selected" | "negative" | "features" | "report"`
- `asOf: "2026-10-15"`, `packetId: "m1-xpeng-2026-10-15"`, actual `nodeVersion`
- `anchors`: exactly the already approved final-core anchor map; no new or broadened anchor
- `finalCoreManifest`, `finalCoreReview`, `finalCoreReceipt`: complete `{anchor,file,sha256,bytes}` refs
- `harnessPins`: all six files above, plus any separately reviewed helper listed by the coordinator; each appears identically in `inputPins`
- `inputPins`: exhaustive unique pinned paths, including every final-core input pin and source file, every final-core output index/value referenced here, recursive car indexes and leaves, all final raw/composed fourteen-field storage, original canonical packet/selected cars/414 new features/345 prior features/acceptance, all 18 predecessor packets, the exact final 124-feature XPENG packet, all original retained source captures and reconciliation evidence
- `output: {"anchor":"xpeng","directory":"consumer-artifacts/<unique-attempt>"}`; directory creation and every file write are exclusive. Interrupted artifacts are retained, never overwritten or resumed blindly
- Negative/features phases: `selectedConsumerReceipt` and all of its referenced output files are pinned inputs
- Report phase: `featureReceipt`, its full feature index and complete JSONL stream, `negativeReceipt`, and `reconciliation` are required pinned refs. Preserve the selected receipt ancestry in the feature proof. Reconciliation must be the final independently reviewed frozen source-grounded document

Review JSON must contain exact `phase`, `manifestSha256`, `harnessPins`, `finalCoreReceiptSha256`, `status: "approved_for_<phase>_xpeng_consumers_v1"`, `canonicalCaptureAuthorized: false`, and `productionRegistrationAuthorized: false`. Independent approval and root's exact measured-command allocation are both required before execution. Neither can be inferred from this preparation document.

The boundary checks the final-core review/receipt links, original accepted canonical generation count of one, exact feature-free packet equality after removing only final features, all eleven full selected-car values, all fourteen original raw/composed field digests, and exact retained `[18 registered IDs, XPENG ID]` composition. Raw metadata remains separate and contains only the invocation-scoped XPENG ID. It never repairs metadata or recaptures before values.

All existing baseline acceptance pins are inherited, including the exact 399-car Subaru feature index SHA-256 `5f52dec2f6c750554dd9dcfae5a8c07753d66690a80bd4e9042e8911cd7fdc50`, accepted baseline report and independent full fresh-registration JSON parity. Do not rerun that baseline report merely to prepare this proof. Every file remains pinned before/after, with the same complete source-inventory membership check at actual execution time. Any source transition requires new review rather than a repin.

## Actual consumers and reviewed evidence distinctions

Actual `createEvidenceConsumers` function bodies are unchanged. Only the imported registry binding is overridden through the existing `compiledSource` helper. It contains the exact original 18 packet objects plus the immutable candidate; the production registry is untouched. All snapshots are explicit. Defaults throw and zero calls is required. There is no `data.ts` import, fallback hydration, manual feature replacement after pack creation, persistent cache, or canonical regeneration.

Selected phase checks all eleven complete actual packs, all 69 features per pack, full original 345+414 canonical before rows, guarded actual feature output, citable sources, and exact full portable roundtrip. The 187 reviewed core cells include 186 filled cells and Patrick MY2024 SR's one real current-price gap. It explicitly checks:

- X9 FWD categorical Confirmed `Not approved for towing`, empty unit/comparison, counts as known reviewed answer, excluded from numeric towing discovery
- G6 configurator 51,800 / 56,800 / 63,800, Confirmed rung 3, exact unknown on-road/tax basis tag, empty comparison basis, false ranking eligibility, maker-only current-price source
- Patrick current price null/Not published and separate historical 54,800 Reported fact
- Three L03 arrivals remain announced/provisional and outside the eight-version on-sale denominator
- L03 cargo equipment mixing maker water-method Check facts and secondary rear-cargo Reported definitions remains Reported

These are reviewed-data/manifest invariants. They do not claim a general application validator independently proves an unpublished price basis. Negative cases separately exercise actual guards with expected exact error messages. They preserve Subaru's identity, source-record/capture drift, missing/duplicate source, full before-fact/feature, secondary/foreign grade promotion, numeric price-basis contradiction, complete dependency, numeric V2L, summary, duplicate feature target, raw canonical row cardinality and brand/tier/identity cases. Synthetic foreign input is isolated and never published. Missing real-candidate coverage writes an explicit incomplete receipt and exits unsuccessfully. Every mutation is frozen and hashed; original full snapshots remain unchanged.

## Full feature stream and report

The full feature phase is one serial 405-car pass, with no batching or range-merge route in this minimal version. It requires exactly 27,945 rows, contiguous exact car order, 69 unique complete criteria per car, 11 complete pack equalities and all 394 other-car feature sets equal to the accepted-before per-car hashes/bytes/counts. It retains all per-car car/feature digests, aggregate JSONL hash/bytes/count, all input pins and receipt ancestry. Missing, duplicate, unknown, reordered or extra car/feature rows fail. Root may choose a separately reviewed contiguous-range adaptation if needed; this version cannot accept partial ranges as a complete stream.

The report phase reconstructs all 405 complete cars and all fourteen Research fields. The unchanged actual report loader receives the complete explicit snapshot; its `effectiveFeatures` binding returns the complete previously proven stream and verifies every car/feature digest. The actual unchanged coverage builder receives all original report fields plus the final frozen reconciliation. Nothing is filtered or normalized. Every complete report-input field is hashed before/after, all complete cars and Research fields remain unchanged, and the original entire JSON report is stored.

The report's on-sale XPENG denominator is eight: 136 represented/reviewed cells, 135 filled, one price gap. X9's categorical towing is filled but unranked; L03's 51 arriving core cells are not moved into that denominator. C2 and C5 remain false. The receipt explicitly leaves fresh registered 405-car entire JSON equality unverified. Root later runs the normal fresh registered CLI and compares its entire unmodified JSON (and bytes where available) to this original staged output; no nonexistent expected 405 report is invented here.

Receipts never claim independent acceptance, source registration, typecheck/build/aggregate/mobile success or publication. Those remain separate root-owned gates.
