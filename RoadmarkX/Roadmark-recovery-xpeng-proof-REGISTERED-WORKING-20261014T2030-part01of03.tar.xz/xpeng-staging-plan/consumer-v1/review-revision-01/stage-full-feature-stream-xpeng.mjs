/** Complete 405 by 69 actual effective-feature stream, adapted from Subaru's proof. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {digestRows,fileHash,referenceFor} from '../baseline-io.mjs';
import {openConsumerInputs,visitCompleteCars,actualConsumers} from './open-consumer-inputs.mjs';
const proof=openConsumerInputs('features'),{index,selected,packet}=proof,out=proof.createOutput();
const selectedReceipt=proof.readPhaseReceipt(proof.manifest.selectedConsumerReceipt,'passed_selected_xpeng_consumers_pending_remaining_gates');
for(const key of ['all405CompleteCarsVerified','all14ResearchFieldsUnchanged','allSelectedCarsAndPacketUnchanged','actualPackPipelineMatches','actualPortableExact','all759OriginalCanonicalFeatureRowsEqual'])assert.equal(selectedReceipt[key],true);
const packs=proof.read(selectedReceipt.packFile);assert.deepEqual(Object.keys(packs),selected.map(car=>car.id));
const api=actualConsumers(proof),data=await proof.readData();global.gc();
const sourceIds=new Set(data.sources.map(row=>row.id));assert.equal(sourceIds.size,data.sources.length);const criteria=[...data.criteria.map(row=>row.key)].sort();assert.equal(new Set(criteria).size,69);
const baseById=new Map(proof.baselineFeatureIndex.perCar.map(row=>[row.id,row]));assert.equal(baseById.size,399);
const output=path.join(out,'all-features.jsonl'),fd=fs.openSync(output,'wx'),aggregate=crypto.createHash('sha256');
const seen=new Set(),perCar=[];let count=0,bytes=0,matchedOther=0,matchedXpeng=0;
try{
  await visitCompleteCars(proof,(car,ordinal)=>{
    assert.equal(ordinal,perCar.length);assert.equal(car.id,index.cars.carHashes[ordinal].id);assert(!seen.has(car.id));seen.add(car.id);
    const before=digestRows([car]),features=api.staged.effectiveFeatures(car,data);
    assert.equal(features.length,69);assert.equal(new Set(features.map(row=>row.criterion)).size,69);assert(features.every(row=>row.variant_id===car.id));assert.deepEqual([...features.map(row=>row.criterion)].sort(),criteria);for(const feature of features)for(const sourceId of feature.source_ids)assert(sourceIds.has(sourceId),'Every full feature source exists');
    const digest=digestRows(features);
    if(Object.hasOwn(packs,car.id)){assert.deepEqual(JSON.parse(JSON.stringify(features)),packs[car.id].features);assert.deepEqual(car,packs[car.id].car);matchedXpeng++;}
    else{const old=baseById.get(car.id);assert(old);assert.equal(digest.sha256,old.featureSha256,'Complete accepted-before other-brand feature equality: '+car.id);assert.equal(digest.bytes,old.featureBytes);assert.equal(digest.rows,old.featureRows);matchedOther++;}
    for(const feature of features){const row=Buffer.from(JSON.stringify(feature)+'\n','utf8');let offset=0;while(offset<row.length){const written=fs.writeSync(fd,row,offset,row.length-offset);assert(written>0);offset+=written;}aggregate.update(row);bytes+=row.length;count++;}
    assert.deepEqual(digestRows([car]),before);perCar.push({id:car.id,carSha256:before.sha256,carBytes:before.bytes,featureRows:digest.rows,featureBytes:digest.bytes,featureSha256:digest.sha256});
    if(perCar.length%25===0){global.gc();console.log('Complete actual XPENG-stage feature sets',perCar.length,process.memoryUsage());}
  });
}finally{fs.closeSync(fd);}
assert.equal(perCar.length,405);assert.equal(seen.size,405);assert.equal(count,27945);assert.equal(matchedXpeng,11);assert.equal(matchedOther,394);assert.deepEqual(perCar.map(row=>row.id),index.cars.carHashes.map(row=>row.id));
const sha256=aggregate.digest('hex');assert.equal(fileHash(output),sha256);assert.equal(fs.statSync(output).size,bytes);
api.verify();proof.verifyData(data);proof.verify();
const features={...referenceFor(proof.anchors,output),rows:count,bytes,sha256};
const featureIndex=proof.write(out,'all-feature-index.json',{schemaVersion:1,...proof.receiptBase(),mode:'Complete actual immutable staged XPENG feature stream',cars:405,features,perCar,xpengMatched:11,otherCarsExactlyUnchanged:394,baselineFeatureIndex:proof.baselineManifest.approved.featureIndex,selectedConsumerReceipt:proof.manifest.selectedConsumerReceipt});
proof.write(out,'all-feature-receipt.json',{...proof.receiptBase(),status:'passed_complete_xpeng_features_pending_report_and_review',cars:405,featureRows:27945,all405CompleteCarHashesVerified:true,all14ResearchFieldsUnchanged:true,packetAndSelectedCarsUnchanged:true,all11ActualPackFeaturesExactlyEqual:true,all394OtherCarFeatureSetsExactlyUnchanged:true,strictCompleteOrderAndUniqueness:true,defaultLoaderCalls:api.loaderCalls(),index:featureIndex,selectedConsumerReceiptSha256:proof.manifest.selectedConsumerReceipt.sha256,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log('All 405 complete actual feature sets passed, including exact accepted-before equality for 394 other cars');
