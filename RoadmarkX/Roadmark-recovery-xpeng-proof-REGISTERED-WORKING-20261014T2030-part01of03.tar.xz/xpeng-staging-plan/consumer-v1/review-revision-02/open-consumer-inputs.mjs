/** Prepared-only XPENG consumer proof boundary; no production loader or implicit inputs. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {
  argumentsFor,readJson,fileHash,locate,referenceFor,pin,verifyPins,sourceNames,
  digestRows,expectedDigest,streamRows,readResearch,assertResearchUnchanged,newDirectory,writeNewJson,
} from '../baseline-io.mjs';
import {readCompleteCars} from '../staging-v1/read-complete-storage.mjs';

export function openConsumerInputs(phase) {
  const args=argumentsFor(['--manifest','--manifest-sha256','--review','--review-sha256']);
  assert.equal(fileHash(args['--manifest']),args['--manifest-sha256']);
  assert.equal(fileHash(args['--review']),args['--review-sha256']);
  const manifest=readJson(args['--manifest']),review=readJson(args['--review']),{anchors}=manifest;
  assert.equal(manifest.schemaVersion,1);assert.equal(manifest.mode,'reviewed-xpeng-consumers-v1');
  assert.equal(manifest.phase,phase);assert(['selected','negative','features','report'].includes(phase));
  assert.equal(manifest.asOf,'2026-10-15');assert.equal(manifest.packetId,'m1-xpeng-2026-10-15');
  assert.equal(manifest.nodeVersion,process.version);assert.equal(process.cwd(),anchors.repo);assert.equal(typeof global.gc,'function');
  locate(anchors,referenceFor(anchors,args['--manifest']));locate(anchors,referenceFor(anchors,args['--review']));
  assert.equal(review.status,'approved_for_'+phase+'_xpeng_consumers_v1');assert.equal(review.phase,phase);
  assert.equal(review.manifestSha256,args['--manifest-sha256']);assert.deepEqual(review.harnessPins,manifest.harnessPins);
  if(phase==='features'){assert(['range','aggregate'].includes(manifest.featureMode));assert.equal(review.featureMode,manifest.featureMode);}
  assert.equal(review.finalCoreReceiptSha256,manifest.finalCoreReceipt.sha256);
  assert.equal(review.canonicalCaptureAuthorized,false);assert.equal(review.productionRegistrationAuthorized,false);
  const pins=new Map(manifest.inputPins.map(row=>[locate(anchors,row),row]));assert.equal(pins.size,manifest.inputPins.length);
  function assertPinned(ref){const expected=pins.get(locate(anchors,ref));assert(expected,'Missing reviewed input pin');assert.equal(ref.sha256,expected.sha256);assert.equal(ref.bytes,expected.bytes);}
  function read(ref){assertPinned(ref);pin(anchors,ref);return readJson(locate(anchors,ref));}
  const own=['open-consumer-inputs.mjs','stage-selected-consumers-xpeng.mjs','stage-negative-guards-xpeng.mjs','stage-full-feature-stream-xpeng.mjs','stage-complete-report-xpeng.mjs','consumer-design.md'];
  for(const ref of manifest.harnessPins)assertPinned(ref);
  for(const file of own)assert(manifest.harnessPins.some(row=>row.anchor==='xpeng'&&row.file==='consumer-v1/'+file),'Missing reviewed consumer harness file');
  const coreManifest=read(manifest.finalCoreManifest),coreReview=read(manifest.finalCoreReview),receipt=read(manifest.finalCoreReceipt);
  assert.equal(coreManifest.mode,'reviewed-xpeng-staging-v1');assert.equal(coreManifest.phase,'final-core');
  assert.deepEqual(anchors,coreManifest.anchors);assert.equal(coreManifest.asOf,manifest.asOf);assert.equal(coreManifest.packetId,manifest.packetId);
  assert.equal(coreReview.status,'approved_for_final_core_xpeng_staging_v1');assert.equal(coreReview.manifestSha256,manifest.finalCoreManifest.sha256);
  assert.deepEqual(coreReview.harnessPins,coreManifest.harnessPins);assert.equal(coreReview.evidenceReviewed,true);assert.equal(coreReview.compositionReviewed,true);assert.equal(coreReview.canonicalCaptureAuthorized,false);
  for(const row of coreManifest.inputPins)assertPinned(row);
  assert.equal(receipt.status,'passed_actual_final_core_pending_consumers_mutations_and_report');assert.equal(receipt.phase,'final-core');
  assert.equal(receipt.inputManifestSha256,manifest.finalCoreManifest.sha256);assert.equal(receipt.independentReviewSha256,manifest.finalCoreReview.sha256);
  assert.equal(receipt.beforeCars,399);assert.equal(receipt.afterCars,405);assert.equal(receipt.xpengCars,11);assert.equal(receipt.newCars,6);
  for(const key of ['all399InputCarsAnd14ResearchFieldsUnchanged','all394NonXpengOrLowerTierCarsUnchanged','rawSinglePacketOutputPreserved','canonicalCompared'])assert.equal(receipt[key],true);
  assert.equal(receipt.onlyCompositionPath,'metadata.brand_update_packet_ids');assert.equal(receipt.registered,false);assert.equal(receipt.freshFullValueLoaderExport,false);
  assert.equal(receipt.packetSha256,coreManifest.packet.sha256);
  const packet=read(coreManifest.packet),packetDigest=digestRows([packet]);
  assert.equal(packet.id,manifest.packetId);assert.equal(packet.brand,'XPENG');assert.equal(packet.facts.length,380);assert.equal(packet.brandTerms.length,3);assert.equal(packet.features.length,124);assert.equal(packet.variants.length,6);
  assert.deepEqual(packet.variants.map(row=>row.id),coreManifest.newIds);
  const canonicalMeta=read(coreManifest.canonicalMeta),canonicalAcceptance=read(coreManifest.canonicalAcceptance);
  assert.equal(canonicalAcceptance.status,'accepted_original_xpeng_canonical_baseline');assert.equal(canonicalAcceptance.canonicalMetaSha256,coreManifest.canonicalMeta.sha256);
  assert.equal(canonicalAcceptance.captureGenerationCount,1);
  for(const key of ['fullPacketAndSelectedCarsVerified','all14RawAndComposedFieldsVerified','all414OriginalFeatureRowsVerified'])assert.equal(canonicalAcceptance[key],true);
  for(const key of ['captureGenerationCount','generationCount','baselineGenerationCount'])assert.equal(canonicalMeta[key],1);
  assert.deepEqual(canonicalMeta.featureFreePacket,coreManifest.canonicalPacket);assert.deepEqual(canonicalMeta.selectedCars,coreManifest.canonicalSelectedCars);assert.deepEqual(canonicalMeta.newFeatures,coreManifest.canonicalNewFeatures);
  const withoutFeatures=structuredClone(packet);withoutFeatures.features=[];assert.deepEqual(withoutFeatures,read(coreManifest.canonicalPacket));assert.deepEqual(digestRows([withoutFeatures]),canonicalMeta.featureFreePacketDigest);
  const index=read(receipt.storageIndex),rawIndex=read(receipt.rawResearchIndex),transition=read(receipt.transition),selected=read(receipt.selectedCars),before=read(coreManifest.selectedBeforeCars);
  assert.equal(index.packetSha256,coreManifest.packet.sha256);assert.equal(index.inputManifestSha256,manifest.finalCoreManifest.sha256);
  assert.equal(index.cars.rows,405);assert.equal(index.cars.baseline.rows,399);assert.equal(index.cars.replacements.rows,11);assert.deepEqual(index.cars.newIds,coreManifest.newIds);
  assert.equal(index.cars.baseline.format,'storage-index');assert.equal(index.cars.replacements.format,'json');
  assert.equal(index.cars.baseline.sha256,coreManifest.baselineStorageIndex.sha256);assert.equal(index.cars.replacements.sha256,receipt.selectedCars.sha256);
  assert.equal(index.cars.carHashes.length,405);assert.equal(new Set(index.cars.carHashes.map(row=>row.id)).size,405);
  assert.deepEqual(selected.map(car=>car.id),[...coreManifest.existingIds,...coreManifest.newIds]);assert.equal(selected.length,11);assert.equal(before.length,5);
  assert.deepEqual(before.map(car=>car.id),coreManifest.existingIds);assert.deepEqual(selected,read(coreManifest.canonicalSelectedCars));assert.deepEqual(digestRows(selected),canonicalMeta.selectedCarsDigest);
  const registeredPackets=coreManifest.registeredPackets.map(row=>{const value=read(row.input);assert.equal(value.id,row.id);return value;});assert.equal(registeredPackets.length,18);
  for(const [current,expected] of [[index,canonicalMeta.composedFieldDigests],[rawIndex,canonicalMeta.rawFieldDigests]]){
    assert.deepEqual(Object.keys(current.research),coreManifest.researchFields);assert.equal(Object.keys(current.research).length,14);
    for(const [key,ref]of Object.entries(current.research)){assertPinned(ref);assert.deepEqual(expectedDigest(ref),expected[key],'All raw/composed original canonical field digests');}
  }
  assert.equal(transition.onlyChangedPath,'metadata.brand_update_packet_ids');assert.deepEqual(transition.rawMetadata,canonicalMeta.rawMetadata);assert.deepEqual(transition.composedMetadata,canonicalMeta.composedMetadata);
  assert.deepEqual(transition.rawMetadata.brand_update_packet_ids,[packet.id]);assert.deepEqual(transition.composedMetadata.brand_update_packet_ids,[...registeredPackets.map(row=>row.id),packet.id]);
  const beforeFeatures=[...read(coreManifest.existingBeforeFeatures),...read(coreManifest.canonicalNewFeatures)];
  assert.equal(beforeFeatures.length,759);const beforeByKey=new Map(beforeFeatures.map(row=>[row.variant_id+'\0'+row.criterion,row]));assert.equal(beforeByKey.size,759);
  for(const edit of packet.features)assert.deepEqual(edit.before,beforeByKey.get(edit.variantId+'\0'+edit.criterion));
  const baselineManifest=read(coreManifest.baselineManifest),baselineFeatureIndex=read(baselineManifest.approved.featureIndex);
  assert.equal(baselineManifest.approved.featureIndex.sha256,'5f52dec2f6c750554dd9dcfae5a8c07753d66690a80bd4e9042e8911cd7fdc50');
  assert.equal(baselineFeatureIndex.cars,399);assert.equal(baselineFeatureIndex.features.rows,27531);assert.equal(baselineFeatureIndex.perCar.length,399);assert.equal(new Set(baselineFeatureIndex.perCar.map(row=>row.id)).size,399);
  assert.deepEqual(baselineFeatureIndex.perCar.map(row=>row.id),index.cars.carHashes.slice(0,399).map(row=>row.id));
  // Retain the accepted baseline's independent whole-JSON fresh-registration parity lineage.
  read(baselineManifest.approved.freshRegisteredParity);read(baselineManifest.approved.finalRegistrationAddendum);read(baselineManifest.approved.report);
  const sourceInventory=read(coreManifest.currentSourceInventory);for(const row of sourceInventory.files)assertPinned({anchor:'repo',...row});
  const selectedDigests=selected.map(car=>digestRows([car])),beforeDigests=before.map(car=>digestRows([car]));
  function verifySelected(){
    for(const [i,car]of selected.entries()){
      const row=index.cars.carHashes.find(value=>value.id===car.id);assert(row);assert.equal(car.brand,'XPENG');assert.equal(digestRows([car]).sha256,row.afterSha256);assert.equal(digestRows([car]).bytes,row.bytes);assert.deepEqual(digestRows([car]),selectedDigests[i]);
    }
    assert.deepEqual(before.map(car=>digestRows([car])),beforeDigests);assert.deepEqual(digestRows([packet]),packetDigest);
  }
  function verify(){
    assert.equal(fileHash(args['--manifest']),args['--manifest-sha256']);assert.equal(fileHash(args['--review']),args['--review-sha256']);
    verifyPins(anchors,manifest.inputPins);assert.deepEqual(sourceNames(anchors.repo),sourceInventory.files.map(row=>row.file).sort());verifySelected();
  }
  const proof={anchors,manifest,manifestSha256:args['--manifest-sha256'],reviewSha256:args['--review-sha256'],coreManifest,receipt,receiptHash:manifest.finalCoreReceipt.sha256,index,rawIndex,packet,selected,before,beforeFeatures,registeredPackets,baselineManifest,baselineFeatureIndex,assertPinned,read,verify,verifySelected};
  function readPhaseReceipt(ref,status){const value=read(ref);assert.equal(value.status,status);assert.equal(value.packetSha256,coreManifest.packet.sha256);assert.equal(value.coreReceiptSha256,manifest.finalCoreReceipt.sha256);assert.equal(value.finalCoreManifestSha256,manifest.finalCoreManifest.sha256);return value;}
  proof.readPhaseReceipt=readPhaseReceipt;
  proof.readData=async()=>{const data=await readResearch(anchors,index,coreManifest.researchFields);assert.equal(data.variants.length,405);assert.deepEqual(data.variants.map(row=>row.id),index.cars.carHashes.map(row=>row.id));assert.deepEqual(data.metadata,transition.composedMetadata);assertResearchUnchanged(data,index);return data;};
  proof.verifyData=data=>assertResearchUnchanged(data,index);
  proof.readCars=async()=>{const complete=await readCompleteCars(proof,receipt.storageIndex);assert.equal(complete.cars.length,405);return complete.cars;};
  proof.createOutput=()=>{assert.equal(manifest.output.anchor,'xpeng');assert(/^consumer-artifacts\/[a-z0-9][a-z0-9_-]*$/.test(manifest.output.directory));return newDirectory(anchors.xpeng,manifest.output.directory);};
  proof.write=(directory,name,value)=>{const result=writeNewJson(directory,name,value);return {...referenceFor(anchors,result.path),bytes:result.bytes,sha256:result.sha256};};
  proof.receiptBase=()=>({asOf:manifest.asOf,packetSha256:coreManifest.packet.sha256,coreReceiptSha256:manifest.finalCoreReceipt.sha256,finalCoreManifestSha256:manifest.finalCoreManifest.sha256,phaseManifestSha256:proof.manifestSha256,phaseReviewSha256:proof.reviewSha256,fullInputPins:manifest.inputPins,candidateRegistered:false,freshFullValueLoaderExport:false});
  verify();return proof;
}

/** Same full recursive before/after checks as the retained reader, one effective car at a time. */
export async function visitCompleteCars(proof,visit,indexRef=proof.receipt.storageIndex,active=new Set()){
  proof.assertPinned(indexRef);pin(proof.anchors,indexRef);const file=locate(proof.anchors,indexRef);assert(!active.has(file),'Cyclic storage index');active.add(file);
  try{
    const index=readJson(file),d=index.cars,expected=d.carHashes;
    assert.equal(d.mode,'baseline-with-complete-replacements-and-appended-identities');assert.equal(expected.length,d.rows);assert.equal(new Set(expected.map(row=>row.id)).size,d.rows);assert.equal(new Set(d.newIds).size,d.newIds.length);
    for(const ref of [d.baseline,d.replacements]){proof.assertPinned(ref);pin(proof.anchors,ref);}
    assert.equal(d.replacements.format,'json');const replacements=readJson(locate(proof.anchors,d.replacements));assert.equal(replacements.length,d.replacements.rows);
    const map=new Map(replacements.map(car=>[car.id,car]));assert.equal(map.size,replacements.length);assert.deepEqual(replacements.map(car=>car.id),expected.filter(row=>map.has(row.id)).map(row=>row.id));
    const used=new Set(),seen=new Set();let ordinal=0;
    async function accept(original,isNew=false){
      const row=expected[ordinal];assert(row);assert.equal(original.id,row.id);assert.equal(original.brand,row.brand);assert(!seen.has(row.id));seen.add(row.id);
      if(isNew)assert.equal(row.beforeSha256,null);else assert.equal(digestRows([original]).sha256,row.beforeSha256);
      const car=map.get(original.id)||original;if(map.has(original.id))used.add(original.id);
      const digest=digestRows([car]);assert.equal(digest.sha256,row.afterSha256);assert.equal(digest.bytes,row.bytes);await visit(car,ordinal++);assert.deepEqual(digestRows([car]),digest);
    }
    if(d.baseline.format==='storage-index')await visitCompleteCars(proof,car=>accept(car),d.baseline,active);
    else{assert(!d.baseline.format||d.baseline.format==='jsonl');await streamRows(proof.anchors,d.baseline,car=>accept(car));}
    assert.equal(ordinal,d.baseline.rows);assert.equal(ordinal+d.newIds.length,d.rows);assert.deepEqual(expected.slice(ordinal).map(row=>row.id),d.newIds);
    for(const id of d.newIds){assert(!seen.has(id));assert(map.has(id));await accept(map.get(id),true);}
    assert.equal(ordinal,d.rows);assert.equal(used.size,map.size);assert.equal(seen.size,d.rows);
    for(const ref of [indexRef,d.baseline,d.replacements])pin(proof.anchors,ref);
  }finally{active.delete(file);}
}

export function actualConsumers(proof){
  const require=createRequire(path.join(proof.anchors.repo,'package.json'));
  const {brandUpdatePackets}=require('./src/lib/brand-update-registry.ts');assert.deepEqual(brandUpdatePackets,proof.registeredPackets);assert.equal(brandUpdatePackets.length,18);assert(!brandUpdatePackets.some(row=>row.id===proof.packet.id||row.brand==='XPENG'));
  const {createEvidenceConsumers}=require('./src/lib/evidence-consumers.ts'),{compiledSource}=require('./tests/helpers/compiled-source.ts');
  let loaderCalls=0;const forbidden=()=>{loaderCalls++;throw new Error('XPENG_CONSUMER_FORBIDDEN_DEFAULT_LOADER');};const defaults={sourceResearch:forbidden,research:forbidden,catalogue:forbidden};
  const registryBinding={brandUpdatePackets:[...brandUpdatePackets,proof.packet]};
  const factory=compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':registryBinding}).createEvidenceConsumers;
  function verify(){assert.equal(loaderCalls,0);assert.deepEqual(brandUpdatePackets,proof.registeredPackets);assert.deepEqual(registryBinding.brandUpdatePackets,[...brandUpdatePackets,proof.packet]);assert(!require.cache[path.join(proof.anchors.repo,'src/lib/data.ts')]);}
  verify();return {require,base:createEvidenceConsumers(defaults),staged:factory(defaults),registryBinding,brandUpdatePackets,verify,loaderCalls:()=>loaderCalls};
}
