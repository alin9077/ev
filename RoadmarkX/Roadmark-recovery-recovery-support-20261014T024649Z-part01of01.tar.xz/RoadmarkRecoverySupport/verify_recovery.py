#!/usr/bin/env python3
"""Verify Roadmark recovery archives without changing a restored tree."""
import hashlib,json,sys,tarfile
from pathlib import Path
def sha(data):return hashlib.sha256(data).hexdigest()
def verify(path):
    with tarfile.open(path,"r:xz") as archive:
        members=archive.getmembers();names=[m.name for m in members]
        if len(names)!=len(set(names)):raise ValueError("Duplicate member names")
        if any(not m.isfile() or m.name.startswith("/") or ".." in Path(m.name).parts for m in members):raise ValueError("Unsafe member")
        manifest_names=[n for n in names if n=="roadmark/SOURCE-FILE-MANIFEST.json" or n.startswith("recovery-metadata/") and n.endswith(".json")]
        if not manifest_names:raise ValueError("No embedded manifest")
        expected={}
        for name in manifest_names:
            data=json.load(archive.extractfile(name))
            for record in data["files"]:
                member="roadmark/"+record["path"] if name=="roadmark/SOURCE-FILE-MANIFEST.json" else record["path"]
                expected[member]=record
        for name,record in expected.items():
            data=archive.extractfile(name).read()
            if len(data)!=record["bytes"] or sha(data)!=record["sha256"]:raise ValueError("Hash mismatch: "+name)
        allowed=set(expected)|set(manifest_names)|{n for n in names if n.startswith("recovery-metadata/") and n.endswith("-RESTORE.txt")}
        if set(names)!=allowed:raise ValueError("Unmanifested members")
    print(json.dumps({"filename":path.name,"bytes":path.stat().st_size,"sha256":sha(path.read_bytes()),"verifiedFiles":len(expected),"result":"PASS"}))
if __name__=="__main__":
    if len(sys.argv)<2:raise SystemExit("Usage: python3 verify_recovery.py archive.tar.xz [...]")
    for arg in sys.argv[1:]:verify(Path(arg))

