# Independent Tesla M1 packet review

Verdict: Approved for Tesla packet registration, subject to the parent's coordinated importer, feature-overlay and integration validation. No research-value or reviewed-snapshot blocker remains. This is not a global C1, C2, C5 or M1-completion sign-off.

Reviewed the final staged packet and reconciliation against DOT-BRIEF-103.md, M1-BRAND-UPDATE-PACKET.md and the prior independent BYD review. Source checks used current Australian pages, captured product/configurator payloads, PDF pixels and Australian secondary reports. Read-only repository review; no catalogue/registry edits and no heavy full-catalogue tests or builds. The 14 October Australian observation date is consistent with captures taken late on 13 October UTC.

## Current range, prices and availability

- The two current Australian configurators and product specification blocks establish eight current versions: four Model 3 sedans, three five-seat Model Ys and one six-seat Model Y L. The reconciliation contains separate 4/3/1 body reviews. The L display update retains its stable ID/modelId and exactly matches its prior identity guard.
- Independently viewed the Model 3 configurator price screenshot: RWD A$45,900, Premium RWD A$54,900, Premium Long Range RWD A$61,900 and Performance AWD A$80,900. The Model Y configurator's exact trim payloads establish Premium RWD A$58,900, Premium Long Range AWD A$68,900, L Premium AWD A$74,900 and Performance AWD A$84,900.
- Each is a rung-3 maker configurator base price including GST. The separate A$1,400 delivery and A$400 order fees are disclosed. The Model 3 breakdown screenshot establishes these mandatory fees separately from government on-roads. No example NSW driveaway total, trade-in bonus, fuel saving or finance assumption is substituted. No independently established higher maker list-price/national-driveaway rung was omitted.
- Availability means advertised ordering only. All eight records expressly leave actual stock and factory acceptance unverified. Tesla's [ordering guide](https://www.tesla.com/en_au/support/ordering-new-vehicle), current AU endpoints and [CarExpert's range page](https://www.carexpert.com.au/tesla) support the S/X and Cybertruck decisions. Roadster reservation terms do not establish a current configurable retail order. Whole-market published-list reconciliation correctly remains open.

## Dimensions, cargo, towing and charging

- Independently inspected Model 3 manual pages 100, 221 and 222 as images. The rear boot is 594 L, front trunk 88 L, and combined cargo with five passengers 682 L. The four unsupported 977 L seats-folded claims are removed from both canonical facts and the four Model 3 storage presentations. The manual's 977 is a rear-overhang dimension in millimetres, not cargo volume.
- The [current AU Model Y manual](https://www.tesla.com/ownersmanual/modely/en_au/GUID-1E76B638-7B12-4D9A-8767-94B7F1E92A0E.html) independently establishes 822 L behind the second row for five-seat cars and 420 L behind the L's third row. Front cargo is 116 L. Maximum combined cargo is 2,138/2,539 L respectively and already includes the front trunk. The final storage rows make that explicit. No VDA method is established; boot facts remain visible but unranked.
- Width uses the body excluding mirrors: Model 3 1,850 mm; Model Y/L 1,920 mm. Folded and extended mirror widths are not substituted. Premium Y length and L height discrepancies between product/manual remain Check with real cited issues, so the unresolved values are excluded from ranking. Their conflicting numbers are preserved rather than silently reconciled.
- Model 3's 1,000 kg braked table is explicit and tow-package/approved-tyre/controller conditions are retained. Performance's zero represents no permitted towing in its supplied 20-inch configuration, not an invented physical maximum; product, manual and accessory citations cover all premises. The [Y/Y L tow page](https://shop.tesla.com/en_au/product/model-y_-y-l-tow-package) and manual support 1,588 kg for five-seat cars with required equipment. L retains the manual's published 1,558 kg as conflicted Check, including the 1,588 kg accessory figure, duplicate five-passenger rows and 1,043 kg six-occupant limit. Its unresolved towing value is unranked.
- AU product blocks support current range/DC peaks. Model 3 LR's 750 km is qualified to 18-inch wheels, with the 691 km 19-inch alternative retained. Both Performance acceleration claims explicitly preserve rollout subtraction. The [AU Wall Connector vehicle table](https://www.tesla.com/en_au/support/charging/wall-connector) supports the 11 kW three-phase charging figure and 7.4 kW single-phase qualification.
- Five exact 10–80% times remain Not published: all Model 3s and Model Y Premium RWD. Each has two genuine, distinct examined documents. Tesla's 15-minute range-added claims and CarsGuide's 15–85% test are not converted. Three Y AWD versions retain the Australian [March launch report](https://www.carexpert.com.au/car-news/2026-tesla-model-y-l-prices-six-seat-ev-on-sale-in-australia-and-new-zealand-1) of approximately 25–30 minutes solely as Reported prior-MY26 family evidence, with current hardware scope unproven and no rank.

## Secondary numbers and ownership terms

- Independently read RACQ's new Model 3 RWD 62.5 kWh report, current RedBook RWD 208 kW, carsales' explicit MY27 Model 3 LR 85 kWh/235 kW and Model 3 Performance 85 kWh, plus current RedBook Y RWD 255 kW and Y LR/L 85 kWh/378 kW. Battery usable/gross scope is not invented. Premium RWD and Y RWD inheritance is explicitly Reported and qualified to the relevant prior/sibling report.
- Y Performance's RedBook page could not be independently reopened through the read tool; I independently inspected the lead's saved full search extraction, which explicitly contains MY27, A$84,900, 580 km, 85 kWh and 461 kW, together with conflicting Germany-origin metadata. The packet retains that discrepancy and Reported status. For Model 3 Performance, maker 343 kW/128 mm/current towing conditions take precedence over the secondary database's inconsistent unrelated fields. No battery energy is calculated and no individual motor powers are added.
- The current [Australian warranty page](https://www.tesla.com/en_au/support/vehicle-warranty), linked AU PDF and PDF pixels support five years/unlimited kilometres under normal use for current new deliveries from 1 January 2026. Battery/drive-unit grouping is correctly 8 years/192,000 km for five versions and 8 years/160,000 km for the three enumerated RWD exceptions, with whichever first and 70% retention retained. Model 3 LR RWD correctly receives the longer distance term.
- Roadside terms are shared once, tied to active basic warranty and qualified by the published breakdown/tyre/lockout limits and depleted-battery exclusions. Commercial-use uncertainty is disclosed without inventing a maker kilometre cap. Each shared term and explicit exception accounts for all eight versions.

## Final artifact checks

- 45 source records have valid cited capture-hash matches. No altered existing source snapshot, invented fragment URL or duplicate fact target was found.
- All 159 fact before-snapshots, eight version guards, one identity update, eight availability snapshots and all shared-term before-snapshots exactly match the staged pre-packet effective view. Source IDs, source-review IDs, packet IDs and observation dates agree.
- All 16 strength/trade-off clauses are substantively supported; all 26 dependency snapshots exactly match effective post-packet facts. The LR sedan statement now includes body_style. No unrelated freshness proxy or global superlative is used.
- All eight storage feature before-snapshots match features-before.json. Their 32 dependencies exactly match post-packet facts, including seats. The Model 3 folded-volume gap is explicitly included as a dependency and not disguised as a confirmed numeric claim.
- Nine Not published facts remain: five core charging-time cells plus four non-core Model 3 folded-cargo maximum cells. All have at least two distinct examined source URLs. Boot method and real source-conflict exclusions follow the existing discovery policy. Reported values stay unranked.

The parent's final feature-overlay behavioral tests and coordinated registration/integration checks remain necessary. No claim is made that these focused research checks substitute for the full milestone gates.

## Reproduction identity

Packet: /tmp/tesla-research/tesla-2026-10-14.json
SHA-256: ed099843f37d65d0b8dbbc949b77b5ca01141936c7921cef3b5d24fb2ffdc059

Reconciliation: /tmp/tesla-research/tesla-reconciliation-2026-10-14.json
SHA-256: 4f1ec930cfd512fea44d890cc30e62c9b7a64287496910361dc982748eff0576

Review checker: ../roadmark-104-qa/review-tesla-packet.py (lightweight structural checks only; feature snapshots additionally checked independently).

## Amendment review: motor-output buyer answers (14 October 2026 Australia)

Current verdict: Approved amended packet e45015f156b981e2c6e9e94338c4d548c91a2588d092a7e0b139fe0e0cc45d03 for the parent's coordinated registration/integration validation. This supersedes the earlier working-packet approval above; the old review and hash are retained as history. No new market research or publication is included.

The parent identified a remaining contradiction after the initial approval: all eight performance_rear_motor equipment answers still said output was not published, although canonical power facts were populated. This amendment closes that duplicate-presentation gap.

Independently verified:

- The sole semantic change from approved ed099843f37d65d0b8dbbc949b77b5ca01141936c7921cef3b5d24fb2ffdc059 is eight appended performance_rear_motor feature replacements. Every prior top-level section and each of the eight existing storage rows deep-equals the earlier approved packet. No canonical fact, source, version, availability, shared term, summary or reconciliation was changed.
- Each new full before-snapshot matches the independently retained pre-packet feature capture. Each has exactly two complete dependency snapshots, power_kw and drive, matching the already approved canonical facts. The canonical drive key is drive, not drive_type. All 16 new dependencies, feature/source IDs, date fields, overlay IDs, grade scopes and status mappings match.
- Seven outputs remain explicitly Reported in the displayed value and explain their Australian secondary source. The Premium Model 3 RWD 208 kW inheritance retains its prior Australian 520 km/6.1-second RWD scope. Model Y Performance retains RedBook's Germany-versus-current-Shanghai metadata discrepancy. Nothing is promoted to maker confirmation.
- Model 3 Performance alone displays maker-confirmed 343 kW peak vehicle output. All AWD rows distinguish whole-vehicle output from an individual rear motor and explicitly avoid summing motor ratings. RWD rows accurately identify their single rear-motor outputs. New values are consistent with the source review above.
- Re-ran the lightweight packet checker successfully. Also inspected the lead's feature-helper validation result, which reports eight applied rows, unchanged sections and immutable inputs. This is a focused helper check, not a substitute for the parent's broader regression run.
- The original approved packet is preserved byte-for-byte at /tmp/tesla-research/review-history/tesla-approved-ed099843f37d65d0b8dbbc949b77b5ca01141936c7921cef3b5d24fb2ffdc059.json; independently recomputed its SHA-256. A separate reviewer copy is ../roadmark-104-qa/tesla-packet-approved-ed099843.json. The amendment-history JSON accurately records old/new hashes and append-only scope.

Current approved packet SHA-256: e45015f156b981e2c6e9e94338c4d548c91a2588d092a7e0b139fe0e0cc45d03
Unchanged reconciliation SHA-256: 4f1ec930cfd512fea44d890cc30e62c9b7a64287496910361dc982748eff0576
Total guarded feature rows after amendment: 16 (eight storage, eight motor-output answers).
