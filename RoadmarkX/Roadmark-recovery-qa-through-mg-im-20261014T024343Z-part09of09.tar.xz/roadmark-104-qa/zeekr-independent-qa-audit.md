# Zeekr M1 independent QA — 14 October 2026

**Decision: approved for integration at the exact hashes in `zeekr-approved-hashes-and-checks.json`.** Research approval is not a claim that global M1 is complete. No packet was registered and no original/core source was edited by this reviewer.

## Scope and result

- Reviewed the full governing brief and packet contract, current Australian primary pages/PDFs, relevant secondary evidence, and the final packet against the effective catalogue after BYD, Tesla and Geely
- Eight current versions: three regular 7X, two MY26 X, and three 009. Black Edition and original MY24 X AWD remain separately visible as outgoing / Not confirmed. The original X model year is not inferred from its 2025 build/compliance
- All 17 core fields have freshly reviewed, labelled facts for every retained version. The final packet has 187 version-specific facts plus 27 inherited brand-term cells, 30 reviewed equipment rows, 53 feature dependencies, ten guarded summaries, and 72 captured source records
- Full independent source/fact/identity/metadata/availability/brand-term/feature/summary checks passed. Deliberately changed source, before snapshot and dependency cases fail closed. The actual importer produced 214 correct citable fact cells and 30 correct citable equipment rows, with exact portable-store/hydrate roundtrip
- All 64 original source/research files still match the original immutable manifest. New source capture hashes all match. Separate final source-bound model-list reconciliation is retained

## Material evidence judgments

- **Price:** current maker 7X list prices use rung 1 before on-road costs. MY26 X national driveaway and 009 list prices remain explicitly Reported where the named-version maker price was not recoverable. No offer was applied to an unstated grade, no on-road conversion was performed, and original X’s specific Perth dealer offer remains rung 6, unranked
- **009 charging:** contemporaneous maker sources agree on 30 minutes from 10–80% but state 150 kW or 205 kW station conditions. Both conditions remain visible. A Check duration on the same SOC window is not excluded merely for that condition discrepancy. Neither station rating becomes vehicle peak. Secondary 205 kW editorial and 206 kW JATO peak claims remain separately labelled, Reported and unranked
- **Storage and scope:** occupied-seat rear boot is separate from front/folded storage. The maker’s explicit 009 FWD 574 L all-seats statement is corroborated by equal body capacities in all three brochure columns. MY26 X’s 404 L is not carried into the original X’s reported 362 L ISO figure. Dimensions/seats apply at the documented body/grade scope; optional doors, colours and wheels do not become extra versions or standard fitment
- **Availability:** direct checking disproved the stale Doncaster original-RWD “New” lead; it redirects to inventory. Essendon originals are Demo. The authorised Perth dealer labels stock 0247 New while the exact same Carsales unit is Dealer used. The contradiction is retained, with no claim of physical stock or confirmed new supply. Bounded Black Edition checks found used/sold/redirected or wrong-grade advertisements, not proof of nationwide unavailability
- **Terms:** private maker baseline remains Confirmed. The policy’s commercial duration caps conflict with application clause 3 excluding commercial use; final qualifications retain the conflict and require confirmation. Terms begin at first registration, with component, maintenance and roadside exceptions. Roadside alternative transport is capped at five people, material to six/seven-seat 009 buyers. Original X has separately sourced historical vehicle/battery/roadside terms; current 70% SoH and a fresh term at resale are not assumed
- **Excluded leads:** 7GT is interest registration expressly not an order; announced future timing is not current availability. 8X/9X are PHEVs outside BEV scope. Announced 009 Grand is not a current exact Australian retail version

## Narrow importer fix

Independently reviewed the bounded unknown-field initializer and regression. It adds neutral unknowns only for 25 shared buyer fields after reviewed values, rather than copying the catalogue-wide equipment-key union. Original X now has 26 facts, including its reviewed historical-price field; all 19 explicit reviewed fields remain byte-equivalent. Compact car size is 24,782 bytes and compact detail pack 60,268 bytes. Unknown equipment/update history remains unknown, not earned Not published.

## Limits retained

Global C1 is open; the two independent brand lists are not represented as whole-market lists. C5 remains below target because Reported values and unestablished measurement methods cannot be promoted into rankings. This review covers M1 core facts and their dependent buyer prose, not a fresh review of every inherited non-core equipment claim. Root owns final integrated tests and release work.

Final staged report independently reconciled to this reviewer’s exact car and feature snapshots: eight on-sale versions, no missing models/leads/summaries or aged/invalid claims; C2/C3/C4/C6 pass, C1/C5 remain open.
