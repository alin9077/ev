from pathlib import Path
from datetime import datetime,timezone
import os,stat,json,hashlib
B=Path('/tmp/audi-handoff');R=Path('/workspace/scratch/586427eef9f2/roadmark-104');Q=R.parent/'roadmark-104-qa'
def pin(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def verify(p,want):
 v=pin(p);assert v['bytes']==want['bytes'] and v['sha256']==want['sha256'],str(p);return v
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,ensure_ascii=False);f.write('\n')
roots=[Path('/tmp')/x for x in ['audi-research','audi-packet','audi-review','audi-split-proposal','audi-split-diagnostic','audi-split-static-checks','audi-split-static-checks-v2','audi-registration-tests','audi-registration-bundle']]+[Q/'audi-sequential-checks']
files=[];links=[];other=[]
for root in roots:
 assert root.is_dir() and not root.is_symlink()
 for d,ds,fs in os.walk(root,followlinks=False):
  for name in sorted(ds+fs):
   p=Path(d)/name;s=p.lstat()
   if stat.S_ISLNK(s.st_mode):links.append({'path':str(p),'target':os.readlink(p),'resolvedTarget':str(p.resolve()),'traversed':False})
   elif stat.S_ISREG(s.st_mode):files.append({'path':str(p),'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'mode':s.st_mode})
   elif not stat.S_ISDIR(s.st_mode):other.append({'path':str(p),'mode':s.st_mode})
assert len(links)==7 and not other
inv={'scope':'Exact metadata-only inventory, no symlink traversal, no content scan or archive capture','at':datetime.now(timezone.utc).isoformat(),'roots':[str(r) for r in roots],'regularFiles':sorted(files,key=lambda x:x['path']),'symlinks':sorted(links,key=lambda x:x['path']),'otherEntries':other,'regularFileCount':len(files),'regularFileBytes':sum(x['bytes'] for x in files)}
write(B/'retention-inventory.json',inv)
m=json.loads(Path('/tmp/audi-registration-bundle/manifest.json').read_text());source=[]
for t in m['targets']:source.append(verify(t['target'],t['after']))
cor=json.loads(Path('/tmp/audi-packet/fixture-typescript-correction-v1/manifest.json').read_text())
# Bind the known exact accepted final test bytes, independently of the original registration bundle.
test=pin(R/'tests/evidence-consumers.test.ts');assert test['sha256']=='49536d663c4b3efe2c32b16fdfde72bb96a3a831c6917b8263a82af39100fbf5';source.append(test)
dm=json.loads(Path('/tmp/audi-packet/docs-draft/documentation-bundle-manifest.json').read_text())
for t in dm['targets']:source.append(verify(R/t['relativePath'],t['after']))
st=json.loads(Path('/tmp/audi-packet/status-transition-v1/manifest.json').read_text());source.append(verify(st['target'],st['after']));assert len(source)==17
receipts=[pin(Path('/tmp/audi-review')/x) for x in ['registration-v1-readback.json','post-registration-nine-results-acceptance.json','fixture-type-correction-focused-results-acceptance.json','full-project-typescript-v1-result-review.json','full-project-typescript-v2-result-acceptance.json','documentation-final-readback.json','status-transition-v1-readback.json']]
freeze={'status':'final_Audi_source_docs_status_and_research_retention_freeze','at':datetime.now(timezone.utc).isoformat(),'noFurtherLiveWritesAuthorized':True,'heavyProcessesActive':False,'sourceAndStatusFiles':source,'retentionInventory':pin(B/'retention-inventory.json'),'metadataOnlyLinks':links,'reviewerReceipts':receipts,'researchProvenance':[pin('/tmp/audi-research/recovery-provenance-metadata.json'),pin('/tmp/audi-research/source-index-review-v1.json'),pin('/tmp/audi-research/census-review-v2.json'),pin('/tmp/audi-research/normalized-review-v5.json')],'backupScope':'Reuse delivered Skoda base; capture only exact selected new or changed artifacts and preserve failures. No full catalogue hydration or dependency traversal. Backup owner performs independent privacy/value scan, restoration verification and delivery.','includedFailures':['Selected preflight v2 harness failure and corrected v3','Browser denied before navigation; no retry','Rejected broad static pin preparation, never run','Earlier compiler OOM provenance','Cold full-project v1 TS2345 diagnostic','Superseded unrun 60-second focused-check preparation'],'finalOutcomes':{'cars':427,'tier1':350,'onSale':309,'packets':25,'AudiTargetedTests':190,'separateTypingCorrectionTests':18,'fullProjectTypeScriptPassed':True,'configuredRoots':361,'cacheOnlyOverride':True,'fullSuitePassed':False,'productionBuildPassed':False,'mobilePassed':False,'wholeMarketLists':0,'M1Complete':False},'publicCalculatorProvenance':'Observed unauthenticated read-only GraphQL identity enumeration and GetPrice GET published totals remain separately recorded in retained research and independent rechecks. No authenticated requests or user credentials.','sensitiveHandlingNotes':['Source captures use whitelisted response headers; Cookie, Set-Cookie, Authorization and token-bearing headers were not retained','Public HTML/application bodies may contain public configuration or token-like values; backup owner must independently classify actual values without echoing them','Known wrappers retain command arguments, process IDs, local paths, environment key removals and safe compile-cache override; no credential values intentionally recorded','Do not traverse seven symlinks into installed dependencies or live source; keep metadata/reference reconstruction'],'handoffArtifacts':[pin(B/'freeze-retention.py')],'scopeBoundary':'This freeze pins the exact listed files. The handoff manifest itself and its inventory are additional retention metadata; later backup receipts belong to the backup owner.'}
write(B/'final-freeze.json',freeze)
print(json.dumps({'inventory':pin(B/'retention-inventory.json'),'freeze':pin(B/'final-freeze.json'),'regularFiles':len(files),'regularFileBytes':inv['regularFileBytes'],'links':len(links),'sourcePins':len(source)}))
