# Installed-layout Audi inventory-split regression bundle

Prepared only under `/tmp/audi-registration-tests`. No live repository edits, test run, compiler run, helper execution, or baseline capture were performed by this bundle author. The ordinary expected-output file is intentionally absent until the separately approved capture completes successfully.

## Installation candidates

Copy only these repository-relative files after the owning task authorizes installation:

- `tests/m1-inventory-split.test.ts`
- `tests/fixtures/m1-inventory-split/reconciliation.json`
- `tests/fixtures/m1-inventory-split/unchanged-review-dispositions.json`
- `tests/fixtures/m1-inventory-split/original-combined-lead.json`
- `tests/fixtures/m1-inventory-split/inventory-audi.json`
- `tests/fixtures/m1-inventory-split/packet-q6-my27.json`
- `tests/fixtures/m1-inventory-split/ordinary-cases.json`
- `tests/fixtures/m1-inventory-split/ordinary-expected.json` after approved capture

The test imports the actual installed `../scripts/reporting/m1-reconciliation`, `../scripts/reporting/reports`, and type definitions from `../src/lib/types`. The bundle contains no replacement helper, report consumer, dependency tree, baseline helper, package file, node_modules link, or compiler configuration. It cannot be run in isolation and must not be treated as a shadow application tree.

## Coverage equivalence

All 78 accepted protections remain: 10 standalone tests and 68 parameterized adversarial tests. Source-level inspection confirms the 68 mutation cases, compile-time list boundary, valid split/immutability/key-order tests, body-related tests, inherited explicit constraints, unrelated same-brand review, future/on-sale separation, and stale/missing eligibility tests are textually unchanged.

The first fixture test no longer reads a complete old baseline registry. Its explicit expectation contains only the full unchanged review objects and the noncombined disposition objects. It still compares every parsed field of every previously compared object. An exact-one combined-disposition assertion plus equality of the entire ordinary-disposition array replaces the former aggregate fixture length assertion, preserving equivalent coverage without whole-run checkpoint pins. The complete original inherited row, two exact body components, and four declared exact versions remain checked.

The two ordinary-case tests replace runtime old-helper comparison with explicit captured expected results for exactly these inputs:

1. Valid ordinary single-review inclusion
2. The same ordinary case with an unrecognized inventory model
3. Ordinary published-list inclusion through the existing explicit alias

The three-case input JSON stores a shared exact ordinary base plus explicit overrides. The base retains all original registry metadata, the complete original ordinary inventory row, and the three synthetic identity cars produced by the accepted test. This is not a full catalogue or report checkpoint. The future packet fixture keeps precisely the availability fields and source records consumed by the tests. The inventory fixture contains just the combined inherited lead used by the first test.

The capture records every returned field except `evidence`, whose reference equality to the input registry is asserted both during capture and in the installed test. Each input must stay deep-equal to its pre-call clone. Exact own-enumerable undefined-property paths are obtained from the actual baseline result, then only those captured paths are restored in the JSON expected value before whole-output deep equality. No blanket removal or unconditional issue-field restoration is used. The three expected outcomes are asserted before stdout is emitted.

The runtime-injected split/list rejection assertions and the `@ts-expect-error` ordinary/list type boundary remain in place. Existing ordinary-helper comparisons in `/tmp/audi-split-proposal` remain historical QA evidence, not installed test dependencies.

## Capture handoff

- Script: `capture/ordinary-baseline.ts`
- Reviewed input provenance: `capture/provenance.json`
- Cases: `tests/fixtures/m1-inventory-split/ordinary-cases.json`
- Required successful stdout destination: `tests/fixtures/m1-inventory-split/ordinary-expected.json`

The script imports only the actual unchanged baseline reconciliation helper at `/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/m1-reconciliation.ts`, plus built-ins and type-only imports. Before calling the helper, it checks that helper and input hashes match the provenance. It accepts only the three named cases. The output contains compact result fixtures, exact undefined-property metadata, and helper/input provenance hashes. Those hashes are not asserted by the installed regression tests.

The parent owns the bounded wrapper, independent readiness review, capture authorization, capture execution, receipt verification, and later installation/tests. This directory does not grant permission for any of those actions. No capture command is embedded here to encourage accidental execution.

## Static review files

- `test-adaptation.patch`: exact test-source delta from the accepted proposal
- `static-coverage.txt`: static text/data equivalence checks; not runtime proof
- `candidate-sha256.txt`: installation-candidate identities before the output fixture exists
- `bundle-sha256.txt`: authored bundle identities before the output fixture exists

The parent must add the successful expected-output fixture hash to its final installation manifest. Successful capture does not itself establish the split helper's behavior; the installed focused tests and scoped typecheck remain separate authorized checks.
