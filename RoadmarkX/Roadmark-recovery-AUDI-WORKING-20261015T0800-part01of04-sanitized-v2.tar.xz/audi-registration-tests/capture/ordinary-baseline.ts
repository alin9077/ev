/** One-time, three-case fixture capture. Do not run before independent readiness review. */
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import {
  buildMarketReconciliation,
  type CurrentVersionReview,
  type M1MarketReconciliation,
} from "/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/m1-reconciliation";
import type { ReportInventory } from "/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/reports";
import type { Car } from "/workspace/scratch/586427eef9f2/roadmark-104/src/lib/types";

const provenance = JSON.parse(readFileSync(new URL("./provenance.json", import.meta.url), "utf8")) as {
  helper: { path: string; sha256: string };
  caseInput: { path: string; sha256: string };
  caseIds: string[];
};
const sha256 = (bytes: Buffer) => createHash("sha256").update(bytes).digest("hex");
const helperPath = "/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/m1-reconciliation.ts";
if (provenance.helper.path !== helperPath || sha256(readFileSync(helperPath)) !== provenance.helper.sha256)
  throw new Error("Actual live baseline helper differs from reviewed capture provenance");
const inputBytes = readFileSync(new URL(provenance.caseInput.path, import.meta.url));
if (sha256(inputBytes) !== provenance.caseInput.sha256)
  throw new Error("Ordinary case input differs from reviewed capture provenance");
const cases = JSON.parse(inputBytes.toString("utf8")) as {
  schemaVersion: 1;
  asOf: string;
  base: { registry: M1MarketReconciliation; cars: Car[]; inventory: ReportInventory };
  cases: {
    id: string;
    registryOverrides: Partial<M1MarketReconciliation>;
    reviewOverrides: Partial<CurrentVersionReview>;
    inventoryRecordOverrides: Partial<ReportInventory["records"][number]>;
  }[];
};
const ids = ["single-valid", "single-invalid-model", "published-list-alias"];
if (cases.schemaVersion !== 1 || JSON.stringify(cases.cases.map((item) => item.id)) !== JSON.stringify(ids) ||
    JSON.stringify(provenance.caseIds) !== JSON.stringify(ids))
  throw new Error("Only the three reviewed ordinary cases may be captured");
type ExpectedReport = Omit<ReturnType<typeof buildMarketReconciliation>, "evidence">;
const outputs: Record<string, { expected: ExpectedReport; ownUndefinedPaths: string[][] }> = {};
function ownUndefinedPaths(value: unknown, prefix: string[] = []): string[][] {
  if (value === null || typeof value !== "object") return [];
  return Object.entries(value).flatMap(([key, child]) =>
    child === undefined ? [[...prefix, key]] : ownUndefinedPaths(child, [...prefix, key]));
}
for (const selected of cases.cases) {
  const input = structuredClone(cases.base);
  Object.assign(input.registry, structuredClone(selected.registryOverrides));
  Object.assign(input.registry.currentVersionReviews[0], structuredClone(selected.reviewOverrides));
  Object.assign(input.inventory.records[0], structuredClone(selected.inventoryRecordOverrides));
  const before = structuredClone(input);
  const { evidence, ...expected } = buildMarketReconciliation(input.registry, input.cars, input.inventory, cases.asOf);
  assert.deepEqual(input, before, `Baseline input mutated for ${selected.id}`);
  if (evidence !== input.registry) throw new Error(`Unexpected evidence behavior for ${selected.id}`);
  outputs[selected.id] = { expected, ownUndefinedPaths: ownUndefinedPaths(expected) };
}
assert.deepEqual(outputs["single-valid"].expected.settledInventory, ["record:audi-q6-e-tron"]);
assert.equal(outputs["single-invalid-model"].expected.settledInventory.includes("record:audi-q6-e-tron"), false);
assert.equal(outputs["published-list-alias"].expected.settledListEntryCount, 2);
assert.equal(outputs["published-list-alias"].expected.pass, true);
// Fixture-only stdout; hashes describe capture provenance and are not historical test pins.
process.stdout.write(`${JSON.stringify({
  capture: {
    schemaVersion: 1,
    helperSha256: provenance.helper.sha256,
    inputSha256: provenance.caseInput.sha256,
    caseIds: ids,
    inputUnchanged: true,
  },
  cases: outputs,
}, null, 2)}\n`);
