# Audi M1 reviewed integration, 15 October 2026

## Reviewed and registered scope

- Seven retained exact MY26 Audi configurations refreshed
- Ten additions: two current MY26 Q6 sport-edition bodies, four future MY27 Q4 grades/bodies, four future MY27 Q6/SQ6 grades/bodies
- Seventeen registered records across seven exact model-year/body reviews; nine on-sale, eight future order-open/arrival records
- Four announced MY27 Q6/SQ6 versions remain distinct. Maker arrival/specification evidence and secondary order-opening evidence are attributed separately
- No physical stock, accepted factory order, delivered VIN or individual delivery promise inferred

## Evidence and price ladder

- Current MY26 base Q6/SQ6 and GT prices use the maker's directly displayed NSW driveaway calculator totals, including applicable LCT. GraphQL enumerates exact identities; observed public GetPrice GET responses supply totals. Sydney Metropolitan CTP estimate conditions are retained
- Current Q Sales SUV sport offer is A$95,900 driveaway, with its directly bound 1–31 October legal terms. The Sportback sport figure has unresolved maker price/scope conflicts and remains unranked
- MY27 Q4 and Q6/SQ6 prices are explicitly before on-road costs. They are not copied into a Driveaway feature or included in current on-sale rankings
- All 289 core fact cells are reviewed: 142 Confirmed, 31 Check, 70 Reported, 46 Not published
- There are 339 total earned packet fact/term cells, including 50 supplemental cells. Reported and conflict-held values stay visible without ranks; missing facts retain two-source search reasons
- Manufacturer body-wide seats, cargo and brand warranty scope are respected. Unknown cargo measurement protocols remain unranked rather than being invented as conditions

## Residual and whole-market limits

- Q4 MY26 45/55 calculator records do not establish current New availability and are not added
- Q8/SQ8 still have maker index links, but the exact current pages say they are no longer available to order. No qualifying live exact New residual ad was verified
- Historical Q6 grades and older GT variants remain outside the reviewed current list
- A6/S6 Australian introduction was cancelled according to the captured report quoting Audi Australia
- Two independently published complete whole-market model-list snapshots are still missing; global C1 remains open
- The inherited combined MY27 Q6/SQ6 SUV/Sportback lead is resolved by a reviewed registered inventory-only split disposition: the entire original row, two body-specific reviews and all four exact versions are guarded. All eight Audi inventory dispositions pass the actual helper. Ordinary matching and on-sale denominators remain unchanged

## Review and execution status

- Independent reviewer passed normalized semantic/source closure and exact candidate before-guard review
- All nominated source capture hashes matched; seven calculator prices were independently rechecked
- Candidate packet is frozen at SHA-256 4a85ee0d92c7a49e3e2265791516658699dfe2320d3e52e2ce39b58b2f6d172e
- Selected actual-function preflight v3 passed: seven before/seventeen after rows, 339 earned cells, 1,173 feature claims, exact source/configuration/summary/availability guards, actual ranking holds, live and written portable parity, and same-run C1 exact identities. It finished in 4.25 seconds with 350,156 KiB peak RSS; all pinned inputs were unchanged. Sixteen before and twenty-six after own-undefined optional paths were individually bound to exact witnesses and real producers
- Expected ranked IDs by attribute: length 2, range 3, price 8, DC time 3, towing 4, seats 3, cargo 0
- Only nine reviewed MY26 Driveaway facts project into the driveaway_price feature. The eight MY27 before-ORC rows keep that feature unverified
- All 78 split-helper tests and the actual selected split-C1 diagnostic passed. Isolated strict compilation of the 19-file source closure and lint of the two new files passed; this is not full-project TypeScript.
- Full derived staging passed at 427 cars / 350 Tier 1 / 309 on-sale, reproducing accepted Škoda all-field/car digests first and leaving 410 peers unchanged. The full report settles all eight Audi dispositions. Exact selected pack and portable output parity passed again. Staging took 204.74 seconds with 612,472 KiB peak RSS; all 146 pins stayed unchanged.
- The exact 13-target registration was independently reviewed, applied under root grant and read back successfully: packet, registry/reconciliation, inventory-only split helper and its adapted behavioral tests/fixtures. No canonical catalogue recapture occurred.
- Fresh registered validation and the complete normal report pass. All 1,670,700 report bytes exactly match the accepted stage with no ignored fields. All 190 targeted tests pass (78 installed split, 105 existing fixtures, seven live-safety), together with actual 18-source/174-declaration strict compilation and three-file lint. These nine scoped checks are independently accepted. The separate cold full-project TypeScript recheck also passes with all 361 configured roots and original options; only the incremental-cache destination moved to a fresh /tmp file. Its 43.46-second run used 874,928 KiB wait4 peak RSS. The prior 512/640 MiB OOM attempts and completed TS2345 run are preserved. A test-only explicit <string[]> argument corrected the assertion narrowing without changing runtime arguments; its 18 focused differential tests and one-file lint pass separately from the 190 Audi-targeted tests. The full suite, production build and mobile gates remain open.
- Verified registered totals are 427 cars, 350 Tier 1, 309 on-sale and 25 packets. Audi is research-complete; C3/C4/C6 pass and strict C1/C2/C5 remain open. The two independent whole-market lists remain missing.
