"""Prepare metadata and approval proposal only. Does not invoke TypeScript."""
from pathlib import Path
from datetime import datetime, timezone
import ast, hashlib, json, os, shutil, sys

B = Path('/tmp/audi-packet/full-project-typescript-v1')
R = Path('/workspace/scratch/586427eef9f2/roadmark-104')
Q = R.parent / 'roadmark-104-qa'

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        while b := f.read(1024 * 1024): h.update(b)
    return h.hexdigest()

def pin(p):
    p = Path(p)
    return {'path': str(p), 'realpath': str(p.resolve()), 'bytes': p.stat().st_size, 'sha256': sha(p)}

def meta(p):
    p = Path(p)
    if not p.exists(): return {'path': str(p), 'exists': False}
    s = p.stat()
    return {'path': str(p), 'exists': True, 'realpath': str(p.resolve()), 'bytes': s.st_size,
            'mtimeNs': s.st_mtime_ns, 'mode': s.st_mode, 'isDirectory': p.is_dir(), 'isSymlink': p.is_symlink()}

def write(name, value):
    with (B / name).open('x') as f: json.dump(value, f, indent=2); f.write('\n')

config = json.loads((R / 'tsconfig.json').read_text())
assert 'extends' not in config and 'references' not in config and 'files' not in config
assert config['compilerOptions']['incremental'] is True
assert config['exclude'] == ['node_modules']
expected = sorted({str(p.resolve()) for pat in config['include'] for p in R.glob(pat) if p.is_file()})
assert all('/node_modules/' not in p for p in expected)
assert len(expected) == 361
scope = {'status': 'metadata_only_preparation_no_compiler_invocation',
         'method': 'Literal configured glob name/stat inventory; no source contents recaptured or substituted',
         'originalInclude': config['include'], 'originalExclude': config['exclude'],
         'matchedByConfiguredPattern': {pat: len([p for p in R.glob(pat) if p.is_file()]) for pat in config['include']},
         'configuredRootFilePaths': expected,
         'fileMetadata': [meta(p) for p in expected],
         'directoryState': [meta(R / n) for n in ['src', 'tests', 'scripts', '.next/types', '.next/dev/types']],
         'note': 'This list is evidence only and is never supplied to tsc. Normal transitive import/type resolution remains enabled. Content integrity is pinned only for named config, tools, generated types, and live cache; metadata is not a whole-project byte freeze.'}
write('project-root-metadata.json', scope)
packages = ['typescript', 'next', 'react', 'react-dom', '@types/node', '@types/react', '@types/react-dom', '@playwright/test', 'tsx']
versions = {name: json.loads((R / 'node_modules' / name / 'package.json').read_text())['version'] for name in packages}
paths = [R / name for name in ['AGENTS.md', 'package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'tsconfig.json', 'next-env.d.ts', 'tsconfig.tsbuildinfo']]
paths += [R / 'node_modules' / name / 'package.json' for name in packages]
paths += [R / 'node_modules/typescript' / name for name in ['bin/tsc', 'lib/tsc.js', 'lib/_tsc.js', 'lib/lib.esnext.d.ts', 'lib/lib.dom.d.ts', 'lib/lib.dom.iterable.d.ts']]
paths += [R / 'node_modules/next' / name for name in ['index.d.ts', 'image-types/global.d.ts', 'dist/docs/01-app/03-api-reference/05-config/02-typescript.md', 'dist/docs/01-app/03-api-reference/05-config/01-next-config-js/useTypeScriptCli.md']]
paths += sorted((R / '.next/types').glob('**/*.ts'))
paths += [Path('/usr/bin/timeout')]
write('input-pins.json', [pin(p) for p in paths])
prior = []
for sub in ['typecheck-direct-20261015T030817.812003Z', 'typecheck-direct-20261015T030931.105777Z']:
    d = Q / 'test-memory-boundary-20261015T0242/verification' / sub
    cmd, terminal = [json.loads((d / n).read_text()) for n in ['command.json', 'terminal.json']]
    prior.append({'command': cmd['argv'], 'nodeOptions': cmd['NODE_OPTIONS'],
                  'timeoutSeconds': cmd['timeoutSeconds'], 'elapsedSeconds': terminal['elapsedSeconds'],
                  'exitCode': terminal['exitCode'], 'maxRssKiB': terminal['maxRssKiB'],
                  'stderrHasExplicitV8HeapOom': 'heap out of memory' in (d / 'stderr.log').read_text(),
                  'retainedEvidence': [pin(d / n) for n in ['command.json', 'terminal.json', 'resource.json', 'stderr.log']]})
write('prior-attempts.json', prior)
node = str(Path(shutil.which('node')).resolve())
python = str(Path(sys.executable).resolve())
command = [node, '--max-old-space-size=768', '--max-semi-space-size=1',
           str(R / 'node_modules/typescript/bin/tsc'), '--noEmit', '--tsBuildInfoFile',
           str(B / 'run/full-project.tsbuildinfo')]
manifest = {
    'id': 'audi-cold-full-project-typescript-768-v1',
    'status': 'prepared_not_executed_requires_exact_review_and_root_grant',
    'preparedAt': datetime.now(timezone.utc).isoformat(), 'cwd': str(R),
    'command': command, 'supervisor': ['/usr/bin/timeout', '--signal=TERM', '--kill-after=10s', '900s'],
    'wrapper': pin(B / 'run.py'), 'preparer': pin(B / 'prepare.py'),
    'inputPins': pin(B / 'input-pins.json'), 'projectRootMetadata': pin(B / 'project-root-metadata.json'),
    'priorAttempts': pin(B / 'prior-attempts.json'),
    'originalConfig': config, 'installedVersions': versions,
    'runtimeVersion': {'node': 'v24.19.0', 'python': sys.version.split()[0]},
    'runtimeMetadata': [meta(node), meta(python)],
    'originalPackageTypecheckScript': 'tsc --noEmit',
    'coldFullProjectAttempt': True, 'literalPackageScript': False,
    'fullProjectTypecheckPassed': None,
    'timeoutSeconds': 900, 'killAfterSeconds': 10, 'supervisorWatchdogSeconds': 920,
    'timeoutRationale': 'Root selected 900 seconds plus 10 seconds grace, matching both prior attempts\' approved limits. Prior 512/640 MiB attempts OOMed after 10.18/18.24 seconds; this timeout does not predict success or authorize a retry. The 920-second wrapper watchdog only terminates a malfunctioning supervisor.',
    'memoryLimits': {'v8OldSpaceMiB': 768, 'v8SemiSpaceMiB': 1, 'osRssHardLimit': None,
                     'note': 'V8 heap flags do not cap total RSS. Root reported approximately 2 GiB available and no shell memory limit; those observations do not establish a reserved budget or guarantee success.'},
    'environmentRemovals': ['NODE_OPTIONS', 'NODE_PATH', 'NODE_COMPILE_CACHE', 'TS_NODE_PROJECT', 'TS_NODE_COMPILER_OPTIONS', 'TS_NODE_TRANSPILE_ONLY'],
    'environmentOverrides': {'NODE_DISABLE_COMPILE_CACHE': '1'},
    'cacheHandling': {'originalConfigIncrementalPreserved': True,
        'onlyCompilerOptionOverrideBeyondNoEmit': '--tsBuildInfoFile',
        'newCachePath': str(B / 'run/full-project.tsbuildinfo'),
        'newCacheMustNotExist': True, 'seedCacheUsed': False,
        'liveCache': pin(R / 'tsconfig.tsbuildinfo'), 'liveCachePinnedBeforeAfter': True,
        'nodeCompileCacheDisabled': True,
        'explanation': 'Incremental noEmit can write tsbuildinfo. A fresh /tmp destination is the explicitly allowed caching-only override; the original config and live cache remain unchanged.'},
    'scopePreservation': {'configPath': str(R / 'tsconfig.json'), 'configSelection': 'Implicit original tsconfig.json from unchanged repository cwd',
        'include': config['include'], 'exclude': config['exclude'], 'configuredRootsObserved': len(expected),
        'generatedTypesRegenerated': False, 'newStubs': False, 'narrowedFileList': False,
        'tsconfigRewritten': False, 'nextEnvRewritten': False,
        'compilerOptionOverrides': {'noEmit': True, 'tsBuildInfoFile': str(B / 'run/full-project.tsbuildinfo')},
        'generatedDevTypesCurrentlyAbsent': True,
        'postRunProof': 'Fresh tsbuildinfo root IDs must resolve to exactly the 361 unchanged configured roots; missing cache or a mismatch prevents a passed claim.'},
    'maximumAttempts': 1, 'automaticRetry': False, 'parallelExecutionAllowed': False,
    'heavySlotExclusiveGrantRequired': True, 'sourceMutationsAuthorized': False,
    'regenerateTypes': False, 'installsAuthorized': False, 'resourceEscalationAuthorized': False,
    'allowedWrites': [str(B / 'run') + '/**'],
    'coreDumpsDisabledInChild': True,
    'successCriteria': ['Compiler exits 0', 'All pinned inputs and configured root metadata unchanged',
                        'Fresh tsbuildinfo validates identical root scope', 'No wrapper watchdog intervention'],
    'claimLimits': ['Cold full-project tsc check, not literal package script and not next build',
                    'Existing skipLibCheck and every other configured checker option are preserved',
                    'All earlier OOM evidence is retained',
                    'Earlier isolated strict 18-source check and nine Audi scoped checks do not satisfy this gate'],
    'approvedFinalDataContext': {'catalogueVersions': 427, 'tierOneVersions': 350, 'onSaleVersions': 309, 'packets': 25},
    'preparationVerification': 'Python AST syntax validation only; no wrapper or compiler executed',
}
write('manifest.json', manifest)
manifest_sha = sha(B / 'manifest.json')
write('root-grant-template.json', {'status': 'TEMPLATE_NOT_A_GRANT',
    'manifest': {'path': str(B / 'manifest.json'), 'sha256': manifest_sha}, 'wrapper': manifest['wrapper'],
    'reviewerReadinessConfirmed': False,
    'reviewerAcceptance': {'path': 'REPLACE_WITH_REVIEWER_ACCEPTANCE_PATH', 'bytes': 0, 'sha256': 'REPLACE'},
    'heavySlotExclusive': True, 'automaticRetry': False, 'parallelExecutionAllowed': False,
    'maximumAttempts': 1, 'coldCacheRelocationApproved': True,
    'instruction': 'Root must confirm exact reviewer readiness and write a separate root_execution_granted receipt before any run. This template authorizes nothing.'})
print(json.dumps({'manifest': pin(B / 'manifest.json'), 'wrapper': pin(B / 'run.py'),
                  'inputPinCount': len(paths), 'configuredRootCount': len(expected),
                  'node': node, 'python': python, 'notExecuted': True}, indent=2))
