"""One approved cold full-project TypeScript attempt; no retry or scope changes."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import resource
import signal
import subprocess
import sys
import time

BASE = Path('/tmp/audi-packet/full-project-typescript-v1')

def now():
    return datetime.now(timezone.utc).isoformat()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        while b := f.read(1024 * 1024):
            h.update(b)
    return h.hexdigest()

def check(pin):
    p = Path(pin['path'])
    assert p.is_file() and p.stat().st_size == pin['bytes'] and sha(p) == pin['sha256'], str(p)
    if 'realpath' in pin:
        assert str(p.resolve()) == pin['realpath'], str(p)

def meta(path):
    p = Path(path)
    if not p.exists():
        return {'path': str(p), 'exists': False}
    s = p.stat()
    return {'path': str(p), 'exists': True, 'realpath': str(p.resolve()),
            'bytes': s.st_size, 'mtimeNs': s.st_mtime_ns, 'mode': s.st_mode,
            'isDirectory': p.is_dir(), 'isSymlink': p.is_symlink()}

def roots(repo, patterns):
    return sorted({str(p.resolve()) for pattern in patterns for p in repo.glob(pattern) if p.is_file()})

assert len(sys.argv) == 5, 'run.py MANIFEST MANIFEST_SHA256 ROOT_GRANT ROOT_GRANT_SHA256'
mp, mh, gp, gh = sys.argv[1:]
assert Path(mp) == BASE / 'manifest.json' and sha(mp) == mh and sha(gp) == gh
m, g = (json.loads(Path(p).read_text()) for p in (mp, gp))
assert m['status'] == 'prepared_not_executed_requires_exact_review_and_root_grant'
assert g['status'] == 'root_execution_granted'
assert g['manifest'] == {'path': mp, 'sha256': mh}
assert g['wrapper'] == m['wrapper']
assert g['heavySlotExclusive'] is True and g['automaticRetry'] is False
assert g['parallelExecutionAllowed'] is False and g['maximumAttempts'] == 1
assert g['coldCacheRelocationApproved'] is True
assert g['reviewerReadinessConfirmed'] is True
check(g['reviewerAcceptance'])
assert Path(__file__).resolve() == Path(m['wrapper']['path']).resolve()
assert m['timeoutSeconds'] == 900 and m['killAfterSeconds'] == 10
assert m['maximumAttempts'] == 1 and m['automaticRetry'] is False
assert m['sourceMutationsAuthorized'] is False and m['regenerateTypes'] is False
assert m['environmentOverrides'] == {'NODE_DISABLE_COMPILE_CACHE': '1'}
assert m['command'][1:3] == ['--max-old-space-size=768', '--max-semi-space-size=1']
assert m['command'][4:] == ['--noEmit', '--tsBuildInfoFile', str(BASE / 'run' / 'full-project.tsbuildinfo')]
check(m['inputPins'])
check(m['projectRootMetadata'])
pins = json.loads(Path(m['inputPins']['path']).read_text())
scope = json.loads(Path(m['projectRootMetadata']['path']).read_text())
repo = Path(m['cwd'])
assert repo == Path('/workspace/scratch/586427eef9f2/roadmark-104')

def check_inputs():
    assert sha(mp) == mh and sha(gp) == gh
    for p in [m['wrapper'], m['inputPins'], m['projectRootMetadata'], g['reviewerAcceptance'], *pins]:
        check(p)
    config = json.loads((repo / 'tsconfig.json').read_text())
    assert config == m['originalConfig']
    assert roots(repo, config['include']) == scope['configuredRootFilePaths']
    for expected in scope['fileMetadata'] + scope['directoryState'] + m['runtimeMetadata']:
        assert meta(expected['path']) == expected, expected['path']

check_inputs()
out = BASE / 'run'
out.mkdir(exist_ok=False)  # A used attempt directory is never reused or removed.

def write(name, value):
    with (out / name).open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())

env = os.environ.copy()
for key in m['environmentRemovals']:
    env.pop(key, None)
env.update(m['environmentOverrides'])
command = ['/usr/bin/timeout', '--signal=TERM', '--kill-after=10s', '900s', *m['command']]
write('invocation.json', {'at': now(), 'manifestSha256': mh, 'rootGrantSha256': gh,
                        'command': m['command'], 'supervisedCommand': command, 'cwd': str(repo),
                        'environmentRemovals': m['environmentRemovals'],
                        'environmentOverrides': m['environmentOverrides'],
                        'beforePinsPassed': True, 'coldFullProjectAttempt': True,
                        'literalPackageScript': False, 'automaticRetry': False,
                        'scopeOverride': None, 'cacheDestinationOverride': m['command'][-1]})

def child_setup():
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))  # Avoid repository core dumps on V8 OOM.

start = time.monotonic()
with (out / 'stdout.log').open('x') as so, (out / 'stderr.log').open('x') as se:
    try:
        p = subprocess.Popen(command, cwd=repo, env=env, stdout=so, stderr=se,
                             start_new_session=True, preexec_fn=child_setup)
    except Exception as error:
        write('setup-failure.json', {'at': now(), 'error': repr(error), 'processStarted': False,
                                   'automaticRetry': False})
        raise
    write('started.json', {'at': now(), 'pid': p.pid, 'processGroup': os.getpgid(p.pid)})
    watchdog_fired = False
    try:
        while True:
            pid, status, usage = os.wait4(p.pid, os.WNOHANG)
            if pid:
                break
            if time.monotonic() - start > 920:
                watchdog_fired = True
                os.killpg(p.pid, signal.SIGKILL)
                _, status, usage = os.wait4(p.pid, 0)
                break
            time.sleep(0.25)
    except BaseException:
        try:
            os.killpg(p.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        try:
            os.wait4(p.pid, 0)
        except ChildProcessError:
            pass
        raise
    code = os.waitstatus_to_exitcode(status)
    p.returncode = code
    so.flush()
    se.flush()
    os.fsync(so.fileno())
    os.fsync(se.fileno())
terminal = {'at': now(), 'exitCode': code, 'rawWaitStatus': status,
            'elapsedSeconds': time.monotonic() - start, 'maxRssKiB': usage.ru_maxrss,
            'userSeconds': usage.ru_utime, 'systemSeconds': usage.ru_stime,
            'resourceSource': 'os.wait4', 'watchdogFired': watchdog_fired,
            'timeoutExitCodeObserved': code == 124,
            'resourceNote': 'wait4 max RSS is not summed simultaneous process-tree memory; V8 limits are not an OS RSS cap',
            'stdoutSha256': sha(out / 'stdout.log'), 'stderrSha256': sha(out / 'stderr.log'),
            'automaticRetry': False}
write('terminal.json', terminal)
pins_ok = False
try:
    check_inputs()
    pins_ok = True
    write('after-pins.json', {'at': now(), 'passed': True, 'liveCacheUnchanged': True,
                              'configuredRootsUnchanged': True, 'inputPinCount': len(pins)})
except Exception as error:
    write('after-pins.json', {'at': now(), 'passed': False, 'error': repr(error)})
cache = out / 'full-project.tsbuildinfo'
scope_ok = False
try:
    assert cache.is_file() and cache.stat().st_size < 16 * 1024 * 1024
    b = json.loads(cache.read_text())
    assert b['version'] == m['installedVersions']['typescript']
    ids = []
    for entry in b['root']:
        ids.extend(range(entry[0], entry[1] + 1) if isinstance(entry, list) else [entry])
    actual = sorted({str((cache.parent / b['fileNames'][i - 1]).resolve()) for i in ids})
    expected = scope['configuredRootFilePaths']
    scope_ok = actual == expected
    write('scope-verification.json', {'at': now(), 'passed': scope_ok,
          'method': 'Root IDs from fresh installed TypeScript tsbuildinfo, compared with unchanged configured-glob root inventory',
          'expectedRootCount': len(expected), 'actualRootCount': len(actual),
          'missingRoots': sorted(set(expected) - set(actual)),
          'unexpectedRoots': sorted(set(actual) - set(expected)),
          'cacheSha256': sha(cache), 'cacheBytes': cache.stat().st_size,
          'includesUnchanged': m['originalConfig']['include'],
          'excludesUnchanged': m['originalConfig']['exclude']})
except Exception as error:
    write('scope-verification.json', {'at': now(), 'passed': False, 'error': repr(error),
                                     'note': 'No fallback, regeneration, narrower check, or retry is authorized'})
passed = code == 0 and pins_ok and scope_ok and not watchdog_fired
write('result.json', {'at': now(), 'passed': passed, 'exitCode': code,
      'manifestSha256': mh, 'rootGrantSha256': gh, 'pinsPassed': pins_ok,
      'scopePassed': scope_ok, 'coldFullProjectAttempt': True,
      'fullProjectTypecheckPassed': passed, 'nextBuildClaim': False,
      'automaticRetry': False, 'furtherAttemptRequiresNewApproval': True})
print(json.dumps(terminal))
print(json.dumps({'passed': passed, 'pinsPassed': pins_ok, 'scopePassed': scope_ok}))
sys.exit(0 if passed else 1)
