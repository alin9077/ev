# Cold full-project TypeScript proposal

Prepared only. The compiler and run wrapper have not been executed. This is a separately gated attempt, requiring the reviewer’s readiness for this exact manifest and a separate root grant. The template is not permission to run.

## Exact command and scope

Working directory: `/workspace/scratch/586427eef9f2/roadmark-104`

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node \
  --max-old-space-size=768 --max-semi-space-size=1 \
  /workspace/scratch/586427eef9f2/roadmark-104/node_modules/typescript/bin/tsc \
  --noEmit \
  --tsBuildInfoFile /tmp/audi-packet/full-project-typescript-v1/run/full-project.tsbuildinfo
```

The wrapper uses GNU timeout with a 900-second TERM timeout and 10-second kill grace, gathers terminal wait4 status/resource usage, and preserves stdout/stderr. A 920-second wrapper watchdog only terminates a malfunctioning supervisor. One attempt; no automatic retry, installation, resource escalation, source edits, root exclusions, regeneration, or stubs.

The original tsconfig is used from the original repository directory. All existing options remain intact. Includes remain `next-env.d.ts`, `src/**/*.ts`, `src/**/*.tsx`, `tests/**/*.ts`, `scripts/**/*.ts`, `.next/types/**/*.ts`, `.next/dev/types/**/*.ts`; the sole exclusion remains `node_modules`.

Observed configured roots: 361 total (1 next-env, 117 src TS, 54 src TSX, 168 tests, 17 scripts, 4 generated). The absent `.next/dev/types` directory is recorded, not regenerated or excluded. `next-env.d.ts` and its imports of generated routes/root-params are unchanged. Normal dependency and transitive type/import resolution is preserved.

This is a cold full-project attempt, not the literal package script: the allowed caching-only option redirects incremental state to a new `/tmp` cache. The original live `tsconfig.tsbuildinfo` is pinned before and after and is not used or overwritten. Node's separate bytecode compile cache is disabled, and child core dumps are disabled to avoid unintended files. The unique run directory prevents another execution using the same proposal.

## Evidence and limits

- `manifest.json`: exact command, config, boundaries, pins, and acceptance requirements
- `input-pins.json`: 31 explicitly named content pins, including original config/cache, package/lock files, actual installed compiler, package versions, four generated declarations/validator files, relevant Next guides, and timeout
- `project-root-metadata.json`: configured filename/stat inventory only; no full-project source contents were recaptured or supplied to the compiler as a narrowed file list
- `prior-attempts.json`: retained exact earlier 512/640 MiB terminal and command references, including explicit V8 OOM stderr; 10.18/18.24 seconds and 626,068/746,540 KiB wait4 max RSS
- `root-grant-template.json`: incomplete, non-executable approval template

The fresh tsbuildinfo must demonstrate that the installed compiler used all 361 original configured roots. An absent cache, different root list, changed pin/metadata, nonzero compiler status, or watchdog intervention prevents a passed claim. Metadata observations are not an exhaustive content freeze of the transitive project/dependency closure.

V8 old-space and semi-space flags do not cap process RSS. The root's approximately 2 GiB available-memory observation and absence of a shell memory limit do not establish reserved capacity or guarantee success. The root selected 900 seconds plus 10 seconds, matching the earlier approved timeout; it is a limit, not a runtime forecast.

Earlier isolated strict 18-source success and nine Audi scoped passes remain distinct from this open gate. Final data context remains 427 catalogue / 350 tier-one / 309 on-sale versions and 25 packets. This proposal makes no next-build or full test-suite claim.

## Run only after exact approval

The root must write a separate grant, including the exact manifest hash, exact wrapper pin, an independently accepted reviewer receipt pin, exclusive heavy-slot confirmation, and the caching-only override approval. Then invoke:

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 \
  /tmp/audi-packet/full-project-typescript-v1/run.py \
  /tmp/audi-packet/full-project-typescript-v1/manifest.json \
  fbd950fb58956b8bec155433defa1cc7409d1d5f5fad70d6c09b6ddd5c7370ce \
  EXACT_ROOT_GRANT_PATH EXACT_ROOT_GRANT_SHA256
```

The wrapper must not be invoked with the template. No run directory exists at preparation completion.
