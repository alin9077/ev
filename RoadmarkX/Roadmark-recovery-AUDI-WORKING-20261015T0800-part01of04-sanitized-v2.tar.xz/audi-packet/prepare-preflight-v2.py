import json,hashlib
from pathlib import Path
old=Path('/tmp/audi-packet/selected-preflight-v1');out=Path('/tmp/audi-packet/selected-preflight-v2');out.mkdir(exist_ok=True)
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def save(p,d):Path(p).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
s=(old/'check.mjs').read_text().replace(str(old),str(out))
s=s.replace("const optionalFields=['buyerGrade','gradeReview','gradeReviewStatus','condition_label','confirmation_needed']","const optionalFields=['validUntil','buyerGrade','gradeReview','gradeReviewStatus','condition_label','usability_notes','confirmation_needed']")
s=s.replace("else if(property==='confirmation_needed'){assert.equal(feature.criterion,'novated_fbt');producer=", "else if(property==='confirmation_needed'){assert.equal(feature.criterion,'novated_fbt');if(retained){assert(sourceRow&&regradedRow);for(const row of [sourceRow,regradedRow]){const d=Object.getOwnPropertyDescriptor(row,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);}}producer=")
s=s.replace('let earnedCells=0,featureClaims=0;','let earnedCells=0,featureClaims=0,priceFeatureRefreshes=0;')
s=s.replace("if(feature.criterion==='driveaway_price'){assert.equal(feature.value,'A$'+car.facts.price_aud.value.toLocaleString('en-AU'));assert.deepEqual(feature.source_ids,car.facts.price_aud.sourceIds);assert.equal(feature.buyerGrade,car.facts.price_aud.buyerGrade);continue;}","""if(feature.criterion==='driveaway_price'){const f=car.facts.price_aud;if(f.comparisonBasis==='Driveaway'){assert.equal(feature.value,'A$'+f.value.toLocaleString('en-AU'));assert.deepEqual(feature.source_ids,f.sourceIds);assert.equal(feature.buyerGrade,f.buyerGrade);assert.equal(feature.verification_state,'reviewed_canonical_driveaway_price');priceFeatureRefreshes++;}else{assert.equal(f.comparisonBasis,'Before on-road costs');assert(!prior,'All non-Driveaway proposals are newly generated MY27 rows');const raw=data.feature_evidence.find(x=>x.variant_id===car.id&&x.criterion==='driveaway_price');assert(raw);assert.equal(feature.value,raw.value);assert.equal(feature.status,'not_verified');assert.deepEqual(feature.source_ids,[]);assert.equal(feature.buyerGrade,undefined);assert.equal(feature.gradeReview,undefined);assert.equal(feature.verification_state,'unverified');assert.deepEqual(feature,final.sourceEffectiveFeatures(car,data).find(x=>x.criterion==='driveaway_price'));}continue;}""")
s=s.replace('assert.equal(earnedCells,339);','assert.equal(priceFeatureRefreshes,9);assert.equal(earnedCells,339);').replace('explicitPriceFeatureRefreshes:17','explicitDriveawayFeatureRefreshes:priceFeatureRefreshes,nonDriveawayFeaturesUnverified:8')
(out/'check.mjs').write_text(s)
(out/'expected-review.json').write_bytes((old/'expected-review.json').read_bytes())
pins=json.loads((old/'source-pins.json').read_text());pins=[pin(x['path'].replace(str(old),str(out))) for x in pins];save(out/'source-pins.json',pins)
m=json.loads((old/'prepared-command.json').read_text());m['script']=pin(out/'check.mjs');m['sourcePins']=pin(out/'source-pins.json');m['command']=[x.replace(str(old),str(out)) for x in m['command']];m['scope']=m['scope'].replace('all 1173 affected feature claims','all 1173 affected feature claims, nine canonical Driveaway feature projections and eight unchanged unverified non-Driveaway rows').replace('raw generated rows','all seven typed optional fields on raw generated rows')
w=(old/'run.py').read_text().replace(json.loads((old/'prepared-command.json').read_text())['script']['sha256'],m['script']['sha256']);(out/'run.py').write_text(w);m['wrapper']=pin(out/'run.py');save(out/'prepared-command.json',m)
print(json.dumps(dict(manifest=pin(out/'prepared-command.json'),script=pin(out/'check.mjs'),executed=False),indent=2))
