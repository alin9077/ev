from pathlib import Path
from datetime import datetime, timezone
import json,hashlib,sys
B=Path('/tmp/audi-packet/status-transition-v1');EXPECTED='af280735b02caa7647a549b050d06161f09a645008182e427d2078fee5aa1843'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def check(v):
 p=Path(v['path']);assert p.stat().st_size==v['bytes'] and sha(p)==v['sha256'],str(p)
assert len(sys.argv)==2 and sys.argv[1]==EXPECTED and sha(B/'manifest.json')==EXPECTED
m=json.loads((B/'manifest.json').read_text());assert m['target']=='/workspace/scratch/586427eef9f2/roadmark-104-qa/work-status.json'
for v in [m['before'],m['beforeCopy'],m['after'],*m['acceptedEvidence'],*m['currentDocumentPins']]:check(v)
b=json.loads(Path(m['beforeCopy']['path']).read_text());a=json.loads(Path(m['after']['path']).read_text())
changed=set(m['changedExistingFields']);new=set(m['newFields']);assert set(a)==set(b)|new
assert all(a[k]==v for k,v in b.items() if k not in changed and k!='workStatusHistory')
assert a['workStatusHistory'][:-1]==b['workStatusHistory'] and len(a['workStatusHistory'])==len(b['workStatusHistory'])+1
assert a['workStatusHistory'][-1]['previous']=={k:b[k] for k in changed}
out=B/'application';out.mkdir(exist_ok=False);p=Path(m['target']);check(m['before']);p.write_bytes(Path(m['after']['path']).read_bytes());assert sha(p)==m['after']['sha256']
r={'status':'applied_exact_qa_status_transition','at':datetime.now(timezone.utc).isoformat(),'manifestSha256':EXPECTED,'before':m['before'],'after':pin(p),'completePriorStatePreserved':True,'historicalFieldsUnchanged':True,'historyAppendCount':1,'applicationScript':pin(Path(__file__)),'automaticRetry':False}
q=out/'result.json';q.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(pin(q)))
