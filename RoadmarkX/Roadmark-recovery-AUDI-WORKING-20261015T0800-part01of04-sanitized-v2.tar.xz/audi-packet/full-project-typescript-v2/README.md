# Cold full-project TypeScript v2 proposal

Prepared only. No v2 wrapper or compiler execution has occurred; the v2 run directory does not exist.

This is one separately authorized recheck after the accepted one-line `<string[]>` type argument in `tests/evidence-consumers.test.ts`. It is not an automatic retry. V1 and all its records are unchanged.

## Exact scope

Same repository, installed compiler, original tsconfig/options, 361 configured root names, generated roots, and 768 MiB old-space / 1 MiB semi-space as v1. The only command difference is the fresh cache destination:

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node \
  --max-old-space-size=768 --max-semi-space-size=1 \
  /workspace/scratch/586427eef9f2/roadmark-104/node_modules/typescript/bin/tsc \
  --noEmit \
  --tsBuildInfoFile /tmp/audi-packet/full-project-typescript-v2/run/full-project.tsbuildinfo
```

Working directory: `/workspace/scratch/586427eef9f2/roadmark-104`.

Supervision remains 900 seconds, TERM then 10 seconds kill grace, wait4 resource/status capture, and a 920-second emergency supervisor watchdog. The original live incremental cache and generated roots remain pinned before/after. No installs, generation, exclusions, stubs, source writes, retry, or resource escalation.

The original 31 content pins were verified unchanged and reused. One explicit corrected-test content pin was added. The configured-root metadata changes only that test's byte count and modification time. `metadata-delta.json` records the exact difference and accepted correction receipt. All 361 configured root names and directory states are identical.

## Evidence and gating

V1 completed with exit 2 and the single TS2345 diagnostic in 27.290299 seconds at 871,712 KiB wait4 max RSS. Its input/cache checks and all 361 root IDs passed. This was not OOM. `prior-attempts.json` retains the earlier 512/640 MiB OOMs and appends v1 with its correct classification and exact receipt pins.

Before execution, the root grant must confirm focused correction tests and changed-file lint have passed and the reviewer accepts that evidence and this exact v2 proposal. In addition to the standard grant fields, the wrapper requires:

- `focusedCorrectionChecksAccepted: true`
- `focusedCorrectionVerification`: the pinned reviewer acceptance receipt covering focused tests and lint

`root-grant-template.json` is deliberately incomplete and grants nothing. The reviewer receipt and root grant must be separately supplied. No new approval roundtrip is implied once the root's existing conditional grant has its conditions satisfied.

Manifest SHA-256: `40134fe13618503f5130287e44580e6cc31d4e799ebb0570dfd5c7d6650f6b45`

Wrapper SHA-256: `a67704871bbf029c1035005e3fb6ede649f15942bf27be807d001b764733139b`

After approval, the invocation is the same four-argument wrapper contract: manifest path, manifest SHA-256, exact root-grant path, exact root-grant SHA-256. A used v2 run directory cannot be reused. Full-project success requires exit 0, unchanged pins/metadata, all 361 fresh cache root IDs, and no watchdog event.
