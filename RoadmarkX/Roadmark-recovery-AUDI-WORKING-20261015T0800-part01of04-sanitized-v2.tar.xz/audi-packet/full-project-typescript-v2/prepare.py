"""Prepare v2 by reusing v1 evidence; no TypeScript or test execution."""
from pathlib import Path
from datetime import datetime, timezone
import ast, copy, hashlib, json
B=Path('/tmp/audi-packet/full-project-typescript-v2')
V=Path('/tmp/audi-packet/full-project-typescript-v1')
C=Path('/tmp/audi-packet/fixture-typescript-correction-v1')

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while d:=f.read(1024*1024):h.update(d)
 return h.hexdigest()
def pin(p):
 p=Path(p);return {'path':str(p),'realpath':str(p.resolve()),'bytes':p.stat().st_size,'sha256':sha(p)}
def meta(p):
 p=Path(p)
 if not p.exists():return {'path':str(p),'exists':False}
 s=p.stat();return {'path':str(p),'exists':True,'realpath':str(p.resolve()),'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'mode':s.st_mode,'isDirectory':p.is_dir(),'isSymlink':p.is_symlink()}
def write(n,v):
 with (B/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')

m=json.loads((V/'manifest.json').read_text())
assert sha(V/'manifest.json')=='fbd950fb58956b8bec155433defa1cc7409d1d5f5fad70d6c09b6ddd5c7370ce'
app=json.loads((C/'application-result.json').read_text())
assert app['status']=='applied_exact_one_line_type_argument'
assert app['manifestSha256']=='b606b54c52925e0e138847a5dde232efafbe89af346880a2d3fcde5c009f133d'
assert sha(C/'manifest.json')==app['manifestSha256']
target=Path(app['target'])
assert sha(target)==app['afterSha256']=='49536d663c4b3efe2c32b16fdfde72bb96a3a831c6917b8263a82af39100fbf5'
scope=json.loads((V/'project-root-metadata.json').read_text())
changed=[]
for i,old in enumerate(scope['fileMetadata']):
 actual=meta(old['path'])
 if actual!=old:
  assert old['path']==str(target)
  assert {k for k in old if old[k]!=actual[k]}=={'bytes','mtimeNs'}
  changed.append({'before':old,'after':actual})
  scope['fileMetadata'][i]=actual
assert len(changed)==1
for old in scope['directoryState']:
 assert meta(old['path'])==old,old['path']
write('project-root-metadata.json',scope)
pins=json.loads((V/'input-pins.json').read_text())
for p in pins:assert pin(p['path'])==p,p['path']
assert len(pins)==31
pins.append(pin(target))
write('input-pins.json',pins)
write('metadata-delta.json',{'previousManifest':pin(V/'manifest.json'),'rootFileNamesUnchanged':True,
 'configuredRootCount':361,'onlyMetadataChanges':changed,'newExplicitContentPin':pin(target),
 'correctionManifest':pin(C/'manifest.json'),'correctionApplication':pin(C/'application-result.json')})
prior=json.loads((V/'prior-attempts.json').read_text())
t=json.loads((V/'run/terminal.json').read_text());r=json.loads((V/'run/result.json').read_text())
assert t['exitCode']==2 and r['pinsPassed'] is True and r['scopePassed'] is True
assert not (V/'run/stderr.log').read_text()
diag=(V/'run/stdout.log').read_text()
assert diag=='''tests/evidence-consumers.test.ts(247,29): error TS2345: Argument of type '"packet"' is not assignable to parameter of type 'never'.\n'''
prior.append({'command':m['command'],'nodeOptions':None,'nodeFlags':m['command'][1:3],
 'timeoutSeconds':900,'elapsedSeconds':t['elapsedSeconds'],'exitCode':2,'maxRssKiB':t['maxRssKiB'],
 'stderrHasExplicitV8HeapOom':False,'classification':'Completed with one TypeScript diagnostic, not OOM',
 'diagnostic':diag.strip(),'pinsPassed':True,'scopePassed':True,'configuredRootCount':361,
 'retainedEvidence':[pin(V/n) for n in ['manifest.json','run/invocation.json','run/terminal.json',
 'run/result.json','run/after-pins.json','run/scope-verification.json','run/stdout.log','run/stderr.log']]})
write('prior-attempts.json',prior)
wrapper=(V/'run.py').read_text().replace(str(V),str(B))
wrapper=wrapper.replace("assert g['reviewerReadinessConfirmed'] is True\n", "assert g['reviewerReadinessConfirmed'] is True\nassert g['focusedCorrectionChecksAccepted'] is True\ncheck(g['focusedCorrectionVerification'])\n")
wrapper=wrapper.replace("m['projectRootMetadata'], g['reviewerAcceptance'], *pins]", "m['projectRootMetadata'], g['reviewerAcceptance'], g['focusedCorrectionVerification'], *pins]")
ast.parse(wrapper)
(B/'run.py').write_text(wrapper)
m['id']='audi-cold-full-project-typescript-768-v2'
m['preparedAt']=datetime.now(timezone.utc).isoformat()
m['command'][-1]=str(B/'run/full-project.tsbuildinfo')
m['wrapper']=pin(B/'run.py');m['preparer']=pin(B/'prepare.py')
for k,n in [('inputPins','input-pins.json'),('projectRootMetadata','project-root-metadata.json'),('priorAttempts','prior-attempts.json')]:m[k]=pin(B/n)
m['metadataDelta']=pin(B/'metadata-delta.json')
m['cacheHandling']['newCachePath']=str(B/'run/full-project.tsbuildinfo')
m['scopePreservation']['compilerOptionOverrides']['tsBuildInfoFile']=str(B/'run/full-project.tsbuildinfo')
m['allowedWrites']=[str(B/'run')+'/**']
m['timeoutRationale']='The separately authorized v2 retains the root-selected 900-second timeout plus 10-second grace. V1 completed with TS2345 in 27.29 seconds at 871,712 KiB wait4 max RSS; this does not guarantee v2 success. The original 512/640 MiB OOMs remain retained. The 920-second watchdog only terminates a malfunctioning supervisor.'
m['separateRecheckAuthorization']={'automaticRetry':False,'previousAttempt':pin(V/'manifest.json'),
 'previousResult':pin(V/'run/result.json'),'newAttemptReason':'Exact accepted one-line <string[]> type argument fixes v1 diagnostic in tests/evidence-consumers.test.ts',
 'fixtureCorrectionManifest':pin(C/'manifest.json'),'fixtureCorrectionApplication':pin(C/'application-result.json'),
 'fixtureAfterPin':pin(target),'executionConditions':['Focused correction tests pass','Changed-file lint passes','Reviewer accepts focused test/lint evidence and exact v2 proposal','Root grant confirms these conditions and exclusive heavy slot'],
 'reviewerGateRequiredInGrant':'focusedCorrectionChecksAccepted=true plus pinned focusedCorrectionVerification receipt'}
write('manifest.json',m)
g=json.loads((V/'root-grant-template.json').read_text())
g['manifest']={'path':str(B/'manifest.json'),'sha256':sha(B/'manifest.json')};g['wrapper']=m['wrapper']
g['focusedCorrectionChecksAccepted']=False
g['focusedCorrectionVerification']={'path':'REPLACE_WITH_REVIEWER_FOCUSED_TESTS_AND_LINT_ACCEPTANCE_PATH','bytes':0,'sha256':'REPLACE'}
g['instruction']='Root must confirm independently accepted focused correction tests/lint and exact v2 reviewer readiness before writing a separate root_execution_granted receipt. This template is not a grant.'
write('root-grant-template.json',g)
assert not (B/'run').exists()
print(json.dumps({'manifest':pin(B/'manifest.json'),'wrapper':pin(B/'run.py'),
 'inputPinCount':len(pins),'configuredRootCount':len(scope['configuredRootFilePaths']),
 'v1Preserved':True,'wrapperNotExecuted':True},indent=2))
