"""Preparation only: reads nominated metadata, writes this proposal, runs no product code."""
from pathlib import Path
import hashlib
import json

base = Path('/tmp/audi-packet/post-registration-checks-v1')
repo = Path('/workspace/scratch/586427eef9f2/roadmark-104')
qa = Path('/workspace/scratch/586427eef9f2/roadmark-104-qa/audi-sequential-checks')
static = Path('/tmp/audi-split-static-checks-v2')
fullstage = Path('/tmp/audi-packet/full-stage-v1/manifest.json')
core = Path('/tmp/audi-registration-bundle/core-manifest.json')

def read(path):
    return json.loads(Path(path).read_text())

def write(name, value):
    (base / name).write_text(json.dumps(value, indent=2) + '\n')

def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

old = read(static / 'import-closure.json')
fixture = '/tmp/audi-split-static-checks/fixture/'
proposal = '/tmp/audi-split-proposal/'
def installed(path):
    if path.startswith(proposal):
        return str(repo / path[len(proposal):])
    if path.startswith(fixture):
        return str(repo / path[len(fixture):])
    return path

sources = sorted(installed(item['fixture']) for item in old['sourceCopies'] if '/baseline/' not in item['fixture'])
assert len(sources) == 18 and len(set(sources)) == 18
edges = [dict(source=installed(item['source']), specifier=item['specifier'], target=installed(item['target']))
         for item in old['edges'] if '/baseline/' not in item['source'] and '/baseline/' not in item['target']]
scope = dict(
    status='proposal_pending_final_registration_and_test_freeze',
    derivation='Nominated 19-source proposal closure mapped to actual repository paths, removing duplicate baseline helper and its edges. Adapted test has same remaining imports. Compiler --listFiles must independently prove exact installed scope after approval.',
    sourceRootCount=2, physicalProjectSourceCount=18, fullProjectCompile=False,
    compilerRoots=[str(repo / 'scripts/reporting/m1-reconciliation.ts'), str(repo / 'tests/m1-inventory-split.test.ts')],
    expectedProjectFiles=sources,
    lintTargets=[str(repo / name) for name in ('scripts/reporting/m1-reconciliation.ts', 'scripts/reporting/load.ts', 'tests/m1-inventory-split.test.ts')],
    allowedDeclarationRoots=read(static / 'scope.json')['allowedDeclarationRoots'],
    duplicateBaselineHelper=False, fakeStubs=False, sourceCopies=False,
    actualInstalledDependencyClosure=True, dependencyTreeScan=False,
    priorClosure=pin(static / 'import-closure.json'), priorSourcePins=pin(static / 'source-pins.json'),
    edges=edges,
)
write('scope.json', scope)
options = read('/tmp/audi-split-static-checks/fixture/tsconfig.json')['compilerOptions']
options['rootDir'] = str(repo)
options['typeRoots'] = [str(repo / 'node_modules/@types')]
write('tsconfig.installed.json', dict(compilerOptions=options, files=scope['compilerRoots'], include=[]))

# Reuse nominated digests without re-reading/hashing canonical data or dependency trees.
pins = {p['path']:dict(p) for p in read(fullstage)['pins'] if p['path'].startswith(str(repo) + '/')}
for p in read(static / 'source-pins.json'):
    if p['path'] in [str(repo / name) for name in ('package.json','pnpm-lock.yaml','eslint.config.mjs')]:
        pins[p['path']] = dict(p)
prior = read('/tmp/skoda-packet/post-registration-checks-v1/structural-validation.json')
needed = ['scripts/generate-market-view.mjs', 'scripts/validate.ts', 'scripts/report-coverage.ts',
          'tests/brand-updates.test.ts', 'tests/price-ladder.test.ts', 'tests/market-review-reconciliation.test.ts',
          'tests/m1-coverage-tracking.test.ts', 'tests/coverage-reports.test.ts', 'tests/c1-order-eligibility.test.ts',
          'tests/availability-ranking.test.ts', 'tests/search.test.ts', 'tests/brand-live-safety.test.ts']
oldpins = {p['path']:p for p in prior['pins']}
for name in needed:
    path = str(repo / name)
    pins[path] = dict(oldpins[path])
for target in read(core)['targets']:
    pins[target['target']] = dict(target['after'], path=target['target'])
write('source-pins.provisional.json', sorted(pins.values(), key=lambda p:p['path']))
write('pin-provenance.json', dict(
    status='metadata_only_no_broad_source_or_dependency_rehash',
    sourceClosure=pin(fullstage), formerCompileSourcePins=pin(static / 'source-pins.json'),
    priorEntryAndTestPins=pin('/tmp/skoda-packet/post-registration-checks-v1/structural-validation.json'),
    intendedCoreAfter=pin(core), toolPins=pin(static / 'tool-pins.json'),
    provisionalSourcePinCount=len(pins), pending=['Final registration manifest and test manifest', 'Exact installed test and small fixture intended-after pins', 'Root and reviewer acceptance of final sequence'],
    noTestCandidatePinFrozen=True, runtimeToolchainSweep=False,
    limitations='Nominated source pins and selected installed tool entrypoints/configs/declarations only; not a whole source-tree or node_modules integrity audit.',
))

tools = read(static / 'installed-toolchain.json')
node = tools['nodeExecutable']
python = tools['pythonExecutable']
priorCompile = read(static / 'compile/prepared-command.json')
priorLint = read(static / 'lint/prepared-command.json')

def n(mem):
    return [node, f'--max-old-space-size={mem}', '--max-semi-space-size=1']
def tests(mem, names):
    return [*n(mem), '--import', 'tsx', '--test', '--test-reporter=tap', '--test-concurrency=1', *names]

commands = [
    ('market-view-preflight', 'check', 60, 128, [*n(128), 'scripts/generate-market-view.mjs', '--check'], None,
     'Read-only generated market-view consistency preflight; no --write'),
    ('structural-validation', 'validate', 900, 448, [*n(448), '--import', 'tsx', 'scripts/validate.ts'], None,
     'Actual installed structural validator, standalone; no validation shortcut'),
    ('normal-coverage-asof-2026-10-15', 'report', 900, 448, [*n(448), '--import', 'tsx', 'scripts/report-coverage.ts', '--as-of', '2026-10-15', '--json'], None,
     'Fresh normal report using actual registry/load wiring; full report stdout preserved'),
    ('report-parity', 'parity', 30, None, [python, str(base / 'check-report-parity.py')], None,
     'Exact complete JSON deep equality and serialized byte equality against accepted staged-report.json; no ignored paths'),
    ('relevant-behavioral-tests', 'tests', 600, 512, tests(512, needed[3:10]), 105,
     'Seven named existing fixture regression files; count must equal 105 with zero failures/skips/cancellations/todo'),
    ('installed-inventory-split-tests', 'tests', 60, 256, tests(256, ['tests/m1-inventory-split.test.ts']), 78,
     'Actual installed helper plus actual installed new test and small local fixtures; count must equal 78'),
    ('search-isolated-tap', 'tests', 600, 512, tests(512, ['tests/search.test.ts']), 6,
     'Warranted: new live Audi catalogue additions pass through common search/discovery while preserving existing behavior; isolated full-live-data load'),
    ('brand-live-safety-isolated-tap', 'tests', 600, 512, tests(512, ['tests/brand-live-safety.test.ts']), 7,
     'Warranted: appended live brand packet and global loader can affect public catalogue/detail safety; isolated full-live-data load'),
    ('installed-strict-compile', 'compile', 60, 256, [*n(256), priorCompile['command'][3], '--project', str(base / 'tsconfig.installed.json'), '--noEmit', '--pretty', 'false', '--listFiles'], None,
     'Strict actual installed 18-source program, two roots, no emit/incremental/cache; exact --listFiles scope verification required; not full-project tsc'),
    ('changed-file-lint', 'lint', 180, 256, [*n(256), priorLint['command'][3], '--no-config-lookup', '--config', str(repo / 'eslint.config.mjs'), '--no-ignore', '--no-cache', '--concurrency', 'off', '--max-warnings', '0', '--format', 'json', '--', 'scripts/reporting/m1-reconciliation.ts', 'scripts/reporting/load.ts', 'tests/m1-inventory-split.test.ts'], None,
     'Exact three changed TypeScript targets with actual repository ESLint config; JSON verifies exact files and zero warnings/errors'),
]
proposals = []
previous = None
for index, (name, kind, timeout, mem, command, count, rationale) in enumerate(commands, 1):
    value = dict(id=name, kind=kind, sequenceNumber=index, status='proposal_only_waiting_final_freeze',
        repo=str(repo), qaRoot=str(qa), runOutput=str(qa / name),
        command=command, timeoutSeconds=timeout, killAfterSeconds=10, oldSpaceMiB=mem, semiSpaceMiB=1 if mem else None,
        automaticRetry=False, parallelExecutionAllowed=False, sourceMutationsAuthorized=False,
        previousResult=previous, expectedTests=count, rationale=rationale,
        sourcePins=None, registrationManifest=None, testManifest=None,
        wrapper=pin(base / 'run.py'), scope=pin(base / 'scope.json'),
        toolPins=pin(static / 'tool-pins.json') if kind in ('compile','lint') else None,
        extraPins=[pin(base / 'tsconfig.installed.json')] if kind=='compile' else [],
        environmentOverrides=dict(NODE_DISABLE_COMPILE_CACHE='1', FORCE_COLOR='0', ESLINT_USE_FLAT_CONFIG='true'))
    if kind=='parity':
        value['extraPins'] += [pin(base / 'check-report-parity.py'),
            read('/tmp/audi-review/full-stage-v1-result-acceptance.json')['artifacts']['report'],
            pin('/tmp/audi-review/full-stage-v1-result-acceptance.json')]
    proposals.append(value)
    previous = str(qa / name / 'result.json')
write('command-scope-proposal.json', dict(
    schemaVersion=1, status='proposal_only_waiting_final_registration_and_test_freeze',
    repo=str(repo), qaRoot=str(qa), commands=proposals,
    fullProjectClaim=False, wholeMarketC1Claim=False, automaticRetry=False,
    requiredBeforeAnyRun=['Exact final registration/test source freeze', 'Independent reviewer acceptance of frozen sequence/manifests',
                          'Verified exact installation', 'Root grant for each exact manifest and exclusive M1 heavy slot'],
    deliberatelyExcluded=['Full-project compile', 'Full test suite', 'Historical sourceCatalogue/added-detail reruns',
                          'Content audits/scans', 'Dependency scans or installs', 'Build/export/publication', 'Fresh canonical capture'],
))
print(json.dumps(dict(status='proposal_prepared_no_checks_executed', commands=len(commands),
                     installedProjectSources=len(sources), provisionalPins=len(pins))))
