"""Exact comparison only; never imports or hydrates the product."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

base = Path('/workspace/scratch/586427eef9f2/roadmark-104-qa/audi-sequential-checks')
actual = base / 'normal-coverage-asof-2026-10-15/stdout.log'
expected = Path('/tmp/audi-packet/full-stage-v1/output/staged-report.json')
terminal = base / 'normal-coverage-asof-2026-10-15/terminal.json'
result = base / 'normal-coverage-asof-2026-10-15/result.json'

def pin(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

assert json.loads(terminal.read_text())['exitCode'] == 0
assert json.loads(result.read_text())['passed'] is True
assert pin(expected)['sha256'] == '0e971290adb305fd261321df5272b469a84e30f7e759f24efb658ddb9d7c6e1a'
a = json.loads(actual.read_text())
e = json.loads(expected.read_text())
assert a == e, 'Complete JSON mismatch; no fields or paths are ignored'
assert actual.read_bytes() == expected.read_bytes(), 'Complete serialized report bytes differ'
assert [a[key] for key in ('allCatalogueVersions', 'tierOneVersions', 'onSaleVersions')] == [427, 350, 309]
brand = next(item for item in a['brandProgress'] if item['brand'] == 'Audi')
assert brand['onSaleVersions'] == 9 and len(brand['currentVersionReviews']) == 7
assert sum(len(review['versions']) for review in brand['currentVersionReviews']) == 17
assert brand['researchCompleted'] is True and brand['criteria']['C1'] is False
receipt = dict(status='normal_full_report_exact_staged_deep_parity_pass',
    at=datetime.now(timezone.utc).isoformat(), actual=pin(actual), expected=pin(expected), terminal=pin(terminal),
    exactDeepEquality=True, byteEquality=True, ignoredPaths=[],
    allCatalogueVersions=427, tierOneVersions=350, onSaleVersions=309,
    audiOnSaleVersions=9, audiCurrentMakerLists=7, audiCurrentVersions=17, wholeMarketC1=False,
    scope='Exact whole-report comparison against independently accepted staged output; no full-project claim')
with (base / 'normal-report-staged-parity.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps(receipt, indent=2))
