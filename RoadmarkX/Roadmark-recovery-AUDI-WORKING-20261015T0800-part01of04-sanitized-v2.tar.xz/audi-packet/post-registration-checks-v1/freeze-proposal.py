"""Prepare final pinned manifests only. Does not check live installed bytes or run commands."""
from pathlib import Path
import hashlib
import json

base = Path('/tmp/audi-packet/post-registration-checks-v1')
registration = Path('/tmp/audi-registration-bundle/manifest.json')
expected_registration = '920db20ecf5c2377731fad37e1fb5cd5eec9bea6ba3f6caa76851868a865ea22'

def read(path):
    return json.loads(Path(path).read_text())

def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def write(name, value):
    (base / name).write_text(json.dumps(value, indent=2) + '\n')

registration_pin = pin(registration)
assert registration_pin['sha256'] == expected_registration
reg = read(registration)
assert len(reg['targets']) == 13
source = {p['path']:p for p in read(base / 'source-pins.provisional.json')}
for target in reg['targets']:
    source[target['target']] = dict(target['after'], path=target['target'])
for unchanged in reg['unchangedPins']:
    assert source[unchanged['path']] == unchanged
source.pop(str(Path(reg['repo']) / 'tests/search.test.ts'), None)
write('source-pins.json', sorted(source.values(), key=lambda p:p['path']))
installed = {target['relativePath']:target for target in reg['targets']}
assert installed['tests/m1-inventory-split.test.ts']['after']['sha256'] == '23ea8824e35b0e895b0dcb8102ede3795701e667a5ef1bda4361e75d6f24a8b4'
assert len([target for target in reg['targets'] if target['relativePath'].startswith('tests/')]) == 8
scope = read(base / 'scope.json')
scope['status'] = 'frozen_actual_installed_scope_requires_execution_verification'
scope['registrationManifest'] = registration_pin
scope['testFixtureCount'] = 7
scope['testsExpected'] = 78
assert all(path in source for path in scope['expectedProjectFiles'])
assert len(scope['expectedProjectFiles']) == 18
write('scope.json', scope)

proposal = read(base / 'command-scope-proposal.json')
by_id = {item['id']:item for item in proposal['commands']}
order = ['installed-inventory-split-tests', 'installed-strict-compile', 'changed-file-lint',
         'market-view-preflight', 'structural-validation', 'normal-coverage-asof-2026-10-15',
         'report-parity', 'relevant-behavioral-tests', 'brand-live-safety-isolated-tap']
sequence = []
previous = None
for index, name in enumerate(order, 1):
    item = by_id[name]
    item['status'] = 'frozen_not_executed_requires_review_and_root_grant'
    item['sequenceNumber'] = index
    item['previousResult'] = previous
    item['sourcePins'] = pin(base / 'source-pins.json')
    item['registrationManifest'] = registration_pin
    item['testManifest'] = registration_pin
    item['testManifestNote'] = 'Final unified 13-target registration includes the adapted test and all seven small fixtures; no separate mutable test snapshot.'
    item['scope'] = pin(base / 'scope.json')
    item['wrapper'] = pin(base / 'run.py')
    write(name + '.json', item)
    sequence.append(pin(base / (name + '.json')))
    previous = str(Path(proposal['qaRoot']) / name / 'result.json')
final = dict(schemaVersion=1, status='frozen_not_executed_requires_review_and_root_grant',
    repo=proposal['repo'], qaRoot=proposal['qaRoot'], sequence=sequence,
    wrapper=pin(base / 'run.py'), scope=pin(base / 'scope.json'), sourcePins=pin(base / 'source-pins.json'),
    registrationManifest=registration_pin, testManifest=registration_pin,
    rootExecutionGrantRequired=True, independentReviewRequired=True, exactRegistrationVerificationRequired=True,
    automaticRetry=False, parallelExecutionAllowed=False, stopOnFailure=True,
    fullProjectClaim=False, wholeMarketC1Claim=False,
    policy='Separate explicit grants permit one check at a time in this exact order. First tiny installed tests, strict 18-source compile, and three-file lint; then market preflight, actual validation, normal coverage, exact staged parity, existing fixture regression and one isolated live-safety. Root omitted unchanged search, full-detail and historical-source tests. No new dependencies, dependency scan, canonical capture, content audit, full-project tsc, build or publication.',
    testCounts=dict(installedSplit=78, existingFixtureRegression=105, liveSafety=7),
    resources='One supervised process per wrapper; Node test worker concurrency 1; GNU timeout TERM with 10-second KILL grace; os.wait4 usage. Compiler 256/1 MiB 60s, lint 256/1 MiB 180s, installed tests 256/1 MiB 60s; market 128/1 MiB 60s; structural/report 448/1 MiB 900s; existing/live-safety 512/1 MiB 600s.',
    pinPolicy='Reuse nominated source manifest hashes plus exact intended-after installation. No broad canonical row hashing or dependency-tree sweep in preparation. Reuse 53 selected installed TS/ESLint entrypoint/config/declaration pins, not entire node_modules.')
final['omitted'] = [dict(id='search-isolated-tap', reason='Root narrowed final scope: unchanged search omitted absent a concrete new need'), dict(id='full-detail-and-historical-source', reason='Unchanged tests omitted; staged actual selected pack/portable proof already accepted')]
write('sequence.json', final)
write('freeze-receipt.json', dict(status='prepared_only_no_checks_executed', sequence=pin(base / 'sequence.json'),
    commands=len(sequence), installedSourceCount=18, sourcePinCount=len(source), registrationTargets=13,
    adaptedTest=source[str(Path(proposal['repo']) / 'tests/m1-inventory-split.test.ts')],
    expectedFixtures=7, rootGrantCreated=False, liveRepositoryWrites=False,
    testsRun=False, compilerRun=False, lintRun=False, productHydration=False,
    runArtifactsCreated=False))
print(json.dumps(read(base / 'freeze-receipt.json'), indent=2))
