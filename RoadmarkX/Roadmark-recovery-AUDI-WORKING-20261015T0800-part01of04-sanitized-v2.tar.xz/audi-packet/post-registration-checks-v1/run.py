"""Prepared only. One explicitly granted manifest per invocation; never auto-retry."""
from pathlib import Path
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
import re
import subprocess
import sys
import time


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while data := stream.read(1024 * 1024):
            value.update(data)
    return value.hexdigest()


def check(pin):
    path = Path(pin["path"])
    assert path.is_file() and path.stat().st_size == pin["bytes"], str(path)
    assert digest(path) == pin["sha256"], str(path)


assert len(sys.argv) == 5, "run.py MANIFEST MANIFEST_SHA256 ROOT_GRANT ROOT_GRANT_SHA256"
m, expected, grant_path, grant_hash = sys.argv[1:]
assert digest(m) == expected and digest(grant_path) == grant_hash
x = json.loads(Path(m).read_text())
grant = json.loads(Path(grant_path).read_text())
assert x["status"] == "frozen_not_executed_requires_review_and_root_grant"
assert grant["status"] == "root_execution_granted"
assert grant["automaticRetry"] is False and grant["parallelExecutionAllowed"] is False
assert any(p["path"] == str(Path(m).resolve()) and p["sha256"] == expected for p in grant["granted"])
assert x["automaticRetry"] is False and x["sourceMutationsAuthorized"] is False
assert x["parallelExecutionAllowed"] is False and x["killAfterSeconds"] == 10
assert 0 < x["timeoutSeconds"] <= 900
assert Path(__file__).resolve() == Path(x["wrapper"]["path"]).resolve()
# The grant must name the independently accepted final sequence and applied registration.
for key in ("sequence", "reviewerAcceptance", "registrationVerification"):
    check(grant[key])
sequence = json.loads(Path(grant["sequence"]["path"]).read_text())
assert sequence["status"] == "frozen_not_executed_requires_review_and_root_grant"
assert sequence["fullProjectClaim"] is False
assert any(p["path"] == str(Path(m).resolve()) and p["sha256"] == expected for p in sequence["sequence"])
assert x["sourcePins"] == sequence["sourcePins"]
assert x["registrationManifest"] == sequence["registrationManifest"]
assert x["testManifest"] == sequence["testManifest"]
base = Path(x["qaRoot"])
assert base == Path(sequence["qaRoot"])
base.mkdir(parents=True, exist_ok=True)
lock = (base / ".sequential-check.lock").open("a+")
fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
# The lock lasts until this wrapper exits. It does not replace the root's M1 heavy-slot grant.
assert x["sequenceNumber"] >= 1
if x["previousResult"] is not None:
    prior = json.loads(Path(x["previousResult"]).read_text())
    assert prior["passed"] is True and prior["sequenceNumber"] == x["sequenceNumber"] - 1
    previous_manifest = sequence["sequence"][x["sequenceNumber"] - 2]
    assert prior["manifestSha256"] == previous_manifest["sha256"]
pins = [x[k] for k in ("wrapper", "sourcePins", "scope", "registrationManifest", "testManifest")]
for key in ("sourcePins", "scope", "registrationManifest", "testManifest"):
    check(x[key])
pins += json.loads(Path(x["sourcePins"]["path"]).read_text())
pins += x["extraPins"]
if x["toolPins"] is not None:
    check(x["toolPins"])
    pins += [x["toolPins"], *json.loads(Path(x["toolPins"]["path"]).read_text())]
scope = json.loads(Path(x["scope"]["path"]).read_text())


def checkpins():
    assert digest(m) == expected and digest(grant_path) == grant_hash
    for pin in pins:
        check(pin)
    for key in ("sequence", "reviewerAcceptance", "registrationVerification"):
        check(grant[key])


checkpins()
out = Path(x["runOutput"])
assert out.parent == base and out.name == x["id"]
out.mkdir(exist_ok=False)  # No second attempt may reuse this manifest's output directory.


def write(name, value):
    with (out / name).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


cmd = x["command"]
wrapped = ["/usr/bin/timeout", "--signal=TERM", "--kill-after=10s", f'{x["timeoutSeconds"]}s', *cmd]
env = os.environ.copy()
removed = ["NODE_OPTIONS", "NODE_PATH", "TS_NODE_PROJECT", "TS_NODE_COMPILER_OPTIONS", "NODE_COMPILE_CACHE"]
for name in removed:
    env.pop(name, None)
env.update(x["environmentOverrides"])
write("invocation.json", dict(
    at=now(), cwd=x["repo"], command=cmd, supervisedCommand=wrapped,
    manifestSha256=expected, wrapperSha256=digest(__file__), grantSha256=grant_hash,
    beforePinsPassed=True, automaticRetry=False, sourceMutationsAuthorized=False,
    removedEnvironmentKeys=removed, environmentOverrides=x["environmentOverrides"],
    sequenceNumber=x["sequenceNumber"], fullProjectClaim=False,
))
start = time.monotonic()
with (out / "stdout.log").open("x") as so, (out / "stderr.log").open("x") as se:
    try:
        process = subprocess.Popen(wrapped, cwd=x["repo"], env=env, stdout=so, stderr=se, start_new_session=True)
    except Exception as error:
        write("setup-failure.json", dict(at=now(), error=repr(error), processStarted=False, automaticRetry=False))
        raise
    write("started.json", dict(at=now(), pid=process.pid, processGroup=os.getpgid(process.pid)))
    _, status, usage = os.wait4(process.pid, 0)
    code = os.waitstatus_to_exitcode(status)
    process.returncode = code
    so.flush()
    se.flush()
    os.fsync(so.fileno())
    os.fsync(se.fileno())
terminal = dict(
    at=now(), exitCode=code, rawWaitStatus=status, elapsedSeconds=time.monotonic() - start,
    maxRssKiB=usage.ru_maxrss, stdoutSha256=digest(out / "stdout.log"), stderrSha256=digest(out / "stderr.log"),
    timeoutInterpretation="Raw wait status retained; no cause inferred", automaticRetry=False,
)
write("terminal.json", terminal)
pins_ok = False
try:
    checkpins()
    pins_ok = True
    write("after-pins.json", dict(at=now(), passed=True, count=len(pins), manifestSha256=expected))
except Exception as error:
    write("after-pins.json", dict(at=now(), passed=False, error=repr(error)))
verified = False
try:
    stdout = (out / "stdout.log").read_text()
    if x["kind"] == "compile":
        observed = sorted(set(str(Path(line.strip()).resolve()) for line in stdout.splitlines()
                              if line.startswith("/") and line.strip().endswith(".ts")))
        expected_sources = set(scope["expectedProjectFiles"])
        allowed_roots = [Path(path).resolve() for path in scope["allowedDeclarationRoots"]]
        unexpected = [path for path in observed if path not in expected_sources and not (
            path.endswith(".d.ts") and any(Path(path).is_relative_to(root) for root in allowed_roots))]
        missing = sorted(expected_sources - set(observed))
        verified = bool(observed) and not unexpected and not missing
        details = dict(observedFiles=observed, expectedProjectFiles=sorted(expected_sources),
                       projectSourceCount=len(expected_sources), unexpected=unexpected, missing=missing,
                       fullProjectCompile=False, skipLibCheck=True)
    elif x["kind"] == "lint":
        reports = json.loads(stdout)
        assert isinstance(reports, list)
        observed = [str(Path(item["filePath"]).resolve()) for item in reports]
        verified = sorted(observed) == sorted(scope["lintTargets"]) and len(observed) == 3 and all(
            item["errorCount"] == item["warningCount"] == item["fatalErrorCount"] == 0 for item in reports)
        details = dict(observedFiles=observed, expectedFiles=scope["lintTargets"],
                       messages=[dict(file=item["filePath"], message=msg) for item in reports for msg in item["messages"]])
    elif x["kind"] == "tests":
        counts = {}
        for label in ("tests", "pass", "fail", "cancelled", "skipped", "todo"):
            values = re.findall(r"^# " + label + r" (\d+)$", stdout, re.MULTILINE)
            assert len(values) == 1, (label, values)
            counts[label] = int(values[0])
        verified = counts["tests"] == counts["pass"] == x["expectedTests"] and all(
            counts[label] == 0 for label in ("fail", "cancelled", "skipped", "todo"))
        details = dict(counts=counts, expectedTests=x["expectedTests"], fullSuiteClaim=False)
    elif x["kind"] == "report":
        report = json.loads(stdout)
        counts = [report[key] for key in ("allCatalogueVersions", "tierOneVersions", "onSaleVersions")]
        verified = counts == [427, 350, 309]
        details = dict(counts=counts, exactFullReportParityRequiresNextStep=True)
    elif x["kind"] == "parity":
        result = json.loads(stdout)
        verified = result["exactDeepEquality"] is True and result["byteEquality"] is True and result["ignoredPaths"] == []
        details = result
    else:
        verified = code == 0
        details = dict(commandCompleted=verified)
    write("scope-verification.json", dict(at=now(), kind=x["kind"], passed=verified, details=details))
except Exception as error:
    write("scope-verification.json", dict(at=now(), kind=x["kind"], passed=False, error=repr(error)))
passed = code == 0 and pins_ok and verified
write("result.json", dict(at=now(), passed=passed, manifestSha256=expected, grantSha256=grant_hash,
                          sequenceNumber=x["sequenceNumber"], exitCode=code, pinsPassed=pins_ok,
                          scopePassed=verified, fullProjectClaim=False, automaticRetry=False))
print(json.dumps(terminal))
print(json.dumps(dict(passed=passed, pinsPassed=pins_ok, scopePassed=verified)))
print((out / "stdout.log").read_text()[-3500:])
print((out / "stderr.log").read_text()[-4500:])
sys.exit(0 if passed else 1)
