# Audi installed post-registration checks

Prepared only. This worker did not run product code, tests, a compiler, lint, validation, report generation, hydration, a dependency scan, a content scan, or an install. No live repository edits were made here.

## Final source freeze

- Registration: `/tmp/audi-registration-bundle/manifest.json`, SHA-256 `920db20ecf5c2377731fad37e1fb5cd5eec9bea6ba3f6caa76851868a865ea22`
- Exactly 13 intended-installed targets: packet, reconciliation, registry append, helper, load append, one adapted test, seven small fixtures
- Final sequence: `sequence.json`, SHA-256 `cb0855571c0c6f77a3dc8e4f31391254701b657e097bafbc049b2b057d0ec8ad`
- `freeze-receipt.json` lists the preparation outcome. This is not an execution receipt
- `command-scope-proposal.json`, `source-pins.provisional.json`, and `pin-provenance.json` retain the earlier preparation state. Only the frozen `sequence.json` and its exact nine member manifests define the final run scope
- Unchanged search, full-detail, and historical-source tests are omitted. The old search proposal is preserved under `superseded/` with non-executable status

## Order and resource limits

All checks are sequential, fail closed, and require independent review and an explicit root grant before execution. The root also owns the exclusive M1 heavy slot. Node worker concurrency is one. GNU timeout sends TERM, then KILL after ten seconds. The wrapper launches one supervised command, records `os.wait4` raw status, elapsed time, and max RSS, preserves full logs, and never retries.

1. Installed inventory split: 78 tests, 256 MiB old space / 1 MiB semi space, 60 seconds
2. Strict installed compile: two roots, exactly 18 project sources, 256/1 MiB, 60 seconds
3. Lint: helper, load, and new test only, 256/1 MiB, 180 seconds
4. Market view consistency: `--check`, 128/1 MiB, 60 seconds
5. Actual structural validator: 448/1 MiB, 900 seconds
6. Normal coverage JSON: `--as-of 2026-10-15`, 448/1 MiB, 900 seconds
7. Exact complete normal/staged report parity: Python comparison, 30 seconds
8. Seven existing fixture test files: exactly 105 tests, 512/1 MiB, 600 seconds
9. One isolated live-safety test file: exactly 7 tests, 512/1 MiB, 600 seconds

The 105 tests are `brand-updates`, `price-ladder`, `market-review-reconciliation`, `m1-coverage-tracking`, `coverage-reports`, `c1-order-eligibility`, and `availability-ranking`. Test verification requires exact expected counts and zero failures, skips, cancellations, and todo tests. Separate test processes do not constitute a full-suite aggregate.

## Installed compiler scope

`tsconfig.installed.json` does not extend the full-project config. It uses the actual repository helper and actual installed test as its only roots; all 18 expected source paths are the actual repository paths. The prior 19-source proposal closure loses only its duplicate baseline helper. No temporary copy or fake stub stands in for installed production dependencies.

The compiler is the existing TypeScript 5.9.3 entrypoint from the accepted narrowed static-tool metadata. It runs strict, no emit, no incremental, no composite, no JavaScript, and Node types only. `skipLibCheck` retains the prior accepted setting for installed declarations. The wrapper checks actual `--listFiles` output even if diagnostics occur: every one of the 18 source files must appear, no additional project source may appear, and other files must be `.d.ts` declarations beneath the three explicitly allowed installed declaration roots. No full-project typecheck is claimed.

ESLint uses the existing pinned entrypoint and actual repository config, JSON output, no cache, concurrency off, exact three targets, and zero warnings. Its reported file list is independently checked.

## Pin policy

`source-pins.json` has 131 exact nominated source/test/config pins, with all 13 registration intended-after hashes substituted at their installed paths. The existing data/source closure comes from the nominated accepted full-stage manifest. Check entrypoints and unchanged regression-file pins come from the previous accepted Skoda checks; configuration/tool metadata comes from the accepted narrowed Audi static preparation. Preparing these plans did not rehash canonical data rows or sweep source/dependency directories.

Only compile/lint add the 53 already narrowed selected toolchain entrypoint/config/declaration pins. They are not a whole-node_modules integrity audit. No dependency modifications may run concurrently. Runtime guards verify the exact nominated files before and after each command with streaming SHA-256; they do not enumerate the filesystem or discover additional inputs.

## Root-grant interface

The root writes a separate immutable grant JSON only after independent acceptance and verified installation. The grant requires these keys:

- `status`: `root_execution_granted`
- `automaticRetry`: false
- `parallelExecutionAllowed`: false
- `sequence`: the exact final sequence pin object, containing path, bytes, sha256
- `reviewerAcceptance`: the independent final-check-plan acceptance receipt pin
- `registrationVerification`: the accepted live registration readback receipt pin
- `granted`: an array of exact manifest pin objects copied unchanged from `sequence.json`

The accepted live readback currently nominated by the parent is `/tmp/audi-review/registration-v1-readback.json`, SHA-256 `864aca6c81ca14aeb07d4b69055c3f5fededa5578472a612aba420dc5452946f`. The reviewer acceptance must refer to this final nine-check sequence. A template is provided as `root-grant-template.json`; its status deliberately cannot execute.

One immutable root grant may cover all nine manifests. The root may instead issue independent grants for later manifests without changing the frozen manifests, sequence, or prior result: each predecessor is validated against its exact sequence-member hash. There is no requirement to mutate or rehash the sequence at each step.

Invoke only the individually approved next check:

`python /tmp/audi-packet/post-registration-checks-v1/run.py MANIFEST_PATH MANIFEST_SHA256 ROOT_GRANT_PATH ROOT_GRANT_SHA256`

For the first check, use `installed-inventory-split-tests.json` and SHA-256 `7fe40ab17d4b31fc6bdd30f43bbb6121c6302d7bdcada540231c14b73e2dee5b`.

The wrapper creates the QA parent directory only after grant metadata checks, then takes a nonblocking sequential lock. Each individual output directory must be new. A command failure, scope mismatch, pin mismatch, or setup problem stops the sequence; any correction and new attempt needs a separately reviewed explicit root decision. The wrapper never loops over or retries commands.

## Report parity

The normal report must produce counts 427 total / 350 Tier 1 / 309 on sale. Parity then requires full JSON equality and full serialized byte equality against the independently accepted 1,670,700-byte staged report with SHA-256 `0e971290adb305fd261321df5272b469a84e30f7e759f24efb658ddb9d7c6e1a`. There are no exclusions or ignored paths. Audi remains 9 on sale, 7 current maker lists, 17 reviewed current versions, and C1 false. No whole-market completion, build, publication, or full-project test claim is made.
