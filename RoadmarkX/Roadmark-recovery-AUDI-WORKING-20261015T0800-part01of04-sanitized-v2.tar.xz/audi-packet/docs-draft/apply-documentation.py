from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,sys
BASE=Path('/tmp/audi-packet/docs-draft')
REPO=Path('/workspace/scratch/586427eef9f2/roadmark-104')
EXPECTED='d03be0f796ba19c8d9c6d7424402eac56deb01c698bcc3a40eb34fcfc946b6b5'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def check(p):
 q=Path(p['path']);assert q.is_file() and q.stat().st_size==p['bytes'] and sha(q)==p['sha256'],str(q)
assert len(sys.argv)==2 and sys.argv[1]==EXPECTED
mp=BASE/'documentation-bundle-manifest.json';assert sha(mp)==EXPECTED
m=json.loads(mp.read_text());assert [t['relativePath'] for t in m['targets']]==['docs/AUDI_M1_UPDATE.md','docs/M1_PROGRESS.md']
check(m['patch']);check(m['draftManifest'])
for g in m['acceptedReceiptGroups']:
 check(g.get('acceptance',g.get('independentAcceptance')))
 for p in g.get('resultArtifacts',[]):check(p)
for t in m['targets']:
 target=REPO/t['relativePath'];b=t['before'];check(t['after'])
 if b['exists']:check(b);assert str(target)==b['path']
 else:assert not target.exists(),str(target)
out=BASE/'application';out.mkdir(exist_ok=False)
for t in m['targets']:
 target=REPO/t['relativePath'];p=out/'before'/t['relativePath'];p.parent.mkdir(parents=True,exist_ok=True)
 if t['before']['exists']:p.write_bytes(target.read_bytes());assert sha(p)==t['before']['sha256']
 else:p.with_suffix(p.suffix+'.absent.json').write_text(json.dumps({'expectedAbsent':True,'target':str(target)})+'\n')
for t in m['targets']:
 target=REPO/t['relativePath'];b=t['before']
 if b['exists']:check(b)
 else:assert not target.exists()
 target.write_bytes(Path(t['after']['path']).read_bytes())
 assert target.stat().st_size==t['after']['bytes'] and sha(target)==t['after']['sha256']
r={'status':'applied_exact_two_documentation_targets','at':datetime.now(timezone.utc).isoformat(),'manifestSha256':EXPECTED,'applicationScript':pin(Path(__file__)),'targets':[pin(REPO/t['relativePath']) for t in m['targets']],'priorProgressPreservedOutsideReviewedSchemaInsertionAndAppend':True,'automaticRetry':False,'sourceCodeChanges':False}
p=out/'result.json';p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(pin(p)))
