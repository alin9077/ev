from pathlib import Path
import json,hashlib,copy,re
from urllib.parse import urlparse
R=Path('/tmp/audi-research');O=Path('/tmp/audi-packet/v1');ID='m1-audi-2026-10-15';DATE='2026-10-15';REVIEWER='Roadmark Audi M1 proposal pending independent review'
N=json.load(open(R/'normalized-review-v5.json'));I=json.load(open(R/'source-index-review-v1.json'))['sources'];B={v['id']:v for v in json.load(open(R/'retained-before-cars.json'))};C=json.load(open(R/'census-review-v2.json'))
assert hashlib.sha256((R/'normalized-review-v5.json').read_bytes()).hexdigest()=='acda8d10b8d699f553a0a31707990f29d7105ea70625b2208fc6d59b2336ce52'
P=dict(schemaVersion=1,id=ID,brand='Audi',reviewedAt=DATE,reviewedBy=REVIEWER,sources=[],models=[],variants=[],versionGuards=[],versionUpdates=[],facts=[],features=[],configurationUpdates=[],brandTerms=[],availability=[],summaries=[])
sourcekeys=set(C['censusSourceKeys'])
for v in N['variants']:
 for f in [*v['coreFacts'].values(),*v['extraFacts'].values()]:sourcekeys.update(f['sourceKeys'])
 sourcekeys.update(v['availability']['sourceKeys'])
# Include exact public identity responses for price provenance, even when a fact cites its total response.
sourcekeys.update(['au-calculator-engines-213','au-calculator-engines-239','au-calculator-engines-221','au-calculator-engines-240'])
def sid(key):return ID+'-'+key
for key in sorted(sourcekeys):
 s=I[key];url=s['url'];host=urlparse(url).hostname or '';maker=bool(re.search(r'(^|\.)(audi\.com\.au|myaudi\.com\.au|audiproduction\.com\.au|audi\.com|one\.audi)$',host));publisher='Audi Australia' if maker else 'CarExpert' if 'carexpert' in host else 'RedBook' if 'redbook' in host else 'GoAuto' if 'goauto' in host else 'Carsales' if 'carsales' in host else host
 title=key.replace('-',' ').replace('_',' ').strip().title();raw=Path(s['rawPath']);captures=[dict(locator=str(raw.relative_to('/tmp')),sha256=s['rawSha256'],bytes=s['rawBytes'],purpose=s.get('captureKind','Retained public source body'))]
 if s.get('textPath'):
  tp=Path(s['textPath']);captures.append(dict(locator=str(tp.relative_to('/tmp')),sha256=s['textSha256'],bytes=tp.stat().st_size,purpose='Extracted source text'))
 P['sources'].append(dict(id=sid(key),url=url,title=title,publisher=publisher,source_type='manufacturer_au_publication' if maker else 'secondary_australian_motoring_publication',published_date=None,accessed_date=DATE,market='AU',supports=title,retrievalMethod=s.get('captureKind',s.get('retrieval','Read-only public HTML/PDF or observed public unauthenticated calculator response; response bodies retained without sensitive headers')),capture_locator=captures[0]['locator'],capture_sha256=s['rawSha256'],retainedCaptures=captures,**({'retrieval_note':s['retrievalLimitation']} if s.get('retrievalLimitation') else {})))
S={s['id']:s for s in P['sources']}
labels=dict(price_aud='Listed price',range_km='Claimed range',battery_kwh='Net battery capacity',dc_peak_kw='Peak vehicle DC acceptance',dc_charge_time_min='Published DC charging duration',ac_kw='On-board AC maximum',seats='Seats',boot_l='Published rear storage',zero_to_100_s='0–100 km/h',power_kw='Motor power',drive='Drive type',length_mm='Length',width_mm='Width',height_mm='Height',towing_braked_kg='Braked towing',warranty='Vehicle warranty',battery_warranty='Battery warranty',battery_gross_kwh='Gross battery capacity',power_launch_control_kw='Power with launch control',zero_to_100_launch_control_s='0–100 km/h with launch control',max_total_cargo_l='Rear storage with seats folded',frunk_l='Front storage',reported_width_mm='Reported alternative width',reported_height_mm='Reported alternative height',reported_sport_driveaway_aud='Reported Sportback sport driveaway offer',reported_review_boot_l='Reported local-review rear boot')
def makefact(n,v,shared=False):
 k=n['key'];ids=[sid(x) for x in n['sourceKeys']];g=n['buyerGrade'];scope='brand_au_terms' if shared else 'secondary_or_sibling' if g=='reported' else 'searched_not_found' if g=='not_published' else n['evidenceScope'];reason={'confirmed':'Australian manufacturer evidence supports this exact labelled value or explicitly applicable body/brand scope. ','check':'Australian manufacturer evidence supports the observation with the stated real condition or unresolved source conflict. ','reported':'Secondary or carried sibling observation remains visible and unranked. ','not_published':'Two distinct public source checks did not establish the exact requested Australian value. '}[g]+n['locator']
 f=dict(key=k,label=labels.get(k,k.replace('_',' ').capitalize()),value=n['value'],unit=n['unit'],basis=n['basis'],comparisonBasis=n['comparisonBasis'],status='standard' if g=='confirmed' else 'not_verified' if g=='not_published' else 'conditional',sourceIds=ids,date=DATE,market='AU',scope='Audi Australia current new-vehicle / BEV high-voltage battery warranty terms' if shared else v['scope'],qualifications=[n['locator'],*n['qualifications']],issues=[],buyerGrade=g,gradeReview=dict(reviewedAt=DATE,overlayId=ID,reason=reason,evidenceScope=scope,sourceIds=ids,sourceLabel=' / '.join(dict.fromkeys(S[x]['publisher'] for x in ids))),resolvedElsewhere=g=='reported')
 if g=='check':f['conditionExplanation']=' '.join(n['qualifications'])
 if n.get('validUntil'):f['validUntil']=n['validUntil']
 if n.get('conflictId'):f['issues']=[dict(issue_id=ID+'-'+n['conflictId'],title=n['conflictId'].replace('_',' ').capitalize(),priority='field_hold',model_ids=[v['modelId']],publication_action='Keep source-labelled observations visible and exclude the unresolved claim from attribute rankings.',source_ids=ids)]
 if k=='price_aud':
  pe=copy.deepcopy(n['priceEvidence']);pe.pop('comparisonBasis',None);pe['sourceKey']=k;pe['sourcePointer']=I[n['sourceKeys'][0]]['url']+' | '+n['locator'];f['priceEvidence']=pe
 return f
modelids=set(v['modelId'] for v in B.values());normalizedfacts={}
for v in N['variants']:
 vid=v['id'];old=B.get(vid);mid=v['modelId'];generation=old['generation'] if old else v['generation']
 if mid not in modelids:
  family='audi-'+v['model'].lower().replace(' ','-');P['models'].append(dict(id=mid,brand='Audi',model=v['model'],generation=generation,family_id=family));modelids.add(mid)
 if old:P['versionGuards'].append(dict(variantId=vid,before={k:old.get(k) for k in ['id','modelId','brand','model','trim','year','generation','vehicleClass','drive']}))
 else:P['variants'].append(dict(id=vid,model_id=mid,brand='Audi',model=v['model'],trim=v['trim'],model_year=v['formalModelYear'],record_state=v['availability']['recordState'],variant_review_date=DATE,source_ids=[sid(k) for k in v['availability']['sourceKeys']],notes=[],price_basis='',range_cycle='',price_aud=None,range_km=None,seats=None,vehicle_class='passenger',drive=v['coreFacts']['drive']['value'],brand_update_generation=generation))
 nf={k:makefact(f,v) for k,f in {**v['coreFacts'],**v['extraFacts']}.items()};normalizedfacts[vid]=nf
 for k,f in nf.items():
  if k not in ['warranty','battery_warranty']:P['facts'].append(dict(variantId=vid,before=copy.deepcopy(old['facts'].get(k)) if old else None,after=f))
 a=v['availability'];e=dict(checkedAt=DATE,orderStatus=a['orderStatus'],stockStatus=a['stockStatus'],sourceIds=[sid(k) for k in a['sourceKeys']],physicalStockVerified=False,factoryOrderAcceptanceVerified=False,factoryBuildSpecificationVerified=False,deliveryToBuyerVerified=False,qualifications=a['qualifications'],configuration=v['scope'])
 before=dict(availability=old['availability'],evidence=copy.deepcopy(old['availabilityEvidence'])) if old else dict(availability=a['recordState'],evidence=dict(checkedAt=DATE,orderStatus='unverified',stockStatus='unverified',sourceIds=[sid(k) for k in a['sourceKeys']],qualifications=['Physical stock and factory-order acceptance have not been verified.']))
 P['availability'].append(dict(id=ID+'-availability-'+vid,variantId=vid,before=before,after=dict(availability=a['recordState'],evidence=e),status='approved',reviewedBy=REVIEWER,reviewedAt=DATE,evidenceDate=DATE,reason='Exact current Australian offering or separately scoped announced/order-open MY27 arrival. Maker and secondary order-opening attribution are explicit; no physical stock or accepted factory-order inference.'))
 summary=dict(variantId=vid,conditions=[])
 for name,clause in v['summary'].items():
  assert all(nf[k]['value'] is not None and not nf[k]['issues'] for k in clause['dependencies']),(vid,name)
  summary[name]=dict(label=clause['label'],text=clause['text'],dependencies=[dict(key=k,expected=copy.deepcopy(nf[k])) for k in clause['dependencies']])
 P['summaries'].append(summary)
for k in ['warranty','battery_warranty']:P['brandTerms'].append(dict(key=k,fact=makefact(N['variants'][0]['coreFacts'][k],N['variants'][0],True),applicableVariantIds=[v['id'] for v in N['variants']],before={v['id']:copy.deepcopy(B[v['id']]['facts'].get(k)) if v['id'] in B else None for v in N['variants']},exceptions=[]))
assert len(P['variants'])==10 and len(P['models'])==4 and len(P['versionGuards'])==7
assert not P['features'] and not P['configurationUpdates'] and not P['versionUpdates']
p=O/'audi-2026-10-15.json';p.write_text(json.dumps(P,indent=2,ensure_ascii=False)+'\n')
receipt=dict(status='proposal assembled pending independent review and selected actual-function preflight',packetPath=str(p),packetSha256=hashlib.sha256(p.read_bytes()).hexdigest(),packetBytes=p.stat().st_size,normalizedPath=str(R/'normalized-review-v5.json'),normalizedSha256=hashlib.sha256((R/'normalized-review-v5.json').read_bytes()).hexdigest(),sources=len(P['sources']),models=len(P['models']),newVariants=len(P['variants']),existingGuards=len(P['versionGuards']),specificFactUpdates=len(P['facts']),sharedBrandTerms=2,effectiveTermCells=34,availability=len(P['availability']),summaries=len(P['summaries']),configurationUpdates=0,equipmentUpdates=0,versionUpdates=0,expectedCatalogueDelta=10,expectedTier1Delta=10,expectedOnSaleDelta=2,baselineStatus='Seven selected unchanged Audi cars from accepted derived retained409 chain; exact beforeguards await selected actual-function preflight. No full catalogue hydrated.',productionSourceEdits=False,productionCatalogueHydration=False)
(O/'assembly-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
