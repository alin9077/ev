from pathlib import Path
import sys,json,subprocess,os,time,hashlib
from datetime import datetime,timezone
m=Path(sys.argv[1]);expected=sys.argv[2]
assert hashlib.sha256(m.read_bytes()).hexdigest()==expected
x=json.loads(m.read_text());assert x['timeoutSeconds']==180 and x['automaticRetry'] is False
assert x['script']['sha256']=='177b7a439bf61f699914d6220313627cd515c7e16c9eee811da70541f37ad04f'
assert x['packet']['sha256']=='4a85ee0d92c7a49e3e2265791516658699dfe2320d3e52e2ce39b58b2f6d172e'
assert x['command'][1:3]==['--max-old-space-size=448','--max-semi-space-size=1']
pins=[x[k] for k in ['script','sourcePins','packet','reconciliation']]+json.loads(Path(x['sourcePins']['path']).read_text())
def checkpins():
 for p in pins:
  b=Path(p['path']).read_bytes();assert len(b)==p['bytes'];assert hashlib.sha256(b).hexdigest()==p['sha256'],p['path']
 assert hashlib.sha256(m.read_bytes()).hexdigest()==expected
checkpins();out=m.parent/'run';out.mkdir(exist_ok=False)
def now():return datetime.now(timezone.utc).isoformat()
def write(name,obj):
 with (out/name).open('x') as f:json.dump(obj,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
cmd=x['command'];wrapped=['/usr/bin/timeout','--signal=TERM','--kill-after=10s','180s',*cmd]
write('invocation.json',dict(at=now(),cwd=x['workdir'],command=cmd,supervisedCommand=wrapped,preparedManifestSha256=expected,wrapperSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),beforePinsPassed=True,automaticRetry=False,sourceMutationsAuthorized=False))
start=time.monotonic()
with (out/'stdout.log').open('x') as so,(out/'stderr.log').open('x') as se:
 p=subprocess.Popen(wrapped,cwd=x['workdir'],stdout=so,stderr=se,start_new_session=True);write('started.json',dict(at=now(),pid=p.pid,processGroup=os.getpgid(p.pid)))
 _,status,usage=os.wait4(p.pid,0);code=os.waitstatus_to_exitcode(status);p.returncode=code;so.flush();se.flush();os.fsync(so.fileno());os.fsync(se.fileno())
terminal=dict(at=now(),exitCode=code,rawWaitStatus=status,elapsedSeconds=time.monotonic()-start,maxRssKiB=usage.ru_maxrss,stdoutSha256=hashlib.sha256((out/'stdout.log').read_bytes()).hexdigest(),stderrSha256=hashlib.sha256((out/'stderr.log').read_bytes()).hexdigest(),timeoutInterpretation='Raw wait status retained; no cause inferred',automaticRetry=False)
write('terminal.json',terminal)
try:checkpins();write('after-pins.json',dict(at=now(),passed=True,count=len(pins),preparedManifestSha256=expected))
except Exception as e:write('after-pins.json',dict(at=now(),passed=False,error=repr(e)));raise
print(json.dumps(terminal));print((out/'stdout.log').read_text()[-3500:]);print((out/'stderr.log').read_text()[-4500:]);sys.exit(0 if code==0 else 1)
