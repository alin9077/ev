from pathlib import Path
import json,hashlib,difflib
old=Path('/tmp/audi-packet/selected-preflight-v2');out=Path('/tmp/audi-packet/selected-preflight-v3');out.mkdir(exist_ok=True)
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def save(p,d):Path(p).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
s=(old/'check.mjs').read_text().replace(str(old),str(out))
needle="for(const edit of packet.availability){const b=before.find(c=>c.id===edit.variantId),a=after.find(c=>c.id===edit.variantId);assert.deepEqual(b?{availability:b.availability,evidence:b.availabilityEvidence}:null,edit.before);assert.equal(a.availability,edit.after.availability);assert.deepEqual(a.availabilityEvidence,edit.after.evidence);}"
replacement="""// Actual generated-before availability witness. This identity-only clone invokes unchanged
// applyBrandUpdates → private newVariantCar for the ten additions; no defaults are copied.
const identityOnlyPacket=structuredClone(packet),clearedProducerFields=['versionGuards','versionUpdates','facts','features','configurationUpdates','brandTerms','availability','summaries'];
for(const field of clearedProducerFields)identityOnlyPacket[field]=[];
for(const field of ['sources','models','variants'])assert.deepEqual(identityOnlyPacket[field],packet[field]);
const packetSnapshot=JSON.stringify(packet),identitySnapshot=JSON.stringify(identityOnlyPacket),generatedBefore=applyBrandUpdates([],data,[identityOnlyPacket]);
assert.equal(JSON.stringify(packet),packetSnapshot);assert.equal(JSON.stringify(identityOnlyPacket),identitySnapshot);assert.equal(generatedBefore.length,10);assert.deepEqual(new Set(generatedBefore.map(c=>c.id)),new Set(packet.variants.map(v=>v.id)));
const generatedAvailabilityProof={producer:'src/lib/brand-updates.ts:applyBrandUpdates → newVariantCar',clearedProducerFields,originalPacketUnchanged:true,identityOnlyInputUnchanged:true,rows:generatedBefore.map(c=>({variantId:c.id,availability:c.availability,evidence:c.availabilityEvidence}))};
for(const edit of packet.availability){const b=before.find(c=>c.id===edit.variantId)??generatedBefore.find(c=>c.id===edit.variantId),a=after.find(c=>c.id===edit.variantId);assert(b);assert.deepEqual({availability:b.availability,evidence:b.availabilityEvidence},edit.before);assert.equal(a.availability,edit.after.availability);assert.deepEqual(a.availabilityEvidence,edit.after.evidence);}"""
assert s.count(needle)==1;s=s.replace(needle,replacement).replace('producerProofs,observations,counts:','producerProofs,generatedAvailabilityProof,observations,counts:')
(out/'check.mjs').write_text(s)
(out/'expected-review.json').write_bytes((old/'expected-review.json').read_bytes());pins=json.loads((old/'source-pins.json').read_text());save(out/'source-pins.json',[pin(x['path'].replace(str(old),str(out))) for x in pins]);m=json.loads((old/'prepared-command.json').read_text());m['script']=pin(out/'check.mjs');m['sourcePins']=pin(out/'source-pins.json');m['command']=[x.replace(str(old),str(out)) for x in m['command']];m['scope']+=' Added availability before-states are independently witnessed by the actual unchanged addition builder via an explicitly recorded identity-only packet; retained before-states still use the accepted seven cars.'
w=(old/'run.py').read_text().replace(json.loads((old/'prepared-command.json').read_text())['script']['sha256'],m['script']['sha256']);(out/'run.py').write_text(w);m['wrapper']=pin(out/'run.py');save(out/'prepared-command.json',m)
(out/'v2-to-v3-harness.patch').write_text(''.join(difflib.unified_diff((old/'check.mjs').read_text().splitlines(True),s.splitlines(True),fromfile='v2/check.mjs',tofile='v3/check.mjs')))
print(json.dumps(dict(manifest=pin(out/'prepared-command.json'),script=m['script'],wrapper=m['wrapper'],packet=m['packet'],executed=False),indent=2))
