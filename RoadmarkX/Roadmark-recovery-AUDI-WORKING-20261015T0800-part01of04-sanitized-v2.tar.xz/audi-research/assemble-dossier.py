from pathlib import Path
import json,hashlib,copy
R=Path('/tmp/audi-research');D=R/'sources';N=json.load(open(R/'normalized-review-v3.json'));G=json.load(open(R/'gt-q8/normalized-gt-q8.json'));Q=json.load(open(R/'q4-my27/my27-core-observations.json'));I={}
for p in D.glob('*-receipt.json'):
 x=json.load(open(p))
 if x.get('status')==200 and x.get('rawPath'):I[x['key']]=x
# Public frontend asset was retained from an exact script URL observed in calculator HTML.
p=D/'au-price-calculator-client.js';I['au-price-calculator-client']=dict(key='au-price-calculator-client',url='https://cdn01.audi.com.au/lib/forms/v132/static/js/client.7bab6ee6.js',checkedAt='2026-10-15',rawPath=str(p),rawBytes=p.stat().st_size,rawSha256=hashlib.sha256(p.read_bytes()).hexdigest(),captureKind='Exact public calculator script asset; no authenticated interaction')
for key,s in G['source_registry'].items():
 p=Path(s['body_path']);I['gt-'+key]=dict(key='gt-'+key,url=s['url'].split(' ; ')[0],checkedAt=s.get('captured_at','2026-10-15'),rawPath=str(p),rawBytes=p.stat().st_size,rawSha256=s['sha256'],captureKind='Public source body or indexed web extraction, as retained in GT source registry')
for key,s in Q['sources'].items():
 if not key.startswith('rb-'):continue
 p=Path(s['capturePath']);I['q4-'+key]=dict(key='q4-'+key,url=s['url'],checkedAt='2026-10-15',rawPath=str(p),rawBytes=p.stat().st_size,rawSha256=s['sha256'],captureKind=s['captureKind'],retrievalLimitation=s.get('limitations',''))
for key,fn,url in [('rb-q6-my26-web','rb-q6-my26-web-extraction.json','https://www.redbook.com.au/cars/details/2026-audi-q6-e-tron-auto-my26/SPOT-ITM-688723?Cr=9'),('rb-q6-sq6-web','rb-q6-sq6-exact-observations.json','https://www.redbook.com.au/cars/details/2026-audi-sq6-e-tron-auto-e-quattro-my26/SPOT-ITM-688721?Cr=108'),('rb-q6-sport-web','rb-q6-sq6-exact-observations.json','https://www.redbook.com.au/cars/details/2026-audi-q6-e-tron-sport-auto-my26/SPOT-ITM-688724?Cr=7')]:
 p=D/fn;I[key]=dict(key=key,url=url,checkedAt='2026-10-15',rawPath=str(p),rawBytes=p.stat().st_size,rawSha256=hashlib.sha256(p.read_bytes()).hexdigest(),captureKind='Indexed public exact AU MY26 record body; direct body403, secondary only, not an availability advertisement')
for v in N['variants']:
 vid=v['id'];c=v['coreFacts']
 if 'audi_q6_' in vid and v['formalModelYear']==2027:v['model']='Q6 Sportback e-tron' if 'sportback' in vid else 'Q6 e-tron'
 if 'audi_q6_suv_my26' in vid and not v['trim'].startswith('SQ'):
  for k in ['length_mm','width_mm','height_mm']:
   z=c[k]
   if z['value'] is None:continue
   z.update(buyerGrade='reported',status='conditional',evidenceScope='secondary_or_sibling',comparisonBasis='',rankingEligible=False)
   if k=='length_mm' or z['sourceKeys']==['au-q6-dimensions']:z['qualifications'].append('Current base page links a drawing titled Q6 e-tron quattro dated12/24 with defined-equipment nominal values. This is a sibling observation, not exact base or sport-edition confirmation.')
 if 'sport_edition' in vid and 'suv' in vid:c['price_aud']['sourceKeys']=['au-q-sales'];c['price_aud']['locator']='Current Q Sales body’s bound q_sale_q6e_disclaimer, not an unrelated shared-payload footnote'
# Audit normalized source closure before freezing.
keys=set()
for v in N['variants']:
 keys.update(v['availability']['sourceKeys'])
 for f in [*v['coreFacts'].values(),*v['extraFacts'].values()]:keys.update(f['sourceKeys'])
assert keys <= set(I),sorted(keys-set(I))
for key in keys:
 s=I[key];p=Path(s['rawPath']);assert hashlib.sha256(p.read_bytes()).hexdigest()==s['rawSha256'],key
N['status']='normalized proposal v4 frozen for independent review';p=R/'normalized-review-v4.json';p.write_text(json.dumps(N,indent=2,ensure_ascii=False)+'\n')
index=dict(asOf='2026-10-15',sources=I,notes=['Response headers retained only through safe allowlist; no Cookie, Set-Cookie, auth or token headers used as evidence.','GraphQL enumerates identities; observed public GetPrice GET returns totals. Exact frontend maps VehicleDriveAwayPrice to driveaway display and LCT-inclusive footnote.','Public web indexed bodies remain labelled secondary, with retrieval limitations described; no exact live stock inference.']);(R/'source-index-review-v1.json').write_text(json.dumps(index,indent=2,ensure_ascii=False)+'\n')
# Current maker enumeration and residual/global leads are separate.
censuskeys=['au-electric','au-q6-spec','au-q6-sportback-spec','au-q6-new','au-q4-new','au-q4-page','au-q4-sportback-page','au-q-sales','au-calculator-visible-electric-variants','au-calculator-engines-207','au-calculator-engines-208','au-calculator-engines-213','au-calculator-engines-239','au-calculator-engines-221','au-calculator-engines-240','goauto-q6-my27','ce-q4-my27-pricing','ce-q6-my27','goauto-a6-cancel','gt-gt-range','gt-gt-my26-spec','gt-q8-suv','gt-q8-sportback','gt-sq8-suv','gt-sq8-sportback']
assert set(censuskeys)<=set(I),set(censuskeys)-set(I)
reviews=[]
for mid in dict.fromkeys(v['modelId'] for v in N['variants']):
 vs=[v for v in N['variants'] if v['modelId']==mid];reviews.append(dict(modelId=mid,model=vs[0]['model'],status='supported_current_version_list',versions=[{k:v[k] for k in ['id','model','trim','formalModelYear']} for v in vs],officialSourceKeys=sorted(set(k for v in vs for k in v['availability']['sourceKeys'] if k.startswith(('au-','gt-gt-')))),orderOpeningAttribution=sorted(set(v['availability']['orderOpeningAttribution'] for v in vs)),reason='Exact current maker technical/current offering or separately announced MY27 version enumeration; future arrival records stay outside on-sale denominator.'))
q4leads=[]
for variant in [207,208]:
 for eng in json.load(open(D/f'au-calculator-engines-{variant}.json'))['data']['engineList']['items']:
  q4leads.append(dict(candidate=('Q4 Sportback ' if variant==208 else 'Q4 ')+eng['label'],modelYear=eng['year'],modelCode=eng['modelCode'],status='unresolved_calculator_listed_not_admitted',sourceKeys=[f'au-calculator-engines-{variant}',f'au-calculator-price-{eng["value"]}'],reason='Current public calculator still exposes MY26 engine and price, but visible maker model/configurator page is MY27. No unambiguous exact dealer-New offering verified in bounded residual pass. Calculator status alone is not current availability proof.'))
C=dict(checkedAt='2026-10-15',scope='Australia Tier1 BEV passenger/SUV versions, read-only evidence preparation',proposedVariants=17,retainedRefreshes=7,additions=10,onSaleProposed=9,futureOrderOrArrivalProposed=8,officialCurrentFamilies=['Q4 e-tron SUV','Q4 Sportback e-tron','Q6/SQ6 e-tron SUV','Q6/SQ6 Sportback e-tron','e-tron GT'],currentVersionReviews=reviews,makerIndexListedButWithdrawn=G['seven_currently_listed_shape_records'][3:],futureAndUnresolvedCandidates=q4leads+[dict(candidate='A6/S6 e-tron Sportback and Avant',status='excluded_cancelled_local_launch',sourceKeys=['goauto-a6-cancel','au-electric'],reason='Older local previews were superseded by reported November2025 cancellation quoting Audi Australia. Absent current electric range and enabled calculator; no new AU model inferred from generic backend inclusion.'),dict(candidate='Q6 performance SUV and Q6 quattro SUV/Sportback outgoing MY25',status='unresolved_residual_only',sourceKeys=['au-q6-spec','au-q6-sportback-spec','goauto-q6-my27'],reason='Absent current MY26 technical/calculator grade enumeration; bounded residual ads found Demo/Used/Sold or generic order templates, not clean New eligibility. Historical launch grades not deleted from the dossier.')],residualCensusPath=str(R/'residual/residual-census.json'),additionalExcludedCandidates=G['excluded_candidates'],residualNewProofCount=0,residualConclusion='No unambiguous exact live New residual found in the bounded pass; this is not a national zero-stock claim.',censusSourceKeys=censuskeys,wholeMarketCoverage=dict(independentWholeMarketLists=0,required=2,closed=False,reason='Brand maker enumeration is reviewed; two independent whole-market lists and remaining brands still prevent global C1 closure.'),limitations=['No physical stock, accepted factory allocation, delivered VIN or build specification verification.','Public configurator direct Chromium failed before navigation and was not retried; permitted public HTML/PDF and observed unauthenticated read-only resources used.','No user-computer, sign-in, new permission, publishing or live catalogue action.'])
p=R/'census-review-v1.json';p.write_text(json.dumps(C,indent=2,ensure_ascii=False)+'\n')
for name in ['normalized-review-v4.json','source-index-review-v1.json','census-review-v1.json']:p=R/name;print(name,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
