import urllib.request,hashlib,json,os,sys,datetime,subprocess
from html.parser import HTMLParser
D='/tmp/audi-research/gt-q8'
class P(HTMLParser):
 def __init__(self):super().__init__();self.skip=0;self.text=[]
 def handle_starttag(self,t,a):
  if t in ['script','style']:self.skip+=1
  if t in ['p','div','h1','h2','h3','li','tr','br']:self.text.append('\n')
 def handle_endtag(self,t):
  if t in ['script','style']:self.skip=max(0,self.skip-1)
 def handle_data(self,s):
  if not self.skip:self.text.append(s)
def cap(name,u):
 try:
  r=urllib.request.urlopen(u,timeout=60);b=r.read();end=r.url
  fn=name+('.pdf' if b.startswith(b'%PDF') else '.html');open(D+'/'+fn,'wb').write(b)
  if fn.endswith('.pdf'):subprocess.run(['pdftotext','-layout',D+'/'+fn,D+'/'+name+'.txt'],check=True)
  else:
   p=P();p.feed(b.decode('utf-8',errors='replace'));open(D+'/'+name+'.txt','w').write('\n'.join(x.strip() for x in ''.join(p.text).splitlines() if x.strip()))
  info=dict(name=name,url=u,final_url=end,status=r.status,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),body_path=D+'/'+fn,captured_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
 except Exception as e:info=dict(name=name,url=u,error=str(e))
 with open(D+'/manifest.jsonl','a') as f:f.write(json.dumps(info)+'\n')
 print(json.dumps(info))
if __name__=='__main__':cap(sys.argv[1],sys.argv[2])
