from pathlib import Path
import json,hashlib,datetime
D=Path('/tmp/audi-research/gt-q8');p=D/'normalized-gt-q8.json';r=json.loads(p.read_text())
secondary={
'gt-s-carexpert-2026-exterior':'https://www.carexpert.com.au/audi/e-tron-gt/2026/s/exterior-and-dimensions',
'gt-rs-carexpert-2026-exterior':'https://www.carexpert.com.au/audi/e-tron-gt/2026/rs/exterior-and-dimensions',
'gt-performance-carexpert-2026-exterior':'https://www.carexpert.com.au/audi/e-tron-gt/2026/rs-performance/exterior-and-dimensions',
'gt-carexpert-features':'https://www.carexpert.com.au/audi/e-tron-gt/features-and-specs',
'gt-carexpert-review':'https://www.carexpert.com.au/car-reviews/2025-audi-e-tron-gt-review',
'gt-seats-redbook-secondary':'https://www.carexpert.com.au/audi/e-tron-gt/features-and-specs ; https://www.carexpert.com.au/audi/e-tron-gt/2026/rs/interior'}
for name,url in secondary.items():
 fn=D/(name+'-web.json');b=fn.read_bytes();s=dict(name=name,url=url,body_path=str(fn),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),captured_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),capture_kind='web_tool_rendered_body',note='Direct fetch returned403; public web-tool extract used. Crawled dates vary, no current inventory inferred.')
 with open(D/'manifest.jsonl','a') as mf:mf.write(json.dumps(s)+'\n')
# Latest registry incorporates historical model captures and secondary rendered bodies.
r['source_registry']={v['name']:v for v in map(json.loads,(D/'manifest.jsonl').read_text().splitlines()) if 'sha256'in v}
for i,v in enumerate(r['current_versions']):
 fields=v['fields'];src=list(secondary)[i]
 for key,value in [('length',{'mm':5004}),('width',{'body_mm':1964,'including_mirrors_mm':2158}),('height',{'mm':[1402,1389,1402][i]}),('boot',{'rear_litres':[405,350,350][i],'frunk_litres':77})]:
  prev=fields[key]
  fields[key]=dict(value=value,status='Reported',ranking_eligible=False,source_ids=[src],note='Exact named Australian secondary model/2026 page. Current AU maker PDF/landing do not publish this measurement; retain unranked. '+('S rear volume conflicts with local review350L and may be equipment-dependent; do not imply AU confirmed405L. ' if i==0 and key=='boot' else '')+('Maker German sheet gives a chassis/equipment-dependent height1369–1402mm; exact AU height not resolved. ' if key=='height' else ''),overseas_maker_supplement=prev)
 fields['seats']=dict(value={'count':5},status='Reported',ranking_eligible=False,source_ids=['gt-seats-redbook-secondary','gt-carexpert-features'],note='AU secondary current facelift three-version comparison explicitly five each; named German maker PDFs corroborate. AU primary exact count not found after PDF/landing/launch checks.')
 if i>0:
  fields['ac']['status']='Reported';fields['ac']['source_ids']=['gt-carexpert-features']
  fields['ac']['ranking_eligible']=False;fields['ac']['note']='AU secondary comparison explicitly11kW for each named facelift model; corresponding German makerPDF corroborates. AU launch explicit11kW applies S only; no primary AU named RS on-board figure found in PDF/page.'
 v['current_listed_C1']=True
 v['on_sale_eligibility']=dict(eligible=True,route='current_maker_new_offering',exact_dealer_new_ad=False,source_ids=['gt-range','gt-my26-spec','calculator-current-variants','calculator-price-'+str([1142,1143,1144][i])+'-NSW'],note='Maker range/build/current calculator new-vehicle evidence; no claim dealer accepts an order or has exact New stock today.')
 v['strengths']=[
 ['Longest official range of these three (558km ADR81/02) and lowest live NSW maker driveaway estimate; same105/97kWh battery and320kW DC peak as RS models.','3.4s launch acceleration plus standard all-wheel steering and adaptive air suspension.'],
 ['2.8s launch acceleration and630kW launch output; standard switchable-opacity glass roof.','Shares upgraded battery and320kW DC hardware with the performance model.'],
 ['Fastest GT version here:2.5s launch acceleration and680kW launch output.','Active electrohydraulic suspension standard in the current AU guide; optional on RS.']][i]
 v['tradeoffs']=[
 ['Slower launch acceleration than both RS versions, despite still very high performance.','Reported five-metre body and2.158m mirror width require garage checks; S boot405/350L conflict remains unresolved.'],
 ['NSW maker driveaway estimate is$57,750 above S while official ADR range is36km lower.','Active suspension is a$15,900 option in the linked MY26 guide; reported350L rear boot is modest for a large sedan.'],
 ['NSW maker driveaway estimate is$47,250 above RS; charging peak and battery capacity are unchanged.','Reported350L rear boot and low roofline trade practicality for performance; peak launch figures require specified conditions.']][i]
 v['strengths_tradeoffs_basis']='Specification-based comparisons/inference, not our driving test. Sources: current AU PDF/range and live maker NSW calculator; packaging secondary marked Reported.'
r['seven_currently_listed_shape_records']=[]
for v in r['current_versions']:
 r['seven_currently_listed_shape_records'].append(dict(name=v['exact_version'],body_shape='four-door GT sedan',current_listed_C1=True,on_sale_eligible=True,price=v['fields']['price'],source_ids=['gt-range','electric-vehicles-index','gt-my26-spec']))
for name,src,hist in [('Q8 e-tron','q8-suv',[{'version':'Q8 50 e-tron','amount':140600,'date':'2024-06-06','source_id':'sq8-launch'},{'version':'Q8 55 e-tron Launch Edition','amount':165900,'date':'2023-10-19','source_id':'q8-launch-edition'}]),('Q8 Sportback e-tron','q8-sportback',[]),('SQ8 e-tron','sq8-suv',[{'version':'SQ8 e-tron','amount':173600,'date':'2024-06-06','source_id':'sq8-launch'}]),('SQ8 Sportback e-tron','sq8-sportback',[{'version':'SQ8 Sportback e-tron','amount':180600,'date':'2024-06-06','source_id':'sq8-launch'}])]:
 r['seven_currently_listed_shape_records'].append(dict(name=name,body_shape='Sportback SUV' if'Sportback'in name else'SUV',current_listed_C1=True,on_sale_eligible=False,price=None,current_price_gap='No qualifying current new offer or exact New dealer ad; no current price ranked.',historical_prices=[dict(x,currency='AUD',basis='maker_launch_MLP_excludes_dealer_delivery_and_government_statutory_charges',status='historical_not_current') for x in hist],source_ids=[src,'electric-vehicles-index','calculator-current-variants'],census_note='Still listed in maker electric index and has a landing page, but page explicitly says no longer available to order. Residual-new eligibility not verified; current listed is not on-sale.'))
r['material_discrepancies']=[
 {'topic':'GT range protocol','maker':'Current AU page explicitly ADR81/02 for558/522/528km','secondary':'CarExpert launch review labels these same figures WLTP','resolution':'Use ADR81/02; no WLTP ranking'},
 {'topic':'S GT range','maker':'Current AU range558km; July2025 launch559km','resolution':'Current AU page558km'},
 {'topic':'RS launch power','maker':'Landing prose650kW conflicts own table630kW and current AU PDF630kW','resolution':'630kW launch,500kW normal'},
 {'topic':'GT DC interval','maker':'Landing body320kW10–80/18min but stale footnote270kW5–80','resolution':'Current AU PDF320kW and AU launch explicit10–80/18min ideal conditions; Check'},
 {'topic':'GT body measurements','maker':'AU current PDF/page omit exact AU length/height/boot; German specs give variable sizes','secondary':'Exact Australian CarExpert2026 pages report5004mm long,1964wide, heights S1402/RS1389/performance1402; S405L vs local review350L','resolution':'Secondary values Reported, visible and unranked; conflict noted'},
 {'topic':'GT prices','maker':'Dated launch209900/264900/309900 before delivery/statutory; liveNSWDA226708.80/284458.80/331708.80','secondary':'CarExpert current S209083/performance309083 alongside older values; inconsistent DA/exclusions footer','resolution':'Use live maker NSWDA as named-state rung; dated launchMLP supplemental only; do not derive fullMSRP from raw MLP plusLCT'},
 {'topic':'Q8 eligibility','maker':'Electric index still includes4bodies, landing pages say no longer orderable','secondary':'Carsales new category has to-order placeholders','resolution':'C1 listed true; on-sale/residual-new eligibility not established'},
 {'topic':'Q8 50 name','maker':'June2024 AU article introduction/headings call Q8 50; one paragraph erroneously says SQ8 50','resolution':'Q8 50 e-tron, never invent SQ8 50 variant'}]
r['search_log'][-1]['sources']=['gt-my26-spec','gt-range','gt-launch','gt-s-global-tech-correct','gt-rs-global-tech','gt-performance-global-tech','gt-carexpert-review','gt-carexpert-features','gt-s-carexpert-2026-exterior','gt-rs-carexpert-2026-exterior','gt-performance-carexpert-2026-exterior']
r['search_log'][-1]['result']='AU PDF/landing/launch and named global maker specs inspected, then exact AU secondary model pages. Dimensions/seats/boot and RS AC available Reported/unranked. Towing remains unknown after primary sources and secondary search: no exact current AU maker towing figure. S boot conflicting. Secondary source capture is web-rendered after direct403.'
p.write_text(json.dumps(r,indent=2))
# Validate source references recursively, including gap records.
def walk(x):
 if isinstance(x,dict):
  for k,v in x.items():
   if k in ['source_ids','sources'] and isinstance(v,list):
    for a in v:
     if isinstance(a,str) and a not in r['source_registry']:print('MISSING_SOURCE',a)
   else:walk(v)
 elif isinstance(x,list):
  for a in x:walk(a)
walk(r)
print('Current versions',len(r['current_versions']),'listed shapes',len(r['seven_currently_listed_shape_records']),'sources',len(r['source_registry']),'bytes',p.stat().st_size,'sha256',hashlib.sha256(p.read_bytes()).hexdigest())
