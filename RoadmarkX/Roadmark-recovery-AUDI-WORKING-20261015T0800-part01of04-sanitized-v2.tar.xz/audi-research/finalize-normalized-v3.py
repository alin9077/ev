from pathlib import Path
import json,copy,hashlib
R=Path('/tmp/audi-research');N=json.load(open(R/'normalized-review-v2.json'));V=N['variants']
def summary(v,a,b,ad,bd):v['summary']={'strength':{'label':a[0],'text':a[1],'dependencies':ad},'tradeoff':{'label':b[0],'text':b[1],'dependencies':bd}}
def supplement(v,key,value,src,basis,note,unit):
 v['extraFacts'][key]=dict(key=key,value=value,unit=unit,buyerGrade='reported',status='conditional',basis=basis,comparisonBasis='',sourceKeys=src,locator=note,evidenceScope='secondary_or_sibling',qualifications=[note],rankingEligible=False)
for v in V:
 c=v['coreFacts'];e=v['extraFacts'];vid=v['id'];future=v['formalModelYear']==2027;gt='etron_gt' in vid;q4='audi_q4_' in vid;sb='sportback' in vid;sport='sport_edition' in vid;sq=v['trim'].startswith('SQ')
 for z in [*c.values(),*e.values()]:
  if z['buyerGrade']=='reported':z['status']='conditional';z['evidenceScope']='secondary_or_sibling'
  if z['buyerGrade']=='not_published':z['evidenceScope']='searched_not_found'
  if z['key']=='price_aud' and z['priceEvidence']['rung']==4:z['priceEvidence']['state']='NSW'
 if not future and not gt and not sport and not sb and not sq:
  c['width_mm']['sourceKeys']=['au-q6-dimensions'];supplement(v,'reported_width_mm',1965,['rb-q6-my26-web'],'Reported MY26 width; mirror basis unstated','Exact RedBook MY26 record gives 1965 mm while current maker-linked quattro drawing gives 1939 mm; base applicability unresolved.','mm')
 if not future and not gt and not sb and sq:
  c['height_mm']['sourceKeys']=['au-sq6-dimensions'];supplement(v,'reported_height_mm',1675,['rb-q6-sq6-web'],'Reported MY26 height','Exact RedBook MY26 SQ6 SUV record says 1675 mm, differing from current maker-linked 1665 mm drawing.','mm')
 if future and not q4:
  c['dc_charge_time_min']['sourceKeys']=['au-q6-new'];supplement(v,'reported_dc_charge_time_min',21 if sq else None,['goauto-q6-my27'],'Reported MY27 DC 10–80% duration','GoAuto says 21 minutes for SQ6 and a little more than 20 minutes for base; no exact base number is synthesized.','min')
  if not sq:del e['reported_dc_charge_time_min']
 if sport and sb:c['price_aud']['sourceKeys']=['au-q6-new'];supplement(v,'reported_sport_driveaway_aud',95900,['ce-q6-my27','goauto-q6-my27'],'Reported MY26 sport edition driveaway','Australian reports say A$95,900 driveaway for both sport-edition bodies. Maker article has A$95,900/A$95,500 conflict and SUV-only legal terms.','AUD')
 if gt and v['trim']=='S e-tron GT':c['boot_l']['buyerGrade']='reported';c['boot_l']['status']='conditional';c['boot_l']['evidenceScope']='secondary_or_sibling';supplement(v,'reported_review_boot_l',350,['gt-gt-carexpert-review'],'Reported local review rear boot','Local Australian facelift review reports 350 L for S; database reports 405 L. No equipment adjustment inferred.','L')
 # Clean buyer-facing summaries depend only on populated, issue-free facts.
 price=c['price_aud']['value'];power=c['power_kw']['value'];net=c['battery_kwh']['value'];peak=c['dc_peak_kw']['value']
 if gt:
  summary(v,('Rapid normal-mode performance',f"{power} kW and a {c['zero_to_100_s']['value']}-second 0–100 km/h claim provide rapid performance without launch control."),('Six-figure purchase',f"The maker’s NSW driveaway estimate is A${price:,.2f}, before optional extras; the final dealer quote can vary."),['power_kw','zero_to_100_s'],['price_aud'])
 elif q4:
  perf='quattro' in v['trim']
  summary(v,('Quick compact quattro',f"The quattro performance pairs {power} kW with a claimed 5.4-second 0–100 km/h time.") if perf else ('Lower entry price',f"The announced A${price:,.0f} before-on-road price buys a {net} kWh net battery and {power} kW rear-drive powertrain."),('Higher-priced quattro',f"Its A${price:,.0f} list price excludes dealer delivery and government charges; the 150 kW grade is less expensive.") if perf else ('Smaller battery, rear drive',f"The base grade has a {net} kWh net battery and rear-wheel drive; the quattro adds battery capacity and AWD."),['power_kw','zero_to_100_s'] if perf else ['price_aud','battery_kwh','power_kw'],['price_aud'] if perf else ['battery_kwh','drive'])
 elif sport:
  summary(v,('Fast-charge hardware',f"The sport edition combines a {net} kWh net battery with a {peak} kW DC charging peak."),('Offer has limits','The A$95,900 SUV campaign excludes WA and requires an eligible private purchase and delivery by 31 October 2026.') if not sb else ('Rear-drive edition','This sport edition remains rear-wheel drive; buyers needing AWD should consider another grade.'),['battery_kwh','dc_peak_kw'],['price_aud'] if not sb else ['drive'])
 elif future:
  summary(v,('Lower announced price',f"The MY27 {v['trim']} is announced at A${price:,.0f} before on-road costs with a {net} kWh net battery."),('Rear-drive base','The base grade remains rear-wheel drive; buyers needing AWD should consider the SQ6.') if not sq else ('Premium purchase',f"Its A${price:,.0f} list price excludes dealer delivery and government charges, so budget beyond the headline figure."),['price_aud','battery_kwh'],['drive'] if not sq else ['price_aud'])
 else:
  summary(v,('Fast-charge hardware',f"A {peak} kW DC peak and {net} kWh net battery give this grade useful long-trip charging capability."),('Rear-drive base','This grade remains rear-wheel drive, with a smaller net battery than the SQ6.') if not sq else ('Premium purchase',f"The NSW maker driveaway estimate is A${price:,.2f}; confirm options and your final dealer quote."),['dc_peak_kw','battery_kwh'],['drive','battery_kwh'] if not sq else ['price_aud'])
N['status']='normalized proposal v3 frozen for independent review';p=R/'normalized-review-v3.json';p.write_text(json.dumps(N,indent=2,ensure_ascii=False)+'\n');print(hashlib.sha256(p.read_bytes()).hexdigest())
