from pathlib import Path
from datetime import datetime,timezone
import sys,json,hashlib,os
manifest_path=Path(sys.argv[1]); expected=sys.argv[2]
def digest(path):
 h=hashlib.sha256();n=0
 with Path(path).open('rb') as f:
  while b:=f.read(1024*1024):h.update(b);n+=len(b)
 return n,h.hexdigest()
def check(pin):
 assert digest(pin['path'])==(pin['bytes'],pin['sha256']),pin['path']
assert digest(manifest_path)[1]==expected
m=json.loads(manifest_path.read_text());repo=Path(m['repo']);assert str(repo)=='/workspace/scratch/586427eef9f2/roadmark-104'
assert m['automaticRetry'] is False and len(m['targets'])==13
assert len({x['relativePath'] for x in m['targets']})==13
out=manifest_path.parent/'application';assert not out.exists(), 'No retry or overwrite of application evidence is permitted'
for pin in m['unchangedPins']+m['provenancePins']+[m['applicationScript'],m['patch']]:check(pin)
for t in m['targets']:
 target=repo/t['relativePath'];assert target==Path(t['target']) and target.resolve().is_relative_to(repo.resolve()) and not target.is_symlink()
 assert t['operation'] in ['create','replace']; check(t['after'])
 if t['operation']=='create':assert t['before'] is None and not target.exists(),str(target)
 else:check(t['before']);check(t['beforeCopy']);assert t['before']['sha256']==t['beforeCopy']['sha256']
assert digest(manifest_path)[1]==expected
out.mkdir()
def now():return datetime.now(timezone.utc).isoformat()
def save(name,value):
 with (out/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
save('invocation.json',dict(at=now(),manifestSha256=expected,allBeforeGuardsPassed=True,targets=[x['relativePath'] for x in m['targets']],automaticRetry=False))
written=[]
try:
 for t in m['targets']:
  target=Path(t['target']); data=Path(t['after']['path']).read_bytes()
  if t['operation']=='create':
   assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True)
   with target.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
  else:
   check(t['before'])
   with target.open('wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
  assert digest(target)==(t['after']['bytes'],t['after']['sha256'])
  written.append(dict(relativePath=t['relativePath'],bytes=len(data),sha256=t['after']['sha256']))
 for pin in m['unchangedPins']+m['provenancePins']+[m['applicationScript'],m['patch']]:check(pin)
 assert digest(manifest_path)[1]==expected
 save('result.json',dict(at=now(),status='applied_exact_reviewed_bytes',manifestSha256=expected,written=written,unchangedPinsPassed=len(m['unchangedPins']),provenancePinsPassed=len(m['provenancePins']),automaticRetry=False))
 print(json.dumps(dict(status='applied_exact_reviewed_bytes',targetCount=len(written),result=str(out/'result.json'))))
except BaseException as e:
 save('failure.json',dict(at=now(),error=repr(e),written=written,automaticRetry=False,automaticRollback=False));raise
