from pathlib import Path
import json, hashlib, difflib
repo=Path('/workspace/scratch/586427eef9f2/roadmark-104'); out=Path('/tmp/audi-registration-bundle')
def stamp(p):
 b=p.read_bytes(); return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def add(rel,b):
 live=repo/rel; before=None; old=b''
 if live.exists():
  old=live.read_bytes(); before=stamp(live); prior=out/'before'/rel;prior.parent.mkdir(parents=True,exist_ok=True);prior.write_bytes(old)
 dst=out/'candidate'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b)
 targets.append(dict(relativePath=rel,target=str(live),operation='replace' if before else 'create',before=before,beforeCopy=stamp(out/'before'/rel) if before else None,after=stamp(dst)))
 patches.extend(difflib.unified_diff(old.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+rel if before else '/dev/null',tofile='b/'+rel))
targets=[];patches=[]
add('data/m1-brand-updates/audi-2026-10-15.json',Path('/tmp/audi-packet/v1/audi-2026-10-15.json').read_bytes())
add('data/m1-audi-market-reconciliation-2026-10-15.json',Path('/tmp/audi-split-proposal/fixtures/reconciliation.json').read_bytes())
r=Path(repo/'data/m1-brand-updates/registry.json'); registry=json.loads(r.read_text());assert len(registry['packets'])==24 and 'audi-2026-10-15.json' not in registry['packets'];registry['packets'].append('audi-2026-10-15.json');add(str(r.relative_to(repo)),(json.dumps(registry,indent=2)+'\n').encode())
add('scripts/reporting/m1-reconciliation.ts',Path('/tmp/audi-split-proposal/scripts/reporting/m1-reconciliation.ts').read_bytes())
r=repo/'scripts/reporting/load.ts';s=r.read_text();a='import skodaReconciliation from "../../data/m1-skoda-market-reconciliation-2026-10-15.json";';b='      skodaReconciliation as M1MarketReconciliation,';assert s.count(a)==1 and s.count(b)==1;s=s.replace(a,a+'\nimport audiReconciliation from "../../data/m1-audi-market-reconciliation-2026-10-15.json";').replace(b,b+'\n      audiReconciliation as M1MarketReconciliation,');add(str(r.relative_to(repo)),s.encode())
manifest=dict(schemaVersion=1,status='partial_core_preparation_pending_adapted_tests_and_exact_review',repo=str(repo),targets=targets,scope='Audi packet and inventory reconciliation, exact registry/load append, unchanged accepted inventory-only split helper; adapted behavioral tests will be added before final freeze',fullstageAcceptance=stamp(Path('/tmp/audi-review/full-stage-v1-result-acceptance.json')),fullstageReceipt=stamp(Path('/tmp/audi-packet/full-stage-v1/output/stage-receipt.json')),productionRegistrationAuthorized=False,automaticRetry=False)
(out/'core-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'core-registration.patch').write_text(''.join(patches));print(json.dumps(dict(targets=len(targets),manifest=stamp(out/'core-manifest.json'),patch=stamp(out/'core-registration.patch')),indent=2))
