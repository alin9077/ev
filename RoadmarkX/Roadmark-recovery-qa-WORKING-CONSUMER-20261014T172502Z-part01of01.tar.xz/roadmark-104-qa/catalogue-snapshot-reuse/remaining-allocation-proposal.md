# Remaining allocation findings

Status: read-only proposal, unimplemented. No production files, data, guards or types changed. This is not a proven explanation or cure for signal9. Further optimization is deferred while Subaru evidence/staging proceeds; release gates remain unchanged.

## What is established

- In the ordinary single-process production module graph, each large additions, identity, proposal, regrading and brand-packet JSON file has one loader. I found no static-import/runtime-read duplicate of those same large files. sourceResearch's2.04MB original input is per-call; the current snapshot already reuses one such load.
- Independently stored expected identities and source facts contain related material, but the identity resolver references existing expected snapshots rather than cloning the entire ledger. Deduplicating those evidence stores would be a larger, unjustified change.
- Catalogue construction retains source and effective views during transformation. Array copies and most car wrappers share nested values; variable scope alone does not prove that V8 keeps an intermediate live after its last use. No quantified saving is established by rewriting const bindings.
- applyCorrections deep-clones facts, even without an active correction. That also provides input isolation; removing it is not a justified identity-preserving change.
- prepareBrandResearch clones historical configuration context to preserve source guards. Removing that isolation is likewise unjustified.

## Deferred candidate

src/lib/correction-guards.ts: assertReviewedJson calls canonical and discards its complete recursively cloned/sorted graph. brand-updates.ts invokes that assertion for each packet during orderedPackets, at research preparation, catalogue application and updated-feature reads. The largest registered packet, Hyundai, is18,134,105 serialized bytes. This establishes repeated throwaway graph construction, not its measured peak heap cost.

A validation-only traversal is equivalent on ordinary, immediately JSON.parse-created data if it preserves all scalar checks and visits every field. However, the exported assertion accepts unknown objects. Existing canonical behavior includes object getter evaluation before undefined-property filtering and key sorting, actual array.map dispatch, ancestor-cycle detection and dense-array checks. A generic replacement can change getters, proxies, array subclasses/overrides, exception wording or exception order. A proxy-gated fast path would add disproportionate complexity and is not approved.

## Why a parse-boundary-only change is insufficient now

brand-update-registry.ts currently parses packets and exports mutable BrandUpdatePacket objects; it does not call assertReviewedJson there. The expensive assertions occur later. prepareBrandResearch, applyBrandUpdates and applyBrandFeatureUpdates also accept caller-supplied packets. Mutation-oriented tests deliberately alter facts, sources, features, availability and configuration between applications.

Consequently, adding ordinary-JSON validation immediately after JSON.parse would not remove an existing heavy assertion. Skipping later checks based solely on the earlier parse would assume continued immutability that the current API does not enforce. No boundary-only optimization is presently justified without a separately reviewed contract change.

## Tests if revisited

- Compare old and proposed outcomes on every registered packet, loaded one at a time in a low-dependency standalone harness
- Test JSON.parse-produced deep arrays/objects, all scalar types, null, negative zero, Unicode, numeric-looking keys and own __proto__ keys; include overflow JSON numbers such as1e400, which parse to nonfinite values and must still fail
- Keep exported canonical strings/comparisons and correction validation unchanged; retain all generic cycle, shared-reference, sparse-array, prototype, undefined and mutation guards
- Require full catalogue/research/pack equality and measured resource results before making any completion or performance claim
