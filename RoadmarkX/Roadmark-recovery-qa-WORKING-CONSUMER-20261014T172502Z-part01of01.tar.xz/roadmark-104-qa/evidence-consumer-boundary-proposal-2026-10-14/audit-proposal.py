from pathlib import Path
import json,re,os,hashlib
root=Path('/workspace/scratch/586427eef9f2/roadmark-104');out=Path(__file__).parent
files={str(p.relative_to(root)):p.read_text() for d in ['src','scripts','tests'] for p in (root/d).rglob('*') if p.is_file() and p.suffix in ['.ts','.tsx','.js','.mjs','.cjs']}
for p in (out/'proposed').rglob('*'):
 if p.is_file():files[str(p.relative_to(out/'proposed'))]=p.read_text()
def imports(s):
 for m in re.finditer(r'^import\s+(?!\()([^;]+);|^export\s+((?:type\s+)?(?:\{[^}]*\}|\*)\s+from\s+[^;]+);',s,re.M):
  text=(m.group(1) or m.group(2)).strip()
  path=re.search(r'(?:from\s*)?[\"\x27]([^\"\x27]+)[\"\x27]\s*$',text)
  if not path:continue
  bindings=text[:path.start()].strip()
  if bindings.endswith('from'):bindings=bindings[:-4].strip()
  typeonly=bindings.startswith('type ')
  if bindings.startswith('{') and bindings.endswith('}'):
   names=[x.strip() for x in bindings[1:-1].split(',') if x.strip()]
   typeonly=bool(names) and all(x.startswith('type ') for x in names)
  yield path.group(1),typeonly,s[:m.start()].count('\n')+1,bindings

def resolve(origin,spec):
 if spec.startswith('@/'):name='src/'+spec[2:]
 elif spec.startswith('.'):name=os.path.normpath(str(Path(origin).parent/spec))
 else:return None
 choices=[name,name+'.ts',name+'.tsx',name+'.js',name+'.mjs',name+'/index.ts',name+'/index.tsx']
 if name.endswith('.js'):choices += [name[:-3]+'.ts',name[:-3]+'.tsx']
 return next((n for n in choices if n in files or (root/n).is_file()),'UNRESOLVED:'+name)
edges=[]
for name,s in files.items():
 for spec,typ,line,bindings in imports(s):edges.append({'from':name,'to':resolve(name,spec),'specifier':spec,'typeOnly':typ,'line':line,'bindings':bindings})
graph={n:[e['to'] for e in edges if e['from']==n and e['to'] and not e['typeOnly']] for n in files}
def closure(start):
 seen=set();todo=[start]
 while todo:
  node=todo.pop()
  if node in seen:continue
  seen.add(node);todo+=graph.get(node,[])
 return sorted(seen)
light=closure('src/lib/evidence-consumers.ts');broad=closure('src/lib/data.ts')
assert 'src/lib/data.ts' not in light
# Detect cycles reachable from either production entry point without executing modules.
cycles=[];active=[];done=set()
def visit(n):
 if n in active:
  cycles.append(active[active.index(n):]+[n]);return
 if n in done:return
 active.append(n)
 for c in graph.get(n,[]):visit(c)
 active.pop();done.add(n)
visit('src/lib/data.ts')
assert not cycles,cycles
staticjson=[n for n in light if n.endswith('.json')]
registry=json.loads((root/'data/m1-brand-updates/registry.json').read_text())
dynamic=['data/m1-evidence-regrading-2026-10-13.json','data/m1-brand-updates/registry.json']+['data/m1-brand-updates/'+n for n in registry['packets']]
inputs=[{'path':p,'bytes':(root/p).stat().st_size,'loading':'static import' if p in staticjson else 'existing module fs/JSON.parse'} for p in sorted(set(staticjson+dynamic))]
# A complete line inventory, not an AST top-level-call classifier.
consumers={}
for e in edges:
 if e['to']=='src/lib/data.ts':consumers.setdefault(e['from'],[]).append(e)
call_inventory=[]
for p,es in consumers.items():
 s=files[p]
 names=set()
 for e in es:
  for public in ['pack','effectiveFeatures','sourceEffectiveFeatures','readableValue']:
   m=re.search(r'\b'+public+r'(?:\s+as\s+(\w+))?',e['bindings'])
   if m:names.add(m.group(1) or public)
 calls=[]
 for i,line in enumerate(s.splitlines(),1):
  if any(re.search(r'\b'+re.escape(n)+r'\s*\(',line) for n in names):calls.append({'line':i,'text':line.strip()})
 if names:call_inventory.append({'file':p,'names':sorted(names),'runtimeImport':any(not e['typeOnly'] for e in es),'insideDataDependencyClosure':p in broad,'calls':calls})
assert all(not item['insideDataDependencyClosure'] for item in call_inventory)
result={'status':'STATIC REVIEW ONLY; no code imported or tests run','auditMethod':'Anchored static import/re-export declarations across src/scripts/tests, excluding explicit type-only edges; dynamic-file loads manually traced in included modules. Not a TypeScript resolver or Next build proof. Call inventory is line-based, not an AST scope classifier.','authoredFilesInspected':len(files),'runtimeClosure':light,'typeOnlyEdgesFromClosure':[e for e in edges if e['from'] in light and e['typeOnly']],'runtimeEdgesFromClosure':[e for e in edges if e['from'] in light and not e['typeOnly']],'unresolvedRuntimeEdges':[e for e in edges if e['from'] in broad and e['to'] and e['to'].startswith('UNRESOLVED:') and not e['typeOnly']],'cyclesReachableFromData':cycles,'dataConsumers':call_inventory,'broadOnlyModules':[p for p in broad if p not in light and p in files],'consumerJsonInputs':inputs,'totalSerializedConsumerJsonBytes':sum(i['bytes'] for i in inputs),'notes':['Data consumers have no runtime back-edge into the data or evidence-consumer dependency closure. Existing top-level script/test calls occur only after successful module evaluation; no current cyclic early-call route found.','The type-only selling-points and brand-updates back references do not import runtime ledgers.','brand-update-registry and evidence-regrading retain their actual eager loaders. No resource-use improvement has been measured.']}
(out/'dependency-audit.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'static-import-edges.json').write_text(json.dumps(edges,indent=2)+'\n')
(out/'inspected-code-sha256.json').write_text(json.dumps([{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in sorted(set(broad+[i['file'] for i in call_inventory])) if p in files and (root/p).is_file()],indent=2)+'\n')
print(json.dumps({'authoredFiles':len(files),'runtimeModules':len([p for p in light if p in files]),'jsonFiles':len(inputs),'serializedJsonBytes':sum(i['bytes'] for i in inputs),'cycles':cycles,'unresolved':result['unresolvedRuntimeEdges'],'callsiteFiles':len(call_inventory),'broadOnlyModules':result['broadOnlyModules']}))
