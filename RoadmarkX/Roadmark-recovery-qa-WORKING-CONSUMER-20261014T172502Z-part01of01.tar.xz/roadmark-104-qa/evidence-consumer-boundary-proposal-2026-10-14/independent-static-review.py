"""Independent textual proposal review only: never imports application modules."""
import pathlib,hashlib,json,re,datetime
p=pathlib.Path(__file__).parent;r=p.parent.parent/'roadmark-104'
sha=lambda x:hashlib.sha256(x).hexdigest()
a=(p/'before/src/lib/data.ts').read_text();b=(p/'proposed/src/lib/evidence-consumers.ts').read_text();d=(p/'proposed/src/lib/data.ts').read_text()
assert (r/'src/lib/data.ts').read_bytes()==(p/'before/src/lib/data.ts').read_bytes(),'Proposal unexpectedly applied before approval'
ranges=[('firstFeatureIndex','function firstFeatureIndex','// Imported overlays','function firstFeatureIndex','// Imported overlays'),('applies','function applies','function buildSourceCatalogue','export function applies','const months'),('tidy','function tidy','function evidenceLabel','function tidy','function evidenceLabel'),('evidenceLabel','function evidenceLabel','function categoryLabel','function evidenceLabel','function categoryLabel'),('categoryLabel','function categoryLabel','export function readableValue','function categoryLabel','export function readableValue'),('readableValue','export function readableValue','/** One effective equipment pipeline','export function readableValue','export function effectiveFeaturesFromRows'),('sourceEffectiveFeatures','export function sourceEffectiveFeatures','export function effectiveFeatures(','function sourceEffectiveFeatures','function effectiveFeatures('),('effectiveFeatures','export function effectiveFeatures(','function effectiveFeaturesFromRows','function effectiveFeatures(','/** A build-scoped snapshot'),('effectiveFeaturesFromRows','function effectiveFeaturesFromRows','/** A build-scoped snapshot','export function effectiveFeaturesFromRows','/** Bind existing loaders once'),('pack','export function pack(','export function counts','function pack(','return { sourceEffectiveFeatures, effectiveFeatures, pack };')]
results=[]
for name,astart,aend,bstart,bend in ranges:
 x=a[a.index(astart):a.index(aend,a.index(astart))].strip();y=b[b.index(bstart):b.index(bend,b.index(bstart))].strip();x=re.sub(r'^export ','',x);y=re.sub(r'^export ','',y)
 assert x==y,name;results.append(dict(name=name,bytes=len(x.encode()),sha256=sha(x.encode()),completeDeclarationIncludingDefaultsEqualExceptExportModifier=True))
for name,start,end in [('sourceResearch','export const sourceResearch','const descriptors ='),('sourceCatalogue','function buildSourceCatalogue','export type CatalogueSnapshot'),('snapshot','export const catalogueSnapshot','const months =')]:
 x=a[a.index(start):a.index(end,a.index(start))].strip()
 if name=='sourceCatalogue':y=d[d.index(start):d.index('/** One fresh, caller-scoped load;',d.index(start))].strip()
 elif name=='snapshot':y=d[d.index(start):d.index('export const { sourceEffectiveFeatures',d.index(start))].strip()
 else:y=d[d.index(start):d.index(end,d.index(start))].strip()
 assert x==y,name;results.append(dict(name=name,bytes=len(x.encode()),sha256=sha(x.encode()),completeBlockEqual=True))
# Exact original runtime import sequence plus one new edge; explicit type-only edges excluded.
def runtime_imports(s):
 return [m.group(1) or m.group(2) for m in re.finditer(r'''^import\s+(?!type\b)(?:\{[^}]*\}|[\w*$, \n]+)\s+from\s+["']([^"']+)["'];|^import\s+["']([^"']+)["'];''',s,re.M)]
assert runtime_imports(d)==runtime_imports(a)+['./evidence-consumers']
assert 'createEvidenceConsumers({ sourceResearch, research, catalogue });' in d
assert d.index('export const catalogue =')<d.index('export const { sourceEffectiveFeatures')
assert 'from "react"' not in b and 'from "./data"' not in b
for unwanted in ['catalogue-additions','buyer-proposal','retained-fact-fills']:
 assert unwanted not in b
changed=json.loads((p/'changed-files.json').read_text());rows=[]
for row in changed['files']:
 f=row['path'];proposed=(p/'proposed'/f).read_bytes();assert sha(proposed)==row['proposedSha256']
 if row['beforeSha256'] is not None:
  original=(p/'before'/f).read_bytes();assert sha(original)==row['beforeSha256'];assert (r/f).read_bytes()==original
 else:assert not (r/f).exists()
 rows.append(dict(path=f,beforeSha256=row['beforeSha256'],proposedSha256=sha(proposed)))
assert {x['path'] for x in rows}=={'src/lib/data.ts','src/lib/evidence-consumers.ts','tests/brand-updates.test.ts','tests/brand-feature-updates.test.ts','tests/catalogue-snapshot.test.ts'}
audit=json.loads((p/'dependency-audit.json').read_text());assert not audit['cyclesReachableFromData'];assert not audit['unresolvedRuntimeEdges']
for name in audit['runtimeClosure']:
 if not name.endswith('.ts'):continue
 f=(p/'proposed'/name) if (p/'proposed'/name).exists() else r/name
 assert not re.search(r'\brequire\s*\(|\bimport\s*\(|\beval\s*\(|\bnew Function\b|from ["\'].*[/]data["\']',f.read_text()),('Unreviewed dynamic/back edge',name)
out=dict(status='approved_for_root_decision_on_application_and_focused_tests',checkedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),mode='Independent static review only; no production import, application, test or typecheck',proposalSha256=sha((p/'proposal.patch').read_bytes()),reviewScriptSha256=sha(pathlib.Path(__file__).read_bytes()),files=rows,comparisons=results,originalRuntimeImportSequencePreserved=True,consumerRuntimeClosureHasNoDataBackEdge=True,defaultsAndCacheBodiesPreserved=True,fixtureOverrideWiringReviewed=True,noExistingTestAssertionsRemoved=True,limitations=['Runtime import graph audit is textual, not a bundler build proof','Exported functions become const bindings: TDZ, module-init stacks and Function.toString location can differ; no current cyclic early caller was found','New lightweight entry intentionally omits unrelated catalogue import-time errors; public data entry preserves original dependency order','TypeScript signatures are textually identical but current full project typecheck remains open','No memory improvement measured'],requiredNext=['Focused default order, explicit snapshot, names/arity, error/source/feature guard and request-cache tests','Exact original 621 Subaru feature rows and 14 Polestar full packs/portable parity','All 397 actual feature sets and full dated reports','Explicit source-transition pins preserving all historical baseline receipts'],acceptedDerivedBaseline=False,freshLoaderValidation=False)
with (p/'independent-static-approval.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({'status':out['status'],'proposalSha256':out['proposalSha256'],'comparisons':len(results),'changedFiles':len(rows)}))
