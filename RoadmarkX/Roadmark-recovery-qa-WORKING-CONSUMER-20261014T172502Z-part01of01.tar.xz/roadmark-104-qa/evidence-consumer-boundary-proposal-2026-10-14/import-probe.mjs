import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { syncBuiltinESMExports, createRequire } from 'node:module';
import { pathToFileURL, fileURLToPath } from 'node:url';
const root = process.cwd();
const output = path.join(path.dirname(fileURLToPath(import.meta.url)), 'import-probe-result.json');
const readFileSync = fs.readFileSync;
const reads = [];
const forbidden = [
  'catalogue-additions-2026-10-10.json', 'buyer-selling-points-2026-10-10.json',
  'buyer-identity-snapshots-2026-10-10.json', 'm1-retained-fact-fills-2026-10-13.json',
  'au_ev_all_variants_2026-10-06.json',
];
fs.readFileSync = function (file, ...args) {
  const name = typeof file === 'number' ? `fd:${file}` : file instanceof URL ? fileURLToPath(file) : String(file);
  reads.push(path.relative(root, path.resolve(name)));
  if (forbidden.some((part) => name.endsWith('/' + part))) throw new Error(`Forbidden unrelated ledger read: ${name}`);
  return readFileSync.call(this, file, ...args);
};
syncBuiltinESMExports();
console.log(JSON.stringify({ stage: 'start', memory: process.memoryUsage() }));
const loaded = await import(pathToFileURL(path.join(root, 'src/lib/evidence-consumers.ts')).href);
const boundary = loaded.createEvidenceConsumers ? loaded : loaded.default;
const unexpected = () => { throw new Error('Import or factory called a default loader'); };
const consumer = boundary.createEvidenceConsumers({ sourceResearch: unexpected, research: unexpected, catalogue: unexpected });
assert.equal(consumer.pack.name, 'pack');
assert.equal(consumer.pack.length, 2);
const required = JSON.parse(readFileSync.call(fs, path.join(root, 'data/m1-brand-updates/registry.json'), 'utf8')).packets;
const jsonReads = [...new Set(reads.filter((name) => name.endsWith('.json') && name.startsWith('data/')))].sort();
for (const name of [
  'data/m1-evidence-regrading-2026-10-13.json', 'data/m1-brand-updates/registry.json',
  'data/approved-feature-corrections.json', 'data/research-refresh-2026-10-10.json',
  'data/research-buyer-2026-10-07.json', 'data/research-completion-2026-10-07.json',
  'data/research-editorial-2026-10-07.json', 'data/research-refinement-2026-10-06.json',
  'data/research-usability-2026-10-06.json', 'data/source-audit-2026-10-08.json',
  ...required.map((name) => 'data/m1-brand-updates/' + name),
]) assert(jsonReads.includes(name), `Required actual input was not observed: ${name}`);
const require = createRequire(path.join(root, 'package.json'));
const loadedModules = Object.keys(require.cache).filter((name) => name.startsWith(path.join(root, 'src/lib/'))).map((name) => path.relative(root, name)).sort();
for (const name of ['data.ts', 'catalogue-additions.ts', 'buyer-proposal.ts', 'buyer-proposal-storage.ts', 'retained-fact-fills.ts'])
  assert(!loadedModules.includes('src/lib/' + name), `Unrelated module loaded: ${name}`);
fs.readFileSync = readFileSync;
syncBuiltinESMExports();
const result = { status: 'PASS', route: 'Fresh Node + tsx, real production consumer import; no calls to catalogue/research or evidence functions', tsxDisableCache: process.env.TSX_DISABLE_CACHE, forbiddenLedgerReads: [], actualJsonReads: jsonReads, loadedModules, factoryDefaultsCalled: false, memory: process.memoryUsage(), resourceUsage: process.resourceUsage() };
fs.writeFileSync(output, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ stage: 'complete', jsonInputs: jsonReads.length, memory: result.memory }));
