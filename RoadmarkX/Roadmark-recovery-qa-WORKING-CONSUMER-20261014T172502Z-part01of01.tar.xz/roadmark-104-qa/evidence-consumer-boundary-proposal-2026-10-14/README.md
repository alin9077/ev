# Evidence-consumer boundary: review-only proposal

Status: **not applied, compiled, or tested**. No production source, data, packet, configuration, or hero changes have been made. This proposal is separate from the pinned core-oracle proof. A smaller dependency graph is credible; successful completion or lower peak memory is not yet established, and prior SIGKILL causes remain unproven.

## Proposed scope

`proposal.patch` adds `src/lib/evidence-consumers.ts`, replaces moved implementation in `src/lib/data.ts` with imports/factory binding, and adjusts dependency injection in three existing fixture loaders. `proposed/` contains complete proposed files; `before/` holds unchanged inputs. No assertion is removed. The nested functions intentionally retain their original whitespace so hashes compare actual bytes, not normalized formatting.

The factory accepts the existing `sourceResearch`, `research`, and `catalogue` functions. `data.ts` binds it once, after those three cached entry points have been initialized, and exports the returned named `sourceEffectiveFeatures`, `effectiveFeatures`, and `pack` functions. The factory calls none of the supplied defaults during construction. It neither caches results nor takes a pretrusted Research object. `readableValue` remains available from `data.ts` through a re-export. `CatalogueSnapshot` moves as an identical structural type and is re-exported from the old path.

An explicit-snapshot caller imports only `createEvidenceConsumers` and types from the new module. It can supply throwing fallback callbacks and pass the already verified data/cars on every call. This invokes the actual unchanged production functions without importing `data.ts`. It does not validate snapshot provenance on the caller's behalf: provenance must come from the independently approved capture/derivation, while every existing feature/correction/packet/pack guard still runs. The broader public loader and release gates remain required.

## Exact moves and dependencies

Moved declarations, without body or default-expression edits:

- `buyerKeys`, `featureKey`, `firstFeatureIndex`, and the completion/usability/refinement/editorial feature indexes
- `applies`, shared with source-catalogue fact/issue construction
- `months`, `tidy`, `evidenceLabel`, `categoryLabel`, `readableValue`
- `sourceEffectiveFeatures`, `effectiveFeatures`, `effectiveFeaturesFromRows`, and `pack`

`featureKey`, `applies`, and `effectiveFeaturesFromRows` become internal module exports used directly by `data.ts`; there is one implementation of each. The full `buildSourceCatalogue` body stays byte-identical and still invokes the shared row helper at the same point. `body-hashes.json` records all ten moved callable bodies, complete declaration ranges (only `export` modifiers normalized), and the unchanged source-catalogue body. `sourceResearch`, request caches, catalogue snapshot stages, counts, and picker logic are not rewritten.

Direct runtime dependencies of the new module:

- `brand-updates`: `applyBrandTermFeatures`, `applyBrandFeatureUpdates`
- `brand-update-registry`: the actual registered packet array
- `evidence-regrading`: actual `applyFeatureRegrading` and unchanged module-loaded ledger
- `configuration-evidence`: `configurationSourceIds`
- `research-refresh`: `refreshFeatures`, plus the same refresh JSON
- `feature-corrections`: `validateFeatureCorrectionRegistry`, `applyFeatureCorrections`, plus the same approved-feature-corrections JSON
- `config`: `safeUrl`
- the same refinement, usability, completion, editorial, and buyer JSON overlays
- `launch-evidence`: `auditedFeature`, retaining its source-audit JSON

Type-only dependencies are `Research`, `Car`, `Feature`, `Pack`, `Variant`, `ResearchRefresh`, and `FeatureCorrection`. Transitive runtime dependencies, all listed in `dependency-audit.json`, are availability-corrections, brand-configuration-updates, corrections, correction-guards, evidence-grading, evidence-regrade-policy, price-ladder, fact-validity, and freshness. The price-ladder's three JSON inputs remain loaded through `brand-updates`. Native runtime dependencies include fs/path/crypto; this remains server/build code.

The proposed consumer closure has 18 local runtime code modules and 30 JSON inputs totaling 64,749,886 serialized bytes, including the complete current packet registry and regrading ledger. Those are file sizes, not heap measurements. It excludes catalogue additions (74,934,307 bytes), buyer proposal (24,074,749), buyer identity ledger (54,962,382), and retained fact fills (1,002,595), as well as catalogue-construction modules. No guards or packet fields are stripped to obtain that boundary.

## Public semantics and limits

- Omitted/undefined feature data still invokes `sourceResearch()` or `research()` exactly once as before; explicit data invokes neither fallback. Null remains distinct from undefined and is not silently accepted.
- `pack` still evaluates data first (`snapshot?.data ?? research()`), then cars (`snapshot?.cars ?? catalogue()`), then finds the car, then throws `Unknown variant` before feature processing if absent. An explicit complete snapshot invokes no default. Untyped partial/null snapshots retain the existing optional-chain/nullish-fallback order.
- The historical feature-context selection, warning reconstruction, overlay precedence, source feature filter, correction-registry validation, refresh/correction order, regrading, required Tier 1 packet guard, and term inheritance are unchanged.
- Pack events/configuration selection, source collection, missing-source exception order/text, safe-URL projection, reference reuse, and final property order are unchanged. No extra clone, freeze, global cache, skipped guard, or freshness assumption is introduced.
- All existing React cache wrappers remain in `data.ts`, including the private source-identity caches. The factory captures those same function objects. Within-request sharing remains their responsibility; outside a request React cache remains the existing CLI no-op. Consumer calls remain uncached, observing caller-owned input mutations as before.
- The three public consumer exports change from function declarations to const bindings of same-named functions. Their signatures and expected `name`/`length` remain the same (`sourceEffectiveFeatures`: 1, `effectiveFeatures`: 1, `pack`: 2); declaration hoisting/TDZ and source locations differ. Stack locations and transpiler-specific function representations are not promised byte-identical. A future runtime cycle calling an export before initialization would need reevaluation.
- A static whole-repository import audit covers 356 authored code files and 60 moved-consumer importing files. No runtime cycle, unresolved relative edge, or data-consumer back-edge into the affected runtime dependency closure was found. Existing script/test top-level calls therefore occur after successful data-module evaluation. The audit is lexical and manually checked, not a compiler/build proof; its call inventory is line-based rather than an AST scope classifier.
- The original `data.ts` runtime import sequence is retained exactly, followed by the new module (`import-order-check.json`). Moved-only dependencies remain original-order side-effect imports there, avoiding a needless change to which malformed module input fails first. Ordinary module deduplication prevents reparsing the same inputs. The new standalone entry point intentionally does not load unrelated catalogue inputs; it cannot substitute for validating those inputs.

## Repository and installed Next constraints

Read `AGENTS.md`, `docs/DOT-BRIEF-103.md`, and the installed Next 16.3.8 guides before design. The data-fetching guide's “Reusing data with React.cache” section specifies per-request memoization without cross-request sharing. No cache directives or new cache layers are proposed.

The output guide states that Next traces imports/requires/fs usage, with includes resolved from the project root. Existing fs loaders and all `next.config.ts` outputFileTracingIncludes paths stay unchanged. The new module remains under src/lib and introduces no external runtime files. Actual build/trace verification remains required. The Server/Client Components guide describes optional server-only poisoning; no marker package/import is added, to avoid changing the existing standalone Node/tsx route. This new entry point must not be imported into a client component.

## Focused tests required before application can be accepted

1. Extend the three existing direct-source fixtures to compile the real new module with the same override object, then inject it as `./evidence-consumers`. The patch includes only this mock plumbing in brand-updates, brand-feature-updates, and catalogue-snapshot tests. `compiledSource` overrides are not recursive; omitting this step would incorrectly mix real packets/overlays into fixtures. Keep all existing assertions and malformed-data coverage.
2. Compare old and proposed consumer behavior with identical small fixtures: successful full output/reference reuse; named-function arities; omitted/undefined/null data; complete/partial/missing snapshots; unknown IDs; throwing research/catalogue callbacks; and exact callback/error ordering. Use throwing fallback callbacks to prove the explicit-snapshot path never loads source/research/catalogue.
3. Exercise source-context reconstruction, first-match duplicate rows and completion > usability > refinement precedence, buyer/editorial rows, full-registry ambiguity rejection, historical configuration context, duplicate/missing sources, refresh/correction failures, source drift, feature-before/dependency drift, Tier 1 required marker, packet mutation between calls, safe/unsafe URL handling, and pack missing configuration/claim source errors. Preserve all existing guard suites.
4. Retain the 25 existing snapshot tests, including same-request sharing in each caller order, fresh subsequent requests, CLI freshness, input immutability, counts/report reuse, and validation's malformed-issue failure before pack access. Assert sourceCatalogue uses the actual imported row helper and does not call the factory defaults.
5. In a fresh isolated process, import only the new entry point; observe actual file reads/imports and prove no catalogue-additions, buyer-proposal/identity, retained-fill, or original-source read. Confirm the real packet, regrade, refresh, correction, and overlay inputs do load. This is dependency-boundary verification, not a replacement for source validation.
6. After explicit approval/application/source freeze and full input manifests, compare every row/field of all effective/source features and all packs on the same independently verified 397-car snapshot against the approved pre-refactor reference. Check input hashes/immutability before and after, use the same explicit as-of date, and preserve terminal receipts. Do not relabel an interrupted export, body hashes, or a reconstructed oracle as a fresh full-loader pass.
7. Run focused lint/type checks and behavioral suites, then unchanged aggregate validation/report/build gates when the coordinated resource slot permits. Standard full typecheck and all other blocked release gates remain unverified until they actually complete. Measure before/after fresh process resource usage; do not infer a cure from smaller serialized dependencies.

## Artifacts and provenance

`changed-files.json` pins original/proposed bytes and records review-only status. `inspected-code-sha256.json` pins existing code used by the dependency review, not a full runtime execution manifest. `static-import-edges.json` and `dependency-audit.json` provide dependency and caller inventories. The original runtime import order and unchanged source bytes were checked textually only. No module was imported, compiler invoked, test run, or catalogue hydrated to produce this proposal.
