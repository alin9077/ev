from pathlib import Path
import hashlib, json, difflib, re, datetime
root=Path('/workspace/scratch/586427eef9f2/roadmark-104')
out=Path(__file__).parent
src=(root/'src/lib/data.ts').read_text()
sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
original_hash=sha(src)
def section(a,b):
 return src[src.index(a):src.index(b)]
indexes=section('/** Rows added for buyer questions', '/** Immutable imported overlays')
applies=section('function applies(', 'function buildSourceCatalogue(')
formatters=section('const months =', '/** One effective equipment pipeline')
source_effective=section('/** One effective equipment pipeline', 'export function effectiveFeatures(')
effective=section('export function effectiveFeatures(', '\nfunction effectiveFeaturesFromRows(').rstrip()+'\n'
rows=section('function effectiveFeaturesFromRows(', '/** A build-scoped snapshot')
pack=section('/** A build-scoped snapshot', 'export function counts(')
consumer_imports='''/** Server/build evidence consumers; no catalogue construction or persistent derived cache. */
import { applyBrandTermFeatures, applyBrandFeatureUpdates } from "./brand-updates";
import { brandUpdatePackets } from "./brand-update-registry";
import { applyFeatureRegrading } from "./evidence-regrading";
import { configurationSourceIds } from "./configuration-evidence";
import refreshEdits from "../../data/research-refresh-2026-10-10.json";
import { refreshFeatures, type ResearchRefresh } from "./research-refresh";
import featureCorrections from "../../data/approved-feature-corrections.json";
import {
  applyFeatureCorrections,
  validateFeatureCorrectionRegistry,
  type FeatureCorrection,
} from "./feature-corrections";
import type { Research, Car, Feature, Pack, Variant } from "./types";
import { safeUrl } from "./config";
import refinement from "../../data/research-refinement-2026-10-06.json";
import usability from "../../data/research-usability-2026-10-06.json";
import completion from "../../data/research-completion-2026-10-07.json";
import editorial from "../../data/research-editorial-2026-10-07.json";
import buyer from "../../data/research-buyer-2026-10-07.json";
import { auditedFeature } from "./launch-evidence";

export type CatalogueSnapshot = { data: Research; cars: Car[] };
export type EvidenceConsumerDefaults = {
  sourceResearch: () => Research;
  research: () => Research;
  catalogue: () => Car[];
};

'''
consumer=(consumer_imports+indexes.replace('const featureKey =','export const featureKey =')+'\n'+applies.replace('function applies(', 'export function applies(',1)+'\n'+formatters+'\n'+rows.replace('function effectiveFeaturesFromRows(', 'export function effectiveFeaturesFromRows(',1)+'''/** Bind existing loaders once; supplied data/snapshots never invoke these defaults. */
export function createEvidenceConsumers({
  sourceResearch,
  research,
  catalogue,
}: EvidenceConsumerDefaults) {
'''+source_effective.replace('export function ', 'function ',1)+effective.replace('export function ', 'function ',1)+'\n'+pack.replace('export function ', 'function ',1)+'''return { sourceEffectiveFeatures, effectiveFeatures, pack };
}
''')
data=src
replacements=[
('import { prepareBrandResearch, applyBrandUpdates, applyBrandTermFeatures, applyBrandFeatureUpdates } from "./brand-updates";', 'import { prepareBrandResearch, applyBrandUpdates } from "./brand-updates";'),
('import { applyEvidenceRegrading, applyFeatureRegrading } from "./evidence-regrading";', 'import { applyEvidenceRegrading } from "./evidence-regrading";'),
('import { configurationSourceIds } from "./configuration-evidence";\n','// Preserve this entry point\'s original dependency evaluation order.\nimport "./configuration-evidence";\n'),
('  refreshFeatures,\n',''),
('import featureCorrections from "../../data/approved-feature-corrections.json";\n','import "../../data/approved-feature-corrections.json";\n'),
('import {\n  applyFeatureCorrections,\n  validateFeatureCorrectionRegistry,\n  type FeatureCorrection,\n} from "./feature-corrections";\n','import "./feature-corrections";\n'),
('import type { Research, Car, Fact, Feature, Pack, Variant } from "./types";', 'import type { Research, Car, Fact, Feature, Variant } from "./types";'),
('import { safeUrl } from "./config";\n','import "./config";\n'),
('import { auditedSource, auditedFact, auditedFeature } from "./launch-evidence";', '''import { auditedSource, auditedFact } from "./launch-evidence";
import {
  applies,
  createEvidenceConsumers,
  effectiveFeaturesFromRows,
  featureKey,
  type CatalogueSnapshot,
} from "./evidence-consumers";
export { readableValue } from "./evidence-consumers";
export type { CatalogueSnapshot } from "./evidence-consumers";'''),
(indexes,''), (applies,''),
('export type CatalogueSnapshot = { data: Research; cars: Car[] };\n',''),
(src[src.index('const months ='):src.index('export function counts(')],'''export const { sourceEffectiveFeatures, effectiveFeatures, pack } =
  createEvidenceConsumers({ sourceResearch, research, catalogue });

''')]
for old,new in replacements:
 assert old in data,old[:90]
 data=data.replace(old,new,1)
changed={'src/lib/data.ts':data,'src/lib/evidence-consumers.ts':consumer}
# Existing direct-source mocks must inject the same unchanged consumer module too.
rel='tests/brand-updates.test.ts'; s=(root/rel).read_text()
a='''  const loaded = compiledSource("src/lib/data.ts", {
    "./brand-update-registry": { brandUpdatePackets: [packet] },
  }) as {'''
b='''  const overrides = {
    "./brand-update-registry": { brandUpdatePackets: [packet] },
  };
  const loaded = compiledSource("src/lib/data.ts", {
    ...overrides,
    "./evidence-consumers": compiledSource("src/lib/evidence-consumers.ts", overrides),
  }) as {'''
assert a in s;changed[rel]=s.replace(a,b,1)
rel='tests/brand-feature-updates.test.ts';s=(root/rel).read_text()
a='''  return compiledSource("src/lib/data.ts", overrides) as {'''
b='''  return compiledSource("src/lib/data.ts", {
    ...overrides,
    "./evidence-consumers": compiledSource("src/lib/evidence-consumers.ts", overrides),
  }) as {'''
assert a in s;changed[rel]=s.replace(a,b,1)
rel='tests/catalogue-snapshot.test.ts';s=(root/rel).read_text()
a='''  const loaded = compiledSource("src/lib/data.ts", overrides) as DataModule;'''
b='''  const loaded = compiledSource("src/lib/data.ts", {
    ...overrides,
    "./evidence-consumers": compiledSource("src/lib/evidence-consumers.ts", overrides),
  }) as DataModule;'''
assert a in s;changed[rel]=s.replace(a,b,1)
manifest=[];patch=[]
for rel,s in changed.items():
 target=out/'proposed'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(s)
 exists=(root/rel).exists();before=(root/rel).read_text() if exists else ''
 if exists:
  p=out/'before'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(before)
 manifest.append({'path':rel,'beforeSha256':sha(before) if exists else None,'proposedSha256':sha(s),'applied':False})
 patch+=list(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='a/'+rel if exists else '/dev/null',tofile='b/'+rel))
(out/'proposal.patch').write_text(''.join(patch))
# Exact declaration ranges; export modifiers alone are normalized, bodies are not.
chunks={
'feature indexes and firstFeatureIndex':indexes,
'applies':applies,
'formatters and readableValue':formatters,
'sourceEffectiveFeatures':source_effective,
'effectiveFeatures':effective,
'effectiveFeaturesFromRows':rows,
'pack':pack,
'buildSourceCatalogue':section('function buildSourceCatalogue(', '// Share by source identity'),
}
body_records=[]
for name,old in chunks.items():
 normalized=old.replace('export function ','function ').replace('export const ','const ')
 haystack=(data if name=='buildSourceCatalogue' else consumer).replace('export function ','function ').replace('export const ','const ')
 assert normalized in haystack,name
 # Function declarations start their body on a line ending in {; concise arrow featureKey is in the exact index block.
 callable_names={'feature indexes and firstFeatureIndex':['firstFeatureIndex'],'formatters and readableValue':['tidy','evidenceLabel','categoryLabel','readableValue']}.get(name,[name])
 for fn in callable_names:
  m=re.search(r'(?:export )?function '+re.escape(fn)+r'\b',old)
  assert m,fn
  tail=old[m.start():]
  body_start=next(x.end()-1 for x in re.finditer(r'\{\n',tail) if ')' in tail[:x.start()])
  # At module/factory scope these exact functions end at the first unindented close brace.
  end=tail.index('\n}',body_start)+2
  body=tail[body_start:end]
  assert body in haystack
  body_records.append({'name':fn,'bodyBytes':len(body.encode()),'beforeBodySha256':sha(body),'proposedBodySha256':sha(body),'byteIdentical':True})
 body_records.append({'name':name+' (whole range, export-only normalization)','bytes':len(normalized.encode()),'beforeSha256':sha(normalized),'proposedSha256':sha(normalized),'byteIdenticalAfterExportModifierOnly':True})
assert sha((root/'src/lib/data.ts').read_text())==original_hash
(out/'body-hashes.json').write_text(json.dumps(body_records,indent=2)+'\n')
(out/'changed-files.json').write_text(json.dumps({'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'REVIEW ONLY; not applied, compiled, or tested','sourceDataBeforeSha256':original_hash,'sourceDataAfterSha256':sha((root/'src/lib/data.ts').read_text()),'files':manifest},indent=2)+'\n')
print(json.dumps({'folder':str(out),'files':len(changed),'sourceUnchanged':True,'patchBytes':len(''.join(patch).encode()),'bodyRecords':len(body_records)}))
