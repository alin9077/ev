from pathlib import Path
import json,hashlib,subprocess,resource,time,os,datetime
out=Path(__file__).parent;root=out.parent.parent/'roadmark-104'
audit=json.loads((out/'dependency-audit.json').read_text())
paths=set(audit['runtimeClosure'])|{x['path'] for x in audit['consumerJsonInputs']}|{'package.json','pnpm-lock.yaml','tsconfig.json'}
paths=[root/p for p in sorted(paths)]+[out/'import-probe.mjs',out/'run-import-probe.py']
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def manifest():return [{'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p)} for p in paths]
before=manifest();(out/'import-probe-inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
cmd=['node','--max-old-space-size=448','--max-semi-space-size=1','--import','tsx',str(out/'import-probe.mjs')]
start=time.monotonic()
with (out/'import-probe.log').open('w') as log:
 child=subprocess.Popen(cmd,cwd=root,env={**os.environ,'TSX_DISABLE_CACHE':'1'},stdout=log,stderr=subprocess.STDOUT)
 code=child.wait()
elapsed=time.monotonic()-start;usage=resource.getrusage(resource.RUSAGE_CHILDREN);after=manifest()
(out/'import-probe-inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
completed=code==0 and (out/'import-probe-result.json').exists() and json.loads((out/'import-probe-result.json').read_text()).get('status')=='PASS'
result={'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'cwd':str(root),'environment':{'TSX_DISABLE_CACHE':'1'},'returnCode':code,'signal':-code if code<0 else None,'elapsedSeconds':elapsed,'childPeakRssKiB':usage.ru_maxrss,'inputsUnchanged':before==after,'inputCount':len(before),'completedProbe':completed,'status':'PASS' if completed and before==after else 'FAIL','scope':'Isolated real consumer module import and factory binding only; no catalogue hydration or full-loader verification'}
(out/'import-probe-terminal.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
raise SystemExit(0 if result['status']=='PASS' else 1)
