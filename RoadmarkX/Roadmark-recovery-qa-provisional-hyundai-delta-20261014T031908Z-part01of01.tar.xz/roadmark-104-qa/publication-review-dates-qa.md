# Publication metadata and glossary review dates

Completed 14 October 2026, within M1.

## Result

- Generated comparison/page publication metadata now uses 14 October 2026 from `src/lib/publication-metadata.ts`; the existing `citable.ts` export remains compatible with current consumers.
- The glossary owns its unchanged 10 October review date. Both visible review labels and the DefinedTermSet schema retain that date.
- Claim evidence, feature review dates, source history, grade-review dates, availability checks, offer deadlines and freshness rules are unchanged.
- Removed the completed M1 date-separation entry from `docs/BACKLOG.md`. The M4 performance item and current README remain unchanged.

## Verification

- Passed 17 tests across `publication-review-dates.test.ts`, `catalogue-reuse.test.ts` and `feature-offer-validity.test.ts` (about 1.4 seconds).
- Four new behavioral tests execute actual source with `compiledSource` and synthetic packs. They vary publication metadata, check JSON/Markdown/schema exports and provenance, retain stale/expired evidence, exercise the independent observation clock, render glossary review labels/schema, and check sitemap/llms publication metadata.
- Full TypeScript passed: `./node_modules/.bin/tsc --noEmit --incremental false`.
- Full lint passed: `./node_modules/.bin/eslint src tests scripts`.
- SHA-256 checks passed for all 85 data files, README and the four saved Hyundai before/baseline artifacts. No data, registry, hero or archive source edits.
- No full-catalogue test suite or full build was run for this narrow metadata change.

The pnpm wrapper tried to initialize its unavailable home store, so formatting, TypeScript and lint used the already-installed local binaries instead. No dependency installation or configuration change was needed.

## Files

Patch: `publication-review-dates.patch`.
Changed-file hashes: `publication-review-dates-changed.sha256`.
Protected-file baseline and verification: `publication-review-dates-protected-before.sha256`, `publication-review-dates-protected-check.log`.
Logs: `publication-review-dates-tests.log`, `publication-review-dates-typecheck.log`, `publication-review-dates-lint.log`.

Application edits are settled; the Hyundai reviewer was told to proceed with its separate final staged importer replay.
