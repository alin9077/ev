import fs from 'node:fs';
import { catalogue,research,effectiveFeatures } from '../roadmark-104/src/lib/data.ts';
const r=research(),cars=catalogue().filter(c=>c.brand==='Hyundai');
const root='/workspace/scratch/586427eef9f2/roadmark-104-qa';
fs.writeFileSync(root+'/hyundai-audit-live-before.json',JSON.stringify(cars,null,2));
fs.writeFileSync(root+'/hyundai-audit-live-sources-before.json',JSON.stringify(r.sources,null,2));
fs.writeFileSync(root+'/hyundai-audit-live-features-before.json',JSON.stringify(cars.flatMap(c=>effectiveFeatures(c,r)),null,2));
console.log(cars.map(c=>[c.id,c.year,c.trim]));
