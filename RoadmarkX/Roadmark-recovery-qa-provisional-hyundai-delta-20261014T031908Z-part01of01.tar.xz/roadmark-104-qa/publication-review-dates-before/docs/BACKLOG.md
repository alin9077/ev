# Deferred work

- M4: Profile repeated catalogue/brand-packet replay and large evidence payloads on the expanded catalogue before claiming mobile performance; the through-Kia full suite took 16 minutes, which is a test-runtime measure rather than a mobile benchmark.

- M1 release check: distinguish the generated comparison/page update date from unchanged glossary review dates and underlying evidence dates; do not advance all dates through one shared constant.
