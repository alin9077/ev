# Hyundai independent review working notes

14 October 2026. No approval yet.

- Immutable application/data baseline: 630 file SHA-256 records captured before review. Live Hyundai capture independently equals researcher before data and effective features: 18 rows including 15 Tier 1 and 1,242 equipment rows.
- Current official model range independently read via web: ELEXIO, INSTER, KONA Electric, IONIQ 5, IONIQ 9, IONIQ 5 N, IONIQ 6 N. STARIA Lounge is hybrid despite erroneous IONIQ 6 N thumbnail. Original lower-tier Hyundai rows remain out of scope.
- Live Midland exact MY26 AX.V1 Extended Range stock 620261783 remains New, VIN KMHB2511UTW080494. Older technical epoch requires a separate residual identity, not current August equipment inheritance.
- Phil Gilbert IONIQ9 220621292 redirects New to Demo. Original Werribee older MY26 six-seat link now returns a generic stock index in researcher capture; independent web open failed. Neither supports a new exact New unit; failure alone is not sold evidence.
- ELEXIO maker specification pp1–2 independently visually reviewed: FWD, explicit total 160 kW, 88.1 kWh, AC 10 kW, 38 min 10–80% at 150 kW station; Battery power output 122 kW is not DC peak. VDA 506 L behind second row conflicts with webpage 504 L.
- IONIQ9 maker MY27 specification pp1–2 independently visually reviewed: explicit total 314 kW, 110.3 kWh, AC 10.5 kW, 24 min 10–80% at 350 kW station; 350 kW is not vehicle peak.600 km WLTP; VDA 338 L behind third row vs 908 L behind second row. Portable cable row copied 10 h/three-phase 16 A text conflicts with domestic 12 A input; no usable normalized time.
- Warranty page independently read: five-year/unlimited private standard, conditional seven-year authorized-servicing extension from first registration 1 June 2025, battery 8 yr/160,000 km; commercial/component exceptions matter. Roadside BEV 24 months initially plus service-activated 24 months, excludes rental/taxi.
