import fs from 'node:fs';
import {catalogue,research,effectiveFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/data.ts';
const root='/tmp/gac-research/', r=research(), all=catalogue(), cars=all.filter(c=>c.brand==='GAC'&&(c.vehicleClass===undefined||['passenger','ute'].includes(c.vehicleClass)));
fs.writeFileSync(root+'gac-live-before.json',JSON.stringify(cars,null,2));
fs.writeFileSync(root+'gac-source-before.json',JSON.stringify(r.sources,null,2));
fs.writeFileSync(root+'gac-feature-before.json',JSON.stringify(cars.flatMap(c=>effectiveFeatures(c,r)),null,2));
fs.writeFileSync(root+'gac-models-before.json',JSON.stringify(r.models.filter(c=>c.brand==='GAC'),null,2));
fs.writeFileSync(root+'gac-variants-before.json',JSON.stringify(r.variants.filter(c=>c.brand==='GAC'),null,2));
console.log(cars.map(c=>({id:c.id,model:c.model,trim:c.trim,year:c.year,availability:c.availability,drive:c.drive,facts:Object.keys(c.facts).length})));
