import json, pathlib, hashlib, collections, re, sys, shutil
R = pathlib.Path('/tmp/gac-research')
REPO = pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104')
QA = REPO.parent / 'roadmark-104-qa'
D = '2026-10-14'
load = lambda f: json.loads((R / f).read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
def save(name, value):
    (R / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
p = load('gac-2026-10-14.json')
e = load('gac-effective-facts.json')
norm = load('normalized-evidence.json')
before = load('gac-live-before.json')
packet = REPO / 'data/m1-brand-updates/gac-2026-10-14.json'
recon = REPO / 'data/m1-gac-market-reconciliation-2026-10-14.json'
assert packet.read_bytes() == (R / 'gac-2026-10-14.json').read_bytes()
assert recon.read_bytes() == (R / 'gac-reconciliation-2026-10-14.json').read_bytes()
core = ['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty','battery_warranty']
source_by_id = {s['id']: s for s in p['sources']}
rows = [dict(variantId=v['id'], model=v['model'], trim=v['trim'], manufacturerModelYear=None, key=k, fact=e[v['id']][k], sourceUrls=[source_by_id[i]['url'] for i in e[v['id']][k]['sourceIds']]) for v in norm['variants'] for k in core]
grades = dict(collections.Counter(r['fact']['buyerGrade'] for r in rows))
save('core-matrix.json', dict(checkedAt=D, packetSha256=sha(packet), coreCells=len(rows), gradeCounts=grades, rows=rows))
save('before-populated-facts.json', [dict(variantId=c['id'], key=k, fact=f) for c in before for k,f in c['facts'].items() if f['value'] is not None])
by_path = collections.defaultdict(list)
for s in p['sources']:
    for key in ['capture_locator', 'capture_text_locator']:
        if s.get(key):
            by_path[s[key]].append(s['url'])
    for loc, h in [('capture_locator','capture_sha256'), ('capture_text_locator','capture_text_sha256')]:
        if s.get(loc):
            assert sha(R / s[loc]) == s[h], (s['id'], loc)
captures = []
for folder in ['current', 'terms', 'census']:
    for f in sorted((R / folder).iterdir()):
        if not f.is_file():
            continue
        rel = str(f.relative_to(R))
        urls = list(by_path[rel])
        if f.suffix.lower() in ['.json', '.txt', '.html']:
            urls.extend(re.findall(r'https?://[^\s<>"\\\]\)]+', f.read_text(errors='replace')))
        kind = 'public downloaded PDF' if f.suffix == '.pdf' else 'public downloaded maker offer/website image' if f.suffix == '.webp' else 'local PDF render' if f.name == 'warranty-table.png' else 'public page capture or research extraction'
        item = dict(path=rel, bytes=f.stat().st_size, sha256=sha(f), kind=kind, sourceUrls=list(dict.fromkeys(u.rstrip('.,;') for u in urls)), browserScreenshot=False)
        if f.name == 'warranty-table.png':
            item.update(parentPdf='terms/warranty-current.pdf', pdfPageNumberOneBased=3, method='Local PDF render visually checked by researcher and independent reviewer')
        captures.append(item)
save('source-index.json', dict(checkedAt=D, packetSha256=sha(packet), sources=p['sources'], captureFiles=captures, provenance='Public web/search/HTTP and ordinary dot-cloud Chrome price UI. No user computer, sign-in, order, contact submission, CAPTCHA or signed-API bypass.', sourcePriorityNotes=['Exact maker base/MSRP recovered through normal price UI outranks earlier secondary editorial fallback. State-specific driveaway estimates remain separately labelled.','Current rendered Q4 offer images override stale Q3 search snippets and alt text. Free22kW wall charger is an accessory rating, not vehicle AC acceptance.','Current exact-grade specification table takes priority over regional owner-manual motor/battery combinations. Same-body manual dimensions and secondary figures are explicitly scoped.','ANCAP12October2026 UT result and eCall hardware/activation distinction supersede earlier unrated claims.','CarsGuide towing database zero placeholders with unspecified-capacity prose do not establish manufacturer towing approval.']))
save('source-hash-manifest.json', dict(checkedAt=D, files=captures))
pattern = re.compile(r'(?i)(?:[?&](?:_gl|gclid|fbclid|csrf(?:token)?|access_token|session(?:id)?|token|challenge(?:id)?)=|["\x27]?(?:csrf(?:token)?|access_token|client_secret|session_cookie|cf_chl_[a-z_]+|authorization)["\x27]?\s*[:=]\s*["\x27]?[A-Za-z0-9_./+\-]{8,}|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.)')
scanned = []
findings = []
for f in R.rglob('*'):
    if f.is_file() and f.suffix.lower() in ['.html','.json','.txt','.log','.md'] and f.name not in ['artifact-hash-manifest.json','source-index.json','source-hash-manifest.json','redaction-audit.json']:
        scanned.append(str(f.relative_to(R)))
        if pattern.search(f.read_text(errors='replace')):
            findings.append(str(f.relative_to(R)))
assert not findings, findings
save('redaction-audit.json', dict(checkedAt=D, scannedFiles=len(scanned), scannedPaths=scanned, sensitiveValueMatches=[], transformationFile='redaction-transformations.json', notes=['No request or response cookie headers, browser storage, credentials, bearer tokens or CSRF values were captured.','Terms worker removed raw client JavaScript and unsuccessful appid-invalid response rather than retaining credential-like constants; those files are not sources for prices. Normal browser UI supplied all four prices later.','Two CarsGuide captures had executable scripts removed, with pre/post hashes recorded; rendered towing text is unchanged.','Historical before-state source records include benign prose describing earlier client-secret redactions; they are immutable and contain no credential values.','Public site/model/dealer stock identifiers and factual URLs remain. Warranty PNG is a local PDF render; WEBP files are downloaded public offer assets, not browser screenshots.']))
immutable = load('immutable-data-before.json')
changed = []
for row in immutable:
    current = sha(REPO / row['path'])
    if current != row['sha256']:
        changed.append(dict(path=row['path'], before=row['sha256'], after=current))
assert not changed, changed
unknown_features = [f for f in load('features-after.json') if f.get('gradeReview', {}).get('overlayId') != p['id']]
retained = [dict(variantId=c['id'], key=k, value=f['value']) for c in before for k,f in c['facts'].items() if k not in e[c['id']]]
assert not retained, retained
save('evidence-completeness-audit.json', dict(checkedAt=D, packetSha256=sha(packet), originalDataFilesUnchanged=len(immutable), originalDataFileChanges=[], reviewedVersions=4, newVersions=0, reviewedCoreCells=68, coreGradeCounts=grades, factEdits=len(p['facts']), brandTerms=len(p['brandTerms']), equipmentReplacements=len(p['features']), summaries=len(p['summaries']), remainingNoncoreEquipment=[dict(variantId=f['variant_id'], criterion=f['criterion'], value=f.get('value'), reason='Unverified lifestyle, subjective, financial, network or exact-function question; not filled by inference or represented as newly verified.') for f in unknown_features], baseline=dict(kind='All four existing full before-state guards and effective feature before rows', newVersionFixtureRequired=False, reason='No new variants added; no generated new-version fixture exists or is used.'), caveats=['Four core braked-towing gaps are genuine two-source unsuccessful searches; no zero-capacity inference.','UT10–80 approximately34minutes is Reported; maker24minutes is30–80 only. V24minutes is explicitly10–80 in current maker matrix.','V0–1007.9seconds is Reported. Battery capacity is maker-published without invented usable/gross label.','UT321L standard block-method volume is grouped only on its own method; V427–978L method unspecified and unranked.','Private warranty terms are Confirmed; commercial UT battery/prose and ambiguous SOH wording remain visible. Roadside12months initial and annual dealer-service renewal up to5years is Check with included fitment.','MY-null identity retained. 44kWhUT arrival is secondary-reported December2026, not current order-grade evidence.','Whole-market C1 snapshots are still outstanding. Brand-level two-publisher closure does not substitute for global reconciliation.']))
passed = '--passed' in sys.argv
if passed:
    assert (R / 'stage-validation.exit').read_text().strip() == '0'
report = load('staged-report.json')
brand = next(b for b in report['brandProgress'] if b['brand'] == 'GAC')
save('integration-readiness.json', dict(checkedAt=D, status='self-stage-passed-independent-review-pending' if passed else 'self-stage-in-progress', registered=False, packetApprovedForGuardedIntegration=False, packet=str(packet.relative_to(REPO)), packetSha256=sha(packet), reconciliation=str(recon.relative_to(REPO)), reconciliationSha256=sha(recon), selfStageExit=0 if passed else None, reviewedVersions=4, newVersions=0, coreCells=68, gradeCounts=grades, researchCompleted=brand['researchCompleted'], criteria=brand['criteria'], requiredNext=['Independent final-byte evidence and actual-pack replay approval','Parent-only registry and reconciliation-loader integration','Root integration validation and verified recovery save'], sources=len(p['sources']), sourceCaptureFiles=len(captures)))
(R / 'REVIEW.md').write_text('''# GAC Australian BEV research — 14 October 2026

Four current versions are established: AION UT Premium/Luxury and AION V Premium/Luxury. Manufacturer model year remains unspecified. No duplicate year identities were invented from seller/build labels or 2027 editorial headings.

## Buyer facts
- Maker base/MSRP: UT A$31,990 / A$35,990; V A$42,590 / A$44,590. Ordinary cloud-browser captures retain exact grade and base/on-road separation. Separate VIC 3000 Personal driveaway estimates are not national prices or personalised quotes
- UT: 430 km WLTP, 60 kWh LFP, 87 kW DC, 11 kW AC. Approximately 34-minute 10–80% duration is Reported; maker 24-minute 30–80% remains separate
- V: 510 km WLTP, 75.26 kWh LFP, 180 kW DC, maker 24-minute 10–80%, 11 kW AC. 7.9-second acceleration is Reported
- Both are five-seat FWD cars with 150 kW. Braked towing is not reliably published after maker/manual and contradictory secondary-database checks
- UT standard block-method cargo is 321 L; V lower declared cargo is 427 L with method unspecified. No VDA or folded-seat method is invented
- Private vehicle warranty is 8 years/unlimited kilometres; battery is 8 years/200,000 km. Commercial and battery-SOH wording issues remain explicit. Roadside starts with 12 months, then dealer-service renewal up to five years
- UT five-star ANCAP result published 12 October 2026 is included as Reported direct assessor evidence. eCall hardware is fitted but service activation is not yet operational

## Commercial closure
Current maker range plus complete CarExpert and CarsGuide brand lists support the four grades. UT 44 kWh / Standard Range is reported for December 2026, Hyptec HT remains a future Australian lead and UT Cross is overseas-only evidence. A stale 2025 V Luxury new ad is now explicitly Demo on the dealer page. Other year-labelled New advertisements do not establish separate maker cohorts or certify registration/warranty history.

This is research closure for the brand, not global C1–C6 completion. All 68 core cells are reviewed: 60 Confirmed, 4 Reported and 4 Not published. C3/C4/C6 pass; C1 awaits whole-market lists, C2 has genuine towing gaps, and C5 excludes reported charge times, unknown-method V cargo and missing towing.

## Deliverable and safeguards
The dated packet is staged, not registered. It has 704 guarded specific fact edits, three shared terms, 114 equipment replacements and four supported summary pairs. All four versions already existed, so full existing before-state guards apply and no new-version baseline is required. Original research, existing data files and previous registered packets are unchanged. No shared code or registry was edited.

The normalized evidence and terms JSON files are authoritative final builder inputs. Intermediate research scripts may recreate earlier research stages; recreate the final packet with build-packet.py only. The source index, capture hashes, core matrix, immutable-data audit and privacy records accompany the staged packet. No user-computer work, publication, login, CAPTCHA, third-party communication or browser-screenshot upload occurred.
''')
artifacts = [dict(path=str(f.relative_to(R)), bytes=f.stat().st_size, sha256=sha(f)) for f in sorted(R.rglob('*')) if f.is_file() and f.name != 'artifact-hash-manifest.json']
save('artifact-hash-manifest.json', dict(checkedAt=D, packetSha256=sha(packet), reconciliationSha256=sha(recon), files=artifacts, note='Manifest excludes itself; regenerate after final review records arrive.'))
for name in ['REVIEW.md','core-matrix.json','source-index.json','source-hash-manifest.json','redaction-audit.json','redaction-transformations.json','evidence-completeness-audit.json','integration-readiness.json','artifact-hash-manifest.json','brand-model-list-reconciliation.json']:
    shutil.copyfile(R / name, QA / ('gac-research-' + name))
print(json.dumps(dict(packetSha256=sha(packet), reconciliationSha256=sha(recon), coreGrades=grades, immutableFiles=len(immutable), captureFiles=len(captures), selfStagePassed=passed), indent=2))
