import json,pathlib
R=pathlib.Path('/tmp/gac-research');p=json.loads((R/'normalized-evidence.json').read_text())
for name in ['ut','v']:
 for trim in ['premium','luxury']:
  key=name+'_'+trim+'_price';p['sources'].append(dict(key=key,url='https://www.gacgroup.com/en-au/price/'+('AION%20UT' if name=='ut' else 'aion-v')+'/2025',title='GAC Australia '+('AION UT' if name=='ut' else 'AION V')+' '+trim.title()+' maker base/MSRP and VIC driveaway estimate',publisher='GAC Australia',source_type='official_configurator',file='terms/aion-'+name+'-'+trim+'-price-browser.txt',supports='Exact named-grade base price displayed separately from on-road charges. VIC3000 Personal driveaway quote is a separate estimate; maker base-price/MSRP and paint terms preserved.',retrievalMethod='Normal dot-cloud browser UI; no direct signed endpoint or credential replay'))
for v in p['variants']:
 name='ut' if v['model']=='AION UT' else 'v';lux=v['trim']=='Luxury';source=name+'_'+v['trim'].lower()+'_price';fs=v['facts'];fd={f['key']:f for f in fs};price=fd['price_aud'];price.update(sourceKeys=[source],grade='confirmed',priceRung=1,basis='Maker base/MSRP before on-road costs',comparison='Before on-road costs',basisTag='Maker’s list price',rankingEligible=True,reason='Current maker exact-grade Price Details UI displays base vehicle price separately from purchase subsidy and on-road costs; terms identify base-price/MSRP. No price conversion or cashback deduction.',qualifications=['Standard colour: '+('white or beige' if name=='ut' else 'white')+'. Other colours add A$600'+('; AION UT dual-tone paint adds A$1,000.' if name=='ut' else '.'),'Maker price UI checked14October2026. Dealer-final total can vary; on-road costs and accessories are separate.'])
 da=([31990,35990] if name=='ut' else[46180,48270])[int(lux)]
 fs.append(dict(key='promotional_driveaway_aud',value=da,sourceKeys=[source],grade='check',priceRung=4,state='VIC',basis='Maker VIC3000 Personal driveaway estimate',comparison='Driveaway',basisTag='Maker’s VIC driveaway estimate',rankingEligible=True,condition='VIC metropolitan postcode3000, Personal registration, private owner aged40 with good driving record;12months registration and CTP. Standard colour; final dealer price varies with buyer circumstances. This is a representative estimate, not the user’s postcode or insurance quote.',reason='Exact-grade driveaway estimate copied directly from maker UI, including its own displayed subsidy and on-road fees; no manual arithmetic or tax conversion.',qualifications=['The UI calls this amount estimated. Optional paint and equipment are additional.','Displayed purchase subsidy: '+('A$2,480' if lux else'A$2,310')+'; no separate novated benefit has been deducted.' if name=='ut' else 'No October cashback or novated lease benefit has been manually deducted.']))
 # Correct known equipment. Unknown lifestyle/subjective claims remain unknown, not guessed.
 features=[]
 def F(criterion,value,keys,**kw):features.append(dict(criterion=criterion,value=value,keys=keys,**kw))
 def ef(s):return'equipment_'+s
 F('front_heated_seats','Both front seats are heated.',[ef('driver_seat_heated'),ef('passenger_seat_heated')] if name=='ut' else[ef('heated_ventilated_driver_front_passenger_seats')])
 if name=='ut':
  F('front_ventilated_seats','Driver seat ventilation is fitted; passenger-seat ventilation is not listed.' if lux else'Front-seat ventilation is not fitted on Premium.',[ef('driver_seat_ventilation')],status='standard' if lux else'unavailable')
 else:
  F('front_ventilated_seats','Both front seats have ventilation.',[ef('heated_ventilated_driver_front_passenger_seats')]);F('rear_heated_seats','Rear-row seat heating is listed as standard.',[ef('heated_rear_row_seats')])
 F('heated_steering_wheel','Heated steering wheel is standard.',[ef('heated_steering_wheel')])
 F('folding_mirrors','Manual-folding mirrors; power folding is not fitted.' if name=='ut' and not lux else'Power-folding exterior mirrors are standard.',[ef('power_folding_side_mirrors')] if name=='ut' else[ef('outside_rearview_mirror_with_electric_folding_heating_and_position_memory')],status='unavailable' if name=='ut' and not lux else'standard')
 F('adas_standard','Adaptive cruise, automatic emergency braking, lane assistance and blind-spot detection are listed. These assist the driver and do not provide autonomous driving.',[ef('adaptive_cruise_control_system_acc'),ef('automatic_emergency_braking_aeb'),ef('blind_spot_detection_bsd'),ef('integrated_cruise_assistance_ica')])
 F('v2l','Vehicle-to-load capability is listed; Australian outlet power and adapter inclusion are not established.', ['v2l','v2l_kw','v2l_adapter_included'])
 F('navigation_route_planner','Online navigation is fitted'+('; the maker lists three years from activation.' if name=='ut' else'.')+' Automatic charging-stop planning is not established in the checked grade matrix.',[ef('online_navigation_valid_for_three_years_after_activation')] if name=='ut' else[ef('online_navigation')])
 F('safety_ancap',('Five-star ANCAP rating, tested2026. eCall hardware is fitted but emergency calling is not yet operational; target activation is October2027.' if name=='ut' else'Five-star ANCAP2025 rating applies to all variants in the assessed Australian range.'),['ancap_stars']+([ef('e_call')] if name=='ut' else[]),grade='reported')
 F('performance_rear_motor','150kW motor output with front-wheel drive.', ['power_kw','drive'])
 F('voice_assistant','Online voice control is listed in English and Thai.' if name=='ut' else'Four-zone voice control is standard.',[ef('online_voice_control_english_thai')] if name=='ut' else[ef('four_zone_voice_control')])
 F('storage','321L standard and689L expanded trunk volumes; maker standard-volume-block method, with loading details unspecified. Front storage volume is not published.' if name=='ut' else'Maker lists427–978L rear trunk volume without a named measurement or loading method. Front storage volume is not published.', ['boot_l','max_total_cargo_l','frunk_l'])
 F('carplay_android_auto','Apple CarPlay and Android Auto are listed in the Australian specification.' if name=='ut' else'Apple CarPlay is listed in the current Australian specification. Android Auto is described in the linked owner manual but exact local fitment should be checked.', ['apple_carplay','android_auto'] if name=='ut' else['apple_carplay'])
 F('app_connectivity','Smartphone app remote-control functions are listed; supported functions and data access should be checked for the delivered vehicle.',[ef('smartphone_app_remote_control')] if name=='ut' else[ef('mobile_phone_remote_vehicle_control')])
 F('heat_pump','Heat pump is standard.',[ef('heat_pump')])
 F('warranty_service','Private use:8years/unlimited-kilometre vehicle warranty and8years/200,000km traction-battery warranty, whichever occurs first. Commercial terms differ; ambiguous battery-capacity wording needs written clarification.', ['warranty','battery_warranty'])
 F('driver_alerts','Driver monitoring and child-presence detection are listed. Alert effectiveness and behaviour remain driver-assistance limitations.', [ef('driver_monitoring_system_dms'),ef('child_presence_detection_cpd')] if name=='ut' else[ef('driver_monitoring_system_dms'),ef('child_presence_detection')])
 F('parking_cameras','Surround-view camera plus front and rear parking sensors are standard.',[ef('surround_view_camera_system'),ef('front_parking_sensors'),ef('rear_parking_sensors')] if name=='ut' else[ef('surround_view_camera_system'),ef('front_and_rear_parking_sensors')])
 F('energy_use',('16.4' if name=='ut' else'16.7')+'kWh/100km WLTP consumption; laboratory value.', ['consumption_kwh_100km'])
 F('battery_chemistry',('60' if name=='ut' else'75.26')+'kWh LFP battery; maker does not distinguish gross from usable capacity.', ['battery_kwh','battery_chemistry'])
 F('home_charging','Maximum11kW AC acceptance. The complimentary22kW wall charger does not increase the vehicle’s onboard limit; installation is excluded.', ['ac_kw','charging_offer'],grade='check',conditions='The offered charger’s rating is separate from vehicle acceptance. Confirm installation, electrical supply, timing and property suitability.')
 F('charging_cable','The current maker campaign lists a complimentary portable charger; confirm supply timing with the dealer.', ['portable_charger_offer'])
 F('child_seats','ISOFIX child-seat fixtures are listed.' if name=='ut' else'i-Size child-seat fixtures are listed; confirm the intended seat and installation positions.',[ef('isofix_child_safety_seat_fixtures')] if name=='ut' else[ef('isize_child_safety_seat_fixtures')])
 if name=='ut':F('spare_tyre','Tyre repair kit is standard; the current grade matrix does not list a spare wheel.',[ef('tire_repair_kit')])
 else:F('spare_tyre','Tyre repair kit is standard; non-full-size spare tyre is optional.',[ef('tire_repair_tools_inflator_tire_repair_fluid'),ef('non_full_size_spare_tire')],grade='check',status='optional',conditions='The maker’s ○ symbol identifies the non-full-size spare as optional; confirm supply and cost.')
 F('screens_hud','14.6-inch central touchscreen and8.88-inch instrument display are listed; a head-up display is not established in the grade matrix.',[ef('14_6_inch_touch_control_central_screen'),ef('8_88_inch_lcd_instrument')])
 F('audio_system',('Six' if name=='ut' else'Nine')+' speakers are listed.',[ef('6_sepakers')] if name=='ut' else[ef('9_sepakers')])
 F('glass_roof','Panoramic sunroof with electric sunshade is fitted.' if name=='v' or lux else'Panoramic sunroof is not fitted on Premium.',[ef('panoramic_sunroof_with_electric_sunshade')],status='standard' if name=='v' or lux else'unavailable')
 F('power_tailgate','Powered tailgate is fitted.' if name=='v' or lux else'Manual tailgate; powered operation is not fitted.',[ef('power_liftgate')] if name=='ut' else[ef('smart_power_liftgate')],status='standard' if name=='v' or lux else'unavailable')
 F('wireless_charging','Wireless phone charging is standard.' if name=='v' or lux else'Wireless phone charging is not fitted on Premium.',[ef('wireless_phone_charging')],status='standard' if name=='v' or lux else'unavailable')
 fs.append(dict(key='portable_charger_offer',value='Complimentary portable EV charger; confirm delivery timing',sourceKeys=[name+'_page'],grade='check',condition='Confirm availability and delivery timing of the complimentary portable charger with the dealer.',basis='Current maker model-page charging benefit',comparison='',reason='Current Australian model campaign and its charger footnote establish the portable-charger benefit without guaranteeing timing.'))
 v['features']=features
# Keep text readable without changing identifiers/URLs.
def clean(x):
 if isinstance(x,list):return[clean(a)for a in x]
 if isinstance(x,dict):return{k:clean(v)for k,v in x.items()}
 if isinstance(x,str) and x != 'v2l' and not (x.startswith('http') or '_' in x or '/'in x and x.startswith('terms')):
  import re
  x=re.sub(r'(?<=[a-zA-Z])(?=\d)',' ',x)
  for a,b in [('3000','3000'),('321L','321 L'),('689L','689 L'),('978L','978 L'),('150kW','150 kW'),('11kW','11 kW'),('22kW','22 kW'),('years/','years / '),('8years','8 years'),('200,000km','200,000 km'),('40with','40 with'),('12months','12 months'),('October2027','October 2027')]:x=x.replace(a,b)
  return x
 return x
p=clean(p);(R/'normalized-evidence.json').write_text(json.dumps(p,indent=2,ensure_ascii=False)+'\n');print('Feature rows',sum(len(v['features'])for v in p['variants']))
