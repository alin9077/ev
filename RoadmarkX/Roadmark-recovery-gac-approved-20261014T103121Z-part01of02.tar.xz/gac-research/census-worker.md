# GAC / AION Australian BEV census research

As-of date: 2026-10-14 (UTC). Research completed against the current Australian range, rather than global nameplates. Scope: ordinary Australian new-vehicle BEVs, including genuine-new residual offers and announced arrivals that might otherwise be mistaken for current offerings. No repository edits, catalogue runs, tests, screenshots, uploads, or publication.

## Decision-ready result

Retain **four current technical identities across two model families**:
1. GAC AION V Premium, current Australian specification, manufacturer model year unproven/null
2. GAC AION V Luxury, current Australian specification, manufacturer model year unproven/null
3. GAC AION UT Premium, current Australian specification, manufacturer model year unproven/null
4. GAC AION UT Luxury, current Australian specification, manufacturer model year unproven/null

The Australian manufacturer list and two independent Australian full-brand lists converge on these two BEV model families. Dealer/listing years 2025 and 2026 and directory/editorial 2027 labels do **not** establish separate manufacturer technical cohorts. There is no evidenced additional currently saleable Australian BEV grade to add. Colours, two-tone paint, stock/build years, promotional prices and international variants are not separate technical identities.

The 44kWh AION UT short-/standard-range variant is an **upcoming lead**, reported for December 2026; do not add to the current-new set. Hyptec HT is a future-market lead. UT Cross is a just-announced UK/European lead, not an Australian offering.

## Primary Australian range and grade closure

### Official current model list
URL: https://www.gacgroup.com/en-au
Observed 2026-10-14. HTTP 200 direct capture at 09:59:47 UTC, with hash in census/official-au-home.metadata.json.
The current menu has four vehicle families: M8 PHEV, EMZOOM, AION UT and AION V. The two electric-only families are the hatchback AION UT and SUV AION V. M8 PHEV and EMZOOM are excluded by powertrain.
The manufacturer's Q4 offer wording covers orders 1 October through 31 December 2026; this is positive current-order evidence, not stock confirmation.

### AION V grade matrix
URL: https://www.gacgroup.com/en-au/configuration/aion-v/2025
Observed 2026-10-14; direct HTTP 200 capture at 09:59:47 UTC.
Exactly two columns: Premium and Luxury. Both FWD, 150kW and 210Nm, with the same battery/range powertrain. No additional Australian battery, motor or trim is shown.
The /2025 route is a site configuration identifier and does not independently establish an official MY2025 designation.
Product page: https://www.gacgroup.com/en-au/suv/aion-v
Use the current Australian matrix as the identity anchor.

### AION UT grade matrix
URL: https://www.gacgroup.com/en-au/configuration/AION%20UT/2025
Observed 2026-10-14; direct HTTP 200 capture at 09:59:47 UTC.
Exactly two columns: Premium and Luxury. Both FWD, 150kW/210Nm, 60kWh LFP, 430km WLTP. The current matrix contains no 44kWh grade.
The /2025 route cannot be taken as MY2025: Australian local launch/order reporting is in 2026.
Product page: https://www.gacgroup.com/en-au/hatchback/aion-ut
Observed live 2026-10-14: Q4 2026 national drive-away offer from AUD31,990, with orders dated 1 October–31 December 2026. Search index snippets still show Q3, so prefer opened current page to stale search text.

### Dated Australian launch support
Official AION UT launch article, dated 2026-04-10:
https://www.gacgroup.com/en-au/news/article/leave-fuel-price-anxiety-behind--aion-ut-debuts-in-australia--setting-a-new-benchmark-for-urban-electric-vehicles-81
It identifies the Australian launch and names the same four model families.
AION V ANCAP fact sheet gives Australian on-sale November 2025, vehicles built from July 2025, and Premium/Luxury as the covered Australian grades:
https://s3.amazonaws.com/cdn.ancap.com.au/app/public/assets/9b84c689a08031c228184f386eaad1499b7883ac/original.pdf
These are calendar/build applicability dates, not proof of separate official MY identities.

## Two independent full-brand list checks

### Independent list 1: CarExpert
URL: https://www.carexpert.com.au/gac
Observed 2026-10-14, direct HTTP 200 capture at 09:59:47 UTC.
Current Australian range explicitly includes AION UT, AION V, M8 PHEV and Emzoom; GS8 is not a current Australian model. Thus the BEV family list closes at UT and V.
Grade/year directories:
- https://www.carexpert.com.au/gac/aion-ut
- https://www.carexpert.com.au/gac/aion-v
Both list Premium and Luxury; both current builder/historical sections show 2026. The directories do not identify a technical MY transition.

### Independent list 2: CarsGuide
URL: https://www.carsguide.com.au/gac
Observed 2026-10-14, direct HTTP 200 capture at 09:59:57 UTC.
The page says four current models and two electric models. Those are Aion UT and Aion V. M8 is marked hybrid, and Emzoom is not electric. The older-model section's E9 and GS8 do not add eligible BEVs.
CarsGuide has year pages including 2027; the year issue is closed below rather than used to create extra rows.

## Year-label and residual-offer reconciliation

### 2025 and 2026 AION V stock labels
Carsales current broad list:
https://www.carsales.com.au/cars/aion/
Web reader observed 2026-10-14, reporting crawl 3 days earlier.
This list contains 2025 AION V Premium dealer-new offers alongside 2026 AION V Premium/Luxury and 2026 AION UT Premium/Luxury offers. It also contains demo and used offers which must not be conflated with new.

Example 2025 V Premium dealer-new:
https://www.carsales.com.au/cars/details/2025-aion-aion-v-premium-auto/OAG-AD-25691059/
Observed in the web reader as dealer-new, 14km, Queensland, AY5-EU Premium, 150kW, 75.3kWh, 510km. Listing-type evidence only; not independently verified physical stock.
Another 2025 Premium example:
https://www.carsales.com.au/cars/details/2025-aion-aion-v-premium-auto/OAG-AD-25430610/
The listing supplies July 2025 build, December 2025 compliance and dealer stock C1290. These describe an individual vehicle, not a distinct manufacturer version.

A fresh direct dealer list provides a stronger current residual-offer lead:
https://www.rockinghamgac.com.au/stock/
Direct HTTP 200 at 2026-10-14 09:59:59 UTC; raw HTML and extracted text captured.
It labels stock G000135 as **New**, heading “2025 GAC Aion Premium AY5-EU”, electric, 10km. The linked listing is:
https://www.rockinghamgac.com.au/new-cars/for-sale/gac/aion/2025/premium/ay5-eu/3909012/
The AY5-EU model identity points to the same first-launch AION V family. Treat the unusual shortened dealer model name as a listing normalization issue, not a third BEV family.

Direct detail fetch at 2026-10-14 10:01:10 UTC also succeeded. It retains a New category but shows a registration number and expired 30 June 2026 cashback wording, and calls the vehicle 2026 in prose while its year field says 2025. Thus this is a currently accessible dealer-advertised-new lead, not certification that the car is unregistered/genuinely retail-new. Do not use its old promotion as current pricing evidence.
GAC Preston's matching C1290 page also says New but includes a registration number:
https://gacpreston.com.au/stock/details/OAG-AD-25430610/2025-aion-aion-v-new
The residual scan found no extra technical identity, so resolving individual registration histories is unnecessary to the census conclusion.

**Mapping recommendation:** map eligible 2025/2026 dealer-new V offers to the current V Premium/Luxury identity when grade and powertrain agree. Keep manufacturer MY null until the maker explicitly differentiates a cohort. Residual offer presence does not create duplicate technical rows.

### Stale “2025 Luxury dealer-new” lead closed by fresh dealer evidence
Old indexed list:
https://www.carsales.com.au/cars/2025/aion/aion-v/luxury-badge/
Specific old ad:
https://www.carsales.com.au/cars/details/2025-aion-aion-v-luxury-auto/OAG-AD-25820870/
The web reader labels it 2025 Luxury, dealer new, 10km, stock G000128, VIN ending K02457; seller prose calls it 2026. Its crawl is two months old.
Fresh Rockingham HTML on 2026-10-14 labels the exact same stock **G000128 as Demo**. Linked dealer page:
https://www.rockinghamgac.com.au/demo-cars/for-sale/aion/aion-v/2025/luxury/ay5-eu/3909010/
Direct detail fetch at 10:01:10 UTC confirms Demo and the matching stock/VIN. Its related listings include 2026 V Premium G000179 and Luxury G000157 both labelled New; these remain offer evidence, not physical-stock confirmation.
Therefore exclude this particular ad from genuine-new residual evidence. A 10km reading alone never proves new status.
No distinct residual Luxury technical cohort was demonstrated. The current Luxury remains in the national new-order range regardless.

### 2027 labels
CarExpert article:
https://www.carexpert.com.au/car-reviews/2027-gac-aion-v-review
Published 6 September 2026. Heading/pricing table use 2027, but its own “Model tested” links to 2026 GAC Aion V; the model catalogue still builds 2026 Premium/Luxury. No maker change or separate powertrain is described.
CarsGuide:
https://www.carsguide.com.au/gac/aion-ut/2027
https://www.carsguide.com.au/gac/aion-ut/price/2027
The generated 2027 pages repeat Premium/Luxury, 60kWh-era range and older 2026 review links; no separately announced Australian MY27 change was found.
**Disposition:** record conflicting editorial/directory year labels; do not promote them into extra current identities or claim MY2027 officially.

## Upcoming and international leads closed

### AION UT 44kWh / short range / Standard Range
CarExpert dated 11 August 2026:
https://www.carexpert.com.au/car-news/one-of-australias-most-affordable-electric-hatchbacks-will-soon-be-even-cheaper
Reports Australian arrival by end-2026 with 44kWh and 320km WLTP; pricing, detailed equipment and motor output were not announced. It distinguishes the overseas 100kW/145Nm motor from unconfirmed Australian output.
Most recent dated closure found:
https://www.carsguide.com.au/car-news/seven-best-electric-cars-still-due-in-2026-including-2026-zeekr-7gt-gac-aion-ut-standard
Published 24 September 2026; section headed AION UT Standard Range: December 2026. Official live Australian matrix on 14 October still has only 60kWh Premium/Luxury.
**Disposition:** upcoming, not current-saleable. “Standard Range” is secondary-source terminology, not independently maker-verified final trim naming. No Australian price/output should be invented.

### Hyptec HT
https://www.whichcar.com.au/news/gac-hyptec-ht-electric-suv-spied-melbourne
Published 4 June 2026; spy/test/show-car evidence, explicitly not confirmation of an Australian retail launch.
https://www.goauto.com.au/amp/motor-show/beijing/1400-models-take-to-the-stands-in-beijing/2026-05-05/news/gac/ute-and-suvs-to-help-gac-rsquo-s-rural-expansion/2026-03-27/98851.html
Dated 27 March 2026; reports plans around/during 2027.
**Disposition:** future lead only, no AU current grade, pricing or order availability established.

### AION UT Cross
Official UK announcement, 12 October 2026:
https://media.aionauto.co.uk/en/news-articles/aion-ut-cross-and-gs7-introduced-at-2026-paris-motor-show-ahead-of-uk-arrival.html
It announces Paris debut and UK launch in early 2027, with pricing/specs still due. No Australian release is established.
**Disposition:** overseas launch, excluded from current Australian census.

### Other names / non-BEVs
AION Y, ES, S, RT, N60, i60 and Hyptec/Hyper overseas grades are absent from the current official AU model range and the two full-brand local lists. Overseas/global or export pages are not Australian retail evidence.
M8/E9 PHEV, S7/GS7/Yue 7 and proposed PHEV ute do not enter the pure-BEV census. GS8 and EMZOOM are also excluded.

## Temporal and evidence limitations

- Research access date is 2026-10-14, but web-reader crawl dates can be older. Explicit article publication dates and direct HTTP capture times are separately recorded.
- Primary current range/grade pages and both independent full-range lists were directly fetched successfully on the research date.
- Direct HTTP retrieval of the two Carsales individual ads returned 403; no retry/bypass was attempted. Already available web-reader extracts remain historical corroboration only, with their crawl dates retained.
- Fresh direct dealer evidence overrules the stale Carsales new/demo classification for G000128.
- No dealer was contacted and no physically present inventory, registration, warranty commencement or delivery date is certified.
- No manufacturer-defined model-year boundary or technical refresh separate from the four current identities was found. The recommendation is identity mapping with provenance, not year proliferation.

## Capture inventory

Directory: /tmp/gac-research/census/
- official-au-home.html, official-ut-spec.html, official-v-spec.html, each with timestamp/URL/status/hash metadata
- carexpert-au-range.html and carsguide-au-range.html with metadata
- rockingham-dealer-stock.html, .txt and metadata
- rockingham-2025-premium-new and rockingham-2025-luxury-demo detail .html/.txt files with successful direct-fetch metadata
- census_*.json web-tool result captures, including dated upcoming evidence and year conflicts

No screenshots were captured or shared. No repo files were modified.

