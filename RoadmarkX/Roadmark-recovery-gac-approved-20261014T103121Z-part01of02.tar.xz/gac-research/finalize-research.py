import json, pathlib, hashlib, re, shutil, datetime
R=pathlib.Path('/tmp/gac-research'); REPO=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104'); QA=REPO.parent/'roadmark-104-qa'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda name:json.loads((R/name).read_text())
def save(name,obj): (R/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
now='2026-10-14T10:25:00Z'
previous=load('artifact-hash-manifest.json')
shutil.copyfile(R/'artifact-hash-manifest.json',R/'pre-integration-artifact-hash-manifest.json')
shutil.copytree(QA/'gac-independent-review', R/'independent-review', dirs_exist_ok=True)
shutil.copyfile(QA/'review-gac-independent.ts',R/'independent-review/review-gac-independent.ts')
review=load('independent-review/independent-review-replay.json')
assert review['status']=='passed'
for name,h in review['approvedHashes'].items(): assert sha(R/name)==h,name
for a,b in [('gac-2026-10-14.json','data/m1-brand-updates/gac-2026-10-14.json'),('gac-reconciliation-2026-10-14.json','data/m1-gac-market-reconciliation-2026-10-14.json')]: assert sha(R/a)==sha(REPO/b)
immutable=load('immutable-data-before.json'); changes=[]
for row in immutable:
 h=sha(REPO/row['path'])
 if h!=row['sha256']: changes.append(dict(path=row['path'],previousSha256=row['sha256'],currentSha256=h))
assert len(changes)==1 and changes[0]['path']=='data/m1-brand-updates/registry.json',changes
registry=json.loads((REPO/changes[0]['path']).read_text())
assert registry['packets'][-1]=='gac-2026-10-14.json' and registry['packets'].count('gac-2026-10-14.json')==1
registry['packets'].pop()
restored=hashlib.sha256((json.dumps(registry,indent=2)+'\n').encode()).hexdigest()
assert restored==changes[0]['previousSha256']
changes[0].update(originalRegistryRestoredInMemorySha256=restored,reason='Parent registered the independently approved packet at 10:22 UTC. Removing only the GAC append in memory restores the original registry bytes. Research worker did not edit the registry.')
save('registered-immutable-audit.json',dict(checkedAt=now,registrationAt='2026-10-14T10:22:00Z',originalDataFilesUnchanged=len(immutable)-1,authorizedRootRegistrationChanges=changes,preRegistrationAudit='evidence-completeness-audit.json',preRegistrationAuditPreserved=True,approvedHashesUnchanged=True,notes='The reviewed completeness audit remains byte-identical as the pre-integration state. This separate audit records the later parent registry append. The parent also registered the reconciliation report loader; no research-worker shared code change.'))
readiness=load('integration-readiness.json')
readiness.update(checkedAt=now,status='independently-approved-and-parent-registered; root-validation-and-recovery-separate',registered=True,registrationAt='2026-10-14T10:22:00Z',packetApprovedForGuardedIntegration=True,independentReplayExit=0,independentReplay='independent-review/independent-review-replay.json',independentSourceReview='independent-review/source-review.md',independentArtifactVerification='independent-review/final-artifact-verification.json',registeredImmutableProof='registered-immutable-audit.json',approvedHashes=review['approvedHashes'],requiredNext=['Parent sequential production checks and independent registered-coverage parity','Verified recovery save after parent source/QA freeze'],frozenResearchScope='Final research, source captures and approved packet bytes. Parent production check artifacts and recovery records are maintained separately in QA.')
save('integration-readiness.json',readiness)
p=R/'REVIEW.md'; t=p.read_text();t=t.replace('The dated packet is staged, not registered.','The dated packet passed independent review and was registered by the parent at 10:22 UTC on 14 October 2026.').replace('Original research, existing data files and previous registered packets are unchanged. No shared code or registry was edited.','All 95 pre-existing data files were unchanged at review. The subsequent parent registry append is separately proven by restoring its prior bytes in memory; the other 94 files remain unchanged. The research worker made no shared-code or registry changes.')
t+='''\n## Independent verification and final research freeze\nThe final-byte independent replay passed: 716 citable facts, 420 exact maker equipment rows, 114 feature replacements with 182 dependencies, full before-state and canonical parity, actual evidence pack and portable roundtrip equality, 11 negative mutation classes, 28 ranking exclusions and 28 secondary-promotion guards. All 111 captured source files were hash-verified. The eight approved artifact hashes remain unchanged. The pre-integration manifest and reviewer verification are preserved as historical snapshots; the final manifest also includes these finalization records.\n\nParent production checks, registered coverage parity and the recovery backup are separate completion gates. Their results belong in the parent QA and recovery records; this frozen research bundle does not claim an unfinished production check has passed. No further research or approved-packet edits are pending.\n''';p.write_text(t)
p=R/'terms-worker.md';t=p.read_text();note='''## Final superseding price finding\nAfter this initial worker report, the independent reviewer successfully used the ordinary dot-cloud Chrome configurator and captured all four current exact-grade maker base/MSRP prices. UT Premium/Luxury are A$31,990/A$35,990 and V Premium/Luxury are A$42,590/A$44,590 before on-road fees. These Confirmed rung-1 captures supersede the unresolved-maker-price statements and fallback recommendation below. See `terms/maker-price-browser-provenance.json` and `independent-review/source-review.md`. The original research below is preserved as the earlier evidence-search history.\n\n'''
assert '## Final superseding price finding' not in t
p.write_text(t.replace('## Findings to use immediately',note+'## Initial findings to use immediately',1))
patterns={
'private_key':re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
'bearer_value':re.compile(r'Bearer\s+[A-Za-z0-9_\-.+/=]{24,}'),
'jwt_value':re.compile(r'eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}'),
'secret_assignment':re.compile(r'(?i)(?:access_token|refresh_token|id_token|client_secret|csrf_token|session_token|api_key)\s*[\"\x27]?\s*[:=]\s*[\"\x27][A-Za-z0-9_\-.+/=]{24,}[\"\x27]'),
'openai_key':re.compile(r'\bsk-(?:proj-)?[A-Za-z0-9_-]{30,}'),
}
scanned=[];matches=[]
for p in sorted(R.rglob('*')):
 if p.is_file() and p.suffix.lower() in ['.json','.txt','.html','.md','.log','.js','.py','.ts']:
  scanned.append(str(p.relative_to(R)));txt=p.read_text(errors='replace')
  for name,pat in patterns.items():
   for m in pat.finditer(txt):matches.append(dict(path=str(p.relative_to(R)),pattern=name,line=txt.count('\n',0,m.start())+1))
assert not matches,matches
save('final-value-privacy-audit.json',dict(checkedAt=now,status='passed',scannedTextFiles=len(scanned),scannedPaths=scanned,patternNames=list(patterns),sensitiveValueMatches=matches,limitations='Bounded credential-value scan, not an exhaustive security certification. Public PDF and image files retain provenance and hashes but are not content-scanned here. Root recovery privacy gate remains separate.',sourceTransformationRecord='redaction-transformations.json',browserScreenshotsIncluded=False))
old={r['path']:r['sha256'] for r in previous['files']}
current={str(p.relative_to(R)):sha(p) for p in R.rglob('*') if p.is_file() and p.name!='artifact-hash-manifest.json'}
save('finalization-changes.json',dict(checkedAt=now,baseline='pre-integration-artifact-hash-manifest.json',changedExisting=[dict(path=k,beforeSha256=v,afterSha256=current[k])for k,v in old.items()if current[k]!=v],addedFiles=sorted(set(current)-set(old)),removedFiles=sorted(set(old)-set(current)),approvedHashesUnchanged=review['approvedHashes'],notes='Final manifest additionally includes this change record; the record excludes its own hash. No approved source, packet, reconciliation, core matrix or completeness audit changed.'))
files=[dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(R.rglob('*')) if p.is_file() and p.name!='artifact-hash-manifest.json']
save('artifact-hash-manifest.json',dict(checkedAt=now,scope='Final frozen GAC research bundle, after independent approval and parent registration. Root production/recovery records remain separate.',packetSha256=review['approvedHashes']['gac-2026-10-14.json'],reconciliationSha256=review['approvedHashes']['gac-reconciliation-2026-10-14.json'],files=files,note='Manifest excludes itself. Preserve final bytes. Pre-integration manifest and reviewer records are separate historical snapshots.'))
for name in ['REVIEW.md','integration-readiness.json','registered-immutable-audit.json','final-value-privacy-audit.json','finalization-changes.json','artifact-hash-manifest.json']:
 shutil.copyfile(R/name,QA/('gac-research-'+name))
for row in files: assert sha(R/row['path'])==row['sha256'],row['path']
for name,h in review['approvedHashes'].items(): assert sha(R/name)==h,name
print(json.dumps(dict(status='research-frozen',artifactFiles=len(files),sourceCaptures=111,manifestSha256=sha(R/'artifact-hash-manifest.json'),packetSha256=sha(R/'gac-2026-10-14.json'),reconciliationSha256=sha(R/'gac-reconciliation-2026-10-14.json'),unchangedOriginalDataFiles=94,registryAppendProven=True,privacyTextFiles=len(scanned),sensitiveValueMatches=0,changedExistingFiles=[r['path']for r in load('finalization-changes.json')['changedExisting']]),indent=2))
