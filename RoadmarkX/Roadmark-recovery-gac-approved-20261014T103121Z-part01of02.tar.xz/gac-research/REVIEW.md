# GAC Australian BEV research — 14 October 2026

Four current versions are established: AION UT Premium/Luxury and AION V Premium/Luxury. Manufacturer model year remains unspecified. No duplicate year identities were invented from seller/build labels or 2027 editorial headings.

## Buyer facts
- Maker base/MSRP: UT A$31,990 / A$35,990; V A$42,590 / A$44,590. Ordinary cloud-browser captures retain exact grade and base/on-road separation. Separate VIC 3000 Personal driveaway estimates are not national prices or personalised quotes
- UT: 430 km WLTP, 60 kWh LFP, 87 kW DC, 11 kW AC. Approximately 34-minute 10–80% duration is Reported; maker 24-minute 30–80% remains separate
- V: 510 km WLTP, 75.26 kWh LFP, 180 kW DC, maker 24-minute 10–80%, 11 kW AC. 7.9-second acceleration is Reported
- Both are five-seat FWD cars with 150 kW. Braked towing is not reliably published after maker/manual and contradictory secondary-database checks
- UT standard block-method cargo is 321 L; V lower declared cargo is 427 L with method unspecified. No VDA or folded-seat method is invented
- Private vehicle warranty is 8 years/unlimited kilometres; battery is 8 years/200,000 km. Commercial and battery-SOH wording issues remain explicit. Roadside starts with 12 months, then dealer-service renewal up to five years
- UT five-star ANCAP result published 12 October 2026 is included as Reported direct assessor evidence. eCall hardware is fitted but service activation is not yet operational

## Commercial closure
Current maker range plus complete CarExpert and CarsGuide brand lists support the four grades. UT 44 kWh / Standard Range is reported for December 2026, Hyptec HT remains a future Australian lead and UT Cross is overseas-only evidence. A stale 2025 V Luxury new ad is now explicitly Demo on the dealer page. Other year-labelled New advertisements do not establish separate maker cohorts or certify registration/warranty history.

This is research closure for the brand, not global C1–C6 completion. All 68 core cells are reviewed: 60 Confirmed, 4 Reported and 4 Not published. C3/C4/C6 pass; C1 awaits whole-market lists, C2 has genuine towing gaps, and C5 excludes reported charge times, unknown-method V cargo and missing towing.

## Deliverable and safeguards
The dated packet passed independent review and was registered by the parent at 10:22 UTC on 14 October 2026. It has 704 guarded specific fact edits, three shared terms, 114 equipment replacements and four supported summary pairs. All four versions already existed, so full existing before-state guards apply and no new-version baseline is required. All 95 pre-existing data files were unchanged at review. The subsequent parent registry append is separately proven by restoring its prior bytes in memory; the other 94 files remain unchanged. The research worker made no shared-code or registry changes.

The normalized evidence and terms JSON files are authoritative final builder inputs. Intermediate research scripts may recreate earlier research stages; recreate the final packet with build-packet.py only. The source index, capture hashes, core matrix, immutable-data audit and privacy records accompany the staged packet. No user-computer work, publication, login, CAPTCHA, third-party communication or browser-screenshot upload occurred.

## Independent verification and final research freeze
The final-byte independent replay passed: 716 citable facts, 420 exact maker equipment rows, 114 feature replacements with 182 dependencies, full before-state and canonical parity, actual evidence pack and portable roundtrip equality, 11 negative mutation classes, 28 ranking exclusions and 28 secondary-promotion guards. All 111 captured source files were hash-verified. The eight approved artifact hashes remain unchanged. The pre-integration manifest and reviewer verification are preserved as historical snapshots; the final manifest also includes these finalization records.

Parent production checks, registered coverage parity and the recovery backup are separate completion gates. Their results belong in the parent QA and recovery records; this frozen research bundle does not claim an unfinished production check has passed. No further research or approved-packet edits are pending.
