import urllib.request,pathlib,json,re,html,sys,time
R=pathlib.Path('/tmp/gac-research');
def capture(key,url):
 p=R/'current'/key
 try:
  with urllib.request.urlopen(url,timeout=65) as r:b=r.read();final=r.url;status=r.status
  p.write_bytes(b)
  if not key.endswith('.pdf'):
   s=b.decode();s=re.sub(r'<(script|style)[\s\S]*?</\1>','',s,flags=re.I);s=re.sub('<[^>]+>','\n',s);s=html.unescape(s);s='\n'.join(x.strip() for x in s.splitlines() if x.strip());p.with_suffix('.txt').write_text(s)
  print(key,status,len(b),final,flush=True)
 except Exception as e:print(key,type(e).__name__,str(e),flush=True)
if __name__=='__main__':
 for key,url in json.loads(sys.argv[1]):capture(key,url)
