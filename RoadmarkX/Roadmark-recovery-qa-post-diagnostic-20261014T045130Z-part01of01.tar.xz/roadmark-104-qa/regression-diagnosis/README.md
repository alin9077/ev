# Roadmark M1 regression diagnosis, 2026-10-14

## Verified initial findings

The full suite through Hyundai was interrupted with no final exit/status or aggregate summary. It observed file-level failures for citable and domain plus the local-review startup timeout. The file-level failure signals were not preserved; an out-of-memory cause is plausible but **not established**. Do not label that run completed or passed.

Controlled isolated runs used Node v24.19.0, NODE_OPTIONS=--max-old-space-size=3072, the TAP reporter and --test-concurrency=1. No simultaneous heavy processes were started by this worker. `/usr/bin/time` is absent, so the Python wrappers retain separate stdout/TAP and stderr, terminal exit code, UTC timing, wall/user/system time and maximum child RSS via resource.getrusage.

- Unchanged local-review: failed exactly at Startup timeout, 15,060 ms test duration, 17.51 s process wall time, exit 1, 818,848 KB maximum RSS, empty stderr
- Unchanged domain: all 26 tests passed, 296.76 s wall time, exit 0, 1,926,768 KB maximum RSS
- Unchanged service startup, with read-only module-boundary timing: readiness at 59.90 s and 1,303,664 KB maximum RSS. Import loading used 2.46 s; catalogue 12.14 s; research 0.35 s; all 363 effective-feature validations 44.68 s. The server was terminated cleanly after readiness with SIGTERM; this intentional shutdown is recorded separately from readiness success

The server currently validates every equipment claim and constructs availability claims before listening, then ensures its queue exists. That eager all-claim readiness contract is preserved.

## Bounded changes

- pairReport accepts an optional caller-scoped snapshot and forwards the exact reference to both existing pack calls
- Omitting the snapshot still invokes the default pack loaders on each call; no global cache was added
- Domain and citable share one current fixture per file. Domain's independent historical source fixtures and the explicit live counts test remain separate
- All prior assertions are retained. Lightweight forwarding, default freshness, error propagation and unknown-slug checks are added, plus a real source-drift check after successful reuse of the same supplied snapshot
- Local-review uses a named 120-second startup budget, based on the measured 59.90-second startup and constrained executor variability. Every origin, claim-binding, persistence and cleanup assertion remains unchanged
- Production data/validation code, the service and source research packets are unchanged

## Open performance issue

The approximately 60-second review-service preflight remains an open performance issue. It is **not** an acceptable mobile page-load metric and is **not** a passed performance target. Increasing the integration test's startup allowance only allows its existing security and persistence assertions to execute after full validation. Any future startup optimization must preserve eager all-claim validation and source/identity/dependency drift rejection, or explicitly establish an equally safe readiness contract. No production startup optimization was attempted here.

## Evidence bundle

- `before/` and `unchanged-source.sha256`: pre-edit source evidence
- `snapshot-reuse.patch`: complete unified patch, including new regressions and documented test budget
- `*.tap`, `*.stderr`, `*.exit`, `*.resources.json`: individual completed checks
- `trace-server.cjs`, `measure-server.py`: non-persisted/read-only server timing instrumentation and bounded readiness observer
- `run-isolated.py`, `run-command.py`: reproducible sequential measurement helpers

## Final validation

Five nonoverlapping final runs passed **85 tests across seven distinct files**, with zero failures, skips or cancellations:

- Pair-report snapshot and existing catalogue reuse: 10 tests, 1.79 s, `pair-report-snapshot-final.tap`
- Domain: 26 tests, 164.76 s, `domain-snapshot.tap`
- Citable: 13 tests, 26.88 s, `citable-snapshot.tap`
- Local-review HTTP integration: 1 test, 82.96 s, `local-review-budget.tap`
- Existing brand fact/equipment guards: 35 tests, 88.48 s, `brand-guards.tap`

The initial lightweight run was repeated after a lint-only local-variable rename and is not counted twice. The unchanged baseline domain run is also excluded from the final total. Full TypeScript checking (`--noEmit --incremental false`) and full lint over `src tests scripts` both exited 0; their final stdout and stderr are empty. The first lint run's four reserved `module` local-name errors remain recorded, followed by the corrected `pairSource` rerun.

Domain's isolated wall time fell 44.48%, from 296.76 s to 164.76 s; peak RSS fell from 1,926,768 KB to 1,707,504 KB. Citable has no completed comparable unchanged isolated baseline, so no percentage improvement is claimed. Core data, brand validation and production service hashes match their pre-edit values.

`final-summary.json` contains exact commands, selected files, run counts, times, resource observations and final source hashes. Independent static review is in `independent-snapshot-reuse-review.md`; its manifest records the reviewed tree.

Focused checks do not constitute a full aggregate suite or production build pass. The broad suite was not rerun, and the original file-level failure mechanism remains unproven. No publication occurred.
