import datetime, json, os, pathlib, resource, subprocess, sys, time
name, target = sys.argv[1:3]
root = pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104-qa/regression-diagnosis')
env = {**os.environ, 'NODE_OPTIONS': '--max-old-space-size=3072'}
cmd = ['node', '--import', 'tsx', '--test', '--test-reporter=tap', '--test-concurrency=1', *sys.argv[2:]]
start = time.monotonic()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root / (name + '.tap')).open('w') as stdout, (root / (name + '.stderr')).open('w') as stderr:
    result = subprocess.run(cmd, env=env, stdout=stdout, stderr=stderr)
r = resource.getrusage(resource.RUSAGE_CHILDREN)
record = {'command': cmd, 'NODE_OPTIONS': env['NODE_OPTIONS'], 'started_utc': started, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'elapsed_s': time.monotonic()-start, 'exit_code': result.returncode, 'user_s': r.ru_utime, 'system_s': r.ru_stime, 'max_rss_kb': r.ru_maxrss, 'minor_page_faults':r.ru_minflt,'major_page_faults':r.ru_majflt,'voluntary_context_switches':r.ru_nvcsw,'involuntary_context_switches':r.ru_nivcsw,'swap_outs':r.ru_nswap,'input_blocks':r.ru_inblock,'output_blocks':r.ru_oublock}
(root / (name + '.resources.json')).write_text(json.dumps(record, indent=2) + '\n')
(root / (name + '.exit')).write_text(str(result.returncode) + '\n')
print(json.dumps(record, indent=2))
sys.exit(result.returncode if result.returncode >= 0 else 128 - result.returncode)
