const Module = require('node:module');
const { performance } = require('node:perf_hooks');
const load = Module._load;
const start = performance.now();
const totals = new Map();
function log(value) { process.stderr.write(`${JSON.stringify({ elapsed_ms: performance.now() - start, ...value })}\n`); }
log({ stage: 'preload' });
Module._load = function(request, parent, isMain) {
  const value = load.apply(this, arguments);
  if (request !== '../src/lib/data' || !parent?.filename.endsWith('/scripts/serve-roadmark.ts')) return value;
  log({ stage: 'data_import_complete' });
  const wrapped = { ...value };
  for (const name of ['catalogue', 'research', 'effectiveFeatures']) {
    wrapped[name] = function(...args) {
      const now = performance.now();
      try { return value[name](...args); }
      finally {
        const duration = performance.now()-now;
        const total = totals.get(name) || { calls: 0, total_ms: 0 };
        total.calls++; total.total_ms += duration; totals.set(name, total);
        if (name !== 'effectiveFeatures' || total.calls % 10 === 0) log({ stage: name, ...total, last_ms: duration, rss_kb: process.memoryUsage().rss/1024 });
      }
    };
  }
  const write = process.stdout.write;
  process.stdout.write = function(chunk, ...args) {
    if (String(chunk).includes('Roadmark local preview:')) log({ stage: 'ready', totals: Object.fromEntries(totals), rss_kb: process.memoryUsage().rss/1024 });
    return write.call(this, chunk, ...args);
  };
  return wrapped;
};
