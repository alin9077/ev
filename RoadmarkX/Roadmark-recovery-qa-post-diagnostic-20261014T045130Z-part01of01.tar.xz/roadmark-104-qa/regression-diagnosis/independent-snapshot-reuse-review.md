# Independent review: explicit snapshot reuse

Initially reviewed 2026-10-14 at 04:42 UTC; narrow final-code re-review at 04:48 UTC. Outcome: **no blocking code finding; static approval**, with 85 focused runtime tests now passed in owner-produced logs. This is not a full-suite or production performance sign-off. Full final TypeScript and lint reruns subsequently passed (logs checked at 04:49 UTC).

## Scope and evidence

Read the complete `snapshot-reuse.patch`, all five final changed files, the before copies, affected production call chain, existing mutation/guard tests, and available result logs. No source files were edited. No test, build, server, lint, or other heavy process was started by this reviewer. This checkout has no Git metadata, so scope is based on the saved patch and before copies, with reviewed hashes in `independent-review-manifest.json`.

## Findings

1. **Explicit reuse preserves default behavior.** `src/lib/pair-pages.ts:21–33` accepts the existing `pack` snapshot type and forwards the exact supplied object to both exact-trim calls. It adds no memoization, cloning, exception handler, retry, fallback, or changed slug resolution. Omission forwards `undefined`; unchanged `src/lib/data.ts:729–736` invokes its ordinary `research()`/`catalogue()` path and re-evaluates features. This preserves the existing React-cache/request-context semantics rather than promising unconditional global freshness beyond them.

2. **Guard contracts remain intact.** SHA-256 hashes of `src/lib/data.ts`, `src/lib/brand-updates.ts`, and `scripts/serve-roadmark.ts` match `unchanged-source.sha256`. Current packs still pass through `effectiveFeatures` and the current-car marker at `src/lib/data.ts:645–654`; source comparison remains in `src/lib/brand-updates.ts:169–192`, and feature source/version/dependency checks remain at `1003–1069`. Missing cited evidence still fails at `src/lib/data.ts:789–792`. No historical-source fallback was introduced.

3. **Mutable supplied snapshots are not silently retained in a new cache.** `tests/citable.test.ts:242–268` exercises one successful real report, mutates only a cloned source title while retaining the same supplied snapshot identity, requires rejection on the next call, restores the title, and requires success again. It also checks the original file-local source was not mutated. Existing public-row replacement coverage remains at `tests/home-payload.test.ts:230–255`; this patch does not modify it. The new real-source-drift case passed in the owner-produced `citable-snapshot.tap`.

4. **Original assertions and historical boundaries are preserved.** Complete before/after diff review found no changed expected values, omitted assertions, reduced loops, skips, or focused-only tests. Domain retains 26 original test titles and 117 assertion calls. Citable retains all 12 original test titles and 62 original assertion calls, adding one test and six assertions. Local review retains its one test and all 19 assertions. Domain's separate historical fixture stays at `tests/domain.test.ts:28–30`; historical callers still use `sourcePack`. Validator mutation is confined to a structured clone at `95–98`. The citable phase-label case replaces its returned Pack's car property with a spread copy at `223–230`, so sharing the file-local catalogue does not contaminate it.

5. **New lightweight coverage is appropriate.** `tests/pair-report-snapshot.test.ts:27–52` checks exact-reference forwarding, ordered IDs, report path and no mutation; `54–75` checks fresh default loader invocation and changed results across calls; `77–92` checks both baseline and rival exceptions propagate identically without retry; `94–103` checks unknown slugs avoid all pack work with and without a snapshot. They execute actual transpiled pair-pages source using the established helper. The owner-produced `pair-report-snapshot-final.tap` reports all 10 combined pair-report/catalogue-reuse checks passed after the lint-only identifier rename, zero skipped/cancelled.

6. **HTTP security and durability assertions are still reachable.** `tests/local-review.test.ts:89–98` still rejects foreign origins and checks no file was written. Exact fact/feature/availability binding and persisted values remain at `99–160`; private queue access remains 404 at `161`; process and temporary-directory cleanup remains at `162–168`. `package.json:12` still discovers all root test files, including security/guard files, with no exclusions added. The owner-produced `local-review-budget.tap` subsequently reports this complete live integration test passed, so the unchanged foreign-origin, exact-claim, persistence and private-queue assertions were executed successfully.

7. **Startup allowance is justified, without a speed claim.** The only local-review behavior change is the test readiness budget from 15 seconds to 120 seconds (`tests/local-review.test.ts:17–19, 37–40`). Production eager equipment claim preflight is unchanged at `scripts/serve-roadmark.ts:24–36`, before HTTP server setup. The existing 15-second test failed on startup (`local-review-unchanged.tap`). The separately traced unchanged server reached readiness in 59.897 seconds with 363 effectiveFeatures calls (`local-review-startup-traced.resources.json` and `.stderr`). This supports an increased integration-test allowance; it is not a startup optimization or production performance pass. A contended full run must still establish that the new allowance is sufficient.

## Narrow final-code re-review

The only subsequent edit was renaming the local `module` variable to `pairSource` in all four tests in `tests/pair-report-snapshot.test.ts` (declarations at lines 34, 57, 81 and 95). Reversing that identifier replacement reproduces the previously reviewed SHA-256 exactly. Every other reviewed changed-file and protected-file hash is unchanged. No test behavior or assertion was changed. The initial full lint failure is preserved in `lint.stdout` and identifies only these four `@next/next/no-assign-module-variable` violations. The final affected 10-test run passed after the rename.

## Verified runtime status at 04:49 UTC

All following counts are distinct, nonoverlapping owner-produced runs; reruns are not counted twice. Total: **85 tests across seven files**, all passed, zero failed/skipped/cancelled.

- `pair-report-snapshot-final.tap`: 10 tests in pair-report-snapshot and catalogue-reuse, final identifier rename included; exit 0
- `domain-snapshot.tap`: 26 tests; exit 0; isolated wall time 164.761 seconds versus the unchanged baseline's 296.759 seconds on this executor
- `citable-snapshot.tap`: 13 tests, including real same-snapshot source drift rejection and recovery; exit 0
- `local-review-budget.tap`: 1 live integration test with all security/persistence assertions; exit 0; total test-process wall time 82.964 seconds (this is not an isolated startup-duration measurement)
- `brand-guards.tap`: 35 tests in brand-updates and brand-feature-updates; exit 0
- Full final TypeScript and lint reruns passed: `typecheck-final` and `lint-final` each have exit 0 and empty stdout/stderr, independently read from the owner-produced logs
- Earlier broad suite was interrupted. No broad-suite success or production startup optimization is claimed here

Before-patch diagnosis remains recorded: unchanged domain passed 26/26 in 296.759 seconds, unchanged local-review failed at the 15-second startup timer, and the separately traced unchanged server reached readiness in 59.897 seconds with all 363 effectiveFeatures preflight calls.

Any change to the recorded hashes requires re-review of the affected file. The broad suite remains unverified; these focused runs and aggregate static checks must not be described as a complete broad-suite pass.
