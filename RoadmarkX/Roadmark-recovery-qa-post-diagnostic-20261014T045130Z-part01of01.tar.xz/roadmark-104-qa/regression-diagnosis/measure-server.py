import datetime, json, os, pathlib, resource, selectors, subprocess, sys, tempfile, time
root = pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104-qa/regression-diagnosis')
name = 'local-review-startup-traced'
cmd = ['node', '--require', str(root/'trace-server.cjs'), '--import', 'tsx', 'scripts/serve-roadmark.ts']
started = datetime.datetime.now(datetime.timezone.utc).isoformat(); start=time.monotonic(); ready=False; output=''; timed_out=False
with tempfile.TemporaryDirectory(prefix='roadmark-startup-diagnostic-') as directory, (root/(name+'.stdout')).open('w') as stdout, (root/(name+'.stderr')).open('w') as stderr:
    child=subprocess.Popen(cmd,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=3072','PORT':'0','ROADMARK_REVIEW_DIR':directory},stdout=subprocess.PIPE,stderr=stderr,text=True)
    selector=selectors.DefaultSelector(); selector.register(child.stdout,selectors.EVENT_READ)
    try:
        while child.poll() is None:
            if time.monotonic()-start>180: timed_out=True; break
            if selector.select(timeout=.5):
                line=child.stdout.readline(); output+=line; stdout.write(line); stdout.flush()
                if 'Roadmark local preview:' in line: ready=True; break
    finally:
        if child.poll() is None:
            child.terminate()
            try: child.wait(timeout=10)
            except subprocess.TimeoutExpired: child.kill(); child.wait()
        selector.close()
r=resource.getrusage(resource.RUSAGE_CHILDREN)
result={'command':cmd,'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'readiness_observed':ready,'timed_out':timed_out,'elapsed_s':time.monotonic()-start,'exit_code_after_clean_termination':child.returncode,'max_rss_kb':r.ru_maxrss,'user_s':r.ru_utime,'system_s':r.ru_stime,'stdout':output}
(root/(name+'.resources.json')).write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))
sys.exit(0 if ready else 1)
