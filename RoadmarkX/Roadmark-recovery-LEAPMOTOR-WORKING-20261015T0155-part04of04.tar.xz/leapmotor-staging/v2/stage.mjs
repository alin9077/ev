/** One complete derived-baseline composition, selected consumers and actual coverage report. No production loader or registry mutation. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {fileHash,readJson,locate,pin,readResearch,digestRows,assertResearchUnchanged} from '/tmp/xpeng-staging-plan/baseline-io.mjs';
import {readCompleteCars} from '/tmp/mercedes-staging-plan/staging-preparation/shape-first-v3/read-complete-storage.mjs';
import {assertDeclaredJson} from '/tmp/mercedes-staging-plan/consumer-preparation/v5/feature-json-parity.mjs';
const args=process.argv.slice(2);assert.equal(args.length,4);assert.equal(args[0],'--manifest');assert.equal(args[2],'--manifest-sha256');assert.equal(fileHash(args[1]),args[3]);
const m=readJson(args[1]);assert.equal(process.cwd(),m.repo);assert.equal(process.env.NODE_OPTIONS,undefined);assert.equal(typeof global.gc,'function');assert.equal(process.version,m.nodeVersion);assert.deepEqual(process.execArgv,m.execArgv);
assert.equal(m.mode,'derived-current-baseline-plus-one-feature-free-packet');assert.equal(m.productionRegistrationAuthorized,false);assert.equal(m.canonicalRecaptureAuthorized,false);
for(const row of m.pins){assert.equal(fs.statSync(row.path).size,row.bytes);assert.equal(fileHash(row.path),row.sha256);}
function progress(phase){const row=JSON.stringify({at:new Date().toISOString(),phase})+'\n';const fd=fs.openSync(path.join(m.runOutput,'progress.jsonl'),'a');try{fs.writeSync(fd,row);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}console.log(phase);}
progress('Inputs pinned; restoring accepted derived baseline');
const accepted=readJson(m.acceptedManifest.path);const anchors=accepted.anchors;const pins=new Map(accepted.inputPins.map(r=>[r.anchor+'\0'+r.file,r]));
const proof={anchors,assertPinned(ref){const expected=pins.get(ref.anchor+'\0'+ref.file);assert(expected,'Existing accepted pin required');assert.equal(ref.sha256,expected.sha256);assert.equal(ref.bytes,expected.bytes);}};
const original=await readCompleteCars(proof,m.storageIndex);const index=original.index;
assert.equal(original.cars.length,409);assert.equal(index.asOf,m.asOf);
for(const ref of Object.values(index.research))proof.assertPinned(ref);
let originalData=await readResearch(anchors,index,Object.keys(index.research));assert.equal(Object.keys(originalData).length,14);assert.equal(originalData.variants.length,409);assert.deepEqual(originalData.variants.map(v=>v.id),original.cars.map(c=>c.id));
const require=createRequire(m.repo+'/package.json');
const {prepareBrandResearch,applyBrandUpdates}=require('./src/lib/brand-updates.ts');
const {brandUpdatePackets}=require('./src/lib/brand-update-registry.ts');
const packet=readJson(m.packet.path),correction=readJson(m.correction.path);assert.equal(packet.id,m.packetId);assert.equal(brandUpdatePackets.length,21);assert.deepEqual(brandUpdatePackets.at(-1),correction);assert.deepEqual(originalData.metadata.brand_update_packet_ids,brandUpdatePackets.slice(0,-1).map(p=>p.id));
assert.equal(correction.variants.length,0);assert.equal(correction.models.length,0);assert.equal(correction.facts.length,1);assert.equal(correction.facts[0].variantId,m.eqaId);
const before20Digests=original.cars.map(c=>({id:c.id,...digestRows([c])}));
const transitions=[];
function compose(base,onePacket,ids){
 const before=digestRows([base.metadata]);const raw=prepareBrandResearch(base,[onePacket]);assert.deepEqual(Object.keys(raw),Object.keys(base));assert.deepEqual(raw.metadata.brand_update_packet_ids,[onePacket.id]);
 const rawMetadata=structuredClone(raw.metadata);const data={...raw,metadata:{...raw.metadata,brand_update_packet_ids:ids}};
 for(const key of Object.keys(raw))if(key!=='metadata')assert.equal(data[key],raw[key]);
 for(const key of Object.keys(raw.metadata))if(key!=='brand_update_packet_ids')assert.deepEqual(data.metadata[key],raw.metadata[key]);
 transitions.push({packetId:onePacket.id,beforeMetadataDigest:before,rawInvocationMetadata:rawMetadata,composedMetadata:structuredClone(data.metadata),onlyCompositionPath:'metadata.brand_update_packet_ids'});return data;
}
const currentData=compose(originalData,correction,brandUpdatePackets.map(p=>p.id));
for(const key of Object.keys(originalData))if(key!=='metadata')assert.deepEqual(currentData[key],originalData[key],'EQA correction does not change Research field '+key);
for(const key of Object.keys(originalData.metadata))if(key!=='brand_update_packet_ids')assert.deepEqual(currentData.metadata[key],originalData.metadata[key]);
const currentCars=applyBrandUpdates(original.cars,currentData,[correction]);assert.equal(currentCars.length,409);assert.equal(currentData.variants.length,409);
for(const [i,c]of currentCars.entries()){
 const prior=original.cars[i];assert.equal(c.id,prior.id);
 if(c.id!==m.eqaId)assert.deepEqual(c,prior);else{const expected={...prior,facts:{...prior.facts,towing_braked_kg:correction.facts[0].after}};assert.deepEqual(c,expected);}
}
assertResearchUnchanged(originalData,index);for(const [i,c]of original.cars.entries())assert.deepEqual({id:c.id,...digestRows([c])},before20Digests[i]);
const currentFieldDigests=Object.fromEntries(Object.entries(currentData).map(([k,v])=>[k,digestRows(Array.isArray(v)?v:[v])]));
const currentCarDigests=currentCars.map(c=>({id:c.id,...digestRows([c])}));const selectedIds=new Set(m.existingIds);const selectedBefore=readJson(m.selectedBefore.path);assert.deepEqual(currentCars.filter(c=>selectedIds.has(c.id)),selectedBefore);
progress('Current 409-car prefix21 verified; applying Leapmotor only');
const allPackets=[...brandUpdatePackets,packet];const data=compose(currentData,packet,allPackets.map(p=>p.id));const cars=applyBrandUpdates(currentCars,data,[packet]);
assert.equal(cars.length,413);assert.equal(data.variants.length,413);assert.equal(new Set(cars.map(c=>c.id)).size,413);assert.deepEqual(cars.map(c=>c.id),[...currentCars.map(c=>c.id),...m.newIds]);assert.deepEqual(data.metadata.brand_update_packet_ids,allPackets.map(p=>p.id));
let unchangedPeers=0;for(const [i,c]of currentCars.entries()){
 assert.deepEqual({id:c.id,...digestRows([c])},currentCarDigests[i]);const after=cars[i];
 if(!selectedIds.has(c.id)){assert.deepEqual(after,c);unchangedPeers++;continue;}
 const touched=new Set([...packet.facts.filter(f=>f.variantId===c.id).map(f=>f.after.key),...packet.brandTerms.filter(t=>t.applicableVariantIds.includes(c.id)).map(t=>t.key)]);
 for(const [key,f]of Object.entries(c.facts))if(!touched.has(key))assert.deepEqual(after.facts[key],f,'Untouched selected fact '+c.id+'/'+key);
 for(const key of ['id','modelId','brand','model','trim','year','generation','vehicleClass','drive'])assert.deepEqual(after[key],c[key]);
}
assert.equal(unchangedPeers,403);assert.equal(data.sources.length,currentData.sources.length+35);assert.deepEqual(data.sources.slice(0,currentData.sources.length),currentData.sources);
assert.deepEqual(data.models.slice(0,currentData.models.length),currentData.models);assert.equal(data.models.length,currentData.models.length+2);
for(const field of ['criteria','update_events','configuration_history','publication_issues','prior_update_summary','schema_version'])assert.deepEqual(data[field],currentData[field]);
for(const field of ['feature_evidence','trim_equipment','update_eligibility'])assert.deepEqual(data[field].slice(0,currentData[field].length),currentData[field]);
assert.deepEqual(data.feature_evidence_variant_context.slice(0,currentData.feature_evidence_variant_context.length),currentData.feature_evidence_variant_context);
assert.deepEqual(data.feature_evidence_variant_context.slice(currentData.feature_evidence_variant_context.length),packet.variants.map(v=>({id:v.id,model_id:v.model_id,record_state:v.record_state})));
assert.equal(data.feature_evidence_variant_context.length,currentData.feature_evidence_variant_context.length+4);
assert.equal(data.feature_evidence.length,currentData.feature_evidence.length+4*69);assert.equal(data.criteria.length,69);
for(const v of currentData.variants)if(!selectedIds.has(v.id))assert.deepEqual(data.variants.find(x=>x.id===v.id),v);
for(const [k,v]of Object.entries(currentData))assert.deepEqual(digestRows(Array.isArray(v)?v:[v]),currentFieldDigests[k]);
const finalFieldDigests=Object.fromEntries(Object.entries(data).map(([k,v])=>[k,digestRows(Array.isArray(v)?v:[v])]));const finalCarDigests=cars.map(c=>({id:c.id,...digestRows([c])}));
originalData=null;global.gc();
const {compiledSource}=require('./tests/helpers/compiled-source.ts');let loaderCalls=0;const forbidden=()=>{loaderCalls++;throw new Error('FORBIDDEN_DEFAULT_CATALOGUE_LOADER');};
const api=compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets:allPackets}}).createEvidenceConsumers({sourceResearch:forbidden,research:forbidden,catalogue:forbidden});
const {factClaim,featureClaim}=require('./src/lib/citable.ts');const {availabilityReportClaim}=require('./src/lib/availability-corrections.ts');const {buyerAvailabilityText}=require('./src/lib/buyer-availability.ts');
const {storePortablePacks,hydratePortablePacks}=require('./src/lib/portable-packs.ts');
progress('Candidate 413 cars and all14 fields verified; producing ten actual consumer packs');
const selected=cars.filter(c=>c.brand==='Leapmotor');assert.equal(selected.length,10);const packs={},claims=[],featureOmissions=[];let factClaims=0,featureClaims=0;
for(const car of selected){
 const pack=api.pack(car.id,{data,cars});assert.deepEqual(pack.car,car);assert.equal(pack.features.length,69);assert.equal(new Set(pack.features.map(f=>f.criterion)).size,69);packs[car.id]=pack;
 const permitted=new Set();for(const [i,f]of pack.features.entries())if(Object.hasOwn(f,'confirmation_needed')&&f.confirmation_needed===undefined){assert.equal(f.criterion,'novated_fbt');permitted.add('/packs/'+car.id+'/features/'+i+'/confirmation_needed');featureOmissions.push({carId:car.id,criterion:f.criterion,index:i,property:'confirmation_needed',ownUndefined:true});}
 assertDeclaredJson(pack,'/packs/'+car.id,permitted);
 for(const f of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===packet.id)){
  const claim=factClaim(pack,f,m.asOf);assert.equal(claim.buyerGrade,f.buyerGrade);assert.deepEqual(claim.sources.map(s=>s.id),f.sourceIds);for(const s of claim.sources){const raw=data.sources.find(x=>x.id===s.id);assert(raw);assert.deepEqual(pack.sources.find(x=>x.id===s.id),raw);for(const k of ['url','publisher','title','accessed_date','published_date','market'])assert.equal(s[k],raw[k]);}claims.push({carId:car.id,key:f.key,claim});factClaims++;
 }
 for(const f of pack.features){const claim=featureClaim(pack,f.criterion,f.criterion,m.asOf);assert(claim);assert.deepEqual(claim.sources.map(s=>s.id),[...new Set(f.source_ids)]);featureClaims++;}
 const availability=buyerAvailabilityText(car);assert.equal(availability,car.availability==='announced_provisional'?'Order open or arriving':'On sale now');claims.push({carId:car.id,key:'availability',buyerAvailability:availability,claim:factClaim(pack,availabilityReportClaim(car),m.asOf)});
 if(car.model==='B03X'){assert(car.availabilityEvidence.qualifications.some(q=>q.includes('dealership arrival expected November 2026')));assert(!Object.hasOwn(car.availabilityEvidence,'expectedDelivery'));}
 assert.equal(car.availabilityEvidence.physicalStockVerified,false);assert.equal(car.availabilityEvidence.factoryOrderAcceptanceVerified,false);assert(car.buyerSummary.strength&&car.buyerSummary.tradeoff);
}
assert.equal(factClaims,185);assert.equal(featureClaims,690);
const stored=storePortablePacks(packs);assert.deepEqual(hydratePortablePacks(stored,data.sources),packs);
const packJson=JSON.stringify(packs,null,2)+'\n',portableJson=JSON.stringify(stored,null,2)+'\n';assert.deepEqual(hydratePortablePacks(JSON.parse(portableJson),data.sources),JSON.parse(packJson));
const sourceById=new Map(data.sources.map(s=>[s.id,s]));for(const p of Object.values(packs))for(const s of p.sources)assert.deepEqual(s,sourceById.get(s.id));
progress('Ten actual packs/citations and serialized portable parity verified; building complete report');
// Actual current report loader, with only its implicit catalogue dependency replaced by the explicit full snapshot and actual consumer.
const loader=compiledSource('scripts/reporting/load.ts',{'../../src/lib/data':{catalogueSnapshot:forbidden,effectiveFeatures:api.effectiveFeatures}});const input=loader.loadReportInput({data,cars});assert.equal(input.cars,cars);assert.equal(input.sources,data.sources);assert.equal(input.features.length,413*69);
const {buildCoverageReport,formatCoverageReport}=require('./scripts/reporting/reports.ts');const report=buildCoverageReport(input,m.asOf);assert.equal(report.allCatalogueVersions,413);const brand=report.brandProgress.find(b=>b.brand==='Leapmotor');assert(brand);assert.equal(brand.onSaleVersions,7);assert.equal(brand.criteria.C1,false);
progress('Complete report built; verifying immutable inputs and writing outputs');
assert.equal(loaderCalls,0);assert(!require.cache[m.repo+'/src/lib/data.ts']);assert.deepEqual(brandUpdatePackets.map(p=>p.id),m.registeredPacketIds);
for(const [k,v]of Object.entries(data))assert.deepEqual(digestRows(Array.isArray(v)?v:[v]),finalFieldDigests[k]);for(const [i,c]of cars.entries())assert.deepEqual({id:c.id,...digestRows([c])},finalCarDigests[i]);
for(const row of m.pins){assert.equal(fs.statSync(row.path).size,row.bytes);assert.equal(fileHash(row.path),row.sha256);}
assert(!fs.existsSync(m.output));fs.mkdirSync(m.output);
const artifacts=[];function write(name,value,raw=false){const file=path.join(m.output,name);fs.writeFileSync(file,raw?value:JSON.stringify(value,null,2)+'\n',{flag:'wx'});artifacts.push({path:file,bytes:fs.statSync(file).size,sha256:fileHash(file)});}
write('metadata-composition.json',transitions);write('selected-after-cars.json',selected);write('staged-packs.json',packJson,true);write('portable-packs.json',portableJson,true);
assert.equal(fs.readFileSync(path.join(m.output,'staged-packs.json'),'utf8'),packJson);assert.equal(fs.readFileSync(path.join(m.output,'portable-packs.json'),'utf8'),portableJson);
assert.deepEqual(hydratePortablePacks(readJson(path.join(m.output,'portable-packs.json')),data.sources),readJson(path.join(m.output,'staged-packs.json')));
write('selected-citations.json',claims);write('portable-json-omissions.json',{allowedLocation:'Exact production audited novated_fbt feature own confirmation_needed: undefined only',observations:featureOmissions,allOtherPackValuesPlainJson:true,livePortableRoundtrip:true,writtenPortableRoundtrip:true});write('staged-report.json',report);write('staged-report.txt',formatCoverageReport(report,true)+'\n',true);write('car-digest-comparison.json',{baseline20:before20Digests,current21:currentCarDigests,candidate22:finalCarDigests});write('research-field-digests.json',{current21:currentFieldDigests,candidate22:finalFieldDigests});
write('stage-receipt.json',{status:'complete_derived_stage_pass_pending_independent_output_review',manifestSha256:args[3],packetSha256:m.packet.sha256,correctedBaselineCars:409,stagedCars:413,untouchedPeerCars:403,all14ResearchFieldsRetained:true,sourcePrefixUnchanged:true,actualSelectedDetailPacks:10,actualFactClaims:factClaims,actualFeatureClaims:featureClaims,inMemoryPortableExact:true,serializedPortableExact:true,omissionAudit:'portable-json-omissions.json',completeActualCoverageReport:true,defaultLoaderCalls:loaderCalls,metadataTransitions:['accepted20_to_corrected21','corrected21_to_candidate22'],olderAddedVersionsReplayed:false,productionRegistration:false,freshCanonicalRecapture:false,brand,artifacts,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log(JSON.stringify({status:'passed',output:m.output,brand,resourceUsage:process.resourceUsage()},null,2));
