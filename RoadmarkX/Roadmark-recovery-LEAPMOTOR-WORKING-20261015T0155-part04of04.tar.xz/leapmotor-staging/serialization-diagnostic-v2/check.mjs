/** Bounded selected-only diagnosis; does not read original full cars or hydrate a catalogue. */
import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {createRequire} from 'node:module';
import {readJson,fileHash,streamRows,digestRows} from '/tmp/xpeng-staging-plan/baseline-io.mjs';
const root='/tmp/leapmotor-staging/serialization-diagnostic-v2',repo='/workspace/scratch/586427eef9f2/roadmark-104';
const manifestPath='/tmp/leapmotor-staging/v2/manifest.json';assert.equal(fileHash(manifestPath),'16b514b62255e6269e9829f544b139164507095a0fd531290904f05bd32cec2e');const m=readJson(manifestPath),accepted=readJson(m.acceptedManifest.path);assert.equal(fileHash(m.acceptedManifest.path),m.acceptedManifest.sha256);
const index=readJson('/tmp/mercedes-staging-plan/staging-preparation/staging-artifacts/canonical-v1/staged-storage-index.json');assert.equal(fileHash('/tmp/mercedes-staging-plan/staging-preparation/staging-artifacts/canonical-v1/staged-storage-index.json'),m.storageIndex.sha256);
const before=readJson(m.selectedBefore.path);assert.equal(fileHash(m.selectedBefore.path),m.selectedBefore.sha256);const selected=new Set(before.map(c=>c.id));const modelIds=new Set(before.map(c=>c.modelId));
const base={};const reads=[];
for(const [key,ref]of Object.entries(index.research)){
 const values=[];await streamRows(accepted.anchors,ref,row=>{
  const keep=key==='variants'||key==='feature_evidence_variant_context'?selected.has(row.id):['feature_evidence','trim_equipment','update_eligibility'].includes(key)?selected.has(row.variant_id):key==='models'?modelIds.has(row.id):true;
  if(keep)values.push(row);
 });base[key]=ref.array?values:values[0];reads.push({field:key,inputRows:ref.rows,selectedRows:values.length,sha256:ref.sha256});
}
assert.equal(base.variants.length,6);assert.equal(base.feature_evidence.length,6*69);assert.equal(base.feature_evidence_variant_context.length,6);assert.equal(base.criteria.length,69);
const require=createRequire(repo+'/package.json');const {prepareBrandResearch,applyBrandUpdates}=require('./src/lib/brand-updates.ts');const {brandUpdatePackets}=require('./src/lib/brand-update-registry.ts');const {compiledSource}=require('./tests/helpers/compiled-source.ts');assert.equal(brandUpdatePackets.length,21);
const packet=readJson(m.packet.path);assert.equal(fileHash(m.packet.path),m.packet.sha256);const data=prepareBrandResearch(base,[packet]),after=applyBrandUpdates(before,data,[packet]);assert.deepEqual(after,readJson('/tmp/leapmotor-packet/v3/selected-core-after.json'));
let calls=0;const forbidden=()=>{calls++;throw new Error('FORBIDDEN_DEFAULT_LOADER');};const defaults={sourceResearch:forbidden,research:forbidden,catalogue:forbidden};
const factory=packets=>compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets:packets}}).createEvidenceConsumers(defaults);
const initial=factory(brandUpdatePackets),final=factory([...brandUpdatePackets,packet]);
const beforeFeatures={},afterFeatures={},observations=[],packs={};
function observe(car,pack,phase){
 const visit=(value,pointer)=>{
  if(value===undefined){observations.push({phase,variantId:car.id,pointer,ownUndefined:true});return;}
  if(!value||typeof value!=='object')return;
  for(const key of Object.keys(value))visit(value[key],pointer+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));
 };visit(pack,'/packs/'+car.id);
 return pack.features;
}
for(const c of before)beforeFeatures[c.id]=observe(c,initial.pack(c.id,{data:base,cars:before}),'before');
for(const c of after){const pack=final.pack(c.id,{data,cars:after});packs[c.id]=pack;afterFeatures[c.id]=observe(c,pack,'after');}
const {storePortablePacks,hydratePortablePacks}=require('./src/lib/portable-packs.ts');const stored=storePortablePacks(packs);assert.deepEqual(hydratePortablePacks(stored,data.sources),packs);assert.deepEqual(hydratePortablePacks(JSON.parse(JSON.stringify(stored)),data.sources),JSON.parse(JSON.stringify(packs)));
const existingFeatureSetsExact=Object.fromEntries(before.map(c=>[c.id,JSON.stringify(beforeFeatures[c.id])===JSON.stringify(afterFeatures[c.id])]))
for(const c of before)assert.deepEqual(afterFeatures[c.id],beforeFeatures[c.id],'Full live retained feature set unchanged, including own undefined and all defined values');
const witnesses=[];
for(const o of observations){
 const match=o.pointer.match(/\/features\/(\d+)\/([^/]+)$/);assert(match,'No undefined outside features: '+o.pointer);const i=Number(match[1]),prop=match[2];const rows=o.phase==='before'?beforeFeatures[o.variantId]:afterFeatures[o.variantId];const feature=rows[i];assert(Object.hasOwn(feature,prop));assert.equal(feature[prop],undefined);
 const knownProducer=['confirmation_needed','gradeReviewStatus','buyerGrade','gradeReview'].includes(prop);
 if(prop==='confirmation_needed')assert.equal(feature.criterion,'novated_fbt');
 if(prop==='gradeReviewStatus'){
  assert(selected.has(o.variantId),'No new-version gradeReviewStatus omission');const old=beforeFeatures[o.variantId].find(f=>f.criterion===feature.criterion);assert(old&&Object.hasOwn(old,prop)&&old[prop]===undefined);assert(feature.gradeReview);assert.deepEqual(feature.gradeReview,old.gradeReview);
 }
 witnesses.push({...o,criterion:feature.criterion,rowIndex:i,property:prop,enumerable:Object.getOwnPropertyDescriptor(feature,prop).enumerable,producer:prop==='gradeReviewStatus'?'src/lib/evidence-regrading.ts:185, retained earned feature review':prop==='confirmation_needed'?'src/lib/launch-evidence.ts:84, auditedFeature novated_fbt':['buyerGrade','gradeReview'].includes(prop)?'Optional withdrawn-review property; inspect exact review-required branch':'Unclassified optional undefined property; review required',sameExistingBeforeReview:prop==='gradeReviewStatus',knownProducer,needsAdditionalReview:!['confirmation_needed','gradeReviewStatus'].includes(prop)});
}
assert.equal(calls,0);assert(!require.cache[repo+'/src/lib/data.ts']);
const result={status:'bounded_selected_serialization_diagnosis',packetSha256:m.packet.sha256,baseScope:'Selected six exact cars/variants/features/context with full retained source registry and small shared supporting fields; not full Research or catalogue',readInputs:reads,selectedBeforeCars:6,selectedAfterCars:10,observations:witnesses,counts:{before:witnesses.filter(x=>x.phase==='before').length,after:witnesses.filter(x=>x.phase==='after').length,existingGradeReviewStatusAfter:witnesses.filter(x=>x.phase==='after'&&x.property==='gradeReviewStatus').length,novatedConfirmationAfter:witnesses.filter(x=>x.phase==='after'&&x.property==='confirmation_needed').length},beforeFeatureJsonDigests:Object.fromEntries(Object.entries(beforeFeatures).map(([id,f])=>[id,digestRows(f)])),afterFeatureJsonDigests:Object.fromEntries(Object.entries(afterFeatures).map(([id,f])=>[id,digestRows(f)])),productionCatalogueHydration:false,sourceEdits:false,stageRetry:false,defaultLoaderCalls:calls,existingLiveFeatureSetsDeepEqual:true,existingFeatureSetsExact,inMemoryPortableExact:true,serializedPortableExact:true,writtenPortableReadback:false,unreviewedOmissions:witnesses.filter(x=>x.needsAdditionalReview),proposedAllowance:'Only exact witnessed existing feature gradeReviewStatus own-undefined paths, each matched to the same pre-packet retained review, plus existing novated_fbt confirmation_needed scope. No generic undefined allowance.'};
fs.writeFileSync(root+'/diagnostic.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({status:result.status,counts:result.counts,diagnostic:root+'/diagnostic.json',sha256:fileHash(root+'/diagnostic.json')}));
