import json, hashlib, sys, re
from pathlib import Path
root=Path('/tmp/leapmotor-research')
source=Path(sys.argv[1])
d=json.loads(source.read_text())
columns=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg']
# Independently transcribed from retained public passages and visually checked Australian PDF technical tables.
expected=[
[35888,401,56.2,156,16,11,5,357,7.5,160,'RWD',4430,1880,1520,750],
[39888,482,67.1,174,18,11,5,357,6.7,160,'RWD',4430,1880,1520,750],
[37888,361,56.2,140,20,11,5,490,7.5,160,'RWD',4515,1885,1665,750],
[40888,434,67.1,168,20,11,5,490,7.5,160,'RWD',4515,1885,1665,750],
[45888,425,69.9,84,30,11,5,581,7.5,160,'RWD',4739,1900,1680,1500],
[49888,510,81.9,180,22,11,5,581,6.2,220,'RWD',4739,1900,1680,1500],
[26990,292,39.8,100,16,11,5,475,8.6,130,'FWD',4270,1810,1635,0],
[30990,382,53,133,16,11,5,475,8.6,145,'FWD',4270,1810,1635,0],
[53888,437,81.9,180,22,11,5,581,4,440,'AWD',4739,1900,1680,1500],
[46888,425,69.9,84,30,11,5,581,7.5,160,'RWD',4739,1900,1680,1500],
]
assert len(d['variants'])==10
records=[]; all_sources=set()
for i,(v,vals) in enumerate(zip(d['variants'],expected)):
 assert set(v['coreFacts'])==set(d['coreKeys'])
 for key,value in zip(columns,vals):assert v['coreFacts'][key]['value']==value,(v['id'],key)
 assert v['coreFacts']['warranty']['value']=='6 years / 150,000 km'
 assert v['coreFacts']['battery_warranty']['value']=='8 years / 160,000 km'
 assert v['powertrain']=='BEV'
 assert not v['availability']['physicalStockVerified']
 assert v['coreFacts']['dc_charge_time_min']['basis']=='30–80% SOC'
 assert not v['coreFacts']['battery_kwh']['comparisonBasis']
 assert not v['coreFacts']['boot_l']['comparisonBasis']
 assert not v['coreFacts']['boot_l']['rankingEligible']
 assert v['coreFacts']['seats']['buyerGrade']=='reported'
 assert v['coreFacts']['warranty']['buyerGrade']=='confirmed'
 assert v['coreFacts']['battery_warranty']['buyerGrade']=='confirmed'
 gap=v['extraFacts']['dc_10_80_min']
 assert gap['value'] is None and gap['buyerGrade']=='not_published' and len(gap['sourceKeys'])>=2
 assert not gap['rankingEligible']
 for field in list(v['coreFacts'].values())+list(v['extraFacts'].values()):
  all_sources.update(field['sourceKeys'])
  assert 'au-b03x-global-guide' not in field['sourceKeys']
  if field['buyerGrade']=='reported':assert not field['rankingEligible']
  if field['buyerGrade']=='check':assert field.get('conditionExplanation')
  if field['key']=='price_aud' and field.get('priceEvidence',{}).get('rung')==1:
   assert field['basis']=='Before on-road costs'
 if i in [6,7,8]:assert v['availability']['buyerState']=='Order open or arriving'
 else:assert v['availability']['buyerState']=='On sale now'
 for summary in v['summary'].values():
  assert summary['text'] and summary['dependencies']
  for key in summary['dependencies']:assert key in v['coreFacts'] or key in v['extraFacts']
 records.append({'id':v['id'],'coreNumericAndStringValuesChecked':17,'chargingWindowsSeparated':True,'secondaryUnranked':True,'noPhysicalStockInference':True})
sources=[]
for key in sorted(all_sources):
 r=json.loads((root/(key+'-receipt.json')).read_text()); text=Path(r['textPath']).read_bytes(); actual=hashlib.sha256(text).hexdigest()
 assert actual==r['textSha256'],key
 sources.append({'key':key,'url':r['url'],'textPath':r['textPath'],'textSha256':actual})
result={'kind':'Independent normalized evidence consistency checks, not production integration tests','candidatePath':str(source),'candidateSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'versions':records,'sourceTextHashChecks':sources,'coreValuesChecked':170,'strict10to80AbsencesChecked':10,'productionFilesReadOrChanged':False,'catalogueHydrationPerformed':False}
print(json.dumps(result,indent=2))
