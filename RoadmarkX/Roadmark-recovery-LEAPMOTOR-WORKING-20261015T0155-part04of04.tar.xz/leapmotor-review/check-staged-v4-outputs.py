from pathlib import Path
import json,hashlib,collections,copy
root=Path('/tmp/leapmotor-staging/v4-timeout/output');read=lambda p:json.loads(Path(p).read_text());pin=lambda p:{'path':str(p),'bytes':Path(p).stat().st_size,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()}
packetPath=Path('/tmp/leapmotor-packet/v3/leapmotor-2026-10-15.json');pkt=read(packetPath);receipt=read(root/'stage-receipt.json');terminal=read(root.parent/'run/terminal.json')
assert terminal['exitCode']==0 and terminal['rawWaitStatus']==0
for a in receipt['artifacts']:assert pin(a['path'])==a
cars=read(root/'selected-after-cars.json');byid={c['id']:c for c in cars};assert len(cars)==len(byid)==10
assert cars==read('/tmp/leapmotor-packet/v3/selected-core-after.json')
packs=read(root/'staged-packs.json');portable=read(root/'portable-packs.json');assert set(packs)==set(byid)==set(portable)
sources={}
for cid,p in packs.items():
 assert p['car']==byid[cid] and len(p['features'])==69
 for s in p['sources']:
  if s['id'] in sources:assert sources[s['id']]==s
  sources[s['id']]=s
for s in pkt['sources']:
 if s['id'] in sources:assert sources[s['id']]==s
for cid,stored in portable.items():
 h=copy.deepcopy(stored);h['sources']=[sources[x] for x in h.pop('sourceIds')]
 for f in h['features']:f.setdefault('variant_id',h['car']['id']);f.setdefault('model_id',h['car']['modelId'])
 assert h==packs[cid]
expected={}
for f in pkt['facts']:
 cid,key=f['variantId'],f['after']['key'];assert byid[cid]['facts'][key]==f['after'];expected[cid,key]=f['after']
for t in pkt['brandTerms']:
 for cid in t['applicableVariantIds']:
  assert byid[cid]['facts'][t['key']]==t['fact'];expected[cid,t['key']]=t['fact']
assert len(expected)==185
claims=read(root/'selected-citations.json');assert len(claims)==195
for row in claims:
 cid,key=row['carId'],row['key'];c=row['claim'];assert c['carId']==cid
 if key!='availability':
  f=expected[cid,key];assert c['buyerGrade']==f['buyerGrade'];assert [s['id'] for s in c['sources']]==f['sourceIds'];assert c['qualifications'][:len(f['qualifications'])]==f['qualifications']
 for s in c['sources']:
  for k in ['id','title','url','publisher','accessed_date','published_date','market']:assert s[k]==sources[s['id']][k]
assert collections.Counter(x['buyerAvailability'] for x in claims if x['key']=='availability')=={'On sale now':7,'Order open or arriving':3}
for c in cars:
 f=c['facts'];assert f['dc_10_80_min']['value'] is None and f['dc_10_80_min']['buyerGrade']=='not_published';assert '30' in f['dc_charge_time_min']['basis'] and '80' in f['dc_charge_time_min']['basis'];assert f['boot_l']['comparisonBasis']=='' and f['battery_kwh']['comparisonBasis']==''
 assert c['availabilityEvidence']['physicalStockVerified'] is False and c['availabilityEvidence']['factoryOrderAcceptanceVerified'] is False
 if c['model']=='B03X':assert 'expectedDelivery' not in c['availabilityEvidence'];assert any('dealership arrival expected November 2026' in q for q in c['availabilityEvidence']['qualifications'])
 if 'maker_msrp_aud' in f:
  m=f['maker_msrp_aud'];assert m['buyerGrade']=='confirmed' and m['comparisonBasis']=='' and 'on-road treatment not stated' in m['label'];assert 'priceEvidence' not in m;assert f['price_aud']['priceEvidence']['rung']==5 and f['price_aud']['buyerGrade']=='reported'
assert sum('maker_msrp_aud' in c['facts'] for c in cars)==3
om=read(root/'portable-json-omissions.json');w=read('/tmp/leapmotor-staging/serialization-diagnostic-v2/diagnostic.json');want={o['pointer']:o for o in w['observations'] if o['phase']=='after'};assert len(om['observations'])==len(want)==54
for o in om['observations']:
 e=want[o['pointer']];assert (o['carId'],o['criterion'],o['index'],o['property'])==(e['variantId'],e['criterion'],e['rowIndex'],e['property']);assert o['property'] not in packs[o['carId']]['features'][o['index']]
assert all(om[k] for k in ['allOtherPackValuesPlainJson','comparisonCloneDeletesOnlyExactWitnessedPaths','livePacksUnchanged','livePortableRoundtrip','writtenPortableRoundtrip'])
dig=read(root/'car-digest-comparison.json');a={x['id']:x for x in dig['baseline20']};b={x['id']:x for x in dig['current21']};c={x['id']:x for x in dig['candidate22']};assert len(a)==len(b)==409 and len(c)==413
oldids={g['variantId'] for g in pkt['versionGuards']};assert len(oldids)==6
changed21=[i for i in a if a[i]!=b[i]];assert len(changed21)==1 and 'eqa' in changed21[0]
assert {i for i in b if b[i]!=c[i]}==oldids;assert len([i for i in b if b[i]==c[i]])==403;assert set(c)-set(b)==set(byid)-oldids
fd=read(root/'research-field-digests.json');assert len(fd['current21'])==len(fd['candidate22'])==14
for k in ['schema_version','criteria','update_events','configuration_history','publication_issues','prior_update_summary']:assert fd['current21'][k]==fd['candidate22'][k]
for k,n in {'sources':35,'models':2,'variants':4,'trim_equipment':4,'feature_evidence':276,'update_eligibility':4,'feature_evidence_variant_context':4}.items():assert fd['candidate22'][k]['rows']-fd['current21'][k]['rows']==n
meta=read(root/'metadata-composition.json');assert [len(x['composedMetadata']['brand_update_packet_ids']) for x in meta]==[21,22];assert meta[1]['composedMetadata']['brand_update_packet_ids'][:-1]==meta[0]['composedMetadata']['brand_update_packet_ids'];assert meta[1]['composedMetadata']['brand_update_packet_ids'][-1]==pkt['id']
basepath=Path('/tmp/mercedes-towing-correction/runs/full-coverage-asof-2026-10-15-v2/stdout.log');a=read(basepath);b=read(root/'staged-report.json');assert pin(basepath)['sha256']=='95f3e8135a0b375e39d032f0697d1ff0064161132dc33dea0953f526002342c8'
la=next(x for x in a['brandProgress'] if x['brand']=='Leapmotor');lb=next(x for x in b['brandProgress'] if x['brand']=='Leapmotor');assert [x for x in a['brandProgress'] if x['brand']!='Leapmotor']==[x for x in b['brandProgress'] if x['brand']!='Leapmotor']
assert (b['allCatalogueVersions'],b['tierOneVersions'],b['onSaleVersions'])==(413,336,305);assert b['grading']=={'reviewedCoreCells':4832,'totalCoreCells':5185,'reviewedPercent':93.2}
assert len(b['gaps'])==401 and lb['coreGaps']==7 and lb['unreviewedCoreGrades']==0;assert sum(x['filled'] for x in lb['core'])==112 and sum(x['reviewed'] for x in lb['core'])==119
for k in ['gaps','missingModels','summaryGaps','unresolvedLeads']:assert [x for x in a[k] if x.get('brand')!='Leapmotor']==[x for x in b[k] if x.get('brand')!='Leapmotor']
assert all(x['key']=='dc_charge_time_min' and '30–80%' in x['reason'] for x in b['gaps'] if x.get('brand')=='Leapmotor')
for ga,gb,ba,bb in zip(a['core'],b['core'],la['core'],lb['core']):
 assert ga['key']==gb['key']==ba['key']==bb['key']
 for k in ['total','filled','reviewed']:assert ga[k]-ba[k]==gb[k]-bb[k]
 for grade in ga['grades']:assert ga['grades'][grade]-ba['grades'][grade]==gb['grades'][grade]-bb['grades'][grade]
rankdelta=[]
for ra,rb in zip(a['rankings'],b['rankings']):
 assert ra['key']==rb['key'];non=lambda ids:{i for i in ids if not i.startswith('leapmotor_')};assert non(ra['rankedIds'])==non(rb['rankedIds']);assert [x for x in ra['excluded'] if not x['carId'].startswith('leapmotor_')]==[x for x in rb['excluded'] if not x['carId'].startswith('leapmotor_')]
 for cid,car in byid.items():
  if car['facts'][rb['key']]['buyerGrade']=='reported' or (rb['key']=='boot_l'):assert cid not in rb['rankedIds']
 rankdelta.append({'key':ra['key'],'before':ra['ranked'],'after':rb['ranked'],'addedIds':sorted(set(rb['rankedIds'])-set(ra['rankedIds'])),'removedIds':sorted(set(ra['rankedIds'])-set(rb['rankedIds']))})
assert [x for x in a['reconciliation']['issues'] if x.get('brand')!='Leapmotor']==[x for x in b['reconciliation']['issues'] if x.get('brand')!='Leapmotor']
assert lb['criteria']=={'C1':False,'C2':False,'C3':True,'C4':True,'C5':False,'C6':True}
unchanged=[k for k in a if a[k]==b[k]];changed=[k for k in a if a[k]!=b[k]]
result={'decision':'Accept actual feature-free packet stage outputs and whole-report delta; machine reconciliation and registered validation remain separate','packet':pin(packetPath),'manifest':pin(root.parent/'manifest.json'),'stageReceipt':pin(root/'stage-receipt.json'),'terminal':terminal,'beforeReport':pin(basepath),'afterReport':pin(root/'staged-report.json'),'artifactPins':receipt['artifacts'],'checks':{'packetFactsExact':185,'packetSourcesUsedInPacksExact':sum(s['id'] in sources for s in pkt['sources']),'packetSourceRegistryPrefixAnd35AdditionsStageVerified':True,'selectedCarsExact':10,'actualWrittenPortableReconstructionExact':True,'actualFactAndAvailabilityCitations':195,'exactAllowedOmissions':54,'unrelatedCarDigestsUnchanged':403,'all14ResearchFieldsRetained':True,'metadataPrefixLengths':[20,21,22],'otherBrandRowsUnchanged':55,'nonLeapmotorCoreGradeAndFillCountsUnchanged':True,'nonLeapmotorRankingMembershipAndExclusionsUnchanged':True,'nonLeapmotorGapsUnchanged':True,'reportedExcludedFromRankings':True,'unknownCargoExcluded':True,'separate30to80GroupsPreserved':True},'wholeReportDelta':{'changedTopLevelFields':changed,'unchangedTopLevelFields':unchanged,'catalogue':[409,413],'tierOne':[332,336],'onSale':[304,305],'reviewedCoreCells':[4787,4832],'totalCoreCells':[5168,5185],'coreGaps':[428,401],'pairedOnSale':[303,304],'missingAuditModels':[24,23],'rankings':rankdelta,'rankingOrderingNote':'Boot group drops six Leapmotor rows; group sorting by descending count (discovery.ts:317) reorders remaining groups without changing unrelated membership or exclusions','reconciliationAddedIssues':[x for x in b['reconciliation']['issues'] if x not in a['reconciliation']['issues']]},'leapmotor':{k:v for k,v in lb.items() if k not in ['core','closureIssues']},'scopeLimits':['Packet-only derived stage; proposed machine reconciliation not included','No production registration performed by reviewer','Registered structural/full coverage parity and parent aggregate checks remain separate','No browser/mobile/React rendering verified']}
p=Path('/tmp/leapmotor-review/staging-v4-output-acceptance.json')
with p.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(pin(p))
