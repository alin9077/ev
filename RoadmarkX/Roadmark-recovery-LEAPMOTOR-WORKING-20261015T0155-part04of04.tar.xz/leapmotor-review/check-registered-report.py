from pathlib import Path
import json,hashlib,collections
read=lambda p:json.loads(Path(p).read_text());pin=lambda p:{'path':str(p),'bytes':Path(p).stat().st_size,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()}
aPath=Path('/tmp/leapmotor-staging/v4-timeout/output/staged-report.json');run=Path('/workspace/scratch/586427eef9f2/roadmark-104-qa/leapmotor-sequential-checks/normal-coverage-asof-2026-10-15');bPath=run/'stdout.log';a=read(aPath);b=read(bPath);term=read(run/'terminal.json')
assert term['exitCode']==0 and term['signal'] is None and term['changedInputs']==[] and term['inputCount']==500;assert (run/'stderr.log').read_bytes()==b''
assert pin(aPath)['sha256']=='688e69cdfb38634b8f2468bf34a4508eba3df1f3d5d8a75ca8c065ae3939ff9f';assert pin(bPath)['sha256']=='625334a4c0cabae4ab099f8d272ba173ef4aa5bf62ea405b0584870a4f296a2c'
changed=[k for k in a if a[k]!=b[k]];assert changed==['reconciliation','brandProgress','criteria']
assert a['criteria'][1:]==b['criteria'][1:];assert a['criteria'][0]['id']==b['criteria'][0]['id']=='C1';assert a['criteria'][0]['pass']==b['criteria'][0]['pass']==False
ra=a['reconciliation'];rb=b['reconciliation'];assert rb['reviewedModels']==ra['reviewedModels']+4==84;assert rb['reviewedVersions']==ra['reviewedVersions']+9==190
recon=read('data/m1-leapmotor-market-reconciliation-2026-10-15.json');expected={v['carId'] for r in recon['currentVersionReviews'] for v in r['versions']};assert len(expected)==9;assert set(rb['reviewedVersionIds'])-set(ra['reviewedVersionIds'])==expected;assert set(ra['reviewedVersionIds'])<=set(rb['reviewedVersionIds']);assert set(rb['settledInventory'])-set(ra['settledInventory'])=={'record:'+r['inventoryId'] for r in recon['inventoryResolutions']}
added=[i for i in rb['issues'] if i not in ra['issues']];removed=[i for i in ra['issues'] if i not in rb['issues']];assert len(added)==len(removed)==10;assert all(i.get('brand')=='Leapmotor' for i in removed);assert collections.Counter(i['code'] for i in removed)=={'version_unreviewed':6,'inventory_unresolved':4};assert collections.Counter(i['brand'] for i in added)=={'Polestar':3,'Volkswagen':5,'Volvo':2};assert all(i['code']=='version_unreviewed' for i in added)
knownChange={'reviewedModels','reviewedVersions','reviewedVersionIds','validModelReviewIds','settledInventory','issues','evidence'};assert all(ra[k]==rb[k] for k in ra if k not in knownChange)
assert set(rb['validModelReviewIds'])-set(ra['validModelReviewIds'])=={r['id'] for r in recon['currentVersionReviews']}
for key,value in ra['evidence'].items():
 if isinstance(value,list):assert rb['evidence'][key]==value+recon[key],key
 else:assert rb['evidence'][key]==value,key
brandChanges={}
for old,new in zip(a['brandProgress'],b['brandProgress']):
 assert old['brand']==new['brand'];keys=[k for k in old if old[k]!=new[k]]
 if keys:brandChanges[old['brand']]=keys
 allowed={'researchRemaining','closureIssues','remaining','reason'}|({'currentVersionReviews'} if old['brand']=='Leapmotor' else set());assert set(keys)<=allowed
assert set(brandChanges)=={'Leapmotor','Polestar','Volkswagen','Volvo'}
leap=next(x for x in b['brandProgress'] if x['brand']=='Leapmotor');assert leap['currentVersionReviews']==recon['currentVersionReviews'];assert [(x['code'],x.get('reference')) for x in leap['closureIssues']]==[('independent_lists',None),('version_unreviewed','leapmotor_c10_my25__design_69_9kwh__20261015')];assert leap['onSaleVersions']==7 and leap['coreGaps']==7 and leap['unreviewedCoreGrades']==0 and leap['researchCompleted']==False
addedIds={i['reference'] for i in added};rows=[];packetPins=[]
for f in ['polestar-2026-10-14.json','volkswagen-2026-10-14.json','volvo-2026-10-14.json']:
 p=Path('data/m1-brand-updates')/f;d=read(p);packetPins.append(pin(p));sources={s['id']:s for s in d['sources']}
 for r in d['availability']:
  if r['variantId'] not in addedIds:continue
  e=r['after']['evidence'];assert r['after']['availability']=='announced_provisional';assert e['orderStatus']=='accepting_orders_advertised' and e['checkedAt']=='2026-10-14';assert e['sourceIds'] and all(s in sources for s in e['sourceIds'])
  for sid in e['sourceIds']:
   s=sources[sid];assert s['accessed_date']=='2026-10-14' and s['url'].startswith('https://') and not any(s.get(k) for k in ['publication_hold','conflict','access_limitation'])
  rows.append({'carId':r['variantId'],'availability':r['after']['availability'],'orderStatus':e['orderStatus'],'checkedAt':e['checkedAt'],'sourceIds':e['sourceIds'],'retainedReason':r['reason'],'scope':'Classifies accepted prior availability records; not a fresh independent recapture or new availability promotion'})
assert {r['carId'] for r in rows}==addedIds
v={'decision':'Accept registered normal complete coverage report as an explicit C1-only transition from accepted packet-only stage','beforeReport':pin(aPath),'afterReport':pin(bPath),'terminal':pin(run/'terminal.json'),'terminalResult':term,'freshStructuralValidationTerminal':pin(run.parent/'fresh-validation/terminal.json'),'registrationTransitionReview':pin('/tmp/leapmotor-review/registration-transition-review.json'),'changedTopLevelFields':changed,'allOtherTopLevelFieldsExact':True,'C2ThroughC6GlobalCriteriaExact':True,'allBrandCriteriaAndNonC1MetricsExact':True,'counts':{'catalogue':413,'tierOne':336,'onSale':305,'reviewedCoreCells':4832,'totalCoreCells':5185,'strictCoreGaps':401,'currentModelReviews':[80,84],'reviewedVersionMemberships':[181,190],'C1Blockers':[245,245]},'removedC1Issues':removed,'addedC1Issues':added,'addedMemberships':sorted(expected),'brandC1OnlyFieldChanges':brandChanges,'addedC1EligibilityPriorEvidence':rows,'priorPacketPinsForClassification':packetPins,'leapmotorResult':{'currentOfficialModels':4,'currentOfficialVersions':9,'onSale':7,'coreReviewed':119,'strictFilled':112,'strict30to80WindowGaps':7,'C1Remaining':leap['closureIssues'],'criteria':leap['criteria'],'researchCompleted':False},'interpretation':['Six old Leapmotor membership gaps and four inherited family gaps resolved by exact four-list reconciliation','Three Leapmotor explicit preorders now eligible for C1 only and reviewed, while all on-sale denominators stay fixed','Ten previously accepted advertised-order provisional versions now receive unresolved current-list scrutiny: Polestar4 SUV3, Volkswagen ID.Buzz MY275, Volvo EX602','Polestar evidence is maker configurator plus launch report; Volkswagen and Volvo preserve attributed secondary order-open evidence and unresolved/current timing qualifiers','No ranking, grade, factual coverage, availability, summary or C2–C6 count changed across this source/reconciliation transition','Whole-market independent lists and MY25 residual membership remain open'],'remainingValidation':['Root11-file relevant tests still running at acceptance','Full suite/typecheck/build/mobile gates remain parent-owned and unclaimed']}
p=Path('/tmp/leapmotor-review/registered-report-c1-delta-acceptance.json')
with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
print(pin(p))
