import json,hashlib,sys
from pathlib import Path
norm_path=Path(sys.argv[1]); packet_path=Path(sys.argv[2]);out_path=Path(sys.argv[3])
n=json.loads(norm_path.read_text());p=json.loads(packet_path.read_text());b=json.load(open('/tmp/leapmotor-research/retained-before-cars.json'));b={x['id']:x for x in b};idx=json.load(open('/tmp/leapmotor-research/source-index-review-v2.json'))['sources']
sha=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest()
errors=[]
def check(x,msg):
 if not x:errors.append(msg)
prefix=p['id']+'-';nv={v['id']:v for v in n['variants']};pv={v['id']:v for v in p['variants']};sources={s['id']:s for s in p['sources']}
check(p['features']==[] and p['versionUpdates']==[],'Unexpected equipment or metadata edits')
check(set(pv)=={v['id'] for v in n['variants'] if v['action']=='add'},'Addition identity mismatch')
check(len(sources)==len(p['sources']),'Duplicate source IDs')
for sid,s in sources.items():
 check(sid.startswith(prefix),'Source outside new packet namespace '+sid)
 key=sid[len(prefix):];r=idx[key]
 check(s['url']==r['url'] and s['accessed_date']=='2026-10-15','Source URL/date mismatch '+sid)
 check(s['capture_sha256']==r['rawSha256'],'Source raw hash binding mismatch '+sid)
 check(s['retainedCaptures'][1]['sha256']==r['textSha256'],'Source text hash binding mismatch '+sid)
 if key.startswith('secondary-'):check(s['source_type']=='secondary_au_publication','Secondary source type mismatch '+sid)
 if key.startswith('au-') or key in ['residual-c10-guide']:check(s['source_type']=='manufacturer_au_publication','Maker source type mismatch '+sid)
check(all('au-b03x-global-guide' not in sid for sid in sources),'Global B03X source unexpectedly admitted')
for g in p['versionGuards']:
 old=b[g['variantId']];expected={k:old.get(k) for k in ['id','modelId','brand','model','trim','year','generation','vehicleClass','drive']}
 check(g['before']==expected,'Version guard mismatch '+g['variantId'])
check({g['variantId'] for g in p['versionGuards']}==set(b),'Existing guard set differs')
expanded=list(p['facts'])
for t in p['brandTerms']:
 check(set(t['applicableVariantIds'])==set(nv),'Brand terms do not cover exact ten')
 check(t['exceptions']==[],'Unexpected brand exceptions')
 for vid in t['applicableVariantIds']:expanded.append({'variantId':vid,'before':t['before'][vid],'after':t['fact']})
expected={(v['id'],k):f for v in n['variants'] for k,f in {**v['coreFacts'],**v['extraFacts']}.items()};actual={(x['variantId'],x['after']['key']):x for x in expanded}
check(set(actual)==set(expected),'Effective fact set mismatch')
check(len(actual)==len(expanded),'Duplicate effective fact edit')
for pair,nf in expected.items():
 if pair not in actual:continue
 row=actual[pair];f=row['after'];vid,key=pair;old=b.get(vid,{}).get('facts',{}).get(key)
 check(row['before']==old,'Fact before mismatch '+str(pair))
 for k in ['key','value','unit','basis','comparisonBasis','status','buyerGrade']:check(f[k]==nf[k],'Normalized '+k+' mismatch '+str(pair))
 check(f['sourceIds']==[prefix+k for k in nf['sourceKeys']],'Fact sources mismatch '+str(pair))
 check(f['date']==n['checkedAt'] and f['market']=='AU','Fact date/market mismatch '+str(pair))
 check(f['issues']==[],'New unexplained issues '+str(pair))
 for q in [nf['locator']]+nf['qualifications']:check(q in f['qualifications'],'Qualification dropped '+str(pair)+' '+q)
 g=f['gradeReview'];check(g['sourceIds']==f['sourceIds'] and g['evidenceScope']==nf['evidenceScope'] and g['overlayId']==p['id'],'Grade source/scope mismatch '+str(pair))
 check(f['resolvedElsewhere']==(f['buyerGrade']=='reported'),'Secondary exclusion flag mismatch '+str(pair))
 if 'priceEvidence' in nf:
  pe=f['priceEvidence'];ne=nf['priceEvidence']
  for k in ['rung','originalBasis','rankingEligible']:check(pe[k]==ne[k],'Price evidence '+k+' mismatch '+str(pair))
  check(pe['sourceKey']==key,'Price sourceKey mismatch '+str(pair))
  check(idx[ne['sourceKey']]['url'] in pe['sourcePointer'],'Price pointer missing URL '+str(pair))
  if 'offerEnd' in ne:check(f['validUntil']==ne['offerEnd'],'Offer end missing '+str(pair))
  if 'offerStart' in ne:check('Offer starts '+ne['offerStart'] in f['qualifications'],'Offer start missing '+str(pair))
 if 'conditionExplanation' in nf:check(f.get('conditionExplanation')==nf['conditionExplanation'],'Condition dropped '+str(pair))
 if key=='maker_msrp_aud':check('on-road treatment not stated' in f['label'] and not f.get('priceEvidence') and f['comparisonBasis']=='','Maker MSRP unsupported ranking/label '+vid)
for a in p['availability']:
 vid=a['variantId'];v=nv[vid];na=v['availability'];old=b.get(vid)
 if old:check(a['before']=={'availability':old['availability'],'evidence':old['availabilityEvidence']},'Availability before mismatch '+vid)
 else:
  vrow=pv[vid];check(a['before']=={'availability':vrow['record_state'],'evidence':{'checkedAt':vrow['variant_review_date'],'orderStatus':'unverified','stockStatus':'unverified','sourceIds':vrow['source_ids'],'qualifications':['Physical stock and factory-order acceptance have not been verified.']}},'Added availability before mismatch '+vid)
 aa=a['after'];e=aa['evidence'];check(aa['availability']==na['recordState'],'Availability state mismatch '+vid)
 for k in ['orderStatus','stockStatus','physicalStockVerified']:check(e[k]==na[k],'Availability '+k+' mismatch '+vid)
 check(e['sourceIds']==[prefix+k for k in na['sourceKeys']],'Availability source mismatch '+vid)
 for q in na['qualifications']:check(q in e['qualifications'],'Availability qualifier dropped '+vid)
 if 'expectedDelivery' in na:check(na['expectedDelivery'] in e['qualifications'] or e.get('expectedDelivery')==na['expectedDelivery'],'Delivery timing dropped '+vid)
for s in p['summaries']:
 vid=s['variantId'];ns=nv[vid]['summary']
 for key in ['strength','tradeoff']:
  clause=s[key];nc=ns[key];check(clause['text']==nc['text'] and clause['label']==nc['label'],'Summary copy mismatch '+vid+'/'+key)
  check([d['key'] for d in clause['dependencies']]==nc['dependencies'],'Summary dependency set mismatch '+vid+'/'+key)
  for dep in clause['dependencies']:
   check(dep['expected']==actual[(vid,dep['key'])]['after'],'Summary expected fact mismatch '+vid+'/'+dep['key'])
   check(dep['expected']['value'] is not None,'Null summary dependency rejected by actual clauseFor '+vid+'/'+dep['key'])
report={'packet':{'path':str(packet_path),'sha256':sha(packet_path)},'normalized':{'path':str(norm_path),'sha256':sha(norm_path)},'staticErrors':errors,'counts':{'sources':len(sources),'additions':len(pv),'existingIdentityGuards':len(p['versionGuards']),'specificFacts':len(p['facts']),'sharedTerms':len(p['brandTerms']),'expandedFacts':len(expanded),'availability':len(p['availability']),'summaries':len(p['summaries'])},'limits':'Static JSON and selected code inspection only. No application execution, full-catalogue loading or production edits.'}
out_path.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
