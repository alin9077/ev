from pathlib import Path
import json,hashlib,datetime
root=Path('/workspace/scratch/586427eef9f2/roadmark-104');qa=root.parent/'roadmark-104-qa';d=Path('/tmp/leapmotor-handoff/status-transition-v1');d2=d.parent/'status-transition-v2';rv=Path('/tmp/leapmotor-review')
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
t=json.loads((d/'transition.json').read_text());u=json.loads((d2/'transition.json').read_text());assert pin(d2/'transition.json')['sha256']=='d7036718d550cc7eaf2aa0df7da280ec5bae2ab6a9919e8123ef668c6a42aa0b'
for k in ['priorTransition','before','after','newReportUnchanged','qaStatusUnchanged']:assert pin(Path(u[k]['path']))==u[k],k
for f in t['files']:
 if f['before']:assert pin(Path(f['before']['path']))==f['before']
 if 'M1_PROGRESS' not in f['after']['path']:assert pin(Path(f['after']['path']))==f['after']
oldClause='outside the unchanged on-sale C2–C6/ranking calculations; November';newClause='outside the on-sale core/ranking denominator; C2–C6 calculation scopes remain unchanged. November'
p1=(d2/'M1_PROGRESS.before.md').read_text();p2=(root/'docs/M1_PROGRESS.md').read_text();assert p1.count(oldClause)==1 and p1.replace(oldClause,newClause)==p2
before=json.loads((d/'work-status.before.json').read_text());after=json.loads((qa/'work-status.json').read_text());changes=[k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)];assert sorted(changes)==sorted(t['changedTopLevelStatusFields']);assert not(before.keys()-after.keys());assert after['workStatusHistory'][:-1]==before['workStatusHistory']
for k,v in after['workStatusHistory'][-1]['previous'].items():assert before[k]==v
assert (root/'docs/M1_PROGRESS.md').read_bytes().startswith((d/'M1_PROGRESS.before.md').read_bytes())
page=(root/'docs/LEAPMOTOR_M1_UPDATE.md').read_text();report=json.loads((qa/'leapmotor-sequential-checks/normal-coverage-asof-2026-10-15/stdout.log').read_text());core={x['key']:x for x in report['core']}
for k in ['price_aud','range_km','battery_kwh','dc_charge_time_min','seats','boot_l','warranty']:
 s=f"{core[k]['filledPercent']:.1f}% / {core[k]['confirmedPercent']:.1f}%";assert s in page,(k,s)
assert str(report['pairedOnSalePercent'])+'%' in page and str(report['inAllRankingsPercent'])+'%' in page
assert len(report['brandsResearchRemaining'])==46 and len(report['missingModels'])==23 and len(report['unresolvedLeads'])==27
for x in report['brandsResearchCompleted']+report['brandsResearchRemaining']:assert x in page,x
for x in report['missingModels']:
 name=x if isinstance(x,str) else x.get('model') or x.get('name');assert name in page,(name,x)
assert len(report['reconciliation']['validModelReviewIds'])==84
assert after['latestWorkingBrandChecks']==after['leapmotorWorking'];assert after['latestWorkingBrandChecks']['finalAcceptanceSha256']==pin(rv/'registered-integration-final-acceptance.json')['sha256'];assert after['latestWorkingBrandChecks']['reportSha256']==pin(qa/'leapmotor-sequential-checks/normal-coverage-asof-2026-10-15/stdout.log')['sha256'];assert after['stopBefore']=='M2' and after['deliveredCheckpoint']==103
p=rv/'final-docs-status-v2-acceptance.json';out={'decision':'Accept final Leapmotor progress append, one-page update and preserved QA status transition with precise C2-C6 scope wording','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'transitions':[pin(d/'transition.json'),pin(d2/'transition.json')],'files':[u['after'],u['newReportUnchanged'],u['qaStatusUnchanged']],'integrationAcceptance':pin(rv/'registered-integration-final-acceptance.json'),'checker':pin(Path(__file__)),'checks':['Frozen final hashes and exact preserved before hashes verified','Progress v2 changes exactly the stated denominator/scope clause and adjacent punctuation from preserved v1','Pre-Leapmotor M1 progress retained as exact byte prefix','Exactly18 declared top-level status changes; all unrelated fields and previous history preserved','Prior replaced status values preserved in appended history','All seven displayed coverage pairs, summary/ranking percentages, completed/remaining brand lists,23 missing models and27 leads match the full report','Current four official cohorts/nine memberships and residual/whole-market blockers accurately retained','Actual265 split relevant-test passes, failed SIGKILL aggregate and unestablished cause retained','Standard TypeScript/full suite/build/mobile gates remain open; no screenshots, publication, M2 or new milestone claimed','Test-loader and paired-snapshot optimizations remain unapplied'],'limitations':['Bounded docs/status consistency review; no new catalogue hydration or source-wide equality assertion','Working recovery delivery is pending and historical Library records remain historical'],'reviewAttemptNote':'Earlier inline checks stopped before receipt creation: first at the live v1 progress hash during the author-announced amendment, second because the checker omitted the author-corrected adjacent punctuation. No data or runtime failure is inferred.'}
with p.open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps(pin(p)))
