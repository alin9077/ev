import urllib.request,json,pathlib,hashlib,re,sys
R=pathlib.Path('/tmp/mini-research/sources')
BAD=re.compile(r'(^|[_-])(token|secret|password|authorization|api.?key|client.?key|access.?key|cookie|jwt|session)([_-]|$)',re.I)
def safe(o):
 if isinstance(o,dict):return {k:safe(v) for k,v in o.items() if not BAD.search(k)}
 if isinstance(o,list):return [safe(v) for v in o]
 if isinstance(o,str) and (re.search(r'eyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]+',o) or 'Bearer ' in o):return '[REDACTED runtime credential]'
 return o

def capture(name,url,mode):
 try:
  with urllib.request.urlopen(url,timeout=20) as r:x=json.loads(r.read());status=r.status
  if mode=='price':
   allowed={k:x[k] for k in ['code','ranges','fromPrice','cheapestVehicle'] if k in x}
  else:
   allowed={k:x[k] for k in ['code','name','models'] if k in x}
  # Source-support copy: data service public vehicle identity, equipment and technical data; no transport/config credentials.
  allowed=safe(allowed);p=R/(name+'.json');p.write_text(json.dumps(allowed,indent=2,ensure_ascii=False));prov={'url':url,'checkedAt':'2026-10-15','status':status,'mode':mode,'transformation':'Top-level factual allowlist; credential-like object keys and credential-like values removed in memory before persistence; no auth header, client key, cookie or token supplied. HTTP headers not retained.','path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};(R/(name+'-provenance.json')).write_text(json.dumps(prov,indent=2));print(name,p.stat().st_size,list(x))
 except Exception as e:
  (R/(name+'-failure.json')).write_text(json.dumps({'url':url,'checkedAt':'2026-10-15','error':type(e).__name__,'reason':str(e)[:150],'credentialsUsed':False},indent=2));print(name,type(e).__name__)
if __name__=='__main__':capture(*sys.argv[1:])
