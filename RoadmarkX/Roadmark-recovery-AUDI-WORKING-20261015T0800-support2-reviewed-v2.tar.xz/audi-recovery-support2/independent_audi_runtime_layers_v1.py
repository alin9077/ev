#!/usr/bin/env python3
"""Inspect raw unchanged runtime findings before per-field layer suppression.
Only the 33 files already reported with plain runtime candidates are read.
No payload writes, archive reads, service requests, or values/value hashes.
"""
import collections, datetime, html, importlib.util, json, pathlib, re, sys
sys.dont_write_bytecode=True
from independent_audi_runtime_diagnosis_v1 import C,R,read,load
def main():
 reports=[];group=collections.defaultdict(list)
 for i in (2,3,4):
  p=C/f'scan-{i:02}.json';b,pin,_=read(p);d=json.loads(b);reports.append({'path':p.name,**pin})
  for r in d['unclassifiedRuntimeCandidates']:group[r['member']].append(r)
 assert len(group)==33 and sum(map(len,group.values()))==45
 cap={r['path']:r for r in load(C/'proof-capture-v1.json')['files']}
 A=R/'privacy-audit-20261014T0355';sys.path.insert(0,str(A));ep=A/'final_residual_scan_memory_bounded.py';assert read(ep)[1]['sha256']=='db71353ba5fe98021f68cd9aeaae6eb4e1878627fb4985278b11457baf837238'
 sp=importlib.util.spec_from_file_location('residual_layers',ep);mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod);_,runtime=mod.patterns()
 plain_values=set();data={};raw_rows=[];newvalues={}
 def value(s,f):
  if f['layer']=='plain':return s[f['valueCharStart']:f['valueCharEnd']]
  x=s[f['sourceWindowStart']:]
  if f['layer']=='html-entities':x=html.unescape(x)
  else:
   count=int(f['layer'].removeprefix('escaped-level-'));assert count in (1,2,3)
   for _ in range(count):
    x=re.sub(r'\\u([0-9a-fA-F]{4})|\\x([0-9a-fA-F]{2})',lambda m:chr(int(m.group(1) or m.group(2),16)),x)
    x=x.replace('\\"','"').replace("\\'","'").replace('\\n','\n').replace('\\r','\r').replace('\\t','\t').replace('\\\\','\\')
  return x[f['valueCharStart']:f['valueCharEnd']]
 for n,reported in group.items():
  c=cap[n];b,pin,ident=read(pathlib.Path(c['payloadPath']),c);s=b.decode();rs=runtime(s);data[n]=(b,s,pin,ident,rs)
  for r in rs:
   if r['layer']=='plain':
    v=value(s,r);assert len(v)==r['valueLength'];plain_values.add(v)
  assert [{**r,'member':n} for r in rs if r['layer']=='plain']==reported
 for n,(b,s,pin,ident,rs) in data.items():
  for f in rs:
   v=value(s,f);assert len(v)==f['valueLength']
   new=f['layer']!='plain' and v not in plain_values
   if new:
    if v not in newvalues:newvalues[v]=len(newvalues)+1
    forms=mod.variants_for({v.encode():[]});locations={}
    for form,meta in forms.items():
     start=0
     while True:
      start=b.find(form,start)
      if start<0:break
      locations[(start,start+len(form))]=meta['encoding'];start+=len(form)
    assert locations,'New decoded value needs a separately reviewed original-byte map'
    raw_rows.append({'member':n,'copyPin':pin,'copyIdentity':ident,'candidate':f,'additionalValueGroup':newvalues[v],'literalOrEncodedLocations':[{'byteStart':a,'byteEndExclusive':z,'encoding':e} for (a,z),e in sorted(locations.items())],'plainCandidateWithSameFieldPresent':any(x['layer']=='plain' and x['field']==f['field'] for x in rs)})
 out={'status':'SUPPLEMENTARY_REVIEW_REQUIRED' if raw_rows else 'NO_ADDITIONAL_DISTINCT_RUNTIME_VALUES','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputReports':reports,'scriptPin':read(pathlib.Path(__file__))[1],'filesRead':len(data),'reportedPlainCandidates':45,'rawCandidateCount':sum(len(x[4]) for x in data.values()),'rawLayerCounts':dict(collections.Counter(r['layer'] for x in data.values() for r in x[4])),'distinctPlainRuntimeValues':len(plain_values),'additionalDistinctRuntimeValues':len(newvalues),'additionalCandidates':raw_rows,'allFilePins':[{'member':n,**x[2]} for n,x in data.items()],'noValuesOrValueDigestsPersisted':True,'payloadsModified':False,'archivesRead':False,'scope':'Raw runtime() output before existing field-level non-plain suppression, only files reported with plain runtime candidates; no scanner decisions changed'}
 with (C/'INDEPENDENT-AUDI-RAW-RUNTIME-LAYERS-v1.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
 print(json.dumps({k:out[k] for k in ['status','filesRead','reportedPlainCandidates','rawCandidateCount','rawLayerCounts','distinctPlainRuntimeValues','additionalDistinctRuntimeValues']}))
if __name__=='__main__':main()
