#!/usr/bin/env python3
"""Bounded no-seed tests of the exact production report adjudication helper."""
import ast
import copy
import datetime
import hashlib
import importlib.util
import json
import os
import pathlib
import resource
import sys
import tempfile

sys.dont_write_bytecode = True
C = pathlib.Path(__file__).absolute().parent
A = C.parents[1] / 'privacy-audit-20261014T0355'
OUT = C / 'INDEPENDENT-AUDI-SUPPORT-RUNTIME-FIXTURE-v2.json'
HELPER = C / 'audi_support_runtime_adjudication_v1.py'
HELPER_PIN = {'bytes': 12067, 'sha256': 'ed8b8abcda99ed577b8b151788f8ab21b50f17da03d130232e9ac3b6f062c778'}
REVIEW = C / 'INDEPENDENT-AUDI-SUPPORT-RUNTIME-CLASSIFICATION-v1.json'
REVIEW_PIN = {'bytes': 7690, 'sha256': '4202ff5b2d466f313df3bd728591b6c3ed05c0733a36be3d1942c47b3cb2ee61'}
SCANNER_PIN = {'bytes': 14676, 'sha256': '4b555e2f81eb96987daf8c4a2fe01d6d9c2d8e3818cde009f7dfa66a055262f9'}
PACKAGE_PIN = {'bytes': 27451, 'sha256': '2051274042fe01c4c0fd45e9325f2692d353abb103cebcd6cc95f58951154577'}
opened_paths = []


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def pin(blob):
    return {'bytes': len(blob), 'sha256': hashlib.sha256(blob).hexdigest()}


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def audit(event, args):
    if event == 'open' and isinstance(args[0], (str, bytes)):
        path = os.fsdecode(args[0])
        need(not path.lower().endswith(('.xz', '.tar', '.gz', '.zip', '.tgz')), 'Archive read prohibited')
        opened_paths.append(path)


sys.addaudithook(audit)


def main():
    need(resource.getrlimit(resource.RLIMIT_AS) == (268435456, 268435456), '256 MiB address-space bound required')
    need(not OUT.exists(), 'Additive output required')
    helper_blob = HELPER.read_bytes()
    need(pin(helper_blob) == HELPER_PIN, 'Actual helper code pin mismatch')
    helper = load_module('exact_support_adjudication_v1', HELPER)
    need(helper._pin(helper._read_pinned(HELPER, HELPER_PIN)) == HELPER_PIN, 'Loaded helper pin mismatch')
    read = helper._read_pinned
    review = json.loads(read(REVIEW, REVIEW_PIN))
    reference = review['failedScan']
    raw_path = C / 'scan-final-07.json'
    raw_pin = {k: reference[k] for k in ('bytes', 'sha256')}
    raw_blob = read(raw_path, raw_pin)
    raw = json.loads(raw_blob)
    package = json.loads(read(C / 'support2-package.json', PACKAGE_PIN))
    members = package['memberFiles']
    archive = {'archive': package['filename'], **{k: package[k] for k in ('bytes', 'sha256')}}
    approved = review['exactSupportRuntimeClassifications']
    data = {name: read(C / pathlib.PurePosixPath(name).name, filepin) for name, filepin in review['files'].items()}
    checks = []
    unchanged_calls = 0

    def record(name, ok):
        checks.append({'check': name, 'result': 'PASS' if ok else 'FAIL'})
        need(ok, name)

    def invoke(report, wanted=None, wanted_archive=None):
        nonlocal unchanged_calls
        wanted = members if wanted is None else wanted
        wanted_archive = archive if wanted_archive is None else wanted_archive
        snapshot = copy.deepcopy([report, wanted, wanted_archive])
        start = len(opened_paths)
        try:
            return helper.adjudicate(report, wanted, wanted_archive)
        finally:
            need([report, wanted, wanted_archive] == snapshot, 'Production helper mutated an input')
            allowed = {str(REVIEW), str(raw_path), *[str(C / pathlib.PurePosixPath(name).name) for name in review['files']]}
            need(set(opened_paths[start:]) <= allowed, 'Production helper opened an unexpected file')
            unchanged_calls += 1

    def reject(fn):
        try:
            fn()
        except (ValueError, KeyError, TypeError, SyntaxError):
            return True
        return False

    def negative(name, change, wanted=None, wanted_archive=None):
        altered = copy.deepcopy(raw)
        change(altered)
        record(name, reject(lambda: invoke(altered, wanted, wanted_archive)))

    original_result = invoke(raw)
    record('Pinned original full report accepted with exact production helper', original_result['exactClassifiedCandidateCount'] == 3 and original_result['regularFilesScanned'] == 144)
    record('Production return is deterministic', invoke(raw) == original_result)
    retry = copy.deepcopy(raw)
    old_metadata = next(row for row in retry['members'] if row['path'] == 'recovery-metadata/AUDI-WORKING-20261015T0800-support2.json')
    retry['members'].remove(old_metadata)
    new_metadata = {'path': 'recovery-metadata/AUDI-WORKING-20261015T0800-support2-v2.json', **pin(b'representative replacement inventory metadata')}
    retry['members'].append({**new_metadata, 'exactMatchesObserved': 0, 'classifiedPublicLexicalCollisions': 0, 'unresolvedExactMatches': 0, 'patternVerdict': 'current-full-unchanged-scanner'})
    retry['classifiedPublicLexicalCollisions'] -= old_metadata['classifiedPublicLexicalCollisions']
    extra_blob = b'representative retry metadata only\n'
    extra_member = {'path': 'audi-recovery-support2/representative-retry-evidence.json', **pin(extra_blob)}
    retry['members'].append({**extra_member, 'exactMatchesObserved': 0, 'classifiedPublicLexicalCollisions': 0, 'unresolvedExactMatches': 0, 'patternVerdict': 'current-full-unchanged-scanner'})
    retry['members'].sort(key=lambda row: row['path'])
    retry_members = [{k: row[k] for k in ('path', 'bytes', 'sha256')} for row in retry['members']]
    retry_archive = {'archive': 'Roadmark-recovery-AUDI-WORKING-20261015T0800-support2-v2.tar.xz', **pin(b'representative replacement archive identity')}
    retry['archive'] = retry_archive['archive']
    retry['archivePin'] = {k: retry_archive[k] for k in ('bytes', 'sha256')}
    retry['regularFilesScanned'] = len(retry_members)
    retry['bytesScanned'] = sum(row['bytes'] for row in retry_members)
    retry['completedAt'] = 'representative metadata fixture only'
    retry_result = invoke(retry, retry_members, retry_archive)
    record('Representative retry archive and extended member metadata accepted', retry_result['regularFilesScanned'] == 145 and retry_result['archivePin'] == retry['archivePin'])
    record('Representative retry uses exact replacement inventory member name', new_metadata in retry_members and not any(row['path'] == old_metadata['path'] for row in retry_members))
    record('Representative retry cannot reuse old archive pin', reject(lambda: invoke(retry, retry_members, archive)))
    record('Representative retry cannot omit added member coverage', reject(lambda: invoke(retry, members, retry_archive)))
    negative('Missing candidate rejected', lambda r: r['unclassifiedRuntimeCandidates'].pop())
    negative('Extra candidate rejected', lambda r: r['unclassifiedRuntimeCandidates'].append({'unexpected': True}))
    negative('Duplicate candidate rejected', lambda r: r['unclassifiedRuntimeCandidates'].append(copy.deepcopy(r['unclassifiedRuntimeCandidates'][0])))
    negative('Duplicate substitution rejected', lambda r: r['unclassifiedRuntimeCandidates'].__setitem__(1, copy.deepcopy(r['unclassifiedRuntimeCandidates'][0])))
    negative('Candidate field mismatch rejected', lambda r: r['unclassifiedRuntimeCandidates'][0].__setitem__('line', 43))
    negative('Candidate span mismatch rejected', lambda r: r['unclassifiedRuntimeCandidates'][0].__setitem__('valueCharEnd', 3818))
    negative('Candidate member mismatch rejected', lambda r: r['unclassifiedRuntimeCandidates'][0].__setitem__('member', members[0]['path']))
    negative('Additional candidate field rejected', lambda r: r['unclassifiedRuntimeCandidates'][0].__setitem__('extra', 1))
    reordered = copy.deepcopy(raw)
    reordered['unclassifiedRuntimeCandidates'].reverse()
    record('Exact candidate multiset permits order only', invoke(reordered) == original_result)
    negative('Raw clean status rejected', lambda r: r.__setitem__('status', 'clean'))
    negative('Archive hash substitution rejected', lambda r: r['archivePin'].__setitem__('sha256', '0' * 64))
    negative('Archive length substitution rejected', lambda r: r['archivePin'].__setitem__('bytes', r['archivePin']['bytes'] + 1))
    negative('Archive name substitution rejected', lambda r: r.__setitem__('archive', 'unexpected.tar.xz'))
    negative('Missing full member rejected', lambda r: r['members'].pop())
    negative('Extra full member rejected', lambda r: r['members'].append(copy.deepcopy(r['members'][0])))
    negative('Duplicate full member substitution rejected', lambda r: r['members'].__setitem__(1, copy.deepcopy(r['members'][0])))
    negative('Full member order mismatch rejected', lambda r: r['members'].reverse())
    negative('Full member digest mismatch rejected', lambda r: r['members'][0].__setitem__('sha256', '0' * 64))
    negative('Full member byte mismatch rejected', lambda r: r['members'][0].__setitem__('bytes', r['members'][0]['bytes'] + 1))
    negative('Full member cardinality counter mismatch rejected', lambda r: r.__setitem__('regularFilesScanned', 143))
    negative('Full member byte counter mismatch rejected', lambda r: r.__setitem__('bytesScanned', r['bytesScanned'] + 1))
    negative('Per-member unresolved matches rejected', lambda r: r['members'][0].__setitem__('unresolvedExactMatches', 1))
    negative('Unaccounted per-member matches rejected', lambda r: r['members'][0].__setitem__('exactMatchesObserved', r['members'][0]['exactMatchesObserved'] + 1))
    negative('Non-full pattern coverage rejected', lambda r: r['members'][0].__setitem__('patternVerdict', 'exact-prior-source-cache'))
    negative('Collision aggregate mismatch rejected', lambda r: r.__setitem__('classifiedPublicLexicalCollisions', r['classifiedPublicLexicalCollisions'] + 1))
    negative('Boolean member count rejected', lambda r: r['members'][0].__setitem__('unresolvedExactMatches', False))
    duplicated_expected = copy.deepcopy(members)
    duplicated_expected[1] = copy.deepcopy(duplicated_expected[0])
    record('Duplicate expected member rejected', reject(lambda: invoke(raw, duplicated_expected)))
    for key in ('exactValueMatches', 'primaryHeaderCandidates', 'classifiedExactCodeHeaderCandidates', 'errors'):
        negative('Nonempty blocking category rejected: ' + key, lambda r, k=key: r[k].append({'unexpected': True}))
    negative('Additional runtime classification rejected', lambda r: r.__setitem__('recognizedBenignRuntimeCandidateCount', 1))
    negative('Missing current byte coverage rejected', lambda r: r.__setitem__('currentByteSearchForEveryMember', False))
    negative('Unknown report category rejected', lambda r: r.__setitem__('additionalFindings', [1]))
    negative('Unchanged engine rule mismatch rejected', lambda r: r['patternCacheProvenance']['rulePins'].__setitem__('runtime_token_scan.py', '0' * 64))
    for index, row in enumerate(approved):
        blob = data[row['member']]
        record('Whole-file substitution rejected ' + str(index), reject(lambda r=row, b=blob: helper._source_context(r, b + b'\n')))
        for key in ('matchedSyntaxSHA256', 'byteStart'):
            changed = copy.deepcopy(row)
            changed[key] = '0' * 64 if key.endswith('SHA256') else changed[key] + 1
            record('Pinned source span mutation rejected ' + str(index) + ' ' + key, reject(lambda r=changed, b=blob: helper._source_context(r, b)))
        for key in ('statementSHA256', 'astSHA256', 'enclosingStatementType'):
            changed = copy.deepcopy(row)
            changed['syntaxContext'][key] = 'invalid'
            record('Pinned source context mutation rejected ' + str(index) + ' ' + key, reject(lambda r=changed, b=blob: helper._source_context(r, b)))
    row = approved[0]
    source = C / pathlib.PurePosixPath(row['member']).name
    bad_identity = list(row['sourceIdentity'])
    bad_identity[1] += 1
    record('Production lstat identity mismatch rejected', reject(lambda: read(source, row['filePin'], bad_identity)))
    with tempfile.TemporaryDirectory(prefix='support-fixture-v2-', dir=C) as directory:
        link = pathlib.Path(directory) / 'source-link.py'
        link.symlink_to(source)
        record('Production source symlink rejected', reject(lambda: read(link, row['filePin'])))
    def corrupted_reader(path, wanted, wanted_identity=None):
        blob = read(path, wanted, wanted_identity)
        return blob + b'\n' if pathlib.Path(path) == source else blob
    helper._read_pinned = corrupted_reader
    try:
        record('Actual production helper rejects substituted source bytes', reject(lambda: invoke(raw)))
    finally:
        helper._read_pinned = read
    engines = json.loads((C / 'INDEPENDENT-AUDI-CHECKER-PATTERN-PREFLIGHT-v1.json').read_bytes())['enginePins']
    for name, digest in engines.items():
        need(pin((A / name).read_bytes())['sha256'] == digest, 'Unchanged engine pin mismatch')
    scanner_blob = read(C / 'privacy_v5.py', SCANNER_PIN)
    sys.path.insert(0, str(A))
    engine = load_module('support_fixture_engine_v2', A / 'final_residual_scan_memory_bounded.py')
    primary, runtime = engine.patterns()
    node = next(n for n in ast.parse(scanner_blob).body if isinstance(n, ast.FunctionDef) and n.name == 'scan_patterns')
    scope = {'scan': engine}
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(C / 'privacy_v5.py'), 'exec'), scope)
    reproduced = []
    raw_count = 0
    for name, blob in data.items():
        ps, rs, bc = scope['scan_patterns'](blob, name, primary, runtime, set())
        need(not ps and bc == 0, 'Unexpected source finding category')
        raw_count += len(runtime(blob.decode('utf-8')))
        reproduced.extend({'member': name, **item} for item in rs)
    reproduced_report = copy.deepcopy(raw)
    reproduced_report['unclassifiedRuntimeCandidates'] = reproduced
    record('Exact unchanged-engine reproduction passes actual production helper', invoke(reproduced_report) == original_result and raw_count == 6)
    source_checks = []
    own_blob = pathlib.Path(__file__).read_bytes()
    for path, blob in ((HELPER, helper_blob), (pathlib.Path(__file__), own_blob)):
        ast.parse(blob)
        ps, rs, bc = scope['scan_patterns'](blob, path.name, primary, runtime, set())
        record('New code has no unchanged-engine findings: ' + path.name, not ps and not rs and bc == 0)
        source_checks.append({'filename': path.name, **pin(blob), 'primaryFindings': len(ps), 'runtimeFindings': len(rs), 'recognizedBenign': bc})
    record('Actual helper source pin unchanged after tests', pin(read(HELPER, HELPER_PIN)) == HELPER_PIN)
    record('Original raw report bytes preserved', read(raw_path, raw_pin) == raw_blob)
    record('All production calls preserve every input including rejection', unchanged_calls > 35)
    result = {
        'result': 'PASS', 'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'checks': checks, 'helperPin': HELPER_PIN, 'classificationPin': REVIEW_PIN,
        'fixturePin': pin(own_blob), 'originalFailedReportPin': raw_pin,
        'scannerPin': SCANNER_PIN, 'enginePins': engines, 'sourcePatternChecks': source_checks,
        'originalReportAdjudication': original_result, 'representativeRetryAdjudication': retry_result,
        'representativeRetryMetadataOnly': True, 'reproducedFindings': reproduced,
        'rawRuntimeFindingsBeforeExistingLayerHandling': raw_count,
        'immutableProductionCallsChecked': unchanged_calls, 'exactClassifiedFindings': 3,
        'seedReads': 0, 'archivePayloadReads': 0, 'productionPayloadsModified': False,
        'detectorBytesChanged': False, 'rawReportPreserved': True,
        'scope': 'Exact production helper binding, full report and metadata coverage, unchanged-engine reproduction, strict negatives; no actual retry scan claimed',
    }
    with OUT.open('x') as handle:
        json.dump(result, handle, indent=2)
        handle.write('\n')
    print(json.dumps({'result': result['result'], 'checks': len(checks), 'exactFindings': 3, 'seedReads': 0, 'archivePayloadReads': 0}))
    return 0


if __name__ == '__main__':
    sys.exit(main())
