#!/usr/bin/env python3
"""No-seed reproduction of three exact retained source-syntax findings."""
import ast, copy, datetime, hashlib, importlib.util, json, os, pathlib, resource, stat, sys
sys.dont_write_bytecode = True
C = pathlib.Path(__file__).resolve().parent
A = C.parents[1] / 'privacy-audit-20261014T0355'
OUT = C / 'INDEPENDENT-AUDI-SUPPORT-RUNTIME-FIXTURE-v1.json'
REVIEW = C / 'INDEPENDENT-AUDI-SUPPORT-RUNTIME-CLASSIFICATION-v1.json'
def identity(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents)
 return [s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev]
def read(p):
 before=identity(p);b=p.read_bytes();assert identity(p)==before and len(b)==before[0]
 return b,{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p):return json.loads(read(p)[0])
def reject(fn):
 try:fn()
 except AssertionError:return True
 return False
def audit(event,args):
 if event=='open' and isinstance(args[0],(str,bytes)):
  assert not os.fsdecode(args[0]).lower().endswith(('.xz','.tar','.gz','.zip','.tgz'))
sys.addaudithook(audit)
def main():
 assert resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456) and not OUT.exists()
 review_bytes,review_pin=read(REVIEW);assert review_pin=={'bytes':7690,'sha256':'4202ff5b2d466f313df3bd728591b6c3ed05c0733a36be3d1942c47b3cb2ee61'}
 review=json.loads(review_bytes);approved=review['exactSupportRuntimeClassifications'];assert len(approved)==3
 engines=load(C/'INDEPENDENT-AUDI-CHECKER-PATTERN-PREFLIGHT-v1.json')['enginePins']
 for name,digest in engines.items():assert read(A/name)[1]['sha256']==digest
 scanner_bytes,scanner_pin=read(C/'privacy_v5.py');assert scanner_pin=={'bytes':14676,'sha256':'4b555e2f81eb96987daf8c4a2fe01d6d9c2d8e3818cde009f7dfa66a055262f9'}
 sys.path.insert(0,str(A));spec=importlib.util.spec_from_file_location('support_fixture_engine',A/'final_residual_scan_memory_bounded.py');engine=importlib.util.module_from_spec(spec);spec.loader.exec_module(engine)
 primary,runtime=engine.patterns();node=next(n for n in ast.parse(scanner_bytes).body if isinstance(n,ast.FunctionDef) and n.name=='scan_patterns');scope={'scan':engine};exec(compile(ast.Module(body=[node],type_ignores=[]),str(C/'privacy_v5.py'),'exec'),scope)
 data={};reproduced=[];raw_count=0
 for name,filepin in review['files'].items():
  p=C/pathlib.PurePosixPath(name).name;b,actual=read(p);assert actual==filepin;data[name]=b
  ps,rs,bc=scope['scan_patterns'](b,name,primary,runtime,set());assert not ps and bc==0
  raw_count+=len(runtime(b.decode('utf-8')));reproduced.extend({'member':name,**row} for row in rs)
 expected=[r['exactFinding'] for r in approved]
 def adjudicate(findings,blobs):
  keys=[json.dumps(f,sort_keys=True) for f in findings];wanted=[json.dumps(f,sort_keys=True) for f in expected]
  assert len(keys)==len(set(keys)) and sorted(keys)==sorted(wanted)
  for r in approved:
   b=blobs[r['member']];assert {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}==r['filePin']
   assert hashlib.sha256(b[r['byteStart']:r['byteEndExclusive']]).hexdigest()==r['matchedSyntaxSHA256']
  return len(findings)
 checks=[]
 def record(name,ok):checks.append({'check':name,'result':'PASS' if ok else 'FAIL'})
 record('Exact unchanged-engine candidates reproduced',adjudicate(reproduced,data)==3)
 record('Missing finding rejected',reject(lambda:adjudicate(reproduced[:-1],data)))
 record('Extra finding rejected',reject(lambda:adjudicate(reproduced+[{'unexpected':True}],data)))
 record('Duplicate finding rejected',reject(lambda:adjudicate(reproduced+[reproduced[0]],data)))
 record('Duplicate substitution rejected',reject(lambda:adjudicate([reproduced[0],reproduced[0],reproduced[-1]],data)))
 altered=copy.deepcopy(reproduced);altered[0]['line']+=1
 record('Candidate-field mismatch rejected',reject(lambda:adjudicate(altered,data)))
 blobs=dict(data);name=next(iter(blobs));blobs[name]+=b'\n'
 record('Whole-file mismatch rejected',reject(lambda:adjudicate(reproduced,blobs)))
 raw=load(C/'scan-final-07.json');assert read(C/'scan-final-07.json')[1]=={k:review['failedScan'][k] for k in ('bytes','sha256')};record('Retained failed report exact candidate set',adjudicate(raw['unclassifiedRuntimeCandidates'],data)==3)
 package=load(C/'support2-package.json');wanted={r['path']:{k:r[k] for k in ('path','bytes','sha256')} for r in package['memberFiles']};actual={r['path']:{k:r[k] for k in ('path','bytes','sha256')} for r in raw['members']}
 record('Completed failed scan has exact full member coverage',raw['status']=='review-required' and actual==wanted and len(actual)==len(raw['members'])==raw['regularFilesScanned']==144 and raw['bytesScanned']==sum(r['bytes'] for r in actual.values()) and all(not raw[k] for k in ('exactValueMatches','primaryHeaderCandidates','errors')))
 own,own_pin=read(pathlib.Path(__file__));ps,rs,bc=scope['scan_patterns'](own,'fixture-source',primary,runtime,set());record('New fixture source has no raw pattern candidates',not ps and not rs and bc==0)
 result={'result':'PASS' if all(r['result']=='PASS' for r in checks) else 'FAIL','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'fixturePin':own_pin,'classificationPin':review_pin,'scannerPin':scanner_pin,'enginePins':engines,'rawRuntimeFindingsBeforeExistingLayerHandling':raw_count,'reproducedFindings':reproduced,'exactClassifiedFindings':3,'wholeFilePins':review['files'],'seedReads':0,'archivePayloadReads':0,'productionPayloadsModified':False,'detectorBytesChanged':False,'productionGateCreated':False,'scope':'Reproduction and exact-policy negative fixture only; classification approval and versioned production adjudication remain separate'}
 with OUT.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({'result':result['result'],'checks':len(checks),'exactFindings':3,'seedReads':0,'archivePayloadReads':0}))
 return 0 if result['result']=='PASS' else 2
if __name__=='__main__':sys.exit(main())
