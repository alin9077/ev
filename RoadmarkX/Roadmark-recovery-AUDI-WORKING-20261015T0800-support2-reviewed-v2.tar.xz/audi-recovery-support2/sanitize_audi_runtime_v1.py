"""Only the independently pinned 47 copy ranges; originals and original pins remain unchanged."""
from capture_v2 import *
review=C/'INDEPENDENT-AUDI-RUNTIME-BATCH-CLASSIFICATION-v1.json';check(review,{'bytes':720844,'sha256':'4bb97b40446fad1a43e08b498ebdab7e1c82af35470de5b83419932047f3eb5a'});d=load(review);assert d['fileCount']==33 and d['proposedRangeCount']==47 and d['distinctNewRuntimeValues']==6 and d['newRuntimeVariantForms']==37
old=load(C/'proof-capture-v1.json');out=P(C/'selected-proof-runtime-sanitized-v2');changes={};mapping=[]
for f in d['files']:
 p=P(f['originalPath']);copy=P(f['copyPath']);check(p,f['originalPin']);check(copy,f['copyPin']);before=identity(p);copybefore=identity(copy);b=copy.read_bytes();assert b==p.read_bytes();assert identity(p)==before and identity(copy)==copybefore;parts=[];pos=0
 for r in f['ranges']:
  a,z=r['byteStart'],r['byteEndExclusive'];assert pos<=a<z<=len(b);parts.extend([b[pos:a],r['replacement'].encode()]);pos=z
 parts.append(b[pos:]);new=b''.join(parts);assert {'bytes':len(new),'sha256':hashlib.sha256(new).hexdigest()}==f['proposedSanitizedPin'];target=out/f['member'];target.parent.mkdir(parents=True,exist_ok=True);target.open('xb').write(new);check(target,f['proposedSanitizedPin']);check(p,f['originalPin']);assert identity(p)==before;changes[f['member']]={'payloadPath':str(target),**f['proposedSanitizedPin'],'captureMethod':'exact-approved-runtime-range-copy-redaction','runtimeSanitation':True};mapping.append({k:f[k] for k in ['member','originalPath','originalPin','copyPath','copyPin','ranges','proposedSanitizedPin','outsideSegments','everyOutsideRangeByteUnchanged','factualProjection','sourceIndexReferences','unchangedTextCapture']}|{'sanitizedPayloadPath':str(target)})
assert len(changes)==33
for key in ['files','changedFiles']:
 for r in old[key]:
  if r['path'] in changes:r.update(changes[r['path']])
old['copyRuntimeSanitation']={'files':33,'ranges':47,'classification':pin(review),'originalExpectedPinsUnchanged':True};dump(C/'proof-capture-v2.json',old)
dump(C/'COPY-SANITATION-MAPPING-v2.json',{'result':'EXACT_APPROVED_COPY_ONLY_RUNTIME_REDACTIONS','files':mapping,'fileCount':33,'locationCount':47,'classification':pin(review),'originalExpectedPinsUnchanged':True,'factualProjectionUnchanged':True,'outsideDeclaredRangesUnchanged':True,'originalReplayLimitation':'The 33 copied captures have distinct hashes and cannot silently satisfy original expected source pins. Intact originals or separately reviewed new manifests are required for original raw replay. All original expected pins and working files remain unchanged.','scannerLimitation':'The original runtime detector does not decode URL-component JSON and excludes values shorter than eight characters; two exact stock-search fields are covered by targeted supplementary mapping and in-memory variant searches, not general URL-decoder coverage.'})
print(json.dumps({'files':33,'ranges':47,'extraBytes':sum(f['proposedSanitizedPin']['bytes']-f['originalPin']['bytes'] for f in d['files']),'originalsUnchanged':True}))
