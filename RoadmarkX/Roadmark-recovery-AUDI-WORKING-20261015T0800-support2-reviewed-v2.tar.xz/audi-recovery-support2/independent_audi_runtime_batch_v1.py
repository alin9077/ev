#!/usr/bin/env python3
"""No-value, read-only classification of the complete initial Audi privacy batch.
Includes the specifically identified URL-component stock-search field only.
No general URL decoding claim, scanner edits, payload writes, or archive reads.
"""
import ast,collections,datetime,importlib.util,json,pathlib,re,sys,urllib.parse
sys.dont_write_bytecode=True
from independent_audi_runtime_diagnosis_v1 import C,R,read,load,sha,visible,leaves
MARKERS={'civic':b'[REDACTED-AUDI-CIVIC-COOKIE-CONTROL-KEY]','maps':b'[REDACTED-AUDI-GOOGLE-MAPS-API-KEY-XXX]','nonce':b'[REDACTED]','scs':b'[REDACTED]'}
assert [len(MARKERS[k]) for k in ('civic','maps','nonce','scs')]==[40,39,10,10]
SCS=re.compile(r'%5C%22apiKey%5C%22(?:%3A|:)(?:%20|\s)*%5C%22(.*?)%5C%22',re.I)
def main():
 reports=[];groups=collections.defaultdict(list);collisions=collections.defaultdict(list)
 for i in (2,3,4):
  p=C/f'scan-{i:02}.json';b,pin,_=read(p);q=json.loads(b);assert not q['primaryHeaderCandidates'] and not q['errors'];reports.append({'path':p.name,**pin})
  for r in q['unclassifiedRuntimeCandidates']:groups[r['member']].append(r)
  for r in q['exactValueMatches']:collisions[r['member']].append(r)
 assert len(groups)==33 and sum(map(len,groups.values()))==45 and sum(map(len,collisions.values()))==4400
 cap={r['path']:r for r in load(C/'proof-capture-v1.json')['files']};source={r['path']:r for r in load(C/'source-capture.json')['files']}
 indices=[]
 for n in ('audi-research/source-index-review-v1.json','audi-review/source-index-hash-review-v1.json'):
  r=cap[n];b,pin,_=read(pathlib.Path(r['payloadPath']),r);indices.append((n,pin,list(leaves(json.loads(b)))))
 n='data/m1-brand-updates/audi-2026-10-15.json';r=source[n];b,pin,_=read(pathlib.Path(r['payloadPath']),r);indices.append(('roadmark/'+n,pin,list(leaves(json.loads(b)))))
 A=R/'privacy-audit-20261014T0355';sys.path.insert(0,str(A));ep=A/'final_residual_scan_memory_bounded.py';assert read(ep)[1]['sha256']=='db71353ba5fe98021f68cd9aeaae6eb4e1878627fb4985278b11457baf837238'
 sp=importlib.util.spec_from_file_location('residual_batch',ep);mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)
 # Exact prior public bare values only; do not persist values or hashes thereof.
 M=C.parent/'mazda-working-20261015T0405';bare=set();public_reads=[]
 for r in load(M/'JSON-SANITIZER-CANDIDATES-v1.json')['candidateFiles']:
  b,pin,ident=read(pathlib.Path(r['originalPath']),{'bytes':r['originalBytes'],'sha256':r['originalSHA256']});j=json.loads(b);name,_,v=j['headers']['Set-Cookie'].split(';',1)[0].partition('=')
  assert (name=='EPiStateMarker' and len(v)==4 and isinstance(json.loads(v),bool)) or (name=='cg_ab_variant' and len(v) in (7,11));bare.add(v.encode());public_reads.append({'path':r['originalPath'],**pin,'identity':ident})
 assert len(bare)==3 and len(public_reads)==8;public_forms=mod.variants_for({v:[] for v in bare})
 files={};values={};class_counts=collections.Counter();nonce_classes=collections.Counter();scs_count=0
 def register(v,kind,n,a,z):
  if v not in values:values[v]={'id':len(values)+1,'class':kind,'sources':[]}
  assert values[v]['class']==kind;values[v]['sources'].append({'member':n,'byteStart':a,'byteEndExclusive':z})
  return values[v]['id']
 for n,candidates in groups.items():
  r=cap[n];b,pin,ident=read(pathlib.Path(r['payloadPath']),r);original,op,oid=read(pathlib.Path(r['originalPath']),{'bytes':r['originalBytes'],'sha256':r['originalSHA256']});assert b==original and oid==r['sourceIdentity'];s=b.decode();ranges=[]
  for f in candidates:
   assert f['layer']=='plain';a,z=f['valueCharStart'],f['valueCharEnd'];v=s[a:z];assert len(v)==f['valueLength'];lo,hi=len(s[:a].encode()),len(s[:z].encode())
   if f['field']=='apiKey' and len(v)==40:
    kind='civic';assert s[a-9:a]=="apiKey: '" and "product: 'PRO_MULTISITE'" in s[z:z+120] and 'CookieControl.load(config)' in s and 'https://cc.cdn.civiccomputing.com/9/cookieControl-9.x.min.js' in s
    context={'role':'Civic Cookie Control PRO_MULTISITE runtime configuration','consumer':'CookieControl.load(config)'}
   elif f['field']=='apiKey' and len(v)==39:
    kind='maps';assert n.endswith('.js') and 'apiKey:"' in s[a-12:a] and ('rb.Wrapper' in s[a-100:a] or 'map' in s[a-350:a].lower() or 'markers:' in s[a-200:a])
    assert 'maps.googleapis.com' in s and 'geocoding' in s and 'places' in s;context={'role':'Google Maps/Places client wrapper key','services':['maps.googleapis.com','places','geocoding']}
   else:
    assert f['field']=='nonce' and len(v)==10 and n.startswith('audi-research/residual/melbourne-');kind='nonce'
    if 'vehica-nonce="' in s[a-20:a]:role='Vehica login component nonce'
    else:
     start=s.rfind('<script',0,a);pre=s[start:a]
     if 'ElementorProFrontendConfig' in pre:role='Elementor frontend AJAX nonce'
     else:
      assert 'nonce' in s[a-10:a] and 'sheets-to-wp-table-live-sync' in s[z:z+1200];role='Sheets-to-WP-table frontend plugin nonce'
    nonce_classes[role]+=1;context={'role':role,'publicPageHost':'shop.audicentremelbourne.com.au'}
   class_counts[kind]+=1;gid=register(v.encode(),kind,n,lo,hi);ranges.append({'field':f['field'],'layer':'plain','charStart':a,'charEndExclusive':z,'byteStart':lo,'byteEndExclusive':hi,'originalValueBytes':hi-lo,'class':kind,'valueGroup':gid,'context':context,'replacement':MARKERS[kind].decode()})
  if n in ('audi-research/gt-q8/new-stock-search.html','audi-research/residual/audi-new-search.html'):
   found=list(SCS.finditer(s));assert len(found)==1
   m=found[0];a,z=m.span(1);v=m.group(1);assert len(v)==7 and urllib.parse.unquote(v)==v and 'scs.audi.de' in s[max(0,a-250):a] and 'envConfig' in s[max(0,a-500):a]
   lo,hi=len(s[:a].encode()),len(s[:z].encode());kind='scs';gid=register(v.encode(),kind,n,lo,hi);scs_count+=1;class_counts[kind]+=1;ranges.append({'field':'envConfig.scs.apiKey','layer':'targeted-url-component-escaped-json','charStart':a,'charEndExclusive':z,'byteStart':lo,'byteEndExclusive':hi,'originalValueBytes':7,'class':kind,'valueGroup':gid,'context':{'role':'Stock-search service runtime key','serviceHost':'scs.audi.de','belowExistingRuntimeLengthThreshold':True,'generalUrlDecoderCoverageClaimed':False},'replacement':MARKERS[kind].decode()})
  ranges.sort(key=lambda x:x['byteStart']);assert all(x['byteEndExclusive']<=y['byteStart'] for x,y in zip(ranges,ranges[1:]))
  files[n]={'b':b,'s':s,'pin':pin,'identity':ident,'originalPin':op,'originalIdentity':oid,'capture':r,'ranges':ranges}
 assert class_counts=={'civic':29,'maps':10,'nonce':6,'scs':2} and scs_count==2 and len(values)==6
 # Supplementary seed variants, using the existing exact variants_for function.
 value_forms=mod.variants_for({v:[x['id']] for v,x in values.items()});unmapped=[];variant_hits=0
 for n,item in files.items():
  expected={(r['byteStart'],r['byteEndExclusive']) for r in item['ranges']};observed=set();b=item['b']
  for form,info in value_forms.items():
   start=0
   while True:
    start=b.find(form,start)
    if start<0:break
    observed.add((start,start+len(form)));start+=len(form)
  variant_hits+=len(observed)
  for a,z in sorted(observed-expected):unmapped.append({'member':n,'byteStart':a,'byteEndExclusive':z,'length':z-a})
 rows=[]
 for n,item in files.items():
  b=item['b'];parts=[];previous=0;outpos=0;outside=[]
  for r in item['ranges']:
   a,z=r['byteStart'],r['byteEndExclusive'];segment=b[previous:a];parts.append(segment);outside.append({'originalByteStart':previous,'originalByteEndExclusive':a,'sanitizedByteStart':outpos,'sanitizedByteEndExclusive':outpos+len(segment),'sha256':sha(segment)});outpos+=len(segment);replacement=MARKERS[r['class']];r['sanitizedByteStart']=outpos;r['sanitizedByteEndExclusive']=outpos+len(replacement);parts.append(replacement);outpos+=len(replacement);previous=z
  segment=b[previous:];parts.append(segment);outside.append({'originalByteStart':previous,'originalByteEndExclusive':len(b),'sanitizedByteStart':outpos,'sanitizedByteEndExclusive':outpos+len(segment),'sha256':sha(segment)});proposed=b''.join(parts)
  for seg in outside:assert b[seg['originalByteStart']:seg['originalByteEndExclusive']]==proposed[seg['sanitizedByteStart']:seg['sanitizedByteEndExclusive']]
  projection=None
  if n.endswith('.html'):
   bv,av=visible(b),visible(proposed);assert bv==av;projection={'method':'HTMLParser data excluding script/style; attributes excluded; no browser execution','bytes':len(bv),'sha256':sha(bv),'equal':True}
  else:
   assert n.endswith('.js');projection={'method':'Every non-key-value byte exact; replacement consists only of ASCII string-literal-safe characters; no JS execution or semantic build claim','equalOutsideRanges':True}
  refs=[]
  for index,pin,ls in indices:
   hits=[{'pointer':p,'match':'original-sha256' if v==item['pin']['sha256'] else 'capture-locator'} for p,v in ls if v==item['pin']['sha256'] or n in v]
   if hits:refs.append({'path':index,**pin,'references':hits})
  lexical=[]
  for h in collisions[n]:
   a,z=h['byteStart'],h['byteEndExclusive'];v=b[a:z];assert v in public_forms and not any(a<r['byteEndExclusive'] and r['byteStart']<z for r in item['ranges']);lexical.append({'byteStart':a,'byteEndExclusive':z,'encoding':public_forms[v]['encoding']})
  r=item['capture'];row={'member':n,'originalPath':r['originalPath'],'originalPin':item['originalPin'],'originalIdentity':item['originalIdentity'],'copyPath':r['payloadPath'],'copyPin':item['pin'],'copyIdentity':item['identity'],'ranges':item['ranges'],'proposedSanitizedPin':{'bytes':len(proposed),'sha256':sha(proposed)},'outsideSegments':outside,'everyOutsideRangeByteUnchanged':True,'factualProjection':projection,'sourceIndexReferences':refs,'reportedKnownValueLocations':lexical,'reportedKnownValueLocationsMatchPinnedPublicForms':True}
  textname=n.removesuffix('.html')+'.txt'
  if n.endswith('.html') and textname in cap:
   tr=cap[textname];_,tp,_=read(pathlib.Path(tr['payloadPath']),tr);row['unchangedTextCapture']={'path':textname,**tp}
  rows.append(row)
 # Classify support candidates as exact Python syntax, never by extension alone.
 p=C/'scan-06.json';b,pin,_=read(p);q=json.loads(b);assert len(q['primaryHeaderCandidates'])==10 and not q['exactValueMatches'] and not q['unclassifiedRuntimeCandidates'];support={r['path']:r for r in load(C/'SUPPORT-MEMBER-INVENTORY.json')['files']};code=[]
 for f in q['primaryHeaderCandidates']:
  r=support[f['member']];b,fp,ident=read(pathlib.Path(r['payloadPath']),r);s=b.decode();ast.parse(s);a,z=f['location']['charStart'],f['location']['charEnd'];line=s.splitlines()[f['location']['line']-1];assert f['header']=='authorization' and f['kind']=='quoted-header-literal' and f['confidence']=='needs-context'
  if line.strip().startswith(('assert b.count','ck(copied.count')):role='Python assertion checking exact metadata key spelling/presence'
  elif line.strip().startswith(('renamed=b.replace','raw = copied.replace')):role='Python byte-string replacement of metadata key spelling with unchanged value'
  else:raise AssertionError('Unrecognized support code context')
  assert 'approvalScope' in line and 'authorization' in line
  code.append({'member':f['member'],'filePin':fp,'identity':ident,'exactFinding':f,'byteStart':len(s[:a].encode()),'byteEndExclusive':len(s[:z].encode()),'matchedSyntaxSHA256':sha(s[a:z].encode()),'lineSHA256':sha(line.encode()),'classification':role,'astValid':True,'isHeaderValueOrCredential':False,'fileExtensionExemption':False,'payloadChangeProposed':False})
 out={'status':'REVIEW_REQUIRED_EXACT_COPY_ONLY_SANITATION' if not unmapped else 'REVIEW_REQUIRED_ADDITIONAL_VALUE_RANGES','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputReports':reports,'supportReport':pin,'scriptPin':read(pathlib.Path(__file__))[1],'fileCount':len(rows),'reportedRuntimeCandidates':45,'targetedSupplementaryRanges':2,'proposedRangeCount':sum(len(r['ranges']) for r in rows),'rangeClasses':dict(class_counts),'nonceRoles':dict(nonce_classes),'distinctNewRuntimeValues':len(values),'newRuntimeVariantForms':len(value_forms),'newValueSources':[v for v in values.values()],'newValueVariantMatchesWithinDiagnosedFiles':variant_hits,'unmappedNewValueVariantLocations':unmapped,'files':rows,'reportedKnownValueLocations':4400,'knownValueClassificationLimit':'All reported ranges match exact pinned public bare forms and are outside proposed edits. No collision waiver or current clean gate; unchanged blocking searches must pass after sanitation.','publicBareSourceReads':public_reads,'exactSupportCodeClassifications':code,'supportCodeCandidateCount':10,'supportedLayerInspection':{'path':'INDEPENDENT-AUDI-RAW-RUNTIME-LAYERS-v1.json',**read(C/'INDEPENDENT-AUDI-RAW-RUNTIME-LAYERS-v1.json')[1]},'noValuesOrValueDigestsPersisted':True,'payloadsModified':False,'archivesRead':False,'proposedNextGate':'Only after root approval: write exact new sanitized copies, preserve originals locally, map original provenance to sanitized members, retain failure/code history in additive support, and search existing plus these six new in-memory values and all 45 exact supported forms across every final fresh member with unchanged header/runtime engines. Final gate must account for exact approved support code findings, never blanket exemptions.'}
 with (C/'INDEPENDENT-AUDI-RUNTIME-BATCH-CLASSIFICATION-v1.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
 print(json.dumps({k:out[k] for k in ('status','fileCount','proposedRangeCount','rangeClasses','distinctNewRuntimeValues','newRuntimeVariantForms','newValueVariantMatchesWithinDiagnosedFiles','supportCodeCandidateCount')}));print(json.dumps({'unmappedNewValueVariantLocations':len(unmapped)}))
if __name__=='__main__':main()
