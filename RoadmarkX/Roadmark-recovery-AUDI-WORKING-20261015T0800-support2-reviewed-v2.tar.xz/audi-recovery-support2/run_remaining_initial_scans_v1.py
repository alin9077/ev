"""Complete only the four unscanned original archives; findings are retained, never waived."""
import pathlib,json,subprocess,datetime
C=pathlib.Path(__file__).resolve().parent
plan=json.loads((C/'ARCHIVE-PLAN.json').read_text())['archives'];assert len(plan)==6
assert json.loads((C/'scan-01.json').read_text())['status']=='clean'
assert json.loads((C/'scan-02.resources.json').read_text())['exitCode']==2
rows=[]
for i,a in enumerate(plan[2:],3):
 n=f'scan-{i:02d}';report=C/(n+'.json');metric=C/(n+'.resources.json')
 assert not report.exists() and not metric.exists()
 cmd=['python3',str(C/'run_bounded_v1.py'),str(metric),'python3',str(C/'privacy_v2.py'),a['file'],str(report)]
 with (C/(n+'.log')).open('x') as out,(C/(n+'.err')).open('x') as err:r=subprocess.run(cmd,stdout=out,stderr=err)
 terminal=json.loads(metric.read_text());assert r.returncode==terminal['exitCode'] and not terminal['timedOut']
 assert r.returncode in (0,2),'Unexpected scanner/resource failure; no next scan'
 q=json.loads(report.read_text());assert q['archivePin']=={k:a[k] for k in ['bytes','sha256']}
 actual={x['path']:{k:x[k] for k in ['path','bytes','sha256']} for x in q['members']};assert actual=={x['path']:x for x in a['memberFiles']};assert len(actual)==q['regularFilesScanned'] and sum(x['bytes'] for x in actual.values())==q['bytesScanned']
 row={'scan':i,'archive':a['filename'],'status':q['status'],'exitCode':r.returncode,'members':len(actual),'exactValueMatchCount':len(q['exactValueMatches']),'primaryCandidateCount':len(q['primaryHeaderCandidates']),'runtimeCandidateCount':len(q['unclassifiedRuntimeCandidates']),'maxRssKiB':terminal['maxRssKiB']};rows.append(row);print(json.dumps(row),flush=True)
with (C/'REMAINING-INITIAL-SCAN-SUMMARY-v1.json').open('x') as f:json.dump({'status':'INITIAL_DIAGNOSTIC_SCANS_COMPLETE_NOT_UPLOAD_CLEARANCE','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archives':rows,'noRuleChanges':True,'noUploadAuthorizedByThisSummary':True,'originalFailurePreserved':True},f,indent=2);f.write('\n')
