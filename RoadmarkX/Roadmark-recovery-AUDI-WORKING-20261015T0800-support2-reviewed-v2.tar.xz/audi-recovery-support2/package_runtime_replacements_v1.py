from package_v1 import *
old=load(C/'proof-packages.json')['archives'];rows={r['path']:r for r in load(C/'proof-capture-v2.json')['changedFiles']};mapping=load(C/'COPY-SANITATION-MAPPING-v2.json');affected={r['member'] for r in mapping['files']};ars=[];seen=set()
for i,a in enumerate(old,1):
 names=[r['path'] for r in a['memberFiles'] if r['path'] in rows];group=[rows[n] for n in names];hits=set(names)&affected;seen|=hits
 if not hits:assert i==4;ars.append(a);continue
 assert i in [1,2,3];meta={'schemaVersion':2,'label':LABEL,'part':i,'parts':4,'state':load(C/'proof-capture-v2.json')['state'],'files':[{k:r[k] for k in ['path','bytes','sha256','originalBytes','originalSHA256']} for r in group],'originalPartPin':{k:a[k] for k in ['bytes','sha256']},'copySanitationMap':'audi-safety-support/COPY-SANITATION-MAPPING.json','originalExpectedHashesUnchanged':True,'restore':'Versioned sanitized replacement for this Audi proof part; never combine the superseded original part with the recommended final chain.'};metadata={f'recovery-metadata/{LABEL}-part{i:02d}-sanitized-v2.json':(json.dumps(meta,indent=2)+'\n').encode()}
 if i==1:metadata['audi-safety-support/COPY-SANITATION-MAPPING.json']=(C/'COPY-SANITATION-MAPPING-v2.json').read_bytes()
 path=R/f'Roadmark-recovery-{LABEL}-part{i:02d}of04-sanitized-v2.tar.xz';ars.append(pack(path,group,metadata));print(json.dumps({'part':i,'members':ars[-1]['members'],'bytes':ars[-1]['bytes']}),flush=True)
assert seen==affected and len(ars)==4;dump(C/'proof-packages-v2.json',{'archives':ars,'unchangedPart4Reused':True,'supersededOriginalPartsPreservedLocally':True})
