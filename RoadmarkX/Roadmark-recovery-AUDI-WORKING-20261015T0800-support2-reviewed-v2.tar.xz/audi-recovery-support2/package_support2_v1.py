from package_v1 import *
inv=load(C/'SUPPORT2-MEMBER-INVENTORY.json');metadata={'recovery-metadata/'+LABEL+'-support2.json':(json.dumps(inv,indent=2)+'\n').encode()};a=pack(R/f'Roadmark-recovery-{LABEL}-support2.tar.xz',inv['files'],metadata);dump(C/'support2-package.json',a);print(json.dumps({'support2Members':a['members'],'support2Bytes':a['bytes']}))
