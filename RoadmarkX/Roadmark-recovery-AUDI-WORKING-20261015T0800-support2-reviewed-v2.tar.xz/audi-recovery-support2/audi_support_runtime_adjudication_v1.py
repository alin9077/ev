#!/usr/bin/env python3
"""Exact post-scan source-syntax adjudication; raw reports remain untouched."""
import ast
import hashlib
import json
import os
import pathlib
import stat

C = pathlib.Path(__file__).absolute().parent
REVIEW = C / 'INDEPENDENT-AUDI-SUPPORT-RUNTIME-CLASSIFICATION-v1.json'
REVIEW_PIN = {'bytes': 7690, 'sha256': '4202ff5b2d466f313df3bd728591b6c3ed05c0733a36be3d1942c47b3cb2ee61'}
DYNAMIC_FIELDS = frozenset(('completedAt', 'archive', 'archivePin', 'members',
    'regularFilesScanned', 'bytesScanned', 'classifiedPublicLexicalCollisions',
    'unclassifiedRuntimeCandidates'))
MEMBER_FIELDS = frozenset(('path', 'bytes', 'sha256', 'exactMatchesObserved',
    'classifiedPublicLexicalCollisions', 'unresolvedExactMatches', 'patternVerdict'))


def _need(condition, reason):
    if not condition:
        raise ValueError(reason)


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False)


def _pin(blob):
    return {'bytes': len(blob), 'sha256': hashlib.sha256(blob).hexdigest()}


def _identity(path):
    path = pathlib.Path(path).absolute()
    _need(not any(p.is_symlink() for p in (path, *path.parents)), 'Symlink rejected')
    s = path.lstat()
    _need(stat.S_ISREG(s.st_mode), 'Regular file required')
    return [s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_ino, s.st_dev]


def _stat_identity(s):
    return [s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_ino, s.st_dev]


def _read_pinned(path, wanted, wanted_identity=None):
    path = pathlib.Path(path).absolute()
    before = _identity(path)
    _need(before[0] == wanted['bytes'], 'Local file length mismatch')
    if wanted_identity is not None:
        _need(before == wanted_identity, 'Local file identity mismatch')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        _need(_stat_identity(os.fstat(fd)) == before, 'Open identity mismatch')
        with os.fdopen(fd, 'rb', closefd=False) as handle:
            blob = handle.read(wanted['bytes'] + 1)
        _need(_stat_identity(os.fstat(fd)) == before, 'Read identity changed')
    finally:
        os.close(fd)
    _need(_identity(path) == before and _pin(blob) == wanted, 'Local file content changed')
    return blob


def _valid_pin(value):
    _need(type(value) is dict and set(value) == {'bytes', 'sha256'}, 'Exact content pin required')
    _need(type(value['bytes']) is int and value['bytes'] >= 0, 'Invalid byte count')
    digest = value['sha256']
    _need(type(digest) is str and len(digest) == 64 and all(c in '0123456789abcdef' for c in digest), 'Invalid digest')
    return dict(value)


def _member_pin(row):
    _need(type(row) is dict, 'Member object required')
    name = row['path']
    metadata_names = ('recovery-metadata/AUDI-WORKING-20261015T0800-support2.json',
        'recovery-metadata/AUDI-WORKING-20261015T0800-support2-v2.json')
    _need(type(name) is str and (name.startswith('audi-recovery-support2/') or name in metadata_names), 'Member scope mismatch')
    parts = name.split('/')
    _need(all(p and p not in ('.', '..') for p in parts) and '\\' not in name, 'Unsafe member name')
    return {'path': name, **_valid_pin({k: row[k] for k in ('bytes', 'sha256')})}


def _source_context(row, blob):
    _need(_pin(blob) == row['filePin'], 'Whole source pin mismatch')
    lo, hi = row['byteStart'], row['byteEndExclusive']
    _need(type(lo) is int and type(hi) is int and 0 <= lo < hi <= len(blob), 'Invalid source span')
    _need(hashlib.sha256(blob[lo:hi]).hexdigest() == row['matchedSyntaxSHA256'], 'Source span digest mismatch')
    text = blob.decode('utf-8')
    finding = row['exactFinding']
    a, z = finding['valueCharStart'], finding['valueCharEnd']
    _need((len(text[:a].encode()), len(text[:z].encode())) == (lo, hi), 'Character and byte spans differ')
    _need(z - a == finding['valueLength'] and text[:a].count('\n') + 1 == finding['line'], 'Source finding position mismatch')
    offsets = [0]
    for line in blob.splitlines(keepends=True):
        offsets.append(offsets[-1] + len(line))
    tree = ast.parse(text)
    enclosing = []
    for node in ast.walk(tree):
        if isinstance(node, ast.stmt) and hasattr(node, 'end_lineno'):
            start = offsets[node.lineno - 1] + node.col_offset
            end = offsets[node.end_lineno - 1] + node.end_col_offset
            if start <= lo and hi <= end:
                enclosing.append((end - start, start, end, node))
    _need(bool(enclosing), 'No enclosing statement')
    _, start, end, node = min(enclosing, key=lambda item: item[0])
    context = row['syntaxContext']
    _need(context['pythonParses'] is True and row['notCredentialOrServiceValue'] is True and row['exactPinnedSyntaxOnly'] is True, 'Classification basis mismatch')
    actual = {
        'enclosingStatementType': type(node).__name__,
        'statementStartLine': node.lineno,
        'statementEndLine': node.end_lineno,
        'statementByteStart': start,
        'statementByteEndExclusive': end,
        'statementSHA256': hashlib.sha256(blob[start:end]).hexdigest(),
        'astSHA256': hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest(),
    }
    _need(all(actual[k] == context[k] for k in actual), 'Source statement or AST context mismatch')


def adjudicate(report, expected_members, expected_archive_pin):
    """Return deterministic metadata or raise ValueError; never alter any argument.

    expected_members is the ordered full list of {path, bytes, sha256} objects.
    expected_archive_pin is {archive, bytes, sha256}; archive may be omitted only
    when the caller separately binds the report's archive name.
    Reads only the fixed classification, pinned reference report, and two fixed
    local source scripts. Never reads an archive or derives sensitive values.
    """
    _need(type(report) is dict and type(expected_members) is list, 'Report and ordered members required')
    report_before = _canonical(report)
    arguments_before = _canonical([expected_members, expected_archive_pin])
    review_blob = _read_pinned(REVIEW, REVIEW_PIN)
    review = json.loads(review_blob)
    _need(review['candidateCount'] == 3 and review['fileCount'] == 2, 'Classification count mismatch')
    reference_record = review['failedScan']
    reference_path = pathlib.Path(reference_record['path'])
    _need(reference_path == C / 'scan-final-07.json', 'Reference report path mismatch')
    reference_pin = _valid_pin({k: reference_record[k] for k in ('bytes', 'sha256')})
    reference = json.loads(_read_pinned(reference_path, reference_pin))
    _need(set(report) == set(reference), 'Report schema differs from exact reference')
    _need(report['status'] == 'review-required', 'Raw review-required status required')
    for key in reference:
        if key not in DYNAMIC_FIELDS:
            _need(_canonical(report[key]) == _canonical(reference[key]), 'Unchanged report field mismatch: ' + key)
    for key in ('exactValueMatches', 'primaryHeaderCandidates', 'classifiedExactCodeHeaderCandidates', 'errors'):
        _need(report[key] == [], 'Other blocking or separately classified category present')
    _need(type(report['recognizedBenignRuntimeCandidateCount']) is int and report['recognizedBenignRuntimeCandidateCount'] == 0, 'Other runtime classification present')
    _need(report['currentByteSearchForEveryMember'] is True, 'Current byte coverage required')
    _need(type(expected_archive_pin) is dict and set(expected_archive_pin) in ({'bytes', 'sha256'}, {'archive', 'bytes', 'sha256'}), 'Expected archive pin shape mismatch')
    archive_pin = _valid_pin({k: expected_archive_pin[k] for k in ('bytes', 'sha256')})
    _need(_valid_pin(report['archivePin']) == archive_pin, 'Archive content pin mismatch')
    _need(type(report['archive']) is str and pathlib.PurePosixPath(report['archive']).name == report['archive'], 'Archive name invalid')
    if 'archive' in expected_archive_pin:
        _need(report['archive'] == expected_archive_pin['archive'], 'Archive name mismatch')
    wanted = []
    for row in expected_members:
        _need(type(row) is dict and set(row) == {'path', 'bytes', 'sha256'}, 'Expected member shape mismatch')
        wanted.append(_member_pin(row))
    _need(len(wanted) > 0 and len({r['path'] for r in wanted}) == len(wanted), 'Expected member duplication or empty coverage')
    _need(type(report['members']) is list and len(report['members']) == len(wanted), 'Full member cardinality mismatch')
    actual = []
    collisions = 0
    for row in report['members']:
        _need(type(row) is dict and set(row) == MEMBER_FIELDS, 'Report member shape mismatch')
        actual.append(_member_pin(row))
        for key in ('exactMatchesObserved', 'classifiedPublicLexicalCollisions', 'unresolvedExactMatches'):
            _need(type(row[key]) is int and row[key] >= 0, 'Invalid member counter')
        _need(row['unresolvedExactMatches'] == 0, 'Per-member unresolved matches remain')
        _need(row['exactMatchesObserved'] == row['classifiedPublicLexicalCollisions'], 'Unaccounted member exact matches')
        _need(row['patternVerdict'] == 'current-full-unchanged-scanner', 'Full unchanged pattern coverage required')
        collisions += row['classifiedPublicLexicalCollisions']
    _need(actual == wanted, 'Ordered full member content coverage mismatch')
    _need(type(report['regularFilesScanned']) is int and report['regularFilesScanned'] == len(wanted), 'Reported member count mismatch')
    _need(type(report['bytesScanned']) is int and report['bytesScanned'] == sum(r['bytes'] for r in wanted), 'Reported byte coverage mismatch')
    _need(type(report['classifiedPublicLexicalCollisions']) is int and report['classifiedPublicLexicalCollisions'] == collisions, 'Collision aggregate mismatch')
    approved = review['exactSupportRuntimeClassifications']
    expected_findings = [row['exactFinding'] for row in approved]
    findings = report['unclassifiedRuntimeCandidates']
    _need(type(findings) is list and len(findings) == 3, 'Candidate cardinality mismatch')
    keys = [_canonical(row) for row in findings]
    expected_keys = [_canonical(row) for row in expected_findings]
    _need(len(keys) == len(set(keys)) == len(set(expected_keys)) == 3 and sorted(keys) == sorted(expected_keys), 'Exact candidate multiset mismatch')
    member_pins = {row['path']: {k: row[k] for k in ('bytes', 'sha256')} for row in wanted}
    blobs = {}
    for row in approved:
        name = row['member']
        _need(row['exactFinding']['member'] == name and member_pins.get(name) == row['filePin'] == review['files'][name], 'Candidate member pin mismatch')
        source = C / pathlib.PurePosixPath(name).name
        _need(str(source) == row['sourcePath'], 'Exact source path mismatch')
        if name not in blobs:
            blobs[name] = _read_pinned(source, row['filePin'], row['sourceIdentity'])
        _source_context(row, blobs[name])
    _need(len(blobs) == 2 and set(blobs) == set(review['files']), 'Exact source set mismatch')
    _need(_canonical(report) == report_before and _canonical([expected_members, expected_archive_pin]) == arguments_before, 'Input mutation detected')
    return {
        'result': 'EXACT_APPROVED_SOURCE_SYNTAX_ONLY',
        'rawStatus': report['status'],
        'archive': report['archive'],
        'archivePin': archive_pin,
        'classificationPin': dict(REVIEW_PIN),
        'originalFailedReportPin': reference_pin,
        'orderedMemberMetadataSHA256': hashlib.sha256(_canonical(wanted).encode()).hexdigest(),
        'regularFilesScanned': len(wanted),
        'bytesScanned': report['bytesScanned'],
        'exactClassifiedCandidateCount': len(keys),
        'exactCandidateMultisetSHA256': hashlib.sha256(_canonical(sorted(keys)).encode()).hexdigest(),
        'wholeFilePins': {name: dict(review['files'][name]) for name in sorted(blobs)},
        'rawReportUnchanged': True,
        'seedReads': 0,
        'archivePayloadReads': 0,
        'detectorBytesChanged': False,
    }
