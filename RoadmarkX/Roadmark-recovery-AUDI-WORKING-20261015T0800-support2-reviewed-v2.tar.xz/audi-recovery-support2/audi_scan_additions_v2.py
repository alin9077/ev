"""Exact approved Audi in-memory values and exact code-context classifications only."""
import pathlib,json,hashlib,datetime,os,time,functools
C=pathlib.Path(__file__).resolve().parent
REVIEW=C/'INDEPENDENT-AUDI-RUNTIME-BATCH-CLASSIFICATION-v1.json'
@functools.lru_cache(maxsize=1)
def review():
 b=REVIEW.read_bytes();assert len(b)==720844 and hashlib.sha256(b).hexdigest()=='4bb97b40446fad1a43e08b498ebdab7e1c82af35470de5b83419932047f3eb5a';return json.loads(b)
from capture_v2 import identity
def audi_values(variants_for):
 d=review();by={r['member']:r for r in d['files']};values=set();reads=[]
 for g in d['newValueSources']:
  r=g['sources'][0];f=by[r['member']];p=pathlib.Path(f['originalPath']);before=identity(p);b=p.read_bytes();assert identity(p)==before==f['originalIdentity'];assert {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}==f['originalPin'];v=b[r['byteStart']:r['byteEndExclusive']];assert v;values.add(v);reads.append({'valueGroup':g['id'],'path':str(p),'pin':f['originalPin'],'byteStart':r['byteStart'],'byteEndExclusive':r['byteEndExclusive'],'payloadReadOperations':1})
 forms=set(variants_for({v:[] for v in values}));assert len(values)==6 and len(forms)==37
 folder=C/'audi-seed-read-invocations';folder.mkdir(exist_ok=True);record={'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'processId':os.getpid(),'classificationReceiptPin':{'bytes':720844,'sha256':'4bb97b40446fad1a43e08b498ebdab7e1c82af35470de5b83419932047f3eb5a'},'distinctValues':6,'variantForms':37,'payloadReadOperations':len(reads),'uniqueOriginalFiles':len({r['path'] for r in reads}),'reads':reads,'noValuesOrValueDigestsPersisted':True,'URLComponentRepresentationIncludedByUnchangedVariantsFunction':True,'generalURLDecodedRuntimeCoverageClaimed':False}
 with (folder/f'{os.getpid()}-{time.time_ns()}.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
 return forms,{'audiRuntimeValues':6,'audiRuntimeForms':37,'audiOriginalPayloadReadOperations':len(reads)}
def code_context(ps,data,name):
 approved=[r for r in review()['exactSupportCodeClassifications'] if r['member']==name]
 if not approved:return ps,[]
 actual={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};assert all(r['filePin']==actual for r in approved)
 findings=[{k:v for k,v in r['exactFinding'].items() if k!='member'} for r in approved];assert len(findings)==len({json.dumps(r,sort_keys=True) for r in findings});classified=[];blocked=[]
 for f in ps:
  if f in findings:
   r=approved[findings.index(f)];assert hashlib.sha256(data[r['byteStart']:r['byteEndExclusive']]).hexdigest()==r['matchedSyntaxSHA256'];classified.append({'member':name,'filePin':actual,'finding':f,'classification':'Exact independently reviewed noncredential Python key-handling syntax'})
  else:blocked.append(f)
 assert len(classified)==len(approved),'Missing/duplicate/mismatched classified candidate';return blocked,classified
