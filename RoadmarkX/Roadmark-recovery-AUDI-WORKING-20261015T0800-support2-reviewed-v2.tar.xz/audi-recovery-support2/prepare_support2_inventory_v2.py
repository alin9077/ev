from capture_v2 import *
scope=load(C/'SUPPORT2-SCOPE.json');names=scope['files'];assert len(names)==len(set(names));rows=[];prior=load(C/'SUPPORT-MEMBER-INVENTORY.json')['files'];priorScripts={(r['bytes'],r['sha256']) for r in prior if P(r['payloadPath']).suffix=='.py'};newScripts=set()
for n in names:
 safe(n);p=C/n;assert p.is_file() and not p.is_symlink();assert p.suffix in ['.py','.json','.txt','.log','.err','.diff','.md'];assert not n.startswith('library-') and n not in ['SUPPORT2-MEMBER-INVENTORY.json','support2-package.json','ARCHIVE-PLAN-v2.json','RESTORE-PLAN-v2.json','FRESH-ONLY-RESTORE-MANIFEST-v2.json'];got,ident=check(p,{})
 if p.suffix=='.py':assert (got['bytes'],got['sha256']) not in priorScripts|newScripts;newScripts.add((got['bytes'],got['sha256']))
 rows.append({'path':'audi-recovery-support2/'+n,**got,'originalBytes':got['bytes'],'originalSHA256':got['sha256'],'payloadPath':str(p),'sourceIdentity':ident})
aliases=scope.get('exactByteReuse',[]);available={r['path']:r for r in prior+rows}
for a in aliases:
 p=P(a['originalPath']);assert p.parent==C and p.name not in names;check(p,a);target=available[a['retainedMember']];assert all(a[k]==target[k] for k in ['bytes','sha256']);assert a['reconstruction']=='Copy the exact retained member bytes to this historical support filename when reproducing its recorded command'
dump(C/'SUPPORT2-MEMBER-INVENTORY.json',{'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SEALED_UNIQUE_ADDITIVE_SUPPORT_BEFORE_FINAL_PRIVACY_AND_REPLAY','files':rows,'scopePin':pin(C/'SUPPORT2-SCOPE.json'),'originalSupportInventoryPin':pin(C/'SUPPORT-MEMBER-INVENTORY.json'),'exactByteReuse':aliases,'noRecursiveExecutableEmbedding':True,'postSealReceiptsRetainedExternally':True});print(json.dumps({'support2Files':len(rows),'support2Bytes':sum(r['bytes'] for r in rows)}))
