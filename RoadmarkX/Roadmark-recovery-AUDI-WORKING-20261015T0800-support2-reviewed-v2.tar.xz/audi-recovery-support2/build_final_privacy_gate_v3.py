"""Aggregate complete unchanged scans with one exact independently approved code adjudication."""
from capture_v2 import *
from audi_support_runtime_adjudication_v1 import adjudicate
ars=load(C/'ARCHIVE-PLAN-v3.json')['archives'];assert len(ars)==7
assert load(C/'INDEPENDENT-AUDI-SUPPORT-RUNTIME-FIXTURE-v2.json')['result']=='PASS'
rows=[];allmembers={}
for i,a in enumerate(ars,1):
 name=f'scan-final-{i:02d}'+('-v2' if i==7 else '')
 report=C/(name+'.json');metric=C/(name+'.resources.json');q=load(report);m=load(metric)
 expected_command=['python3',str(C/('privacy_v6.py' if i==7 else 'privacy_v5.py')),a['file'],str(report)]
 assert m['command']==expected_command and m['addressSpaceLimitBytes']==268435456 and not m['timedOut']
 assert q['archivePin']=={k:a[k] for k in ['bytes','sha256']}
 got={r['path']:{k:r[k] for k in ['path','bytes','sha256']} for r in q['members']};want={r['path']:r for r in a['memberFiles']}
 assert got==want and len(got)==len(q['members'])==q['regularFilesScanned'] and sum(r['bytes'] for r in got.values())==q['bytesScanned']
 assert not(set(allmembers)&set(got));allmembers.update(got)
 assert not any(q[k] for k in ['exactValueMatches','primaryHeaderCandidates','errors'])
 judgment=None
 if i==7:
  assert m['exitCode']==2 and q['status']=='review-required' and len(q['unclassifiedRuntimeCandidates'])==3
  judgment=adjudicate(q,a['memberFiles'],{'archive':a['filename'],**{k:a[k] for k in ['bytes','sha256']}})
 else:assert m['exitCode']==0 and q['status']=='clean' and not q['unclassifiedRuntimeCandidates']
 row={'archive':a['filename'],'report':str(report),'reportPin':pin(report),'terminal':m,'members':len(got),'bytes':q['bytesScanned'],'classifiedPublicLexicalCollisions':q['classifiedPublicLexicalCollisions'],'classifiedExactCodeHeaderCandidates':q['classifiedExactCodeHeaderCandidates'],'cachedPatternMembers':sum(r['patternVerdict']=='exact-prior-source-cache' for r in q['members']),'rawScannerStatus':q['status'],'rawRuntimeCandidateCount':len(q['unclassifiedRuntimeCandidates'])}
 if judgment is not None:row['runtimeCodeAdjudication']=judgment
 rows.append(row)
expected=load(C/'FRESH-ONLY-RESTORE-MANIFEST-v3.json');assert allmembers=={r['path']:r for r in expected['files']}
gate={'result':'PASS','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archives':rows,'freshMembers':len(allmembers),'freshBytes':sum(r['bytes'] for r in allmembers.values()),'currentKnownValuesAcrossAllMembers':True,'exactCachedPatternVerdictsOnly':True,'knownHistoricalValues':55,'knownHistoricalForms':373,'mercedesRuntimeValues':20,'mercedesRuntimeForms':128,'leapmotorCookieAndHeaderValues':26,'leapmotorCookieForms':171,'classifiedPublicLexicalCollisions':sum(x['classifiedPublicLexicalCollisions'] for x in rows),'classifiedExactCodeHeaderCandidates':sum(len(x['classifiedExactCodeHeaderCandidates']) for x in rows),'classifiedExactCodeRuntimeCandidates':3,'rawRuntimeCandidatesPreserved':3,'rawScannerResultsModified':False,'supportRuntimeApproval':pin(C/'APPROVED-AUDI-SUPPORT-ADJUDICATION-v1.json'),'supportRuntimeClassification':pin(C/'INDEPENDENT-AUDI-SUPPORT-RUNTIME-CLASSIFICATION-v1.json'),'supportRuntimeFixture':pin(C/'INDEPENDENT-AUDI-SUPPORT-RUNTIME-FIXTURE-v2.json'),'priorFailedSupportScan':pin(C/'scan-final-07.json'),'sixExactCleanReportsReused':True,'unclassifiedFindings':0,'errors':0,'limitations':'Complete unchanged searches plus exact independent adjudication of three pinned Python syntax candidates; no universal absence guarantee, decryption or recursive arbitrary-format decoding.'}
for k in ['mazdaCookieAndHeaderValues','mazdaCookieForms','mazdaPublicBareValues','mazdaPublicBareForms','mazdaFormTokenValues','mazdaFormTokenForms','audiRuntimeValues','audiRuntimeForms']:gate[k]=q[k]
dump(C/'ALL-ARCHIVE-PRIVACY-GATE-v3.json',gate);print(json.dumps({'result':'PASS','archives':7,'freshMembers':len(allmembers),'rawRuntimeCodeCandidatesPreservedAndAdjudicated':3}))
