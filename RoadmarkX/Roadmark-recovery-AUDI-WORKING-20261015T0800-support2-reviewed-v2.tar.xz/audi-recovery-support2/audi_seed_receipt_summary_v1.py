import pathlib,json,hashlib,datetime
C=pathlib.Path(__file__).resolve().parent
def summary(final=False):
 rows=[]
 for p in sorted((C/'audi-seed-read-invocations').glob('*.json')):
  b=p.read_bytes();r=json.loads(b);assert r['distinctValues']==6 and r['variantForms']==37 and r['payloadReadOperations']==6 and r['noValuesOrValueDigestsPersisted'];rows.append({'receipt':p.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'record':r})
 return {'asOf':max((x['record']['completedAt'] for x in rows),default=None) if final else datetime.datetime.now(datetime.timezone.utc).isoformat(),'completedInvocations':len(rows),'payloadReadOperations':sum(x['record']['payloadReadOperations'] for x in rows),'distinctValues':6,'variantForms':37,'receipts':rows,'noValuesOrValueDigestsPersisted':True,'coverage':'Current fresh members: additive exact known-value searches, including supported URL-component representations; not general URL-decoded runtime-pattern coverage'}
