import pathlib,json,datetime,os
from capture_v2 import C,load,pin
from audi_seed_receipt_summary_v1 import summary as audi_seed_summary
def seed_execution_summary():
 rows=[]
 for p in sorted((C/'seed-read-invocations').glob('*.json')):
  r=load(p);assert r['exactPinnedMembersReadAndVerified']==200 and r['historicalArchives']==21 and r['noExtractedValuesPersisted'];rows.append({'receipt':p.name,**pin(p),'record':r})
 return {'asOf':max((x['record']['completedAt'] for x in rows),default=None),'completedInvocations':len(rows),'targetedPinnedMemberReads':200*len(rows),'uniquePinnedMembers':200,'uniqueHistoricalArchives':21,'receipts':rows,'laterDocumentAndActiveScansRecordedSeparately':True,'noExtractedValues':True}
phases={n:load(C/f'library-{n}-results.json') for n in ['archives','documents','active']};rows=[r for x in phases.values() for r in x['results']];assert len(rows)==len(load(C/'ARCHIVE-PLAN-v2.json')['archives'])+5;files=[];verifiedArchives={r['library_file_id']:r for r in [json.loads(line) for line in (C/'library-archives-verified.jsonl').read_text().splitlines()]}
for r in rows:
 p=pathlib.Path(r['local_path']);assert r['status']=='succeeded' and r['local_metadata_applied'] and os.getxattr(p,'user.library-file-id').decode()==r['library_file_id'] and os.getxattr(p,'user.library-file-version').decode()==str(r['current_version_number']);
 if r['library_file_id'] in verifiedArchives:
  old=verifiedArchives[r['library_file_id']];assert old['verified'] and old['filename']==p.name and old['version']==r['current_version_number'] and p.stat().st_size==old['bytes'];filepin={k:old[k] for k in ['bytes','sha256']}
 else:filepin=pin(p)
 files.append({'filename':p.name,'library_file_id':r['library_file_id'],'version':r['current_version_number'],**filepin})
x={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'All new Audi working recovery files persisted; integration accepted and broader release gates open','sourceLibraryFileId':phases['archives']['results'][0]['library_file_id'],'archiveLibraryFileIds':[r['library_file_id'] for r in phases['archives']['results']],'indexLibraryFileId':next(r['library_file_id'] for r in phases['documents']['results'] if 'INDEX-' in r['file_name']),'manifestLibraryFileId':next(r['library_file_id'] for r in phases['documents']['results'] if 'MANIFEST-' in r['file_name']),'verificationLibraryFileId':next(r['library_file_id'] for r in phases['documents']['results'] if 'VERIFICATION-' in r['file_name']),'summaryLibraryFileId':next(r['library_file_id'] for r in phases['documents']['results'] if 'M1-UPDATE' in r['file_name']),'activeReceiptLibraryFileId':phases['active']['results'][0]['library_file_id'],'files':files,'phases':phases,'independentVerification':load(C/'INDEPENDENT-AUDI-RECOVERY-VERIFICATION-v2.json'),'documentCheck':load(C/'INDEPENDENT-DELIVERY-DOCUMENT-CHECK.json'),'activeCheck':load(C/'INDEPENDENT-ACTIVE-RECEIPT-CHECK.json'),'savingAnnouncement':load(C/'SAVING-ANNOUNCEMENT.json'),'noDeletionOrReplacement':True,'noPinnedSourceOrStatusMutation':True,'targetedSeedReadExecutionSummary':seed_execution_summary(),'audiRuntimeResidualVerification':audi_seed_summary(final=True),'delivery':'Await root accepted-send confirmation'}
for n,k in [('DELIVERY-CONFIRMATION.json','deliveryConfirmation'),('INDEPENDENT-PERSISTED-ACTIVE-CHECK.json','activePersistenceCheck')]:
 if (C/n).exists():x[k]=load(C/n)
if 'deliveryConfirmation' in x:x['delivery']='Parent reports accepted delivery; exact message, timestamp and IDs in deliveryConfirmation'
target=C/'FINAL-AUDI-UPLOAD-RECEIPTS.json'
if target.exists():
 previous=target.read_bytes();prior=C/'FINAL-AUDI-UPLOAD-RECEIPTS-before-persistence-check.json'
 assert not prior.exists(),'Earlier terminal version already preserved; inspect instead of overwriting again'
 with prior.open('xb') as f:f.write(previous)
 assert pin(prior)==pin(target)
target.write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({k:v for k,v in x.items() if 'LibraryFileId' in k or k=='status'}))
