#!/usr/bin/env python3
"""Bounded raw-pattern preflight of the two new checkers and this exact helper.
No seed extraction, archive reads, payload changes, or classification exemptions.
"""
import ast,datetime,hashlib,importlib.util,json,pathlib,resource,stat,sys
sys.dont_write_bytecode=True
C=pathlib.Path(__file__).resolve().parent
A=C.parents[1]/'privacy-audit-20261014T0355'
OUT=C/'INDEPENDENT-AUDI-CHECKER-PATTERN-PREFLIGHT-v1.json'
def pin(p):
 def identity():
  s=p.lstat();assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents)
  return [s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev]
 before=identity();b=p.read_bytes();assert before==identity() and len(b)==before[0]
 return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def main():
 assert resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456)
 engines={'final_residual_scan_memory_bounded.py':'db71353ba5fe98021f68cd9aeaae6eb4e1878627fb4985278b11457baf837238','chunked_lower_find.py':'6de208f633b05ef1cb894ca8e896c4a489bb093eb1339134c4b1d7158263ec1f','audit_scan.py':'54ee0827089ad8202a24c6769a4178dee28fe96b85f1fd8a627a15703c15f3b2','runtime_token_scan.py':'4ea9c6be9b292bbe126fcc2f8d7b3254a1dc941c49d78b263c9203d0025f9c46'}
 for n,h in engines.items():assert pin(A/n)['sha256']==h
 sys.path.insert(0,str(A));spec=importlib.util.spec_from_file_location('checker_preflight_engine',A/'final_residual_scan_memory_bounded.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);primary,runtime=mod.patterns()
 rows=[]
 for n in ['independent_audi_recovery_v2.py','independent_audi_documents_v2.py',pathlib.Path(__file__).name]:
  p=C/n;b=p.read_bytes();ast.parse(b);before=pin(p);ps,_,_=primary(b,n);rs=runtime(b.decode());assert pin(p)==before
  rows.append({'filename':n,**before,'primaryFindings':ps,'rawRuntimeFindings':rs,'astValid':True})
 result={'result':'PASS' if all(not r['primaryFindings'] and not r['rawRuntimeFindings'] for r in rows) else 'REVIEW_REQUIRED','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':rows,'enginePins':engines,'rawPatternsUnchanged':True,'knownValueSearchPerformed':False,'seedReads':0,'historicalArchiveReads':0,'payloadsModified':False,'newClassificationsGranted':False,'scope':'Only raw unchanged primary/runtime patterns on these three exact source files; final archive scans remain required'}
 with OUT.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({'result':result['result'],'files':len(rows),'primaryFindings':sum(len(r['primaryFindings']) for r in rows),'rawRuntimeFindings':sum(len(r['rawRuntimeFindings']) for r in rows)}))
 return 0 if result['result']=='PASS' else 2
if __name__=='__main__':sys.exit(main())
