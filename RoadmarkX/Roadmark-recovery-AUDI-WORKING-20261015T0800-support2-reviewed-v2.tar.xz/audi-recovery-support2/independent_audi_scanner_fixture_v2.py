#!/usr/bin/env python3
"""One bounded independent Audi fixture; original bytes and values remain unchanged."""
import ast, collections, copy, datetime, hashlib, importlib.util, json, os, pathlib, stat, sys
sys.dont_write_bytecode = True
P = pathlib.Path
C = P(__file__).resolve().parent
A = C.parents[1] / 'privacy-audit-20261014T0355'
REPORT = C / 'INDEPENDENT-AUDI-SCANNER-FIXTURE-v2.json'
ISOLATED = C / 'independent-scanner-fixture-data-v2'
EXPECTED = {
 'audi_scan_additions_v3.py': '8b6d1933dfce1734c9a0b8dc167b760a975314a8a0a84919eaabc62ae28cb435',
 'privacy_v2.py': '8f5cc03b411a8276a0245e2e911dede15b0746d008b24e1c7cd27720320c5a8f',
 'privacy_v5.py': '4b555e2f81eb96987daf8c4a2fe01d6d9c2d8e3818cde009f7dfa66a055262f9',
 'run_scans_v2.py': '4ece8f5af5813ae226b8acd3e516f2a3a70db34ca9d0f7790bbcc9e0c2b81ac2',
 'run_scans_v5.py': '89aa43c2f8a6e8f09bb8145257fc9718d864c16516a750f1d48b4e2feb4e061e',
 'scan_documents_v2.py': '34398778e2e5ff84b1cb5fc3cafd5be5955f5651e3d664c032e9cc2276f34fae',
 'scan_documents_v5.py': 'ba54acf8358b19b311cf072e45db107fcb0a2071c7002c2bcb820fcd8d91e364',
 'run_bounded_v1.py': '44aa66726c01e1defd7b2fa45ad0ccd45fcfaf3cfcbe0792ab62fe5aa1c1fb8d',
 'capture_v2.py': '59e21e7eb841f62ac84a30f318e9e8344ff7c987bcfdd00759215a8e5e9379ed',
 'INDEPENDENT-AUDI-RUNTIME-BATCH-CLASSIFICATION-v1.json': '4bb97b40446fad1a43e08b498ebdab7e1c82af35470de5b83419932047f3eb5a',
 'APPROVED-AUDI-REMEDIATION-v1.json': 'eff4b3ec10144684bedda1f024773e5e0d1b213c3b968fe4f2a5e3d12cbff80d',
}
ENGINES = {
 'final_residual_scan_memory_bounded.py': 'db71353ba5fe98021f68cd9aeaae6eb4e1878627fb4985278b11457baf837238',
 'chunked_lower_find.py': '6de208f633b05ef1cb894ca8e896c4a489bb093eb1339134c4b1d7158263ec1f',
 'audit_scan.py': '54ee0827089ad8202a24c6769a4178dee28fe96b85f1fd8a627a15703c15f3b2',
 'runtime_token_scan.py': '4ea9c6be9b292bbe126fcc2f8d7b3254a1dc941c49d78b263c9203d0025f9c46',
}
rows = []
report = {'result': 'FAIL', 'fixture': P(__file__).name, 'checks': rows,
          'productionPayloadsModified': False, 'valuesOrValueDigestsPersisted': False,
          'historicalArchivesRead': 0, 'productionSeedReceiptDirectoriesModified': False}

def sha(b):
 return hashlib.sha256(b).hexdigest()

def ident(p):
 z = p.lstat()
 assert stat.S_ISREG(z.st_mode) and not any(q.is_symlink() for q in p.parents)
 return [z.st_size, z.st_mtime_ns, z.st_ctime_ns, z.st_ino, z.st_dev]

def read_pinned(p, expected=None):
 before = ident(p)
 b = p.read_bytes()
 assert ident(p) == before and len(b) == before[0]
 got = {'bytes': len(b), 'sha256': sha(b)}
 if expected is not None:
  assert got == expected
 return b, got, before

def check(name, ok, **details):
 rows.append({'check': name, 'result': 'PASS' if ok else 'FAIL', **details})

def rejects(fn):
 try:
  fn()
 except AssertionError:
  return True
 return False

def load_module(name, path):
 spec = importlib.util.spec_from_file_location(name, path)
 module = importlib.util.module_from_spec(spec)
 spec.loader.exec_module(module)
 return module

def production_receipts():
 result = {}
 for name in ('audi-seed-read-invocations', 'seed-read-invocations'):
  folder = C / name
  result[name] = ({p.name: ident(p) for p in folder.iterdir()} if folder.exists() else None)
 return result

def audit(event, args):
 if event == 'open' and isinstance(args[0], (str, bytes)):
  name = os.fsdecode(args[0]).lower()
  assert not name.endswith(('.tar', '.tar.xz', '.xz', '.gz', '.zip', '.tgz')), 'Archive read forbidden in fixture'
sys.addaudithook(audit)

def run():
 assert not REPORT.exists() and not ISOLATED.exists()
 static = {}
 for name, expected in EXPECTED.items():
  b, got, _ = read_pinned(C / name)
  assert got['sha256'] == expected
  static[name] = got
 report['inputPins'] = static
 engine_pins = {}
 for name, expected in ENGINES.items():
  b, got, _ = read_pinned(A / name)
  assert got['sha256'] == expected
  engine_pins[name] = got
 report['enginePins'] = engine_pins
 check('All reviewed implementation and original engine pins exact', True)
 old_tree = ast.parse((C / 'privacy_v2.py').read_text())
 new_tree = ast.parse((C / 'privacy_v5.py').read_text())
 old = {n.name: n for n in old_tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
 new = {n.name: n for n in new_tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
 unchanged = sorted(set(old) - {'main', 'seed_sets'})
 for name in unchanged:
  assert ast.dump(old[name], include_attributes=False) == ast.dump(new[name], include_attributes=False)
 inherited = copy.deepcopy(new['inherited_seed_sets'])
 inherited.name = 'seed_sets'
 assert ast.dump(old['seed_sets'], include_attributes=False) == ast.dump(inherited, include_attributes=False)
 assert (C / 'scan_documents_v5.py').read_text() == (C / 'scan_documents_v2.py').read_text().replace('from privacy_v2 import', 'from privacy_v5 import', 1)
 check('Header runtime byte-search and inherited seed semantics unchanged', True, unchangedDefinitions=unchanged, inheritedSeedBodyIdentical=True, documentChangeIsImportOnly=True)
 adapter = load_module('fixture_audi_adapter', C / 'audi_scan_additions_v3.py')
 review_path = adapter.REVIEW
 d = adapter.review()
 assert review_path == C / 'INDEPENDENT-AUDI-RUNTIME-BATCH-CLASSIFICATION-v1.json'
 assert static[review_path.name]['bytes'] == 720844
 assert len(d['exactSupportCodeClassifications']) == 10
 approved = d['exactSupportCodeClassifications']
 support = json.loads((C / 'SUPPORT-MEMBER-INVENTORY.json').read_text())
 support_by = {r['path']: r for r in support['files']}
 members = sorted({r['member'] for r in approved})
 assert len(members) == 5
 sys.path.insert(0, str(A))
 residual = load_module('fixture_residual', A / 'final_residual_scan_memory_bounded.py')
 # source_values is never called. patterns compiles the original pinned engines
 # with their existing bounded lowercase wrapper; no archive loop is executed.
 primary, runtime = residual.patterns()
 pattern_scope = {'scan': residual}
 exec(compile(ast.Module(body=[new['scan_patterns']], type_ignores=[]), str(C / 'privacy_v5.py'), 'exec'), pattern_scope)
 scan_patterns = pattern_scope['scan_patterns']
 total_raw = total_classified = total_blocked = total_runtime = 0
 per_member = []
 exemplar = None
 for member in members:
  rr = [r for r in approved if r['member'] == member]
  support_row = support_by[member]
  path = P(support_row['payloadPath'])
  data, got, identity = read_pinned(path, rr[0]['filePin'])
  assert identity == support_row['sourceIdentity'] == rr[0]['identity']
  assert got == {k: support_row[k] for k in ('bytes', 'sha256')}
  expected_findings = [{k: v for k, v in r['exactFinding'].items() if k != 'member'} for r in rr]
  ps, us, benign = scan_patterns(data, member, primary, runtime, set())
  assert collections.Counter(json.dumps(f, sort_keys=True) for f in ps) == collections.Counter(json.dumps(f, sort_keys=True) for f in expected_findings)
  blocked, classified = adapter.code_context(ps, data, member)
  assert not blocked and len(classified) == len(rr)
  assert not us and benign == 0
  assert ident(path) == identity
  total_raw += len(ps)
  total_classified += len(classified)
  total_blocked += len(blocked)
  total_runtime += len(us)
  per_member.append({'member': member, 'filePin': got, 'rawPrimaryFindings': len(ps), 'classifiedExactFindings': len(classified), 'remainingPrimaryFindings': len(blocked), 'runtimeFindings': len(us)})
  if exemplar is None:
   exemplar = (member, data, ps)
  residual.release_memory()
 check('Exactly ten findings from five sealed support members classified', total_raw == total_classified == 10 and total_blocked == total_runtime == 0, members=per_member)
 member, data, ps = exemplar
 extra = {'kind': 'synthetic-unapproved-candidate', 'location': {'line': 1}, 'confidence': 'fixture'}
 blocked, classified = adapter.code_context(ps + [extra], data, member)
 check('Injected extra finding stays blocked', blocked == [extra] and len(classified) == len(ps))
 mismatch = copy.deepcopy(ps)
 mismatch[0]['location']['charStart'] += 1
 check('Exact finding mismatch fails closed', rejects(lambda: adapter.code_context(mismatch, data, member)))
 check('Missing finding fails closed', rejects(lambda: adapter.code_context(ps[1:], data, member)))
 check('Added duplicate finding fails closed', rejects(lambda: adapter.code_context(ps + [ps[0]], data, member)))
 check('Duplicate substitution fails closed', rejects(lambda: adapter.code_context([ps[0], ps[0]], data, member)))
 check('File pin mismatch fails closed', rejects(lambda: adapter.code_context(ps, data + b'\n', member)))
 blocked, classified = adapter.code_context(ps, data, 'unapproved-same-extension.py')
 check('Unapproved member receives no extension exemption', blocked == ps and classified == [])
 actual_review = adapter.review
 mutated = copy.deepcopy(d)
 target = next(r for r in mutated['exactSupportCodeClassifications'] if r['member'] == member)
 target['matchedSyntaxSHA256'] = '0' * 64
 try:
  adapter.review = lambda: mutated
  check('Span hash mismatch fails closed', rejects(lambda: adapter.code_context(ps, data, member)))
 finally:
  adapter.review = actual_review
 before_receipts = production_receipts()
 sources = {r['member']: r for r in d['files']}
 allowed_originals = {P(sources[g['sources'][0]['member']]['originalPath']) for g in d['newValueSources']}
 assert len(allowed_originals) == 4
 observed_reads = []
 observed_variants = {}
 original_read = P.read_bytes
 def tracked_read(path):
  if path in allowed_originals:
   observed_reads.append(str(path))
  return original_read(path)
 def variants(known):
  assert len(known) == 6 and all(isinstance(v, bytes) and v for v in known)
  result = residual.variants_for(known)
  observed_variants['distinctValues'] = len(known)
  observed_variants['variantForms'] = len(result)
  return result
 ISOLATED.mkdir(exist_ok=False)
 adapter.C = ISOLATED
 try:
  P.read_bytes = tracked_read
  forms, counts = adapter.audi_values(variants)
 finally:
  P.read_bytes = original_read
 assert adapter.REVIEW == review_path
 check('Six distinct values produce exactly 37 unchanged variant forms', len(forms) == 37 and observed_variants == {'distinctValues': 6, 'variantForms': 37} and counts == {'audiRuntimeValues': 6, 'audiRuntimeForms': 37, 'audiOriginalPayloadReadOperations': 6})
 del forms
 check('Actual seed payload reads are six operations across four originals', len(observed_reads) == 6 and len(set(observed_reads)) == 4)
 receipts = list((ISOLATED / 'audi-seed-read-invocations').iterdir())
 assert len(receipts) == 1
 receipt_data, receipt_pin, _ = read_pinned(receipts[0])
 receipt = json.loads(receipt_data)
 assert receipt['distinctValues'] == 6 and receipt['variantForms'] == 37
 assert receipt['payloadReadOperations'] == 6 and receipt['uniqueOriginalFiles'] == 4
 assert receipt['noValuesOrValueDigestsPersisted']
 assert [r['path'] for r in receipt['reads']] == observed_reads
 assert receipt['processId'] == os.getpid()
 check('Fixture seed receipt isolated from production with exact read accounting', production_receipts() == before_receipts, receiptPath=str(receipts[0]), receiptPin=receipt_pin, originalPayloadReadOperations=6, uniqueOriginalFiles=4)
 report['fixtureSeedReadReceipt'] = {'path': str(receipts[0]), 'pin': receipt_pin, 'processId': receipt['processId']}
 identity_node = next(n for n in ast.parse((C / 'capture_v2.py').read_text()).body if isinstance(n, ast.FunctionDef) and n.name == 'identity')
 identity_source = ast.unparse(identity_node)
 attributes = {n.attr for n in ast.walk(identity_node) if isinstance(n, ast.Attribute)}
 check('Production identities use lstat regular/no-symlink five-field tuple', {'lstat', 'S_ISREG', 'is_symlink', 'parents', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_ino', 'st_dev'} <= attributes and not any('atime' in a for a in attributes) and all(adapter.identity(p) == ident(p) for p in allowed_originals), fields=['size', 'mtime_ns', 'ctime_ns', 'inode', 'device'], atimeExcluded=True)
 report['rawPrimaryFindings'] = total_raw
 report['classifiedExactCodeFindings'] = total_classified
 report['unclassifiedPrimaryFindings'] = total_blocked
 report['runtimeFindings'] = total_runtime
 report['audiDistinctValues'] = 6
 report['audiVariantForms'] = 37
 report['originalPayloadReadOperations'] = len(observed_reads)
 report['uniqueOriginalFiles'] = len(set(observed_reads))
 report['engineSemanticsUnchanged'] = True

try:
 run()
 report['result'] = 'PASS' if all(r['result'] == 'PASS' for r in rows) else 'FAIL'
except BaseException as exc:
 report['result'] = 'FAIL'
 report['errorType'] = type(exc).__name__
 # Never expose exception messages, payloads, extracted values, or value digests.
report['completedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
report['fixturePin'] = {'bytes': P(__file__).stat().st_size, 'sha256': sha(P(__file__).read_bytes())}
with REPORT.open('x') as out:
 json.dump(report, out, indent=2)
 out.write('\n')
 out.flush()
 os.fsync(out.fileno())
print(json.dumps({'result': report['result'], 'checks': len(rows), 'failedChecks': [r['check'] for r in rows if r['result'] != 'PASS'], 'report': REPORT.name}), flush=True)
sys.exit(0 if report['result'] == 'PASS' else 2)
