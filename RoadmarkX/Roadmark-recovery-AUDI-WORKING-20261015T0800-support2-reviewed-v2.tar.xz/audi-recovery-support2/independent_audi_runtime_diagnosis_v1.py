#!/usr/bin/env python3
"""Read-only, no-value classification of seven reported Audi HTML ranges.

No archive access, network calls, scanner-rule changes, or payload writes.
Proposed replacements exist only in process memory until separately approved.
"""
import collections, datetime, hashlib, html.parser, importlib.util, json, pathlib, re, stat, sys
sys.dont_write_bytecode=True
C=pathlib.Path(__file__).resolve().parent
R=C.parents[1]
CHUNK=65536
REPLACEMENT=b'[REDACTED-AUDI-CIVIC-COOKIE-CONTROL-KEY]'
assert len(REPLACEMENT)==40
def load(p): return json.loads(p.read_text())
def sha(b): return hashlib.sha256(b).hexdigest()
def identity(p):
 s=p.lstat(); assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents)
 return [s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev]
def read(p,expected=None):
 before=identity(p); b=p.read_bytes(); assert identity(p)==before and len(b)==before[0]
 pin={'bytes':len(b),'sha256':sha(b)}
 if expected: assert pin=={k:expected[k] for k in ('bytes','sha256')}
 return b,pin,before
class Visible(html.parser.HTMLParser):
 def __init__(self): super().__init__(convert_charrefs=True); self.hidden=0; self.parts=[]
 def handle_starttag(self,tag,attrs):
  if tag in ('script','style'): self.hidden+=1
 def handle_endtag(self,tag):
  if tag in ('script','style'): self.hidden-=1; assert self.hidden>=0
 def handle_data(self,data):
  if not self.hidden:self.parts.append(data)
def visible(b):
 p=Visible();p.feed(b.decode());p.close();assert p.hidden==0
 return '\n'.join(p.parts).encode()
def leaves(x,p=''):
 if isinstance(x,dict):
  for k,v in x.items():yield from leaves(v,p+'/'+k.replace('~','~0').replace('/','~1'))
 elif isinstance(x,list):
  for i,v in enumerate(x):yield from leaves(v,p+'/'+str(i))
 elif isinstance(x,str):yield p,x
def main():
 report,pin_report,_=read(C/'scan-02.json');report=json.loads(report)
 assert report['status']=='review-required' and not report['primaryHeaderCandidates'] and not report['errors']
 candidates=report['unclassifiedRuntimeCandidates'];assert len(candidates)==7 and len({r['member'] for r in candidates})==7
 capture=load(C/'proof-capture-v1.json');cap={r['path']:r for r in capture['files']}
 source={r['path']:r for r in load(C/'source-capture.json')['files']}
 index_names=['audi-research/source-index-review-v1.json','audi-review/source-index-hash-review-v1.json','audi-research/gt-q8/normalized-gt-q8.json']
 indices=[]
 for n in index_names:
  r=cap[n]; b,p,_=read(pathlib.Path(r['payloadPath']),r); indices.append((n,p,list(leaves(json.loads(b)))))
 n='data/m1-brand-updates/audi-2026-10-15.json';r=source[n];b,p,_=read(pathlib.Path(r['payloadPath']),r);packet=json.loads(b);indices.append(('roadmark/'+n,p,list(leaves(packet))))
 mpath=C/'selected-proof-sanitized-v1/audi-research/gt-q8/manifest.jsonl';mb,mp,_=read(mpath,cap['audi-research/gt-q8/manifest.jsonl']);manifest=[json.loads(x) for x in mb.splitlines()]
 # Reconstruct only three previously classified public bare values from eight exact
 # pinned local JSON files. No historical archive/member reads and no values persist.
 A=R/'privacy-audit-20261014T0355';engine=A/'final_residual_scan_memory_bounded.py';eb,ep,_=read(engine)
 assert ep['sha256']=='db71353ba5fe98021f68cd9aeaae6eb4e1878627fb4985278b11457baf837238'
 sys.path.insert(0,str(A));sp=importlib.util.spec_from_file_location('residual_diagnosis',engine);mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)
 M=C.parent/'mazda-working-20261015T0405';mi=load(M/'JSON-SANITIZER-CANDIDATES-v1.json'); bare=set();seed_reads=[]
 assert len(mi['candidateFiles'])==8
 for r in mi['candidateFiles']:
  p=pathlib.Path(r['originalPath']);b,pin,ident=read(p,{'bytes':r['originalBytes'],'sha256':r['originalSHA256']});j=json.loads(b)
  assert len(r['locations'])==1 and r['locations'][0]['pointer']=='/headers/Set-Cookie'
  pair=j['headers']['Set-Cookie'].split(';',1)[0];name,sep,v=pair.partition('=');assert sep
  assert (name=='EPiStateMarker' and len(v)==4 and isinstance(json.loads(v),bool)) or (name=='cg_ab_variant' and len(v) in (7,11))
  bare.add(v.encode());seed_reads.append({'path':str(p),**pin,'identity':ident})
 assert len(bare)==3;forms=mod.variants_for({v:[] for v in bare});groups=collections.defaultdict(list)
 for r in report['exactValueMatches']:groups[r['member']].append(r)
 assert len(report['exactValueMatches'])==698 and set(groups)=={r['member'] for r in candidates}
 rows=[];values=set();all_locations=[]
 for r in candidates:
  n=r['member'];c=cap[n];b,bp,bident=read(pathlib.Path(c['payloadPath']),c);original,op,oid=read(pathlib.Path(c['originalPath']),{'bytes':c['originalBytes'],'sha256':c['originalSHA256']})
  assert original==b and oid==c['sourceIdentity'];s=b.decode();a,z=r['valueCharStart'],r['valueCharEnd'];v=s[a:z]
  assert r['layer']=='plain' and r['field']=='apiKey' and r['valueLength']==40 and len(v)==40 and v.isalnum();values.add(v)
  lo=len(s[:a].encode());hi=len(s[:z].encode());assert hi-lo==40 and b.count(v.encode())==1
  assert s[a-9:a]=="apiKey: '" and s[z:z+2]=="'," and "product: 'PRO_MULTISITE'" in s[z:z+120]
  start=s.rfind('<script',0,a);tag_end=s.find('>',start);end=s.find('</script>',z);assert 0<=start<tag_end<a<z<end
  assert s.rfind('</script>',0,a)<start and 'CookieControl.load(config)' in s[tag_end:end]
  assert 'https://cc.cdn.civiccomputing.com/9/cookieControl-9.x.min.js' in s[tag_end:end]
  proposed=b[:lo]+REPLACEMENT+b[hi:];assert len(proposed)==len(b) and proposed[:lo]==b[:lo] and proposed[hi:]==b[hi:]
  before_visible=visible(b);after_visible=visible(proposed);assert before_visible==after_visible
  source_row=[x for x in manifest if x.get('body_path')==c['originalPath']];assert len(source_row)==1;source_row=source_row[0]
  assert source_row['status']==200 and source_row['bytes']==len(b) and source_row['sha256']==sha(b)
  refs=[]
  for refpath,refpin,ls in indices:
   matches=[{'pointer':p,'match':'original-payload-sha256' if v==bp['sha256'] else 'capture-locator-or-public-url'} for p,v in ls if bp['sha256']==v or n in v or source_row['url']==v]
   if matches:refs.append({'path':refpath,**refpin,'references':matches})
  packet_sources=[{'id':x['id'],'supports':x.get('supports'),'title':x.get('title')} for x in packet['sources'] if n in json.dumps(x) or source_row['url']==x.get('url')]
  text_name=n.removesuffix('.html')+'.txt';tr=cap[text_name];tb,tp,_=read(pathlib.Path(tr['payloadPath']),tr)
  classified=[]
  for hit in groups[n]:
   l,h=hit['byteStart'],hit['byteEndExclusive'];lex=b[l:h];assert lex in forms and not (l<hi and lo<h) and proposed[l:h]==lex
   context=b[max(0,l-90):min(len(b),h+90)]
   classified.append({**hit,'length':h-l,'publicBareVariantEncoding':forms[lex]['encoding'],'reportedRangeMatchesExactPinnedPublicBareForm':True,'outsideRuntimeReplacement':True,'contextSHA256':sha(context),'contextBytes':len(context)})
  all_locations.extend(classified)
  rows.append({'member':n,'originalPath':c['originalPath'],'originalPin':op,'originalIdentity':oid,'copyPath':c['payloadPath'],'copyPin':bp,'copyIdentity':bident,'field':'apiKey','byteStart':lo,'byteEndExclusive':hi,'valueLength':40,'classification':'capability-like-public-service-runtime-key; not authorized as benign','serviceContext':{'service':'Civic Cookie Control','product':'PRO_MULTISITE','configConsumer':'CookieControl.load(config)','scriptUrl':'https://cc.cdn.civiccomputing.com/9/cookieControl-9.x.min.js','enclosingScriptCharStart':start,'enclosingScriptCharEndExclusive':end+9},'captureManifest':{'path':'audi-research/gt-q8/manifest.jsonl',**mp,'sourceRow':source_row},'sourceIndexReferences':refs,'packetSources':packet_sources,'proposedReplacement':REPLACEMENT.decode(),'proposedSanitizedPin':{'bytes':len(proposed),'sha256':sha(proposed)},'unchangedPrefixPin':{'bytes':lo,'sha256':sha(b[:lo])},'unchangedSuffixPin':{'bytes':len(b)-hi,'sha256':sha(b[hi:])},'everyOutsideRangeByteUnchanged':True,'visibleTextProjection':{'bytes':len(before_visible),'sha256':sha(before_visible),'equal':True,'method':'HTMLParser data excluding script and style; no browser execution'},'existingTextCapture':{'path':text_name,**tp,'unchanged':True},'knownValueLocations':len(classified)})
 assert len(values)==1
 out={'status':'REVIEW_REQUIRED_EXACT_COPY_ONLY_SANITATION','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputScan':pin_report,'scriptPin':read(pathlib.Path(__file__))[1],'files':rows,'fileCount':7,'rangeCount':7,'distinctRuntimeValues':1,'runtimeValuesOrValueDigestsPersisted':False,'knownValueLocationCount':len(all_locations),'knownValueLocations':all_locations,'publicBareSeedSourceReads':seed_reads,'targetedHistoricalArchiveReads':0,'classificationLimit':'Observed public client configuration is not proof of harmlessness or unrestricted rights. No API use or external transmission was attempted. Scanner remains unchanged. Prior gate stays failed until approved sanitized copies pass all required scans.','proposedAction':'On separate root approval, write new copy-only versions with these exact same-length ranges replaced; preserve original frozen hash provenance and byte maps, references, previous failure and support versions. Do not upload the original failed archive.','payloadsModified':False,'archivesRead':False}
 with (C/'INDEPENDENT-AUDI-RUNTIME-CLASSIFICATION-v1.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
 print(json.dumps({'status':out['status'],'files':7,'ranges':7,'uniqueValues':1,'classifiedKnownValueLocations':len(all_locations),'payloadsModified':False}))
if __name__=='__main__':main()
