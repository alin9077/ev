import test from "node:test";
import assert from "node:assert/strict";
import {
  applyBrandUpdates,
  prepareBrandResearch,
  brandVersionSnapshot,
  applyBrandTermFeatures,
  type BrandUpdatePacket,
} from "../src/lib/brand-updates";
import { availabilitySnapshot } from "../src/lib/availability-corrections";
import { currentBuyerSummary } from "../src/lib/selling-points";
import { validateResearch } from "../src/lib/validate";
import {
  storePortablePacks,
  hydratePortablePacks,
} from "../src/lib/portable-packs";
import { factClaim, featureClaim } from "../src/lib/citable";
import { compiledSource } from "./helpers/compiled-source";
import type {
  Car,
  Fact,
  Feature,
  Research,
  Source,
  Pack,
} from "../src/lib/types";

function fixture() {
  const source: Source = {
    id: "fixture-maker-2026-10-14",
    url: "https://maker.example/au/specifications",
    title: "Synthetic fixture specification",
    publisher: "Maker",
    source_type: "manufacturer",
    published_date: null,
    accessed_date: "2026-10-14",
    market: "AU",
    supports: "Synthetic exact-version measurements for behavioural tests",
  };
  const fact: Fact = {
    key: "range_km",
    label: "Claimed range",
    value: 450,
    unit: "km",
    basis: "WLTP",
    comparisonBasis: "WLTP",
    status: "standard",
    sourceIds: [source.id],
    date: "2026-10-14",
    market: "AU",
    scope: "Maker Example Base",
    qualifications: [],
    issues: [],
  };
  const car: Car = {
    id: "fixture_maker_example__base__1",
    modelId: "fixture_maker_example",
    family: "fixture-maker-example",
    slug: "base-1",
    brand: "Maker",
    model: "Example",
    trim: "Base",
    year: null,
    generation: "Current",
    drive: "RWD",
    vehicleClass: "passenger",
    availability: "current_or_order_listed",
    availabilityEvidence: {
      checkedAt: "2026-10-14",
      orderStatus: "unverified",
      stockStatus: "unverified",
      sourceIds: [source.id],
      qualifications: ["Stock unverified."],
    },
    facts: {
      range_km: fact,
      seats: {
        ...fact,
        key: "seats",
        label: "Seats",
        value: 5,
        unit: "",
        basis: "Occupied seats",
        comparisonBasis: "Occupied seats",
      },
    },
    issues: [],
  };
  const research: Research = {
    schema_version: "fixture",
    metadata: {
      as_of: "2026-10-14",
      baseline_variant_id: car.id,
      record_count: 1,
      criterion_count: 1,
      feature_row_count: 1,
    },
    models: [
      {
        id: car.modelId,
        brand: car.brand,
        model: car.model,
        generation: car.generation,
      },
    ],
    variants: [
      {
        id: car.id,
        model_id: car.modelId,
        brand: car.brand,
        model: car.model,
        trim: car.trim,
        model_year: null,
        record_state: car.availability,
        price_aud: null,
        price_basis: "",
        range_km: null,
        range_cycle: "",
        seats: null,
        source_ids: [source.id],
        notes: [],
        variant_review_date: "2026-10-14",
        drive: "RWD",
        vehicle_class: "passenger",
      },
    ],
    criteria: [
      {
        key: "fixture",
        label: "Fixture",
        group: "Fixture",
        definition: "Fixture",
      },
    ],
    trim_equipment: [{ variant_id: car.id, source_ids: [] }],
    feature_evidence: [
      {
        variant_id: car.id,
        model_id: car.modelId,
        criterion: "fixture",
        value: "Needs confirmation",
        status: "not_verified",
        conditions: "Unknown",
        source_ids: [],
        evidence_scope: "Fixture",
        last_evidence_date: "2026-10-14",
        reviewed_date: "2026-10-14",
        verification_state: "unverified",
      },
    ],
    update_eligibility: [
      {
        variant_id: car.id,
        model_id: car.modelId,
        documented_family_minimum: null,
        exact_total_known: false,
        exact_total: null,
        scope: "Unknown",
        meaning: "Research pending",
        source_ids: [],
        observation_window_start: "2026-10-14",
        observation_window_end: "2026-10-14",
      },
    ],
    update_events: [],
    configuration_history: [],
    sources: [source],
    publication_issues: [],
    prior_update_summary: [],
  };
  const packet: BrandUpdatePacket = {
    schemaVersion: 1,
    id: "m1-fixture-2026-10-14",
    brand: car.brand,
    reviewedAt: "2026-10-14",
    reviewedBy: "Fixture review",
    sources: [source],
    models: [],
    variants: [],
    versionGuards: [{ variantId: car.id, before: brandVersionSnapshot(car) }],
    versionUpdates: [],
    facts: [],
    availability: [],
    summaries: [],
  };
  const grade = (input: Fact, owner = packet): Fact => ({
    ...structuredClone(input),
    buyerGrade: "confirmed",
    gradeReview: {
      reviewedAt: owner.reviewedAt,
      overlayId: owner.id,
      reason: "Exact Australian version confirmed by maker fixture",
      evidenceScope: "exact_au_version",
      sourceIds: [...input.sourceIds],
    },
  });
  return { car, source, fact, research, packet, grade };
}

test("dated fact updates target the reviewed version and preserve original sources, dates and cars", () => {
  const { car, source, fact, research, packet, grade } = fixture();
  packet.facts = [
    { variantId: car.id, before: fact, after: grade({ ...fact, value: 470 }) },
  ];
  const before = structuredClone({ car, source, research, packet });
  const sibling = { ...car, id: "unrelated", trim: "Other" };
  const updated = prepareBrandResearch(research, [packet]);
  const cars = applyBrandUpdates([car, sibling], updated, [packet]);
  assert.equal(cars[0].facts.range_km.value, 470);
  assert.equal(cars[0].facts.range_km.buyerGrade, "confirmed");
  assert.equal(cars[0].facts.range_km.gradeReview?.overlayId, packet.id);
  assert.equal(cars[1], sibling);
  assert.deepEqual({ car, source, research, packet }, before);
  assert.equal(updated.sources.filter((row) => row.id === source.id).length, 1);
  assert.equal(cars[0].facts.seats.date, car.facts.seats.date);
});

test("wrong identity, tier, source drift and changed fact snapshots fail closed", () => {
  const { car, fact, source, research, packet, grade } = fixture();
  packet.facts = [
    { variantId: car.id, before: fact, after: grade({ ...fact, value: 470 }) },
  ];
  for (const changed of [
    { ...car, trim: "AWD" },
    { ...car, brand: "Other" },
    { ...car, vehicleClass: "van" as const },
  ])
    assert.throws(
      () => applyBrandUpdates([changed], research, [packet]),
      /version|tier|brand/,
    );
  const changedFact = {
    ...car,
    facts: { ...car.facts, range_km: { ...fact, qualifications: ["Changed"] } },
  };
  assert.throws(
    () => applyBrandUpdates([changedFact], research, [packet]),
    /before snapshot changed/,
  );
  assert.throws(
    () =>
      prepareBrandResearch(
        {
          ...research,
          sources: [{ ...source, supports: "Different version" }],
        },
        [packet],
      ),
    /source snapshot changed/,
  );
  const missing = structuredClone(packet);
  missing.sources = [];
  assert.throws(
    () => applyBrandUpdates([car], research, [missing]),
    /explicit source snapshot/,
  );
});

test("new versions have complete unknown rows and no fabricated update counts", () => {
  const { car, research, packet, grade, fact, source } = fixture();
  packet.versionGuards = [];
  packet.sources.push({
    ...source,
    id: "fixture-new-source",
    url: "https://maker.example/au/new-version",
  });
  const variant = {
    ...research.variants[0],
    id: "fixture_maker_example__new__1",
    trim: "New",
  };
  packet.variants.push(variant);
  packet.facts.push({
    variantId: variant.id,
    before: null,
    after: grade({ ...fact, value: 490 }),
  });
  const updated = prepareBrandResearch(research, [packet]);
  const cars = applyBrandUpdates([car], updated, [packet]);
  const added = cars.find((candidate) => candidate.id === variant.id)!;
  assert.equal(added.facts.range_km.value, 490);
  assert.equal(added.facts.seats.value, null);
  assert.equal(added.facts.seats.buyerGrade, undefined);
  assert.deepEqual(added.facts.seats.sourceIds, []);
  assert.equal(
    updated.feature_evidence.find((row) => row.variant_id === variant.id)
      ?.status,
    "not_verified",
  );
  assert.equal(
    updated.update_eligibility.find((row) => row.variant_id === variant.id)
      ?.exact_total,
    null,
  );
  assert.equal(
    updated.update_eligibility.find((row) => row.variant_id === variant.id)
      ?.documented_family_minimum,
    null,
  );
  assert.equal(
    updated.sources.filter((row) => row.id === "fixture-new-source").length,
    1,
  );
  assert.deepEqual(validateResearch(updated), []);
  assert.equal(research.variants.length, 1);
  assert.throws(
    () => prepareBrandResearch(updated, [packet]),
    /duplicate new version/,
  );
});

test("new versions do not acquire unrelated catalogue equipment fields or source-derived labels", () => {
  const { car, research, packet, grade, fact } = fixture();
  for (let i = 0; i < 500; i++) {
    const key = `equipment_unrelated_${i}`;
    car.facts[key] = {
      ...fact,
      key,
      label: "Other model equipment",
      value: true,
    };
  }
  const variant = {
    ...research.variants[0],
    id: "fixture_maker_example__bounded__1",
    trim: "Bounded",
  };
  packet.variants = [variant];
  packet.versionGuards = [];
  packet.facts = [
    {
      variantId: variant.id,
      before: null,
      after: grade({ ...fact, key: "equipment_reviewed", value: true }),
    },
  ];
  const original = JSON.stringify({ car, research, packet });
  const updated = prepareBrandResearch(research, [packet]);
  const added = applyBrandUpdates([car], updated, [packet]).find(
    (candidate) => candidate.id === variant.id,
  )!;
  assert.equal(added.facts.equipment_reviewed.value, true);
  assert.equal(added.facts.equipment_unrelated_0, undefined);
  assert.equal(added.facts.equipment_unrelated_499, undefined);
  assert.ok(Object.keys(added.facts).length < 40);
  for (const key of [
    "price_aud",
    "range_km",
    "seats",
    "power_kw",
    "drive",
    "battery_warranty",
  ]) {
    assert.equal(added.facts[key].value, null, key);
    assert.equal(added.facts[key].buyerGrade, undefined, key);
    assert.deepEqual(added.facts[key].sourceIds, [], key);
  }
  assert.deepEqual(applyBrandUpdates([], updated, [packet])[0], added);
  assert.equal(JSON.stringify({ car, research, packet }), original);
});

test("new grades require genuine search evidence and price ladder provenance", () => {
  const { car, research, packet, fact, grade, source } = fixture();
  packet.facts = [
    {
      variantId: car.id,
      before: fact,
      after: {
        ...grade(fact),
        value: null,
        status: "not_verified",
        buyerGrade: "not_published",
        gradeReview: {
          ...grade(fact).gradeReview!,
          evidenceScope: "searched_not_found",
        },
      },
    },
  ];
  assert.throws(
    () => applyBrandUpdates([car], research, [packet]),
    /unearned grade/,
  );
  const second = {
    ...source,
    id: "second-search",
    url: "https://maker.example/au/brochure",
  };
  packet.sources.push(second);
  packet.facts[0].after.sourceIds.push(second.id);
  packet.facts[0].after.gradeReview!.sourceIds.push(second.id);
  assert.equal(
    applyBrandUpdates([car], prepareBrandResearch(research, [packet]), [
      packet,
    ])[0].facts.range_km.buyerGrade,
    "not_published",
  );
  packet.facts = [
    {
      variantId: car.id,
      before: null,
      after: grade({ ...fact, key: "price_aud", value: 42000, unit: "AUD" }),
    },
  ];
  assert.throws(
    () =>
      applyBrandUpdates([car], prepareBrandResearch(research, [packet]), [
        packet,
      ]),
    /price lacks ladder/,
  );
});

test("availability and current metadata changes use reviewed guards", () => {
  const { car, research, packet } = fixture();
  packet.versionUpdates = [
    {
      variantId: car.id,
      before: brandVersionSnapshot(car),
      after: { ...brandVersionSnapshot(car), year: 2027 },
      reason: "Maker identifies current model year",
    },
  ];
  packet.availability = [
    {
      id: "fixture-orders-open",
      variantId: car.id,
      before: availabilitySnapshot(car),
      after: {
        availability: "current_or_order_listed",
        evidence: {
          ...car.availabilityEvidence!,
          orderStatus: "accepting_orders_advertised",
          qualifications: ["Delivery and physical stock need confirmation."],
        },
      },
      status: "approved",
      reviewedAt: packet.reviewedAt,
      reviewedBy: packet.reviewedBy,
      evidenceDate: packet.reviewedAt,
      reason: "Exact version maker order listing",
    },
  ];
  const updated = prepareBrandResearch(research, [packet]);
  const result = applyBrandUpdates([car], updated, [packet])[0];
  assert.equal(result.year, 2027);
  assert.equal(updated.variants[0].model_year, 2027);
  assert.equal(
    result.availabilityEvidence?.orderStatus,
    "accepting_orders_advertised",
  );
  assert.equal(result.availabilityEvidence?.physicalStockVerified, undefined);
  packet.availability[0].before.evidence.stockStatus = "new_stock_listed";
  assert.throws(
    () => applyBrandUpdates([car], updated, [packet]),
    /snapshot changed/,
  );
});

test("summary freshness and correction invalidation use actual fact dependencies", () => {
  const { car, research, packet, grade, fact } = fixture();
  const range = grade(fact);
  const seats = grade(car.facts.seats);
  packet.facts = [
    { variantId: car.id, before: fact, after: range },
    { variantId: car.id, before: car.facts.seats, after: seats },
  ];
  packet.summaries = [
    {
      variantId: car.id,
      strength: {
        label: "Range",
        text: "Published range suits longer trips",
        dependencies: [{ key: "range_km", expected: range }],
      },
      tradeoff: {
        label: "Five seats",
        text: "No third row in this version",
        dependencies: [{ key: "seats", expected: seats }],
      },
    },
  ];
  const updated = prepareBrandResearch(research, [packet]);
  const first = applyBrandUpdates([car], updated, [packet])[0];
  const later = currentBuyerSummary(first.buyerSummary, updated.sources, {
    asOf: "2027-05-01",
  });
  assert.equal(later?.strength, undefined);
  assert.equal(later?.tradeoff?.label, "Five seats");
  assert.deepEqual(
    new Set(first.buyerSummary?.strength?.freshness?.map((row) => row.key)),
    new Set(["range_km"]),
  );
  const correction: BrandUpdatePacket = {
    ...structuredClone(packet),
    id: "m1-fixture-correction-2026-10-15",
    reviewedAt: "2026-10-15",
    summaries: [],
    facts: [],
    versionGuards: [{ variantId: car.id, before: brandVersionSnapshot(first) }],
  };
  correction.facts = [
    {
      variantId: car.id,
      before: first.facts.range_km,
      after: grade({ ...range, value: 460 }, correction),
    },
  ];
  const corrected = applyBrandUpdates(
    [car],
    prepareBrandResearch(research, [packet, correction]),
    [packet, correction],
  )[0];
  assert.equal(corrected.facts.range_km.value, 460);
  assert.equal(corrected.facts.range_km.gradeReview?.overlayId, correction.id);
  assert.equal(corrected.buyerSummary?.strength, undefined);
  assert.equal(corrected.buyerSummary?.tradeoff?.label, "Five seats");
  packet.summaries[0].strength.dependencies[0].expected = {
    ...range,
    value: 999,
  };
  assert.throws(
    () => applyBrandUpdates([car], updated, [packet]),
    /summary dependency changed/,
  );
});

test("public research, catalogue, packs and exact-version route enumeration share added IDs", () => {
  const { research: fixtureResearch, packet, source, fact, grade } = fixture();
  packet.models = fixtureResearch.models;
  packet.variants = fixtureResearch.variants;
  packet.versionGuards = [];
  packet.facts = [
    { variantId: packet.variants[0].id, before: null, after: grade(fact) },
  ];
  const loaded = compiledSource("src/lib/data.ts", {
    "./brand-update-registry": { brandUpdatePackets: [packet] },
  }) as {
    research(): Research;
    sourceResearch(): Research;
    catalogue(): Car[];
    sourceCatalogue(): Car[];
    pack(id: string, snapshot: { data: Research; cars: Car[] }): Pack;
  };
  const original = loaded.sourceResearch();
  const originalSource = JSON.stringify(original.sources);
  const data = loaded.research();
  const cars = loaded.catalogue();
  const id = packet.variants[0].id;
  assert(data.variants.some((variant) => variant.id === id));
  assert(!loaded.sourceCatalogue().some((car) => car.id === id));
  assert.equal(JSON.stringify(loaded.sourceResearch().sources), originalSource);
  assert.equal(data.sources.filter((row) => row.id === source.id).length, 1);
  const pack = loaded.pack(id, { data, cars });
  assert.equal(pack.car.facts.range_km.value, fact.value);
  assert.equal(pack.features.length, data.criteria.length);
  assert(
    pack.features.every(
      (row) => row.variant_id === id && row.status === "not_verified",
    ),
  );
  assert.equal(pack.eligibility.exact_total, null);
  assert(pack.sources.some((row) => row.id === source.id));
  assert.deepEqual(validateResearch(data), []);
  const routes = cars.map((car) => ({ family: car.family, variant: car.slug }));
  assert(
    routes.some(
      (route) =>
        route.family === pack.car.family && route.variant === pack.car.slug,
    ),
  );
  assert.equal(JSON.parse(JSON.stringify(pack)).car.id, id);
  const restored = hydratePortablePacks(
    storePortablePacks({ [id]: pack }),
    data.sources,
  )[id];
  assert.deepEqual(restored, pack);
  const exported = factClaim(restored, restored.car.facts.range_km);
  assert.equal(exported.buyerGrade, "confirmed");
  assert.equal(exported.gradeReview?.overlayId, packet.id);
  assert(exported.sources.some((citation) => citation.id === source.id));
});

test("brand terms are stored once, inherited only within reviewed scope, and project roadside into equipment", () => {
  const { car, research, packet, grade, fact } = fixture();
  const sibling = {
    ...structuredClone(car),
    id: "fixture_sibling",
    trim: "Other",
  };
  const exception = {
    ...structuredClone(car),
    id: "fixture_legacy",
    trim: "Legacy",
  };
  const roadside = grade({
    ...fact,
    key: "roadside_assistance",
    label: "Roadside assistance",
    value: "Five years",
    unit: "",
    basis: "Australian brand terms",
    comparisonBasis: "",
    scope: "Maker current Australian vehicles",
  });
  roadside.gradeReview!.evidenceScope = "brand_au_terms";
  packet.versionGuards.push({
    variantId: sibling.id,
    before: brandVersionSnapshot(sibling),
  });
  packet.brandTerms = [
    {
      key: "roadside_assistance",
      fact: roadside,
      applicableVariantIds: [car.id, sibling.id],
      before: { [car.id]: null, [sibling.id]: null },
      exceptions: [
        {
          variantId: exception.id,
          reason: "Prior policy applies to this older version",
        },
      ],
    },
  ];
  const result = applyBrandUpdates([car, sibling, exception], research, [
    packet,
  ]);
  assert.equal(result[0].facts.roadside_assistance.value, "Five years");
  assert.equal(result[1].facts.roadside_assistance.value, "Five years");
  assert.equal(result[2].facts.roadside_assistance, undefined);
  assert.equal(packet.facts.length, 0);
  const feature = {
    ...research.feature_evidence[0],
    criterion: "roadside_assistance",
  };
  const features = applyBrandTermFeatures(result[0], [feature]);
  assert.equal(features[0].value, "Five years");
  assert.equal(features[0].buyerGrade, "confirmed");
  assert.deepEqual(features[0].source_ids, roadside.sourceIds);
  assert.equal(feature.status, "not_verified");
  result[0].facts.roadside_assistance.value = "Local mutation";
  assert.equal(result[1].facts.roadside_assistance.value, "Five years");
  assert.equal(packet.brandTerms[0].fact.value, "Five years");
  packet.brandTerms[0].exceptions = [];
  assert.throws(
    () => applyBrandUpdates([car, sibling, exception], research, [packet]),
    /account for every current version/,
  );
});

function reviewedDriveawayFixture(state?: string) {
  const data = fixture();
  const price: Fact = {
    ...data.grade(data.fact),
    key: "price_aud",
    label: "Published price",
    value: 39990,
    unit: "AUD",
    basis: state
      ? "Maker state driveaway offer"
      : "Maker national driveaway offer",
    comparisonBasis: "Driveaway",
    status: "conditional",
    buyerGrade: "check",
    qualifications: ["Private retail buyers; metallic paint excluded."],
    conditionExplanation:
      "Order by the stated deadline; subject to allocation.",
    validUntil: "2026-12-15",
    priceEvidence: {
      rung: state ? 4 : 2,
      basisTag: state
        ? `Maker's ${state} driveaway`
        : "Maker's national driveaway",
      sourceKey: "fixture_driveaway_offer",
      sourcePointer: data.source.url,
      ...(state ? { state } : {}),
      originalBasis: "Maker's explicitly published driveaway offer",
      rankingEligible: true,
    },
  };
  data.car.facts.price_aud = price;
  const feature: Feature = {
    ...data.research.feature_evidence[0],
    criterion: "driveaway_price",
    value: "Request an older quote",
    conditions: "Superseded quotation conditions.",
    gradeReviewStatus: "review_required",
    usability_notes: ["Superseded quote note."],
    confirmation_needed: "Superseded quote request.",
  };
  return { ...data, price, feature };
}

test("reviewed national and state driveaway facts project value, provenance and conditions into feature claims", () => {
  for (const state of [undefined, "NSW"]) {
    const { car, source, price, feature, research } =
      reviewedDriveawayFixture(state);
    const unrelated: Feature = { ...feature, criterion: "unrelated_fixture" };
    const before = structuredClone({ car, source, feature, unrelated });
    const features = applyBrandTermFeatures(car, [feature, unrelated]);
    const projected = features[0];
    assert.equal(projected.value, "A$39,990");
    assert.equal(projected.status, price.status);
    assert.equal(projected.buyerGrade, price.buyerGrade);
    assert.deepEqual(projected.gradeReview, price.gradeReview);
    assert.equal(Object.hasOwn(projected, "gradeReviewStatus"), false);
    assert.deepEqual(projected.source_ids, price.sourceIds);
    assert.equal(projected.last_evidence_date, price.date);
    assert.equal(projected.reviewed_date, price.gradeReview!.reviewedAt);
    assert.equal(projected.evidence_scope, price.scope);
    assert.match(
      projected.conditions,
      /Private retail buyers; metallic paint excluded/,
    );
    assert.match(
      projected.conditions,
      /Order by the stated deadline; subject to allocation/,
    );
    assert.match(projected.conditions, /Offer deadline: 2026-12-15/);
    assert.equal(
      projected.conditions.includes("Driveaway price applies in NSW."),
      !!state,
    );
    assert.ok(
      projected.condition_label!.includes(price.priceEvidence!.basisTag),
    );
    assert.deepEqual(projected.usability_notes, []);
    assert.equal(projected.confirmation_needed, "");
    assert.doesNotMatch(projected.conditions, /Superseded/);
    assert.equal(features[1], unrelated);
    const pack: Pack = {
      car,
      features,
      eligibility: research.update_eligibility[0],
      events: [],
      configuration: [],
      sources: [source],
    };
    const claim = featureClaim(pack, "driveaway_price", "Driveaway price")!;
    assert.equal(claim.value, "A$39,990");
    assert.equal(claim.evidenceDate, price.date);
    assert.equal(claim.buyerGrade, "check");
    assert.equal(claim.gradeReviewStatus, undefined);
    assert.deepEqual(claim.gradeReview, price.gradeReview);
    assert.deepEqual(
      claim.sources.map((citation) => citation.id),
      price.sourceIds,
    );
    assert.equal(claim.sources[0].url, source.url);
    assert.equal(claim.sources[0].accessed_date, source.accessed_date);
    assert.ok(claim.basis.includes(price.priceEvidence!.basisTag));
    assert.match(claim.qualifications.join(" "), /Offer deadline: 2026-12-15/);
    assert.equal(
      claim.qualifications
        .join(" ")
        .includes("Driveaway price applies in NSW."),
      !!state,
    );
    assert.doesNotMatch(claim.sentence, /Superseded|review required/i);
    assert.deepEqual({ car, source, feature, unrelated }, before);
    projected.source_ids.push("local-mutation");
    projected.gradeReview!.sourceIds.push("local-mutation");
    assert.deepEqual({ car, source, feature, unrelated }, before);
  }
});

test("before-on-road canonical prices preserve separately sourced driveaway feature evidence", () => {
  const { car, price, feature } = reviewedDriveawayFixture();
  car.facts.price_aud = {
    ...price,
    comparisonBasis: "Before on-road costs",
    basis: "Maker list price before on-road costs",
    status: "standard",
    buyerGrade: "confirmed",
    priceEvidence: {
      ...price.priceEvidence!,
      rung: 1,
      basisTag: "Maker list price",
    },
  };
  const before = structuredClone({ car, feature });
  const projected = applyBrandTermFeatures(car, [feature])[0];
  assert.equal(projected, feature);
  assert.deepEqual({ car, feature }, before);
});

test("withdrawn or incomplete canonical driveaway reviews never replace the separate feature", () => {
  const { car, price, feature } = reviewedDriveawayFixture("NSW");
  const variants: Fact[] = [
    { ...price, gradeReviewStatus: "review_required" },
    { ...price, buyerGrade: undefined },
    { ...price, gradeReview: undefined },
    { ...price, priceEvidence: undefined },
    { ...price, value: null },
  ];
  for (const unreviewed of variants) {
    const candidate = {
      ...car,
      facts: { ...car.facts, price_aud: unreviewed },
    };
    const before = structuredClone({ candidate, feature });
    assert.equal(applyBrandTermFeatures(candidate, [feature])[0], feature);
    assert.deepEqual({ candidate, feature }, before);
  }
});

test("a separately reviewed driveaway offer updates its answer without replacing the higher-rung list price", () => {
  const { car, price, feature } = reviewedDriveawayFixture("NSW");
  car.facts.price_aud = {
    ...price,
    value: 35990,
    comparisonBasis: "Before on-road costs",
    basis: "Maker list price before on-road costs",
  };
  const offer = { ...price, key: "promotional_driveaway_aud" };
  car.facts.promotional_driveaway_aud = offer;
  const original = structuredClone({ car, feature });
  const projected = applyBrandTermFeatures(car, [feature])[0];
  assert.equal(projected.value, "A$39,990");
  assert.equal(car.facts.price_aud.value, 35990);
  assert.match(projected.conditions, /Offer deadline: 2026-12-15/);
  assert.match(projected.conditions, /applies in NSW/);
  assert.deepEqual(projected.source_ids, offer.sourceIds);
  assert.deepEqual(projected.gradeReview, offer.gradeReview);
  assert.deepEqual({ car, feature }, original);
  for (const invalid of [
    { ...offer, gradeReviewStatus: "review_required" as const },
    { ...offer, priceEvidence: undefined },
    { ...offer, comparisonBasis: "Before on-road costs" },
    { ...offer, value: null },
  ]) {
    const candidate = {
      ...car,
      facts: { ...car.facts, promotional_driveaway_aud: invalid },
    };
    assert.equal(applyBrandTermFeatures(candidate, [feature])[0], feature);
  }
});

test("supplemental driveaway offers require the same price provenance as canonical prices", () => {
  const { car, price, packet, research } = reviewedDriveawayFixture();
  const offer = { ...price, key: "promotional_driveaway_aud" };
  packet.facts = [{ variantId: car.id, before: null, after: offer }];
  assert.equal(
    applyBrandUpdates([car], research, [packet])[0].facts
      .promotional_driveaway_aud.value,
    price.value,
  );
  for (const invalid of [
    { ...offer, priceEvidence: undefined },
    {
      ...offer,
      priceEvidence: {
        ...offer.priceEvidence!,
        sourcePointer: "",
      },
    },
    { ...offer, comparisonBasis: "Before on-road costs" },
  ]) {
    assert.throws(
      () =>
        applyBrandUpdates([car], research, [
          {
            ...packet,
            facts: [{ variantId: car.id, before: null, after: invalid }],
          },
        ]),
      /price|driveaway/i,
    );
  }
});

test("a guarded valid replacement clears its stale review marker without weakening identity, fact or source guards", () => {
  const { car, fact, source, research, packet, grade } = fixture();
  const withdrawn: Fact = { ...fact, gradeReviewStatus: "review_required" };
  car.facts.range_km = withdrawn;
  packet.facts = [
    {
      variantId: car.id,
      before: structuredClone(withdrawn),
      after: grade({ ...withdrawn, value: 470 }),
    },
  ];
  const before = structuredClone({ car, source, research, packet });
  const updated = applyBrandUpdates([car], research, [packet])[0];
  assert.equal(updated.facts.range_km.value, 470);
  assert.equal(updated.facts.range_km.buyerGrade, "confirmed");
  assert.equal(updated.facts.range_km.gradeReview!.overlayId, packet.id);
  assert.equal(
    Object.hasOwn(updated.facts.range_km, "gradeReviewStatus"),
    false,
  );
  assert.equal(packet.facts[0].after.gradeReviewStatus, "review_required");
  assert.deepEqual({ car, source, research, packet }, before);
  assert.throws(
    () =>
      applyBrandUpdates([{ ...car, trim: "Different version" }], research, [
        packet,
      ]),
    /reviewed version changed/,
  );
  assert.throws(
    () =>
      applyBrandUpdates(
        [
          {
            ...car,
            facts: { ...car.facts, range_km: { ...withdrawn, value: 451 } },
          },
        ],
        research,
        [packet],
      ),
    /fact before snapshot changed/,
  );
  assert.throws(
    () =>
      applyBrandUpdates(
        [car],
        {
          ...research,
          sources: [{ ...source, supports: "Different source content" }],
        },
        [packet],
      ),
    /source snapshot changed/,
  );
  const invalid = structuredClone(packet);
  invalid.facts[0].after.gradeReview!.reason = "";
  assert.throws(
    () => applyBrandUpdates([car], research, [invalid]),
    /invalid fact or unearned grade/,
  );
  assert.equal(invalid.facts[0].after.gradeReviewStatus, "review_required");
  assert.deepEqual({ car, source, research, packet }, before);
});
