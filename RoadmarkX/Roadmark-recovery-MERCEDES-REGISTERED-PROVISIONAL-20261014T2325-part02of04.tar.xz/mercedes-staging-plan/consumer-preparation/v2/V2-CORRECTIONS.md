# Static v2 corrections

V1 remains unchanged and unexecuted. Independent review found three proof-authoring blockers before any command ran.

1. Three criteria counts in negative positive controls were e.newCars9 after an unbounded numeric text replacement matched the prefix of 69. They are now e.criteria. A complete static inventory checked every e.* property against the actual frozen expected schema across all six modules; no other undefined compound property was found
2. No accepted Mercedes price has a comparable positive basis. V2 selects the actual CLA 200 Reported price through manifest.negativeSelectors.priceBasis, retains its blank comparisonBasis and complete original provenance for the positive control, then inserts only Driveaway in an isolated negative copy. The unchanged before-on-road basisTag rejects the contradiction. Only this basisTag branch is newly tested; the originalBasis branch is explicitly historical and price-ladder.ts joins the exact source-equality ancestry pins
3. No accepted summary depends on price. V2 selects EQA battery_kwh through manifest.negativeSelectors.numericSummary and changes that actual numeric Fact only in an isolated negative copy. The exact retained summary dependency must reject it. Receipt text expressly records that no price-specific summary dependency exists

All code/manifest/harness paths and the aggregate's expected command point to v2. One stale diagnostic message now says complete contiguous rows rather than hardcoding 69. Original packet, sources, facts, grades, blank price bases, summaries, canonical capture and baseline files remain untouched.

The six modules were statically re-read and their literal-to-parameter contexts reviewed. parameter-audit-v2.json records the actual text-property inventory and remaining intentional numeric constants. No syntax parser, import, test, compiler, dataset hydration or other prepared-code execution was used.

