# Mercedes consumer static handover v2

Prepared only, unexecuted. Repository and frozen inputs remain untouched. V1 is preserved after three independent static-review findings; v2 corrects the proof assumptions without changing the accepted candidate.

Start with consumer-static-index-v2.json, V2-CORRECTIONS.md, v1-to-v2.patch, consumer-design.md and REVIEWER-HANDOFF.md. adaptation.patch shows the full retained-XPENG-to-v2 changes, and serialization-adapter.patch shows the narrow helper reuse.

First exact standalone phase manifest:
- selected-manifest-frozen-v2.json
- 147,067 bytes
- SHA256 0d2eb03f77b1753494c68e13f9a1ae5657dbb1e4d7bad16cd11d192258ff1b47
- 691 actual unique input pins, all seven v2 harness/design pins, actual accepted canonical invocation and complete output/meta/audit/acceptance lineage

Bounded serial batch:
- bounded-serial-batch-contract-v2.json
- 31,148 bytes
- SHA256 1f2191bd8b554b3a6a87df1771ecf3e108ada97141c59815d97c2b76e5d26b55
- Selected, applicable negatives, eight full contiguous ranges, strict byte aggregate, full unchanged actual report
- 180 seconds per command, Node 448 MiB old/1 MiB semi, common measured runner, NODE_OPTIONS absent, no overlap, no automatic retry, stop on any failure
- Root owns the sole heavy slot; exact reviewer receipts and root's separate batch grant are required

selected-command-template-v2.json fixes the command except for the not-yet-issued phase review reference/hash. Its 2,084 bytes have SHA256 0f8c93afbd5d3eaec9f3670623cb7b06fa6857b3f59ec49310ead929cd251fb4. It cannot run as written. After the real receipt exists, bind that exact review in a new command artifact; no prepared module changes are needed.

The first phase uses the accepted original canonical result and unchanged empty-feature packet. No second core run, recapture or cosmetic packet rewrite is required. Consumer/status protocol remains reviewed-brand-consumers-v1; v2 names the corrected immutable code cut, not a changed protocol.

Later phases use consumer-manifest-template-v2.json as a static authoring starting point, not an executable inheritance system. Each standalone manifest must append every actual referenced receipt/output/review/terminal/log/nested descriptor pin. Future pins remain null; they are never derived from expected counts. Actual Mercedes reconciliation content still needs separate exact review before report.

V2's negative selectors are actual CLA200 price_aud for a clearly isolated contradictory Driveaway insertion, and actual EQA battery_kwh for numeric summary dependency drift. All original price bases stay blank. No accepted summary has a price dependency. Candidate provenance testing claims the basisTag branch only; originalBasis and feature-only fixture coverage remain separate historical proofs, guarded by unchanged implementation pins.

GLC stays unchanged and outside actual public-builder coverage. The selected 187-slot displayed Fact inventory is explicitly non-coverage. Full reports retain City missing strict-window cells and any genuine Unreviewed limitation, while their Reported 35/32-minute values remain visible.

Completion remains pending real selected/negative/range/aggregate/report outputs, independent output acceptance, root registration/fresh normal CLI exact full JSON and byte parity, and the already-open compiler/build/full aggregate/mobile/release/M1 gates.
