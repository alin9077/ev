/** Static, manifest-driven adaptation of the retained XPENG consumer-v1 boundary. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {
  argumentsFor,readJson,fileHash,locate,referenceFor,pin,verifyPins,sourceNames,
  digestRows,expectedDigest,streamRows,readResearch,assertResearchUnchanged,newDirectory,writeNewJson,
} from '/tmp/xpeng-staging-plan/baseline-io.mjs';
import {readCompleteCars} from '/tmp/xpeng-staging-plan/staging-v1/read-complete-storage.mjs';

export function openConsumerInputs(phase) {
  const args=argumentsFor(['--manifest','--manifest-sha256','--review','--review-sha256']);
  assert.equal(fileHash(args['--manifest']),args['--manifest-sha256']);
  assert.equal(fileHash(args['--review']),args['--review-sha256']);
  const manifest=readJson(args['--manifest']),review=readJson(args['--review']),{anchors,expected:e}=manifest;
  assert.equal(manifest.schemaVersion,1);assert.equal(manifest.mode,'reviewed-brand-consumers-v1');
  assert.equal(manifest.status,'frozen_pending_independent_review_and_explicit_root_grant','Blocked templates cannot execute');
  assert.equal(manifest.phase,phase);assert(['selected','negative','features','report'].includes(phase));
  assert.equal(manifest.nodeVersion,process.version);assert.equal(process.cwd(),anchors.repo);assert.equal(typeof global.gc,'function');
  assert.equal(process.env.NODE_OPTIONS,undefined);assert.deepEqual(process.execArgv,manifest.execution.execArgv);
  assert.equal(manifest.execution.timeoutSeconds,180);assert.equal(manifest.execution.requiresSeparateRootHeavySlotGrant,true);assert.equal(manifest.execution.automaticRetry,false);
  assert.equal(e.afterCars,e.beforeCars+e.newCars);assert.equal(e.selectedCars,e.existingCars+e.newCars);assert.equal(e.unselectedCars,e.beforeCars-e.existingCars);
  for(const [rows,cars]of [['beforeFeatureRows','beforeCars'],['afterFeatureRows','afterCars'],['selectedFeatureRows','selectedCars'],['existingFeatureRows','existingCars'],['newFeatureRows','newCars']])assert.equal(e[rows],e[cars]*e.criteria);
  assert.equal(e.authorizedFeatureMutations,0);assert.equal(e.authorizedDriveOnlyVersionUpdates,e.existingCars);
  locate(anchors,referenceFor(anchors,args['--manifest']));locate(anchors,referenceFor(anchors,args['--review']));
  assert.equal(review.status,'approved_for_'+phase+'_brand_consumers_v1');assert.equal(review.phase,phase);
  assert.equal(review.manifestSha256,args['--manifest-sha256']);assert.deepEqual(review.harnessPins,manifest.harnessPins);assert.deepEqual(review.expected,e);
  if(phase==='features'){assert(['range','aggregate'].includes(manifest.featureMode));assert.equal(review.featureMode,manifest.featureMode);}
  assert.equal(review.coreReceiptSha256,manifest.coreReceipt.sha256);
  assert.equal(review.canonicalCaptureAuthorized,false);assert.equal(review.productionRegistrationAuthorized,false);assert.equal(review.separateRootExecutionGrantRequired,true);
  const pins=new Map(manifest.inputPins.map(row=>[locate(anchors,row),row]));assert.equal(pins.size,manifest.inputPins.length);
  function assertPinned(ref){assert(ref&&typeof ref.sha256==='string'&&/^[a-f0-9]{64}$/.test(ref.sha256)&&Number.isSafeInteger(ref.bytes),'Unresolved input pin');const expected=pins.get(locate(anchors,ref));assert(expected,'Missing reviewed input pin');assert.equal(ref.sha256,expected.sha256);assert.equal(ref.bytes,expected.bytes);}
  function read(ref){assertPinned(ref);pin(anchors,ref);return readJson(locate(anchors,ref));}
  function absolutePin(ref){return {path:locate(anchors,ref),sha256:ref.sha256,bytes:ref.bytes};}
  const own=['open-consumer-inputs.mjs','feature-json-parity.mjs','stage-selected-consumers-brand.mjs','stage-negative-guards-brand.mjs','stage-full-feature-stream-brand.mjs','stage-complete-report-brand.mjs','consumer-design.md'];
  for(const ref of manifest.harnessPins)assertPinned(ref);
  for(const file of own)assert(manifest.harnessPins.some(row=>row.anchor==='consumerPreparation'&&row.file==='v2/'+file),'Missing reviewed consumer harness file');
  for(const ref of Object.values(manifest.dependencies))assertPinned(ref);
  assert.equal(locate(anchors,manifest.dependencies.io),'/tmp/xpeng-staging-plan/baseline-io.mjs');
  assert.equal(locate(anchors,manifest.dependencies.storageReader),'/tmp/xpeng-staging-plan/staging-v1/read-complete-storage.mjs');
  assert.equal(locate(anchors,manifest.measuredWrapper),'/tmp/mercedes-staging-plan/measured-command.py');assertPinned(manifest.measuredWrapper);
  const coreManifest=read(manifest.coreManifest),coreReview=read(manifest.coreReview),receipt=read(manifest.coreReceipt);
  assert.equal(coreManifest.mode,'reviewed-brand-staging-v1');assert.equal(coreManifest.phase,'canonical');
  assert.deepEqual(anchors,{...coreManifest.anchors,consumerPreparation:'/tmp/mercedes-staging-plan/consumer-preparation'});
  assert.deepEqual(e,coreManifest.expected);assert.equal(coreManifest.brand,manifest.brand);assert.equal(coreManifest.asOf,manifest.asOf);assert.equal(coreManifest.packetId,manifest.packetId);
  assert.deepEqual(manifest.existingIds,coreManifest.existingIds);assert.deepEqual(manifest.newIds,coreManifest.newIds);
  assert.equal(coreReview.status,'approved_for_canonical_brand_staging_v1');assert.equal(coreReview.manifestSha256,manifest.coreManifest.sha256);
  assert.deepEqual(coreReview.harnessPins,coreManifest.harnessPins);assert.equal(coreReview.evidenceReviewed,true);assert.equal(coreReview.compositionReviewed,true);assert.equal(coreReview.canonicalCaptureAuthorized,true);
  for(const row of coreManifest.inputPins)assertPinned(row);
  assert.equal(receipt.status,'captured_once_pending_independent_review');assert.equal(receipt.phase,'canonical');
  assert.equal(receipt.inputManifestSha256,manifest.coreManifest.sha256);assert.equal(receipt.independentReviewSha256,manifest.coreReview.sha256);
  assert.equal(receipt.beforeCars,e.beforeCars);assert.equal(receipt.afterCars,e.afterCars);assert.equal(receipt.selectedCarsCount,e.selectedCars);assert.equal(receipt.newCars,e.newCars);assert.equal(receipt.unselectedCars,e.unselectedCars);
  for(const key of ['allInputCarsAnd14ResearchFieldsUnchanged','allUnselectedCarsUnchanged','rawSinglePacketOutputPreserved'])assert.equal(receipt[key],true);
  assert.equal(receipt.canonicalCompared,false,'The original canonical invocation is reused, not relabelled as a second final-core run');
  assert.equal(receipt.onlyCompositionPath,'metadata.brand_update_packet_ids');assert.equal(receipt.registered,false);assert.equal(receipt.freshFullValueLoaderExport,false);
  assert.equal(receipt.packetSha256,coreManifest.packet.sha256);
  const packet=read(coreManifest.packet),packetDigest=digestRows([packet]),normalized=read(coreManifest.normalizedEvidence);
  assert.equal(packet.id,manifest.packetId);assert.equal(packet.brand,manifest.brand);assert.equal(packet.facts.length,e.facts);assert.equal((packet.brandTerms??[]).length,0);assert.equal(packet.features.length,e.authorizedFeatureMutations);assert.equal(packet.variants.length,e.newCars);assert.equal(packet.sources.length,e.directSources);
  assert.deepEqual(packet.variants.map(row=>row.id),coreManifest.newIds);assert.deepEqual(normalized.currentVersionReviews,[]);
  assert.deepEqual(coreManifest.packet,coreManifest.featureFreePacket,'The original empty-feature packet is final, unchanged');
  assert.equal(packet.versionUpdates.length,e.authorizedDriveOnlyVersionUpdates);assert.deepEqual(packet.versionUpdates.map(row=>row.variantId),coreManifest.existingIds);
  const canonicalMeta=read(manifest.canonicalMeta),canonicalAcceptance=read(manifest.canonicalAcceptance),canonicalJsonAudit=read(manifest.canonicalJsonAudit),beforeFeatureParityAudit=read(coreManifest.beforeFeatureParityAudit);
  assert.equal(canonicalAcceptance.status,'accepted_original_brand_canonical_baseline');assert.equal(canonicalAcceptance.canonicalMetaSha256,manifest.canonicalMeta.sha256);assert.equal(canonicalAcceptance.captureGenerationCount,1);
  for(const key of ['exactOriginalPacketAndSelectedCarsVerified','all14RawAndComposedFieldsVerified','allOriginalNewFeatureRowsVerified'])assert.equal(canonicalAcceptance[key],true);
  assert.equal(canonicalAcceptance.serializationAuditSha256,manifest.canonicalJsonAudit.sha256);assert.equal(canonicalAcceptance.newFeatureRows,e.newFeatureRows);
  assert.deepEqual(canonicalAcceptance.coreReceipt,absolutePin(manifest.coreReceipt));assert.deepEqual(canonicalAcceptance.manifest,absolutePin(manifest.coreManifest));assert.deepEqual(canonicalAcceptance.phaseReview,absolutePin(manifest.coreReview));
  assert.equal(canonicalMeta.inputManifestSha256,manifest.coreManifest.sha256);assert.equal(canonicalMeta.independentReviewSha256,manifest.coreReview.sha256);
  for(const key of ['captureGenerationCount','generationCount','baselineGenerationCount'])assert.equal(canonicalMeta[key],1);
  assert.deepEqual(canonicalMeta.featureFreePacket,manifest.canonicalPacket);assert.deepEqual(canonicalMeta.selectedCars,manifest.canonicalSelectedCars);assert.deepEqual(canonicalMeta.newFeatures,manifest.canonicalNewFeatures);assert.deepEqual(canonicalMeta.serializationAudit,manifest.canonicalJsonAudit);
  assert.deepEqual(canonicalMeta.storageIndex,receipt.storageIndex);assert.deepEqual(canonicalMeta.rawResearchIndex,receipt.rawResearchIndex);assert.deepEqual(canonicalMeta.selectedCars,receipt.selectedCars);assert.deepEqual(receipt.canonicalMeta,manifest.canonicalMeta);
  assert.deepEqual(canonicalAcceptance.storageIndex,absolutePin(receipt.storageIndex));assert.deepEqual(canonicalAcceptance.rawResearchIndex,absolutePin(receipt.rawResearchIndex));assert.deepEqual(canonicalAcceptance.selectedCars,absolutePin(receipt.selectedCars));
  assert.deepEqual(packet,read(manifest.canonicalPacket));assert.deepEqual(packetDigest,canonicalMeta.featureFreePacketDigest);
  assert.deepEqual(canonicalJsonAudit.policy,coreManifest.canonicalJsonParity);assert.equal(canonicalJsonAudit.fullParsedOriginalOutputCompared,true);assert.equal(canonicalJsonAudit.liveRowsUnchanged,true);
  assert.deepEqual(canonicalJsonAudit.existingSevenOmissionAuditUnchanged,coreManifest.beforeFeatureParityAudit);
  const index=read(receipt.storageIndex),rawIndex=read(receipt.rawResearchIndex),transition=read(receipt.transition),selected=read(receipt.selectedCars),before=read(coreManifest.selectedBeforeCars);
  assert.equal(index.packetSha256,coreManifest.packet.sha256);assert.equal(index.inputManifestSha256,manifest.coreManifest.sha256);
  assert.equal(index.cars.rows,e.afterCars);assert.equal(index.cars.baseline.rows,e.beforeCars);assert.equal(index.cars.replacements.rows,e.selectedCars);assert.deepEqual(index.cars.newIds,coreManifest.newIds);
  assert.equal(index.cars.baseline.format,'storage-index');assert.equal(index.cars.replacements.format,'json');
  assert.equal(index.cars.baseline.sha256,coreManifest.baselineStorageIndex.sha256);assert.equal(index.cars.replacements.sha256,receipt.selectedCars.sha256);
  assert.equal(index.cars.carHashes.length,e.afterCars);assert.equal(new Set(index.cars.carHashes.map(row=>row.id)).size,e.afterCars);
  assert.deepEqual(selected.map(car=>car.id),[...coreManifest.existingIds,...coreManifest.newIds]);assert.equal(selected.length,e.selectedCars);assert.equal(before.length,e.existingCars);
  assert.deepEqual(before.map(car=>car.id),coreManifest.existingIds);assert.deepEqual(selected,read(manifest.canonicalSelectedCars));assert.deepEqual(digestRows(selected),canonicalMeta.selectedCarsDigest);
  const registeredPackets=coreManifest.registeredPackets.map(row=>{const value=read(row.input);assert.equal(value.id,row.id);return value;});assert.equal(registeredPackets.length,e.registeredPackets);
  for(const [current,expected]of [[index,canonicalMeta.composedFieldDigests],[rawIndex,canonicalMeta.rawFieldDigests]]){
    assert.deepEqual(Object.keys(current.research),coreManifest.researchFields);assert.equal(Object.keys(current.research).length,14);
    for(const [key,ref]of Object.entries(current.research)){assertPinned(ref);assert.deepEqual(expectedDigest(ref),expected[key],'Every raw/composed canonical field digest');}
  }
  assert.equal(transition.onlyChangedPath,'metadata.brand_update_packet_ids');assert.deepEqual(transition.rawMetadata,canonicalMeta.rawMetadata);assert.deepEqual(transition.composedMetadata,canonicalMeta.composedMetadata);
  assert.deepEqual(transition.rawMetadata.brand_update_packet_ids,[packet.id]);assert.deepEqual(transition.composedMetadata.brand_update_packet_ids,[...registeredPackets.map(row=>row.id),packet.id]);
  const beforeFeatures=[...read(coreManifest.existingBeforeFeatures),...read(manifest.canonicalNewFeatures)];
  assert.equal(beforeFeatures.length,e.selectedFeatureRows);assert.equal(new Set(beforeFeatures.map(row=>row.variant_id+'\0'+row.criterion)).size,e.selectedFeatureRows);
  const extraction=read(coreManifest.baselineExtractionReceipt),baselineAcceptance=read(coreManifest.baselineAcceptance);
  assert.equal(extraction.status,'passed_read_only_reviewed_derived_baseline_extraction');assert.equal(extraction.manifestSha256,coreManifest.baselineManifest.sha256);assert.equal(extraction.completeCarsVerified,e.beforeCars);assert.equal(extraction.completeFeatureRowsVerified,e.beforeFeatureRows);assert.equal(extraction.actualFeatureRows,e.existingFeatureRows);assert.equal(extraction.defaultLoaderCalls,0);
  assert.deepEqual(extraction.selectedIds,coreManifest.existingIds);assert.deepEqual(extraction.featureParityPolicy,coreManifest.existingFeatureParity);
  assert.equal(baselineAcceptance.status,'accepted_exact_read_only_derived_baseline_extraction');assert.deepEqual(baselineAcceptance.extractionReceipt,absolutePin(coreManifest.baselineExtractionReceipt));
  for(const [name,ref]of [['selected-complete-before-cars.json',coreManifest.selectedBeforeCars],['actual-before-features.json',coreManifest.existingBeforeFeatures],['before-feature-json-parity-audit.json',coreManifest.beforeFeatureParityAudit]]){assert.deepEqual(extraction.artifacts[name],absolutePin(ref));assert.deepEqual(baselineAcceptance.artifacts[name],absolutePin(ref));}
  const baselineManifest=read(coreManifest.baselineManifest),baselineFeatureIndex=read(coreManifest.baselineFeatureIndex);
  assert.deepEqual(baselineManifest.accepted.featureIndex,coreManifest.baselineFeatureIndex);
  assert.equal(baselineFeatureIndex.cars,e.beforeCars);assert.equal(baselineFeatureIndex.features.rows,e.beforeFeatureRows);assert.equal(baselineFeatureIndex.perCar.length,e.beforeCars);assert.equal(new Set(baselineFeatureIndex.perCar.map(row=>row.id)).size,e.beforeCars);
  assert.deepEqual(baselineFeatureIndex.perCar.map(row=>row.id),index.cars.carHashes.slice(0,e.beforeCars).map(row=>row.id));
  for(const key of ['registeredReportParity','registrationAddendum','completeReport','registeredReport']){assertPinned(baselineManifest.accepted[key]);pin(anchors,baselineManifest.accepted[key]);}
  const sourceInventory=read(coreManifest.currentSourceInventory);for(const row of sourceInventory.files)assertPinned({anchor:'repo',...row});
  const selectedDigests=selected.map(car=>digestRows([car])),beforeDigests=before.map(car=>digestRows([car]));
  function verifySelected(){
    for(const [i,car]of selected.entries()){const row=index.cars.carHashes.find(value=>value.id===car.id);assert(row);assert.equal(car.brand,manifest.brand);assert.equal(digestRows([car]).sha256,row.afterSha256);assert.equal(digestRows([car]).bytes,row.bytes);assert.deepEqual(digestRows([car]),selectedDigests[i]);}
    assert.deepEqual(before.map(car=>digestRows([car])),beforeDigests);assert.deepEqual(digestRows([packet]),packetDigest);
  }
  function verify(){
    assert.equal(fileHash(args['--manifest']),args['--manifest-sha256']);assert.equal(fileHash(args['--review']),args['--review-sha256']);
    verifyPins(anchors,manifest.inputPins);assert.deepEqual(sourceNames(anchors.repo),sourceInventory.files.map(row=>row.file).sort());verifySelected();
  }
  const proof={anchors,manifest,e,manifestSha256:args['--manifest-sha256'],reviewSha256:args['--review-sha256'],coreManifest,receipt,receiptHash:manifest.coreReceipt.sha256,index,rawIndex,packet,normalized,selected,before,beforeFeatures,canonicalJsonAudit,beforeFeatureParityAudit,registeredPackets,baselineManifest,baselineFeatureIndex,assertPinned,read,verify,verifySelected};
  proof.readPhaseReceipt=(ref,status)=>{const value=read(ref);assert.equal(value.status,status);assert.equal(value.packetSha256,coreManifest.packet.sha256);assert.equal(value.coreReceiptSha256,manifest.coreReceipt.sha256);assert.equal(value.coreManifestSha256,manifest.coreManifest.sha256);return value;};
  proof.readData=async()=>{const data=await readResearch(anchors,index,coreManifest.researchFields);assert.equal(data.variants.length,e.afterCars);assert.deepEqual(data.variants.map(row=>row.id),index.cars.carHashes.map(row=>row.id));assert.deepEqual(data.metadata,transition.composedMetadata);assertResearchUnchanged(data,index);return data;};
  proof.verifyData=data=>assertResearchUnchanged(data,index);
  proof.readCars=async()=>{const complete=await readCompleteCars(proof,receipt.storageIndex);assert.equal(complete.cars.length,e.afterCars);return complete.cars;};
  proof.createOutput=()=>{assert.equal(manifest.output.anchor,'consumerPreparation');assert(/^consumer-artifacts\/[a-z0-9][a-z0-9_-]*$/.test(manifest.output.directory));return newDirectory(anchors.consumerPreparation,manifest.output.directory);};
  proof.write=(directory,name,value)=>{const result=writeNewJson(directory,name,value);return {...referenceFor(anchors,result.path),bytes:result.bytes,sha256:result.sha256};};
  proof.receiptBase=()=>({asOf:manifest.asOf,brand:manifest.brand,packetSha256:coreManifest.packet.sha256,coreReceiptSha256:manifest.coreReceipt.sha256,coreManifestSha256:manifest.coreManifest.sha256,phaseManifestSha256:proof.manifestSha256,phaseReviewSha256:proof.reviewSha256,corePhase:'original-accepted-canonical',canonicalAcceptanceSha256:manifest.canonicalAcceptance.sha256,fullInputPins:manifest.inputPins,candidateRegistered:false,freshFullValueLoaderExport:false});
  verify();return proof;
}

/** Same full recursive before/after checks as the retained reader, one effective car at a time. */
export async function visitCompleteCars(proof,visit,indexRef=proof.receipt.storageIndex,active=new Set()){
  proof.assertPinned(indexRef);pin(proof.anchors,indexRef);const file=locate(proof.anchors,indexRef);assert(!active.has(file),'Cyclic storage index');active.add(file);
  try{
    const index=readJson(file),d=index.cars,expected=d.carHashes;
    assert.equal(d.mode,'baseline-with-complete-replacements-and-appended-identities');assert.equal(expected.length,d.rows);assert.equal(new Set(expected.map(row=>row.id)).size,d.rows);assert.equal(new Set(d.newIds).size,d.newIds.length);
    for(const ref of [d.baseline,d.replacements]){proof.assertPinned(ref);pin(proof.anchors,ref);}
    assert.equal(d.replacements.format,'json');const replacements=readJson(locate(proof.anchors,d.replacements));assert.equal(replacements.length,d.replacements.rows);
    const map=new Map(replacements.map(car=>[car.id,car]));assert.equal(map.size,replacements.length);assert.deepEqual(replacements.map(car=>car.id),expected.filter(row=>map.has(row.id)).map(row=>row.id));
    const used=new Set(),seen=new Set();let ordinal=0;
    async function accept(original,isNew=false){
      const row=expected[ordinal];assert(row);assert.equal(original.id,row.id);assert.equal(original.brand,row.brand);assert(!seen.has(row.id));seen.add(row.id);
      if(isNew)assert.equal(row.beforeSha256,null);else assert.equal(digestRows([original]).sha256,row.beforeSha256);
      const car=map.get(original.id)||original;if(map.has(original.id))used.add(original.id);
      const digest=digestRows([car]);assert.equal(digest.sha256,row.afterSha256);assert.equal(digest.bytes,row.bytes);await visit(car,ordinal++);assert.deepEqual(digestRows([car]),digest);
    }
    if(d.baseline.format==='storage-index')await visitCompleteCars(proof,car=>accept(car),d.baseline,active);
    else{assert(!d.baseline.format||d.baseline.format==='jsonl');await streamRows(proof.anchors,d.baseline,car=>accept(car));}
    assert.equal(ordinal,d.baseline.rows);assert.equal(ordinal+d.newIds.length,d.rows);assert.deepEqual(expected.slice(ordinal).map(row=>row.id),d.newIds);
    for(const id of d.newIds){assert(!seen.has(id));assert(map.has(id));await accept(map.get(id),true);}
    assert.equal(ordinal,d.rows);assert.equal(used.size,map.size);assert.equal(seen.size,d.rows);
    for(const ref of [indexRef,d.baseline,d.replacements])pin(proof.anchors,ref);
  }finally{active.delete(file);}
}

export function actualConsumers(proof){
  const require=createRequire(path.join(proof.anchors.repo,'package.json'));
  const {brandUpdatePackets}=require('./src/lib/brand-update-registry.ts');assert.deepEqual(brandUpdatePackets,proof.registeredPackets);assert.equal(brandUpdatePackets.length,proof.e.registeredPackets);assert(!brandUpdatePackets.some(row=>row.id===proof.packet.id||row.brand===proof.manifest.brand));
  const {createEvidenceConsumers}=require('./src/lib/evidence-consumers.ts'),{compiledSource}=require('./tests/helpers/compiled-source.ts');
  let loaderCalls=0;const forbidden=()=>{loaderCalls++;throw new Error('BRAND_CONSUMER_FORBIDDEN_DEFAULT_LOADER');};const defaults={sourceResearch:forbidden,research:forbidden,catalogue:forbidden};
  const registryBinding={brandUpdatePackets:[...brandUpdatePackets,proof.packet]};
  const factory=compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':registryBinding}).createEvidenceConsumers;
  function verify(){assert.equal(loaderCalls,0);assert.deepEqual(brandUpdatePackets,proof.registeredPackets);assert.deepEqual(registryBinding.brandUpdatePackets,[...brandUpdatePackets,proof.packet]);assert(!require.cache[path.join(proof.anchors.repo,'src/lib/data.ts')]);}
  verify();return {require,base:createEvidenceConsumers(defaults),staged:factory(defaults),registryBinding,brandUpdatePackets,verify,loaderCalls:()=>loaderCalls};
}


