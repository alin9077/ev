/** Complete manifest-sized report through the unchanged actual loader/builder; final CLI parity is root-owned. */
import fs from 'node:fs';
import assert from 'node:assert/strict';
import path from 'node:path';
import {createRequire} from 'node:module';
import {digestRows,streamRows,fileHash,referenceFor} from '/tmp/xpeng-staging-plan/baseline-io.mjs';
import {openConsumerInputs} from './open-consumer-inputs.mjs';
const proof=openConsumerInputs('report'),{index,selected,e}=proof,out=proof.createOutput();
const featureReceipt=proof.readPhaseReceipt(proof.manifest.featureReceipt,'passed_complete_brand_features_pending_report_and_review');
for(const key of ['allCompleteCarHashesVerified','all14ResearchFieldsUnchanged','packetAndSelectedCarsUnchanged','allActualPackFeaturesExactlyEqual','allUnselectedCarFeatureSetsExactlyUnchanged','strictCompleteOrderAndUniqueness'])assert.equal(featureReceipt[key],true);
assert.equal(featureReceipt.cars,e.afterCars);assert.equal(featureReceipt.featureRows,e.afterFeatureRows);assert.equal(featureReceipt.defaultLoaderCalls,0);
const negativeReceipt=proof.readPhaseReceipt(proof.manifest.negativeReceipt,'passed_brand_negative_guards_pending_remaining_gates');assert.equal(negativeReceipt.loaderCalls,0);assert.deepEqual(negativeReceipt.unsupportedCategories,[]);
for(const key of ['allCompleteCarsVerified','positiveCoreCompleteEquality','allMutationInputsUnchanged','allOriginalSelectedCarsUnchanged','allOriginalBeforeCarsUnchanged','all14ResearchFieldsUnchanged','allOriginalRegisteredPacketsUnchanged','fullOriginalPacketUnchanged'])assert.equal(negativeReceipt[key],true);
const featureIndex=proof.read(featureReceipt.index);assert.equal(featureIndex.cars,e.afterCars);assert.equal(featureIndex.features.rows,e.afterFeatureRows);assert.equal(featureIndex.packetSha256,proof.coreManifest.packet.sha256);assert.equal(featureIndex.coreReceiptSha256,proof.receiptHash);
assert.deepEqual(featureIndex.perCar.map(row=>row.id),index.cars.carHashes.map(row=>row.id));assert.equal(new Set(featureIndex.perCar.map(row=>row.id)).size,e.afterCars);
const cars=await proof.readCars(),data=await proof.readData(),features=[];proof.assertPinned(featureIndex.features);
await streamRows(proof.anchors,featureIndex.features,(feature,ordinal)=>{
  const carIndex=Math.floor(ordinal/e.criteria);assert(carIndex<e.afterCars);assert.equal(feature.variant_id,cars[carIndex].id,'Strict 69-row contiguous per-car feature order');features.push(feature);
});assert.equal(features.length,e.afterFeatureRows);
const perCar=new Map();for(let i=0;i<e.afterCars;i++){const rows=features.slice(i*e.criteria,(i+1)*e.criteria);assert.equal(new Set(rows.map(row=>row.criterion)).size,e.criteria);perCar.set(cars[i].id,rows);}
const carDigests=cars.map(car=>digestRows([car]));
function verifiedFeatures(car){
  const ordinal=cars.findIndex(row=>row.id===car.id);assert(ordinal>=0);const carProof=index.cars.carHashes[ordinal],featureProof=featureIndex.perCar[ordinal],rows=perCar.get(car.id);assert(rows);
  const cd=digestRows([car]),fd=digestRows(rows);assert.deepEqual(cd,carDigests[ordinal]);assert.equal(cd.sha256,carProof.afterSha256);assert.equal(cd.bytes,carProof.bytes);assert.equal(cd.sha256,featureProof.carSha256);assert.equal(cd.bytes,featureProof.carBytes);assert.equal(fd.sha256,featureProof.featureSha256);assert.equal(fd.bytes,featureProof.featureBytes);assert.equal(fd.rows,featureProof.featureRows);assert.equal(fd.rows,e.criteria);return rows;
}
for(const car of cars)verifiedFeatures(car);global.gc();
const require=createRequire(path.join(proof.anchors.repo,'package.json')),{compiledSource}=require('./tests/helpers/compiled-source.ts');
const {buildCoverageReport,formatCoverageReport,coreFacts,isOnSale}=require('./scripts/reporting/reports.ts');
const {combineM1Reconciliations}=require('./scripts/reporting/m1-reconciliation.ts');let loaderCalls=0;
// The unchanged report loader receives the complete explicit snapshot. Its feature function
// is the already proved full actual stream, verified against every full car/feature digest.
const loader=compiledSource('scripts/reporting/load.ts',{'../../src/lib/data':{catalogueSnapshot:()=>{loaderCalls++;throw new Error('BRAND_REPORT_FORBIDDEN_FRESH_LOADER');},effectiveFeatures:(car,supplied)=>{assert.equal(supplied,data);return verifiedFeatures(car);}}});
const input=loader.loadReportInput({data,cars});assert.equal(input.cars,cars);assert.equal(input.sources,data.sources);assert.deepEqual(input.features,features);
const reconciliation=proof.read(proof.manifest.reconciliation);assert.equal(reconciliation.checkedAt,proof.manifest.asOf);
input.m1Reconciliation=combineM1Reconciliations(input.m1Reconciliation,reconciliation);
const inputDigests=Object.fromEntries(Object.entries(input).map(([key,value])=>[key,digestRows(Array.isArray(value)?value:[value])]));
const report=buildCoverageReport(input,proof.manifest.asOf);assert.equal(report.asOf,proof.manifest.asOf);assert.equal(report.allCatalogueVersions,e.afterCars);
const brand=report.brandProgress.find(row=>row.brand===proof.manifest.brand);assert(brand);
assert.deepEqual(reconciliation.currentVersionReviews,[],'No current-version or whole-market closure invented');
assert.equal(brand.criteria.C1,false);assert.equal(brand.researchCompleted,false);
const checks=proof.manifest.buyerChecks,onSale=selected.filter(isOnSale);
assert(!onSale.some(car=>car.id===checks.glc));assert.equal(brand.onSaleVersions,onSale.length);
const coreDiagnostics=[];
for(const car of selected){
  // Unchanged actual cars only. Provisional GLC stays outside the core denominator.
  const diagnostic=buildCoverageReport({...input,cars:[car],features:verifiedFeatures(car)},proof.manifest.asOf);
  assert.equal(diagnostic.core.length,coreFacts.length);
  for(const cell of diagnostic.core)assert.equal(cell.total,isOnSale(car)?1:0);
  coreDiagnostics.push({id:car.id,actualAvailability:car.availability,actualOnSale:isOnSale(car),unchangedActualCar:true,core:diagnostic.core,gaps:diagnostic.gaps,rankings:diagnostic.rankings});
}
assert.equal(coreDiagnostics.reduce((sum,row)=>sum+row.core.reduce((count,cell)=>count+cell.total,0),0),onSale.length*coreFacts.length);
for(const definition of coreFacts){
  const actual=brand.core.find(row=>row.key===definition.key);assert(actual);
  const diagnostics=coreDiagnostics.filter(row=>row.actualOnSale).map(row=>row.core.find(cell=>cell.key===definition.key));
  assert.equal(actual.total,onSale.length);assert.equal(actual.filled,diagnostics.reduce((sum,row)=>sum+row.filled,0));
  for(const grade of Object.keys(actual.grades))assert.equal(actual.grades[grade],diagnostics.reduce((sum,row)=>sum+row.grades[grade],0));
}
const charging=report.rankings.find(row=>row.key==='dc_charge_time_min');assert(charging);
const cityStrictCore=[];
for(const {id,duration}of checks.city){
  const car=selected.find(row=>row.id===id);assert(car);assert.equal(car.facts.dc_charge_time_min.value,duration);assert.equal(car.facts.dc_charge_time_min.buyerGrade,'reported');
  const diagnostic=coreDiagnostics.find(row=>row.id===id),cell=diagnostic.core.find(row=>row.key==='dc_charge_time_min');
  assert.equal(cell.filled,0,'Unestablished charging window cannot fill strict 10–80 coverage');
  assert(diagnostic.gaps.some(row=>row.carId===id&&row.key==='dc_charge_time_min'));
  assert(report.gaps.some(row=>row.carId===id&&row.key==='dc_charge_time_min'));assert(!charging.rankedIds.includes(id));
  cityStrictCore.push({id,visibleDuration:duration,visibleGrade:car.facts.dc_charge_time_min.buyerGrade,strictCore:cell,reporterLimitation:cell.grades.Unreviewed===1?'The unchanged reporter counts the visible reviewed Reported duration as Unreviewed for the missing strict-window core cell':null});
}
assert.equal(brand.criteria.C2,false,'Two genuine strict-window charging gaps keep the per-field target open');
assert.deepEqual(Object.keys(input),Object.keys(inputDigests));for(const [key,value]of Object.entries(input))assert.deepEqual(digestRows(Array.isArray(value)?value:[value]),inputDigests[key]);
for(const car of cars)verifiedFeatures(car);assert.equal(loaderCalls,0);assert(!require.cache[path.join(proof.anchors.repo,'src/lib/data.ts')]);proof.verifyData(data);proof.verify();
// Preserve the exact original report, never filter, normalize, sort or substitute fields.
const reportFile=proof.write(out,'staged-report.json',report),diagnosticsFile=proof.write(out,'selected-core-diagnostics.json',coreDiagnostics);
const textFile=path.join(out,'staged-report.txt');fs.writeFileSync(textFile,formatCoverageReport(report,true)+'\n',{flag:'wx'});
const reportText={...referenceFor(proof.anchors,textFile),bytes:fs.statSync(textFile).size,sha256:fileHash(textFile)};
proof.write(out,'complete-report-receipt.json',{...proof.receiptBase(),status:'passed_complete_brand_staged_report_pending_independent_review_and_fresh_registered_parity',cars:e.afterCars,selectedCars:e.selectedCars,onSaleSelectedCars:onSale.length,features:e.afterFeatureRows,sources:data.sources.length,all14ResearchFieldsUnchanged:true,allCompleteCarsUnchanged:true,allReportInputFieldsUnchanged:true,completeReportInputFieldDigests:inputDigests,actualReportLoaderUsed:true,actualCoverageBuilderUsed:true,actualFullFeatureStreamUsed:true,reportFile,reportText,diagnosticsFile,onSaleCoreSlotsInspected:onSale.length*coreFacts.length,cityStrictCore,brand,featureReceiptSha256:proof.manifest.featureReceipt.sha256,negativeReceiptSha256:proof.manifest.negativeReceipt.sha256,reconciliation:proof.manifest.reconciliation,acceptedBaselineWholeJsonParity:proof.baselineManifest.accepted.registeredReportParity,fullFreshRegisteredJsonParity:false,filteredOrNormalized:false,defaultLoaderCalls:loaderCalls,openGates:['Independent staged candidate review','Root-authorized production registration','Fresh normal CLI entire unmodified JSON and byte equality to this original staged report','Current TypeScript/build/aggregate/mobile release checks'],resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log('Original complete staged report preserved; fresh registered full-JSON and byte parity remains explicitly unverified');

