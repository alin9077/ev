# Review handoff: static Mercedes consumer preparation

No prepared module has run. Review this exact cut, adaptation.patch and reuse-provenance.json before permitting any invocation. The parent owns the sole measured slot and the stop-on-first-failure serial batch.

## Changed boundaries to examine closely

1. The real accepted canonical invocation is the consumer input. There is no second final-core run and no forged receipt. Check the canonical acceptance pins/flags against the actual produced artifacts and ensure the same original packet is used unchanged
2. All IDs, counts and semantic buyer selectors come from the frozen manifest. Check 405 -> 409, seven + four, 483 + 276, 27,945 -> 28,221, 398 peers, 258 facts, 39 sources, 19 prior packets and fourteen fields
3. The narrow JSON helper reuses the shape-first guard and keeps existing-seven/new-four omission audits separate; no generic JSON normalization is allowed
4. Mercedes equipment is empty. Applicable candidate mutations remain real. Historical fixture coverage remains separately identified and its source implementations must be byte-identical; zero feature updates is not described as a new feature-guard runtime pass
5. The report uses unchanged actual cars. GLC is never temporarily relabelled on sale. The 187 displayed Fact inventory is not strict coverage, and City wrong-window durations can produce genuine missing/Unreviewed core cells
6. Full range aggregation retains all descriptor lists, actual invocation counts, exact commands and non-overlapping measured times; only original raw range bytes are concatenated

## Buyer acceptance checklist

- GLC is announced_provisional, buyer-facing Not confirmed, outside actual on-sale coverage. The exact Coming soon/configurator conflict is present once alongside original availability qualifiers
- Both City campaigns retain undated/©2025/no-identified-vehicle limits, advertised-only availability, and no stock/order promise
- EQA 578 NEDC stays distinct from WLTP. City duration 35/32 is Reported, has no proved window and never fills strict 10–80 coverage. The unchanged reports.ts basis/comparison/window regex must not be fooled by negated prose
- All Reported/Check values remain visible with full citations and qualifications; candidate ranking exclusions stay intact. Prices retain exact amount, rung, tax/on-road basis and conditions
- City price, range, cargo and six dimension alternatives remain visible in the full Fact/claim output. Distinct 2025 launch and CarsGuide 2026/discontinued cohorts are not merged or treated as maker-current guarantees
- Passenger warranty distance is the visible string Unlimited, private-use scoped and unranked. GLB HV is 8 years/160,000 km/<70% SOCE; EQS 10 years/250,000 km/<70% SOHC
- Tourer vehicle is 5 years/250,000 km, HV 8 years/160,000 km, with genuinely unpublished retention. G580 commercial HV exclusion is visible. No stale canonical-null or GLB-battery-unknown text supersedes updated buyer facts
- Every after Fact and summary is full exact packet equality. Old summary qualifiers are not merged. Shared-term projections cannot rewrite car facts
- All seven historical manufacturer_model_code Facts remain unchanged. GLB350 2446442_AU1 is not labelled freshly decoded. All seven roadside Facts remain unchanged and not newly verified
- Seven full original guards prove drive-only metadata changes. The two approved raw derived markers equal the unchanged model/generation. Car/Variant drive agrees with its graded Fact; picker/filter use cannot promote grades
- All 398 unselected complete cars and features match original descriptors, especially cargo eVito Tier 2 and Model Y. All source inventory files, including hero/nine selling points, remain pinned and unchanged
- No new currentVersionReviews or whole-market closure. The exact full report decides actual criteria. No TypeScript/build/full aggregate/mobile/release/M2/publication claim is added

## Required runtime artifacts

Selected packs/features/portable values, original feature replay audit and buyer observations; isolated negative cases with precise applicability plus retained fixture ancestry; eight complete range indices and measured invocation/stdout/stderr/terminal evidence; exact complete aggregate stream with all 409 descriptors; unchanged full JSON/text report and unchanged-actual-car diagnostics. Each output-dependent manifest must include all referenced nested pins, not just top-level receipt hashes.

## Still blocked in this static handoff

Canonical output is independently accepted by /tmp/mercedes-review/canonical-v1-output-acceptance.json, SHA256 8fe894bc269680403b13d72552e77745b7ff37ffbd535a19d0a4696f991e587e (7,896 bytes). Remaining blockers are independent static review; exact per-phase reviews and root batch slot; selected/negative/range/aggregate/report output pins; exact reviewed reconciliation input; later independent candidate acceptance and fresh normal registered CLI whole-JSON/byte parity. Missing items stay null. No execution or compiler/syntax validation has been performed by this worker.

