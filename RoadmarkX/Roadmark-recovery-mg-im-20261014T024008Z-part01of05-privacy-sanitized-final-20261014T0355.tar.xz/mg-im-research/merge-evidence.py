import json,pathlib,copy,re
R=pathlib.Path('/tmp/mg-im-research');D='2026-10-14';before={c['id']:c for c in json.load(open(R/'before.json'))}
x={'reviewedAt':D,'sources':[],'variants':[],'familyNotes':{}}
for name,path in [('cyberster','cyberster-evidence.json'),('mg4','mg4/normalized-evidence.json'),('mgs','mgs/normalized-evidence.json'),('im','im/normalized-evidence.json')]:
 e=json.load(open(R/path));x['sources']+=e['sources'];x['familyNotes'][name]={k:v for k,v in e.items() if k not in ['sources','variants']}
 for r in e['variants']:
  r['brand']=before.get(r['id'],{}).get('brand','IM' if name=='im' else 'MG');r['modelId']=r.get('modelId',before.get(r['id'],{}).get('modelId'))
  # Fresh canonical prices also refresh explicitly retained legacy offer cells, preserving deadline and source scope.
  if r['id'] in before:
   keys={f['key'] for f in r['facts']}
   for key in ['advertised_driveaway_aud','driveaway_price_aud']:
    if key not in before[r['id']]['facts'] or key in keys:continue
    price=next(f for f in r['facts'] if f['key']=='price_aud')
    if name=='cyberster':
     r['facts'].append({'key':key,'value':None,'grade':'not_published','sourceKeys':['cyberster-config','offers'],'reason':'The current maker configurator publishes a named-trim selector amount without a completed location-specific total, and the national October offers page does not list Cyberster. An exact current driveaway total was not established after these two checks; do not retain the ambiguous selector value as a driveaway claim.','basis':'Current exact driveaway total not established','comparison':'','qualifications':['The separate main price retains the maker selector amount with unconfirmed on-road basis.']})
    else:
     assert price['value'] is not None and price.get('comparison')=='Driveaway',(name,r['id'],price)
     f=copy.deepcopy(price);f['key']=key;f['label']='Current advertised driveaway offer';f['reason']='Fresh reviewed current maker national driveaway offer also refreshes the retained legacy price cell; the offer deadline and eligibility remain identical to the canonical price.'
     r['facts'].append(f)
  if name=='cyberster' and r['id'] in before and 'dc_charge_10_80_min' in before[r['id']]['facts']:
   dc=copy.deepcopy(next(f for f in r['facts'] if f['key']=='dc_charge_time_min'));dc['key']='dc_charge_10_80_min';dc['label']='Separate narrative 10–80% charging claim';r['facts'].append(dc)
  x['variants'].append(r)
res=json.load(open(R/'residuals/normalized-evidence.json'));x['sources']+=res['sources'];x['familyNotes']['residuals']={k:v for k,v in res.items() if k not in ['sources','variants']}
for r in res['variants']:
 current=next(v for v in x['variants'] if v['id']==r['id']);av=current['availability'];ra=r['availability'];av['sourceKeys']=list(dict.fromkeys(av['sourceKeys']+ra['sourceKeys']));av['stockStatus']=ra['stockStatus'];av['qualifications']+=ra['qualifications'];av['reason']+=' '+ra['reason']
# No unsupported publication date is inferred from URL/filename/month-only footer.
ids=[s['key'] for s in x['sources']];assert len(ids)==len(set(ids)),[k for k in ids if ids.count(k)>1]
for r in x['variants']:
 keys=[f['key'] for f in r['facts']];assert len(keys)==len(set(keys)),(r['id'],'duplicate fact')
 # Metadata for an unchanged version need not create an empty no-op identity correction.
 if not r.get('metadata'):r.pop('metadata',None)
(R/'normalized-evidence.json').write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
print(len(x['variants']),'versions',len(x['sources']),'sources',sum(len(v['facts']) for v in x['variants']),'facts',sum(len(v['features']) for v in x['variants']),'features')
