import json,pathlib
R=pathlib.Path('/tmp/mg-im-research');D='2026-10-14';cars=[c for c in json.load(open(R/'before.json')) if c['model']=='Cyberster'];out={'reviewedAt':D,'sources':[],'variants':[],'reconciliation':{'currentTrims':['77kWh RWD','77kWh AWD'],'formalModelYear':None,'reason':'Current Australian page names MY26, but the currently linked brochure explicitly covers MY25 as at August 2026. Exact current named trims are retained without guessing a formal model year. Roof and paint choices are options, not distinct mechanical versions.','sourceKeys':['cyberster-page','cyberster-brochure','cyberster-config']}}
def source(key,url,title,publisher,kind,file,date=None,note=''):
 out['sources'].append({'key':key,'url':url,'title':title,'publisher':publisher,'source_type':kind,'published_date':date,'file':str(R/'sources'/file),'textFile':str(R/'sources'/(file.rsplit('.',1)[0]+'.txt')) if file.endswith(('.pdf','.html')) else None,'supports':note or title})
source('cyberster-page','https://mgmotor.com.au/vehicles/cyberster','MG Cyberster current Australian range and two exact trims','MG Motor Australia','manufacturer_au_model_page','cyberster-page.html',note='Current RWD/AWD range, drivetrain, power, acceleration, range and wheels. Page footer says MY26 as at May2026, while linked brochure says MY25 as atAugust2026; month-only dates are retained without invented publication day.')
source('cyberster-brochure','https://mgmotor.com.au/brochures/MG_CYBERSTER_2026_v2.pdf','Cyberster Australian brochure: current linked August2026 MY25 specification','MG Motor Australia','manufacturer_au_brochure','cyberster-brochure.pdf',note='Full current linked AU technical/equipment brochure. Pages10–11 are exact RWD/AWD columns; page6 AWD discussion explicitly gives40min10–80% at150kW station. Footer says content correctAugust2026 forMY25; filename is not model-year proof.')
source('cyberster-config','https://mgmotor.com.au/configurator/cyberster','Cyberster Australian current two-grade configurator','MG Motor Australia','manufacturer_au_configurator','cyberster-config.html',note='Current named-trim selector amounts99,900/115,000, standard roof/colour choices, October2026 terms. No explicit RRP label or completed location-specific total; amounts are shown as maker configurator with unconfirmed on-road basis, unranked.')
source('cyberster-carsguide-current','https://www.carsguide.com.au/mg/cyberster/2026','2026 Cyberster range, dimensions and no-towing guide','CarsGuide','secondary_au_price_spec_guide','cyberster-carsguide-current.html',note='Secondary exact RWD/AWD2026 overview lists no towing capacity/0kg. Reported only, not a maker tow approval; historical warranty errors are not used.')
source('cyberster-carsguide-rwd','https://www.carsguide.com.au/mg/cyberster/price/2026/77kwh-rwd?id=2IDOShEM','2026 Cyberster77kWhRWD exact price/specification entry','CarsGuide','secondary_au_price_spec_guide','cyberster-carsguide-rwd.html')
source('cyberster-carsguide-awd','https://www.carsguide.com.au/mg/cyberster/price/2026/77kwh-awd?id=2IzNShEM','2026 Cyberster77kWhAWD exact price/specification entry','CarsGuide','secondary_au_price_spec_guide','cyberster-carsguide-awd.html')
for c in cars:
 awd=c['drive']=='AWD';facts=[];features=[]
 def f(key,value,keys=['cyberster-brochure'],grade='confirmed',basis=None,comparison=None,reason=None,qualifications=None,**kw):
  row={'key':key,'value':value,'sourceKeys':keys,'grade':grade,'reason':reason or 'Current linked MG Australia brochure gives the exact named-trim value; generic production-year and laboratory notes do not change the published figure.','qualifications':qualifications or [],**kw}
  if basis is not None:row['basis']=basis
  if comparison is not None:row['comparison']=comparison
  facts.append(row);return row
 def feature(criterion,value,keys,grade=None,conditions='',**kw):
  row={'criterion':criterion,'value':value,'keys':keys,**kw}
  if grade:row['grade']=grade
  if conditions:row['conditions']=conditions
  features.append(row)
 f('price_aud',115000 if awd else 99900,['cyberster-config'],'check',basis='Maker configurator named-trim amount; on-road basis unconfirmed',comparison='',reason='The highest currently verifiable maker price rung is its named-trim configurator amount. There is no explicit RRP label or completed location-specific total. Secondary list prices are lower ladder rungs and do not supply maker price provenance.',condition='Confirm final on-road basis and location-specific total with the dealer; a selector amount is not a verified national driveaway total.',priceRung=3,basisTag='Maker configurator · on-road basis unconfirmed',rankingEligible=False,validUntil='2026-10-31',qualifications=['Current configurator terms apply to new vehicles sold and delivered1–31October2026; while stocks last; excludes fleet/government/rental buyers and other offers. No purchase made.'])
 f('range_km',443 if awd else 507,['cyberster-brochure','cyberster-page'],basis='WLTP combined laboratory range',comparison='WLTP combined')
 f('battery_kwh',77,basis='Maker declared battery capacity; gross/usable unspecified',comparison='Declared capacity (gross/usable unspecified)',qualifications=['Do not relabel as usable or gross capacity.'])
 f('dc_peak_kw',144,basis='Maximum vehicle DC charging acceptance',comparison='Peak DC power',qualifications=['150kW is the separate test-station capability, not vehicle peak acceptance.'])
 f('dc_charge_time_min',40,grade='confirmed' if awd else 'reported',basis='DC10–80% at150kW station; maker AWD passage' if awd else 'DC10–80% at150kW station; carried from Australian AWD sibling',comparison='DC 10–80%',reason='Page6 explicitly describes the375kW AWD Cyberster and states10–80% in40minutes at a150kW DC station.' if awd else 'The current Australian brochure explicitly publishes40minutes10–80% only in its AWD discussion. This is openly carried from the same77kWh AWD sibling at Reported grade, not claimed as exact RWD maker confirmation.',qualifications=['The technical table also gives34minutes30–80% at25°C; that is a separate window, not a conflicting10–80% figure.']+([] if awd else ['RWD exact10–80% time is not separately identified in the current AU brochure or model page; confirm before relying on this sibling estimate.']))
 f('dc_30_80_time_min',34,basis='DC30–80% at25°C on150kW CCS station',comparison='DC 30–80%',qualifications=['Distinct from canonical10–80%; no window conversion.'])
 f('dc_test_station_kw',150,basis='DC station rating for timed charging claims',comparison='Station output; not vehicle peak',qualifications=['Not vehicle peak charging acceptance.'])
 f('ac_kw',11,basis='On-board AC charging unit maximum',comparison='AC kW')
 f('ac_charge_time_min',540,basis='Maker9hours full charge at11kW and25°C',comparison='AC full-charge estimate at11kW',reason='The exact-trim table publishes9h full charge at11kW and25°C; converted only from hours to minutes, not estimated from battery energy.',qualifications=['The manufacturer supplies9hours; not a power/battery division.'])
 f('seats',2,['cyberster-carsguide-awd' if awd else 'cyberster-carsguide-rwd'],'reported',basis='Australian exact-trim secondary seating specification',comparison='Seats',reason='CarsGuide exact Australian RWD/AWD specification lists two seats; maker seating table names driver/passenger features but does not state an explicit total.')
 f('boot_l',249,basis='Rear boot; measurement method and roof position unspecified',comparison='',qualifications=['Maker does not identify VDA/SAE or roof/parcel-shelf boundary; not ranked against standardized cargo volumes.'])
 f('zero_to_100_s',3.2 if awd else 5.2,['cyberster-brochure','cyberster-page'],basis='Manufacturer0–100km/h claim',comparison='0–100 km/h')
 f('power_kw',375 if awd else 250,['cyberster-brochure','cyberster-page'],basis='Explicit combined motor output' if awd else 'Rear motor output',comparison='Manufacturer total power',qualifications=['AWD total is explicitly375kW; front150+rear250 are not summed to400kW.'] if awd else [])
 if awd:
  f('front_motor_kw',150,basis='Front motor rating; not added to rear rating',comparison='')
  f('rear_motor_kw',250,basis='Rear motor rating; not added to front rating',comparison='')
 f('drive',c['drive'],['cyberster-page'],basis='Drivetrain',comparison='Drivetrain')
 for key,value in [('length_mm',4535),('width_mm',1913),('height_mm',1329),('wheelbase_mm',2690),('ground_clearance_mm',116)]:f(key,value,basis='Manufacturer body measurement; width mirror treatment unspecified' if key=='width_mm' else 'Manufacturer body measurement',comparison='' if key=='width_mm' else key)
 f('towing_braked_kg',0,['cyberster-carsguide-current'],'reported',basis='Secondary guide: no braked towing capacity',comparison='Braked towing',reason='CarsGuide current Australian RWD/AWD table expressly records0kg and says the Cyberster has no towing capacity. The maker brochure/model page omit a rating, so this is a Reported secondary figure, not manufacturer towing approval.',qualifications=['Do not tow based on this guide; confirm vehicle handbook and approval.'])
 for key,value in [('torque_nm',725 if awd else 475),('tare_mass_kg',1985 if awd else 1885),('wheel_inches',20 if awd else 19),('speaker_count',8),('energy_use_wh_km',191 if awd else 167)]:f(key,value,basis='Maker declared driving efficiency; cycle not specified in row' if key=='energy_use_wh_km' else None,comparison='' if key=='energy_use_wh_km' else None)
 f('battery_chemistry','Ternary lithium')
 f('charging_connector','CCS Type2')
 f('body_style','Convertible roadster',['cyberster-page'],basis='Body style',comparison='Body style')
 equipment={
 'driver_profiles_local':'Driver and passenger seat memory; no broader profile-transfer claim',
 'front_heated_seats':'Three-level heated front seats',
 'heated_steering_wheel':'Heated steering wheel',
 'v2l':'Vehicle-to-load function; outlet power and adapter inclusion not specified here',
 'carplay_android_auto':'Apple CarPlay and Android Auto; connection type not specified by this AU brochure',
 'parking_cameras':'HD360-degree camera, front and rear parking sensors',
 'folding_mirrors':'Electrically adjustable, folding and heated exterior mirrors',
 'adas_standard':'Adaptive cruise control, autonomous emergency braking, lane-keep/emergency lane-keep, blind-spot detection and rear cross-traffic braking/alert',
 'voice_assistant':'Voice control is listed; supported command scope is not specified',
 'app_connectivity':'iSMART connectivity; first12months complimentary, later service/licence charges may apply with60days notice',
 'spare_tyre':'Tyre repair kit supplied',
 'screens_hud':'10.25-inch driver display, two7-inch side screens and a7-inch centre screen; no head-up-display claim',
 'audio_system':'Eight-speaker Bose audio system',
 'battery_preconditioning_navigation':'Charging pre-heating is listed; navigation-triggered automation is not established',
 }
 for criterion,value in equipment.items():
  key='feature_'+criterion;f(key,value,basis='Exact Australian trim equipment table',comparison='',reason='Current linked Australian brochure pages10–11 explicitly list the stated equipment for both named grades; no adjacent automation or option is inferred.');feature(criterion,value,[key])
 feature('storage','249 L rear boot; cargo measurement method and roof position are not stated',['boot_l'])
 feature('performance_rear_motor',('375kW combined AWD;150kW front and250kW rear motor ratings are not additive' if awd else '250kW rear motor;475Nm torque'),['power_kw','front_motor_kw','rear_motor_kw'] if awd else ['power_kw','torque_nm'])
 feature('battery_chemistry','77kWh ternary-lithium battery; gross/usable capacity is not stated',['battery_kwh','battery_chemistry'])
 feature('energy_use',f"Maker lists {191 if awd else 167}Wh/km driving efficiency; the table does not name the test cycle",['energy_use_wh_km'])
 feature('home_charging','11kW on-board AC; maker estimates9hours for a full charge at11kW and25°C',['ac_kw','ac_charge_time_min'])
 out['variants'].append({'id':c['id'],'brand':'MG','model':c['model'],'trim':c['trim'],'modelId':c['modelId'],'modelYear':None,'drive':c['drive'],'facts':facts,'features':features,'availability':{'state':'current_or_order_listed','orderStatus':'listed_unconfirmed','stockStatus':'unverified','sourceKeys':['cyberster-page','cyberster-config'],'reason':'Both exact named trims remain in the current Australian maker model page and configurator. No completed factory order or physical stock verification is inferred.','qualifications':['Current named Australian configuration; formal model year remains unresolved because maker webpageMY26 and linked brochureMY25 disagree.','Roof and paint choices are options, not new versions.','Order acceptance and physical/unallocated stock are not verified.']},'summary':{'strength':{'label':'Quick open-top performance' if awd else 'Open-top range','text':'The AWD combines a convertible-roadster body with375kW and a claimed3.2-second0–100km/h time.' if awd else 'The rear-drive convertible pairs250kW with a maker-rated507km WLTP range.','keys':['body_style','power_kw','zero_to_100_s'] if awd else ['body_style','power_kw','range_km']},'tradeoff':{'label':'Limited carrying space','text':'Two seats and a249L boot keep passenger and luggage capacity modest. Seating is reported by CarsGuide; the maker does not state a standardized cargo method.','keys':['seats','boot_l']}}})
(R/'cyberster-evidence.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
