import fs from 'node:fs';
import {catalogue,research,effectiveFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/data.ts';
const root='/tmp/mg-im-research/', r=research(), all=catalogue(), cars=all.filter(c=>['MG','IM','MG / IM'].includes(c.brand));
fs.writeFileSync(root+'before.json',JSON.stringify(cars,null,2));
fs.writeFileSync(root+'research-before.json',JSON.stringify(r,null,2));
fs.writeFileSync(root+'features-before.json',JSON.stringify(cars.flatMap(c=>effectiveFeatures(c,r)),null,2));
console.log(cars.map(c=>({id:c.id,model:c.model,trim:c.trim,year:c.year,availability:c.availability,drive:c.drive})));
