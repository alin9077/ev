import json,pathlib,hashlib,collections
R=pathlib.Path('/tmp/mg-im-research');D='2026-10-14'
packets=[json.load(open(R/(b+'-2026-10-14.json'))) for b in ['mg','im']]
rows=[]
for p in packets:
 for s in p['sources']:
  row={**s,'packetId':p['id']}
  for loc,h in [('capture_locator','capture_sha256'),('capture_text_locator','capture_text_sha256')]:
   if s.get(loc):
    f=R/s[loc];assert f.is_file(),s['id'];assert hashlib.sha256(f.read_bytes()).hexdigest()==s[h],s['id']
  rows.append(row)
(R/'source-index.json').write_text(json.dumps({'checkedAt':D,'scope':'Dated MG and IM Australian Tier 1 research overlays; shared source captures may support separate brand packets. Raw captures remain unchanged. Source publication dates are null unless an exact publication date is established.','sources':rows},indent=2,ensure_ascii=False)+'\n')
captures=[]
for p in sorted(R.rglob('*')):
 if p.is_file() and ('sources' in p.relative_to(R).parts or p.parent.name=='inherited-source-artifacts'):
  captures.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(R/'source-hash-manifest.json').write_text(json.dumps({'checkedAt':D,'scope':'All permitted full raw captures, extraction sidecars and public web-tool retrieval captures; denied or failed responses are retained for traceability, never silently promoted as factual source text.','files':captures},indent=2,ensure_ascii=False)+'\n')
artifacts=['mg-2026-10-14.json','im-2026-10-14.json','mg-reconciliation-2026-10-14.json','im-reconciliation-2026-10-14.json','brand-model-list-reconciliation.json','source-index.json','source-hash-manifest.json','before.json','research-before.json','features-before.json','new-feature-before.json','mg4/inherited-inventory-audit.json','mg4/price-ladder-review.json','mgs/audit.json','residuals/residual-closure.json','residuals/archive-closure.json','im/review-summary.md']
if (R/'REVIEW.md').exists():artifacts.append('REVIEW.md')
manifest=[]
for n in artifacts:
 p=R/n;assert p.is_file(),n;manifest.append({'path':n,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(R/'artifact-hash-manifest.json').write_text(json.dumps({'checkedAt':D,'files':manifest},indent=2,ensure_ascii=False)+'\n')
print('Validated',len(rows),'packet source entries and hashed',len(captures),'full capture/sidecar files;',len(artifacts),'artifact hashes')
