import json,pathlib,hashlib,copy,re,sys
R=pathlib.Path('/tmp/mg-im-research');D='2026-10-14';BRAND=sys.argv[1];SLUG=BRAND.lower();PID='m1-'+SLUG+'-2026-10-14';REVIEWER='Roadmark '+BRAND+' Australian source review'
cars=[c for c in json.load(open(R/'before.json')) if c['vehicleClass']=='passenger' and c['brand']==BRAND];old={c['id']:c for c in cars};prior=json.load(open(R/'features-before.json'));prior+=json.load(open(R/'new-feature-before.json')) if (R/'new-feature-before.json').exists() else [];effective={c['id']:{} for c in cars}
p={'schemaVersion':1,'id':PID,'brand':BRAND,'reviewedAt':D,'reviewedBy':REVIEWER,'sources':[],'models':[],'variants':[],'versionGuards':[],'versionUpdates':[],'facts':[],'features':[],'brandTerms':[],'availability':[],'summaries':[]};sources={}
pe=json.load(open(R/'normalized-evidence.json'));pe['variants']=[v for v in pe['variants'] if v.get('brand',next((c['brand'] for c in cars if c['id']==v['id']),'MG'))==BRAND];terms=json.load(open(R/'terms.json'))[BRAND];scopeTrims={r['id']:r.get('metadata',{}).get('trim',r['trim']) for r in pe['variants']}
def source(row):
 k=row['key'];s={'id':PID+'-'+k,'url':row['url'],'title':row['title'],'publisher':row['publisher'],'source_type':row.get('source_type',row.get('kind')),'published_date':row.get('published_date'),'accessed_date':D,'market':'AU','supports':row.get('supports') or row.get('note') or row['title']}
 for key in ['notes','note','conflicts','capture_section']:
  if key in row:s[key]=row[key]
 path=row.get('file') or row.get('path') or row.get('textFile')
 if path:
  f=pathlib.Path(path);f=f if f.is_absolute() else R/f
  if f.exists():s['capture_sha256']=hashlib.sha256(f.read_bytes()).hexdigest();s['capture_locator']=str(f.relative_to(R))
 textpath=row.get('textFile') or row.get('textPath')
 if textpath:
  tf=pathlib.Path(textpath);tf=tf if tf.is_absolute() else R/tf
  if tf.exists():s['capture_text_locator']=str(tf.relative_to(R));s['capture_text_sha256']=hashlib.sha256(tf.read_bytes()).hexdigest()
 if k in sources:
  assert sources[k]==s,k
  return
 p['sources'].append(s);sources[k]=s
for s in json.load(open(R/'parent-sources.json'))+pe['sources']:source(s)
for row in pe['variants']:
 if row['id'] in old:continue
 mid=row['modelId'];model=row['model'];drive=row['drive'];generation=row.get('generation',row.get('metadata',{}).get('generation','Australian specification'));src=[sources[k]['id'] for k in row['availability']['sourceKeys']]
 if mid not in [m['id'] for m in p['models']] and mid not in [m['id'] for m in json.load(open(R/'research-before.json'))['models']]:p['models'].append({'id':mid,'brand':BRAND,'model':model,'generation':generation})
 v={'id':row['id'],'model_id':mid,'brand':BRAND,'model':model,'trim':row['trim'],'model_year':row.get('model_year',row.get('modelYear')),'record_state':row['availability']['state'],'variant_review_date':D,'source_ids':src,'notes':row.get('notes',[]),'price_basis':'','range_cycle':'WLTP','price_aud':None,'range_km':None,'seats':None,'vehicle_class':'passenger','drive':drive,'brand_update_generation':generation}
 p['variants'].append(v)
 c={'id':v['id'],'modelId':mid,'brand':BRAND,'model':model,'trim':v['trim'],'year':v['model_year'],'generation':generation,'vehicleClass':'passenger','drive':drive,'availability':v['record_state'],'availabilityEvidence':{'checkedAt':D,'orderStatus':'unverified','stockStatus':'unverified','sourceIds':src,'qualifications':['Physical stock and factory-order acceptance have not been verified.']},'facts':{}}
 old[c['id']]=c;cars.append(c);effective[c['id']]={}
def ident(c):return {k:c[k] for k in ['id','modelId','brand','model','trim','year','generation','vehicleClass','drive']}
for c in cars:
 if c['id'] not in [v['id'] for v in p['variants']]:p['versionGuards'].append({'variantId':c['id'],'before':ident(c)})
meta={
'price_when_new_aud':['Historical price when new','AUD','Before on-road costs'],'price_aud':['Price','AUD','Before on-road costs'],'promotional_driveaway_aud':['Driveaway offer','AUD','Driveaway'],'range_km':['Range','km','WLTP'],'battery_kwh':['Battery capacity','kWh','Battery capacity; gross/usable unspecified'],'dc_peak_kw':['DC peak charging','kW','Peak DC power'],'dc_charge_time_min':['DC 10–80% charge time','min','10–80%'],'ac_kw':['AC charging power','kW','Maximum AC input'],'seats':['Seats','','Seating capacity'],'boot_l':['Boot volume','L','Rear luggage; all seats in use; method unspecified'],'zero_to_100_s':['0–100 km/h','s','0–100 km/h'],'power_kw':['Motor power','kW','Motor output'],'drive':['Drive type','','Drivetrain'],'length_mm':['Length','mm','Length'],'width_mm':['Width','mm','Width; mirror treatment unspecified'],'height_mm':['Height','mm','Height'],'towing_braked_kg':['Braked towing','kg','Maximum braked towing'],'warranty':['Vehicle warranty','','Australian new-vehicle warranty'],'battery_warranty':['Battery warranty','','Australian traction-battery warranty'],'roadside_assistance':['Roadside assistance','','Australian roadside assistance'],'body_style':['Body style','','Body style'],'frunk_l':['Front storage','L','Front luggage; method unspecified'],'max_total_cargo_l':['Rear cargo with seats folded','L','Rear cargo; seats folded; method unspecified'],'rear_cargo_folded_l':['Rear cargo with seats folded','L','Rear luggage; seats folded; method unspecified'],'wheelbase_mm':['Wheelbase','mm','Wheelbase'],'torque_nm':['Torque','Nm','Motor torque'],'dc_test_charger_kw':['DC charging test station','kW','Station output used for charging-time claim'],'ac_single_phase_kw':['Single-phase AC charging power','kW','Maximum single-phase AC input'],'ac_three_phase_kw':['Three-phase AC charging power','kW','Maximum three-phase AC input'],'ac_charge_time_min':['AC charging duration','min','AC charging duration'],'battery_chemistry':['Battery chemistry','','Battery chemistry'],'energy_use_wh_km':['Energy consumption','Wh/km','Energy consumption'],'towing_unbraked_kg':['Unbraked towing','kg','Maximum unbraked towing'],'wheels_inches':['Wheel size','in','Standard wheel size']}
meta.update({'energy_consumption_wh_km':['Energy consumption','Wh/km','WLTP combined'],'ground_clearance_mm':['Ground clearance','mm','Minimum ground clearance'],'turning_circle_m':['Turning circle','m','Minimum turning circle'],'configurator_rrp_aud':['Configurator RRP','AUD','Before on-road costs'],'driveaway_price_aud':['Configurator driveaway estimate','AUD','Driveaway'],'cargo_third_row_folded_l':['Rear cargo with third row folded','L','Rear cargo; third row folded'],'kerb_weight_kg':['Kerb mass','kg','Kerb mass'],'tare_weight_kg':['Tare mass','kg','Tare mass'],'motor_count':['Motors','','Motor count']})
meta.update({'battery_usable_kwh':['Usable battery capacity','kWh','Usable battery capacity'],'front_motor_kw':['Front motor power','kW','Front motor component output'],'rear_motor_kw':['Rear motor power','kW','Rear motor component output'],'dc_30_80_time_min':['DC 30–80% charge time','min','DC 30–80%'],'dc_test_station_kw':['DC charging test station','kW','Station output; not vehicle peak'],'tare_mass_kg':['Tare mass','kg','Tare mass'],'wheel_inches':['Wheel size','in','Standard wheel size'],'speaker_count':['Speakers','','Speaker count'],'warranty_extension':['Service-activated warranty extension','','Australian extended-warranty terms']})
def fact(c,key,value,sourceKeys,grade='confirmed',reason=None,scope=None,basis=None,comparison=None,condition='',qualifications=None,**extra):
 label,unit,default=meta.get(key,[old[c['id']]['facts'].get(key,{}).get('label',key.replace('_',' ').capitalize()),old[c['id']]['facts'].get(key,{}).get('unit',''),key]);scope=scope or ('secondary_or_sibling' if grade=='reported' else 'searched_not_found' if grade=='not_published' else 'exact_au_version')
 ids=[sources[x]['id'] for x in sourceKeys];reason=reason or 'Current Australian maker material explicitly establishes this figure for the named version.'
 f={'key':key,'label':label,'value':value,'unit':unit,'basis':basis or default,'comparisonBasis':default if comparison is None else comparison,'status':{'confirmed':'standard','check':'conditional','reported':'conditional','not_published':'not_verified'}[grade],'sourceIds':ids,'date':D,'market':'AU','scope':BRAND+' '+c['model']+' '+scopeTrims.get(c['id'],c['trim']),'qualifications':qualifications or ([condition] if condition else []),'issues':[],'buyerGrade':grade,'gradeReview':{'reviewedAt':D,'overlayId':PID,'reason':reason,'evidenceScope':scope,'sourceIds':ids,'sourceLabel':' / '.join(dict.fromkeys(sources[k]['publisher'] for k in sourceKeys))},**extra}
 if condition:f['conditionExplanation']=condition
 if grade=='check' and not condition:f['conditionExplanation']=' '.join(f['qualifications']) or reason
 if grade=='not_published':f['conditionExplanation']=reason
 if grade=='reported':f['resolvedElsewhere']=True
 assert key not in effective[c['id']],(c['id'],key)
 p['facts'].append({'variantId':c['id'],'before':old[c['id']]['facts'].get(key),'after':f});effective[c['id']][key]=f
 return f
for key in ['warranty','battery_warranty','roadside_assistance']:
 row=terms[key];app=cars
 f=fact(app[0],key,row['value'],row['sourceKeys'],row['grade'],reason=row['reason'],scope='brand_au_terms',qualifications=row['qualifications']);p['facts'].pop();f['scope']=BRAND+' Australia private-buyer policy baseline for explicitly enumerated applicable versions; registration-date, commercial-use and component exceptions retained'
 p['brandTerms'].append({'key':key,'fact':f,'applicableVariantIds':[c['id'] for c in app],'before':{c['id']:c['facts'].get(key) for c in app},'exceptions':[]})
 for c in app:effective[c['id']][key]=f
for c in cars:
 t=terms['extension'];fact(c,'warranty_extension',t['value'],t['sourceKeys'],t['grade'],reason=t['reason'],scope='brand_au_terms',condition=t['condition'],comparison='')
for row in pe['variants']:
 c=old[row['id']]
 if row.get('metadata') and row['id'] not in [v['id'] for v in p['variants']]:
  a=ident(c);a.update(row['metadata']);p['versionUpdates'].append({'variantId':c['id'],'before':ident(c),'after':a,'reason':row['metadataReason']})
 for rf in row['facts']:
  key=rf['key']
  if key in ['warranty','battery_warranty','roadside_assistance']:continue
  extra={k:rf[k] for k in ['unit','label','validUntil','displayValue'] if k in rf and rf[k] is not None}
  if rf.get('offerEnds') and 'validUntil' not in extra:extra['validUntil']=rf['offerEnds']
  f=fact(c,key,rf['value'],rf['sourceKeys'],rf.get('grade','confirmed'),reason=rf.get('reason'),scope=rf.get('scope',rf.get('evidenceScope')),basis=rf.get('basis'),comparison=rf.get('comparison'),condition=rf.get('condition',''),qualifications=rf.get('qualifications'),**extra)
  if key in ['price_aud','promotional_driveaway_aud'] and f['value'] is not None:
   rung=rf['priceRung'];f['priceEvidence']={'rung':rung,'basisTag':rf.get('basisTag','Maker’s RRP' if rung==1 else 'Maker’s national driveaway offer' if rung==2 else 'Maker’s configuration price' if rung==3 else 'Maker’s state driveaway estimate' if rung==4 else 'Reported by '+sources[rf['sourceKeys'][0]]['publisher']),'sourceKey':key,'sourcePointer':rf.get('sourcePointer',sources[rf['sourceKeys'][0]]['url']),'originalBasis':f['basis'],'rankingEligible':rf.get('rankingEligible',f['buyerGrade'] in ['confirmed','check'])}
   if rung>=5:f['priceEvidence']['publisher']=sources[rf['sourceKeys'][0]]['publisher']
   if rung==4:f['priceEvidence']['state']=rf['state']
 av=row['availability'];ids=[sources[k]['id'] for k in av['sourceKeys']]
 p['availability'].append({'id':PID+'-availability-'+c['id'],'variantId':c['id'],'before':{'availability':c['availability'],'evidence':c['availabilityEvidence']},'after':{'availability':av['state'],'evidence':{'checkedAt':D,'orderStatus':av.get('orderStatus','listed_unconfirmed'),'stockStatus':av.get('stockStatus','unverified'),'sourceIds':ids,'physicalStockVerified':False,'factoryOrderAcceptanceVerified':False,'qualifications':av['qualifications']}},'status':'approved','reviewedBy':REVIEWER,'reviewedAt':D,'evidenceDate':D,'reason':av['reason']})
def feature(c,criterion,value,keys,grade=None,conditions='',reason=None,status=None):
 matches=[f for f in prior if f['variant_id']==c['id'] and f['criterion']==criterion]
 if not matches:
  if '--identities-only' in sys.argv:return
  raise ValueError(('Missing feature before',c['id'],criterion))
 before=matches[0];facts=[effective[c['id']][k] for k in keys];ids=list(dict.fromkeys(i for f in facts for i in f['sourceIds']))
 grade=grade or ('reported' if any(f['buyerGrade']=='reported' for f in facts) else 'check' if any(f['buyerGrade']=='check' for f in facts) else 'confirmed')
 after=copy.deepcopy(before)
 for k in ['gradeReviewStatus','confirmation_needed']:after.pop(k,None)
 after.update(status='standard' if grade=='confirmed' else 'not_verified' if grade=='not_published' else 'conditional',value=value,conditions=conditions,condition_label='Measurement scope' if conditions else '',source_ids=ids,evidence_scope='Reviewed Australian '+c['model']+' '+scopeTrims.get(c['id'],c['trim']),last_evidence_date=D,reviewed_date=D,verification_state='reviewed_m1_'+SLUG+'_2026_10_14',buyerGrade=grade,gradeReview={'reviewedAt':D,'overlayId':PID,'reason':reason or 'Fresh reviewed answer mirrors canonical post-packet facts and their measurement and source qualifications.','evidenceScope':'secondary_or_sibling' if grade=='reported' else 'searched_not_found' if grade=='not_published' else 'exact_au_version','sourceIds':ids,'sourceLabel':' / '.join(dict.fromkeys(s['publisher'] for s in p['sources'] if s['id'] in ids))})
 if status is not None:after['status']=status
 p['features'].append({'variantId':c['id'],'criterion':criterion,'before':before,'after':after,'dependencies':[{'key':f['key'],'expected':f} for f in facts]})
for row in pe['variants']:
 c=old[row['id']];e=effective[c['id']]
 for fr in row.get('features',[]):feature(c,**fr)
 feature(c,'warranty_service',('7 years / unlimited km standard; up to 10 years / 250,000 km with qualifying MG dealer servicing' if BRAND=='MG' else '5 years / unlimited km standard; up to 7 years / unlimited km with qualifying IM dealer servicing'),['warranty','warranty_extension'],grade='check',conditions=terms['extension']['condition'],reason='Separates standard cover from the real exclusive-servicing extension; canonical shared terms and extension facts are its exact dependencies.')
 def clause(x):return {'label':x['label'],'text':x['text'],'dependencies':[{'key':k,'expected':e[k]} for k in x['keys']]}
 if row.get('summary'):p['summaries'].append({'variantId':c['id'],'conditions':row.get('summaryConditions',c.get('configurationEvidence',{}).get('requiredBuyerVisibleConditions',[])),'strength':clause(row['summary']['strength']),'tradeoff':clause(row['summary']['tradeoff'])})
(R/(SLUG+'-2026-10-14.json')).write_text(json.dumps(p,indent=2,ensure_ascii=False)+'\n');(R/(SLUG+'-effective-facts.json')).write_text(json.dumps(effective,indent=2,ensure_ascii=False)+'\n');(R/(SLUG+'-source-index.json')).write_text(json.dumps({'checkedAt':D,'sources':p['sources'],'scope':BRAND+' only, independent brand lists do not prove whole-market C1 closure'},indent=2,ensure_ascii=False)+'\n')
print('Prepared',len(p['variants']),'new versions,',len(p['facts']),'specific facts,',len(p['brandTerms']),'shared terms,',len(p['features']),'guarded features,',len(p['sources']),'sources.')
