# IM5 / IM6 Australian review, 14 October 2026

## Ready for integration

- `normalized-evidence.json`: six existing exact IM-branded identities, 323 fact reviews and 132 full equipment-row reviews
- `source-manifest.json`: hashes and sizes for captured source files, extracted text and permitted web-tool captures
- `sources/`: full Australian maker brochures, technical sheets, model pages, configurators, October offers, launch release, owner manual, seven full dealer HTML pages and secondary/cached text captures where direct downloading returned HTTP 403
- No repository edits or packet registration performed

## Version closure

IM5 and IM6 each retain Premium RWD, Platinum RWD and Performance AWD. Fresh official tables, configurators and offers agree with reopened CarExpert model lists. Maker technical material remains explicitly MY25. Calendar-year 2026 sales headings and RedBook MY26 descriptions do not establish a new maker technical epoch. Platinum air suspension remains a configurable option, not an additional trim: A$3,990 for IM5 and A$4,990 for IM6.

All ten inherited IM dealer leads are individually classified in familyReconciliation.residualClassifications:

- Three currently live New advertisements map to existing grades, but their exact model-year join is unresolved
- Three indexed New / MY25 advertisements map to existing versions, but the live download returned HTTP 403. Cached content is not treated as fresh physical-stock proof
- Three direct pages still explicitly say sold
- One direct model index exposes a demonstrator only

All six vehicles remain on sale based on maker order-listing evidence. None is represented as physically verified new stock.

## Core facts and material corrections

- All six current national driveaway prices are now A$57,990 / A$64,990 / A$74,990 by grade, already including A$3,000 cashback. These are rung 2, Check for eligibility and sale plus delivery by 31 October 2026. Optional A$500 accessory/cash election is not silently deducted. No maker before-on-road RRP was found
- IM5 uses 490 / 655 / 575 km WLTP. Its 755 km prose claim is NEDC Platinum in the maker table
- Australian DC figures of 20 / 15.2 minutes are explicitly 30–80% and moved to a separate fact. Canonical 10–80% is Not published for 75 kWh; the 100 kWh 17-minute claim is explicitly European sibling Reported and unranked, with source attribution. No interval conversion
- 153 / 396 kW is the explicit vehicle DC maximum. The website's 350 kW station caveat is not substituted as the vehicle maximum
- Performance combined 572 kW and 802 Nm are Reported from explicit Australian secondary statements, not summed components. The competing IM5 553 kW report is disclosed. Exact maker 200/372 kW and 302/500 Nm component values remain separate
- Rear cargo is explicitly seats in place: IM5 457 L; IM6 665 / 665 / 646 L. No VDA/SAE method is claimed, and separate front storage is not added
- All retained researched equipment rows are freshly dependency-bound. IM5 front ventilation remains backrest-only under the later December 2025 brochure, superseding the June 2025 spec sheet. IM6 brochure says cushion and backrest ventilation

Vehicle and battery warranties, roadside and warranty-service rows are delegated to the parent's separate IM-specific shared terms. No warranty-service equipment row was added here.

## Validation

The local normalized check verifies all six identities against the baseline; every variant contains all 15 non-shared core fields; all source references resolve; every Not published fact is genuinely null with two distinct usable URLs; every feature criterion already exists; all feature and summary dependency keys resolve; source files match their SHA-256 entries. No whole-row Not published feature was created. Repository integration/typechecks remain the parent's responsibility.
