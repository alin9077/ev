import json,pathlib,hashlib,re,urllib.parse
P=pathlib.Path('/tmp/mg-im-research/im'); S=P/'sources'; DATE='2026-10-14'
B=json.load(open('/tmp/mg-im-research/before.json')); F=json.load(open('/tmp/mg-im-research/features-before.json')); old=json.load(open('/workspace/scratch/586427eef9f2/roadmark-104/data/mg-remaining-evidence-2026-10-10.json'))
# Persist individual, provenance-preserving text extractions where the origin refuses a direct full-file request.
sections_by_key={}
for name in ['secondary-web-capture','secondary-fact-web-capture','dealer-foreign-web-capture']:
 raw=json.load(open(S/(name+'.json')))
 for section in raw.split('\n--------------------------------------------------------------------------------\n'):
  m=re.search(r'^([^\n]+) \((https?://[^\s]+)\)',section)
  if not m: continue
  u=m.group(2)
  keys={'https://www.carexpert.com.au/mg/im5':'im5-carexpert-list','https://www.carexpert.com.au/mg/im6':'im6-carexpert-list','https://www.chasingcars.com.au/reviews/large-cars/mg-im5-performance-2025-review/':'im5-chasingcars-review'}
  keys.update({x['sourceUrl']:x['sourceId'] for x in old['specificNewStock'] if x['model'] in ['IM5','IM6']})
  k=keys.get(u)
  if k:
   sections_by_key.setdefault(k,[])
   if section not in sections_by_key[k]:sections_by_key[k].append(section)
for k, sections in sections_by_key.items():
 (S/(k+'-web.txt')).write_text('\n\n'.join(sections))
urls={}
for model in ['im5','im6']:
 urls.update({model+'-model':f'https://mgmotor.com.au/vehicles/{model}',model+'-config':f'https://mgmotor.com.au/configurator/{model}',model+'-brochure':f'https://mgmotor.com.au/brochures/MG_{model.upper()}_Brochure.pdf',model+'-spec':f'https://mgmotor.com.au/brochures/MG_{model.upper()}_Spec_Sheet.pdf'})
urls.update({'mg-offers':'https://mgmotor.com.au/offers','mg-home':'https://mgmotor.com.au/','im5-au-owner-manual':'https://mgmotor.com.au/brochures/IM5-owners-manual.pdf','im-au-launch-release':'https://gaycarboys.com/wp-content/uploads/2025/09/IM-Presented-by-MG-Motor-Proudly-Launches-in-Australia_Press-Release.pdf','im-eu-launch':'https://news.mgmotor.eu/press/introducing-the-new-mg-im-range/','im5-carexpert-list':'https://www.carexpert.com.au/mg/im5','im6-carexpert-list':'https://www.carexpert.com.au/mg/im6'})
urls.update(json.load(open(S/'extra-urls.json')))
sources=[]
for k,u in urls.items():
 files=[S/(k+e) for e in ['.pdf','.html','-web.txt'] if (S/(k+e)).exists()]
 if not files:continue
 f=files[0]; pdf=f.suffix=='.pdf'; web=f.name.endswith('-web.txt'); txt=f if web else f.with_suffix('.txt')
 typ='manufacturer' if 'mgmotor.com.au' in u or k in ['im-au-launch-release','im-eu-launch'] else 'secondary' if 'carexpert' in u or 'chasingcars' in u or 'carsales' in u else 'dealer'
 pub='MG Motor Australia' if typ=='manufacturer' else 'CarExpert / JATO' if 'carexpert' in u else 'Chasing Cars' if 'chasingcars' in u else 'carsales' if 'carsales' in u else urllib.parse.urlparse(u).netloc
 if k=='im-eu-launch':pub='MG Motor Europe'
 note='Full source captured by permitted public download; accompanying text is an extraction of that file.' if not web else 'Public web-tool text extraction captured; direct full HTML download returned HTTP 403. Extraction may contain a subset of source lines; retrieval date is not its crawl date.'
 if k.endswith('-brochure'):note+=' Full current linked AU brochure explicitly says MY25 and content correct as of December 2025. That is month-precision content dating, not an invented publication day.'
 if k.endswith('-spec'):note+=' PDF file metadata is June 2025; older than December 2025 full brochure. No publication day is inferred from metadata.'
 if k=='im-eu-launch':note+=' European-market sibling evidence only; not Australian exact-version evidence.'
 if k=='im-au-launch-release':note+=' MG Australia original press-release PDF mirrored by an Australian publication; explicitly embargoed until 1 August 2025.'
 if k in ['im5-premium-waverley-web','im5-platinum-osborne-web','im6-performance-waverley-web']:note+=' Indexed dealer content is several weeks old; not admitted as fresh direct physical-stock verification.'
 sources.append({'key':k,'url':u,'title':({'im-eu-launch':'MG Europe: Introducing the new MG IM range','im-au-launch-release':'IM Presented by MG Motor Proudly Launches in Australia'}.get(k,k.replace('-',' ').title())),'publisher':pub,'source_type':typ,'published_date':'2025-07-10' if k=='im-eu-launch' else '2025-08-01' if k=='im-au-launch-release' else '2026-04-13' if k=='im6-carsales-review' else None,'accessed_date':DATE,'market':'EU' if k=='im-eu-launch' else 'AU','file':str(f),'textFile':str(txt) if txt.exists() else None,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size,'note':note})
sourcekeys={x['key'] for x in sources}
variants=[]
for c in B:
 if c['brand']!='IM':continue
 model=c['model'];m=model.lower();t=c['trim'];j=0 if t.startswith('Premium') else 1 if t.startswith('Platinum') else 2;per=j==2
 v={'id':c['id'],'brand':'IM','model':model,'trim':t,'modelYear':2025,'drive':'AWD' if per else 'RWD','metadata':{},'metadataReason':'Fresh current Australian maker model page and December 2025 brochure still explicitly identify MY25 technical scope. Dealer calendar/build year 2026 and third-party MY26 descriptors do not establish a distinct maker model year. Retain exact existing IM identity.','identitySourceKeys':[m+'-model',m+'-brochure',m+'-config'],'availability':{'state':'current_or_order_listed','buyerState':'On sale now','sourceKeys':[m+'-model',m+'-config','mg-offers'],'orderStatus':'accepting_order_requests_advertised','stockStatus':'unverified','qualifications':['Current official named-grade configurator and October offer establish an order/enquiry path. No accepted individual order, allocation, delivery date or physical stock is verified.','Dealer headings using 2026 are kept separate from maker MY25 technical scope; the finite inherited stock review is documented separately.'],'reason':'All three grades remain in each maker model comparison and live configurator, with valid 1–31 October 2026 named-grade offers.'},'facts':[],'features':[]}
 def fact(key,value,basis,comparison='',grade='confirmed',sources=None,qualifications=None,reason=None,condition=None,pointer=None,**extra):
  f={'key':key,'value':value,'sourceKeys':sources or [m+'-brochure'],'grade':grade,'basis':basis,'comparison':comparison,'reason':reason or 'Current linked Australian manufacturer brochure explicitly publishes this fact in the named grade column.','qualifications':qualifications or []}
  if condition:f['condition']=condition
  if pointer:f['sourcePointer']=pointer
  f.update(extra);v['facts'].append(f);return f
 p=[57990,64990,74990][j]
 offerq=['Offer for new vehicles sold and delivered 1–31 October 2026 at participating Australian dealers, while stocks last; excludes fleet, government and rental buyers.','Base configuration, no options; includes 12 months registration and CTP, maximum dealer delivery and estimated stamp duty.','Published amount already includes A$3,000 cashback. Do not subtract it twice. The optional A$500 accessory bonus may instead reduce purchase price at the buyer’s election; that election is not silently applied here.','A before-on-road maker RRP was not found in the current model page, brochure, offer or configurator. Crossed-out amounts are prior driveaway prices, not RRP.']
 for key in ['price_aud','advertised_driveaway_aud']+(['attributed_configurator_offer_aud'] if 'attributed_configurator_offer_aud' in c['facts'] else []):
  fact(key,p,'Maker national driveaway offer including A$3,000 cashback','Driveaway','check',['mg-offers',m+'-config'],offerq,'Current official national offers page names this exact grade and driveaway amount; select rung 2 ahead of a configurator or dealer advertisement.','Offer requires eligible new vehicle sold and delivered by 31 October 2026, participating dealer and remaining stock.',pointer=f'Offers > {model} {t.split()[0].upper()}; October offer terms; configurator exact variant option price',priceRung=2,basisTag="Maker's national driveaway offer",priceTag='National driveaway',rankingEligible=True,originalBasis='Driveaway price without any options applied; cashback included',validUntil='2026-10-31',offerDeadline='2026-10-31')
 ranges=([490,655,575] if m=='im5' else [450,555,505]);nedc=([550,755,625] if m=='im5' else [505,670,600]);boots=([457]*3 if m=='im5' else [665,665,646]);folds=([1290]*3 if m=='im5' else [1640,1640,1621]);acc=([6.8,4.9,3.2] if m=='im5' else [6.8,5.4,3.4]);dims=([4931,1960,1474] if m=='im5' else [4904,1988,1669]);mass=([2180,2210,2298] if m=='im5' else [2280,2320,2410])
 fact('range_km',ranges[j],'WLTP combined laboratory range','WLTP',sources=[m+'-brochure',m+'-model'],qualifications=['The separate 755 km IM5 marketing text corresponds to NEDC Platinum in the technical table; it is not used as WLTP.'] if m=='im5' else [],pointer='Brochure PDF page 19, Driving Range: WLTP Combined Cycle, exact grade column')
 fact('range_nedc_km',nedc[j],'NEDC combined laboratory range','NEDC',pointer='Brochure PDF page 19, Driving Range: NEDC Combined Cycle')
 fact('battery_kwh',[75,100,100][j],'Maker published battery capacity; gross/usable not specified','Published capacity, gross/usable unspecified',pointer='Brochure PDF page 19, Battery Capacity (kWh)')
 fact('battery_chemistry',['LFP','NCM','NCM'][j],'Maker battery chemistry','Battery chemistry')
 fact('battery_usable_kwh',None,'Usable battery energy not identified by maker','','not_published',[m+'-brochure',m+'-model'],reason='Searched current Australian full brochure and model-page specification table: advertised capacity is present but no usable/net energy is identified. Do not rename nominal capacity as usable.')
 fact('seats',5,'Australian standard seating capacity','Seats',pointer='Brochure PDF page 19, Seats, shared all-grade row')
 fact('dc_peak_kw',[153,396,396][j],'Manufacturer maximum vehicle DC charging power','DC kW',sources=[m+'-brochure',m+'-model'],qualifications=['This is the explicit vehicle maximum row. A 350 kW charger in charging-time footnotes is station power and is not substituted.'])
 if j==0:
  fact('dc_charge_time_min',None,'DC 10–80% time not published for this Australian 75 kWh version','DC 10–80%','not_published',[m+'-brochure',m+'-model'],reason='Searched current Australian brochure and model charging specifications: only 30–80% is specified. The IM5 owner handbook uses an undefined low-battery-alarm-to-80% interval. Neither establishes 10–80%; no conversion is made.')
 else:
  fact('dc_charge_time_min',17,'European 100 kWh IM5/IM6 sibling DC 10–80% claim; Australian exact-version time not published','DC 10–80%','reported',['im-eu-launch']+(['im5-chasingcars-review'] if m=='im5' and per else []),['European-market 100 kWh sibling figure only; the Australian maker publishes 15.2 minutes for 30–80%, a different window.','Not an Australian maker-certified 10–80% result; Reported and unranked.'],reason='MG Europe’s dated 10 July 2025 release explicitly gives 17 minutes from 10% to 80% for the IM range’s 100 kWh battery. Used only as clearly labelled foreign-sibling evidence; no arithmetic conversion of the Australian 30–80% time.',pointer='MG Europe release, Ultimate Performance paragraph',rankingEligible=False)
 fact('dc_charge_30_80_min',[20,15.2,15.2][j],'Manufacturer DC 30–80% test time','DC 30–80%','confirmed',[m+'-brochure',m+'-model'],['Exact 30–80% window retained separately; never placed in the canonical 10–80% field.','Model-page station caveat refers to a 350 kW ultra-fast charger; actual times depend on battery/charger conditions.'],pointer='Brochure PDF page 19, Estimated DC Charge Time (30% to 80%)')
 fact('ac_kw',11,'Maximum onboard AC charging power','AC kW')
 fact('charging_connector','CCS Type 2','Maker charge-port type','Connector type')
 fact('nominal_platform_volts',[400,800,800][j],'Maker platform voltage class','Platform volts',qualifications=['800 V is platform class; website separately describes operating capability up to 875 V.'])
 fact('boot_l',boots[j],'Rear boot with seats in place; VDA/SAE method not stated','Seats in place; measurement method unspecified',qualifications=['Seating position is explicit. No VDA/SAE method or load-height definition is supplied; do not merge with a standardized VDA/SAE group.'],pointer='Brochure PDF page 19, Boot Volume with Seats in Place (L)')
 fact('frunk_l',18 if m=='im5' else 32,'Separate front trunk; measurement method not stated','Front trunk, method unspecified',qualifications=['Separate from rear boot; not added to boot volume.'])
 fact('max_total_cargo_l',folds[j],'Rear boot with seats folded; excludes separate front trunk','Seats folded; measurement method unspecified',qualifications=['Inherited key names this max total cargo, but maker figure is rear boot with seats folded, not a sum of front and rear compartments.'])
 fact('zero_to_100_s',acc[j],'Manufacturer 0–100 km/h time including starting time','0–100 km/h',pointer='Brochure PDF page 19, Acceleration Time; page 21 footnote 2')
 fact('drive','AWD' if per else 'RWD','Maker driven wheels','Drive type',sources=[m+'-brochure',m+'-model'],qualifications=['IM6 Performance configurator hidden nvic driveTrain value incorrectly says RWD; visible named-grade description and AU brochure explicitly say AWD.'] if m=='im6' and per else [])
 if not per:
  fact('power_kw',[217,300][j],'Maximum output of the sole rear motor','Manufacturer maximum system output')
  fact('torque_nm',[450,500][j],'Maximum torque of the sole rear motor','Manufacturer maximum system torque')
 else:
  sec=[m+'-carexpert-list']+(['im6-carsales-review'] if m=='im6' else [])
  for key,value,units in [('power_kw',572,'kW'),('torque_nm',802,'Nm')]:
   fact(key,value,'Australian secondary-reported combined output; maker AU supplies motor components only','','reported',sec,['Current CarExpert/JATO Australian catalogue reports this combined value. It is not calculated here from motor components and is not ranked.','Chasing Cars reports 553 kW for IM5, while current CarExpert reports 572 kW; obtain an Australian delivered-build combined-output statement if this difference matters.'] if key=='power_kw' else ['Maker AU lists individual front/rear maxima; the combined figure here is explicitly a secondary report, not an assistant sum.'],reason='Current Australian secondary catalogue explicitly states the Performance combined figure; carsales also explicitly reports combined 572 kW/802 Nm for IM6. Maker component maxima remain separate.',rankingEligible=False)
  fact('motor_power_components_kw',{'front':200,'rear':372},'Individual motor maxima; not established simultaneous system output','Individual front/rear motor maxima')
  fact('motor_torque_components_nm',{'front':302,'rear':500},'Individual motor maxima; not established simultaneous system torque','Individual front/rear motor maxima')
 for key,num in zip(['length_mm','width_mm','height_mm'],dims):fact(key,num,'Manufacturer overall body dimension','Body mm',qualifications=['Mirror-inclusive width not specified.'] if key=='width_mm' else [])
 fact('wheelbase_mm',2950,'Wheelbase','Wheelbase mm')
 fact('ground_clearance_mm',135 if m=='im5' else 166,'Unladen running clearance','Unladen ground clearance mm',qualifications=['Distinct from the separately published gross/loaded clearance.'])
 fact('gross_ground_clearance_mm',([120,120,134] if m=='im5' else [145,145,164])[j],'Gross/loaded running clearance','Loaded ground clearance mm')
 fact('tare_weight_kg',mass[j],'Manufacturer tare mass','Tare mass')
 fact('kerb_weight_kg',None,'Kerb weight under a defined fuel/driver convention not explicitly published','','not_published',[m+'-brochure',m+'-spec'],reason='Both current Australian brochure and technical sheet label the mass as tare and unladen, not kerb under a defined convention. Preserve the published tare figure separately; do not silently relabel it.')
 fact('turning_radius_m',4.99 if m=='im5' else 5.09,'Maker stated turning radius with four-wheel steering','Turning radius m',pointer='Brochure driving dynamics section, turning radius')
 fact('turning_circle_m',None,'Explicit turning-circle diameter not published','','not_published',[m+'-brochure',m+'-model'],reason='Searched current maker brochure and model dynamics section: a radius is given, not a defined kerb-to-kerb or wall-to-wall turning-circle diameter. Radius remains separate; no unlabeled doubling is inserted.')
 fact('towing_braked_kg',1500,'Manufacturer maximum braked towing capacity','Braked towing kg')
 fact('towing_unbraked_kg',750,'Manufacturer maximum unbraked towing capacity','Unbraked towing kg')
 fact('speaker_count',20,'Manufacturer speaker count including four sky speakers','Speakers')
 fact('screen_inches',26.3,'Immersive touchscreen diagonal','Screen inches')
 fact('central_screen_inches',10.5,'Central touchscreen diagonal','Screen inches')
 # All retained researched equipment is re-expressed against fresh, exact supporting facts; generic build disclaimers are removed.
 equip={
 'driver_profiles_local':('Driver seat position memory and Easy Entry; broader driver profiles not established','Driver Seat Memory & Easy Entry, PDF page 20'),
 'front_heated_seats':('Heated front-seat cushions and backrests','Front Seats Heating and footnote 7, PDF pages 20–21'),
 'front_ventilated_seats':('Ventilated front-seat backrests only' if m=='im5' else 'Ventilated front-seat cushions and backrests','Front Seats Ventilation and footnote 7, PDF pages 20–21'),
 'rear_heated_seats':('Heated rear-seat cushions and backrests','Rear Seats Heating and footnote 7, PDF pages 20–21'),
 'heated_steering_wheel':('Heated steering wheel','Sporty Steering Wheel (Heating), PDF page 20'),
 'carplay_android_auto':('Wireless Apple CarPlay and Android Auto','Infotainment, PDF page 21'),
 'heat_pump':(f'{400 if j==0 else 800} V heat-pump dual-zone air conditioning','Climate Control, PDF page 20'),
 'parking_cameras':('360-degree HD camera','Safety, PDF page 19'),
 'glass_roof':('Double-glazed, thermally insulated panoramic glass roof','Interior, PDF page 20'),
 'power_tailgate':('Hands-free powered tailgate','Exterior, PDF page 20'),
 'wireless_charging':('Ventilated Qi wireless mobile charging pad, rated 50 W','Interior, PDF page 20'),
 'child_seats':('3 ISOFIX locations listed by the Australian manufacturer','Acoustic and seats, ISOFIX row, PDF page 20'),
 'dashcam':('Digital video recorder (DVR) listed','Infotainment, PDF page 21'),
 'charge_port_operation':('Powered charge-port cover with indicator light','Exterior, PDF page 20'),
 'folding_mirrors':('Power mirrors with automatic folding, memory, heating and reverse tilt-down','Exterior, PDF page 20'),
 'voice_assistant':('Voice control system listed','Infotainment, PDF page 21')}
 for criterion,(value,ptr) in equip.items():
  key=criterion+'_published';q=[]
  if criterion=='front_ventilated_seats' and m=='im5':q=['December 2025 full brochure footnote 7 explicitly limits ventilation to the backrest. The older June 2025 standalone sheet’s cushion-and-backrest wording is superseded for this claim.']
  if criterion=='driver_profiles_local':q=['Seat-position memory is established; no cloud transfer or multi-system driver-profile capability is inferred.']
  if criterion=='child_seats':q=['The table gives a count, not seating-location labels or a three-restraint fit test. Confirm restraint placement and fit.']
  fact(key,value,'Current Australian brochure standard equipment','',qualifications=q,pointer=ptr)
  v['features'].append({'criterion':criterion,'value':value,'keys':[key],'grade':'confirmed','conditions':' '.join(q),'reason':'Fresh review of the current exact-grade Australian brochure replaces retained generic build caveats and binds the equipment wording to the named supporting fact.'})
 fact('v2l_kw',6.6,'Maximum whole-vehicle V2L output','V2L kW',qualifications=['Actual external output depends on the external discharge device maximum; adaptor and socket limits can be lower.'],pointer='Brochure page 19 V2L row and page 21 footnote 4')
 v['features'].append({'criterion':'v2l','value':'V2L supported; maximum whole-vehicle output 6.6 kW','keys':['v2l_kw'],'grade':'check','conditions':'Actual external output depends on the discharge device or adaptor rating, which may be lower than the vehicle maximum.','reason':'Maker explicitly publishes V2L and whole-vehicle maximum with an actual output-device limitation.'})
 v['features'] += [
  {'criterion':'storage','value':f'{boots[j]} L rear boot with seats in place; {folds[j]} L with seats folded; separate {18 if m=="im5" else 32} L front trunk','keys':['boot_l','max_total_cargo_l','frunk_l'],'grade':'confirmed','conditions':'VDA/SAE measurement method not stated; separate rear and front capacities are not added.','reason':'Maker exact-grade rear seating position and separate front volume are explicit; inherited unknown storage answer is resolved.'},
  {'criterion':'home_charging','value':'Up to 11 kW onboard AC charging','keys':['ac_kw'],'grade':'confirmed','conditions':'Actual input also depends on the available AC supply and charging equipment.','reason':'Exact Australian onboard charger power, not station power.'},
  {'criterion':'screens_hud','value':'26.3-inch immersive touchscreen and 10.5-inch central touchscreen','keys':['screen_inches','central_screen_inches'],'grade':'confirmed','conditions':'These are two separate displays; no head-up display is inferred.','reason':'Two separately specified manufacturer displays.'},
  {'criterion':'audio_system','value':'20 speakers, including four sky speakers','keys':['speaker_count'],'grade':'confirmed','conditions':'','reason':'Exact manufacturer speaker count; no subjective sound-quality conclusion.'},
  {'criterion':'battery_chemistry','value':('LFP' if j==0 else 'NCM')+' battery chemistry','keys':['battery_chemistry'],'grade':'confirmed','conditions':'','reason':'Named-grade battery chemistry is explicitly listed.'}]
 # The V2L condition needs an identically qualified dependency, so retain device limit at fact level too.
 vf=next(f for f in v['facts'] if f['key']=='v2l_kw');vf.update(grade='check',condition='Actual external output depends on the external discharge device or adaptor rating.')
 if per:
  strength={'label':'AWD acceleration','text':f'All-wheel drive and a claimed {acc[j]}-second 0–100 km/h time give this version a clear performance focus.','keys':['drive','zero_to_100_s']}
 elif j==1:
  strength={'label':'Long-distance range','text':f'The {ranges[j]} km WLTP range provides more room between planned charging stops.','keys':['range_km']}
 else:
  strength={'label':'Five-seat practicality','text':f'Five seats and {boots[j]} litres of rear boot space with the seats in place support everyday passenger and luggage use.','keys':['seats','boot_l']}
 trade={'label':'Wide body','text':f'The {dims[1]:,} mm body width needs care in narrow bays and garages; mirror-inclusive width is not supplied.','keys':['width_mm']}
 v['summary']={'strength':strength,'tradeoff':trade}
 variants.append(v)
# Each inherited lead has one explicit terminal classification for this dated review.
res=[]
for x in old['specificNewStock']:
 if x['model'] not in ['IM5','IM6']:continue
 k=x['sourceId'];direct=(S/(k+'.html')).exists();my=x['formalModelYear']
 res.append({'leadId':x['id'],'sourceKey':k,'url':x['sourceUrl'],'model':x['model'],'trim':x['trim'],'stockNumber':x['stockNumber'],'vin':x['vin'],'advertisedYear':x['advertisedYear'],'formalModelYear':my,'classification':'current_grade_new_listing_epoch_unresolved' if direct else 'current_grade_MY25_indexed_listing_live_recheck_blocked','resolution':'Live dealer HTML still advertises New and this exact VIN/stock, but calendar/build 2026 and third-party MY26 do not prove the maker technical model-year join; no new version or MY25 equipment inheritance.' if direct else 'Indexed dealer extraction still says New and Model Year 25 for this exact VIN/stock; direct HTML returned 403 and current physical-stock availability is not reverified. It maps to an already-catalogued grade, not an extra model-year version.','stockEligible':False,'sourceCapture':str(S/(k+'.html')) if direct else str(S/(k+'-web.txt'))})
for x in old['rejectedStockEvidence']:
 if not ('im5' in str(x).lower() or 'im6' in str(x).lower()):continue
 k=x['sourceId'];demo='macarthur' in k
 res.append({'leadId':k,'sourceKey':k,'url':x['url'],'classification':'demonstrator_excluded' if demo else 'sold_excluded','resolution':'Fresh direct dealer index lists only a demo unit; no cached New status used.' if demo else 'Fresh direct dealer HTML still explicitly says SOLD / recently sold.','stockEligible':False,'sourceCapture':str(S/(k+'.html'))})
closure={'IM5':['Premium RWD','Platinum RWD','Performance AWD'],'IM6':['Premium RWD','Platinum RWD','Performance AWD']}
conflicts=[
 {'subject':'IM5 range','resolution':'755 km unqualified marketing line is NEDC Platinum in the exact technical table; canonical WLTP uses 490/655/575 km, supported by brochure plus exact-grade model table.','sourceKeys':['im5-model','im5-brochure']},
 {'subject':'IM5 front ventilation coverage','resolution':'December 2025 full brochure restricts ventilation to front backrests; supersedes June 2025 technical sheet stating cushions and backrests. Standard ventilation remains Confirmed with the narrower current description.','sourceKeys':['im5-brochure','im5-spec','im5-chasingcars-review']},
 {'subject':'Performance system output','resolution':'Maker AU publishes 200/372 kW front/rear and 302/500 Nm front/rear, not simultaneous combined maxima. Current AU CarExpert catalogue 572 kW/802 Nm is Reported unranked; carsales explicitly corroborates combined values for IM6. Chasing Cars 553 kW IM5 report is retained as a disclosed discrepancy. No component arithmetic is used.','sourceKeys':['im5-brochure','im6-brochure','im5-carexpert-list','im6-carexpert-list','im6-carsales-review','im5-chasingcars-review']},
 {'subject':'DC charging windows','resolution':'Maker 30–80% 20/15.2 min moved to separate fact. Canonical 10–80% is null Not published for 75 kWh; 100 kWh 17 min is explicitly foreign-sibling Reported and unranked, sourced from dated MG Europe and supported by AU review for IM5 Performance. Owner-handbook alarm-to-80 time is not silently treated as 10–80.','sourceKeys':['im5-brochure','im6-brochure','im-eu-launch','im5-chasingcars-review','im5-au-owner-manual']},
 {'subject':'IM6 Performance configurator hidden drive type','resolution':'Hidden nvic descriptor says RWD, contrary to visible configurator all-wheel drive and exact AU brochure. Retain AWD from visible authoritative technical rows.','sourceKeys':['im6-config','im6-brochure']},
 {'subject':'Platinum air suspension option','resolution':'Current configurator explicitly allows optional air suspension/CCD on Platinum: IM5 A$3,990; IM6 A$4,990. Standard technical columns show it absent on Platinum and present on Performance. This is an option, not an additional named grade. No arbitrary new trim or blanket standard-fit claim.','sourceKeys':['im5-config','im6-config','im5-brochure','im6-brochure']}]
out={'reviewedAt':DATE,'familyScope':['IM5','IM6'],'sources':sources,'variants':variants,'warrantyHandling':{'delegateToParent':True,'sharedCoreFacts':['warranty','battery_warranty','roadside_assistance'],'note':'All six exact identities remain brand IM. Parent must apply IM-specific AU policy, not generic MG warranty. Current AU secondary review flags 5-year basic / 7-year service-activated vehicle cover, 8-year / 160,000 km battery and 5-year air-suspension/four-wheel-steering warranty; verify original current maker terms before integration.'},'familyClosure':closure,'familyReconciliation':{'makerSourceKeys':['im5-model','im6-model','im5-config','im6-config','mg-offers'],'independentSourceKeys':['im5-carexpert-list','im6-carexpert-list'],'result':'Fresh direct web-tool CarExpert catalogue lists all 3 grades for each family, matching official current maker. Earlier search index omission of IM5 Premium is superseded by reopened direct catalogue.','yearDifference':'Secondary catalogue and dealer sales headings say 2026. Current AU maker technical publications explicitly scope MY25; do not manufacture additional MY26 rows without maker identity evidence.','newVariants':[],'optionalPackages':'Platinum air-suspension upgrades are separately configurable options, not additional named versions.','scopeLimit':'Finite review of all 10 inherited IM leads: 6 prior new-stock candidates and 4 exclusions. Not an unbounded national dealer inventory census.','residualClassifications':res},'conflicts':conflicts,'captureLimitations':['All currentAU maker pages, offers, configurators, full brochures and technical PDFs were saved in full.','Several dealer and secondary origins returned HTTP 403 for direct HTML downloads. Permitted public web-tool text extracts were captured where available and identified as such; none masquerades as full HTML.','UK brochures and direct EU/UK HTML downloads returned 403. The accessible official EU release was captured completely through the web extraction; used only as labelled foreign-sibling charging evidence.'],'coreReview':'Each variant includes 15 vehicle/price core fields; vehicle and battery warranties are explicitly delegated to parent shared IM terms, completing the 17-field requirement at integration.'}
for v in variants:
 fs={x['key']:x for x in v['facts']};assert len(fs)==len(v['facts'])
 for f in v['facts']:
  assert set(f['sourceKeys'])<=sourcekeys,(v['id'],f['key'],f['sourceKeys'],sourcekeys)
  if f['grade']=='not_published':assert f['value'] is None and len({next(s['url'] for s in sources if s['key']==k) for k in f['sourceKeys']})>=2
 for f in v['features']:
  assert all(k in fs for k in f['keys'])
  assert any(b['variant_id']==v['id'] and b['criterion']==f['criterion'] for b in F)
 for c in v['summary'].values():assert all(k in fs for k in c['keys'])
(P/'normalized-evidence.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
manifest=[{'path':str(f.relative_to(P)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(S.iterdir()) if f.is_file()]
(P/'source-manifest.json').write_text(json.dumps({'checkedAt':DATE,'files':manifest},indent=2)+'\n')
print('sources',len(sources),'variants',len(variants),'facts',sum(len(v['facts']) for v in variants),'features',sum(len(v['features']) for v in variants),'residual',len(res))
