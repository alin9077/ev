import httpx,pathlib,hashlib,subprocess,json,concurrent.futures
from lxml import html
P=pathlib.Path('/tmp/mg-im-research/mg4/sources');P.mkdir(exist_ok=True,parents=True)
URLS={'brochure':'https://mgmotor.com.au/brochures/MG4_EV_2026_V2.pdf','urban-brochure':'https://mgmotor.com.au/brochures/MG4_EV_URBAN_2026.pdf','product':'https://mgmotor.com.au/vehicles/mg4-ev','urban-product':'https://mgmotor.com.au/vehicles/mg4-ev-urban','offers':'https://mgmotor.com.au/offers','config':'https://mgmotor.com.au/configurator/mg4-ev','urban-config':'https://mgmotor.com.au/configurator/mg4-ev-urban'}
def capture(t):
 k,u=t
 try:
  rdata=subprocess.run(['curl','-L','--max-time','90','-sS',u],capture_output=True,check=True).stdout
  class R:pass
  r=R();r.content=rdata;r.text=rdata.decode('utf-8',errors='replace');r.status_code=None
  ext='pdf' if '.pdf' in u else 'html';f=P/(k+'.'+ext);f.write_bytes(r.content);tf=P/(k+'.txt')
  if ext=='pdf':subprocess.run(['pdftotext','-layout',str(f),str(tf)],check=True)
  else:
   h=html.fromstring(r.text)
   for n in h.xpath('//script|//style'):n.getparent().remove(n)
   tf.write_text('\n'.join(x.strip() for x in h.xpath('//text()') if x.strip()))
  return {'key':'mg4-'+k,'url':u,'file':str(f),'textFile':str(tf),'sha256':hashlib.sha256(r.content).hexdigest(),'textSha256':hashlib.sha256(tf.read_bytes()).hexdigest(),'status':r.status_code}
 except Exception as e:return {'key':'mg4-'+k,'url':u,'error':str(e)}
if __name__=='__main__':
 m=list(concurrent.futures.ThreadPoolExecutor().map(capture,URLS.items()));json.dump(m,open('/tmp/mg-im-research/mg4/captures.json','w'),indent=2);print(json.dumps(m))
