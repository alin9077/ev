import sys,json,concurrent.futures
sys.path.insert(0,'/tmp/mg-im-research/mg4');from capture import capture
x=json.load(open('/workspace/scratch/586427eef9f2/roadmark-104/data/mg4-evidence-2026-10-10.json')); urls={}
for i,c in enumerate(x['outgoingCandidates']):urls['residual-'+str(i)]=c['unverifiedStockLead']['url']
for i,c in enumerate(x['rejectedStockEvidence']):urls['rejected-'+str(i)]=c['url']
for s in x['sources']:
 if s['id'].startswith(('qauto','westpoint')):urls[s['id']]=s['url']
r=list(concurrent.futures.ThreadPoolExecutor(max_workers=8).map(capture,urls.items()));json.dump(r,open('/tmp/mg-im-research/mg4/lead-captures.json','w'),indent=2);print(json.dumps(r))
