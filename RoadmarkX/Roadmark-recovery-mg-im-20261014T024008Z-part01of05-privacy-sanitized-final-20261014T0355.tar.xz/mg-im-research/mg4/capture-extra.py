import sys,json,concurrent.futures
sys.path.insert(0,'/tmp/mg-im-research/mg4');from capture import capture
urls={'ce-current':'https://origin.carexpert.com.au/car-news/2026-mg-4-ev-price-and-specs','ce-urban':'https://origin.carexpert.com.au/car-news/2026-mg-4-ev-urban-price-and-specs','nrma-urban':'https://jss.sitecore.prod.svc.mynrma.com.au/open-road/car-reviews/mg/2026-mg4-ev-urban-review','cs-new':'https://www.carsales.com.au/cars/new/mg/mg4/'}
r=list(concurrent.futures.ThreadPoolExecutor(max_workers=4).map(capture,urls.items()));json.dump(r,open('/tmp/mg-im-research/mg4/extra-captures.json','w'),indent=2);print(json.dumps(r))
