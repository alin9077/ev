import json,pathlib,hashlib
B=pathlib.Path('/tmp/mazda-research')
def r(n):return json.loads((B/n).read_text())
def w(n,j):(B/n).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
j=r('normalized-review-v1.json');j['schema']='mazda-normalized-research-review-v2';j['previousVersion']=str(B/'normalized-review-v1.json')
for v in j['variants']:
 gt=v['trim']=='E35 GT'; cx=v['model']=='CX-6e';f=v['coreFacts']['price_aud'];p=v['priceLadderReview'];build='au-cx6e-build' if cx else 'au-6e-build'
 f['priceEvidence']['rung']=3 if gt else 4
 if gt:
  f['basis']='Maker driveaway from';f['sourceKeys']=['au-offers',build];f['locator']='Electric Vehicle Driveaway Offers exact E35 GT card; state-specific corroboration in configurator exact grade price/1'
  f['priceEvidence'].update(basisTag='Maker driveaway from',sourcePointer=f'au-offers.txt#Mazda-{v["model"]}-E35-GT',originalBasis='Driveaway from; exact GT offer card, premium paint excluded')
  f['qualifications'][0]='The public exact-GT offer card gives this driveaway-from amount; not claimed nationally. Configurator corroborates it for NSW, ACT, NT, QLD, SA, TAS and VIC; WA is A$1,000 higher. No personalized quote.'
  p['candidates'][0].update(sourceKey='au-offers',reason='Separate current public offer card explicitly names E35 GT and Driveaway from. State-specific corroboration retained; no national-price inference.')
 else:
  f['basis']='Maker NSW driveaway from';f['priceEvidence']['basisTag']='Maker NSW driveaway from'
  p['candidates']=[a for a in p['candidates'] if a['rung']!=3]
  p['candidates'][0]['reason']='Exact-grade state-specific maker driveaway-from offer. No higher-rung exact-grade public from offer or national price established.'
 p['selectedRung']=3 if gt else 4
 p['reason']='Separate public named-GT from offer is rung 3; state configurator is rung 4; unknown-basis MLP is not rung 1.' if gt else 'Exact named-version state driveaway-from amount is rung 4. Generic GT offer cannot be applied to this higher grade. Unknown-basis MLP is not rung 1.'
 if cx:
  v['availability']['recordState']='announced_provisional'
  v['availability']['beforeRecordState']='current_or_order_listed'
  v['availability']['classificationReason']='Fresh current maker hub and model page explicitly say coming soon / preorder; retain exact preorder semantics and remove the legacy on-sale denominator classification. Separate New Azami advertisement does not verify model-wide current sale or physical stock.'
j['reviewNotes']=[s for s in j['reviewNotes'] if 'prices chosen' not in s and 'validator enum' not in s]
j['reviewNotes']+=['Two separate GT public Driveaway from offers are selected at rung 3. Exact state-specific configurator prices for Atenza/Azami are rung 4, tagged NSW; MLP stays supplemental and is not rung 1.','Proposed narrow preorder enum allowance preserves evidence/source/date guards and existing buyer mapping. Both CX-6e states change current_or_order_listed to announced_provisional with preorder; provisional expected global on-sale count 305 to 303, while catalogue total stays 413 and C1 current-list eligibility remains.']
j['censusPath']=str(B/'census-review-v2.json');j['conflictsPath']=str(B/'conflicts-review-v2.json')
w('normalized-review-v2.json',j)
c=r('census-review-v1.json');c['availabilityCorrection']={'variantIds':[v['id'] for v in j['variants'][2:]],'before':'current_or_order_listed + preorder','after':'announced_provisional + preorder','expectedOnSaleDelta':-2,'currentListC1':'remain eligible from explicit fresh preorder evidence'};w('census-review-v2.json',c)
c=r('conflicts-review-v1.json');c['conflicts'][-1]['decision']='Visible supplemental official MLP observations, no before-on-road inference and no rung 1. Separate public exact-GT Driveaway from offers are rung 3. Higher-grade exact state driveaway-from configurator offers are rung 4, tagged NSW.';w('conflicts-review-v2.json',c)
p=B/'RESEARCH-REVIEW-v1.md';s=p.read_text().replace('Exact maker configurator/from prices satisfy rung 3, tagged NSW.','Separate exact-GT public Driveaway from offers satisfy rung 3; exact state driveaway-from Atenza/Azami configurator totals are rung 4, tagged NSW.').replace('1. Accept current-price rung 3 with exact state tag; unknown-basis MLP stays supplemental.','1. Select the distinct GT public from offers at rung 3 and the higher-grade state configurator offers at rung 4; unknown-basis MLP stays supplemental.').replace('Retain the still-fresh snapshot or authorize a narrow enum behavior change; do not silently make the cars on sale.','Propose a narrow enum allowance plus announced_provisional + preorder after states. The buyer label stays Order open or arriving; these two leave the legacy on-sale denominator (expected 305 to 303), remain in C1, and never imply accepted factory orders.');(B/'RESEARCH-REVIEW-v2.md').write_text(s)
manifest={'checkedAt':'2026-10-15','status':'normalized_frozen_for_independent_review','artifacts':[{'path':str(B/n),'bytes':(B/n).stat().st_size,'sha256':hashlib.sha256((B/n).read_bytes()).hexdigest()} for n in ['normalized-review-v2.json','census-review-v2.json','source-index-review-v1.json','conflicts-review-v2.json','RESEARCH-REVIEW-v2.md']],'coreFields':68,'gradeCounts':j['gradeCounts'],'liveEdits':False};w('review-freeze-v2.json',manifest);print(json.dumps(manifest,indent=2))
