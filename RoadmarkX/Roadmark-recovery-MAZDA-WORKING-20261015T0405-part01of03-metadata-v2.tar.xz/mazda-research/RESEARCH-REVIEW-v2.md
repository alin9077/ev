# Mazda M1 research, 15 October 2026

## Buyer changes proposed
- Refresh four existing current maker versions: Mazda 6e E35 GT/Atenza and CX-6e E35 GT/Azami. No added version.
- Exact NSW configurator driveaway-from prices: A$52,990 / A$55,990 / A$56,990 / A$59,990. WA is A$1,000 higher; paid paint/interior extras and personal conditions remain visible.
- Fill all 17 core fields using 48 Confirmed, 16 Check and four Reported observations. Labelled boot figures stay visible; conflicting source observations remain unranked.
- Keep CX-6e explicitly preorder, one Azami New advertisement separate, and the unresolved residual MX-30 question open. No physical possession or fulfilled delivery inferred.

## Evidence and decisions
The exact current lists are supported by Australian model pages, configurator JSON and current linked July/August brochures. Two independent Mazda brand lists are checked; they do not close whole-market C1. Unknown-basis maker MLP is supplemental, never rung 1. Separate exact-GT public Driveaway from offers satisfy rung 3; exact state driveaway-from Atenza/Azami configurator totals are rung 4, tagged NSW. Current maker 8-year/160,000 km battery badge is freshly captured and visually inspected.

Boot: 6e brochure 337 L VDA versus website 336 L unspecified; CX-6e brochure 363 L VDA versus website 468 L unspecified. Show both, hold numeric ranking. 6e 1,500 kg braked towing has an unmatched brochure footnote and remains unranked. CX-6e explicitly requires Mazda Genuine Towing Kit; its 1,500 kg claim can be grouped as braked towing with that condition. Height uses a 75 kg driver, not unladen height. Azami 0–100 km/h is Reported 8.1 s by The Driven; CarsGuide says 7.9 s and the conflict is retained.

The four selected before rows were streamed from accepted derived storage and verified; this is not a fresh full-catalogue export. No live repository edit, full catalogue hydration, full test, build or publication has run. A narrow packet and selected actual-function preflight are still required after review.

## Review points
1. Select the distinct GT public from offers at rung 3 and the higher-grade state configurator offers at rung 4; unknown-basis MLP stays supplemental.
2. Accept visible source-labelled boot values while preserving conflicts and ranking holds.
3. Resolve CX-6e preorder refresh: current correction validator excludes preorder in after snapshots despite existing valid preorder records. Propose a narrow enum allowance plus announced_provisional + preorder after states. The buyer label stays Order open or arriving; these two leave the legacy on-sale denominator (expected 305 to 303), remain in C1, and never imply accepted factory orders.
4. Preserve original source records and sanitize eight early receipt copies before backup; the new source index contains no response headers.

M1 continues. M2 and release validation remain outside this research step.
