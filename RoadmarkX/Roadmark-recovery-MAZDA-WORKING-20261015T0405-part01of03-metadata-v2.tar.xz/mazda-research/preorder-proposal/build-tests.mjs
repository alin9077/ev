import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
const repo='/workspace/scratch/586427eef9f2/roadmark-104';
const base='/tmp/mazda-research/preorder-proposal';
const require=createRequire(repo+'/package.json');
const esbuild=require('esbuild');
const entry=`export * from ${JSON.stringify(repo+'/src/lib/availability-corrections.ts')}; export {buyerAvailability,buyerAvailabilityText} from ${JSON.stringify(repo+'/src/lib/buyer-availability.ts')}; export {isOnSale,isCurrentListEligible} from ${JSON.stringify(repo+'/scripts/reporting/reports.ts')};`;
for (const mode of ['original','candidate']) {
 const plugins=mode==='candidate'?[{name:'proposed-preorder-only',setup(build){build.onLoad({filter:/\/src\/lib\/availability-corrections\.ts$/},args=>({contents:fs.readFileSync(base+'/availability-corrections.proposed.ts','utf8'),loader:'ts',resolveDir:path.dirname(args.path)}));}}]:[];
 await esbuild.build({stdin:{contents:entry,resolveDir:repo,sourcefile:'preorder-tests-entry.ts',loader:'ts'},outfile:base+'/output/'+mode+'.mjs',bundle:true,platform:'node',format:'esm',plugins,logLevel:'warning'});
}
