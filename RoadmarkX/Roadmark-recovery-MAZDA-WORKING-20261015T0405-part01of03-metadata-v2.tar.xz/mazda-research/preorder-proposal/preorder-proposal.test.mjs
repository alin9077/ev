import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as proposed from './output/candidate.mjs';
import * as original from './output/original.mjs';
const cars=JSON.parse(fs.readFileSync('/tmp/mazda-research/retained-before-cars.json','utf8'));
const cx=cars.filter(c=>c.model==='CX-6e');
const source={id:'qa-current-maker-preorder',url:'https://www.mazda.com.au/electric/battery-electric/',title:'Mazda Australia current BEV range',publisher:'Mazda Australia',source_type:'manufacturer_primary',published_date:null,accessed_date:'2026-10-15',market:'AU',supports:'Explicit CX-6e coming soon and open for pre-order; no factory acceptance or stock verification.'};
const clone=x=>structuredClone(x);
function edit(car=cx[0]) {return {id:'qa-guarded-preorder-refresh-'+car.id,variantId:car.id,before:proposed.availabilitySnapshot(car),after:{availability:'announced_provisional',evidence:{...clone(car.availabilityEvidence),checkedAt:'2026-10-15',orderStatus:'preorder',sourceIds:[source.id],physicalStockVerified:false,factoryOrderAcceptanceVerified:false,qualifications:['Current Australian maker advertises CX-6e open for pre-order; enquiry is not an accepted factory order.','Historical September delivery forecast is not proof of arrival.']}},status:'approved',reviewedBy:'Proposal behavior fixture only',reviewedAt:'2026-10-15',evidenceDate:'2026-10-15',reason:'Test proposed exact source-supported preorder refresh without changing buyer/report policy.'};}
function apply(e=edit(),sources=[source],input=cars){return proposed.applyAvailabilityCorrections(input,[e],sources);}
test('current validator reproduces the exact preorder after-snapshot gap',()=>{assert.throws(()=>original.applyAvailabilityCorrections(cars,[edit()],[source]),/invalid status or qualifications/);});
test('real CX-6e preorder refresh preserves buyer meaning, C1 evidence and all nonavailability data',()=>{
 const before=clone(cars);const edits=cx.map(edit);const changed=proposed.applyAvailabilityCorrections(cars,edits,[source]);
 for(const car of changed.filter(c=>c.model==='CX-6e')){
  assert.equal(car.availability,'announced_provisional');assert.equal(car.availabilityEvidence.orderStatus,'preorder');
  assert.equal(proposed.buyerAvailability(car),'order_open_or_arriving');assert.equal(proposed.buyerAvailabilityText(car),'Order open or arriving');
  assert.equal(proposed.isOnSale(car),false);assert.equal(proposed.isCurrentListEligible(car,[source],'2026-10-15'),true);
  assert.equal(car.availabilityEvidence.physicalStockVerified,false);assert.equal(car.availabilityEvidence.factoryOrderAcceptanceVerified,false);
  const prior=cars.find(c=>c.id===car.id);assert.deepEqual(car.facts,prior.facts);assert.deepEqual(car.configurationEvidence,prior.configurationEvidence);assert.equal(car.year,null);
  assert.equal(proposed.buyerAvailabilityText(prior),'Order open or arriving');assert.equal(proposed.isOnSale(prior),true);
 }
 assert.equal(changed.filter(proposed.isOnSale).length,cars.filter(proposed.isOnSale).length-2);assert.deepEqual(cars,before);
 assert.deepEqual(changed.filter(c=>c.model!=='CX-6e'),cars.filter(c=>c.model!=='CX-6e'));
});
test('preorder cannot bypass identity, exact before snapshot or source guards',()=>{
 for(const e of [{...edit(),variantId:'missing'},{...edit(),before:{...edit().before,availability:'not_current'}}])assert.throws(()=>apply(e),/conflict/);
 const missing=edit();missing.after.evidence.sourceIds=[];assert.throws(()=>apply(missing),/supporting sources/);
 assert.throws(()=>apply(edit(),[]),/supporting sources/);
 for(const extra of [{accessed_date:'2026-07-01'},{accessed_date:'2026-10-16'},{url:'javascript:alert(1)'},{access_limitation:'blocked'},{conflict:'unresolved'},{publication_hold:true}])assert.throws(()=>apply(edit(),[{...source,...extra}]),/supporting sources/);
 assert.throws(()=>apply(edit(),[source,source]),/supporting sources/);
});
test('preorder retains approval, evidence-date and chronology validation',()=>{
 for(const change of [{reviewedBy:''},{reason:''},{evidenceDate:'2026-02-30'},{evidenceDate:'2026-10-14'},{reviewedAt:'2026-10-14'},{supersedes:'nonexistent'}])assert.throws(()=>apply({...edit(),...change}),/provenance|chronology/);
 for(const status of ['pending','rejected'])assert.deepEqual(apply({...edit(),status},[]),cars);
 const invalid=edit();invalid.after.evidence.orderStatus='invented_preorder_status';assert.throws(()=>apply(invalid),/invalid status/);
 const contradiction=edit();contradiction.after.availability='not_current';assert.throws(()=>apply(contradiction),/contradictory eligibility/);
});
test('existing allowed statuses and mapping are unchanged',()=>{
 for(const status of ['listed_unconfirmed','accepting_orders','accepting_orders_advertised','accepting_order_requests_advertised','not_accepting_orders','unverified']){
  const e=edit();e.after.evidence.orderStatus=status;
  const a=apply(e);const b=original.applyAvailabilityCorrections(cars,[e],[source]);assert.deepEqual(a,b);
  assert.equal(proposed.buyerAvailabilityText(a[2]),original.buyerAvailabilityText(b[2]));assert.equal(proposed.isOnSale(a[2]),original.isOnSale(b[2]));
 }
});
