// src/lib/config.ts
function publicOrigin(value) {
  if (!value) return null;
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" || url.username || url.password || url.pathname !== "/" || url.search || url.hash || /^(localhost|127\.|0\.|\[::1\])/.test(url.hostname) || url.hostname.endsWith(".local"))
      return null;
    return url.origin;
  } catch {
    return null;
  }
}
var publishedOrigin = publicOrigin(process.env.NEXT_PUBLIC_SITE_URL);
var availabilityLabels = {
  not_current: "Not currently available",
  current_or_order_listed: "Current listing",
  outgoing: "Older / outgoing version",
  announced_provisional: "Announced / provisional"
};
function safeUrl(input) {
  try {
    const url = new URL(input);
    return ["https:", "http:"].includes(url.protocol) && !url.username && !url.password ? url.href : null;
  } catch {
    return null;
  }
}

// src/lib/corrections.ts
function validDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = /* @__PURE__ */ new Date(`${value}T00:00:00Z`);
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

// src/lib/freshness.ts
var day = 864e5;
function evidenceDateValue(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return NaN;
  const parsed = Date.parse(`${value}T00:00:00Z`);
  return Number.isFinite(parsed) && new Date(parsed).toISOString().slice(0, 10) === value ? parsed : NaN;
}
function freshnessWindowDays(key) {
  const name = key.replace(/([a-z])([A-Z])/g, "$1_$2").toLowerCase();
  if (/(^|_)(price|offer|offers|availability|stock|order_status|driveaway|rrp|msrp|mlp|mrlp)(_|$)/.test(
    name
  ))
    return 45;
  if (/(^|_)equipment(_|$)/.test(name)) return 180;
  if (/(^|_)(cargo_(openluggagecompartmenttoseattop|largestluggagecompartment|behind_(first|second|third)_row|(rear|front|total)_vda|seats_(up|down|folded)|minimum|maximum|method|measurement)|luggage_(minimum|maximum)|passenger_volume|euro_pallet_capacity)(_|$)/.test(
    name
  ))
    return 365;
  if (/(^|_)(overhang|front_track|rear_track|track_mm|head_?room|leg_?room|shoulder_?room|hip_?room|road_clearance|trail|between_wheelarches|floor_to_roof)(_|$)/.test(
    name
  ))
    return 365;
  if (/(^|_)(seated_count|seating_layout|fit_seating|technical_seating_claim)(_|$)/.test(
    name
  ))
    return 365;
  if (/^(source_.*|option_\d+)_seats$/.test(name) && !/(^|_)(heated|ventilated|power|powered|relaxation|massage|memory|leather|cloth)(_|$)/.test(
    name
  ))
    return 365;
  if (/(^|_)(cargo|boot|frunk|luggage|storage|tub)(_|$)/.test(name) && /(^|_)(volume|litres|liters|l|m3)(_|$)/.test(name))
    return 365;
  if (/(^|_)(seat_count|seating_capacity|seating_positions|passenger_capacity|seated_passengers|standing_passengers|driver_seats|passenger_seats)(_|$)/.test(
    name
  ))
    return 365;
  if (/(warranty|roadside|dimension|wheelbase|towball|towing|(^|_)tow(_|$))/.test(
    name
  ))
    return 365;
  if (/(^|_)(length|width|height|depth|ground_clearance|turning_circle|turning_radius|turning_diameter|track_front|track_rear|boot|frunk|cargo_volume|cargo_capacity|luggage_volume|storage_litres)(_|$)/.test(
    name
  ))
    return 365;
  if (/^(source_)?(seats|seat_count|seating_capacity|seating_positions|passenger_capacity|model_year|year)(_|$)/.test(
    name
  ))
    return 365;
  return 180;
}
function evidenceAgeDays(checkedAt, asOf) {
  const age = (evidenceDateValue(asOf) - evidenceDateValue(checkedAt)) / day;
  return Number.isFinite(age) ? age : null;
}
function evidenceFreshness(checkedAt, key, asOf, modelYearChanged = false) {
  const windowDays = freshnessWindowDays(key);
  const ageDays = evidenceAgeDays(checkedAt, asOf);
  const date = evidenceDateValue(checkedAt);
  const fresh = ageDays !== null && ageDays >= 0 && ageDays <= windowDays && !(windowDays === 365 && modelYearChanged);
  return {
    fresh,
    ageDays,
    windowDays,
    expiresOn: Number.isFinite(date) ? new Date(date + windowDays * day).toISOString().slice(0, 10) : null,
    staleOn: Number.isFinite(date) ? new Date(date + (windowDays + 1) * day).toISOString().slice(0, 10) : null
  };
}

// src/lib/correction-guards.ts
var nonemptyReviewText = (value) => typeof value === "string" && !!value.trim();
function canonical(value, parents = /* @__PURE__ */ new Set()) {
  if (value === null || typeof value === "string" || typeof value === "boolean")
    return value;
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (!value || typeof value !== "object" || parents.has(value))
    throw new Error("Invalid reviewed state: finite acyclic JSON required");
  if (!Array.isArray(value) && ![Object.prototype, null].includes(Object.getPrototypeOf(value)))
    throw new Error("Invalid reviewed state: plain JSON objects required");
  parents.add(value);
  let result;
  if (Array.isArray(value)) {
    if (Object.keys(value).length !== value.length || Array.from({ length: value.length }, (_, i) => i).some(
      (i) => !Object.hasOwn(value, i)
    ))
      throw new Error("Invalid reviewed state: dense JSON arrays required");
    result = value.map((part) => canonical(part, parents));
  } else {
    result = Object.fromEntries(
      Object.entries(value).filter(([, part]) => part !== void 0).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([key, part]) => [key, canonical(part, parents)])
    );
  }
  parents.delete(value);
  return result;
}
var sameReviewedState = (a, b) => JSON.stringify(canonical(a)) === JSON.stringify(canonical(b));
function assertReviewedJson(value) {
  canonical(value);
}
function usableCorrectionSources(ids, sources, reviewedAt, evidenceDate) {
  return Array.isArray(ids) && ids.length > 0 && new Set(ids).size === ids.length && Array.from(ids).every((id) => {
    if (!nonemptyReviewText(id)) return false;
    const matches = sources.filter((source2) => source2.id === id);
    if (matches.length !== 1) return false;
    const source = matches[0];
    return !!safeUrl(source.url) && validDate(source.accessed_date) && source.accessed_date <= reviewedAt && (!evidenceDate || Date.parse(evidenceDate) - Date.parse(source.accessed_date) <= freshnessWindowDays("availability") * 864e5) && !source.access_limitation && !source.conflict && !source.publication_hold;
  });
}

// src/lib/availability-corrections.ts
function orderEvidenceText(status) {
  if (status === "accepting_order_requests_advertised")
    return "Order requests are advertised; acceptance and delivery need confirmation.";
  if (["accepting_orders", "accepting_orders_advertised"].includes(status))
    return "Orders advertised as open.";
  if (status === "not_accepting_orders")
    return "New factory orders are not currently advertised as open.";
  return "Factory-order acceptance has not been confirmed.";
}
function availabilitySnapshot(car) {
  return {
    availability: car.availability,
    evidence: structuredClone(
      car.availabilityEvidence || {
        checkedAt: "",
        orderStatus: "unverified",
        stockStatus: "unverified",
        sourceIds: []
      }
    )
  };
}
function applyAvailabilityCorrections(cars, edits, sources) {
  const result = cars.map((c) => ({ ...c }));
  const seen = /* @__PURE__ */ new Set();
  const last = /* @__PURE__ */ new Map();
  for (const edit of edits) {
    if (edit.status !== "approved") continue;
    if (!nonemptyReviewText(edit.id) || seen.has(edit.id))
      throw new Error("Invalid or duplicate availability correction ID");
    seen.add(edit.id);
    const i = result.findIndex((c) => c.id === edit.variantId);
    if (cars.filter((car) => car.id === edit.variantId).length !== 1 || i < 0 || !sameReviewedState(availabilitySnapshot(result[i]), edit.before))
      throw new Error(
        `Availability correction conflict ${edit.id}: reviewed snapshot changed or variant missing`
      );
    const prior = last.get(edit.variantId);
    if (edit.supersedes !== prior?.id || prior && edit.reviewedAt < prior.reviewedAt)
      throw new Error(
        `Availability correction ${edit.id} has invalid predecessor or review chronology`
      );
    assertReviewedJson(edit.after);
    const e = edit.after.evidence;
    if (!nonemptyReviewText(edit.reviewedBy) || !nonemptyReviewText(edit.reason) || !validDate(edit.reviewedAt) || !validDate(edit.evidenceDate) || edit.evidenceDate > edit.reviewedAt || !validDate(e.checkedAt) || e.checkedAt !== edit.evidenceDate)
      throw new Error(
        `Availability correction ${edit.id} lacks review provenance`
      );
    if (!Object.hasOwn(availabilityLabels, edit.after.availability) || ![
      "listed_unconfirmed",
      "preorder",
      "accepting_orders",
      "accepting_orders_advertised",
      "accepting_order_requests_advertised",
      "not_accepting_orders",
      "unverified"
    ].includes(e.orderStatus) || !["new_stock_listed", "no_new_stock_verified", "unverified"].includes(
      e.stockStatus
    ) || e.physicalStockVerified !== void 0 && typeof e.physicalStockVerified !== "boolean" || e.factoryOrderAcceptanceVerified !== void 0 && typeof e.factoryOrderAcceptanceVerified !== "boolean" || !Array.isArray(e.qualifications) || !e.qualifications.length || e.qualifications.some((q) => typeof q !== "string" || !q.trim()))
      throw new Error(
        `Availability correction ${edit.id} has invalid status or qualifications`
      );
    if (edit.after.availability === "not_current" && (e.stockStatus === "new_stock_listed" || e.orderStatus === "preorder" || e.orderStatus.startsWith("accepting_")))
      throw new Error(
        `Availability correction ${edit.id} has contradictory eligibility`
      );
    if (!usableCorrectionSources(
      e.sourceIds,
      sources,
      edit.reviewedAt,
      e.checkedAt
    ))
      throw new Error(
        `Availability correction ${edit.id} lacks usable supporting sources`
      );
    last.set(edit.variantId, edit);
    result[i] = {
      ...result[i],
      availability: edit.after.availability,
      availabilityEvidence: structuredClone(e),
      availabilityRevision: edit.id,
      buyerSummary: void 0
    };
  }
  return result;
}
function availabilityReportClaim(car) {
  const { availability, evidence: e } = availabilitySnapshot(car);
  return {
    key: "availability:exact_version",
    label: "Availability of this exact version",
    value: `${availabilityLabels[availability] || availability}; orders: ${e.orderStatus}; stock: ${e.stockStatus}`,
    unit: "",
    basis: "Exact Australian version availability",
    comparisonBasis: "",
    status: "conditional",
    sourceIds: [...e.sourceIds],
    date: e.checkedAt,
    market: "AU",
    scope: `Exact variant ${car.id}`,
    qualifications: [
      `Checked ${e.checkedAt || "date unverified"}`,
      ...e.qualifications || []
    ],
    issues: []
  };
}

// src/lib/buyer-availability.ts
var buyerAvailabilityLabels = {
  on_sale_now: "On sale now",
  order_open_or_arriving: "Order open or arriving",
  not_confirmed: "Not confirmed"
};
function statedArrivalTiming(car) {
  if (car.buyerAvailabilityDisplay) return car.buyerAvailabilityDisplay.timing;
  if (!car.availabilityEvidence?.sourceIds.length) return void 0;
  const month = "(?:January|February|March|April|May|June|July|August|September|October|November|December)";
  const date = `(?:${month} \\d{4}|Q[1-4] \\d{4}|\\d{4} Q[1-4])`;
  const pattern = new RegExp(
    `^First (?:customer )?deliveries (expected(?: from)? ${date})(?=[.;,]|$)`,
    "i"
  );
  for (const qualification of car.availabilityEvidence.qualifications ?? []) {
    const match = qualification.trim().match(pattern);
    if (match) return match[1];
  }
  return void 0;
}
function buyerAvailability(car) {
  if (car.buyerAvailabilityDisplay) return car.buyerAvailabilityDisplay.state;
  const evidence = car.availabilityEvidence;
  const supported = Boolean(evidence?.sourceIds.length);
  if (car.availability === "not_current") return "not_confirmed";
  if (supported && (evidence?.orderStatus === "preorder" || car.availability === "announced_provisional" && (["accepting_orders", "accepting_orders_advertised"].includes(
    evidence?.orderStatus ?? ""
  ) || statedArrivalTiming(car))))
    return "order_open_or_arriving";
  if (car.availability === "current_or_order_listed") return "on_sale_now";
  if (supported && evidence?.stockStatus === "new_stock_listed")
    return "on_sale_now";
  if (supported && ["accepting_orders", "accepting_orders_advertised"].includes(
    evidence?.orderStatus ?? ""
  ))
    return "order_open_or_arriving";
  return "not_confirmed";
}
function buyerAvailabilityText(car) {
  const state = buyerAvailability(car);
  const timing = state === "order_open_or_arriving" && statedArrivalTiming(car);
  return `${buyerAvailabilityLabels[state]}${timing ? ` \xB7 ${timing}` : ""}`;
}

// src/lib/car-avatar-shapes.ts
var shapes = {
  tesla_model_y: {
    overhang: 880,
    tyre: 720,
    sill: 0.115,
    nose: 0.47,
    cowl: [0.27, 0.6],
    roofFrom: 0.44,
    peak: 0.53,
    roofTo: [0.63, 0.985],
    tail: [0.935, 0.745],
    rear: 0.52,
    glass: "M.305,.63 L.452,.925 Q.56,.965 .68,.9 Q.79,.83 .868,.7 L.855,.665 Z",
    pillars: [
      [0.53, 0.52],
      [0.7, 0.71]
    ]
  },
  tesla_model_3: {
    overhang: 850,
    tyre: 670,
    sill: 0.11,
    nose: 0.5,
    cowl: [0.28, 0.63],
    roofFrom: 0.46,
    peak: 0.53,
    roofTo: [0.61, 0.98],
    tail: [0.885, 0.765],
    deck: [0.975, 0.735],
    rear: 0.56,
    glass: "M.315,.66 L.472,.93 Q.56,.96 .66,.905 Q.76,.84 .835,.735 L.82,.7 Z",
    pillars: [
      [0.545, 0.535],
      [0.7, 0.715]
    ]
  },
  byd_sealion_7: {
    overhang: 900,
    tyre: 740,
    sill: 0.125,
    nose: 0.53,
    cowl: [0.27, 0.62],
    roofFrom: 0.45,
    peak: 0.54,
    roofTo: [0.66, 0.975],
    tail: [0.95, 0.725],
    rear: 0.55,
    glass: "M.3,.645 L.46,.925 Q.58,.96 .7,.9 Q.8,.84 .875,.76 L.8,.705 L.62,.67 Z",
    pillars: [
      [0.54, 0.53],
      [0.7, 0.715]
    ],
    cladding: "thin"
  },
  geely_ex5: {
    overhang: 880,
    tyre: 700,
    sill: 0.125,
    nose: 0.57,
    cowl: [0.26, 0.645],
    roofFrom: 0.42,
    peak: 0.55,
    roofTo: [0.82, 0.965],
    spoiler: [0.905, 0.925],
    tail: [0.955, 0.71],
    rear: 0.56,
    glass: "M.29,.665 L.43,.925 Q.6,.955 .8,.91 L.885,.865 L.86,.775 L.74,.7 Z",
    pillars: [
      [0.52, 0.51],
      [0.7, 0.71],
      [0.795, 0.81]
    ],
    cladding: "thin",
    rails: [0.47, 0.8]
  },
  zeekr_7x: {
    overhang: 870,
    tyre: 740,
    sill: 0.12,
    nose: 0.53,
    cowl: [0.26, 0.615],
    roofFrom: 0.43,
    peak: 0.53,
    roofTo: [0.78, 0.955],
    spoiler: [0.885, 0.905],
    tail: [0.95, 0.7],
    rear: 0.55,
    glass: "M.29,.635 L.44,.925 Q.58,.955 .76,.9 L.855,.845 L.825,.72 L.7,.68 Z",
    pillars: [
      [0.53, 0.52],
      [0.705, 0.715]
    ],
    cladding: "thin"
  },
  jaecoo_j5_ev: {
    overhang: 850,
    tyre: 690,
    sill: 0.125,
    nose: 0.61,
    cowl: [0.25, 0.685],
    roofFrom: 0.38,
    peak: 0.46,
    roofTo: [0.88, 0.935],
    spoiler: [0.935, 0.915],
    tail: [0.972, 0.73],
    rear: 0.56,
    glass: "M.28,.705 L.39,.925 Q.6,.95 .87,.88 L.92,.855 L.9,.79 L.7,.755 Z",
    pillars: [
      [0.5, 0.49],
      [0.68, 0.69],
      [0.8, 0.81]
    ],
    cladding: "thick"
  },
  byd_atto_2: {
    overhang: 830,
    tyre: 670,
    sill: 0.125,
    nose: 0.58,
    cowl: [0.25, 0.665],
    roofFrom: 0.4,
    peak: 0.5,
    roofTo: [0.84, 0.965],
    spoiler: [0.915, 0.94],
    tail: [0.958, 0.72],
    rear: 0.56,
    glass: "M.28,.685 L.41,.925 Q.6,.955 .84,.915 L.9,.885 L.872,.8 L.72,.705 Z",
    pillars: [
      [0.51, 0.5],
      [0.7, 0.71],
      [0.8, 0.81]
    ],
    cladding: "thick",
    rails: [0.45, 0.82]
  },
  kia_ev5: {
    overhang: 880,
    tyre: 720,
    sill: 0.125,
    nose: 0.62,
    cowl: [0.24, 0.685],
    roofFrom: 0.37,
    peak: 0.5,
    roofTo: [0.9, 0.975],
    spoiler: [0.955, 0.955],
    tail: [0.978, 0.73],
    rear: 0.52,
    glass: "M.27,.7 L.38,.925 Q.62,.95 .9,.92 L.94,.895 L.922,.745 L.7,.705 Z",
    pillars: [
      [0.5, 0.49],
      [0.69, 0.7],
      [0.83, 0.8]
    ],
    cladding: "square",
    rails: [0.43, 0.86],
    wheel: "block"
  },
  kia_ev3: {
    overhang: 810,
    tyre: 690,
    sill: 0.125,
    nose: 0.6,
    cowl: [0.25, 0.675],
    roofFrom: 0.39,
    peak: 0.5,
    roofTo: [0.86, 0.955],
    spoiler: [0.93, 0.93],
    tail: [0.968, 0.73],
    rear: 0.54,
    glass: "M.28,.69 L.4,.925 Q.6,.955 .85,.9 L.91,.868 L.888,.79 L.78,.765 L.66,.695 Z",
    pillars: [
      [0.51, 0.5],
      [0.69, 0.7],
      [0.81, 0.78]
    ],
    cladding: "square",
    wheel: "block"
  },
  byd_atto_3_evo: {
    overhang: 870,
    tyre: 690,
    sill: 0.125,
    nose: 0.56,
    cowl: [0.26, 0.645],
    roofFrom: 0.42,
    peak: 0.52,
    roofTo: [0.78, 0.955],
    spoiler: [0.895, 0.91],
    tail: [0.95, 0.7],
    rear: 0.56,
    glass: "M.29,.665 L.43,.925 Q.58,.955 .78,.9 L.855,.855 L.83,.79 L.72,.7 Z",
    pillars: [
      [0.52, 0.51],
      [0.7, 0.71]
    ],
    cladding: "thin",
    rails: [0.46, 0.76],
    trim: "M.868,.84 L.905,.74 M.885,.85 L.922,.75 M.902,.855 L.935,.765"
  }
};
shapes.byd_atto_3_legacy = shapes.byd_atto_3_evo;

// scripts/reporting/reports.ts
var isOnSale = (car) => car.availability === "current_or_order_listed" || car.availability === "outgoing" && car.availabilityEvidence?.stockStatus === "new_stock_listed" && !!car.availabilityEvidence.sourceIds.length;
var isCurrentListEligible = (car, sources, asOf) => isOnSale(car) || ["announced_provisional", "outgoing"].includes(car.availability) && ["preorder", "accepting_orders", "accepting_orders_advertised"].includes(
  car.availabilityEvidence?.orderStatus ?? ""
) && !!car.availabilityEvidence && evidenceFreshness(car.availabilityEvidence.checkedAt, "availability", asOf).fresh && usableCorrectionSources(
  car.availabilityEvidence.sourceIds,
  sources,
  asOf,
  car.availabilityEvidence.checkedAt
);
export {
  applyAvailabilityCorrections,
  availabilityReportClaim,
  availabilitySnapshot,
  buyerAvailability,
  buyerAvailabilityText,
  isCurrentListEligible,
  isOnSale,
  orderEvidenceText
};
