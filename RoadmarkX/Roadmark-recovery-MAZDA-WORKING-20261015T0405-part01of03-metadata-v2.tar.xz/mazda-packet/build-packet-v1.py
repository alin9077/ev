from pathlib import Path
import json,hashlib,copy
R=Path('/tmp/mazda-research');O=Path('/tmp/mazda-packet/v1');ID='m1-mazda-2026-10-15';DATE='2026-10-15';REVIEWER='Roadmark Mazda M1 proposal pending independent review'
N=json.load(open(R/'normalized-review-v2.json'));I=json.load(open(R/'source-index-review-v1.json'))['sources'];B={v['id']:v for v in json.load(open(R/'retained-before-cars.json'))}
assert hashlib.sha256((R/'normalized-review-v2.json').read_bytes()).hexdigest()=='320362a7579d66b5f097d4f625b9ba064fd9972933513fa1e0ce53c236ddeed2'
P=dict(schemaVersion=1,id=ID,brand='Mazda',reviewedAt=DATE,reviewedBy=REVIEWER,sources=[],models=[],variants=[],versionGuards=[],versionUpdates=[],facts=[],features=[],configurationUpdates=[],brandTerms=[],availability=[],summaries=[])
sourcekeys=set()
for v in N['variants']:
 for f in [*v['coreFacts'].values(),*v['extraFacts'].values()]:sourcekeys.update(f['sourceKeys'])
 sourcekeys.update(v['availability']['sourceKeys'])
sourcekeys.update(['au-home','au-6e-build','au-cx6e-build'])
def sid(key):return ID+'-'+key
for key in sorted(sourcekeys):
 s=I[key];url=s['url'];maker=key.startswith('au-');publisher='Mazda Australia' if maker else 'CarExpert' if 'carexpert.com.au' in url else 'CarsGuide' if 'carsguide.com.au' in url else 'The Driven' if 'thedriven.io' in url else 'Melville Mazda'
 title={'au-6e-brochure':'Mazda 6e Australian brochure, July 2026 AU41-P00008059','au-cx6e-brochure':'Mazda CX-6e Australian brochure, August 2026 AU41-P00008813','au-6e-build':'Mazda 6e current Australian exact-grade configurator and state offers','au-cx6e-build':'Mazda CX-6e current Australian exact-grade configurator and state offers','au-battery-warranty-image':'Mazda Australia current 8-year / 160,000 km battery warranty badge','au-bev-range':'Mazda Australia current battery-electric range and preorder status','au-warranty':'Mazda Australia new-vehicle warranty','au-warranty-terms':'Mazda Australia new-vehicle warranty terms','au-offers':'Mazda Australia exact E35 GT electric driveaway-from offers'}.get(key,key.replace('-',' ').title())
 captures=[dict(locator='mazda-research/sources/'+Path(s['rawPath']).name,sha256=s['rawSha256'],bytes=s['rawBytes'],purpose='Raw public source body')]
 if s.get('textPath'):captures.append(dict(locator='mazda-research/sources/'+Path(s['textPath']).name,sha256=s['textSha256'],bytes=Path(s['textPath']).stat().st_size,purpose='Extracted source text'))
 row=dict(id=sid(key),url=url,title=title,publisher=publisher,source_type='manufacturer_au_publication' if maker else 'dealer_advertisement' if key=='residual-cx6e-azami-ad' else 'secondary_australian_motoring_publication',published_date={'au-6e-launch':'2026-02-17','au-cx6e-launch':'2026-04-08'}.get(key),accessed_date=DATE,market='AU',supports=title,retrievalMethod='Fresh public read-only body capture; PDF and warranty badge visually inspected where noted',capture_locator=captures[0]['locator'],capture_sha256=s['rawSha256'],retainedCaptures=captures)
 if key=='au-battery-warranty-image':row['scope_note']='Badge linked on both current Australian 6e and CX-6e pages; BEV hub corroborates high-voltage battery coverage. Duration and kilometre label only; no retention threshold or whichever-first guarantee inferred.'
 P['sources'].append(row)
S={s['id']:s for s in P['sources']}
labels=dict(price_aud='Listed price',range_km='Claimed WLTP range',battery_kwh='Published battery capacity',dc_peak_kw='Peak vehicle DC acceptance',dc_charge_time_min='Published DC charging duration',ac_kw='On-board AC maximum',seats='Seats',boot_l='Published rear storage',zero_to_100_s='0–100 km/h',power_kw='Motor power',drive='Drive type',length_mm='Length',width_mm='Width',height_mm='Height',towing_braked_kg='Braked towing',warranty='Vehicle warranty',battery_warranty='Battery warranty',source_mlp_aud='Maker MLP · on-road basis unstated',source_boot_web_l='Maker website boot · method unstated',source_dc_30_80_min='Maker DC 30–80% duration')
def makefact(n,v,shared=False):
 k=n['key'];ids=[sid(x) for x in n['sourceKeys']];g=n['buyerGrade'];scope='brand_au_terms' if shared else n['evidenceScope']
 reason={'confirmed':'Current Australian maker source supports the stated value for this named grade/body. ','check':'Current Australian maker source supports the labelled value with the specific condition or unresolved source-method difference. ','reported':'Exact Australian secondary observation, displayed with publisher attribution and no rank. ','not_published':'Two source checks did not establish the requested value. '}[g]+n['locator']
 if shared:reason='Current Australian maker brand warranty label and terms, with applicability to both currently advertised battery-electric model families; unprinted retention/precedence terms are not inferred.'
 f=dict(key=k,label=labels[k],value=n['value'],unit=n['unit'],basis=n['basis'],comparisonBasis=n['comparisonBasis'],status=n['status'],sourceIds=ids,date=DATE,market='AU',scope='Mazda Australia current new-vehicle / high-voltage battery warranty terms; current BEV scope' if shared else v['scope'],qualifications=[n['locator'],*n['qualifications']],issues=[],buyerGrade=g,gradeReview=dict(reviewedAt=DATE,overlayId=ID,reason=reason,evidenceScope=scope,sourceIds=ids,sourceLabel=' / '.join(dict.fromkeys(S[x]['publisher'] for x in ids))),resolvedElsewhere=g=='reported')
 if g=='check':f['conditionExplanation']=' '.join(n['qualifications'])
 if n.get('conflictId'):
  f['issues']=[dict(issue_id=ID+'-'+n['conflictId'],title=n['conflictId'].replace('_',' ').capitalize(),priority='field_hold',model_ids=[v['modelId']],publication_action='Keep the source-labelled figure and differing observation visible; do not include this unresolved claim in attribute rankings.',source_ids=ids)]
 if k=='price_aud':
  pe=copy.deepcopy(n['priceEvidence']);pe['sourceKey']=k;pe['sourcePointer']=I[n['sourceKeys'][0]]['url']+' | '+pe['sourcePointer'];f['priceEvidence']=pe
 return f
normalizedfacts={}
for v in N['variants']:
 vid=v['id'];old=B[vid];P['versionGuards'].append(dict(variantId=vid,before={k:old.get(k) for k in ['id','modelId','brand','model','trim','year','generation','vehicleClass','drive']}))
 nf={k:makefact(f,v) for k,f in {**v['coreFacts'],**v['extraFacts']}.items()};normalizedfacts[vid]=nf
 for k,f in nf.items():
  if k not in ['warranty','battery_warranty']:P['facts'].append(dict(variantId=vid,before=copy.deepcopy(old['facts'].get(k)),after=f))
 a=v['availability'];e={**copy.deepcopy(old['availabilityEvidence']),**dict(checkedAt=DATE,orderStatus=a['orderStatus'],stockStatus=a['stockStatus'],sourceIds=[sid(k) for k in a['sourceKeys']],physicalStockVerified=False,factoryOrderAcceptanceVerified=False,factoryBuildSpecificationVerified=False,deliveryToBuyerVerified=False,qualifications=a['qualifications'],configuration=v['scope'])}
 P['availability'].append(dict(id=ID+'-availability-'+vid,variantId=vid,before=dict(availability=old['availability'],evidence=copy.deepcopy(old['availabilityEvidence'])),after=dict(availability=a['recordState'],evidence=e),status='approved',reviewedBy=REVIEWER,reviewedAt=DATE,evidenceDate=DATE,reason='Fresh maker exact-grade listing and explicit CX-6e preorder scope; the legacy CX-6e on-sale classification is corrected without inferring stock or factory order acceptance.'))
 summary=dict(variantId=vid,conditions=[])
 for name,clause in v['summary'].items():summary[name]=dict(label=clause['label'],text=clause['text'],dependencies=[dict(key=k,expected=copy.deepcopy(nf[k])) for k in clause['dependencies']])
 P['summaries'].append(summary)
 before=copy.deepcopy(old['configurationEvidence']);after=copy.deepcopy(before)
 # Specific labelled core prices/capacity and reported performance no longer require a null. Other independent holds remain exact.
 released=[k for k in ['price_aud','battery_kwh','zero_to_100_s'] if k in after.get('requiredNulls',{})]
 for k in released:del after['requiredNulls'][k]
 depkeys=list(dict.fromkeys(['price_aud','range_km','dc_charge_time_min','seats','length_mm','width_mm',*released]))
 deps=[dict(key=k,expected=copy.deepcopy(nf[k])) for k in depkeys]
 sourceids=list(dict.fromkeys(s for d in deps for s in d['expected']['sourceIds']))
 after.update(rankingEligible=True,projectionScope=v['scope']+'; current core facts regraded individually. Remaining source conflicts and factory-build boundaries are unchanged.',sourceIds=sourceids,requiredBuyerVisibleConditions=['Manufacturer model year and exact delivered build remain unverified; brochure publication month is not a model year.',v['coreFacts']['boot_l']['qualifications'][0],'78 kWh is a maker capacity label with no stated gross or usable basis.','Historical equipment conflicts remain unresolved; no core review resolves climate, screen or glovebox discrepancies.']+(['Mazda 6e towing footnote remains unresolved; 1,500 kg braked is visible but unranked.'] if v['model']=='6e' else ['CX-6e is currently advertised for pre-order; no accepted factory allocation or physical stock is verified.']),configurationReview=dict(overlayId=ID,reviewedAt=DATE,historicalBoundaryFields=[k for k in ['pricingBoundary','chargingBoundary','projectionContract'] if k in before],releasedNulls=[dict(key=k,factKeys=[k]) for k in released]))
 P['configurationUpdates'].append(dict(variantId=vid,before=before,after=after,reason='Named current Australian grades have individually supported core facts under the M1 brief. Release only exact price/capacity-label/secondary-performance scalar nulls where present; retain cargo conflict, gross/usable, model-year, warranty-retention and factory-build holds. Configuration ranking permission does not override fact issues or preorder availability exclusions.',sourceIds=sourceids,dependencies=deps))
for k in ['warranty','battery_warranty']:
 shared=makefact(N['variants'][0]['coreFacts'][k],N['variants'][0],True)
 P['brandTerms'].append(dict(key=k,fact=shared,applicableVariantIds=[v['id'] for v in N['variants']],before={v['id']:copy.deepcopy(B[v['id']]['facts'].get(k)) for v in N['variants']},exceptions=[]))
assert len(P['facts'])==72 and len(P['configurationUpdates'])==4 and len(P['versionGuards'])==4 and not P['features'] and not P['variants']
p=O/'mazda-2026-10-15.json';p.write_text(json.dumps(P,indent=2,ensure_ascii=False)+'\n')
r=dict(status='proposal_assembled_pending_independent_review_and_selected_actual_function_preflight',packetPath=str(p),packetSha256=hashlib.sha256(p.read_bytes()).hexdigest(),packetBytes=p.stat().st_size,normalizedPath=str(R/'normalized-review-v2.json'),normalizedSha256=hashlib.sha256((R/'normalized-review-v2.json').read_bytes()).hexdigest(),sources=len(P['sources']),models=0,newVariants=0,existingGuards=4,specificFactUpdates=72,sharedBrandTerms=2,effectiveTermCells=8,availability=4,configurationUpdates=4,summaries=4,equipmentUpdates=0,versionUpdates=0,expectedOnSaleDelta=-2,requiredUnappliedPatch='/tmp/mazda-research/preorder-proposal/availability-preorder.patch',baselineStatus='Four Mazda rows reused from verified accepted derived chain; not fresh full export.',productionSourceEdits=False,productionCatalogueHydration=False)
(O/'assembly-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
