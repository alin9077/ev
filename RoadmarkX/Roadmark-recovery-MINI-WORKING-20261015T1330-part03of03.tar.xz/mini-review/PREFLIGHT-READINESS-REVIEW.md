# MINI selected actual-consumer preflight: independent readiness review

Verdict: accept the frozen v2 command for one isolated selected preflight only after root grants the exclusive heavy slot. This is readiness review, not a consumer test pass, integration approval or C1 closure. No heavy command was executed by this reviewer.

## Frozen pins

- Prepared manifest: `/tmp/mini-packet/selected-preflight-v2/prepared-command.json`, SHA256 `41719ecc7954882fc9b95fa2d24ded00fa2f7c74fe4c189d41db3c79a02758a7`
- Script: `/tmp/mini-packet/selected-preflight-v2/check.mjs`, SHA256 `571ac3b7f999e9728d3b953143ed74cf15f4c2677a6423cfabc5f5a5f7a708d1`
- Source pins: `/tmp/mini-packet/selected-preflight-v2/source-pins.json`, SHA256 `5f87d292e413913f981217d7ea93956ed3a884b63e5b456b08075e724343828e`
- Wrapper: `/tmp/mini-packet/selected-preflight-v2/run.py`, SHA256 `4942c622d933e6c970b2357d02ed25a76230533095193e1935bfde9d96862e59`
- Expected review: `/tmp/mini-packet/selected-preflight-v2/expected-review.json`, SHA256 `1a163112ed50bc1bb151b86014be2a493943017c3c50560c2d75810155829c89`
- Candidate: `/tmp/mini-packet/mini-2026-10-15-candidate-v2.json`, SHA256 `615215e71c808a64fd87a66bf99ca223688ec70fd49e6dd43a74607c9dbaebff`
- Reconciliation: `/tmp/mini-packet/mini-market-reconciliation-v2.json`, SHA256 `86359cbd7e8a2097b53db4ae57d8b92f4fd51a3b244fd4aa60a414d6e30dd0de`
- Machine receipt: `/tmp/mini-review/preflight-v2-readiness-receipt.json`, SHA256 `d8262e41fba4abc3992186f124c6a0f1d7e656658d600880b11b1ceee741c537`

All 182 source pins were independently hashed against current bytes. No failures or missing static relative import pins were found. Source files outside the preparation folder are byte-identical between v1 and v2. The wrapper and expected policy are also byte-identical. Candidate and reconciliation retain the prior independent source verdict.

## What the command will establish

1. It selects the exact ten retained Cooper, Aceman and Countryman identities from the retained before rows, reproduces each accepted post-Deepal26 row digest, and checks the live registry remains exactly 26 packets ending with Deepal. Earlier packet targets and shared-term scopes cannot include these MINI rows. Streamed research retains ten variant rows, ten historical contexts, three model rows and 690 feature rows. It does not construct a catalogue.
2. Actual `prepareBrandResearch` and `applyBrandUpdates` must accept the ten full identity guards, 153 fact before states, 30 term applications and ten complete availability before/after states. Version additions, metadata changes, model additions, feature packet edits and configuration edits remain empty. Before/after identity snapshots and configurations must be identical; formal model year stays null.
3. All 170 core cells must earn the proposed grade. Three supplemental net-battery conflict cells and ten roadside terms bring the effective updated claim count to 183. Fact claims must carry the exact cited IDs and grades; explicit Not published values must remain null in the facts and render as Not published.
4. All 690 feature claims are produced by the actual consumer and citable code. The actual source-effective, regrade, brand-feature and term-projection pipeline is replayed. The ten roadside projections retain the real five-versus-eight-year conflict. The ten driveaway answers must equal the actual source-effective regraded fallback, with no canonical driveaway projection from the GST/delivery maker prices or the Paul Smith before-ORC amount. Other retained features stay exactly equal to the before packs; this does not claim a new review of all retained equipment.
5. Actual packs enforce source closure for facts, issues, availability, summaries, features, configuration and other context. Citable claims are replayed and compared again after written portable hydration.
6. The twenty summary clauses must match exact label, text, clean dependency facts, ordered dependency source IDs, all fact-plus-source freshness entries, combined guard IDs, complete packet source snapshots, conditions and review date. There are 27 claim-only dependencies; unrelated conflict or formal-MY fields do not become proxies for summary freshness.
7. The 140 numeric-core policy rows match the source-reviewed candidate values, grades and measurement bases. Actual ranking eligibility must agree with those expectations, and all seven supported discovery attributes must have exact expected membership and compatible basis/unit groups. Nine maker GST/delivery prices plus the reported Paul Smith price remain unranked; maximum-WLTP range, cargo without a protocol, width without a mirror basis, null towing and genuine battery/charging conflicts remain excluded. Clean values retain eligibility.
8. The three current-model reviews must cover the exact ten versions and the three existing MINI inventory families. Selected report totals remain ten, on-sale delta remains zero, stock and factory-order acceptance flags remain false, and global C1 must remain false because independent-list closure is unresolved. Separate residual/future leads are not promoted.

## Exact live and written boundaries

V1 was held because JSON-string equality could miss own-undefined input mutation, and its pack snapshot followed rather than preceded the storage producer. V2 fixes both. It takes structured clones before calls and uses deep strict equality for original research, before cars, proposed research, after cars, candidate and live packs. The live pack snapshot now precedes storage. These checks recur after consumer and serialization work.

Live portable storage/hydration is compared to the complete live pack. Written JSON and written portable hydration are compared to a separate cloned representation with only witnessed omission paths removed. Optional keys are not stripped globally and JSON normalization is not used as the live immutability proof.

Each permitted feature omission is bound to exact phase, car, row index, criterion and own enumerable undefined property. It must match the same-run actual source/regrade/final projection, with actual `auditedFeature(raw)` evidence for the novated-FBT confirmation field. Before witnesses must match retained after omissions; fresh roadside projections may not carry them. Unrecognized optional properties fail.

Citation omissions are confined to exact source-index `limitation` or `checked` fields whose actual source metadata is falsey and whose actual citable replay agrees. The report permits only the actual independent-list issue's own undefined brand/reference fields at the three precise current-list/report locations. Full readback equality and unchanged live objects are required.

## Execution boundary

The wrapper requires an explicit root grant matching the frozen manifest and command, plus the exclusive slot. It runs one Node process with 448 MiB old-space and 1 MiB semi-space, supervised by 180 seconds and a 10-second TERM-to-KILL grace. Heap flags are not an OS RSS limit. There is no automatic retry. Outputs are create-only in the preparation directory and its run subdirectory; before/after pins, raw terminal status, wait4 resource evidence and stdout/stderr hashes are retained.

Default catalogue/research callbacks must remain unused, and production loader modules must remain absent from the require cache. No helper changes, source edits, registration, broad hydration, test/build/server or publication is included. At readiness inspection there was no run directory, result or root execution grant. Actual success, memory consumption and unexpected producer shapes remain to be measured by the authorized isolated run; any failure must stop without widening or normalization.
