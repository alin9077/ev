from pathlib import Path
import json,hashlib,copy,re,collections
from datetime import datetime,timezone
D=Path('/tmp/mini-packet/selected-preflight-v3');R=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(262144):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def unique(xs):return list(dict.fromkeys(xs))
def clean(s):return re.sub(r'\s+',' ',s).strip()
m=read(D/'prepared-command.json');result=read(D/'result.json');packet=read(m['packet']['path']);expected=read(D/'expected-review.json');before=read('/tmp/mini-research/retained-before-cars.json');cars=read(D/'selected-after-cars.json');packs=read(D/'selected-packs.json');stored=read(D/'portable.json');claims=read(D/'claims.json');features=read(D/'feature-claims.json');fw=read(D/'undefined-witnesses.json');cw=read(D/'claim-undefined-witnesses.json');rw=read(D/'report-undefined-witnesses.json');terminal=read(D/'run/terminal.json');invocation=read(D/'run/invocation.json');afterpins=read(D/'run/after-pins.json')
assert pin(D/'result.json')['sha256']=='aa64d34beaaa1913eacf7a6f7e4326470939e14125f61147b91b52f68c7e0fa8'
assert terminal['exitCode']==0 and terminal['rawWaitStatus']==0 and terminal['elapsedSeconds']<180
assert pin(D/'run/stdout.log')['sha256']==terminal['stdoutSha256'];assert pin(D/'run/stderr.log')['sha256']==terminal['stderrSha256'];assert (D/'run/stderr.log').stat().st_size==0
assert invocation['manifestSha256']==pin(D/'prepared-command.json')['sha256'];assert invocation['grantSha256']==pin(D/'root-execution-grant.json')['sha256'];assert invocation['command']==m['command'];assert invocation['automaticRetry'] is False and invocation['liveSourceMutationsAuthorized'] is False
assert afterpins['passed'] and afterpins['manifestSha256']==invocation['manifestSha256']
pins=read(D/'source-pins.json');assert len(pins)==191
for p in pins:assert pin(p['path'])==p,p['path']
ids=[c['id'] for c in before];assert ids==[c['id'] for c in cars]==expected['currentListIds']==list(packs)==list(stored);assert len(ids)==10
bm={c['id']:c for c in before};cm={c['id']:c for c in cars};sources={s['id']:s for s in packet['sources']};updates={(x['variantId'],x['after']['key']):x['after'] for x in packet['facts']}
for t in packet['brandTerms']:
 for i in t['applicableVariantIds']:assert (i,t['key']) not in updates;updates[i,t['key']]=t['fact']
assert len(updates)==183
availability={x['variantId']:x for x in packet['availability']};summaries={x['variantId']:x for x in packet['summaries']};dependency_count=0
for c in cars:
 i=c['id'];b=bm[i];e=copy.deepcopy(b)
 for (v,k),f in updates.items():
  if v==i:e['facts'][k]=copy.deepcopy(f)
 e['availabilityRevision']=availability[i]['id'];e['buyerGradesRequired']=True;e['availability']=availability[i]['after']['availability'];e['availabilityEvidence']=availability[i]['after']['evidence'];edit=summaries[i];bs={'checkedAt':packet['reviewedAt'],'guardSourceIds':[],'expectedSourceSnapshots':[],'conditions':edit.get('conditions',[])}
 for side in ['strength','tradeoff']:
  deps=edit[side]['dependencies'];dependency_count+=len(deps);fs=[x['expected'] for x in deps];fids=unique([s for f in fs for s in f['sourceIds']]);fresh=[]
  for f in fs:
   assert c['facts'][f['key']]==f and not f['issues'] and f['value'] is not None
   for d in [f['date']]+[sources[s]['accessed_date'] for s in f['sourceIds']]:
    entry={'checkedAt':d,'key':f['key']}
    if f.get('modelYearChangedAt'):entry['modelYearChangedAt']=f['modelYearChangedAt']
    fresh.append(entry)
  clause={'label':edit[side]['label'],'text':edit[side]['text'],'sourceIds':fids,'freshness':fresh};deadlines=sorted(f['validUntil'] for f in fs if f.get('validUntil'))
  if deadlines:clause['validUntil']=deadlines[0]
  bs[side]=clause;bs['guardSourceIds']=unique(bs['guardSourceIds']+fids)
 bs['expectedSourceSnapshots']=[s for s in packet['sources'] if s['id'] in bs['guardSourceIds']];e['buyerSummary']=bs
 assert e==c,('complete after-car mismatch',i)
 assert c['year'] is None and c['availabilityEvidence']['physicalStockVerified'] is False and c['availabilityEvidence']['factoryOrderAcceptanceVerified'] is False
 assert packs[i]['car']==c and len(packs[i]['features'])==69 and len({f['criterion'] for f in packs[i]['features']})==69
assert dependency_count==27
# Frozen source registry only: no variants, catalogue, producer imports or hydration.
accepted=read('/tmp/mercedes-staging-plan/consumer-preparation/v5/manifests/report-v5.json');idx=read('/tmp/mercedes-staging-plan/staging-preparation/staging-artifacts/canonical-v1/staged-storage-index.json');ref=idx['research']['sources'];source_path=Path(accepted['anchors'][ref['anchor']])/ref['file'];assert pin(source_path)['sha256']==ref['sha256'];assert source_path.stat().st_size==ref['bytes']
needed={s['id'] for p in packs.values() for s in p['sources']};retained={}
with source_path.open() as f:
 for line in f:
  s=json.loads(line)
  if s['id'] in needed:retained[s['id']]=s
all_sources={**retained,**sources}
for i,p in packs.items():
 sm={s['id']:s for s in p['sources']};assert len(sm)==len(p['sources'])
 for s in p['sources']:assert s==all_sources[s['id']],('source mutation',i,s['id'])
 required=[]
 for f in p['car']['facts'].values():required+=f['sourceIds']+[s for issue in f['issues'] for s in issue['source_ids']]
 required+=p['car']['availabilityEvidence']['sourceIds']+p['car']['buyerSummary']['guardSourceIds']+[s for f in p['features'] for s in f['source_ids']]+p['eligibility']['source_ids']+[s for e in p['events'] for s in e['source_ids']]+[s for e in p['configuration'] for s in e['source_ids']]+[s for e in p['car']['issues'] for s in e['source_ids']]
 assert set(required)<=set(sm)
 q=copy.deepcopy(stored[i]);sids=q.pop('sourceIds');q['sources']=[all_sources[s] for s in sids]
 for f in q['features']:f.setdefault('variant_id',q['car']['id']);f.setdefault('model_id',q['car']['modelId'])
 assert q==p,('full written portable reconstruction',i)
claimmap={(x['variantId'],x['key']):x['claim'] for x in claims};assert len(claimmap)==len(claims)==183 and set(claimmap)==set(updates)
def citations(claim,p,ids):
 assert [s['id'] for s in claim['sources']]==unique(ids)
 sm={s['id']:s for s in p['sources']}
 for s in claim['sources']:
  original=sm[s['id']]
  for k in ['id','title','url','publisher','accessed_date','published_date','market']:assert s[k]==original[k],('citation metadata',k)
  for k,o in [('limitation','access_limitation'),('checked','full_text_checked_date')]:
   if original.get(o):assert s[k]==str(original[o])
   else:assert k not in s
for (i,k),f in updates.items():
 c=claimmap[i,k];assert c['key']==k and c['carId']==i
 for a,b in [('basis','basis'),('evidenceDate','date'),('status','status'),('buyerGrade','buyerGrade'),('gradeReview','gradeReview')]:assert c[a]==f[b]
 for k2 in ['priceEvidence','validUntil','modelYearChangedAt']:assert c.get(k2)==f.get(k2)
 qs=f['qualifications'][:];ex=f.get('conditionExplanation','').strip()
 if ex and ex not in ' '.join(qs):qs.append(ex)
 qs+=[issue['publication_action'] for issue in f['issues']]
 assert c['qualifications']==unique([clean(x) for x in qs if clean(x)]),('fact conditions',i,k)
 if f['value'] is None:assert c['value']=='Not published'
 else:
  v=f['value'];num=format(v,',g') if isinstance(v,(int,float)) else v
  if isinstance(v,(int,float)):num=f'{v:,.3f}'.rstrip('0').rstrip('.')
  value='A$'+num if f['unit']=='AUD' else str(num)+(' '+f['unit'] if f['unit'] else '')
  assert c['value']==value,('fact display',i,k,c['value'],value)
 citations(c,packs[i],f['sourceIds'])
fmap={(x['variantId'],x['criterion']):x['claim'] for x in features};assert len(fmap)==len(features)==690
for i,p in packs.items():
 for f in p['features']:
  assert f['variant_id']==i and f['model_id']==cm[i]['modelId'];c=fmap[i,f['criterion']]
  assert c['key']==f['criterion'] and c['carId']==i and c['value']==('Not published' if f.get('buyerGrade')=='not_published' else str(f['value']))
  assert c['evidenceDate']==f['last_evidence_date'] and c['status']==f['status'] and c['basis']==(f.get('condition_label') or 'Australian variant research; see conditions')
  for k in ['buyerGrade','gradeReview','gradeReviewStatus','validUntil']:assert c.get(k)==f.get(k)
  qs=[f['conditions']]+f.get('usability_notes',[])+[f.get('confirmation_needed','')];assert c['qualifications']==unique([clean(x) for x in qs if clean(x)])
  citations(c,p,f['source_ids'])
  if f['criterion']=='roadside_assistance':assert f['buyerGrade']=='check' and f['source_ids']==cm[i]['facts']['roadside_assistance']['sourceIds'];assert 'five' in f['conditions'].lower() and 'eight' in f['conditions'].lower()
  if f['criterion']=='driveaway_price':assert f['value']=='Needs confirmation' and f['status']=='not_verified' and f['verification_state']=='unverified' and f['source_ids']==[]
assert fw==result['optionalFeaturePaths'] and cw==result['optionalCitationPaths'];assert len(fw)==40 and len(cw)==646 and len(rw)==6
for w in fw:
 assert w['phase'] in ['before','after'] and w['ownUndefined'] and w['enumerable'] and w['actualFinalProjectionMatched']
 assert (w['criterion'],w['rowIndex'],w['property']) in [('novated_fbt',49,'confirmation_needed'),('audio_system',65,'gradeReviewStatus'),('style_refinement',37,'gradeReviewStatus')]
 assert w['pointer']==f"/packs/{w['variantId']}/features/{w['rowIndex']}/{w['property']}"
 assert packs[w['variantId']]['features'][w['rowIndex']]['criterion']==w['criterion'];assert w['property'] not in packs[w['variantId']]['features'][w['rowIndex']]
 if w['property']=='gradeReviewStatus':assert packs[w['variantId']]['features'][w['rowIndex']]['buyerGrade']=='confirmed' and packs[w['variantId']]['features'][w['rowIndex']]['gradeReview']
assert len({(w['phase'],w['pointer']) for w in fw})==40
citation_paths=set()
for name,rows in [('claims',claims),('feature-claims',features)]:
 for j,row in enumerate(rows):
  for z,s in enumerate(row['claim']['sources']):
   for k in ['limitation','checked']:
    if k not in s:citation_paths.add(f'/{name}/{j}/claim/sources/{z}/{k}')
assert citation_paths=={w['pointer'] for w in cw} and len(citation_paths)==len(cw)
for w in cw:assert w['ownUndefined'] and w['enumerable'] and w['property'] in ['limitation','checked'] and w['sourceId'] in needed
paths={f'/result/{p}/{k}' for p in ['currentListProof/issues/0','selectedCoverage/reconciliation/issues/0','selectedCoverage/brandProgress/0/closureIssues/0'] for k in ['brand','reference']};assert paths=={w['pointer'] for w in rw}
for w in rw:assert w['ownUndefined'] and w['enumerable']
assert len(result['rankingProof'])==140
rp={(x['variantId'],x['key']):x for x in result['rankingProof']}
for r in expected['normalizedRankPolicy']:assert rp[r['variantId'],r['key']]['eligible']==r['eligible']
for k,ids2 in expected['rankingIds'].items():assert set(result['rankCounts'][k]['ranked'])==set(ids2);assert len(result['rankCounts'][k]['excluded'])==10-len(ids2)
c1=result['currentListProof'];assert c1['reviewedModels']==3 and c1['reviewedVersions']==10 and set(c1['reviewedVersionIds'])==set(ids);assert set(c1['settledInventory'])==set(expected['expectedSettledInventory']);assert len(c1['issues'])==1 and c1['issues'][0]['code']=='independent_lists' and c1['pass'] is False
assert result['selectedCoverage']['reconciliation']==c1
for row in result['selectedCoverage']['core']:
 counter=collections.Counter(cm[i]['facts'][row['key']]['buyerGrade'] for i in ids)
 for grade,n in row['grades'].items():assert n==counter.get({'Confirmed':'confirmed','Check':'check','Reported':'reported','Not published':'not_published','Unreviewed':'unreviewed'}[grade],0)
 assert row['reviewed']==10
assert result['defaultLoaderCalls']==0 and not result['productionCatalogueHydration'] and not result['sourceEdits']
receipt={'verdict':'v3_execution_and_complete_written_outputs_verified_source_grade_correction_pending','checkedAt':datetime.now(timezone.utc).isoformat(),'method':'Independent JSON/hash/source-metadata and written-to-written reconstruction only; no actual consumer rerun or catalogue hydration','runtime':terminal,'inputsVerified':191,'completeAfterCarsReconstructed':10,'specificAndTermFactsExact':183,'factClaimsVerified':183,'featureClaimsVerified':690,'coreGradesRecounted':170,'fullWrittenPacksReconstructedFromPortable':10,'uniqueReferencedSourcesComparedToFrozenMetadata':len(needed),'summaryClausesVerified':20,'summaryDependenciesVerified':dependency_count,'featureOptionalPaths':{'before':20,'after':20,'exactTypes':['novated_fbt/49/confirmation_needed: 10 per phase','audio_system/65/gradeReviewStatus: 6 per phase','style_refinement/37/gradeReviewStatus: 4 per phase']},'citationOptionalPaths':646,'reportOptionalPaths':6,'numericCoreRankingRows':140,'discoveryRankingCounts':{k:len(v['ranked']) for k,v in result['rankCounts'].items()},'inventorySettlements':c1['settledInventory'],'c1Pass':False,'selectedCriteria':{c['id']:c['pass'] for c in result['selectedCoverage']['criteria']},'sourceGradeCaveat':'Exact-grade maximum-range checks are over-broad for five Cooper/Aceman identities; root reviewing narrow correction. Five exact-trim Countryman maker prices also merit Confirmed with unchanged rung3/unranked GST+delivery basis. Technical v3 pass remains valid against its frozen expectations, not final data/integration acceptance.','outputPins':[pin(p) for p in [D/'result.json',D/'selected-after-cars.json',D/'selected-packs.json',D/'portable.json',D/'claims.json',D/'feature-claims.json',D/'undefined-witnesses.json',D/'claim-undefined-witnesses.json',D/'report-undefined-witnesses.json',D/'run/invocation.json',D/'run/terminal.json',D/'run/after-pins.json',D/'run/stdout.log',D/'run/stderr.log']]}
out=Path('/tmp/mini-review/preflight-v3-output-review.json');out.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'review':pin(out),'facts':len(claims),'features':len(features),'sources':len(needed),'status':receipt['verdict']},indent=2))
