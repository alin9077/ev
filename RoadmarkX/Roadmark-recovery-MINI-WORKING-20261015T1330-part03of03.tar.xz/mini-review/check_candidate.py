import json,pathlib,hashlib,collections,sys
candidate=pathlib.Path(sys.argv[1]); c=json.loads(candidate.read_text()); retained=pathlib.Path('/tmp/mini-research/retained-before-cars.json'); before={r['id']:r for r in json.loads(retained.read_text())}; failures=[];counts=collections.Counter();after={}
def require(test,subject):
 if not test:failures.append(subject)
require(len(before)==10,'ten retained rows')
for key in ['models','variants','versionUpdates','features','configurationUpdates']:require(c[key]==[],f'no {key} changes')
require({x['variantId'] for x in c['versionGuards']}==set(before),'exact retained identity guard set')
for g in c['versionGuards']:
 for key,value in g['before'].items():require(before[g['variantId']].get(key)==value,f'identity before {g["variantId"]}/{key}')
 require(g['before']['year'] is None,f'null formal MY {g["variantId"]}')
for r in c['facts']:
 vid=r['variantId']; f=r['after'];key=f['key'];counts['specificFacts']+=1
 require((vid,key) not in after,f'unique fact {vid}/{key}');after[(vid,key)]=f
 require(before[vid]['facts'].get(key)==r['before'],f'fact before {vid}/{key}')
for t in c['brandTerms']:
 require(set(t['applicableVariantIds'])==set(before),f'explicit ten term recipients {t["key"]}')
 for vid in t['applicableVariantIds']:
  counts['brandTermApplications']+=1
  require(before[vid]['facts'].get(t['key'])==t['before'][vid],f'term before {vid}/{t["key"]}');after[(vid,t['key'])]=t['fact']
for r in c['availability']:
 vid=r['variantId'];counts['availability']+=1
 require(r['before']=={'availability':before[vid]['availability'],'evidence':before[vid]['availabilityEvidence']},f'availability before {vid}')
 e=r['after']['evidence'];require(e['orderStatus']=='listed_unconfirmed' and e['stockStatus']=='unverified',f'no availability promotion {vid}')
 require(e['physicalStockVerified'] is False and e['factoryOrderAcceptanceVerified'] is False,f'no stock/order assertion {vid}')
for r in c['summaries']:
 vid=r['variantId']
 for kind in ['strength','tradeoff']:
  counts['summaryClaims']+=1
  require(bool(r[kind]['text']) and bool(r[kind]['dependencies']),f'summary present {vid}/{kind}')
  for dep in r[kind]['dependencies']:
   counts['summaryDependencies']+=1
   require(after.get((vid,dep['key']),before[vid]['facts'].get(dep['key']))==dep['expected'],f'summary exact fact {vid}/{kind}/{dep["key"]}')
   require(not dep['expected']['issues'],f'clean summary dependency {vid}/{kind}/{dep["key"]}')
   require(dep['key'] not in ['model_year','production_revision','manufacturer_model_code','dc_test_station_kw','battery_kwh','battery_usable_kwh'],f'no unrelated held dependency {vid}/{kind}/{dep["key"]}')
sids=[s['id'] for s in c['sources']];require(len(sids)==len(set(sids)),'unique source IDs')
for s in c['sources']:
 p=pathlib.Path(s['capturePath']);counts['sourceCaptures']+=1
 require(p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==s['captureSha256'],f'source capture hash {s["id"]}')
for (vid,key),f in after.items():
 for sid in f.get('sourceIds',[]):require(sid in sids,f'registered source {vid}/{key}/{sid}')
 require(f['date']=='2026-10-15',f'current reviewed date {vid}/{key}')
 if key=='width_mm':require(f['label']=='Published width' and f['comparisonBasis']=='',f'width basis/label {vid}')
 if key=='price_aud':
  require(f['label']=='Published price' and f['priceEvidence']['rankingEligible'] is False,f'price display/ranking {vid}')
  if 'paul_smith' in vid:
   require(f['value']==60990 and f['buyerGrade']=='reported' and f['priceEvidence']['rung']==5 and f['comparisonBasis']=='Before on-road costs',f'exact reported Paul Smith price {vid}')
  else:
   source=next(s for s in c['sources'] if s['id']==f['sourceIds'][0]);raw=json.loads(pathlib.Path(source['capturePath']).read_text())
   require(f['value']==raw['fromPrice']['grossPrice'] and f['priceEvidence']['rung']==3 and f['comparisonBasis']=='',f'exact delivery-inclusive from-price {vid}')
 if key=='towing_braked_kg':require(f['value'] is None and f['buyerGrade']=='not_published' and len(f['sourceIds'])>=2,f'two-source null towing {vid}')
 if key=='battery_kwh' and 'aceman' in vid:require(f['value']==49.2 and f['comparisonBasis']=='Usable battery capacity',f'Aceman usable basis retained {vid}')
 if key=='battery_kwh' and 'countryman' in vid:require(f['issues'] and f['status']=='conditional' and f['comparisonBasis']=='',f'Countryman battery conflict retained {vid}')
 if key=='battery_usable_kwh':require(f['issues'] and f['status']=='conditional' and f['comparisonBasis']=='',f'Cooper net conflict retained {vid}')
 if key in ['dc_peak_kw','dc_charge_time_min'] and '__82ga_' in vid:require(f['issues'] and f['status']=='conditional' and f['comparisonBasis']=='',f'Countryman E DC conflict retained {vid}/{key}')
core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty','battery_warranty']
for vid in before:
 for key in core:require((vid,key) in after,f'core reviewed {vid}/{key}');counts['coreCells']+=1
receipt={'candidatePath':str(candidate),'candidateSha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'retainedInputSha256':hashlib.sha256(retained.read_bytes()).hexdigest(),'checks':dict(counts),'failures':failures,'scope':'Independent read-only static check of ten retained rows and standalone candidate. No catalogue hydration, integration, build, report or public-site check.'}
print(json.dumps(receipt,indent=2));pathlib.Path('/tmp/mini-review/candidate-v2-static-check.json').write_text(json.dumps(receipt,indent=2)+'\n')
if failures:sys.exit(1)
