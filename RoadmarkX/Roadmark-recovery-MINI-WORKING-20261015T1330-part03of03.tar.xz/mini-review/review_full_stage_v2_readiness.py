import json,hashlib,re
from pathlib import Path
D=Path('/tmp/mini-packet/full-stage-v2');OLD=Path('/tmp/mini-packet/full-stage-v1')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h}
m=read(D/'manifest.json');old=read(OLD/'manifest.json');assert pin(D/'manifest.json')['sha256']=='295de742b61e3c064019a0d959cb5490127645a513ad5322d220b707d70ee814'
ps={p['path']:p for p in m['pins']};op={p['path']:p for p in old['pins']};assert len(ps)==len(m['pins'])==287
for p in m['pins']:assert pin(p['path'])==p,p['path']
for k,v in m.items():
 if isinstance(v,dict) and {'path','bytes','sha256'}<=v.keys():assert ps[v['path']]==v
for p in m['selectedArtifacts'].values():assert ps[p['path']]==p
for p in m['rawOverlayInputs']+m['reconciliationInputs']:assert ps[p['path']]==p
common=set(ps)&set(op);assert all(ps[p]==op[p] for p in common)
assert set(m)-set(old)=={'storageClosure'}
assert {k for k in old if old[k]!=m[k]}=={'script','wrapper','output','runOutput','pins'}
assert (D/'run.py').read_bytes()==(OLD/'run.py').read_bytes()
closure=read(m['storageClosure']['path']);assert len(closure)==21 and all(ps[p['path']]==p for p in closure)
a=read(m['acceptedManifest']['path']);allowed={(p['anchor'],p['file']):p for p in a['inputPins']};actual={}
def take(ref):
 p=Path(a['anchors'][ref['anchor']])/ref['file'];accepted=allowed[(ref['anchor'],ref['file'])]
 assert ref['bytes']==accepted['bytes'] and ref['sha256']==accepted['sha256'];q={'path':str(p),'bytes':ref['bytes'],'sha256':ref['sha256']};assert ps[str(p)]==q;actual[str(p)]=q;return p
def walk(ref):
 j=read(take(ref));take(j['cars']['replacements']);base=j['cars']['baseline']
 if base.get('format')=='storage-index':walk(base)
 else:take(base)
 return j
index=walk(m['storageIndex']);assert len(index['research'])==14
for ref in index['research'].values():take(ref)
assert actual=={p['path']:p for p in closure}
s=(D/'stage.mjs').read_text()
assert s.count('function progress(phase)')==1 and 'const progress=' not in s and 'const selectedBrandProgress=' in s
assert s.index("assertDeclaredJson(data,'/initialResearch'")<s.index('assertResearchUnchanged(data,index)')<s.index('carStages={baseline20:carDigests(cars)}')
assert s.index("assertDeclaredJson(data,'/candidateResearchBeforeDigest'")<s.index('const candidateFields=fieldDigests(data)')
assert "assert.deepStrictEqual([...storageReads].sort(),[...storagePins.keys()].sort())" in s
assert "assert.deepStrictEqual(globalWritten,expectedGlobalWritten,'Complete proposed C1 equality, including unchanged counters and exact evidence arrays')" in s
assert m['timeoutSeconds']==420 and m['killAfterSeconds']==10 and m['automaticRetry'] is False and m['execArgv']==['--max-old-space-size=448','--max-semi-space-size=1','--expose-gc','--import','tsx']
assert m['rootExecutionGrantRequired'] and m['exclusiveHeavySlotRequired'] and not m['productionRegistrationAuthorized'] and not m['normalFullReportInStage']
assert not Path(m['output']).exists() and not Path(m['runOutput']).exists()
# Independently assemble complete expected proposed C1 from frozen evidence and original inventory order, without calling a consumer.
baseline=read(m['acceptedDeepalC1']['path'])['after'];normal=read(m['acceptedNormalReport']['path'])['reconciliation'];assert baseline==normal
r=read(m['reconciliation']['path']);e=read(m['expectedReview']['path']);inv=read(Path(m['repo'])/'data/market-inventory-2026-10-10.json')
sel=set(m['selectedIds']);settled=set(e['expectedSettledInventory']);nonmini=lambda x:x.get('brand','').upper()!='MINI' and x.get('reference') not in sel and x.get('reference') not in settled
assert sum(not nonmini(i) for i in baseline['issues'])==13
expected=json.loads(json.dumps(baseline));ev=json.loads(json.dumps(baseline['evidence']));assert set(ev)==set(r)
ev['checkedAt']=max(ev['checkedAt'],r['checkedAt'])
for k in ['notes','publishedLists','currentVersionReviews','listResolutions','catalogueOnlyDifferences','inventoryResolutions']:ev[k]+=r[k]
order=[]
for kind,key in [('record','records'),('lead','unverifiedLeads')]:
 for row in inv[key]:
  if row.get('vehicleClass') and row['vehicleClass'] not in ['passenger','ute']:continue
  order.append(kind+':'+(row.get('id') or row.get('familyId') or (row['brand']+'-'+row['model'])))
ss=set(baseline['settledInventory'])|settled
expected.update(registryCheckedAt=ev['checkedAt'],reviewedModels=baseline['reviewedModels']+3,reviewedVersions=baseline['reviewedVersions']+10,reviewedVersionIds=baseline['reviewedVersionIds']+[v['carId'] for rev in r['currentVersionReviews'] for v in rev['versions']],validModelReviewIds=baseline['validModelReviewIds']+[rev['id'] for rev in r['currentVersionReviews']],settledInventory=[x for x in order if x in ss],issues=[x for x in baseline['issues'] if nonmini(x)],evidence=ev)
assert expected['reviewedModels']==101 and expected['reviewedVersions']==231 and len(expected['settledInventory'])==len(baseline['settledInventory'])+3 and len(expected['issues'])==200
expectedpath=Path('/tmp/mini-review/full-stage-v2-expected-global-c1.json');expectedpath.write_text(json.dumps(expected,indent=2,ensure_ascii=False)+'\n')
receipt={'verdict':'ready_for_one_new_root_authorized_bounded_full_stage_run','manifest':pin(D/'manifest.json'),'script':m['script'],'wrapper':m['wrapper'],'directPinsVerified':287,'commonV1PinsUnchanged':len(common),'retainedStorageFilesVerifiedAndTerminalPinned':21,'storageClosure':m['storageClosure'],'independentExpectedProposedC1':pin(expectedpath),'v1BlockersResolved':['Unique progress logger/local binding','Strict shape check precedes first initial/proposed digest capture','Entire actual recursive21-file storage closure matches accepted pins and is included in before/after proof','Entire proposed C1 compared against independently accounted baseline+MINI fields and original inventory order'],'selectedProof':'Exact accepted candidate v3,10 selected cars/packs,183 cells,690 claims,40 feature/646 citation/6 report optional paths; actual producers and live/written parity retained.','baselineProof':'409 prefix20 restored once; all seven accepted complete-car and fourteen-field stages through427 Deepal26 required;417 peers exact;427/350/309 fixed.','rankingProof':'Actual grouped membership,within-group peer order,complete values/bases/units via unchanged cars/facts, exclusions,competition ranks,group comparator and insertion-order ties; five MINI WLTP maximum entries;all prices excluded.','globalC1Expected':{'reviewedModels':101,'reviewedVersions':231,'settledInventory':len(expected['settledInventory']),'issues':len(expected['issues']),'pass':False},'runtimeEnvelope':{'oldSpaceMiB':448,'semiSpaceMiB':1,'exposeGc':True,'timeoutSeconds':420,'killGraceSeconds':10,'automaticRetry':False},'noExecutionPerformed':True,'notAccepted':'No full stage result,integration,normal production report,global C1 closure,release or publishing acceptance. Fresh exact root exclusive slot grant remains required.'}
p=Path('/tmp/mini-review/full-stage-v2-readiness-review.json');p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'receipt':pin(p),'expectedGlobalC1':pin(expectedpath),'commonPins':len(common)},indent=2))
