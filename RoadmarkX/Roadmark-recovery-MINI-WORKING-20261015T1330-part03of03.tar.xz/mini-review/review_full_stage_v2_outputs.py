from pathlib import Path
import json,hashlib,collections
D=Path('/tmp/mini-packet/full-stage-v2');O=D/'output';S=Path('/tmp/mini-packet/selected-preflight-v4')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h}
def digest(rows):
 b=b''.join((json.dumps(x,separators=(',',':'),ensure_ascii=False)+'\n').encode() for x in rows)
 return {'rows':len(rows),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
m=read(D/'manifest.json');r=read(O/'stage-receipt.json');t=read(D/'run/terminal.json');invocation=read(D/'run/invocation.json');terminalpins=read(D/'run/after-pins.json');grant=read(D/'root-execution-grant.json')
assert pin(D/'manifest.json')['sha256']=='295de742b61e3c064019a0d959cb5490127645a513ad5322d220b707d70ee814'
assert pin(O/'stage-receipt.json')['sha256']=='12ef502fa4d1dcd3ce45090c8cbcabc0851db9d247d9f1a9e01c00a16fc1f6d3'
assert r['manifestSha256']==invocation['manifestSha256']==terminalpins['manifestSha256']==pin(D/'manifest.json')['sha256']
assert invocation['grantSha256']==pin(D/'root-execution-grant.json')['sha256'] and grant['authorized'] and grant['exclusiveHeavySlotGranted'] and grant['preparedManifestSha256']==r['manifestSha256']
assert invocation['command']==grant['command']==['node',*m['execArgv'],m['script']['path'],'--manifest',str(D/'manifest.json'),'--manifest-sha256',r['manifestSha256']]
assert t['exitCode']==t['rawWaitStatus']==0 and t['elapsedSeconds']<420 and t['automaticRetry'] is False and invocation['beforePinsPassed'] and terminalpins['passed'] and terminalpins['count']==287
for k in ['stdout','stderr']:assert pin(D/f'run/{k}.log')['sha256']==t[k+'Sha256']
assert (D/'run/stderr.log').stat().st_size==0
for p in m['pins']:assert pin(p['path'])==p,p['path']
for name,p in m['selectedArtifacts'].items():assert pin(O/(name+'.json'))['sha256']==p['sha256'],name
selected=read(O/'selected-after-cars.json');acceptedresult=read(S/'result.json');result=read(O/'result.json');assert set(result)==set(acceptedresult)
assert [k for k in result if result[k]!=acceptedresult[k]]==['readInputs']
assert len(read(O/'claims.json'))==183 and len(read(O/'feature-claims.json'))==690
assert len(read(O/'undefined-witnesses.json'))==40 and len(read(O/'claim-undefined-witnesses.json'))==646 and len(read(O/'report-undefined-witnesses.json'))==6
oldcars=read(m['acceptedDeepalCars']['path']);oldfields=read(m['acceptedDeepalFields']['path']);cars=read(O/'car-digest-comparison.json');fields=read(O/'research-field-digests.json');stages=['baseline20','corrected21','current22','current23','current24','candidate25','candidate26'];assert list(cars)==list(fields)==stages+['candidate27']
for stage,n in zip(stages,[409,409,413,413,417,427,427]):assert cars[stage]==oldcars[stage] and len(cars[stage])==n;assert fields[stage]==oldfields[stage] and len(fields[stage])==14
ids=m['selectedIds'];sel=set(ids);before=cars['candidate26'];after=cars['candidate27'];assert [c['id'] for c in after]==[c['id'] for c in before] and len(after)==427
changed=[x['id'] for x,y in zip(after,before) if x!=y];assert changed==ids and sum(x==y for x,y in zip(after,before))==417
selectedDigests={c['id']:digest([c]) for c in selected}
for row in after:
 if row['id'] in sel:assert {k:v for k,v in row.items() if k!='id'}==selectedDigests[row['id']]
assert {k for k in fields['candidate26'] if fields['candidate26'][k]!=fields['candidate27'][k]}=={'metadata','variants','sources'}
assert fields['candidate27']['sources']['rows']==fields['candidate26']['sources']['rows']+46 and fields['candidate27']['variants']['rows']==427
for x in result['readInputs']:assert x['inputRows']==x['retainedRows']==fields['candidate26'][x['field']]['rows'] and x['sha256']==fields['candidate26'][x['field']]['sha256']
transitions=read(O/'metadata-composition.json');oldtransitions=read('/tmp/deepal-packet/full-stage-v4/output/metadata-composition.json');assert transitions[:6]==oldtransitions and len(transitions)==7
for i,tr in enumerate(transitions):
 priorstage=stages[i];nextstage=(stages+['candidate27'])[i+1];assert tr['beforeMetadata']==fields[priorstage]['metadata']
 assert tr['rawMetadata']['brand_update_packet_ids']==[tr['packetId']]
 composed={**tr['rawMetadata'],'brand_update_packet_ids':m['registeredPacketIds'][:21+i] if i<6 else m['registeredPacketIds']+['m1-mini-2026-10-15']}
 assert composed==tr['composedMetadata'] and digest([composed])==fields[nextstage]['metadata']
closure=read(O/'retained-storage-read-closure.json');assert closure['actualReadFiles']==sorted(p['path'] for p in read(m['storageClosure']['path'])) and len(closure['actualReadFiles'])==21 and closure['all21FilesPinnedBeforeAndAfter']
sourceProof=read(O/'source-reference-neutrality.json');assert sourceProof['peerCars']==417 and sourceProof['sourceRowsAdded']==46 and not sourceProof['helperChanges'] and not sourceProof['broadFeatureReplay'];assert len(sourceProof['inspections'])==3+len(m['rawOverlayInputs']);assert all(x['newSourceReferences']==0 and x['nestedGradeReviewsAndKeysIncluded'] for x in sourceProof['inspections'])
c1=read(O/'global-c1-comparison.json');expected=read('/tmp/mini-review/full-stage-v2-expected-global-c1.json');assert c1['after']==c1['expectedCompleteAfter']==expected and c1['completeExpectedWrittenEquality']
assert c1['before']==read(O/'baseline-global-c1.json')==read(m['acceptedDeepalC1']['path'])['after']==read(m['acceptedNormalReport']['path'])['reconciliation']
assert c1['baselineMatchesAcceptedDeepalAndNormal'] and c1['nonMiniIssuesReviewsDispositionsExact'] and not c1['normalFullReportRun'];assert {w['property'] for w in c1['issueOwnership']}=={'brand','reference'} and all(w['ownUndefined'] and w['enumerable'] for w in c1['issueOwnership'])
assert r['selectedC1']==result['currentListProof'] and r['globalC1Counts']=={'reviewedModels':101,'reviewedVersions':231,'pass':False}
for k,v in {'originalBaselineCars':409,'acceptedCurrentCars':427,'stagedCars':427,'tierOneVersions':350,'onSaleVersions':309,'untouchedPeerCars':417,'sourceRowsAdded':46,'actualSelectedCars':10,'actualFactAndTermClaims':183,'actualFeatureClaims':690,'roadsideRefreshes':10,'driveawayFallbacks':10,'defaultLoaderCalls':0}.items():assert r[k]==v
for k in ['newModels','newVersions','versionUpdates','configurationUpdates','manualFeatureUpdates']:assert r[k]==0
for k in ['broadFeatureReplay','normalFullReportRun','liveSourceEdits','productionRegistration']:assert r[k] is False
# Independent written group membership/relative order and input insertion-key proof. Sorting itself is checked in a separate bounded JSON-only Node check.
rankproof=read(O/'global-ranking-comparison.json');e=read(m['expectedReview']['path']);assert len(rankproof)==7
inputorder=[row['id'] for row in before];rankcounts={}
for row in rankproof:
 a,b=row['before'],row['after'];am={x['key']:x for x in a['groups']};bm={x['key']:x for x in b['groups']};assert len(am)==len(a['groups']) and len(bm)==len(b['groups'])
 for side in [a,b]:
  member={};assert side['sortedKeys']==[x['key'] for x in side['groups']]
  for g in side['groups']:
   assert g['count']==len(g['ids'])==len(set(g['ids']));assert g['selectedIds']==[i for i in g['ids'] if i in sel] and g['peerIds']==[i for i in g['ids'] if i not in sel]
   for i in g['ids']:assert i not in member;member[i]=g['key']
  insertion=list(dict.fromkeys(member[i] for i in inputorder if i in member));assert insertion==side['insertionKeys']
 for key in set(am)|set(bm):
  old,new=am.get(key,{}),bm.get(key,{});assert old.get('peerIds',[])==new.get('peerIds',[])
  assert new.get('count',0)==old.get('count',0)-len(old.get('selectedIds',[]))+len(new.get('selectedIds',[]))
 assert {i for g in b['groups'] for i in g['selectedIds']}==set(e['rankingIds'][row['attribute']])
 for k in ['peerMembershipAndWithinGroupOrderExact','insertionTiesProvedFromActualInputOrder','selectedCountDeltasExact']:assert row[k]
 assert all(x['carId'] not in sel for x in row['peerExclusions'])
 rankcounts[row['attribute']]={'beforeAllCatalogue':sum(x['count'] for x in a['groups']),'afterAllCatalogue':sum(x['count'] for x in b['groups']),'selectedRanked':sum(len(x['selectedIds']) for x in b['groups'])}
receipt={'verdict':'bounded_full_stage_v2_outputs_independently_verified','method':'Light JSON/hash review only; no catalogue hydration, producer rerun, broad feature replay, live edit or normal report','manifest':pin(D/'manifest.json'),'stageReceipt':pin(O/'stage-receipt.json'),'terminal':t,'pinsVerified':287,'actualRetainedFilePins':21,'acceptedStagesExact':dict(zip(stages,[409,409,413,413,417,427,427])),'researchFieldsPerStage':14,'changedResearchFields':['metadata','variants','sources'],'allOtherResearchFieldDigestsExact':True,'completePeerCarsExact':417,'selectedCompleteCars':10,'selectedWrittenArtifactsByteExact':list(m['selectedArtifacts']),'factClaims':183,'featureClaims':690,'featureCitationReportOptionalPaths':[40,646,6],'selectedResultOnlyDifference':'readInputs now identifies full structural inputs rather than selected input streams','metadataTransitionsExact':7,'globalC1CompleteExpectedObjectExact':pin('/tmp/mini-review/full-stage-v2-expected-global-c1.json'),'globalC1Counts':r['globalC1Counts'],'globalC1Settlements':60,'globalC1Issues':200,'fixedCatalogueTierOneOnSale':[427,350,309],'globalStructuralRankCounts':rankcounts,'rankingNote':'All-catalogue structural ranking counts, not the on-sale Tier1 coverage headline. Peer membership and relative order inside exact compatible groups preserved; whole groups may move. Actual competition ranks/ties and peer exclusions/unranked equality are asserted by the pinned passed producer run.','groupSortIndependentJsonCheck':'pending companion check','sourceNeutralityInputCount':len(sourceProof['inspections']),'notAccepted':'No production integration, ordinary full coverage report, C1/C2/C5 completion, release or publishing acceptance.','outputPins':[pin(p) for p in sorted(O.glob('*.json'))]+[pin(D/'run'/name) for name in ['invocation.json','terminal.json','after-pins.json','stdout.log','stderr.log']]}
p=Path('/tmp/mini-review/full-stage-v2-output-review.json');p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'review':pin(p),'selectedClaims':183,'features':690,'peers':417,'globalC1Exact':True},indent=2))
