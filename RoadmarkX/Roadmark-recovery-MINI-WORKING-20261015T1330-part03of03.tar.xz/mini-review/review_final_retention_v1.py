from pathlib import Path
import json,hashlib,os,stat
B=Path('/tmp/mini-packet/final-freeze-v1');O=Path('/tmp/mini-review');dest=O/'final-retention-v1-acceptance.json'
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h)
def check(p):assert pin(p['path'])=={k:p[k] for k in ['path','bytes','sha256']},p['path']
x=read(B/'inventory.json');assert not dest.exists();assert x['status']=='author_frozen_metadata_exact_allowlist_pending_backup_capture_and_independent_final_receipt' and x['noFurtherPayloadEdits'] and x['metadataOnlyInventory'] and not x['contentCaptureOrPrivacyScanPerformed'];assert x['finalReviewerReceiptPolicy']['path']==str(dest) and not x['finalReviewerReceiptPolicy']['includedInPayload']
assert x['payloadRoots']==['/tmp/mini-research','/tmp/mini-packet','/tmp/mini-review'];indexed={r['path']:r for r in x['files']};assert len(indexed)==x['totalFiles'];assert x['symlinkCount']==0
exclude={r['path']:r for r in x['excluded']};known={'/tmp/mini-research/__pycache__/capture_public_json.cpython-312.pyc','/tmp/mini-research/__pycache__/capture_sources.cpython-312.pyc','/tmp/mini-packet/post-registration-checks-v1/.exclusive-heavy.lock',str(B),'/workspace/scratch/586427eef9f2/roadmark-104-visual-qa-20261015/snapshot'};assert set(exclude)==known and all(not r['deletionAuthorized'] for r in exclude.values())
observed=set()
for root in x['payloadRoots']:
 for current,dirs,files in os.walk(root,followlinks=False):
  dirs.sort()
  if Path(current)==B:dirs[:]=[];continue
  for name in list(dirs):
   p=Path(current)/name
   assert not p.is_symlink(),str(p)
  for name in files:
   p=Path(current)/name
   if str(p) not in exclude:observed.add(str(p))
expectedInside={p for p in indexed if any(Path(p).is_relative_to(Path(root)) for root in x['payloadRoots'])};assert observed==expectedInside,{'missing':sorted(expectedInside-observed),'extra':sorted(observed-expectedInside)}
for r in x['files']:
 p=Path(r['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and r['kind']=='file' and not p.is_symlink();assert (s.st_size,s.st_mode,s.st_mtime_ns)==(r['bytes'],r['mode'],r['mtimeNs']),r['path']
assert sum(r['bytes'] for r in x['files'])==x['regularFileBytes'];assert Path('/tmp/mini-packet/post-registration-checks-v1/.exclusive-heavy.lock').stat().st_size==0
for key in ['publicImageProvenance','independentDocsReadback','finalRuntimeAcceptance','currentPacket','currentReconciliation','retainedStorageReadClosure','preparer']:check(x[key])
for p in x['sourceAndStatusAfterPins']:check(p)
assert len(x['sourceAndStatusAfterPins'])==7
readback=read(x['independentDocsReadback']['path']);assert readback['status']=='accepted';assert read(x['finalRuntimeAcceptance']['path'])['status']=='accepted'
for r in x['retainedFailures']:
 check(r['terminal']);check(r['diagnosis']);assert read(r['terminal']['path'])['exitCode']==1
required=['/tmp/mini-packet/selected-preflight-v1/prepared-command.json','/tmp/mini-packet/selected-preflight-v2/run/terminal.json','/tmp/mini-packet/selected-preflight-v3/result.json','/tmp/mini-packet/selected-preflight-v4/result.json','/tmp/mini-packet/full-stage-v1/manifest.json','/tmp/mini-packet/full-stage-v2/output/stage-receipt.json','/tmp/mini-packet/report-comparison-v1/sequence.json','/tmp/mini-packet/report-comparison-v2/artifacts/result.json','/tmp/mini-packet/docs-status-v1/manifest.json','/tmp/mini-packet/docs-status-v2/manifest.json','/tmp/mini-packet/full-project-typescript-v1/run/full-project.tsbuildinfo','/tmp/mini-review/docs-status-v2-live-readback.json','/tmp/mini-review/report-comparison-v2-output-review.json']
assert all(p in indexed for p in required)
provenance=read(x['publicImageProvenance']['path']);assert len(provenance['images'])==3
for r in provenance['images']:
 check(r['image']);check(r['parentPdf']);assert r['pageNumber']==4 and r['zeroBasedPageIndex']==3 and not r['browserScreenshot'] and not r['siteAsset'] and not r['rendererInvocationRetained']
# Preserve source/parser/helper pins without executing any producer or broad capture.
sourcepins=read('/tmp/mini-packet/report-comparison-v2/source-pins.json');assert len(sourcepins)==206
for p in sourcepins:check(p)
r={'status':'accepted','inventory':pin(B/'inventory.json'),'preparer':x['preparer'],'docsReadback':x['independentDocsReadback'],'runtimeAcceptance':x['finalRuntimeAcceptance'],'frozenPayloadRoots':x['payloadRoots'],'metadataPathSetAndStatEquality':True,'payloadFiles':x['totalFiles'],'payloadRegularBytes':x['regularFileBytes'],'symlinkCount':0,'sevenLiveTargetsExact':x['sourceAndStatusAfterPins'],'retainedAllFailuresAndSupersededPreparations':True,'originalColdCompilerProofCacheRetained':True,'unchangedSourceContentPinsReverified':206,'futureReceiptPolicy':'This exact receipt is the only intentional post-inventory addition under the reviewer root and is pinned separately. No other wildcard additions.','exclusions':x['excluded'],'publicSourceRenderProvenance':'Three existing official PDF page-4 source-table PNGs; parent and image hashes verified. Renderer invocation/version/DPI was not retained and remains explicitly unknown.','privacyBoundary':'No payload capture, archive, broad sanitation scan or delivery performed by this review. Backup must independently perform authorized capture/sanitation and verify its final exact mapping. Known credential-free factual capture provenance is not a privacy-scan substitute.','scope':'MINI 27 working integration, accepted checks and docs frozen for recovery. Broader M1/release/visual gates remain open. No checkpoint 104, M2, publication or backup delivery acceptance.'}
dest.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(pin(dest)))
