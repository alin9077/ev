from pathlib import Path
import json,hashlib,re,sys
B=Path('/tmp/mini-packet/post-registration-checks-v1'); O=Path('/tmp/mini-review')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h)
def check(p):assert pin(p['path'])=={k:p[k] for k in ['path','bytes','sha256']},p['path']
def meta(p):
 p=Path(p)
 if not p.exists():return {'path':str(p),'exists':False}
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
seq=read(B/'sequence.json'); grant=read(B/'first-five-root-grant.json'); gp=pin(B/'first-five-root-grant.json'); assert gp['sha256']=='1a0759959f0f8c0a70d8fa9b7fcf5ad059b3060107ab70ce329031b85ce4002a'
for k in ['sequence','reviewerAcceptance','registrationVerification']:check(grant[k])
assert grant['granted']==seq['sequence'][:5] and grant['status']=='root_execution_granted' and grant['heavySlotExclusive'] and not grant['automaticRetry']
pins=read(seq['sourcePins']['path']);assert len(pins)==193
for p in pins:check(p)
md=read(seq['rootMetadata']['path'])
for p in md['fileMetadata']+md['directoryState']:assert meta(p['path'])==p,p['path']
repo=Path(read(seq['sequence'][0]['path'])['repo']); cfg=read(repo/'tsconfig.json');assert sorted({str(p.resolve()) for pattern in cfg['include'] for p in repo.glob(pattern) if p.is_file()})==md['configuredRootFilePaths']
checks=[]; details=[];prior_terminal=None
count=int(sys.argv[1]) if len(sys.argv)>1 else 5
assert 1<=count<=5
for pp in seq['sequence'][:count]:
 check(pp);m=read(pp['path']);d=Path(m['runOutput']);r=read(d/'result.json');t=read(d/'terminal.json');iv=read(d/'invocation.json');a=read(d/'after-pins.json');scope=read(d/'scope-verification.json');stdout=(d/'stdout.log').read_text()
 assert r['passed'] and r['exitCode']==0 and r['pinsPassed'] and r['scopePassed'] and not r['automaticRetry'] and not r['nextBuildClaim'];assert r['manifestSha256']==pp['sha256']==iv['manifestSha256'];assert iv['grantSha256']==gp['sha256'] and iv['command']==m['command'] and iv['cwd']==m['repo'];assert iv['supervisedCommand']==['/usr/bin/timeout','--signal=TERM','--kill-after=10s',str(m['timeoutSeconds'])+'s',*m['command']]
 assert t['exitCode']==0 and not t['watchdogFired'] and not t['automaticRetry'] and t['elapsedSeconds']<m['timeoutSeconds'];assert t['stdoutSha256']==pin(d/'stdout.log')['sha256'] and t['stderrSha256']==pin(d/'stderr.log')['sha256'] and (d/'stderr.log').stat().st_size==0
 assert a['passed'] and scope['passed'] and scope['sourceScopeUnchanged'] and scope['registrationTargetMetadataUnchanged'];assert a['count']==len([m['wrapper'],m['sourcePins'],m['rootMetadata'],m['testInventory'],m['registrationManifest'],*pins,*m['extraPins'],grant['sequence'],grant['reviewerAcceptance'],grant['registrationVerification']])
 if prior_terminal:assert iv['at']>prior_terminal
 prior_terminal=t['at']
 for p in m['runtimeMetadata']:assert meta(p['path'])==p
 assert cfg==m['originalConfig']; before=read(d/'registration-target-metadata-before.json'); assert before==[meta(p['path']) for p in m['registrationTargets']]
 for p in m['registrationTargets']:check(p)
 if m['kind']=='market':assert stdout=='Market view verified without writing\n'
 elif m['kind']=='lint':
  rows=json.loads(stdout);assert len(rows)==1 and rows[0]['filePath']==str(repo/'scripts/reporting/load.ts');assert rows[0]['messages']==[] and rows[0]['suppressedMessages']==[] and all(rows[0][k]==0 for k in ['errorCount','warningCount','fatalErrorCount','fixableErrorCount','fixableWarningCount'])
 elif m['kind']=='tests':
  inv=read(m['testInventory']['path']);names=[n for f in m['testFiles'] for n in inv[f]['names']];assert len(names)==m['expectedTests'];observed=re.findall(r'^# Subtest: (.*)$',stdout,re.M);assert sorted(observed)==sorted(names)
  for key,n in [('tests',len(names)),('pass',len(names)),('fail',0),('cancelled',0),('skipped',0),('todo',0)]:assert re.search('^# '+key+' '+str(n)+'$',stdout,re.M)
  assert len(re.findall(r'^ok \d+ - ',stdout,re.M))==len(names) and not re.search(r'^not ok\b',stdout,re.M)
 elif m['kind']=='structural':
  x=json.loads(stdout);assert x['result']=='PASS' and x['counts']==m['expectedStructuralCounts'] and x['sourceReferences']==m['expectedSourceReferences'] and x['publicationIssues']==m['expectedPublicationIssues'] and x['approvedExternalAssets']==0 and x['sha256']==m['immutableResearchSha256']
 else:raise AssertionError(m['kind'])
 checks.append(dict(name=m['id'],passed=True,exitCode=0,manifest=pp,result=pin(d/'result.json'),terminal=pin(d/'terminal.json')))
 details.append(dict(name=m['id'],elapsedSeconds=t['elapsedSeconds'],maxRssKiB=t['maxRssKiB'],stdout=pin(d/'stdout.log'),stderr=pin(d/'stderr.log'),afterPins=pin(d/'after-pins.json'),invocation=pin(d/'invocation.json'),actualCommand=iv['command'],exactTestCount=m.get('expectedTests'),allSourcePinsIndependentlyVerified=193,rootNames=361,unchangedRootStats=360,fourTargetStatsExact=True))
r={'status':'accepted','applicationManifestSha256':seq['registrationManifest']['sha256'],'checks':checks,'details':details,'sequence':pin(B/'sequence.json'),'rootGrant':gp,'registrationVerification':grant['registrationVerification'],'scope':'Actual completed first '+str(count)+' scoped gates only','allFivePrerequisitesAccepted':count==5,'noTypeScriptNormalReportOrBuildAcceptance':True,'reviewerExecutedProducerCommands':False,'memoryNote':'V8 heap flags are not an RSS cap; terminal max RSS is the process wait4 measure, not a sum of simultaneous process-tree memory'}
p=O/(f'post-registration-first-{count}-gate-results-v1.json' if count<5 else 'post-registration-five-gate-results-v1.json');assert not p.exists();p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(pin(p)));print(json.dumps([{'name':x['name'],'elapsedSeconds':x['elapsedSeconds'],'maxRssKiB':x['maxRssKiB']} for x in details]))
