# Independent MINI M1 source review, 15 October 2026

Status: preliminary source review only. The author is still preparing the exact proposal/manifest. No acceptance of an unapplied packet, full catalogue validation, market closure, or live change is implied.

## Confirmed source findings

- Ten retained exact identities are supported by the current Australian brochures: Cooper SE Favoured, Cooper JCW Electric, Cooper SE Paul Smith Edition; Aceman SE, Aceman JCW; Countryman E Classic, E Favoured, SE ALL4 Classic, SE ALL4 Favoured and SE ALL4 JCW Sport. J01/J05 normal range feeds expose two motor grades each; Countryman U25E exposes E/SE with the corresponding two/three style codes. Formal model year must remain null. Current PDFs explicitly scope Cooper/Aceman to September 2026 production and Countryman/Paul Smith to July 2026 production; API dates and future illustrative production dates are not formal MY proof.
- Nine maker JSON from-prices are factual, not reconstructed MRLP. Public unauthenticated independent GET spot checks reproduced Cooper SE 61,489.70 and Countryman SE ALL4 JCW Sport 82,490.01. Both include GST and 2,500 dealer delivery in the returned tax components. Preserve exact amounts, rung 3 and the delivery-inclusive basis. Do not subtract delivery, round to a fabricated MRLP, label national driveaway, or establish a before-on-road ranking basis from a tax component's omission. There is no demonstrated complete driveaway or exact MRLP quote in these JSON captures.
- Paul Smith 60,990 before on-road costs is explicitly reported in the CarExpert 30 April 2026 article. This is eligible secondary evidence with the Reported grade, not maker price evidence: https://www.carexpert.com.au/car-news/2026-mini-cooper-se-paul-smith-edition-arrives-in-australia
- Maker battery conflicts are real: Cooper PDF 49.8 net versus current web/technical JSON 49.2; Paul Smith-specific PDF 48.2 net versus regular Cooper references; Countryman current grade pages 66 net versus web/technical JSON 64.8. The Cooper/Paul Smith brochures agree on 54.2 gross, which is a separately clean figure. Countryman PDF p4 uses a single 66 figure under an ambiguous usable/gross label; it cannot establish clean gross capacity. CarExpert's August review adds 66.5 gross/65.2 usable but does not resolve the maker conflict.
- Countryman E DC peak remains 95 kW in current PDF versus 130 kW in current technical JSON and charging page. Countryman SE ALL4 130 is consistent. E's 29-minute 10–80% claim remains linked to the unresolved charging specification; do not make a clean ranking/strength claim by ignoring that dependency.
- Current maker warranty PDF p7 supports J01/J05/U25 battery defects 8 years/160,000 km, separately from F56/F57 8 years/100,000 km. Vehicle warranty is 5 years/unlimited km for ordinary use, with 200,000 km hire/reward/instruction limitation. The 70% capacity-retention row explicitly starts with first registrations from 1 April 2026. Retain scope and terms when inheriting; do not import the secondary review's incorrect 100,000 km electric warranty.
- Boot figures in maker technical JSON are 210–800 L Cooper, 300–1005 L Aceman and 460–1450 L Countryman. The numeric lower endpoints alone do not prove VDA/SAE or load-height basis. Keep truthful basis/measurement qualifications, rather than relabeling a normalized luggage standard.

## Closure and availability safeguards

- CarsGuide's complete calendar-2026 lists still contain Cooper E, Aceman E and Countryman E Core; these are explicit reconciliation differences against the current maker normal range. Paul Smith is omitted by those table lists. The independently observed table extracts and no-value receipt are under /tmp/mini-research/reviewer-secondary.
- Current range omission does not prove there are no residual new cars. Keep the three older grades' residual-new/orderability disposition explicit. Countryman E Core deletion is positively reported in CarExpert's 12 June 2026 current-range story.
- Retain the prior 1965 Victory Edition lead with its unresolved current electric new/order evidence. Untamed's Australian maker page has enquiry/contact CTAs and mentions a 2027 colour/configurator date; that is not exact current Australian order acceptance, a complete orderable trim list or a price. Oxford must be correctly separated as petrol if discussed.
- No catalogue listing or dealer advertisement establishes physical stock. Keep public catalogue/order/interest evidence separate from verified stock and individual factory order acceptance.

## Proposal review gates still pending

- Exact frozen manifest and proposed overlay/reconciliation files
- Correct core fact values, grades and measurement bases on every intended identity
- Per-gap two-source checks and explicit reasons, without manufacturing zero/not-towable facts
- Brand warranty inheritance plus explicit actual exceptions
- Claim-only buyer strength/trade-off dependencies; existing arrays include unrelated held battery/DC/model-year guards and should not carry forward
- Strict write-set isolation, untouched immutable source, all ten identities preserved and held leads not promoted

## Verification receipts

- /tmp/mini-review/provenance-check.json: 37 inspected source files matched their author provenance SHA-256 values
- /tmp/mini-review/price-22GC-independent.json and /tmp/mini-review/price-12HP-S0ZM4-independent.json: public unauthenticated GET spot checks, factual allowlists only
- No raw runtime configuration was read; no credentials, keys, tokens, cookies or custom authentication headers were requested or supplied
- No catalogue hydration, heavy replay/test, repository edit, cloud task, user-computer action or publication was performed
