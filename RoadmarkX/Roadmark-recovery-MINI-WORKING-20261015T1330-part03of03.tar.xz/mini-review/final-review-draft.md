# MINI M1 independent source review

Reviewed on 15 October 2026. Verdict: the candidate is acceptable for isolated staged guard, grade and report validation. It is not an approval for direct live registration, publication, or a claim that MINI or whole-market M1 is complete.

## Accepted scope

- The existing ten exact Australian identities remain unchanged, with formal model year null and the documented July/September production applicability preserved. No model or version is added or deleted.
- All 170 core cells have an explicit proposed review. The candidate contains 153 specific fact updates, three inherited terms applied to ten versions, ten identity guards and ten guarded availability updates.
- Nine maker from-prices preserve their actual JSON amounts and GST/dealer-delivery basis. They are neither converted to MRLP nor claimed as driveaway, and remain outside price rankings. Paul Smith's A$60,990 before-on-road figure is correctly Reported from its exact CarExpert article and has a retained factual source capture.
- Genuine net-battery, Countryman E DC and roadside conflicts stay visible, conditional and outside normalized comparisons. Clean gross capacity remains separately supported. Aceman retains its existing 49.2 kWh usable core basis.
- All ten towing gaps have a documented two-source check and no fabricated zero. Boot and width figures preserve their limited stated measurement basis. The misleading inherited price/width labels have been corrected.
- Maker vehicle and J01/J05/U25 battery warranty terms are inherited with commercial-use and first-registration eligibility distinctions intact.
- Availability refreshes current catalogue evidence without re-dating historic advertisements or claiming physical stock or accepted factory orders.
- All twenty strength/trade-off clauses have clean, claim-only dependencies. The 27 exact dependency fingerprints match the proposed facts.
- The residual census preserves older E/E Core, Victory and Untamed uncertainty. Oxford is explicitly excluded as petrol using exact Australian evidence. The brand-only reconciliation does not claim whole-market C1 closure.

## Independent verification

A standalone Python review compared only the ten retained rows with the candidate, checked source capture hashes, factual price identity/basis, warranty recipients, conflict holds, all before-state guards and summary fingerprints. It found no failures. All source and supporting-artifact pins in the final research manifest were separately verified.

I also checked the maker PDF page images for the Cooper net-battery and Countryman battery/DC conflicts, independently read the exact Paul Smith price article and the three CarsGuide model tables, and independently repeated two maker price GETs without credentials, cookies, tokens, keys or custom headers. No raw runtime configuration was read or retained.

## Remaining boundaries

- The importer/schema/typecheck, isolated application, coverage/ranking effects, behavioural tests and build have not been run by this review. Their results remain a separate integration gate.
- Price, maximum WLTP range and unspecified boot-measurement rankings remain unavailable for the reviewed claims; towing remains Not published. Genuine source conflicts have not been resolved merely by making their figures visible.
- Physical new stock, individual factory-order acceptance and residual-new availability remain unverified. No current held lead is promoted to a purchasable exact version.
- No catalogue hydration, heavy replay, live repository edit, user-computer action, cloud task or publication occurred during this review.

## Reproducing the light check

Run the standalone reviewer script against the frozen candidate:

python /tmp/mini-review/check_candidate.py /tmp/mini-packet/mini-2026-10-15-candidate-v2.json

The script reads the ten retained MINI rows and the standalone candidate only. It does not import or hydrate the live catalogue.
