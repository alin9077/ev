from pathlib import Path
from collections import Counter
import json,hashlib,copy,re,math
B=Path('/tmp/mini-packet/report-comparison-v2');A=B/'artifacts';O=Path('/tmp/mini-review');repo=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h)
def check(p):assert pin(p['path'])=={k:p[k] for k in ['path','bytes','sha256']},p['path']
def meta(p):
 p=Path(p)
 if not p.exists():return {'path':str(p),'exists':False}
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
def pct(n,d):return math.floor(n/d*1000+0.5)/10 if d else None
def differences(a,b,path=''):
 if type(a)!=type(b):
  if isinstance(a,(int,float)) and isinstance(b,(int,float)) and a==b:return []
  return [(path,a,b)]
 if isinstance(a,dict):
  out=[]
  for k in list(a)+[k for k in b if k not in a]:
   p=path+'/'+k.replace('~','~0').replace('/','~1')
   if k not in a or k not in b:out.append((p,a.get(k),b.get(k)))
   else:out.extend(differences(a[k],b[k],p))
  return out
 if isinstance(a,list):
  return sum([differences(a[i],b[i],path+'/'+str(i)) if i<len(a) and i<len(b) else [(path+'/'+str(i),None,None)] for i in range(max(len(a),len(b)))],[])
 return [] if a==b else [(path,a,b)]
seq=read(B/'sequence.json');grant=read(B/'root-execution-grant.json');gp=pin(B/'root-execution-grant.json')
assert grant['status']=='root_execution_granted' and grant['heavySlotExclusive'] and not grant['automaticRetry'] and not grant['parallelExecutionAllowed'];assert grant['granted']==seq['sequence']
for k in ['sequence','reviewerAcceptance','registrationVerification']:check(grant[k])
shared=read(seq['sourcePins']['path']);assert len(shared)==206;unique={};runs=[];last=None
for p in seq['sequence']:
 check(p);m=read(p['path']);d=Path(m['runOutput']);r=read(d/'result.json');t=read(d/'terminal.json');iv=read(d/'invocation.json');a=read(d/'after-pins.json');scope=read(d/'scope-verification.json')
 assert r['passed'] and r['exitCode']==0 and r['pinsPassed'] and r['scopePassed'] and not r['automaticRetry'];assert r['manifestSha256']==iv['manifestSha256']==p['sha256'] and iv['grantSha256']==gp['sha256'] and iv['command']==m['command'];assert iv['supervisedCommand']==['/usr/bin/timeout','--signal=TERM','--kill-after=10s',str(m['timeoutSeconds'])+'s',*m['command']]
 assert t['exitCode']==0 and not t['watchdogFired'] and t['elapsedSeconds']<m['timeoutSeconds'] and not t['automaticRetry'];assert (d/'stderr.log').stat().st_size==0
 for k in ['stdout','stderr']:assert t[k+'Sha256']==pin(d/(k+'.log'))['sha256']
 assert a['passed'] and scope['passed'] and scope['sourceScopeUnchanged'] and scope['registrationTargetMetadataUnchanged'];allpins=[m['wrapper'],m['sourcePins'],m['rootMetadata'],m['testInventory'],m['registrationManifest'],*shared,*m['extraPins'],grant['sequence'],grant['reviewerAcceptance'],grant['registrationVerification']];assert a['count']==len(allpins)
 for q in allpins:check(q);unique[q['path']]=q
 assert read(d/'registration-target-metadata-before.json')==[meta(q['path']) for q in m['registrationTargets']]
 for q in m['registrationTargets']:check(q)
 for q in m['runtimeMetadata']:assert meta(q['path'])==q
 if last:assert iv['at']>last
 last=t['at'];runs.append(dict(name=m['id'],manifest=p,result=pin(d/'result.json'),terminal=pin(d/'terminal.json'),stdout=pin(d/'stdout.log'),afterPins=pin(d/'after-pins.json'),elapsedSeconds=t['elapsedSeconds'],maxRssKiB=t['maxRssKiB']))
md=read(seq['rootMetadata']['path']);cfg=read(repo/'tsconfig.json');assert cfg==m['originalConfig'];assert sorted({str(p.resolve()) for pattern in cfg['include'] for p in repo.glob(pattern) if p.is_file()})==md['configuredRootFilePaths']
for q in md['fileMetadata']+md['directoryState']:assert meta(q['path'])==q
normal=read(B/'normal-coverage-asof-2026-10-15/stdout.log');baseline=read('/workspace/scratch/586427eef9f2/roadmark-104-qa/deepal-continuation-checks/normal-coverage-asof-2026-10-15/stdout.log');before=read(A/'selected-before-report.json');after=read('/tmp/mini-packet/selected-preflight-v4/result.json')['selectedCoverage'];bcars=read('/tmp/mini-research/retained-before-cars.json');acars=read('/tmp/mini-packet/full-stage-v2/output/selected-after-cars.json');ids={c['id'] for c in bcars};assert len(ids)==10
assert [normal[k] for k in ['allCatalogueVersions','tierOneVersions','onSaleVersions']]==[427,350,309] and normal['asOf']=='2026-10-15';assert pin(B/'normal-coverage-asof-2026-10-15/stdout.log')['sha256']=='0cd717ad3b1db049e14559010770b9b5dfb1e9ed05718ca7635d82a6bbde4464'
assert [x for x in normal['brandProgress'] if x['brand']!='MINI']==[x for x in baseline['brandProgress'] if x['brand']!='MINI'];assert next(x for x in normal['brandProgress'] if x['brand']=='MINI')==after['brandProgress'][0]
dig=read('/tmp/mini-packet/full-stage-v2/output/car-digest-comparison.json');order={c['id']:i for i,c in enumerate(dig['candidate26'])};assert len(order)==427;peerproof=read(A/'accepted-peer-car-value-and-basis-proof.json');assert peerproof['peers']==[x for x in dig['candidate26'] if x['id'] not in ids]==[x for x in dig['candidate27'] if x['id'] not in ids] and len(peerproof['peers'])==417
peer=lambda rows:[x for x in rows if x.get('carId') not in ids]
selected=lambda rows:[x for x in rows if x.get('carId') in ids]
reasonproof=read(A/'global-core-complete-reason-inventory.json');assert len(reasonproof)==17
labels={'confirmed':'Confirmed','check':'Check','reported':'Reported','not_published':'Not published'}
def selected_reasons(cars,key,expected):
 counts=Counter();grades=Counter()
 for car in cars:
  keys={'drive':['drive','drive_type','drivetrain'],'dc_charge_time_min':['dc_charge_time_min','dc_10_80_min','dc_charge_10_80_min']}.get(key,[key]);facts=[car['facts'][k] for k in keys if k in car['facts']];fact=next((f for f in facts if f.get('value') is not None and f.get('value')!=''),facts[0] if facts else {})
  grade=labels.get(fact.get('buyerGrade'),'Unreviewed');grades[grade]+=1
  if grade=='Confirmed':continue
  if key=='drive' and not fact and car.get('drive'):reason='Drive value exists without a per-fact grade'
  elif grade=='Unreviewed':reason='Value missing; no valid completed two-source search recorded' if fact.get('value') in [None,''] else ('Recorded grade review has incomplete or invalid evidence' if fact.get('gradeReview') else 'Published value has no auditable M1 grading review')
  else:reason=fact.get('gradeReview',{}).get('reason') or ('Value missing; no completed two-source search recorded' if fact.get('value') in [None,''] else 'Published value has no auditable M1 grading review')
  counts[re.sub(r'\s+',' ',reason).strip()]+=1
 assert all(grades[g]==n for g,n in expected['grades'].items())
 return counts
for old,new,b,a,proof in zip(baseline['core'],normal['core'],before['core'],after['core'],reasonproof):
 key=old['key'];assert key==new['key']==b['key']==a['key']==proof['key'];assert new['filled']==old['filled']-b['filled']+a['filled'] and new['total']==old['total']==309
 for g,n in old['grades'].items():assert new['grades'][g]==n-b['grades'][g]+a['grades'][g]
 for side,cell in [('before',old),('after',new)]:
  reasons=proof[side+'FullReasons'];assert len(dict(reasons))==len(reasons) and sum(n for reason,n in reasons)==309-cell['grades']['Confirmed'];assert all(isinstance(n,int) and n>0 for reason,n in reasons)
  explanation='; '.join(f'{n}: {reason}' for reason,n in sorted(reasons,key=lambda p:-p[1])[:2]) if cell['grades']['Confirmed']/309<0.5 else None
  assert cell['explanation']==proof[side+'Explanation']==explanation
 beforeCounts=Counter(dict(proof['beforeFullReasons']));afterCounts=Counter(dict(proof['afterFullReasons']));beforeCounts.subtract(selected_reasons(bcars,key,b));beforeCounts.update(selected_reasons(acars,key,a));assert beforeCounts==afterCounts
 assert new['filledPercent']==pct(new['filled'],309) and new['confirmedPercent']==pct(new['grades']['Confirmed'],309) and new['reviewed']==309-new['grades']['Unreviewed'] and new['reviewedPercent']==pct(new['reviewed'],309);assert new['passes']==(new['filled']/309*100>=new['target']) and new['gradingPasses']==(new['grades']['Unreviewed']==0)
coreorder={c['key']:i for i,c in enumerate(normal['core'])};expectedgaps=sorted(peer(baseline['gaps'])+after['gaps'],key=lambda x:(coreorder[x['key']],order[x['carId']]));assert normal['gaps']==expectedgaps and len(expectedgaps)==312
stage=read('/tmp/mini-packet/full-stage-v2/output/global-ranking-comparison.json');rankproof=read(A/'ranking-group-order-and-peer-proof.json');rankcounts={}
def segments(r):
 offset=0;out={}
 for g in r['groups']:
  k=json.dumps([g['vehicleClass'],g['basis'],g['unit']],separators=(',',':'),ensure_ascii=False);out[k]=r['rankedIds'][offset:offset+g['count']];offset+=g['count']
 assert offset==len(r['rankedIds']) and len(set(r['rankedIds']))==offset
 return out
for old,new,b,a,proof in zip(baseline['rankings'],normal['rankings'],before['rankings'],after['rankings'],rankproof['groups']):
 assert old['key']==new['key']==b['key']==a['key']==proof['key'];assert new['ranked']==old['ranked']-b['ranked']+a['ranked'];assert new['percent']==pct(new['ranked'],309) and new['passes']==(new['ranked']/309>=0.9)
 assert new['excluded']==sorted(peer(old['excluded'])+a['excluded'],key=lambda x:order[x['carId']]);assert new['exclusionReasons']==dict(Counter(x['reason'] for x in new['excluded']))
 og,ng,bg,ag=map(segments,[old,new,b,a]);assert list(ng)==proof['newOrder'];assert list(og)==proof['oldOrder'];assert sum(g['count'] for g in new['groups'])==new['ranked'];assert {k:[x for x in v if x not in ids] for k,v in ng.items() if any(x not in ids for x in v)}=={k:[x for x in v if x not in ids] for k,v in og.items() if any(x not in ids for x in v)}
 assert {k:[x for x in v if x in ids] for k,v in ng.items() if any(x in ids for x in v)}==ag
 sr=next(x for x in stage if x['attribute']==new['key']);members=set(new['rankedIds']);projection={g['key']:[x for x in g['ids'] if x in members] for g in sr['after']['groups'] if any(x in members for x in g['ids'])};assert projection==ng
 assert proof['actualProductionGroupComparator'] and proof['exactNumericInterleavingFromAcceptedStage'];assert sorted((g['count'] for g in new['groups']),reverse=True)==[g['count'] for g in new['groups']];rankcounts[new['key']]=new['ranked']
assert rankcounts=={'range_km':231,'price_aud':172,'dc_charge_time_min':177,'seats':207,'boot_l':52,'towing_braked_kg':153}
assert normal['summaryGaps']==baseline['summaryGaps'] and normal['unresolvedLeads']==baseline['unresolvedLeads'];assert normal['missingModels']==[x for x in baseline['missingModels'] if x['brand']!='MINI'];assert normal['ageing']==baseline['ageing']
c1=read('/tmp/mini-packet/full-stage-v2/output/global-c1-comparison.json');assert normal['reconciliation']==c1['after'] and baseline['reconciliation']==c1['before'];assert [normal['reconciliation'][k] for k in ['reviewedModels','reviewedVersions']]==[101,231]
assert normal['grading']=={'reviewedCoreCells':5026,'totalCoreCells':5253,'reviewedPercent':pct(5026,5253)};assert normal['gradeNote']==baseline['gradeNote'].replace(str(baseline['grading']['reviewedCoreCells'])+'/'+str(baseline['grading']['totalCoreCells']),'5026/5253')
for key,prop,negate in [('brandsResearchCompleted','researchCompleted',False),('brandsResearchRemaining','researchCompleted',True),('brandsDone','done',False),('brandsRemaining','done',True)]:assert normal[key]==[x['brand'] for x in normal['brandProgress'] if bool(x[prop])!=negate]
assert normal['pairedOnSale']==309 and normal['pairedOnSalePercent']==100 and normal['inAllRankings']==len(set.intersection(*(set(r['rankedIds']) for r in normal['rankings'])))==26 and normal['inAllRankingsPercent']==pct(26,309)
assert [c['pass'] for c in normal['criteria']]==[False,False,False,False,False,True]
allowed={'gradeNote','core','gaps','rankings','missingModels','reconciliation','grading','brandsResearchCompleted','brandsResearchRemaining','brandProgress','criteria'};assert {k for k in normal if normal[k]!=baseline[k]}==allowed
features=read(A/'selected-before-features.json');packs=read('/tmp/mini-packet/full-stage-v2/output/selected-packs.json');assert len(features)==690
for f in features:
 assert f['variant_id'] in ids
 if f['criterion']!='roadside_assistance':assert f==next(x for x in packs[f['variant_id']]['features'] if x['criterion']==f['criterion'])
fresh=read(A/'selected-freshness-producer-proof.json');assert len(fresh['actualSelectedFeatureProducers'])==10 and sum(x['actualCanonicalRows'] for x in fresh['actualSelectedFeatureProducers'])==690;assert fresh['before']==before['ageing'] and fresh['after']==after['ageing']
issue=read(A/'selected-before-c1-issue-producer.json');assert issue['issue']==before['brandProgress'][0]['closureIssues'][0] and {x['property'] for x in issue['exactOwnership']}=={'brand','reference'} and all(x['ownUndefined'] and x['enumerable'] for x in issue['exactOwnership'])
proof=read(A/'result.json');assert proof['passed'] and proof['allNormalLeavesAccounted'] and proof['completeCoreReasonInventory'] and not proof['broadFeatureReplay'] and proof['peerFeaturesReplayed']==proof['defaultLoaderCalls']==0 and proof['normalReportSha256']==runs[0]['stdout']['sha256'];assert read(A/'expected-versus-normal-diff.json')==[];assert len(differences(baseline,normal))==proof['exhaustiveDifferences']==len(read(A/'exhaustive-normal-versus-deepal-diff.json'))==2610
receipt={'status':'accepted','sequence':pin(B/'sequence.json'),'readiness':grant['reviewerAcceptance'],'rootGrant':gp,'runs':runs,'normalReport':runs[0]['stdout'],'comparisonResult':pin(A/'result.json'),'comparisonExpectedDiff':pin(A/'expected-versus-normal-diff.json'),'allArtifactPins':[pin(p) for p in sorted(A.iterdir()) if p.is_file()],'independentOutputChecks':{'fixedCounts':[427,350,309],'exactPeerCompleteCars':417,'exactPeerBrandObjects':55,'all17CoreCountsGradesRates':True,'all17CompleteReasonCountDeltasMatchExactBeforeAfterSelectedFacts':True,'allGlobalLowConfirmedExplanationsMatchCompleteReasonInventory':True,'exhaustiveChangedLeaves':2610,'unexplainedDiffs':0,'compatibleRankMembershipNumericInterleavingAndPeerOrder':True,'fullExcludedArraysFromCatalogueTraversal':True,'otherFullArraysExact':True,'globalC1EqualsIndependentlyAcceptedStage':True,'selectedBeforeFeatures':690,'selectedUnchangedNonRoadsideFeatures':680,'exactOptionalC1OwnershipWitnesses':True,'all206SharedPinsAndExtraDependenciesVerified':True,'rootConfigCacheAndRegistrationStatsUnchanged':True},'globalResults':{'ranked':rankcounts,'reviewedCoreCells':5026,'totalCoreCells':5253,'coreGaps':312,'reviewedModels':101,'reviewedVersions':231,'c1Issues':len(normal['reconciliation']['issues']),'unmatchedAuditModels':len(normal['missingModels']),'unresolvedLeads':len(normal['unresolvedLeads']),'criteria':[{'id':x['id'],'pass':x['pass']} for x in normal['criteria']]},'miniResults':{'researchCompleted':True,'coverageQualified':False,'coreGrades':{'Confirmed':136,'Check':23,'Reported':1,'Not published':10},'criteria':after['brandProgress'][0]['criteria'],'onlyUnderHalfConfirmedCoreField':'Braked towing; ten explicit two-source absences, not zero ratings','rankedRange':5,'rankedPrice':0,'rankedDcTime':8},'scope':'One actual unchanged production report and its separate exact saved-output comparator accepted. Global C1–C5 remain open; no Next build claim. Reviewer performed only read-only artifact/hash/JSON checks.'}
p=O/'report-comparison-v2-output-review.json';assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(pin(p)))
