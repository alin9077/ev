from pathlib import Path
import json,hashlib,ast
B=Path('/tmp/mini-packet/report-comparison-v2');A=Path('/tmp/mini-packet/report-comparison-v1');O=Path('/tmp/mini-review'); pins={}
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h)
def check(p):
 actual=pin(p['path']);assert actual=={k:p[k] for k in ['path','bytes','sha256']},p['path']
 if actual['path'] in pins:assert pins[actual['path']]==actual
 pins[actual['path']]=actual
s=read(B/'sequence.json');assert pin(B/'sequence.json')['sha256']=='1451c50601e5de1514c7446dbd9154941b6f419269e8bc5c494c7270f52e4950'; assert s['normalReportRuns']==1 and not s['normalReportSubstitutionAllowed'] and s['priorChecksAndFullProjectTypeScriptRequired'] and s['noAutomaticRetry'] and not s['extraBroadFeatureReplay'] and not s['executionAuthorized']
for pp in s['sequence']:
 check(pp);m=read(pp['path']);old=read(A/Path(pp['path']).name)
 for k in ['wrapper','sourcePins','rootMetadata','testInventory','registrationManifest']:check(m[k])
 for p in read(m['sourcePins']['path'])+m['extraPins']+m['registrationTargets']:check(p)
 for p in m['prerequisites']:check(p['manifest'])
 for k in ['repo','exclusiveLock','killAfterSeconds','automaticRetry','parallelExecutionAllowed','sourceMutationsAuthorized','rootMetadata','testInventory','registrationManifest','registrationTargets','originalConfig','runtimeMetadata','environmentRemovals','environmentOverrides','id','kind','timeoutSeconds']:assert m[k]==old[k]
 assert m['wrapper']['sha256']=='c352e82a50f0d32892ecd68788c8e8713041fecb03a30de60b2dcc19ccd103fe'
 assert m['command'][0:3]==['/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','--max-old-space-size=448','--max-semi-space-size=1']
 assert m['timeoutSeconds']==(900 if m['kind']=='normal-report' else 180) and m['killAfterSeconds']==10
 assert not Path(m['runOutput']).exists()
 if m['kind']=='normal-report':assert m['command']==old['command'] and m['prerequisites']==old['prerequisites']
 else:assert m['command'][:-1]==old['command'][:-1] and m['command'][-1]==str(B/'compare-report.mjs');assert m['prerequisites'][0]['manifest']==s['sequence'][0]
assert (B/'source-pins.json').read_bytes()==(A/'source-pins.json').read_bytes();assert len(read(B/'source-pins.json'))==206
assert (B/'run.py').read_bytes()==(A/'run.py').read_bytes();ast.parse((B/'run.py').read_text())
closure=read(B/'static-import-closure.json');assert closure==read(A/'static-import-closure.json') and len(closure['files'])==114
for p in closure['files']:check(p)
assert set(p['path'] for p in read('/tmp/mini-review/full-stage-v1-storage-closure.json'))<=set(pins)
# Written baseline producer traversal, using only existing accepted data.
b=read('/workspace/scratch/586427eef9f2/roadmark-104-qa/deepal-continuation-checks/normal-coverage-asof-2026-10-15/stdout.log');cars=read('/tmp/mini-packet/full-stage-v2/output/car-digest-comparison.json');order={c['id']:i for i,c in enumerate(cars['candidate26'])};assert len(order)==427
for r in b['rankings']:assert r['excluded']==sorted(r['excluded'],key=lambda r:order[r['carId']])
assert b['summaryGaps']==sorted(b['summaryGaps'],key=lambda r:order[r['carId']])
for k in ['overdue','invalid','excludedHistory']:assert b['ageing'][k]==sorted(b['ageing'][k],key=lambda r:(r['kind']=='equipment',order[r['carId']]))
# Read-only current metadata, same fixed roots and only registration transitions.
meta=read(s['rootMetadata']['path'])
for expected in meta['fileMetadata']:
 p=Path(expected['path']);t=p.stat();assert t.st_size==expected['bytes'] and t.st_mtime_ns==expected['mtimeNs'] and t.st_mode==expected['mode'] and str(p.resolve())==expected['realpath']
normal=read(s['sequence'][0]['path']);cmp=read(s['sequence'][1]['path'])
r={'status':'accepted','sequence':pin(B/'sequence.json'),'wrapper':normal['wrapper'],'normalManifest':s['sequence'][0],'comparisonManifest':s['sequence'][1],'comparator':pin(B/'compare-report.mjs'),'priorHeldReview':pin(O/'report-comparison-v1-readiness-review.json'),'uniqueDependencyPinsVerified':len(pins),'sharedSourcePinsVerified':206,'normalStaticClosureFiles':114,'retainedStorageClosureFiles':21,'actualExecutionPerformed':False,'correctionAccepted':'All complete excluded, summary, missing-model, lead and ageing arrays are independently composed using actual producer catalogue/inventory/phase traversal; baseline traversal is first asserted and no new-report arrays are copied into expected.','checks':{'oneActualProductionReport':True,'productionEntrypointUnchanged':'scripts/report-coverage.ts --as-of 2026-10-15 --json','normalPrerequisite':'Exact passed fresh full-project TypeScript manifest; root must accept its actual results before granting this run','comparatorPrerequisite':'The one saved normal production report must pass and its terminal stdout hash must equal the read report','completeCarDigestChain':'Retained prefix20; exact guarded EQA21 fact; accepted complete replacement arrays22–26; exact 427 candidate26 and candidate27 car digests, 417 peers unchanged','completeSources':'Full source field digests exactly match accepted Deepal26 and MINI27, no overwrite of reused IDs','coreReasonReconstruction':'Actual coreCoverage and gradePattern over all digest-verified on-sale complete cars, with original order and every reason count; baseline full core/gaps equality then selected deltas and new report equality','rankingProjection':'Accepted full numeric groups projected to precise on-sale membership; exact production count/basis comparator and catalogue-derived stable insertion ties; full peer group membership/order and exclusions composed independently','fullReportEquality':'Every expected leaf starts from accepted baseline and receives explicit selected/core/C1/rank/age/aggregate deltas; final complete written equality required','representationBoundaries':'Pre-call snapshots for selected cars, packs, source research, packet, feature and report inputs; strict plain-JSON whole cars before digest capture; exact actual feature/C1 own-undefined producer witnesses only; separate live and written comparisons','effectiveFeatureScope':'Only the ten selected prior MINI cars / 690 features; current selected features already bound to accepted preflight and stage. No peer effective-feature replay or catalogue/default-loader hydration in comparator','fixedRootAndCacheScope':'All 361 configured roots and 360 unchanged root stats; bounded load.ts registration transition, four live registration target before/after stats, original config/generated roots/live cache unchanged','execution':'Fresh exact root grant and exclusive shared lock for each command; new output paths, no retry, no mutation, terminal/content/stat checks'},'envelopes':{'normal':{'oldSpaceMiB':448,'semiSpaceMiB':1,'timeoutSeconds':900,'killGraceSeconds':10},'comparator':{'oldSpaceMiB':448,'semiSpaceMiB':1,'timeoutSeconds':180,'killGraceSeconds':10}},'scope':'Readiness only. No ordinary report result, comparator result, integration completion or Next build acceptance inferred.'}
p=O/'report-comparison-v2-readiness-review.json';assert not p.exists();p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(pin(p)))
