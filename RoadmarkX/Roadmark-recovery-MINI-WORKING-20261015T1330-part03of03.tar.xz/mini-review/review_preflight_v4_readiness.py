from pathlib import Path
import json,hashlib
R=Path('/tmp/mini-packet'); D=R/'selected-preflight-v4'; OLD=R/'selected-preflight-v3'
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def verify(p):
 q=Path(p['path']);assert q.stat().st_size==p['bytes'],str(q);assert sha(q)==p['sha256'],str(q)
m=read(D/'prepared-command.json')
assert sha(D/'prepared-command.json')=='6b0971f09153fe4c8afdadf70f54a28ce1529134bc803fa33236ee4d28862546'
ps=read(D/'source-pins.json');assert len(ps)==197 and len({p['path'] for p in ps})==197
for p in ps:verify(p)
for k in ['script','sourcePins','packet','reconciliation','expectedReview','wrapper']:verify(m[k])
a=read(R/'mini-2026-10-15-candidate-v2.json');b=read(R/'mini-2026-10-15-candidate-v3.json')
assert a.keys()==b.keys();assert [k for k in a if a[k]!=b[k]]==['facts'];assert len(a['facts'])==len(b['facts'])==153
exp=read(D/'expected-review.json'); ids=exp['currentListIds'];assert len(ids)==10 and len(set(ids))==10
changed=[]
for x,y in zip(a['facts'],b['facts']):
 if x==y:continue
 assert x.keys()==y.keys() and [k for k in x if x[k]!=y[k]]==['after']
 f,g=x['after'],y['after'];assert f.keys()==g.keys();i=y['variantId'];k=g['key']
 expectedkey='range_km' if i in ids[:5] else 'price_aud';assert k==expectedkey
 allowed={'status','qualifications','conditionExplanation','buyerGrade','gradeReview'}
 if k=='range_km':allowed|={'basis','comparisonBasis'}
 assert set(q for q in f if f[q]!=g[q])==allowed
 assert [q for q in f['gradeReview'] if f['gradeReview'][q]!=g['gradeReview'][q]]==['reason']
 assert f['buyerGrade']=='check' and g['buyerGrade']=='confirmed' and f['status']=='conditional' and g['status']=='standard' and g['conditionExplanation']==''
 if k=='range_km':
  assert g['basis']=='Manufacturer-declared maximum WLTP range for this named grade' and g['comparisonBasis']=='WLTP maximum'
 else:
  assert g['qualifications']==f['qualifications']+[f['conditionExplanation']]
  assert g['priceEvidence']==f['priceEvidence'] and g['priceEvidence']['rung']==3 and not g['priceEvidence']['rankingEligible'] and g['comparisonBasis']==''
 changed.append({'variantId':i,'key':k,'value':g['value'],'changedAfterFields':sorted(allowed)})
assert len(changed)==10 and {c['variantId'] for c in changed}==set(ids)
e0=read(OLD/'expected-review.json');assert set(k for k in e0 if e0[k]!=exp[k])=={'packetSha256','normalizedRankPolicy','rankingIds'}
expectedchanges={(c['variantId'],c['key']) for c in changed};actualchanges=set()
assert len(e0['normalizedRankPolicy'])==len(exp['normalizedRankPolicy'])==140
for x,y in zip(e0['normalizedRankPolicy'],exp['normalizedRankPolicy']):
 if x==y:continue
 identity=(y['variantId'],y['key']);actualchanges.add(identity);assert identity in expectedchanges
 if y['key']=='range_km':
  assert {k for k in x if x[k]!=y[k]}=={'eligible','buyerGrade','comparisonBasis'} and y['eligible'] is True and y['comparisonBasis']=='WLTP maximum'
 else:assert {k for k in x if x[k]!=y[k]}=={'buyerGrade'} and y['eligible'] is False
 assert y['buyerGrade']=='confirmed'
assert actualchanges==expectedchanges
assert [k for k in e0['rankingIds'] if e0['rankingIds'][k]!=exp['rankingIds'][k]]==['range_km']
assert exp['rankingIds']['range_km']==ids[:5] and exp['rankingIds']['price_aud']==[]
script0=(OLD/'check.mjs').read_text();script=(D/'check.mjs').read_text()
assert script==script0.replace("const out='/tmp/mini-packet/selected-preflight-v3';","const out='/tmp/mini-packet/selected-preflight-v4';").replace("const packetPath='/tmp/mini-packet/mini-2026-10-15-candidate-v2.json';","const packetPath='/tmp/mini-packet/mini-2026-10-15-candidate-v3.json';")
for name in ['run.py','inventory-resolution-review.json']:assert (D/name).read_bytes()==(OLD/name).read_bytes()
p0={p['path']:p for p in read(OLD/'source-pins.json')};p1={p['path']:p for p in ps};common=set(p0)&set(p1)
assert all(p0[p]==p1[p] for p in common)
assert m['command'][1:3]==['--max-old-space-size=448','--max-semi-space-size=1'] and m['timeoutSeconds']==180 and m['killGraceSeconds']==10 and m['automaticRetry'] is False and m['rootExecutionGrantRequired'] and m['exclusiveHeavySlotRequired']
assert not (D/'run').exists() and not (D/'result.json').exists()
manifest=Path('/tmp/mini-research/research-manifest-v6.json');assert sha(manifest)=='a238a519ab87c1a5ec016b8c9aed9d97ebc7ea4e6c61efbb9bfec7d04020ed7b'
audit=read('/tmp/mini-research/grade-alignment-audit-v1.json')
assert {(c['variantId'],c['key']) for c in audit['changes']}==expectedchanges
for c in audit['changes']:
 f=next(y for y in b['facts'] if y['variantId']==c['variantId'] and y['after']['key']==c['key']);assert f['after']==c['after']
 for s in c['sourceSupport']:assert sha(s['capturePath'])==s['captureSha256']
assert 'five Countryman maxima with unresolved style attribution' in (D/'PLAN.md').read_text()
receipt={'verdict':'ready_for_one_new_root_authorized_selected_run_only','checkedAt':'2026-10-15','manifest':pin(D/'prepared-command.json'),'candidate':pin(R/'mini-2026-10-15-candidate-v3.json'),'sourceManifest':pin(manifest),'script':pin(D/'check.mjs'),'expectedReview':pin(D/'expected-review.json'),'plan':pin(D/'PLAN.md'),'sourcePinsCount':len(ps),'commonPriorPinsUnchanged':len(common),'linkedPinsVerified':6,'candidateChangedCells':changed,'preserved':'All numerical values, source records and IDs, identities, guards, summaries, availability, terms, residual census, exact three-record inventory and reconciliation; helpers and predicates unchanged.','rangeDecision':'Five directly assigned named-grade maxima Confirmed in WLTP maximum comparison group; five broad Countryman E/SE ALL4 style maxima remain Check with unresolved package/wheel attribution. No generic lab/build downgrade.','priceDecision':'Five exact model/trim Countryman maker from-prices Confirmed including GST and delivery. No before-ORC or driveaway promotion; all ten prices remain unranked. Four BASIC_LINE applicability Checks and Paul Smith Reported fallback unchanged.','envelope':{'oldSpaceMiB':448,'semiSpaceMiB':1,'timeoutSeconds':180,'killGraceSeconds':10,'automaticRetry':False},'currentExecutionState':'No v4 run or result exists at review','technicalScope':'183 cells, 690 actual claims, exact optional-path witnesses, live-to-live and written-to-written portable/citable parity, 140 ranking policies, 20 clauses and 3 exact C1 settlements retain v3 predicates.','excludedAcceptance':'No global C1/C2/C5, full stage, integration, release, stock or accepted-order acceptance.'}
out=Path('/tmp/mini-review/preflight-v4-readiness-receipt.json');out.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'passed':True,'receipt':pin(out),'inputPins':len(ps),'unchangedCommonPins':len(common),'candidateChangedCells':len(changed)},indent=2))
