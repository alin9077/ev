from pathlib import Path
import json,hashlib
B=Path('/tmp/mini-packet/full-project-typescript-v1');D=B/'run';O=Path('/tmp/mini-review')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h)
def check(p):assert pin(p['path'])=={k:p[k] for k in ['path','bytes','sha256']},p['path']
def meta(p):
 p=Path(p)
 if not p.exists():return {'path':str(p),'exists':False}
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
m=read(B/'manifest.json');mp=pin(B/'manifest.json');g=read(B/'root-execution-grant.json');gp=pin(B/'root-execution-grant.json');r=read(D/'result.json');t=read(D/'terminal.json');iv=read(D/'invocation.json');a=read(D/'after-pins.json');s=read(D/'scope-verification.json')
assert mp['sha256']=='7a7a432906d6a0b6d684c4130210679985170fe5fcc9e10945ecc621b668d68e';assert gp['sha256']=='3649bc83d52bca8757b6e4831bb5c5f815b0a9cae7b7255566cf48ddc3b8b002'
assert g['manifest']=={'path':mp['path'],'sha256':mp['sha256']} and g['status']=='root_execution_granted' and g['heavySlotExclusive'] and not g['parallelExecutionAllowed'] and not g['automaticRetry'] and g['maximumAttempts']==1 and g['coldCacheRelocationApproved']
for k in ['applicationVerification','precedingCheckVerification','reviewerAcceptance']:check(g[k])
prior=read(g['precedingCheckVerification']['path']);assert prior['status']=='accepted' and prior['allFivePrerequisitesAccepted'] and [x['name'] for x in prior['checks']]==m['requiredPrecedingChecks']
for c in prior['checks']:
 for k in ['manifest','result','terminal']:check(c[k])
 assert c['passed'] and c['exitCode']==0
assert r['passed'] and r['fullProjectTypecheckPassed'] and r['coldFullProjectAttempt'] and r['pinsPassed'] and r['scopePassed'] and r['exitCode']==0 and not r['nextBuildClaim'] and not r['automaticRetry'];assert r['manifestSha256']==iv['manifestSha256']==mp['sha256'] and r['rootGrantSha256']==iv['rootGrantSha256']==gp['sha256']
assert iv['command']==m['command'] and iv['supervisedCommand']==['/usr/bin/timeout','--signal=TERM','--kill-after=10s','900s',*m['command']] and iv['scopeOverride'] is None and iv['coldFullProjectAttempt'] and not iv['literalPackageScript'];assert iv['environmentRemovals']==m['environmentRemovals'] and iv['environmentOverrides']==m['environmentOverrides']
assert t['exitCode']==0 and t['rawWaitStatus']==0 and not t['watchdogFired'] and not t['timeoutExitCodeObserved'] and not t['automaticRetry'] and t['elapsedSeconds']<900
for k in ['stdout','stderr']:assert (D/(k+'.log')).stat().st_size==0 and t[k+'Sha256']==pin(D/(k+'.log'))['sha256']
assert a['passed'] and a['liveCacheUnchanged'] and a['configuredRootsUnchanged'] and a['inputPinCount']==193
for p in [m['wrapper'],m['inputPins'],m['projectRootMetadata'],m['cacheHandling']['liveCache'],*read(m['inputPins']['path']),*m['registrationTargets']]:check(p)
roots=read(m['projectRootMetadata']['path']);repo=Path(m['cwd']);cfg=read(repo/'tsconfig.json');assert cfg==m['originalConfig'];actual=sorted({str(p.resolve()) for pattern in cfg['include'] for p in repo.glob(pattern) if p.is_file()});assert actual==roots['configuredRootFilePaths'] and len(actual)==361
for p in roots['fileMetadata']+roots['directoryState']+m['runtimeMetadata']:assert meta(p['path'])==p,p['path']
assert read(D/'registration-target-metadata-before.json')==[meta(p['path']) for p in m['registrationTargets']]
cache=Path(m['command'][-1]);cp=pin(cache);info=read(cache);assert info['version']==m['installedVersions']['typescript'];ids=[]
for x in info['root']:ids.extend(range(x[0],x[1]+1) if isinstance(x,list) else [x])
cacheRoots=sorted({str((cache.parent/info['fileNames'][i-1]).resolve()) for i in ids});assert cacheRoots==actual and len(cacheRoots)==361
assert s['passed'] and s['actualRootCount']==s['expectedRootCount']==361 and s['missingRoots']==s['unexpectedRoots']==[] and s['cacheSha256']==cp['sha256'] and s['cacheBytes']==cp['bytes'] and s['includesUnchanged']==cfg['include'] and s['excludesUnchanged']==cfg['exclude'];assert len([p for p in actual if '/.next/types/' in p])==4 and not (repo/'.next/dev/types').exists()
receipt={'status':'accepted','manifest':mp,'rootGrant':gp,'result':pin(D/'result.json'),'terminal':pin(D/'terminal.json'),'invocation':pin(D/'invocation.json'),'afterPins':pin(D/'after-pins.json'),'scopeVerification':pin(D/'scope-verification.json'),'freshCache':cp,'reviewerReadiness':g['reviewerAcceptance'],'fiveGatePrerequisites':g['precedingCheckVerification'],'registrationVerification':g['applicationVerification'],'passed':True,'exitCode':0,'elapsedSeconds':t['elapsedSeconds'],'maxRssKiB':t['maxRssKiB'],'independentChecks':{'all193ContentPins':True,'all361ConfiguredAndActualCompilerRoots':True,'unchanged360RootMetadataRows':True,'onlyAcceptedLoadTsRegistrationStatTransition':True,'fourRegistrationTargetStatsIdentical':True,'originalConfigUnchanged':True,'liveCacheUnchanged':True,'fourRetainedGeneratedTypeRootsUnchanged':True,'noDevGeneratedTypes':True,'actualFreshCacheRootIdsParsedIndependently':True,'emptyStdoutAndStderr':True,'coldInstalledFullProjectCompiler':True,'noNarrowedProjectOrFallback':True,'exactApproved768MiBOldSpace1MiBSemiSpace900Plus10Seconds':True},'scope':'Genuine cold full-project TypeScript accepted; original package script semantics with only the explicitly approved output cache relocation. Not a Next build or ordinary-report result.','memoryNote':'V8 limits are not an OS RSS cap; wait4 max RSS is not summed simultaneous process-tree memory','reviewerExecutedProducerCommands':False}
p=O/'full-project-typescript-v1-output-review.json';assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(pin(p)))
