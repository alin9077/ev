from pathlib import Path
import json,hashlib,ast
P=Path('/tmp/mini-packet/post-registration-checks-v1');T=Path('/tmp/mini-packet/full-project-typescript-v1')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h}
def verify(p):
 q=pin(p['path']);assert all(q[k]==p[k] for k in ['path','bytes','sha256']),p['path']
def meta(p):
 p=Path(p)
 if not p.exists():return {'path':str(p),'exists':False}
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
seq=read(P/'sequence.json');ts=read(T/'manifest.json');assert pin(P/'sequence.json')['sha256']=='5f4e4a339984dc55797869e7e5e895295cd37b5e91c549679525edf7a0b5448d';assert pin(T/'manifest.json')['sha256']=='7a7a432906d6a0b6d684c4130210679985170fe5fcc9e10945ecc621b668d68e'
for p in seq['sequence']+[seq['sourcePins'],seq['rootMetadata'],seq['registrationManifest']]:verify(p)
assert seq['sequence'][-1]==pin(T/'manifest.json')==seq['fullProjectTypeScriptManifest'];assert seq['sequence'][:5]==ts['precedingCheckManifests']
pins=read(seq['sourcePins']['path']);assert len(pins)==193 and len({p['path'] for p in pins})==193
for p in pins:verify(p)
assert Path(ts['inputPins']['path']).read_bytes()==Path(seq['sourcePins']['path']).read_bytes()
priorpins=read('/tmp/deepal-packet/full-project-typescript-v2/input-pins.json');nowpins={p['path']:p for p in pins};common=[p for p in priorpins if p['path'] in nowpins];changed=[p['path'] for p in common if (p['sha256'],p['bytes'])!=(nowpins[p['path']]['sha256'],nowpins[p['path']]['bytes'])]
assert set(changed)=={ts['cwd']+'/data/m1-brand-updates/registry.json',ts['cwd']+'/scripts/reporting/load.ts'}
scope=read(seq['rootMetadata']['path']);priorScope=read('/tmp/deepal-packet/full-project-typescript-v2/project-root-metadata.json');assert scope['configuredRootFilePaths']==priorScope['configuredRootFilePaths'];assert len(scope['configuredRootFilePaths'])==361 and len(scope['fileMetadata'])==360
load=ts['cwd']+'/scripts/reporting/load.ts';assert scope['fileMetadata']==[x for x in priorScope['fileMetadata'] if x['path']!=load];assert scope['directoryState']==priorScope['directoryState'];assert len(scope['registrationStatTransitions'])==1 and scope['registrationStatTransitions'][0]['before']==next(x for x in priorScope['fileMetadata'] if x['path']==load)
for p in scope['fileMetadata']+scope['directoryState']+ts['runtimeMetadata']:assert meta(p['path'])==p,p['path']
repo=Path(ts['cwd']);config=read(repo/'tsconfig.json');assert config==ts['originalConfig'];roots=sorted({str(p.resolve()) for pattern in config['include'] for p in repo.glob(pattern) if p.is_file()});assert roots==scope['configuredRootFilePaths'];assert len([p for p in roots if '/.next/types/' in p])==4 and not (repo/'.next/dev/types').exists()
readback=read('/tmp/mini-review/registration-v1-live-readback.json');assert readback['status']=='accepted' and readback['allFourLiveHashesAndBytesMatchAcceptedPayloads'];assert readback['manifestSha256']==seq['registrationManifest']['sha256'];verify(readback['applicationReceipt']);ar=read(readback['applicationReceipt']['path']);assert ar['passed'] and ar['manifestSha256']==readback['manifestSha256']
inv=read(P/'test-inventory.json');assert inv==read('/tmp/deepal-packet/post-registration-checks-v3/test-inventory.json')
for v in inv.values():verify(v['source']);assert len(v['names'])==v['count']
names=['market-view','changed-file-lint','behavioural-suites','live-brand-safety','structural-validation'];mem=[128,256,512,512,448];timeouts=[60,180,600,600,900];gates=[]
for i,p in enumerate(seq['sequence'][:5]):
 m=read(p['path']);assert m['id']==names[i] and m['command'][1:3]==[f'--max-old-space-size={mem[i]}','--max-semi-space-size=1'] and m['timeoutSeconds']==timeouts[i];assert m['killAfterSeconds']==10 and m['automaticRetry'] is False and m['sourceMutationsAuthorized'] is False
 assert m['sourcePins']==seq['sourcePins'] and m['rootMetadata']==seq['rootMetadata'] and m['originalConfig']==config and m['registrationTargets']==seq['registrationTargets']==ts['registrationTargets'];assert m['exclusiveLock']==ts['exclusiveLock'];verify(m['wrapper']);verify(m['testInventory']);assert m['environmentRemovals']==ts['environmentRemovals'] and m['environmentOverrides']['NODE_DISABLE_COMPILE_CACHE']=='1'
 assert m['prerequisites']==([] if i==0 else [{'manifest':seq['sequence'][i-1],'resultPath':str(P/'run'/names[i-1]/'result.json')}])
 if m['kind']=='tests':assert sum(inv[f]['count'] for f in m['testFiles'])==m['expectedTests'];assert '--test-concurrency=1' in m['command'] and '--test-reporter=tap' in m['command']
 if m['kind']=='lint':assert m['lintFiles']==['scripts/reporting/load.ts'] and m['command'][-2:]==['--','scripts/reporting/load.ts'];assert '--no-cache' in m['command'] and '--fix' not in m['command']
 if m['kind']=='market':assert m['command'][-2:]==['scripts/generate-market-view.mjs','--check']
 if m['kind']=='structural':assert m['expectedSourceReferences']==3753 and m['expectedPublicationIssues']==15 and m['expectedApprovedExternalAssets']==0 and m['expectedStructuralCounts']=={'variants':427,'families':170,'generations':193,'criteria':69,'evidence':29463,'current':348,'outgoing':43,'provisional':36}
 assert not Path(m['runOutput']).exists();gates.append({'id':m['id'],'manifest':p,'oldSpaceMiB':mem[i],'semiSpaceMiB':1,'timeoutSeconds':timeouts[i],'expectedTests':m.get('expectedTests')})
for p in ts['registrationTargets']:verify(p)
verify(ts['wrapper']);verify(ts['inputPins']);verify(ts['projectRootMetadata']);verify(ts['cacheHandling']['liveCache']);assert not Path(ts['cacheHandling']['newCachePath']).exists() and not (T/'run').exists()
assert read(repo/'package.json')['scripts']['typecheck']==ts['originalPackageTypecheckScript']=='tsc --noEmit'
assert ts['command']==['/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','--max-old-space-size=768','--max-semi-space-size=1',str(repo/'node_modules/typescript/bin/tsc'),'--noEmit','--tsBuildInfoFile',str(T/'run/full-project.tsbuildinfo')]
assert ts['timeoutSeconds']==900 and ts['killAfterSeconds']==10 and ts['supervisorWatchdogSeconds']==920 and ts['maximumAttempts']==1 and ts['automaticRetry'] is False and ts['regenerateTypes'] is False and ts['environmentOverrides']=={'NODE_DISABLE_COMPILE_CACHE':'1'}
assert ts['requiredPrecedingChecks']==names
for f in [P/'run.py',T/'run.py']:ast.parse(f.read_text())
base={'status':'accepted','registrationVerification':pin('/tmp/mini-review/registration-v1-live-readback.json'),'inputContentPinsVerified':193,'unchangedConfiguredRootNames':361,'unchangedRootMetadataRows':360,'allowedRootStatTransition':'Only load.ts exact accepted registration after bytes; all four target stats captured before and identical after each gate','generatedTypeRoots':4,'generatedDevTypesAbsent':True,'liveCacheUnchanged':ts['cacheHandling']['liveCache'],'sourceContentChangesVersusPriorTypecheck':changed,'actualExecutionPerformed':False,'grantRequired':'Fresh exact root exclusive heavy-slot grant; acceptance of preparation is not an executed pass','serialNoRetry':True,'noBuildOrNormalReportAcceptance':True}
generic={**base,'sequence':pin(P/'sequence.json'),'wrapper':read(seq['sequence'][0]['path'])['wrapper'],'gates':gates,'scope':'Only the five explicit gates, in order. Every manifest enforces prior successful result; root grants each execution separately.'}
typecheck={**base,'manifest':pin(T/'manifest.json'),'wrapper':ts['wrapper'],'scope':'One genuine cold full-project installed TypeScript attempt using unchanged original tsconfig and all361roots; only tsbuildinfo destination relocated','requiredPrecedingChecks':names,'preconditions':'All five fresh actual gates independently accepted with exact manifest/result/terminal pins, plus accepted registration readback and separate root grant','envelope':{'oldSpaceMiB':768,'semiSpaceMiB':1,'timeoutSeconds':900,'killGraceSeconds':10,'watchdogSeconds':920},'cacheProof':'Fresh cache root IDs must resolve to all361original roots; no seed,narrowed project,generated types,config edits or fallback'}
for name,value in [('post-registration-five-gates-v1-readiness.json',generic),('full-project-typescript-v1-readiness.json',typecheck)]:
 p=Path('/tmp/mini-review')/name;p.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(pin(p)))
