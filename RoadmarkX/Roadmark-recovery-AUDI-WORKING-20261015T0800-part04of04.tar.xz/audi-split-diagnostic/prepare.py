from pathlib import Path
import hashlib,json
root=Path('/tmp/audi-split-diagnostic');proposal=Path('/tmp/audi-split-proposal');repo=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def save(p,d):Path(p).write_text(json.dumps(d,indent=2)+'\n')
# Bounded, explicit closure of the proposal, reused report consumers and selected evidence.
paths=[proposal/p for p in ['scripts/reporting/m1-reconciliation.ts','scripts/reporting/reports.ts','baseline/scripts/reporting/m1-reconciliation.ts','tests/m1-inventory-split.test.ts','fixtures/reconciliation.json','fixtures/included-split-mapping.json','fixtures/original-combined-lead.json','fixtures/inventory-audi.json','fixtures/packet-q6-my27.json']]
paths += [Path('/tmp/audi-packet/selected-preflight-v3')/p for p in ['result.json','selected-after-cars.json','selected-packs.json']]
paths += [repo/p for p in ['scripts/reporting/reports.ts','scripts/reporting/m1-reconciliation.ts','src/lib/freshness.ts','src/lib/fact-validity.ts','src/lib/correction-guards.ts','src/lib/evidence-grading.ts','src/lib/selling-points.ts','src/lib/types.ts','data/market-inventory-2026-10-10.json']]
wrapper='''from pathlib import Path
import sys,json,subprocess,os,time,hashlib
from datetime import datetime,timezone
m=Path(sys.argv[1]);expected=sys.argv[2]
assert hashlib.sha256(m.read_bytes()).hexdigest()==expected
x=json.loads(m.read_text());assert x['timeoutSeconds']==60 and x['automaticRetry'] is False
assert x['command'][1:3]==['--max-old-space-size=256','--max-semi-space-size=1']
pins=[x[k] for k in ['script','sourcePins','wrapper']]+json.loads(Path(x['sourcePins']['path']).read_text())
def checkpins():
 for p in pins:
  b=Path(p['path']).read_bytes();assert len(b)==p['bytes'];assert hashlib.sha256(b).hexdigest()==p['sha256'],p['path']
 assert hashlib.sha256(m.read_bytes()).hexdigest()==expected
checkpins();out=m.parent/'run';out.mkdir(exist_ok=False)
def now():return datetime.now(timezone.utc).isoformat()
def write(name,obj):
 with (out/name).open('x') as f:json.dump(obj,f,indent=2);f.write('\\n');f.flush();os.fsync(f.fileno())
cmd=x['command'];wrapped=['/usr/bin/timeout','--signal=TERM','--kill-after=10s','60s',*cmd]
write('invocation.json',dict(at=now(),cwd=x['workdir'],command=cmd,supervisedCommand=wrapped,preparedManifestSha256=expected,wrapperSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),beforePinsPassed=True,automaticRetry=False,sourceMutationsAuthorized=False))
start=time.monotonic()
with (out/'stdout.log').open('x') as so,(out/'stderr.log').open('x') as se:
 p=subprocess.Popen(wrapped,cwd=x['workdir'],stdout=so,stderr=se,start_new_session=True);write('started.json',dict(at=now(),pid=p.pid,processGroup=os.getpgid(p.pid)))
 _,status,usage=os.wait4(p.pid,0);code=os.waitstatus_to_exitcode(status);p.returncode=code;so.flush();se.flush();os.fsync(so.fileno());os.fsync(se.fileno())
terminal=dict(at=now(),exitCode=code,rawWaitStatus=status,elapsedSeconds=time.monotonic()-start,maxRssKiB=usage.ru_maxrss,stdoutSha256=hashlib.sha256((out/'stdout.log').read_bytes()).hexdigest(),stderrSha256=hashlib.sha256((out/'stderr.log').read_bytes()).hexdigest(),timeoutInterpretation='Raw wait status retained; no cause inferred',automaticRetry=False)
write('terminal.json',terminal)
try:checkpins();write('after-pins.json',dict(at=now(),passed=True,count=len(pins),preparedManifestSha256=expected))
except Exception as e:write('after-pins.json',dict(at=now(),passed=False,error=repr(e)));raise
print(json.dumps(terminal));print((out/'stdout.log').read_text()[-5000:]);print((out/'stderr.log').read_text()[-4500:]);sys.exit(0 if code==0 else 1)
'''
for name,script,args in [('unit',proposal/'tests/m1-inventory-split.test.ts',['--test','--test-concurrency=1',str(proposal/'tests/m1-inventory-split.test.ts')]),('selected',root/'selected/check.mjs',[str(root/'selected/check.mjs'),'--root-execution-granted'])]:
 out=root/name;(out/'run.py').write_text(wrapper);save(out/'source-pins.json',[pin(p) for p in paths]);m=dict(status='prepared_not_executed',script=pin(script),sourcePins=pin(out/'source-pins.json'),wrapper=pin(out/'run.py'),command=['node','--max-old-space-size=256','--max-semi-space-size=1','--import','tsx',*args],workdir=str(proposal),timeoutSeconds=60,automaticRetry=False,rootExecutionGrantRequired=True,scope='Proposed included_split helper only, no live source edits. '+('Focused adversarial and unchanged-behavior unit tests; no compiler.' if name=='unit' else 'Actual already-passed seventeen Audi cars/packs, exact seven reviews and eight inventory resolutions; future/current-list and on-sale remain separate. No catalogue hydration.'))
 save(out/'prepared-command.json',m);print(name,json.dumps(pin(out/'prepared-command.json')), 'wrapper',pin(out/'run.py')['sha256'])
