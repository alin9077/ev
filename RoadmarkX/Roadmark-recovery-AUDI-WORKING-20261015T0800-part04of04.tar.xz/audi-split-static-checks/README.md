# Prepared isolated Audi split static checks

Status: prepared only; neither compiler nor lint has run. The shared wrapper has not run. No help/version commands, tests, installs, builds, whole-project compilation, or live source edits were performed in preparing this directory. Preparation consisted of source/config inspection, text authoring, byte-for-byte copying, read-only package discovery, and hashing. Explicit root execution approval is still required.

## Frozen execution artifacts

- `compile/prepared-command.json`: SHA256 `c932f30526db9f16b18092a3e1b38527d4e2633e87f1ceccc2607cb2467290e0`
- `lint/prepared-command.json`: SHA256 `0de7780ec82ec02af2e5b16d2781334ad1510bf9569502ec7ffe0a19075ee206`
- `run.py`: SHA256 `0b15ecff2320083c013cc2937a38a9a51c295257eea27eac071590dddc13d4d1`
- `source-pins.json`: SHA256 `a76fc1341c87b6797b667acbdc3ba2c9fc1c5b913e064bdcea076431d55eb74c`
- `tool-pins.json`: SHA256 `4cbffb863a94a2a329425edc74226aff73f38cbc41898fc07bcdab6a04559eeb`
- `scope.json`: SHA256 `429ca489f78c81a97f39c69938607a85a377b24ff4ea4c1c93f5413f9e29479f`

The manifest files bind the wrapper, scope, source/config pins, executable/tool pins, exact argv, working directory, environment changes and limits. The helper copy remains SHA256 `4b42c0b69031b0a3f450f883a278c2cbc9f37aa8519478b45649b3cf07924cc0`; the test copy remains SHA256 `ede08b632fb1bcd29be623438bee5053204b23a63e66d73180655675d537bb97`.

## Scope: two compiler roots, 19 actual source files

Working directory: `/tmp/audi-split-static-checks/fixture`.

`fixture/tsconfig.json` is standalone. It does not extend the live project configuration and has no project references or broad include patterns. Its `files` array contains exactly:

1. `scripts/reporting/m1-reconciliation.ts`
2. `tests/m1-inventory-split.test.ts`

The actual imported local closure, including type-only imports, comprises 19 physical source files and 202,113 bytes:

- Proposed helper and test
- Unchanged report consumer and baseline helper
- The 15 exact source modules `car-avatar-shapes`, `config`, `configuration-evidence`, `correction-guards`, `corrections`, `discovery`, `evidence-grading`, `evidence-regrade-policy`, `fact-validity`, `freshness`, `page-evidence`, `search`, `selling-points`, `types`, and `vehicle-scope`

`import-closure.json` documents each original path, copied path, hash and inspected import edge. No mock functions, truncated dependencies, fake type declarations or generated catalogue data are substituted. The baseline's reports and src links retain the proposal's topology, redirected only to the exact fixture copies. Compiler file-list verification normalizes these aliases to physical paths.

The source options preserve the original proposal's ES2022/ESNext/Bundler/strict/esModuleInterop/noEmit settings. `skipLibCheck: true` is retained: the real project sources are checked strictly, while standard/dependency declaration internals are not checked. `incremental`, `composite` and `allowJs` are explicitly false. Ambient types are restricted to installed `@types/node`, using an explicit type root. The normal ES2022 standard libraries and Node's `undici-types` dependency are real installed declarations, not stubs. No Next plugin, Next-generated declarations, app routes, catalogue loader, root tsconfig includes, test glob, or project build is involved.

The compiler command contains `--listFiles` as well as actual checking. After its single run, the wrapper requires all 19 physical project files and rejects any other project source. Additional files may only be `.d.ts` files under the exact installed TypeScript lib, `@types/node`, and `undici-types` roots recorded in `scope.json`. This is an independent observation of the compiled scope, rather than an assumption that the two root files are the entire program.

## Exact installed tools and lint configuration

Versions were read from installed package JSON, not from executing tools:

- TypeScript 5.9.3: `/workspace/scratch/586427eef9f2/roadmark-104/node_modules/.pnpm/typescript@5.9.3/node_modules/typescript/bin/tsc`
- ESLint 9.39.5: `/workspace/scratch/586427eef9f2/roadmark-104/node_modules/.pnpm/eslint@9.39.5_supports-color@7.2.0/node_modules/eslint/bin/eslint.js`
- Node executable: `/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node`
- Node declarations: `@types/node` 24.19.1; `undici-types` 7.24.6
- Lint config: `/tmp/audi-split-static-checks/fixture/eslint.config.mjs`, byte-identical to the live repo config (SHA256 `b1b6d3c3376a8fc2a6a2fa3fa5c231a3b87a54705dcf6e8de2d34af015ebaeb4`)

The repo's `.bin` shims carry old roadmark-103 NODE_PATH values. The proposed commands bypass those shims, invoke the exact installed roadmark-104 JS entries directly, and remove inherited NODE_OPTIONS and NODE_PATH. No alternate dependency install or version substitution is used.

Lint receives two exact relative filenames from inside the fixture, never a `/tmp` filename outside its config base. It uses explicit `--config`, `--no-config-lookup`, `--no-ignore`, `--no-cache`, `--concurrency off`, `--max-warnings 0`, and JSON output. No directories or globs are passed. The copied config retains the live rules. Its installed recommended TypeScript configuration does not enable type-aware project/projectService compilation. The fixture contains no app/pages tree for a Next rule to scan; that rule may emit its ordinary missing-pages diagnostic to stderr. Such stderr remains in the evidence for review; it is not silently suppressed. No live app tree is linked into the fixture.

The wrapper rejects a lint result unless there are exactly two JSON records matching the expected helper and test paths, with zero fatal errors, errors or warnings. An ignored-file warning, missing file, parser failure, extra lint target or nonzero CLI exit therefore cannot be reported as a clean check.

## Resource and mutation boundaries

Each proposed tool process has `--max-old-space-size=256 --max-semi-space-size=1`, a 60-second GNU timeout sending TERM, and a 10-second KILL grace period. This is a V8 heap cap, not a hard RSS/cgroup limit. The small 202 KB source closure justifies starting with this conservative bound; it is not a promise that the tools will fit. There is no automatic resource escalation or second attempt after failure, timeout, signal, out-of-memory, source drift or inconclusive output.

Run sequentially, only after explicit root approval for the corresponding manifest. Lint's multithreading is explicitly disabled. The wrapper follows the existing `/tmp/audi-split-diagnostic/unit/run.py` pattern: separate process session, `os.wait4`, raw wait status, elapsed time, observed max RSS, stdout/stderr hashes, and before/after source/tool verification. It does not infer the cause of a signal or exit from an exit code alone. The timeout covers the tool process; bounded read-only pin verification and result processing happen outside that process timeout.

Tool pins cover 11,620 existing files / 228,651,909 bytes, including Node/Python/timeout, compiler payload and standard libs, real Node/Undici declarations, the 316 installed ESLint runtime-dependency packages, and Next's compiled Babel parser. This is a read-only identity inventory, not extra lint/compile targets. Pin checking streams files in 1 MiB chunks; it does not load the whole tool inventory or Node binary into memory at once. `tool-packages.json` records the package discovery. Installed dependency links are reused read-only; no install runs.

The compiler has no emit or incremental output. Lint has no fixes or cache. Node's compile cache is explicitly disabled. Only `/tmp/audi-split-static-checks/{compile,lint}/run/` receives process evidence. The wrapper's `mkdir(exist_ok=False)` makes accidental repetition against the same manifest fail before launching a tool. Live helper/report/config/dependency-lock hashes and the absence of the new live test are checked before and after. This does not claim a repository-wide byte audit; it establishes the specifically pinned no-mutation boundary.

## Proposed invocation, not executed

After approval, the exact one-attempt compile invocation is:

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/audi-split-static-checks/run.py /tmp/audi-split-static-checks/compile/prepared-command.json c932f30526db9f16b18092a3e1b38527d4e2633e87f1ceccc2607cb2467290e0
```

After separate or explicitly bundled approval, the exact one-attempt lint invocation is:

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/audi-split-static-checks/run.py /tmp/audi-split-static-checks/lint/prepared-command.json 0de7780ec82ec02af2e5b16d2781334ad1510bf9569502ec7ffe0a19075ee206
```

Each output directory would contain `invocation.json`, `started.json`, `stdout.log`, `stderr.log`, `terminal.json`, `after-pins.json`, and `scope-verification.json`. Both run directories are absent at preparation. A clean result requires zero tool exit status, unchanged pins, and successful scope verification. Any failed or incomplete result must be reported as such and returned to root; no retry or scope expansion is authorized by this preparation.
