# Audi inherited combined-lead split proposal

Status: proposal text only. No helper, test, compiler, formatter, report, app or full-catalogue code has been executed for this proposal. No live repository files have been edited. File extraction, file authoring, copying, diffing and hashing were the only local operations.

## Scope and files

- `scripts/reporting/m1-reconciliation.ts`: complete proposed helper, derived from the exact captured live source
- `m1-reconciliation.patch`: unified helper diff against that exact source, with repository-relative paths
- `fixtures/reconciliation.json`: complete candidate reconciliation copied from `/tmp/audi-packet/v1/m1-audi-market-reconciliation-2026-10-15.json`; only the combined lead disposition and its explanatory note change
- `fixtures/included-split-mapping.json`: the complete new disposition on its own
- `fixtures/original-combined-lead.json`: entire original JSON row, not a reduced AuditRecord projection
- `fixtures/inventory-audi.json`: only Audi records and leads, otherwise unchanged
- `fixtures/packet-q6-my27.json`: narrow four-version MY27 Q6/SQ6 packet extract, with real availability/source records and no added body facts
- `tests/m1-inventory-split.test.ts`: tests importing the actual proposed helper, not a mock validator
- `scripts/reporting/reports.ts`: unchanged copy of the current report consumer, so the proposed helper is used by the future/on-sale regression test
- `baseline/`: unchanged source and candidate reconciliation for regression comparison
- `input-sha256.txt`: original input identities
- `proposal-sha256.txt`: final proposal artifact identities
- `tsconfig.proposal.json`: optional scoped no-emit compilation configuration, not yet run

The `src`, `node_modules`, and baseline dependency links are read-only reuse of existing checkout dependencies. All authored files are under this proposal directory. There are no instructions to apply the proposal automatically.

## Proposed schema and behavior

`Resolution` remains unchanged. Published-list resolutions cannot acquire the new outcome through the TypeScript schema, and a runtime-injected split fails the existing list path. Only `InventoryResolution` gains `included_split`.

An inventory split contains:

1. Existing dated reason and source URL fields
2. `originalRecord`, containing every key/value of the exact original inherited JSON row, including undeclared metadata and nested values
3. A separately reviewed `declaredCoverage` with its own date, reason, uniquely cited dated source records, and the complete exact expected version identities
4. Two or more distinct current-review components, each with exact brand, class, model ID, model, body and the complete versions of its referenced review

The Audi mapping declares exactly four MY27 identities:

- `audi_q6_suv_my27`: Q6 e-tron and SQ6 e-tron
- `audi_q6_sportback_my27`: Q6 Sportback e-tron and SQ6 Sportback e-tron

Each version binds its exact review ID, model ID, body, brand, class, car ID, model, trim and model year. The original combined lead is neither renamed nor split into replacement inventory rows.

## Machine-checkable guarantees

- The original row must be `isDeepStrictEqual` to the full captured guard. Object key order is immaterial; extra/missing keys, changed types, nested values and array order are not
- Disposition, declaration, cited checks and current reviews must have valid, non-future, current dates under the existing 45-day window; source checks cannot postdate the declaration and the declaration cannot postdate the disposition
- Every cited URL has one explicit dated source record and a nonempty scoped interpretation; each component links to a current official-review URL
- Components and declared identities use strict string/value equality. No fuzzy matching, new aliases, combined-name parsing or normalisation is introduced
- Review IDs and model IDs are distinct, review version lists are complete, all referenced cars are uniquely present, and cars cannot overlap across components or model reviews
- The covered union equals the separately declared expected set. Missing body/trim components fail even if the component and its review are shortened together
- Duplicate mappings, inherited row IDs, component reviews, car IDs, declared car IDs or source records fail
- An explicit inherited `bodyStyle`, `trim` or `catalogueVariantIds` constraint remains binding
- A referenced review cannot be reused in another split mapping

### Absent body-fact witness

The retained Audi cars and proposed MY27 Q6 rows do not contain `body_style`/`body_type` facts. This is a representation limit, not permission to invent facts. The split binds body exactly between the declaration, component and current review, and binds the car to that review with its exact body-specific `modelId`, model, trim, year and ID. If either body fact is present, it must agree exactly; conflicting present facts fail. Unit fixtures truthfully keep those facts absent. The only body facts constructed in tests are explicitly synthetic positive/adversarial test cases.

## Human provenance boundary

These checks validate consistency and freshness of recorded evidence; they do not fetch a source, prove the date of a real retrieval, interpret a webpage, or prove that a nonempty `supports` string is true.

An independent reviewer must confirm that the unchanged original combined lead really denotes these four versions and that the cited Audi/GoAuto material supports that scope and the future/order-opening distinction. Source dates and interpretations are copied from the candidate research record, not independently reverified by this proposal author.

The separate expected coverage guard prevents accidental or opportunistic component-only narrowing. It is not a cryptographic signature or an independent authority: coordinated edits to the declaration, reviews, cars and source labels could manufacture an internally consistent fiction. Such edits require renewed human source review. Do not claim these self-authored fields prove webpage semantics.

The Audi manufacturer source supports the future MY27 bodies/versions and arrival scope; the secondary GoAuto source supports reported order opening. Neither is an accepted individual factory order, inspected physical stock, delivered VIN or individual delivery promise.

## Test coverage and stopping condition

The supplied tests exercise the actual proposed helper for:

- Valid full split, complete original guard and immutability
- Original identity and untyped/nested metadata drift
- Stale, future, invalid or missing evidence
- Component, declaration and catalogue body/model/model-ID/year/trim/car-ID mismatch
- Absent body facts and conflicting present body facts
- Unrelated valid same-brand review, missing component, missing trim and jointly shortened component/review
- Duplicate inventory mapping/row, source, review, component and car
- Explicit inherited body/trim/car-ID restrictions
- Baseline-equivalent ordinary single-review inclusion and ordinary published-list/alias behavior
- Type-level and runtime inventory-only split boundary
- Actual unchanged `buildCoverageReport` consumer using this proposed helper: four future current-list-eligible cars plus three on-sale cars must review seven while counting only three on-sale; stale/missing future order-opening evidence fails eligibility

Unit cars are deliberately narrow fixtures rather than a hydrated full catalogue. The real four-car availability evidence is copied from the packet; ordinary MY26 identities come from the existing exact review. A focused test pass would not establish full integration or whole-market C1 completion. Two independent whole-market published lists remain absent, so the valid split fixture must still report `pass: false` with `independent_lists`.

After explicit root authorization only, the suggested bounded checks from this directory are:

```
node --import tsx --test --test-concurrency=1 tests/m1-inventory-split.test.ts
./node_modules/.bin/tsc --project tsconfig.proposal.json --noEmit
```

These commands have NOT run. Obtain authorization before any of them or any selected-consumer integration harness is executed. No apply, build, broad test suite, catalogue hydration, commit or publication is included in this proposal.
