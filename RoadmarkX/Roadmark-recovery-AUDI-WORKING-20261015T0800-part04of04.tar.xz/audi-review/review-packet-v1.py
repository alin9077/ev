import json,pathlib,hashlib,collections,datetime
R=pathlib.Path('/tmp/audi-review');Ppath=pathlib.Path('/tmp/audi-packet/v1/audi-2026-10-15.json');P=json.loads(Ppath.read_bytes());N=json.load(open('/tmp/audi-research/normalized-review-v5.json'));I=json.load(open('/tmp/audi-research/source-index-review-v1.json'))['sources'];C=json.load(open('/tmp/audi-research/census-review-v2.json'));B={v['id']:v for v in json.load(open('/tmp/audi-research/retained-before-cars.json'))};nv={v['id']:v for v in N['variants']};S={s['id']:s for s in P['sources']};prefix=P['id']+'-';issues=[];checks=collections.Counter();after={};add={v['id']:v for v in P['variants']}
def ck(ok,label,detail=''):
 checks[label]+=1
 if not ok:issues.append({'check':label,'detail':detail})
for kind in ['sources','models','variants']:
 ck(len({x['id'] for x in P[kind]})==len(P[kind]),'unique_'+kind)
ck(set(B)=={v['variantId'] for v in P['versionGuards']},'exact_refresh_set')
ck(set(add)=={v['id'] for v in N['variants'] if v['action']=='add'},'exact_addition_set')
for g in P['versionGuards']:
 b=B[g['variantId']];ck(g['before']=={k:b[k] for k in ['id','modelId','brand','model','trim','year','generation','vehicleClass','drive']},'exact_version_guard',g['variantId'])
for s in P['sources']:
 k=s['id'][len(prefix):];i=I.get(k);ck(i is not None,'source_index_membership',k)
 if i:
  ck(s['url']==i['url'] and s['capture_sha256']==i['rawSha256'],'source_pointer_exact',k)
  ck(s['capture_locator']=='audi-research/'+str(pathlib.Path(i['rawPath']).relative_to('/tmp/audi-research')),'capture_locator_exact',k)
for row in P['facts']:
 vid=row['variantId'];f=row['after'];key=f['key'];expected=B[vid]['facts'].get(key) if vid in B else None
 ck(row['before']==expected,'exact_fact_before',vid+'/'+key);ck((vid,key) not in after,'unique_fact',vid+'/'+key);after[vid,key]=f
for row in P['brandTerms']:
 key=row['key'];ck(set(row['applicableVariantIds'])==set(nv),'term_exact_scope',key)
 for vid in row['applicableVariantIds']:
  ck(row['before'][vid]==(B[vid]['facts'].get(key) if vid in B else None),'exact_term_before',vid+'/'+key);ck((vid,key) not in after,'unique_term',vid+'/'+key);after[vid,key]=row['fact']
for (vid,key),f in after.items():
 nf=nv[vid]['coreFacts'].get(key,nv[vid].get('extraFacts',{}).get(key));ck(nf is not None,'normalized_membership',vid+'/'+key)
 if nf:
  for field in ['value','buyerGrade','status','basis','comparisonBasis','unit']:
   ck(f[field]==nf[field],'normalized_'+field,vid+'/'+key)
  ck(f['sourceIds']==[prefix+s for s in nf['sourceKeys']],'normalized_sources',vid+'/'+key)
  ck(bool(f['issues'])==bool(nf.get('conflictId')),'conflict_preserved',vid+'/'+key)
 for sid in f['sourceIds']:ck(sid in S,'fact_source_closure',sid)
 ck(f['gradeReview']['sourceIds']==f['sourceIds'],'grade_source_identity',vid+'/'+key)
 ck(f['gradeReview']['overlayId']==P['id'] and f['gradeReview']['reviewedAt']==P['reviewedAt'],'grade_review_identity',vid+'/'+key)
 ck(f['date']==P['reviewedAt'],'current_fact_date',vid+'/'+key)
 grade=f['buyerGrade'];expected_status={'confirmed':'standard','check':'conditional','reported':'conditional','not_published':'not_verified'}[grade]
 ck(f['status']==expected_status,'grade_status',vid+'/'+key)
 if grade in ['confirmed','check']:
  ck(all(S[sid]['source_type']=='manufacturer_au_publication' for sid in f['sourceIds']),'maker_grade_sources',vid+'/'+key)
 if grade=='check':ck(bool(f.get('conditionExplanation')),'real_check_explanation',vid+'/'+key)
 if grade=='reported':ck(f.get('resolvedElsewhere') is True and f['gradeReview']['evidenceScope']=='secondary_or_sibling','reported_unranked_scope',vid+'/'+key)
 if grade=='not_published':ck(f['value'] is None and f['gradeReview']['evidenceScope']=='searched_not_found' and len({S[sid]['url'].split('#')[0] for sid in f['sourceIds']})>=2,'two_source_absence',vid+'/'+key)
 if key=='price_aud':ck(f['priceEvidence']['rankingEligible']==nf['rankingEligible'],'price_ranking_preserved',vid)
for row in P['availability']:
 vid=row['variantId'];a=nv[vid]['availability'];got=row['after'];ev=got['evidence'];ck(got['availability']==a['recordState'] and ev['orderStatus']==a['orderStatus'] and ev['stockStatus']=='unverified','availability_scope',vid)
 for sid in ev['sourceIds']:ck(sid in S,'availability_source_closure',vid+'/'+sid)
 if vid in B: exp={'availability':B[vid]['availability'],'evidence':B[vid]['availabilityEvidence']}
 else:exp={'availability':add[vid]['record_state'],'evidence':{'checkedAt':add[vid]['variant_review_date'],'orderStatus':'unverified','stockStatus':'unverified','sourceIds':add[vid]['source_ids'],'qualifications':['Physical stock and factory-order acceptance have not been verified.']}}
 ck(row['before']==exp,'exact_availability_before',vid)
 ck(all(ev[k] is False for k in ['physicalStockVerified','factoryOrderAcceptanceVerified','factoryBuildSpecificationVerified','deliveryToBuyerVerified']),'no_unverified_stock_claim',vid)
 if nv[vid]['formalModelYear']==2027:ck(got['availability']=='announced_provisional','future_not_on_sale',vid)
for row in P['summaries']:
 vid=row['variantId']
 for kind in ['strength','tradeoff']:
  clause=row[kind];nc=nv[vid]['summary'][kind];ck(clause['text']==nc['text'] and clause['label']==nc['label'],'summary_text_exact',vid+'/'+kind)
  ck([d['key'] for d in clause['dependencies']]==nc['dependencies'],'summary_keys_exact',vid+'/'+kind)
  for dep in clause['dependencies']:
   expected=after[vid,dep['key']];ck(dep['expected']==expected and expected['value'] is not None and not expected['issues'],'summary_dependency_exact',vid+'/'+kind+'/'+dep['key'])
refs=[]
def walk(x):
 if isinstance(x,dict):
  for k,v in x.items():
   if k in ['sourceKeys','officialSourceKeys','censusSourceKeys','source_ids'] and isinstance(v,list):refs.extend(v)
   elif k=='source_id' and isinstance(v,str):refs.append(v)
   else:walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
walk(C)
for k in refs:ck(k in I,'census_source_closure',k)
ck({v['id'] for r in C['currentVersionReviews'] for v in r['versions']}==set(nv),'census_exact_17_membership')
ck(all(not q['on_sale_eligible'] and q.get('maker_index_listed') for q in C['makerIndexListedButWithdrawn']),'q8_withdrawn_separation')
ck(C['wholeMarketCoverage']['closed'] is False,'no_wholemarket_closure')
ck(not P['features'] and not P['configurationUpdates'] and not P['versionUpdates'],'no_unrequested_equipment_metadata_edits')
report={'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Independent bounded JSON semantic, provenance and before-guard review; no actual catalogue application or hydration','packetPath':str(Ppath),'packetSha256':hashlib.sha256(Ppath.read_bytes()).hexdigest(),'normalizedSha256':hashlib.sha256(pathlib.Path('/tmp/audi-research/normalized-review-v5.json').read_bytes()).hexdigest(),'censusSha256':hashlib.sha256(pathlib.Path('/tmp/audi-research/census-review-v2.json').read_bytes()).hexdigest(),'status':'passed' if not issues else 'changes_required','checks':dict(checks),'checkCount':sum(checks.values()),'issues':issues,'coreGradeCounts':dict(collections.Counter(f['buyerGrade'] for v in N['variants'] for f in v['coreFacts'].values())),'counts':{'selectedVersions':17,'retainedRefreshes':7,'newVersions':10,'provisionalMY27':8,'onSale':9,'specificFacts':len(P['facts']),'sharedTermCells':34,'allFactCells':len(after),'coreFactCells':289,'supplementalCells':len(after)-289,'sources':len(S),'summaries':17},'limits':['No full-catalogue source closure or peer parity check performed','No actual-function preflight, compiler, tests, production build or device verification performed','Retained before values independently compared to the seven accepted selected JSONL row digests; no broad baseline recapture','Source capture hashes checked separately in source-index-hash-review-v1.json','Seven independent current calculator GET responses match author captures exactly']}
(R/'packet-v1-semantic-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['checks','limits']},indent=2))
