from pathlib import Path
import json,hashlib,re,datetime,ast
R=Path('/tmp/audi-review'); repo=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def check(p):
 q=Path(p['path']);assert q.is_file() and q.stat().st_size==p['bytes'] and sha(q)==p['sha256'],str(q)
 if 'realpath' in p: assert str(q.resolve())==p['realpath']
def write(n,j):
 p=R/n; assert not p.exists();p.write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(pin(p)))
def meta(p):
 p=Path(p)
 if not p.exists():return {'path':str(p),'exists':False}
 s=p.stat();return {'path':str(p),'exists':True,'realpath':str(p.resolve()),'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'mode':s.st_mode,'isDirectory':p.is_dir(),'isSymlink':p.is_symlink()}
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
f=Path('/tmp/audi-packet/fixture-typescript-correction-v1/focused-checks-v2'); reviews=[]
for name,expected in [('tests','ef44d42e2429b4b4b8aa2dbce82e57c0506804c5bc61f0801c934f807b0a4841'),('lint','c8e6c348f633af623b8d3f777fa95a1e8b2d5f98eddf8588ac9425e8c356e4a9')]:
 b=f/name;mp=b/'manifest.json';assert sha(mp)==expected;m=read(mp)
 for p in [m['script'],m['sourcePins'],m['wrapper']]:check(p)
 pins=read(m['sourcePins']['path']);assert len(pins)==19
 for p in pins:check(p)
 t=read(b/'run/terminal.json');a=read(b/'run/after-pins.json');o=(b/'run/stdout.log').read_text()
 assert t['exitCode']==0 and t['rawWaitStatus']==0 and t['automaticRetry'] is False
 assert sha(b/'run/stdout.log')==t['stdoutSha256'] and sha(b/'run/stderr.log')==t['stderrSha256']
 assert (b/'run/stderr.log').stat().st_size==0
 assert a['passed'] and a['count']==22 and a['preparedManifestSha256']==expected
 if name=='tests':
  assert re.findall(r'^ok (\d+) - ',o,re.M)==[str(i) for i in range(1,19)]
  assert '\n1..18\n' in o
  for field,n in [('tests',18),('pass',18),('fail',0),('cancelled',0),('skipped',0),('todo',0)]:assert re.search(r'^# '+field+' '+str(n)+r'$',o,re.M)
  assert not re.search(r'^not ok\b',o,re.M)
 else:
  entries=json.loads(o);assert len(entries)==1 and entries[0]['filePath']==str(repo/'tests/evidence-consumers.test.ts')
  e=entries[0]
  for field in ['messages','suppressedMessages']:assert e[field]==[]
  for field in ['errorCount','fatalErrorCount','warningCount','fixableErrorCount','fixableWarningCount']:assert e[field]==0
 reviews.append({'name':name,'manifest':pin(mp),'terminal':pin(b/'run/terminal.json'),'stdout':pin(b/'run/stdout.log'),'afterPins':pin(b/'run/after-pins.json'),'exitCode':0,'elapsedSeconds':t['elapsedSeconds'],'maxRssKiB':t['maxRssKiB'],'scopeAccepted':True,'stderrEmpty':True,'inputPinCount':len(pins)})
write('fixture-type-correction-focused-results-acceptance.json',{'at':now,'status':'accepted','reviewer':'review_audi_evidence','method':'Read-only independent hash, TAP, exact one-file ESLint JSON and pin comparison; no product execution by reviewer','checks':reviews,'testsPassed':18,'testsFailedSkippedCancelledTodo':0,'lintFiles':1,'lintErrorsWarningsSuppressed':0,'liveCorrection':pin(repo/'tests/evidence-consumers.test.ts'),'rootConditionalGateSatisfied':True,'claims':'Focused differential tests and single-file lint only; cold full-project recheck remains separately gated'})
b=Path('/tmp/audi-packet/full-project-typescript-v2');old=b.parent/'full-project-typescript-v1';m=read(b/'manifest.json');v1=read(old/'manifest.json')
assert sha(b/'manifest.json')=='40134fe13618503f5130287e44580e6cc31d4e799ebb0570dfd5c7d6650f6b45'
assert sha(b/'run.py')=='a67704871bbf029c1035005e3fb6ede649f15942bf27be807d001b764733139b'
assert not (b/'run').exists()
for k in ['wrapper','preparer','inputPins','projectRootMetadata','priorAttempts','metadataDelta']:check(m[k])
for k in ['originalConfig','installedVersions','runtimeVersion','runtimeMetadata','timeoutSeconds','killAfterSeconds','supervisorWatchdogSeconds','memoryLimits','environmentRemovals','environmentOverrides','maximumAttempts','automaticRetry','parallelExecutionAllowed','sourceMutationsAuthorized','regenerateTypes','installsAuthorized','resourceEscalationAuthorized','coreDumpsDisabledInChild']:assert m[k]==v1[k],k
assert m['command'][:-1]==v1['command'][:-1]
assert m['command'][-1]==str(b/'run/full-project.tsbuildinfo')
assert read(repo/'tsconfig.json')==m['originalConfig']
pins=read(b/'input-pins.json');before=read(old/'input-pins.json');assert len(pins)==32 and len(before)==31
assert pins[:31]==before
assert pins[-1]['path']==str(repo/'tests/evidence-consumers.test.ts')
for p in pins:check(p)
s=read(b/'project-root-metadata.json');prev=read(old/'project-root-metadata.json')
assert len(s['configuredRootFilePaths'])==361 and s['configuredRootFilePaths']==prev['configuredRootFilePaths']
assert s['directoryState']==prev['directoryState']
changes=[(a,c) for a,c in zip(prev['fileMetadata'],s['fileMetadata']) if a!=c]
assert len(changes)==1 and changes[0][0]['path']==str(repo/'tests/evidence-consumers.test.ts')
for p in s['fileMetadata']+s['directoryState']+m['runtimeMetadata']:assert meta(p['path'])==p,p['path']
for k in ['previousAttempt','previousResult','fixtureCorrectionManifest','fixtureCorrectionApplication','fixtureAfterPin']:check(m['separateRecheckAuthorization'][k])
check(m['cacheHandling']['liveCache'])
expected=(old/'run.py').read_text().replace("BASE = Path('/tmp/audi-packet/full-project-typescript-v1')","BASE = Path('/tmp/audi-packet/full-project-typescript-v2')").replace("assert g['reviewerReadinessConfirmed'] is True\n","assert g['reviewerReadinessConfirmed'] is True\nassert g['focusedCorrectionChecksAccepted'] is True\ncheck(g['focusedCorrectionVerification'])\n").replace("g['reviewerAcceptance'], *pins","g['reviewerAcceptance'], g['focusedCorrectionVerification'], *pins")
assert (b/'run.py').read_text()==expected
ast.parse((b/'run.py').read_text())
write('full-project-typescript-v2-readiness.json',{'at':now,'status':'accepted_ready_under_root_conditional_grant','reviewer':'review_audi_evidence','method':'Static read and bounded existing-file pin/metadata comparisons; no compiler or wrapper execution by reviewer','manifest':pin(b/'manifest.json'),'wrapper':pin(b/'run.py'),'focusedResultAcceptance':pin(R/'fixture-type-correction-focused-results-acceptance.json'),'inputPinsVerified':32,'originalPinsUnchanged':31,'configuredRoots':361,'originalRootPathsAndConfigUnchanged':True,'onlyRootMetadataChange':'tests/evidence-consumers.test.ts accepted <string[]> insertion','wrapperDeltaOnly':'v2 output directory and required pinned focused-result reviewer gate','freshDestinationAbsent':True,'liveCacheUnchanged':True,'resources':{'oldSpaceMiB':768,'semiSpaceMiB':1,'timeoutSeconds':900,'killAfterSeconds':10,'watchdogSeconds':920,'attempts':1},'executionCondition':'Root standing conditional grant plus exact receipt pins and exclusive heavy slot; no retries or source edits','priorTs2345AttemptRetained':True})
