from pathlib import Path
import difflib,json,hashlib,datetime
b=Path('/tmp/audi-packet/docs-draft');repo=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def check(p):
 q=Path(p['path']);assert q.is_file() and q.stat().st_size==p['bytes'] and sha(q)==p['sha256'],str(q)
m=json.loads((b/'documentation-bundle-manifest.json').read_text());assert sha(b/'documentation-bundle-manifest.json')=='d03be0f796ba19c8d9c6d7424402eac56deb01c698bcc3a40eb34fcfc946b6b5'
for t in m['targets']:
 check(t['after']);p=repo/t['relativePath']
 if t['before']['exists']:check(t['before'])
 else:assert not p.exists()
for p in [m['patch'],m['preservation']['schemaParagraph'],m['preservation']['progressAppend'],m['draftManifest']]:check(p)
for g in m['acceptedReceiptGroups']:
 for k in ['acceptance','independentAcceptance']:
  if k in g:check(g[k])
 for p in g.get('resultArtifacts',[]):check(p)
old=(repo/'docs/M1_PROGRESS.md').read_text();new=(b/'M1_PROGRESS.md').read_text();audi=(b/'AUDI_M1_UPDATE.md').read_text();schema=(b/'C1-schema-paragraph.md').read_text();append=(b/'M1_PROGRESS-append.md').read_text()
assert new.count('\n'+schema)==1 and new.endswith(append)
assert new[:-len(append)].replace('\n'+schema,'',1)==old
expected=''.join(difflib.unified_diff([],audi.splitlines(keepends=True),fromfile='/dev/null',tofile='b/docs/AUDI_M1_UPDATE.md'))+''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/docs/M1_PROGRESS.md',tofile='b/docs/M1_PROGRESS.md'))
assert (b/'documentation-draft.patch').read_text()==expected
assert sha(b/'apply-documentation.py')=='81b35d62eb71e27e0e2c3dde7305cb7020cfc9511187320c2692196af3a789df'
assert not (b/'application').exists()
for target in ['data/m1-brand-updates/audi-2026-10-15.json','data/m1-audi-market-reconciliation-2026-10-15.json']:assert (repo/target).is_file()
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'accepted_for_exact_two_document_application','reviewer':'review_audi_evidence','manifest':pin(b/'documentation-bundle-manifest.json'),'patch':pin(b/'documentation-draft.patch'),'applier':pin(b/'apply-documentation.py'),'targets':m['targets'],'readComplete':['AUDI_M1_UPDATE.md','M1_PROGRESS-append.md','C1-schema-paragraph.md','draft-manifest.json','apply-documentation.py'],'exactPreservationVerified':'Original M1 progress text remains byte-identical after removing the reviewed schema paragraph with its preceding separator newline and the exact append','semanticAcceptance':{'17AudiVersions9OnSale8Provisional':True,'makerPriceTotalsAndOrderAttribution':True,'reportedResidualLimitsAndUnknownProtocols':True,'289Core339FactTerm1173FeatureCounts':True,'427Catalogue350TierOne309OnSale':True,'190ScopedTestsAndSeparate18FocusedTests':True,'coldFullProject361RootPassSeparatelyAttributed':True,'failedV2HarnessTs2345AndEarlierHeapAttemptsRetained':True,'globalC1AndM1Open':True,'recoveryStillPending':True,'noProductionBuildFullSuiteMobileM2PublicationClaim':True},'method':'Read-only content review and exact small-file pin/diff comparison; no product execution or live mutation','applicationRequiresRootAuthorization':True,'applierReview':'Exact two-target allowlist, candidate/current-before and accepted-receipt hashes, one-shot application directory, preserved original/absence witnesses and final readback; no runtime or unrelated writes','reviewerCheckNote':'Initial comparator placed the schema separator newline at end-of-file; corrected to its actual adjacent insertion position. Candidate bytes were unchanged.'}
p=Path('/tmp/audi-review/documentation-final-readiness.json');assert not p.exists();p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(pin(p)))
