from pathlib import Path
import json,hashlib,collections,datetime,copy
O=Path('/tmp/audi-packet/selected-preflight-v3'); R=Path('/tmp/audi-review')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p); b=p.read_bytes(); return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
r=read(O/'result.json'); terminal=read(O/'run/terminal.json'); assert terminal['exitCode']==0
assert pin(O/'result.json')['sha256']=='f3f1e6bac452b1557acbd21285c6bf532f5c0f25411a3903f00cdddf2c07e13c'
for n in ['stdout','stderr']:assert pin(O/f'run/{n}.log')['sha256']==terminal[n+'Sha256']
assert read(O/'run/after-pins.json')['passed']
m=read(O/'prepared-command.json'); assert pin(O/'prepared-command.json')['sha256']=='9b79d1c7d02c4233eed551b0093e385dc4ee0d9079b4ea78ef9bf1e091a1cd2a'
for k in ['script','sourcePins','packet','reconciliation','wrapper']:assert pin(m[k]['path'])==m[k]
p=read(m['packet']['path']); cars=read(O/'selected-after-cars.json');packs=read(O/'selected-packs.json');stored=read(O/'portable.json');claims=read(O/'claims.json');obs=read(O/'undefined-witnesses.json');expected=read(O/'expected-review.json');before=read('/tmp/audi-research/retained-before-cars.json'); bi={x['id']:x for x in before};ci={x['id']:x for x in cars};adds={x['id'] for x in p['variants']}; assert len(ci)==17 and set(ci)==set(packs)==set(stored)
reviewed={(x['variantId'],x['after']['key']):x['after'] for x in p['facts']}
for term in p['brandTerms']:
 for ident in term['applicableVariantIds']:reviewed[ident,term['key']]=term['fact']
assert len(reviewed)==len(claims)==339
claimmap={(x['variantId'],x['key']):x['claim'] for x in claims};assert set(claimmap)==set(reviewed)
sourceIndex={};features=0;priceproj=0;nonprice=0
for ident,pack in packs.items():
 assert pack['car']==ci[ident]; assert len(pack['features'])==69 and len({f['criterion'] for f in pack['features']})==69;features+=len(pack['features']);local={s['id']:s for s in pack['sources']};assert len(local)==len(pack['sources'])
 for sid,s in local.items():
  if sid in sourceIndex:assert sourceIndex[sid]==s
  sourceIndex[sid]=s
 for f in pack['features']:
  assert f['variant_id']==ident and f['model_id']==ci[ident]['modelId'];assert set(f['source_ids'])<=set(local)
  if ident in adds and f['criterion']!='driveaway_price':assert f['status'] in ['not_verified','not_applicable']
 price=ci[ident]['facts']['price_aud'];f=next(x for x in pack['features'] if x['criterion']=='driveaway_price')
 if price['comparisonBasis']=='Driveaway':
  assert f['source_ids']==price['sourceIds'] and f['buyerGrade']==price['buyerGrade'] and f['verification_state']=='reviewed_canonical_driveaway_price';priceproj+=1
 else:
  assert ci[ident]['year']==2027 and f['status']=='not_verified' and f['source_ids']==[] and f['verification_state']=='unverified' and 'buyerGrade' not in f and 'gradeReview' not in f;nonprice+=1
 # Independent JSON transport inverse, not actual helper replay
 hydrated=copy.deepcopy(stored[ident]);ids=hydrated.pop('sourceIds');hydrated['sources']=[local[sid] for sid in ids]
 for f in hydrated['features']:f.setdefault('variant_id',ident);f.setdefault('model_id',ci[ident]['modelId'])
 assert hydrated==pack
assert (features,priceproj,nonprice)==(1173,9,8)
for (ident,key),f in reviewed.items():
 assert ci[ident]['facts'][key]==f
 claim=claimmap[ident,key];assert claim['buyerGrade']==f['buyerGrade'];assert claim['gradeReview']==f['gradeReview'];assert [s['id'] for s in claim['sources']]==f['sourceIds'];assert claim['carId']==ident
 for s in claim['sources']:
  full=sourceIndex[s['id']];assert all(full.get(k)==v for k,v in s.items())
for row in p['availability']:
 c=ci[row['variantId']];assert c['availability']==row['after']['availability'] and c['availabilityEvidence']==row['after']['evidence']
for row in p['summaries']:
 c=ci[row['variantId']]
 for side in ['strength','tradeoff']:
  assert c['buyerSummary'][side]['text']==row[side]['text']
  for dep in row[side]['dependencies']:assert c['facts'][dep['key']]==dep['expected']
assert obs==r['observations'];counts=collections.Counter(x['phase'] for x in obs);assert dict(counts)==r['counts']=={'before':16,'after':26}
assert len({(x['phase'],x['pointer']) for x in obs})==len(obs)
prior={(x['variantId'],x['pointer'],x['criterion'],x['property']):x for x in obs if x['phase']=='before'}
for x in obs:
 assert x['ownUndefined'] and x['enumerable'];assert x['pointer']==f"/packs/{x['variantId']}/features/{x['rowIndex']}/{x['property']}"
 assert x['property'] in ['confirmation_needed','gradeReviewStatus'];assert x['producer'];assert x['actualGeneratedAuditProof']==(x['variantId'] in adds)
 if x['phase']=='after':
  f=packs[x['variantId']]['features'][x['rowIndex']];assert f['criterion']==x['criterion'];assert x['property'] not in f
  if x['variantId'] not in adds:
   q=prior[x['variantId'],x['pointer'],x['criterion'],x['property']];assert {k:v for k,v in q.items() if k!='phase'}=={k:v for k,v in x.items() if k!='phase'}
  else:assert x['property']=='confirmation_needed' and x['criterion']=='novated_fbt'
proof={x['variantId']:x for x in r['producerProofs']};assert set(proof)==adds
for ident,x in proof.items():
 assert x['rawUnchanged'] and x['rawOptionalPropertiesAllAbsent'];assert x['rawInput']['variant_id']==ident;assert x['rawInput']['criterion']=='novated_fbt';assert not (set(['validUntil','buyerGrade','gradeReview','gradeReviewStatus','condition_label','usability_notes','confirmation_needed'])&set(x['rawInput']))
newObs=[x for x in obs if x['phase']=='after' and x['variantId'] in adds];assert len(newObs)==10 and {x['variantId'] for x in newObs}==adds
ap=r['generatedAvailabilityProof'];assert ap['originalPacketUnchanged'] and ap['identityOnlyInputUnchanged'];assert len(ap['rows'])==10 and {x['variantId'] for x in ap['rows']}==adds
for x in ap['rows']:
 edit=next(z for z in p['availability'] if z['variantId']==x['variantId']);assert {k:v for k,v in x.items() if k!='variantId'}==edit['before']
for k,v in r['rankCounts'].items():assert set(v['ranked'])==set(expected['rankingIds'][k]);assert len(v['ranked'])+len(v['excluded'])==17
c1=r['currentListProof'];assert c1['reviewedModels']==7 and c1['reviewedVersions']==17 and set(c1['reviewedVersionIds'])==set(ci);assert [x['code'] for x in c1['issues']]==['independent_lists','inventory_unresolved'];assert c1['issues'][1]['reference']=='lead:audi-my27-q6-sq6-suv-and-sportback';assert c1['evidence']==read(m['reconciliation']['path'])
assert r['selectedCoverage']['onSaleVersions']==9 and r['selectedCoverage']['allCatalogueVersions']==17
for key in ['inMemoryPortableExact','serializedPortableExact','writtenPortableReadback','livePacksUnchanged','otherRetainedEffectiveFeaturesDeepEqual']:assert r[key]
for key in ['newEquipmentExpanded','sourceEdits','productionCatalogueHydration']:assert not r[key]
assert r['defaultLoaderCalls']==0
result={'status':'accepted_selected_v3_actual_consumer_diagnostic','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':pin(O/'result.json'),'terminal':terminal,'manifest':pin(O/'prepared-command.json'),'packet':m['packet'],'counts':{'beforeCars':7,'afterCars':17,'reviewedFactTermCells':339,'featureRowsAndRuntimeClaims':1173,'driveawayProjections':9,'nonDriveawayUnverifiedRows':8,'beforeOptionalUndefinedPaths':16,'afterOptionalUndefinedPaths':26,'newActualNovatedProducerWitnesses':10,'generatedAvailabilityBeforeWitnesses':10},'omissionBreakdown':[{'phase':phase,'property':prop,'count':n} for (phase,prop),n in collections.Counter((x['phase'],x['property']) for x in obs).items()],'rankingCounts':{k:len(v['ranked']) for k,v in r['rankCounts'].items()},'outputs':[pin(O/f'{name}.json') for name in ['selected-after-cars','selected-packs','portable','claims','undefined-witnesses']],'checks':['Terminal exit0 and before/after pins/manifest/script/packet/wrapper binding verified','All339 exact applied facts/terms and actual fact claim grades/reviews/source metadata verified','All1173 selected feature rows unique, exact variant/model, source-closed; actual feature-claim assertions in successful harness','Independent read-back JSON transport reconstruction equals every stored pack; actual live/serialized/written portable helper parity passed in harness','All42 own-undefined witnesses exact path/criterion/property and producer-bound; retained16 recur exactly; new10 are only novated confirmation_needed','Actual ten-row addition builder witness equals every new packet availability before state','All17 availability and summary dependency snapshots match candidate','All ranking sets match independently reviewed normalized policy; eightMY27 remain outside on-sale','Seven exact reviews17versions accepted; combined inherited lead gap and independent-list gap remain explicit'],'limits':['No reviewer actual-function execution or hydration','Selected diagnostic only; split helper diagnostic and full stage/peer/report/registration checks pending','JSON cannot itself reproduce live undefined; live descriptor/producer evidence is from the pinned successful actual harness']}
(R/'selected-preflight-v3-result-acceptance.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'review':pin(R/'selected-preflight-v3-result-acceptance.json'),'counts':result['counts']},indent=2))
