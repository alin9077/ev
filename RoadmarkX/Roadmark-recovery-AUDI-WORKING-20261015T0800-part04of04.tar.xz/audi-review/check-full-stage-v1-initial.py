from pathlib import Path
import json,hashlib,collections
D=Path('/tmp/audi-packet/full-stage-v1'); O=D/'output'; V=Path('/tmp/audi-packet/selected-preflight-v3'); S=Path('/tmp/skoda-packet/full-stage-v1/output')
def load(p): return json.loads(Path(p).read_text())
def meta(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
m=load(D/'manifest.json');r=load(O/'stage-receipt.json');t=load(D/'run/terminal.json');assert t['exitCode']==t['rawWaitStatus']==0 and (D/'run/stderr.log').read_bytes()==b'';assert load(D/'run/after-pins.json')['passed']
for stream in ['stdout','stderr']: assert meta(D/f'run/{stream}.log')['sha256']==t[stream+'Sha256']
for a in r['artifacts']:assert meta(a['path'])==a
assert r['manifestSha256']==meta(D/'manifest.json')['sha256']=='64157458221004a554937e3287bc52184a1e974d77e6c36d4f2805a97084e848' and r['packetSha256']==m['packet']['sha256']
cd=load(O/'car-digest-comparison.json');fd=load(O/'research-field-digests.json');sc=load(S/'car-digest-comparison.json');sf=load(S/'research-field-digests.json')
for k,prior in [('baseline20','baseline20'),('corrected21','corrected21'),('current22','current22'),('current23','current23'),('current24','candidate24')]:assert cd[k]==sc[prior] and fd[k]==sf[prior] and len(fd[k])==14
assert len(fd['candidate25'])==14
cur={x['id']:x for x in cd['current24']};aft={x['id']:x for x in cd['candidate25']};oldids=set(m['existingSelectedIds']);selected=set(m['selectedIds']);newids=selected-oldids
assert len(oldids)==7 and len(selected)==17 and len(newids)==10 and len(cur)==417 and len(aft)==427 and set(aft)-set(cur)==newids
peers=set(cur)-oldids;assert len(peers)==410 and all(cur[i]==aft[i] for i in peers) and all(cur[i]!=aft[i] for i in oldids)
for out,pre in [('selected-after-cars.json','selected-after-cars.json'),('staged-packs.json','selected-packs.json'),('portable-packs.json','portable.json')]:assert (O/out).read_bytes()==(V/pre).read_bytes()
claims=load(O/'selected-citations.json');factclaims={(x['carId'],x['key']):x['claim'] for x in claims if x['key']!='availability'};vclaims={(x['variantId'],x['key']):x['claim'] for x in load(V/'claims.json')};assert factclaims==vclaims and len(factclaims)==339 and len(claims)==356
assert {x['carId'] for x in claims if x['key']=='availability'}==selected
w=load(V/'result.json');om=load(O/'portable-json-omissions.json');assert om['witnessSha256']==meta(V/'result.json')['sha256'] and len(om['observations'])==42
for x in om['observations']:
 y=dict(x);assert y.pop('producerVerified');assert y in w['observations']
assert len(om['generatedProofs'])==10
for x in om['generatedProofs']:
 y=dict(x);assert y.pop('actualFullStageRawEqual') and y.pop('actualAuditedFeatureCalled');assert y in w['producerProofs']
assert all(om[k] for k in ['allOtherPackValuesPlainJson','livePacksUnchanged','inMemoryPortableExact','writtenPortableReadback'])
a=load(m['currentBaselineReport']['path']);b=load(O/'staged-report.json');split=load(m['splitSelectedResult']['path']);assert (b['allCatalogueVersions'],b['tierOneVersions'],b['onSaleVersions'])==(427,350,309)
ab={x['brand']:x for x in a['brandProgress']};bb={x['brand']:x for x in b['brandProgress']};assert set(ab)==set(bb) and all(ab[k]==bb[k] for k in ab if k!='Audi');assert bb['Audi']==split['coverage']['brandProgress'][0]
assert [g for g in a['gaps'] if g['carId'] not in selected]==[g for g in b['gaps'] if g['carId'] not in selected]
assert len(a['gaps'])==372 and len(b['gaps'])==323 and len([g for g in b['gaps'] if g['carId'] in selected])==6
for x,y in zip(a['core'],b['core']):
 assert x['key']==y['key'];sa=next(q for q in ab['Audi']['core'] if q['key']==x['key']);sb=next(q for q in bb['Audi']['core'] if q['key']==x['key'])
 for k in ['total','filled','reviewed']:assert y[k]-x[k]==sb[k]-sa[k],(x['key'],k)
 for grade in x['grades']:assert y['grades'][grade]-x['grades'][grade]==sb['grades'][grade]-sa['grades'][grade],(x['key'],grade)
def groupRows(rank):
 pos=0;out={}
 for g in rank['groups']:
  ids=rank['rankedIds'][pos:pos+g['count']];assert len(ids)==g['count'];pos+=g['count'];key=(g['vehicleClass'],g['basis'],g['unit']);assert key not in out;out[key]=ids
 assert pos==len(rank['rankedIds']);return out
rankdeltas=[]
for x,y in zip(a['rankings'],b['rankings']):
 assert x['key']==y['key'];gx=groupRows(x);gy=groupRows(y)
 for key in gx.keys()|gy.keys():assert [i for i in gx.get(key,[]) if i not in selected]==[i for i in gy.get(key,[]) if i not in selected],(x['key'],key)
 assert [q for q in x['excluded'] if q['carId'] not in selected]==[q for q in y['excluded'] if q['carId'] not in selected]
 assert len(y['rankedIds'])==y['ranked'];assert set(y['rankedIds'])&selected==set(w['rankCounts'][y['key']]['ranked'])
 rankdeltas.append({'key':x['key'],'before':x['ranked'],'after':y['ranked'],'audiBefore':len(set(x['rankedIds'])&selected),'audiAfter':len(set(y['rankedIds'])&selected)})
ca=a['reconciliation'];cb=b['reconciliation'];assert cb['pass'] is False and cb['registryValid'] and cb['independentListCount']==0
assert set(cb['reviewedVersionIds'])-set(ca['reviewedVersionIds'])==selected and set(ca['reviewedVersionIds'])<=set(cb['reviewedVersionIds'])
assert set(cb['validModelReviewIds'])-set(ca['validModelReviewIds'])==set(split['c1']['validModelReviewIds']) and len(split['c1']['validModelReviewIds'])==7
inv={x['reference'] for x in ca['issues'] if x.get('brand')=='Audi' and x['code']=='inventory_unresolved'};assert len(inv)==8 and set(cb['settledInventory'])-set(ca['settledInventory'])==inv
assert [x for x in ca['issues'] if x.get('reference') not in selected|inv]==cb['issues'];assert len(ca['issues'])-len(cb['issues'])==15 and not any(x.get('brand')=='Audi' for x in cb['issues'])
assert r['bodyWitnesses']==split['bodyWitnesses'] and len(r['bodyWitnesses'])==4
assert b['grading']=={'reviewedCoreCells':4998,'totalCoreCells':5253,'reviewedPercent':95.1}
assert sum(x['reviewed'] for x in b['core'])==4998 and sum(x['total'] for x in b['core'])==5253
for k in ['missingModels','unresolvedLeads']:assert [x for x in a[k] if x['brand']!='Audi']==b[k]
assert set(b['brandsResearchCompleted'])-set(a['brandsResearchCompleted'])=={'Audi'} and set(a['brandsResearchCompleted'])<=set(b['brandsResearchCompleted'])
assert [x for x in a['brandsResearchRemaining'] if x!='Audi']==b['brandsResearchRemaining']
assert all(a[k]==b[k] for k in ['asOf','denominatorNote','summaryGaps','pairedOnSalePercent','inAllRankings','brandsDone','brandsRemaining'])
assert b['pairedOnSale']==309 and b['pairedOnSalePercent']==100
assert b['ageing']['overdue']==a['ageing']['overdue']==[] and b['ageing']['invalid']==a['ageing']['invalid']==[] and b['ageing']['excludedHistory']==a['ageing']['excludedHistory']
assert r['defaultLoaderCalls']==0 and not r['productionRegistration'] and not r['freshCanonicalRecapture'] and not r['earlierAddedVersionsReplayed']
receipt={'status':'accepted_full_stage_v1_outputs','reviewScope':'Bounded independent JSON/artifact/digest comparisons; no reviewer hydration, product execution, compiler or tests.','artifacts':{k:meta(p) for k,p in {'manifest':D/'manifest.json','stageReceipt':O/'stage-receipt.json','terminal':D/'run/terminal.json','report':O/'staged-report.json','carDigests':O/'car-digest-comparison.json','researchDigests':O/'research-field-digests.json','omissions':O/'portable-json-omissions.json'}.items()},'terminal':t,'checks':{'acceptedSkodaEveryIntermediateCarAnd14FieldDigestsExact':True,'currentCars':417,'stagedCars':427,'tierOneVersions':350,'onSaleVersions':309,'unchangedPeerWholeCarDigests':410,'changedRetainedAudiCars':7,'newCars':10,'selected17CarPackPortableBytesEqualAcceptedV3':True,'exactFactAndTermClaims':339,'availabilityClaims':17,'actualFeatureClaimsReproduced':1173,'beforeUndefinedPaths':16,'afterUndefinedPaths':26,'newActualProducerProofs':10,'other55BrandProgressExact':True,'nonAudiGapsAndWithinGroupRankingOrderAndExclusionsExact':True,'allCoreGradeAndCountDeltasExactlyAudi':True,'currentMakerListsAdded':7,'currentMakerVersionsReviewed':17,'inheritedAudiDispositionsSettled':8,'nonAudiC1IssuesExact':True,'bodyFactsRemainAbsentForFourMY27Q6Rows':True,'all146RuntimePinsUnchanged':True},'coverage':{'grading':b['grading'],'gaps':len(b['gaps']),'audiCriteria':bb['Audi']['criteria'],'audiResearchCompleted':bb['Audi']['researchCompleted'],'audiClosureIssues':bb['Audi']['closureIssues'],'globalC1':False,'independentWholeMarketLists':0,'rankDeltas':rankdeltas,'ageingDueNext30DaysBefore':a['ageing']['dueNext30Days'],'ageingDueNext30DaysAfter':b['ageing']['dueNext30Days']},'limitations':['Derived staged proof only; current registration and fresh normal validation/report equality remain to be established.','No whole-market C1 or ranking-completion claim.','No full project compile/build/test aggregate or real-device checks.']}
p=Path('/tmp/audi-review/full-stage-v1-result-acceptance.json');p.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps(meta(p)));print(json.dumps(receipt['coverage'],ensure_ascii=False))
