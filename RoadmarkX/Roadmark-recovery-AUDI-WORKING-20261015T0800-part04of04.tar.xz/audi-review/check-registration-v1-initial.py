import pathlib,json,hashlib,re
R=pathlib.Path('/tmp/audi-registration-bundle');m=json.loads((R/'manifest.json').read_text());sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();assert sha(R/'manifest.json')=='920db20ecf5c2377731fad37e1fb5cd5eec9bea6ba3f6caa76851868a865ea22';assert len(m['targets'])==13
for pin in m['provenancePins']+[m['patch'],m['applicationScript']]:assert sha(pin['path'])==pin['sha256']
for t in m['targets']:
 assert sha(t['after']['path'])==t['after']['sha256'] and pathlib.Path(t['after']['path']).stat().st_size==t['after']['bytes']
 if t['before']:
  for k in ['before','beforeCopy']:assert sha(t[k]['path'])==t[k]['sha256']
 else:assert not pathlib.Path(t['target']).exists()
fm=json.loads(pathlib.Path('/tmp/audi-packet/full-stage-v1/manifest.json').read_text());ip={x['path']:x for x in fm['pins']};assert len(m['unchangedPins'])==104
small=0
for pin in m['unchangedPins']:
 assert pin==ip[pin['path']]
 if pin['bytes']<=1000000:assert sha(pin['path'])==pin['sha256'];small+=1
 assert pathlib.Path(pin['path']).stat().st_size==pin['bytes']
t=R/'candidate/tests/m1-inventory-split.test.ts';s=t.read_text();old=pathlib.Path('/tmp/audi-split-proposal/tests/m1-inventory-split.test.ts').read_text();assert 'baselineBuild' not in s and '../baseline/' not in s and '/tmp/' not in s and 'sha256' not in s and 'bytes' not in s
assert len(re.findall(r'^test\(',s,re.M))==10
adverse=s[s.index('const failures:'):s.index('test("absent body facts')];assert adverse==old[old.index('const failures:'):old.index('test("absent body facts')];assert len(re.findall(r'^  \["',adverse,re.M))==68
for start,end in [('function listTypeBoundary','void listTypeBoundary;'),('test("valid exact split','const failures:'),('test("absent body facts','test("ordinary single-review'),('test("future order-open',None)]:
 now=s[s.index(start):s.index(end) if end else None];prior=old[old.index(start):old.index(end) if end else None];assert now==prior,start
f=R/'candidate/tests/fixtures/m1-inventory-split';reg=json.loads((f/'reconciliation.json').read_text());unchanged=json.loads((f/'unchanged-review-dispositions.json').read_text());assert unchanged=={'currentVersionReviews':reg['currentVersionReviews'],'inventoryResolutions':[x for x in reg['inventoryResolutions'] if x['inventoryId']!='audi-my27-q6-sq6-suv-and-sportback']}
assert (f/'ordinary-expected.json').read_bytes()==pathlib.Path('/tmp/audi-registration-tests/capture-run/run/stdout.log').read_bytes()
for name in ['packet-q6-my27.json','reconciliation.json','original-combined-lead.json']:assert (f/name).read_bytes()==(pathlib.Path('/tmp/audi-split-proposal/fixtures')/name).read_bytes()
inv=json.loads((f/'inventory-audi.json').read_text());orig=json.loads((f/'original-combined-lead.json').read_text());assert inv['records']==[] and inv['unverifiedLeads']==[orig]
receipt={'status':'ready_for_root_registration_grant','manifestSha256':sha(R/'manifest.json'),'patchSha256':sha(R/'registration.patch'),'applicationScriptSha256':sha(R/'apply-registration.py'),'targetCount':13,'coreTargets':5,'adaptedTestAndFixtureTargets':8,'adaptedTestAndFixtureBytes':sum(x['after']['bytes'] for x in m['targets'] if x['relativePath'].startswith('tests/')),'allExactBeforeAndCandidateGuardsChecked':True,'all104UnchangedPinMetadataEqualAcceptedFullstage':True,'unchangedSmallPinsRehashed':small,'largeUnchangedPins':'Size checked here; exact hash checked by guarded application before/after, no reviewer large rescan','testReview':'68 adverse mutations byte-identical;10 standalone protections retained; actual shipping helper imports, all-field ordinary fixture outputs with exact own-undefined restoration, no duplicated baseline helper or historical runtime byte/count pins','ordinaryExpectedSha256':sha(f/'ordinary-expected.json'),'applicationReview':'Exactly13 preguarded target writes; no hydration/tests/install/publication; postwrite exact verification, partial failure receipts, no retry or automatic rollback','limitations':['Live registration requires root explicit grant.','Adapted installed test runtime and current normal validation/report parity must pass after registration.'],'reviewerLiveEdits':False}
p=pathlib.Path('/tmp/audi-review/registration-v1-readiness.json');p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print('receiptSHA',sha(p))
