# Audi independent evidence review

Accepted for source/JSON semantics only: packet v1 `4a85ee0d92c7a49e3e2265791516658699dfe2320d3e52e2ce39b58b2f6d172e`, normalized v5 and census v2. See `packet-v1-semantic-review.json` for exact pins, check scope and limitations.

The seven current maker calculator responses were independently re-read and exactly matched retained author responses. The client directly displays VehicleDriveAwayPrice, with an LCT-inclusive MRDP footnote. Prices are NSW estimates using Sydney Metropolitan CTP assumptions, without options. GraphQL enumerates models/engines; GetPrice is a separate observed read-only GET endpoint. No total was derived.

All 108 source-index records' 146 nominated capture references match their retained hashes (144 distinct files). This is bounded source-index verification, not a whole-catalogue scan.

Seven retained selected cars match the accepted selector's exact JSON.stringify(car) plus newline digest contract. All packet before values match those selected rows. This is accepted derived-baseline reuse, not a new canonical export.

Preserved diagnostic attempts:
- `retained-before-digest-check.json` deliberately remains as the initial incorrect diagnostic: it omitted the newline required by the selector's documented JSONL digest contract, causing seven digest mismatches. The subsequent `retained-before-exact-jsonl-digest-check.json` uses that exact existing contract and matches all seven hashes and byte lengths. No source or baseline values were changed.
- An initial live-price-check script could not import the uninstalled Python requests package before making a request. The supported standard-library urllib implementation then completed all seven independent GET requests successfully. No software was installed.

No catalogue hydration, actual-function preflight, compiler, tests, broad peer comparisons, production build, user-computer access, browser launch or publication was performed by this reviewer. Those execution gates remain separate.
