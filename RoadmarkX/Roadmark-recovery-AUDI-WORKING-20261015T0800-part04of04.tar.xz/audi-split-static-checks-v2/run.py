"""Prepared only. Invoke once per pinned manifest after explicit root approval."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys
import time

m = Path(sys.argv[1])
expected = sys.argv[2]
assert hashlib.sha256(m.read_bytes()).hexdigest() == expected
x = json.loads(m.read_text())
assert x["kind"] in ("compile", "lint")
assert x["timeoutSeconds"] == 60 and x["killAfterSeconds"] == 10
assert x["automaticRetry"] is False
assert x["command"][1:3] == ["--max-old-space-size=256", "--max-semi-space-size=1"]
assert Path(__file__).resolve() == Path(x["wrapper"]["path"]).resolve()
pins = [x[k] for k in ("sourcePins", "toolPins", "wrapper", "scope")]
pins += json.loads(Path(x["sourcePins"]["path"]).read_text())
pins += json.loads(Path(x["toolPins"]["path"]).read_text())
scope = json.loads(Path(x["scope"]["path"]).read_text())


def checkpins():
    for pin in pins:
        path = Path(pin["path"])
        assert path.stat().st_size == pin["bytes"], pin["path"]
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            while data := stream.read(1024 * 1024):
                digest.update(data)
        assert digest.hexdigest() == pin["sha256"], pin["path"]
    for link in scope["symlinks"]:
        path = Path(link["path"])
        assert path.is_symlink() and os.readlink(path) == link["target"], str(path)
    for name in scope["expectedAbsentLivePaths"]:
        path = Path(name)
        assert not path.exists() and not path.is_symlink(), name
    assert hashlib.sha256(m.read_bytes()).hexdigest() == expected


def now():
    return datetime.now(timezone.utc).isoformat()


checkpins()
out = m.parent / "run"
out.mkdir(exist_ok=False)  # A second attempt cannot reuse this manifest's run directory.


def write(name, value):
    with (out / name).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


cmd = x["command"]
wrapped = ["/usr/bin/timeout", "--signal=TERM", "--kill-after=10s", "60s", *cmd]
env = os.environ.copy()
removed = ("NODE_OPTIONS", "NODE_PATH", "TS_NODE_PROJECT", "TS_NODE_COMPILER_OPTIONS")
for name in removed:
    env.pop(name, None)
env.update(x["environmentOverrides"])
write("invocation.json", dict(
    at=now(), cwd=x["workdir"], command=cmd, supervisedCommand=wrapped,
    preparedManifestSha256=expected, wrapperSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    beforePinsPassed=True, automaticRetry=False, sourceMutationsAuthorized=False,
    removedEnvironmentKeys=list(removed), environmentOverrides=x["environmentOverrides"],
))
start = time.monotonic()
with (out / "stdout.log").open("x") as so, (out / "stderr.log").open("x") as se:
    p = subprocess.Popen(wrapped, cwd=x["workdir"], env=env, stdout=so, stderr=se, start_new_session=True)
    write("started.json", dict(at=now(), pid=p.pid, processGroup=os.getpgid(p.pid)))
    _, status, usage = os.wait4(p.pid, 0)
    code = os.waitstatus_to_exitcode(status)
    p.returncode = code
    so.flush()
    se.flush()
    os.fsync(so.fileno())
    os.fsync(se.fileno())
terminal = dict(
    at=now(), exitCode=code, rawWaitStatus=status, elapsedSeconds=time.monotonic() - start,
    maxRssKiB=usage.ru_maxrss,
    stdoutSha256=hashlib.sha256((out / "stdout.log").read_bytes()).hexdigest(),
    stderrSha256=hashlib.sha256((out / "stderr.log").read_bytes()).hexdigest(),
    timeoutInterpretation="Raw wait status retained; no cause inferred",
    automaticRetry=False,
)
write("terminal.json", terminal)
pins_ok = False
try:
    checkpins()
    pins_ok = True
    write("after-pins.json", dict(at=now(), passed=True, count=len(pins), preparedManifestSha256=expected))
except Exception as error:
    write("after-pins.json", dict(at=now(), passed=False, error=repr(error)))

scope_ok = False
try:
    if x["kind"] == "compile":
        # --listFiles lists the actual program even when semantic diagnostics exist.
        observed = sorted(set(
            str(Path(line.strip()).resolve())
            for line in (out / "stdout.log").read_text().splitlines()
            if line.startswith("/") and line.strip().endswith(".ts")
        ))
        expected_sources = set(scope["expectedProjectFiles"])
        allowed_roots = [Path(path).resolve() for path in scope["allowedDeclarationRoots"]]
        unexpected = [path for path in observed if path not in expected_sources and not (
            path.endswith(".d.ts") and any(Path(path).is_relative_to(root) for root in allowed_roots)
        )]
        missing = sorted(expected_sources - set(observed))
        scope_ok = bool(observed) and not unexpected and not missing
        result = dict(passed=scope_ok, observedFiles=observed, unexpected=unexpected, missing=missing)
    else:
        reports = json.loads((out / "stdout.log").read_text())
        assert isinstance(reports, list)
        observed = [str(Path(item["filePath"]).resolve()) for item in reports]
        expected_files = sorted(scope["lintTargets"])
        messages = [dict(file=item["filePath"], message=msg) for item in reports for msg in item["messages"]]
        scope_ok = sorted(observed) == expected_files and len(observed) == 2 and all(
            item["errorCount"] == 0 and item["warningCount"] == 0 and item["fatalErrorCount"] == 0
            for item in reports
        )
        result = dict(passed=scope_ok, observedFiles=observed, expectedFiles=expected_files, messages=messages)
    write("scope-verification.json", dict(at=now(), kind=x["kind"], **result))
except Exception as error:
    write("scope-verification.json", dict(at=now(), kind=x["kind"], passed=False, error=repr(error)))
print(json.dumps(terminal))
print(json.dumps(dict(pinsPassed=pins_ok, scopePassed=scope_ok)))
print((out / "stdout.log").read_text()[-5000:])
print((out / "stderr.log").read_text()[-4500:])
sys.exit(0 if code == 0 and pins_ok and scope_ok else 1)
