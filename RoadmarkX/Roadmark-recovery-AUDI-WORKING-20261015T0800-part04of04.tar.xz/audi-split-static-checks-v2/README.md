# Audi split static checks: proportional pin scope, v2

Prepared only. No compiler, lint, wrapper, test, help/version command, installation or dependency mutation has run. The prior `/tmp/audi-split-static-checks` preparation remains unchanged. Explicit root approval is required before either invocation below.

## What changed

Only the pin registry and its versioned manifest references changed. `delta-from-v1.json` records the exact comparison. The wrapper, scope JSON and import-closure JSON are byte-identical to v1. The commands, working directory, strict config, 19 exact source copies/originals, two lint targets, timeout/heap limits and every behavioral/scope assertion remain unchanged.

The v2 registry contains 50 source/config/metadata pins and 53 tool/declaration/config pins. The tool pins total 10,134,803 bytes, down from 11,620 files / 228,651,909 bytes. Selection reused previously recorded file metadata; there was no new installed-tree scan or exhaustive rehash.

The 53 selected tool files cover the actual TypeScript and ESLint entrypoints and compiler payload, relevant package versions, directly referenced ESLint/Next/TypeScript parser and recommended-config files, and the standard-library/Node/Undici declaration entries that describe the checked scope. The code under test is still the full, real 19-file imported source closure, without fake types or stubs.

This records the toolchain as installed. It is deliberately not an integrity audit of every transitive dependency or runtime executable. Runtime binaries, unreferenced transitive package trees and runtime-only test JSON are no longer rehashed. Do not install or mutate dependencies concurrently with a check. The package lock, relevant package metadata, both compiler roots, exact source copies and their original counterparts remain pinned. Live helper/report pins and the assertion that the new test is absent from the live repository are unchanged.

## Unchanged boundaries

- Working directory and source fixture: `/tmp/audi-split-static-checks/fixture`
- Standalone strict TypeScript config: two explicit roots, 19 actual source files / 202,113 bytes, no root-project extension or broad include
- Same real installed TypeScript 5.9.3, ESLint 9.39.5, Node declarations 24.19.1 and Undici declarations 7.24.6
- Same byte-identical copied repo ESLint config, explicit config/no lookup, two filenames inside its cwd, no ignore/cache/fix, concurrency off, zero warnings
- 256 MiB V8 old-space and 1 MiB semi-space; these are heap bounds, not a hard RSS limit
- 60-second TERM timeout plus 10-second KILL grace; pin verification remains outside the tool-process timeout
- Sequential single attempts only, no retry or resource escalation
- Streaming before/after selected pin verification, wait4 raw status/RSS, logs and output hashes
- Compiler `--listFiles` must show all 19 sources and only the exact permitted declaration roots
- ESLint JSON must contain exactly the helper and test, with zero fatal errors/errors/warnings

The existing detailed scope explanation in the v1 README still applies except for its obsolete broad pin inventory and invocation paths. A Next rule may emit a missing-pages warning to stderr because the fixture intentionally contains no app/pages tree; stderr is retained for review, not suppressed.

## Frozen hashes

- `compile/prepared-command.json`: `554bed669ed550ca131805f6e717b1b06511d59598002f4daea456fc00a23c3e`
- `lint/prepared-command.json`: `4c27d1bc6a0f9f9b9c63de579d8f909e4258f655c6c90411a922fe97aaeb1187`
- `run.py`: `0b15ecff2320083c013cc2937a38a9a51c295257eea27eac071590dddc13d4d1`
- `source-pins.json`: `7fe92040a102eabcdb3f8fd8b3f1dc896f2cc488026762c47afac25b752d14c5`
- `tool-pins.json`: `8bf7645894c273838681f4656f58b0ceb7a7c680d64fdf7d899858a41464cde1`
- `scope.json`: `429ca489f78c81a97f39c69938607a85a377b24ff4ea4c1c93f5413f9e29479f`
- `delta-from-v1.json`: `b2480f684f46510662665d2e7110b7125162e511a427d11e2bf019a499c3493f`

## Exact proposed invocations, not executed

Compile, only after approval:

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/audi-split-static-checks-v2/run.py /tmp/audi-split-static-checks-v2/compile/prepared-command.json 554bed669ed550ca131805f6e717b1b06511d59598002f4daea456fc00a23c3e
```

Lint, only after separate or explicitly bundled approval:

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/audi-split-static-checks-v2/run.py /tmp/audi-split-static-checks-v2/lint/prepared-command.json 4c27d1bc6a0f9f9b9c63de579d8f909e4258f655c6c90411a922fe97aaeb1187
```

The new output locations are `/tmp/audi-split-static-checks-v2/compile/run/` and `/tmp/audi-split-static-checks-v2/lint/run/`. Neither exists at preparation. Any failure, timeout, drift, signal or incomplete result stops that attempt and must be reported to root. No retry or scope expansion is authorized by these artifacts.
