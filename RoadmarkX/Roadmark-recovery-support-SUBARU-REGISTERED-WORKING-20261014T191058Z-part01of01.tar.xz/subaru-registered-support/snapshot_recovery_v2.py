#!/usr/bin/env python3
"""Create non-destructive, independently restorable Roadmark recovery archives."""
import argparse, datetime, hashlib, importlib.util, io, json, os, re, shutil, sys, tarfile, time
from pathlib import Path
BASE=Path(__file__).resolve().parent
REPO=BASE.parent/"roadmark-104"
OMIT_DIRS={"node_modules",".git",".next","out","dist",".pnpm-store",".tool-cache",".tool-data","__pycache__", ".roadmark",".claude",".openai","playwright-report","test-results","browser-profile","browser-profiles"}
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(data): return hashlib.sha256(data).hexdigest()
def write_json(path,obj): path.write_text(json.dumps(obj,indent=2)+"\n")
def reason(path,rel):
    extra=json.loads(os.environ.get("ROADMARK_RECOVERY_EXCLUDE","[]"))
    if rel.as_posix() in extra or path.name in extra: return "Explicitly excluded active regression run; save final log/status after completion"
    if path.is_symlink(): return "symlink excluded"
    if any(x in OMIT_DIRS for x in rel.parts): return "dependency, build, cache, or runtime directory"
    if path.name.startswith(".env"): return "environment/credential configuration"
    if "headers" in path.name.lower() and path.suffix in {".txt",".json"}: return "HTTP response headers may include cookies"
    if path.name in {"configurator-prices.jpg","configurator-fees.jpg"}: return "browser screenshot excluded; corresponding public source captures retained"
    if path.name == "roadmark-104-source-trial.tar.xz": return "superseded opaque trial archive; its source roundtrip is separately captured with header sanitization"
    if path.suffix in {".pyc",".tsbuildinfo"}: return "regenerable cache"
    if re.search(r"(cookies?|credentials|auth-state|storage-state|session-state|secrets?)\.(json|txt|db|sqlite)$",path.name,re.I): return "authentication/runtime state"
    return None
def sanitize_json(data):
    redactions=[]
    try: obj=json.loads(data)
    except (ValueError,UnicodeDecodeError):return data,redactions
    def walk(value,pointer=""):
        if isinstance(value,dict):
            for key,child in list(value.items()):
                ptr=pointer+"/"+str(key).replace("~","~0").replace("/","~1")
                if key.lower() in {"cookie","set-cookie","authorization","proxy-authorization"} and isinstance(child,str) and child:
                    value[key]="[REDACTED: captured HTTP authentication/session header]"
                    redactions.append(ptr)
                elif isinstance(child,(dict,list)):walk(child,ptr)
        elif isinstance(value,list):
            for idx,child in enumerate(value):walk(child,pointer+"/"+str(idx))
    walk(obj)
    return ((json.dumps(obj,indent=2,ensure_ascii=False)+"\n").encode() if redactions else data),redactions

def sanitize_headers(data):
    lines=[]; redactions=[]
    sensitive={b"cookie",b"set-cookie",b"authorization",b"proxy-authorization",b"x-csrf-token",b"x-xsrf-token"}
    for number,line in enumerate(data.splitlines(keepends=True),1):
        key,sep,value=line.partition(b":")
        if sep and key.strip().lower() in sensitive:
            ending=b"\r\n" if line.endswith(b"\r\n") else b"\n" if line.endswith(b"\n") else b""
            line=key+b": [REDACTED: captured HTTP authentication/session header]"+ending
            redactions.append("line "+str(number)+": "+key.decode("utf8",errors="replace"))
        lines.append(line)
    return b"".join(lines),redactions

def stable_copy(src,dst):
    for attempt in range(4):
        s1=src.stat(); data=src.read_bytes(); s2=src.stat()
        if (s1.st_mtime_ns,s1.st_size)==(s2.st_mtime_ns,s2.st_size) and len(data)==s2.st_size: break
        time.sleep(.25)
    else: raise RuntimeError(f"File remained unstable: {src}")
    originalBytes=len(data);originalSHA256=digest(data)
    redactions=[]
    if src.suffix==".json":data,redactions=sanitize_json(data)
    elif src.suffix.lower()==".headers":data,redactions=sanitize_headers(data)
    dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
    rec={"bytes":len(data),"sha256":digest(data),"sourceMtimeNs":s2.st_mtime_ns,"originalBytes":originalBytes,"originalSHA256":originalSHA256}
    if redactions:rec["redactedHeaderPaths"]=redactions
    return rec
def add(tar,name,data):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
    tar.addfile(info,io.BytesIO(data))
def verify(path,expected):
    seen=set()
    with tarfile.open(path,"r:xz") as tar:
        for member in tar:
            if not member.isfile() or member.name.startswith("/") or ".." in Path(member.name).parts: raise RuntimeError("Unsafe member")
            if member.name in seen: raise RuntimeError("Duplicate member")
            seen.add(member.name); data=tar.extractfile(member).read()
            if member.name not in expected: raise RuntimeError("Unmanifested member "+member.name)
            rec=expected[member.name]
            if len(data)!=rec["bytes"] or digest(data)!=rec["sha256"]: raise RuntimeError("Hash mismatch "+member.name)
    if seen!=set(expected): raise RuntimeError("Missing archive member")
    return {"allMembersVerified":True,"members":len(seen),"bytes":path.stat().st_size,"sha256":digest(path.read_bytes())}
def snapshot(root,label,state,max_raw=45_000_000):
    root=Path(root);stamp=datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    cut=BASE/"snapshots"/(label+"-"+stamp);cut.mkdir(parents=True,exist_ok=False)
    tree=cut/root.name;start=now();included=[];excluded=[]
    candidates=sorted(p for p in root.rglob("*") if p.is_file() or p.is_symlink())
    for p in candidates:
        rel=p.relative_to(root);why=reason(p,rel)
        if why: excluded.append({"path":rel.as_posix(),"reason":why});continue
        rec=stable_copy(p,tree/rel);rec["path"]=(Path(root.name)/rel).as_posix();included.append(rec)
    finish=now()
    changed=[]
    for rec in included:
        p=root/Path(rec["path"]).relative_to(root.name)
        try:
            stat=p.stat()
            if (stat.st_mtime_ns,stat.st_size)!=(rec["sourceMtimeNs"],rec["originalBytes"]): changed.append(rec["path"])
        except FileNotFoundError:changed.append(rec["path"])
    if changed: state+="; individual files copied consistently but source changed during capture; see sourceChangesDuringCapture"
    manifest={"schemaVersion":1,"label":label,"state":state,"sourceRoot":str(root),"restoreRoot":root.name,"captureStartedAt":start,"captureCutoff":finish,"files":included,"excluded":excluded,"sourceChangesDuringCapture":changed,"restore":"Extract every numbered part into the same empty parent directory. Every part is independently extractable. Merge with older backups only deliberately; historical snapshots remain separate."}
    write_json(cut/"RECOVERY-FILE-MANIFEST.json",manifest)
    groups=[];cur=[];size=0
    for rec in included:
        if cur and size+rec["bytes"]>max_raw:groups.append(cur);cur=[];size=0
        cur.append(rec);size+=rec["bytes"]
    if cur:groups.append(cur)
    archive_records=[]
    for n,group in enumerate(groups,1):
        name=f"Roadmark-recovery-{label}-{stamp}-part{n:02d}of{len(groups):02d}.tar.xz"
        output=BASE/name
        part_manifest={**manifest,"part":n,"parts":len(groups),"files":group}
        manifest_data=(json.dumps(part_manifest,indent=2)+"\n").encode()
        restore=(f"Roadmark recovery: {label}\nState: {state}\nCapture interval: {start} to {finish}\nPart {n} of {len(groups)}\n\nExtract all numbered parts into one empty directory. The original folder name is retained.\nNo source data has been deleted. Header/cookie files, browser screenshots, dependency and build caches are excluded.\nFiles are byte-preserved; verify SHA-256 against the embedded part manifest.\n").encode()
        support={f"recovery-metadata/{label}-{stamp}-part{n:02d}.json":manifest_data,f"recovery-metadata/{label}-{stamp}-part{n:02d}-RESTORE.txt":restore}
        expected={r["path"]:r for r in group}
        with tarfile.open(output,"w:xz",preset=6,format=tarfile.PAX_FORMAT) as tar:
            for rec in group:add(tar,rec["path"],(cut/rec["path"]).read_bytes())
            for name,data in support.items():add(tar,name,data);expected[name]={"bytes":len(data),"sha256":digest(data)}
        record={"file":str(output),"filename":output.name,"label":label,"part":n,"parts":len(groups),"state":state,"captureStartedAt":start,"captureCutoff":finish,**verify(output,expected)}
        archive_records.append(record);print(json.dumps(record),flush=True)
    result={"archives":archive_records,"manifest":str(cut/"RECOVERY-FILE-MANIFEST.json"),"captureCutoff":finish,"files":len(included),"excludedFiles":len(excluded),"sourceChangesDuringCapture":changed}
    write_json(BASE/f"{label}-{stamp}-snapshot.json",result)
    return result
def source_cut(label,state):
    spec=importlib.util.spec_from_file_location("packager",REPO/"scripts/package-source.py");module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    cut=BASE/"snapshots"/(label+"-"+stamp);tree=cut/"roadmark";tree.mkdir(parents=True)
    start=now();records=[]
    for rel,p in module.source_files(REPO):
        rec=stable_copy(p,tree/rel);rec["path"]=rel.as_posix();records.append(rec)
    cutoff=now();changes=[]
    for rec in records:
        p=REPO/rec["path"];s=p.stat()
        if (s.st_size,s.st_mtime_ns)!=(rec["originalBytes"],rec["sourceMtimeNs"]):changes.append(rec["path"])
    if changes:raise RuntimeError("Source changed during snapshot: "+str(changes))
    result={"label":label,"state":state,"stagingSource":str(tree),"captureStartedAt":start,"captureCutoff":cutoff,"sourceChangesDuringCapture":changes,"files":records}
    write_json(cut/"SOURCE-CAPTURE.json",result)
    print(json.dumps({k:v for k,v in result.items() if k!="files"}),flush=True)
    return result
if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("kind",choices=["research","qa","source-cut"]);p.add_argument("label");p.add_argument("--state",required=True);a=p.parse_args()
    if a.kind=="source-cut": source_cut(a.label,a.state)
    elif a.kind=="qa":snapshot(BASE.parent/"roadmark-104-qa",a.label,a.state)
    else:snapshot(Path("/tmp")/(a.label+"-research"),a.label,a.state)

