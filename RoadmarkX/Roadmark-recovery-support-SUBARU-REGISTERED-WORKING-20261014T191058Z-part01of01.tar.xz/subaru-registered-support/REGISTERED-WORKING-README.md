# Roadmark Subaru registered working recovery

Subaru is registered in this frozen working source. This is a preservation checkpoint with TypeScript and release gates open. The separate Polestar recovery remains the last fully standard-checked integrated brand recovery; all intervening working recovery files remain available.

## Passed checks and exact limits

The approved Subaru packet/reconciliation, registry append and report-loader transition were registered at 18:33:33 UTC on 14 October. Fresh structural validation passed through the existing validation entry point using explicit post-import harness GC. The normal coverage CLI for 15 October passed; its complete 1,623,123-byte output exactly matches the staged report, without filtering or normalization.

214 distinct relevant tests passed across serial runs: 193 tests in six other files, plus all 21 tests in the later feature-file run. The earlier combined attempt did not pass. The one-line test helper transition preserves all 21 test bodies and 128 assertion calls; its original, revised bytes, diff and independent review are retained. Eight-file changed-file lint passed.

The complete current TypeScript compiler terminated with signal 9 and is unpassed. Production build, broad clean aggregate regression, real-device mobile verification, research C1/C5 and whole-market closure remain open. No release-ready, publication, M1 completion or fresh full-data row-for-row loader-equality claim is made.

## Preserve failure evidence

Keep all original failed commands and measured terminal/resource receipts. The original core phase exited 1. The interrupted full feature phase ended signal 9 with a 7,176-row/104-car partial; it remains alongside all eight successful ranges and aggregate. No partial is omitted using an assumed prefix relation.

The earlier combined and isolated Node test wrappers exited 1; their feature-test child explicitly reported SIGKILL. Do not relabel the wrapper as signal 9 or infer a cause. The later full 21-test pass is separate. Complete TypeScript failures have no successful terminal or diagnostics. Historical baseline interruption and its process-visibility correction remain in the reused chain.

## Restore and resume

Use the accompanying exact ordered archive manifest and existing standalone recovery verifier to restore into a new empty directory. The project is roadmark; QA is roadmark-104-qa. Six newly captured proof roots retain their original basenames. Historical absolute references resolve to these restored locations.

Read subaru-post-registration-review/final-post-registration-gate-addendum.json and subaru-retention-handover-2026-10-15/final-working-status-addendum-20261014T1906Z.json for the current state. Earlier unregistered/pending handovers remain historical; only their current-status statements are superseded.

The immutable 237-file staging allowlist is crosswalked exactly: 164 files in four external roots and 73 in QA, without duplicating the QA payloads. The 19 post-registration review files and four handover records are also included. Original 198-file sanitized research and 90-file accepted baseline proof are reused unchanged. The prior three optional car-prefix reconstructions remain outside normal restored-file counts.

Schedule expensive commands serially. Relevant remaining commands include the complete project typecheck, full regression suite, production build and mobile checks. Preserve each actual terminal and metric rather than claiming success from a partial log. Existing report comparisons retain their explicit 14/15 October dates.

No old local original or Library backup is deleted or replaced. The backup source retains the established ten-field legacy header sanitation with original/copied hashes; new proof and QA bytes are checked separately. Privacy scans are bounded known-value/header/runtime checks, not proof that every possible secret is absent.
