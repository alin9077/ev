#!/usr/bin/env python3
"""Exact original-hash keyed QA delta; bounded unchanged-file verification."""
import argparse,datetime,hashlib,importlib.util,json,pathlib,tarfile
P=pathlib.Path;B=P(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('snapshot',B/'snapshot_recovery_v2.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
CHUNK=1024*1024

def identity(p):
 s=p.stat();return (s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev)
def hashfile(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(CHUNK),b''):h.update(b);n+=len(b)
 return n,h.hexdigest()
def verify_prior(p,old):
 assert p.is_file() and not p.is_symlink(),p
 before=identity(p);n,h=hashfile(p);assert identity(p)==before
 assert (n,h)==(old['bytes'],old['sha256']),str(p)
def capture_file(src,old,prior):
 assert src.is_file() and not src.is_symlink()
 before=identity(src);n,h=hashfile(src);after=identity(src);assert before==after and n==before[0],str(src)
 reused=old is not None and (n,h)==(old.get('originalBytes'),old.get('originalSHA256'))
 if reused:
  verify_prior(prior,old)
  rec={k:v for k,v in old.items() if k!='path'};rec.update(originalBytes=n,originalSHA256=h,sourceMtimeNs=after[1]);data=None
 else:
  data=src.read_bytes();assert identity(src)==before and len(data)==n and r.digest(data)==h,str(src)
  redacted=[]
  if src.suffix=='.json':data,redacted=r.sanitize_json(data)
  elif src.suffix.lower()=='.headers':data,redacted=r.sanitize_headers(data)
  rec={'bytes':len(data),'sha256':r.digest(data),'originalBytes':n,'originalSHA256':h,'sourceMtimeNs':after[1]}
  if redacted:rec['redactedHeaderPaths']=redacted
  if old is not None and (rec['bytes'],rec['sha256'])==(old['bytes'],old['sha256']):verify_prior(prior,old)
 assert identity(src)==before,str(src)
 return rec,data,{'method':'exact-original-and-prior-sanitized-output-hashes' if reused else 'full-existing-sanitizer','sourceIdentity':list(before),'priorOutputVerified':old is not None and (rec['bytes'],rec['sha256'])==(old['bytes'],old['sha256'])}

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=P,required=True);p.add_argument('--baseline',type=P,required=True);p.add_argument('--prior-restore',type=P,required=True);p.add_argument('--omit',type=P,required=True);p.add_argument('--label',required=True);p.add_argument('--state',required=True);p.add_argument('--receipt',type=P,required=True);a=p.parse_args()
 base=json.loads(a.baseline.read_text());old={f['path']:f for f in base['files']};omitted=set(json.loads(a.omit.read_text()));stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');cut=B/'snapshots'/(a.label+'-'+stamp);cut.mkdir(parents=True,exist_ok=False)
 def reason(p):
  rel=p.relative_to(a.root);return 'Prior exact-prefix reconstruction mapping, unchanged originals remain local' if rel.as_posix() in omitted else r.reason(p,rel)
 candidates=sorted(p for p in a.root.rglob('*') if p.is_file() or p.is_symlink());start=r.now();full=[];changed=[];excluded=[];methods=[]
 for src in candidates:
  rel=src.relative_to(a.root);why=reason(src)
  if why:excluded.append({'path':rel.as_posix(),'reason':why});continue
  name=(P(a.root.name)/rel).as_posix();rec,data,proof=capture_file(src,old.get(name),a.prior_restore/name);rec['path']=name;full.append(rec);methods.append({'path':name,**proof})
  if name not in old or (rec['bytes'],rec['sha256'])!=(old[name]['bytes'],old[name]['sha256']):
   assert data is not None;dest=cut/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);changed.append(rec)
 finish=r.now();captured={f['path'] for f in full};now_paths={(P(a.root.name)/p.relative_to(a.root)).as_posix() for p in a.root.rglob('*') if p.is_file() and not reason(p)};assert now_paths==captured
 for f,proof in zip(full,methods):assert list(identity(a.root/P(f['path']).relative_to(a.root.name)))==proof['sourceIdentity'],f['path']
 manifest={'schemaVersion':3,'kind':'delta','label':a.label,'state':a.state,'sourceRoot':str(a.root),'restoreRoot':a.root.name,'captureStartedAt':start,'captureCutoff':finish,'baselineManifest':str(a.baseline),'baselineCaptureCutoff':base['captureCutoff'],'fullCurrentFileManifest':full,'files':changed,'excluded':excluded,'missingSinceBaseline':sorted(old.keys()-captured),'sourceChangesDuringCapture':[],'restore':'Extract prior safe archives first, then overlay every part of this delta. No deletion is performed. Exact previously sanitized files are reused only after matching original bytes/SHA256 and independently verifying prior output bytes/SHA256.'};r.write_json(cut/'RECOVERY-FILE-MANIFEST.json',manifest)
 receipt={'result':'PASS','captureStartedAt':start,'captureCutoff':finish,'chunkBytes':CHUNK,'baselineManifestSHA256':r.digest(a.baseline.read_bytes()),'scriptSHA256':r.digest(P(__file__).read_bytes()),'sanitizerModuleSHA256':r.digest((B/'snapshot_recovery_v2.py').read_bytes()),'priorRestore':str(a.prior_restore),'files':methods,'originalHashReused':sum(x['method'].startswith('exact-') for x in methods),'fullSanitizerApplied':sum(x['method']=='full-existing-sanitizer' for x in methods),'noOriginalFilesDeletedOrModified':True};r.write_json(a.receipt,receipt)
 groups=[];cur=[];size=0
 for f in changed:
  if cur and size+f['bytes']>45000000:groups.append(cur);cur=[];size=0
  cur.append(f);size+=f['bytes']
 if cur:groups.append(cur)
 if not groups:groups=[[]]
 archives=[]
 for n,group in enumerate(groups,1):
  out=B/f'Roadmark-recovery-{a.label}-{stamp}-part{n:02d}of{len(groups):02d}.tar.xz';m={**manifest,'part':n,'parts':len(groups),'files':group};support={f'recovery-metadata/{a.label}-{stamp}-part{n:02d}.json':(json.dumps(m,indent=2)+'\n').encode(),f'recovery-metadata/{a.label}-{stamp}-part{n:02d}-RESTORE.txt':(manifest['restore']+'\nState: '+a.state+'\n').encode()};expected={f['path']:f for f in group}
  with tarfile.open(out,'w:xz',preset=6,format=tarfile.PAX_FORMAT) as tar:
   for f in group:r.add(tar,f['path'],(cut/f['path']).read_bytes())
   for name,data in support.items():r.add(tar,name,data);expected[name]={'bytes':len(data),'sha256':r.digest(data)}
  archives.append({'file':str(out),'filename':out.name,'label':a.label,'kind':'delta','part':n,'parts':len(groups),'captureStartedAt':start,'captureCutoff':finish,'state':a.state,**r.verify(out,expected)})
 print(json.dumps({'archives':archives,'manifest':str(cut/'RECOVERY-FILE-MANIFEST.json'),'captureCutoff':finish,'files':len(full),'changedFiles':len(changed),'unchangedFiles':len(full)-len(changed),'missingSinceBaseline':manifest['missingSinceBaseline'],'excludedFiles':len(excluded),'sourceChangesDuringCapture':[],'boundedCaptureReceipt':str(a.receipt)},indent=2))
if __name__=='__main__':main()
