# Geely Australian M1 research packet

Checked Australian date: 14 October 2026. Staged and independently reviewed, not registered or published by this researcher. All work used dot's own environment. Original catalogue/research files and Model Y hero/art are untouched.

## Buyer result
- Full current Australian Geely BEV range: EX5 Complete Extended Range and Inspire Extended Range; EX2 Complete and Inspire. Four on-sale versions, two bodies.
- EX2 prices are maker RRP: A$26,490 / A$30,990 before on-road costs. EX5 Extended Range prices are Reported by CarExpert: A$41,990 / A$45,990 before on-road costs. No discounts, state driveaway conversions, invented fees or stock assumptions.
- Both outgoing 60.22 kWh EX5 grades remain visible but outside the on-sale denominator. Their reported reference prices are A$40,990 / A$44,990. Genuine current new-stock supply was not established; generic carsales listings expressly are not dealer/manufacturer offers. Used and demo ads do not establish new supply.
- The inherited EX5 20-minute time is correctly preserved as 30–80%, never 10–80%. All four current exact 10–80% durations remain Not published after genuine two-source searches. The outgoing 60.22 kWh versions retain an explicitly Reported approximately 28-minute 10–80% figure; it is not carried to the bigger battery.
- Shared manufacturer terms are stored once and explicitly inherited: private vehicle 7 years/unlimited kilometres; private traction battery 8 years/unlimited kilometres, with 70% original-capacity threshold. Commercial-use limits, first-registration start and component exclusions remain explicit. Roadside is 12 months initially, then service-activated extensions up to seven years, with limits and exclusions.

## Important evidence decisions
1. Geely's central Australian site returned 403, including a checked own-cloud-browser attempt. Its current Australian maker-authored guides and warranty documents are accessible through authorised dealer/media hosts; source authorship is distinguished from host. EX5 higher price rungs were sought but not established. EX2 RRP is in a maker-authored September release, not a dealer unit advertisement.
2. EX2 AC remains 6.6 kW from the detailed July guide, graded Check. The newer September maker release says 6 kW. Both are cited; the issue is explicit and unranked rather than silently called rounding. No optional feature or summary is allowed to depend on that unresolved issue.
3. Five seats and zero rated towing are Reported from Australian publications where the maker guides do not publish numeric counts/limits. EX5's towing preparation and 750 kg homologation lead do not prove a currently orderable tow-rated retail grade.
4. Battery numbers preserve unspecified gross/usable scope. Boot figures preserve second-row-up versus expanded/folded and front/rear scope. No VDA/SAE method is established, so cargo is unranked. EX5 is 302 L row-up, 410 L separately labelled expanded and 1,877 L rear folded; EX2 is 375 L rear, 70 L front and 1,320 L rear folded. No combined cargo total is calculated.
5. Sixteen guarded buyer-answer replacements keep canonical facts and prose aligned: six power answers, six storage answers and four EX5 AC-charging answers. Unsupported full-charge estimates are removed. EX5 no-frunk is explicitly Reported; EX2 front storage comes directly from its maker guide.
6. RD6 BEV is excluded from official-new Australian supply with fresh Riddara/authorised-network evidence and explicit Australian reporting. NZ/global availability and earlier expansion intentions do not establish an Australian offer. RD6 Econ/King Kong, future unorderable EV announcements, PHEVs and historical combustion models are separately explained; no overseas specifications were imported.

## Coverage and validation
The staged effective-catalogue importer/report passes against the registered BYD/Tesla view. Geely researchCompleted=true; 68/68 on-sale core cells have earned reviews, with four honest charging gaps. All six retained versions have fact-dependent strengths/trade-offs. C3, C4 and C6 pass for Geely; no Geely model/lead dispositions remain open. C1 still requires independent whole-market model-list closure, C2 remains open for the four charging gaps, and C5 remains open because Reported values and incomparable cargo are intentionally unranked. This is research completion, not global C1–C6 completion.

The stage validator verifies exact current before snapshots, fact/version and feature guards, all feature dependencies, citable and portable propagation, and immutable inputs. Its first assertion failed solely because JSON omitted undefined properties; normalising the read-only snapshot fixed that test harness without changing production guards or evidence. Final stage rerun passed after both independently identified availability corrections: outgoing order acceptance is unverified; EX2 Complete exact new stock is unverified because the cited Frankston NEW unit ads were Inspire.

Independent review approved packet SHA-256 f1a7332edda3fd9cdbb5d60f6b97636a20f5b14e623158f9c3705963f34ff882. Root owns registration and integration. Reconciliation wording was subsequently spaced for readability; its facts and outcomes were unchanged.

## Files
- geely-2026-10-14.json: approved guarded packet, 128 specific facts, three shared brand terms, 16 guarded features, six summaries, 36 exact source snapshots
- geely-reconciliation-2026-10-14.json: two current-body reviews, EX2 audit resolution and RD6 lead exclusion
- brand-model-list-reconciliation.json: brand-only published-list transcriptions and every difference; not represented as whole-market C1 closure
- source-index.json and evidence-manifest.json: verified source URLs, local captures and SHA-256 evidence hashes
- sources/, terms/, riddara/: captured primary/secondary evidence, searchable text and visual checks
- staged-report.json, after.json, features-after.json, stage-validation.log: final dry-run result
- scoped-tests.log and typecheck.log: focused verification, separate from root's full-suite/build coordination
