# Independent MG and IM M1 approval

Checked 14 October 2026. **Approved for guarded M1 registration at the exact hashes below.** Separate MG and IM identities and packets are preserved. No unresolved reviewer issue remains. Research completion is earned; target completion is not claimed.

## Approved immutable artifacts

| Artifact | SHA-256 |
|---|---|
| `/tmp/mg-im-research/mg-2026-10-14.json` | `b13872c4ffa2ae506e6a8e8c4daeac59db4fe6d6b267d5b6107797fb7c536e06` |
| `/tmp/mg-im-research/mg-reconciliation-2026-10-14.json` | `8102d0892e4cd6e7e54664749c5ab7ac4a1d3ec3ae2723d315fa3d6aa30f475c` |
| `/tmp/mg-im-research/im-2026-10-14.json` | `14e224bbd15a219d6a530bd0218e0183ceaa454f120ab990cf45762edd4ef801` |
| `/tmp/mg-im-research/im-reconciliation-2026-10-14.json` | `7f8ade71d596bd550181199f7dc39e45c3327011704705d1da3f329b35ab2961` |

MG final replay was bracketed by matching packet hashes. IM replay and final static/hash verification bind the unchanged approved IM bytes. The final combined researcher stage also passes, independently of these per-brand checks.

## Independent checks passed

- Read both governing M1 documents fully and reviewed actual Australian maker brochures, current pages, policy documents, dealer exact-identity captures, contemporary Australian secondary evidence and source conflicts. Current brand lists were reconciled separately; body, trim, formal model year, build/registration year and technical epoch were not treated as interchangeable.
- Independently captured the live pre-packet catalogue with all six previous brand overlays applied: 16 existing MG/IM cars and 1,104 effective equipment rows match researcher before snapshots exactly. Seven new-version equipment baselines were independently generated during replay.
- Full identity, source snapshot, fact, shared-term, availability, summary and equipment before guards and exact post-packet dependency snapshots pass. Every core field has fresh review metadata. Both MGS5 formal-year changes leave no inherited Confirmed technical fact unreviewed; known equipment is replaced or explicitly projected. MY26 residual Excite 49 does not silently inherit MY25 Confirmed equipment.
- Whole-row missing equipment uses exact `Not published`, `not_verified` and its own null `feature_<criterion>` dependency. Missing facts have earned two-distinct-source searches; failed responses are not substantive negative evidence. Historical source/feature context repair and before guards remain stable.
- Actual `src/lib/data.ts` compilation with an in-memory registry override matches explicit guarded staged features. Reviewed citable facts and equipment preserve exact grade review and source lists. Portable pack storage/hydration is deeply identical. Offer projections retain conditions, grade, citations and expiry; date-boundary tests retain the historical amount while marking the following day expired.
- Negative mutations of fact, source, identity, availability, shared-term and full equipment before snapshots, plus summary/equipment dependency snapshots, are rejected. Input objects remain immutable. Other brands and their order are unchanged.
- Both packets contain 151 source snapshots. All 302 combined source-index records equal exact packet sources; all 596 raw/text locator hash references pass. All 356 source-file manifest entries and all 18 artifact-manifest entries match bytes, lengths and SHA-256. Denied/unavailable responses are retained with honest limitations, not promoted as evidence.
- All 170 pre-existing application files and all 81 pre-existing data files remain byte-identical to the review baseline. Only the parent's `docs/M1_PROGRESS.md` differs among the broader 210-file baseline. The reviewer made no application, registry or original source-data edit.

## Guarded replay counts

| Brand | Versions | Specific facts | Shared term definitions | Citable reviewed facts | Equipment replacements / dependencies | Offer projections |
|---|---:|---:|---:|---:|---:|---:|
| MG | 17 | 851 | 3 | 902 | 416 / 582 | 14 |
| IM | 6 | 329 | 3 | 347 | 138 / 162 | 6 |

MG adds seven separately guarded residual identities: MG4 MY23 Excite 64 and MY25 Excite 51; MGS5 MY25 Excite 49, Excite 62, Essence 49, original 125 kW Essence 62; and MY26 Excite 49. Current MG4 Urban is its separate FWD body. IM remains six MY25 configurations; a 2026 unit heading does not relabel them MY26.

## Factual caveats preserved in approval

1. **Price ladder and eligibility.** Current national October MG4/Urban/MGS5/MGS6/IM offers take the highest available rung, with real private-buyer/dealer/date conditions at Check and 31 October expiry. Cashback is not subtracted twice; accessories are not a cash discount. Cyberster selector prices retain unknown on-road basis and remain unranked. MY25 MG4 Excite 51's $36,990 before-on-road figure is current Australian guide evidence at Reported, not a dealer quotation. Exact residual ads or guides are retained only after higher rungs are exhausted, with expired or mismatched offers rejected.
2. **Charging windows and power.** MGS5's 19/19.3 minutes and IM's 20/15.2 minutes are 30–80%, never relabelled 10–80%. All seven MGS5 and both 75 kWh IM versions have genuine 10–80% gaps. IM 100 kWh foreign/sibling 17-minute 10–80% evidence remains Reported and unranked. Cyberster AWD brochure page 6 explicitly supports 40 minutes 10–80%; RWD carry-over is openly Reported. Its 34 minutes is separately 30–80%; 150 kW station rating is not its 144 kW vehicle peak. Combined motor output is explicitly sourced, never obtained merely by adding motor component peaks.
3. **Model-year and conflicts.** Current MGS5 maker MY26 page plus dated, exact importer-quoted July refresh reporting identifies the two-Essence epoch, including 150 kW/350 Nm/450 km Essence 62. The older MY25 brochure footer is disclosed, and old 125 kW residuals stay distinct. Cyberster formal year remains null because the unchanged configuration does not resolve maker year disagreement. MGS6 RWD 7.5/7.3-second acceleration and both frunk-volume conflicts remain Check.
4. **Cargo and cycle.** MG4 Urban's 382 L rear cargo and 98 L separate underfloor are not treated as a 480 L standardized rear boot. Unspecified cargo method is left unranked, including all final MG4 boot/folded/underfloor bases; both brands have zero boot ranking entries. Cyberster cargo gains no invented seating/roof basis. IM6 Performance 646 L differs from 665 L other grades; IM5 marketing 755 km NEDC is not the Platinum 655 km WLTP claim.
5. **Shared terms and exceptions.** MG private standard cover is 7 years/unlimited km; conditional service activation extends to 10 years/250,000 km. Battery is 7 years/150,000 km with a 70% floor. IM private standard is 5 years/unlimited km, conditional extension 7 years/unlimited, battery 8 years/160,000 km/70%. Older registration policies, commercial use and limited components remain explicit. IM website/PDF first-registration date and air/four-wheel-steer warranty disagreements remain visible; the stronger term is not silently promised. IM roadside duration remains genuinely unpublished rather than inferred from MG or from warranty duration.
6. **Availability is advertising evidence.** New, registered New, Demo, sold, replaced and unretrievable pages remain distinct. Physical stock and factory-order acceptance are not verified by advertisements. The inherited 11-stock/five-unresolved-lead archive was recovered and finitely disposed, including G10095's exact Portside URL/VIN. That ad's unresolved 125/150 kW epoch does not create a duplicate version. Albany Cyberster's resolved VIN does not overcome deleted-at/See-similar evidence; MY24.5/MY25 Cyberster naming conflicts do not create an invented year version. Failed or blocked pages are not labelled sold. ZS EV's bounded residual checks do not establish a current exact New unit; this is not a nationwide absence claim. MGU9 EV remains Coming Soon/Register Interest despite hidden generic form data.

## Honest C1–C6 result

Both brands: C1 false, C2 false, C3 true, C4 true, C5 false, C6 true. Research completed is true; target `done` remains false. Both have zero missing reviewed models, unresolved research leads, unreviewed core grades, missing summaries and aged/invalid claims as of 14 October.

- **C1:** These are reconciled complete brand lists, not two independent whole-market snapshots. Global list closure remains open.
- **C2:** MG 282/289 core cells populated, with seven exact-window charging gaps; IM 100/102, with two. DC 10–80% coverage is 10/17 and 4/6 respectively, below 95%. All other core fields meet fill targets, including price.
- **C3:** Grades are earned. MG core split: 233 Confirmed, 11 Check, 38 Reported, 7 Not published, 0 Unreviewed. IM: 88 Confirmed, 6 Check, 6 Reported, 2 Not published, 0 Unreviewed. Below-half-Confirmed patterns are price (eligibility conditions and secondary residual evidence) and DC time (wrong-window maker publications, explicit sibling evidence and genuine gaps), not missing grading work.
- **C4:** All 23 versions have substantive dependency-bound strength/tradeoff pairs; no placeholder or unsupported market-wide superlative.
- **C5:** See exact eligible counts below. Reported, disputed and incompatible/unknown measurement bases are not upgraded to meet a quota.
- **C6:** No current reviewed claim is outside its freshness window as of the review date; offer deadlines remain carried through buyer-facing claims.

| Ranking | MG eligible / 17 | IM eligible / 6 |
|---|---:|---:|
| range_km | 15 | 6 |
| price_aud | 8 | 6 |
| dc_charge_time_min | 8 | 0 |
| seats | 12 | 6 |
| boot_l | 0 | 0 |
| towing_braked_kg | 11 | 6 |

## Reproduction and evidence

Run from `roadmark-104-qa` while neither approved packet is registered:

```sh
python3 review-mg-im-packet.py /tmp/mg-im-research/mg-2026-10-14.json
python3 review-mg-im-packet.py /tmp/mg-im-research/im-2026-10-14.json
../roadmark-104/node_modules/.bin/tsx review-mg-im-importer.ts /tmp/mg-im-research/mg-2026-10-14.json /tmp/mg-im-research/mg-reconciliation-2026-10-14.json
../roadmark-104/node_modules/.bin/tsx review-mg-im-importer.ts /tmp/mg-im-research/im-2026-10-14.json /tmp/mg-im-research/im-reconciliation-2026-10-14.json
```

Final independent logs: `mg-packet-final-review.log`, `im-packet-final-review.log`, `mg-importer-final-stage.log`, `im-importer-stage.log`. Exact machine-readable outcome: `mg-im-independent-approval.json`; manifest and immutability result: `mg-im-final-hash-audit.json`; full per-core splits/ranking reasons: `mg-independent-stage-report.json`, `im-independent-stage-report.json`. Researcher's combined result: `/tmp/mg-im-research/validate-stage.log` and `staged-report.json`.

Earlier `mg-im-independent-evidence-notes.md` and preliminary logs are preserved as historical work-in-progress, superseded by this exact-hash approval. This review does not claim to have rerun the entire application test suite; the parent's separate suite/test-boundary work is outside this evidence approval.
