# Equipment offer expiry metadata QA

Date: 14 October 2026. Scope: M1 shared evidence consistency only.

## Buyer-visible result

- A reviewed canonical or supplemental driveaway offer retains its inclusive `validUntil` on the equipment row. The selected primary price and sourced equipment amount are unchanged.
- The equipment answer, evidence drawer and citable claim label an ended offer separately from evidence age. The amount and earned grade remain visible; neither source dates nor review dates are refreshed.
- Missing deadline metadata retains legacy behaviour. Explicit malformed/empty deadlines say “Offer deadline needs confirmation” and enter stale reporting as invalid; they do not claim a known end date.
- Citable JSON and portable packs retain optional deadline metadata. Static citable claims also carry the live freshness-label component, so clients can identify expiry after a serialized report was generated. No start date is inferred.
- Equipment stale entries use the earlier offer deadline or evidence-age threshold, just as canonical facts do. Historical source-observation exclusions are unchanged. Feature-dependent cached summaries also stop depending on an ended offer.

## Checks

- New behavioural tests: 7 passed, 0 failed (`feature-offer-boundaries.log`). Covers both canonical and supplemental projection; 30/31 October, 1 November, day 45 (28 November), day 46 (29 November); invalid/missing deadlines; non-offer compatibility; JSON/Markdown/FAQ/evidence and portable string-codec roundtrips; stale entries; strict correction snapshots; cached summaries.
- Initial importer/new-feature run: 31 passed, 1 failed (`feature-offer-focused-initial.log`). The failure was a new test expecting JSON to preserve pre-existing undefined citation fields. Assertion corrected to compare serialized values; the seven-test rerun passes.
- Broader focused regression run: 138 passed, 0 failed across 11 targeted files, completed in 175.6 seconds (`feature-offer-focused.log`). No full test suite or build was requested or run.
- Typecheck passed with no diagnostics (`feature-offer-typecheck.log`).
- Targeted ESLint passed with no diagnostics (`feature-offer-lint.log`).
- Real Jaecoo pack replay on 1 November: selected primary A$35,990; equipment A$36,990, deadline 31 October, original evidence date 14 October, Check grade; equipment overdue from 1 November for the offer deadline (`feature-offer-jaecoo-check.log`).
- Independently compared all 78 pre-existing data JSON/CSV files against the Kia review worker's 01:08Z baseline: byte-identical, including the registry and five registered packets (`kia-expiry-fix-immutable-check.json`). Additional check: 71 immutable source/data files match the prior Jaecoo baseline and the approved Jaecoo packet/reconciliation hashes match (`feature-offer-data-integrity.log`). No data, packet, guard snapshot, research capture, hero, artwork or publishing edits were made by this fix.

## Exact edited source/test files

1. `src/lib/types.ts`
2. `src/lib/brand-updates.ts`
3. `src/lib/fact-validity.ts`
4. `src/components/freshness-label.tsx`
5. `src/components/ui.tsx`
6. `src/lib/citable.ts`
7. `src/components/citable-report.tsx`
8. `scripts/reporting/reports.ts`
9. `src/lib/corrections.ts`
10. `src/lib/report-review-proposal.ts`
11. `src/lib/evidence-regrade-policy.ts`
12. `src/lib/selling-points.ts`
13. `tests/feature-offer-validity.test.ts` (new)
14. `tests/report-review-proposal.test.ts`

Typecheck also refreshed the ignored generated `tsconfig.tsbuildinfo` cache. Portable storage code itself needed no change: its existing complete-field transport preserves the new optional property.

## Focused regression command

`node --import tsx --test --test-concurrency=2 tests/feature-offer-validity.test.ts tests/brand-updates.test.ts tests/brand-feature-updates.test.ts tests/fact-validity.test.ts tests/freshness.test.ts tests/coverage-reports.test.ts tests/citable.test.ts tests/portable-packs.test.ts tests/buyer-grade-display.test.ts tests/feature-corrections.test.ts tests/report-review-proposal.test.ts`
