# Kia M1 source review — 14 October 2026

## Buyer outcome
- 27 exact new-vehicle versions reviewed: 20 current maker/configurator versions and 7 separately evidenced residual-new versions, including MY26 EV4, MY26 EV6 and Niro EV GT-Line MY24/MY25
- Current factory list: EV3 five, EV4 Sedan three, EV5 four, EV6 four and EV9 four. EV3 AWD is now explicitly configured; obsolete provisional naming is removed
- Every version has a current labelled price and sourced strength/trade-off. Current factory primary prices are maker RRP; residual EV4 prices use eligible national driveaway offers, while the Niro and MY26 EV6 amounts are separately scoped to the reviewed exact residual versions
- Private-buyer warranty/roadside terms are shared once. Battery cover keeps the real MY2027/any-EV4 8-year exception versus earlier non-EV4 7-year policy, with 70% floor and commercial/component exclusions
- Stale energy-cost/estimated charging prose is replaced. 10 genuinely unestablished AWD equipment answers say Not published after two-source searches; no brochure-existence proxy establishes software fitment

## Scope and evidence
The staged packet contains 1,392 version-specific fact reviews, three shared policy records, 357 guarded equipment replacements and 111 fresh source records. 4 residual versions are new; all their reviewed facts begin with before:null and generated unknown fields remain the bounded buyer-field schema. Tier 2 PV5 Cargo is untouched. No registration, original-source edits, checkpoint or publication was performed.

CarExpert and CarsGuide complete Kia model lists are reconciled separately in brand-model-list-reconciliation.json. They are brand-only lists, not the two whole-market C1 lists. Inherited EV4/EV6/EV9 audit records are resolved; the inventory has no separate Kia unverified-lead records. The finite inherited EV6 stock trail also retains eight rejected or unverified leads as explicit demo, sold, conflicting or unavailable-page dispositions. Niro S searches returned used/demo listings only. EV2, EV3 GT, EV4 hatch/AWD/GT, EV5 GT and PV5 Passenger have no established current exact Australian retail offer; announced/regulatory-approved is not the same as orderable. Commercial vans remain excluded.

## Important qualifications
- Kia's live EV3 AWD API and rendered page publish A$63,950 RRP. The earlier July A$66,490 secondary report is retained as a historical discrepancy, without changing the current maker amount or reconstructing it from driveaway arithmetic
- The EV9 MY26 PDF has a future inspection footer, “As of 12 February 2027”. It is retained explicitly, not treated as a known publication date. Current live grade/price/order-enquiry evidence independently establishes the GT listing; no physical stock or completed order is claimed
- EV9 GT seats six. Its 333 L all-seats-used boot is Reported from an exact-GT Australian review; the maker's inconsistent seven-seat cargo heading is not silently repurposed. EV6 maker VDA-minimum boot figures retain unspecified seating/load position and stay unranked wherever the seating/load position is not established
- MY26 EV6 Air RWD and GT-Line RWD advertisements remain distinct from the current MY27 range. Exact dealer identities, prior-model specifications and price applicability are retained; a listing is not physical-stock verification
- MY25 Niro specifications are Reported MY24 sibling evidence. Maker Niro pricing expressly scopes 2025-built vehicles, so it is not used for the two advertised 2024-built residual units
- Maker charging times remain Confirmed on their exact stated supply/window, with station power separate from vehicle acceptance; generic laboratory and towing-use notes are retained without automatic grade downgrades

## Completion and remaining limits
Research completion: true, with 27 on-sale versions and no unreviewed core grades, missing summaries or aged/invalid current claims. All 459 core cells have an earned review; 458 have values. The only core gap is exact-Australian EV3 GT-Line AWD peak DC acceptance; the two current maker sources publish timed charging and station ratings only.

Core prices: 20 Confirmed, 3 Check, 4 Reported. DC peak: 26 Reported and one Not published because the maker's specification tables generally publish test-station outputs rather than acceptance peaks. This source pattern is explained, not promoted to meet a quota.

C2/C3/C4/C6 pass in the staged brand report. Strict C1 remains open for the global independent-list requirement. C5 remains open: range_km 24/27 (88.9%); price_aud 23/27 (85.2%); dc_charge_time_min 24/27 (88.9%); seats 24/27 (88.9%); boot_l 19/27 (70.4%); towing_braked_kg 24/27 (88.9%). Research completion does not claim strict C1–C6 completion.

## Verification and handoff
validate-stage.ts passed full current identity/fact/availability guards, exact feature chains/dependencies, canonical price/roadside projections, citable claims and portable round-trip propagation, generated new-version fields, unchanged Tier 2 PV5 and immutable inputs. Evidence-manifest.json verifies source/body and artifact hashes. Independent review is performed separately before root registration. Captured third-party documents stay under this temporary evidence directory and outside the delivered working source.

Register only after independent approval: kia-2026-10-14.json and kia-reconciliation-2026-10-14.json. Do not replay earlier registered brand packets against the new catalogue.
