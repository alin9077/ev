/** Dated Tier 1 research packets, applied after the frozen initial M1 view. */
import { validDate } from "./corrections";
import { availabilityLabels, safeUrl } from "./config";
import {
  applyAvailabilityCorrections,
  type AvailabilityCorrection,
} from "./availability-corrections";
import {
  sameReviewedState,
  assertReviewedJson,
  usableCorrectionSources,
} from "./correction-guards";
import { hasEarnedBuyerGrade } from "./evidence-grading";
import { priceCandidateRejection } from "./price-ladder";
import type { BuyerClause, BuyerSummary } from "./selling-points";
import type { Car, Fact, Feature, Research, Source, Variant } from "./types";

export type BrandVersionSnapshot = Pick<
  Car,
  | "id"
  | "modelId"
  | "brand"
  | "model"
  | "trim"
  | "year"
  | "generation"
  | "drive"
> & { vehicleClass: "passenger" | "ute" };
export type BrandFactUpdate = {
  variantId: string;
  before: Fact | null;
  after: Fact;
};
export type BrandSummaryClause = {
  label: string;
  text: string;
  /** Exact effective facts after this packet, never unrelated proxy evidence. */
  dependencies: { key: string; expected: Fact }[];
};
export type BrandSummaryUpdate = {
  variantId: string;
  conditions?: string[];
  strength: BrandSummaryClause;
  tradeoff: BrandSummaryClause;
};
export type BrandTerm = {
  key: "warranty" | "battery_warranty" | "roadside_assistance";
  fact: Fact;
  applicableVariantIds: string[];
  before: Record<string, Fact | null>;
  exceptions: { variantId: string; reason: string }[];
};
export type BrandUpdatePacket = {
  schemaVersion: 1;
  id: string;
  brand: string;
  reviewedAt: string;
  reviewedBy: string;
  /** Full snapshots. Existing IDs are checked; only genuinely new IDs are added. */
  sources: Source[];
  models: Research["models"];
  variants: Variant[];
  versionGuards: { variantId: string; before: BrandVersionSnapshot }[];
  versionUpdates: {
    variantId: string;
    before: BrandVersionSnapshot;
    after: BrandVersionSnapshot;
    reason: string;
  }[];
  facts: BrandFactUpdate[];
  /** One reviewed source of truth, explicitly inherited by all applicable versions. */
  brandTerms?: BrandTerm[];
  availability: AvailabilityCorrection[];
  summaries: BrandSummaryUpdate[];
};
const text = (value: unknown): value is string =>
  typeof value === "string" && !!value.trim();
const tier1 = (value: unknown) =>
  value === undefined || value === "passenger" || value === "ute";
function fail(message: string): never {
  throw new Error(`Brand update: ${message}`);
}
export function brandVersionSnapshot(car: Car): BrandVersionSnapshot {
  if (!tier1(car.vehicleClass)) fail(`version is outside Tier 1: ${car.id}`);
  return {
    id: car.id,
    modelId: car.modelId,
    brand: car.brand,
    model: car.model,
    trim: car.trim,
    year: car.year,
    generation: car.generation,
    vehicleClass: (car.vehicleClass ?? "passenger") as "passenger" | "ute",
    drive: car.drive,
  };
}
function validatePacket(packet: BrandUpdatePacket) {
  assertReviewedJson(packet);
  if (
    packet.schemaVersion !== 1 ||
    !text(packet.id) ||
    !text(packet.brand) ||
    !text(packet.reviewedBy) ||
    !validDate(packet.reviewedAt)
  )
    fail("invalid packet header");
  for (const key of [
    "sources",
    "models",
    "variants",
    "versionGuards",
    "versionUpdates",
    "facts",
    "availability",
    "summaries",
  ] as const)
    if (!Array.isArray(packet[key])) fail(`missing ${key} in ${packet.id}`);
  if (packet.brandTerms !== undefined && !Array.isArray(packet.brandTerms))
    fail(`invalid brand terms in ${packet.id}`);
  for (const key of ["sources", "models", "variants"] as const)
    if (new Set(packet[key].map((row) => row.id)).size !== packet[key].length)
      fail(`duplicate ${key} in ${packet.id}`);
  for (const key of [
    "versionGuards",
    "versionUpdates",
    "availability",
    "summaries",
  ] as const)
    if (
      new Set(packet[key].map((row) => row.variantId)).size !==
      packet[key].length
    )
      fail(`duplicate ${key} target in ${packet.id}`);
  if (
    new Set(packet.facts.map((row) => `${row.variantId}\0${row.after?.key}`))
      .size !== packet.facts.length
  )
    fail(`duplicate fact target in ${packet.id}`);
}
function orderedPackets(packets: readonly BrandUpdatePacket[]) {
  const seen = new Set<string>();
  let previous = "";
  for (const packet of packets) {
    validatePacket(packet);
    if (seen.has(packet.id) || packet.reviewedAt < previous)
      fail("duplicate packet ID or non-chronological registry");
    seen.add(packet.id);
    previous = packet.reviewedAt;
  }
}
function mergeSources(sources: Source[], packet: BrandUpdatePacket): Source[] {
  const result = [...sources];
  for (const source of packet.sources) {
    if (
      !text(source.id) ||
      !safeUrl(source.url) ||
      !text(source.title) ||
      !text(source.publisher) ||
      !text(source.source_type) ||
      !text(source.supports) ||
      !["AU", "Australia", "AU/NZ"].includes(source.market) ||
      !validDate(source.accessed_date) ||
      source.accessed_date > packet.reviewedAt
    )
      fail(`invalid source ${source.id}`);
    const current = result.filter((row) => row.id === source.id);
    if (
      current.length > 1 ||
      (current.length === 1 && !sameReviewedState(current[0], source))
    )
      fail(`source snapshot changed: ${source.id}`);
    if (!current.length) result.push(structuredClone(source));
  }
  return result;
}
function cited(ids: string[], packet: BrandUpdatePacket) {
  if (
    !Array.isArray(ids) ||
    !ids.length ||
    new Set(ids).size !== ids.length ||
    ids.some((id) => !packet.sources.some((source) => source.id === id))
  )
    fail(`missing explicit source snapshot in ${packet.id}`);
}
function newVariantCar(variant: Variant, models: Research["models"]): Car {
  const model = models.find((row) => row.id === variant.model_id);
  if (!model) fail(`unknown model for ${variant.id}`);
  return {
    id: variant.id,
    modelId: variant.model_id,
    modelFamily: model.family_id,
    family: variant.model_id.startsWith("byd_atto_3")
      ? "byd-atto-3"
      : variant.model_id.replaceAll("_", "-"),
    slug: (variant.id.split("__").length >= 3
      ? variant.id.split("__").slice(1).join("-")
      : variant.id
    ).replaceAll("_", "-"),
    brand: variant.brand,
    model:
      typeof variant.brand_update_model === "string"
        ? variant.brand_update_model
        : variant.model_id === "byd_atto_3_legacy"
          ? "ATTO 3 (legacy FWD)"
          : variant.model,
    trim: variant.trim,
    year: variant.model_year,
    generation:
      typeof variant.brand_update_generation === "string"
        ? variant.brand_update_generation
        : model.generation || "Generation details not verified",
    vehicleClass: (variant.vehicle_class ?? "passenger") as Car["vehicleClass"],
    researchStage: "partial",
    buyerGradesRequired: true,
    availability: variant.record_state,
    availabilityEvidence: {
      checkedAt: variant.variant_review_date,
      orderStatus: "unverified",
      stockStatus: "unverified",
      sourceIds: [...variant.source_ids],
      qualifications: [
        "Physical stock and factory-order acceptance have not been verified.",
      ],
    },
    drive: typeof variant.drive === "string" ? variant.drive : "Unknown",
    ...(variant.configuration_evidence
      ? {
          configurationEvidence: structuredClone(
            variant.configuration_evidence,
          ),
        }
      : {}),
    facts: {},
    issues: [],
  };
}
/** Research identity/features are added before route and pack enumeration. No original object is edited. */
export function prepareBrandResearch(
  base: Research,
  packets: readonly BrandUpdatePacket[],
): Research {
  orderedPackets(packets);
  if (!packets.length) return base;
  const result = {
    ...base,
    metadata: { ...base.metadata },
    models: [...base.models],
    variants: [...base.variants],
    sources: [...base.sources],
    trim_equipment: [...base.trim_equipment],
    feature_evidence: [...base.feature_evidence],
    update_eligibility: [...base.update_eligibility],
  };
  for (const packet of packets) {
    result.sources = mergeSources(result.sources, packet);
    for (const model of packet.models) {
      if (
        !text(model.id) ||
        !text(model.model) ||
        model.brand !== packet.brand ||
        result.models.some((row) => row.id === model.id)
      )
        fail(`invalid or duplicate model ${model.id}`);
      result.models.push(structuredClone(model));
    }
    for (const variant of packet.variants) {
      if (
        !text(variant.id) ||
        variant.brand !== packet.brand ||
        !text(variant.model) ||
        !text(variant.trim) ||
        !tier1(variant.vehicle_class) ||
        !Object.hasOwn(availabilityLabels, variant.record_state) ||
        !validDate(variant.variant_review_date) ||
        variant.variant_review_date > packet.reviewedAt ||
        result.variants.some((row) => row.id === variant.id) ||
        !result.models.some(
          (model) =>
            model.id === variant.model_id && model.brand === packet.brand,
        )
      )
        fail(`invalid or duplicate new version ${variant.id}`);
      // Values belong in guarded facts, not in two competing specification stores.
      if (
        [variant.price_aud, variant.range_km, variant.seats].some(
          (value) => value !== null,
        )
      )
        fail(`new version values must be supplied as facts: ${variant.id}`);
      if (variant.availability_evidence !== undefined)
        fail(
          `new version availability must use a guarded availability change: ${variant.id}`,
        );
      cited(variant.source_ids, packet);
      if (variant.configuration_evidence?.sourceIds)
        cited(variant.configuration_evidence.sourceIds, packet);
      result.variants.push(structuredClone(variant));
      result.trim_equipment.push({
        variant_id: variant.id,
        source_ids: [],
        notes: "Exact-version equipment research pending",
      });
      for (const criterion of result.criteria)
        result.feature_evidence.push({
          variant_id: variant.id,
          model_id: variant.model_id,
          criterion: criterion.key,
          value: "Needs confirmation",
          status: "not_verified",
          conditions: "Exact-version equipment research pending.",
          source_ids: [],
          evidence_scope: "AU exact version; research pending",
          last_evidence_date: packet.reviewedAt,
          reviewed_date: packet.reviewedAt,
          verification_state: "unverified",
        });
      result.update_eligibility.push({
        variant_id: variant.id,
        model_id: variant.model_id,
        documented_family_minimum: null,
        exact_total_known: false,
        exact_total: null,
        scope: "No exact-version software-update history established.",
        meaning: "Research pending",
        source_ids: [],
        observation_window_start: packet.reviewedAt,
        observation_window_end: packet.reviewedAt,
      });
    }
    const researchTargets = new Set(
      [
        ...packet.versionGuards,
        ...packet.versionUpdates,
        ...packet.availability,
        ...packet.facts,
        ...packet.summaries,
        ...(packet.brandTerms ?? []).flatMap((term) =>
          term.applicableVariantIds.map((variantId) => ({ variantId })),
        ),
      ].map((row) => row.variantId),
    );
    for (const id of researchTargets) {
      const variant = result.variants.find((row) => row.id === id);
      if (
        !variant ||
        variant.brand !== packet.brand ||
        !tier1(variant.vehicle_class)
      )
        fail(`wrong brand, version or tier: ${id}`);
      if (!packet.variants.some((row) => row.id === id)) {
        const guard = packet.versionGuards.find((row) => row.variantId === id);
        if (
          !guard ||
          !sameReviewedState(
            brandVersionSnapshot(newVariantCar(variant, result.models)),
            guard.before,
          )
        )
          fail(`reviewed version changed: ${id}`);
      }
    }
    for (const edit of packet.versionUpdates) {
      const index = result.variants.findIndex(
        (variant) => variant.id === edit.variantId,
      );
      if (
        index < 0 ||
        edit.after.id !== edit.variantId ||
        edit.after.brand !== packet.brand ||
        edit.after.modelId !== result.variants[index].model_id ||
        !sameReviewedState(
          brandVersionSnapshot(
            newVariantCar(result.variants[index], result.models),
          ),
          edit.before,
        ) ||
        !text(edit.reason)
      )
        fail(`invalid metadata target ${edit.variantId}`);
      result.variants[index] = {
        ...result.variants[index],
        brand: edit.after.brand,
        model: edit.after.model,
        brand_update_model: edit.after.model,
        trim: edit.after.trim,
        model_year: edit.after.year,
        drive: edit.after.drive,
        vehicle_class: edit.after.vehicleClass,
        brand_update_generation: edit.after.generation,
      };
    }
    for (const edit of packet.availability) {
      const index = result.variants.findIndex(
        (variant) => variant.id === edit.variantId,
      );
      if (index < 0 || result.variants[index].brand !== packet.brand)
        fail(`invalid availability target ${edit.variantId}`);
      result.variants[index] = {
        ...result.variants[index],
        record_state: edit.after.availability,
        availability_evidence: structuredClone(edit.after.evidence),
      };
    }
  }
  result.metadata.added_variant_count =
    Number(base.metadata.added_variant_count ?? 0) +
    result.variants.length -
    base.variants.length;
  result.metadata.added_feature_row_count =
    Number(base.metadata.added_feature_row_count ?? 0) +
    result.feature_evidence.length -
    base.feature_evidence.length;
  result.metadata.brand_update_packet_ids = packets.map((packet) => packet.id);
  return result;
}
function validateFact(
  fact: Fact,
  packet: BrandUpdatePacket,
  sources: Source[],
) {
  assertReviewedJson(fact);
  cited(fact.sourceIds, packet);
  if (
    !text(fact.key) ||
    !text(fact.label) ||
    !text(fact.basis) ||
    !text(fact.scope) ||
    !Array.isArray(fact.qualifications) ||
    !Array.isArray(fact.issues) ||
    !["AU", "Australia"].includes(fact.market) ||
    !validDate(fact.date) ||
    fact.date > packet.reviewedAt ||
    !fact.gradeReview ||
    fact.gradeReview.overlayId !== packet.id ||
    fact.gradeReview.reviewedAt !== packet.reviewedAt ||
    !sameReviewedState(fact.sourceIds, fact.gradeReview.sourceIds) ||
    !hasEarnedBuyerGrade(fact, sources, packet.reviewedAt) ||
    !usableCorrectionSources(fact.sourceIds, sources, packet.reviewedAt)
  )
    fail(`invalid fact or unearned grade: ${fact.key}`);
  const expectedStatus =
    fact.buyerGrade === "confirmed"
      ? "standard"
      : fact.buyerGrade === "not_published"
        ? "not_verified"
        : "conditional";
  if (
    fact.status !== expectedStatus ||
    (fact.buyerGrade === "check" && !text(fact.conditionExplanation)) ||
    (fact.buyerGrade === "reported" && fact.resolvedElsewhere !== true)
  )
    fail(`grade/status mismatch: ${fact.key}`);
  if (fact.key === "price_aud" && fact.value !== null) {
    const price = fact.priceEvidence;
    if (!price || !text(price.basisTag) || typeof fact.value !== "number")
      fail("price lacks ladder provenance");
    const rejection = priceCandidateRejection(
      {
        variantId: "packet",
        value: fact.value,
        sourceIds: fact.sourceIds,
        date: fact.date,
        ...price,
        comparisonBasis: fact.comparisonBasis as
          "" | "Before on-road costs" | "Driveaway",
        qualifications: fact.qualifications,
        validUntil: fact.validUntil,
      },
      "packet",
      sources,
      packet.reviewedAt,
    );
    if (rejection) fail(rejection);
    if (
      typeof price.rankingEligible !== "boolean" ||
      !text(price.originalBasis) ||
      (!fact.comparisonBasis && price.rankingEligible) ||
      (price.rung === 5 && !text(price.publisher))
    )
      fail("price lacks a truthful basis or source label");
    if (
      (price.rung >= 5 && fact.buyerGrade !== "reported") ||
      (price.rung === 1 && fact.comparisonBasis !== "Before on-road costs") ||
      ([2, 4].includes(price.rung) && fact.comparisonBasis !== "Driveaway")
    )
      fail("price grade or measurement basis contradicts its ladder rung");
  }
}
function unknownFacts(car: Car, templates: Map<string, Fact>, date: string) {
  const facts = { ...car.facts };
  for (const [key, template] of templates)
    if (!facts[key])
      facts[key] = {
        key,
        label: template.label,
        unit: template.unit,
        value: null,
        status: "not_verified",
        basis: "Exact-version research pending",
        comparisonBasis: "",
        sourceIds: [],
        date,
        market: "AU",
        scope: `${car.brand} ${car.model} ${car.trim}`,
        qualifications: [
          "No exact-version measurement has been verified for this field.",
        ],
        issues: [],
      };
  return { ...car, facts };
}
function clauseFor(
  clause: BrandSummaryClause,
  car: Car,
  packet: BrandUpdatePacket,
  strict: boolean,
): BuyerClause | undefined {
  if (
    !text(clause.label) ||
    !text(clause.text) ||
    !Array.isArray(clause.dependencies) ||
    !clause.dependencies.length ||
    new Set(clause.dependencies.map((dep) => dep.key)).size !==
      clause.dependencies.length
  )
    fail(`invalid summary clause for ${car.id}`);
  for (const dependency of clause.dependencies) {
    cited(dependency.expected.sourceIds, packet);
    if (
      dependency.expected.key !== dependency.key ||
      dependency.expected.value === null ||
      dependency.expected.issues.length ||
      !sameReviewedState(car.facts[dependency.key], dependency.expected)
    ) {
      if (strict)
        fail(`summary dependency changed: ${car.id}/${dependency.key}`);
      return undefined;
    }
  }
  const sources = new Map(packet.sources.map((source) => [source.id, source]));
  const facts = clause.dependencies.map((dep) => dep.expected);
  const deadlines = facts
    .flatMap((fact) => (fact.validUntil ? [fact.validUntil] : []))
    .sort();
  return {
    label: clause.label,
    text: clause.text,
    sourceIds: [...new Set(facts.flatMap((fact) => fact.sourceIds))],
    freshness: facts.flatMap((fact) =>
      [
        fact.date,
        ...fact.sourceIds.map((id) => sources.get(id)!.accessed_date),
      ].map((checkedAt) => ({
        checkedAt,
        key: fact.key,
        ...(fact.modelYearChangedAt
          ? { modelYearChangedAt: fact.modelYearChangedAt }
          : {}),
      })),
    ),
    ...(deadlines.length ? { validUntil: deadlines[0] } : {}),
  };
}
function summaryFor(
  row: BrandSummaryUpdate,
  car: Car,
  packet: BrandUpdatePacket,
  strict: boolean,
): BuyerSummary | undefined {
  const strength = clauseFor(row.strength, car, packet, strict);
  const tradeoff = clauseFor(row.tradeoff, car, packet, strict);
  if (!strength && !tradeoff) return undefined;
  const conditions = row.conditions ?? [];
  const required = car.configurationEvidence?.requiredBuyerVisibleConditions;
  if (required && !sameReviewedState(required, conditions))
    fail(`summary dropped version conditions: ${car.id}`);
  const ids = [
    ...new Set([
      ...(strength?.sourceIds ?? []),
      ...(tradeoff?.sourceIds ?? []),
    ]),
  ];
  return {
    checkedAt: packet.reviewedAt,
    guardSourceIds: ids,
    expectedSourceSnapshots: packet.sources.filter((source) =>
      ids.includes(source.id),
    ),
    conditions,
    ...(required ? { expectedVisibleConditions: [...required] } : {}),
    strength,
    tradeoff,
  };
}
/** Guarded changes to the effective initial M1 catalogue; legacy ledgers are never regenerated. */
export function applyBrandUpdates(
  base: Car[],
  research: Research,
  packets: readonly BrandUpdatePacket[],
): Car[] {
  orderedPackets(packets);
  if (!packets.length) return base;
  let cars = [...base];
  const templates = new Map(base.flatMap((car) => Object.entries(car.facts)));
  const summaries = new Map<
    string,
    { row: BrandSummaryUpdate; packet: BrandUpdatePacket }
  >();
  for (const packet of packets) {
    // The research extension is independently usable, but catalogue application checks all sources again.
    if (
      mergeSources(research.sources, packet).length !== research.sources.length
    )
      fail(`research is missing packet sources: ${packet.id}`);
    const addedIds = new Set(packet.variants.map((variant) => variant.id));
    for (const variant of packet.variants) {
      if (cars.some((car) => car.id === variant.id))
        fail(`duplicate catalogue version ${variant.id}`);
      cars.push(newVariantCar(variant, research.models));
    }
    const facts = [...packet.facts, ...expandBrandTerms(packet, cars)];
    if (
      new Set(facts.map((row) => `${row.variantId}\0${row.after.key}`)).size !==
      facts.length
    )
      fail(`duplicate shared or version-specific fact in ${packet.id}`);
    const guards = new Map(
      packet.versionGuards.map((guard) => [guard.variantId, guard.before]),
    );
    const targets = new Set(
      [
        ...facts,
        ...packet.availability,
        ...packet.summaries,
        ...packet.versionUpdates,
      ].map((row) => row.variantId),
    );
    for (const guard of packet.versionGuards) targets.add(guard.variantId);
    for (const id of targets) {
      const car = cars.find((row) => row.id === id);
      if (!car || car.brand !== packet.brand || !tier1(car.vehicleClass))
        fail(`wrong brand, version or tier: ${id}`);
      if (
        !addedIds.has(id) &&
        (!guards.has(id) ||
          !sameReviewedState(brandVersionSnapshot(car), guards.get(id)))
      )
        fail(`reviewed version changed: ${id}`);
    }
    cars = cars.map((car) =>
      targets.has(car.id) ? { ...car, buyerGradesRequired: true } : car,
    );
    for (const edit of packet.versionUpdates) {
      const index = cars.findIndex((car) => car.id === edit.variantId);
      const car = cars[index];
      if (
        !text(edit.reason) ||
        !sameReviewedState(brandVersionSnapshot(car), edit.before) ||
        edit.after.id !== car.id ||
        edit.after.brand !== packet.brand ||
        edit.after.modelId !== car.modelId ||
        !tier1(edit.after.vehicleClass)
      )
        fail(`metadata before snapshot changed: ${edit.variantId}`);
      cars[index] = {
        ...car,
        ...structuredClone(edit.after),
        buyerSummary: undefined,
      };
    }
    for (const edit of facts) {
      const index = cars.findIndex((car) => car.id === edit.variantId);
      const car = cars[index];
      const current = car.facts[edit.after.key] ?? null;
      if (!sameReviewedState(current, edit.before))
        fail(
          `fact before snapshot changed: ${edit.variantId}/${edit.after.key}`,
        );
      const accepted = structuredClone(edit.after);
      // A genuinely reviewed replacement supersedes a stale review marker; it
      // still has to earn its grade against this packet and its exact sources.
      delete accepted.gradeReviewStatus;
      validateFact(accepted, packet, research.sources);
      const touchesSummary = [
        car.buyerSummary?.strength,
        car.buyerSummary?.tradeoff,
      ].some((clause) =>
        clause?.freshness?.some((entry) => entry.key === edit.after.key),
      );
      cars[index] = {
        ...car,
        buyerGradesRequired: true,
        facts: { ...car.facts, [edit.after.key]: accepted },
        ...(touchesSummary ? { buyerSummary: undefined } : {}),
      };
    }
    for (const edit of packet.availability) {
      if (
        edit.status !== "approved" ||
        edit.reviewedAt !== packet.reviewedAt ||
        edit.reviewedBy !== packet.reviewedBy
      )
        fail(`invalid availability review: ${edit.id}`);
      cited(edit.after.evidence.sourceIds, packet);
    }
    if (packet.availability.length)
      cars = applyAvailabilityCorrections(
        cars,
        packet.availability,
        research.sources,
      );
    cars = cars.map((car) =>
      addedIds.has(car.id)
        ? unknownFacts(car, templates, packet.reviewedAt)
        : car,
    );
    for (const row of packet.summaries) {
      const car = cars.find((candidate) => candidate.id === row.variantId)!;
      summaryFor(row, car, packet, true);
      summaries.set(row.variantId, { row, packet });
    }
    // A later correction invalidates only actual dependent clauses of prior packets.
    cars = cars.map((car) => {
      const summary = summaries.get(car.id);
      return summary
        ? {
            ...car,
            buyerSummary: summaryFor(summary.row, car, summary.packet, false),
          }
        : car;
    });
  }
  return cars;
}

/** Store a brand term once; preserve reviewed per-version guards and explicit policy exceptions. */
function expandBrandTerms(
  packet: BrandUpdatePacket,
  cars: Car[],
): BrandFactUpdate[] {
  const rows: BrandFactUpdate[] = [];
  const keys = new Set<string>();
  const brandIds = cars
    .filter((car) => car.brand === packet.brand && tier1(car.vehicleClass))
    .map((car) => car.id);
  for (const term of packet.brandTerms ?? []) {
    if (
      !["warranty", "battery_warranty", "roadside_assistance"].includes(
        term.key,
      ) ||
      keys.has(term.key) ||
      term.fact.key !== term.key ||
      term.fact.gradeReview?.evidenceScope !== "brand_au_terms" ||
      !["confirmed", "check"].includes(term.fact.buyerGrade ?? "")
    )
      fail(`invalid brand term ${term.key}`);
    keys.add(term.key);
    const applicable = term.applicableVariantIds;
    const exceptions = term.exceptions;
    if (
      !Array.isArray(applicable) ||
      !applicable.length ||
      new Set(applicable).size !== applicable.length ||
      !Array.isArray(exceptions) ||
      new Set(exceptions.map((row) => row.variantId)).size !==
        exceptions.length ||
      exceptions.some(
        (row) => !text(row.reason) || applicable.includes(row.variantId),
      )
    )
      fail(`invalid brand term scope ${term.key}`);
    const all = [...applicable, ...exceptions.map((row) => row.variantId)];
    if (
      all.length !== brandIds.length ||
      all.some((id) => !brandIds.includes(id)) ||
      brandIds.some((id) => !all.includes(id)) ||
      !term.before ||
      !sameReviewedState(
        Object.keys(term.before).sort(),
        [...applicable].sort(),
      )
    )
      fail(`brand term must account for every current version: ${term.key}`);
    for (const variantId of applicable)
      rows.push({
        variantId,
        before: term.before[variantId],
        after: term.fact,
      });
  }
  return rows;
}
/** Canonical reviewed facts also feed their equipment/question rows. */
export function applyBrandTermFeatures(
  car: Car,
  features: Feature[],
): Feature[] {
  const roadside = car.facts.roadside_assistance;
  const price = car.facts.price_aud;
  const knownDriveaway =
    price?.comparisonBasis === "Driveaway" &&
    typeof price.value === "number" &&
    Number.isFinite(price.value) &&
    price.value > 0 &&
    !!price.priceEvidence &&
    !!price.buyerGrade &&
    price.buyerGrade !== "not_published" &&
    !!price.gradeReview &&
    price.gradeReviewStatus !== "review_required";
  const reviewedRoadside =
    !!roadside?.gradeReview &&
    roadside.gradeReview.evidenceScope === "brand_au_terms" &&
    roadside.gradeReviewStatus !== "review_required";
  return features.map((feature) => {
    const isPrice = feature.criterion === "driveaway_price" && knownDriveaway;
    const fact = isPrice
      ? price
      : feature.criterion === "roadside_assistance" && reviewedRoadside
        ? roadside
        : undefined;
    if (!fact) return feature;
    const projected: Feature = {
      ...feature,
      value: isPrice
        ? `A$${Number(fact.value).toLocaleString("en-AU")}`
        : String(fact.value ?? "Not published"),
      status: fact.status,
      buyerGrade: fact.buyerGrade,
      gradeReview: structuredClone(fact.gradeReview),
      conditions: [
        ...new Set([
          ...fact.qualifications,
          ...(fact.conditionExplanation ? [fact.conditionExplanation] : []),
          ...(isPrice && fact.priceEvidence?.state
            ? [`Driveaway price applies in ${fact.priceEvidence.state}.`]
            : []),
          ...(fact.validUntil
            ? [
                `Offer deadline: ${fact.validUntil}; confirm eligibility and earlier stock exhaustion.`,
              ]
            : []),
        ]),
      ].join(" "),
      source_ids: [...fact.sourceIds],
      last_evidence_date: fact.date,
      reviewed_date: fact.gradeReview!.reviewedAt,
      evidence_scope: fact.scope,
      verification_state: isPrice
        ? "reviewed_canonical_driveaway_price"
        : "reviewed_brand_au_terms",
      condition_label: isPrice
        ? [...new Set([fact.basis, fact.priceEvidence!.basisTag])].join(" · ")
        : fact.buyerGrade === "check"
          ? fact.conditionExplanation
          : "",
      // Notes from a replaced unknown/older quotation must not survive its replacement.
      usability_notes: [],
      confirmation_needed: "",
    };
    delete projected.gradeReviewStatus;
    return projected;
  });
}
