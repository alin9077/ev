# Independent Geely / Riddara M1 evidence review

Verdict: Approved for the parent's coordinated registration and integration checks, for the exact packet identified below. No remaining source, research-value or reviewed-snapshot blocker. This does not close whole-market C1, C2, C5 or M1, and does not authorize M2 or publication.

## Findings

- Four current Australian versions are supported: EX2 Complete/Inspire and EX5 Complete/Inspire Extended Range. CarExpert, CarsGuide and Carbroker brand lists agree on the two BEV families; PHEVs, historical combustion models and future Australian/China-only BEVs are explicitly reconciled. The two original 60.22 kWh EX5 grades remain outgoing. Their generic carsales listings explicitly disclaim dealer/manufacturer authorship and cannot establish live new stock or accepted orders. The final packet correctly leaves those orders unverified. EX2 Complete is current-listed but its stock remains unverified: the cited Frankston NEW unit advertisements are Inspire only. Both ER advertisements explicitly identify NEW, exact grade and dealer stock number; no physical-stock or factory-acceptance guarantee is made.
- EX2 prices A$26,490/A$30,990 are genuine manufacturer RRP from the September Australian release mirrored by Essendon Geely, before on-road costs. EX5 ER A$41,990/A$45,990 and outgoing A$40,990/A$44,990 are correctly Reported Australian publication/guide prices. An independent higher-rung search did not establish readable current maker EX5 pricing. Dealer driveaway ads and October finance/novated-lease offers are not substituted; fees, options and on-road exclusions stay explicit.
- Maker tables and dimensional drawings were independently inspected, including EX5 ER table pixels and EX2 cargo/dimension pixels. The packet preserves 68.39 versus 60.22 kWh, 475/450 versus 430/410 km, and 7.4/7.6 versus 6.9/7.1 seconds. EX2 values are 35.35/47.14 kWh, 252/345 km, 60/85 kW and 14.2/11.5 seconds. Gross/usable battery terminology is not invented. Cargo remains 302 L EX5 rear seats-up, 410 L separately labelled expanded, 1,877 L rear folded; EX2 rear 375/1,320 L and separate 70 L frunk. No VDA/SAE method or combined maximum is fabricated. Unspecified cargo methods remain unranked.
- The independently identified EX2 maker conflict is now retained: July guide 6.6 kW AC versus September release 6 kW. Both facts are Check, with a real issue and no ranking comparison basis. Five seats and zero towing remain Reported, rather than promoting secondary reports. The EX5 750 kg homologation entries have no established current named-trim retail mapping, so do not create new current versions or override the reported zero. Current ER and outgoing no-frunk claims use separately appropriate Australian reviews; sibling inheritance stays Reported.
- Four current-version 10–80% cells are genuine Not published searches. The EX5 maker's 20 minutes is separately retained as 30–80%, never converted. The EX2 guide has no 10–80% duration; Chasing Cars' proposed 10–80% estimate and EV Central/carloop calculated durations are explicitly rejected. The latter's methodology was inspected and describes derived charging data. The Driven's explicit approximately 28-minute 10–80% manufacturer confirmation is Reported only for the original battery grades. All four null facts cite distinct, examined URLs and explain their gaps.
- Shared manufacturer Australian warranty terms explicitly cover all Geely vehicles: private 7-year/unlimited-km vehicle and 8-year/unlimited-km traction battery, with 70% battery threshold. Commercial 150,000 km caps, first registration, prior-commercial-use and component/maintenance exceptions are retained. Roadside is conditional: initial 12 months, qualifying-service renewal, program maximum and towing limits. Independently followed the current Geelong roadside PDF link and downloaded it; its bytes match the research capture. The brand terms account for all six retained versions without assuming an RD6 Australian warranty.
- RD6 exclusion is supported by the official Australian retail-network list, manufacturer market-scoped releases, current local model list and Australian reporting. Earlier Australian export intentions and the genuine NZ offer are not current Australian orders. No RD6 facts or invented trims are added; the finding concerns official Australian new supply, not global discontinuation or every private import.

## Guard and consistency verification

The research before-catalogue and equipment captures exactly equal a separate live pre-packet capture made by this reviewer. All 128 specific fact snapshots, six version guards, four identity changes, six availability snapshots and every shared-term before-snapshot match. Existing source records are unchanged. All 36 source captures and 35 Riddara bundle files match their recorded hashes.

All 16 reviewed feature rows have exact full before-snapshots and 38 matching post-packet dependencies. Six storage answers and six motor answers agree with the canonical facts. Four EX5 home-charging answers remove old calculated full-charge estimates. The twelve strength/trade-off clauses have matching substantive dependencies, no unrelated freshness proxy and no unsupported market superlative. The independent 17-core-field matrix checker passes for all six retained versions.

No registry, original research or core source file was edited by this reviewer. Focused research checks are not a substitute for the parent's importer, regression, report and build checks.

## Exact reviewed artifacts

Packet: `/tmp/geely-research/geely-2026-10-14.json`

SHA-256: `f1a7332edda3fd9cdbb5d60f6b97636a20f5b14e623158f9c3705963f34ff882`

Reconciliation: `/tmp/geely-research/geely-reconciliation-2026-10-14.json`

SHA-256: `682544d30b186ee1c294c20deb5bb7bdb98022c41b144bb61efb759cfc50c8ea`

Reproducible QA: `review-geely-packet.py`, `geely-packet-check.log`, `geely-source-hash-verification.json`, and the independently captured web/source and live before-state files in this QA directory.
