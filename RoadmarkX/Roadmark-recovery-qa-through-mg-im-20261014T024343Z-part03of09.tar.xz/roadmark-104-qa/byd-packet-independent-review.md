# Independent BYD M1 packet review

Verdict: Approved for BYD packet registration, subject to the parent's coordinated foundation/integration validation. No research-value blocker remains. This is not a global C1, C2, C5 or M1-completion sign-off.

Reviewed the staged packet and reconciliation dated 14 October 2026, DOT-BRIEF-103.md and M1-BRAND-UPDATE-PACKET.md. Read-only review; no catalogue source or registry edits and no full-suite/full-catalogue runs.

## Checks performed

- Independently viewed all seven brochure page-2 table images: ATTO 1, ATTO 2, ATTO 3 EVO, legacy ATTO 3, DOLPHIN, SEAL and SEALION 7. Compared core values with the staged facts. All 12 PDF captures carrying hashes match their packet source metadata.
- ATTO 1 pixels explicitly print a shared 30-minute 10-80% row, plus 25/22-minute 30-100% rows. The packet retains both windows without a conversion and marks the source conflict Check. Reviewed discovery.ts: the unresolved issue excludes the 10-80% figure from ranking while preserving the value.
- ATTO 3 EVO pixels independently establish Dynamic FWD/Premium RWD differences: 60.48/74.88 kWh, 110/220 kW DC, 7/11 kW AC, 434/490 L rear boot and 750/1500 kg braked towing. Maker 41/30-minute 0-80% times remain separate. Premium 25-minute 10-80% is accurately Reported from WhichCar; Dynamic 10-80% stays unknown.
- Live-read all six official configurator routes. Exact named trim prices match; legacy Essential remains in the EVO configurator and legacy Premium is absent. The 13 current availability IDs exactly equal the versions in seven reconciliation body reviews. No stock or factory-acceptance proof is claimed.
- Live-read official offers: ATTO 1 Essential A$19,990 and DOLPHIN Essential A$28,888 are the exact national driveaway campaigns, ordered 15 September-15 December 2026, delivered by 31 December. Retail eligibility, metallic-paint exclusion, non-stacking and allocation conditions are retained, with validUntil 15 December. Other prices remain before-on-road configurator prices, not NSW driveaway totals. No higher explicit maker MLP source was established; no cashback, finance or novated-lease discount was subtracted.
- Live-read the current service/warranty page and followed its warranty link to vehicle-warranty-2026.pdf. Sections 1.3/1.3.1 support the shared 6-year/150,000-km vehicle and 8-year/160,000-km battery terms with 70% retention. Roadside 12 months from delivery is current. Each of three brandTerms applies to all 14 reviewed versions.
- All 11 core Not published cells have two distinct documents after stripping query strings; no duplicate-PDF URL substitution. Independently searched the relevant ATTO 1, ATTO 2 and SEAL handbook text. ATTO 2's 750-kg total towing claim is not labeled braked in the handbook, and remains a separate Check fact. SEAL and ATTO 1 lack numeric braked capacities. DOLPHIN's range-level 40-41-minute result stays separately Reported and unmapped.
- Independently read WhichCar, EV Central, GoAuto and CarExpert pages used for secondary facts. The specific Reported claims and the historical outgoing Premium price are supported. No secondary source is silently promoted to maker confirmation.
- All 28 strength/trade-off clauses have exact post-packet fact snapshots; numeric claims and supporting body/size facts are covered. No generic model-year or laboratory disclaimer is used to downgrade the new confirmed core facts.
- Lightweight structural checks pass: unique sources/fact targets, resolved citations, grade-review citation equality, same review dates, exact summary dependencies, all shared-term coverage and all fact/brand-term/version guards against the 14-car staged before.json capture.

## Small issues corrected by research worker and rechecked

- Historical legacy Premium price review reason now identifies CarExpert and historical scope
- Legacy Premium strength now depends on body_style; DOLPHIN Premium compact-body statement now also depends on length_mm
- Synthetic price source-pointer fragments removed in favor of verified page URLs
- Each handbook source's supports metadata now describes only its actual document

## Deliberately unresolved

Global independent market-list reconciliation is empty/open. Eleven core gaps remain. Boot volumes have no demonstrated VDA/SAE method and remain unranked. Secondary charging/towing values remain unranked. Parent must still run coordinated importer/integration and milestone validation after registration.

## Reproduction identity

Packet: /tmp/byd-research/byd-2026-10-14.json
SHA-256: f3783a1980cdc49ef1f4e49c227311b45fe8d90d030edcf05854a0c0bd26ab07
Reconciliation: /tmp/byd-research/byd-reconciliation-2026-10-14.json
SHA-256: fe42227db84de3cb665fba5f7253730c40dfb3cb2da8f62d0edfbffeeba1ff98
