# Omoda / Jaecoo independent evidence review

Checked 14 October 2026 against the effective Roadmark catalogue after BYD, Tesla, Geely and Zeekr packets. No source, registry, catalogue or original research files were changed by this review.

## Result

The frozen research packet and brand reconciliation are accepted. One existing Jaecoo J5 EV EV Summit MY26 remains the complete current Australian BEV version list for this group. No duplicate Chery E5, foreign Omoda E5, petrol/hybrid grade or future interest-only model is added. Registration is root-owned. Final runtime replay also passes after the root's supplemental driveaway-offer projection correction.

- All 17 core fields have a fresh, earned review: 15 Confirmed, one Reported (7.7-second acceleration), one Not published (DC 10–80%). No invented conversion fills the charge-time gap
- A$35,990 is the maker's undiscounted RRP, excluding registration, CTP, stamp duty and dealer delivery. The separate A$36,990 national October offer retains its 1–31 October new-stock/participating-dealer/no-paint-or-options conditions and deadline. A restricted novated-lease discount is not applied
- Maker evidence confirms 402 km WLTP, 58.9 kWh with gross/usable basis unspecified, 130 kW DC peak, approximately 28 minutes for 30–80%, 10.3 kW three-phase and 6.6 kW single-phase AC, five seats, 155 kW FWD, 4,380 × 1,860 × 1,650 mm, and 1,250 kg braked towing. Width mirror treatment remains explicitly unspecified
- Cargo bases are distinct: 384 L VDA to cargo cover and 480 L VDA to roof are maker figures. 35 L front storage and 1,180 L folded cargo are Reported with measurement-method limitations
- Private-use vehicle and battery warranties are eight years/unlimited kilometres. Commercial use is eight years/150,000 km; the vehicle policy explicitly applies the same terms to the HV battery. The battery's below-70% capacity threshold, demonstrator balance and 12 V battery exception are retained. Roadside starts at one year and renews with scheduled authorised servicing, with geographic exclusions stated
- Physical stock, factory acceptance and delivery dates remain unverified. Historic NEW advertisements are not refreshed or carried as physical-stock proof

## Independent findings resolved before freeze

1. The first home-charging replacement mixed a secondary absence-search citation into a Confirmed feature and failed earned-grade validation. The final AC-duration search uses two checked current maker pages; RACV independently corroborates the absence of a published AC duration
2. The initial folded-cargo gap would have withheld an available Reported figure. Independent checking located [WhichCar's Australian review](https://www.whichcar.com.au/reviews/jaecoo-j5-ev-review-stylish-small-electric-suv-hits-market), which explicitly publishes 1,180 L with the rear seats folded. The final packet uses that source
3. Unsupported 9-hour/5.5-hour home-charging estimates and A$665 annual electricity-cost prose are removed through exact guarded feature replacements. The maker's 143 Wh/km calculator input is labelled with no asserted test basis
4. An EVDB 40-minute 10–80% entry was rejected: its battery, AC and towing fields mismatch the current Australian maker specification and provide no traceable test basis. It is recorded as rejected evidence rather than promoted to a fact

## Checks

- Full before snapshots match independently captured effective facts, identity, availability and equipment
- All facts, brand-term applicability, feature and summary dependencies pass pure importer replay
- Negative mutations to fact, source, version, availability, brand-term, feature and summary guards fail closed
- 31 reviewed fact claims and five reviewed equipment rows preserve values, grades, review metadata and citations in citable output; portable packing/hydration is exact
- All other brands and catalogue record counts stay unchanged in replay
- Independent coverage replay finds one current version, no missing models/leads/summaries and no aged claims. Price, range, seats, boot and towing rank; the missing 10–80% duration is unranked
- The two independent brand-list families are CarExpert/JATO and CarsGuide/Glass's. Their complete brand-only mixed-powertrain scope is preserved. They do not falsely close whole-market C1
- All 112 research evidence-manifest entries verify. The final index records 40 successful bodies and two failed attempts. All 14 packet source captures verify directly
- All 71 pre-existing research/reconciliation data files in the review baseline remain byte-identical

## Final integration replay

The pre-fix canonical projection ignored promotional_driveaway_aud when price_aud correctly selected higher-rung RRP, retaining old driveaway equipment prose. Root corrected the projection and added price-provenance/basis regressions. The independent replay with REQUIRE_SUPPLEMENTAL_PRICE=1 now passes. The projected A$36,990 equipment row and citable claim preserve the fresh 14 October offer citation, Check grade, exact eligibility and 31 October deadline. Its portable citable roundtrip is exact. The selected A$35,990 RRP and before-on-road ranking basis remain unchanged. Full release/build checks remain root-owned.

Exact frozen hashes and test/capture records are separate JSON/log files beside this audit.
