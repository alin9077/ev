import json,re,copy,collections,pathlib
ROOT=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104')
QA=ROOT.parent/'roadmark-104-qa'
allcars=json.load(open(QA/'audit-existing-cars.json'))
cs=[c for c in allcars if c.get('vehicleClass','passenger') in ['passenger','ute']]
sources={s['id']:s for s in json.load(open(QA/'audit-existing-sources.json'))}
byid={c['id']:c for c in cs}
rows=[]
keys=['key','value','status','sourceIds','date','basis','comparisonBasis','scope','qualifications','conditionExplanation']
def snap(f):return {k:f[k] for k in keys if k in f} if f else None
def add(c,key,f,reason,location,kind='same-version-alias',support=None):
 if c['facts'].get(key,{}).get('value') is not None:return
 assert f['value'] is not None,(c['id'],key)
 assert all(s in sources for s in f['sourceIds']),(c['id'],f['sourceIds'])
 assert not any(x['variantId']==c['id'] and x['key']==key for x in rows),(c['id'],key)
 row={'variantId':c['id'],'brand':c['brand'],'model':c['model'],'trim':c['trim'],'key':key,'before':snap(c['facts'].get(key)),'kind':kind,'reason':reason,'evidenceLocation':location,'sources':[{'id':s,'url':sources[s]['url']} for s in f['sourceIds']],'fact':f}
 if support:row['supportingFact']={'key':support,'before':snap(c['facts'][support])}
 rows.append(row)
def fact(c,key,value,sids,date,basis,unit='',condition=None,label=None,quals=[]):
 return {'key':key,'label':label or {'power_kw':'Motor power','drive':'Drive type','battery_kwh':'Battery capacity','width_mm':'Width','height_mm':'Height','zero_to_100_s':'0–100 km/h','dc_peak_kw':'Peak DC acceptance','dc_charge_time_min':'DC charging time','ac_kw':'AC charging','warranty':'Vehicle warranty','battery_warranty':'Battery warranty','towing_braked_kg':'Braked towing'}[key], 'value':value,'unit':unit,'basis':basis,'comparisonBasis':basis,'status':'conditional' if condition else 'standard','sourceIds':sids,'date':date,'market':'AU','scope':f"{c['brand']} {c['model']} {c['trim']} · retained Australian evidence",'qualifications':list(quals),'issues':[],**({'conditionExplanation':condition} if condition else {})}
def alias(c,target,source,basis=None,condition=None,label=None,value=None):
 sf=c['facts'].get(source)
 if not sf or sf['value'] is None or c['facts'].get(target,{}).get('value') is not None:return
 f={k:copy.deepcopy(sf[k]) for k in ['value','unit','basis','comparisonBasis','sourceIds','date','market','scope','qualifications','issues']}
 f.update(key=target,label=label or {'battery_kwh':'Battery capacity','width_mm':'Width','height_mm':'Height','zero_to_100_s':'0–100 km/h','power_kw':'Motor power','ac_kw':'AC charging','dc_charge_time_min':'DC charging time','dc_peak_kw':'Peak DC acceptance','towing_braked_kg':'Braked towing'}[target],status='conditional' if condition else 'standard')
 if value is not None:f['value']=value
 if basis:f['basis']=basis;f['comparisonBasis']=basis
 if condition:f['conditionExplanation']=condition;f['qualifications'].append(condition)
 add(c,target,f,'Publish the already sourced named-version measurement with its actual basis; do not infer a different capacity, mode or protocol.',f"effective catalogue {c['id']}.facts.{source}",support=source)
for c in cs:
 for s in ['battery_usable_kwh','battery_gross_kwh','battery_advertised_total_kwh','battery_label_kwh','source_catalogue_battery_label_kwh','source_ora5_battery_capacity_stated']:
  sf=c['facts'].get(s)
  if sf and isinstance(sf['value'],(int,float)) and not any(r['variantId']==c['id'] and r['key']=='battery_kwh' for r in rows):
   cond=None if s in ['battery_usable_kwh','battery_gross_kwh'] else 'Published battery capacity; the maker does not identify this as gross or usable.'
   alias(c,'battery_kwh',s,condition=cond)
 alias(c,'width_mm','width_excluding_mirrors_mm',basis='Body width excluding mirrors')
 alias(c,'height_mm','height_including_roof_rails_mm',basis='Height including roof rails',condition='Height includes roof rails.')
 for s in ['zero_to_100_launch_control_s','zero_to_100_boost_s']:
  if c['facts'].get(s,{}).get('value') is not None and not any(r['variantId']==c['id'] and r['key']=='zero_to_100_s' for r in rows):
   sf=c['facts'][s];alias(c,'zero_to_100_s',s,condition=sf['basis'])
 if c['facts'].get('power_kw',{}).get('value') is None:
  for s in ['power_boost_kw','source_catalogue_boost_power_kw','maximum_power_kw','source_peak_power']:
   if c['facts'].get(s,{}).get('value') is not None and not any(r['variantId']==c['id'] and r['key']=='power_kw' for r in rows):
    sf=c['facts'][s];cond=sf['basis'] if 'boost' in s else None
    alias(c,'power_kw',s,basis=sf['basis'] if s!='source_peak_power' else 'Manufacturer advertised peak motor power',condition=cond)
 alias(c,'ac_kw','source_ora5_ac_charging_rate_stated',basis='Manufacturer stated AC charging rate')
 alias(c,'dc_peak_kw','dc_conditional_peak_kw',basis='Manufacturer conditional maximum DC charging power',condition=c['facts'].get('dc_conditional_peak_kw',{}).get('conditionExplanation'))
 sf=c['facts'].get('dc_charge_time_declared')
 if c['brand']=='smart' and sf and sf['value']:
  m=re.fullmatch(r'(\d+) min 10-80% \((\d+)kW\)\*',sf['value']);assert m
  alias(c,'dc_charge_time_min','dc_charge_time_declared',basis=f'10–80% on a {m[2]} kW charger',value=int(m[1]),condition=f'Manufacturer 10–80% reference time on a {m[2]} kW charger; local infrastructure affects actual charging time.')
  rows[-1]['fact']['unit']='min'
 # Exact braked rating supplied for an expressly optional towbar. Do not use nose weight.
 if c['brand']=='Porsche' and c['facts'].get('towing_option_2',{}).get('value')==3500:
  sf=c['facts']['towing_option_2'];assert 'braked, AUS/NZL' in sf['basis']
  alias(c,'towing_braked_kg','towing_option_2',basis='Maximum braked towing',condition='3,500 kg applies with the specified Performance Battery and Trailer hitch without tow ball configuration; extending towbar system is rated 3,000 kg.')
# Restore original snapshot motor fields omitted from the original adapter descriptors.
raw=json.load(open(ROOT/'data/au_ev_all_variants_2026-10-06.json'))
source_by_model={'byd_sealion_7':'byd_sealion_spec','geely_ex5':'geely_brochure_er','zeekr_7x':'zeekr_au_brochure_20250820','jaecoo_j5_ev':'jaecoo_spec_apr2026','byd_atto_2':'byd_atto2_spec','kia_ev5':'kia_ev5_spec','kia_ev3':'kia_ev3_spec','byd_atto_3_evo':'byd_evo_spec','byd_atto_3_legacy':'byd_atto3_spec'}
for v in raw['variants']:
 c=byid.get(v['id'])
 if not c or v.get('power_kw') is None:continue
 sid='v2_zeekr_black_primary' if 'black_special' in v['id'] else source_by_model[v['model_id']]
 date=v.get('field_review',{}).get('power_kw',{}).get('date') or v.get('specification_evidence_date') or v['variant_review_date']
 f=fact(c,'power_kw',v['power_kw'],[sid],date,'Manufacturer stated motor output','kW',quals=['Original dated Australian variant measurement retained; no re-observation date inferred from this display admission.'])
 add(c,'power_kw',f,'The immutable original variant has this published power figure; the adapter did not expose power_kw as a fact.',f'data/au_ev_all_variants_2026-10-06.json variants[id={v["id"]}].power_kw','retained-packet')
# Exact packet records whose power output was retained but not projected.
packet_maps={
 'kia-ev6-ev9-evidence-2026-10-10.json':('r10_kia_',{
  'kia-ev6-my27-air-rwd':'kia_ev6_my27__air_rwd__20261010','kia-ev6-my27-gt-line-rwd':'kia_ev6_my27__gt_line_rwd__20261010','kia-ev6-my27-gt-awd':'kia_ev6_my27__gt_awd__20261010','kia-ev9-my26-air-rwd':'kia_ev9_my26__air_rwd__20261010','kia-ev9-my26-earth-awd':'kia_ev9_my26__earth_awd__20261010','kia-ev9-my26-gt-line-awd':'kia_ev9_my26__gt_line_awd__20261010','kia-ev9-my26-gt-awd':'kia_ev9_my26__gt_awd__20261010'}),
 'toyota-subaru-evidence-2026-10-10.json':('r10_ts_',{
  'toyota-bz4x-current-awd':'toyota_bz4x_current__awd__20261010','toyota-bz4x-touring-current-awd':'toyota_bz4x_touring_current__awd__20261010','toyota-hilux-bev-current-sr-double-cab-cab-chassis':'toyota_hilux_bev_current__sr_double_cab_cab_chassis__20261010','toyota-hilux-bev-current-sr-double-cab-pick-up':'toyota_hilux_bev_current__sr_double_cab_pick_up__20261010','toyota-hilux-bev-current-sr5-double-cab-pick-up':'toyota_hilux_bev_current__sr5_double_cab_pick_up__20261010','subaru-solterra-my26-awd':'subaru_solterra_my26__awd__20261010','subaru-solterra-my26-awd-touring':'subaru_solterra_my26__awd_touring__20261010','subaru-trailseeker-my27-awd':'subaru_trailseeker_my27__awd__20261010','subaru-trailseeker-my27-awd-touring':'subaru_trailseeker_my27__awd_touring__20261010','subaru-uncharted-my27-awd':'subaru_uncharted_my27__awd_without_panoramic_glass_roof__20261010','subaru-uncharted-my27-awd-panoramic-roof':'subaru_uncharted_my27__awd_with_panoramic_glass_roof__20261010'}),
 'hyundai-evidence-2026-10-10.json':('r10_hyundai_',{'hyundai-ioniq5-my27-rwd':'hyundai_ioniq_5_my27__84kwh_rwd__20261010','hyundai-ioniq5-my27-elite-rwd':'hyundai_ioniq_5_my27__elite_84kwh_rwd__20261010','hyundai-ioniq5-my27-premium-n-line-awd':'hyundai_ioniq_5_my27__premium_n_line_84kwh_awd__20261010'})}
for filename,(prefix,mapping) in packet_maps.items():
 d=json.load(open(ROOT/'data'/filename))
 for record in d['records']:
  if record['id'] not in mapping:continue
  c=byid[mapping[record['id']]];p=record['specifications']['power_kw'];sids=[prefix+s for s in p['source_ids']]
  cond=None
  if p.get('verification_status')=='conditional_brochure_source_date_conflict':cond='Current MY26 brochure is dated into the future; this GT power figure is not corroborated by the separately dated MY26 document.'
  f=fact(c,'power_kw',p['value'],sids,'2026-10-10','Manufacturer combined system output','kW',condition=cond,quals=[p['locator']]+([p['qualifier']] if p.get('qualifier') else []))
  add(c,'power_kw',f,'Published combined system power already retained for the exact named version; no sum of motor peaks.',f'data/{filename} records[id={record["id"]}].specifications.power_kw','retained-packet')
# BYD ATTO 1 exact grade power is held in the original packet.
d=json.load(open(ROOT/'data/atto1-evidence-2026-10-10.json'))
for r in d['records']:
 suffix='essential' if 'essential' in r['id'] else 'premium';c=byid[f'byd_atto_1__{suffix}_fwd__20261010']
 f=fact(c,'power_kw',r['powertrain']['maximumPowerKW'],['r10_atto1_atto1_product','r10_atto1_atto1_brochure'],'2026-10-10','Manufacturer maximum motor power','kW')
 add(c,'power_kw',f,'Exact published Australian grade maximum power is retained in the ATTO 1 packet.',f'data/atto1-evidence-2026-10-10.json records[id={r["id"]}].powertrain.maximumPowerKW','retained-packet')
# MG4 packet has explicit single-motor maximum ratings that were also omitted.
d=json.load(open(ROOT/'data/mg4-evidence-2026-10-10.json'))
mgmap={'mg4-my26-essence-64-rwd':'mg4_ev_my26__essence_64_rwd__20261010','mg4-urban-my26-essence-43-fwd':'mg4_ev_urban_my26__essence_43_fwd__20261010','mg4-urban-my26-essence-54-fwd':'mg4_ev_urban_my26__essence_54_fwd__20261010'}
for r in d['records']:
 if r['id'] not in mgmap:continue
 c=byid[mgmap[r['id']]];sids=['r10_mg_'+s.replace('-','_') for s in r['powertrain']['sourceIds']]
 f=fact(c,'power_kw',r['powertrain']['maximumPowerKW'],sids,'2026-10-10','Manufacturer maximum motor power','kW')
 add(c,'power_kw',f,'Exact published Australian grade maximum power retained in the MG4 packet.',f'data/mg4-evidence-2026-10-10.json records[id={r["id"]}].powertrain.maximumPowerKW','retained-packet')
# Brand-wide private-use baseline terms; no conditional extended cover inheritance.
warranty_policies=[
 {'brand':'BYD','vehicle':'6 years / 150,000 km','battery':'8 years / 160,000 km; minimum 70% battery retention','sourceIds':['r4_byd_warranty'],'date':'2026-10-06','location':'data/research-refinement-2026-10-06.json sources[id=r4_byd_warranty], booklet pages 7–8','condition':'Whichever limit is reached first; exclusions and component-specific terms apply.'},
 {'brand':'Volkswagen','vehicle':'5 years / unlimited km for private use','battery':'8 years / 160,000 km; battery capacity trigger below 70%','sourceIds':['r10_vag_vw_warranty_terms'],'date':'2026-10-10','location':'data/vw-skoda-cupra-evidence-2026-10-10.json shared_warranty.vw','condition':'Taxi/rideshare/hire vehicle cover is 5 years / 150,000 km. Battery cover uses whichever limit is reached first; capacity restoration levels and full terms apply.'},
 {'brand':'Hyundai','vehicle':'5 years / unlimited km for private use','battery':'8 years / 160,000 km, whichever comes first','sourceIds':['r10_hy_hyundai_warranty_terms'],'date':'2026-10-10','location':'data/remaining-hyundai-evidence.json manufacturer warranty evidence and data/hyundai-evidence-2026-10-10.json shared_warranty','condition':'Private-use baseline warranty. Up to seven years requires eligible registration and authorised servicing; commercial-use limits differ.'},
 {'brand':'Mazda','vehicle':'5 years / unlimited kilometres','sourceIds':['r10_mazda_6e_warranty_summary','r10_mazda_6e_warranty_terms'],'date':'2026-10-10','location':'data/catalogue-additions-2026-10-10.json Mazda source_catalogue_vehicle_warranty and manufacturer-wide warranty source records','condition':'Commencement, proper use, maintenance and full manufacturer warranty terms apply.'},
]
for p in warranty_policies:
 for c in cs:
  if c['brand']!=p['brand']:continue
  for key,pkey in [('warranty','vehicle'),('battery_warranty','battery')]:
   if pkey not in p:continue
   f=fact(c,key,p[pkey],p['sourceIds'],p['date'],'Australian manufacturer brand-wide private-use warranty terms',quals=[p['condition']])
   add(c,key,f,'The maker\'s Australian brand-wide baseline warranty applies to this passenger version; no delivered-build identity or extended warranty inferred.',p['location'],'brand-warranty')
# GWM private-use warranty already has an exact linked term record per grade; retain commercial wording conflict in detail.
for c in cs:
 if c['brand']!='GWM' or not c['facts'].get('source_ora5_warranty',{}).get('value'):continue
 sf=c['facts']['source_ora5_warranty']
 for key,value in [('warranty','7 years / unlimited km for private use'),('battery_warranty','8 years / unlimited km for private use')]:
  f=fact(c,key,value,sf['sourceIds'],sf['date'],'Australian manufacturer private-use warranty terms',quals=['First sold new through an authorised Australian dealer. Commercial/paying-passenger use has different limits and wording between webpage and linked terms; full terms and commencement apply.','Battery state of health at or above 70% is excluded as a defect; no automatic replacement promise below 70% is inferred.'])
  add(c,key,f,'Private-use warranty term is explicitly recorded for this exact grade; differing commercial-use conditions remain disclosed.',f"effective catalogue {c['id']}.facts.source_ora5_warranty",'same-version-alias',support='source_ora5_warranty')
registry={'schemaVersion':1,'reviewedOn':'2026-10-13','scope':'Tier 1 existing evidence admissions only; immutable original observations retained. No new source retrieval or model-year inference.','rows':rows}
json.dump(registry,open(ROOT/'data/m1-retained-fact-fills-2026-10-13.json','w'),indent=2,ensure_ascii=False);print('fills',len(rows),'variants',len(set(r['variantId'] for r in rows)));print(collections.Counter(r['key'] for r in rows));print(collections.Counter(r['kind'] for r in rows))
