import json,pathlib
r=pathlib.Path('/tmp/mg-im-research')
base=json.load(open(r/'before.json'))
rows={}
for c in base:
 i=c['id'];m=c['model'];t=c['trim'];v={}
 if m=='MG4 EV':
  n=0 if 'Essence' in t else 1
  v=dict(range_km=[452,405][n],battery_kwh=64,dc_peak_kw=[154,140][n],dc_charge_time_min=[25,30][n],ac_kw=6.6,boot_l=350,zero_to_100_s=[7.5,3.8][n],length_mm=4287,width_mm=1836,height_mm=1516,towing_braked_kg=500)
  if n==0:v['power_kw']=140
 elif m=='MG4 EV Urban':
  n=0 if '43' in t else 1
  v=dict(range_km=[316,405][n],battery_kwh=[43,54][n],dc_peak_kw=[82,87][n],dc_charge_time_min=[28,30][n],ac_kw=6.6,boot_l=382,zero_to_100_s=[9,8.7][n],power_kw=[110,118][n],length_mm=4395,width_mm=1842,height_mm=1549)
 elif m=='MGS5 EV':
  n=0 if '49' in t else 1
  v=dict(range_km=[335,450][n],battery_kwh=[49,62][n],dc_peak_kw=[120,150][n],ac_kw=6.6,boot_l=453,zero_to_100_s=[8.2,7][n],power_kw=[125,150][n],length_mm=4476,width_mm=1849,height_mm=1621)
 elif m=='MGS6 EV':
  n=0 if 'RWD' in t else 1
  v=dict(range_km=[530,485][n],battery_kwh=77,dc_peak_kw=144,dc_charge_time_min=38,ac_kw=11,boot_l=581,power_kw=[180,266][n],length_mm=4708,width_mm=1912,height_mm=1664,towing_braked_kg=1500)
  if n==1:v['zero_to_100_s']=5.1
 elif m=='Cyberster':
  n=0 if 'RWD' in t else 1
  v=dict(range_km=[507,443][n],battery_kwh=77,dc_peak_kw=144,ac_kw=11,boot_l=249,power_kw=[250,375][n],zero_to_100_s=[5.2,3.2][n],length_mm=4535,width_mm=1913,height_mm=1329)
 elif m in ['IM5','IM6']:
  n=['Premium RWD','Platinum RWD','Performance AWD'].index(t)
  v=dict(range_km=([490,655,575] if m=='IM5' else [450,555,505])[n],battery_kwh=[75,100,100][n],dc_peak_kw=[153,396,396][n],ac_kw=11,seats=5,boot_l=(457 if m=='IM5' else [665,665,646][n]),zero_to_100_s=([6.8,4.9,3.2] if m=='IM5' else [6.8,5.4,3.4])[n],length_mm=(4931 if m=='IM5' else 4904),width_mm=(1960 if m=='IM5' else 1988),height_mm=(1474 if m=='IM5' else 1669),towing_braked_kg=1500)
  if n<2:v['power_kw']=[217,300][n]
 rows[i]=v
out=pathlib.Path(__file__).parent/'mg-im-independent-numeric-matrix.json'
out.write_text(json.dumps(rows,indent=2)+'\n')
print(len(rows),'exact original configurations checked from maker technical tables; conflicts, price, secondary or missing SOC windows omitted for separate source review')
