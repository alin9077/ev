# Kia M1 independent QA — approved

14 October 2026. Approved for root registration of the exact packet and reconciliation below. This review did not edit the registry, original data, implementation or research packet.

## Scope and result

- Effective baseline: BYD, Tesla, Geely, Zeekr and Jaecoo already registered; 23 existing Kia Tier 1 versions plus protected Tier 2 PV5 Cargo
- Final scope: 27 Tier 1 versions, including four additions: Niro GT-Line MY24/MY25 and EV6 Air/GT-Line RWD MY26 residual New advertisements. Current factory/configurator scope is 20 versions; seven outgoing versions have separately evidenced New advertising
- All 459 core cells have earned, current reviews; 458 have values. The single core gap is exact EV3 AWD vehicle DC peak, after two current maker-source searches. No test-station output was substituted
- 1,392 specific fact edits, three shared policy records, 357 guarded equipment replacements and 622 full fact dependencies passed static review against independently captured before states and numeric matrices
- Actual data.ts pack replay with an in-memory registry override passed for all 27 versions. All 1,461 effective reviewed fact claims, 357 feature claims, 26 canonical/supplemental price projections, deadline boundaries and exact portable round trips agree with the packet
- Negative tests reject source, identity, availability, fact, brand-term, feature-before and summary/feature-dependency drift. Inputs, all other brands and PV5 remain unchanged
- 111 source snapshots exactly match the source index. All 111 raw captures and 106 extracted-text hashes pass. All 13 evidence-manifest artifacts pass. The 78 pre-existing data JSON/CSV files were byte-identical before registration

## Important evidence decisions

- Current exact maker sheets/configurators support EV3 AWD and MY27 EV4 availability; provisional labels are removed. EV3 AWD towing is 1,500 kg. Its live maker RRP is A$63,950; the earlier secondary A$66,490 remains a historical discrepancy, with no driveaway arithmetic reconstruction
- EV4 remains a sedan. EV5 has four mechanical grades; Two-Tone is a paid paint choice. Niro's maker withdrawal and the two real dealer New residuals are reconciled separately. Eight inherited EV6 rejected/unverified leads retain their actual sold/demo/conflicting/HTTP 500 dispositions; the unavailable Air page is not falsely declared sold
- Price priority is preserved: current factory RRP; applicable MY26 EV4 national driveaway offers; exact-year Reported MY26 EV6 list prices ahead of separate unit-specific dealer driveaway; Niro exact dealer prices where the orphan maker price excludes their build years. Fees, state scope, colours, eligibility and 31 October deadlines remain source-bound
- EV9's future inspection footer is retained as a dating anomaly, not invented as a publication/on-sale date. The current exact GT configurator independently establishes listing. GT seats six; 333 L with all three rows in use is Reported from the exact Australian CarExpert GT review, with measurement method unspecified and no ranking. The separate 2,393 L VDA figure is two-seats-up cargo
- Maker charging times retain their exact published SOC window and station supply at Confirmed grade. Generic laboratory/use caveats do not automatically downgrade them. Real Launch Control/offer conditions remain Check. Secondary DC peaks, MY25 Niro and MY26 EV6 sibling/secondary specifications remain Reported
- MY26 EV6 Air's exact dealer width is 1,880 mm. CarsGuide mixes stale technical cells into its current price entry; those cells were rejected. Its 490 L rear minimum is explicitly MY27 Air sibling evidence, without an invented occupied-seat basis
- Current private vehicle warranty, battery 70% floor and MY/EV4 split, commercial/component exceptions, and service-renewed roadside limits were independently read and preserved
- Thirty-six stale AWD equipment clauses were replaced. Ten wholly missing answers have actual two-source searches and same-criterion null dependencies. Generic/older manual operation does not become exact MY27 fitment proof
- No existing version changes model year. EV5's generation description is clarified at its unchanged 2026 year; retained same-year noncore facts do not create a fictional model-year freshness failure

## Shared implementation review

Independently inspected the offer-deadline propagation, canonical whole-row Not published boundary and source-warning baseline repair. Historical id/model_id/record_state context survives current metadata updates, clone/JSON transport and chained prepares; exact captured guards remain intact. Live supporting-source tampering is rejected; immutable source packs separately retain URL sanitization coverage. Focused shared-code gates passed; no full suite/build was run for this review.

## Completion limits

Research completion is true, with zero missing models, unresolved inventory leads, missing summaries or aged/invalid claims. C2/C3/C4/C6 pass. C1 remains false because two brand lists do not establish whole-market closure. C5 remains false: range, charge time, seats and towing each 24/27 (88.9%); price 23/27 (85.2%); boot 19/27 (70.4%). Secondary/sibling evidence and unspecified cargo bases were not promoted to force targets.

DC peak has 26 Reported and one Not published because primary sheets generally publish station power, not vehicle acceptance. Prices have 20 Confirmed, three Check and four Reported.

## Exact approved artifacts

- Packet: 7fa42384d26808dda94732b51fbdb8f6e1c666c6ab50ceff3129a8cedf23797e
- Reconciliation: 0be0fa552c246999f2fa9a213ae3c30cdf7abc776bbb94972acf165cad42d24e
- Source index: d2fddea178e7e171ad731f39d211d0725f08abe5bb8b73b935b07242490a501c
- Evidence manifest: a0454f413665a8cbed87e9807891b80c6dc3d1f277eb3bebcda58f72fb76121b

Replay log: kia-importer-final-stage.log. Static review: kia-packet-final-review.log. Independent report: kia-independent-stage-report.json. Machine-readable audit: kia-final-audit-results.json. Capture hashes: kia-final-capture-hash-check.json. Before-registration immutability: kia-final-immutable-check.json.
