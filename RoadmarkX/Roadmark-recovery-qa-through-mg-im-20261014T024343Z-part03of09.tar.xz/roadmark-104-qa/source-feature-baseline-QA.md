# Historical source-feature baseline repair

## Result

The source pipeline retains the historical warning context required by exact feature `before` guards while exposing the latest reviewed identity and availability in the public catalogue and Research. The original research snapshot and dated packets/registry were not edited.

## Scope

- `Research` gains an optional three-field context per variant: ID, model ID and original record state. Original `sourceResearch()` does not contain it.
- `prepareBrandResearch` captures that context before any packet metadata/availability changes, copies it across chained prepares, and captures new variants at admission before their same-packet updates.
- Historical feature warnings use that context. Feature rows and sources remain freshly read, and all full before/source/version/dependency guards remain unchanged.
- Current availability evidence, record state, trim and generation still propagate to both prepared Research and the catalogue.

## Verification

- PASS: 44 focused behavioural tests across `brand-feature-updates`, `brand-updates`, `brand-added-detail`, and `home-payload`.
- PASS: TypeScript `tsc --noEmit` and full ESLint over `src tests scripts`.
- PASS: The supplied Kia EV3 AWD repro preserves `v2_kia_ev3_awd_report` in all three captured feature baselines: `interior_fit_finish_subjective`, `style_refinement`, and `alert_sound_quality`.
- PASS: Independent reviewer reported actual `data.ts` pack replay of the frozen 25-version Kia candidate: 332 feature edits, 1,382 fact claims, portable round trip and negative guards all match/pass.
- Regression coverage includes exact current feature replay, original default source snapshots, existing registered packet features, newly admitted variants with same-packet availability and feature changes, JSON/structured cloning, repeated preparation, chained preparation, source-row mutation and guard rejection.

The broader focused run initially found an existing `home-payload` test that changed a source used by a reviewed Tesla feature and expected sanitization to bypass the exact guard. The failure was reproduced using the saved pre-fix `data.ts` and `brand-updates.ts` without modifying the working tree. At the parent’s request, the test now separately verifies that current guarded packs reject changed source evidence and that immutable source packs sanitize unsafe URLs without mutating input. Both pass.

The pnpm launcher attempted an environment-level automatic dependency install and failed creating `/home/agent/.local/share/pnpm`. Checks therefore invoked the already installed repository binaries directly; no dependency or package changes were made.

## Commands

```
node --import tsx --test --test-concurrency=2 tests/brand-feature-updates.test.ts tests/brand-updates.test.ts tests/brand-added-detail.test.ts tests/home-payload.test.ts
node node_modules/typescript/bin/tsc --noEmit
node node_modules/eslint/bin/eslint.js src tests scripts
node --import tsx /tmp/kia-research/check-feature-before.ts
node --import tsx ../roadmark-104-qa/check-pre-fix-home-payload.ts
```

## Files beside this report

- `source-feature-baseline.patch`: complete five-file patch
- `source-feature-baseline-hashes.txt`: final source/test hashes
- `source-feature-baseline-tests.log`: final 44/44 test output
- `source-feature-baseline-typecheck.log` and `source-feature-baseline-lint.log`: successful checks (empty logs)
- `source-feature-baseline-kia-repro.log`: three historical/current row comparisons
- `source-feature-baseline-preexisting-home-payload.log`: pre-fix failure confirmation
- `check-pre-fix-home-payload.ts` and `source-feature-baseline-original/`: reproducible pre-fix evidence

This is a focused fix, not a new full-suite/build/publication claim. The packet/registry integration and final milestone-wide checks remain with the parent task.
