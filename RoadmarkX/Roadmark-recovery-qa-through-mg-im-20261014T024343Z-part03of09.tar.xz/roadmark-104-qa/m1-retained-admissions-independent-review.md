# Independent M1 retained-admission review

Reviewed 13 October 2026 against `docs/DOT-BRIEF-103.md`, immutable evidence packets, the dated price/fill overlays and their application helpers. This was read-only product review; fixes were made by the parent/assigned implementation workers. No fresh external brand research or full catalogue/test-suite load was performed.

## Findings

1. **P1 — EV3 AWD power falsely attributed to a FWD-only maker source.** Retained-fill row 123 originally made 195 kW Confirmed for `kia_ev3__gt_line_awd_long_range__5` using `kia_ev3_spec`. The immutable variant explicitly says that AU brochure covers four FWD trims only. `v2_kia_ev3_awd_report` supports the provisional AWD figure. Parent corrected to WhichCar, `resolvedElsewhere`, and a Reported-oriented basis. The updated fill was independently observed through the helper.

2. **P1 — correction guards omitted material evidence state.** Original retained snapshots excluded units, market and other metadata, and source verification only matched URLs. An actual MINI row accepted a changed supporting unit of Wh as 54.2 kWh; changing the source to UK plus a publication hold still admitted a standard fact. Parent replaced these with full fact/source snapshots. Independently verified that unit and source-market mutations are now rejected and all 184 reviewed rows still apply against the existing audited catalogue JSON.

3. **P1 — EV9 GT source-date conflict was dropped.** Row 134 originally Confirmed 374 kW for `kia_ev9_my26__gt_awd__20261010`. Its immutable `specifications.power_kw` is explicitly `conditional_brochure_source_date_conflict` and unranked. The source has a future February 2027 footer and no distinct corroboration for the GT-only number. Parent added the missing qualification and conditional state; grading worker reports its date-conflict Check/unranked handling fixed. Full regenerated grading was left to that worker.

4. **P2 — outgoing Geely versions cited the newer ER brochure.** Rows 106–107 used `geely_brochure_er` for the original Complete/Inspire variants although those variants cite `geely_brochure_old`. Parent corrected source and observation date; independently observed 160 kW retained with the old brochure dated 5 October. No number changed.

5. **P2 — premium price provenance inherited an unrelated null-cell basis.** Premium candidates often have no corresponding car fact for their `sourceKey`; missing `originalBasis` fell back to the old null `price_aud` template, yielding “List price before on-road costs” for Volvo configurator quotes whose on-road treatment is unresolved, and for dealer/WA driveaway prices. Display comparison basis was correctly empty or driveaway, so this was exported provenance contamination. Reported to parent; price worker reports explicit bases added to all 23 premium candidates.

## Other checks

- Inspected all 184 fill admissions by category and compared the retained structured power extractions with their immutable packet values and conditions
- No motor-front/rear addition was found: bZ4X stays at published 252 kW, not the 255 kW sum of individual maxima; HiLux keeps published system output
- Nine smart charging-time aliases keep their actual 10–80% window and 150/400 kW station conditions; no station rating is inserted as vehicle acceptance
- Gross, usable and unstated battery bases remain distinct; Porsche conditional peak power and equipment-dependent towing retain their conditions
- Reviewed shared warranty inheritance and private/commercial scope for BYD, Volkswagen, Hyundai, Mazda and GWM; no additional unsupported entitlement was identified
- Reviewed highest-rung selection, named-version/state mapping, unknown tax/on-road treatment and offer date fields. No additional false amount or tax conversion was identified
- Applied all 184 retained fills and the price helper to pre-existing audited JSON using only the small helpers, avoiding a full catalogue initialization

This is a targeted evidence review, not a market-completeness declaration or full UI/end-to-end test pass. The parent owns final aggregate tests and regenerated grade/coverage artifacts.
