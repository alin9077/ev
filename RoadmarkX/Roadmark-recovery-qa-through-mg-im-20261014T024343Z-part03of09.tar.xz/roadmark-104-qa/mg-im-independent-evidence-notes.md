# MG/IM independent evidence review (in progress)

Checked 14 October 2026 against the live official Australian site and fresh worker captures. This note is not packet approval.

## Fixed review baseline

Six registered brand packets through Kia; 10 MG and six IM effective existing versions. Separate catalogue brand identities must retain separately scoped packets and shared terms. Hashes of all pre-existing `src`, `data`, `qa` and `docs` files were captured before this work. No application, immutable-source or registry edit is authorized for this review.

## Independently read sources and traps

- MG4 MY26 brochure: https://mgmotor.com.au/brochures/MG4_EV_2026_V2.pdf. Essence64 and XPOWER technical table is not the outgoing Essence150kW epoch. Vehicle DC acceptance154/140kW; 10–80%25/30min. 350L seats-in-place cargo has no standardized VDA/SAE method. XPOWER component ratings150+170 need explicit combined evidence for a combined number.
- MG4 Urban MY26 brochure: https://mgmotor.com.au/brochures/MG4_EV_URBAN_2026.pdf. FWD E3 body is separate from MG4. 43/54kWh, DC82/87kW, 10–80%28/30min, boot382L and separate98L underfloor; marketing480L includes that underfloor. Do not silently rank480L on the382L basis.
- MGS5 current product and linked brochure: https://mgmotor.com.au/vehicles/mgs5-ev and https://mgmotor.com.au/brochures/MGS5_EV_2026.pdf. Product says MY26, brochure footer says MY25/June2026. Dated 8 July 2026 CarExpert reporting quotes MG Australia about the precise two-Essence MY26 refresh; current maker page plus corroborated refresh supports reviewed MY26 metadata with the brochure-footer conflict retained. Existing known specifics must be freshly reviewed rather than carried silently. Refreshed62kWh is150kW/350Nm/450km, distinct from prior125kW. Published19/19.3min is30–80%; it is not10–80% evidence.
- MGS6 current linked brochure: https://mgmotor.com.au/vehicles/mgs6-ev. Both copies captured are MY26, but current footer isJune2026 versus olderMay2026. Brochure says RWD7.5s and86L frunk; webpage/configurator conflict7.3s/124L must be adjudicated or kept explicitly conditional. Vehicle DC144kW;10–80%38min.
- Cyberster: https://mgmotor.com.au/vehicles/cyberster and https://mgmotor.com.au/brochures/MG_CYBERSTER_2026_v2.pdf. Current webpage/brochure formal-year conflict remains. Brochure explicitly gives AWD combined375kW despite motors150+250kW, proving motor maxima cannot simply be summed. Published 34min is 30–80%, at a 150kW station, while vehicle DC acceptance is 144kW. Page 6 is an AWD performance discussion and explicitly states 40min 10–80%; this earns direct AWD confirmation and may be openly carried to the RWD sibling as Reported.
- IM5/IM6: https://mgmotor.com.au/vehicles/im5 and https://mgmotor.com.au/vehicles/im6 with current linked MY25 brochures. 2026 unit-heading/build date does not prove MY26. Performance only prints front/rear200/372kW; no unearned572kW combined calculation. Primary DC153/396kW acceptance is explicit. Published20/15.2min window is30–80%. IM6 Performance rear boot646L differs from665L other grades. IM5 marketing755km is NEDC, while current Platinum WLTP is655km.
- MG warranty: https://mgmotor.com.au/explore/warranty. Standard private passenger7y/unlimited; service-activated extension10y/250,000km; battery7y/150,000km70% floor. Do not apply old10y policy to newly retailed cars or extend battery to10y. Convertible roof and limited items retain shorter cover.
- IM warranty: https://mgmotor.com.au/explore/im-mgu9-warranty. Relevant IM section is below separate MGU9 terms and stale pre-2024 general text. Standard5y/unlimited; service-activated7y/unlimited; battery8y/160,000km70% floor. Worker identified linkedJune2025 PDF disagreement for effective-date and air/four-wheel-steer coverage; retain it explicitly rather than silently choosing terms.
- Roadside: https://mgmotor.com.au/about/roadside-assist. Published period follows vehicle warranty, towing limits100km regional/20km metro; specific conditions and charges are not unlimited recovery entitlement.
- MGU9 EV: https://mgmotor.com.au/vehicles/mgu9-ev and configurator still visibly say Coming Soon / Register Interest. Hidden generic pre-order forms and price78,990 cannot independently prove orderability.

## Review artifacts prepared

Independent numeric matrix covers16 original configurations. It intentionally omits disputed figures, unknown SOC windows, prices and later residual additions until exact-source review. Static checker covers full before/identity/source/dependency guards and exact whole-row Notpublished shape. Importer checker will exercise actual `data.ts` pack replay with in-memory registry override, citable claims, deadline boundaries, portable exact roundtrip and unchanged other brands once CPU coordination permits.


## Independent preliminary checks

- Runtime before capture completed with all six prior packets live. Research worker's 16 before cars and 1,104 equipment rows exactly match the independently evaluated catalogue and effective feature view.
- Preliminary IM static candidate passes full identity/fact/feature/availability guards, numeric matrix, and exact dependencies: 329 specific facts, three shared policy records, 138 equipment replacements with 162 dependencies. 119 raw captures and 118 extracted text hashes match the source index. These are preliminary observations, not approved artifact hashes.
- All known pre-existing MGS and IM feature rows are covered by proposed replacements or canonical driveaway/roadside projections.
- Independent archive search recovered the full inherited MG residual packet (11 stock candidates plus five unresolved leads), including the formerly unlocated G10095 URL. Research worker is rechecking all recovered leads before completion.
- Candidate corrections requested: remove unsupported Cyberster seats-in-use cargo basis; support AWD component-power figures with exact component facts; support MGS6 50 W cooled charger detail in its full dependency; normalize concatenated buyer-facing prose.
