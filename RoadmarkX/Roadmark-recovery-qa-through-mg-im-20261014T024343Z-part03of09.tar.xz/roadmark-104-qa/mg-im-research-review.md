# MG and IM Australian M1 research review

Checked 14 October 2026. Research is staged for independent approval; nothing is registered and no implementation or original research fixture was changed.

## Result

- 23 exact Tier 1 versions: 17 MG and 6 IM. Seven separately guarded residual identities are added: MG4 MY23 Excite 64 and MY25 Excite 51; MGS5 MY25 Excite 49, Excite 62, Essence 49 and original 125 kW Essence 62; and independently identified MY26 Excite 49.
- The two packets contain 1,180 specific facts, six shared brand-term definitions, 554 full before-guarded equipment replacements and 23 dependency-bound strength/tradeoff pairs.
- Every inherited non-null MG/IM fact is refreshed. New identities receive bounded defaults. Both changed current MGS5 model years have refreshed equipment; the residual MY26 Excite 49 does not inherit MY25 Confirmed equipment.
- All current and inherited leads have finite dispositions. Dealer New, registered New, Demo, sold, replaced, withdrawn and unavailable pages remain distinct. Advertisements do not verify physical stock or accepted factory orders.

## Material buyer findings

- Current MGS5 is the two-Essence MY26 range; Essence 62 is the refreshed 150 kW / 450 km configuration. The brochure's older MY25 footer is explicitly retained as a source conflict. The old 125 kW configuration remains separate.
- Exact residual MG4 MY25 Excite 51 has a current CarExpert guide of $36,990 before on-roads. It is Reported and unranked, not a dealer quote. Ambiguous MY23 guide revisions and expired offers are rejected rather than substituted for the exact MY23 dealer advertisement.
- National October offers take precedence over lower-rung prices. Eligible-buyer, participating-dealer, cashback and sale/delivery conditions remain Check, with 31 October expiry in canonical facts and projections. Cyberster selector prices retain an unresolved on-road basis and are unranked.
- MG standard private cover is 7 years/unlimited km, with a conditional service-activated extension up to 10 years/250,000 km. IM standard private cover is 5 years/unlimited km, with a conditional extension to 7 years/unlimited km. Battery cover is respectively 7 years/150,000 km and 8 years/160,000 km, with 70% capacity wording. Registration-date, use and component exceptions remain explicit. IM web/PDF limited-component disagreements are preserved.
- Canonical charging time means exactly 10–80%. All seven MGS5 configurations and both 75 kWh IM versions have genuinely searched Not published gaps. IM 100 kWh and Cyberster RWD sibling evidence remain Reported. Maker 30–80% figures are separate; station ratings are not vehicle charging peaks.
- MGS6 acceleration and frunk conflicts remain Check. IM5 755 km is NEDC rather than WLTP. IM AWD combined output is sourced secondary evidence, not an arithmetic sum of motor components. Cargo methods, seating state and separate front/underfloor storage are preserved.
- ZS EV residual leads do not establish an authentic current exact New unit after bounded checks. MGU9 EV remains Coming Soon/Register Interest. Neither is promoted into the current list.

## Validation and honest limits

The combined stage passes exact identity, source, fact, availability, shared-term, feature and dependency guards, citable/portable roundtrips and immutable input/other-brand checks. Independent actual `data.ts` replay also passes both brands, including negative drift guards. Baselines were captured before any packet was applied.

Both brands report research complete, with zero missing models, unresolved research leads, missing summaries or aged/invalid claims. This is distinct from global strict closure: C1, C2 and C5 remain false; C3, C4 and C6 pass. The independent directories are complete MG/IM brand lists, not whole-market snapshots. MG has 10/17 populated exact-window charging fields and IM has 4/6; Reported and method-mismatched facts remain unranked. No grade quota or manufactured closure pass is claimed.

## Deliverables

- `mg-2026-10-14.json` and `im-2026-10-14.json`: separate, strict guarded packets
- `mg-reconciliation-2026-10-14.json`, `im-reconciliation-2026-10-14.json` and `brand-model-list-reconciliation.json`: dated catalogue and directory closure
- `source-index.json`, `source-hash-manifest.json` and `artifact-hash-manifest.json`: portable capture locators and exact hashes
- `mg4/inherited-inventory-audit.json`, `mg4/price-ladder-review.json`, `mgs/audit.json`, `residuals/residual-closure.json`, `residuals/archive-closure.json` and `im/review-summary.md`: complete family and inherited-lead dispositions
- Source folders preserve full permitted captures and extraction sidecars, including failed/blocked responses and their limitations. Publication dates are not inferred from future footers, filenames or retrieval timestamps.
