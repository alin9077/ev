import fs from 'node:fs';
import assert from 'node:assert/strict';
import {catalogue,research,pack,effectiveFeatures} from '../roadmark-104/src/lib/data.ts';
import {applyBrandUpdates,prepareBrandResearch,applyBrandFeatureUpdates,applyBrandTermFeatures,type BrandUpdatePacket} from '../roadmark-104/src/lib/brand-updates.ts';
import {factClaim,featureClaim} from '../roadmark-104/src/lib/citable.ts';
import {loadReportInput} from '../roadmark-104/scripts/reporting/load.ts';
import {buildCoverageReport} from '../roadmark-104/scripts/reporting/reports.ts';
import {combineM1Reconciliations} from '../roadmark-104/scripts/reporting/m1-reconciliation.ts';
import {storePortablePacks,hydratePortablePacks} from '../roadmark-104/src/lib/portable-packs.ts';
const path=process.argv[2] || '/tmp/omoda-jaecoo-research/jaecoo-2026-10-14.json';
const p=JSON.parse(fs.readFileSync(path,'utf8')) as BrandUpdatePacket;
const old=research(), before=catalogue();
assert(!old.sources.some(s=>p.sources.some(n=>n.id===s.id&&n.id.startsWith('m1-jaecoo-'))),'Packet may already be registered; use clean pre-packet branch');
const prepared=prepareBrandResearch(old,[p]);
const after=applyBrandUpdates(before,prepared,[p]);
const built: Record<string,ReturnType<typeof pack>>={};
const newFeatureBaselines: unknown[]=[];
let claims=0,features=0;
for(const car of after.filter(c=>c.brand==='Jaecoo')) {
 const original=before.find(c=>c.id===car.id);
 const starting=effectiveFeatures(original||car,original?old:prepared);
 if(!original)newFeatureBaselines.push(...starting);
 const final=applyBrandTermFeatures(car,applyBrandFeatureUpdates(car,starting,prepared,[p]));
 const facts=car.facts;
 assert.equal(facts.price_aud.value,35990);
 assert.equal(facts.price_aud.priceEvidence?.rung,1);
 assert.equal(facts.price_aud.comparisonBasis,'Before on-road costs');
 assert.equal(facts.promotional_driveaway_aud.value,36990);
 assert.equal(facts.promotional_driveaway_aud.priceEvidence?.rung,2);
 assert.equal(facts.promotional_driveaway_aud.validUntil,'2026-10-31');
 assert.equal(facts.dc_charge_time_min.value,null);
 assert.equal(facts.dc_charge_time_min.buyerGrade,'not_published');
 assert.equal(facts.dc_charge_time_min.comparisonBasis,'10–80%');
 assert.equal(facts.dc_charge_30_80_min.value,28);
 assert.equal(facts.dc_charge_30_80_min.comparisonBasis,'30–80%');
 assert.equal(facts.max_total_cargo_l.value,1180);
 assert.equal(facts.max_total_cargo_l.buyerGrade,'reported');
 for(const criterion of ['home_charging','energy_use']) {
   const f=final.find(f=>f.criterion===criterion)!;
   assert(!/9 hours|5\.5 hours|A\$665|14\.8/.test(`${f.value} ${f.conditions}`),'Unsupported retained charging/cost estimate survived');
 }
 if(process.env.REQUIRE_SUPPLEMENTAL_PRICE==='1') {
   const f=final.find(f=>f.criterion==='driveaway_price')!, offer=facts.promotional_driveaway_aud;
   assert.equal(f.value,'A$36,990');
   assert.deepEqual(f.source_ids,offer.sourceIds);
   assert.deepEqual(f.gradeReview,offer.gradeReview);
   assert.equal(f.buyerGrade,offer.buyerGrade);
   assert(f.conditions.includes('2026-10-31'));
   assert(f.conditions.includes(offer.conditionExplanation!));
 }
 const base=pack(car.id,{data:prepared,cars:after});
 const ids=new Set([...base.sources.map(s=>s.id),...final.flatMap(f=>f.source_ids)]);
 const view={...base,features:final,sources:prepared.sources.filter(s=>ids.has(s.id))};built[car.id]=view;
 for (const row of p.features?.filter(f=>f.variantId===car.id)??[]) {
   const f=final.find(f=>f.criterion===row.criterion)!;assert.deepEqual(f,row.after);
   const claim=featureClaim(view,f.criterion,f.criterion)!;assert.equal(claim.value,String(f.value));
   assert.deepEqual(claim.gradeReview,f.gradeReview);assert.deepEqual(claim.sources.map(s=>s.id),f.source_ids);features++;
 }
 for(const f of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===p.id)) {
  const claim=factClaim(view,f);assert.equal(claim.buyerGrade,f.buyerGrade);
  assert.deepEqual(claim.gradeReview,f.gradeReview);assert.deepEqual(claim.sources.map(s=>s.id),f.sourceIds);claims++;
 }
}
const hyd=hydratePortablePacks(storePortablePacks(built),prepared.sources);
assert.deepEqual(hyd,built);
assert.deepEqual(old.sources, research().sources);assert.deepEqual(before,catalogue());
assert.deepEqual(after.filter(c=>c.brand!=='Jaecoo'),before.filter(c=>c.brand!=='Jaecoo'));
assert.equal(after.length,before.length);
const broken=structuredClone(p);broken.facts[0].before!.value='changed';
assert.throws(()=>applyBrandUpdates(before,prepared,[broken]),/before snapshot changed/);
const brokenSource=structuredClone(p);const retained=brokenSource.sources.find(s=>old.sources.some(o=>o.id===s.id));
if(retained){retained.title+=' changed';assert.throws(()=>prepareBrandResearch(old,[brokenSource]),/source snapshot changed/)}
else { const changed=structuredClone(old.sources[0]);changed.title+=' changed';brokenSource.sources.push(changed);assert.throws(()=>prepareBrandResearch(old,[brokenSource]),/source snapshot changed/); }
const brokenIdentity=structuredClone(p);brokenIdentity.versionGuards[0].before.trim+=' changed';
assert.throws(()=>applyBrandUpdates(before,prepared,[brokenIdentity]),/identity|version|snapshot/i);
const brokenAvailability=structuredClone(p);brokenAvailability.availability[0].before.availability='changed';
assert.throws(()=>applyBrandUpdates(before,prepared,[brokenAvailability]),/snapshot|availability/i);
const brokenTerm=structuredClone(p);const term=brokenTerm.brandTerms![0];term.before[term.applicableVariantIds[0]]!.value='changed';
assert.throws(()=>applyBrandUpdates(before,prepared,[brokenTerm]),/before snapshot changed/);
const brokenSummary=structuredClone(p);brokenSummary.summaries[0].strength.dependencies[0].expected.value='changed';
assert.throws(()=>applyBrandUpdates(before,prepared,[brokenSummary]),/dependency changed/);
const brokenFeature=structuredClone(p);
if(brokenFeature.features?.length){
 const row=brokenFeature.features[0];row.before.conditions+=' changed';
 const c=after.find(c=>c.id===row.variantId)!,b=before.find(c=>c.id===row.variantId)!;
 assert.throws(()=>applyBrandFeatureUpdates(c,effectiveFeatures(b,old),prepared,[brokenFeature]),/before snapshot changed/);
 const dep=structuredClone(p);dep.features![0].dependencies[0].expected.value='changed';
 assert.throws(()=>applyBrandUpdates(before,prepared,[dep]),/dependency changed/);
}
fs.writeFileSync('/workspace/scratch/586427eef9f2/roadmark-104-qa/jaecoo-audit-new-feature-baselines.json',JSON.stringify(newFeatureBaselines,null,2));
fs.writeFileSync('/workspace/scratch/586427eef9f2/roadmark-104-qa/jaecoo-reviewed-stage-packs.json',JSON.stringify(built,null,2));
console.log(JSON.stringify({versions:Object.keys(built).length,citableFacts:claims,reviewedFeatures:features,portableExactRoundtrip:true,immutableInputObjects:true,negativeFactSourceIdentityAvailabilityTermFeatureSummaryGuards:true}));

const reconciliation=JSON.parse(fs.readFileSync('/tmp/omoda-jaecoo-research/jaecoo-reconciliation-2026-10-14.json','utf8'));
const reportInput=loadReportInput();
reportInput.cars=after;reportInput.sources=prepared.sources;
reportInput.features=reportInput.features.filter(f=>!built[f.variant_id]).concat(Object.values(built).flatMap(p=>p.features));
reportInput.m1Reconciliation=combineM1Reconciliations(reportInput.m1Reconciliation!,reconciliation);
const report=buildCoverageReport(reportInput,'2026-10-14');
const brand=report.brandProgress.find(b=>b.brand==='Jaecoo')!;
assert.equal(brand.researchCompleted,true);
assert.equal(brand.missingModels,0);
assert.equal(brand.unresolvedLeads,0);
assert.equal(brand.missingSummaries,0);
assert.equal(brand.agedOrInvalidClaims,0);
assert.equal(brand.onSaleVersions,1);
assert.deepEqual(brand.currentVersionReviews[0].versions,[{carId:'jaecoo_j5_ev__ev_summit__1',model:'J5 EV',trim:'EV Summit',modelYear:2026}]);
const independentReport={brand,gaps:report.gaps.filter(g=>g.brand==='Jaecoo'),rankings:report.rankings.map(r=>({key:r.key,jaecooRanked:r.rankedIds.includes('jaecoo_j5_ev__ev_summit__1'),groups:r.groups})),note:'Brand-only list review does not establish global C1 closure.'};
fs.writeFileSync('../roadmark-104-qa/jaecoo-independent-stage-report.json',JSON.stringify(independentReport,null,2));
console.log('PASS: current version reconciliation, research completion, zero aged claims and preserved global C1 limitation');
