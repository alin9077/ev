import fs from 'node:fs';
import assert from 'node:assert/strict';
import {catalogue,research,pack,effectiveFeatures} from '../roadmark-104/src/lib/data.ts';
import {applyBrandUpdates,prepareBrandResearch,applyBrandFeatureUpdates,applyBrandTermFeatures,type BrandUpdatePacket} from '../roadmark-104/src/lib/brand-updates.ts';
import {factClaim,featureClaim} from '../roadmark-104/src/lib/citable.ts';
import {storePortablePacks,hydratePortablePacks} from '../roadmark-104/src/lib/portable-packs.ts';
const path='/tmp/zeekr-research/zeekr-2026-10-14.json';
const p=JSON.parse(fs.readFileSync(path,'utf8')) as BrandUpdatePacket;
const old=research(), before=catalogue();
assert(!old.sources.some(s=>p.sources.some(n=>n.id===s.id&&n.id.startsWith('m1_zeekr_'))),'Packet may already be registered; use clean pre-packet branch');
const prepared=prepareBrandResearch(old,[p]);
const after=applyBrandUpdates(before,prepared,[p]);
const built: Record<string,ReturnType<typeof pack>>={};
const newFeatureBaselines: unknown[]=[];
let claims=0,features=0;
for(const car of after.filter(c=>c.brand==='Zeekr')) {
 const original=before.find(c=>c.id===car.id);
 const starting=effectiveFeatures(original||car,original?old:prepared);
 if(!original)newFeatureBaselines.push(...starting);
 const final=applyBrandTermFeatures(car,applyBrandFeatureUpdates(car,starting,prepared,[p]));
 const base=pack(car.id,{data:prepared,cars:after});
 const ids=new Set([...base.sources.map(s=>s.id),...final.flatMap(f=>f.source_ids)]);
 const view={...base,features:final,sources:prepared.sources.filter(s=>ids.has(s.id))};built[car.id]=view;
 for (const row of p.features?.filter(f=>f.variantId===car.id)??[]) {
   const f=final.find(f=>f.criterion===row.criterion)!;assert.deepEqual(f,row.after);
   const claim=featureClaim(view,f.criterion,f.criterion)!;assert.equal(claim.value,String(f.value));
   assert.deepEqual(claim.gradeReview,f.gradeReview);assert.deepEqual(claim.sources.map(s=>s.id),f.source_ids);features++;
 }
 for(const f of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===p.id)) {
  const claim=factClaim(view,f);assert.equal(claim.buyerGrade,f.buyerGrade);
  assert.deepEqual(claim.gradeReview,f.gradeReview);assert.deepEqual(claim.sources.map(s=>s.id),f.sourceIds);claims++;
 }
}
const hyd=hydratePortablePacks(storePortablePacks(built),prepared.sources);
assert.deepEqual(hyd,built);
assert.deepEqual(old.sources, research().sources);assert.deepEqual(before,catalogue());
const broken=structuredClone(p);broken.facts[0].before!.value='changed';
assert.throws(()=>applyBrandUpdates(before,prepared,[broken]),/before snapshot changed/);
const brokenSource=structuredClone(p);const retained=brokenSource.sources.find(s=>old.sources.some(o=>o.id===s.id));
if(retained){retained.title+=' changed';assert.throws(()=>prepareBrandResearch(old,[brokenSource]),/source snapshot changed/)}
else { const changed=structuredClone(old.sources[0]);changed.title+=' changed';brokenSource.sources.push(changed);assert.throws(()=>prepareBrandResearch(old,[brokenSource]),/source snapshot changed/); }
const brokenIdentity=structuredClone(p);brokenIdentity.versionGuards[0].before.trim+=' changed';
assert.throws(()=>applyBrandUpdates(before,prepared,[brokenIdentity]),/identity|version|snapshot/i);
const brokenAvailability=structuredClone(p);brokenAvailability.availability[0].before.availability='changed';
assert.throws(()=>applyBrandUpdates(before,prepared,[brokenAvailability]),/snapshot|availability/i);
const brokenTerm=structuredClone(p);const term=brokenTerm.brandTerms![0];term.before[term.applicableVariantIds[0]]!.value='changed';
assert.throws(()=>applyBrandUpdates(before,prepared,[brokenTerm]),/before snapshot changed/);
const brokenSummary=structuredClone(p);brokenSummary.summaries[0].strength.dependencies[0].expected.value='changed';
assert.throws(()=>applyBrandUpdates(before,prepared,[brokenSummary]),/dependency changed/);
const brokenFeature=structuredClone(p);
if(brokenFeature.features?.length){
 const row=brokenFeature.features[0];row.before.conditions+=' changed';
 const c=after.find(c=>c.id===row.variantId)!,b=before.find(c=>c.id===row.variantId)!;
 assert.throws(()=>applyBrandFeatureUpdates(c,effectiveFeatures(b,old),prepared,[brokenFeature]),/before snapshot changed/);
 const dep=structuredClone(p);dep.features![0].dependencies[0].expected.value='changed';
 assert.throws(()=>applyBrandUpdates(before,prepared,[dep]),/dependency changed/);
}
fs.writeFileSync('/workspace/scratch/586427eef9f2/roadmark-104-qa/zeekr-audit-new-feature-baselines.json',JSON.stringify(newFeatureBaselines,null,2));
fs.writeFileSync('/workspace/scratch/586427eef9f2/roadmark-104-qa/zeekr-reviewed-stage-packs.json',JSON.stringify(built,null,2));
console.log(JSON.stringify({versions:Object.keys(built).length,citableFacts:claims,reviewedFeatures:features,portableExactRoundtrip:true,immutableInputObjects:true,negativeFactSourceIdentityAvailabilityTermFeatureSummaryGuards:true}));
