import test from "node:test";
import assert from "node:assert/strict";
import {
  applyBrandFeatureUpdates,
  applyBrandUpdates,
  brandVersionSnapshot,
  prepareBrandResearch,
  type BrandUpdatePacket,
} from "../src/lib/brand-updates";
import { featureClaim } from "../src/lib/citable";
import {
  storePortablePacks,
  hydratePortablePacks,
} from "../src/lib/portable-packs";
import { compiledSource } from "./helpers/compiled-source";
import type {
  Car,
  Fact,
  Feature,
  Pack,
  Research,
  Source,
} from "../src/lib/types";

function fixture() {
  const source: Source = {
    id: "fixture-maker-2026-10-14",
    url: "https://maker.example/au/specifications",
    title: "Synthetic fixture specification",
    publisher: "Maker",
    source_type: "manufacturer",
    published_date: null,
    accessed_date: "2026-10-14",
    market: "AU",
    supports: "Synthetic exact-version measurements for behavioural tests",
  };
  const fact: Fact = {
    key: "range_km",
    label: "Claimed range",
    value: 450,
    unit: "km",
    basis: "WLTP",
    comparisonBasis: "WLTP",
    status: "standard",
    sourceIds: [source.id],
    date: "2026-10-14",
    market: "AU",
    scope: "Maker Example Base",
    qualifications: [],
    issues: [],
  };
  const car: Car = {
    id: "fixture_maker_example__base__1",
    modelId: "fixture_maker_example",
    family: "fixture-maker-example",
    slug: "base-1",
    brand: "Maker",
    model: "Example",
    trim: "Base",
    year: null,
    generation: "Current",
    drive: "RWD",
    vehicleClass: "passenger",
    availability: "current_or_order_listed",
    availabilityEvidence: {
      checkedAt: "2026-10-14",
      orderStatus: "unverified",
      stockStatus: "unverified",
      sourceIds: [source.id],
      qualifications: ["Stock unverified."],
    },
    facts: {
      range_km: fact,
      seats: {
        ...fact,
        key: "seats",
        label: "Seats",
        value: 5,
        unit: "",
        basis: "Occupied seats",
        comparisonBasis: "Occupied seats",
      },
    },
    issues: [],
  };
  const research: Research = {
    schema_version: "fixture",
    metadata: {
      as_of: "2026-10-14",
      baseline_variant_id: car.id,
      record_count: 1,
      criterion_count: 1,
      feature_row_count: 1,
    },
    models: [
      {
        id: car.modelId,
        brand: car.brand,
        model: car.model,
        generation: car.generation,
      },
    ],
    variants: [
      {
        id: car.id,
        model_id: car.modelId,
        brand: car.brand,
        model: car.model,
        trim: car.trim,
        model_year: null,
        record_state: car.availability,
        price_aud: null,
        price_basis: "",
        range_km: null,
        range_cycle: "",
        seats: null,
        source_ids: [source.id],
        notes: [],
        variant_review_date: "2026-10-14",
        drive: "RWD",
        vehicle_class: "passenger",
      },
    ],
    criteria: [
      {
        key: "fixture",
        label: "Fixture",
        group: "Fixture",
        definition: "Fixture",
      },
    ],
    trim_equipment: [{ variant_id: car.id, source_ids: [] }],
    feature_evidence: [
      {
        variant_id: car.id,
        model_id: car.modelId,
        criterion: "fixture",
        value: "Needs confirmation",
        status: "not_verified",
        conditions: "Unknown",
        source_ids: [],
        evidence_scope: "Fixture",
        last_evidence_date: "2026-10-14",
        reviewed_date: "2026-10-14",
        verification_state: "unverified",
      },
    ],
    update_eligibility: [
      {
        variant_id: car.id,
        model_id: car.modelId,
        documented_family_minimum: null,
        exact_total_known: false,
        exact_total: null,
        scope: "Unknown",
        meaning: "Research pending",
        source_ids: [],
        observation_window_start: "2026-10-14",
        observation_window_end: "2026-10-14",
      },
    ],
    update_events: [],
    configuration_history: [],
    sources: [source],
    publication_issues: [],
    prior_update_summary: [],
  };
  const packet: BrandUpdatePacket = {
    schemaVersion: 1,
    id: "m1-fixture-2026-10-14",
    brand: car.brand,
    reviewedAt: "2026-10-14",
    reviewedBy: "Fixture review",
    sources: [source],
    models: [],
    variants: [],
    versionGuards: [{ variantId: car.id, before: brandVersionSnapshot(car) }],
    versionUpdates: [],
    facts: [],
    availability: [],
    summaries: [],
  };
  const grade = (input: Fact, owner = packet): Fact => ({
    ...structuredClone(input),
    buyerGrade: "confirmed",
    gradeReview: {
      reviewedAt: owner.reviewedAt,
      overlayId: owner.id,
      reason: "Exact Australian version confirmed by maker fixture",
      evidenceScope: "exact_au_version",
      sourceIds: [...input.sourceIds],
    },
  });
  return { car, source, fact, research, packet, grade };
}

function featureFixture() {
  const data = fixture();
  const { car, fact, grade, research, packet } = data;
  const before: Feature = {
    ...research.feature_evidence[0],
    gradeReviewStatus: "review_required",
  };
  research.feature_evidence = [before];
  const afterFact = grade({ ...fact, value: 470 });
  packet.facts = [{ variantId: car.id, before: fact, after: afterFact }];
  const after: Feature = {
    ...before,
    value: "470 km WLTP",
    status: "standard",
    conditions: "",
    source_ids: afterFact.sourceIds,
    buyerGrade: "confirmed",
    gradeReview: structuredClone(afterFact.gradeReview),
    evidence_scope: "Exact Australian version",
    verification_state: "reviewed_exact_version",
  };
  packet.features = [
    {
      variantId: car.id,
      criterion: before.criterion,
      before,
      after,
      dependencies: [{ key: fact.key, expected: afterFact }],
    },
  ];
  const apply = (
    owner = packet,
    inputCar = car,
    inputResearch = research,
    inputFeatures = [before],
  ) => {
    const prepared = prepareBrandResearch(inputResearch, [owner]);
    const updated = applyBrandUpdates([inputCar], prepared, [owner])[0];
    return applyBrandFeatureUpdates(updated, inputFeatures, prepared, [owner]);
  };
  return { ...data, before, after, afterFact, apply };
}

test("reviewed feature replacement preserves inputs and carries its new citations and grade", () => {
  const { car, research, packet, before, after, apply } = featureFixture();
  const original = structuredClone({ car, research, packet, before, after });
  const [updated] = apply();
  assert.equal(updated.value, "470 km WLTP");
  assert.equal(updated.buyerGrade, "confirmed");
  assert.equal(updated.gradeReview?.overlayId, packet.id);
  assert.equal(Object.hasOwn(updated, "gradeReviewStatus"), false);
  assert.deepEqual(updated.source_ids, after.source_ids);
  assert.notEqual(updated, after);
  assert.deepEqual({ car, research, packet, before, after }, original);
  assert.equal(
    applyBrandFeatureUpdates(car, [before], research, [])[0],
    before,
  );
});

test("feature target, exact before metadata, version and source snapshots fail closed", () => {
  const { car, research, packet, before, apply } = featureFixture();
  for (const change of [
    (row: BrandUpdatePacket) => {
      row.features![0].variantId = "wrong";
    },
    (row: BrandUpdatePacket) => {
      row.features![0].criterion = "unknown";
    },
    (row: BrandUpdatePacket) => {
      row.features![0].before.conditions = "Different qualification";
    },
    (row: BrandUpdatePacket) => {
      row.features![0].after.model_id = "wrong_model";
    },
    (row: BrandUpdatePacket) => {
      row.features!.push(structuredClone(row.features![0]));
    },
    (row: BrandUpdatePacket) => {
      row.versionGuards = [];
    },
    (row: BrandUpdatePacket) => {
      row.sources[0].supports = "Changed source scope";
    },
    (row: BrandUpdatePacket) => {
      row.features![0].after.source_ids = ["missing"];
    },
  ]) {
    const edited = structuredClone(packet);
    change(edited);
    assert.throws(() => apply(edited), /Brand update:/);
  }
  assert.throws(
    () => apply(packet, { ...car, trim: "Other" }),
    /version changed/,
  );
  const updated = applyBrandUpdates([car], research, [packet])[0];
  assert.throws(
    () =>
      applyBrandFeatureUpdates(
        { ...updated, trim: "Other" },
        [before],
        research,
        [packet],
      ),
    /version changed/,
  );
  assert.throws(
    () =>
      applyBrandFeatureUpdates(updated, [before, before], research, [packet]),
    /before snapshot changed/,
  );
});

test("feature grades require current review provenance and full matching citations", () => {
  const { packet, apply } = featureFixture();
  for (const change of [
    (feature: Feature) => {
      feature.gradeReview!.overlayId = "old-review";
    },
    (feature: Feature) => {
      feature.gradeReview!.reviewedAt = "2026-10-13";
    },
    (feature: Feature) => {
      feature.reviewed_date = "2026-10-13";
    },
    (feature: Feature) => {
      feature.last_evidence_date = "2026-10-15";
    },
    (feature: Feature) => {
      feature.gradeReview!.sourceIds = [];
    },
    (feature: Feature) => {
      feature.gradeReview!.reason = "";
    },
    (feature: Feature) => {
      feature.buyerGrade = "reported";
    },
    (feature: Feature) => {
      feature.buyerGrade = "not_published";
      feature.value = "Not published";
    },
    (feature: Feature) => {
      feature.buyerGrade = "check";
      feature.status = "conditional";
      feature.conditions = "";
    },
  ]) {
    const edited = structuredClone(packet);
    change(edited.features![0].after);
    assert.throws(() => apply(edited), /unearned grade|grade\/status mismatch/);
  }
});

test("Confirmed equipment keeps explicitly reviewed optional, unavailable and not-applicable fitment", () => {
  const { packet, apply } = featureFixture();
  for (const status of ["optional", "unavailable", "not_applicable"] as const) {
    const edited = structuredClone(packet);
    edited.features![0].after.status = status;
    edited.features![0].after.conditions =
      "Explicitly reviewed equipment fitment.";
    assert.equal(apply(edited)[0].status, status);
  }
  const check = structuredClone(packet);
  check.features![0].after.buyerGrade = "check";
  check.features![0].after.status = "conditional";
  check.features![0].after.conditions = "Requires the optional wheel package.";
  assert.equal(apply(check)[0].buyerGrade, "check");
});

test("dependencies must exactly match post-packet facts", () => {
  const { packet, apply, car, research } = featureFixture();
  for (const change of [
    (row: BrandUpdatePacket) => {
      row.features![0].dependencies[0].expected = {
        ...row.features![0].dependencies[0].expected,
        value: 999,
      };
    },
    (row: BrandUpdatePacket) => {
      row.features![0].dependencies[0].key = "seats";
    },
    (row: BrandUpdatePacket) => {
      row.features![0].dependencies = [];
    },
    (row: BrandUpdatePacket) => {
      row.features![0].dependencies.push(
        structuredClone(row.features![0].dependencies[0]),
      );
    },
  ]) {
    const edited = structuredClone(packet);
    change(edited);
    assert.throws(() => apply(edited), /feature dependenc/);
  }
  const updated = applyBrandUpdates([car], research, [packet])[0];
  updated.facts.range_km = {
    ...updated.facts.range_km,
    qualifications: ["Changed later"],
  };
  assert.throws(
    () =>
      applyBrandFeatureUpdates(
        updated,
        [packet.features![0].before],
        research,
        [packet],
      ),
    /feature dependency changed/,
  );
});

test("a mixed feature can cite an earned null Not published fact without weakening fact grading", () => {
  const { packet, research, fact, apply } = featureFixture();
  const second: Source = {
    ...research.sources[0],
    id: "second-search",
    url: "https://maker.example/au/manual",
  };
  packet.sources.push(second);
  const unknown: Fact = {
    ...fact,
    key: "folded_l",
    value: null,
    status: "not_verified",
    sourceIds: packet.sources.map((source) => source.id),
    buyerGrade: "not_published",
    gradeReview: {
      reviewedAt: packet.reviewedAt,
      overlayId: packet.id,
      reason: "No folded cargo measurement found in two current maker sources.",
      evidenceScope: "searched_not_found",
      sourceIds: packet.sources.map((source) => source.id),
    },
  };
  packet.facts.push({
    variantId: packet.features![0].variantId,
    before: null,
    after: unknown,
  });
  packet.features![0].dependencies.push({
    key: unknown.key,
    expected: unknown,
  });
  packet.features![0].after.value += "; folded cargo Not published";
  packet.features![0].after.source_ids = [...unknown.sourceIds];
  packet.features![0].after.gradeReview!.sourceIds = [...unknown.sourceIds];
  assert.equal(apply()[0].buyerGrade, "confirmed");
});

test("later fact changes require a reviewed feature replacement and replay exact before states", () => {
  const { car, research, packet, before, grade } = featureFixture();
  const firstCar = applyBrandUpdates([car], research, [packet])[0];
  const firstFeature = applyBrandFeatureUpdates(firstCar, [before], research, [
    packet,
  ])[0];
  const second: BrandUpdatePacket = {
    ...structuredClone(packet),
    id: "m1-fixture-2026-10-15",
    reviewedAt: "2026-10-15",
    features: [],
    facts: [],
  };
  const updatedFact = grade(
    { ...firstCar.facts.range_km, value: 480, date: second.reviewedAt },
    second,
  );
  second.facts = [
    { variantId: car.id, before: firstCar.facts.range_km, after: updatedFact },
  ];
  assert.throws(
    () => applyBrandUpdates([car], research, [packet, second]),
    /feature dependency changed/,
  );
  const after: Feature = {
    ...firstFeature,
    value: "480 km WLTP",
    reviewed_date: second.reviewedAt,
    last_evidence_date: second.reviewedAt,
    gradeReview: structuredClone(updatedFact.gradeReview),
  };
  second.features = [
    {
      variantId: car.id,
      criterion: before.criterion,
      before: firstFeature,
      after,
      dependencies: [{ key: updatedFact.key, expected: updatedFact }],
    },
  ];
  const finalCar = applyBrandUpdates([car], research, [packet, second])[0];
  assert.equal(
    applyBrandFeatureUpdates(finalCar, [before], research, [packet, second])[0]
      .value,
    "480 km WLTP",
  );
  second.features[0].before = before;
  assert.throws(
    () =>
      applyBrandFeatureUpdates(finalCar, [before], research, [packet, second]),
    /before snapshot changed/,
  );
});

test("canonical driveaway and roadside equipment rows cannot be manually overwritten", () => {
  const { packet, research, car, apply } = featureFixture();
  for (const criterion of ["driveaway_price", "roadside_assistance"]) {
    const edited = structuredClone(packet);
    edited.features![0].criterion = criterion;
    edited.features![0].before.criterion = criterion;
    edited.features![0].after.criterion = criterion;
    const data = structuredClone(research);
    data.criteria[0].key = criterion;
    data.feature_evidence[0].criterion = criterion;
    assert.throws(() => apply(edited, car, data), /canonical feature target/);
  }
});

test("current pack, citable claims and portable hydration carry the reviewed feature", () => {
  const { car, research, packet, before } = featureFixture();
  const updated = applyBrandUpdates([car], research, [packet])[0];
  const emptyOverlay = {
    features: [],
    facts: [],
    sources: [],
    criteria: [],
    issues: [],
    eligibility: [],
    configuration: [],
  };
  const overrides: Record<string, unknown> = {
    "./brand-update-registry": { brandUpdatePackets: [packet] },
    "./retained-fact-fills": {},
    "./price-ladder": {},
    "./evidence-regrading": { applyFeatureRegrading: () => [before] },
    "./catalogue-additions": {
      catalogueAdditions: { ...emptyOverlay, variants: [] },
    },
    "./buyer-proposal": { buyerProposal: {} },
    "./launch-evidence": { auditedFeature: (feature: Feature) => feature },
  };
  for (const name of [
    "refinement",
    "usability",
    "sales",
    "completion",
    "editorial",
    "buyer",
  ])
    overrides[
      `../../data/research-${name}-2026-10-${["completion", "editorial", "buyer"].includes(name) ? "07" : "06"}.json`
    ] = emptyOverlay;
  for (const name of [
    "approved-feature-corrections",
    "approved-availability-corrections",
    "approved-corrections",
    "research-refresh-2026-10-10",
  ])
    overrides[`../../data/${name}.json`] = [];
  const loaded = compiledSource("src/lib/data.ts", overrides) as {
    pack(id: string, snapshot: { data: Research; cars: Car[] }): Pack;
  };
  const packed = loaded.pack(car.id, { data: research, cars: [updated] });
  assert.equal(packed.features[0].value, "470 km WLTP");
  assert.equal(packed.features[0].gradeReview?.overlayId, packet.id);
  const restored = hydratePortablePacks(
    storePortablePacks({ [car.id]: packed }),
    research.sources,
  )[car.id];
  assert.deepEqual(restored, packed);
  const claim = featureClaim(restored, before.criterion, "Fixture")!;
  assert.equal(claim.value, "470 km WLTP");
  assert.equal(claim.buyerGrade, "confirmed");
  assert.equal(claim.gradeReviewStatus, undefined);
  assert.equal(claim.gradeReview?.overlayId, packet.id);
  assert.deepEqual(
    claim.sources.map((source) => source.id),
    packet.features![0].after.source_ids,
  );
});

test("immutable Tesla source snapshots still pack while current Tesla storage uses the reviewed overlay", async () => {
  const { sourceSnapshotPack } = await import("./helpers/source-fixture");
  const {
    sourceCatalogue,
    sourceResearch,
    sourceEffectiveFeatures,
    catalogue,
    research,
    pack,
  } = await import("../src/lib/data");
  const original = { data: sourceResearch(), cars: sourceCatalogue() };
  const current = { data: research(), cars: catalogue() };
  for (const id of [
    "tesla_model_3__premium_long_range_rwd__1",
    "tesla_model_y__l_premium_awd__4",
  ]) {
    const car = original.cars.find((row) => row.id === id)!;
    assert.equal(car.buyerGradesRequired, undefined);
    const frozen = sourceSnapshotPack(id, original);
    const originalStorage = sourceEffectiveFeatures(car, original.data).find(
      (row) => row.criterion === "storage",
    )!;
    assert.deepEqual(
      frozen.features.find((row) => row.criterion === "storage"),
      originalStorage,
    );
    assert(
      !frozen.sources.some((source) =>
        source.id.startsWith("m1-tesla-2026-10-14"),
      ),
    );
    const updated = pack(id, current);
    assert.equal(updated.car.buyerGradesRequired, true);
    const storage = updated.features.find(
      (row) => row.criterion === "storage",
    )!;
    assert.equal(storage.gradeReview?.overlayId, "m1-tesla-2026-10-14");
    assert.equal(storage.gradeReviewStatus, undefined);
    if (id.startsWith("tesla_model_3")) {
      assert.match(
        storage.value,
        /594 L rear boot.*88 L front boot.*Not published/,
      );
      assert.doesNotMatch(storage.value, /977/);
    } else {
      assert.match(storage.value, /420 L rear behind occupied third row/);
      assert.equal(updated.car.model, "Model Y L");
    }
    const drifted: Car = {
      ...updated.car,
      facts: {
        ...updated.car.facts,
        boot_l: { ...updated.car.facts.boot_l, value: 9999 },
      },
    };
    assert.throws(
      () => pack(id, { data: current.data, cars: [drifted] }),
      /feature dependency changed/,
    );
  }
});
