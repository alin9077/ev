# Through-Kia test-boundary repairs: approved

Independent read-only review, 14 October 2026. No blocking issue found in the five repairs. No implementation, source evidence, catalogue data or repository test file was changed by this review.

## Findings

1. **Buyer availability:** The three MY27 EV4 variants have explicitly reviewed `current_or_order_listed` replacements in the Kia packet, supported by current configuration/pricing sources. `buyer-availability.ts` defines this as an advertised current version. The repaired test still requires unverified stock, false physical-stock and accepted-order flags, no invented arrival timing, and citations. The source-layer Kia/Cadillac admission tests separately retain the original provisional state. This is an updated expectation, not removal of the stock/order boundary.
2. **Corrections:** The towing approval is exercised against `sourceCatalogue()`, the layer on which the original complete before-state was captured. The test still verifies replacement comparison basis and preserved semantic status, then explicitly requires the later Tesla packet to reject the changed full before-state. `brand-updates.ts` checks `sameReviewedState(current, edit.before)` before accepting each fact. The production correction registry is restored in `finally`. This strengthens coverage of the now-two-stage correction boundary.
3. **Domain buyer audit:** The assertions include the literal `full_text_audit_2026-10-08` marker and historical buyer statements, so using the source snapshot is appropriate. The observed current-data failure is not missing caution: seven Kia kerb-mass nulls carry `not_verified`, earned two-source `not_published` reviews, explicit basis and substantive `conditionExplanation`, while `qualifications` is legitimately empty. All seven earned reviews and their rejection under invalid-status, non-null-value and one-source mutations were checked independently. Current domain count, validation, source-closure, fact-scope and reviewed-comparison tests remain current; `brand-live-safety.test.ts` also exercises current packs and complete claim/review/availability source closure.
4. **Coverage fixtures:** The three synthetic missing facts previously inherited `standard` from their populated-fact factory. Adding `not_verified` makes them canonical null Not published facts. `hasEarnedBuyerGrade()` expressly requires this status, true null, searched-not-found scope and at least two distinct source URLs. Two-source failure, missing C2 coverage, incomplete whole-market closure and unranked towing/charging assertions remain intact.
5. **Historical market count:** The 10 October market inventory and source cars are the same dated layer. Comparing its family count with the source-car family set fixes the 150-versus-152 layer mismatch without changing the family definition or fixing a magic number. Exact trim count and four unique commercial-family records remain checked. `domain.test.ts` separately verifies live `counts().families` against the current catalogue.

## Verification

- Inspected original full-suite log: 1,001 tests, 994 pass, seven failures; all seven match these boundaries
- Inspected focused rerun: 89/89 pass, zero skipped; typecheck and lint exit files are both zero
- Independently reran `tests/m1-coverage-tracking.test.ts`: 19/19 pass, zero skipped; log `m1-through-kia-boundary-review-coverage.log`
- Lightweight production-function probes: all three EV4 offers preserve stock/order/timing holds; all seven reviewed empty-qualification kerb-mass nulls earn their grade; 21 malformed status/value/source mutations are rejected; log `m1-through-kia-boundary-review-probes.log`
- No additional full-suite or heavy catalogue process was run. Full-suite/build completion remains separate from this bounded approval

## Reviewed test hashes (SHA-256)

- buyer-availability-scope.test.ts: `53bd150d211e781d2bb91712fb1bc6bdd217d290f7eaaeb2f8ed928c2f554e21`
- corrections.test.ts: `c514463094d18e1050ded34e9420f3e8718aed2410c1eaa792c465f8fc976452`
- domain.test.ts: `25258a2017cb143fe4c4a560d3a555c483023c70579835db239849803e0da53d`
- m1-coverage-tracking.test.ts: `c17dadba09e50223099357c7e4e58fe7306961f298e372fc2b2bfa7d5e1af405`
- remaining-utes-vans.test.ts: `4519d860667b464863ade0d73fe81f0260e90f928523e5ec5a3d393823adcf19`
