import json, hashlib, pathlib, urllib.parse, collections, sys
r=pathlib.Path('/tmp/tesla-research')
p=json.load(open(r/'tesla-2026-10-14.json'))
before={c['id']:c for c in json.load(open(r/'before.json'))}
sources={s['id']:s for s in p['sources']}
errors=[]
def check(condition,message):
 if not condition: errors.append(message)
def identity(c):return {**{k:c[k] for k in ['id','modelId','brand','model','trim','year','generation','drive']},'vehicleClass':c.get('vehicleClass','passenger')}
check(len(sources)==len(p['sources']),'duplicate sources')
effective={i:dict(c['facts']) for i,c in before.items()}
for x in p['variants']:effective[x['id']]={}
for x in p['versionGuards']:check(x['before']==identity(before[x['variantId']]),f"bad identity guard {x['variantId']}")
for x in p['versionUpdates']:
 check(x['before']==identity(before[x['variantId']]),f"bad identity update guard {x['variantId']}")
 for k in ['id','modelId','brand']:check(x['before'][k]==x['after'][k],f'changed stable {k}')
seen=set()
for x in p['facts']:
 i=x['variantId'];f=x['after'];k=f['key'];target=(i,k)
 check(target not in seen,f'duplicate target {target}');seen.add(target)
 check(x['before']==before.get(i,{}).get('facts',{}).get(k),f'bad before fact {target}')
 effective[i][k]=f
for t in p.get('brandTerms',[]):
 check(set(t['applicableVariantIds'])|{e['variantId'] for e in t['exceptions']}==set(effective),f"term coverage {t['key']}")
 check(not set(t['applicableVariantIds'])&{e['variantId'] for e in t['exceptions']},f"term duplicate exception {t['key']}")
 for i in t['applicableVariantIds']:
  target=(i,t['key']);check(target not in seen,f'duplicate target {target}');seen.add(target)
  check(t['before'][i]==before.get(i,{}).get('facts',{}).get(t['key']),f'bad before term {target}')
  effective[i][t['key']]=t['fact']
for f in [x['after'] for x in p['facts']]+[x['fact'] for x in p.get('brandTerms',[])]:
 check(set(f['sourceIds'])<=set(sources),f"missing source {f['key']}")
 check(f['sourceIds']==f['gradeReview']['sourceIds'],f"source review mismatch {f['key']}")
 check(f['date']==p['reviewedAt']==f['gradeReview']['reviewedAt'],f"date mismatch {f['key']}")
 check(f['gradeReview']['overlayId']==p['id'],f"overlay mismatch {f['key']}")
 g=f['buyerGrade'];check(f['status']=={'confirmed':'standard','check':'conditional','reported':'conditional','not_published':'not_verified'}[g],f"status grade {f['key']}")
 if g=='not_published':
  us={urllib.parse.urlsplit(sources[x]['url'])._replace(query='',fragment='').geturl() for x in f['sourceIds']}
  check(len(us)>=2,f"two sources missing {f['key']}");check(f['value'] is None,f"not null gap {f['key']}")
 if g=='check':check(bool(f.get('conditionExplanation')),f"missing Check condition {f['key']}")
 if g=='reported':check(f.get('resolvedElsewhere')==True,f"missing Reported marker {f['key']}")
for s in p['sources']:
 if s.get('capture_locator'):
  f=r/s['capture_locator'];check(f.exists(),f'missing capture {f}')
  if f.exists():check(hashlib.sha256(f.read_bytes()).hexdigest()==s['capture_sha256'],f'bad capture hash {f}')
for x in p['summaries']:
 for c in ['strength','tradeoff']:
  for d in x[c]['dependencies']:check(effective[x['variantId']].get(d['key'])==d['expected'],f"bad dependency {x['variantId']} {c} {d['key']}")
for x in p['availability']:
 i=x['variantId'];c=before[i]
 expected={'availability':c['availability'],'evidence':c.get('availabilityEvidence',{'checkedAt':'','orderStatus':'unverified','stockStatus':'unverified','sourceIds':[]})}
 check(x['before']==expected,f'bad availability guard {i}')
 check(x['reviewedAt']==p['reviewedAt']==x['evidenceDate']==x['after']['evidence']['checkedAt'],f'bad availability date {i}')
 check(x['status']=='approved' and x['reviewedBy']==p['reviewedBy'],f'bad availability review {i}')
 check(set(x['after']['evidence']['sourceIds'])<=set(sources),f'bad availability citations {i}')
 for clause in ('strength','tradeoff'):
  summary=next((s for s in p['summaries'] if s['variantId']==i),None)
  if summary:
   for d in summary[clause]['dependencies']:
    check(not d['expected'].get('issues'),f'conflicted summary {i} {clause}')
research=json.load(open(r/'research-before.json'))
old_sources={s['id']:s for s in research['sources']}
for s in p['sources']:
 if s['id'] in old_sources:check(s==old_sources[s['id']],f"modified existing source {s['id']}")
check(len(p['summaries'])==len(effective),'summary coverage')
print('COUNTS', {k:len(p[k]) for k in ['sources','models','variants','versionGuards','versionUpdates','facts','brandTerms','availability','summaries']})
print('GRADES',collections.Counter(f['buyerGrade'] for e in effective.values() for f in e.values() if f.get('gradeReview',{}).get('overlayId')==p['id']))
print('ERRORS',errors)
print('PACKET_SHA256',hashlib.sha256((r/'tesla-2026-10-14.json').read_bytes()).hexdigest())
for x in p['summaries']:
 print('\n',x['variantId'])
 for c in ['strength','tradeoff']:print(c,x[c]['text'],'DEPENDENCIES:',', '.join(d['key'] for d in x[c]['dependencies']))
if errors:sys.exit(1)
