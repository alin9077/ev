import json, hashlib, pathlib, urllib.parse, collections, sys
r=pathlib.Path('/tmp/omoda-jaecoo-research')
p=json.load(open(pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else r/'jaecoo-2026-10-14.json'))
before={c['id']:c for c in json.load(open(r/'before.json')) if c['brand']=='Jaecoo'}
sources={s['id']:s for s in p['sources']}
errors=[]
def check(condition,message):
 if not condition: errors.append(message)
def identity(c):return {**{k:c[k] for k in ['id','modelId','brand','model','trim','year','generation','drive']},'vehicleClass':c.get('vehicleClass','passenger')}
check(len(sources)==len(p['sources']),'duplicate sources')
effective={i:dict(c['facts']) for i,c in before.items()}
for x in p['variants']:effective[x['id']]={}
for x in p['versionGuards']:check(x['before']==identity(before[x['variantId']]),f"bad identity guard {x['variantId']}")
for x in p['versionUpdates']:
 check(x['before']==identity(before[x['variantId']]),f"bad identity update guard {x['variantId']}")
 for k in ['id','modelId','brand']:check(x['before'][k]==x['after'][k],f'changed stable {k}')
seen=set()
for x in p['facts']:
 i=x['variantId'];f=x['after'];k=f['key'];target=(i,k)
 check(target not in seen,f'duplicate target {target}');seen.add(target)
 check(x['before']==before.get(i,{}).get('facts',{}).get(k),f'bad before fact {target}')
 effective[i][k]=f
for t in p.get('brandTerms',[]):
 check(set(t['applicableVariantIds'])|{e['variantId'] for e in t['exceptions']}==set(effective),f"term coverage {t['key']}")
 check(not set(t['applicableVariantIds'])&{e['variantId'] for e in t['exceptions']},f"term duplicate exception {t['key']}")
 for i in t['applicableVariantIds']:
  target=(i,t['key']);check(target not in seen,f'duplicate target {target}');seen.add(target)
  check(t['before'][i]==before.get(i,{}).get('facts',{}).get(t['key']),f'bad before term {target}')
  effective[i][t['key']]=t['fact']
for f in [x['after'] for x in p['facts']]+[x['fact'] for x in p.get('brandTerms',[])]:
 check(set(f['sourceIds'])<=set(sources),f"missing source {f['key']}")
 check(f['sourceIds']==f['gradeReview']['sourceIds'],f"source review mismatch {f['key']}")
 check(f['date']==p['reviewedAt']==f['gradeReview']['reviewedAt'],f"date mismatch {f['key']}")
 check(f['gradeReview']['overlayId']==p['id'],f"overlay mismatch {f['key']}")
 g=f['buyerGrade'];check(f['status']=={'confirmed':'standard','check':'conditional','reported':'conditional','not_published':'not_verified'}[g],f"status grade {f['key']}")
 if g=='not_published':
  us={urllib.parse.urlsplit(sources[x]['url'])._replace(query='',fragment='').geturl() for x in f['sourceIds']}
  check(len(us)>=2,f"two sources missing {f['key']}");check(f['value'] is None,f"not null gap {f['key']}")
 if g=='check':check(bool(f.get('conditionExplanation')),f"missing Check condition {f['key']}")
 if g=='reported':check(f.get('resolvedElsewhere')==True,f"missing Reported marker {f['key']}")
for s in p['sources']:
 if s.get('capture_locator'):
  f=r/s['capture_locator'];check(f.exists(),f'missing capture {f}')
  if f.exists():check(hashlib.sha256(f.read_bytes()).hexdigest()==s['capture_sha256'],f'bad capture hash {f}')
for x in p['summaries']:
 for c in ['strength','tradeoff']:
  for d in x[c]['dependencies']:check(effective[x['variantId']].get(d['key'])==d['expected'],f"bad dependency {x['variantId']} {c} {d['key']}")
for x in p['availability']:
 i=x['variantId'];c=before.get(i)
 if not c:
  v=next(v for v in p['variants'] if v['id']==i)
  c={'availability':v['record_state'],'availabilityEvidence':{'checkedAt':v['variant_review_date'],'orderStatus':'unverified','stockStatus':'unverified','sourceIds':v['source_ids'],'qualifications':['Physical stock and factory-order acceptance have not been verified.']}}
 expected={'availability':c['availability'],'evidence':c.get('availabilityEvidence',{'checkedAt':'','orderStatus':'unverified','stockStatus':'unverified','sourceIds':[]})}
 check(x['before']==expected,f'bad availability guard {i}')
 check(x['reviewedAt']==p['reviewedAt']==x['evidenceDate']==x['after']['evidence']['checkedAt'],f'bad availability date {i}')
 check(x['status']=='approved' and x['reviewedBy']==p['reviewedBy'],f'bad availability review {i}')
 check(set(x['after']['evidence']['sourceIds'])<=set(sources),f'bad availability citations {i}')
 for clause in ('strength','tradeoff'):
  summary=next((s for s in p['summaries'] if s['variantId']==i),None)
  if summary:
   for d in summary[clause]['dependencies']:
    check(not d['expected'].get('issues'),f'conflicted summary {i} {clause}')
research=json.load(open(r/'research-before.json'))
old_sources={s['id']:s for s in research['sources']}
for s in p['sources']:
 if s['id'] in old_sources:check(s==old_sources[s['id']],f"modified existing source {s['id']}")
check(len(p['summaries'])==len(effective),'summary coverage')
# Independent effective snapshots establish the capture came from the live pre-packet view.
qa=pathlib.Path(__file__).parent
live={c['id']:c for c in json.load(open(qa/'jaecoo-audit-live-before.json'))}
check(before==live,'research before snapshot differs from independently captured live catalogue')
features={(f['variant_id'],f['criterion']):f for f in json.load(open(r/'features-before.json')) if f['variant_id'].startswith('jaecoo_')}
live_features={(f['variant_id'],f['criterion']):f for f in json.load(open(qa/'jaecoo-audit-live-features-before.json'))}
check(features==live_features,'research feature capture differs from independently captured live equipment')
if p['variants']:
 for f in json.load(open(qa/'jaecoo-audit-new-feature-baselines.json')):features[(f['variant_id'],f['criterion'])]=f
feature_targets=set()
for x in p.get('features',[]):
 target=(x['variantId'],x['criterion']);a=x['after'];i=x['variantId']
 check(target not in feature_targets,f'duplicate feature {target}');feature_targets.add(target)
 check(x['before']==features.get(target),f'bad full feature before {target}')
 check(a['variant_id']==i and a['criterion']==x['criterion'],f'feature identity {target}')
 check(a['source_ids']==a['gradeReview']['sourceIds'],f'feature grade source mismatch {target}')
 check(set(a['source_ids'])<=set(sources),f'unknown feature source {target}')
 check(a['reviewed_date']==p['reviewedAt']==a['gradeReview']['reviewedAt'],f'feature review date {target}')
 check(a['last_evidence_date']<=p['reviewedAt'],f'feature future evidence {target}')
 check(a['gradeReview']['overlayId']==p['id'],f'feature overlay mismatch {target}')
 for d in x['dependencies']:
  check(effective[i].get(d['key'])==d['expected'],f'bad feature dependency {target} {d["key"]}')
  check(not d['expected']['issues'],f'issue-bearing feature dependency {target} {d["key"]}')
  check(set(d['expected']['sourceIds'])<=set(a['source_ids']),f'feature dependency missing citations {target}')
core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty','battery_warranty']
for i,fs in effective.items():
 for k in core:
  check(k in fs and fs[k].get('gradeReview',{}).get('overlayId')==p['id'],f'core not reviewed {i} {k}')

# Independent maker PDF and AU review matrix, read on 14 October 2026.
expected = {'jaecoo_j5_ev__ev_summit__1':[35990,402,58.9,130,None,10.3,5,384,7.7,155,'FWD',4380,1860,1650]}
keys=core[:14]
for i,values in expected.items():
 for k,v in zip(keys,values):
  if v is not None:
   check(effective[i][k]['value']==v,f'numeric matrix mismatch {i} {k}: {effective[i][k]["value"]} != {v}')
 print('CORE',i,{k:(effective[i][k]['value'],effective[i][k]['buyerGrade']) for k in core})
print('FEATURE_COUNTS',len(p.get('features',[])),sum(len(x['dependencies']) for x in p.get('features',[])))
print('SOURCE_CAPTURES',sum(bool(s.get('capture_locator')) for s in p['sources']))
print('COUNTS', {k:len(p[k]) for k in ['sources','models','variants','versionGuards','versionUpdates','facts','brandTerms','availability','summaries']})
print('GRADES',collections.Counter(f['buyerGrade'] for e in effective.values() for f in e.values() if f.get('gradeReview',{}).get('overlayId')==p['id']))
print('ERRORS',errors)
print('PACKET_SHA256',hashlib.sha256((pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else r/'jaecoo-2026-10-14.json').read_bytes()).hexdigest())
for x in p['summaries']:
 print('\n',x['variantId'])
 for c in ['strength','tradeoff']: print(c,x[c]['text'],'DEPENDENCIES:',', '.join(d['key'] for d in x[c]['dependencies']))
if errors:sys.exit(1)
