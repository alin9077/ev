import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { createRequire } from "node:module";
import assert from "node:assert/strict";
import type * as Data from "../roadmark-104/src/lib/data";
const root = process.cwd();
const require = createRequire(path.join(root, "package.json"));
const ts = require("typescript") as typeof import("typescript");
function prior(relative: string): Record<string, unknown> {
  const filename = path.join(root, relative);
  const input = fs.readFileSync(path.join(root, "../roadmark-104-qa/source-feature-baseline-original", relative), "utf8");
  const output = ts.transpileModule(input, { fileName: filename, compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, esModuleInterop: true }}).outputText;
  const scopedRequire = createRequire(filename);
  const module = { exports: {} };
  const load = (id: string) => id === "./brand-updates" ? prior("src/lib/brand-updates.ts") : scopedRequire(id);
  vm.runInThisContext(`(function(require,module,exports){${output}\n})`, { filename })(load, module, module.exports);
  return module.exports;
}
const { catalogue, research, pack } = prior("src/lib/data.ts") as typeof Data;
const cars = catalogue(), data = research(), snapshot = { cars, data };
const target = pack(cars[0].id, snapshot).sources[0].id;
const changed = structuredClone(data);
changed.sources.find(source => source.id === target)!.url = "javascript:alert(1)";
assert.throws(() => pack(cars[0].id, { cars, data: changed }), /Brand update: feature before snapshot changed: tesla_model_y__premium_long_range_awd__1\/storage/);
console.log("Confirmed pre-fix data.ts + brand-updates.ts reproduce the existing home-payload URL-mutation failure, without altering the working tree. Source ID:", target);
