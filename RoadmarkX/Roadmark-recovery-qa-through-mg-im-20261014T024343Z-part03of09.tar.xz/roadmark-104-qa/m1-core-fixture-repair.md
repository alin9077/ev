# M1 core fixture repairs

The frozen full run finished with 945 tests: 866 passed and 79 failed. The failures handled here came from dated fixtures being mixed with M1 overlays, intentional transport/history changes, and the Tier 1 default. No production source file was changed by this work.

## Files repaired

- `tests/availability-corrections.test.ts`: 10 October approvals use source cars and source research. A separate current BYD test verifies withdrawal propagates into packs, removes ranks, clears cached copy, preserves facts and retains complete citations.
- `tests/corrections.test.ts`: only the production-register towing fixture takes its before-state from the source stage. It additionally verifies the current projection retains the correction and withdraws the obsolete grade.
- `tests/feature-corrections.test.ts`: the dated buyer-proposal guard uses source features. A separate production-register test verifies the correction reaches current packs and marks the old grade as requiring review.
- `tests/configuration-payload.test.ts`: only the synthetic configuration-eligibility control explicitly omits the M1 grade requirement, since its made-up fact has no grade review. The complete current-catalogue projection, rank parity, evidence and freshness tests remain live.
- `tests/detail-client-props.test.ts`: the exact narrow transport contract includes and verifies `buyerGradesRequired`, without weakening fact/source exclusion or reference-identity assertions.
- `tests/domain.test.ts`: five historical claim/status scenarios use the shared source-snapshot pack helper. Live counts, validation, source closure, current pack behavior and all other integration tests remain current. A new current-data test preserves incompatible comparison bases, paid-adapter disclosure, operating thresholds and unavailable equipment.
- `tests/explorer-interactions.test.ts`: the history harness supports both browser methods and verifies text/number changes replace history while select/reset changes push it. Reveal and selection assertions remain intact.
- `tests/market-audit-interactions.test.ts`: reset expects the authorized Tier 1 default while preserving query/evidence/pagination assertions.
- `tests/market-trike-evidence.test.ts`: reset expects Tier 1; the cross-class pagination/search scenario explicitly opts back into all classes. Held-candidate and repeated-reset checks remain.
- `tests/research-refresh.test.ts`: the dated refresh contract runs at the source stage before later grade/price/brand overlays.
- `tests/mg4-additions.test.ts`: original admission assertions use source cars/features. The older-availability test remains a current graded-catalogue test, evaluated on 14 October, and still verifies withdrawn/outgoing exclusions.

## Verification

- Focused execution: 102/102 passed, zero skipped, across the 11 files above
- Each file ran in its own Node invocation, one at a time
- Log: `m1-core-fixture-tests.log`
- Per-file exit status: `m1-core-fixture-tests.status` (all zero)
- Initial correction-only runs also passed; no full-suite rerun was performed here
- Full-suite rerun and final project-wide validation remain with the parent task

No behavioural assertion was deleted, no status/value was generally ignored, and no production guard was relaxed to satisfy a test.
