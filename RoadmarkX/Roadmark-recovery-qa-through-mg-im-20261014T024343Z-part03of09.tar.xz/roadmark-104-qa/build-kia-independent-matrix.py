import json,pathlib
qa=pathlib.Path(__file__).parent
before=json.load(open(qa/'kia-audit-live-before.json'))
expected={}
for c in before:
 if c['vehicleClass']!='passenger':continue
 i=c['id'];m=c['model'];t=c['trim'];f={}
 if m=='EV3':
  ix={'kia_ev3__air_2wd_standard_range__1':0,'kia_ev3__air_2wd_long_range__2':1,'kia_ev3__earth_2wd_long_range__3':2,'kia_ev3__gt_line_2wd_long_range__4':3,'kia_ev3__gt_line_awd_long_range__5':4}[i]
  keys=['range_km','battery_kwh','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg']
  vals=[[436,58.3,29,10.5,5,460,7.5,150,'FWD',4300,1850,1560,500],[604,81.4,31,10.5,5,460,7.7,150,'FWD',4300,1850,1560,1000],[563,81.4,31,10.5,5,460,7.9,150,'FWD',4300,1850,1560,1000],[563,81.4,31,10.5,5,460,7.9,150,'FWD',4310,1850,1570,1000],[559,81.4,31,10.5,5,460,6.6,195,'AWD',4310,1850,1570,1500]][ix]
  f=dict(zip(keys,vals))
  if ix<4:f['price_aud']=[47600,53315,58600,63950][ix]
 elif m=='EV4':
  sr='air_sr' in i
  f={'range_km':456 if sr else 612,'battery_kwh':58.3 if sr else 81.4,'dc_charge_time_min':29 if sr else 31,'ac_kw':10.5,'seats':5,'boot_l':490,'zero_to_100_s':7.4 if sr else 7.8,'power_kw':150,'drive':'FWD','length_mm':4730,'width_mm':1860,'height_mm':1480,'towing_braked_kg':500 if sr else 1000}
 elif m=='EV5':
  ix=['air_2wd_standard','air_2wd_long','earth_awd','gt_line_awd'].index(next(x for x in ['air_2wd_standard','air_2wd_long','earth_awd','gt_line_awd'] if x in i))
  f=dict(zip(['price_aud','range_km','battery_kwh','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg'],[[56770,400,64.2,36,6.6,5,513,8.5,160,'FWD',4615,1875,1715,300],[61170,555,88.1,38,11,5,513,8.9,160,'FWD',4615,1875,1715,1250],[64770,500,88.1,38,11,5,513,6.1,230,'AWD',4615,1875,1715,1250],[71770,470,88.1,38,11,5,513,6.3,230,'AWD',4615,1875,1715,1250]][ix]))
 elif m=='EV6':
  ix=['air_rwd','gt_line_rwd','gt_line_awd','gt_awd'].index(next(x for x in ['air_rwd','gt_line_rwd','gt_line_awd','gt_awd'] if x in i))
  f=dict(zip(['price_aud','range_km','battery_kwh','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg'],[[72660,582,84,18,10.5,5,490,7.7,168,'RWD',4695,1880,1550,1800],[79660,560,84,18,10.5,5,480,7.7,168,'RWD',4695,1890,1550,1800],[87660,522,84,18,10.5,5,480,5.3,239,'AWD',4695,1890,1550,1800],[99660,450,84,18,10.5,5,480,3.5,478,'AWD',4695,1890,1545,1800]][ix]))
 elif m=='EV9':
  ix=['air_rwd','earth_awd','gt_line_awd','gt_awd'].index(next(x for x in ['air_rwd','earth_awd','gt_line_awd','gt_awd'] if x in i))
  f=dict(zip(['price_aud','range_km','battery_kwh','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg'],[[97000,443,76.1,20,10.5,7,333,8.2,160,'RWD',5010,1980,1755,900],[106500,512,99.8,24,10.5,7,333,5.3,282.6,'AWD',5010,1980,1755,2500],[121000,505,99.8,24,10.5,7,333,5.3,282.6,'AWD',5015,1980,1780,2500],[129250,510,99.8,24,10.5,6,333,4.5,374,'AWD',5015,1980,1755,2500]][ix]))
 expected[i]=f
json.dump(expected,open(qa/'kia-independent-numeric-matrix.json','w'),indent=2)
