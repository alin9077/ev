# Roadmark working safety recovery: evidence consumers and accepted derived baseline

This is a working safety recovery, not a passed fresh-loader or integrated Subaru release. Polestar remains the separate last passed integrated recovery. The earlier working-safety-20261014T1545 copy also remains intact.

## What has passed

The reviewed lightweight evidence-consumer refactor has 43 focused core tests (25 existing snapshot tests and 18 new differential tests), 163 filtered guard tests, six-file lint and an isolated consumer-import probe. Three named full-hydration tests were explicitly excluded from the focused guard run and remain in the source. Earlier test/lint failures and exact terminal receipts are preserved.

The independent acceptance issued at 17:16:58 UTC on 14 October accepts a derived-only baseline for Subaru staging. It covers all 397 retained cars, 383 unchanged non-Polestar cars, all 14 research fields, 3,432 sources, all five original Subaru files, 14 actual Polestar packs, exact portable results, the complete 27,393-row actual feature population, and complete reports compared separately for 14 and 15 October. All planned measured phases passed. The original accepted index and receipt are retained byte-for-byte, with their complete source-transition and historical-input lineage.

These checks execute real consumer and report functions over proven retained values. They do not establish a new successful full catalogue hydration, full current TypeScript check or normal top-level report execution.

## What remains open

- Fresh full-loader/equality verification
- Current complete TypeScript check
- Normal top-level report execution
- Subaru final candidate/canonical fixture review, staged checks and root registration
- Full aggregate tests, build, mobile/browser QA and publication

Subaru remains unintegrated in this cut. The ten retained staging-plan files are syntax-only drafts; they have not built a candidate, canonical fixture or staged packet. Their historical status was written before final derived acceptance and is superseded only as to that baseline acceptance, not as to execution. The accepted derived baseline permits preparation and independent review under the separately approved staging plan; it does not authorize registry changes or publication. M1 and the unresolved research census gaps remain open.

## Interrupted and recovered output

Both feature JSONL files are retained in full. The original 20,700-row output has an unrecoverable session and no terminal receipt. Its exact bytes remained unchanged and were independently proved a prefix of the complete 27,393-row recovery output. It is not a successful phase. Preserve process-visibility-correction.json with the original interruption observation: a separate process listing did not conclusively prove process termination. No exit code, signal or cause is inferred.

The separately named recovery output has its own measured successful terminal, complete index and receipt. Retain all earlier script versions, attempts, corrections and provenance. No original local file or existing Library backup is deleted or replaced.

## Restore and continue

Use the accompanying working recovery index and manifest with the retained standalone verifier to restore into a new empty directory. For the last passed application source, choose the separate Polestar recovery instead.

The authoritative 65,021,562-byte cars JSONL and 14 research fields are already in the reused safe chain. The accepted derived index points to their exact paths/hashes; no duplicate full exports are needed. The prior three optional car-prefix reconstruction mappings and their non-overwriting helper remain available in working-safety-support. Those optional copies are outside the normal restored-file count.

Read subaru-derived-proof-plan/accepted-derived-index.json and derived-baseline-acceptance.json, then subaru-staging-plan/STAGING-STATUS.json and its reviewed planning material. Resolve historical absolute workspace or /tmp references to the corresponding restored root. The project directory is roadmark, and the QA directory is roadmark-104-qa.

Schedule resource-intensive commands one at a time. Standard project gates include `pnpm typecheck`, `pnpm validate`, `pnpm report:coverage --as-of 2026-10-15`, `pnpm lint`, `pnpm test` and `pnpm build`; these commands are not claimed to pass for this working cut. Keep the distinct 14/15 October report references and do not normalize dates away. Follow the accepted staging plan and obtain final integration approval before registry changes.

Exact archive preservation and privacy scans do not establish these still-open application gates. The final index records the completed preservation checks separately.
