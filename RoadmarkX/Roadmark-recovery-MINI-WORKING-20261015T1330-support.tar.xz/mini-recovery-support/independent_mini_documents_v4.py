#!/usr/bin/env python3
"""Independent document, native persistence and append-only closure assertions."""
import resource
import sys
import time
import traceback
from delivery_common_v4 import *

NAMES = {'documents': 'INDEPENDENT-DELIVERY-DOCUMENT-CHECK.json',
         'active': 'INDEPENDENT-ACTIVE-RECEIPT-CHECK.json',
         'persisted-active': 'INDEPENDENT-PERSISTED-ACTIVE-CHECK.json',
         'terminal': 'INDEPENDENT-MINI-TERMINAL-CLOSURE-v1.json'}

def check_ref(value):
    path = pathlib.Path(value['path'])
    if not path.is_absolute():
        path = C / path
    check(path, value)

def verify_support_scripts():
    package = load(C / 'support-package.json')
    members = file_map(package['memberFiles'])
    for name in DELIVERY_SCRIPTS:
        check(C / name, members['mini-recovery-support/' + name])
    return {'archive': package['filename'], 'scripts': len(DELIVERY_SCRIPTS), 'noExecutableSourceTextEmbedded': True}

def bind_seed_terminals():
    terminals = []
    for path in sorted(C.glob('*.resources.json')):
        value = load(path)
        if any(pathlib.Path(part).name.startswith(('privacy_v', 'scan_documents_v')) and str(part).endswith('.py')
               for part in value.get('command', [])):
            terminals.append((path, value))
    rows = []
    for kind, summary in seed_summary().items():
        if kind == 'inheritedLocal':
            continue
        for row in summary['receiptReferences']:
            when = datetime.datetime.fromisoformat(row['completedAt'])
            matches = [(path, value) for path, value in terminals if value['childPid'] == row['processId'] and
                       datetime.datetime.fromisoformat(value['startedAt']) <= when <= datetime.datetime.fromisoformat(value['endedAt'])]
            ck(len(matches) == 1, 'seed receipt lacks one exact terminal interval')
            path, value = matches[0]
            if kind == 'deepal':
                ck(any(pathlib.Path(part).name in ('privacy_v3.py', 'privacy_v4.py', 'privacy_v6_support.py', 'scan_documents_v4.py') for part in value['command']),
                   'Deepal seed bound to a pre-adapter scan')
            invocation_path = path.with_name(path.stem + '.invocation.json')
            invocation = load(invocation_path)
            ck(value['command'] == invocation['command'] and value['childPid'] == invocation['childPid'] and
               value['addressSpaceLimitBytes'] == invocation['addressSpaceLimitBytes'] == LIMIT and
               value['wallLimitSeconds'] == invocation['wallLimitSeconds'] == 600,
               'seed scanner invocation/terminal contract differs')
            ck(value['exitCode'] in (0, 2) and not value['timedOut'], 'partial failed seed invocation requires separate reviewed accounting')
            if kind == 'historical':
                ck(load(C / row['path'])['memberIdentityListPin'] == pin(C / 'SEED-PROVENANCE.json'), 'seed provenance pin differs')
            rows.append({'kind': kind, 'receipt': row['path'], 'terminal': ref(path),
                         'exitCode': value['exitCode'], 'timedOut': value['timedOut']})
    return rows

def documents():
    plan, base, prior = load(C / 'RESTORE-PLAN.json'), load(BASE_MANIFEST), load(BASE_TERMINAL)
    inventory, author_acceptance = author_inputs()
    scope, contract = load(C / 'FROZEN-CAPTURE-SCOPE.json'), load(C / 'APPLICATION-ASSERTION-CONTRACT.json')
    ck(scope['authorRetention'] == inventory and len(scope['files']) == 537, 'current frozen inventory differs')
    dependency = load(C / DEPENDENCY)
    manifest, verification = load(DOCS[1]), load(DOCS[2])
    ck([row['local_path'] for row in load(C / 'library-documents-request.json')['uploads']] == [str(path) for path in DOCS],
       'document request order differs')
    ck(manifest['schemaVersion'] == verification['schemaVersion'] == 8, 'document schema differs')
    archives = final_archives(plan)
    ck(manifest['archivesInRestoreOrder'] == archives and manifest['newArchives'] ==
       [row for row in archives if row.get('new')], 'native archive chain differs')
    ck(manifest['files'] == plan['files'] and len(file_map(manifest['files'])) == plan['logicalFiles'], 'logical file map differs')
    counts = {key: plan[key] for key in COUNT_KEYS}
    ck(manifest['incrementalVerification'] == verification['counts'] == counts and
       counts['baseArchivesReused'] == 128 and counts['fullSourceFiles'] == 691, 'counts differ')
    source = next(row for row in archives if row['group'].startswith('source-'))
    ck(manifest['source'] == verification['source'] == source and source['bytes'] < 15000000, 'source differs or exceeds limit')
    support = next(row for row in archives if row.get('new') and row['filename'].endswith('-support.tar.xz'))
    ck(manifest['supportArchive']['archive'] == verification['supportArchive'] == support and
       manifest['supportArchive']['members'] == load(C / 'support-package.json')['memberFiles'], 'support identity differs')
    check_ref(manifest['supportArchive']['reuseMapping'])
    ck(manifest['baseRecovery']['manifestLibraryFileId'] == prior['manifestLibraryFileId'] and
       manifest['baseRecovery']['indexLibraryFileId'] == prior['indexLibraryFileId'] and
       manifest['baseRecovery']['activeReceiptLibraryFileId'] == prior['activeReceiptLibraryFileId'] and
       manifest['baseRecovery']['manifest'] == {'library_file_id': prior['manifestLibraryFileId'], **pin(BASE_MANIFEST)},
       'base native identity differs')
    ck(manifest['baseRecovery']['terminalReceiptPin'] == pin(BASE_TERMINAL) and
       manifest['baseRecovery']['archives'] == len(base['archivesInRestoreOrder']) == 129 and
       manifest['baseRecovery']['logicalFiles'] == len(base['files']) == 12076 and
       manifest['baseRecovery']['unchangedArchivesReused'] == 128, 'base terminal/counts differ')
    for key in INHERIT_KEYS:
        ck(manifest[key] == base[key], 'inherited sanitation/exclusion field differs: ' + key)
    ck(manifest['inheritedCopyOnlySanitation'] == base['inheritedCopyOnlySanitation'] +
       [{'cut': 'Deepal', 'mapping': base['copyOnlySanitation']}], 'inherited copy sanitation chain differs')
    ck(manifest['inheritedCurrentRawCaptureReplayLimitation'] == base['currentRawCaptureReplayLimitation'] and
       manifest['inheritedCurrentCopySourcePinReferenceCounts'] == base['inheritedCurrentCopySourcePinReferenceCounts'], 'inherited raw-pin limitations differ')
    ck(manifest['inheritedLinkAndDuplicateScope'] == {'priorManifest': manifest['baseRecovery']['manifest'],
        'priorSymlinkReconstructionPointer': '/symlinkReconstruction',
        'priorInheritedScopePointer': '/inheritedLinkAndDuplicateScope'}, 'inherited link references differ')
    sanitation_path, sanitation = replay_metadata('copySanitation')
    proof_path, proof_capture = replay_metadata('proofCapture')
    ck(manifest['copyOnlySanitation'] == sanitation and
       manifest['symlinkReconstruction'] == load(C / 'SYMLINK-RECONSTRUCTION.json'), 'current transformation/link map differs')
    ck(manifest['copyOnlySanitationReference'] == verification['copyOnlySanitationReference'] == ref(sanitation_path) and
       manifest['currentProofCapture'] == {'receipt': ref(proof_path), 'selectedOriginalFiles': len(proof_capture['files']),
                                         'newDeltaFiles': len(proof_capture['changedFiles'])} and
       manifest['currentRawCaptureReplayLimitation'] == verification['currentRawCaptureReplayLimitation'] ==
       'Sanitized copied bytes verify retained hashes only; they cannot silently satisfy original raw expected pins. Original files and expected raw pins remain unchanged.',
       'selected final sanitation/proof binding or raw-pin limitation differs')
    adapter, deepal_counters, unused = deepal_adapter()
    classified = load(adapter['classification']['path'])
    expected_review = {'classification': adapter['classification'], 'additiveInventory': adapter['additiveInventory'],
                       'summary': classified['summary'], 'knownValueSearchCounts': deepal_counters,
                       'pinReferencedCopiedFiles': sum(bool(row['sourcePinReferences']) for row in classified['files']),
                       'originalDetectorCoverageGap': classified['originalDetectorCoverageGap'],
                       'fourHTMLFactualProjectionsUnchanged': all(row['visibleFactualTextUnchanged'] for row in classified['files'] if row['format'] == 'html'),
                       'oneJSONOpaqueQueryOnly': all(row['jsonStructureAndOtherValuesUnchanged'] and
                                                    [leaf['pointer'] for leaf in row['changedJSONLeaves']] == ['/scripts/24'] and
                                                    all(leaf['onlyApprovedOpaqueValueReplacements'] for leaf in row['changedJSONLeaves'])
                                                    for row in classified['files'] if row['format'] == 'json'),
                       'genericDecodedCoverageClaimed': False, 'universalAbsenceClaimed': False}
    ck(manifest['deepalSanitationReview'] == verification['deepalSanitationReview'] == expected_review and
       expected_review == base['deepalSanitationReview'] and expected_review['fourHTMLFactualProjectionsUnchanged'] and expected_review['oneJSONOpaqueQueryOnly'],
       'copy-parity, original detector gap or final classification summary differs')
    mapping = manifest['inheritedDependencyReconstruction']
    ck(mapping['dependencies'] == dependency['dependencies'] and mapping['count'] == dependency['count'] == len(dependency['dependencies']) and
       mapping['relocatedMemberPointers'] == dependency['relocatedMemberPointers'] and
       mapping['newRecords'] == dependency['newRecords'] and mapping['originalExpectedPathsAndHashesUnchanged'],
       'dependency reconstruction differs')
    canonical = hashlib.sha256(json.dumps(mapping['dependencies'], sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    ck(canonical == mapping['dependenciesCanonicalSha256'] == dependency['dependenciesCanonicalSha256'], 'dependency canonical hash differs')
    ck(manifest['authorFinalAcceptance'] == verification['authorFinalAcceptance'] == {'path': str(AUTHOR_ACCEPTANCE), **AUTHOR_ACCEPTANCE_PIN}, 'author final acceptance identity differs')
    check_ref(mapping['receipt'])
    ck(dependency_summary(dependency) == {key: mapping[key] for key in ('receipt', 'count', 'relocatedMemberPointers', 'newRecords')}, 'dependency summary differs')
    ck(verification['dependencyMapping'] == mapping['receipt'] and verification['dependencyCount'] == dependency['count'] and
       verification['dependencyRelocations'] == dependency['relocatedMemberPointers'], 'verification dependency summary differs')
    state = manifest['workState']
    ck(verification['workState'] == state and manifest['status'] == verification['status'] == scope['workingResult'], 'working status differs')
    expected_summary = {'scopedTests': 151, 'fullProjectTypeScriptRoots': 361,
                        'normalReportRuns': 1, 'retainedExecutedFailureBoundaries': 1,
                        'previewScreenshots': 0, 'mobilePassClaimed': False}
    ck(all(contract['summary'].get(key) == value for key, value in expected_summary.items()), 'MINI application summary differs')
    for key, value in contract['summary'].items():
        ck(state[key] == value, 'document application fact differs: ' + key)
    ck(state['currentCounts'] == {'catalogue': 427, 'tier1': 350, 'onSale': 309, 'packets': 27} and
       state['historicalDeepalPreview'] == {'compactReceipts': 6, 'browserOutcome': 'Cloud-browser loopback reachability refused', 'notMINIVisualQA': True} and
       state['miniVisualQAPassed'] is False and state['otherAttemptHistory'] == inventory['otherAttemptHistory'], 'counts/attempt/preview boundary differs')
    ck(state['registered'] and state['integrationIndependentlyAccepted'] and state['targetedCountsNotClaimedDisjoint'] and
       state['fullProjectTypeScriptPassed'] and state['structuralValidationPassed'] and state['strictSavedReportComparisonPassed'],
       'accepted scope facts differ')
    ck(all(state[key] is False for key in ('fullProjectSuitePassed', 'buildPassed', 'mobilePassed', 'releaseReady', 'published')) and
       state['milestone'] == 'M1 open' and state['openGates'] == verification['openGates'] == scope['openGates'], 'open gates falsely closed')
    ck(state['failedAttempts'] == scope['authorRetention']['retainedFailures'] and
       state['authorFreezeAt'] == scope['authorRetention']['frozenAt'], 'retained failures/freeze differs')
    ck(manifest['sourceChangedPaths'] == verification['sourceChangedPaths'] == scope['sourceChangedPaths'] and
       len(scope['sourceChangedPaths']) == 6, 'source delta differs')
    recovery, gate = load(C / RECOVERY), load(C / GATE)
    ck(recovery['result'] == gate['result'] == 'PASS', 'fresh recovery/privacy did not pass')
    application = recovery['application']
    ck(application['assertionCount'] == len(contract['assertions']) == 187 and
       application['freshArchiveAssertions'] == 183 and application['exactInheritedAssertions'] == 4 and
       application['freshArchiveAssertions'] + application['exactInheritedAssertions'] == application['assertionCount'] and
       application['mandatoryRetainedPins'] == len(contract['retainedPins']) == 149 and
       recovery['overlay']['inheritedPayloadReadsByIndependentVerifier'] == 0,
       'fresh/inherited application assertion qualification differs')
    inherited_application_contract = {'path': str(BASE / 'APPLICATION-ASSERTION-CONTRACT.json'),
        'bytes': 49243, 'sha256': '9b32dc6a763f27c08cd450bdf39ab04dd9deff5d7bea4819f9d1a98cd9753134'}
    inherited_application_replay = {'path': str(BASE / 'INDEPENDENT-DEEPAL-RECOVERY-VERIFICATION-v1.json'),
        'bytes': 65044, 'sha256': 'c8738baae2cb2b29ca4cf300d5e39934f64db17ebdb7ac4ca01cf5c5cb6191de'}
    ck(application['inheritedAssertionContract'] == inherited_application_contract and
       application['inheritedAssertionReplay'] == inherited_application_replay,
       'inherited application proof identities differ')
    for inherited_pin in (inherited_application_contract, inherited_application_replay):
        check(inherited_pin['path'], inherited_pin)
    ck(load(inherited_application_replay['path'])['result'] == 'PASS', 'inherited application replay did not pass')
    application_assertion_scope = {
        'totalAssertions': 187, 'freshArchiveAssertions': 183, 'exactInheritedAssertions': 4,
        'mandatoryRetainedPins': 149,
        'inheritedAssertionContract': inherited_application_contract,
        'inheritedAssertionReplay': inherited_application_replay,
        'inheritedPayloadReadsByIndependentVerifier': 0,
        'qualification': 'Four historical Deepal visual-blocker assertions reuse the exact prior accepted contract, PASS replay and unchanged retained member hash. They are not fresh MINI visual assertions.'}
    independent = manifest['independentVerification']
    ck(independent == verification['independentVerification'] and independent['result'] == 'PASS' and
       independent['receipt'] == ref(C / RECOVERY) and independent['applicationAssertionCount'] == len(contract['assertions']) and len(contract['assertions']) > 0 and
       independent['mandatoryRetainedPins'] == len(contract['retainedPins']) and len(contract['retainedPins']) > 0 and
       independent['applicationAssertionScope'] == application_assertion_scope and
       independent['freshMembers'] == plan['freshFiles'] and independent['freshBytes'] == plan['freshBytes'] and
       independent['freshArchiveCount'] == len(plan['newArchives']) and independent['archiveStreamsVerifiedThroughXZEOF'], 'fresh verification summary differs')
    ck(independent['recoverableReceipt'] == {'document': DOCS[2].name, 'jsonPointer': '/postSealReceipts/0'},
       'recoverable independent receipt pointer differs')
    ck(independent['recoverableInputManifest'] == {'document': DOCS[2].name, 'jsonPointer': '/postSealReceipts/2'},
       'recoverable pinned replay-input manifest pointer differs')
    for key, name in [('inputManifest', 'INDEPENDENT-MINI-REPLAY-INPUTS-v1.json'),
                      ('memberReplayManifest', 'INDEPENDENT-NEW-MEMBER-REPLAY-MANIFEST-v1.json'),
                      ('applicationContract', 'APPLICATION-ASSERTION-CONTRACT.json')]:
        ck(independent[key] == ref(C / name), 'verification evidence pin differs')
    privacy_summary = manifest['privacyVerification']
    ck(privacy_summary['recoverableReceipt'] == {'document': DOCS[2].name, 'jsonPointer': '/postSealReceipts/1'},
       'recoverable privacy receipt pointer differs')
    ck(privacy_summary == verification['privacyVerification'] and privacy_summary['receipt'] == ref(C / GATE) and
       privacy_summary['result'] == 'PASS' and privacy_summary['freshMembers'] == gate['freshMembers'] == plan['freshFiles'] and
       privacy_summary['freshBytes'] == gate['freshBytes'] == plan['freshBytes'] and
       privacy_summary['unclassifiedFindings'] == gate['unclassifiedFindings'] == 0 and privacy_summary['errors'] == gate['errors'] == 0,
       'privacy summary differs')
    ck(privacy_summary['rawScannerResultsModified'] == gate['rawScannerResultsModified'] is False and
       privacy_summary['classificationCounts'] == {key: value for key, value in gate.items() if
                                                    isinstance(value, int) and ('Candidate' in key or 'Collision' in key)} and
       privacy_summary['rawArchiveOutcomes'] == [{'archive': row['archive'], 'rawScannerStatus': row['rawScannerStatus'],
                                                 **{key: value for key, value in row.items() if
                                                    isinstance(value, int) and ('Candidate' in key or 'Collision' in key)}}
                                                for row in gate['archives']], 'raw scan/adjudication disclosure differs')
    ck(privacy_summary['supportOnlySyntaxClassification'] == support_privacy_scope(gate, recovery), 'support-only syntax disclosure differs')
    ck(verification['inheritedLocalSeedExecutionsAtFreshVerification'] == recovery['inheritedLocalSeedExecutions'],
       'fresh-verification inherited local seed accounting differs')
    images = load(C / 'IMAGE-PROVENANCE-v2.json')
    ck(manifest['currentImageProvenance'] == verification['imageProvenance'] == images and len(images['files']) == 3 and
       images['noNewRenderPerformed'], 'image provenance differs')
    ck(manifest['inheritedImageProvenance'] == {'priorManifest': manifest['baseRecovery']['manifest'], 'jsonPointer': '/currentImageProvenance'}, 'inherited image provenance differs')
    ck(manifest['inheritedDeepalCopySourcePinReferenceCounts'] == {'copiedFiles': expected_review['pinReferencedCopiedFiles'], 'references': expected_review['summary']['sourcePinReferences']}, 'inherited Deepal source-pin counts differ')
    logical = file_map(manifest['files'])
    for row in images['files']:
        ck(logical[row['image']['path']] == row['image'] and logical[row['parentPDF']['path']] == row['parentPDF'] and
           row['browserScreenshot'] is False and row['PDFPageOneBased'] == 4, 'image/PDF member mapping differs')
    ck(manifest['deepalSanitizedSupport'] == verification['deepalSanitizedSupport'] == base['deepalSanitizedSupport'] and
       manifest['miniFactualCaptureProvenance'] == verification['miniFactualCaptureProvenance'] == inventory['knownSanitizedSupport'] and
       manifest['currentExcludedItems'] == scope['authorRetention']['excluded'] and
       manifest['rawDeepalOriginalReadRecoveryRefetchForbidden'] and verification['rawDeepalOriginalReadRecoveryRefetchForbidden'], 'Deepal raw-body restriction differs')
    ck(manifest['factualSummary'] == {'filename': DOCS[3].name, 'sourceMember': 'roadmark/docs/MINI_M1_UPDATE.md',
                                    'bytes': 5601, 'sha256': '2b9edee6cfc1ee6a46245e9a73e50488c2b2512746fb8890ffe46615bf7010c2',
                                    'copiedExactly': True}, 'factual summary reference differs')
    check(DOCS[3], manifest['factualSummary'])
    ck(verification['manifest'] == {'filename': DOCS[1].name, **pin(DOCS[1])}, 'verification manifest binding differs')
    index = DOCS[0].read_text()
    ck(f"Recommended chain: {len(archives)} archives, {plan['logicalFiles']:,} logical files" in index, 'index count differs')
    for row in archives:
        exact = f"{row['restoreOrder']}. {row['filename']} | {row['library_file_id']} v{row['version']} | {row['bytes']} bytes | SHA-256 {row['sha256']}"
        ck(index.count(exact) == 1, 'index exact archive row absent/duplicated')
    for phrase in ('Exactly two AST-bound noncredential syntax candidates', 'missing, duplicate or unexpected findings block',
                   'original privacy_v4 scanner remains unchanged',
                   '187 assertions: 183 verified against fresh archive bytes and four historical Deepal visual-blocker assertions',
                   'independent verifier reread zero inherited payloads', 'Those four assertions are not fresh MINI visual QA',
                   '151 fresh scoped', 'One actual selected-preflight-v2 failure', 'held unexecuted preparations, not runtime failures',
                   'Zero MINI UI screenshots', 'full-base rescan', 'must never be read, recovered or refetched',
                   f"{dependency['count']} exact dependency reconstruction records", 'strict M1 closure and release remain open',
                   'not a new MINI field inventory', 'Original rendering command, version and DPI were not retained and remain unknown'):
        ck(phrase in index, 'required index limitation absent')
    for phrase in (classified['originalDetectorCoverageGap'], 'exact two-shape raw-byte inventory',
                   'generic arbitrary-decoding coverage is not claimed',
                   f"{deepal_counters['deepalRuntimeValues']} distinct values and {deepal_counters['deepalRuntimeForms']} supported forms"):
        ck(phrase in index, 'final Deepal search limit disclosure absent')
    seeds = manifest['targetedHistoricalSeedReadDependency']
    ck(seeds['scope'] == load(C / 'TARGETED-SEED-READ-DEPENDENCY.json') and
       seeds['executionsAsOfBuild'] == verification['targetedSeedExecutionsAsOfBuild'], 'seed disclosure differs')
    seed_counts = check_seed_summary(seeds['executionsAsOfBuild'])
    retained_receipts = check_post_seal_receipts(verification['postSealReceipts'])
    ck(verification['miniPrivacyAdapter'] == ref(C / 'MINI-PRIVACY-ADAPTER-CONTRACT.json'),
       'verification privacy adapter differs')
    no_embedded_source(manifest)
    no_embedded_source(verification)
    return {'result': 'PASS', 'documents': [{'filename': path.name, **pin(path)} for path in DOCS],
            'recommendedArchives': len(archives), 'logicalFiles': plan['logicalFiles'], 'freshMembers': plan['freshFiles'],
            'privacyGate': privacy('DELIVERABLE-PRIVACY-GATE.json', DOCS), 'seedCountsAsOfDocumentBuild': seed_counts,
            'inheritedSanitationAndExclusionsPreserved': True, 'dependencies': dependency['count'], 'dependencyRelocations': dependency['relocatedMemberPointers'],
            'sourceSummaryCopiedExactly': True, 'noExecutableSourceTextEmbedded': True,
            'recoverablePostSealReceipts': retained_receipts,
            'noArchivePayloadReread': True, 'broaderReleaseGatesRemainOpen': True}

def active(persisted=False):
    manifest, value = load(DOCS[1]), load(ACTIVE)
    for key in ('status', 'source', 'newArchives', 'baseRecovery', 'workState', 'verificationScope', 'independentVerification'):
        ck(value[key] == manifest[key], 'active/manifest differs: ' + key)
    ck(value['counts'] == manifest['incrementalVerification'] and value['archivePrivacyGate'] == manifest['privacyVerification'] and
       value['supportArchive'] == manifest['supportArchive']['archive'], 'active summary differs')
    docs = native('documents')
    ck(value['documents'] == docs and value['manifest'] == next(row for row in docs if row['filename'] == DOCS[1].name), 'active document identities differ')
    ck(value['verificationDocument'] == next(row for row in docs if row['filename'] == DOCS[2].name) and
       value['recoverablePostSealReceiptPointers'] == ['/postSealReceipts/0', '/postSealReceipts/1', '/postSealReceipts/2'],
       'active recoverable verification references differ')
    review = load(C / 'INDEPENDENT-DELIVERY-DOCUMENT-CHECK.json')
    ck(review['result'] == 'PASS' and review['documents'] == [{'filename': path.name, **pin(path)} for path in DOCS], 'approved document bytes differ')
    ck(value['preSaveDocumentVerification'] == {'result': 'PASS', 'receipt': ref(C / 'INDEPENDENT-DELIVERY-DOCUMENT-CHECK.json')} and
       value['documentPrivacyGate'] == {'result': 'PASS', 'receipt': privacy('DELIVERABLE-PRIVACY-GATE.json', DOCS)}, 'active document evidence differs')
    ck(value['inheritedDependencyReconstruction'] == dependency_summary(load(C / DEPENDENCY)), 'active dependencies differ')
    for key in ('rawDeepalOriginalReadRecoveryRefetchForbidden', 'allInheritedSanitationExclusionsPreservedInManifest',
                'noSourceOrStatusMutationByBackup', 'noDeletionOrReplacement', 'noExecutableSourceTextEmbedded'):
        ck(value[key] is True, 'active preservation claim absent')
    ck(value['savingAnnouncement'] == saving_announcement(), 'active saving announcement differs')
    no_embedded_source(value)
    result = {'result': 'PASS', 'activeReceipt': pin(ACTIVE), 'documents': docs,
              'recommendedArchives': value['counts']['archiveCount'], 'logicalFiles': value['counts']['logicalFiles'],
              'activePrivacyGate': privacy('ACTIVE-PRIVACY-GATE.json', [ACTIVE]),
              'seedCountsAsOfActiveBuild': check_seed_summary(value['seedReadExecutionsAsOfBuild']),
              'noArchivePayloadReread': True, 'broaderReleaseGatesRemainOpen': True}
    if persisted:
        before = load(C / 'INDEPENDENT-ACTIVE-RECEIPT-CHECK.json')
        ck(before['result'] == 'PASS' and before['activeReceipt'] == pin(ACTIVE), 'persisted active bytes differ')
        rows = native('active')
        ck(len(rows) == 1 and rows[0]['filename'] == ACTIVE.name, 'persisted active native identity differs')
        result.update(persistedActive=rows[0], preSaveCheck=ref(C / 'INDEPENDENT-ACTIVE-RECEIPT-CHECK.json'))
    return result

def closure():
    target = C / 'FINAL-MINI-UPLOAD-RECEIPTS.json'
    earlier = C / 'FINAL-MINI-UPLOAD-RECEIPTS-before-persistence-check.json'
    final, previous, manifest = load(target), load(earlier), load(DOCS[1])
    allowed = {'createdAt', 'delivery', 'deliveryConfirmation', 'activePersistenceCheck'}
    ck({key: value for key, value in final.items() if key not in allowed} ==
       {key: value for key, value in previous.items() if key not in allowed}, 'terminal append changed immutable fields')
    archive_pins = {row['filename']: {key: row[key] for key in ('bytes', 'sha256')} for row in manifest['newArchives']}
    archives, docs, active_rows = native('archives', archive_pins), native('documents'), native('active')
    ck(final['files'] == archives + docs + active_rows and len(active_rows) == 1 and len(docs) == 4, 'terminal native set differs')
    wanted = {'source': manifest['source']['library_file_id'],
              **{key: next(row['library_file_id'] for row in docs if row['filename'] == path.name)
                 for key, path in zip(('index', 'manifest', 'verification', 'summary'), DOCS)}}
    delivery = load(C / 'DELIVERY-CONFIRMATION.json')
    ck(delivery['libraryFileIds'] == wanted and delivery['channel'] == 'chatgpt' and delivery['messageId'] and delivery['sentAt'] and
       delivery['acceptedSendDoesNotProveOpened'], 'accepted delivery identity differs')
    ck(final['deliveryConfirmation'] == {'receipt': ref(C / 'DELIVERY-CONFIRMATION.json'), **delivery} and
       final['activePersistenceCheck'] == {'result': 'PASS', 'receipt': ref(C / 'INDEPENDENT-PERSISTED-ACTIVE-CHECK.json')}, 'terminal closure refs differ')
    persisted = load(C / 'INDEPENDENT-PERSISTED-ACTIVE-CHECK.json')
    ck(persisted['result'] == 'PASS' and persisted['persistedActive'] == active_rows[0], 'persisted active check differs')
    for key, field in [('source', 'sourceLibraryFileId'), ('index', 'indexLibraryFileId'), ('manifest', 'manifestLibraryFileId'),
                       ('verification', 'verificationLibraryFileId'), ('summary', 'summaryLibraryFileId')]:
        ck(final[field] == wanted[key], 'terminal primary native ID differs')
    ck(final['activeReceiptLibraryFileId'] == active_rows[0]['library_file_id'] and
       final['archiveLibraryFileIds'] == [row['library_file_id'] for row in archives], 'terminal archive/active IDs differ')
    for phase in ('archives', 'documents', 'active'):
        for value in final['phaseReferences'][phase].values():
            check_ref(value)
    no_embedded_source(final)
    return {'result': 'PASS_TERMINAL_RECOVERY_CLOSURE', 'currentFinalReceipt': pin(target),
            'preservedInitialFinalReceipt': pin(earlier), 'persistenceCheck': ref(C / 'INDEPENDENT-PERSISTED-ACTIVE-CHECK.json'),
            'newNativeFiles': len(final['files']), 'recommendedArchives': len(manifest['archivesInRestoreOrder']),
            'logicalFiles': len(manifest['files']), 'sourceLibraryFileId': wanted['source'], 'activeReceipt': active_rows[0],
            'acceptedDelivery': {'receipt': ref(C / 'DELIVERY-CONFIRMATION.json'), 'messageId': delivery['messageId'],
                                 'sentAt': delivery['sentAt'], 'libraryFileIds': wanted},
            'targetedSeedReadExecutions': check_seed_summary(final['targetedSeedReadExecutionSummary'], complete=True),
            'changedFinalReceiptFieldsOnly': sorted(key for key in set(final) | set(previous) if final.get(key) != previous.get(key)),
            'noArchivePayloadReadsOrUploadsOrDeletion': True, 'broaderApplicationReleaseGatesRemainOpen': True}

def main():
    started = time.monotonic()
    mode = sys.argv[1]
    ck(mode in NAMES, 'unknown check mode')
    output = C / NAMES[mode]
    ck(not output.exists(), 'preserve prior result; use a separately reviewed retry')
    code = 0
    try:
        ck('--sole-child-slot-authorized' in sys.argv and resource.getrlimit(resource.RLIMIT_AS) == (LIMIT, LIMIT),
           'sole-slot 256 MiB verification contract absent')
        retained = verify_support_scripts()
        result = documents() if mode == 'documents' else active(mode == 'persisted-active') if mode in ('active', 'persisted-active') else closure()
        result['supportScriptBinding'] = retained
        result['seedTerminalBindings'] = bind_seed_terminals()
    except BaseException as error:
        code = 1
        result = {'result': 'BLOCKED', 'blocker': {'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()}}
    result.update(checkedAt=now(), verifierScript=pin(pathlib.Path(__file__)),
                  resources={'wallSeconds': round(time.monotonic() - started, 3),
                             'maxRssKiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                             'addressSpaceLimitBytes': resource.getrlimit(resource.RLIMIT_AS)[0], 'chunkBytes': CHUNK})
    dump(output, result)
    print(json.dumps({'mode': mode, 'result': result['result'], 'blocker': result.get('blocker'), 'resources': result['resources']}))
    raise SystemExit(code)

if __name__ == '__main__':
    main()
