from capture_v2 import *
inventory=P('/tmp/mini-packet/final-freeze-v1/inventory.json')
check(inventory,{'bytes':145241,'sha256':'320ae09e676a2166039cd574b2f32e1b481f12a71dc192cc4feeaa98997ede4e'})
v=load(inventory)
assert v['noFurtherPayloadEdits'] and v['metadataOnlyInventory'] and not v['contentCaptureOrPrivacyScanPerformed']
assert v['totalFiles']==len(v['files'])==534 and v['symlinkCount']==0
assert sum(r['bytes'] for r in v['files'])==v['regularFileBytes']==63855881
review=P('/tmp/mini-review/final-retention-v1-acceptance.json')
reviewPin={'bytes':5168,'sha256':'83384b36822ebce9df12628b52f1c69e173b00419fc33411bb1807c99f5ca353'}
check(review,reviewPin)
assert load(review)['status']=='accepted'
files={}
for row in v['files']:
 p=P(row['path']);ident=identity(p)
 assert row['kind']=='file' and ident[0]==row['bytes'] and ident[1]==row['mtimeNs']
 assert str(p) not in files
 files[str(p)]={'path':str(p),'bytes':ident[0],'mtimeNsAtFreeze':ident[1]}
pins=v['sourceAndStatusAfterPins']+[v['independentDocsReadback'],v['finalRuntimeAcceptance'],v['publicImageProvenance'],v['knownSanitizedSupport']['sourceEvidenceManifest'],v['knownSanitizedSupport']['anonymousRequestReceipts']]
assert len(v['sourceAndStatusAfterPins'])==7
for row in pins:
 p=P(row['path']);got,ident=check(p,row)
 assert str(p) in files and files[str(p)]['mtimeNsAtFreeze']==ident[1]
 files[str(p)].update(got)
for row in [{'path':str(inventory),**pin(inventory)},v['preparer'],{'path':str(review),**reviewPin}]:
 p=P(row['path']);got,ident=check(p,row);assert str(p) not in files
 files[str(p)]={'path':str(p),**got,'mtimeNsAtFreeze':ident[1]}
assert len(files)==537
for row in v['excluded']:assert row['path'] not in files
changed=sorted(P(row['path']).relative_to(W/'roadmark-104').as_posix() for row in v['sourceAndStatusAfterPins'] if P(row['path']).is_relative_to(W/'roadmark-104'))
assert len(changed)==6
pack=module('packager',W/'roadmark-104/scripts/package-source.py');sourceFiles=list(pack.source_files(W/'roadmark-104'))
assert len(sourceFiles)==691
base=load(BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-DEEPAL-WORKING-20261015.json');old={r['path']:r for r in base['files']}
overlay=sorted(restpath(P(p)) for p in files if restpath(P(p)) in old and not restpath(P(p)).startswith('roadmark/'))
previewNames=['launch-receipt.json','market-check.log','server.log','snapshot-manifest.json','stop-receipt.json','visual-qa-blocker-receipt.json']
previewPaths=['roadmark-104-visual-qa-20261015/'+n for n in previewNames]
assert overlay==sorted(['roadmark-104-qa/work-status.json']+previewPaths)
reusedPreview=[]
for n in previewPaths:
 p=W/n;got,ident=check(p,old[n]);assert ident[1]==files[str(p)]['mtimeNsAtFreeze']
 files[str(p)].update(got);reusedPreview.append({'originalPath':str(p),'member':n,**got})
overlay=['roadmark-104-qa/work-status.json']
state='Registered MINI 27 working cut; 151 scoped tests (144 behavioural plus 7 safety), full-project cold TypeScript with 361 roots, structural validation and one actual normal report with strict saved-report comparison independently passed. Selected-preflight-v2 failure, held unexecuted v1 preparations, superseded v3 success and current v4/full-stage-v2/comparator-v2 proof remain retained. No helper or test changes in this cut. Full aggregate suite, production build, MINI browser/device visual verification, strict M1 closure and release remain open.'
(C/'WORKING-STATE.txt').open('x').write(state+'\n')
q={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'freezeMetadata':{'path':str(inventory),**pin(inventory)},'authorRetention':v,'authorInventory':{'path':str(inventory),**pin(inventory)},'finalRetentionReview':{'path':str(review),**reviewPin},'roots':v['payloadRoots'],'files':sorted(files.values(),key=lambda x:x['path']),'knownPinsVerified':len({r['path'] for r in pins})+3,'sourceChangedPaths':changed,'expectedSourceFiles':len(sourceFiles),'expectedNonSourceOverlay':overlay,'workingResult':state,'openGates':['M1 strict closure','Full-project aggregate suite','Production build','MINI browser UI and real-device mobile verification','Release/M2'],'scopeMethod':'Exact534-file author inventory plus separately pinned inventory/preparer/final review; no recursive research or broad QA capture','metadataOnlySymlinks':[],'exactBaseReusedPreviewReceipts':reusedPreview,'noDeletion':True,'noSymlinkTraversal':True,'rawDeepalOriginalReadRecoveryRefetchForbidden':True}
dump(C/'FROZEN-CAPTURE-SCOPE.json',q)
print(json.dumps({'files':len(files),'bytes':sum(r['bytes'] for r in files.values()),'sourceFiles':len(sourceFiles),'sourceDeltaPaths':len(changed),'metadataOnlyLinks':0}))
