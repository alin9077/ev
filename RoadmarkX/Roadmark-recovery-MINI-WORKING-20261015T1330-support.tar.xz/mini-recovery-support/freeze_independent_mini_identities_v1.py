#!/usr/bin/env python3
"""Metadata-only selected identity binding; no payload opens."""
import datetime,hashlib,json,pathlib,resource,stat
P=pathlib.Path;C=P(__file__).resolve().parent;LIMIT=268435456
assert resource.getrlimit(resource.RLIMIT_AS)==(LIMIT,LIMIT)
scope_path=C/'FROZEN-CAPTURE-SCOPE.json';b=scope_path.read_bytes();scope=json.loads(b)
rows=[]
for row in scope['files']:
 p=P(row['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents)
 identity=[s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev]
 assert identity[:2]==[row['bytes'],row['mtimeNsAtFreeze']]
 rows.append({'path':str(p),'identity':identity})
assert len(rows)==len({r['path'] for r in rows})==537
q={'result':'PASS_EXACT_537_SELECTED_FILE_INITIAL_IDENTITY_BINDING','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozenScope':{'path':str(scope_path),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'identityFields':['size','mtimeNs','ctimeNs','inode','device'],'atimeExcluded':True,'metadataOnly':True,'payloadFilesOpened':0,'files':rows}
p=C/'INDEPENDENT-MINI-INITIAL-IDENTITIES-v1.json'
with p.open('x') as f:json.dump(q,f,indent=2);f.write('\n')
print(json.dumps({'result':q['result'],'files':len(rows),'payloadFilesOpened':0}))
