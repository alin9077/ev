"""Only the two independently reviewed, approved and exact pinned syntax findings."""
import ast,hashlib,json
from capture_v2 import C,load,check
CLASSIFICATION=C/'INDEPENDENT-MINI-SUPPORT-SYNTAX-CLASSIFICATION-v1.json'
CLASSIFICATION_PIN={'bytes':5561,'sha256':'ea6372b3f27bd1f5959c9332daec49a52e3f56d76f89979b82970cb9432a3fa4'}
def code_context(candidates,data,name):
 approval=load(C/'APPROVED-MINI-SUPPORT-SYNTAX.json')
 assert approval['classificationPin']==CLASSIFICATION_PIN and approval['exactCandidates']==2
 check(CLASSIFICATION,CLASSIFICATION_PIN);d=load(CLASSIFICATION)
 rows=[r for r in d['exactSupportCodeClassifications'] if r['member']==name]
 if not rows:return candidates,[]
 assert len(rows)==2
 actual={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 assert all(r['filePin']==actual for r in rows)
 tree=ast.parse(data);text=data.decode('utf-8');lines=text.splitlines()
 expected=[{k:v for k,v in r['exactFinding'].items() if k!='member'} for r in rows]
 assert len(expected)==len({json.dumps(r,sort_keys=True) for r in expected})
 classified=[];blocked=[]
 for candidate in candidates:
  if candidate not in expected:blocked.append(candidate);continue
  r=rows[expected.index(candidate)]
  assert hashlib.sha256(data[r['byteStart']:r['byteEndExclusive']]).hexdigest()==r['matchedSyntaxSHA256']
  line=candidate['location']['line'];assert hashlib.sha256(lines[line-1].encode()).hexdigest()==r['lineSHA256']
  statements=[n for n in ast.walk(tree) if isinstance(n,ast.stmt) and n.lineno==line and type(n).__name__==r['astStatementType']]
  assert len(statements)==1
  statement=ast.dump(statements[0],include_attributes=False);assert hashlib.sha256(statement.encode()).hexdigest()==r['astStatementSHA256']
  classified.append({'member':name,'filePin':actual,'finding':candidate,'classification':r['classification']})
 assert len(classified)==2 and sorted(json.dumps(r['finding'],sort_keys=True) for r in classified)==sorted(json.dumps(r,sort_keys=True) for r in expected)
 return blocked,classified
