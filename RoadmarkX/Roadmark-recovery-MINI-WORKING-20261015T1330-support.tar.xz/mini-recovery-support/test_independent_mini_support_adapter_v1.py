#!/usr/bin/env python3
"""Exact support-hook positive/fail-closed tests; no scan, secret, archive or live writes."""
import ast,copy,datetime,hashlib,importlib.util,json,pathlib,resource,sys
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent;LIMIT=268435456
assert resource.getrlimit(resource.RLIMIT_AS)==(LIMIT,LIMIT)
def pin(p):
 b=P(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p):return json.loads(P(p).read_bytes())
v4=(C/'privacy_v4.py').read_text();v5=(C/'privacy_v5_support.py').read_text();v6=(C/'privacy_v6_support.py').read_text();h1=(C/'mini_support_classifications_v1.py').read_text();h2=(C/'mini_support_classifications_v2.py').read_text()
insert='from mini_support_classifications_v1 import code_context as mini_code_context;ps,classified=mini_code_context(ps,data,m.name);codeClassified.extend(classified);'
assert v5==v4.replace('us,classified=template_context(us,data,m.name);',insert+'us,classified=template_context(us,data,m.name);')
assert v6==v5.replace('from mini_support_classifications_v1 import','from mini_support_classifications_v2 import')
assert h2==h1.replace('text.splitlines(keepends=True)','text.splitlines()').replace('statement=ast.get_source_segment(text,statements[0]);assert hashlib.sha256(statement.encode()).hexdigest()',"statement=ast.dump(statements[0],include_attributes=False);assert hashlib.sha256(statement.encode()).hexdigest()")
for source in (v4,v5,v6,h1,h2):ast.parse(source)
spec=importlib.util.spec_from_file_location('mini_exact_support_test',C/'mini_support_classifications_v2.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
classification=load(C/'INDEPENDENT-MINI-SUPPORT-SYNTAX-CLASSIFICATION-v1.json');approved=classification['exactSupportCodeClassifications'];member='mini-recovery-support/capture_v2.py';data=(C/'capture_v2.py').read_bytes();candidates=[{k:v for k,v in r['exactFinding'].items() if k!='member'} for r in approved];tests=[]
def passed(name):tests.append({'name':name,'passed':True})
def rejects(name,fn):
 try:fn()
 except AssertionError:passed(name)
 else:raise AssertionError('expected fail-closed rejection: '+name)
blocked,classified=m.code_context(copy.deepcopy(candidates),data,member);assert blocked==[] and len(classified)==2
expected=[{'member':r['member'],'filePin':r['filePin'],'finding':{k:v for k,v in r['exactFinding'].items() if k!='member'},'classification':r['classification']} for r in approved];assert classified==expected;passed('exact approved candidate multiset classified')
extra={'kind':'unexpected-candidate','location':{'pointer':'','line':1,'charStart':0,'charEnd':1},'confidence':'needs-context','header':'x-unreviewed','valueType':'str','valueLength':0};blocked,classified=m.code_context(candidates+[extra],data,member);assert blocked==[extra] and classified==expected;passed('extra candidate remains blocking and unchanged')
rejects('missing candidate rejected',lambda:m.code_context(candidates[:1],data,member))
rejects('duplicate candidate rejected',lambda:m.code_context(candidates+[candidates[0]],data,member))
rejects('wrong whole-file bytes rejected',lambda:m.code_context(candidates,data+b' ',member))
wrong=copy.deepcopy(candidates);wrong[0]['location']['charStart']+=1;rejects('wrong candidate location rejected',lambda:m.code_context(wrong,data,member))
blocked,classified=m.code_context(candidates,data,'mini-recovery-support/not-approved.py');assert blocked==candidates and classified==[];passed('unapproved member receives no exemption')
real_load=m.load
for field,value,label in [('byteStart',approved[0]['byteStart']+1,'wrong span hash rejected'),('lineSHA256','0'*64,'wrong complete-line hash rejected'),('astStatementSHA256','0'*64,'wrong AST hash rejected')]:
 altered=copy.deepcopy(classification);altered['exactSupportCodeClassifications'][0][field]=value
 m.load=lambda p,altered=altered:copy.deepcopy(altered) if P(p)==m.CLASSIFICATION else real_load(p)
 try:rejects(label,lambda:m.code_context(candidates,data,member))
 finally:m.load=real_load
q={'result':'PASS_EXACT_SUPPORT_ONLY_ADAPTER_AND_FAIL_CLOSED_TESTS','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseEngine':pin(C/'privacy_v4.py'),'supportEngine':pin(C/'privacy_v6_support.py'),'supportSyntaxHandler':pin(C/'mini_support_classifications_v2.py'),'classification':pin(C/'INDEPENDENT-MINI-SUPPORT-SYNTAX-CLASSIFICATION-v1.json'),'supportSyntaxApproval':pin(C/'APPROVED-MINI-SUPPORT-SYNTAX.json'),'preservedUnexecutedDrafts':[pin(C/'privacy_v5_support.py'),pin(C/'mini_support_classifications_v1.py')],'testScript':pin(__file__),'tests':tests,'testCount':len(tests),'exactCandidates':2,'rawPrimaryCandidatesRetained':True,'unexpectedCandidatesRemainBlocking':True,'missingDuplicateWrongMemberOrHashCannotBeClassified':True,'engineChange':'Only exact MINI syntax hook call after inherited primary contexts and before lexical collision adjudication; unchanged inherited seeds, detectors, full byte searches and runtime/template handling','correctedRepresentations':'Complete line excludes newline and AST hash uses ast.dump(include_attributes=False), exactly matching independent classification','baseV4SourceProofAndDocumentScansUnchanged':True,'noPayloadRedactions':True,'newBroadExemptions':0,'seedReads':0,'archivePayloadReads':0,'liveSourceWrites':0,'onlyInMemoryFaultInjection':True}
out=C/'INDEPENDENT-MINI-SUPPORT-ADAPTER-REVIEW-v1.json'
with out.open('x') as f:json.dump(q,f,indent=2);f.write('\n')
print(json.dumps({'result':q['result'],'tests':len(tests),'pin':pin(out)}))
