"""Aggregate complete fresh-member privacy scans and exact immutable plan identities."""
from capture_v2 import *
ars=load(C/'ARCHIVE-PLAN.json')['archives'];initial=load(C/'ARCHIVE-PLAN-initial.json')['archives'];assert [{k:v for k,v in a.items() if k!='restoreOrder'} for a in ars[:-1]]==initial and len(ars)==len(initial)+1
rows=[];allmembers={}
for i,a in enumerate(ars,1):
 report=C/f'scan-fresh-{i:02d}.json';metric=C/f'scan-fresh-{i:02d}.resources.json';q=load(report);m=load(metric)
 plan=C/('ARCHIVE-PLAN-initial.json' if i<=len(initial) else 'ARCHIVE-PLAN.json')
 assert m['command']==['python3',str(C/'privacy_v4.py'),a['file'],str(report),str(plan)]
 assert m['addressSpaceLimitBytes']==268435456 and not m['timedOut'] and m['exitCode']==0
 assert q['status']=='clean' and q['archivePin']=={k:a[k] for k in ('bytes','sha256')}
 assert not any(q[k] for k in ('exactValueMatches','primaryHeaderCandidates','unclassifiedRuntimeCandidates','errors'))
 got={r['path']:{k:r[k] for k in ('path','bytes','sha256')} for r in q['members']};want={r['path']:r for r in a['memberFiles']}
 assert got==want and len(got)==len(q['members'])==q['regularFilesScanned']
 assert sum(r['bytes'] for r in got.values())==q['bytesScanned'] and not(set(allmembers)&set(got));allmembers.update(got)
 rows.append({'archive':a['filename'],'report':str(report),'reportPin':pin(report),'terminalPath':str(metric),'terminalPin':pin(metric),'terminal':m,'members':len(got),'bytes':q['bytesScanned'],'cachedPatternMembers':sum(r['patternVerdict']=='exact-prior-source-cache' for r in q['members']),'classifiedPublicLexicalCollisions':q['classifiedPublicLexicalCollisions'],'classifiedExactCodeHeaderCandidates':len(q['classifiedExactCodeHeaderCandidates']),'classifiedExactTemplateRuntimeCandidates':len(q['classifiedExactTemplateRuntimeCandidates']),'rawScannerStatus':q['status']})
assert allmembers=={r['path']:r for r in load(C/'FRESH-ONLY-RESTORE-MANIFEST.json')['files']}
gate={'result':'PASS','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archives':rows,'freshMembers':len(allmembers),'freshBytes':sum(r['bytes'] for r in allmembers.values()),'currentKnownValuesAcrossAllMembers':True,'exactCachedPatternVerdictsOnly':True,'classifiedPublicLexicalCollisions':sum(r['classifiedPublicLexicalCollisions'] for r in rows),'classifiedExactCodeHeaderCandidates':sum(r['classifiedExactCodeHeaderCandidates'] for r in rows),'classifiedExactTemplateRuntimeCandidates':sum(r['classifiedExactTemplateRuntimeCandidates'] for r in rows),'unclassifiedFindings':0,'errors':0,'rawScannerResultsModified':False,'preservedInitialPlan':pin(C/'ARCHIVE-PLAN-initial.json'),'initialPlan':pin(C/'ARCHIVE-PLAN-initial.json'),'finalPlan':pin(C/'ARCHIVE-PLAN.json'),'limitations':'Complete specified known-value and unchanged pattern scans; no universal secret-free guarantee, decryption, or recursive arbitrary-format decoding.'}
for k in ['historicalValues','historicalForms','mercedesValues','mercedesForms','leapmotorCookieAndHeaderValues','leapmotorCookieForms','mazdaCookieAndHeaderValues','mazdaCookieForms','mazdaPublicBareValues','mazdaPublicBareForms','mazdaFormTokenValues','mazdaFormTokenForms','audiRuntimeValues','audiRuntimeForms','deepalRuntimeValues','deepalRuntimeForms','deepalOriginalPayloadReadOperations']:
 gate[k]=q[k]
 assert all(load(C/f'scan-fresh-{i:02d}.json')[k]==gate[k] for i in range(1,len(ars)+1))
dump(C/'ALL-ARCHIVE-PRIVACY-GATE.json',gate);print(json.dumps({'result':'PASS','archives':len(ars),'freshMembers':len(allmembers)}))
