"""Seal unique backup support once; exact inherited bytes use member references."""
from capture_v2 import *
base=load(BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-DEEPAL-WORKING-20261015.json')
by={}
for r in sorted(base['files'],key=lambda x:x['path']):by.setdefault((r['bytes'],r['sha256']),[]).append(r['path'])
assert not (C/'SUPPORT-MEMBER-INVENTORY.json').exists()
fixed=['APPROVED-INHERITED-SEED-SCOPE.json', 'IMAGE-PROVENANCE.json', 'IMAGE-PROVENANCE-v2.json', 'WORKING-STATE.txt', 'FROZEN-CAPTURE-SCOPE.json', 'source-capture.json', 'proof-capture-v1.json', 'source-package.json', 'proof-packages-v1.json', 'ARCHIVE-PLAN-initial.json', 'COPY-SANITATION-MAPPING.json', 'SYMLINK-RECONSTRUCTION.json', 'PROSE-KEY-RENAME-APPROVALS.json', 'JSON-SANITIZER-CANDIDATES-v1.json', 'APPLICATION-ASSERTION-CONTRACT.json', 'INHERITED-DEPENDENCY-RECONSTRUCTION-v1.json', 'SEED-PROVENANCE.json', 'TARGETED-SEED-READ-DEPENDENCY.json', 'INHERITED-LOCAL-SEED-READ-SCOPE.json', 'APPROVED-MINI-CAPTURE-SCOPE.json', 'SAVING-ANNOUNCEMENT.json', 'OFFICIAL-HELPER-INTEGRITY.json', 'MINI-PRIVACY-ADAPTER-CONTRACT-PROPOSAL.json', 'MINI-PRIVACY-ADAPTER-CONTRACT.json', 'MINI-METADATA-INVENTORY-PROPOSAL-v1.json', 'MINI-BACKUP-PLAN-PROPOSAL-v1.json']
paths={C/n for n in fixed};paths.update(C.glob('*.py'))
for pattern in ['INDEPENDENT-*.json','MINI-*.json','scan-fresh-0[1-4].json','*.resources.json','*.resources.invocation.json','*.log','*.err']:
 paths.update(C.glob(pattern))
for folder in ['seed-read-invocations','audi-seed-read-invocations','deepal-seed-read-invocations']:
 paths.update((C/folder).glob('*.json'))
paths.update(p for p in (C/'phase-logs').glob('*') if p.is_file())
assert all(p.is_file() and not p.is_symlink() for p in paths)
reuse=[];rows=[];seen={}
for p in sorted(paths):
 h=pin(p);key=(h['bytes'],h['sha256']);local=p.relative_to(C).as_posix()
 if key in by:
  names=by[key];n=next((x for x in names if 'recovery-support' in x),names[0]);reuse.append({'originalPath':str(p),'localRelativePath':local,'retainedMember':n,**h,'kind':'exact-inherited-member'});continue
 if key in seen:
  reuse.append({'originalPath':str(p),'localRelativePath':local,'retainedMember':seen[key],**h,'kind':'exact-new-unique-member-alias'});continue
 n='mini-recovery-support/'+local;seen[key]=n;rows.append({'path':n,**h,'payloadPath':str(p)})
assert rows and len(paths)==len(rows)+len(reuse)
mapping={'result':'EXACT_BYTE_REUSE','files':reuse,'baseManifestPin':pin(BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-DEEPAL-WORKING-20261015.json'),'reconstruction':'Map originalPath or localRelativePath to retainedMember after exact hash verification; no source trees or old archives recopied','noDeletion':True}
dump(C/'SUPPORT-REUSE-MAPPING.json',mapping)
rows.append({'path':'mini-recovery-support/SUPPORT-REUSE-MAPPING.json',**pin(C/'SUPPORT-REUSE-MAPPING.json'),'payloadPath':str(C/'SUPPORT-REUSE-MAPPING.json')})
dump(C/'SUPPORT-MEMBER-INVENTORY.json',{'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SEALED_UNIQUE_SUPPORT','files':rows,'reuseMapping':pin(C/'SUPPORT-REUSE-MAPPING.json'),'selectedLocalSupportFiles':len(paths),'uniqueNewFiles':len(rows),'exactReusedOrAliasedFiles':len(reuse),'noRecursiveExecutableEmbedding':True,'postSealReceiptsRetainedExternally':True,'postSealReceiptRetention':'Final independent recovery receipt and final privacy gate are retained once as pinned byte-reconstructible data-only records in the standalone verification document, with references elsewhere.','newUniqueCodeRequiresSeparateReviewedRetention':True,'scopePin':pin(C/'FROZEN-CAPTURE-SCOPE.json')})
print(json.dumps({'newSupportMembers':len(rows),'exactReuseOrAliases':len(reuse),'newBytes':sum(r['bytes'] for r in rows)}))
