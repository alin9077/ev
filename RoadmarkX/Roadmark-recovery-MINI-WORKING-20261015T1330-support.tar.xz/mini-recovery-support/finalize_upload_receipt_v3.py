#!/usr/bin/env python3
"""One initial and one terminal closure receipt; never overwrite delivered bytes."""
from delivery_common_v3 import *

def main():
    manifest = load(DOCS[1])
    expected = {row['filename']: {key: row[key] for key in ('bytes', 'sha256')} for row in manifest['newArchives']}
    archives, docs, active = native('archives', expected), native('documents'), native('active')
    ck(len(active) == 1 and active[0]['filename'] == ACTIVE.name and len(docs) == 4, 'terminal native set differs')
    for name in ('INDEPENDENT-DELIVERY-DOCUMENT-CHECK.json', 'INDEPENDENT-ACTIVE-RECEIPT-CHECK.json'):
        ck(load(C / name)['result'] == 'PASS', 'terminal pre-save check missing')
    ck(load(C / RECOVERY)['result'] == 'PASS', 'fresh replay absent')
    source = next(row for row in archives if row['filename'] == manifest['source']['filename'])
    by_name = {row['filename']: row for row in docs}
    value = {'schemaVersion': 8, 'createdAt': now(),
             'status': 'All new MINI working recovery files persisted; broader release gates remain open',
             'sourceLibraryFileId': source['library_file_id'],
             'archiveLibraryFileIds': [row['library_file_id'] for row in archives],
             'indexLibraryFileId': by_name[DOCS[0].name]['library_file_id'],
             'manifestLibraryFileId': by_name[DOCS[1].name]['library_file_id'],
             'verificationLibraryFileId': by_name[DOCS[2].name]['library_file_id'],
             'summaryLibraryFileId': by_name[DOCS[3].name]['library_file_id'],
             'activeReceiptLibraryFileId': active[0]['library_file_id'],
             'files': archives + docs + active,
             'counts': manifest['incrementalVerification'],
             'phaseReferences': {phase: {kind: ref(C / ('library-' + phase + '-' + suffix)) for kind, suffix in
                                         [('request', 'request.json'), ('results', 'results.json'), ('verified', 'verified.jsonl')]}
                                 for phase in ('archives', 'documents', 'active')},
             'independentVerification': {'result': 'PASS', 'receipt': ref(C / RECOVERY)},
             'documentCheck': {'result': 'PASS', 'receipt': ref(C / 'INDEPENDENT-DELIVERY-DOCUMENT-CHECK.json')},
             'activeCheck': {'result': 'PASS', 'receipt': ref(C / 'INDEPENDENT-ACTIVE-RECEIPT-CHECK.json')},
             'savingAnnouncement': saving_announcement(),
             'noDeletionOrReplacement': True, 'noPinnedSourceOrStatusMutation': True,
             'noExecutableSourceTextEmbedded': True, 'rawDeepalOriginalReadRecoveryRefetchForbidden': True,
             'targetedSeedReadExecutionSummary': seed_summary(), 'delivery': 'Await parent accepted-send confirmation'}
    if (C / 'DELIVERY-CONFIRMATION.json').exists():
        delivery = load(C / 'DELIVERY-CONFIRMATION.json')
        wanted = {key: value[field] for key, field in [('source', 'sourceLibraryFileId'), ('summary', 'summaryLibraryFileId'),
                                                       ('index', 'indexLibraryFileId'), ('manifest', 'manifestLibraryFileId'),
                                                       ('verification', 'verificationLibraryFileId')]}
        ck(delivery['libraryFileIds'] == wanted and delivery['channel'] == 'chatgpt' and
           delivery['messageId'] and delivery['sentAt'] and delivery['acceptedSendDoesNotProveOpened'],
           'accepted five-attachment delivery receipt differs')
        value['deliveryConfirmation'] = {'receipt': ref(C / 'DELIVERY-CONFIRMATION.json'), **delivery}
        value['delivery'] = 'Parent reports accepted delivery; this does not prove the files were opened'
    if (C / 'INDEPENDENT-PERSISTED-ACTIVE-CHECK.json').exists():
        check_value = load(C / 'INDEPENDENT-PERSISTED-ACTIVE-CHECK.json')
        ck(check_value['result'] == 'PASS' and check_value['persistedActive'] == active[0], 'active persistence check differs')
        value['activePersistenceCheck'] = {'result': 'PASS', 'receipt': ref(C / 'INDEPENDENT-PERSISTED-ACTIVE-CHECK.json')}
    no_embedded_source(value)
    target = C / 'FINAL-MINI-UPLOAD-RECEIPTS.json'
    if target.exists():
        previous = load(target)
        allowed = {'createdAt', 'delivery', 'deliveryConfirmation', 'activePersistenceCheck'}
        ck({key: item for key, item in previous.items() if key not in allowed} ==
           {key: item for key, item in value.items() if key not in allowed}, 'terminal append changes immutable initial fields')
        ck('deliveryConfirmation' in value and 'activePersistenceCheck' in value, 'terminal closure is incomplete')
        preserved = C / 'FINAL-MINI-UPLOAD-RECEIPTS-before-persistence-check.json'
        with preserved.open('xb') as handle:
            handle.write(target.read_bytes())
        check(preserved, pin(target))
        with target.open('w') as handle:
            json.dump(value, handle, indent=2)
            handle.write('\n')
    else:
        dump(target, value)
    print(json.dumps({key: item for key, item in value.items() if 'LibraryFileId' in key or key == 'status'}))

if __name__ == '__main__':
    main()
