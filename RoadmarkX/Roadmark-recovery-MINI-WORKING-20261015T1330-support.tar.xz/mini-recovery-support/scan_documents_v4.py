#!/usr/bin/env python3
"""Ordinary full document scan; no new code-context or runtime exemptions."""
import datetime
import json
import pathlib
import sys
from delivery_common_v4 import deepal_adapter, ref, ck
from privacy_v4 import C, load, dump, pin, seed_sets, classify_exact_matches, scan_patterns, ByteSearch, scan, CHUNK

def main():
    phase = sys.argv[1]
    assert phase in ('documents', 'active')
    request = load(C / ('library-' + phase + '-request.json'))['uploads']
    assert len(request) == (4 if phase == 'documents' else 1)
    contract, expected_counters, unused = deepal_adapter()
    forms, blocking, public, benign, counts = seed_sets()
    ck(all(counts[key] == value for key, value in expected_counters.items()), 'reviewed Deepal seed counters differ')
    primary, runtime = scan.patterns()
    rows, findings = [], []
    for item in request:
        path = pathlib.Path(item['local_path'])
        assert path.parent == C / 'deliverables'
        before = pin(path)
        data = path.read_bytes()
        assert pin(path) == before
        search, blocked, lexical = ByteSearch(forms), ByteSearch(blocking), ByteSearch(public)
        for offset in range(0, len(data), CHUNK):
            block = data[offset:offset + CHUNK]
            search.feed(block)
            blocked.feed(block)
            lexical.feed(block)
        primary_hits, runtime_hits, benign_count = scan_patterns(data, path.name, primary, runtime, benign)
        unresolved, collisions = classify_exact_matches(search, blocked, lexical, bool(primary_hits or runtime_hits))
        rows.append({'filename': path.name, **before, 'exactMatchesObserved': len(search.matches),
                     'exactValueMatches': len(unresolved), 'classifiedPublicLexicalCollisions': len(collisions),
                     'primaryCandidates': len(primary_hits), 'runtimeCandidates': len(runtime_hits),
                     'recognizedBenignRuntimeCandidates': benign_count})
        findings.extend({'filename': path.name, 'kind': 'known-value', 'byteStart': start, 'byteEndExclusive': end}
                        for start, end in unresolved)
        findings.extend({'filename': path.name, 'kind': 'primary', **row} for row in primary_hits)
        findings.extend({'filename': path.name, 'kind': 'runtime', **row} for row in runtime_hits)
        del data
        scan.release_memory()
    value = {'result': 'PASS' if not findings else 'REVIEW_REQUIRED',
             'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'files': rows, 'findings': findings, 'errors': [], **counts,
             'currentCompletePatternScan': True, 'allKnownValueForms': True,
             'newCodeContextExemptions': 0, 'rawDeepalOriginalReadRecoveryRefetchForbidden': True,
             'deepalAdapterContract': ref(C / 'MINI-PRIVACY-ADAPTER-CONTRACT.json'),
             'privacyEngine': contract['engine'],
             'limitations': 'Specified searches only, not a universal absence guarantee'}
    name = sys.argv[2] if len(sys.argv) > 2 else ('DELIVERABLE-PRIVACY-GATE.json' if phase == 'documents' else 'ACTIVE-PRIVACY-GATE.json')
    assert pathlib.Path(name).name == name
    dump(C / name, value)
    print(json.dumps({'result': value['result'], 'files': len(rows), 'findings': len(findings)}))
    raise SystemExit(0 if value['result'] == 'PASS' else 2)

if __name__ == '__main__':
    main()
