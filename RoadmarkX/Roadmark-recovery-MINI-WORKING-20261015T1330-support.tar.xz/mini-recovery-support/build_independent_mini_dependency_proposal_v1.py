#!/usr/bin/env python3
"""Independent metadata-only inherited/MINI external dependency reconciliation."""
import copy,datetime,hashlib,json,pathlib,resource,sys
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent;B=C.parent/'deepal-working-20261015T1110';LIMIT=268435456
assert resource.getrlimit(resource.RLIMIT_AS)==(LIMIT,LIMIT)
def load(p):return json.loads(P(p).read_bytes())
def pin(p):
 b=P(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def core(r):return {k:r[k] for k in ('path','bytes','sha256')}
def sh(r):return {k:r[k] for k in ('bytes','sha256')}
basepath=B/'deliverables/Roadmark-RECOVERY-MANIFEST-DEEPAL-WORKING-20261015.json'
basepin=pin(basepath);assert sh(basepin)=={'bytes':3072311,'sha256':'66775e32af7363d434c290ac3b0f6ff55639d61f4aae2ae7c7f1d4a509372ce6'}
base=load(basepath);old={r['path']:r for r in base['files']};assert len(old)==12076 and len(base['archivesInRestoreOrder'])==129
priorpath=B/'INHERITED-DEPENDENCY-RECONSTRUCTION-v1.json';prior=load(priorpath)
assert prior['dependencies']==base['inheritedDependencyReconstruction']['dependencies']
deps=copy.deepcopy(prior['dependencies']);assert len(deps)==len({r['originalPath'] for r in deps})==119
scopepath=C/'FROZEN-CAPTURE-SCOPE.json';scope=load(scopepath);changed={'roadmark/'+n for n in scope['sourceChangedPaths']};assert len(changed)==6
intersection=[]
for i,r in enumerate(deps):
 for j,p in enumerate(r['pins']):
  assert p['expected']['path']==r['originalPath'] and sh(p['expected'])==sh(p['member'])
  assert old[p['member']['path']]==core(p['member'])
  if p['member']['path'] in changed:intersection.append({'dependencyIndex':i,'pinIndex':j,'dependencyOriginalPath':r['originalPath'],'originalExpected':p['expected'],'currentMember':p['member']})
assert intersection==[], 'A new exact before-copy relocation review is required'
metapath=C/'MINI-METADATA-INVENTORY-PROPOSAL-v1.json';meta=load(metapath);reqs=meta['priorChainDependencies']['dependencies'];assert len(reqs)==51
by={r['originalPath']:r for r in deps};archive_names={r['filename'] for r in base['archivesInRestoreOrder']};new=[];existing=[];resolved=[]
for row in reqs:
 e=row['expected'];member=old[row['member']];assert sh(e)==sh(member) and row['exactFinalLogicalIdentity']
 assert row['mapping']['archives'] and set(row['mapping']['archives'])<=archive_names
 resolved.append({'expected':e,'member':member,'mapping':row['mapping'],'nominatedBy':row['nominatedBy']})
 if e['path'] in by:
  matches=[p for p in by[e['path']]['pins'] if sh(p['expected'])==sh(e)]
  assert len(matches)==1 and matches[0]['member']==member
  existing.append({'originalPath':e['path'],'member':member})
 else:
  r={'originalPath':e['path'],'pins':[{'expected':copy.deepcopy(e),'reconstructFrom':'exact inherited recommended-chain member','member':copy.deepcopy(member)}]}
  deps.append(r);by[e['path']]=r;new.append(r)
assert len(existing)==6 and len(new)==45 and len(deps)==164
canonical=hashlib.sha256(json.dumps(deps,sort_keys=True,separators=(',',':')).encode()).hexdigest()
q={'schemaVersion':1,'result':'PASS_EXACT_METADATA_ONLY_DEPENDENCY_PROPOSAL','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseManifest':basepin,'baseDependencyMap':pin(priorpath),'metadataProposal':pin(metapath),'frozenScope':pin(scopepath),'allSixFinalSourceChangedPaths':sorted(changed),'relocationProposals':[],'inheritedPointerIntersections':intersection,'inheritedDependencyRecords':119,'unchangedInheritedRecords':119,'miniExternalRequirements':51,'existingExactRequirements':existing,'resolvedMiniRequirements':resolved,'newDependencyRecords':new,'proposedDependenciesCount':164,'proposedDependenciesCanonicalSha256':canonical,'originalExpectedPathsAndHashesUnchanged':True,'metadataOnly':True,'externalPayloadReads':0,'archivePayloadReads':0,'rawDeepalOriginalReads':False,'beforeCopiesRequiredForInheritedPointerRelocations':0,'note':'Existing inherited member pointers already target exact retained historical copies where necessary. The new MINI requirements resolve to the unchanged 129-archive base metadata. No source-pointer relocation is needed for this cut.'}
o=C/'INDEPENDENT-MINI-DEPENDENCY-PROPOSAL-v1.json'
with o.open('x') as f:json.dump(q,f,indent=2);f.write('\n')
print(json.dumps({'result':q['result'],'prior':119,'externalRequirements':51,'newRecords':45,'final':164,'relocations':0,'canonicalSha256':canonical,'pin':pin(o)}))
