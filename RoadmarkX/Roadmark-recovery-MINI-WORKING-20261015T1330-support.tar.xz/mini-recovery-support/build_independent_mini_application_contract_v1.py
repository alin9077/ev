#!/usr/bin/env python3
"""Freeze bounded MINI application assertions for later archive-byte replay; no product run."""
import datetime, hashlib, json, pathlib, resource, stat, sys
sys.dont_write_bytecode = True
P=pathlib.Path; C=P(__file__).resolve().parent; W=C.parents[2]; LIMIT=268435456
INVENTORY=P('/tmp/mini-packet/final-freeze-v1/inventory.json')
ACCEPTANCE=P('/tmp/mini-review/final-retention-v1-acceptance.json')

def ck(v,m):
    if not v: raise AssertionError(m)
def core(r): return {k:r[k] for k in ('bytes','sha256')}
def identity(p):
    p=P(p);s=p.lstat();ck(stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents),'unsafe metadata path')
    return [s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev]
def read_bytes(p):
    a=identity(p);ck(a[0]<500000,'metadata read too large'); b=P(p).read_bytes();ck(identity(p)==a and len(b)==a[0],'metadata changed');return b
def pin(p):
    b=read_bytes(p);return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def rest(p):
    p=P(p)
    if p.is_relative_to('/tmp'): return p.relative_to('/tmp').as_posix()
    if p.is_relative_to(W/'roadmark-104'): return 'roadmark/'+p.relative_to(W/'roadmark-104').as_posix()
    ck(p.is_relative_to(W/'roadmark-104-qa') or p.is_relative_to(W/'roadmark-104-visual-qa-20261015'),'unexpected metadata root')
    return p.relative_to(W).as_posix()
def pointer(x,p):
    if not p:return x
    for k in p.split('/')[1:]:
        k=k.replace('~1','/').replace('~0','~');x=x[int(k)] if isinstance(x,list) else x[k]
    return x

def main():
    ck(resource.getrlimit(resource.RLIMIT_AS)==(LIMIT,LIMIT),'ceiling absent')
    invpin,accpin=pin(INVENTORY),pin(ACCEPTANCE)
    ck(invpin['sha256']=='320ae09e676a2166039cd574b2f32e1b481f12a71dc192cc4feeaa98997ede4e','freeze differs')
    ck(accpin['sha256']=='83384b36822ebce9df12628b52f1c69e173b00419fc33411bb1807c99f5ca353','acceptance differs')
    inv=json.loads(read_bytes(INVENTORY));acc=json.loads(read_bytes(ACCEPTANCE));frozen={r['path']:r for r in inv['files']}
    ck(len(frozen)==534 and inv['regularFileBytes']==63855881 and inv['symlinkCount']==0,'freeze counts differ')
    ck(acc['status']=='accepted' and acc['sevenLiveTargetsExact']==inv['sourceAndStatusAfterPins'],'seven live pins differ')
    documents={};retained={};assertions=[];reads=[]
    extra={str(INVENTORY):invpin,str(ACCEPTANCE):accpin}
    def add(r):
        p=r['path'];ck(p in frozen or p in extra,'pin outside exact MINI metadata selection: '+p)
        if p in frozen:ck(frozen[p]['bytes']==r['bytes'],'frozen size differs: '+p)
        e={'path':rest(p),**core(r)};ck(e['path'] not in retained or retained[e['path']]==e,'conflicting pin');retained[e['path']]=e
    def read(p):
        p=str(p)
        if p in documents:return documents[p]
        ck(p in frozen or p in extra,'read outside exact MINI metadata selection')
        s=identity(p)
        if p in frozen:ck(s[:2]==[frozen[p]['bytes'],frozen[p]['mtimeNs']],'metadata differs from author freeze')
        q=pin(p);add(q);x=json.loads(read_bytes(p));ck(pin(p)==q and identity(p)==s,'unstable receipt')
        documents[p]=x;reads.append({'path':p,**core(q),'identity':s});return x
    def refs(x):
        if isinstance(x,dict):
            if all(k in x for k in ('path','bytes','sha256')): add(x)
            for v in x.values():refs(v)
        elif isinstance(x,list):
            for v in x:refs(v)
    def exact(p,field,expected):
        p=str(p);ck(pointer(read(p),field)==expected,'application field differs '+p+field)
        assertions.append({'restorePath':rest(p),'pointer':field,'expected':expected})
    def fields(p,names):
        x=read(p)
        for n in names:exact(p,'/'+n,x[n])
    def accepted(p,names):
        x=read(p);exact(p,'/status','accepted');fields(p,names);refs(x);return x
    def run(step):
        refs(step);rp,tp=step['result']['path'],step['terminal']['path'];r,t=read(rp),read(tp)
        for f in ('passed','pinsPassed','scopePassed'):exact(rp,'/'+f,True)
        exact(rp,'/exitCode',0);exact(tp,'/exitCode',0)
        if 'watchdogFired' in t:exact(tp,'/watchdogFired',False)
        ck(r['manifestSha256']==step['manifest']['sha256'],'command manifest binding differs')
        for stream in ('stdout','stderr'):
            p=str(P(tp).parent/(stream+'.log'));add({'path':p,'bytes':frozen[p]['bytes'],'sha256':t[stream+'Sha256']})
    read(INVENTORY);read(ACCEPTANCE)
    for r in inv['sourceAndStatusAfterPins']:add(r)
    ck(len(inv['sourceAndStatusAfterPins'])==7,'live pin count differs')
    exact(INVENTORY,'/sourceAndStatusAfterPins',inv['sourceAndStatusAfterPins'])
    fields(INVENTORY,['otherAttemptHistory','retainedFailures','totalFiles','regularFileBytes','symlinkCount'])
    exact(ACCEPTANCE,'/status','accepted');fields(ACCEPTANCE,['sevenLiveTargetsExact','retainedAllFailuresAndSupersededPreparations','originalColdCompilerProofCacheRetained','scope'])
    R=P('/tmp/mini-review');T=P('/tmp/mini-packet')
    selected=R/'preflight-v4-output-review.json';s=read(selected);refs(s)
    fields(selected,['verdict','completeAfterCarsReconstructed','factClaimsVerified','featureClaimsVerified','coreGradesRecounted','fullWrittenPacksReconstructedFromPortable','featureOptionalPaths','citationOptionalPaths','reportOptionalPaths','inventorySettlements','c1Pass','selectedCriteria','gradeCorrectionVerified'])
    for k,v in {'completeAfterCarsReconstructed':10,'factClaimsVerified':183,'featureClaimsVerified':690,'coreGradesRecounted':170,'c1Pass':False}.items():ck(s[k]==v,'selected result differs')
    stage=R/'full-stage-v2-output-review.json';s=read(stage);refs(s)
    fields(stage,['verdict','acceptedStagesExact','allOtherResearchFieldDigestsExact','completePeerCarsExact','selectedCompleteCars','selectedWrittenArtifactsByteExact','factClaims','featureClaims','featureCitationReportOptionalPaths','globalC1Counts','globalC1Settlements','globalC1Issues','fixedCatalogueTierOneOnSale','sourceNeutralityInputCount','notAccepted'])
    ck(s['completePeerCarsExact']==417 and s['fixedCatalogueTierOneOnSale']==[427,350,309],'stage counts differ')
    stage_receipt=s['stageReceipt']['path'];x=read(stage_receipt)
    fields(stage_receipt,['status','manifestSha256','packetSha256','acceptedCurrentCars','stagedCars','tierOneVersions','onSaleVersions','untouchedPeerCars','actualSelectedCars','actualFactAndTermClaims','actualFeatureClaims','allAcceptedStagesThroughDeepal26ExactlyReproduced','all14ResearchFieldsProved','all21RetainedStorageFilesPinnedBeforeAndAfter','completeGlobalC1ExpectedEquality','actualOptionalWitnessesExact','broadFeatureReplay','normalFullReportRun','defaultLoaderCalls','liveSourceEdits','productionRegistration'])
    reg=accepted(R/'registration-v1-live-readback.json',['allFourLiveHashesAndBytesMatchAcceptedPayloads','liveReadback','registryEntries','registrationDelta'])
    ck(reg['registryEntries']==27,'registry append count differs')
    doc=accepted(R/'docs-status-v2-live-readback.json',['allThreeLiveHashesAndBytesMatchAcceptedPayloads','liveReadback','all38ProofPinsUnchanged','all206RuntimeSourcePinsUnchanged','historyChecks'])
    for review,count in [(reg,4),(doc,3)]:
        rp=review['applicationReceipt']['path'];x=read(rp);exact(rp,'/passed',True);fields(rp,['manifestSha256','grantSha256','writes','heavyExecution','automaticRetry']);ck(len(x['writes'])==count,'application write count differs')
    five=accepted(R/'post-registration-five-gate-results-v1.json',['allFivePrerequisitesAccepted','checks','details','scope','noTypeScriptNormalReportOrBuildAcceptance'])
    ck([r['name'] for r in five['checks']]==['market-view','changed-file-lint','behavioural-suites','live-brand-safety','structural-validation'],'five gates differ')
    ck([r['exactTestCount'] for r in five['details']]==[None,None,144,7,None],'actual test counts differ')
    for r in five['checks']:run(r)
    ts=accepted(R/'full-project-typescript-v1-output-review.json',['passed','exitCode','independentChecks','scope']);run(ts)
    ck(all(ts['independentChecks'].values()),'cold compiler scope checks differ')
    for f in ('coldFullProjectAttempt','fullProjectTypecheckPassed'):exact(ts['result']['path'],'/'+f,True)
    exact(ts['result']['path'],'/nextBuildClaim',False)
    for f,v in [('passed',True),('expectedRootCount',361),('actualRootCount',361),('missingRoots',[]),('unexpectedRoots',[])]:exact(ts['scopeVerification']['path'],'/'+f,v)
    normal=accepted(R/'report-comparison-v2-output-review.json',['independentOutputChecks','globalResults','miniResults','scope'])
    ck(len(normal['runs'])==2 and normal['independentOutputChecks']['fixedCounts']==[427,350,309],'normal report scope differs')
    for r in normal['runs']:run(r)
    semantic=normal['comparisonResult']['path'];x=read(semantic);fields(semantic,list(x))
    ck(x['passed'] and x['allNormalLeavesAccounted'] and x['ordinaryProductionReportRanSeparately'] and not x['normalReportSubstituted'] and not x['broadFeatureReplay'],'comparator scope differs')
    exact(normal['comparisonExpectedDiff']['path'],'',[])
    for version,exit_code in [(2,1),(3,0),(4,0)]:
        tp=T/f'selected-preflight-v{version}/run/terminal.json';x=read(tp);exact(tp,'/exitCode',exit_code);exact(tp,'/automaticRetry',False)
        for stream in ('stdout','stderr'):
            p=str(tp.parent/(stream+'.log'));add({'path':p,'bytes':frozen[p]['bytes'],'sha256':x[stream+'Sha256']})
    tp=T/'full-stage-v2/run/terminal.json';exact(tp,'/exitCode',0)
    held=['mini-packet/selected-preflight-v1/run/terminal.json','mini-packet/full-stage-v1/run/terminal.json','mini-packet/report-comparison-v1/normal-coverage-asof-2026-10-15/terminal.json','mini-packet/report-comparison-v1/report-comparison/terminal.json']
    ck(not set(held)&{rest(p) for p in frozen},'held preparation falsely contains executed terminal')
    preview=W/'roadmark-104-visual-qa-20261015'
    for f in ('appRendered','phoneViewportVerified','protectedHeroVisuallyInspected'):exact(preview/'visual-qa-blocker-receipt.json','/'+f,False)
    exact(preview/'visual-qa-blocker-receipt.json','/screenshots',[])
    for r in reads:ck(identity(r['path'])==r['identity'] and core(pin(r['path']))==core(r),'metadata mutated during contract freeze')
    result={'schemaVersion':1,'result':'APPROVED_EXACT_CAPTURED_APPLICATION_ASSERTIONS','preparedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'generator':pin(__file__),'finalFreeze':invpin,'finalAcceptance':accpin,'assertions':assertions,'retainedPins':sorted(retained.values(),key=lambda r:r['path']),'exactMetadataReads':reads,'forbiddenExecutedTerminals':held,'summary':{'catalogue':427,'tierOne':350,'onSale':309,'registeredPackets':27,'selectedVersions':10,'scopedTests':151,'relevantTests':144,'isolatedSafetyTests':7,'fullProjectTypeScriptRoots':361,'normalReportRuns':1,'executedFailure':'selected-preflight-v2','supersededSuccess':'selected-preflight-v3','currentSelected':'selected-preflight-v4','currentFullStage':'full-stage-v2','currentReportComparator':'report-comparison-v2','heldUnexecuted':['selected-preflight-v1','full-stage-v1','report-comparison-v1'],'globalCriteriaOpen':['C1','C2','C3','C4','C5'],'MINICriteriaOpen':['C1','C2','C5'],'MINIVisualQAPassed':False,'productionBuildPassed':False,'retainedExecutedFailureBoundaries':1,'previewScreenshots':0,'mobilePassClaimed':False},'scope':'Exact bounded accepted reviewer/result metadata; assertions execute against captured archive bytes during fresh independent replay','noProductExecution':True,'noSourceOrResearchBodyHashSweep':True,'noRawDeepalOriginalReads':True,'noCodeEmbedding':True}
    out=C/'APPLICATION-ASSERTION-CONTRACT.json'
    with out.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({'result':result['result'],'assertions':len(assertions),'retainedPins':len(retained),'metadataReadFiles':len(reads),'pin':pin(out)}))
if __name__=='__main__':main()
