#!/usr/bin/env python3
"""Small identity helpers; no payload extraction, scanning or source embedding."""
import datetime
import hashlib
import json
import os
import pathlib
import stat

C = pathlib.Path(__file__).resolve().parent
BASE = C.parent / 'deepal-working-20261015T1110'
D = C / 'deliverables'
STEM = 'MINI-WORKING-20261015'
CHUNK = 65536
LIMIT = 268435456
DOCS = [D / ('Roadmark-RECOVERY-' + kind + '-' + STEM + suffix) for kind, suffix in
        [('INDEX', '.md'), ('MANIFEST', '.json'), ('VERIFICATION', '.json')]]
DOCS.append(D / 'Roadmark-MINI-M1-UPDATE-20261015.md')
ACTIVE = D / ('Roadmark-RECOVERY-ACTIVE-STATE-' + STEM + '.json')
BASE_MANIFEST = BASE / 'deliverables/Roadmark-RECOVERY-MANIFEST-DEEPAL-WORKING-20261015.json'
BASE_TERMINAL = BASE / 'FINAL-DEEPAL-UPLOAD-RECEIPTS.json'
RECOVERY = 'INDEPENDENT-MINI-RECOVERY-VERIFICATION-v1.json'
GATE = 'ALL-ARCHIVE-PRIVACY-GATE.json'
DEPENDENCY = 'INHERITED-DEPENDENCY-RECONSTRUCTION-v1.json'
COUNT_KEYS = ('archiveCount', 'logicalFiles', 'logicalBytes', 'freshFiles', 'freshBytes',
              'fullSourceFiles', 'baseArchivesReused')
INHERIT_KEYS = ('sourceSanitation', 'originalRawCaptureReplayCompatibility',
               'missingHistoricalCaptureProvenance', 'priorToyotaBrowserScreenshotExclusions',
               'sourcePackagingExclusions', 'historicalExclusions', 'lastPassedRecovery',
               'optionalReconstruction', 'partialOutputRetention', 'reusedVerifier',
               'cleanupCandidatesExcludedFromRestore', 'cleanupListLibraryFileId',
               'exactDuplicateProvenance')
DELIVERY_SCRIPTS = ('delivery_common_v4.py', 'build_documents_v4.py',
                    'independent_mini_documents_v4.py', 'build_active_receipt_v4.py',
                    'finalize_upload_receipt_v4.py', 'preupload_gate_v4.py',
                    'scan_documents_v4.py')

def ck(value, message):
    if not value:
        raise AssertionError(message)

def load(path):
    return json.loads(pathlib.Path(path).read_text())

def dump(path, value):
    with pathlib.Path(path).open('x') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def pin(path):
    path = pathlib.Path(path)
    before = path.lstat()
    ck(stat.S_ISREG(before.st_mode) and not any(p.is_symlink() for p in path.parents),
       'not an ordinary unlinked file: ' + str(path))
    digest, size = hashlib.sha256(), 0
    with path.open('rb') as handle:
        while block := handle.read(CHUNK):
            digest.update(block)
            size += len(block)
    after = path.lstat()
    ck((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
       (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
       'file changed during pin: ' + str(path))
    ck(size == before.st_size, 'short file read')
    return {'bytes': size, 'sha256': digest.hexdigest()}

def check(path, expected):
    actual = pin(path)
    ck(actual == {key: expected[key] for key in ('bytes', 'sha256')}, 'pin differs: ' + str(path))
    return actual

def ref(path):
    path = pathlib.Path(path)
    return {'path': path.relative_to(C).as_posix() if path.is_relative_to(C) else str(path), **pin(path)}

def replay_metadata(name):
    inputs = load(C / 'INDEPENDENT-MINI-REPLAY-INPUTS-v1.json')
    selected = inputs['metadata'][name]
    path = pathlib.Path(selected['path'])
    ck(path.is_absolute() and path.is_relative_to(C), 'selected current metadata must be inside this checkpoint')
    check(path, selected)
    return path, load(path)

def json_pointer(value, path):
    ck(isinstance(path, str) and path.startswith('/'), 'invalid classification counter pointer')
    for part in path.split('/')[1:]:
        part = part.replace('~1', '/').replace('~0', '~')
        value = value[int(part)] if isinstance(value, list) else value[part]
    return value

def deepal_adapter():
    path = C / 'MINI-PRIVACY-ADAPTER-CONTRACT.json'
    contract = load(path)
    ck(contract['result'] == 'APPROVED_MINI_INHERITED_PRIVACY_ADAPTER', 'current inherited privacy adapter not approved')
    inherited_path = BASE / 'DEEPAL-PRIVACY-ADAPTER-CONTRACT.json'
    ck(contract['inheritedContract']['path'] == str(inherited_path), 'inherited adapter contract path differs')
    check(inherited_path, contract['inheritedContract'])
    inherited = load(inherited_path)
    ck(inherited['result'] == 'APPROVED_FINAL_DEEPAL_PRIVACY_ADAPTER', 'inherited adapter approval absent')
    for key in ('classification', 'approval', 'additiveInventory', 'classificationCounterPointers'):
        ck(contract[key] == inherited[key], 'inherited privacy scope differs: ' + key)
    engine_review_path = C / 'INDEPENDENT-MINI-PRIVACY-PLAN-ADAPTER-REVIEW-v1.json'
    ck(contract['engineAdaptationReview']['path'] == str(engine_review_path), 'scanner adaptation review path differs')
    check(engine_review_path, contract['engineAdaptationReview'])
    engine_review = load(engine_review_path)
    ck(engine_review['result'] == 'PASS_EXACT_PLAN_FILENAME_ALLOWLIST_ADDITION' and
       engine_review['script'] == contract['engine'] and engine_review['otherBytesUnchanged'] and
       engine_review['engineRuleSeedByteSearchAndClassificationSemanticsUnchanged'] and
       engine_review['noNewPrivacyException'], 'scanner plan-only adaptation is not independently approved')
    check(engine_review['previousScript']['path'], engine_review['previousScript'])
    ck({key: engine_review['previousScript'][key] for key in ('bytes', 'sha256')} ==
       {key: inherited['engine'][key] for key in ('bytes', 'sha256')}, 'previous scanner differs from inherited engine')
    previous = pathlib.Path(engine_review['previousScript']['path']).read_bytes()
    current = pathlib.Path(contract['engine']['path']).read_bytes()
    before = b"('ARCHIVE-PLAN-sanitized-v1.json','ARCHIVE-PLAN.json')"
    after = b"('ARCHIVE-PLAN-initial.json','ARCHIVE-PLAN-sanitized-v1.json','ARCHIVE-PLAN.json')"
    ck(previous.count(before) == 1 and current == previous.replace(before, after), 'scanner adaptation changed more than the approved filename allowlist')
    for key in ('engine', 'addition', 'classification', 'approval', 'additiveInventory'):
        location = pathlib.Path(contract[key]['path'])
        ck(location.is_absolute() and location.is_relative_to(C if key in ('engine', 'addition') else BASE), 'adapter dependency outside its exact current/inherited checkpoint')
        check(location, contract[key])
    ck(pathlib.Path(contract['engine']['path']).name == 'privacy_v4.py', 'unexpected reviewed privacy adapter')
    classification = load(contract['classification']['path'])
    approval = load(contract['approval']['path'])
    ck(approval['classificationPin'] == {key: contract['classification'][key] for key in ('bytes', 'sha256')} and
       approval['copyOnly'], 'approval does not bind final copy-only classification')
    ck(classification['additiveInventory'] == contract['additiveInventory'] and
       approval['additiveInventoryPin'] == {key: contract['additiveInventory'][key] for key in ('bytes', 'sha256')},
       'approved additive inventory identity differs')
    pointers = contract['classificationCounterPointers']
    ck(set(pointers) == {'deepalRuntimeValues', 'deepalRuntimeForms', 'deepalOriginalPayloadReadOperations'},
       'Deepal counter pointer set differs')
    counters = {key: json_pointer(classification, pointer) for key, pointer in pointers.items()}
    ck(counters == {'deepalRuntimeValues': 6, 'deepalRuntimeForms': 41, 'deepalOriginalPayloadReadOperations': 5}, 'inherited final Deepal counter scope differs')
    expected_reads = [{'path': row['capturedPayloadPath'], 'pin': row['originalPin'],
                       'payloadReadOperations': 1, 'valueRanges': len(row['ranges'])}
                      for row in classification['files']]
    ck(len(expected_reads) == counters['deepalOriginalPayloadReadOperations'] and
       len({row['path'] for row in expected_reads}) == len(expected_reads), 'Deepal exact read mapping differs')
    return contract, counters, expected_reads

POST_SEAL_SERIALIZATION = {'encoding': 'UTF-8', 'indent': 2, 'ensure_ascii': True, 'sort_keys': False,
                           'separators': [',', ': '], 'trailingNewline': True}
POST_SEAL_RESULTS = {RECOVERY: 'PASS', GATE: 'PASS',
                     'INDEPENDENT-MINI-REPLAY-INPUTS-v1.json': 'APPROVED_PINNED_FRESH_REPLAY_INPUTS'}

def reject_embedded_bodies(value):
    no_embedded_source(value)
    if isinstance(value, dict):
        ck(not ({'archivesInRestoreOrder', 'files'} <= set(value)), 'full prior manifest embedded')
        ck('postSealReceipts' not in value, 'nested post-seal receipt envelope')
        for key, item in value.items():
            ck(not (key.lower() in ('scripttext', 'sourcetext', 'body', 'content', 'stdout', 'stderr', 'log', 'traceback', 'text', 'code') and
                    isinstance(item, str) and item), 'script or log body embedded')
            reject_embedded_bodies(item)
    elif isinstance(value, list):
        for item in value:
            reject_embedded_bodies(item)
    elif isinstance(value, str):
        ck(len(value) < 8192 and not any(marker in value for marker in ('\ndef ', '\nclass ', '#!/usr/', '<script', '<html')),
           'source-like or oversized text body embedded')

def reserialize_receipt(record):
    reject_embedded_bodies(record)
    return (json.dumps(record, indent=2, ensure_ascii=True, sort_keys=False, separators=(',', ': '), allow_nan=False) + '\n').encode('utf-8')

def post_seal_receipts():
    rows = []
    for name, required_result in POST_SEAL_RESULTS.items():
        path = C / name
        original = path.read_bytes()
        record = json.loads(original)
        ck(record['result'] == required_result, 'data-only receipt result differs from exact filename allowlist')
        rebuilt = reserialize_receipt(record)
        ck(rebuilt == original, 'receipt does not follow declared exact serialization')
        rows.append({'filename': name, **pin(path), 'serialization': POST_SEAL_SERIALIZATION, 'record': record})
    return rows

def check_post_seal_receipts(rows):
    ck([row['filename'] for row in rows] == list(POST_SEAL_RESULTS), 'post-seal receipt set/order differs')
    for row in rows:
        ck(row['serialization'] == POST_SEAL_SERIALIZATION and row['record']['result'] == POST_SEAL_RESULTS[row['filename']],
           'receipt serialization or exact filename result differs')
        rebuilt = reserialize_receipt(row['record'])
        expected = {'bytes': len(rebuilt), 'sha256': hashlib.sha256(rebuilt).hexdigest()}
        ck(expected == {key: row[key] for key in ('bytes', 'sha256')} == pin(C / row['filename']) and
           rebuilt == (C / row['filename']).read_bytes(), 'reconstructed receipt bytes or pin differ')
    return [{'filename': row['filename'], 'bytes': row['bytes'], 'sha256': row['sha256']} for row in rows]

def safe_member(name):
    path = pathlib.PurePosixPath(name)
    ck(name and not path.is_absolute() and '..' not in path.parts and str(path) == name and '\\' not in name,
       'unsafe member path')

def file_map(rows):
    result = {}
    for row in rows:
        safe_member(row['path'])
        ck(row['path'] not in result, 'duplicate member')
        ck(isinstance(row['bytes'], int) and row['bytes'] >= 0 and len(row['sha256']) == 64, 'invalid pin')
        result[row['path']] = row
    return result

def native(phase, expected=None):
    request = load(C / ('library-' + phase + '-request.json'))['uploads']
    result = load(C / ('library-' + phase + '-results.json'))['results']
    witnesses = [json.loads(line) for line in (C / ('library-' + phase + '-verified.jsonl')).read_text().splitlines()]
    ck(len(request) == len(result) == len(witnesses), 'native phase lengths differ')
    rows = []
    for wanted, value, witness in zip(request, result, witnesses):
        path = pathlib.Path(wanted['local_path'])
        ck(value['status'] == 'succeeded' and value['local_metadata_applied'] and
           value['local_path'] == str(path) and value['file_name'] == path.name, 'native upload not verified')
        ck(witness['verified'] and witness['filename'] == path.name and
           witness['library_file_id'] == value['library_file_id'] and
           witness['version'] == value['current_version_number'], 'native witness differs')
        ck(os.getxattr(path, 'user.library-file-id').decode() == value['library_file_id'] and
           os.getxattr(path, 'user.library-file-version').decode() == str(value['current_version_number']),
           'local native identity differs')
        actual = {key: witness[key] for key in ('bytes', 'sha256')}
        if expected is None:
            ck(actual == pin(path), 'persisted document bytes differ')
        else:
            ck(path.name in expected and actual == expected[path.name] and
               path.stat().st_size == actual['bytes'], 'persisted archive pin differs')
        rows.append({'filename': path.name, 'library_file_id': value['library_file_id'],
                     'file_id': value['file_id'], 'version': value['current_version_number'], **actual})
    ck(len({row['filename'] for row in rows}) == len(rows) and
       len({row['library_file_id'] for row in rows}) == len(rows), 'duplicate native identity')
    if expected is not None:
        ck(set(expected) == {row['filename'] for row in rows}, 'native archive set differs')
    return rows

def final_archives(plan):
    expected = {row['filename']: {key: row[key] for key in ('bytes', 'sha256')} for row in plan['newArchives']}
    persisted = {row['filename']: row for row in native('archives', expected)}
    result = []
    for item in plan['archivesInRestoreOrder']:
        row = {key: value for key, value in item.items() if key not in ('file', 'memberFiles', 'allMembersVerified')}
        if row.get('new'):
            row.update({key: persisted[row['filename']][key] for key in ('library_file_id', 'file_id', 'version')})
        ck(row['library_file_id'] and row['file_id'] and isinstance(row['version'], int), 'archive native identity absent')
        result.append(row)
    ck([row['restoreOrder'] for row in result] == list(range(1, len(result) + 1)), 'restore order differs')
    ck(len(result) == plan['archiveCount'] and len({row['filename'] for row in result}) == len(result), 'archive count differs')
    return result

def no_embedded_source(value):
    if isinstance(value, dict):
        ck(not {'verificationSupportFiles', 'postSealCompactEvidence', 'scriptText', 'sourceText'} & set(value),
           'recursive evidence or executable text field')
        if 'filename' in value and 'text' in value:
            ck(not str(value['filename']).endswith(('.py', '.js', '.ts', '.sh')), 'executable text embedded')
        for child in value.values():
            no_embedded_source(child)
    elif isinstance(value, list):
        for child in value:
            no_embedded_source(child)

def seed_summary():
    summaries = {}
    for kind, directory in [('historical', 'seed-read-invocations'), ('audi', 'audi-seed-read-invocations')]:
        rows = []
        for path in sorted((C / directory).glob('*.json')):
            value = load(path)
            if kind == 'historical':
                ck(value['exactPinnedMembersReadAndVerified'] == 200 and value['historicalArchives'] == 21 and
                   value['noExtractedValuesPersisted'], 'historical seed receipt scope differs')
            else:
                ck(value['distinctValues'] == 6 and value['variantForms'] == 37 and
                   value['payloadReadOperations'] == 6 and value['uniqueOriginalFiles'] == 4 and
                   value['noValuesOrValueDigestsPersisted'], 'Audi seed receipt scope differs')
            rows.append({**ref(path), 'completedAt': value['completedAt'], 'processId': value['processId']})
        summaries[kind] = {'asOf': max((r['completedAt'] for r in rows), default=None),
                           'completedInvocations': len(rows), 'receiptReferences': rows,
                           'noExtractedValuesOrValueDigests': True}
        if kind == 'historical':
            summaries[kind].update(uniquePinnedMembers=200, uniqueHistoricalArchives=21,
                                   targetedPinnedMemberReads=200 * len(rows))
        else:
            summaries[kind].update(distinctValues=6, variantForms=37, uniqueOriginalFiles=4,
                                   payloadReadOperations=6 * len(rows))
    scope = load(C / 'INHERITED-LOCAL-SEED-READ-SCOPE.json')
    ck(scope['result'] == 'EXACT_UNCHANGED_SELECTOR_ACCOUNTING_SPECIFICATION' and len(scope['files']) == 48 and
       scope['payloadValueReadsPerSuccessfulInvocation'] == scope['streamingIntegrityReadsPerSuccessfulInvocation'] == 48,
       'inherited local seed accounting scope differs')
    count = summaries['historical']['completedInvocations']
    ck(count == summaries['audi']['completedInvocations'], 'incomplete paired seed ledgers')
    summaries['inheritedLocal'] = {'specification': ref(C / 'INHERITED-LOCAL-SEED-READ-SCOPE.json'),
                                  'completedInvocations': count, 'uniqueOriginalFiles': 48,
                                  'payloadValueReads': 48 * count, 'streamingIntegrityReads': 48 * count,
                                  'accountingMethod': 'Derived from reviewed selector control flow and paired seed completion ledgers; not separate per-file instrumentation',
                                  'noValuesOrValueDigestsPersisted': True}
    contract, counters, expected_reads = deepal_adapter()
    deepal_rows = []
    for path in sorted((C / 'deepal-seed-read-invocations').glob('*.json')):
        value = load(path)
        ck(value['classificationReceiptPin'] == {key: contract['classification'][key] for key in ('bytes', 'sha256')} and
           value['distinctValues'] == counters['deepalRuntimeValues'] and value['variantForms'] == counters['deepalRuntimeForms'] and
           value['payloadReadOperations'] == counters['deepalOriginalPayloadReadOperations'] and value['reads'] == expected_reads,
           'Deepal seed receipt identity/count/read scope differs')
        ck(value['noValuesOrValueDigestsPersisted'] and not value['rawDeepalApiManagerOriginalRead'] and
           value['URLComponentRepresentationIncludedByUnchangedVariantsFunction'] and not value['generalArbitraryDecodedCoverageClaimed'],
           'Deepal raw-body or decoding boundary differs')
        deepal_rows.append({**ref(path), 'completedAt': value['completedAt'], 'processId': value['processId']})
    summaries['deepal'] = {'asOf': max((row['completedAt'] for row in deepal_rows), default=None),
                           'completedInvocations': len(deepal_rows), 'receiptReferences': deepal_rows,
                           'classification': contract['classification'], 'adapterContract': ref(C / 'MINI-PRIVACY-ADAPTER-CONTRACT.json'),
                           'distinctValues': counters['deepalRuntimeValues'], 'variantForms': counters['deepalRuntimeForms'],
                           'uniqueOriginalFiles': len(expected_reads),
                           'payloadReadOperations': counters['deepalOriginalPayloadReadOperations'] * len(deepal_rows),
                           'noValuesOrValueDigestsPersisted': True, 'rawDeepalApiManagerOriginalRead': False,
                           'earlierV1ScansCountedSeparately': True}
    return summaries

def check_seed_summary(value, complete=False):
    actual = seed_summary()
    for kind in ('historical', 'audi'):
        selected, current = value[kind], actual[kind]
        refs = selected['receiptReferences']
        cutoff = selected['asOf']
        wanted = [row for row in current['receiptReferences'] if cutoff and row['completedAt'] <= cutoff]
        ck(refs == wanted and selected['completedInvocations'] == len(refs), 'seed as-of scope differs')
        for key, item in selected.items():
            if key not in ('asOf', 'completedInvocations', 'receiptReferences', 'targetedPinnedMemberReads', 'payloadReadOperations'):
                ck(current[key] == item, 'seed fixed scope differs')
        total = 'targetedPinnedMemberReads' if kind == 'historical' else 'payloadReadOperations'
        ck(selected[total] == len(refs) * (200 if kind == 'historical' else 6), 'seed total differs')
        if complete:
            ck(selected == current, 'terminal omits a seed invocation')
    inherited = value['inheritedLocal']
    count = value['historical']['completedInvocations']
    ck(count == value['audi']['completedInvocations'] and inherited ==
       {**actual['inheritedLocal'], 'completedInvocations': count, 'payloadValueReads': 48 * count,
        'streamingIntegrityReads': 48 * count}, 'inherited local seed totals differ')
    selected, current = value['deepal'], actual['deepal']
    refs = selected['receiptReferences']
    cutoff = selected['asOf']
    wanted = [row for row in current['receiptReferences'] if cutoff and row['completedAt'] <= cutoff]
    expected = {**current, 'asOf': cutoff, 'completedInvocations': len(refs), 'receiptReferences': wanted,
                'payloadReadOperations': current['uniqueOriginalFiles'] * len(refs)}
    ck(refs == wanted and selected == expected, 'Deepal seed as-of boundary or accounting differs')
    if complete:
        ck(value == actual, 'terminal seed account is incomplete')
    return {kind: {key: item for key, item in data.items() if key != 'receiptReferences'} for kind, data in value.items()}

def privacy(name, paths):
    value = load(C / name)
    ck(value['result'] == 'PASS' and not value['findings'] and not value['errors'] and
       value['currentCompletePatternScan'] and value['allKnownValueForms'], 'document privacy gate failed')
    ck(value['audiRuntimeValues'] == 6 and value['audiRuntimeForms'] == 37 and
       value['audiOriginalPayloadReadOperations'] == 6, 'current residual coverage differs')
    contract, counters, unused = deepal_adapter()
    ck(all(value[key] == number for key, number in counters.items()) and
       value['deepalAdapterContract'] == ref(C / 'MINI-PRIVACY-ADAPTER-CONTRACT.json') and
       value['privacyEngine'] == contract['engine'], 'inherited Deepal document residual coverage differs')
    seen = {}
    for row in value['files']:
        ck(row['filename'] not in seen and row['exactValueMatches'] == row['primaryCandidates'] == row['runtimeCandidates'] == 0,
           'duplicate privacy member or unresolved finding')
        ck(row['exactMatchesObserved'] == row['classifiedPublicLexicalCollisions'], 'privacy accounting differs')
        seen[row['filename']] = {key: row[key] for key in ('bytes', 'sha256')}
    ck(seen == {path.name: pin(path) for path in paths}, 'privacy input set or pins differ')
    return ref(C / name)


AUTHOR_INVENTORY = pathlib.Path('/tmp/mini-packet/final-freeze-v1/inventory.json')
AUTHOR_ACCEPTANCE = pathlib.Path('/tmp/mini-review/final-retention-v1-acceptance.json')
AUTHOR_INVENTORY_PIN = {'bytes': 145241, 'sha256': '320ae09e676a2166039cd574b2f32e1b481f12a71dc192cc4feeaa98997ede4e'}
AUTHOR_ACCEPTANCE_PIN = {'bytes': 5168, 'sha256': '83384b36822ebce9df12628b52f1c69e173b00419fc33411bb1807c99f5ca353'}
MINI_SUMMARY_PIN = {'bytes': 5601, 'sha256': '2b9edee6cfc1ee6a46245e9a73e50488c2b2512746fb8890ffe46615bf7010c2'}

def author_inputs():
    check(AUTHOR_INVENTORY, AUTHOR_INVENTORY_PIN)
    check(AUTHOR_ACCEPTANCE, AUTHOR_ACCEPTANCE_PIN)
    inventory, acceptance = load(AUTHOR_INVENTORY), load(AUTHOR_ACCEPTANCE)
    ck(acceptance['status'] == 'accepted' and acceptance['inventory'] == {'path': str(AUTHOR_INVENTORY), **AUTHOR_INVENTORY_PIN}, 'author acceptance does not bind final inventory')
    ck(inventory['noFurtherPayloadEdits'] and inventory['totalFiles'] == acceptance['payloadFiles'] == 534 and
       inventory['regularFileBytes'] == acceptance['payloadRegularBytes'] == 63855881 and inventory['symlinkCount'] == acceptance['symlinkCount'] == 0,
       'author frozen scope differs')
    ck(inventory['sourceAndStatusAfterPins'] == acceptance['sevenLiveTargetsExact'] and len(acceptance['sevenLiveTargetsExact']) == 7,
       'author seven-target pins differ')
    ck(len(inventory['retainedFailures']) == 1 and acceptance['retainedAllFailuresAndSupersededPreparations'], 'attempt retention boundary differs')
    return inventory, acceptance

def dependency_summary(dependency):
    ck(dependency['count'] == len(dependency['dependencies']) and dependency['count'] >= 119 and
       dependency['originalExpectedPathsAndHashesUnchanged'], 'dependency count or original expected-pin boundary differs')
    canonical = hashlib.sha256(json.dumps(dependency['dependencies'], sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    ck(canonical == dependency['dependenciesCanonicalSha256'], 'dependency mapping canonical hash differs')
    return {'receipt': ref(C / DEPENDENCY), 'count': dependency['count'],
            'relocatedMemberPointers': dependency['relocatedMemberPointers'], 'newRecords': dependency['newRecords']}

def saving_announcement():
    value = load(C / 'SAVING-ANNOUNCEMENT.json')
    ck(value['messageId'] == 'Sentinel_50a8ef96b63481919b0ada48075e1507' and
       value['sentAt'] == '2026-10-15T13:26:49.383159Z', 'saving announcement identity differs')
    return ref(C / 'SAVING-ANNOUNCEMENT.json')


def support_privacy_scope(gate, recovery):
    contract_path = C / 'MINI-SUPPORT-PRIVACY-CONTRACT-v1.json'
    contract = load(contract_path)
    ck(contract['result'] == 'APPROVED_MINI_SUPPORT_PRIVACY_ADAPTER', 'support-only privacy adapter not approved')
    names = {'supportEngine': 'privacy_v6_support.py',
             'supportSyntaxHandler': 'mini_support_classifications_v2.py',
             'supportSyntaxApproval': 'APPROVED-MINI-SUPPORT-SYNTAX.json',
             'classification': 'INDEPENDENT-MINI-SUPPORT-SYNTAX-CLASSIFICATION-v1.json',
             'baseEngine': 'privacy_v4.py'}
    for key in (*names, 'independentReview'):
        path = pathlib.Path(contract[key]['path'])
        ck(path.is_absolute() and path.parent == C and (key not in names or path.name == names[key]),
           'support-only dependency path differs: ' + key)
        check(path, contract[key])
    review_pin = {'path': str(C / 'INDEPENDENT-MINI-SUPPORT-ADAPTER-REVIEW-v1.json'),
                  'bytes': 3989, 'sha256': '883bd5606225e5a2edbf28960e315d5186697940dd38e08e4c8f34b6cf6b789f'}
    ck(contract['independentReview'] == review_pin and contract['exactApprovedCandidates'] == 2 and
       contract['noDetectorOrKnownValueSearchChanges'] and contract['supportArchiveOnly'] and
       contract['firstFourInitialCleanReportsReusedExactly'], 'support-only contract scope differs')
    review = load(review_pin['path'])
    ck(review['result'] == 'PASS_EXACT_SUPPORT_ONLY_ADAPTER_AND_FAIL_CLOSED_TESTS' and
       review['exactCandidates'] == 2 and review['testCount'] == len(review['tests']) == 10 and
       all(row['passed'] is True for row in review['tests']) and
       all(review[key] == contract[key] for key in names), 'support-only independent review differs')
    adapter, unused_counters, unused_reads = deepal_adapter()
    ck(contract['baseEngine'] == adapter['engine'], 'support hook changed the document/archive base scanner')
    classification_pin = {'bytes': 5561, 'sha256': 'ea6372b3f27bd1f5959c9332daec49a52e3f56d76f89979b82970cb9432a3fa4'}
    ck({key: contract['classification'][key] for key in ('bytes', 'sha256')} == classification_pin,
       'support classification identity differs')
    approval = load(contract['supportSyntaxApproval']['path'])
    classification = load(contract['classification']['path'])
    ck(approval['result'] == 'APPROVED_EXACT_SYNTAX_CLASSIFICATION' and
       approval['classificationPin'] == classification_pin and approval['exactCandidates'] == 2 and
       approval['detectorsAndValueSearchesUnchanged'] and approval['rawFindingCountsRetained'] and
       approval['payloadRedactions'] == 0, 'support syntax approval scope differs')
    ck(classification['result'] == 'INDEPENDENT_BENIGN_SYNTAX_PROPOSAL_REQUIRES_ROOT_APPROVAL' and
       classification['primaryCandidates'] == 2 and classification['rawRuntimeCandidates'] == 0 and
       classification['candidateMultisetMustMatchExactly'] and classification['wholeFilePinRequired'] and
       classification['allUnexpectedCandidatesBlock'] and classification['noDetectorChanges'] and
       classification['noPayloadEdits'], 'support classification boundary differs')
    rows = classification['exactSupportCodeClassifications']
    ck(len(rows) == 2 and all(row['member'] == 'mini-recovery-support/capture_v2.py' and row['astValid'] and
       row['isHeaderValueOrCredential'] is False and row['fileExtensionExemption'] is False and
       row['payloadChangeProposed'] is False for row in rows), 'support classification member/syntax differs')
    expected = [{'member': row['member'], 'filePin': row['filePin'],
                 'finding': {key: value for key, value in row['exactFinding'].items() if key != 'member'},
                 'classification': row['classification']} for row in rows]
    canonical = lambda items: sorted(json.dumps(row, sort_keys=True, separators=(',', ':')) for row in items)
    ck(len(set(canonical(expected))) == 2, 'duplicate approved support syntax findings')
    archive_rows = [row for row in gate['archives'] if row['archive'].endswith('-support.tar.xz')]
    ck(len(archive_rows) == 1, 'support archive privacy receipt is missing or duplicated')
    support_row = archive_rows[0]
    ck(support_row['classifiedExactCodeHeaderCandidates'] == gate['classifiedExactCodeHeaderCandidates'] == 2 and
       support_row['classifiedExactTemplateRuntimeCandidates'] == gate['classifiedExactTemplateRuntimeCandidates'] == 0 and
       all(row['classifiedExactCodeHeaderCandidates'] == 0 for row in gate['archives'] if row is not support_row),
       'support-only classification counts differ')
    report_path = pathlib.Path(support_row['report'])
    ck(report_path.is_absolute() and report_path.parent == C, 'support scan report is outside current checkpoint')
    check(report_path, support_row['reportPin'])
    report = load(report_path)
    ck(report['status'] == 'clean' and not any(report[key] for key in
       ('exactValueMatches', 'primaryHeaderCandidates', 'unclassifiedRuntimeCandidates', 'errors',
        'classifiedExactTemplateRuntimeCandidates')), 'support report has unresolved findings')
    retained_member = [row for row in report['members'] if row['path'] == 'mini-recovery-support/capture_v2.py']
    ck(len(retained_member) == 1 and all(row['filePin'] ==
       {key: retained_member[0][key] for key in ('bytes', 'sha256')} for row in rows),
       'support classification whole-file identity differs from scanned member')
    ck(len(report['classifiedExactCodeHeaderCandidates']) == 2 and
       canonical(report['classifiedExactCodeHeaderCandidates']) == canonical(expected),
       'missing, duplicate or unexpected support syntax classifications')
    ck(recovery['privacy']['exactPinnedCodeSyntaxClassifications'] == 2 and
       recovery['privacy']['exactPinnedTemplateSyntaxClassifications'] == 0 and
       recovery['inputPins']['supportPrivacyContract'] == {'path': str(contract_path), **pin(contract_path)},
       'fresh replay did not bind the exact support-only privacy adapter')
    return {'contract': ref(contract_path),
            **{key: contract[key] for key in (*names, 'independentReview')},
            'scanReport': {'path': str(report_path), **pin(report_path)},
            'exactApprovedSyntaxCandidates': 2, 'unresolvedCandidates': 0,
            'scope': 'Only two AST-bound noncredential syntax findings in the exact MINI capture_v2.py support member',
            'rawFindingsAndCountsRetained': True, 'payloadRedactions': 0,
            'documentScannerUnchanged': True, 'fileExtensionExemption': False,
            'unexpectedMissingOrDuplicateFindingsBlock': True}
