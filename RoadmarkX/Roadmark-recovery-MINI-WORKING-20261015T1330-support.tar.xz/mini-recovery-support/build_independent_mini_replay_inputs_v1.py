#!/usr/bin/env python3
"""Bind final immutable MINI replay metadata and exact completed scan/phase terminals."""
import ast,datetime,hashlib,json,pathlib,re,resource,stat,sys
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent;BASE=C.parent/'deepal-working-20261015T1110';OUT=C/'INDEPENDENT-MINI-REPLAY-INPUTS-v1.json';LIMIT=268435456

def ck(v,m):
 if not v:raise AssertionError(m)
def load(p):return json.loads(P(p).read_bytes())
def pin(p):
 p=P(p);s=p.lstat();ck(stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents),'unsafe metadata input');before=[s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev];h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(65536):h.update(b);n+=len(b)
 s=p.lstat();ck(before==[s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev] and n==s.st_size,'metadata mutated');return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
def main():
 ck(resource.getrlimit(resource.RLIMIT_AS)==(LIMIT,LIMIT),'256MiB ceiling absent');ck(not OUT.exists(),'preserve input binding')
 names={'scope':'FROZEN-CAPTURE-SCOPE.json','initialIdentities':'INDEPENDENT-MINI-INITIAL-IDENTITIES-v1.json','sourceCapture':'source-capture.json','proofCapture':'proof-capture-v1.json','sourcePackage':'source-package.json','proofPackages':'proof-packages-v1.json','supportInventory':'SUPPORT-MEMBER-INVENTORY.json','supportReuse':'SUPPORT-REUSE-MAPPING.json','supportPackage':'support-package.json','restorePlan':'RESTORE-PLAN.json','archivePlan':'ARCHIVE-PLAN.json','initialArchivePlan':'ARCHIVE-PLAN-initial.json','freshRestoreManifest':'FRESH-ONLY-RESTORE-MANIFEST.json','privacyGate':'ALL-ARCHIVE-PRIVACY-GATE.json','application':'APPLICATION-ASSERTION-CONTRACT.json','dependencyMap':'INHERITED-DEPENDENCY-RECONSTRUCTION-v1.json','dependencyProposal':'INDEPENDENT-MINI-DEPENDENCY-PROPOSAL-v1.json','copySanitation':'COPY-SANITATION-MAPPING.json','keyApprovals':'PROSE-KEY-RENAME-APPROVALS.json','symlinks':'SYMLINK-RECONSTRUCTION.json','seedProvenance':'SEED-PROVENANCE.json','inheritedLocalSeedScope':'INHERITED-LOCAL-SEED-READ-SCOPE.json','imageProvenance':'IMAGE-PROVENANCE-v2.json','privacyAdapterContract':'MINI-PRIVACY-ADAPTER-CONTRACT.json','supportPrivacyContract':'MINI-SUPPORT-PRIVACY-CONTRACT-v1.json','supportSyntaxClassification':'INDEPENDENT-MINI-SUPPORT-SYNTAX-CLASSIFICATION-v1.json','supportSyntaxApproval':'APPROVED-MINI-SUPPORT-SYNTAX.json','supportSyntaxReview':'INDEPENDENT-MINI-SUPPORT-ADAPTER-REVIEW-v1.json'}
 metadata={k:pin(C/n) for k,n in names.items()};gate=load(metadata['privacyGate']['path']);ck(gate['result']=='PASS','final privacy gate absent')
 scripts=[]
 for p in sorted(C.glob('*.py')):ast.parse(p.read_bytes());scripts.append(pin(p))
 ck(any(r['path']==str(C/'independent_mini_recovery_v1.py') for r in scripts),'independent checker absent')
 final_reports={str(C/r['report']) if not P(r['report']).is_absolute() else r['report'] for r in gate['archives']};scans=[];scan_terminals=set()
 for p in sorted(C.glob('*.resources.json')):
  term=load(p);cmd=term.get('command',[])
  if not any(P(a).name.startswith('privacy_v') and P(a).suffix=='.py' for a in cmd):continue
  ck(len(cmd)==5 and P(cmd[1]) in (C/'privacy_v4.py',C/'privacy_v6_support.py'),'unreviewed production scanner invocation');rp,pp=P(cmd[3]),P(cmd[4]);ck(rp.parent==C and pp in (C/'ARCHIVE-PLAN-initial.json',C/'ARCHIVE-PLAN.json'),'scanner report/plan locator differs')
  report=load(rp);code=term['exitCode'];final=str(rp) in final_reports;ck(code in (0,2) and not term['timedOut'] and term['addressSpaceLimitBytes']==LIMIT,'partial/unbounded scanner attempt requires review')
  ck(report['status']==('clean' if code==0 else 'review-required') and (not final or code==0),'final scanner did not pass');ck(report['archive']==P(cmd[2]).name,'scan archive argument differs')
  plan_key='initialArchivePlan' if pp.name=='ARCHIVE-PLAN-initial.json' else 'archivePlan';ck(P(cmd[1])==C/('privacy_v4.py' if plan_key=='initialArchivePlan' else 'privacy_v6_support.py'),'support-only scanner selection differs');scans.append({'archive':report['archive'],'report':pin(rp),'terminal':pin(p),'command':cmd,'archivePlan':metadata[plan_key],'expectedExitCode':code,'finalCoverage':final});scan_terminals.add(str(p))
 ck({r['report']['path'] for r in scans if r['finalCoverage']}==final_reports and len(final_reports)==len(gate['archives']),'final scan terminal coverage differs')
 phases=[];preflights=[];classes=load(metadata['supportSyntaxClassification']['path'])['exactSupportCodeClassifications']
 for p in sorted(C.glob('*.resources.json')):
  if str(p) in scan_terminals:continue
  v=load(p);code=v['exitCode'];allowed_failure=p.name=='freeze-scope-v1.resources.json' and code==1
  match=re.fullmatch(r'support-pattern-preflight-v(\d+)\.resources\.json',p.name)
  allowed_preflight=bool(match) and code==2
  ck(code==0 or allowed_failure or allowed_preflight,'unreviewed preparatory failure: '+p.name)
  if match:
   rp=C/('MINI-SUPPORT-PATTERN-PREFLIGHT-v'+match.group(1)+'.json');raw=load(rp);ck(raw['result']=='REVIEW_REQUIRED' and raw['rawPatternsUnchanged'] and not raw['knownValueSearchPerformed'] and raw['seedReads']==raw['historicalArchiveReads']==0 and not raw['payloadsModified'] and not raw['newClassificationsGranted'],'support preflight boundary differs')
   candidates=[]
   for row in raw['files']:
    ck(row['astValid'] and not row['rawRuntimeFindings'],'unexpected support runtime/AST findings')
    for finding in row['primaryFindings']:
     member='mini-recovery-support/'+row['filename'];matches=[r for r in classes if r['member']==member and r['filePin']=={k:row[k] for k in ('bytes','sha256')} and r['exactFinding']=={'member':member,**finding}];ck(len(matches)==1,'unapproved raw support candidate');candidates.append(matches[0])
   ck(len(candidates)==2 and sorted(json.dumps(r,sort_keys=True) for r in candidates)==sorted(json.dumps(r,sort_keys=True) for r in classes),'support raw candidate multiset differs')
   preflights.append({'version':int(match.group(1)),'report':pin(rp),'terminal':pin(p),'newExecutableFiles':raw['newExecutableFiles'],'primaryCandidates':2,'rawRuntimeCandidates':0})
  if allowed_failure:ck(load(C/'INDEPENDENT-MINI-FREEZE-FIX-REVIEW-v2.json')['preservedFailureTerminal']==pin(p),'failed freeze not bound to reviewed correction')
  phases.append({'phase':p.name.removesuffix('.resources.json'),'terminal':pin(p),'command':v['command'],'expectedExitCode':code})
 ck(preflights,'raw support preflight absent');latest=max(preflights,key=lambda r:r['version']);latest_report=load(latest['report']['path']);tested={(r['bytes'],r['sha256']) for r in latest_report['files']};base=load(BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-DEEPAL-WORKING-20261015.json');inherited={(r['bytes'],r['sha256']) for r in base['files'] if r['path'].endswith('.py')};ck(all((r['bytes'],r['sha256']) in tested|inherited for r in scripts),'new script missing from final preflight')
 counts={k:len(list((C/d).glob('*.json'))) for k,d in [('historical','seed-read-invocations'),('audi','audi-seed-read-invocations'),('deepal','deepal-seed-read-invocations')]};ck(all(n==len(scans) for n in counts.values()),'seed completion counts differ from exact production scans')
 result={'result':'APPROVED_PINNED_FRESH_REPLAY_INPUTS','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'metadata':metadata,'scriptPins':scripts,'phaseCommands':phases,'scanReports':scans,'expectedScanInvocations':counts,'supportPatternPreflights':preflights,'baseTerminalReceipt':pin(BASE/'FINAL-DEEPAL-UPLOAD-RECEIPTS.json'),'noSourceArchiveOrSeedPayloadReads':True,'postSealMetadataBindingOnly':True}
 for r in list(metadata.values())+scripts:ck(pin(r['path'])==r,'input mutated during binding')
 with OUT.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({'result':result['result'],'metadataPins':len(metadata),'scriptPins':len(scripts),'phaseTerminals':len(phases),'scanAttempts':len(scans),'seedInvocations':counts,'outputPin':pin(OUT)}))
if __name__=='__main__':main()
