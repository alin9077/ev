#!/usr/bin/env python3
"""Independent MINI fresh-member streaming replay; no inherited archive or restore-tree reads."""
import copy,datetime,hashlib,json,lzma,pathlib,resource,stat,sys,tarfile,time,traceback
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent;R=C.parents[1];W=R.parent;BASE=C.parent/'deepal-working-20261015T1110';AUDI=C.parent/'audi-working-20261015T0800';LABEL='MINI-WORKING-20261015T1330';LIMIT=268435456;CHUNK=65536
OUT=C/'INDEPENDENT-MINI-RECOVERY-VERIFICATION-v1.json';REPLAY=C/'INDEPENDENT-NEW-MEMBER-REPLAY-MANIFEST-v1.json';START=time.monotonic();RESULT={'result':'IN_PROGRESS'}
def ck(v,m):
 if not v:raise AssertionError(m)
def load(p):return json.loads(P(p).read_bytes())
def encoded(v):return (json.dumps(v,indent=2)+'\n').encode()
def sizehash(r):return {k:r[k] for k in ('bytes','sha256')}
def core(r):return {k:r[k] for k in ('path','bytes','sha256')}
def original(r):return {'bytes':r['originalBytes'],'sha256':r['originalSHA256']}
def pinbytes(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(p,v):
 with P(p).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def identity(p):
 p=P(p);s=p.lstat();ck(stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents),'nonregular/symlink input '+str(p));return [s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev]
def pin(p):
 p=P(p);a=identity(p);h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(CHUNK):h.update(b);n+=len(b)
 ck(identity(p)==a and n==a[0],'unstable file '+str(p));return {'bytes':n,'sha256':h.hexdigest()}
def check(p,r):
 a=pin(p);ck(a==sizehash(r),'pin differs '+str(p));return a
def safe(n):
 p=P(n);ck(n and not p.is_absolute() and '..' not in p.parts and str(p)==n and '\\' not in n,'unsafe archive member')
def rows_map(rows):
 out={}
 for r in rows:safe(r['path']);ck(r['path'] not in out,'duplicate member');out[r['path']]=core(r)
 return out
def restore_path(p):
 p=P(p)
 if p.is_relative_to('/tmp'):n=p.relative_to('/tmp').as_posix()
 elif p.is_relative_to(W/'roadmark-104'):n='roadmark/'+p.relative_to(W/'roadmark-104').as_posix()
 else:ck(p.is_relative_to(W/'roadmark-104-qa') or p.is_relative_to(W/'roadmark-104-visual-qa-20261015'),'unexpected restore root');n=p.relative_to(W).as_posix()
 safe(n);return n
def pointer(x,p):
 if not p:return x
 ck(p.startswith('/'),'invalid JSON pointer')
 for k in p.split('/')[1:]:k=k.replace('~1','/').replace('~0','~');x=x[int(k)] if isinstance(x,list) else x[k]
 return x
def terminal(path,command,expected_exit=0):
 path=P(path);ip=path.with_name(path.stem+'.invocation.json');t,i=load(path),load(ip)
 ck(t['command']==i['command']==command and t['exitCode']==expected_exit and not t['timedOut'],'terminal command/outcome differs '+path.name)
 ck(t['addressSpaceLimitBytes']==i['addressSpaceLimitBytes']==LIMIT and t['wallLimitSeconds']==i['wallLimitSeconds']==600 and t['childPid']==i['childPid'],'terminal bounds differ')
 ck(t['maxRssKiB']>0,'missing resource metric')
 return {'receipt':{'path':str(path),**pin(path)},'invocation':{'path':str(ip),**pin(ip)},'command':command,'exitCode':expected_exit,'addressSpaceLimitBytes':LIMIT,'maxRssKiB':t['maxRssKiB'],'wallSeconds':t['wallSeconds']}
def seed_ledgers(entries,metadata):
 terminals=[(P(e['terminal']['path']),load(e['terminal']['path'])) for e in entries];declared={str(p) for p,t in terminals}
 for p in C.glob('*.resources.json'):
  t=load(p)
  if any(P(a).name.startswith('privacy_v') and P(a).suffix=='.py' for a in t.get('command',[])):ck(str(p) in declared,'unaccounted production scan attempt')
 ck(all(t['exitCode'] in (0,2) for p,t in terminals),'partial seed attempt requires separate exact accounting')
 ap=AUDI/'INDEPENDENT-AUDI-RUNTIME-BATCH-CLASSIFICATION-v1.json';check(ap,{'bytes':720844,'sha256':'4bb97b40446fad1a43e08b498ebdab7e1c82af35470de5b83419932047f3eb5a'})
 ar=load(ap);by={r['member']:r for r in ar['files']};audi=[]
 for g in ar['newValueSources']:
  s=g['sources'][0];r=by[s['member']];audi.append({'valueGroup':g['id'],'path':r['originalPath'],'pin':r['originalPin'],'byteStart':s['byteStart'],'byteEndExclusive':s['byteEndExclusive'],'payloadReadOperations':1})
 dp=BASE/'INDEPENDENT-DEEPAL-RUNTIME-CLASSIFICATION-v3.json';check(dp,{'bytes':52667,'sha256':'b448315960f3e54d72ff0133ca296094bc7ab9503bbc8233ea455a8cd6f2484d'})
 dr=load(dp);deepal=[{'path':r['capturedPayloadPath'],'pin':r['originalPin'],'payloadReadOperations':1,'valueRanges':len(r['ranges'])} for r in dr['files']]
 result={}
 for key,folder in [('historical','seed-read-invocations'),('audi','audi-seed-read-invocations'),('deepal','deepal-seed-read-invocations')]:
  out=[]
  for p in sorted((C/folder).glob('*.json')):
   r=load(p)
   if key=='historical':ck(r['exactPinnedMembersReadAndVerified']==200 and r['historicalArchives']==21 and r['noExtractedValuesPersisted'] and r['memberIdentityListPin']==sizehash(metadata['seedProvenance']),'historical seed scope differs')
   elif key=='audi':ck(r['distinctValues']==6 and r['variantForms']==37 and r['payloadReadOperations']==6 and r['uniqueOriginalFiles']==4 and r['reads']==audi and r['classificationReceiptPin']==pin(ap) and r['noValuesOrValueDigestsPersisted'] and not r['generalURLDecodedRuntimeCoverageClaimed'],'Audi seed scope differs')
   else:ck(r['distinctValues']==6 and r['variantForms']==41 and r['payloadReadOperations']==5 and r['reads']==deepal and r['classificationReceiptPin']==pin(dp) and r['noValuesOrValueDigestsPersisted'] and not r['rawDeepalApiManagerOriginalRead'] and r['URLComponentRepresentationIncludedByUnchangedVariantsFunction'],'Deepal seed scope differs')
   when=datetime.datetime.fromisoformat(r['completedAt']);matches=[(p,t) for p,t in terminals if t['childPid']==r['processId'] and datetime.datetime.fromisoformat(t['startedAt'])<=when<=datetime.datetime.fromisoformat(t['endedAt'])]
   ck(len(matches)==1,'seed completion has no unique invocation');out.append({'receipt':{'path':str(p),**pin(p)},'terminal':str(matches[0][0]),'processId':r['processId'],'completedAt':r['completedAt']})
  ck(len(out)==len(terminals) and {r['terminal'] for r in out}==declared,'missing/duplicate seed completion ledger');result[key]=out
 local=load(metadata['inheritedLocalSeedScope']['path']);ck(local['result']=='EXACT_UNCHANGED_SELECTOR_ACCOUNTING_SPECIFICATION' and len(local['files'])==48 and local['payloadValueReadsPerSuccessfulInvocation']==local['streamingIntegrityReadsPerSuccessfulInvocation']==48,'inherited local seed scope differs')
 ck(all(r['payloadValueReadsPerSuccessfulInvocation']==r['streamingIntegrityReadsPerSuccessfulInvocation']==1 for r in local['files']),'local per-file control flow differs')
 for r in local['metadataPins']:check(r['path'],r)
 return result

def main():
 ck('--sole-child-slot-authorized' in sys.argv,'explicit heavy slot required');ck(resource.getrlimit(resource.RLIMIT_AS)==(LIMIT,LIMIT),'256MiB ceiling absent');ck(not OUT.exists() and not REPLAY.exists(),'preserve earlier outcome')
 ip=C/'INDEPENDENT-MINI-REPLAY-INPUTS-v1.json';inputs=load(ip);ipin=pin(ip);ck(inputs['result']=='APPROVED_PINNED_FRESH_REPLAY_INPUTS','replay inputs not approved');metadata=inputs['metadata'];docs={}
 required={'scope','initialIdentities','sourceCapture','proofCapture','sourcePackage','proofPackages','supportInventory','supportReuse','supportPackage','restorePlan','archivePlan','initialArchivePlan','freshRestoreManifest','privacyGate','application','dependencyMap','dependencyProposal','copySanitation','keyApprovals','symlinks','seedProvenance','inheritedLocalSeedScope','imageProvenance','privacyAdapterContract','supportPrivacyContract'}
 ck(required<=set(metadata) and set(metadata)<=required|{'supportSyntaxClassification','supportSyntaxApproval','supportSyntaxReview','dependencyReview'},'unexpected replay metadata keys')
 for k,r in metadata.items():check(r['path'],r);docs[k]=load(r['path'])
 for r in inputs['scriptPins']:check(r['path'],r)
 adapter=docs['privacyAdapterContract'];ck(adapter['result']=='APPROVED_MINI_INHERITED_PRIVACY_ADAPTER','privacy adapter not approved')
 inherited_adapter=load(BASE/'DEEPAL-PRIVACY-ADAPTER-CONTRACT.json');check(BASE/'DEEPAL-PRIVACY-ADAPTER-CONTRACT.json',adapter['inheritedContract'])
 for k in ('classification','approval','additiveInventory','classificationCounterPointers'):ck(adapter[k]==inherited_adapter[k],'inherited adapter metadata changed')
 for k in ('engine','addition','engineAdaptationReview','captureScannerAdapterReview','freezeCorrectionReview'):check(adapter[k]['path'],adapter[k])
 er=load(adapter['engineAdaptationReview']['path']);ck(er['result']=='PASS_EXACT_PLAN_FILENAME_ALLOWLIST_ADDITION' and er['script']==adapter['engine'],'engine adaptation review differs');check(er['previousScript']['path'],er['previousScript'])
 before=P(er['previousScript']['path']).read_bytes();after=P(adapter['engine']['path']).read_bytes();needle=b"('ARCHIVE-PLAN-sanitized-v1.json','ARCHIVE-PLAN.json')";replacement=b"('ARCHIVE-PLAN-initial.json','ARCHIVE-PLAN-sanitized-v1.json','ARCHIVE-PLAN.json')";ck(before.count(needle)==1 and after==before.replace(needle,replacement),'scanner differs beyond reviewed plan pointer')
 ck(any(P(r['path'])==P(__file__) for r in inputs['scriptPins']),'verifier unpinned')
 phases={r['phase']:terminal(r['terminal']['path'],r['command'],r.get('expectedExitCode',0)) for r in inputs['phaseCommands']};ck(len(phases)==len(inputs['phaseCommands']),'duplicate phase')
 basepath=BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-DEEPAL-WORKING-20261015.json';check(basepath,{'bytes':3072311,'sha256':'66775e32af7363d434c290ac3b0f6ff55639d61f4aae2ae7c7f1d4a509372ce6'});base=load(basepath);old=rows_map(base['files']);ck(len(old)==12076 and len(base['archivesInRestoreOrder'])==129,'base closure counts differ')
 check(BASE/'FINAL-DEEPAL-UPLOAD-RECEIPTS.json',inputs['baseTerminalReceipt'])
 scope,idsdoc=docs['scope'],docs['initialIdentities'];ck(idsdoc['result']=='PASS_EXACT_537_SELECTED_FILE_INITIAL_IDENTITY_BINDING' and idsdoc['identityFields']==['size','mtimeNs','ctimeNs','inode','device'] and idsdoc['atimeExcluded'],'initial identity contract differs');check(metadata['scope']['path'],idsdoc['frozenScope'])
 ids={r['path']:r['identity'] for r in idsdoc['files']};frozen={restore_path(r['path']):r for r in scope['files']};ck(len(ids)==len(frozen)==len(scope['files'])==537,'selected scope differs')
 ck(scope['authorInventory']['sha256']=='320ae09e676a2166039cd574b2f32e1b481f12a71dc192cc4feeaa98997ede4e' and scope['finalRetentionReview']['sha256']=='83384b36822ebce9df12628b52f1c69e173b00419fc33411bb1807c99f5ca353','accepted freeze differs')
 sc,pc=docs['sourceCapture'],docs['proofCapture'];prior={r['path']:r for r in load(BASE/'source-capture.json')['files']};current={r['path']:r for r in sc['files']};captured={r['path']:r for r in pc['files']};delta={r['path']:r for r in pc['changedFiles']}
 ck(len(current)==len(sc['files'])==scope['expectedSourceFiles']==691 and set(prior)<=set(current),'full source membership differs');changed={n for n,r in current.items() if n not in prior or original(r)!=original(prior[n])};ck(changed==set(scope['sourceChangedPaths']) and len(changed)==6,'source delta differs')
 state=(C/'WORKING-STATE.txt').read_text();ck(sc['state']==pc['state']==state==scope['workingResult']+'\n' and sc['chunkBytes']==pc['chunkBytes']==CHUNK and not sc['fullSourceTreeCloned'] and pc['noBroadQaTraversal'] and not sc['sourceChangesDuringCapture'] and not pc['sourceChangesDuringCapture'],'capture scope/stability differs')
 for n,r in current.items():
  safe(n);ck(r['originalPath']==str(W/'roadmark-104'/n),'source path differs')
  if n in changed:
   f=frozen['roadmark/'+n];ck(original(r)==sizehash(r)==sizehash(f) and r['sourceIdentity']==ids[r['originalPath']],'source changed bytes/identity differ')
  else:
   o=prior[n];ck(all(r.get(k,[])==o.get(k,[]) for k in ('bytes','sha256','originalBytes','originalSHA256','redactedHeaderPaths','redactedPointers','redactedHTMLRanges')) and r['payloadPath']==o['payloadPath'] and r['captureMethod']=='exact-original-and-prior-sanitized-hashes','unchanged source reuse differs')
 ck(len(captured)==len(pc['files'])==537 and len(delta)==len(pc['changedFiles']) and pc['scope']==scope,'proof selection differs')
 ck(docs['copySanitation']['result']=='NO_NEW_TRANSFORMATIONS' and docs['copySanitation']['files']==docs['keyApprovals']['files']==[] and docs['copySanitation']['locationCount']==0,'new copy transformation requires reviewed verifier adaptation')
 covered=[];reused=[]
 for n,f in frozen.items():
  r=captured[n];ck(r['originalPath']==f['path'] and r['sourceIdentity']==ids[f['path']] and original(r)['bytes']==f['bytes'],'proof original scope/identity differs')
  if f.get('sha256'):ck(original(r)['sha256']==f['sha256'],'frozen known pin differs')
  if n.startswith('roadmark/'):
   s=current[n[9:]];ck(core(r)=={'path':n,**sizehash(s)} and original(r)==original(s) and r['captureMethod']=='covered-by-full-source' and n not in delta,'source-covered proof differs');covered.append(n)
  elif n in delta:ck(r==delta[n] and r['archiveAction']=='new-delta-member' and sizehash(r)==original(r) and not any(r.get(k) for k in ('metadataKeyRename','redactedPointers','redactedHTMLRanges')),'proof delta transformed');
  else:ck(core(r)==old[n] and r['archiveAction']=='reuse-exact-base-member','base proof reuse differs');reused.append(n)
 ck(len(covered)==6 and len(reused)==6 and len(delta)==525,'selected disposition counts differ')
 expected_preview=['roadmark-104-visual-qa-20261015/'+n for n in ['launch-receipt.json','market-check.log','server.log','snapshot-manifest.json','stop-receipt.json','visual-qa-blocker-receipt.json']]
 ck(sorted(reused)==expected_preview and len(scope['exactBaseReusedPreviewReceipts'])==6,'historical preview selection differs')
 for r in scope['exactBaseReusedPreviewReceipts']:ck(r['member'] in reused and sizehash(r)==sizehash(old[r['member']]),'preview reuse identity differs')
 links=docs['symlinks'];ck(links['result']=='EXACT_METADATA_AND_MEMBER_MAPPING' and links['noTraversalOrDependencyCapture'] and links['links']==scope['metadataOnlySymlinks']==[],'symlink contract differs')
 source,proof,support=docs['sourcePackage'],docs['proofPackages']['archives'],docs['supportPackage'];sinv,sreuse=docs['supportInventory'],docs['supportReuse'];archives=docs['archivePlan']['archives'];plan=docs['restorePlan']
 ck(docs['initialArchivePlan']['archives']==[source]+proof,'initial archive plan differs');ck([{k:v for k,v in r.items() if k!='restoreOrder'} for r in archives]==[source]+proof+[support] and archives==plan['newArchives'],'final archive order differs')
 generated={'roadmark/SOURCE-FILE-MANIFEST.json':encoded({'schemaVersion':1,'root':'roadmark','files':[core(r) for r in sc['files']]})}
 source_members={'roadmark/'+n:{'path':'roadmark/'+n,**sizehash(r)} for n,r in current.items()};source_members['roadmark/SOURCE-FILE-MANIFEST.json']={'path':'roadmark/SOURCE-FILE-MANIFEST.json',**pinbytes(generated['roadmark/SOURCE-FILE-MANIFEST.json'])}
 ck(rows_map(source['memberFiles'])==source_members and [r['path'] for r in source['memberFiles']]==list(source_members) and source['bytes']<15000000,'source member identity/order/size differs')
 groups=[];group=[];count=0
 for r in pc['changedFiles']:
  if group and count+r['bytes']>24000000:groups.append(group);group=[];count=0
  group.append(r);count+=r['bytes']
 if group:groups.append(group)
 ck(len(groups)==len(proof),'proof group count differs')
 for i,(group,a) in enumerate(zip(groups,proof),1):
  n=f'recovery-metadata/{LABEL}-part{i:02d}.json';v={'schemaVersion':1,'label':LABEL,'part':i,'parts':len(groups),'state':pc['state'],'files':[{k:r[k] for k in ('path','bytes','sha256','originalBytes','originalSHA256')} for r in group],'restore':'Overlay after the exact 129-archive Deepal chain, replacing its source archive with this full registered MINI working source. Original raw-capture expected hashes remain unchanged; exact copy-only changes are recorded in the retained sanitation mapping.'};generated[n]=encoded(v);members=rows_map(group);members[n]={'path':n,**pinbytes(generated[n])}
  if i==1:n='mini-safety-support/COPY-SANITATION-MAPPING.json';generated[n]=P(metadata['copySanitation']['path']).read_bytes();members[n]={'path':n,**pinbytes(generated[n])}
  ck(rows_map(a['memberFiles'])==members and [r['path'] for r in a['memberFiles']]==list(members) and a['filename']==f'Roadmark-recovery-{LABEL}-part{i:02d}of{len(groups):02d}.tar.xz','proof metadata/member/name differs')
 check(metadata['scope']['path'],sinv['scopePin']);check(metadata['supportReuse']['path'],sinv['reuseMapping']);check(basepath,sreuse['baseManifestPin']);ck(sinv['status']=='SEALED_UNIQUE_SUPPORT' and sreuse['result']=='EXACT_BYTE_REUSE','support selection not sealed')
 aliases=sreuse['files'];new_support=rows_map(sinv['files']);retained_paths={r['payloadPath'] for r in sinv['files']};alias_paths={r['originalPath'] for r in aliases};ck(len(retained_paths)==len(sinv['files']) and len(alias_paths)==len(aliases) and not retained_paths&alias_paths,'support input duplicate')
 ck(sinv['selectedLocalSupportFiles']==len(sinv['files'])-1+len(aliases) and sinv['uniqueNewFiles']==len(sinv['files']) and sinv['exactReusedOrAliasedFiles']==len(aliases),'support counts differ')
 for r in sinv['files']:
  local=P(r['payloadPath']).relative_to(C).as_posix();safe(local);ck(r['path']=='mini-recovery-support/'+local,'support member locator differs');check(r['payloadPath'],r)
 for r in aliases:
  p=P(r['originalPath']);ck(p.is_relative_to(C) and p.relative_to(C).as_posix()==r['localRelativePath'],'support alias locator differs');check(p,r);target=r['retainedMember'];expected=old if r['kind']=='exact-inherited-member' else new_support;ck(r['kind'] in ('exact-inherited-member','exact-new-unique-member-alias') and target in expected and sizehash(expected[target])==sizehash(r),'support alias identity differs')
 scripts=[r for r in sinv['files'] if P(r['payloadPath']).suffix=='.py'];script_bytes={(r['bytes'],r['sha256']) for r in scripts};inherited_script_bytes={(r['bytes'],r['sha256']) for r in base['files'] if r['path'].endswith('.py')};ck(len(script_bytes)==len(scripts) and not script_bytes&inherited_script_bytes,'duplicate executable source bytes')
 for r in inputs['scriptPins']:ck(r['path'] in retained_paths|alias_paths,'support missing script')
 for p in C.glob('*.py'):ck(str(p) in retained_paths|alias_paths,'unretained script version '+p.name)
 ck(str(P(__file__)) in retained_paths,'verifier missing from support');members=rows_map(sinv['files']);n=f'recovery-metadata/{LABEL}-support.json';generated[n]=encoded(sinv);members[n]={'path':n,**pinbytes(generated[n])};ck(rows_map(support['memberFiles'])==members and [r['path'] for r in support['memberFiles']]==list(members),'support metadata union/order differs')
 app=docs['application'];ck(app['result']=='APPROVED_EXACT_CAPTURED_APPLICATION_ASSERTIONS' and app['summary']['scopedTests']==151 and app['summary']['fullProjectTypeScriptRoots']==361 and app['summary']['normalReportRuns']==1 and app['summary']['retainedExecutedFailureBoundaries']==1,'application contract scope differs')
 ck(len(app['assertions'])==187 and len(app['retainedPins'])==149,'exact application contract counts differ')
 prior_app_path=BASE/'APPLICATION-ASSERTION-CONTRACT.json';prior_replay_path=BASE/'INDEPENDENT-DEEPAL-RECOVERY-VERIFICATION-v1.json'
 check(prior_app_path,base['independentVerification']['applicationContract']);check(prior_replay_path,base['independentVerification']['receipt'])
 prior_app,prior_replay=load(prior_app_path),load(prior_replay_path);ck(prior_replay['result']=='PASS' and prior_replay['application']['contract']==prior_replay['inputPins']['application'] and sizehash(prior_replay['application']['contract'])==pin(prior_app_path),'prior application replay binding differs')
 assertions={};inherited_assertions=[]
 for a in app['assertions']:
  if a['restorePath'] in reused:
   ck(a in prior_app['assertions'] and a['restorePath']=='roadmark-104-visual-qa-20261015/visual-qa-blocker-receipt.json','inherited assertion not covered by exact prior replay');inherited_assertions.append(a)
  else:assertions.setdefault(a['restorePath'],[]).append(a)
 ck(len(inherited_assertions)==4,'inherited application assertion count differs')
 scans=inputs['scanReports'];byarchive={}
 for e in scans:
  for k in ('report','terminal','archivePlan'):check(e[k]['path'],e[k])
  if e.get('finalCoverage',True):ck(e['archive'] not in byarchive,'duplicate final scan coverage');byarchive[e['archive']]=e
 ck(set(byarchive)=={r['filename'] for r in archives},'scan archive coverage differs')
 baseline=load(BASE/'scan-sanitized-01.json');expected_counts={k:v for k,v in baseline.items() if k in ('historicalValues','historicalForms','mercedesValues','mercedesForms','originalSeedMembers','leapmotorCookieAndHeaderValues','leapmotorCookieForms','mazdaCookieAndHeaderValues','mazdaCookieForms','mazdaPublicBareValues','mazdaPublicBareForms','mazdaCompleteHeaderValues','mazdaCompleteHeaderForms','mazdaCookiePairValues','mazdaCookiePairForms','mazdaFormTokenValues','mazdaFormTokenForms','audiRuntimeValues','audiRuntimeForms','audiOriginalPayloadReadOperations','deepalRuntimeValues','deepalRuntimeForms','deepalOriginalPayloadReadOperations')}
 cache_source={r['path']:r for r in load(C.parent/'xpeng-registered-working-20261014T2030'/'source-capture.json')['files']}
 code_classifications=docs.get('supportSyntaxClassification',{}).get('exactSupportCodeClassifications',[])
 ck(len(code_classifications)==2 and docs['supportSyntaxApproval']['result']=='APPROVED_EXACT_SYNTAX_CLASSIFICATION' and docs['supportSyntaxApproval']['exactCandidates']==2 and docs['supportSyntaxApproval']['classificationPin']==sizehash(metadata['supportSyntaxClassification']),'current syntax approval missing')
 support_adapter=docs['supportPrivacyContract'];ck(support_adapter['result']=='APPROVED_MINI_SUPPORT_PRIVACY_ADAPTER','support-only adapter approval absent')
 for k in ('baseEngine','supportEngine','supportSyntaxHandler','supportSyntaxApproval','classification','independentReview'):check(support_adapter[k]['path'],support_adapter[k])
 ck(support_adapter['baseEngine']==adapter['engine'] and support_adapter['classification']==metadata['supportSyntaxClassification'] and support_adapter['supportSyntaxApproval']==metadata['supportSyntaxApproval'] and support_adapter['independentReview']==metadata['supportSyntaxReview'],'support adapter pin identity differs')
 review=docs['supportSyntaxReview'];ck(review['result']=='PASS_EXACT_SUPPORT_ONLY_ADAPTER_AND_FAIL_CLOSED_TESTS' and review['exactCandidates']==2 and review['testCount']==10 and len(review['tests'])==10 and all(r['passed'] for r in review['tests']),'strict support adapter tests absent')
 for k in ('baseEngine','supportEngine','supportSyntaxHandler','classification','supportSyntaxApproval'):ck(review[k]==support_adapter[k],'support adapter review binding differs')
 v4=P(support_adapter['baseEngine']['path']).read_bytes();v6=P(support_adapter['supportEngine']['path']).read_bytes();hook=b'from mini_support_classifications_v2 import code_context as mini_code_context;ps,classified=mini_code_context(ps,data,m.name);codeClassified.extend(classified);';needle=b'us,classified=template_context(us,data,m.name);';ck(v4.count(needle)==1 and v6==v4.replace(needle,hook+needle),'support-only engine diff differs')
 preflights=inputs['supportPatternPreflights'];ck(preflights,'support raw preflight absent')
 for entry in preflights:
  check(entry['report']['path'],entry['report']);check(entry['terminal']['path'],entry['terminal']);raw=load(entry['report']['path']);ck(raw['result']=='REVIEW_REQUIRED' and raw['rawPatternsUnchanged'] and not raw['knownValueSearchPerformed'] and raw['seedReads']==raw['historicalArchiveReads']==0,'raw preflight scope differs');raw_candidates=[]
  for row in raw['files']:
   ck(row['astValid'] and not row['rawRuntimeFindings'],'unresolved raw support runtime candidate')
   for finding in row['primaryFindings']:
    member='mini-recovery-support/'+row['filename'];matches=[r for r in code_classifications if r['member']==member and r['filePin']==sizehash(row) and r['exactFinding']=={'member':member,**finding}];ck(len(matches)==1,'unapproved raw support primary candidate');raw_candidates.append(matches[0])
  ck(len(raw_candidates)==2 and sorted(json.dumps(r,sort_keys=True) for r in raw_candidates)==sorted(json.dumps(r,sort_keys=True) for r in code_classifications),'raw support multiset differs')
 latest=load(max(preflights,key=lambda r:r['version'])['report']['path']);tested={(r['bytes'],r['sha256']) for r in latest['files']};ck(all((r['bytes'],r['sha256']) in tested|inherited_script_bytes for r in inputs['scriptPins']),'final script missing raw preflight')
 classified_members={r['member'] for r in code_classifications};fresh={};verified=[];scan_rows=[];checked=0
 for index,a in enumerate(archives,1):
  path=P(a['file']);ck(path.parent==R and path.name==a['filename'],'archive locator differs');check(path,a);wanted=rows_map(a['memberFiles']);actual={}
  with lzma.open(path,'rb') as stream:
   with tarfile.open(fileobj=stream,mode='r|') as tar:
    for member in tar:
     safe(member.name);ck(member.isfile() and member.name in wanted and member.name not in actual and member.name not in fresh,'unsafe/unexpected/duplicate fresh member');h=hashlib.sha256();count=0;parts=[] if member.name in generated or member.name in assertions or member.name in classified_members else None
     with tar.extractfile(member) as payload:
      while b:=payload.read(CHUNK):h.update(b);count+=len(b);parts.append(b) if parts is not None else None
     row={'path':member.name,'bytes':count,'sha256':h.hexdigest()};ck(row==wanted[member.name] and count==member.size,'fresh member bytes differ '+member.name);actual[member.name]=row;fresh[member.name]=row
     if parts is not None:
      data=b''.join(parts)
      if member.name in generated:ck(data==generated[member.name],'generated metadata differs')
      for r in code_classifications:
       if r['member']==member.name:ck(sizehash(r['filePin'])==pinbytes(data) and hashlib.sha256(data[r['byteStart']:r['byteEndExclusive']]).hexdigest()==r['matchedSyntaxSHA256'],'classified syntax bytes differ')
      if member.name in assertions:
       value=json.loads(data)
       for assertion in assertions[member.name]:ck(pointer(value,assertion['pointer'])==assertion['expected'],'application assertion differs '+member.name+assertion['pointer']);checked+=1
   while stream.read(CHUNK):pass
  ck(actual==wanted and list(actual)==list(wanted) and len(actual)==a['members'],'fresh member order/coverage differs');check(path,a)
  e=byarchive[path.name];report=load(e['report']['path']);t=terminal(e['terminal']['path'],e['command'],e.get('expectedExitCode',0));ck(e.get('expectedExitCode',0)==0,'unresolved final scan failure')
  expected_plan=metadata['archivePlan'] if a['filename']==support['filename'] else metadata['initialArchivePlan'];expected_engine=support_adapter['supportEngine'] if a['filename']==support['filename'] else adapter['engine'];ck(e['archivePlan']==expected_plan and e['command'][-1]==expected_plan['path'] and e['command'][1]==expected_engine['path'],'scan plan/support-only engine binding differs')
  ck(report['status']=='clean' and report['archive']==path.name and report['archivePin']==sizehash(a) and rows_map(report['members'])==actual,'scan archive/member coverage differs');ck(report['regularFilesScanned']==len(actual) and report['bytesScanned']==sum(r['bytes'] for r in actual.values()) and report['currentByteSearchForEveryMember'] and report['chunkBytes']==CHUNK,'scan totals differ')
  ck(all(not report[k] for k in ('exactValueMatches','primaryHeaderCandidates','unclassifiedRuntimeCandidates','errors')),'unresolved scan findings');ck(all(report[k]==v for k,v in expected_counts.items()) and report['patternCacheProvenance']==baseline['patternCacheProvenance'],'seed/rule cache differs')
  expected_code=[{'member':r['member'],'filePin':r['filePin'],'finding':{k:v for k,v in r['exactFinding'].items() if k!='member'},'classification':r['classification']} for r in code_classifications if r['member'] in actual]
  canonical=lambda rows:sorted(json.dumps(r,sort_keys=True) for r in rows)
  ck(canonical(report['classifiedExactCodeHeaderCandidates'])==canonical(expected_code) and report['classifiedExactTemplateRuntimeCandidates']==[],'exact syntax classification multiset differs')
  for r in report['members']:
   n=r['path'];eligible=n.startswith('roadmark/') and n!='roadmark/SOURCE-FILE-MANIFEST.json' and n[9:] in cache_source and core(r)=={'path':n,**sizehash(cache_source[n[9:]])}
   ck((r['patternVerdict']=='exact-prior-source-cache')==eligible and (eligible or r['patternVerdict']=='current-full-unchanged-scanner'),'pattern-cache eligibility differs');ck(r['exactMatchesObserved']==r['classifiedPublicLexicalCollisions']+r['unresolvedExactMatches'] and r['unresolvedExactMatches']==0,'exact match accounting differs')
  ck(sum(r['classifiedPublicLexicalCollisions'] for r in report['members'])==report['classifiedPublicLexicalCollisions'],'collision totals differ')
  scan_rows.append({'archive':path.name,'report':e['report'],'terminal':t,'archivePlan':expected_plan,'members':len(actual),'bytes':sum(r['bytes'] for r in actual.values()),'classifiedPublicLexicalCollisions':report['classifiedPublicLexicalCollisions'],'classifiedExactCodeHeaderCandidates':len(expected_code),'classifiedExactTemplateRuntimeCandidates':0});verified.append({'filename':path.name,**pin(path),'members':len(actual),'uncompressedBytes':sum(r['bytes'] for r in actual.values())});print(json.dumps({'stage':'fresh-only-independent-replay','archive':index,'members':len(actual),'result':'PASS'}),flush=True)
 ck(checked==183 and checked+len(inherited_assertions)==len(app['assertions']),'fresh/inherited application assertion coverage differs');ck(fresh==rows_map(plan['newFiles']) and len(fresh)==plan['freshFiles'] and sum(r['bytes'] for r in fresh.values())==plan['freshBytes'],'fresh union differs')
 merged={n:r for n,r in old.items() if not n.startswith('roadmark/')};merged.update(fresh);ck(merged==rows_map(plan['files']) and len(merged)==plan['logicalFiles'] and sum(r['bytes'] for r in merged.values())==plan['logicalBytes'],'logical overlay differs')
 ck((set(old)&set(fresh))-{n for n in old if n.startswith('roadmark/')}==set(scope['expectedNonSourceOverlay'])=={'roadmark-104-qa/work-status.json'},'unexpected non-source overlay')
 expected_archives=[dict(source) if r['group'].startswith('source-') else {**r,'new':False} for r in base['archivesInRestoreOrder']]+copy.deepcopy(proof)+[copy.deepcopy(support)]
 for i,r in enumerate(expected_archives,1):r['restoreOrder']=i
 ck(sum(r['group'].startswith('source-') for r in base['archivesInRestoreOrder'])==1 and expected_archives==plan['archivesInRestoreOrder'] and plan['baseArchivesReused']==128 and plan['archiveCount']==len(expected_archives),'inherited archive identity/order differs');ck(docs['freshRestoreManifest']=={'archivesInRestoreOrder':archives,'files':list(fresh.values())},'fresh restore manifest differs')
 for r in pc['files']:ck(merged[r['path']]==core(r),'selected proof missing')
 for n in app['forbiddenExecutedTerminals']:ck(n not in merged,'held preparation contains claimed execution')
 for r in app['retainedPins']:ck(merged[r['path']]==core(r),'mandatory application pin absent')
 for r in scope['authorRetention']['sourceAndStatusAfterPins']:ck(merged[restore_path(r['path'])]=={'path':restore_path(r['path']),**sizehash(r)},'seven accepted live pins differ')
 for r in aliases:ck(sizehash(merged[r['retainedMember']])==sizehash(r),'support alias target missing')
 inherited=set()
 def inherited_mappings(value):
  if isinstance(value,dict):
   if 'sanitizedBytes' in value and 'sanitizedSHA256' in value and ('restorePath' in value or 'path' in value):
    n=value.get('restorePath') or value['path'];ck(merged[n]==old[n]=={'path':n,'bytes':value['sanitizedBytes'],'sha256':value['sanitizedSHA256']},'inherited sanitation changed');inherited.add(n)
   for v in value.values():inherited_mappings(v)
  elif isinstance(value,list):
   for v in value:inherited_mappings(v)
 for n in ('sourceSanitation','copyOnlySanitation','inheritedCopyOnlySanitation','originalRawCaptureReplayCompatibility'):inherited_mappings(base[n])
 for r in base['copyOnlySanitation'].get('files',[]):
  if r.get('metadataKeyRename'):ck(merged[r['path']]==old[r['path']]==core(r),'inherited prose-key copy changed')
 proposal,depmap=docs['dependencyProposal'],docs['dependencyMap'];check(basepath,proposal['baseManifest']);check(metadata['scope']['path'],proposal['frozenScope']);ck(proposal['relocationProposals']==[] and proposal['inheritedPointerIntersections']==[] and proposal['inheritedDependencyRecords']==119,'dependency proposal differs')
 dependencies=copy.deepcopy(base['inheritedDependencyReconstruction']['dependencies']);dependencies.extend(copy.deepcopy(proposal['newDependencyRecords']));ck(len(dependencies)==len({r['originalPath'] for r in dependencies})==164 and dependencies==depmap['dependencies'],'dependency mapping differs');canonical=hashlib.sha256(json.dumps(dependencies,sort_keys=True,separators=(',',':')).encode()).hexdigest();ck(canonical==proposal['proposedDependenciesCanonicalSha256']==depmap['dependenciesCanonicalSha256'],'dependency canonical hash differs')
 for r in dependencies:
  for p in r['pins']:ck(merged[p['member']['path']]==core(p['member']) and sizehash(p['member'])==sizehash(p['expected']),'dependency reconstruction pin differs')
 for r in proposal['resolvedMiniRequirements']:ck(merged[r['member']['path']]==core(r['member']) and sizehash(r['member'])==sizehash(r['expected']),'MINI external requirement differs')
 images=docs['imageProvenance'];ck(len(images['files'])==3 and images['noNewRenderPerformed'],'MINI image count/origin differs')
 for r in images['files']:ck(merged[r['image']['path']]==core(r['image']) and merged[r['parentPDF']['path']]==core(r['parentPDF']) and not r['browserScreenshot'] and r['PDFPageOneBased']==4,'MINI image/parent pin differs')
 gate=docs['privacyGate'];ck(gate['result']=='PASS' and gate['freshMembers']==len(fresh) and gate['freshBytes']==sum(r['bytes'] for r in fresh.values()) and len(gate['archives'])==len(archives) and gate['unclassifiedFindings']==gate['errors']==0,'aggregate privacy union/findings differ');ck(gate['classifiedPublicLexicalCollisions']==sum(r['classifiedPublicLexicalCollisions'] for r in scan_rows),'aggregate collisions differ')
 for r,e in zip(gate['archives'],scan_rows):ck(r['archive']==e['archive'] and sizehash(r['reportPin'])==sizehash(e['report']) and r['members']==e['members'] and r['bytes']==e['bytes'],'aggregate report binding differs')
 ck(gate['classifiedExactCodeHeaderCandidates']==len(code_classifications) and gate['classifiedExactTemplateRuntimeCandidates']==0 and gate['preservedInitialPlan']==sizehash(metadata['initialArchivePlan']) and gate['initialPlan']==sizehash(metadata['initialArchivePlan']) and gate['finalPlan']==sizehash(metadata['archivePlan']),'aggregate classification or exact plan pins differ')
 for key,value in expected_counts.items():
  if key in gate:ck(gate[key]==value,'aggregate inherited seed count differs')
 seeds=seed_ledgers(scans,metadata);ck({k:len(v) for k,v in seeds.items()}==inputs['expectedScanInvocations'],'seed invocation count differs')
 for r in list(metadata.values())+inputs['scriptPins']:check(r['path'],r)
 check(ip,ipin);live=[];seen=set()
 for r in sc['files']+pc['files']:
  p=r['originalPath']
  if p in seen:continue
  seen.add(p)
  try:now=identity(p)
  except (OSError,AssertionError):now=None
  if now!=r['sourceIdentity']:live.append({'path':p,'capturedIdentity':r['sourceIdentity'],'currentIdentity':now,'classification':'Later live identity differs from verified immutable cut'})
 dump(REPLAY,{'result':'PASS','method':'Fresh source/proof/support only; non-materializing 64KiB streaming hash and member order through XZ EOF','archives':verified,'files':list(fresh.values()),'fileCount':len(fresh),'bytes':sum(r['bytes'] for r in fresh.values()),'noExtractedTree':True})
 n=len(scans);RESULT.update(result='PASS',verificationScope='All fresh members streamed; exact base metadata overlay checked; no inherited archive replay or restore clone',source={'files':len(current),'changedPaths':sorted(changed),'exactPriorReuse':len(current)-len(changed),'captureCutoff':sc['captureCutoff'],'strictCompressedUnder15000000':True},proof={'selectedOriginalFiles':537,'sourceCovered':6,'reusedBaseMembers':6,'newDeltaFiles':525,'newTransformations':0,'captureCutoff':pc['captureCutoff']},support={'inventory':metadata['supportInventory'],'archive':verified[-1],'uniquePinnedMembers':len(sinv['files']),'uniqueExecutableFiles':len(scripts),'noRecursiveExecutableText':True},newArchives=verified,phaseTerminals=phases,privacy={'result':'PASS','reports':scan_rows,'seedCounts':expected_counts,'knownValuesPersistedOrPrinted':False,'blockingOrUnclassifiedFindings':0,'newExemptions':0,'exactPinnedCodeSyntaxClassifications':len(code_classifications),'exactPinnedTemplateSyntaxClassifications':0,'limitations':['No decryption or arbitrary embedded-format decoding','No universal secret-free claim','Targeted URL-component representations only; no general URL-decoded runtime coverage']},replay={'manifest':{'path':str(REPLAY),**pin(REPLAY)},'noDiskExtractedTree':True},overlay={'baseArchiveCount':129,'unchangedBaseArchivesReused':128,'combinedArchiveCount':len(expected_archives),'combinedLogicalFiles':len(merged),'combinedLogicalBytes':sum(r['bytes'] for r in merged.values()),'freshFiles':len(fresh),'freshBytes':sum(r['bytes'] for r in fresh.values()),'inheritedPayloadReadsByIndependentVerifier':0},inheritedSanitation={'exactPreservedMembers':len(inherited),'allOriginalAndSanitizedPinsUnchanged':True},inheritedDependencyReconstruction={'mapping':metadata['dependencyMap'],'records':164,'priorRecords':119,'relocatedPins':0,'unchangedInheritedRecords':119,'newRecords':45,'miniExternalRequirements':51,'canonicalSha256':canonical},application={'contract':metadata['application'],'assertionCount':checked+len(inherited_assertions),'freshArchiveAssertions':checked,'exactInheritedAssertions':len(inherited_assertions),'inheritedAssertionContract':{'path':str(prior_app_path),**pin(prior_app_path)},'inheritedAssertionReplay':{'path':str(prior_replay_path),**pin(prior_replay_path)},'mandatoryRetainedPins':len(app['retainedPins']),'summary':app['summary'],'workingState':state,'openGates':scope['openGates']},targetedHistoricalSeedExecutions={'completedInvocations':n,'targetedPinnedMemberReads':200*n,'uniquePinnedMembers':200,'uniqueHistoricalArchives':21,'receipts':seeds['historical'],'separateFromFreshMemberReplay':True},targetedAudiSeedExecutions={'completedInvocations':n,'originalPayloadReadOperations':6*n,'uniqueOriginalFiles':4,'distinctValues':6,'variantForms':37,'receipts':seeds['audi'],'noValuesOrValueDigestsPersisted':True},targetedDeepalSeedExecutions={'completedInvocations':n,'capturedPayloadReadOperations':5*n,'uniqueCapturedPayloadFiles':5,'rangeValueExtractionsPerInvocation':9,'distinctValues':6,'variantForms':41,'receipts':seeds['deepal'],'noValuesOrValueDigestsPersisted':True,'rawDeepalApiManagerOriginalRead':False},inheritedLocalSeedExecutions={'specification':metadata['inheritedLocalSeedScope'],'completedInvocations':n,'uniqueOriginalFiles':48,'payloadValueReads':48*n,'streamingIntegrityReads':48*n,'accountingMethod':'Derived from immutable reviewed selector control flow and paired seed completion ledgers bound to actual completed scanner terminals; not separate per-file instrumentation','failedPartialInvocations':[],'noValuesOrValueDigestsPersisted':True},preservedInitialScanFailures=[{'report':e['report'],'terminal':e['terminal'],'expectedExitCode':e.get('expectedExitCode',0)} for e in scans if not e.get('finalCoverage',True)],rawDeepalOriginalReadRecoveryRefetchForbidden=True,rawDeepalOriginalRead=False,postCaptureLiveChanges=live,inputPins=metadata,replayInputManifest={'path':str(ip),**ipin},verifierScript={'path':str(P(__file__)),**pin(__file__)},noUploadsOrDeletion=True)
if __name__=='__main__':
 code=0
 try:main()
 except BaseException as error:code=1;RESULT.update(result='BLOCKED',blocker={'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()})
 RESULT['completedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();RESULT['resources']={'wallSeconds':round(time.monotonic()-START,3),'maxRssKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'addressSpaceLimitBytes':resource.getrlimit(resource.RLIMIT_AS)[0],'chunkBytes':CHUNK,'noRestoreClone':True};dump(OUT,RESULT);print(json.dumps({'result':RESULT['result'],'resources':RESULT['resources'],'blocker':RESULT.get('blocker')}),flush=True);sys.exit(code)
