from capture_v2 import *
proposal=load(C/'INDEPENDENT-MINI-DEPENDENCY-PROPOSAL-v1.json')
assert proposal['result']=='PASS_EXACT_METADATA_ONLY_DEPENDENCY_PROPOSAL'
basepath=BASE/'INHERITED-DEPENDENCY-RECONSTRUCTION-v1.json'
base=load(basepath)
assert proposal['inheritedDependencyRecords']==119 and proposal['unchangedInheritedRecords']==119
assert not proposal['relocationProposals'] and not proposal['inheritedPointerIntersections']
dependencies=base['dependencies']+proposal['newDependencyRecords']
assert len(base['dependencies'])==119 and len(proposal['newDependencyRecords'])==45 and len(dependencies)==164
canonical=hashlib.sha256(json.dumps(dependencies,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert canonical==proposal['proposedDependenciesCanonicalSha256']
scope=load(C/'FROZEN-CAPTURE-SCOPE.json')
assert proposal['allSixFinalSourceChangedPaths']==['roadmark/'+n for n in scope['sourceChangedPaths']]
q={'schemaVersion':1,'result':'FINAL_LAYOUT_METADATA_BOUND_PENDING_FRESH_ARCHIVE_REPLAY','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseManifest':proposal['baseManifest'],'proposal':{'path':str(C/'INDEPENDENT-MINI-DEPENDENCY-PROPOSAL-v1.json'),**pin(C/'INDEPENDENT-MINI-DEPENDENCY-PROPOSAL-v1.json')},'frozenScope':{'path':str(C/'FROZEN-CAPTURE-SCOPE.json'),**pin(C/'FROZEN-CAPTURE-SCOPE.json')},'count':164,'originalExpectedPathsAndHashesUnchanged':True,'relocatedMemberPointers':0,'inheritedRelocatedMemberPointers':base['relocatedMemberPointers'],'inheritedMapping':{'path':str(basepath),**pin(basepath)},'unchangedInheritedRecords':119,'newRecords':45,'allSixFinalSourceChangedPathsIntersected':True,'inheritedPointerIntersections':[],'dependenciesCanonicalSha256':canonical,'dependencies':dependencies,'noExternalPayloadOrArchiveReads':True}
dump(C/'INHERITED-DEPENDENCY-RECONSTRUCTION-v1.json',q)
print(json.dumps({'result':q['result'],'records':164,'newRecords':45,'currentRelocations':0}))
