#!/usr/bin/env python3
"""Compact active receipt, prepared only after verified document persistence."""
from delivery_common_v1 import *

def main():
    manifest = load(DOCS[1])
    review = load(C / 'INDEPENDENT-DELIVERY-DOCUMENT-CHECK.json')
    ck(review['result'] == 'PASS', 'document check not passed')
    gate_ref = privacy('DELIVERABLE-PRIVACY-GATE.json', DOCS)
    docs = native('documents')
    ck([row['filename'] for row in docs] == [path.name for path in DOCS], 'document order differs')
    check(DOCS[1], next(row for row in review['documents'] if row['filename'] == DOCS[1].name))
    value = {'schemaVersion': 8, 'createdAt': now(), 'status': manifest['status'],
             'source': manifest['source'], 'newArchives': manifest['newArchives'],
             'baseRecovery': manifest['baseRecovery'], 'workState': manifest['workState'],
             'counts': manifest['incrementalVerification'], 'documents': docs,
             'manifest': next(row for row in docs if row['filename'] == DOCS[1].name),
             'verificationDocument': next(row for row in docs if row['filename'] == DOCS[2].name),
             'recoverablePostSealReceiptPointers': ['/postSealReceipts/0', '/postSealReceipts/1', '/postSealReceipts/2'],
             'verificationScope': manifest['verificationScope'],
             'independentVerification': manifest['independentVerification'],
             'preSaveDocumentVerification': {'result': 'PASS', 'receipt': ref(C / 'INDEPENDENT-DELIVERY-DOCUMENT-CHECK.json')},
             'documentPrivacyGate': {'result': 'PASS', 'receipt': gate_ref},
             'archivePrivacyGate': manifest['privacyVerification'],
             'supportArchive': manifest['supportArchive']['archive'],
             'inheritedDependencyReconstruction': dependency_summary(load(C / DEPENDENCY)),
             'seedReadExecutionsAsOfBuild': seed_summary(),
             'savingAnnouncement': saving_announcement(),
             'rawDeepalOriginalReadRecoveryRefetchForbidden': True,
             'allInheritedSanitationExclusionsPreservedInManifest': True,
             'noSourceOrStatusMutationByBackup': True, 'noDeletionOrReplacement': True,
             'noExecutableSourceTextEmbedded': True, 'remotePayloadRedownloadPerformed': False}
    no_embedded_source(value)
    dump(ACTIVE, value)
    dump(C / 'library-active-request.json', {'uploads': [{'local_path': str(ACTIVE), 'purpose': 'create_library_file',
                                                        'library_artifact_type': 'report'}]})
    print('Active native receipt prepared with compact identity references')

if __name__ == '__main__':
    main()
