#!/usr/bin/env python3
"""Exact script-span/AST review; proposal only, no detector change or payload/seed reads."""
import ast,datetime,hashlib,json,pathlib,resource,stat
P=pathlib.Path;C=P(__file__).resolve().parent;BASE=C.parent/'deepal-working-20261015T1110'
assert resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456)
def pin(p):
 p=P(p);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents);a=[s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev];b=p.read_bytes();s=p.lstat();assert a==[s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev];return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p):return json.loads(P(p).read_bytes())
preflight=C/'MINI-SUPPORT-PATTERN-PREFLIGHT-v1.json';raw=load(preflight);assert raw['result']=='REVIEW_REQUIRED' and raw['newExecutableFiles']==38 and raw['seedReads']==raw['historicalArchiveReads']==0
rows=[r for r in raw['files'] if r['primaryFindings'] or r['rawRuntimeFindings']];assert len(rows)==1 and rows[0]['filename']=='capture_v2.py' and len(rows[0]['primaryFindings'])==2 and not rows[0]['rawRuntimeFindings'];assert not any(r['rawRuntimeFindings'] for r in raw['files'])
p=C/'capture_v2.py';whole=pin(p);assert {k:whole[k] for k in ('bytes','sha256')}=={k:rows[0][k] for k in ('bytes','sha256')};b=p.read_bytes();text=b.decode('ascii');tree=ast.parse(text)
priorpath=BASE/'INDEPENDENT-DEEPAL-SUPPORT-SYNTAX-CLASSIFICATION-v1.json';prior=load(priorpath);assert pin(priorpath)['sha256']=='7f9f6816eb61b6fce6d26972e068ddbb4a994592bc78d7922aad29e0f310d29b';old=prior['exactSupportCodeClassifications'];assert len(old)==2
classifications=[]
for index,(finding,approved) in enumerate(zip(rows[0]['primaryFindings'],old)):
 loc=finding['location'];start,end=loc['charStart'],loc['charEnd'];line=text.splitlines()[loc['line']-1].encode();span=b[start:end]
 assert hashlib.sha256(span).hexdigest()==approved['matchedSyntaxSHA256'] and hashlib.sha256(line).hexdigest()==approved['lineSHA256']
 assert {k:v for k,v in finding.items() if k!='location'}=={k:v for k,v in approved['exactFinding'].items() if k not in ('location','member')}
 nodes=[n for n in ast.walk(tree) if isinstance(n,ast.stmt) and n.lineno==n.end_lineno==loc['line']];assert len(nodes)==1;node=nodes[0]
 if index==0:
  assert isinstance(node,ast.Assert) and isinstance(node.test,ast.BoolOp) and isinstance(node.test.op,ast.And)
  compares=[n for n in ast.walk(node) if isinstance(n,ast.Compare)];calls=[n for n in ast.walk(node) if isinstance(n,ast.Call)]
  assert len(compares)==2 and len(calls)==1 and isinstance(calls[0].func,ast.Attribute) and calls[0].func.attr=='count' and isinstance(calls[0].func.value,ast.Name) and calls[0].func.value.id=='b'
 else:
  assert isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id=='renamed'
  call=node.value;assert isinstance(call,ast.Call) and isinstance(call.func,ast.Attribute) and call.func.attr=='replace' and isinstance(call.func.value,ast.Name) and call.func.value.id=='b' and len(call.args)==3 and isinstance(call.args[-1],ast.Constant) and call.args[-1].value==1
 member='mini-recovery-support/capture_v2.py'
 classifications.append({'member':member,'filePin':{k:whole[k] for k in ('bytes','sha256')},'exactFinding':{'member':member,**finding},'byteStart':start,'byteEndExclusive':end,'matchedSyntaxSHA256':hashlib.sha256(span).hexdigest(),'lineSHA256':hashlib.sha256(line).hexdigest(),'classification':approved['classification'],'astValid':True,'astStatementType':type(node).__name__,'astStatementSHA256':hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest(),'isHeaderValueOrCredential':False,'fileExtensionExemption':False,'payloadChangeProposed':False,'exactMatchedSyntaxAndCompleteLineEqualPriorReviewedCase':True,'priorMember':approved['member'],'priorFinding':approved['exactFinding']})
assert pin(p)==whole
q={'result':'INDEPENDENT_BENIGN_SYNTAX_PROPOSAL_REQUIRES_ROOT_APPROVAL','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'preflightPin':pin(preflight),'preflightTerminalPin':pin(C/'support-pattern-preflight-v1.resources.json'),'priorClassificationPin':pin(priorpath),'newExecutableFiles':38,'primaryCandidates':2,'rawRuntimeCandidates':0,'exactSupportCodeClassifications':classifications,'enginePins':raw['enginePins'],'noDetectorChanges':True,'noPayloadEdits':True,'noSeedOrArchiveReads':True,'candidateMultisetMustMatchExactly':True,'wholeFilePinRequired':True,'allUnexpectedCandidatesBlock':True,'newFutureScriptsRequireAnotherPreflight':True,'reviewedSourceFileReads':[whole]}
out=C/'INDEPENDENT-MINI-SUPPORT-SYNTAX-CLASSIFICATION-v1.json'
with out.open('x') as f:json.dump(q,f,indent=2);f.write('\n')
print(json.dumps({'result':q['result'],'classified':len(classifications),'scriptFilesRead':1,'seedOrArchiveReads':0,'pin':pin(out)}))
