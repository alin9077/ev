import json,hashlib,pathlib
P=pathlib.Path('/tmp/mg-im-research/mg4');x=json.load(open(P/'normalized-evidence.json'));m=json.load(open(P/'evidence-manifest.json'))
r=json.load(open(P/'maker-historic-capture.json'));r.pop('status',None)
r.update(captureKind='direct_public_http_body',httpStatus=None,responseBodyState='current_offers_page',accessed_date='2026-10-14',published_date=None,title='MG Australia legacy offer URL, reaccessed October 2026',publisher='MG Motor Australia',source_type='official_au_manufacturer',market='AU',supports='The historical-looking /pages/offer/?make=MG5 URL now returns October-2026 offer text with no residual Excite51 or Excite64 amount. Indexed search text instead retained June-2025 expired cards. Neither establishes a current maker residual price.',note='Direct body preserved separately from the web-search extract. Search crawl age is not a current maker offer date. Transport status not recorded; no historical offer is promoted.')
for ss in [x['sources'],m]:
 ss[:]=[s for s in ss if s['key']!=r['key']];ss.append(r)
json.dump(x,open(P/'normalized-evidence.json','w'),indent=2);json.dump(m,open(P/'evidence-manifest.json','w'),indent=2)
q=json.load(open(P/'price-ladder-review.json'));q['makerRungs1to4']['sourceKeys'].append(r['key']);q['makerRungs1to4']['finding']+=' The legacy offer URL was also fetched directly: current October terms, with no Excite residual amount; the old June cards survive only in indexed search text.';json.dump(q,open(P/'price-ladder-review.json','w'),indent=2)
source={s['key']:s for s in x['sources']};assert len(source)==len(x['sources'])
for s in x['sources']:
 for fk,hk in [('file','sha256'),('textFile','textSha256')]:
  assert pathlib.Path(s[fk]).exists(),s['key'];assert hashlib.sha256(pathlib.Path(s[fk]).read_bytes()).hexdigest()==s[hk],s['key']
for v in x['variants']:
 fs={f['key']:f for f in v['facts']};assert len(fs)==len(v['facts']),v['id']
 for f in v['facts']:
  assert f['sourceKeys'] and all(k in source for k in f['sourceKeys']),(v['id'],f['key'])
  if f['grade']=='confirmed':assert all(source[k]['source_type']=='official_au_manufacturer' for k in f['sourceKeys']),(v['id'],f['key'],f['sourceKeys'])
  if f['grade']=='not_published':assert f['value'] is None and len({source[k]['url'].split('#')[0] for k in f['sourceKeys']})>=2,(v['id'],f['key'])
 for ft in v['features']:
  assert all(k in fs for k in ft['keys']),(v['id'],ft)
  if ft['grade']=='not_published':
   key='feature_'+ft['criterion'];assert ft['value']=='Not published' and key in ft['keys'] and fs[key]['grade']=='not_published'
 for sk in ['strength','tradeoff']:assert all(k in fs for k in v['summary'][sk]['keys'])
 for k in v['availability']['sourceKeys']:assert k in source
pfiles=[dict(path=str(f),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in sorted((P/'sources').iterdir()) if f.is_file()]
json.dump(dict(checkedAt='2026-10-14',files=pfiles),open(P/'all-source-files-sha256.json','w'),indent=2)
validation=dict(checkedAt='2026-10-14',variants=len(x['variants']),currentMakerVersions=4,residualDealerNewAdvertisingVersions=2,facts=sum(len(v['facts']) for v in x['variants']),features=sum(len(v['features']) for v in x['variants']),sourceCount=len(x['sources']),sourceFilesHashed=len(pfiles),hashesVerified=True,allDependenciesPresent=True,confirmedFactsUseMakerOnly=True,notPublishedExactFeatureDependenciesVerified=True,gaps=[dict(variantId=v['id'],key=f['key'],reason=f['reason']) for v in x['variants'] for f in v['facts'] if f['grade']=='not_published' and not f['key'].startswith('feature_')],brandTermsSuppliedByParent=True,notes=['MY25 Excite51 corrected to rung-5 $36,990 before on-roads, Reported by CarExpert; exact ad remains enquiry-only.','MY23 ambiguous secondary-guide revisions explicitly reviewed; exact-unit dealer rung 6 retained.','Raw HTTP status was not recorded; response bodies retain errors faithfully, and no false HTTP 200 is asserted.','Unknown equipment rows have exact feature_<criterion> null facts and two distinct maker URLs.','No repository edits or registration were made.'])
json.dump(validation,open(P/'validation.json','w'),indent=2)
print(json.dumps(validation,indent=2))
