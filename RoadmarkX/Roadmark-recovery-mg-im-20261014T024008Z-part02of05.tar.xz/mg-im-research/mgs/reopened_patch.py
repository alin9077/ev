import json,pathlib,hashlib,copy
R=pathlib.Path('/tmp/mg-im-research/mgs');S=R/'sources';D=json.load(open(R/'normalized-evidence.json'));A=json.load(open(R/'audit.json'))
# All inherited retrievals retained, including failed retrieval logs.
fetch=json.load(open(S/'fetch8.json'));sources={s['key']:s for s in D['sources']}
for f in fetch:
 k='mgs-'+f['key']
 if k in sources:continue
 pub={'kenmuston':'Ken Muston Automotive','newspot':'Newspot Motors','xcite':'Xcite Autos','portside':'Portside Motors','westpoint':'Westpoint Autos','penfold':'Penfold','macarthur':'Macarthur Automotive','hobart':'Hobart MG'}
 publisher=next((v for n,v in pub.items() if n in k),'MG Motor Australia (dealer-hosted original brochure)')
 d={'key':k,'url':f['url'],'title':f['key'].replace('-',' ').title(),'publisher':publisher,'source_type':'official_au_manufacturer' if 'brochure' in k else 'dealer','published_date':None,'accessed_date':'2026-10-14','market':'AU','note':'Fresh finite recheck of recovered inherited lead. Advertisement is not physical stock verification. Copyright footer is not a publication date.','supports':'Finite inherited lead disposition and expressly stated exact vehicle identity.'}
 if 'file' in f:
  d.update({x:f[x] for x in ['file','textFile','sha256','textSha256']})
 else:
  capture=S/('web-inherited-additional.json' if any(x in k for x in ['hobart','newspot']) else 'fetch8.json')
  d.update(file=str(capture),sha256=hashlib.sha256(capture.read_bytes()).hexdigest(),note=d['note']+' Origin retrieval failed: '+f['error']+'. '+('Public web extraction contains full listing for Hobart; Newspot remains a cache miss.' if 'hobart' in k or 'newspot' in k else 'No live New proof claimed.'))
 D['sources'].append(d);sources[k]=d
# exact feature dependencies, including closely related multi-claim rows
for v in D['variants']:
 fs={f['key']:f for f in v['facts']};base=copy.deepcopy(fs['power_folding_mirrors']);base.update(key='heated_door_mirrors',value=True,basis='Maker exact equipment column: heated door mirrors');v['facts'].append(base)
 for row in v['features']:
  if row['criterion']=='folding_mirrors' and 'heated_door_mirrors' not in row['keys']:row['keys'].append('heated_door_mirrors')
  if row['criterion']=='storage' and 'seats' not in row['keys']:row['keys'].append('seats')
 if v['model']=='MGS6 EV':
  for k,val,basis in [('wireless_phone_charger_w',50,'Wireless Phone Charger with cooling - 50W'),('wireless_phone_charger_cooling',True,'Wireless Phone Charger with cooling - 50W'),('audio_subwoofer',True,'11 Speaker Premium Audio (including sub-woofer)')]:
   f=copy.deepcopy(fs['wireless_phone_charger']);f.update(key=k,value=val,basis=basis,sourcePointer='Australian MY26 brochure, in-car entertainment table, page 22');v['facts'].append(f)
  for row in v['features']:
   if row['criterion']=='wireless_charging':row['keys']=['wireless_phone_charger','wireless_phone_charger_w','wireless_phone_charger_cooling']
   if row['criterion']=='audio_system':row['keys']=['speaker_count','audio_subwoofer']
  v['metadataReason']='Current Australian maker model page and MY26 brochure plus independent Australian launch/review lists explicitly establish Essence RWD and Essence AWD. Approval-only alternatives are not treated as sold-new grades.'
# additional corroboration only, not lowest-price re-selection unless source/basis improves
for i,key in [(4,'mgs-s5-inherited-excite49-westpoint'),(5,'mgs-s5-inherited-excite62-westpoint')]:
 v=D['variants'][i];v['availability']['sourceKeys'].append(key);v['availability']['qualifications'].append('Additional Westpoint advert is labelled New and NewCondition/InStock but displays a registration plate; this is registered New advertising, not proof of unregistered stock. The selected dealer price remains the independent unregistered-status-unspecified exact New advertisement.')
# recovered exact old original brochure verifies original MY25 equipment, not current new-MY equipment
for v in D['variants'][4:8]:
 for f in v['facts']:
  if 'mgs-s5-old-model' in f['sourceKeys'] and f['grade']=='confirmed':f['sourceKeys'].append('mgs-s5-inherited-my25-brochure')
# Refresh/invalidate extra MY26 Excite49 rather than inherit MY25 equipment.
v=copy.deepcopy(D['variants'][4]);v['id']='mg_mgs5_my26_excite_49_rwd__20261014';v['modelYear']=2026;v['trim']='Excite 49kWh RWD · MY26 residual New advertising';v['metadata'].update(trim=v['trim'],year=2026,generation='MY26 Excite 49 original 125 kW specification; residual dealer New');v['generation']=v['metadata']['generation'];v['metadataReason']='Hobart stock 2604150358 VIN LSJWS4092TZ586614 expressly states MY26 in dealer narrative and Model Year 26 field, with 49 kWh, 125 kW, 250 Nm, 340 km WLTP and 8.0 s. No year inference from title or VIN is needed; not a current factory-order grade.'
h='mgs-s5-inherited-excite49-hobart';current='mgs-s5-brochure';old='mgs-s5-old-model';guide='mgs-s5-guide2026'
oldfacts={f['key']:f for f in v['facts']};v['facts']=[]
wholebody={'length_mm','width_mm','height_mm','wheelbase_mm','ground_clearance_mm','boot_l','max_total_cargo_l'}
direct={'range_km','battery_kwh','zero_to_100_s','power_kw','torque_nm','drive','seats','towing_braked_kg','towing_unbraked_kg','tare_mass_kg','wheel_inches','speaker_count','driver_display_inches','rear_camera','rear_parking_sensors'}
# known matching original technical claims retained as explicitly reported sibling evidence, not exact-MY confirmed
sibling={'dc_peak_kw','dc_30_80_time_min','dc_30_80_window','ac_kw','battery_chemistry','motor_location','charging_connector'}
keep=wholebody|direct|sibling|{'price_aud','dc_charge_time_min','battery_usable_kwh','frunk_l'}
for k in keep:
 f=copy.deepcopy(oldfacts[k])
 if k=='price_aud':
  f.update(value=40490,sourceKeys=[guide],grade='reported',basis='Secondary-reported manufacturer MSRP before government charges/options',comparison='Before on-roads',reason='Current CarsGuide 2026 table names Excite 49 at $40,490 and its lowest-price MSRP footnote excludes stamp duty, government charges and options. No current maker rung 1–4 exact MY26 Excite price found after current brochure/model/offers/configurator search; rung 5 outranks Hobart dealer $40,690 driveaway.',priceRung=5,basisTag='Reported MSRP',priceTag='Reported MSRP',rankingEligible=False,originalBasis='Manufacturer Suggested Retail Price; excludes government charges and options',sourcePointer='2026 table Excite 49 plus lowest-price MSRP footnote',publisher='CarsGuide',qualifications=['Secondary price report; not a manufacturer quotation and not directly comparable with driveaway.'])
 elif k in direct:
  f.update(sourceKeys=[h],grade='reported',evidenceScope='secondary_or_sibling',reason='Exact MY26 Excite 49 dealer narrative/specification supports this value; no maker exact MY26 Excite column is presently published. Dealer facts remain Reported and unranked.');f['rankingEligible']=False
 elif k in wholebody:
  f.update(sourceKeys=[old,current],reason='Original and refreshed Australian maker tables explicitly publish the same whole-body dimension/cargo capacity for this MGS5 body. It is not inferred from a sibling battery or drive version. Seating/load state and missing cargo method are retained.',evidenceScope='explicit_au_range')
 elif k in sibling:
  f.update(sourceKeys=[old,h],grade='reported',evidenceScope='secondary_or_sibling',reason='Original maker Excite 49 technical table is the closest 49 kWh/125 kW/340 km technical cohort, corroborated by exact MY26 dealer identity. This particular charging/chemistry item is not independently restated for MY26 in a current maker Excite column; kept explicitly Reported as sibling evidence, never Confirmed or ranked.');f['rankingEligible']=False
 else:
  f.update(sourceKeys=[current,h],reason='Current Australian maker specification and exact MY26 dealer listing both checked; this exact metric is not published. No older-year or overseas number imported.')
 v['facts'].append(f)
# exact dealer says wireless phone projection, without the wired claim.
f=copy.deepcopy(oldfacts['wired_wireless_carplay_android']);f.update(key='wireless_carplay_android',value=True,sourceKeys=[h],grade='reported',evidenceScope='secondary_or_sibling',reason='Exact MY26 dealer highlighted features explicitly list wireless Apple CarPlay and Android Auto; wired connection is not asserted.',rankingEligible=False);v['facts'].append(f)
# Re-review every inherited equipment row; retain only real evidence and invalidate remaining rows.
valid={'parking_cameras':['rear_camera','rear_parking_sensors'],'audio_system':['speaker_count'],'performance_rear_motor':['power_kw','torque_nm','drive','motor_location'],'storage':['boot_l','max_total_cargo_l','seats'],'battery_chemistry':['battery_kwh','battery_chemistry','battery_usable_kwh'],'home_charging':['ac_kw'],'carplay_android_auto':['wireless_carplay_android'],'screens_hud':['driver_display_inches']}
for row in v['features']:
 c=row['criterion'];row.pop('status',None)
 if c in valid:
  row.update(keys=valid[c],grade='reported',reason='New MY26 record reviewed against exact dealer listing and separately labelled maker whole-body or original-cohort evidence. Not inherited as exact-MY Confirmed.',conditions='Dealer or expressly labelled original-cohort report; unranked.')
  if c=='carplay_android_auto':row['value']='Wireless Apple CarPlay and Android Auto reported'
  if c=='screens_hud':row['value']='10.25-inch driver display reported; central-screen size and HUD fitment not established for this MY26 advert'
  if c=='parking_cameras':row['value']='Reversing camera and rear parking sensors reported'
 else:
  key='feature_'+c;v['facts'].append({'key':key,'value':None,'sourceKeys':[current,h],'grade':'not_published','basis':'','comparison':'','reason':'Current maker specification omits Excite and exact MY26 dealer listing does not establish this equipment. Original MY25 equipment is invalidated for this new MY rather than carried forward as Confirmed. Two relevant Australian sources checked.','evidenceScope':'searched_not_found','qualifications':[]})
  row.update(value='Not published',keys=[key],grade='not_published',conditions='',reason='Rechecked current maker and exact MY26 dealer sources; retained MY25 equipment knowledge does not prove this MY26 vehicle.')
v['availability']={'state':'outgoing','sourceKeys':[h,'mgs-s5-ce-update','mgs-s5-model'],'orderStatus':'not_accepting_orders','stockStatus':'new_stock_listed','qualifications':['Exact Hobart MY26 Excite49 listing advertises New and In stock; physical stock, registration status, allocation and delivery are not independently verified.','Current maker range no longer lists Excite; this is a finite residual New-advertised MY26 version, not current factory availability.'],'reason':'Explicit dealer MY26 narrative and model-year field establish a separate advertised residual identity; no inference from calendar year or VIN.'}
v['summary']={'strength':{'label':'Compact five-seat format','text':'The 4,476 mm MGS5 body has a reported five-seat layout in this MY26 dealer specification.','keys':['length_mm','seats']},'tradeoff':{'label':'Light reported towing','text':'The exact MY26 dealer specification reports a 750 kg braked towing limit.','keys':['towing_braked_kg']}}
D['variants']=[x for x in D['variants'] if x['id']!=v['id']]+[v]
# finite closure of every recovered MGS5 stock candidate and unresolved lead.
entries=[
 {'stock':'G10095','sourceKey':'mgs-s5-inherited-essence62-portside','disposition':'New','identity':'MY25 Essence62; VIN LSJWS4090SZ707607; 18 km','notes':'Recovered exact URL still returns New MY25 at $46,990 driveaway. No power/range/build detail distinguishes original 125 kW from refreshed 150 kW under conflicting MY25 brochure naming; epoch remains unresolved for this particular unit. Replaces previous unrecoverable-URL audit, not evidence of either epoch.'},
 {'stock':'4106082','sourceKey':'mgs-s5-inherited-excite49-westpoint','disposition':'New_registered_advertisement','identity':'MY25 Excite49; VIN LSJWS4093SZ671864; registration 496RF7','notes':'Current HTML labels New and schema NewCondition/InStock. 10 km, April 2025 build, $34,988 driveaway. Registration is explicit; not silently relabelled Demo, and not proof of unregistered or physical stock.'},
 {'stock':'4106079','sourceKey':'mgs-s5-inherited-excite62-westpoint','disposition':'New_registered_advertisement','identity':'MY25 Excite62; VIN LSJWS4093SZ699566; registration 492RF7','notes':'Current HTML labels New and schema NewCondition/InStock. 12 km, June 2025 build, $38,488 driveaway. Registration explicitly qualified; not silently relabelled Demo.'},
 {'stock':'2604150358','sourceKey':h,'disposition':'New','identity':'Explicit MY26 Excite49; VIN LSJWS4092TZ586614; 10 km','notes':'Origin HTTP403 but complete public web extraction has repeated MY26 narrative, Model Year26 and matching 125 kW/250 Nm/340 km WLTP/8s. New/In stock and $40,690 driveaway advertised. Added separate MY26 residual version. 415 km NEDC is separately labelled and not confused with WLTP.'},
 {'stock':'MG698624','sourceKey':'mgs-s5-inherited-essence49-macarthur','disposition':'New','identity':'Essence49; VIN LSJWS4098SZ698624; June 2025 build; headline 2026','notes':'Current $38,400 driveaway, 10 km, NewCondition/InStock. Hidden model_year=2026 but no explicit MY25/MY26 vehicle wording; 2025 build/compliance differs. Does not independently resolve exact MY epoch. No new duplicate Essence49 record from title year alone.'},
 {'stock':'19883','sourceKey':'mgs-s5-inherited-excite49-kenmuston','disposition':'demo','identity':'MY25 Excite49; VIN LSJWS409XSZ699872','notes':'Current exact page explicitly Demo and EX-DEMO, 315 km, $36,990 driveaway; excluded from New proof.'},
 {'stock':'1300155','sourceKey':'mgs-s5-inherited-excite62-xcite','disposition':'dead_replaced_url','identity':'Historical MY25 Excite62; VIN LSJWS4099SZ652087','notes':'Inherited capture was Demo despite New headline. Current reused generic URL shows stock1300156/VIN LSJWS4099SZ649450,13 km, repeatedly Condition Demo. Original stock1300155 cannot be reverified from this replaced URL; neither original nor replacement is New evidence. Not claimed sold.'},
 {'stock':'597586','sourceKey':'mgs-s5-inherited-essence49-penfold','disposition':'dead_unretrievable','identity':'Historical Essence49 lead; exact current status unverified','notes':'Fresh origin HTTP500 plus earlier public-web cache miss. Finite lead closed as unretrievable and excluded from New evidence; not claimed sold.'},
 {'stock':'Newspot-33917922','sourceKey':'mgs-s5-inherited-excite62-newspot','disposition':'dead_unretrievable','identity':'Historical Excite62 lead; exact current status unverified','notes':'Fresh origin HTTP403 and public-web cache miss. Finite lead closed as unretrievable and excluded from New evidence; not claimed sold.'}
]
A['inheritedAds']=[x for x in A['inheritedAds'] if x.get('stock') not in {e['stock'] for e in entries}]+entries
A['residualNewVersions']=[{k:x[k] for k in ['model','trim','modelYear','id']} for x in D['variants'] if x.get('new')]
A['recoveredArchiveAudit']={'artifact':'roadmark-103-archive/data/research-pending/mg-remaining-residual-evidence.json','result':'All seven MGS5 stockCandidates plus both MGS5 unresolvedLeads have finite fresh dispositions above. Xcite generic URL changed vehicle identity. New evidence never proves physical stock.','retrievalLog':'sources/fetch8.json','publicWebCapture':'sources/web-inherited-additional.json'}
A['independentListReconciliation'][0]['difference']+=' Recovered Hobart explicit MY26 Excite49 adds one separate residual MY26, not an additional current maker grade.'
A['priceLadderAudit']+=' Extra MY26 Excite49 uses current CarsGuide 2026 exact-name MSRP $40,490, reported rung5 before government charges/options, ahead of dealer rung6 $40,690 driveaway. Registered Westpoint New ads are additional corroboration, not a reason to imply all new cars are unregistered.'
D['familyNotes']['MGS5 EV']+=' Recovered finite inherited lead audit adds explicit dealer MY26 Excite49 as a fifth residual record, with refreshed/invalidate equipment knowledge and Reported technical gaps. G10095 exact URL recovered and still New MY25, but this particular unit remains 125/150 kW epoch-unresolved. Westpoint registered New ads explicitly qualified; Macarthur year not inferred; Ken Muston Demo, Xcite replaced/Demo, Penfold/Newspot unretrievable.'
for path,data in [(R/'normalized-evidence.json',D),(R/'audit.json',A)]:path.write_text(json.dumps(data,indent=2)+'\n')
# manifest regenerated by dedicated QA after final captures
print(len(D['variants']),len(D['sources']),sum(len(v['facts']) for v in D['variants']))
