import urllib.request,concurrent.futures,pathlib,json,subprocess,hashlib
from html.parser import HTMLParser
ROOT=pathlib.Path('/tmp/mg-im-research/mgs/sources')
class T(HTMLParser):
 def __init__(self):super().__init__();self.skip=0;self.out=[]
 def handle_starttag(self,t,a):
  if t in ['script','style']:self.skip+=1
  if t in ['p','li','tr','div','h1','h2','h3','h4','th','td','option']:self.out.append('\n')
 def handle_endtag(self,t):
  if t in ['script','style']:self.skip-=1
 def handle_data(self,d):
  if not self.skip:self.out.append(d.strip())
def fetch(k,u):
 try:
  r=urllib.request.urlopen(u,timeout=35);b=r.read();ext='pdf' if 'pdf' in r.headers.get('content-type','') else 'html';f=ROOT/(k+'.'+ext);f.write_bytes(b)
  if ext=='html':
   t=T();t.feed(b.decode());f.with_suffix('.txt').write_text('\n'.join(l.strip() for l in ''.join(t.out).splitlines() if l.strip()))
  else:subprocess.run(['pdftotext','-layout',str(f),str(f.with_suffix('.txt'))])
  return {'key':k,'url':u,'status':r.status,'file':str(f),'textFile':str(f.with_suffix('.txt')),'sha256':hashlib.sha256(b).hexdigest(),'textSha256':hashlib.sha256(f.with_suffix('.txt').read_bytes()).hexdigest()}
 except Exception as e:return {'key':k,'url':u,'error':str(e)}
if __name__=='__main__':
 import sys
 d=json.load(open(sys.argv[1]));a=list(concurrent.futures.ThreadPoolExecutor(8).map(lambda kv:fetch(*kv),d.items()));out=ROOT/(sys.argv[2] if len(sys.argv)>2 else 'fetch-log.json');out.write_text(json.dumps(a,indent=2));print(json.dumps(a,indent=2))
