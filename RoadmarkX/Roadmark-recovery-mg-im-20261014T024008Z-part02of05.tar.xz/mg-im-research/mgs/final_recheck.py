import json,pathlib,hashlib,copy,collections
R=pathlib.Path('/tmp/mg-im-research/mgs');D=json.load(open(R/'normalized-evidence.json'));A=json.load(open(R/'audit.json'));f=json.load(open(R/'sources/fetch9.json'))[0]
s={'key':'mgs-s5-guide-my26-excite49','url':f['url'],'title':'2026 MG MGS5 EV Excite 49 Pricing and Spec Configurations','publisher':'CarsGuide','source_type':'independent_au_secondary','published_date':None,'accessed_date':'2026-10-14','market':'AU','note':'Exact 2026 Excite49 configuration independently corroborates 49kWh/340km/125kW/250Nm/8.0s. Selector explicitly says Discontinued Apr2026: reported $40,490 MSRP is historical catalogue context, not selected as a current quote. Equipment and warranty fields are not taken wholesale; Heated Seats-All and 10-year battery warranty conflict with stronger original maker/brand sources.','supports':'Independent residual MY26 identity and original technical cohort; historical price excluded.'};s.update({k:f[k] for k in ['file','textFile','sha256','textSha256']});D['sources'].append(s)
v=D['variants'][-1];p=next(f for f in v['facts'] if f['key']=='price_aud');p.update(value=40690,sourceKeys=['mgs-s5-inherited-excite49-hobart'],basis='Dealer-advertised driveaway',comparison='Driveaway',priceRung=6,basisTag='Dealer ad',priceTag='Dealer ad',originalBasis='Driveaway',publisher='Hobart MG',sourcePointer='Exact MY26 New vehicle headline price',reason='No current maker exact MY26 Excite price in searched brochure/model/offers/configurator. Exact CarsGuide 2026 Excite49 subpage labels its $40,490 configuration Discontinued Apr2026, so this historical catalogue price is not a current rung5 quote. Highest usable current price is this live exact New dealer advertisement.',qualifications=['Exact Diamond Red Metallic advertised vehicle; no claim this is an option-free national base price. Dealer price is Reported and unranked.'])
for fact in v['facts']:
 if fact['key'] in ['range_km','battery_kwh','zero_to_100_s','power_kw','torque_nm','seats','wheel_inches','speaker_count','driver_display_inches','towing_braked_kg']:
  fact['sourceKeys'].append(s['key']);fact['reason']+=' Independently matched by CarsGuide exact 2026 Excite49 catalogue; still secondary evidence.'
# Useful secondary evidence is kept, without copying unreliable template fields wholesale.
for criterion,key,val,txt in [('v2l','v2l_supported',True,'Vehicle-to-load capability reported'),('spare_tyre','tyre_repair_kit',True,'Tyre repair kit reported')]:
 row=next(x for x in v['features'] if x['criterion']==criterion);v['facts']=[x for x in v['facts'] if x['key']!='feature_'+criterion];v['facts'].append({'key':key,'value':val,'sourceKeys':[s['key']],'grade':'reported','basis':'Exact MY26 secondary equipment listing','comparison':'','reason':'CarsGuide exact 2026 Excite49 feature list names this item. Retained as Reported secondary evidence; not a Confirmed manufacturer fitment statement.','evidenceScope':'secondary_or_sibling','qualifications':[],'rankingEligible':False});row.update(value=txt,keys=[key],grade='reported',conditions='Secondary exact-configuration report; unranked.',reason='Re-reviewed against exact MY26 secondary equipment list; not carried forward as Confirmed from MY25.')
A['priceLadderAudit']=A['priceLadderAudit'].replace('Extra MY26 Excite49 uses current CarsGuide 2026 exact-name MSRP $40,490, reported rung5 before government charges/options, ahead of dealer rung6 $40,690 driveaway.','Extra MY26 Excite49 uses current Hobart dealer rung6 $40,690 driveaway. The exact CarsGuide 2026 Excite49 selector labels its $40,490 configuration Discontinued Apr2026, excluding that historical catalogue amount from current rung5 selection.')
A['independentListReconciliation'][0]['sources'].append(s['key']);A['independentListReconciliation'][0]['difference']+=' Exact CarsGuide2026 Excite49 catalogue independently matches the original 125kW/340km cohort and labels it discontinued; this does not restore factory-order status.'
D['familyNotes']['MGS5 EV']+=' MY26 Excite49 CarsGuide selector explicitly discontinued: its $40,490 price is historical context; current Hobart $40,690 driveaway dealer rung6 selected.'
# Deterministic facts for added record
v['facts'].sort(key=lambda x:x['key'])
for path,data in [(R/'normalized-evidence.json',D),(R/'audit.json',A)]:path.write_text(json.dumps(data,indent=2)+'\n')
# Source manifest includes every full permitted raw/parsed capture and retrieval result.
files=[]
for p in sorted((R/'sources').glob('*')):
 if p.is_file():files.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(R/'source-manifest.json').write_text(json.dumps({'reviewedAt':'2026-10-14','files':files},indent=2)+'\n')
keys={s['key'] for s in D['sources']};assert len(keys)==len(D['sources'])
for v in D['variants']:
 fs={f['key']:f for f in v['facts']};assert len(fs)==len(v['facts'])
 for f in v['facts']:
  assert set(f['sourceKeys'])<=keys
  if f['grade']=='not_published':assert f['value'] is None and len(f['sourceKeys'])>=2
 for row in v['features']:
  assert set(row['keys'])<=fs.keys(),(v['id'],row)
  if row['value']=='Not published':assert row['keys']==['feature_'+row['criterion']] and fs[row['keys'][0]]['grade']=='not_published'
 for row in v.get('summary',{}).values():assert set(row['keys'])<=fs.keys()
print('VALIDATED',len(D['variants']),'versions',len(D['sources']),'sources',sum(len(v['facts']) for v in D['variants']),'facts',sum(len(v['features']) for v in D['variants']),'features',len(files),'capture files')
