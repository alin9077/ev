import json,pathlib,re,hashlib
P=pathlib.Path('/tmp/mg-im-research/mgs');D=P/'sources';p=P/'normalized-evidence.json';x=json.load(open(p))
textkeys={'title','supports','note','reason','conditions','conditionExplanation','metadataReason','generation','text','basis','comparison','originalBasis','sourcePointer','label'}
def clean(s):
 s=re.sub(r'(?<=[a-zA-Z])(?=\d)', ' ',s)
 s=re.sub(r'(?<=\d)(?=(?:kWh|kW|Wh/km|km|mm|Nm|L|kg|minutes|minute|seconds|second|s\b|point|seats|front|rear|degree|speakers|months|month|years|year|W\b|°C))',' ',s)
 s=re.sub(r'(?<=[,;:])(?=[A-Za-z0-9])',' ',s)
 s=s.replace('MY 26','MY26').replace('MY 25','MY25').replace('MY 2026','MY2026').replace('MY 2025','MY2025').replace('MGS 5','MGS5').replace('MGS 6','MGS6')
 for a,b in {'Essence49':'Essence 49','Essence62':'Essence 62','Excite49':'Excite 49','Excite62':'Excite 62','two-Essence':'two-Essence','brochure7':'brochure 7','webpage7':'webpage 7','frunk86':'frunk 86','says7':'says 7','says86':'says 86','says67':'says 67','says124':'says 124','says102':'says 102','methodVDA':'method VDA','Type2':'Type 2','stock48137':'stock 48137','stockA260':'stock A260','stockRB':'stock RB','stock415873':'stock 415873','stock555656':'stock 555656','stock431220':'stock 431220','stockMG':'stock MG','13km':'13 km','2026build':'2026 build'}.items():s=s.replace(a,b)
 return s
for v in x['variants']:
 for k in ['metadataReason','generation']:
  if k in v:v[k]=clean(v[k])
 for k in ['generation']:
  if k in v['metadata']:v['metadata'][k]=clean(v['metadata'][k])
 for f in v['facts']:
  for k in textkeys:
   if k in f and isinstance(f[k],str):f[k]=clean(f[k])
  f['qualifications']=[clean(s) for s in f['qualifications']]
  if f['key']=='dc_charge_time_min' and f['value'] is not None:f['comparison']='DC 10–80%'
  if f['key']=='dc_30_80_time_min':f['comparison']='DC 30–80%'
  if f['key']=='zero_to_100_s':f['comparison']='0–100 km/h'
  if f['key']=='seats':
   f['reason']='The maker Australian safety table enumerates two front seating positions and rear left, right and centre seating positions. This is five seats; no capacity is estimated from exterior size.'
 for f in v['features']:
  f['value']=clean(f['value']);f['reason']=clean(f['reason']);f['conditions']=clean(f['conditions'])
 for f in v['summary'].values():f['text']=clean(f['text'])
 v['availability']['qualifications']=[clean(s) for s in v['availability']['qualifications']]
 v['availability']['reason']=clean(v['availability']['reason'])
 for s in x['sources']:
  if s['source_type']=='dealer':s['source_type']='dealer_listing'
for s in x['sources']:
 for k in ['note','supports']:s[k]=clean(s[k])
x['familyNotes']={k:clean(v) for k,v in x['familyNotes'].items()}
p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
# Self-contained finite disposition audit, every inherited S5/S6 exact ad and investigated cohort.
audit={'reviewedAt':'2026-10-14','currentMakerVersions':[{'model':v['model'],'trim':v['trim'],'modelYear':v['modelYear'],'id':v['id']} for v in x['variants'] if not v.get('new')],'residualNewVersions':[{'model':v['model'],'trim':v['trim'],'modelYear':v['modelYear'],'id':v['id']} for v in x['variants'] if v.get('new')], 'inheritedAds':[
 {'stock':'48137','sourceKey':'mgs-s5-stock-hamilton','disposition':'New','identity':'MY26 Essence 49, VIN LSJWS409XTZ565090','notes':'Raw current HTTP listing retains New. Current headline cash price is used only for advert audit, maker national price outranks it.'},
 {'stock':'431220','sourceKey':'mgs-s5-stock-colcrawford','disposition':'New','identity':'MY26 Essence 62 refreshed 150 kW, VIN LSJWS4096TZ566690','notes':'Public extraction exact narrative specifies 150 kW/350 Nm/450 km; origin HTTP403. Advertisement, no physical-stock claim.'},
 {'stock':'A2607100266','sourceKey':'mgs-s5-stock-wangara','disposition':'New','identity':'Essence 62, epoch unresolved','notes':'New advert exists but heading2026 and highlighted450km/7s conflict with MY25 field and125kW/8.6s factory-template block. Does not prove either exact epoch; do not import dealer template facts.'},
 {'stock':'4817','sourceKey':'mgs-s6-stock-orange','disposition':'New','identity':'MY26 Essence RWD, VIN LSJWX4090TN069031','notes':'Public extraction retains New; origin HTTP403.'},
 {'stock':'MG056828','sourceKey':'mgs-s6-stock-norris','disposition':'New','identity':'MY26 Essence AWD','notes':'Public extraction retains New; origin HTTP403.'},
 {'stock':'G10095','sourceKey':None,'disposition':'dead_unidentifiable_historical_ad','identity':'Historical MY25 Essence62 lead; epoch unresolved','notes':'Only prose remains in inherited inventory; exact URL could not be recovered from supplied repository or captures. No New/sold/125/150kW claim is made for this unit. Separate exact Allan Mackay MY25 125kW New ad closes the original-trim cohort.'}
 ],'additionalInvestigatedAds':[
 {'stock':'A2604100964','sourceKey':'mgs-s5-residual-excite49-motorama','disposition':'New','identity':'MY25 Excite49; raw embedded description explicitly ZS3EM MY25 125kW; VIN LSJWS4092TZ595782'},
 {'stock':'RB538449','sourceKey':'mgs-s5-residual-excite62-vonbibra','disposition':'New','identity':'Explicit MY25 Excite62; February2026 build; VIN LSJWS4094TZ538449'},
 {'stock':'555656','sourceKey':'mgs-s5-residual-essence49-buckby','disposition':'New','identity':'Explicit MY25 Essence49; VIN LSJWS4096TZ555656'},
 {'stock':'415873','sourceKey':'mgs-s5-residual-essence62-allan','disposition':'New','identity':'Explicit MY25 Essence62,125kW/250Nm/425km/8.6s in live exact listing; VIN LSJWS4091TZ566449'},
 {'stock':'MGS5EVE49RWDGR','sourceKey':'mgs-s5-residual-excite49-johnhughes','disposition':'sold','identity':'Original Excite49; live SOLD/recently sold beats cached New'},
 {'stock':'A2605130193','sourceKey':'mgs-s5-residual-excite62-motorama','disposition':'sold','identity':'2026 title Excite62; live SOLD/recently sold beats cached New; no separate MY26 addition'},
 {'stock':'MG515639','sourceKey':'mgs-s5-residual-excite62-northern','disposition':'demo','identity':'Explicit Demo now, registration8AB2GZ, formerly cached New'},
 {'url':'https://www.buckbymotors.com.au/new-cars/for-sale/mg/mgs5-ev/2025/essence-62/zs3em-my25/3888117/','sourceKey':'mgs-s5-residual-essence62-buckby','disposition':'dead','identity':'Exact listing replaced by generic stock index; not assumed sold'},
 {'url':'https://www.carsales.com.au/cars/details/2025-mg-mgs5-ev-essence-62-auto-my25/OAG-AD-25116989/','disposition':'sold_or_unavailable','identity':'Dealer demo with explicit Sold or unavailable; excluded','capture':'sources/web-residual1.json'},
 {'url':'https://www.carsales.com.au/cars/details/2025-mg-mgs5-ev-essence-62-auto-my25/OAG-AD-25156695/','disposition':'dead','identity':'Open yields one-line empty page; not used','capture':'sources/web-residual1.json'},
 {'url':'https://www.penfold.com.au/cars/new-camden-grey-2025-mg-mgs5-ev-597586','disposition':'unretrievable','identity':'Current raw500 and web cache miss; not used for New closure'},
 {'url':'https://www.newspot.com.au/stock-specials/list/MG/MGS5%2BEV','disposition':'unretrievable','identity':'Origin403 and web cache miss; not used for New closure'},
 {'url':'https://dwyers.com.au/new-demo-used-vehicles/?makes=MG','disposition':'unretrievable','identity':'Origin403 and web cache miss; not used for New closure'}
 ],'independentListReconciliation':[
 {'model':'MGS5 EV','sources':['mgs-s5-ce-update','mgs-s5-guide2026'],'difference':'CarExpert July update explicitly current two Essence variants. CarsGuide calendar2026 has six names mixing original four with refreshed labels; its Excites/original125kW are residual, not four extra current factory grades. Two naming entries for49 are not two mechanical grades. Four original residual variants added from exact New ads.'},
 {'model':'MGS6 EV','sources':['mgs-s6-ce-review','mgs-s6-drivingenthusiast'],'difference':'Both independent Australian published lists have Essence RWD and AWD77kWh, matching maker. Prelaunch government-approval62.2kWh/base variants are not a sold-new version absent current maker order/listing evidence.'}
 ],'priceLadderAudit':'Current four: maker national driveaway rung2, after checking current maker brochure/model/offers/configurator for rung1. Residual four: no current exact-epoch maker price; CarsGuide2025 is resale ranges, historical launch/monthly offers expired. Current exact New dealer rung6 is selected; no cross-epoch current Essence62 offer assumed for original125kW. Dealer prices shown Reported/unranked.', 'knownGaps':'MGS5 exact Australian10–80% DC time; usable battery energy; measured front cargo. Heat pump fitment wholly Not published depends on its ownfeature_heat_pump Fact. No generic lab/MY penalty applied. All rear cargo lacks published measurement method; keep figures visible but do not rank as VDA/SAE.', 'brandTerms':'Parent supplies current MG warranty,batterywarranty,roadside terms uniformly after applicability review.'}
(P/'audit.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False)+'\n')
# Preserve manifest for all permitted raw/parsed/tool captures, including failed retrieval logs.
files=[]
for f in sorted(D.iterdir()):
 if f.is_file():files.append({'file':str(f.relative_to(P)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(P/'source-manifest.json').write_text(json.dumps({'reviewedAt':'2026-10-14','files':files},indent=2)+'\n')
# Structural validations
assert len(x['variants'])==8
src={s['key']:s for s in x['sources']}
for v in x['variants']:
 fs={f['key']:f for f in v['facts']};assert len(fs)==len(v['facts']),v['id']
 for f in v['facts']:
  assert all(s in src for s in f['sourceKeys']),f
  if f['grade']=='not_published':assert f['value'] is None and len({src[s]['url'] for s in f['sourceKeys']})>=2,f
  if f['grade']=='check':assert f.get('conditionExplanation'),f
 for f in v['features']:
  assert all(k in fs for k in f['keys']),f
  if f['grade']=='not_published':assert f['value']=='Not published' and f['keys']==['feature_'+f['criterion']],f
 for f in v['summary'].values():assert all(k in fs for k in f['keys'])
print('Validated',len(x['variants']),'versions;',sum(len(v['facts']) for v in x['variants']),'facts;',len(files),'capture files')
