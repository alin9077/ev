from pathlib import Path
import json,hashlib
from datetime import datetime,timezone
qa=Path('/workspace/scratch/586427eef9f2/roadmark-104-qa/mazda-sequential-checks')
actual=qa/'normal-coverage-asof-2026-10-15/stdout.log';expected=Path('/tmp/mazda-staging/full-v2/output/staged-report.json')
terminal=json.loads((actual.parent/'terminal.json').read_text());assert terminal['exitCode']==0
left=json.loads(actual.read_text());right=json.loads(expected.read_text());assert left==right,'Full normal report differs from staged report; no ignored paths'
assert (left['allCatalogueVersions'],left['tierOneVersions'],left['onSaleVersions'])==(413,336,303)
brand=next(b for b in left['brandProgress'] if b['brand']=='Mazda');assert brand['onSaleVersions']==2;assert len(brand['currentVersionReviews'])==2
selected=json.loads(Path('/tmp/mazda-staging/selected-preflight-v5/selected-after-cars.json').read_text());assert all(c['id'] in left['reconciliation']['reviewedVersionIds'] for c in selected)
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
receipt={'status':'normal_full_report_exact_staged_deep_parity_pass','at':datetime.now(timezone.utc).isoformat(),'actual':pin(actual),'expected':pin(expected),'exactDeepEquality':True,'ignoredPaths':[],'byteEquality':actual.read_bytes()==expected.read_bytes(),'allCatalogueVersions':413,'tierOneVersions':336,'onSaleVersions':303,'mazdaOnSaleVersions':2,'mazdaMakerLists':2,'mazdaCurrentListIds':[c['id'] for c in selected],'wholeMarketC1':left['reconciliation']['pass'],'terminal':pin(actual.parent/'terminal.json')}
out=qa/'normal-report-staged-parity.json'
with out.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'receipt':pin(out),**receipt}))
