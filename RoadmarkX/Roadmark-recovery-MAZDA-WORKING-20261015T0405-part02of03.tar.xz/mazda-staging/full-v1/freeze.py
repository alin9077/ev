from pathlib import Path
import json,hashlib,re
repo=Path('/workspace/scratch/586427eef9f2/roadmark-104');base=Path('/tmp/mazda-staging/full-v1')
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
# The approved wrapper supervises exactly one Node process using timeout and wait4, preserving raw terminal status.
(base/'run.py').write_bytes(Path('/tmp/leapmotor-staging/v3-reviewed/run.py').read_bytes())
old=json.load(open('/tmp/leapmotor-staging/v4-timeout/manifest.json'));registry=json.load(open(repo/'data/m1-brand-updates/registry.json'));selected=json.load(open('/tmp/mazda-research/retained-before-cars.json'))
inputs={
'acceptedManifest':old['acceptedManifest']['path'],
'packet':'/tmp/mazda-packet/v5/mazda-2026-10-15.json',
'correction':old['correction']['path'],
'leapmotor':str(repo/'data/m1-brand-updates/leapmotor-2026-10-15.json'),
'availabilityProposal':'/tmp/mazda-research/preorder-proposal/availability-corrections.proposed.ts',
'selectedBefore':'/tmp/mazda-research/retained-before-cars.json',
'selectedAfter':'/tmp/mazda-staging/selected-preflight-v5/selected-after-cars.json',
'selectedPacks':'/tmp/mazda-staging/selected-preflight-v5/selected-packs.json',
'selectedPortable':'/tmp/mazda-staging/selected-preflight-v5/portable.json',
'undefinedWitness':'/tmp/mazda-staging/selected-preflight-v5/result.json',
'acceptedLeapmotorCarDigests':'/tmp/leapmotor-staging/v4-timeout/output/car-digest-comparison.json',
'acceptedLeapmotorFieldDigests':'/tmp/leapmotor-staging/v4-timeout/output/research-field-digests.json',
'reconciliation':'/tmp/mazda-packet/reconciliation-v1/m1-mazda-market-reconciliation-2026-10-15.json',
'currentBaselineReport':'/workspace/scratch/586427eef9f2/roadmark-104-qa/leapmotor-sequential-checks/normal-coverage-asof-2026-10-15/stdout.log',
'script':str(base/'stage.mjs'),'wrapper':str(base/'run.py')}
# Bounded dependency traversal starts only at modules imported by stage, skipping the explicit replaced production loader.
seeds=['src/lib/availability-corrections.ts','src/lib/brand-updates.ts','src/lib/brand-update-registry.ts','tests/helpers/compiled-source.ts','src/lib/evidence-consumers.ts','src/lib/citable.ts','src/lib/evidence-grading.ts','src/lib/buyer-availability.ts','src/lib/portable-packs.ts','src/lib/discovery.ts','scripts/reporting/reports.ts','scripts/reporting/load.ts','scripts/reporting/m1-reconciliation.ts']
seen=set();skipped=[]
def walk(p):
 p=p.resolve()
 if p in seen:return
 seen.add(p)
 if p.suffix not in ('.ts','.tsx','.js','.mjs'):return
 text=p.read_text()
 for spec in re.findall(r'(?:from\s*|import\s*|require\(\s*)[\'\"](\.[^\'\"]+)[\'\"]',text):
  if p==repo/'scripts/reporting/load.ts' and spec=='../../src/lib/data':skipped.append({'from':str(p),'specifier':spec,'reason':'Exact compiled-source override supplies explicit composed snapshot and actual effectiveFeatures; implicit loaders throw.'});continue
  q=(p.parent/spec).resolve();options=[q,Path(str(q)+'.ts'),Path(str(q)+'.tsx'),Path(str(q)+'.json'),q/'index.ts'];found=next((x for x in options if x.is_file()),None)
  assert found,(p,spec);walk(found)
for s in seeds:walk(repo/s)
for name in registry['packets']:seen.add(repo/'data/m1-brand-updates'/name)
extra=[repo/'data/m1-brand-updates/registry.json',Path('/tmp/xpeng-staging-plan/baseline-io.mjs'),Path('/tmp/xpeng-staging-plan/staging-v1/read-complete-storage.mjs'),Path('/tmp/mercedes-staging-plan/staging-preparation/shape-first-v3/read-complete-storage.mjs'),Path('/tmp/mercedes-staging-plan/consumer-preparation/v5/feature-json-parity.mjs'),Path('/tmp/mazda-research/preorder-proposal/source-rationale.json'),Path('/tmp/mazda-review/ACCEPTANCE-v5.md'),Path('/tmp/mazda-review/PREFLIGHT-ACCEPTANCE-v5.md'),Path('/tmp/mazda-staging/runs-v1/preorder-tests/terminal.json'),Path('/tmp/mazda-staging/runs-v1/selected-preflight/terminal.json')]
seen.update(extra);seen.update(Path(v) for v in inputs.values())
qa=Path('/workspace/scratch/586427eef9f2/roadmark-104-qa/test-memory-boundary-20261015T0242')
testpaths=['tests/helpers/kia-cadillac-stage.ts','tests/kia-cadillac-integration.test.ts','tests/kia-cadillac-stage.boundary.test.ts','tests/typechecks/kia-cadillac-stage.contract.ts','tests/brand-added-detail.test.ts']
assert not set(repo/p for p in testpaths)&seen
m={'schemaVersion':1,'status':'frozen_pending_independent_manifest_review_and_root_execution_grant','mode':'derived-prefix20-EQA21-Leapmotor22-Mazda23','asOf':'2026-10-15','repo':str(repo),'nodeVersion':'v24.19.0','execArgv':['--max-old-space-size=448','--max-semi-space-size=1','--expose-gc','--import','tsx'],'timeoutSeconds':420,'killAfterSeconds':10,'automaticRetry':False,'productionRegistrationAuthorized':False,'canonicalRecaptureAuthorized':False,'rootExecutionGrantRequired':True,**{k:pin(v) for k,v in inputs.items()},'storageIndex':old['storageIndex'],'packetId':'m1-mazda-2026-10-15','eqaId':old['eqaId'],'registeredPacketIds':[json.load(open(repo/'data/m1-brand-updates'/n))['id'] for n in registry['packets']],'selectedIds':[c['id'] for c in selected],'output':str(base/'output'),'runOutput':str(base/'run'),'pins':[pin(p) for p in sorted(seen)],'dependencyTraversalSkipped':skipped,'expected':{'prefix20Cars':409,'prefix21Cars':409,'prefix22Cars':413,'prefix23Cars':413,'tierOneVersions':336,'beforeOnSaleVersions':305,'afterOnSaleVersions':303,'unchangedPeerCars':409,'researchFields':14,'selectedCars':4,'earnedFactCells':80,'selectedFeatureClaims':276,'selectedOptionalUndefinedPaths':24,'addedSources':20,'addedVersions':0,'addedModels':0,'explicitEquipmentUpdates':0},'composition':'Read retained accepted prefix20; apply only EQA21, only Leapmotor22, only Mazda23. Preserve raw one-packet metadata and compose full registry lineage explicitly. Reproduce accepted Leapmotor22 full car and all14 field digests exactly. Never replay earlier added versions.','serializationAllowance':'Exactly24 selected preflight paths, each with exact before witness:16 gradeReviewStatus,4 condition_label,4 novated_fbt confirmation_needed. Reject every other non-JSON omission. Full-stage written selected cars, packs and portable JSON must equal the passed selected preflight outputs.','consumerScope':'Four actual selected detail packs,80 new claims,276 feature claims, actual availability/ranking predicates; full report using all413 cars and actual effectiveFeatures plus the reviewed Mazda reconciliation. No production loaders.','liveTestOnlyDistinction':{'description':'The five test-only files recently updated by the separate compiler-boundary task are not imported by this stage. They are not the proposed Mazda production availability change. Focused71 tests and full lint passed; full TypeScript512/640MiB both explicit OOM, no pass claimed.','files':[pin(repo/p) for p in testpaths],'receipts':[pin(qa/'INDEPENDENT-APPLICATION-RECEIPT.json'),pin(qa/'FINAL-REVIEW-RECEIPT.md')]},'notClaimed':['Fresh original catalogue export','Full feature before/after replay','Current full suite/typecheck/build/mobile pass','Live registration or report parity','Whole-market C1 closure','Resolved residual MX-30 new-stock question','M1 completion or M2 work']}
# Record the unrelated test-only distinction as immutable pins too, without importing any of it.
m['pins']+=m['liveTestOnlyDistinction']['files']+m['liveTestOnlyDistinction']['receipts']
(base/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'script':m['script'],'wrapper':m['wrapper'],'manifest':pin(base/'manifest.json'),'pins':len(m['pins']),'sourceBytes':sum(p['bytes'] for p in m['pins']),'skipped':skipped},indent=2))
