from pathlib import Path
import sys,json,subprocess,os,time,resource,hashlib
from datetime import datetime,timezone
m=Path(sys.argv[1]); h=sys.argv[2]; assert hashlib.sha256(m.read_bytes()).hexdigest()==h
x=json.loads(m.read_text());out=Path(x['runOutput']);out.mkdir(exist_ok=False)
def now():return datetime.now(timezone.utc).isoformat()
def write(name,obj):
 with (out/name).open('x') as f:json.dump(obj,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
cmd=['node',*x['execArgv'],x['script']['path'],'--manifest',str(m),'--manifest-sha256',h]
wrapped=['/usr/bin/timeout','--signal=TERM','--kill-after=10s',str(x['timeoutSeconds'])+'s',*cmd]
write('invocation.json',dict(at=now(),cwd=x['repo'],command=cmd,supervisedCommand=wrapped,manifestSha256=h,automaticRetry=False,sourceMutationsAuthorized=False))
start=time.monotonic()
with (out/'stdout.log').open('x') as so,(out/'stderr.log').open('x') as se:
 p=subprocess.Popen(wrapped,cwd=x['repo'],stdout=so,stderr=se,start_new_session=True);write('started.json',dict(at=now(),pid=p.pid,processGroup=os.getpgid(p.pid)))
 _,status,usage=os.wait4(p.pid,0);code=os.waitstatus_to_exitcode(status);p.returncode=code;so.flush();se.flush();os.fsync(so.fileno());os.fsync(se.fileno())
terminal=dict(at=now(),exitCode=code,rawWaitStatus=status,elapsedSeconds=time.monotonic()-start,maxRssKiB=usage.ru_maxrss,stdoutSha256=hashlib.sha256((out/'stdout.log').read_bytes()).hexdigest(),stderrSha256=hashlib.sha256((out/'stderr.log').read_bytes()).hexdigest(),timeoutInterpretation='Raw status retained; no inferred cause' if code in [124,137] or code<0 else 'No timeout convention',automaticRetry=False)
write('terminal.json',terminal);print(json.dumps(terminal));print((out/'stdout.log').read_text()[-1800:]);print((out/'stderr.log').read_text()[-1800:]);sys.exit(0 if code==0 else 1)
