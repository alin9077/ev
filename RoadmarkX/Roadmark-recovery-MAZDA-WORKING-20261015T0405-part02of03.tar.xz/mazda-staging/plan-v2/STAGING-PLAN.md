# Mazda M1 staged execution plan (not executed)

## Gate and scope
- Requires independent source/packet/preorder proposal review, the bounded preorder behavioral test pass, the single selected actual-function/serialization preflight pass, and an exact root execution grant.
- No live Mazda edit, packet registration, full-car export, production catalogue hydration, build, broad test suite, publication or M2 work is authorized by this plan.
- Candidate packet: /tmp/mazda-packet/v3/mazda-2026-10-15.json, SHA-256 3657e47d6a0b3cbd690dbbe6e775fd6e07dacfc46f3096cbf143cd2e6286b1f4
- Proposed source change: /tmp/mazda-research/preorder-proposal/availability-preorder.patch. The staged candidate uses the exact proposed module in memory, with all dependencies resolved against the live source; the live file stays untouched until separately authorized registration.
- Proposed reconciliation: /tmp/mazda-packet/reconciliation-v1/m1-mazda-market-reconciliation-2026-10-15.json

## Selected preflight, before any full composition
Use /tmp/mazda-staging/selected-preflight-v2/prepared-command.json. This single selected run covers four before/after Mazda rows, all 276 actual effective feature outputs, 80 new/updated fact citations, availability and C1/on-sale predicates, full live and written portable parity, and exact own-undefined omission paths. It verifies all unaffected features, including auxiliary warranty content, while allowing only the four canonical driveaway-price feature projections to refresh. It never calls a production loader. It does not assert a full-market report.

The source registry and small support fields are retained from the accepted storage chain. Only the four Mazda variants, models, raw features, feature contexts and eligibility rows enter actual selected consumers. Every observed optional undefined location must have a specific producer/type and exact before witness; there is no copied Leapmotor 54-path allowance. The full-stage manifest must pin the resulting witness and exact locations after review, not a predicted count.

## Full current derived composition (one pass)
1. Restore the 409-car accepted Mercedes prefix-20 storage using the exact accepted readers and pinned storage index. This is a derived retained baseline, not a fresh full-car export.
2. Apply only the later single EQA towing-basis correction, prefix 20 to 21. Prove the 408 other cars and all nonmetadata research fields unchanged.
3. Apply only the accepted Leapmotor packet, prefix 21 to 22. Result: 413 cars, 336 Tier 1, previous report 305 on-sale. Preserve its four added identities exactly. Do not replay earlier added-version packets.
4. Assert that the four selected Mazda before rows equal the already verified research selection. Apply only the proposed Mazda packet, prefix 22 to 23, via the exact proposed availability module and otherwise actual unchanged functions.
5. Compose metadata packet IDs explicitly at each single-packet prepareBrandResearch boundary, preserving every other metadata field. Record the raw single-packet output metadata as well as the composition transition. Never treat prepareBrandResearch([one packet]) metadata as a complete registry history.

## Expected bounded effects
- 413 catalogue identities and 336 Tier 1 identities remain unchanged; no additions, removals, model-year inference or identity edit.
- Exactly four Mazda cars can change. All 409 peer cars and all unselected variants/features/history must remain byte-equivalent under canonical JSON digests and deep comparisons.
- Mazda has 72 specific fact updates, eight cells from two shared brand terms, four explicit configuration reviews, four availability changes and four summaries. No explicit equipment update, model addition, version addition or identity update.
- CX-6e GT/Azami change current_or_order_listed + preorder to announced_provisional + preorder. Both keep the buyer label Order open or arriving and fresh C1 eligibility. Expected global C2–C6 on-sale denominator: 305 to 303. Reporter and ranking scope code does not change.
- Mazda 6e GT/Atenza remain on sale under current maker advertised availability. No physical stock, accepted factory order, completed delivery or formal manufacturer MY is asserted.

## Actual consumers and report
- Instantiate the actual evidence-consumers factory with the hypothetical 23-packet registry; supply explicit data/cars and make all default loaders throw.
- Produce four actual detail/comparison packs; verify source pointers, all 80 packet fact/term claims and all 276 feature claims. Verify all nonprice effective feature rows against before. Preserve all historical source records, unresolved auxiliary fields and source conflicts.
- Apply the selected-preflight witness's exact after omission paths only, then run strict JSON shape checks for every other pack value. Verify live portable equality and JSON-written/readback portable equality, without normalizing or mutating live packs.
- Use the actual report loader with explicit composed data/cars and actual effectiveFeatures. Append only the reviewed Mazda reconciliation using the actual combineM1Reconciliations function. Verify 413 total, 336 Tier 1 and 303 on-sale if all evidence remains unchanged; supported current Mazda lists must be present, while whole-market C1 and residual MX-30 uncertainty remain open.
- Record exact field/car digest comparisons, transition proofs, four selected after cars/packs, citations, portable JSON, omission proof, full report, measurements and exit receipt. Do not produce a new full canonical snapshot or broad feature replay.

## Resource and stop policy
One sequential process after root grants the heavy slot. Proposed cap follows accepted Leapmotor execution: Node --max-old-space-size=448 --max-semi-space-size=1 --expose-gc --import tsx, measured by a bounded wrapper, with a reviewed timeout informed by the prior accepted 420-second run. Pin exact live dependencies, approved packet/proposal/reconciliation, baseline inputs and selected witness before granting. No automatic retry. Preserve actual failure output, never infer a SIGKILL cause. A failed assertion or new serialization path stops for diagnosis and independent review.

## Registration and checks remain separate
After staged output review, root may authorize exact registration (packet, preorder allowance, behavioral test, reconciliation import/data, and brief documentation). Fresh structural validation, report, relevant behavioral tests and lint then run sequentially. Full TypeScript/full suite/build/mobile remain independent open checks unless actually run and passed. A safety save must omit response Cookie/Set-Cookie/authentication headers in backup copies while retaining frozen original capture pins locally.
