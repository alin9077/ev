from pathlib import Path
import sys, json, hashlib, os
from datetime import datetime, timezone
manifest=Path(sys.argv[1]); expected=sys.argv[2]
assert hashlib.sha256(manifest.read_bytes()).hexdigest()==expected
m=json.loads(manifest.read_text()); repo=Path(m['repo']); out=manifest.parent/'application-receipt.json'
assert not out.exists()
expected_targets={'data/m1-brand-updates/mazda-2026-10-15.json','data/m1-mazda-market-reconciliation-2026-10-15.json','src/lib/availability-corrections.ts','data/m1-brand-updates/registry.json','scripts/reporting/load.ts','tests/availability-preorder.test.ts'}
assert len(m['targets'])==6 and {r['relativePath'] for r in m['targets']}==expected_targets

def pin(p):
 p=Path(p); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def verify(p):
 assert pin(p['path'])==p,p['path']
for p in m['existingPacketPins']:verify(p)
verify(m['stageManifest']);verify(m['stageReceipt']);verify(m['stageTerminal']);verify(m['patch'])
for row in m['targets']:
 assert Path(row['target'])==repo/row['relativePath']
 verify(row['after'])
 if row['before']:verify(row['before']);verify(row['beforeCopy'])
 else:assert not Path(row['target']).exists()
registry_target=repo/'data/m1-brand-updates/registry.json';before_registry=json.loads(registry_target.read_text());candidate_registry=json.loads(next(Path(r['after']['path']).read_text() for r in m['targets'] if r['relativePath']=='data/m1-brand-updates/registry.json'))
assert len(before_registry['packets'])==m['expectedRegistryBefore']
assert candidate_registry=={**before_registry,'packets':[*before_registry['packets'],'mazda-2026-10-15.json']}
assert len(candidate_registry['packets'])==m['expectedRegistryAfter']
changes=[]
for row in m['targets']:
 target=Path(row['target']); payload=Path(row['after']['path']).read_bytes()
 with target.open('wb' if row['before'] else 'xb') as f:f.write(payload);f.flush();os.fsync(f.fileno())
 actual=pin(target);assert actual['bytes']==row['after']['bytes'] and actual['sha256']==row['after']['sha256']
 changes.append({'relativePath':row['relativePath'],'before':row['before'],'after':actual})
for p in m['existingPacketPins']:verify(p)
receipt={'status':'exact_six_path_registration_applied_pending_fresh_validation','at':datetime.now(timezone.utc).isoformat(),'manifestSha256':expected,'changedPaths':changes,'oldPacketsPreserved':m['existingPacketPins'],'registryBefore':m['expectedRegistryBefore'],'registryAfter':m['expectedRegistryAfter'],'unrelatedWrites':False,'productionPublication':False,'canonicalRecapture':False}
with out.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'status':receipt['status'],'receipt':pin(out),'changedPaths':[r['relativePath'] for r in changes]}))
