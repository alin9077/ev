import json,hashlib,pathlib,collections
P=pathlib.Path
root=P('/tmp/mazda-research')
p=json.loads(P('/tmp/mazda-packet/v3/mazda-2026-10-15.json').read_text())
r=json.loads((root/'normalized-review-v3.json').read_text())
b=json.loads((root/'retained-before-cars.json').read_text()); by={x['id']:x for x in b}
checks={}; findings=[]
checks['frozenHashes']={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in [root/'normalized-review-v3.json',root/'census-review-v2.json',P('/tmp/mazda-packet/v3/mazda-2026-10-15.json')]}
checks['scope']={k:len(p[k]) for k in ['models','variants','features','versionUpdates','versionGuards','facts','configurationUpdates','availability','summaries','brandTerms']}
checks['coreGrades']=dict(collections.Counter(f['buyerGrade'] for v in r['variants'] for f in v['coreFacts'].values()))
checks['beforeSnapshotMismatches']=[]
for kind in ['facts','configurationUpdates','availability']:
 for x in p[kind]:
  c=by[x['variantId']]
  expected=c['facts'].get(x['after']['key']) if kind=='facts' else c['configurationEvidence'] if kind=='configurationUpdates' else {'availability':c['availability'],'evidence':c['availabilityEvidence']}
  if x['before']!=expected: checks['beforeSnapshotMismatches'].append([kind,x['variantId']])
for t in p['brandTerms']:
 for id in t['applicableVariantIds']:
  if t['before'][id]!=by[id]['facts'].get(t['key']):checks['beforeSnapshotMismatches'].append(['brandTerms',id,t['key']])
for x in p['versionGuards']:
 expected={k:by[x['variantId']].get(k) for k in x['before']}
 if x['before']!=expected:checks['beforeSnapshotMismatches'].append(['versionGuard',x['variantId']])
checks['normalizedPacketMismatches']=[]; checks['summaryConfigurationMismatches']=[];checks['dependencyMismatches']=[]
for v in r['variants']:
 facts={f['after']['key']:f['after'] for f in p['facts'] if f['variantId']==v['id']}
 facts.update({t['key']:t['fact'] for t in p['brandTerms'] if v['id'] in t['applicableVariantIds']})
 for k,f in v['coreFacts'].items():
  for field in ['value','status','buyerGrade','basis','comparisonBasis','unit']:
   if facts[k][field]!=f[field]:checks['normalizedPacketMismatches'].append([v['id'],k,field])
 config=next(x for x in p['configurationUpdates'] if x['variantId']==v['id']); summary=next(x for x in p['summaries'] if x['variantId']==v['id'])
 if summary['conditions']!=config['after']['requiredBuyerVisibleConditions']:checks['summaryConfigurationMismatches'].append(v['id'])
 for scope,dep in [('configuration',d) for d in config['dependencies']]+[(part,d) for part in ['strength','tradeoff'] for d in summary[part]['dependencies']]:
  if facts.get(dep['key'])!=dep['expected']:checks['dependencyMismatches'].append([v['id'],scope,dep['key']])
checks['configurationChanges']={x['variantId']:{'changedTopKeys':[k for k in x['after'] if x['before'].get(k)!=x['after'][k]],'removedNulls':sorted(set(x['before'].get('requiredNulls',{}))-set(x['after'].get('requiredNulls',{})))} for x in p['configurationUpdates']}
checks['captureMismatches']=[]
for s in p['sources']:
 for cap in s['retainedCaptures']:
  f=P('/tmp')/cap['locator']
  actual=hashlib.sha256(f.read_bytes()).hexdigest()
  if actual!=cap['sha256'] or f.stat().st_size!=cap['bytes']:checks['captureMismatches'].append([s['id'],cap['locator']])
checks['sourceSnapshotCount']=len(p['sources']);checks['captureCount']=sum(len(x['retainedCaptures']) for x in p['sources'])
checks['availabilityTransitions']=[{'id':x['variantId'],'before':x['before']['availability'],'after':x['after']['availability'],'orderStatus':x['after']['evidence']['orderStatus'],'physicalStockVerified':x['after']['evidence']['physicalStockVerified'],'factoryOrderAcceptanceVerified':x['after']['evidence']['factoryOrderAcceptanceVerified']} for x in p['availability']]
checks['runtimeExecuted']=False
P('/tmp/mazda-review/static-audit-v3.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({k:v for k,v in checks.items() if k not in ['configurationChanges','availabilityTransitions','frozenHashes']},indent=2))
