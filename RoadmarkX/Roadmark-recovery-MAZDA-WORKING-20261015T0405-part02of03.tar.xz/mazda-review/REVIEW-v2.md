# Mazda M1 independent review, 15 October 2026

## Decision
The four-refresh scope and researched figures are supported. Hold packet acceptance for one narrow traceability correction, then run the already-prepared bounded behavioral and selected actual-consumer checks under the parent's execution grant. No live file was edited, no catalogue was hydrated, no tests/build/typecheck ran, and nothing was published during this review.

## Blocking finding
1. CX-6e E35 Azami acceleration retains the opposing CarsGuide 7.9-second observation in a visible qualification, but the applied packet omits the captured CarsGuide source. The acceleration conflict's source_ids only contains The Driven. Add the existing exact CarsGuide source snapshot (https://www.carsguide.com.au/mazda/cx-6e/price/2026/azami) and attach it to the conflict citation. Preserve the selected 8.1-second figure as Reported by The Driven, the 7.9-second opposing observation, and the no-ranking decision. This is a packet traceability gap, not unsupported numerical research: both local source bodies independently support their respective values.

## Minor correction requested
The Mazda 6e brochure page 5 has a single shared E35 specification column, applying to GT and Atenza. Replace references to separate GT/Atenza columns with the shared E35 table. The figures and application are correct.

## Verified research and scope
- Read docs/DOT-BRIEF-103.md fully. Review remains M1-only. No additions, equipment expansion, hero edits, M2 changes, or publishing are proposed by this packet.
- Independently verified the exact pinned v2 normalized/census/packet hashes supplied by the parent.
- Exactly four existing Mazda identities are guarded; no model/version/identity/feature additions or updates. Four summaries and configurations, four availability reviews, 72 individual facts plus eight inherited warranty cells.
- 68 core cells: 48 Confirmed, 16 Check, four Reported. Packet values/status/grade/basis/unit exactly match normalized research.
- All 72 fact before snapshots, four configuration snapshots, four availability snapshots, four identity guards and eight brand-term before snapshots match the selected retained rows.
- All summary conditions exactly equal their configuration conditions. Every summary/configuration dependency equals its packet fact. Source capture hashes/byte sizes match for all 37 retained captures across 19 v2 source snapshots.
- Current Australian maker configurator bodies contain exactly GT/Atenza for 6e and GT/Azami for CX-6e. Paid paint/interior options are not new grades. Australian brochure pages 5 and 7 and the battery badge were independently visually inspected.

## Source findings
- Public exact E35 GT offer cards support A$52,990 for 6e and A$56,990 for CX-6e as driveaway-from observations. These are distinct from the higher-grade exact-state configurator figures, A$55,990 Atenza and A$59,990 Azami in NSW. All four state arrays show WA A$1,000 higher. No universal national-price inference or promotion rebate deduction.
- Historical maker launch tables say MLP without explicitly establishing before-on-road treatment. They remain supplemental and unranked. The 6e model page's before-on-road quote is a reproduced third-party review, not a maker list-price table, so it does not justify rung 1. Separate secondary before-on-road amounts remain below maker rungs.
- Brochures support 78 kWh labelled battery capacity, 194 kW DC peak, approximately 24 minutes 10–80%, 11 kW maximum onboard AC, 190 kW motor output and RWD. The 15-minute figure is separately 30–80%, not 10–80%. Gross/usable capacity, charging-session average/input and charge-cable inclusion are not inferred.
- 6e WLTP range is 560 km for the shared E35 powertrain; CX-6e is 484 km GT / 468 km Azami. 6e dimensions are 4,921 / 1,890 / 1,485 mm; CX-6e 4,850 / 1,935 / 1,620 mm. Length includes plate holder, width excludes mirrors, height includes a 75 kg driver. Five seats are supported by official 6e launch prose and current CX-6e maker navigation data.
- Both boot conflicts stay visible: 6e 337 L brochure VDA versus website 336 L; CX-6e 363 L brochure VDA versus website 468 L. Both primary boot facts retain field holds. The separate web observations have no comparison basis.
- 6e 1,500 kg braked towing carries an unmatched paragraph footnote in its brochure and remains unranked. CX-6e's separate brochure explicitly requires Mazda Genuine Towing Kit, subject to State/Territory regulations; this condition is not borrowed into 6e.
- New-vehicle warranty is five years/unlimited km under current official terms. Current official model-linked badge says eight years/160,000 km battery warranty. No retention threshold or whichever-first wording is invented. Existing auxiliary source observations remain untouched.
- All acceleration values are secondary, Reported and unranked: 6e GT/Atenza 7.9 seconds, CX-6e GT 7.9 and Azami 8.1, with the Azami opposing 7.9 retained.
- Maker BEV hub explicitly says 6e available now/test-drive and CX-6e coming soon/open for pre-order. The linked preorder URL is a dealer enquiry form. The current model-page 'almost here' wording is retained. Historical delivery forecasts do not prove arrival.
- CarExpert and CarsGuide brand lists show 6e and CX-6e and treat MX-30 as discontinued/older. Mazda's discontinued page supports removal from production. The unresolved residual-new MX-30 search remains open and does not claim nationwide stock absence. Global C1 remains open.

## Configuration and availability boundaries
Only mutable scope keys change. Historical source/build records, held equipment conflicts, gross/usable battery, model-year, VIN/build and battery-retention nulls remain exact. The 6e removes only price_aud, battery_kwh label and zero_to_100_s nulls with exact supporting facts. CX-6e has no null release. Complete-vehicle certification stays false.

The proposed validator patch adds the already-documented preorder enum and rejects contradictory not_current + preorder. It does not change before-snapshot, source, freshness, provenance, chronology or permission guards. Buyer availability already prioritizes preorder. Reporter isOnSale excludes announced_provisional; isCurrentListEligible explicitly permits fresh preorder with usable evidence. Thus the two CX-6e transitions logically reduce the on-sale denominator by two (expected global 305 to 303) while keeping C1 eligibility and the buyer label Order open or arriving. This global count is a prediction pending actual composition/report execution, not an executed report.

## Remaining gates
- Accept the source-citation/locator correction and pin its new files.
- Run the narrow preorder behavioral tests and selected actual-function preflight only under the parent's heavy-slot grant. Confirm all 276 effective features except the intended four price projections stay exact; verify citable/portable parity and actual ranking behavior.
- Full composition/report and no-peer-change/hero preservation evidence remain separate. This review provides no live registration or publishing authorization.

Static audit: /tmp/mazda-review/static-audit-v2.json. The review reads public source bodies and the sanitized index; it does not copy receipt response headers or authentication/cookie data.
