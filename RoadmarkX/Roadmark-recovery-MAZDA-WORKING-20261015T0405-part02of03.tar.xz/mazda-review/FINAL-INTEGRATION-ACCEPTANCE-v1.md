# Mazda M1 final independent integration acceptance

Accepted for source/document freeze and the parent-controlled periodic working save. This is a Mazda M1 integration acceptance, not whole-market M1 completion, a full-suite/typecheck pass, a phone/UI validation or publication approval. No remaining blocking Mazda source/registration finding. Reviewer performed read-only/static/result checks and wrote only reviewer artifacts.

## Accepted scope

- Four retained Mazda versions refreshed; no added versions, identity, equipment or hero changes.
- Packetv5 SHA256 `8af4d56bba3d3ad523df3ed42f0d6f72cb0372f82b0bf19669d73345c24ee62c`; reconciliationv2 SHA256 `8cbb5d269f6914192ae6427166bc34517b9a9e6347c13413b2a5dd63e883b69c`.
- Exact six-path application receipt `320f8354dbc0525986e5af00c3ef00b333661b5c321f635bf6ea2df111b86560`: accepted packet/reconciliation, append-only registry22→23, reporting import/combine, exact two-line preorder validator support, actual-module behavior test. All six live files read back exact.
- Separately granted one-file safety-test update receipt `c0658db8e635186e9bea1b221b2f176e50b4efcb1ff539173df92d22eb8303d9`; test SHA256 `d5b9c0c479c30f2f171f1fffb3e7ba0a2a5c8fa28bc83e7a3a6f85872343a3d1`. Three stale null assumptions replaced with stronger value/grade/source/method/conflict/ranking assertions. All production registration files remain unchanged.

## Proven results

Accepted retained20→EQA21→Leapmotor22→Mazda23 composition, all14 field digests, exact accepted prefix22,409 unchanged peers, four actual selected packs and276 feature claims; all24 optional-undefined paths witnessed exactly before and after. In-memory and serialized portable parity verified; no arbitrary omissions. Fullstagev2 passed after the retained v1 failure/corrected reconciliation wording.

Fresh normal market-view preflight and structural validation passed. Fresh normal coverage is byte-for-byte and deep-equal to accepted staged report SHA256 `f6d52d701b71bea682e586ad168d166c7f180430fab0d843297cbbf99d81fb02`, with no ignored paths:413 catalogue,336 Tier1,303 on-sale. The305→303 change is the corrected scope for two CX-6e preorder records, which remain in the catalogue and C1 lists. Mazda has two on-sale versions/all34 core cells filled and reviewed, four current-list memberships in two maker-family reviews, and supported summaries. Global independent-list closure and residual MX-30 remain open. Cargo/towing/secondary conflicts remain visible and excluded from ranking as appropriate.

## Test results and preserved limitations

The original relevant14-file run failed:232 tests,229 pass,3 fail. Two live-safety null assertions predated accepted Mazda/Toyota labelled-number evidence; the third was a buyer-availability file failure with no captured cause. It is not retrospectively a pass. The corrected safety file then passed7/7, including unchanged whole-catalogue claim/review/availability source closure; the unchanged buyer file separately passed11/11. Four changed TypeScript files passed lint with empty output. Do not sum overlapping runs or claim a full suite passed. All seven fresh terminal stdout/stderr hashes were independently verified.

Full TypeScript checks at512MiB and640MiB remain explicit OOM failures. No new phone screenshots, browser/UI/full-build validation or publishing occurred. Stage/run original failure evidence is retained. Current source receipts containing response headers require the established sanitization treatment before backup distribution; no header values were copied by reviewer.

## Handoff

The plain-English one-page report is SECTION-8-REPORT-FINAL-v1.md; its separate FRESH-REPORT-APPENDIX-FINAL-v1.json contains exact terminal/report pins, all remaining brands/models/leads and before/after coverage numerators. Final author document/status index readback remains the last freeze housekeeping step; no further evidence research or test expansion is requested.
