# Mazda registration live readback

Application receipt `/tmp/mazda-staging/registration-v1/application-receipt.json`, SHA256 `320f8354dbc0525986e5af00c3ef00b333661b5c321f635bf6ea2df111b86560`, independently checked. All six live target bytes/hash values match the accepted manifest after pins exactly. Registry has23 entries. Receipt records all22 prior packet hashes preserved.

Of134 full-stage input pins, the only allowed changed paths are registry.json, scripts/reporting/load.ts and src/lib/availability-corrections.ts. All remaining131 file sizes and112 bounded hashes (<1MiB) checked unchanged. Larger inputs were not broadly rehashed by reviewer; the guarded application recorded its full old-packet checks.

No fresh test/report pass is implied. All live validation remains pending under parent supervision. Reviewer only performed bounded readback and wrote this receipt.
