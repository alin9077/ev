# Mazda v5 bounded runtime review

Accepted the two root-granted candidate runs. This supersedes only the pending behavioral/selected-runtime gates in ACCEPTANCE-v5.md; full composition, report, peer/hero proof, live registration and publishing remain separate.

- Five preorder behavioral tests passed. Exit 0, 0.427 seconds, peak RSS 50,900 KiB. Reproduced old-validator rejection; candidate accepts guarded preorder while retaining identity, before-state, source, approval, evidence-date and chronology failures and existing-status parity.
- Selected actual-function preflight passed. Exit 0, 3.658 seconds, peak RSS 297,836 KiB. Empty stderr, no retry. Result hash independently verified: 07768ae2dc4ff095075f836ac361ccb34bad125455b19ca5bc08b5faeb8f8ba9.
- Four before/after cars, 80 earned fact/term claims, 276 effective feature claims. Only the four intended canonical driveaway feature projections change; other effective features remain exact. Actual current/buyer/C1 predicates and seven discovery ranking attributes pass, including the empty-unit Seats bucket.
- Exact 24 before and 24 after optional-undefined witness objects match after removing phase. Four confirmation_needed paths on novated_fbt, 16 gradeReviewStatus paths, four condition_label paths. One witness on each 6e and eleven on each CX-6e. Every path is unique. Producers at launch-evidence.ts:84 and evidence-regrading.ts:185/188 and optional Feature type fields were read and verified.
- In-memory portable equality, serialized equality after only those witnessed omissions, written readback equality, and unchanged live packs all passed. No production/default loader calls, source edits or full-catalogue hydration.

Primary result: /tmp/mazda-staging/selected-preflight-v5/result.json
Terminal receipts: /tmp/mazda-staging/runs-v1/preorder-tests/terminal.json and /tmp/mazda-staging/runs-v1/selected-preflight/terminal.json
These are reviewed author-executed results. The reviewer did not run or rerun tests.
