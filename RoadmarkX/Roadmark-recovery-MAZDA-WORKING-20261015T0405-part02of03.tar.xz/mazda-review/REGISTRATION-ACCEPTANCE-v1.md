# Mazda six-path registration acceptance

Static patch/application review accepted, pending root's explicit application grant and subsequent fresh validation. Reviewer made no live changes.

- Manifest `/tmp/mazda-staging/registration-v1/manifest.json`: SHA256 `7f30a76e3fdc7c896ff0ed3e5fba9e823d58c007763fc56d8cef38cbf25b031b`
- Patch `/tmp/mazda-staging/registration-v1/registration.patch`: SHA256 `8341dbb8a6996e4e4878050ae6c998fe14c7892ef14e993da59c4f014cba3b1a`
- Apply script `/tmp/mazda-staging/registration-v1/apply.py`: SHA256 `7520efde86f7df3dc651b1c9753c805e3de9fdd79d6e179b6d1496221a83fe32`

All six candidate/before/before-copy hashes and all stage receipt references checked exact. All22 old packet pins equal the passed full-stage pins. Patch paths and guarded script target allowlist contain exactly:

1. Create data/m1-brand-updates/mazda-2026-10-15.json, exact accepted packetv5 `8af4d56bba3d3ad523df3ed42f0d6f72cb0372f82b0bf19669d73345c24ee62c`
2. Create data/m1-mazda-market-reconciliation-2026-10-15.json, exact accepted reconciliationv2 `8cbb5d269f6914192ae6427166bc34517b9a9e6347c13413b2a5dd63e883b69c`
3. Replace src/lib/availability-corrections.ts: exactly two added lines, preorder status admission and not_current+preorder contradiction; no guard removal
4. Replace data/m1-brand-updates/registry.json: append Mazda after the exact22 retained entries; no reorder/removal
5. Replace scripts/reporting/load.ts: only Mazda reconciliation import and final combine argument
6. Create tests/availability-preorder.test.ts: exact reviewed four-group actual-module synthetic-fixture behavioral test

Apply checks manifest hash, target allowlist, all22 old packets, stage evidence, candidates and unchanged before snapshots before writing; verifies every written target and all old packet bytes afterward, then records an exclusive application receipt. Three created targets must be absent. Before copies are retained for the three replacements. No other source/hero/doc/asset target or publication action. Sequential filesystem writes are not represented as a transactional rollback mechanism; failures must be retained and inspected, not blindly retried. Fresh actual-source tests and normal report remain separate validation gates.
