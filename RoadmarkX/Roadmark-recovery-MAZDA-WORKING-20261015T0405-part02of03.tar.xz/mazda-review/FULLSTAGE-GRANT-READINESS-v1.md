# Mazda full-stage v1 grant-readiness review

Ready for the parent's one-pass execution grant. No blocking finding in the frozen manifest/script. This review did not execute the stage or any runtime check.

Exact approved candidate inputs:
- /tmp/mazda-staging/full-v1/manifest.json: 4fa2ccbfa8162f83370de9c7cb079acf019a972f0692a4cfba151154f85a76fe
- /tmp/mazda-staging/full-v1/stage.mjs: 3a933dcfdaa9104edf12348add2373b77204ad00b7e4416c1423637cb6038b1d
- /tmp/mazda-staging/full-v1/run.py: 1cd8a3fcc310f77ea0d40051dce25bb4626028ce2a3be12ea29405dcde6c444b
- Mazda packet stays accepted v5: 8af4d56bba3d3ad523df3ed42f0d6f72cb0372f82b0bf19669d73345c24ee62c

Checks:
1. The accepted recursive reader is reused, not its historical fixed-size wrapper or a production catalogue loader. Its exact pinned storage descriptors and all inherited car hashes are verified at each retained layer. The accepted prefix20 manifest, index and all fourteen research fields are reused. No new canonical full export is written.
2. Only EQA21, Leapmotor22 and Mazda23 are applied. Earlier added-version packets are not replayed. EQA affects exactly its one towing fact. The entire prefix22 car and field digests must equal the accepted Leapmotor stage. Four Mazda before rows must equal the passed selection.
3. Raw one-packet metadata is retained and only metadata.brand_update_packet_ids is explicitly composed to the full prefix. Other metadata and research fields are checked, with immutable input digests repeated at completion.
4. Mazda preserves all 413 identities and all 409 peer cars. Only the four selected Mazda variants/configuration/availability/facts/summaries change. All existing sources are preserved and exactly twenty source snapshots added. No models, versions, explicit equipment or identity updates.
5. Four selected after cars, actual consumer packs and serialized portable output must exactly equal the passed selected preflight files. Eighty fact/term claims, 276 feature claims, exact source URLs/dates/metadata, availability/C1 and ranking predicates are checked. All twenty-four undefined omissions require exact pointer, variant, criterion, row index, property and retained-before witness; strict JSON checking rejects every other omitted/non-JSON value.
6. Actual report loader runs with explicit composed data/cars and the actual effectiveFeatures consumer. Its production-data import is the sole documented traversal skip and is replaced with a throwing implicit loader plus actual effectiveFeatures. Actual report asserts 413 catalogue, 336 Tier 1, 303 on-sale, valid registry, all four Mazda current-list IDs/two model reviews and zero unreviewed Mazda core grades/missing summaries. Global C1 and residual MX-30 remain open. The reviewed Mazda reconciliation is appended by the actual combine function.
7. Static relative-import traversal found no missing pin in the imported source graph. All 127 file sizes match; 94 bounded code/small-file hashes were independently checked. Larger registered data files are not broadly rehashed by the reviewer; the staged process verifies every declared pin before and after its single run. The five separately labelled test-only changes are not imported. No full-suite/typecheck/build success is asserted.
8. The wrapper preserves timeout/wait4 terminal status, stdout/stderr hashes and resource usage. Fixed Node version/flags and unset NODE_OPTIONS are asserted. Limits: old-space 448 MiB, semi-space 1 MiB, expose-gc, tsx, 420 seconds plus ten-second TERM/KILL grace. Exclusive output creation, no automatic retry, no source edits, no live registration or publishing.

Output and run directories did not exist at review. Static dependency/pin audit is fullstage-static-pins-v1.json. After a grant and run, inspect terminal receipts, progress, every digest transition, selected output pins, report and peer-preservation evidence before accepting registration.
