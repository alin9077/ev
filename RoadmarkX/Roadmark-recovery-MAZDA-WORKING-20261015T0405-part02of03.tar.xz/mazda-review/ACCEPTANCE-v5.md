# Mazda M1 v5 independent source and candidate review

## Decision
Accept the v5 research and packet for the bounded candidate validation stage. No remaining source or static packet blocker was found. Accept the narrow preorder validator proposal in principle, subject to its prepared behavioral tests. This is not runtime acceptance, live-registration approval, a full-market report, M1 completion or permission to publish.

## Reviewed freeze
- Normalized v5: /tmp/mazda-research/normalized-review-v5.json
  SHA-256 5b381f508e599c37bee5915ed86ce1d891c0413f946b6e9b696c8af2fc56da5f
- Census v2 (unchanged): /tmp/mazda-research/census-review-v2.json
  SHA-256 d927aaa7151ac866884618a1a6a8fe8c1c81bdb7f02ff4aadf4a66a5bf38238a
- Packet v5: /tmp/mazda-packet/v5/mazda-2026-10-15.json
  SHA-256 8af4d56bba3d3ad523df3ed42f0d6f72cb0372f82b0bf19669d73345c24ee62c
- Proposed availability module: /tmp/mazda-research/preorder-proposal/availability-corrections.proposed.ts
  SHA-256 9e75e8ebce7c4392c37f46d12873bbaa472cdd1a0b127c8a89c55a34a9d94b47
- Selected preflight v5: /tmp/mazda-staging/selected-preflight-v5/check.mjs
  SHA-256 7c32204af51aed6da2c79638514305a0f7018dacbd0d4b7997dc92692fdf4daf

## Findings closed
The v2 Azami acceleration conflict lacked a source link for the opposing CarsGuide figure. v3 adds the already-captured exact source to fact, grade-review and issue citations. v4 keeps the displayed attribution The Driven for the selected 8.1 seconds, while retaining CarsGuide's conflicting 7.9 seconds and both links. The sourceLabel fix is the only packet change from v3 to v4.

The 6e range locators now correctly identify the shared E35 brochure table instead of separate GT/Atenza columns. Values remain unchanged.

v5 then changes only the four seat-count units from “seats” to the existing empty-unit convention, plus their exact configuration dependencies. Values stay 5 and comparisonBasis stays Seats. This avoids splitting the existing seat-count ranking bucket. The final preflight asserts these four fields and the actual empty-unit Seats group.

## Independent checks completed
- Full brief read, source text and five relevant visual assets inspected, both raw configurator HTML JSON payloads independently parsed and compared exactly with their extracted data.
- Four retained identities only, zero additions or explicit equipment changes. 68 core cells retain 48 Confirmed, 16 Check, four Reported.
- All identity/fact/configuration/availability/brand-term before snapshots match selected retained rows.
- All normalized-to-packet core values, grades, statuses, units and bases match.
- Summary conditions exactly match configuration conditions; every summary/configuration dependency equals its exact post-packet fact.
- All 39 public capture files across 20 source snapshots match their declared hashes and byte sizes.
- Historical configuration fields and equipment conflicts remain exact. Only justified price, labelled-battery and secondary-acceleration null releases occur on the two 6e records; factory-build, MY, gross/usable, cargo and retention holds remain intact.
- The detailed research/source conclusions in REVIEW-v2.md remain valid, with its two requested corrections closed above. The source route for the opposing CarsGuide page is the exact captured URL https://www.carsguide.com.au/mazda/cx-6e/price/2026/azami?id=2IzQ0kEM.
- Source-supported availability is 6e current advertised on-sale, CX-6e announced_provisional + preorder. Existing reporter logic predicts two fewer on-sale rows, global 305 to 303, while C1 eligibility and Order open or arriving labels remain. No reporter-scope change, physical-stock claim, factory acceptance or fulfilled forecast is inferred.
- The proposed validator changes only preorder enum admission and the matching not_current contradiction check. Existing identity, before state, provenance, chronology, source/freshness and hold guards remain.

## Required execution gates
The latest selected preflight now checks actual discovery exclusionReason/rankAttribute across all seven discovery attributes, including 6e boot/towing holds, eligible 6e price/range/charging/seats/length, CX-6e preorder exclusions, and secondary acceleration gates. It also checks 276 effective feature claims, 80 packet fact/term claims, exact before witnesses for omitted undefined properties, and live/serialized/written portable parity. Source/helper pins are recorded. None of these runtime assertions has been executed by this reviewer.

The parent must grant the heavy slot before the bounded preorder tests and selected preflight run. Full current composition, global coverage/report counts, no-peer-change proof and protected-hero preservation remain later acceptance gates. No live repository file was edited by this reviewer, and no test, typecheck, build, catalogue hydration or publication was performed.

Artifacts: static-audit-v5.json contains the independently computed structural and capture checks. Header-bearing receipt files were neither reproduced nor uploaded.
