# Mazda live-source preorder test: static acceptance

Draft `/tmp/mazda-staging/registration-preparation-v1/availability-preorder.test.ts`, SHA256 `c83ea6121df66abff68f19cf1599eccbd5c16b45205d36a3d2b74dc2024e1d35`, is suitable for the narrow registration candidate, intended destination `tests/availability-preorder.test.ts`. Not executed by reviewer; execution requires root grant.

Four behavioral test groups import actual availability corrections, buyer availability and reporting helpers. The synthetic Source, Car and AvailabilityCorrection are explicitly typed and include required fields. No production catalogue loader or historical car/count fixture, no assertion that the old source must reject preorder, and no replacement matcher.

Coverage: fresh sourced preorder refresh preserves Order open or arriving and C1 while leaving legacy on-sale; direct stale/unsourced C1 rejection; no stock/factory acceptance/model-year/fact/configuration promotion; original input immutable; exact identity/before/duplicate-ID/usable-source validation; source duplicate/missing/stale/future/unsafe/blocked/conflicted/held rejection; review approval/provenance/date/predecessor guards; unknown order status and not_current+preorder contradiction; existing six status behaviors preserved. Expected assertions agree with current actual consumer/helper code plus the exact two-line preorder validator proposal.

This is static source review, not a typecheck or test-pass claim.
