# Mazda full-stage v1 failure: exact reconciliation identity

Status: original full-stage run failed and is not accepted. No output directory was written. No execution retry or assertion relaxation is authorized by this review.

The retained run is `/tmp/mazda-staging/full-v1/run/terminal.json`; exit 1 after 175.26 seconds, peak RSS 546,180 KiB. Stderr SHA256 `61cc83d44373d43c3d89bb9b46539b618470eb2417dc6fe54e5dd7be8c99ff91`. The failure at stage.mjs line 70 column 585 is the assertion that every selected ID appears in reconciliation.reviewedVersionIds. Earlier gates passed: accepted 20 → EQA 21 → Leapmotor 22 → Mazda 23 composition; accepted Leapmotor car/field digests; 409 untouched Mazda peer cars; actual selected packs and 24-path portable parity; allCatalogueVersions=413, tierOneVersions=336, onSaleVersions=303; reconciliation registry valid and global C1 still open. No full-stage pass is implied.

## Independently verified cause

Both unchanged selected 6e records have facts.body_type.value = `five-door hatchback`. Reconciliation v1 currentVersionReviews[0].bodyStyle is `Hatchback`. The actual m1-reconciliation.ts exact normalized identity guard compares this field and rejects both 6e records; normalization does not discard five-door. CX-6e body facts are absent, so this mismatch does not apply to them. This is a reconciliation wording mismatch, not stale source eligibility or a failed CX preorder gate.

## Narrow correction and bounded diagnostic readiness

Reconciliation v2 has exactly one JSON field change: currentVersionReviews[0].bodyStyle from `Hatchback` to `five-door hatchback`. File `/tmp/mazda-packet/reconciliation-v2/m1-mazda-market-reconciliation-2026-10-15.json`, SHA256 `8cbb5d269f6914192ae6427166bc34517b9a9e6347c13413b2a5dd63e883b69c`. All catalogue data, core packet, matching code, and full-stage assertions remain unchanged.

Selected-four diagnostic script `/tmp/mazda-staging/c1-diagnostic-v1/check.mjs`, SHA256 `1346345267f45bb63f87bfd20e4c670872e49d7d724572d2560975104a98dc37`; manifest SHA256 `a0dc5a169c8d9a6c6b1c6bbfb538658fc6c76061fdd77502240d116c461026af`. All 44 input pins checked exact. It requires actual old reconciliation to reject 6e, corrected reconciliation to include all four IDs and two valid reviews, both inventory dispositions, and only independent_lists unresolved. It checks selected report has two on-sale, zero unreviewed core grades, zero missing summaries, and no production loaders. Root conditionally granted this exact 256/1, 180-second plus 10-second grace, wait4-supervised diagnostic with no retry; reviewer cleared its execution by author. Results remain pending at this note creation.
