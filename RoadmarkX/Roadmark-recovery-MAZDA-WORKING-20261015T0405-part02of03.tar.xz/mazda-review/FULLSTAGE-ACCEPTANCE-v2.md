# Mazda full-stage v2 output acceptance

Accepted the complete derived stage for the narrow registration review; no production validation or publication is implied.

## Exact evidence

- Manifest: `/tmp/mazda-staging/full-v2/manifest.json`, SHA256 `83c895339ac7254b0aaf0422e8a3d8a30070fc8bc85c2c08ca727399b46e1677`
- Stage receipt: `/tmp/mazda-staging/full-v2/output/stage-receipt.json`, SHA256 `5b9511497c4ab83afc0605d846c8a2f47968d5d35af2bea4540651ba421c81b0`
- Terminal: `/tmp/mazda-staging/full-v2/run/terminal.json`, SHA256 `2e9ef4461be5d5d3914306594144f59db76d1b86d29cacf53c9a130c2ede7a76`
- Full actual report: `/tmp/mazda-staging/full-v2/output/staged-report.json`, SHA256 `f6d52d701b71bea682e586ad168d166c7f180430fab0d843297cbbf99d81fb02`

Exit 0, 212.612 seconds, peak RSS 587,988 KiB; empty stderr. Terminal stdout/stderr hashes independently verified. All eleven output artifact hashes and sizes verified. Reviewer did not rerun the stage or invoke runtime consumers.

## Independent output checks

1. Accepted baseline20 and corrected21 car digests exactly equal prior accepted Leapmotor provenance. Current22 car digests and all fourteen research-field digests exactly equal accepted Leapmotor candidate22.
2. Transition20→21 changes only the expected Mercedes EQA ID; 21→22 adds the four previously accepted Leapmotor IDs and updates its six retained grades. No early added-version packet replay.
3. Mazda22→23 adds/removes no ID, changes exactly four selected Mazda cars and preserves all 409 other car digests. Only metadata, variants and sources research fields differ; other eleven fields match exactly.
4. Each raw invocation metadata is retained. Explicit composition changes only metadata.brand_update_packet_ids; prefix lengths are21,22,23.
5. All four selected after cars, actual packs and portable packs are byte-identical to the passed selected preflight files. Eighty fact/term claims and276 feature claims were verified by the actual stage.
6. All24 serialized omissions exactly match both preflight retained-before and selected-after witnesses after removing phase/explicit-match marker:16 gradeReviewStatus,4 condition_label,4 novated_fbt confirmation_needed. No blanket undefined allowance.
7. Actual report counts413 catalogue,336 Tier1,303 on-sale. All four selected IDs appear in reviewedVersionIds, both Mazda model reviews are valid, registryValid=true, independentListCount=0, reconciliation.pass=false. Mazda has2 on-sale, all17 core fields filled and reviewed, zero core gaps/unreviewed grades/missing summaries. C2/C3/C4/C6 pass; C1 remains open for independent whole-market lists and C5 cargo/towing rankings remain held. Residual MX-30 unresolved remains explicit in reconciliation notes, not claimed absent or closed.

The first full-stage run remains a retained failure with a separately proven reconciliation wording correction; it is not rewritten as success. Full TypeScript runs remain explicit OOM, not passes. No current hero, production registration, fresh canonical recapture or publishing occurred in staging.
