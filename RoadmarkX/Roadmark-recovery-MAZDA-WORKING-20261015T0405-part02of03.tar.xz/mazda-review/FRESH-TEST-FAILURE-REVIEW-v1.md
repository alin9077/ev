# Mazda fresh relevant-test failure review

Status: sequence failed, not accepted as a complete test pass. Original receipts retained. No test/source edits or execution by reviewer.

Actual run terminal: `/workspace/scratch/586427eef9f2/roadmark-104-qa/mazda-sequential-checks/relevant-behavioral-tests/terminal.json`. Exit1,379.215 seconds, peak RSS826,824KiB.232 tests,229 pass,3 fail. Empty stderr. New four-group preorder behavior tests pass, but that does not turn the whole relevant run into a pass.

## 1. Mazda CX-6e cargo assertion is stale

`tests/brand-live-safety.test.ts:195` expects boot_l.value=null; actual363. The accepted Mazda packet/display rule deliberately shows source-labelled363L VDA with seats-up/parcel-shelf or seatback/underfloor basis, Check grade, both brochure363 and webpage468 evidence, specific unresolved conflict issue and ranking hold. Both unchanged auxiliary source_brochure_boot_l363 and source_model_page_boot_l468 observations remain. This is the labelled-number policy, not loss of the occupied-seat/roof measurement boundary. Suggested updated behavioral assertions must preserve all of these boundaries and independently invoke actual ranking exclusion on a hypothetical current CX-6e car, preventing preorder exclusion from hiding a missing cargo conflict hold. Existing EV9/Volvo/Polestar cargo assertions should remain untouched.

## 2. Toyota null assertions predate accepted Toyota M1 evidence

`tests/brand-live-safety.test.ts:215` expects bZ4X2WD towing_braked_kg=null; actual750. Toyota is one of409 unchanged peers in the accepted Mazda stage. The accepted Toyota14October packet explicitly replaces this with750kg Reported from an exact FWD CarExpert entry, empty comparisonBasis, while retaining original maker-unclassified750 observation. It is not a maker-unclassified figure relabelled Confirmed. The next assertion expecting dc_charge_time_min=null is also stale against the same accepted Toyota overlay:28min Check, retained28/30/45 primary-source discrepancy, empty comparison basis. A test-only update should assert separate measurement attribution, Reported grade and no rank for towing, plus Check/conflict wording/no rank for charging. Lexus pack/cell voltage and tyre radius/diameter checks should remain unchanged. This review establishes consistency with the previously accepted overlay and untouched-peer proof, not a new Toyota source research pass.

## 3. Buyer availability file failure remains unexplained

`tests/buyer-availability-scope.test.ts` failed as a file after40.7s, with only “test failed” and no named subtest output. Captured stdout/stderr do not establish a signal, OOM or a specific assertion. It imports and initializes the full catalogue at module scope, but that alone is not cause evidence. A separately granted diagnostic must preserve structured runner failure details before any recovery claim. No automatic retry or inferred OOM diagnosis.

Fresh normal coverage remains byte/deep identical to the accepted stage; its success does not waive these test failures. Section8 draftv2 now reports229passes/3failures and lint not run.
