from pathlib import Path
O=Path('/tmp/cupra-packet/full-stage-v1');k=Path('/tmp/kgm-packet/full-stage-v1/stage.mjs').read_text();s=Path('/tmp/cupra-packet/selected-preflight-v1/check.mjs').read_text()
prefix=k[:k.index('const base=data,currentCars=cars')]
prefix=prefix.replace('KGM28 bounded full-stage draft','CUPRA29 bounded full-stage draft').replace('derived-prefix20-through-MINI27-then-KGM28-no-broad-features','derived-prefix20-through-KGM28-then-CUPRA29-no-broad-features').replace('assert.equal(brandUpdatePackets.length,27)','assert.equal(brandUpdatePackets.length,28)').replace("brandUpdatePackets.at(-1).id,'m1-mini-2026-10-15'","brandUpdatePackets.at(-1).id,'m1-kgm-2026-10-15'").replace('m.acceptedMiniCars.path','m.acceptedKgmCars.path').replace('m.acceptedMiniFields.path','m.acceptedKgmFields.path').replace("[26,'candidate27',427]","[26,'candidate27',427],[27,'candidate28',427]")
addition=r'''
const material='/tmp/cupra-packet/typed-preparation-v4';
const base=data,currentCars=cars,currentFields=fieldStages.candidate28,currentDigests=carStages.candidate28;
const packetPath=m.packet.path,packet=readJson(packetPath),packetSnapshot=structuredClone(packet);
assert.equal(fileHash(packetPath),'24092e919c384e1bf3a8e85eeed360de39405d7ea58b46b2c79bca4d2f2e794a');assert.equal(packet.id,'m1-cupra-2026-10-15');
const selected=new Set(m.selectedIds),before=currentCars.filter(car=>selected.has(car.id)),beforeSnapshot=structuredClone(before);
assert.equal(selected.size,3);assert.deepEqual(before,[]);assert.deepEqual(before,readJson(m.selectedBefore.path));assert(!currentCars.some(car=>car.brand.toUpperCase()==='CUPRA'));
for(const prior of brandUpdatePackets){assert.notEqual(prior.brand.toUpperCase(),'CUPRA');for(const row of [...prior.facts,...prior.variants,...prior.versionGuards,...prior.availability,...prior.summaries,...(prior.features??[]),...(prior.configurationUpdates??[])])assert(!selected.has(row.variantId??row.id));for(const term of prior.brandTerms??[])assert(term.applicableVariantIds.every(id=>!selected.has(id)));}
const peerCars=currentCars,peerIds=new Set(peerCars.map(car=>car.id));assert.equal(peerCars.length,427);
const sourceIdsAdded=new Set(packet.sources.map(source=>source.id));assert.equal(sourceIdsAdded.size,16);assert.equal(packet.sources.length,16);assert.equal(packet.facts.length,45);assert.equal(packet.models.length,1);assert.equal(packet.variants.length,3);
const sourceReferenceProof=[];
function inspectSourceReferences(value,label,pointer=''){if(typeof value==='string'){assert(!sourceIdsAdded.has(value),'New source already referenced '+label+pointer);return;}if(!value||typeof value!=='object')return;for(const [key,item]of Object.entries(value)){assert(!sourceIdsAdded.has(key),'New source already a dictionary key '+label+pointer);inspectSourceReferences(item,label,pointer+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));}}
for(const [label,value]of [['accepted complete research',base],['accepted complete cars',currentCars],['accepted packets',brandUpdatePackets]]){inspectSourceReferences(value,label);sourceReferenceProof.push({input:label,newSourceReferences:0,nestedGradeReviewsAndKeysIncluded:true});}
for(const pin of m.rawOverlayInputs){inspectSourceReferences(require(pin.path),pin.path);sourceReferenceProof.push({input:pin.path,sha256:pin.sha256,newSourceReferences:0,nestedGradeReviewsAndKeysIncluded:true});}
write('source-reference-neutrality',{peerCars:427,helperChanges:false,sourceRowsAdded:16,inspections:sourceReferenceProof,broadFeatureReplay:false});
data=compose(base,packet,[...m.registeredPacketIds,packet.id]);cars=applyBrandUpdates(currentCars,data,[packet]);
assertDeclaredJson(data,'/candidateResearchBeforeDigest',new Set());assertDeclaredJson(cars,'/candidateCarsBeforeDigest',new Set());
const candidateFields=fieldDigests(data),candidateDigests=carDigests(cars),after=cars.filter(car=>selected.has(car.id)),afterSnapshot=structuredClone(after);
assert.equal(cars.length,430);assert.equal(data.variants.length,430);assert.equal(after.length,3);assert.deepEqual(after,readJson(m.selectedAfter.path));
fullResearchExact(base,currentFields,'baseResearch');fullCarsExact(currentCars,currentDigests,'currentCars');
const addedRows={models:1,variants:3,sources:16,trim_equipment:3,feature_evidence:207,update_eligibility:3,feature_evidence_variant_context:3};
for(const key of Object.keys(base)){
 if(key==='metadata')continue;
 if(Object.hasOwn(addedRows,key)){assert.deepEqual(data[key].slice(0,base[key].length),base[key]);assert.equal(data[key].length,base[key].length+addedRows[key]);}
 else assert.deepEqual(data[key],base[key]);
}
const expectedMetadata={...base.metadata,added_variant_count:Number(base.metadata.added_variant_count??0)+3,added_feature_row_count:Number(base.metadata.added_feature_row_count??0)+207,brand_update_packet_ids:[...m.registeredPacketIds,packet.id]};assert.deepEqual(data.metadata,expectedMetadata);
assert.deepEqual(data.models.at(-1),packet.models[0]);assert.deepEqual(data.variants.slice(base.variants.length).map(v=>v.id),packet.variants.map(v=>v.id));
assert(data.feature_evidence.slice(base.feature_evidence.length).every(row=>selected.has(row.variant_id)));assert.equal(new Set(data.feature_evidence.slice(base.feature_evidence.length).map(row=>row.variant_id+'\0'+row.criterion)).size,207);
assert.deepEqual(cars.slice(0,currentCars.length),currentCars);assert.deepEqual(candidateDigests.slice(0,currentCars.length),currentDigests);assert.deepEqual(data.variants.slice(0,base.variants.length),base.variants);
const unchangedPeers=427,reads=Object.entries(currentFields).map(([field,ref])=>({field,inputRows:ref.rows,retainedRows:ref.rows,sha256:ref.sha256,scope:'full accepted research structural composition; only three newly added feature packs replayed'}));
const contextComposition=transitions.map(row=>({packetId:row.packetId,scope:'Actual full retained research composition, metadata packet-list composition only'}));
for(const row of packet.facts){assert.equal(row.before,null);assert.deepEqual(after.find(c=>c.id===row.variantId).facts[row.after.key],row.after);}
for(const term of packet.brandTerms)for(const id of term.applicableVariantIds){assert.equal(term.before[id],null);assert.deepEqual(after.find(c=>c.id===id).facts[term.key],term.fact);}
const generated=readJson(material+'/output/builder-guard-provenance.json').generatedAvailabilityBefore;
for(const edit of packet.availability){assert.deepEqual(edit.before,generated.find(row=>row.variantId===edit.variantId).before);const car=after.find(c=>c.id===edit.variantId);assert.deepEqual({availability:car.availability,evidence:car.availabilityEvidence},edit.after);}
for(const row of packet.summaries){const car=after.find(c=>c.id===row.variantId);for(const side of ['strength','tradeoff']){assert.equal(car.buyerSummary[side].text,row[side].text);for(const dep of row[side].dependencies){assert.deepEqual(car.facts[dep.key],dep.expected);assert.notEqual(dep.expected.value,null);assert.equal(dep.expected.issues.length,0);}const ids=[...new Set(row[side].dependencies.flatMap(d=>d.expected.sourceIds))];assert.deepEqual(car.buyerSummary[side].sourceIds,ids);}assert.deepEqual(car.buyerSummary.conditions,row.conditions??[]);}
progress('CUPRA29 added with all 427 peers and exact append-only research fields proved');
'''
selected=s[s.index('const {compiledSource,elementNodes}'):]
selected=selected.replace('const {isOnSale,isCurrentListEligible,buildCoverageReport}','const {isOnSale,isCurrentListEligible,isTierOne,buildCoverageReport}')
selected=selected.replace('assert.deepEqual(base,baseSnapshot);','fullResearchExact(base,currentFields,\'baseResearch\');').replace('assert.deepEqual(data,dataSnapshot);','fullResearchExact(data,candidateFields,\'candidateResearch\');')
selected=selected[:selected.index("console.log(JSON.stringify({status:result.status")]
bridge=r'''
progress('Three selected packs, 54 fact claims, 207 feature claims and recall/citable/portable ownership proved');
const acceptedSelected=readJson(m.selectedResult.path);assert.equal(acceptedSelected.status,'selected_actual_consumers_and_exact_serialization_witness_pass');assert.equal(acceptedSelected.packetSha256,m.packet.sha256);
for(const [name,pin]of Object.entries(m.selectedArtifacts))assert.equal(fileHash(out+'/'+name),pin.sha256,'Exact selected written artifact '+name);
const acceptedWrittenPacks=readJson(m.selectedArtifacts['selected-packs.json'].path);
const acceptedWrittenClaims=readJson(m.selectedArtifacts['claims.json'].path),acceptedWrittenFeatureClaims=readJson(m.selectedArtifacts['feature-claims.json'].path),acceptedAvailabilityClaims=readJson(m.selectedArtifacts['availability-claims.json'].path);
assert.deepEqual(claims,acceptedWrittenClaims.map(row=>({variantId:row.variantId,key:row.key,claim:factClaim(acceptedWrittenPacks[row.variantId],acceptedWrittenPacks[row.variantId].car.facts[row.key],m.asOf)})));
assert.deepEqual(featureClaims,acceptedWrittenFeatureClaims.map(row=>({variantId:row.variantId,criterion:row.criterion,claim:featureClaim(acceptedWrittenPacks[row.variantId],row.criterion,row.criterion,m.asOf)})));
assert.deepEqual(availabilityClaims,acceptedAvailabilityClaims.map(row=>({variantId:row.variantId,claim:factClaim(acceptedWrittenPacks[row.variantId],availabilityReportClaim(acceptedWrittenPacks[row.variantId].car),m.asOf)})));
assert.deepEqual(observations,acceptedSelected.optionalFeaturePaths);assert.deepEqual(claimOmissions,acceptedSelected.optionalCitationPaths);assert.deepEqual(readJson(out+'/result.json').selectedCoverage,acceptedSelected.selectedCoverage);
const policy={asOf:m.asOf};
'''
ranking=k[k.index('// Full structural ranking comparison:'):k.index('// Actual global C1 only:')]
ranking=ranking.replace('new Set(expected.rankingIds[attribute.key])','new Set()')
globalblock=r'''
// Actual global C1 only: mirror current loader imports without running its full loader.
const actualPaths=[...fs.readFileSync(repo+'/scripts/reporting/load.ts','utf8').matchAll(/import \w+ from "(\.\.\/\.\.\/data\/m1-[^"]+\.json)";/g)].map(match=>path.resolve(repo+'/scripts/reporting',match[1]));assert.deepEqual(actualPaths,m.reconciliationInputs.map(pin=>pin.path));assert.equal(actualPaths.length,28);
const {combineM1Reconciliations,inventoryRecordId}=require('./scripts/reporting/m1-reconciliation.ts');
const baseReconciliation=combineM1Reconciliations(...m.reconciliationInputs.map(pin=>require(pin.path)));
const baselineC1=buildMarketReconciliation(baseReconciliation,currentCars.filter(isTierOne).filter(car=>isCurrentListEligible(car,base.sources,m.asOf)),allInventory,m.asOf);
const acceptedStageGlobal=readJson(m.acceptedKgmC1.path).after,acceptedReport=readJson(m.acceptedNormalReport.path),normalTerminal=readJson(m.acceptedNormalTerminal.path);assert.equal(normalTerminal.exitCode,0);assert.equal(normalTerminal.stdoutSha256,m.acceptedNormalReport.sha256);
const fixtureRegistry={schemaVersion:1,checkedAt:m.asOf,publishedLists:[],currentVersionReviews:[],listResolutions:[],inventoryResolutions:[],catalogueOnlyDifferences:[]},fixtureInventory={records:[],unverifiedLeads:[]};
const fixture=buildMarketReconciliation(fixtureRegistry,[],fixtureInventory,m.asOf);assert.deepEqual(fixture.issues.map(issue=>issue.code),['independent_lists','empty_catalogue']);
const producedIssue=fixture.issues[0],issueOwnership=[];assert.deepEqual(Object.keys(producedIssue).sort(),['brand','code','reason','reference']);
for(const property of ['brand','reference']){const descriptor=Object.getOwnPropertyDescriptor(producedIssue,property);assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value'));assert.equal(descriptor.value,undefined);issueOwnership.push({property,ownUndefined:true,enumerable:true,producer:'Actual buildMarketReconciliation fixture add(code,reason)'});}
function c1Written(live,label){const snapshot=structuredClone(live),clone=structuredClone(live),indices=live.issues.map((issue,index)=>issue.code==='independent_lists'?index:-1).filter(index=>index>=0);assert.equal(indices.length,1);const index=indices[0],issue=live.issues[index];assert.deepEqual(issue,producedIssue);const allowed=new Set();for(const property of ['brand','reference']){assert.deepEqual(Object.getOwnPropertyDescriptor(issue,property),Object.getOwnPropertyDescriptor(producedIssue,property));allowed.add('/'+label+'/issues/'+index+'/'+property);delete clone.issues[index][property];}assertDeclaredJson(live,'/'+label,allowed);assert.deepEqual(JSON.parse(JSON.stringify(live)),clone);assert.deepEqual(live,snapshot);return clone;}
const baselineWritten=c1Written(baselineC1,'baselineC1');assert.deepEqual(baselineWritten,acceptedStageGlobal);assert.deepEqual(baselineWritten,acceptedReport.reconciliation);
const expectedLive=structuredClone(acceptedStageGlobal),independentIndex=expectedLive.issues.findIndex(issue=>issue.code==='independent_lists');expectedLive.issues[independentIndex]=producedIssue;assert.deepEqual(baselineC1,expectedLive);
const proposedReconciliation=combineM1Reconciliations(baseReconciliation,reconciliation),globalC1=buildMarketReconciliation(proposedReconciliation,cars.filter(isTierOne).filter(car=>isCurrentListEligible(car,data.sources,m.asOf)),allInventory,m.asOf);
assert.equal(baselineC1.reviewedModels,103);assert.equal(baselineC1.reviewedVersions,234);assert.equal(globalC1.reviewedModels,103);assert.equal(globalC1.reviewedVersions,234);assert.equal(globalC1.registryValid,true);assert.equal(globalC1.pass,false);
assert.deepEqual(globalC1.reviewedVersionIds,baselineC1.reviewedVersionIds);assert.deepEqual(globalC1.validModelReviewIds,baselineC1.validModelReviewIds);
const nonCupraIssue=issue=>!isCupra(issue.brand)&&!selected.has(issue.reference)&&!['record:cupra-tavascan','lead:cupra-born'].includes(issue.reference);assert.deepEqual(globalC1.issues.filter(nonCupraIssue),baselineC1.issues.filter(nonCupraIssue));
assert.deepEqual(baselineC1.issues.filter(issue=>!nonCupraIssue(issue)).map(issue=>issue.reference),['record:cupra-tavascan','lead:cupra-born']);
assert.deepEqual(globalC1.issues.filter(issue=>!nonCupraIssue(issue)).map(issue=>issue.reference),[...selected,'record:cupra-tavascan']);
assert.deepEqual(cars.slice(0,427).map(car=>car.id),currentCars.map(car=>car.id));assert.equal(cars.length,430);assert.equal(cars.filter(isTierOne).length,353);assert.equal(cars.filter(isTierOne).filter(isOnSale).length,312);
assert.equal(currentCars.filter(isTierOne).length,350);assert.equal(currentCars.filter(isTierOne).filter(isOnSale).length,309);
const expectedGlobalEvidence=structuredClone(baselineWritten.evidence);assert.deepEqual(Object.keys(expectedGlobalEvidence).sort(),Object.keys(reconciliation).sort());expectedGlobalEvidence.checkedAt=[baselineWritten.evidence.checkedAt,reconciliation.checkedAt].sort().at(-1);
for(const key of ['notes','publishedLists','currentVersionReviews','listResolutions','catalogueOnlyDifferences','inventoryResolutions'])expectedGlobalEvidence[key]=[...baselineWritten.evidence[key],...reconciliation[key]];
assert.deepEqual(proposedReconciliation,expectedGlobalEvidence);
assert.deepEqual(new Set(baselineWritten.issues.map(issue=>issue.code)),new Set(['independent_lists','version_unreviewed','inventory_unresolved']));
const expectedNewIssues=packet.variants.map(variant=>({code:'version_unreviewed',reason:`${variant.model} ${variant.trim}: current version-list membership has not been settled`,brand:'CUPRA',reference:variant.id}));
const expectedIssues=[...baselineWritten.issues.filter(issue=>issue.code==='independent_lists'),...baselineWritten.issues.filter(issue=>issue.code==='version_unreviewed'),...expectedNewIssues,...baselineWritten.issues.filter(issue=>issue.code==='inventory_unresolved'&&issue.reference!=='lead:cupra-born')];
const originalInventoryOrder=[...allInventory.records.filter(record=>!record.vehicleClass||['passenger','ute'].includes(record.vehicleClass)).map(record=>'record:'+inventoryRecordId(record)),...allInventory.unverifiedLeads.filter(record=>!record.vehicleClass||['passenger','ute'].includes(record.vehicleClass)).map(record=>'lead:'+inventoryRecordId(record))];
const allExpectedSettlements=new Set([...baselineWritten.settledInventory,'lead:cupra-born']);
const expectedGlobalWritten={...structuredClone(baselineWritten),registryCheckedAt:expectedGlobalEvidence.checkedAt,settledInventory:originalInventoryOrder.filter(id=>allExpectedSettlements.has(id)),issues:expectedIssues,evidence:expectedGlobalEvidence};
assert.equal(expectedGlobalWritten.settledInventory.length,baselineWritten.settledInventory.length+1);assert.equal(expectedGlobalWritten.issues.length,baselineWritten.issues.length+2);
const globalWritten=c1Written(globalC1,'globalC1');assert.deepEqual(globalWritten,expectedGlobalWritten,'Complete proposed C1 equality, all counters, exact issue order and evidence arrays');
write('baseline-global-c1',baselineC1);write('global-c1-comparison',{before:baselineWritten,after:globalWritten,expectedCompleteAfter:expectedGlobalWritten,completeExpectedWrittenEquality:true,baselineMatchesAcceptedKgmAndNormal:true,nonCupraIssuesReviewsDispositionsExact:true,issueOwnership,normalFullReportRun:false});
progress('Global compatible-group rankings and complete expected C1 gaps proved without broad features');
fullResearchExact(base,currentFields,'baseResearch');fullCarsExact(currentCars,currentDigests,'currentCars');fullResearchExact(data,candidateFields,'candidateResearch');fullCarsExact(cars,candidateDigests,'candidateCars');assert.deepEqual(before,beforeSnapshot);assert.deepEqual(after,afterSnapshot);assert.deepEqual(packet,packetSnapshot);assert.deepEqual(packs,snapshot);assert.equal(defaultCalls,0);
for(const file of ['src/lib/data.ts','src/lib/catalogue.ts','src/lib/research.ts','scripts/reporting/load.ts'])assert(!require.cache[repo+'/'+file]);checkPins();
write('metadata-composition',transitions);write('car-digest-comparison',{...carStages,candidate29:candidateDigests});write('research-field-digests',{...fieldStages,candidate29:candidateFields});
write('stage-receipt',{status:'bounded_structural_selected_stage_pass_pending_independent_review',manifestSha256:args[3],packetSha256:m.packet.sha256,originalBaselineCars:409,acceptedCurrentCars:427,stagedCars:430,tierOneVersions:353,onSaleVersions:312,untouchedPeerCars:427,newModels:1,newVersions:3,versionUpdates:0,configurationUpdates:0,manualFeatureUpdates:0,sourceRowsAdded:16,allAcceptedStagesThroughKgm28ExactlyReproduced:true,all14ResearchFieldsProved:true,strictJsonShapeBeforeDigest:true,all21RetainedStorageFilesPinnedBeforeAndAfter:true,completeGlobalC1ExpectedEquality:true,actualSelectedCars:3,actualFactAndTermClaims:earnedCells,actualFeatureClaims:featureClaims.length,roadsideCanonicalProjections:3,generatedFeatureRows:207,actualOptionalWitnessesExact:true,inMemoryPortableExact:true,writtenPortableExact:true,writtenClaimReadback:true,recallDisclosureAndGovernmentCitationProved:true,hydratedFootnoteInteractionTested:false,selectedC1:c1Written(c1,'selectedC1'),globalC1Counts:{reviewedModels:globalC1.reviewedModels,reviewedVersions:globalC1.reviewedVersions,pass:globalC1.pass},sourceAdditionsDoNotReviveAcceptedReferences:true,allPeerDigestsAndIdentitiesExact:true,peerOrderExactWithinCompatibleRankingGroups:true,productionGroupSortingAndInsertionTieProvenance:true,broadFeatureReplay:false,normalFullReportRun:false,normalFullReportRequiredAfterGuardedIntegration:true,defaultLoaderCalls:defaultCalls,liveSourceEdits:false,productionRegistration:false,currentProjectTypeScript:'UNPASSED; no compiler retry',resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log(JSON.stringify({status:'passed',receipt:out+'/stage-receipt.json',sha256:fileHash(out+'/stage-receipt.json'),noBroadFeatureReplay:true}));
'''
with (O/'stage.mjs').open('x') as f:f.write(prefix+addition+selected+bridge+ranking+globalblock)
# Existing accepted 448/1 MiB, 420 s supervisor; only action name changes.
with (O/'run.py').open('x') as f:f.write(Path('/tmp/kgm-packet/full-stage-v1/run.py').read_text().replace('run_single_bounded_kgm_full_stage','run_single_bounded_cupra_full_stage'))
with (O/'storage-read-closure.json').open('xb') as f:f.write(Path('/tmp/kgm-packet/full-stage-v1/storage-read-closure.json').read_bytes())
