# CUPRA29 bounded full-stage plan

Prepared only. No execution, registration, compiler retry or normal report is authorized by this file.

## Accepted inputs

- Source/admission v3 and typed candidate v1 remain unchanged. Candidate SHA-256: `24092e919c384e1bf3a8e85eeed360de39405d7ea58b46b2c79bca4d2f2e794a`.
- Selected actual-consumer result SHA-256: `6f9e9acffc44e4e975b3e1135b1616e8393f31e01faf86be682085ed58c94335`, independently accepted. Exactly three additions from the preserved zero-row CUPRA baseline, 45 specific and nine shared-term cells, 207 features, 54 fact/term claims and three availability claims. Core grades: 43 Reported, six Confirmed, two Not published; roadside adds three Confirmed cells.
- Selected live/portable/written/hydrated equality is already accepted. Its producer-owned optional witnesses are three feature paths, 256 citation paths and six report paths. The full stage must reproduce those exact artifacts and observations without treating written JSON as a complete live object.
- Current accepted production is KGM28: 427 catalogue, 350 Tier 1, 309 on-sale Tier 1. TypeScript remains UNPASSED after two earlier unknown-cause SIGKILL terminations; this stage does not attempt a compiler.

## Single bounded computation

Restore the accepted retained 409-row/prefix-20 canonical storage once. All 21 actual retained storage files, its locator, the accepted anchor manifest, and all 14 research fields are pinned. Reproduce each complete-car and full research-field digest for EQA21, Leapmotor22, Mazda23, Skoda24, Audi25, Deepal26, MINI27 and KGM28. The only research composition adjustment is the actual packet-ID list in metadata; its actual producer input/output is recorded.

Apply the unchanged CUPRA packet through the real prepareBrandResearch/applyBrandUpdates producers. It adds one Tavascan model and three distinct MY26 variants. The genuine new-car producer validates null before guards; no baseline Car is manually fabricated. Availability guards must equal the accepted actual-builder-generated snapshots.

The exact structural change is append-only:

- models +1; variants +3; sources +16
- trim equipment +3; raw feature rows +207; update eligibility +3; historical feature context +3
- metadata added_variant_count +3, added_feature_row_count +207, and packet-ID list append
- every other research value and every existing research prefix remains exact
- all 427 existing complete cars and variants remain exact, in their original order

Expected counts, asserted through actual eligibility helpers, are 430 catalogue / 353 Tier 1 / 312 on-sale Tier 1. On-sale is advertised current-release/listing evidence with Reported availability interpretation. Factory-order acceptance, physical dealer stock, new-versus-demonstrator condition and individual delivery remain unverified.

No broad effective-feature replay is allowed. Replay only the three new packs through the real global issue/source context, effective-feature producer, audit/regrading and brand-term projection. Preserve their 207 source-effective feature claims, 54 graded fact/term claims, summary dependencies, availability evidence, source-labelled height and V/VZ towing alternatives, and all normalized ranking exclusions. The raw generated unknown rows are not substituted for the effective pipeline outputs.

## Recall display boundary

The actual Detail availability subtree must pass the full REC-006687 / 94S9 VIN-scoped advisory to the actual EvidenceConditions disclosure and the government source ID to FootnoteRefs. Saved actual disclosure HTML and citable Markdown must equal the selected accepted files and retain the government URL. The notice says affected drivers should not use advanced full beam assist until rectified, with a free dealer software update and actual VIN check; no candidate VIN is assumed affected or remedied. Hydrated footnote interaction is untested. No browser/server result is claimed.

## Global ranking and C1

Use actual global compatible ranking groups, their full exclusions and unranked entries. Preserve all peers' group membership and within-group order, and explicitly verify the production group comparator, insertion ties, value order and tie ranks. The new numeric facts are Reported or Not published, so no CUPRA version enters a normalized ranking group. Source-reference neutrality checks ensure the 16 new source IDs did not previously occur anywhere in accepted cars, research, prior packets or raw overlays.

Mirror the current reporting loader's 28 reconciliation imports without invoking that loader. Baseline global C1 must equal both accepted KGM28 stage output and the actual normal KGM report. Construct the complete expected post-CUPRA C1 value from that frozen baseline:

- append this exact reconciliation's notes and evidence arrays
- retain reviewed counts at 103 models / 234 versions, and retain all reviewed IDs
- add the three exact CUPRA version-unreviewed issues in their actual ordered position
- preserve the Tavascan unresolved inventory issue
- remove only the Born lead unresolved issue and add only that lead to settled inventory in the inherited inventory order
- keep all other issues, list counters and evidence unchanged; the total issue count rises by two

No complete official current MY26 model list is invented. The current maker landing and brochure remain 2025/MY25.5-scoped. The independent whole-market list requirement remains open. Old MY25.5 references, Born residual uncertainty and Raval's reported future arrival are preserved in source/admission evidence, without extra catalogue rows.

## Supervision and outputs

One root-authorized run only, with an exclusive heavy slot: Node v24.19.0; old space 448 MiB, semi-space 1 MiB, exposed GC, 420 seconds plus 10-second kill grace. Before/after checks cover every pinned input. Record raw wait status, exit code, elapsed time, peak RSS and stdout/stderr hashes. No automatic retry or inferred kill cause.

Save complete stage-by-stage car digests and 14-field research digests, selected packs/claims/portable and recall files, exact optional witnesses, source neutrality, full ranking structures, full expected global C1 comparison, metadata transitions and the stage receipt. Do not write complete production catalogue artifacts or change the live registry. A separately reviewed guarded integration and one later actual normal report remain necessary. Current TypeScript is still unpassed.
