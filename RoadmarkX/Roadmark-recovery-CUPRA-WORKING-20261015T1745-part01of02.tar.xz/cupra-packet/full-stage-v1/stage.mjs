/** CUPRA29 bounded full-stage draft: no broad effective-feature replay or normal report. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {fileHash,readJson,readResearch,digestRows,assertResearchUnchanged} from '/tmp/xpeng-staging-plan/baseline-io.mjs';
import {readCompleteCars} from '/tmp/mercedes-staging-plan/staging-preparation/shape-first-v3/read-complete-storage.mjs';
import {assertDeclaredJson} from '/tmp/mercedes-staging-plan/consumer-preparation/v5/feature-json-parity.mjs';
const args=process.argv.slice(2);assert.equal(args.length,4);assert.equal(args[0],'--manifest');assert.equal(args[2],'--manifest-sha256');assert.equal(fileHash(args[1]),args[3]);
const m=readJson(args[1]),repo=m.repo,out=m.output,pins=m.pins;
assert.equal(process.cwd(),repo);assert.equal(process.env.NODE_OPTIONS,undefined);assert.equal(typeof global.gc,'function');assert.equal(process.version,m.nodeVersion);assert.deepEqual(process.execArgv,m.execArgv);
assert.equal(m.mode,'derived-prefix20-through-KGM28-then-CUPRA29-no-broad-features');assert.equal(m.productionRegistrationAuthorized,false);assert.equal(m.canonicalRecaptureAuthorized,false);assert.equal(m.normalFullReportInStage,false);
function checkPins(){for(const p of pins){assert.equal(fs.statSync(p.path).size,p.bytes);assert.equal(fileHash(p.path),p.sha256,p.path);}}
checkPins();assert(!fs.existsSync(out));fs.mkdirSync(out);
function write(name,obj){fs.writeFileSync(out+'/'+name+'.json',JSON.stringify(obj,null,2)+'\n',{flag:'wx'});}
function progress(phase){const fd=fs.openSync(path.join(m.runOutput,'progress.jsonl'),'a');try{fs.writeSync(fd,JSON.stringify({at:new Date().toISOString(),phase})+'\n');fs.fsyncSync(fd);}finally{fs.closeSync(fd);}console.log(phase);}
const fieldDigests=data=>Object.fromEntries(Object.entries(data).map(([key,value])=>[key,digestRows(Array.isArray(value)?value:[value])])),carDigests=cars=>cars.map(car=>({id:car.id,...digestRows([car])}));
function fullResearchExact(data,expected,label){assertDeclaredJson(data,'/'+label,new Set());assert.deepStrictEqual(fieldDigests(data),expected);}
function fullCarsExact(cars,expected,label){assertDeclaredJson(cars,'/'+label,new Set());assert.deepStrictEqual(carDigests(cars),expected);}
progress('Restoring accepted retained409/prefix20 once');
const accepted=readJson(m.acceptedManifest.path),anchors=accepted.anchors,inputPins=new Map(accepted.inputPins.map(row=>[row.anchor+'\0'+row.file,row]));
const storageClosure=readJson(m.storageClosure.path),storagePins=new Map(storageClosure.map(pin=>[pin.path,pin])),storageReads=new Set();
assert.equal(storagePins.size,21);
const proof={anchors,assertPinned(ref){
 const pin=inputPins.get(ref.anchor+'\0'+ref.file);assert(pin);assert.equal(ref.sha256,pin.sha256);assert.equal(ref.bytes,pin.bytes);
 const absolute=path.resolve(anchors[ref.anchor],ref.file),terminalPin=storagePins.get(absolute);assert(terminalPin,'Actual retained input missing terminal pin '+absolute);
 assert.equal(terminalPin.sha256,ref.sha256);assert.equal(terminalPin.bytes,ref.bytes);assert(pins.some(pin=>pin.path===absolute&&pin.sha256===ref.sha256&&pin.bytes===ref.bytes));storageReads.add(absolute);
}};
let restored=await readCompleteCars(proof,m.storageIndex),cars=restored.cars;const index=restored.index;restored=null;
assert.equal(cars.length,409);for(const ref of Object.values(index.research))proof.assertPinned(ref);
let data=await readResearch(anchors,index,Object.keys(index.research));assert.equal(Object.keys(data).length,14);assertDeclaredJson(data,'/initialResearch',new Set());assertDeclaredJson(cars,'/initialCars',new Set());assertResearchUnchanged(data,index);assert.deepStrictEqual(data.variants.map(row=>row.id),cars.map(car=>car.id));
assert.deepStrictEqual([...storageReads].sort(),[...storagePins.keys()].sort());
write('retained-storage-read-closure',{actualReadFiles:[...storageReads].sort(),all21FilesPinnedBeforeAndAfter:true,rootStorageIndex:m.storageIndex,acceptedManifest:m.acceptedManifest});
const require=createRequire(repo+'/package.json'),brand=require('./src/lib/brand-updates.ts');
const {prepareBrandResearch,applyBrandUpdates,brandVersionSnapshot,applyBrandFeatureUpdates,applyBrandTermFeatures}=brand;
const {brandUpdatePackets}=require('./src/lib/brand-update-registry.ts');assert.equal(brandUpdatePackets.length,28);assert.deepStrictEqual(brandUpdatePackets.map(p=>p.id),m.registeredPacketIds);assert.equal(brandUpdatePackets.at(-1).id,'m1-kgm-2026-10-15');assert.deepStrictEqual(data.metadata.brand_update_packet_ids,m.registeredPacketIds.slice(0,20));
const acceptedCarStages=readJson(m.acceptedKgmCars.path),acceptedFieldStages=readJson(m.acceptedKgmFields.path),carStages={baseline20:carDigests(cars)},fieldStages={baseline20:fieldDigests(data)},transitions=[];
fullResearchExact(data,acceptedFieldStages.baseline20,'baseline20Research');fullCarsExact(cars,acceptedCarStages.baseline20,'baseline20Cars');
function compose(base,p,ids){const raw=prepareBrandResearch(base,[p]);assert.deepStrictEqual(Object.keys(raw),Object.keys(base));assert.deepStrictEqual(raw.metadata.brand_update_packet_ids,[p.id]);const result={...raw,metadata:{...raw.metadata,brand_update_packet_ids:ids}};for(const key of Object.keys(raw))if(key!=='metadata')assert.equal(result[key],raw[key]);transitions.push({packetId:p.id,beforeMetadata:digestRows([base.metadata]),rawMetadata:structuredClone(raw.metadata),composedMetadata:structuredClone(result.metadata),onlyCompositionPath:'metadata.brand_update_packet_ids'});return result;}
for(const [offset,stage,count]of [[20,'corrected21',409],[21,'current22',413],[22,'current23',413],[23,'current24',417],[24,'candidate25',427],[25,'candidate26',427],[26,'candidate27',427],[27,'candidate28',427]]){
 const packet=brandUpdatePackets[offset],priorData=data,priorCars=cars,priorFields=fieldDigests(data),priorDigests=carDigests(cars);
 data=compose(priorData,packet,m.registeredPacketIds.slice(0,offset+1));cars=applyBrandUpdates(priorCars,data,[packet]);assert.equal(cars.length,count);assert.equal(data.variants.length,count);assert.deepStrictEqual(data.variants.map(row=>row.id),cars.map(car=>car.id));
 fullResearchExact(priorData,priorFields,'priorResearch');fullCarsExact(priorCars,priorDigests,'priorCars');
 fullResearchExact(data,acceptedFieldStages[stage],stage+'Research');fullCarsExact(cars,acceptedCarStages[stage],stage+'Cars');
 carStages[stage]=carDigests(cars);fieldStages[stage]=fieldDigests(data);global.gc();progress('Accepted '+stage+' complete-car and all14-field digests reproduced');
}

const material='/tmp/cupra-packet/typed-preparation-v4';
const base=data,currentCars=cars,currentFields=fieldStages.candidate28,currentDigests=carStages.candidate28;
const packetPath=m.packet.path,packet=readJson(packetPath),packetSnapshot=structuredClone(packet);
assert.equal(fileHash(packetPath),'24092e919c384e1bf3a8e85eeed360de39405d7ea58b46b2c79bca4d2f2e794a');assert.equal(packet.id,'m1-cupra-2026-10-15');
const selected=new Set(m.selectedIds),before=currentCars.filter(car=>selected.has(car.id)),beforeSnapshot=structuredClone(before);
assert.equal(selected.size,3);assert.deepEqual(before,[]);assert.deepEqual(before,readJson(m.selectedBefore.path));assert(!currentCars.some(car=>car.brand.toUpperCase()==='CUPRA'));
for(const prior of brandUpdatePackets){assert.notEqual(prior.brand.toUpperCase(),'CUPRA');for(const row of [...prior.facts,...prior.variants,...prior.versionGuards,...prior.availability,...prior.summaries,...(prior.features??[]),...(prior.configurationUpdates??[])])assert(!selected.has(row.variantId??row.id));for(const term of prior.brandTerms??[])assert(term.applicableVariantIds.every(id=>!selected.has(id)));}
const peerCars=currentCars,peerIds=new Set(peerCars.map(car=>car.id));assert.equal(peerCars.length,427);
const sourceIdsAdded=new Set(packet.sources.map(source=>source.id));assert.equal(sourceIdsAdded.size,16);assert.equal(packet.sources.length,16);assert.equal(packet.facts.length,45);assert.equal(packet.models.length,1);assert.equal(packet.variants.length,3);
const sourceReferenceProof=[];
function inspectSourceReferences(value,label,pointer=''){if(typeof value==='string'){assert(!sourceIdsAdded.has(value),'New source already referenced '+label+pointer);return;}if(!value||typeof value!=='object')return;for(const [key,item]of Object.entries(value)){assert(!sourceIdsAdded.has(key),'New source already a dictionary key '+label+pointer);inspectSourceReferences(item,label,pointer+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));}}
for(const [label,value]of [['accepted complete research',base],['accepted complete cars',currentCars],['accepted packets',brandUpdatePackets]]){inspectSourceReferences(value,label);sourceReferenceProof.push({input:label,newSourceReferences:0,nestedGradeReviewsAndKeysIncluded:true});}
for(const pin of m.rawOverlayInputs){inspectSourceReferences(require(pin.path),pin.path);sourceReferenceProof.push({input:pin.path,sha256:pin.sha256,newSourceReferences:0,nestedGradeReviewsAndKeysIncluded:true});}
write('source-reference-neutrality',{peerCars:427,helperChanges:false,sourceRowsAdded:16,inspections:sourceReferenceProof,broadFeatureReplay:false});
data=compose(base,packet,[...m.registeredPacketIds,packet.id]);cars=applyBrandUpdates(currentCars,data,[packet]);
assertDeclaredJson(data,'/candidateResearchBeforeDigest',new Set());assertDeclaredJson(cars,'/candidateCarsBeforeDigest',new Set());
const candidateFields=fieldDigests(data),candidateDigests=carDigests(cars),after=cars.filter(car=>selected.has(car.id)),afterSnapshot=structuredClone(after);
assert.equal(cars.length,430);assert.equal(data.variants.length,430);assert.equal(after.length,3);assert.deepEqual(after,readJson(m.selectedAfter.path));
fullResearchExact(base,currentFields,'baseResearch');fullCarsExact(currentCars,currentDigests,'currentCars');
const addedRows={models:1,variants:3,sources:16,trim_equipment:3,feature_evidence:207,update_eligibility:3,feature_evidence_variant_context:3};
for(const key of Object.keys(base)){
 if(key==='metadata')continue;
 if(Object.hasOwn(addedRows,key)){assert.deepEqual(data[key].slice(0,base[key].length),base[key]);assert.equal(data[key].length,base[key].length+addedRows[key]);}
 else assert.deepEqual(data[key],base[key]);
}
const expectedMetadata={...base.metadata,added_variant_count:Number(base.metadata.added_variant_count??0)+3,added_feature_row_count:Number(base.metadata.added_feature_row_count??0)+207,brand_update_packet_ids:[...m.registeredPacketIds,packet.id]};assert.deepEqual(data.metadata,expectedMetadata);
assert.deepEqual(data.models.at(-1),packet.models[0]);assert.deepEqual(data.variants.slice(base.variants.length).map(v=>v.id),packet.variants.map(v=>v.id));
assert(data.feature_evidence.slice(base.feature_evidence.length).every(row=>selected.has(row.variant_id)));assert.equal(new Set(data.feature_evidence.slice(base.feature_evidence.length).map(row=>row.variant_id+'\0'+row.criterion)).size,207);
assert.deepEqual(cars.slice(0,currentCars.length),currentCars);assert.deepEqual(candidateDigests.slice(0,currentCars.length),currentDigests);assert.deepEqual(data.variants.slice(0,base.variants.length),base.variants);
const unchangedPeers=427,reads=Object.entries(currentFields).map(([field,ref])=>({field,inputRows:ref.rows,retainedRows:ref.rows,sha256:ref.sha256,scope:'full accepted research structural composition; only three newly added feature packs replayed'}));
const contextComposition=transitions.map(row=>({packetId:row.packetId,scope:'Actual full retained research composition, metadata packet-list composition only'}));
for(const row of packet.facts){assert.equal(row.before,null);assert.deepEqual(after.find(c=>c.id===row.variantId).facts[row.after.key],row.after);}
for(const term of packet.brandTerms)for(const id of term.applicableVariantIds){assert.equal(term.before[id],null);assert.deepEqual(after.find(c=>c.id===id).facts[term.key],term.fact);}
const generated=readJson(material+'/output/builder-guard-provenance.json').generatedAvailabilityBefore;
for(const edit of packet.availability){assert.deepEqual(edit.before,generated.find(row=>row.variantId===edit.variantId).before);const car=after.find(c=>c.id===edit.variantId);assert.deepEqual({availability:car.availability,evidence:car.availabilityEvidence},edit.after);}
for(const row of packet.summaries){const car=after.find(c=>c.id===row.variantId);for(const side of ['strength','tradeoff']){assert.equal(car.buyerSummary[side].text,row[side].text);for(const dep of row[side].dependencies){assert.deepEqual(car.facts[dep.key],dep.expected);assert.notEqual(dep.expected.value,null);assert.equal(dep.expected.issues.length,0);}const ids=[...new Set(row[side].dependencies.flatMap(d=>d.expected.sourceIds))];assert.deepEqual(car.buyerSummary[side].sourceIds,ids);}assert.deepEqual(car.buyerSummary.conditions,row.conditions??[]);}
progress('CUPRA29 added with all 427 peers and exact append-only research fields proved');
const {compiledSource,elementNodes}=require('./tests/helpers/compiled-source.ts');
let defaultCalls=0;const forbidden=()=>{defaultCalls++;throw new Error('FORBIDDEN_DEFAULT_CATALOGUE_LOADER');};
const consumer=compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets:[...brandUpdatePackets,packet]}}).createEvidenceConsumers({sourceResearch:forbidden,research:forbidden,catalogue:forbidden});
const {hasEarnedBuyerGrade}=require('./src/lib/evidence-grading.ts');
const {factClaim,featureClaim,makeReport,reportMarkdown}=require('./src/lib/citable.ts');
const {availabilityReportClaim}=require('./src/lib/availability-corrections.ts');
const {buyerAvailabilityText}=require('./src/lib/buyer-availability.ts');
const {isOnSale,isCurrentListEligible,isTierOne,buildCoverageReport}=require('./scripts/reporting/reports.ts');
const {auditedFeature}=require('./src/lib/launch-evidence.ts');
const {applyFeatureRegrading}=require('./src/lib/evidence-regrading.ts');
const {storePortablePacks,hydratePortablePacks}=require('./src/lib/portable-packs.ts');
const {exclusionReason,rankAttribute,attributes}=require('./src/lib/discovery.ts');
const packs={},observations=[],claims=[],featureClaims=[],claimOmissions=[],producerProofs=[],frames=new Map(),availabilityClaims=[];
for(const car of after){const input=consumer.sourceEffectiveFeatures(car,data),snap=structuredClone(input),regraded=applyFeatureRegrading(car,input,data.sources);assert.deepEqual(input,snap);const branded=applyBrandFeatureUpdates(car,regraded,data,[...brandUpdatePackets,packet]),projected=applyBrandTermFeatures(car,branded,data.sources);frames.set('after\0'+car.id,{input,regraded,branded,projected,research:data});producerProofs.push({variantId:car.id,producer:'Actual sourceEffectiveFeatures with retained global issues -> applyFeatureRegrading -> applyBrandFeatureUpdates -> applyBrandTermFeatures',inputRows:input.length,outputRows:projected.length,globalIssueIds:data.publication_issues.map(i=>i.issue_id),inputUnchanged:true});}
function observePack(car,pack,phase){
 const pointers=[];
 function visit(value,pointer){
  if(value===undefined){
   const match=pointer.match(/\/features\/(\d+)\/([^/]+)$/);assert(match,'Unexpected undefined outside feature: '+pointer);
   const rowIndex=Number(match[1]),property=match[2],feature=pack.features[rowIndex],descriptor=Object.getOwnPropertyDescriptor(feature,property);
   assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value')&&descriptor.value===undefined);
   const frame=frames.get(phase+'\0'+car.id),sourceRow=frame.input.find(f=>f.criterion===feature.criterion),regraded=frame.regraded.find(f=>f.criterion===feature.criterion),projected=frame.projected.find(f=>f.criterion===feature.criterion);
   assert(sourceRow&&regraded&&projected);assert.deepEqual(feature,projected);
   let producer;
   if(property==='gradeReviewStatus'){
    assert(feature.gradeReview);assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts earned retained-feature branch explicitly sets gradeReviewStatus undefined';
   }else if(property==='condition_label'){
    assert.equal(feature.buyerGrade,'check');assert(!Object.hasOwn(sourceRow,property)||sourceRow[property]===undefined);assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts Check branch retains source optional condition_label';
   }else if(property==='confirmation_needed'){
    assert.equal(feature.criterion,'novated_fbt');
    for(const row of [sourceRow,regraded]){const d=Object.getOwnPropertyDescriptor(row,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);}
    const raw=frame.research.feature_evidence.find(f=>f.variant_id===car.id&&f.criterion===feature.criterion);assert(raw);
    const snap=structuredClone(raw),audited=auditedFeature(raw);assert.deepEqual(raw,snap);
    const d=Object.getOwnPropertyDescriptor(audited,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);
    producer='launch-evidence.ts actual auditedFeature(raw exact novated_fbt row) creates confirmation_needed undefined';
   }else if(['buyerGrade','gradeReview'].includes(property)){
    assert.equal(feature.gradeReviewStatus,'review_required');assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts unmatched retained-feature branch withdraws optional review';
   }else assert.fail('Unclassified optional undefined: '+pointer);
   observations.push({phase,variantId:car.id,pointer,rowIndex,criterion:feature.criterion,property,ownUndefined:true,enumerable:true,producer,sourceProperty:{own:Object.hasOwn(sourceRow,property),valueKind:sourceRow[property]===undefined?'undefined':typeof sourceRow[property]},regradedProperty:{own:Object.hasOwn(regraded,property),valueKind:regraded[property]===undefined?'undefined':typeof regraded[property]},actualFinalProjectionMatched:true});
   pointers.push(pointer);return;
  }
  if(!value||typeof value!=='object')return;
  for(const key of Object.keys(value))visit(value[key],pointer+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));
 }
 visit(pack,'/packs/'+car.id);assertDeclaredJson(pack,'/packs/'+car.id,new Set(pointers));
}
function observeClaim(claim,pack,pointer,replay,record=true){
 assert.deepEqual(replay(),claim,'Actual citable producer replay must match');
 const clone=structuredClone(claim),pointers=[];
 function visit(value,path){
  if(value===undefined){
   const match=path.match(/\/sources\/(\d+)\/(limitation|checked)$/);assert(match,'Unclassified citable undefined: '+path);
   const i=Number(match[1]),key=match[2],citation=claim.sources[i],source=pack.sources.find(s=>s.id===citation.id);assert(source);
   const d=Object.getOwnPropertyDescriptor(citation,key);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);
   assert(!source[key==='limitation'?'access_limitation':'full_text_checked_date']);
   pointers.push(path);if(record)claimOmissions.push({pointer:path,sourceId:source.id,property:key,ownUndefined:true,enumerable:true,producer:'Actual citable.ts citations() falsey source-metadata branch; actual factClaim/featureClaim replay matches'});
   delete clone.sources[i][key];return;
  }
  if(!value||typeof value!=='object')return;
  for(const key of Object.keys(value))visit(value[key],path+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));
 }
 visit(claim,pointer);assertDeclaredJson(claim,pointer,new Set(pointers));assert.deepEqual(JSON.parse(JSON.stringify(claim)),clone);return clone;
}

const core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','length_mm','width_mm','height_mm','towing_braked_kg','zero_to_100_s','power_kw','drive','warranty','battery_warranty'];
let earnedCells=0,roadsideProjections=0;const gradeCounts={},rankingProof=[];
const recallId='m1-cupra-2026-10-15-government-recall-006687',recallUrl='https://www.vehiclerecalls.gov.au/recalls/rec-006687';
for(const car of after){
 const pack=consumer.pack(car.id,{data,cars:after});packs[car.id]=pack;assert.equal(pack.features.length,69);assert.equal(new Set(pack.features.map(f=>f.criterion)).size,69);observePack(car,pack,'after');
 const frame=frames.get('after\0'+car.id);assert.deepEqual(pack.features,frame.projected);
 for(const feature of pack.features){
  if(feature.criterion==='roadside_assistance'){const f=car.facts.roadside_assistance;assert.equal(feature.value,f.value);assert.equal(feature.buyerGrade,'confirmed');assert.equal(feature.status,'standard');assert.deepEqual(feature.source_ids,f.sourceIds);for(const q of f.qualifications)assert(feature.conditions.includes(q));roadsideProjections++;}
  else{assert.deepEqual(feature,frame.regraded.find(f=>f.criterion===feature.criterion));assert.equal(feature.status,'not_verified');assert.equal(feature.buyerGrade,undefined);}
  const claim=featureClaim(pack,feature.criterion,feature.criterion,packet.reviewedAt);assert(claim);observeClaim(claim,pack,'/feature-claims/'+featureClaims.length+'/claim',()=>featureClaim(pack,feature.criterion,feature.criterion,packet.reviewedAt));featureClaims.push({variantId:car.id,criterion:feature.criterion,claim});
 }
 for(const f of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===packet.id)){assert(hasEarnedBuyerGrade(f,data.sources,packet.reviewedAt));const claim=factClaim(pack,f,packet.reviewedAt);assert.equal(claim.buyerGrade,f.buyerGrade);assert.deepEqual(claim.sources.map(s=>s.id),f.sourceIds);if(f.buyerGrade==='not_published'){assert.equal(f.value,null);assert.equal(claim.value,'Not published');}observeClaim(claim,pack,'/claims/'+claims.length+'/claim',()=>factClaim(pack,f,packet.reviewedAt));claims.push({variantId:car.id,key:f.key,claim});earnedCells++;}
 for(const key of core){const f=car.facts[key];gradeCounts[f.buyerGrade]=(gradeCounts[f.buyerGrade]??0)+1;if(typeof f.value==='number'){const reason=exclusionReason(car,f,data.sources,{asOf:packet.reviewedAt});assert(reason);rankingProof.push({variantId:car.id,key,ranked:false,reason,grade:f.buyerGrade,basis:f.comparisonBasis});}}
 for(const key of ['height_mm',...(car.trim==='MY26 Endurance'?[]:['towing_braked_kg'])]){const f=car.facts[key],claim=factClaim(pack,f,packet.reviewedAt),visible=[claim.sentence,...claim.qualifications].join(' ');assert.equal(f.comparisonBasis,'');assert(f.issues.length);assert(visible.includes('RedBook')&&visible.includes('CarExpert'));if(key==='height_mm')assert(visible.includes('1598')&&visible.includes('1597'));else assert(visible.includes('1200')&&visible.includes(car.trim==='MY26 V'?'1000':'1800'));}
 assert.equal(buyerAvailabilityText(car),'On sale now');assert(isOnSale(car));assert(isCurrentListEligible(car,data.sources,packet.reviewedAt));assert.equal(car.availabilityEvidence.orderStatus,'listed_unconfirmed');assert.equal(car.availabilityEvidence.physicalStockVerified,false);assert.equal(car.availabilityEvidence.factoryOrderAcceptanceVerified,false);
 const av=availabilityReportClaim(car),claim=factClaim(pack,av,packet.reviewedAt);observeClaim(claim,pack,'/availability-claims/'+availabilityClaims.length+'/claim',()=>factClaim(pack,av,packet.reviewedAt));assert(claim.sources.some(s=>s.id===recallId&&s.url===recallUrl));assert(claim.qualifications.some(q=>q.includes('REC-006687')&&q.includes('should not use advanced full beam assist')&&q.includes('free dealer software update')));availabilityClaims.push({variantId:car.id,claim});
}
assert.equal(earnedCells,54);assert.equal(featureClaims.length,207);assert.equal(roadsideProjections,3);assert.deepEqual(gradeCounts,{reported:43,confirmed:6,not_published:2});
const rankCounts={};for(const attr of attributes){const result=rankAttribute(after,data.sources,attr.key,{asOf:packet.reviewedAt});assert.equal(result.groups.length,0);assert.equal(result.excluded.length,3);rankCounts[attr.key]=result;}
const reconciliation=readJson(material+'/cupra-market-reconciliation-v2.json');
const allInventory=require('./src/lib/market-inventory-data.ts').default,isCupra=s=>typeof s==='string'&&s.toUpperCase()==='CUPRA';
const inventory={...allInventory,records:allInventory.records.filter(r=>isCupra(r.brand)),unverifiedLeads:allInventory.unverifiedLeads.filter(r=>isCupra(r.brand))};
assert.deepEqual({records:inventory.records,unverifiedLeads:inventory.unverifiedLeads},readJson('/tmp/cupra-research/inherited-inventory-extract.json'));
const {buildMarketReconciliation}=require('./scripts/reporting/m1-reconciliation.ts');
const c1=buildMarketReconciliation(reconciliation,after,inventory,packet.reviewedAt);assert.equal(c1.pass,false);assert.equal(c1.reviewedModels,0);assert.equal(c1.reviewedVersions,0);assert.deepEqual(c1.reviewedVersionIds,[]);assert.deepEqual(c1.settledInventory,['lead:cupra-born']);
assert.deepEqual(c1.issues.map(i=>i.code),['independent_lists','version_unreviewed','version_unreviewed','version_unreviewed','inventory_unresolved']);
const selectedCoverage=buildCoverageReport({cars:after,sources:data.sources,features:Object.values(packs).flatMap(p=>p.features),inventory,m1Reconciliation:reconciliation},packet.reviewedAt);
assert.equal(selectedCoverage.allCatalogueVersions,3);assert.equal(selectedCoverage.tierOneVersions,3);assert.equal(selectedCoverage.onSaleVersions,3);
const progress=selectedCoverage.brandProgress.find(b=>isCupra(b.brand));assert(progress);assert.equal(progress.currentVersionReviews.length,0);assert.equal(progress.unreviewedCoreGrades,0);assert.equal(progress.missingSummaries,0);assert.equal(progress.criteria.C1,false);
const snapshot=structuredClone(packs),writtenExpected=structuredClone(packs),stored=storePortablePacks(packs);assert.deepEqual(packs,snapshot);assert.deepEqual(hydratePortablePacks(stored,data.sources),packs);
for(const o of observations){const row=writtenExpected[o.variantId].features[o.rowIndex];assert(Object.hasOwn(row,o.property));assert.equal(row[o.property],undefined);delete row[o.property];}
assert.deepEqual(JSON.parse(JSON.stringify(packs)),writtenExpected);assert.deepEqual(hydratePortablePacks(JSON.parse(JSON.stringify(stored)),data.sources),writtenExpected);
for(const [name,obj]of Object.entries({'selected-after-cars':after,'selected-packs':packs,portable:stored,claims,'feature-claims':featureClaims,'availability-claims':availabilityClaims,'undefined-witnesses':observations,'claim-undefined-witnesses':claimOmissions})){
 fs.writeFileSync(out+'/'+name+'.json',JSON.stringify(obj,null,2)+'\n',{flag:'wx'});
}
const written=readJson(out+'/selected-packs.json'),hydrated=hydratePortablePacks(readJson(out+'/portable.json'),data.sources);assert.deepEqual(written,writtenExpected);assert.deepEqual(hydrated,writtenExpected);
for(const row of claims)assert.deepEqual(factClaim(hydrated[row.variantId],after.find(c=>c.id===row.variantId).facts[row.key],packet.reviewedAt),row.claim);
for(const row of featureClaims)assert.deepEqual(featureClaim(hydrated[row.variantId],row.criterion,row.criterion,packet.reviewedAt),row.claim);
for(const row of availabilityClaims)assert.deepEqual(factClaim(hydrated[row.variantId],availabilityReportClaim(after.find(c=>c.id===row.variantId)),packet.reviewedAt),row.claim);
for(const [name,rows]of [['claims',claims],['feature-claims',featureClaims],['availability-claims',availabilityClaims]]){const written=readJson(out+'/'+name+'.json');for(let i=0;i<rows.length;i++){const row=rows[i],pack=packs[row.variantId],car=after.find(c=>c.id===row.variantId),replay=()=>name==='claims'?factClaim(pack,car.facts[row.key],packet.reviewedAt):name==='availability-claims'?factClaim(pack,availabilityReportClaim(car),packet.reviewedAt):featureClaim(pack,row.criterion,row.criterion,packet.reviewedAt);const expected=observeClaim(row.claim,pack,'/'+name+'/'+i+'/claim',replay,false);assert.deepEqual(written[i],{...row,claim:expected});}}
// Actual Detail subtree, actual native-disclosure HTML, and actual citable Markdown.
// Footnote links require client effects; hydrated interactions are not claimed.
const Detail=require('./src/components/detail.tsx').default;
const {EvidenceConditions}=require('./src/components/evidence-conditions.tsx');
const {FootnoteRefs}=require('./src/components/footnotes.tsx');
const {createElement}=require('react'),{renderToStaticMarkup}=require('react-dom/server');
const detailProof=[];
for(const car of after){
 const pack=packs[car.id],nodes=elementNodes(Detail({pack,criteria:data.criteria})),availability=nodes.find(n=>n.type==='section'&&n.props['aria-label']==='Availability evidence');assert(availability);
 const subtree=elementNodes(availability),conditions=subtree.find(n=>n.type===EvidenceConditions),footnote=subtree.find(n=>n.type===FootnoteRefs);assert(conditions&&footnote);
 assert.deepEqual(conditions.props.conditions,car.availabilityEvidence.qualifications);assert.deepEqual(footnote.props.ids,car.availabilityEvidence.sourceIds);assert(footnote.props.ids.includes(recallId));
 const html=renderToStaticMarkup(createElement(EvidenceConditions,conditions.props));for(const part of ['REC-006687','94S9','318','2024–2026','should not use advanced full beam assist','free dealer software update','No candidate vehicle is assumed affected or remedied'])assert(html.includes(part));
 const report=makeReport([pack],'/cars/'+car.family+'/'+car.slug,packet.reviewedAt),markdown=reportMarkdown(report);assert.deepEqual(makeReport([hydrated[car.id]],report.path,packet.reviewedAt),report);assert(markdown.includes(recallUrl)&&markdown.includes('should not use advanced full beam assist')&&markdown.includes('No candidate vehicle is assumed affected or remedied'));
 fs.writeFileSync(out+'/'+car.id+'-availability.html',html+'\n',{flag:'wx'});fs.writeFileSync(out+'/'+car.id+'-report.md',markdown,{flag:'wx'});
 assert.equal(fs.readFileSync(out+'/'+car.id+'-report.md','utf8'),reportMarkdown(makeReport([written[car.id]],report.path,packet.reviewedAt)));
 detailProof.push({variantId:car.id,actualDetailSection:'Availability evidence',actualConditionsComponent:true,completeConditions:conditions.props.conditions,actualFootnoteSourceIds:footnote.props.ids,governmentSource:pack.sources.find(s=>s.id===recallId),disclosureHtmlFile:out+'/'+car.id+'-availability.html',citableMarkdownFile:out+'/'+car.id+'-report.md',writtenHydratedReportExact:true,hydratedFootnoteInteractionTested:false});
}
assert.equal(defaultCalls,0);for(const f of ['src/lib/data.ts','src/lib/catalogue.ts','src/lib/research.ts'])assert(!require.cache[repo+'/'+f]);
fullResearchExact(base,currentFields,'baseResearch');assert.deepEqual(before,beforeSnapshot);fullResearchExact(data,candidateFields,'candidateResearch');assert.deepEqual(after,afterSnapshot);assert.deepEqual(packet,packetSnapshot);assert.deepEqual(packs,snapshot);checkPins();
const result={status:'selected_actual_consumers_and_exact_serialization_witness_pass',packetSha256:fileHash(packetPath),beforeCars:0,afterCars:3,newModels:1,coreCells:51,coreGradeCounts:gradeCounts,earnedPacketCells:earnedCells,selectedFeatureClaims:207,roadsideCanonicalProjections:3,expectedOnSaleDelta:3,readInputs:reads,registeredContextComposition:contextComposition,generatedOnlySelectedFeatures:true,currentListProof:c1,selectedCoverage,rankingProof,rankCounts,producerProofs,detailProof,optionalFeaturePaths:observations,optionalCitationPaths:claimOmissions,inMemoryPortableExact:true,writtenPortableExact:true,writtenClaimReadback:true,livePacksUnchanged:true,productionCatalogueHydration:false,defaultLoaderCalls:defaultCalls,sourceEdits:false,fullProjectTypeScript:'UNPASSED; no compiler retry',hydratedBrowserInteractionsTested:false};
assert.deepEqual(buildMarketReconciliation(reconciliation,after,inventory,packet.reviewedAt),c1);assert.deepEqual(selectedCoverage.reconciliation,c1);
const resultSnapshot=structuredClone(result),resultWritten=structuredClone(result),reportOmissions=[];
function reportShape(value,path,clone,parent){
 if(value===undefined){
  assert(/\/(brand|reference)$/.test(path),'Unexpected report undefined '+path);assert.deepEqual(parent,c1.issues[0]);assert.equal(parent.code,'independent_lists');
  const property=path.split('/').at(-1),d=Object.getOwnPropertyDescriptor(parent,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);
  reportOmissions.push({pointer:path,property,ownUndefined:true,enumerable:true,producer:'Actual buildMarketReconciliation independent_lists issue via add(code, reason), no brand/reference arguments'});return;
 }
 if(!value||typeof value!=='object')return;
 for(const key of Object.keys(value)){reportShape(value[key],path+'/'+key.replaceAll('~','~0').replaceAll('/','~1'),clone?.[key],value);if(value[key]===undefined)delete clone[key];}
}
reportShape(result,'/result',resultWritten,null);assertDeclaredJson(result,'/result',new Set(reportOmissions.map(x=>x.pointer)));assert.deepEqual(JSON.parse(JSON.stringify(result)),resultWritten);assert.deepEqual(result,resultSnapshot);
fs.writeFileSync(out+'/report-undefined-witnesses.json',JSON.stringify(reportOmissions,null,2)+'\n',{flag:'wx'});fs.writeFileSync(out+'/result.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});assert.deepEqual(readJson(out+'/result.json'),resultWritten);

progress('Three selected packs, 54 fact claims, 207 feature claims and recall/citable/portable ownership proved');
const acceptedSelected=readJson(m.selectedResult.path);assert.equal(acceptedSelected.status,'selected_actual_consumers_and_exact_serialization_witness_pass');assert.equal(acceptedSelected.packetSha256,m.packet.sha256);
for(const [name,pin]of Object.entries(m.selectedArtifacts))assert.equal(fileHash(out+'/'+name),pin.sha256,'Exact selected written artifact '+name);
const acceptedWrittenPacks=readJson(m.selectedArtifacts['selected-packs.json'].path);
const acceptedWrittenClaims=readJson(m.selectedArtifacts['claims.json'].path),acceptedWrittenFeatureClaims=readJson(m.selectedArtifacts['feature-claims.json'].path),acceptedAvailabilityClaims=readJson(m.selectedArtifacts['availability-claims.json'].path);
assert.deepEqual(claims,acceptedWrittenClaims.map(row=>({variantId:row.variantId,key:row.key,claim:factClaim(acceptedWrittenPacks[row.variantId],acceptedWrittenPacks[row.variantId].car.facts[row.key],m.asOf)})));
assert.deepEqual(featureClaims,acceptedWrittenFeatureClaims.map(row=>({variantId:row.variantId,criterion:row.criterion,claim:featureClaim(acceptedWrittenPacks[row.variantId],row.criterion,row.criterion,m.asOf)})));
assert.deepEqual(availabilityClaims,acceptedAvailabilityClaims.map(row=>({variantId:row.variantId,claim:factClaim(acceptedWrittenPacks[row.variantId],availabilityReportClaim(acceptedWrittenPacks[row.variantId].car),m.asOf)})));
assert.deepEqual(observations,acceptedSelected.optionalFeaturePaths);assert.deepEqual(claimOmissions,acceptedSelected.optionalCitationPaths);assert.deepEqual(readJson(out+'/result.json').selectedCoverage,acceptedSelected.selectedCoverage);
const policy={asOf:m.asOf};
// Full structural ranking comparison: peers stay exact inside compatible groups; whole groups may move.
const discoverySource=fs.readFileSync(repo+'/src/lib/discovery.ts','utf8');
const comparatorSource='(a, b) =>\n        b.entries.length - a.entries.length || a.basis.localeCompare(b.basis)';
assert.equal(discoverySource.split(comparatorSource).length,2,'Unique production group-sort expression');
const groupCompare=(a,b)=>b.entries.length-a.entries.length||a.basis.localeCompare(b.basis);
const groupKey=group=>JSON.stringify([group.vehicleClass,group.basis,group.unit]);
const globalRankProof=[];
function groupProof(ranking,inputCars,attribute){
 const byKey=new Map(ranking.groups.map(group=>[groupKey(group),group]));assert.equal(byKey.size,ranking.groups.length);
 const memberGroup=new Map();for(const group of ranking.groups)for(const entry of group.entries){assert(!memberGroup.has(entry.car.id));memberGroup.set(entry.car.id,groupKey(group));assert.deepStrictEqual(entry.fact,entry.car.facts[attribute.key]);}
 const insertionKeys=[];for(const car of inputCars){const key=memberGroup.get(car.id);if(key&&!insertionKeys.includes(key))insertionKeys.push(key);}
 assert.equal(insertionKeys.length,ranking.groups.length);
 const predicted=insertionKeys.map(key=>byKey.get(key)).sort(groupCompare);assert.deepStrictEqual(predicted.map(groupKey),ranking.groups.map(groupKey));
 for(const group of ranking.groups){
  const ordered=[...group.entries].sort((a,b)=>(Number(a.fact.value)-Number(b.fact.value))*(attribute.direction==='lower'?1:-1)||a.car.id.localeCompare(b.car.id));
  assert.deepStrictEqual(ordered.map(row=>row.car.id),group.entries.map(row=>row.car.id));
  for(const row of group.entries){const value=Number(row.fact.value);assert.equal(row.rank,group.entries.findIndex(entry=>Number(entry.fact.value)===value)+1);assert.equal(row.tied,group.entries.filter(entry=>Number(entry.fact.value)===value).length>1);}
 }
 return {insertionKeys,sortedKeys:ranking.groups.map(groupKey),groups:ranking.groups.map(group=>({key:groupKey(group),count:group.entries.length,ids:group.entries.map(row=>row.car.id),selectedIds:group.entries.filter(row=>selected.has(row.car.id)).map(row=>row.car.id),peerIds:group.entries.filter(row=>peerIds.has(row.car.id)).map(row=>row.car.id)}))};
}
for(const attribute of attributes){
 const old=rankAttribute(currentCars,base.sources,attribute.key,policy),next=rankAttribute(cars,data.sources,attribute.key,policy);
 const a=groupProof(old,currentCars,attribute),b=groupProof(next,cars,attribute),aBy=new Map(a.groups.map(group=>[group.key,group])),bBy=new Map(b.groups.map(group=>[group.key,group]));
 for(const key of new Set([...aBy.keys(),...bBy.keys()])){
  const oldGroup=aBy.get(key),newGroup=bBy.get(key),oldPeers=oldGroup?.peerIds??[],newPeers=newGroup?.peerIds??[];
  assert.deepStrictEqual(newPeers,oldPeers,'Peer order within compatible group '+attribute.key+'/'+key);
  assert.equal(newGroup?.count??0,(oldGroup?.count??0)-(oldGroup?.selectedIds.length??0)+(newGroup?.selectedIds.length??0));
 }
 assert.deepStrictEqual(next.excluded.filter(row=>peerIds.has(row.carId)),old.excluded.filter(row=>peerIds.has(row.carId)));
 assert.deepStrictEqual(next.unranked.filter(row=>peerIds.has(row.car.id)),old.unranked.filter(row=>peerIds.has(row.car.id)));
 assert.deepStrictEqual(new Set(b.groups.flatMap(group=>group.selectedIds)),new Set());
 globalRankProof.push({attribute:attribute.key,before:a,after:b,peerExclusions:next.excluded.filter(row=>peerIds.has(row.carId)),peerMembershipAndWithinGroupOrderExact:true,productionGroupComparator:comparatorSource,insertionTiesProvedFromActualInputOrder:true,selectedCountDeltasExact:true});
}
write('global-ranking-comparison',globalRankProof);

// Actual global C1 only: mirror current loader imports without running its full loader.
const actualPaths=[...fs.readFileSync(repo+'/scripts/reporting/load.ts','utf8').matchAll(/import \w+ from "(\.\.\/\.\.\/data\/m1-[^"]+\.json)";/g)].map(match=>path.resolve(repo+'/scripts/reporting',match[1]));assert.deepEqual(actualPaths,m.reconciliationInputs.map(pin=>pin.path));assert.equal(actualPaths.length,28);
const {combineM1Reconciliations,inventoryRecordId}=require('./scripts/reporting/m1-reconciliation.ts');
const baseReconciliation=combineM1Reconciliations(...m.reconciliationInputs.map(pin=>require(pin.path)));
const baselineC1=buildMarketReconciliation(baseReconciliation,currentCars.filter(isTierOne).filter(car=>isCurrentListEligible(car,base.sources,m.asOf)),allInventory,m.asOf);
const acceptedStageGlobal=readJson(m.acceptedKgmC1.path).after,acceptedReport=readJson(m.acceptedNormalReport.path),normalTerminal=readJson(m.acceptedNormalTerminal.path);assert.equal(normalTerminal.exitCode,0);assert.equal(normalTerminal.stdoutSha256,m.acceptedNormalReport.sha256);
const fixtureRegistry={schemaVersion:1,checkedAt:m.asOf,publishedLists:[],currentVersionReviews:[],listResolutions:[],inventoryResolutions:[],catalogueOnlyDifferences:[]},fixtureInventory={records:[],unverifiedLeads:[]};
const fixture=buildMarketReconciliation(fixtureRegistry,[],fixtureInventory,m.asOf);assert.deepEqual(fixture.issues.map(issue=>issue.code),['independent_lists','empty_catalogue']);
const producedIssue=fixture.issues[0],issueOwnership=[];assert.deepEqual(Object.keys(producedIssue).sort(),['brand','code','reason','reference']);
for(const property of ['brand','reference']){const descriptor=Object.getOwnPropertyDescriptor(producedIssue,property);assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value'));assert.equal(descriptor.value,undefined);issueOwnership.push({property,ownUndefined:true,enumerable:true,producer:'Actual buildMarketReconciliation fixture add(code,reason)'});}
function c1Written(live,label){const snapshot=structuredClone(live),clone=structuredClone(live),indices=live.issues.map((issue,index)=>issue.code==='independent_lists'?index:-1).filter(index=>index>=0);assert.equal(indices.length,1);const index=indices[0],issue=live.issues[index];assert.deepEqual(issue,producedIssue);const allowed=new Set();for(const property of ['brand','reference']){assert.deepEqual(Object.getOwnPropertyDescriptor(issue,property),Object.getOwnPropertyDescriptor(producedIssue,property));allowed.add('/'+label+'/issues/'+index+'/'+property);delete clone.issues[index][property];}assertDeclaredJson(live,'/'+label,allowed);assert.deepEqual(JSON.parse(JSON.stringify(live)),clone);assert.deepEqual(live,snapshot);return clone;}
const baselineWritten=c1Written(baselineC1,'baselineC1');assert.deepEqual(baselineWritten,acceptedStageGlobal);assert.deepEqual(baselineWritten,acceptedReport.reconciliation);
const expectedLive=structuredClone(acceptedStageGlobal),independentIndex=expectedLive.issues.findIndex(issue=>issue.code==='independent_lists');expectedLive.issues[independentIndex]=producedIssue;assert.deepEqual(baselineC1,expectedLive);
const proposedReconciliation=combineM1Reconciliations(baseReconciliation,reconciliation),globalC1=buildMarketReconciliation(proposedReconciliation,cars.filter(isTierOne).filter(car=>isCurrentListEligible(car,data.sources,m.asOf)),allInventory,m.asOf);
assert.equal(baselineC1.reviewedModels,103);assert.equal(baselineC1.reviewedVersions,234);assert.equal(globalC1.reviewedModels,103);assert.equal(globalC1.reviewedVersions,234);assert.equal(globalC1.registryValid,true);assert.equal(globalC1.pass,false);
assert.deepEqual(globalC1.reviewedVersionIds,baselineC1.reviewedVersionIds);assert.deepEqual(globalC1.validModelReviewIds,baselineC1.validModelReviewIds);
const nonCupraIssue=issue=>!isCupra(issue.brand)&&!selected.has(issue.reference)&&!['record:cupra-tavascan','lead:cupra-born'].includes(issue.reference);assert.deepEqual(globalC1.issues.filter(nonCupraIssue),baselineC1.issues.filter(nonCupraIssue));
assert.deepEqual(baselineC1.issues.filter(issue=>!nonCupraIssue(issue)).map(issue=>issue.reference),['record:cupra-tavascan','lead:cupra-born']);
assert.deepEqual(globalC1.issues.filter(issue=>!nonCupraIssue(issue)).map(issue=>issue.reference),[...selected,'record:cupra-tavascan']);
assert.deepEqual(cars.slice(0,427).map(car=>car.id),currentCars.map(car=>car.id));assert.equal(cars.length,430);assert.equal(cars.filter(isTierOne).length,353);assert.equal(cars.filter(isTierOne).filter(isOnSale).length,312);
assert.equal(currentCars.filter(isTierOne).length,350);assert.equal(currentCars.filter(isTierOne).filter(isOnSale).length,309);
const expectedGlobalEvidence=structuredClone(baselineWritten.evidence);assert.deepEqual(Object.keys(expectedGlobalEvidence).sort(),Object.keys(reconciliation).sort());expectedGlobalEvidence.checkedAt=[baselineWritten.evidence.checkedAt,reconciliation.checkedAt].sort().at(-1);
for(const key of ['notes','publishedLists','currentVersionReviews','listResolutions','catalogueOnlyDifferences','inventoryResolutions'])expectedGlobalEvidence[key]=[...baselineWritten.evidence[key],...reconciliation[key]];
assert.deepEqual(proposedReconciliation,expectedGlobalEvidence);
assert.deepEqual(new Set(baselineWritten.issues.map(issue=>issue.code)),new Set(['independent_lists','version_unreviewed','inventory_unresolved']));
const expectedNewIssues=packet.variants.map(variant=>({code:'version_unreviewed',reason:`${variant.model} ${variant.trim}: current version-list membership has not been settled`,brand:'CUPRA',reference:variant.id}));
const expectedIssues=[...baselineWritten.issues.filter(issue=>issue.code==='independent_lists'),...baselineWritten.issues.filter(issue=>issue.code==='version_unreviewed'),...expectedNewIssues,...baselineWritten.issues.filter(issue=>issue.code==='inventory_unresolved'&&issue.reference!=='lead:cupra-born')];
const originalInventoryOrder=[...allInventory.records.filter(record=>!record.vehicleClass||['passenger','ute'].includes(record.vehicleClass)).map(record=>'record:'+inventoryRecordId(record)),...allInventory.unverifiedLeads.filter(record=>!record.vehicleClass||['passenger','ute'].includes(record.vehicleClass)).map(record=>'lead:'+inventoryRecordId(record))];
const allExpectedSettlements=new Set([...baselineWritten.settledInventory,'lead:cupra-born']);
const expectedGlobalWritten={...structuredClone(baselineWritten),registryCheckedAt:expectedGlobalEvidence.checkedAt,settledInventory:originalInventoryOrder.filter(id=>allExpectedSettlements.has(id)),issues:expectedIssues,evidence:expectedGlobalEvidence};
assert.equal(expectedGlobalWritten.settledInventory.length,baselineWritten.settledInventory.length+1);assert.equal(expectedGlobalWritten.issues.length,baselineWritten.issues.length+2);
const globalWritten=c1Written(globalC1,'globalC1');assert.deepEqual(globalWritten,expectedGlobalWritten,'Complete proposed C1 equality, all counters, exact issue order and evidence arrays');
write('baseline-global-c1',baselineC1);write('global-c1-comparison',{before:baselineWritten,after:globalWritten,expectedCompleteAfter:expectedGlobalWritten,completeExpectedWrittenEquality:true,baselineMatchesAcceptedKgmAndNormal:true,nonCupraIssuesReviewsDispositionsExact:true,issueOwnership,normalFullReportRun:false});
progress('Global compatible-group rankings and complete expected C1 gaps proved without broad features');
fullResearchExact(base,currentFields,'baseResearch');fullCarsExact(currentCars,currentDigests,'currentCars');fullResearchExact(data,candidateFields,'candidateResearch');fullCarsExact(cars,candidateDigests,'candidateCars');assert.deepEqual(before,beforeSnapshot);assert.deepEqual(after,afterSnapshot);assert.deepEqual(packet,packetSnapshot);assert.deepEqual(packs,snapshot);assert.equal(defaultCalls,0);
for(const file of ['src/lib/data.ts','src/lib/catalogue.ts','src/lib/research.ts','scripts/reporting/load.ts'])assert(!require.cache[repo+'/'+file]);checkPins();
write('metadata-composition',transitions);write('car-digest-comparison',{...carStages,candidate29:candidateDigests});write('research-field-digests',{...fieldStages,candidate29:candidateFields});
write('stage-receipt',{status:'bounded_structural_selected_stage_pass_pending_independent_review',manifestSha256:args[3],packetSha256:m.packet.sha256,originalBaselineCars:409,acceptedCurrentCars:427,stagedCars:430,tierOneVersions:353,onSaleVersions:312,untouchedPeerCars:427,newModels:1,newVersions:3,versionUpdates:0,configurationUpdates:0,manualFeatureUpdates:0,sourceRowsAdded:16,allAcceptedStagesThroughKgm28ExactlyReproduced:true,all14ResearchFieldsProved:true,strictJsonShapeBeforeDigest:true,all21RetainedStorageFilesPinnedBeforeAndAfter:true,completeGlobalC1ExpectedEquality:true,actualSelectedCars:3,actualFactAndTermClaims:earnedCells,actualFeatureClaims:featureClaims.length,roadsideCanonicalProjections:3,generatedFeatureRows:207,actualOptionalWitnessesExact:true,inMemoryPortableExact:true,writtenPortableExact:true,writtenClaimReadback:true,recallDisclosureAndGovernmentCitationProved:true,hydratedFootnoteInteractionTested:false,selectedC1:c1Written(c1,'selectedC1'),globalC1Counts:{reviewedModels:globalC1.reviewedModels,reviewedVersions:globalC1.reviewedVersions,pass:globalC1.pass},sourceAdditionsDoNotReviveAcceptedReferences:true,allPeerDigestsAndIdentitiesExact:true,peerOrderExactWithinCompatibleRankingGroups:true,productionGroupSortingAndInsertionTieProvenance:true,broadFeatureReplay:false,normalFullReportRun:false,normalFullReportRequiredAfterGuardedIntegration:true,defaultLoaderCalls:defaultCalls,liveSourceEdits:false,productionRegistration:false,currentProjectTypeScript:'UNPASSED; no compiler retry',resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log(JSON.stringify({status:'passed',receipt:out+'/stage-receipt.json',sha256:fileHash(out+'/stage-receipt.json'),noBroadFeatureReplay:true}));
