"""Seal exact metadata-only CUPRA29 retention cut after accepted live readback."""
from pathlib import Path
from datetime import datetime, timezone
import json,hashlib,os,stat
B=Path('/tmp/cupra-packet/final-freeze-v1');W=Path('/workspace/scratch/586427eef9f2');R=W/'roadmark-104';REV=Path('/tmp/cupra-review')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def row(p,category):
 p=Path(p);s=p.lstat();r=dict(path=str(p),category=category,bytes=s.st_size,mode=s.st_mode,mtimeNs=s.st_mtime_ns)
 if stat.S_ISLNK(s.st_mode):r.update(kind='symlink',target=os.readlink(p),targetFollowed=False)
 else:assert stat.S_ISREG(s.st_mode),str(p);r['kind']='file'
 return r
out=B/'inventory.json';assert not out.exists()
readback=REV/'docs-status-v2-live-readback-accepted.json';assert read(readback)['status']=='accepted'
final=REV/'final-retention-v1-accepted.json';assert not final.exists()
source_path=Path('/tmp/cupra-packet/source-retention-v1/manifest.json');source=read(source_path)
source_allowlist={x['path']:x for x in source['currentAcceptedSourcePins']+source['heldOnlySourcePins']};assert len(source_allowlist)==97
accepted_paths={x['path'] for x in source['currentAcceptedSourcePins']}
reg=read('/tmp/cupra-packet/registration-v1/manifest.json');docs=read('/tmp/cupra-packet/docs-status-v2/manifest.json')
excluded_mutable={x['path'] for x in source['excludedPathsOrClasses'] if x['path'].startswith('/tmp/cupra-packet/')}
roots=[('/tmp/cupra-research','sanitized_public_research_and_source_history'),('/tmp/cupra-packet','packet_commands_qa_and_all_attempt_history'),('/tmp/cupra-review','independent_reviews')]
rows=[];excluded=[];seen_sources=set()
for root,category in roots:
 for cur,dirs,files in os.walk(root,followlinks=False):
  dirs.sort();files.sort()
  if Path(cur)==B:dirs[:]=[];continue
  for name in list(dirs):
   p=Path(cur)/name
   if p.is_symlink():rows.append(row(p,category));dirs.remove(name)
  for name in files:
   p=Path(cur)/name;path=str(p)
   reason=None;cat='excluded_reconstructible'
   if path=='/tmp/cupra-packet/post-registration-checks-v1/.exclusive-heavy.lock':
    assert p.lstat().st_size==0;reason='Empty terminal exclusive lock; not reconstruction state'
   elif name.endswith('.pyc') or '__pycache__' in p.parts:reason='Reconstructible bytecode; source retained'
   elif path in excluded_mutable:
    cat='excluded_mutable_unversioned_preparation';reason='Unversioned mutable light preparation; current bytes do not reconstruct original 81-pin reviewed v1 bytes. Frozen v2/v3 retained separately.'
   elif p.is_relative_to('/tmp/cupra-research') and path not in source_allowlist:
    cat='excluded_not_in_source_allowlist';reason='Not in accepted-v3 or held-v2 source allowlist; no payload read/copy without separate review'
   if reason:
    excluded.append(dict(**row(p,cat),reason=reason,deletionAuthorized=False));continue
   if path in source_allowlist:
    declared=source_allowlist[path];item=row(p,'accepted_source_v3' if path in accepted_paths else 'held_source_v2_only')
    assert item['bytes']==declared['bytes'];item['declaredSha256']=declared['sha256'];item['contentHashRecomputedAtFreeze']=False
    rows.append(item);seen_sources.add(path)
   else:rows.append(row(p,category))
assert seen_sources==set(source_allowlist)
assert not any(x['category']=='excluded_not_in_source_allowlist' for x in excluded),'Unexpected source file needs explicit review'
live=[]
for item in reg['writes']+docs['writes']:
 p=pin(item['target']);assert p['bytes']==item['after']['bytes'] and p['sha256']==item['after']['sha256'];live.append(p);rows.append(row(item['target'],'live_registered_docs_status_target'))
assert len(live)==7 and len({x['path'] for x in rows})==len(rows);rows.sort(key=lambda x:x['path'])
state=read(W/'roadmark-104-qa/work-status.json');assert state['currentBrand']=='CUPRA' and not state['cupraWorking']['fullProjectTypecheckPassed'] and not state['cupraWorking']['releaseReady'] and not state['cupraResearchStatus']['researchCompleted']
assert state['cupraWorking']['coverage']['catalogue']==430
failure_provenance=read('/tmp/kgm-packet/report-comparison-v2/typescript-failure-provenance.json')
images=[]
for x in source['sourceImages']:
 item=dict(x);item.update(pdfPageNumber=x['printedPage'],pdfZeroBasedPageIndex=x['printedPage']-1,parentProvenance=source_allowlist['/tmp/cupra-research/sources/tavascan-my255-brochure-provenance.json'],parentExtractedText=source_allowlist['/tmp/cupra-research/sources/tavascan-my255-brochure.txt'],pageMappingProof='Public parent PDF extracted text has Technical on page 27 and Full features on page 28; existing renders visibly show those same printed page numbers. No new rendering or screenshot was performed during final freeze.')
 images.append(item)
x=dict(schemaVersion=1,status='author_frozen_metadata_exact_allowlist_pending_backup_capture_and_independent_final_receipt',frozenAt=datetime.now(timezone.utc).isoformat(),noFurtherPayloadEdits=True,metadataOnlyInventory=True,contentCaptureOrPrivacyScanPerformed=False,inventoryHashScope='Only seven exact live targets and named small receipts/provenance are hashed here. Payload walk records lstat metadata only; 97 source declared hashes are copied from frozen accepted-v3 and held-v2 manifests. No payload hash sweep or capture. Backup owns separately authorized capture/privacy scan.',payloadRoots=[r for r,_ in roots],files=rows,totalFiles=len(rows),regularFileBytes=sum(r['bytes'] for r in rows if r['kind']=='file'),symlinkCount=sum(r['kind']=='symlink' for r in rows),sourceAndStatusAfterPins=live,excluded=excluded+[dict(path=str(B),reason='Inventory and preparer pinned separately with future reviewer acceptance to avoid circularity',deletionAuthorized=False)],sourceAllowlist=pin(source_path),currentAcceptedSourceManifest=source['currentAcceptedManifest'],heldSupersededSourceManifest=source['heldSupersededManifest'],acceptedSourcePins=86,heldOnlySourcePins=11,allowlistedSourceUnion=97,rawRuntimeExclusion=dict(rawRuntimeHTMLOrConfigurationPersisted=False,rawResponseHeadersOrCookiesPersisted=False,credentialOrClientKeyPayloadPersisted=False,locallyPresentExcludedOriginalPaths=[],basis='Public capture no-value provenance and versioned source reviews; scripts/runtime/config discarded before text persistence, no raw originals saved',readRefetchOrRecoveryAuthorized=False),publicImageProvenance=dict(publicPdfDocuments=3,existingPublicPdfPageRenders=images,newRenderAtFreeze=False,productBrowserOrPhoneScreenshots=0,currentMy26EquipmentInference=False,sourceImageOrConfigurationPayloadReconstructionAuthorized=False),knownSanitizedSupport=dict(officialHtml='Visible text and ordinary public links only, adjacent no-value provenance; runtime scripts/config omitted before persistence',secondary='Allowlisted factual public web/search transcriptions with exact source identity and URL. RedBook indexed evidence is not described as a successful full-page GET.',pdfs='Three public maker PDFs: historical MY25.5 Tavascan brochure, warranty terms and roadside terms; two existing historical brochure page renders.',classificationCautions='Credential-related field names and false/empty request flags are no-value provenance. Public source URLs, grade identifiers, hashes, test identifiers and compiler paths are factual/proof material.',knownSensitiveValuesRetained=False,privacyScanClaim=False),mutableV1Limitation=source['limitation'],retainedFailures=dict(classification='Two actual earlier KGM compiler failures; no CUPRA runtime failure',provenance=pin('/tmp/kgm-packet/report-comparison-v2/typescript-failure-provenance.json'),cupraFailureContext=pin('/tmp/cupra-packet/report-comparison-v1/typescript-failure-context.json'),attempts=failure_provenance['attempts'],scope='Both unknown-cause SIGKILL attempts, empty logs, no fresh cache and original roots/config/pins preserved. Current TypeScript and release remain unpassed. No compiler retry authorized.'),otherAttemptHistory=dict(sourceV2='Held incorrect V towing transcription; corrected accepted source v3 separately retained',typedV1='Held unexecuted preparation required buyer-visible recall warning; v2/v3/v4 later preparations retained; only v4 materialized',fullStageV1='Held unexecuted composition duplicate binding and incomplete ranking record closure; corrected v2 syntax-only check and actual run passed',docsV1='Superseded unapplied documentary preparation; v2 clarifies inherited roadside applications, fact-proof scope and Alto New/demo conflict',actualRuns='First materialization v4, selected v1, full-stage v2, four-file application, five scoped gates, one normal report/comparator and three-file docs v2 application all passed; no automatic runtime retries'),currentValidation=dict(catalogue=430,tier1=353,onSale=312,packetCount=29,additions=3,unchangedPeers=427,reviewedCore=51,filledCore=49,reported=43,confirmed=6,notPublished=2,scopedTests=151,structuralPassed=True,normalReportAndExhaustiveComparisonPassed=True,fullProjectTypecheckPassed=False,releaseReady=False,researchCompleted=False,compilerRetriesAuthorized=False,factualCoverageOnly=True,currentCleanFullSuite=False,productionBuildVerified=False,phoneMobileVerified=False,priorPassScope='Historical source only'),independentDocsReadback=pin(readback),independentSourceRetentionAcceptance=pin(REV/'source-retention-v1-metadata-accepted.json'),factualReportAcceptance=pin(REV/'report-comparison-v1-results-accepted.json'),currentPacket=pin('/tmp/cupra-packet/typed-preparation-v4/output/cupra-2026-10-15-candidate-v1.json'),currentReconciliation=pin('/tmp/cupra-packet/typed-preparation-v4/cupra-market-reconciliation-v2.json'),retainedStorageReadClosure=pin('/tmp/cupra-packet/full-stage-v2/storage-read-closure.json'),externalDependencies='Reuse accepted terminal KGM28 recovery chain, exact prefix20 retained storage and EQA21/Leap22/Mazda23/Skoda24/Audi25/Deepal26/MINI27/KGM28 stage proofs/replacement cars and KGM baseline normal report. CUPRA manifests include exact 21-file storage closure and original logical hashes; backup owns existing-chain mapping. Both KGM failed compiler envelopes/provenance stay referenced and retained by that chain. No broad recapture.',reconstructionNotes='No payload symlinks expected. No node_modules, generated Next caches, preview snapshot or broad catalogue recapture added. Reconstruct exact original logical paths through the accepted recovery chain. Preserve builder-generated zero-row guards and producer-owned optional-property semantics. Do not regenerate or mislabel missing original mutable light-v1 bytes.',finalReviewerReceiptPolicy=dict(path=str(final),state='future_separate_acceptance_after_inventory_review',includedInPayload=False,reason='Avoid recursive inventory pins; reviewer directory otherwise frozen after documentary live readback and source-retention review'),preparer=pin(__file__))
assert x['symlinkCount']==0
with out.open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False);f.write('\n')
print(json.dumps(dict(inventory=pin(out),files=x['totalFiles'],bytes=x['regularFileBytes'],symlinks=x['symlinkCount'],liveTargets=7,excludedFiles=len(excluded),fullProjectTypecheckPassed=False,researchCompleted=False,releaseReady=False),indent=2))
