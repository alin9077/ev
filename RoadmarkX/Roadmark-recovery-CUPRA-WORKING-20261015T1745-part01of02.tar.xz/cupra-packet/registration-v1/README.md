# CUPRA29 minimal guarded registration

Preparation only. Four writes: two byte-identical accepted JSON files; registry append at position 29 preserving the first 28 entries; one report-loader import and final reconciliation argument. No helper, alias, test, inventory, immutable research or generated market-view changes.

The three MY26 Tavascan additions retain Reported current-release availability, qualified unverified order/physical-stock status, before-ORC prices, source-labelled current towing/height conflicts, exact summary dependencies, inherited warranty use conditions, and the VIN-scoped government recall qualification. The official current model/version-list gap remains open. Dated MY25.5, Born and Raval dispositions remain separate.

The accepted full stage proved 430 catalogue / 353 Tier 1 / 312 on-sale, all 427 existing cars and variants unchanged, 1 new model, 3 new versions, 16 sources, and 207 genuine builder-generated feature rows. C1 remains false: 103 models and 234 versions reviewed, 197 issues, 63 settled inventory entries. No national-best claim follows.

Application requires independent bundle review and a separate exact root application grant. The applicator checks every retained stage input, output and source-review leaf, exact before hashes and proposed bytes; journals each of four writes; then checks post hashes and unchanged helpers. Failure retains its journal and stops without automatic retry or rollback. The grant template is explicitly not authorization.

Later checks are separate: scoped market-view, changed-file lint, 144 behavioral tests, 7 live-safety tests, structural validation, then one actual normal coverage report and an independent saved-output comparator. No compiler retry is included. Full-project TypeScript remains UNPASSED after two preserved KGM SIGKILL failures of unknown cause. Previous historical compiler passes, isolated source transpilation and syntax-only preparation do not replace that status.
