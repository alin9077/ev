from pathlib import Path
import ast,difflib,hashlib,json
R=Path('/workspace/scratch/586427eef9f2/roadmark-104');B=Path('/tmp/cupra-packet/registration-v1')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def put(p,b):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
def write(n,x):put(B/n,(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode())
packet=Path('/tmp/cupra-packet/typed-preparation-v4/output/cupra-2026-10-15-candidate-v1.json')
recon=Path('/tmp/cupra-packet/typed-preparation-v4/cupra-market-reconciliation-v2.json')
registry='data/m1-brand-updates/registry.json';loader='scripts/reporting/load.ts'
old=json.loads((R/registry).read_text());assert len(old['packets'])==28 and old['packets'][-1]=='kgm-2026-10-15.json'
new={**old,'packets':[*old['packets'],'cupra-2026-10-15.json']};assert new['packets'][:-1]==old['packets']
s=(R/loader).read_text();imp='import kgmReconciliation from "../../data/m1-kgm-market-reconciliation-2026-10-15.json";';arg='      kgmReconciliation as M1MarketReconciliation,'
assert s.count(imp)==1 and s.count(arg)==1 and 'cupraReconciliation' not in s
newload=s.replace(imp,imp+'\nimport cupraReconciliation from "../../data/m1-cupra-market-reconciliation-2026-10-15.json";').replace(arg,arg+'\n      cupraReconciliation as M1MarketReconciliation,')
proposals={registry:(json.dumps(new,indent=2)+'\n').encode(),loader:newload.encode(),'data/m1-brand-updates/cupra-2026-10-15.json':packet.read_bytes(),'data/m1-cupra-market-reconciliation-2026-10-15.json':recon.read_bytes()}
rows=[];patch=''
for rel,after in proposals.items():
 p=R/rel;before=p.read_bytes() if p.exists() else None;assert (before is None)==rel.startswith('data/m1-cupra') or rel.startswith('data/m1-brand-updates/') or rel==loader
 put(B/'after'/rel,after)
 if before is not None:put(B/'before'/rel,before)
 rows.append(dict(relativePath=rel,target=str(p),operation='create' if before is None else 'replace',before=None if before is None else {k:v for k,v in pin(p).items() if k!='path'},after=pin(B/'after'/rel),beforeCopy=None if before is None else pin(B/'before'/rel)))
 patch+=''.join(difflib.unified_diff((before or b'').decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+rel if before is not None else '/dev/null',tofile='b/'+rel))
assert [r['operation'] for r in rows]==['replace','replace','create','create']
write('prepared-writes.json',rows);put(B/'registration.patch',patch.encode())
app=Path('/tmp/kgm-packet/registration-v1/apply.py').read_text().replace('apply_exact_kgm_registration','apply_exact_cupra_registration')
ast.parse(app);put(B/'apply.py',app.encode())
write('applicator-syntax-check.json',dict(status='passed_python_ast_parse_only',applicator=pin(B/'apply.py'),executed=False,compilerRun=False))
proofpaths=[
'/tmp/cupra-packet/full-stage-v2/manifest.json','/tmp/cupra-packet/full-stage-v2/full-stage-result-manifest-v1.json','/tmp/cupra-review/full-stage-v2-readiness-accepted.json','/tmp/cupra-review/full-stage-v2-result-accepted.json',
'/tmp/cupra-packet/selected-preflight-v1/selected-result-manifest-v1.json','/tmp/cupra-review/selected-preflight-v1-result-accepted.json','/tmp/cupra-review/typed-candidate-v1-accepted.json','/tmp/cupra-review/source-review-v3-accepted.json',
'/tmp/cupra-packet/source-review-v3/source-admission-manifest.json',str(packet),str(recon),'/tmp/cupra-packet/typed-preparation-v4/admission-audit-v2.json',
'/tmp/kgm-packet/full-project-typescript-v1/run/terminal.json','/tmp/kgm-packet/full-project-typescript-v2/run/terminal.json','/tmp/kgm-packet/report-comparison-v2/typescript-failure-provenance.json']
proofs={}
def add(p):
 x=pin(p);prev=proofs.get(x['path']);assert not prev or prev==x;proofs[x['path']]=x
for p in proofpaths:add(p)
for p,key in [('/tmp/cupra-packet/full-stage-v2/manifest.json','pins'),('/tmp/cupra-packet/full-stage-v2/full-stage-result-manifest-v1.json','files'),('/tmp/cupra-packet/source-review-v3/source-admission-manifest.json','files')]:
 for x in json.loads(Path(p).read_text())[key]:
  assert pin(x['path'])==x,(x['path'],'retained proof drift');add(x['path'])
helper=['src/lib/brand-updates.ts','src/lib/brand-update-registry.ts','src/lib/evidence-consumers.ts','src/lib/discovery.ts','src/lib/data.ts','scripts/reporting/reports.ts','scripts/reporting/m1-reconciliation.ts','tests/brand-updates.test.ts']
readme='''# CUPRA29 minimal guarded registration

Preparation only. Four writes: two byte-identical accepted JSON files; registry append at position 29 preserving the first 28 entries; one report-loader import and final reconciliation argument. No helper, alias, test, inventory, immutable research or generated market-view changes.

The three MY26 Tavascan additions retain Reported current-release availability, qualified unverified order/physical-stock status, before-ORC prices, source-labelled current towing/height conflicts, exact summary dependencies, inherited warranty use conditions, and the VIN-scoped government recall qualification. The official current model/version-list gap remains open. Dated MY25.5, Born and Raval dispositions remain separate.

The accepted full stage proved 430 catalogue / 353 Tier 1 / 312 on-sale, all 427 existing cars and variants unchanged, 1 new model, 3 new versions, 16 sources, and 207 genuine builder-generated feature rows. C1 remains false: 103 models and 234 versions reviewed, 197 issues, 63 settled inventory entries. No national-best claim follows.

Application requires independent bundle review and a separate exact root application grant. The applicator checks every retained stage input, output and source-review leaf, exact before hashes and proposed bytes; journals each of four writes; then checks post hashes and unchanged helpers. Failure retains its journal and stops without automatic retry or rollback. The grant template is explicitly not authorization.

Later checks are separate: scoped market-view, changed-file lint, 144 behavioral tests, 7 live-safety tests, structural validation, then one actual normal coverage report and an independent saved-output comparator. No compiler retry is included. Full-project TypeScript remains UNPASSED after two preserved KGM SIGKILL failures of unknown cause. Previous historical compiler passes, isolated source transpilation and syntax-only preparation do not replace that status.
'''
put(B/'README.md',readme.encode())
m=dict(schemaVersion=1,status='frozen_preparation_only_requires_bundle_review_and_root_application_grant',repo=str(R),writes=rows,proofs=list(proofs.values()),unchangedHelperPins=[pin(R/p) for p in helper],patch=pin(B/'registration.patch'),applicator=pin(B/'apply.py'),preparation=[pin(B/'prepare.py'),pin(B/'README.md'),pin(B/'prepared-writes.json'),pin(B/'applicator-syntax-check.json')],expected=dict(catalogue=430,tierOne=353,onSale=312,packets=29,changedExistingCars=0,unchangedPeers=427,newModels=1,newVersions=3,newSources=16,generatedFeatureRows=207,manualFeatureUpdates=0,C1=dict(pass_=False,reviewedModels=103,reviewedVersions=234,issues=197,settledInventory=63)),scope=dict(existingFiles=2,newFiles=2,helperSemantics='Unchanged accepted live helpers',packet='Exact accepted materialized candidate v1',reconciliation='Exact accepted typed reconciliation v2',registry='Append only; preserve first 28 ordered entries',reportLoader='One import and one last combineM1Reconciliations argument',reportImplementationChanged=False,testsChanged=False,heroChanged=False,immutableSnapshotChanged=False,sourceCapturesAddedToRepository=False),currentProjectTypeScript='UNPASSED: two preserved unknown-cause KGM SIGKILL failures; no compiler retry',automaticRetry=False,rootGrantRequired=True,heavyChecksAllowed=False,rollback='No automatic rollback or deletion; retain journal and exact before copies for separately authorised recovery')
m['expected']['C1']['pass']=m['expected']['C1'].pop('pass_')
write('manifest.json',m)
write('root-grant-template.json',dict(status='NOT_GRANTED',action='apply_exact_cupra_registration',manifest=pin(B/'manifest.json'),reviewerAcceptance=None,allowedTargets=[x['target'] for x in rows],automaticRetry=False,heavyExecutionAuthorized=False))
print(json.dumps(dict(manifest=pin(B/'manifest.json'),proofs=len(proofs),writes=rows),indent=2))
