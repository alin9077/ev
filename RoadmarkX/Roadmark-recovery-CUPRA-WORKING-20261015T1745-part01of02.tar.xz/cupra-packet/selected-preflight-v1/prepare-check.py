from pathlib import Path
O=Path('/tmp/cupra-packet/selected-preflight-v1')
prior=Path('/tmp/kgm-packet/selected-preflight-v2/check.mjs').read_text()
functions=prior[prior.index('function observePack('):prior.index('for(const car of before){const pack=initial.pack')]
header=r'''/** Prepared selected actual consumers for three genuine additions; no full catalogue loader. */
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readJson,fileHash,streamRows} from '/tmp/xpeng-staging-plan/baseline-io.mjs';
import {assertDeclaredJson} from '/tmp/mercedes-staging-plan/consumer-preparation/v5/feature-json-parity.mjs';
const repo='/workspace/scratch/586427eef9f2/roadmark-104',out='/tmp/cupra-packet/selected-preflight-v1';
const material='/tmp/cupra-packet/typed-preparation-v4';
assert.equal(process.argv[2],'--root-execution-granted');assert.equal(process.cwd(),repo);assert(!fs.existsSync(out+'/result.json'));
const pins=readJson(out+'/source-pins.json');
function checkPins(){for(const p of pins){assert.equal(fs.statSync(p.path).size,p.bytes,p.path);assert.equal(fileHash(p.path),p.sha256,p.path);}}checkPins();
const packetPath=material+'/output/cupra-2026-10-15-candidate-v1.json';
assert.equal(fileHash(packetPath),'24092e919c384e1bf3a8e85eeed360de39405d7ea58b46b2c79bca4d2f2e794a');
const packet=readJson(packetPath),packetSnapshot=structuredClone(packet);
const before=readJson('/tmp/cupra-research/retained-before-cars.json');assert.deepEqual(before,[]);
const receipt=readJson('/tmp/cupra-research/retained-selection-proof.json');assert.equal(fileHash(receipt.acceptedIndex),receipt.indexSha256);
const acceptedDigests=readJson(receipt.acceptedIndex)[receipt.stage];assert.equal(acceptedDigests.length,427);assert(acceptedDigests.every(row=>!/cupra|tavascan|born/i.test(row.id)));
const selected=new Set(packet.variants.map(v=>v.id));assert.equal(selected.size,3);
const accepted=readJson('/tmp/mercedes-staging-plan/consumer-preparation/v5/manifests/report-v5.json');
const storage=readJson('/tmp/mercedes-staging-plan/staging-preparation/staging-artifacts/canonical-v1/staged-storage-index.json');
const base={},reads=[];
for(const [key,ref]of Object.entries(storage.research)){
 const values=[];
 await streamRows(accepted.anchors,ref,row=>{
  const keep=['variants','feature_evidence_variant_context'].includes(key)?selected.has(row.id):['feature_evidence','trim_equipment','update_eligibility'].includes(key)?selected.has(row.variant_id):true;
  if(keep)values.push(row);
 });
 base[key]=ref.array?values:values[0];reads.push({field:key,inputRows:ref.rows,selectedRows:values.length,sha256:ref.sha256});
}
for(const key of ['variants','feature_evidence_variant_context','feature_evidence','trim_equipment','update_eligibility'])assert.deepEqual(base[key],[]);
assert.equal(base.criteria.length,69);assert(!base.models.some(m=>m.brand.toUpperCase()==='CUPRA'));
const require=createRequire(repo+'/package.json');
const {brandUpdatePackets}=require('./src/lib/brand-update-registry.ts');assert.equal(brandUpdatePackets.length,28);assert.equal(brandUpdatePackets.at(-1).id,'m1-kgm-2026-10-15');
const contextComposition=[];
// Only exact registered model/source snapshots extend the selected global context.
// No unrelated variants, features or Cars are generated or manually reconstructed.
for(const prior of brandUpdatePackets){
 assert.notEqual(prior.brand.toUpperCase(),'CUPRA');
 for(const row of [...prior.variants,...prior.versionGuards,...prior.facts,...prior.availability,...prior.summaries,...(prior.features??[])])assert(!selected.has(row.variantId??row.id));
 for(const term of prior.brandTerms??[])assert(term.applicableVariantIds.every(id=>!selected.has(id)));
 const counts={packetId:prior.id,modelsAdded:0,sourcesAdded:0};
 for(const [key,count]of [['models','modelsAdded'],['sources','sourcesAdded']])for(const row of prior[key]){
  const current=base[key].filter(x=>x.id===row.id);assert(current.length<=1);
  if(current.length)assert.deepEqual(current[0],row,'Retained registered context changed '+row.id);else{base[key].push(structuredClone(row));counts[count]++;}
 }
 contextComposition.push(counts);
}
assert.deepEqual(base.models,readJson(material+'/base-research-input.json').models);
const baseSnapshot=structuredClone(base),beforeSnapshot=structuredClone(before);
const {prepareBrandResearch,applyBrandUpdates,applyBrandFeatureUpdates,applyBrandTermFeatures}=require('./src/lib/brand-updates.ts');
const data=prepareBrandResearch(base,[packet]),dataSnapshot=structuredClone(data),after=applyBrandUpdates(before,data,[packet]),afterSnapshot=structuredClone(after);
assert.deepEqual(after,readJson(material+'/output/selected-after-cars.json'));
assert.equal(data.variants.length,3);assert.equal(data.feature_evidence.length,207);assert.equal(data.trim_equipment.length,3);assert.equal(data.update_eligibility.length,3);
assert.equal(data.models.length,base.models.length+1);assert.deepEqual(data.models.slice(0,base.models.length),base.models);
assert.deepEqual(data.criteria,base.criteria);assert.deepEqual(data.publication_issues,base.publication_issues);
assert.equal(packet.facts.length,45);assert.equal(packet.brandTerms.reduce((n,t)=>n+t.applicableVariantIds.length,0),9);
for(const row of packet.facts){assert.equal(row.before,null);assert.deepEqual(after.find(c=>c.id===row.variantId).facts[row.after.key],row.after);}
for(const term of packet.brandTerms)for(const id of term.applicableVariantIds){assert.equal(term.before[id],null);assert.deepEqual(after.find(c=>c.id===id).facts[term.key],term.fact);}
const generated=readJson(material+'/output/builder-guard-provenance.json').generatedAvailabilityBefore;
for(const edit of packet.availability){assert.deepEqual(edit.before,generated.find(row=>row.variantId===edit.variantId).before);const car=after.find(c=>c.id===edit.variantId);assert.deepEqual({availability:car.availability,evidence:car.availabilityEvidence},edit.after);}
for(const row of packet.summaries){const car=after.find(c=>c.id===row.variantId);for(const side of ['strength','tradeoff']){assert.equal(car.buyerSummary[side].text,row[side].text);for(const dep of row[side].dependencies){assert.deepEqual(car.facts[dep.key],dep.expected);assert.notEqual(dep.expected.value,null);assert.equal(dep.expected.issues.length,0);}const ids=[...new Set(row[side].dependencies.flatMap(d=>d.expected.sourceIds))];assert.deepEqual(car.buyerSummary[side].sourceIds,ids);}assert.deepEqual(car.buyerSummary.conditions,row.conditions??[]);}
const {compiledSource,elementNodes}=require('./tests/helpers/compiled-source.ts');
let defaultCalls=0;const forbidden=()=>{defaultCalls++;throw new Error('FORBIDDEN_DEFAULT_CATALOGUE_LOADER');};
const consumer=compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets:[...brandUpdatePackets,packet]}}).createEvidenceConsumers({sourceResearch:forbidden,research:forbidden,catalogue:forbidden});
const {hasEarnedBuyerGrade}=require('./src/lib/evidence-grading.ts');
const {factClaim,featureClaim,makeReport,reportMarkdown}=require('./src/lib/citable.ts');
const {availabilityReportClaim}=require('./src/lib/availability-corrections.ts');
const {buyerAvailabilityText}=require('./src/lib/buyer-availability.ts');
const {isOnSale,isCurrentListEligible,buildCoverageReport}=require('./scripts/reporting/reports.ts');
const {auditedFeature}=require('./src/lib/launch-evidence.ts');
const {applyFeatureRegrading}=require('./src/lib/evidence-regrading.ts');
const {storePortablePacks,hydratePortablePacks}=require('./src/lib/portable-packs.ts');
const {exclusionReason,rankAttribute,attributes}=require('./src/lib/discovery.ts');
const packs={},observations=[],claims=[],featureClaims=[],claimOmissions=[],producerProofs=[],frames=new Map(),availabilityClaims=[];
for(const car of after){const input=consumer.sourceEffectiveFeatures(car,data),snap=structuredClone(input),regraded=applyFeatureRegrading(car,input,data.sources);assert.deepEqual(input,snap);const branded=applyBrandFeatureUpdates(car,regraded,data,[...brandUpdatePackets,packet]),projected=applyBrandTermFeatures(car,branded,data.sources);frames.set('after\0'+car.id,{input,regraded,branded,projected,research:data});producerProofs.push({variantId:car.id,producer:'Actual sourceEffectiveFeatures with retained global issues -> applyFeatureRegrading -> applyBrandFeatureUpdates -> applyBrandTermFeatures',inputRows:input.length,outputRows:projected.length,globalIssueIds:data.publication_issues.map(i=>i.issue_id),inputUnchanged:true});}
'''
body=r'''
const core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','length_mm','width_mm','height_mm','towing_braked_kg','zero_to_100_s','power_kw','drive','warranty','battery_warranty'];
let earnedCells=0,roadsideProjections=0;const gradeCounts={},rankingProof=[];
const recallId='m1-cupra-2026-10-15-government-recall-006687',recallUrl='https://www.vehiclerecalls.gov.au/recalls/rec-006687';
for(const car of after){
 const pack=consumer.pack(car.id,{data,cars:after});packs[car.id]=pack;assert.equal(pack.features.length,69);assert.equal(new Set(pack.features.map(f=>f.criterion)).size,69);observePack(car,pack,'after');
 const frame=frames.get('after\0'+car.id);assert.deepEqual(pack.features,frame.projected);
 for(const feature of pack.features){
  if(feature.criterion==='roadside_assistance'){const f=car.facts.roadside_assistance;assert.equal(feature.value,f.value);assert.equal(feature.buyerGrade,'confirmed');assert.equal(feature.status,'standard');assert.deepEqual(feature.source_ids,f.sourceIds);for(const q of f.qualifications)assert(feature.conditions.includes(q));roadsideProjections++;}
  else{assert.deepEqual(feature,frame.regraded.find(f=>f.criterion===feature.criterion));assert.equal(feature.status,'not_verified');assert.equal(feature.buyerGrade,undefined);}
  const claim=featureClaim(pack,feature.criterion,feature.criterion,packet.reviewedAt);assert(claim);observeClaim(claim,pack,'/feature-claims/'+featureClaims.length+'/claim',()=>featureClaim(pack,feature.criterion,feature.criterion,packet.reviewedAt));featureClaims.push({variantId:car.id,criterion:feature.criterion,claim});
 }
 for(const f of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===packet.id)){assert(hasEarnedBuyerGrade(f,data.sources,packet.reviewedAt));const claim=factClaim(pack,f,packet.reviewedAt);assert.equal(claim.buyerGrade,f.buyerGrade);assert.deepEqual(claim.sources.map(s=>s.id),f.sourceIds);if(f.buyerGrade==='not_published'){assert.equal(f.value,null);assert.equal(claim.value,'Not published');}observeClaim(claim,pack,'/claims/'+claims.length+'/claim',()=>factClaim(pack,f,packet.reviewedAt));claims.push({variantId:car.id,key:f.key,claim});earnedCells++;}
 for(const key of core){const f=car.facts[key];gradeCounts[f.buyerGrade]=(gradeCounts[f.buyerGrade]??0)+1;if(typeof f.value==='number'){const reason=exclusionReason(car,f,data.sources,{asOf:packet.reviewedAt});assert(reason);rankingProof.push({variantId:car.id,key,ranked:false,reason,grade:f.buyerGrade,basis:f.comparisonBasis});}}
 for(const key of ['height_mm',...(car.trim==='MY26 Endurance'?[]:['towing_braked_kg'])]){const f=car.facts[key],claim=factClaim(pack,f,packet.reviewedAt),visible=[claim.sentence,...claim.qualifications].join(' ');assert.equal(f.comparisonBasis,'');assert(f.issues.length);assert(visible.includes('RedBook')&&visible.includes('CarExpert'));if(key==='height_mm')assert(visible.includes('1598')&&visible.includes('1597'));else assert(visible.includes('1200')&&visible.includes(car.trim==='MY26 V'?'1000':'1800'));}
 assert.equal(buyerAvailabilityText(car),'On sale now');assert(isOnSale(car));assert(isCurrentListEligible(car,data.sources,packet.reviewedAt));assert.equal(car.availabilityEvidence.orderStatus,'listed_unconfirmed');assert.equal(car.availabilityEvidence.physicalStockVerified,false);assert.equal(car.availabilityEvidence.factoryOrderAcceptanceVerified,false);
 const av=availabilityReportClaim(car),claim=factClaim(pack,av,packet.reviewedAt);observeClaim(claim,pack,'/availability-claims/'+availabilityClaims.length+'/claim',()=>factClaim(pack,av,packet.reviewedAt));assert(claim.sources.some(s=>s.id===recallId&&s.url===recallUrl));assert(claim.qualifications.some(q=>q.includes('REC-006687')&&q.includes('should not use advanced full beam assist')&&q.includes('free dealer software update')));availabilityClaims.push({variantId:car.id,claim});
}
assert.equal(earnedCells,54);assert.equal(featureClaims.length,207);assert.equal(roadsideProjections,3);assert.deepEqual(gradeCounts,{reported:43,confirmed:6,not_published:2});
const rankCounts={};for(const attr of attributes){const result=rankAttribute(after,data.sources,attr.key,{asOf:packet.reviewedAt});assert.equal(result.groups.length,0);assert.equal(result.excluded.length,3);rankCounts[attr.key]=result;}
const reconciliation=readJson(material+'/cupra-market-reconciliation-v2.json');
const allInventory=require('./src/lib/market-inventory-data.ts').default,isCupra=s=>typeof s==='string'&&s.toUpperCase()==='CUPRA';
const inventory={...allInventory,records:allInventory.records.filter(r=>isCupra(r.brand)),unverifiedLeads:allInventory.unverifiedLeads.filter(r=>isCupra(r.brand))};
assert.deepEqual({records:inventory.records,unverifiedLeads:inventory.unverifiedLeads},readJson('/tmp/cupra-research/inherited-inventory-extract.json'));
const {buildMarketReconciliation}=require('./scripts/reporting/m1-reconciliation.ts');
const c1=buildMarketReconciliation(reconciliation,after,inventory,packet.reviewedAt);assert.equal(c1.pass,false);assert.equal(c1.reviewedModels,0);assert.equal(c1.reviewedVersions,0);assert.deepEqual(c1.reviewedVersionIds,[]);assert.deepEqual(c1.settledInventory,['lead:cupra-born']);
assert.deepEqual(c1.issues.map(i=>i.code),['independent_lists','version_unreviewed','version_unreviewed','version_unreviewed','inventory_unresolved']);
const selectedCoverage=buildCoverageReport({cars:after,sources:data.sources,features:Object.values(packs).flatMap(p=>p.features),inventory,m1Reconciliation:reconciliation},packet.reviewedAt);
assert.equal(selectedCoverage.allCatalogueVersions,3);assert.equal(selectedCoverage.tierOneVersions,3);assert.equal(selectedCoverage.onSaleVersions,3);
const progress=selectedCoverage.brandProgress.find(b=>isCupra(b.brand));assert(progress);assert.equal(progress.currentVersionReviews.length,0);assert.equal(progress.unreviewedCoreGrades,0);assert.equal(progress.missingSummaries,0);assert.equal(progress.criteria.C1,false);
const snapshot=structuredClone(packs),writtenExpected=structuredClone(packs),stored=storePortablePacks(packs);assert.deepEqual(packs,snapshot);assert.deepEqual(hydratePortablePacks(stored,data.sources),packs);
for(const o of observations){const row=writtenExpected[o.variantId].features[o.rowIndex];assert(Object.hasOwn(row,o.property));assert.equal(row[o.property],undefined);delete row[o.property];}
assert.deepEqual(JSON.parse(JSON.stringify(packs)),writtenExpected);assert.deepEqual(hydratePortablePacks(JSON.parse(JSON.stringify(stored)),data.sources),writtenExpected);
for(const [name,obj]of Object.entries({'selected-after-cars':after,'selected-packs':packs,portable:stored,claims,'feature-claims':featureClaims,'availability-claims':availabilityClaims,'undefined-witnesses':observations,'claim-undefined-witnesses':claimOmissions})){
 fs.writeFileSync(out+'/'+name+'.json',JSON.stringify(obj,null,2)+'\n',{flag:'wx'});
}
const written=readJson(out+'/selected-packs.json'),hydrated=hydratePortablePacks(readJson(out+'/portable.json'),data.sources);assert.deepEqual(written,writtenExpected);assert.deepEqual(hydrated,writtenExpected);
for(const row of claims)assert.deepEqual(factClaim(hydrated[row.variantId],after.find(c=>c.id===row.variantId).facts[row.key],packet.reviewedAt),row.claim);
for(const row of featureClaims)assert.deepEqual(featureClaim(hydrated[row.variantId],row.criterion,row.criterion,packet.reviewedAt),row.claim);
for(const row of availabilityClaims)assert.deepEqual(factClaim(hydrated[row.variantId],availabilityReportClaim(after.find(c=>c.id===row.variantId)),packet.reviewedAt),row.claim);
for(const [name,rows]of [['claims',claims],['feature-claims',featureClaims],['availability-claims',availabilityClaims]]){const written=readJson(out+'/'+name+'.json');for(let i=0;i<rows.length;i++){const row=rows[i],pack=packs[row.variantId],car=after.find(c=>c.id===row.variantId),replay=()=>name==='claims'?factClaim(pack,car.facts[row.key],packet.reviewedAt):name==='availability-claims'?factClaim(pack,availabilityReportClaim(car),packet.reviewedAt):featureClaim(pack,row.criterion,row.criterion,packet.reviewedAt);const expected=observeClaim(row.claim,pack,'/'+name+'/'+i+'/claim',replay,false);assert.deepEqual(written[i],{...row,claim:expected});}}
// Actual Detail subtree, actual native-disclosure HTML, and actual citable Markdown.
// Footnote links require client effects; hydrated interactions are not claimed.
const Detail=require('./src/components/detail.tsx').default;
const {EvidenceConditions}=require('./src/components/evidence-conditions.tsx');
const {FootnoteRefs}=require('./src/components/footnotes.tsx');
const {createElement}=require('react'),{renderToStaticMarkup}=require('react-dom/server');
const detailProof=[];
for(const car of after){
 const pack=packs[car.id],nodes=elementNodes(Detail({pack,criteria:data.criteria})),availability=nodes.find(n=>n.type==='section'&&n.props['aria-label']==='Availability evidence');assert(availability);
 const subtree=elementNodes(availability),conditions=subtree.find(n=>n.type===EvidenceConditions),footnote=subtree.find(n=>n.type===FootnoteRefs);assert(conditions&&footnote);
 assert.deepEqual(conditions.props.conditions,car.availabilityEvidence.qualifications);assert.deepEqual(footnote.props.ids,car.availabilityEvidence.sourceIds);assert(footnote.props.ids.includes(recallId));
 const html=renderToStaticMarkup(createElement(EvidenceConditions,conditions.props));for(const part of ['REC-006687','94S9','318','2024–2026','should not use advanced full beam assist','free dealer software update','No candidate vehicle is assumed affected or remedied'])assert(html.includes(part));
 const report=makeReport([pack],'/cars/'+car.family+'/'+car.slug,packet.reviewedAt),markdown=reportMarkdown(report);assert.deepEqual(makeReport([hydrated[car.id]],report.path,packet.reviewedAt),report);assert(markdown.includes(recallUrl)&&markdown.includes('should not use advanced full beam assist')&&markdown.includes('No candidate vehicle is assumed affected or remedied'));
 fs.writeFileSync(out+'/'+car.id+'-availability.html',html+'\n',{flag:'wx'});fs.writeFileSync(out+'/'+car.id+'-report.md',markdown,{flag:'wx'});
 assert.equal(fs.readFileSync(out+'/'+car.id+'-report.md','utf8'),reportMarkdown(makeReport([written[car.id]],report.path,packet.reviewedAt)));
 detailProof.push({variantId:car.id,actualDetailSection:'Availability evidence',actualConditionsComponent:true,completeConditions:conditions.props.conditions,actualFootnoteSourceIds:footnote.props.ids,governmentSource:pack.sources.find(s=>s.id===recallId),disclosureHtmlFile:out+'/'+car.id+'-availability.html',citableMarkdownFile:out+'/'+car.id+'-report.md',writtenHydratedReportExact:true,hydratedFootnoteInteractionTested:false});
}
assert.equal(defaultCalls,0);for(const f of ['src/lib/data.ts','src/lib/catalogue.ts','src/lib/research.ts'])assert(!require.cache[repo+'/'+f]);
assert.deepEqual(base,baseSnapshot);assert.deepEqual(before,beforeSnapshot);assert.deepEqual(data,dataSnapshot);assert.deepEqual(after,afterSnapshot);assert.deepEqual(packet,packetSnapshot);assert.deepEqual(packs,snapshot);checkPins();
const result={status:'selected_actual_consumers_and_exact_serialization_witness_pass',packetSha256:fileHash(packetPath),beforeCars:0,afterCars:3,newModels:1,coreCells:51,coreGradeCounts:gradeCounts,earnedPacketCells:earnedCells,selectedFeatureClaims:207,roadsideCanonicalProjections:3,expectedOnSaleDelta:3,readInputs:reads,registeredContextComposition:contextComposition,generatedOnlySelectedFeatures:true,currentListProof:c1,selectedCoverage,rankingProof,rankCounts,producerProofs,detailProof,optionalFeaturePaths:observations,optionalCitationPaths:claimOmissions,inMemoryPortableExact:true,writtenPortableExact:true,writtenClaimReadback:true,livePacksUnchanged:true,productionCatalogueHydration:false,defaultLoaderCalls:defaultCalls,sourceEdits:false,fullProjectTypeScript:'UNPASSED; no compiler retry',hydratedBrowserInteractionsTested:false};
assert.deepEqual(buildMarketReconciliation(reconciliation,after,inventory,packet.reviewedAt),c1);assert.deepEqual(selectedCoverage.reconciliation,c1);
const resultSnapshot=structuredClone(result),resultWritten=structuredClone(result),reportOmissions=[];
function reportShape(value,path,clone,parent){
 if(value===undefined){
  assert(/\/(brand|reference)$/.test(path),'Unexpected report undefined '+path);assert.deepEqual(parent,c1.issues[0]);assert.equal(parent.code,'independent_lists');
  const property=path.split('/').at(-1),d=Object.getOwnPropertyDescriptor(parent,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);
  reportOmissions.push({pointer:path,property,ownUndefined:true,enumerable:true,producer:'Actual buildMarketReconciliation independent_lists issue via add(code, reason), no brand/reference arguments'});return;
 }
 if(!value||typeof value!=='object')return;
 for(const key of Object.keys(value)){reportShape(value[key],path+'/'+key.replaceAll('~','~0').replaceAll('/','~1'),clone?.[key],value);if(value[key]===undefined)delete clone[key];}
}
reportShape(result,'/result',resultWritten,null);assertDeclaredJson(result,'/result',new Set(reportOmissions.map(x=>x.pointer)));assert.deepEqual(JSON.parse(JSON.stringify(result)),resultWritten);assert.deepEqual(result,resultSnapshot);
fs.writeFileSync(out+'/report-undefined-witnesses.json',JSON.stringify(reportOmissions,null,2)+'\n',{flag:'wx'});fs.writeFileSync(out+'/result.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});assert.deepEqual(readJson(out+'/result.json'),resultWritten);
console.log(JSON.stringify({status:result.status,result:out+'/result.json',sha256:fileHash(out+'/result.json')}));
'''
with (O/'check.mjs').open('x') as f:f.write(header+functions+body)
