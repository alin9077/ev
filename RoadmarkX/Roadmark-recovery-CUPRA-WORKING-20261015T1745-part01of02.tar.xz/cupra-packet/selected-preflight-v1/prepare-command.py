from pathlib import Path
import json,hashlib,re
O=Path('/tmp/cupra-packet/selected-preflight-v1');M=Path('/tmp/cupra-packet/typed-preparation-v4');R=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def write(name,x):
 with (O/name).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
files={Path(x['path']) for x in json.loads((M/'source-pins.json').read_text())}
for x in json.loads(Path('/tmp/kgm-packet/selected-preflight-v2/source-pins.json').read_text()):
 p=Path(x['path'])
 if str(p).startswith(str(R)) or str(p).startswith(('/tmp/xpeng-staging-plan/','/tmp/mercedes-staging-plan/')):files.add(p)
files.update(O.glob('*'));files.update((M/'output').glob('*'));files.update((M/'run').glob('*'));files.update([M/'source-pins.json',M/'prepared-command.json',M/'root-execution-grant.json'])
files.add(Path('/tmp/cupra-research/inherited-inventory-extract.json'))
for p in Path('/tmp/cupra-review').glob('*'):
 if p.is_file() and p.suffix in ['.json','.md']:files.add(p)
registry=json.loads((R/'data/m1-brand-updates/registry.json').read_text());assert len(registry['packets'])==28
for f in registry['packets']:files.add(R/'data/m1-brand-updates'/f)
files.update(R/p for p in ['src/lib/evidence-consumers.ts','src/lib/evidence-regrading.ts','src/lib/launch-evidence.ts','src/lib/portable-packs.ts','src/lib/citable.ts','src/lib/discovery.ts','src/lib/market-inventory-data.ts','scripts/reporting/reports.ts','scripts/reporting/m1-reconciliation.ts','tests/helpers/compiled-source.ts','src/components/detail.tsx','src/components/evidence-conditions.tsx','src/components/footnotes.tsx','src/lib/brand-update-registry.ts','tsconfig.json','data/m1-evidence-regrading-2026-10-13.json','package.json','pnpm-lock.yaml'])
anchorsPath=Path('/tmp/mercedes-staging-plan/consumer-preparation/v5/manifests/report-v5.json');storagePath=Path('/tmp/mercedes-staging-plan/staging-preparation/staging-artifacts/canonical-v1/staged-storage-index.json')
files.update([anchorsPath,storagePath]);anchors=json.loads(anchorsPath.read_text())['anchors'];storage=json.loads(storagePath.read_text())
assert len(storage['research'])==14
for ref in storage['research'].values():
 root=Path(anchors[ref['anchor']]);p=root/ref['file'];assert p.resolve()==p and p.is_file() and p.is_relative_to(root)
 actual=pin(p);assert actual['bytes']==ref['bytes'] and actual['sha256']==ref['sha256'];files.add(p)
# Static dependency closure includes repository aliases and createRequire(repo) calls.
queue=[p for p in files if p.suffix in ['.ts','.tsx','.mts','.mjs'] and (str(p).startswith(str(R)) or p.parent==O)];seen=set()
while queue:
 p=queue.pop()
 if p in seen:continue
 seen.add(p)
 for spec in re.findall(r'''(?:from\s*|import\s*\(?\s*|require\(\s*)["']([^"']+)["']''',p.read_text()):
  if spec.startswith('@/'):root=R/'src'/spec[2:]
  elif spec.startswith('./src/') and p.parent==O:root=R/spec
  elif spec.startswith('./tests/') and p.parent==O:root=R/spec
  elif spec.startswith('./scripts/') and p.parent==O:root=R/spec
  elif spec.startswith('.'):root=(p.parent/spec).resolve()
  elif spec.startswith('/'):root=Path(spec)
  else:continue
  choices=[root,Path(str(root)+'.ts'),Path(str(root)+'.tsx'),Path(str(root)+'.json'),root/'index.ts']
  hit=next((x for x in choices if x.is_file()),None)
  if hit:
   files.add(hit)
   if hit.suffix in ['.ts','.tsx','.mts','.mjs']:queue.append(hit)
# Earlier accepted pins may contain loader definitions, but selected runtime forbids
# loading them and never calls a default data/catalogue function.
write('source-pins.json',[pin(p) for p in sorted(files)])
m=dict(status='prepared_not_executed',script=pin(O/'check.mjs'),sourcePins=pin(O/'source-pins.json'),packet=pin(M/'output/cupra-2026-10-15-candidate-v1.json'),reconciliation=pin(M/'cupra-market-reconciliation-v2.json'),readinessReview=pin(O/'readiness-review.json'),wrapper=pin(O/'run.py'),command=['node','--max-old-space-size=448','--max-semi-space-size=1','--import','tsx',str(O/'check.mjs'),'--root-execution-granted'],workdir=str(R),timeoutSeconds=180,killGraceSeconds=10,automaticRetry=False,rootExecutionGrantRequired=True,exclusiveHeavySlotRequired=True,scope='Exactly three actual additions from the retained zero-row CUPRA baseline. Real global evidence context from 14 pinned retained research storage descriptors, all 28 registered source/model snapshots, actual addition producers, 45 specific plus 9 term guards, 207 effective feature/citable rows, compatible rank exclusions, exact summary dependencies and source-labelled towing/height conflicts. Actual Detail recall disclosure/FootnoteRefs property proof, native disclosure HTML and citable Markdown; no hydrated-browser claim. Actual live/portable/written/hydrated pack and claim equality with exact producer-owned optional-property witnesses. C1 stays open with Tavascan unresolved and Born excluded. No full catalogue, tsc, live edits, registration, build, server, browser or automatic retry.',currentProjectTypeScript='UNPASSED; no retry')
write('prepared-command.json',m)
write('root-grant-template.json',dict(authorized=False,exclusiveHeavySlotGranted=False,action='run_single_selected_cupra_preflight',preparedManifestSha256=pin(O/'prepared-command.json')['sha256'],command=m['command'],automaticRetry=False,note='Template only. Independent readiness review and root exclusive-slot grant required.'))
print(json.dumps(dict(manifest=pin(O/'prepared-command.json'),sourcePinCount=len(files),executed=False),indent=2))
