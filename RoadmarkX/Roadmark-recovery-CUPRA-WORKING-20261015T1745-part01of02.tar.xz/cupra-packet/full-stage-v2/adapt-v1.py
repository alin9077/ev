from pathlib import Path
import json,hashlib
A=Path('/tmp/cupra-packet/full-stage-v1');B=Path('/tmp/cupra-packet/full-stage-v2')
def pin(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
m=json.loads((A/'manifest.json').read_text())
for p in m['pins']:assert pin(p['path'])==p
assert not (A/'run').exists() and not (A/'output').exists()
s=(A/'stage.mjs').read_text();assert s.count('const progress=selectedCoverage.brandProgress.find')==1
s=s.replace('const progress=selectedCoverage.brandProgress.find','const selectedBrandProgress=selectedCoverage.brandProgress.find').replace('assert(progress);','assert(selectedBrandProgress);').replace('progress.currentVersionReviews','selectedBrandProgress.currentVersionReviews').replace('progress.unreviewedCoreGrades','selectedBrandProgress.unreviewedCoreGrades').replace('progress.missingSummaries','selectedBrandProgress.missingSummaries').replace('progress.criteria','selectedBrandProgress.criteria')
needle='const globalRankProof=[];'
insert=r'''const alphabeticalSource='unranked.sort((a, b) =>\n    `${a.car.brand} ${a.car.model} ${a.car.trim}`.localeCompare(\n      `${b.car.brand} ${b.car.model} ${b.car.trim}`,\n    ),\n  );';
assert.equal(discoverySource.split(alphabeticalSource).length,2,'Unique production unranked alphabetical comparator');
const alphabetical=(a,b)=>`${a.car.brand} ${a.car.model} ${a.car.trim}`.localeCompare(`${b.car.brand} ${b.car.model} ${b.car.trim}`);
function rankingRecords(ranking,digests){
 const byId=new Map(digests.map(row=>[row.id,row]));
 function entryRecord(entry){const {car,...fields}=entry;const digest=byId.get(car.id);assert(digest);assert.deepEqual({id:car.id,...digestRows([car])},digest);return {carId:car.id,carDigest:{...digest},...fields};}
 return {groups:ranking.groups.map(group=>({...group,entries:group.entries.map(entryRecord)})),excluded:ranking.excluded.map(row=>{const digest=byId.get(row.carId);assert(digest);return {...row,carDigest:{...digest}};}),unranked:ranking.unranked.map(entryRecord)};
}
const globalRankProof=[];'''
assert s.count(needle)==1;s=s.replace(needle,insert)
needle=" const a=groupProof(old,currentCars,attribute),b=groupProof(next,cars,attribute),aBy=new Map(a.groups.map(group=>[group.key,group])),bBy=new Map(b.groups.map(group=>[group.key,group]));"
insert=r''' const selectedRanking=rankAttribute(after,data.sources,attribute.key,policy);assert.deepEqual(selectedRanking.groups,[]);assert.equal(selectedRanking.excluded.length,3);
 assert.deepEqual(next.groups,old.groups,'Complete ordered compatible groups must remain exact');
 const expectedExcluded=[...old.excluded,...selectedRanking.excluded];assert.deepEqual(next.excluded,expectedExcluded,'Complete ordered exclusion records');
 const expectedUnranked=[...old.unranked,...selectedRanking.unranked].sort(alphabetical);assert.deepEqual(next.unranked,expectedUnranked,'Complete alphabetical unranked records');
 const beforeRecords=rankingRecords(old,currentDigests),afterRecords=rankingRecords(next,candidateDigests),selectedRecords=rankingRecords(selectedRanking,candidateDigests);
 assertDeclaredJson(beforeRecords,'/beforeRankingRecords',new Set());assertDeclaredJson(afterRecords,'/afterRankingRecords',new Set());assertDeclaredJson(selectedRecords,'/selectedRankingRecords',new Set());
 const a=groupProof(old,currentCars,attribute),b=groupProof(next,cars,attribute),aBy=new Map(a.groups.map(group=>[group.key,group])),bBy=new Map(b.groups.map(group=>[group.key,group]));'''
assert s.count(needle)==1;s=s.replace(needle,insert)
needle='globalRankProof.push({attribute:attribute.key,before:a,after:b,'
replacement='globalRankProof.push({attribute:attribute.key,completeOrderedBefore:beforeRecords,completeOrderedAfter:afterRecords,completeSelectedRecords:selectedRecords,fullGroupsExact:true,fullExcludedEqualsOldPlusSelected:true,fullUnrankedEqualsAlphabeticalOldPlusSelected:true,productionAlphabeticalComparator:alphabeticalSource,fullCarDigestBindingsVerified:true,before:a,after:b,'
assert s.count(needle)==1;s=s.replace(needle,replacement)
with (B/'stage.mjs').open('x') as f:f.write(s)
for name in ['run.py','storage-read-closure.json']:
 with (B/name).open('xb') as f:f.write((A/name).read_bytes())
plan=(A/'PLAN.md').read_text().replace('# CUPRA29 bounded full-stage plan','# CUPRA29 bounded full-stage plan v2')
plan+='\n## Preserved preparation correction\n\nV1 is preserved and was never executed. It composed an accepted KGM full-stage base with the accepted CUPRA selected harness, reintroducing a duplicate `progress` binding during composition. V2 renames only the selected brand-progress value, and adds complete ranking-record closure: exact unchanged groups, ordered old-plus-selected exclusions, and old-plus-selected unranked records sorted by the verified production alphabetical comparator. Saved structures retain every group and full fact/rank/tie/reason field. Only repeated Car objects are represented by exact id plus independently proved full-car digest. A root-authorized, 10-second/64 MiB Node syntax-only check runs without imports or stage execution before this preparation is frozen; it is not a TypeScript or runtime validation pass.\n'
with (B/'PLAN.md').open('x') as f:f.write(plan)
prep=(A/'prepare-manifest.py').read_text().replace("O=Path('/tmp/cupra-packet/full-stage-v1')","O=Path('/tmp/cupra-packet/full-stage-v2')")
prep=prep.replace("files.update(O.glob('*'));", "files.update(O.glob('*'));files.update(Path('/tmp/cupra-packet/full-stage-v1').glob('*'));" )
# The final manifest captures the independently authorized syntax-only receipt.
prep=prep.replace("old=json.loads((K/'manifest.json').read_text());", "syntax=json.loads((O/'syntax-only-check.json').read_text());assert syntax['exitCode']==0 and syntax['runtimeExecuted'] is False and syntax['typescriptCompilerAttempted'] is False\nold=json.loads((K/'manifest.json').read_text());")
with (B/'prepare-manifest.py').open('x') as f:f.write(prep)
with (B/'v1-to-v2-provenance.json').open('x') as f:json.dump(dict(status='v1_preserved_unexecuted_preparation',v1Manifest=pin(A/'manifest.json'),v1PinsStillPass=377,v1RunOrOutputExists=False,lineage='Accepted KGM full-stage v1 plus accepted CUPRA selected preflight v1. The duplicate progress binding was reintroduced during composition; no held predecessor was used as an accepted runtime base.',changes=['Rename selected brand-progress binding to avoid collision with the actual progress logger.','Add complete ordered ranking groups, exclusions and unranked expected-array equality; retain full Fact/rank/tie/reason records with exact full-car digest bindings instead of repeated Car objects.','Add separately root-authorized bounded syntax-only preparation check.'],candidateOrProductionDataChanged=False,typescriptStatus='UNPASSED; no compiler retry'),f,indent=2);f.write('\n')
