from pathlib import Path
import json,hashlib,re
O=Path('/tmp/cupra-packet/full-stage-v2');R=Path('/workspace/scratch/586427eef9f2/roadmark-104');S=Path('/tmp/cupra-packet/selected-preflight-v1');M=Path('/tmp/cupra-packet/typed-preparation-v4');K=Path('/tmp/kgm-packet/full-stage-v1')
def pin(path):
 path=Path(path);h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return dict(path=str(path),bytes=path.stat().st_size,sha256=h.hexdigest())
def write(name,value):
 with (O/name).open('x') as f:f.write(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
syntax=json.loads((O/'syntax-only-check.json').read_text());assert syntax['exitCode']==0 and syntax['runtimeExecuted'] is False and syntax['typescriptCompilerAttempted'] is False
old=json.loads((K/'manifest.json').read_text());registry=json.loads((R/'data/m1-brand-updates/registry.json').read_text());ids=['m1-'+name.removesuffix('.json') for name in registry['packets']];assert len(ids)==28 and ids[-1]=='m1-kgm-2026-10-15'
packet=json.loads((M/'output/cupra-2026-10-15-candidate-v1.json').read_text());result=json.loads((S/'result.json').read_text());assert result['status']=='selected_actual_consumers_and_exact_serialization_witness_pass'
review=Path('/tmp/cupra-review/selected-preflight-v1-result-accepted.json');assert json.loads(review.read_text())['resultSha256']==pin(S/'result.json')['sha256']
files={Path(p['path']) for p in json.loads((S/'source-pins.json').read_text())}
files.update(Path(p['path']) for p in old['pins'] if p['path'].startswith(str(R)) or p['path'].startswith(('/tmp/mercedes-staging-plan/','/tmp/xpeng-staging-plan/')))
refs=dict(acceptedManifest=old['acceptedManifest'],storageClosure=pin(O/'storage-read-closure.json'),packet=pin(M/'output/cupra-2026-10-15-candidate-v1.json'),reconciliation=pin(M/'cupra-market-reconciliation-v2.json'),admissionAudit=pin(M/'admission-audit-v2.json'),selectedBefore=pin('/tmp/cupra-research/retained-before-cars.json'),selectedAfter=pin(S/'selected-after-cars.json'),selectedResult=pin(S/'result.json'),selectedTerminal=pin(S/'run/terminal.json'),selectedReadiness=pin('/tmp/cupra-review/selected-preflight-v1-readiness.json'),selectedOutputReview=pin(review),acceptedKgmCars=pin(K/'output/car-digest-comparison.json'),acceptedKgmFields=pin(K/'output/research-field-digests.json'),acceptedKgmC1=pin(K/'output/global-c1-comparison.json'),acceptedKgmReceipt=pin(K/'output/stage-receipt.json'),acceptedKgmTerminal=pin(K/'run/terminal.json'),acceptedNormalReport=pin('/tmp/kgm-packet/report-comparison-v2/normal-coverage-asof-2026-10-15/stdout.log'),acceptedNormalTerminal=pin('/tmp/kgm-packet/report-comparison-v2/normal-coverage-asof-2026-10-15/terminal.json'),script=pin(O/'stage.mjs'),wrapper=pin(O/'run.py'))
names=[n+'.json' for n in ['selected-after-cars','selected-packs','portable','claims','feature-claims','availability-claims','undefined-witnesses','claim-undefined-witnesses','report-undefined-witnesses']]+[v['id']+suffix for v in packet['variants'] for suffix in ['-availability.html','-report.md']]
artifacts={name:pin(S/name) for name in names}
reconciliationPaths=[(R/'scripts/reporting'/name).resolve() for name in re.findall(r'import \w+ from "(\.\./\.\./data/m1-[^"]+\.json)";',(R/'scripts/reporting/load.ts').read_text())];assert len(reconciliationPaths)==28
reconciliationInputs=[pin(p) for p in reconciliationPaths];rawInputs=[pin(p['path']) for p in old['rawOverlayInputs']]
files.update(Path(p['path']) for p in [*refs.values(),*artifacts.values(),*reconciliationInputs,*rawInputs]);files.update(O.glob('*'));files.update(Path('/tmp/cupra-packet/full-stage-v1').glob('*'));files.update([R/'scripts/reporting/load.ts',S/'run/after-pins.json',S/'prepared-command.json',S/'source-pins.json',S/'selected-result-manifest-v1.json',Path('/tmp/kgm-review/full-stage-v1-output-review.json'),Path('/tmp/kgm-review/report-comparison-v2-output-review.json')])
files.update(R/'data/m1-brand-updates'/name for name in registry['packets'])
closure=json.loads((O/'storage-read-closure.json').read_text());assert len(closure)==21
accepted=json.loads(Path(old['acceptedManifest']['path']).read_text());acceptedPins={(str((Path(accepted['anchors'][row['anchor']])/row['file']).resolve()),row['bytes'],row['sha256']) for row in accepted['inputPins']}
for row in closure:
 assert pin(row['path'])==row;assert (row['path'],row['bytes'],row['sha256']) in acceptedPins;files.add(Path(row['path']))
queue=[p for p in files if p.suffix in ['.ts','.tsx','.mts','.mjs'] and (str(p).startswith(str(R)) or p.parent==O)];seen=set()
while queue:
 p=queue.pop()
 if p in seen:continue
 seen.add(p)
 for spec in re.findall(r'''(?:from\s*|import\s*\(?\s*|require\(\s*)["']([^"']+)["']''',p.read_text()):
  if spec.startswith('@/'):root=R/'src'/spec[2:]
  elif spec.startswith(('./src/','./tests/','./scripts/')) and p.parent==O:root=R/spec
  elif spec.startswith('.'):root=(p.parent/spec).resolve()
  elif spec.startswith('/'):root=Path(spec)
  else:continue
  hit=next((f for f in [root,Path(str(root)+'.ts'),Path(str(root)+'.tsx'),Path(str(root)+'.json'),root/'index.ts'] if f.is_file()),None)
  if hit:
   files.add(hit)
   if hit.suffix in ['.ts','.tsx','.mts','.mjs']:queue.append(hit)
m=dict(schemaVersion=1,status='frozen_pending_independent_command_review_and_root_execution_grant',mode='derived-prefix20-through-KGM28-then-CUPRA29-no-broad-features',asOf='2026-10-15',repo=str(R),nodeVersion='v24.19.0',execArgv=['--max-old-space-size=448','--max-semi-space-size=1','--expose-gc','--import','tsx'],timeoutSeconds=420,killAfterSeconds=10,automaticRetry=False,productionRegistrationAuthorized=False,canonicalRecaptureAuthorized=False,normalFullReportInStage=False,rootExecutionGrantRequired=True,exclusiveHeavySlotRequired=True,**refs,selectedArtifacts=artifacts,storageIndex=old['storageIndex'],registeredPacketIds=ids,selectedIds=[v['id'] for v in packet['variants']],rawOverlayInputs=rawInputs,reconciliationInputs=reconciliationInputs,output=str(O/'output'),runOutput=str(O/'run'),expected=dict(beforeCatalogue=427,afterCatalogue=430,beforeTierOne=350,afterTierOne=353,beforeOnSale=309,afterOnSale=312,beforePackets=28,afterPackets=29,changedRetainedCars=0,unchangedPeers=427,newModels=1,newVersions=3,sourcesAdded=16,specificFacts=45,termCells=9,coreCells=51,earnedCells=54,selectedFeatureClaims=207,currentOfficialListReviewsAdded=0,settledInventoryLeads=1,unresolvedInventoryRecords=1,globalReviewedModels=103,globalReviewedVersions=234,globalC1Complete=False),pins=[pin(p) for p in sorted(files)],scope='Restore retained409 prefix20 once; reproduce every accepted complete-car/all14-field digest through KGM28 before adding CUPRA29. No helper changes. Exactly three selected packs, 54 fact/term claims, 207 feature claims, VIN-scoped recall disclosure/citation outputs and exact live/written ownership. Global complete ranking and expected C1 structures; all 427 existing cars/variants and research prefixes unchanged. Expected430/353/312 counts require actual eligibility assertions. No broad feature replay, normal report, production loader, live edit, registration, canonical recapture, compiler retry, server, browser or automatic retry. One later normal report after separately guarded integration remains required.')
write('manifest.json',m);h=pin(O/'manifest.json')['sha256'];command=['node',*m['execArgv'],m['script']['path'],'--manifest',str(O/'manifest.json'),'--manifest-sha256',h]
write('root-grant-template.json',dict(authorized=False,exclusiveHeavySlotGranted=False,action='run_single_bounded_cupra_full_stage',preparedManifestSha256=h,command=command,automaticRetry=False,note='Template only; explicit root grant and exclusive heavy slot required.'))
print(json.dumps(dict(manifest=pin(O/'manifest.json'),script=refs['script'],wrapper=refs['wrapper'],pins=len(files),reconciliationInputs=len(reconciliationInputs),executed=False),indent=2))
