from pathlib import Path
import difflib
old=Path('/tmp/kgm-packet/report-comparison-v2/compare-report.mjs').read_text();s=old
s=s.replace('One saved normal report versus accepted MINI27; exact core reasons and selected-only features.','One saved normal report versus accepted KGM28; exact core reasons and zero-row CUPRA baseline.')
s=s.replace("const prep='/tmp/kgm-packet/report-comparison-v2';","const prep='/tmp/cupra-packet/report-comparison-v1';").replace("const qa='/tmp/kgm-packet/report-comparison-v2';","const qa='/tmp/cupra-packet/report-comparison-v1';")
s=s.replace("const baselinePath='/tmp/mini-packet/report-comparison-v2/normal-coverage-asof-2026-10-15/stdout.log';","const baselinePath='/tmp/kgm-packet/report-comparison-v2/normal-coverage-asof-2026-10-15/stdout.log';")
s=s.replace('0cd717ad3b1db049e14559010770b9b5dfb1e9ed05718ca7635d82a6bbde4464','ec789547ae84ecf1bcec0953c08df124ef0cbbe3c54b19c314e4f117b4bea339').replace('exhaustive-normal-versus-mini-diff','exhaustive-normal-versus-kgm-diff')
s=s.replace('/tmp/kgm-packet/selected-preflight-v2/result.json','/tmp/cupra-packet/selected-preflight-v1/result.json').replace('/tmp/kgm-research/retained-before-cars.json','/tmp/cupra-research/retained-before-cars.json').replace('/tmp/kgm-packet/full-stage-v1/','/tmp/cupra-packet/full-stage-v2/')
s=s.replace("const selectedIds=new Set(before.map(c=>c.id)),modelIds=new Set(before.map(c=>c.modelId));\nassert.equal(selectedIds.size,3);assert.equal(selectedResult.otherRetainedFeaturesUnchanged,true);","const selectedIds=new Set(after.map(c=>c.id)),modelIds=new Set(after.map(c=>c.modelId));\nassert.deepEqual(before,[]);assert.equal(selectedResult.beforeCars,0);assert.equal(selectedResult.afterCars,3);assert.equal(selectedIds.size,3);assert.equal(selectedResult.selectedFeatureClaims,207);\nassert.equal(fileHash('/tmp/cupra-research/retained-before-cars.json'),'37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570');")
s=s.replace("const acceptedMiniDigests=readJson('/tmp/mini-packet/full-stage-v2/output/car-digest-comparison.json');\nassert.deepStrictEqual(acceptedStageDigests.candidate27,acceptedMiniDigests.candidate27);\nassert.equal(acceptedStageDigests.candidate28.length,427);\nconst oldPeerDigests=acceptedStageDigests.candidate27.filter(c=>!selectedIds.has(c.id)),newPeerDigests=acceptedStageDigests.candidate28.filter(c=>!selectedIds.has(c.id));\nassert.equal(oldPeerDigests.length,424);assert.deepStrictEqual(newPeerDigests,oldPeerDigests);\nwrite('accepted-peer-car-value-and-basis-proof',{exactCompletePeerCars:424,allPeerValuesBasesUnitsGradesAndIdentitiesUnchanged:true,peers:newPeerDigests});", "const acceptedKgmDigests=readJson('/tmp/kgm-packet/full-stage-v1/output/car-digest-comparison.json');\nassert.deepStrictEqual(acceptedStageDigests.candidate28,acceptedKgmDigests.candidate28);\nassert.equal(acceptedStageDigests.candidate29.length,430);\nconst oldPeerDigests=acceptedStageDigests.candidate28,newPeerDigests=acceptedStageDigests.candidate29.filter(c=>!selectedIds.has(c.id));\nassert.equal(oldPeerDigests.length,427);assert.deepStrictEqual(newPeerDigests,oldPeerDigests);\nwrite('accepted-peer-car-value-and-basis-proof',{exactCompletePeerCars:427,allPeerValuesBasesUnitsGradesAndIdentitiesUnchanged:true,peers:newPeerDigests});")
s=s.replace('acceptedMiniDigests','acceptedKgmDigests').replace('assert.equal(base.variants.length,3);assert.equal(base.feature_evidence.length,207);','assert.equal(base.variants.length,0);assert.equal(base.feature_evidence.length,0);assert.equal(base.models.length,0);assert.equal(base.trim_equipment.length,0);assert.equal(base.feature_evidence_variant_context.length,0);')
s=s.replace("assert.equal(brandUpdatePackets.length,28);assert.equal(brandUpdatePackets.at(-1).id,'m1-kgm-2026-10-15');","assert.equal(brandUpdatePackets.length,29);assert.equal(brandUpdatePackets.at(-1).id,'m1-cupra-2026-10-15');")
s=s.replace('const priorPackets=brandUpdatePackets.slice(0,27)','const priorPackets=brandUpdatePackets.slice(0,28)')
s=s.replace("readJson('/tmp/mini-packet/full-stage-v2/output/research-field-digests.json').candidate27.sources","readJson('/tmp/kgm-packet/full-stage-v1/output/research-field-digests.json').candidate28.sources")
s=s.replace(" ['candidate27','/tmp/mini-packet/full-stage-v2/output/selected-after-cars.json'],"," ['candidate27','/tmp/mini-packet/full-stage-v2/output/selected-after-cars.json'],\n ['candidate28','/tmp/kgm-packet/full-stage-v1/output/selected-after-cars.json'],")
s=s.replace("const afterMap=new Map(after.map(car=>[car.id,car])),completeAfter=completeBefore.map(car=>afterMap.get(car.id)??car);","const existingIds=new Set(completeBefore.map(car=>car.id));assert(after.every(car=>!existingIds.has(car.id)));\nconst completeAfter=[...completeBefore,...after];")
s=s.replace('acceptedStageDigests.candidate28);\nconst beforeSourceSnapshot','acceptedStageDigests.candidate29);\nconst beforeSourceSnapshot')
s=s.replace("readJson('/tmp/cupra-packet/full-stage-v2/output/research-field-digests.json').candidate28.sources","readJson('/tmp/cupra-packet/full-stage-v2/output/research-field-digests.json').candidate29.sources")
a=s.index("const {compiledSource}=require('./tests/helpers/compiled-source.ts');");b=s.index("const peer=(rows,key='carId')",a)
zero="""const reports=compile(repo+'/scripts/reporting/reports.ts','scripts/reporting/reports.ts',{},'\\nexport { coreFact, gradePattern, coreCoverage };\\n');
const inventory=require('./src/lib/market-inventory-data.ts').default;
const {inventoryRecordId}=require('./scripts/reporting/m1-reconciliation.ts');
const cupraInventory={...inventory,records:inventory.records.filter(r=>r.brand==='CUPRA'),unverifiedLeads:inventory.unverifiedLeads.filter(r=>r.brand==='CUPRA')};
const emptyRegistry={schemaVersion:1,checkedAt:'2026-10-15',notes:[],publishedLists:[],currentVersionReviews:[],listResolutions:[],catalogueOnlyDifferences:[],inventoryResolutions:[]};
// Real zero-row controls. Its global empty-catalogue warning is NOT substituted for the prior global brand object.
const selectedBefore=reports.buildCoverageReport({cars:before,sources:base.sources,features:[],inventory:cupraInventory,m1Reconciliation:emptyRegistry},normal.asOf);
const selectedBeforeSnapshot=structuredClone(selectedBefore),oldCupra=baseline.brandProgress.find(b=>b.brand==='CUPRA');
assert.deepStrictEqual(selectedBefore.core,oldCupra.core);
assert.equal(selectedBefore.allCatalogueVersions,0);assert.equal(selectedBefore.tierOneVersions,0);assert.equal(selectedBefore.onSaleVersions,0);
assert.equal(selectedBefore.pairedOnSale,0);assert.deepEqual(selectedBefore.summaryGaps,[]);assert.deepEqual(selectedBefore.gaps,[]);
assert.deepEqual(selectedBefore.ageing,{overdue:[],invalid:[],dueNext30Days:0,excludedHistory:[]});
assert(selectedBefore.reconciliation.issues.some(row=>row.code==='empty_catalogue'));
assert(!oldCupra.closureIssues.some(row=>row.code==='empty_catalogue'));
const zeroControls={beforeCars:before,core:selectedBefore.core,gaps:selectedBefore.gaps,pairedOnSale:selectedBefore.pairedOnSale,summaryGaps:selectedBefore.summaryGaps,ageing:selectedBefore.ageing,beforeRawVariants:base.variants.length,beforeRawFeatures:base.feature_evidence.length,oldFeaturesReplayed:0,globalEmptyCatalogueWarningNotSubstituted:true};
assertDeclaredJson(zeroControls,'/zeroControls',new Set());write('selected-zero-row-controls',zeroControls);assert.deepEqual(readJson(out+'/selected-zero-row-controls.json'),zeroControls);
write('selected-freshness-producer-proof',{reads,before:selectedBefore.ageing,after:selectedAfter.ageing,acceptedSelectedResult:'/tmp/cupra-packet/selected-preflight-v1/result.json',acceptedProducerProofs:selectedResult.producerProofs,optionalFeaturePaths:selectedResult.optionalFeaturePaths,selectedEffectiveFeaturesReplayed:0,peerFeaturesReplayed:0});
"""
s=s[:a]+zero+s[b:]
s=s.replace('new Map(completeBefore.map((car,index)=>[car.id,index]))','new Map(completeAfter.map((car,index)=>[car.id,index]))')
s=s.replace('assert.equal(catalogueOrder.size,427);assert.deepStrictEqual(completeAfter.map(car=>car.id),completeBefore.map(car=>car.id));','assert.equal(catalogueOrder.size,430);assert.deepStrictEqual(completeAfter.slice(0,427).map(car=>car.id),completeBefore.map(car=>car.id));')
s=s.replace('// Each already accepted same-car subsequence is preserved by stable sort; peer and KGM identities are disjoint.','// Each accepted same-car subsequence is preserved by stable sort; peer and CUPRA identities are disjoint.')
s=s.replace('assert.deepEqual([normal.allCatalogueVersions,normal.tierOneVersions,normal.onSaleVersions],[427,350,309]);','assert.deepEqual([normal.allCatalogueVersions,normal.tierOneVersions,normal.onSaleVersions],[430,353,312]);\nexpected.allCatalogueVersions=430;expected.tierOneVersions=353;expected.onSaleVersions=312;')
s=s.replace("b.brand!=='KGM'","b.brand!=='CUPRA'").replace("b.brand==='KGM'","b.brand==='CUPRA'").replace('newKgm','newCupra')
s=s.replace('assert.equal(onSaleBefore.length,309);assert.equal(onSaleAfter.length,309);','assert.equal(onSaleBefore.length,309);assert.equal(onSaleAfter.length,312);')
s=s.replace('assert.equal(next.total,old.total);','assert.equal(next.total,old.total+3);')
a=s.index('const groupKey=g=>JSON.stringify');b=s.index("assert.deepStrictEqual(peer(normal.gaps)",a)
ranks="""const groupKey=g=>JSON.stringify([g.vehicleClass,g.basis,g.unit]);
const discoveryPath=repo+'/src/lib/discovery.ts',discoverySource=fs.readFileSync(discoveryPath,'utf8');
const comparatorText='(a, b) =>\\n        b.entries.length - a.entries.length || a.basis.localeCompare(b.basis)';
assert.equal(discoverySource.split(comparatorText).length,2);
const groupOrder=vm.runInThisContext('('+comparatorText+')',{filename:discoveryPath+':actual-group-order-excerpt'});
const stageRankings=readJson('/tmp/cupra-packet/full-stage-v2/output/global-ranking-comparison.json');
const completeCarMap=new Map(completeAfter.map(car=>[car.id,car])),digestMap=new Map(acceptedStageDigests.candidate29.map(row=>[row.id,row]));
const alphabeticalSource='unranked.sort((a, b) =>\\n    `${a.car.brand} ${a.car.model} ${a.car.trim}`.localeCompare(\\n      `${b.car.brand} ${b.car.model} ${b.car.trim}`,\\n    ),\\n  );';
assert.equal(discoverySource.split(alphabeticalSource).length,2);
const alphabetical=(a,b)=>{const ac=completeCarMap.get(a.carId),bc=completeCarMap.get(b.carId);return `${ac.brand} ${ac.model} ${ac.trim}`.localeCompare(`${bc.brand} ${bc.model} ${bc.trim}`);};
const rankingBindings=[];
for(const stage of stageRankings){
 const old=stage.completeOrderedBefore,next=stage.completeOrderedAfter,selected=stage.completeSelectedRecords;
 assert.deepEqual(next.groups,old.groups);assert.deepEqual(selected.groups,[]);assert.equal(selected.excluded.length,3);
 assert.deepEqual(next.excluded,[...old.excluded,...selected.excluded]);assert.deepEqual(next.unranked,[...old.unranked,...selected.unranked].sort(alphabetical));
 for(const [phase,records]of [['before',old],['after',next],['selected',selected]]){
  for(const row of [...records.groups.flatMap(g=>g.entries),...records.excluded,...records.unranked]){
   assert.deepEqual(row.carDigest,digestMap.get(row.carId));
   if(Object.hasOwn(row,'fact'))assert.deepEqual(row.fact,completeCarMap.get(row.carId).facts[stage.attribute]);
  }
  for(const group of records.groups)for(const row of group.entries){
   assert.equal(row.rank,group.entries.findIndex(other=>Number(other.fact.value)===Number(row.fact.value))+1);
   assert.equal(row.tied,group.entries.filter(other=>Number(other.fact.value)===Number(row.fact.value)).length>1);
  }
  rankingBindings.push({attribute:stage.attribute,phase,completeGroups:records.groups.length,completeEntries:records.groups.reduce((n,g)=>n+g.entries.length,0),completeExcluded:records.excluded.length,completeUnranked:records.unranked.length,allCarDigestsAndFactsExact:true,allRankAndTiedFieldsExact:true});
 }
}
function projectRecords(records,inputCars){
 const ids=new Set(inputCars.map(car=>car.id)),index=new Map(inputCars.map((car,i)=>[car.id,i]));
 const groups=records.groups.map(g=>({...g,entries:g.entries.filter(row=>ids.has(row.carId))})).filter(g=>g.entries.length);
 // Filtering a complete input can change group sizes. Re-establish production bucket insertion order before stable group sorting.
 groups.sort((a,b)=>Math.min(...a.entries.map(row=>index.get(row.carId)))-Math.min(...b.entries.map(row=>index.get(row.carId))));
 const insertionKeys=groups.map(groupKey);groups.sort(groupOrder);
 return {groups:groups.map(g=>({vehicleClass:g.vehicleClass,basis:g.basis,unit:g.unit,count:g.entries.length})),rankedIds:groups.flatMap(g=>g.entries.map(row=>row.carId)),excluded:records.excluded.filter(row=>ids.has(row.carId)).map(({carDigest,...row})=>row),insertionKeys};
}
const rankingGroupProof=[];
expected.rankings=baseline.rankings.map((old,i)=>{
 const actual=normal.rankings[i],selected=selectedAfter.rankings[i],stage=stageRankings.find(row=>row.attribute===old.key);assert(stage);
 assert.equal(actual.key,old.key);assert.equal(selected.key,old.key);assert.equal(selected.ranked,0);
 const b=projectRecords(stage.completeOrderedBefore,onSaleBefore),a=projectRecords(stage.completeOrderedAfter,onSaleAfter);
 assert.deepEqual(b.groups,old.groups);assert.deepEqual(b.rankedIds,old.rankedIds);assert.deepEqual(b.excluded,old.excluded);
 assert.deepEqual(a.groups,b.groups);assert.deepEqual(a.rankedIds,b.rankedIds);assert.deepEqual(a.excluded,[...b.excluded,...selected.excluded]);
 const exclusionReasons={};for(const row of a.excluded)exclusionReasons[row.reason]=(exclusionReasons[row.reason]||0)+1;
 assert.equal(a.rankedIds.length+a.excluded.length,312);
 fullArrayOrderProof.push({path:'rankings/'+old.key+'/excluded',producer:'Full digest-bound stage exclusions filtered in actual input catalogue order',beforeRows:b.excluded.length,afterRows:a.excluded.length,completeEquality:true});
 rankingGroupProof.push({key:old.key,groupsUnchanged:true,rankedIdsUnchanged:true,allNewRowsExcluded:true,beforeInsertionKeys:b.insertionKeys,afterInsertionKeys:a.insertionKeys,actualProductionGroupComparator:true,completeBeforeAndAfterRecordBindings:true});
 return {...old,ranked:a.rankedIds.length,percent:pct(a.rankedIds.length,312),rankedIds:a.rankedIds,passes:a.rankedIds.length/312>=0.9,groups:a.groups,excluded:a.excluded,exclusionReasons};
});
write('ranking-group-order-and-peer-proof',{sourcePath:discoveryPath,sourceSha256:fileHash(discoveryPath),exactComparatorText:comparatorText,fullStageRecordPath:'/tmp/cupra-packet/full-stage-v2/output/global-ranking-comparison.json',fullStageRecordSha256:fileHash('/tmp/cupra-packet/full-stage-v2/output/global-ranking-comparison.json'),completeBindings:rankingBindings,groups:rankingGroupProof});
"""
s=s[:a]+ranks+s[b:]
s=s.replace("row.brand!=='KGM'","row.brand!=='CUPRA'").replace("row.brand==='KGM'","row.brand==='CUPRA'")
s=s.replace("acceptedStageDigests.candidate27);assertDeclaredJson(completeAfter,'/completeAfter',new Set());assert.deepStrictEqual(carDigests(completeAfter),acceptedStageDigests.candidate28);","acceptedStageDigests.candidate28);assertDeclaredJson(completeAfter,'/completeAfter',new Set());assert.deepStrictEqual(carDigests(completeAfter),acceptedStageDigests.candidate29);")
s=s.replace("assert.deepStrictEqual(beforeFeatures,beforeFeatureSnapshot);assert.deepStrictEqual(selectedBefore,selectedBeforeSnapshot);assert.equal(defaultCalls,0);","assert.deepStrictEqual(selectedBefore,selectedBeforeSnapshot);")
s=s.replace('peerCompleteCarDigestsExact:424','peerCompleteCarDigestsExact:427').replace('selectedOldFeatureProducers:207','selectedOldFeatureProducers:0').replace('defaultLoaderCalls:0,selectedFreshnessBefore','defaultLoaderModulesLoaded:false,selectedFreshnessBefore').replace('counts:{catalogue:427,tierOne:350,onSale:309}','counts:{catalogue:430,tierOne:353,onSale:312}')
assert 'acceptedMiniDigests' not in s and 'beforeFeatures' not in s and 'newKgm' not in s and 'defaultCalls' not in s
B=Path('/tmp/cupra-packet/report-comparison-v1')
with (B/'compare-report.mjs').open('x')as f:f.write(s)
with (B/'kgm-to-cupra-comparator.patch').open('x')as f:f.write(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='/tmp/kgm-packet/report-comparison-v2/compare-report.mjs',tofile=str(B/'compare-report.mjs'))))
print('Prepared comparison script',len(s),'bytes, not executed')
