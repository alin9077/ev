# CUPRA29 independent normal coverage report and saved-output comparator

Preparation only. A separate reviewed command and root execution grant are required. Full-project TypeScript remains UNPASSED after two preserved KGM SIGKILL attempts of unknown cause; neither factual validation nor syntax-only preparation changes that status. No compiler retry, Next build, server, browser, publication or live helper edit is included.

## Prerequisites and resource envelope

- Exact accepted four-file CUPRA29 registration and independent live readback
- Five fresh accepted scoped gates, in order: market-view check, changed-file lint, 144 behavioral tests, 7 live-safety tests, structural validation
- Pinned retained TypeScript failure provenance, original tsconfig, unchanged 361 configured root names, 360 unchanged root stats plus exact loader transition, installed runtime/dependency content, and all four post-registration target hashes/stats
- One root-granted exclusive heavy slot; no parallel execution or automatic retry

The normal command uses the installed pinned Node with 448 MiB old space / 1 MiB semi space, --import tsx, and unchanged scripts/report-coverage.ts --as-of 2026-10-15 --json. Its timeout is 900 seconds with 10-second TERM-to-KILL grace and 20-second supervisor margin. This is one actual normal loader/report run, including its inherent full effective-feature work. The selected or derived stage does not substitute for this output.

The saved-output comparator uses pinned installed Node 448/1 MiB, --import tsx and a versioned comparison script, with a 180-second timeout plus 10-second grace. It reads the saved report and never reruns it. Both commands have create-only outputs, exact source/import closure, before/after content and metadata guards, resource/terminal receipts, and preserved failure evidence.

## Baseline and exact additions

Baseline is the independently accepted KGM28 normal output at /tmp/kgm-packet/report-comparison-v2/normal-coverage-asof-2026-10-15/stdout.log, SHA ec789547ae84ecf1bcec0953c08df124ef0cbbe3c54b19c314e4f117b4bea339. It has 427 catalogue, 350 Tier 1 and 309 on-sale versions. CUPRA29 adds three separate MY26 Tavascan versions, so expected actual totals are 430 / 353 / 312, matching independently accepted full-stage semantics.

Restore retained complete-car prefix20 (409 cars) once and compose accepted written car replacements/additions through EQA21, Leap22, Mazda23, Skoda24, Audi25, Deepal26, MINI27 and KGM28. Every intermediate ordered complete-car digest must equal accepted stage history. Append only the three accepted CUPRA cars. All 427 peers, order, identities, fact values, bases, grades and summaries remain exact. Original retained CUPRA baseline is the accepted empty array; do not invent a manual old-car or feature baseline.

Stream only the 14 retained research descriptors needed for source/control context, retaining zero pre-existing CUPRA variants, features and equipment. Close all 21 descriptor-selected physical files. Compose source registries from exact accepted packet additions through KGM28 and CUPRA29, checking both full source-array digests. No peer feature generation or broad replay is allowed in the comparator. The 207 new effective features and their producer-owned optional fields are already proven by the accepted selected actual-consumer run; use those saved results and keep their exact source/receipt/byte closure.

## Complete comparison obligations

1. Verify fixed date, actual report terminal and exact stdout hash, denominators 430 / 353 / 312, and unchanged report implementation
2. Compare all non-CUPRA whole brandProgress objects exactly to the KGM baseline. CUPRA's complete new object must equal the accepted selected output, including C1/C2/C5 false, C3/C4/C6 true, and researchCompleted false because four version/model dispositions remain open
3. Compute the actual zero-row selected core/freshness controls; do not substitute a zero-row global reconciliation warning for the accepted global baseline CUPRA object. Zero selected historical rows imply no prior feature replay, no old summary or freshness contributions, and no invented before snapshots
4. Recompute complete global coreCoverage/coreFact/gradePattern over all digest-verified on-sale cars and complete sources, using actual pinned production functions. Match every one of the 17 baseline core objects and all gaps before computing the after objects. Verify each filled/reviewed/grade delta equals the accepted three-version selected contribution, with denominator +3
5. Retain every full per-field reason count in catalogue insertion order, not only the displayed shortened explanation. Confidence and comparison compatibility stay separate; two real Not published charging searches stay gaps, current source-labelled towing/height conflicts stay held, and all Reported numbers stay unranked
6. Bind all complete accepted full-stage ranking records to exact full-car digests. Preserve complete Fact/rank/tied/reason fields, the unchanged peer groups, old-plus-three exclusions and alphabetical unranked order. Project the actual on-sale subset using the actual production group comparator and insertion-tie order. Match every report group, ordered rankedIds, ordered excluded array, reason count, percentage and pass flag; no set-only or count-only substitute
7. Reconstruct summaryGaps in actual Tier 1 catalogue order, missingModels and unresolvedLeads in actual inventory traversal order, and ageing overdue/invalid/excludedHistory in actual producer order: all cars' facts/availability followed by features. Bind all new selected contributions to accepted selected output. No additional effective-feature pass
8. Compare the complete global C1 object to accepted stage before/after: reviewed counts remain 103 models and 234 versions, issue count 195→197, settled inventory 62→63, Tavascan remains unresolved, Born settles, three MY26 version-list issues are added, all other evidence and ordering unchanged, pass false
9. Explicitly reconstruct every remaining aggregate: paired summaries, all-rank intersection, 17-field grade totals/percentages, grade note, completed/remaining brand arrays, freshness counts and every C1–C6 detail. Entire expected final report must deep-equal actual normal output with zero ignored leaves
10. Require nonmutation of complete cars, sources, selected facts/packs/results and packet. Any optional-property normalization must have an actual producer witness. Default catalogue loaders remain unused in the comparator; actual normal report uses its unmodified default loader

## Retained outputs and stopping conditions

Keep exhaustive baseline-versus-normal differences, expected-versus-normal differences, complete core reason inventory, full digest-bound ranking and array-order proof, zero-row controls, formatted normal coverage text and a final all-leaves-accounted receipt. Syntax-only checking is preparation, not a compiler result.

A failed normal report ends that grant with terminal evidence. A failed comparator preserves the normal report for a separately reviewed correction; never rerun the expensive report merely to repair comparison code. No automatic retry, memory escalation, source change, new brand or fabricated C1 closure.
