from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
B=Path('/tmp/cupra-packet/report-comparison-v1')
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def read(p):return json.loads(Path(p).read_text())
s=read(B/'sequence.json');files=[];checks=[]
for row in s['sequence']:
 assert pin(row['path'])==row;m=read(row['path']);d=Path(m['runOutput']);r=read(d/'result.json');t=read(d/'terminal.json')
 assert r['passed']is True and r['exitCode']==t['exitCode']==0 and r['manifestSha256']==row['sha256']
 assert read(d/'after-pins.json')['passed']is True and read(d/'scope-verification.json')['passed']is True
 assert (d/'stderr.log').stat().st_size==0 and not t['watchdogFired']
 files.extend(pin(d/n)for n in ['registration-target-metadata-before.json','invocation.json','started.json','stdout.log','stderr.log','terminal.json','after-pins.json','scope-verification.json','result.json'])
 checks.append(dict(name=m['id'],manifest=row,result=pin(d/'result.json'),terminal=pin(d/'terminal.json'),passed=True,seconds=t['elapsedSeconds'],maxRssKiB=t['maxRssKiB']))
r=read(B/'artifacts/result.json');assert r['passed']is True and r['allNormalLeavesAccounted']is True and r['broadFeatureReplay']is False
assert r['counts']==dict(catalogue=430,tierOne=353,onSale=312)
for p in sorted((B/'artifacts').iterdir()):assert p.is_file();files.append(pin(p))
for p in read(s['sourcePins']['path']):assert pin(p['path'])==p
for row in s['sequence']:
 for p in read(row['path'])['extraPins']:assert pin(p['path'])==p
out=dict(status='normal_report_and_saved_comparison_pass_pending_independent_result_review',at=datetime.now(timezone.utc).isoformat(),sequence=pin(B/'sequence.json'),rootGrant=pin(B/'root-execution-grant.json'),collector=pin(B/'collect-results.py'),checks=checks,files=files,sourcePins=s['sourcePins'],all488SourcePinsExact=True,all205ExtraProofPinsExact=True,counts=r['counts'],allNormalLeavesAccounted=True,peerCompleteCarDigestsExact=r['peerCompleteCarDigestsExact'],globalC1EqualsAcceptedStage=r['globalC1EqualsAcceptedStage'],currentProjectTypeScript='UNPASSED; both unknown-cause KGM SIGKILL failures retained; no compiler retry',releaseAcceptanceClaim=False,normalReportRuns=1,extraBroadFeatureReplay=False,automaticRetry=False)
with (B/'results-manifest-v1.json').open('x')as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps(dict(manifest=pin(B/'results-manifest-v1.json'),checks=checks,result=r),indent=2))
