from pathlib import Path
import ast,difflib,hashlib,json,sys
R=Path('/workspace/scratch/586427eef9f2/roadmark-104');B=Path('/tmp/nissan-packet/registration-v1')
assert len(sys.argv)==2,'prepare.py INDEPENDENT_FULL_STAGE_OUTPUT_ACCEPTANCE'
accepted=Path(sys.argv[1]);assert accepted.is_file()
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def put(p,b):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
def write(n,x):put(B/n,(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode())
packet=Path('/tmp/nissan-packet/typed-preparation-v2/nissan-2026-10-15-candidate.json');recon=Path('/tmp/nissan-packet/typed-preparation-v2/nissan-market-reconciliation.json')
assert pin(packet)['sha256']=='6aa651b6932721365dfdee38c92fd19d9dd62cf50cb42ec6c348d495f00c9585'
registry='data/m1-brand-updates/registry.json';loader='scripts/reporting/load.ts'
old=json.loads((R/registry).read_text());assert len(old['packets'])==30 and old['packets'][-1]=='renault-2026-10-15.json'
new={**old,'packets':[*old['packets'],'nissan-2026-10-15.json']};assert new['packets'][:-1]==old['packets']
s=(R/loader).read_text();imp='import renaultReconciliation from "../../data/m1-renault-market-reconciliation-2026-10-15.json";';arg='      renaultReconciliation as M1MarketReconciliation,'
assert s.count(imp)==1 and s.count(arg)==1 and 'nissanReconciliation' not in s
newload=s.replace(imp,imp+'\nimport nissanReconciliation from "../../data/m1-nissan-market-reconciliation-2026-10-15.json";').replace(arg,arg+'\n      nissanReconciliation as M1MarketReconciliation,')
proposals={registry:(json.dumps(new,indent=2)+'\n').encode(),loader:newload.encode(),'data/m1-brand-updates/nissan-2026-10-15.json':packet.read_bytes(),'data/m1-nissan-market-reconciliation-2026-10-15.json':recon.read_bytes()}
rows=[];patch=''
for index,(rel,after) in enumerate(proposals.items()):
 p=R/rel;before=p.read_bytes() if p.exists() else None;assert (before is None)==(index>=2)
 put(B/'after'/rel,after)
 if before is not None:put(B/'before'/rel,before)
 rows.append(dict(relativePath=rel,target=str(p),operation='create' if before is None else 'replace',before=None if before is None else {k:v for k,v in pin(p).items() if k!='path'},after=pin(B/'after'/rel),beforeCopy=None if before is None else pin(B/'before'/rel)))
 patch+=''.join(difflib.unified_diff((before or b'').decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+rel if before is not None else '/dev/null',tofile='b/'+rel))
assert [r['operation'] for r in rows]==['replace','replace','create','create']
write('prepared-writes.json',rows);put(B/'registration.patch',patch.encode())
app=Path('/tmp/renault-packet/registration-v1/apply.py').read_text().replace('apply_exact_renault_registration','apply_exact_nissan_registration')
app=app.replace("assert g['automaticRetry'] is False and g['heavyExecutionAuthorized'] is False","assert g['automaticRetry'] is False and g['heavyExecutionAuthorized'] is False\nassert m['backupFreezeReleaseRequired'] is True and g['backupLiveSourceFreezeReleased'] is True")
ast.parse(app);put(B/'apply.py',app.encode())
write('applicator-syntax-check.json',dict(status='passed_python_ast_parse_only',applicator=pin(B/'apply.py'),executed=False,compilerRun=False))
proofpaths=[str(accepted),'/tmp/nissan-packet/full-stage-v1/manifest.json','/tmp/nissan-packet/full-stage-v1/full-stage-result-manifest-v1.json','/tmp/nissan-review/full-stage-v1-readiness-v1.json','/tmp/nissan-packet/selected-preflight-v4/selected-result-manifest-v1.json','/tmp/nissan-review/selected-preflight-v4-results-v1.json','/tmp/nissan-review/typed-preparation-v2-findings-v1.json','/tmp/nissan-review/source-review-v3-findings-v1.json','/tmp/nissan-packet/source-review-v3/manifest.json','/tmp/nissan-packet/typed-preparation-v2/manifest.json',str(packet),str(recon),'/tmp/kgm-packet/full-project-typescript-v1/run/terminal.json','/tmp/kgm-packet/full-project-typescript-v2/run/terminal.json','/tmp/kgm-packet/report-comparison-v2/typescript-failure-provenance.json']
proofs={}
def add(p):
 x=pin(p);prev=proofs.get(x['path']);assert not prev or prev==x;proofs[x['path']]=x
for p in proofpaths:add(p)
for p,key in [('/tmp/nissan-packet/full-stage-v1/manifest.json','pins'),('/tmp/nissan-packet/full-stage-v1/full-stage-result-manifest-v1.json','outputs'),('/tmp/nissan-packet/source-review-v3/manifest.json','pins'),('/tmp/nissan-packet/typed-preparation-v2/manifest.json','pins')]:
 for x in json.loads(Path(p).read_text())[key]:
  assert pin(x['path'])==x,(x['path'],'retained proof drift');add(x['path'])
helper=['src/lib/brand-updates.ts','src/lib/brand-update-registry.ts','src/lib/evidence-consumers.ts','src/lib/discovery.ts','src/lib/data.ts','scripts/reporting/reports.ts','scripts/reporting/m1-reconciliation.ts','tests/brand-updates.test.ts']
m=dict(schemaVersion=1,status='frozen_preparation_only_requires_bundle_review_backup_freeze_release_and_root_application_grant',repo=str(R),writes=rows,proofs=list(proofs.values()),unchangedHelperPins=[pin(R/p) for p in helper],patch=pin(B/'registration.patch'),applicator=pin(B/'apply.py'),preparation=[pin(B/'prepare.py'),pin(B/'README.md'),pin(B/'prepared-writes.json'),pin(B/'applicator-syntax-check.json')],expected=dict(catalogue=430,tierOne=353,onSale=312,packets=31,changedExistingCars=4,unchangedPeers=426,newModels=0,newVersions=0,newSources=22,generatedFeatureRows=0,manualFeatureUpdates=0,C1=dict(pass_=False,reviewedModels=106,reviewedVersions=242,issues=187,settledInventory=65)),scope=dict(existingFiles=2,newFiles=2,helperSemantics='Unchanged accepted live helpers',packet='Exact accepted typed-v2 candidate',reconciliation='Exact accepted typed-v2 reconciliation',registry='Append only; preserve first30 ordered entries',reportLoader='One import and one last combineM1Reconciliations argument',reportImplementationChanged=False,testsChanged=False,heroChanged=False,immutableSnapshotChanged=False,sourceCapturesAddedToRepository=False),currentProjectTypeScript='UNPASSED: two preserved unknown-cause KGM SIGKILL failures; no compiler retry',automaticRetry=False,rootGrantRequired=True,backupFreezeReleaseRequired=True,heavyChecksAllowed=False,rollback='No automatic rollback or deletion; retain journal and exact before copies for separately authorised recovery')
m['expected']['C1']['pass']=m['expected']['C1'].pop('pass_')
write('manifest.json',m)
write('root-grant-template.json',dict(status='NOT_GRANTED',action='apply_exact_nissan_registration',manifest=pin(B/'manifest.json'),reviewerAcceptance=None,backupLiveSourceFreezeReleased=False,allowedTargets=[x['target'] for x in rows],automaticRetry=False,heavyExecutionAuthorized=False))
print(json.dumps(dict(manifest=pin(B/'manifest.json'),proofs=len(proofs),writes=rows),indent=2))
