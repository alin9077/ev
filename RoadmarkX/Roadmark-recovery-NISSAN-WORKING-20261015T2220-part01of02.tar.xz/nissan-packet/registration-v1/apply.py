"""Exact four-file application only, after separate bundle review and root grant."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,sys

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def check(p):
 x=Path(p['path']);assert x.is_file() and x.stat().st_size==p['bytes'] and sha(x)==p['sha256'],str(x)
def now():return datetime.now(timezone.utc).isoformat()
assert len(sys.argv)==5,'apply.py MANIFEST SHA256 ROOT_GRANT SHA256'
mp,mh,gp,gh=sys.argv[1:];assert sha(mp)==mh and sha(gp)==gh
m=json.loads(Path(mp).read_text());g=json.loads(Path(gp).read_text())
assert g['status']=='root_application_granted' and g['action']=='apply_exact_nissan_registration'
assert g['manifest']['path']==str(Path(mp).resolve()) and g['manifest']['sha256']==mh
assert g['automaticRetry'] is False and g['heavyExecutionAuthorized'] is False
assert m['backupFreezeReleaseRequired'] is True and g['backupLiveSourceFreezeReleased'] is True
assert m['rootGrantRequired'] and m['automaticRetry'] is False and m['heavyChecksAllowed'] is False
check(g['reviewerAcceptance']);check(m['applicator']);assert Path(__file__).resolve()==Path(m['applicator']['path'])
for p in m['proofs']:check(p)
check(m['patch'])
for p in m['unchangedHelperPins']:check(p)
assert len(m['writes'])==4 and g['allowedTargets']==[r['target'] for r in m['writes']]
repo=Path(m['repo']).resolve()
for r in m['writes']:
 p=Path(r['target']);assert p==repo/r['relativePath'] and p.parent.is_dir() and not p.is_symlink()
 check(r['after'])
 if r['before'] is None:assert not p.exists()
 else:
  check(r['beforeCopy']);assert p.is_file() and p.stat().st_size==r['before']['bytes'] and sha(p)==r['before']['sha256']
out=Path(mp).parent/'application';out.mkdir(exist_ok=False)
def write(name,x):
 with (out/name).open('x') as f:json.dump(x,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
write('started.json',dict(at=now(),manifestSha256=mh,grantSha256=gh,beforeGuardsPassed=True,heavyExecution=False))
completed=[]
try:
 for i,r in enumerate(m['writes']):
  p=Path(r['target']);content=Path(r['after']['path']).read_bytes()
  # No process or runtime work; exactly the reviewed four filesystem writes.
  if r['operation']=='create':
   with p.open('xb') as f:f.write(content);f.flush();os.fsync(f.fileno())
  else:
   assert sha(p)==r['before']['sha256']
   with p.open('wb') as f:f.write(content);f.flush();os.fsync(f.fileno())
  assert sha(p)==r['after']['sha256']
  completed.append(dict(target=str(p),sha256=sha(p)))
  write(f'write-{i+1}.json',completed[-1])
 for r in m['writes']:assert sha(r['target'])==r['after']['sha256']
 for p in m['unchangedHelperPins']:check(p)
 write('result.json',dict(at=now(),passed=True,manifestSha256=mh,grantSha256=gh,writes=completed,heavyExecution=False,automaticRetry=False))
except Exception as e:
 write('failure.json',dict(at=now(),error=repr(e),completedWrites=completed,automaticRollback=False,automaticRetry=False));raise
print(json.dumps(dict(passed=True,writes=len(completed),receipt=str(out/'result.json'))))
