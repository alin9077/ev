"""Read/hash-only pre-registration observation. No project import or process launch.
The output is historical planning evidence, never live-after command pins.
"""
from pathlib import Path
from datetime import datetime, timezone
import ast, hashlib, json
R=Path('/workspace/scratch/586427eef9f2/roadmark-104')
B=Path('/tmp/nissan-packet/post-registration-plan-v1')
O=Path('/tmp/renault-packet/post-registration-checks-v6')
T=Path('/tmp/kgm-packet/full-project-typescript-v1')
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def verify(p):
 actual=pin(p['path']);assert actual=={k:p[k] for k in ['path','bytes','sha256']},p['path']
 if 'realpath' in p:assert str(Path(p['path']).resolve())==p['realpath']
 return actual
def meta(p):
 p=Path(p)
 if not p.exists():return dict(path=str(p),exists=False)
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
def read(p):return json.loads(Path(p).read_text())
def write(p,x):
 with Path(p).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
accept=read('/tmp/renault-review/post-registration-v6-readiness-v1.json')
for key in ['sequence','wrapper','sourcePins','staticInputClosure','registrationManifest']:verify(accept[key])
for row in accept['reviewedCommands']:verify(row['manifest'])
sourcepins=read(O/'source-pins.json')
for p in sourcepins:verify(p)
closure=read(O/'static-input-closure.json')
for p in closure['files']:verify(p)
for e in closure['edges']:verify(e['resolved'])
metadata=read(O/'project-root-metadata.json');ts=read(T/'manifest.json')
for p in metadata['fileMetadata']+metadata['directoryState']+ts['runtimeMetadata']:assert meta(p['path'])==p,p['path']
config=read(R/'tsconfig.json');assert config==ts['originalConfig']
roots=sorted({str(p.resolve()) for pat in config['include'] for p in R.glob(pat) if p.is_file()})
assert roots==metadata['configuredRootFilePaths'] and len(roots)==361
inventory=read(O/'test-inventory.json');names=[]
for relative,v in inventory.items():
 verify(v['source']);assert v['count']==len(v['names']);names+=v['names']
assert len(names)==len(set(names))==151
behavior=read(O/'behavioural-suites.json')['testFiles']
assert sum(inventory[p]['count'] for p in behavior)==144
assert inventory['tests/brand-live-safety.test.ts']['count']==7
registry=read(R/'data/m1-brand-updates/registry.json')
assert registry['packets']==closure['registeredPackets'] and len(registry['packets'])==30
assert not (R/'data/m1-brand-updates/nissan-2026-10-15.json').exists()
assert not (R/'data/m1-nissan-market-reconciliation-2026-10-15.json').exists()
# Match the data-driven path and value selection actually used by price-ladder.test.ts.
bindings=[];pointerfiles=set();cache={}
for filename in ['data/price-ladder-existing-candidates-2026-10-13.json','data/price-ladder-premium-candidates-2026-10-13.json']:
 overlay=read(R/filename)
 for index,row in enumerate(overlay['candidates']):
  target,pointer=row['sourcePointer'].split('#',1);path=(R/target).resolve();assert path.is_relative_to(R/'data')
  if target not in cache:cache[target]=read(path)
  value=cache[target]
  for part in filter(None,pointer.split('/')):
   part=part.replace('~1','/').replace('~0','~');value=value[int(part)] if isinstance(value,list) else value[part]
  if isinstance(value,dict):
   value=next((value[k] for k in ['value','amountAud','amount'] if value.get(k) is not None),None)
   if isinstance(value,dict):value=next((value[k] for k in ['amountAud','amount'] if value.get(k) is not None),None)
  assert value==row['value'],(row['variantId'],row['sourcePointer'])
  pointerfiles.add(target)
  bindings.append(dict(overlay=pin(R/filename),candidateIndex=index,variantId=row['variantId'],sourcePointer=row['sourcePointer'],resolved=pin(path)))
assert bindings==closure['priceSourcePointerBindings'] and len(bindings)==137
assert sorted(pointerfiles)==closure['priceSourcePointerFilenames'] and len(pointerfiles)==7
assert read(R/'media/approved-assets.json')==[]
packet=read('/tmp/nissan-packet/typed-preparation-v2/nissan-2026-10-15-candidate.json')
receipt=read('/tmp/nissan-packet/full-stage-v1/output/stage-receipt.json')
digests=read('/tmp/nissan-packet/full-stage-v1/output/research-field-digests.json')
assert receipt['packetSha256']==pin('/tmp/nissan-packet/typed-preparation-v2/nissan-2026-10-15-candidate.json')['sha256']
assert digests['candidate30']['sources']['rows']==3809 and digests['candidate31']['sources']['rows']==3831
assert len(packet['sources'])==22 and not any(packet[k] for k in ['models','variants','versionUpdates','configurationUpdates','features'])
assert receipt['stagedCars']==receipt['acceptedCurrentCars']==430 and receipt['newModels']==receipt['newVersions']==0
historical=[Path('/tmp/kgm-packet/full-project-typescript-v1/run/terminal.json'),Path('/tmp/kgm-packet/full-project-typescript-v2/run/terminal.json'),Path('/tmp/kgm-packet/report-comparison-v2/typescript-failure-provenance.json'),Path('/tmp/renault-packet/report-comparison-v4/retry-provenance.json')]
for f in ['run.reference.py','close-inputs.future.py']:ast.parse((B/f).read_text())
observation=dict(status='current_pre_registration_read_hash_observation_only',at=datetime.now(timezone.utc).isoformat(),executionAuthorized=False,liveAfterHashesFrozen=False,backupFreezeReleased=False,registrationApplied=False,sourcePinsVerified=len(sourcepins),localClosureFilesVerified=len(closure['files']),localClosureEdgesVerified=len(closure['edges']),registeredPackets=30,configuredRootsVerified=len(roots),unchangedRootStatsVerified=len(metadata['fileMetadata']),directoryStatesVerified=len(metadata['directoryState']),runtimeMetadataVerified=len(ts['runtimeMetadata']),currentLoaderObservation=pin(R/'scripts/reporting/load.ts'),testFiles=len(inventory),behavioralTests=144,liveSafetyTests=7,distinctTestNames=151,priceSourcePointerRowsVerified=len(bindings),priceSourcePointerFiles=sorted(pointerfiles),emptyApprovedAssetIndex=True,candidate31ExpectedSources=3831,candidate31ExpectedCounts=dict(variants=430,families=171,generations=194,criteria=69,evidence=29670,current=351,outgoing=43,provisional=36),candidate31CountsStatus='planned expectations; independent full-stage acceptance and fresh structural gate still required',referenceReadiness=pin('/tmp/renault-review/post-registration-v6-readiness-v1.json'),referenceResults=pin('/tmp/renault-review/post-registration-v6-results-v1.json'),closureReference=pin(O/'static-input-closure.json'),testInventoryReference=pin(O/'test-inventory.json'),nissanCandidate=pin('/tmp/nissan-packet/typed-preparation-v2/nissan-2026-10-15-candidate.json'),nissanStageReceipt=pin('/tmp/nissan-packet/full-stage-v1/output/stage-receipt.json'),nissanResearchDigests=pin('/tmp/nissan-packet/full-stage-v1/output/research-field-digests.json'),historicalFailuresPreserved=[pin(p) for p in historical],pythonSyntaxOnlyFiles=[pin(B/f) for f in ['run.reference.py','close-inputs.future.py']],projectImports=False,testsRun=False,compilerRun=False,liveEdits=False,wrapperRun=False)
write(B/'current-observation.json',observation)
print(json.dumps({k:v for k,v in observation.items() if not isinstance(v,(list,dict))},indent=2))
