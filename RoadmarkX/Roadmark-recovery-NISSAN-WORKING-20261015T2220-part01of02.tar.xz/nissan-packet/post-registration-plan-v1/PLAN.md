# Nissan31: bounded post-registration validation preparation

Status: planning and read/hash checks only. No final gate directory, live-after input freeze, project runtime import, gate, test, compiler, browser, server, archive or live edit has run in this task. The four-file registration remains a parent-owned action. Backup live-source freeze release, application, independent live readback and an exact five-gate execution grant are separate prerequisites.

## Ready for parent handoff

- `prepare-final.py` is a reusable future preparation script. It creates `/tmp/nissan-packet/post-registration-checks-v1` once, after checking the prerequisites below. It performs stdlib Python file/JSON/hash/metadata work only and never launches a subprocess
- `close-inputs.future.py` is the conservative static closure scanner adapted narrowly from accepted Renault v6. It requires all four live registration targets to equal the reviewed prepared bytes and all 31 registry entries to be present. It was AST-checked, not executed
- `run.reference.py` is byte-identical to accepted Renault v6 supervisor SHA256 `0669805bd8b514e510179aea3f93adb5b231b5e02e08ec6b5cde26b290f62828`. It was AST-checked, not executed. No production or test helper is changed
- `test-inventory.reference.json` retains the accepted exact per-file names and source pins: 144 behavioral tests and seven disjoint live-safety names
- `current-observation.json` is a dated pre-registration observation, never final live-after authorization or command pins. It verifies all 255 retained Renault inputs, 168 local closure files, 494 edges, 361 configured root identities, 360 unchanged root stats, five directory states, two runtime stat records, and all 137 dynamic price-source-pointer bindings across seven files
- `python-syntax-only.json` records Python AST parse only. It is not a project parser, runtime test or compiler result

The parent subsequently supplied the independently accepted Nissan full-stage result at `/tmp/nissan-review/full-stage-v1-results-v1.json`. The earlier observation's “acceptance required” field is a prerequisite statement, not a claim that this now-available acceptance is absent. The future script verifies its exact manifest/output/candidate/receipt bindings.

## Prerequisites and invocation

Only after the backup freeze is released and registration is actually applied and independently read back:

    python /tmp/nissan-packet/post-registration-plan-v1/prepare-final.py REGISTRATION_READBACK_JSON APPLICATION_ROOT_GRANT_JSON

The application grant is the real root-authored four-file application grant, not a newly synthesized substitute. The preparation checks its actual grant SHA against the completed application receipt; it requires `backupLiveSourceFreezeReleased: true`, `status: root_application_granted`, the exact Nissan action/manifest/targets, `automaticRetry: false` and `heavyExecutionAuthorized: false`. It then requires the independent readback contract used by accepted Renault v6: `status: accepted`, exact `manifestSha256`, `allFourLiveHashesAndBytesMatchAcceptedPayloads: true`, and a pinned successful application receipt.

Registration is fixed to manifest SHA256 `32a850242cd6c60781ad96a961db78034803d90657d536b3321b76f3f0b1347c`. Candidate is fixed to `6aa651b6932721365dfdee38c92fd19d9dd62cf50cb42ec6c348d495f00c9585`. Only these four paths transition:

1. `data/m1-brand-updates/registry.json`, append Nissan at position 31
2. `scripts/reporting/load.ts`, Nissan reconciliation import and final combine argument
3. `data/m1-brand-updates/nissan-2026-10-15.json`, exact accepted packet
4. `data/m1-nissan-market-reconciliation-2026-10-15.json`, exact accepted reconciliation

The final preparation directory must not exist. Any partial preparation must be retained and reviewed; the script does not retry or overwrite it. After final preparation, independently review the actual manifests/closure/wrapper and obtain the exact root execution grant. No grant or readiness acceptance is fabricated here.

## Exact future five-gate command scope

All commands use cwd `/workspace/scratch/586427eef9f2/roadmark-104` and Node `/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node`. Exact argv are retained in `commands.plan.json`; this is a non-executable plan, not gate authorization.

1. Market view: 128 MiB old-space, 1 MiB semi-space, `scripts/generate-market-view.mjs --check`; 60-second timeout. Require the exact no-write success sentence
2. One-file lint: 256/1 MiB, resolved installed ESLint executable, explicit flat config, no config lookup, no ignore/cache/concurrency, max warnings zero, JSON output; only `scripts/reporting/load.ts`; 180 seconds. Require one exact file result and zero messages/errors/warnings/fatals
3. Behavioral suites: 512/1 MiB, `--import tsx --test --test-reporter=tap --test-concurrency=1`, the exact ten existing files below; 600 seconds. Require the complete exact 144-name inventory, 144 pass and zero fail/cancel/skip/todo
4. Live safety: 512/1 MiB and the same Node test options, only `tests/brand-live-safety.test.ts`; 600 seconds. Require all seven exact names, 7 pass and zero fail/cancel/skip/todo
5. Structural validator: 448/1 MiB, `--import tsx scripts/validate.ts`; 900 seconds. Require exact structural expectations below

Behavioral files/counts: brand-updates 30; evidence-consumers 18; price-ladder 21; fact-validity 2; citable 14; market-review-reconciliation 4; m1-coverage-tracking 27; coverage-reports 9; c1-order-eligibility 10; availability-ranking 9. Total 144. Live-safety's seven names are distinct from all 144: 151 distinct scoped tests in two separate runs, never a full-suite claim.

Expected Nissan31 structural result, to be freshly established: PASS; 430 variants; 171 families; 194 generations; 69 criteria; 29,670 evidence rows; 351 current / 43 outgoing / 36 provisional; **3,831 source references**; 15 publication issues; zero approved external assets; immutable research SHA256 `010ded194b4d61cd7be606ce0cc332fa7e32906bba70abff2b5c38541e634657`. The 3,831 source expectation is independently grounded in accepted full-stage candidate31 field digests and 22 appended Nissan sources, not copied from Renault's 3,809. No model or version addition is expected.

## Actual local and dynamic read closure

The accepted closure roots are the eleven test files, validator, market generator, report loader, ESLint config, and directly retained `tests/fixtures/evidence-consumers/data-before.ts.txt`. Recursively close local imports/requires, aliases rooted at `src`, literal `compiledSource` targets, literal module-relative URLs, working-directory reads, and declared local filename arrays. Include conservative stubbed import branches rather than dropping them.

The retained `data-before.ts.txt` behavioral oracle must be directly pinned and traversed using its real `src/lib/data.ts` import context. It is not compiled in its fixture directory. Pin the exact TypeScript implementation used by the existing helper. Future tests may use that existing `transpileModule` helper and tsx; there is no project compiler/tsc/checker gate and no parser execution during this preparation.

Dynamic sources:

- `src/lib/brand-update-registry.ts`: exact final registry and every one of its 31 listed packet JSON files; keep order and all 30 preceding entries exact
- `tests/brand-updates.test.ts`: module-relative registry URL and every name in its retained literal packet loop are covered by that registry closure
- `tests/price-ladder.test.ts`: derive every `sourcePointer` filename before `#` from both existing/premium candidate overlays; retain all 137 row bindings and seven unique source files. The current observation independently resolves each actual JSON pointer, applies the test's value/amountAud/amount selection, and confirms the published number
- Those seven files are `data/bmw-mini-evidence-2026-10-10.json`, `data/catalogue-additions-2026-10-10.json`, `data/deepal-evidence.json`, `data/geely-zeekr-xpeng-evidence.json`, `data/omoda-jaecoo-evidence.json`, `data/volvo-polestar-evidence-2026-10-10.json`, and `data/vw-skoda-cupra-evidence-2026-10-10.json`
- Fixed runtime ledgers in retained-fact-fills, evidence-regrading, catalogue-additions, buyer-proposal and data are included through their declared filenames and transitive imports
- Market generator: pin both `data/market-inventory-2026-10-10.json` and `data/market-view.generated.json`; `--check` forbids regeneration
- Validator: pin root and copied immutable research, plus `media/approved-assets.json`. The asset index is empty, so dynamic `public${a.src}` has zero possible leaves. A nonempty index must fail preparation rather than silently opening unclosed files

The expected final local closure is 170 files / 496 edges: the unchanged accepted 168/494 plus the new Nissan packet and new reconciliation import. Final preparation derives and asserts those counts against actual post-registration bytes; no final closure is asserted to have run yet.

Retain the accepted package/runtime guards and external-specifier inventory. These are conservative local-source/read closure plus package content/stat guards, not a claim to have runtime-traced every installed transitive dependency. The 361 configured TypeScript root identities, 360 unchanged root stats, original tsconfig, five generated-type directory states, live cache and two runtime metadata entries remain exact. Only load.ts is the pre-existing root with a reviewed content transition. All four registration targets are bound to expected bytes and get per-command before/after exact stat guards.

## Supervision, failure and claim boundaries

- One root-exclusive heavy slot, no backup/heavy overlap, five strictly serial prerequisite-linked gates, exclusive lock, no concurrent gate execution
- `/usr/bin/timeout --signal=TERM --kill-after=10s TIMEOUTs ...`; parent watchdog at timeout plus 20 seconds; kill process group if needed; disabled core dumps; no automatic retry
- Heap settings are V8 limits, not an OS RSS hard cap or a guarantee that the job cannot be killed
- Remove NODE_OPTIONS, NODE_PATH, NODE_COMPILE_CACHE, TS_NODE_PROJECT, TS_NODE_COMPILER_OPTIONS, TS_NODE_TRANSPILE_ONLY. Set NODE_DISABLE_COMPILE_CACHE=1, FORCE_COLOR=0, ESLINT_USE_FLAT_CONFIG=true
- Create-only output directories/files. Retain invocation, started/process group, stdout, stderr, raw wait status, terminal timing, wait4 max RSS, before target metadata, after input checks, scope result and final result for every attempted gate
- Empty stderr, exit zero, no watchdog, exact scope assertions, all content pins and all metadata are required. An assertion/setup/runtime failure stops the chain; keep original evidence. A new attempt requires its own reviewed/granted version
- Ordinary live-safety and structural validation intentionally exercise full catalogue pack paths. This does not authorize a fresh canonical capture, broad stage/comparator replay, a normal coverage report or a report comparator; those remain separate later gates
- No source/helper/test/UI/layout/hero/history edits. No project compiler, production build, browser/server, screenshot/phone test, archive or publishing. No whole-suite, C1–C6, milestone, mobile or release success claim
- Both KGM unknown-cause SIGKILL compiler attempts and retained provenance remain pinned. Renault's original UNKNOWN report invocation and later separately accepted run remain historical; do not overwrite/reclassify original logs or infer OOM. Current full-project TypeScript and release remain UNPASSED
