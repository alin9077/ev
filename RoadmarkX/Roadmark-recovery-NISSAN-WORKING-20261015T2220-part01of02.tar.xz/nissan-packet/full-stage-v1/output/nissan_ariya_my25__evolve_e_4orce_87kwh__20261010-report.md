# Nissan Ariya Evolve e-4ORCE 87kWh

http://localhost:3000/cars/nissan-ariya-my25/evolve-e-4orce-87kwh-20261010
Page updated: 2026-10-14. Individual evidence dates below are retained.

Nissan Ariya Evolve e-4ORCE 87kWh, Australian specifications. The six figures below cover listed price, claimed range, DC charging time, cargo space, braked towing and vehicle warranty. Evidence checked 2026-10-15; measurement bases and conditions are shown beside each figure.

## Availability

Nissan Ariya Evolve e-4ORCE 87kWh: availability of this exact version — Current listing; orders: listed_unconfirmed; stock: unverified; basis: Exact Australian version availability; evidence checked 2026-10-15; conditional. Checked 2026-10-15 Exact named grade remains on the current Australian maker model/specification list; Australian sale launch was September 2025. Current listing and reserve/search-stock calls to action do not establish physical stock, unregistered condition, individual warranty commencement or factory acceptance of a new order. Historical New dealer advertisements checked 10 October 2026 remain in the before evidence; they are not re-dated as current stock observations. Current new-and-demonstrator driveaway offer is not exact new-stock proof; retain MY25 launch technical identity rather than manufacture a calendar-year 2026 model.
Source: Nissan Australia (AU): https://www.nissan.com.au/vehicles/browse-range/ariya.html (accessed 2026-10-15) | Nissan Australia (AU): https://www.nissan.com.au/vehicles/browse-range/ariya/download-specsheet.html (accessed 2026-10-15) | Nissan Australia (AU): https://www.nissan.com.au/about-nissan/news-and-events/news/2025/july/2025-nissan-ariya-pricing-and-specifications-confirmed-ahead-of-striking-electric-suvs-australian-launch.html (accessed 2026-10-15; published 2025-07-29)

## Key facts

Nissan Ariya Evolve e-4ORCE 87kWh: published price — A$71,840; basis: Maker list price before on-road costs; published 29 July 2025, checked current 15 October 2026; evidence checked 2026-10-15; confirmed. Maker MSRP published 29 July 2025, excludes premium paint, statutory charges and other on-road costs. Current October 2026 CarExpert table corroborates the four amounts. Primary before-on-road-costs price is separate from the October temporary dealer-republished driveaway offer. The secondary article entry prose differs from its own table; the maker and table agree.
Source: Nissan Australia (AU): https://www.nissan.com.au/about-nissan/news-and-events/news/2025/july/2025-nissan-ariya-pricing-and-specifications-confirmed-ahead-of-striking-electric-suvs-australian-launch.html (accessed 2026-10-15; published 2025-07-29)

Nissan Ariya Evolve e-4ORCE 87kWh: claimed range — 487 km; basis: WLTP combined cycle; evidence checked 2026-10-15; confirmed. Exact named-grade WLTP combined cycle from current linked Australian specification; real-world range varies with use and conditions.
Source: Nissan Australia (AU): https://www.nissan.com.au/vehicles/browse-range/ariya/download-specsheet.html (accessed 2026-10-15)

Nissan Ariya Evolve e-4ORCE 87kWh: dc 10–80% charging time — 40 min; basis: 10–80% at 130 kW DC station; evidence checked 2026-10-15; confirmed. Explicit maker 10–80% duration at a 130 kW DC charger. Actual charging depends on battery temperature, state of charge and available charger power. The separate charging page gives an up-to-80% claim without a starting SOC; it is not treated as the same test window.
Source: Nissan Australia (AU): https://www.nissan.com.au/vehicles/browse-range/ariya/download-specsheet.html (accessed 2026-10-15)

Nissan Ariya Evolve e-4ORCE 87kWh: declared boot volume to roof — 408 L; basis: Seats upright, loaded to roof; VDA/SAE measurement protocol not stated; evidence checked 2026-10-15; confirmed. Maker specifies seats upright, litres to roof. Measurement protocol is not stated, so the declared value is shown without direct cargo ranks or cross-method deltas.
Source: Nissan Australia (AU): https://www.nissan.com.au/vehicles/browse-range/ariya/download-specsheet.html (accessed 2026-10-15)

Nissan Ariya Evolve e-4ORCE 87kWh: braked towing — 1,500 kg; basis: Maximum braked trailer mass; evidence checked 2026-10-15; confirmed. Requires suitable genuine Nissan towbar; towball mass, fully laden vehicle and accessory limits apply. Confirm handbook/load limits for the actual vehicle.
Source: Nissan Australia (AU): https://www.nissan.com.au/vehicles/browse-range/ariya/download-specsheet.html (accessed 2026-10-15)

Nissan Ariya Evolve e-4ORCE 87kWh: vehicle warranty — 5 years / unlimited kilometres; basis: Australian Nissan vehicle policy; evidence checked 2026-10-15; confirmed. Current new-vehicle terms apply to vehicles retailed on or after 1 January 2025 Begins first registration or first put into service, whichever comes first; demonstrators receive remaining balance Covers material/workmanship defects subject to exclusions; proper use, care, maintenance and records required Originally sold, registered and normally used in Australia; relocation abroad excluded; remaining coverage transfers to subsequent owners 12-volt battery has separate one-year terms and tyres have their own manufacturer cover Optional service-activated warranty can extend eligible cover to a total of ten years / 300,000 km, whichever first; it is not unconditional base cover. Effective 1 January 2025; eligible Nissan vehicles retailed on or after 1 January 2021 and under 300,000 km All logbook services at authorised Nissan dealers within prescribed interval or 60 days / 3,000 km of it; outside non-logbook work must follow Nissan Electronic Service Manual Alternative eligibility only with discretionary written Nissan approval, potentially after health check Starts fifth anniversary of warranty commencement; 12-month periods with up to four further annual extensions Ceasing eligibility ends cover at end of last qualifying 12-month period; capacity loss outside separate capacity warranty excluded
Source: Nissan Australia (AU): https://www.nissan.com.au/owners-hub/nissan-warranty.html (accessed 2026-10-15) | Nissan Australia (AU): https://www.nissan.com.au/owners-hub/nissan-warranty/new-vehicle-warranty-terms.html (accessed 2026-10-15)

## Does Nissan Ariya have Apple CarPlay and Android Auto?

Nissan Ariya Evolve e-4ORCE 87kWh: Needs confirmation (needs confirmation).

Nissan Ariya Evolve e-4ORCE 87kWh: apple carplay and android auto — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-10; needs confirmation. This exact-trim equipment claim has not yet been researched.
Source: 

## What real-world range has been measured for Nissan Ariya?

Nissan Ariya Evolve e-4ORCE 87kWh: Needs confirmation (needs confirmation).

Nissan Ariya Evolve e-4ORCE 87kWh: independent road-test range — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-10; needs confirmation. This exact-trim equipment claim has not yet been researched.
Source: 

## How much does Nissan Ariya cost to insure?

These benchmarks do not establish the cheaper car for you; check the driver profile, date and tested version before comparing, then obtain quotes for the same cover.

Nissan Ariya Evolve e-4ORCE 87kWh: insurance benchmark — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-10; needs confirmation. This exact-trim equipment claim has not yet been researched.
Source: 

## What is the driveaway price of Nissan Ariya?

Nissan Ariya Evolve e-4ORCE 87kWh: A$60,990 (conditional); Offer deadline: 2026-10-31.

Nissan Ariya Evolve e-4ORCE 87kWh: driveaway price — A$60,990; basis: CarExpert-reported from driveaway campaign, corroborated by Sutherland Nissan · Reported by CarExpert · driveaway; evidence checked 2026-10-15; reported; Offer deadline: 2026-10-31. CarExpert reports the exact named-grade from driveaway amounts, corroborated by Sutherland Nissan. Current maker offer text supplies the campaign conditions; its rendered price fields do not provide usable amounts. For private and ABN buyers of new and demonstrator ARIYA purchased 1–31 October 2026 and delivered by 30 November 2026. Premium paint extra; participating dealers while stocks last. Excludes government, rental and national fleet. Not transferable or redeemable for cash; Nissan may vary, extend or withdraw. Combined new/demonstrator campaign does not identify an individual car, its registration status, warranty start, physical stock or accepted order. Offer deadline: 2026-10-31; confirm eligibility and earlier stock exhaustion.
Source: Sutherland Nissan (AU): https://www.sutherlandnissan.com.au/special-offers/m/offers/ (accessed 2026-10-15) | CarExpert (AU): https://www.carexpert.com.au/car-news/nissan-ariya-deals-ev-prices-slashed-by-up-to-dollar15000 (accessed 2026-10-15; published 2026-10-05) | Nissan Australia (AU): https://www.nissan.com.au/offers.html (accessed 2026-10-15)

## How long does Nissan Ariya take to charge at home?

Nissan Ariya Evolve e-4ORCE 87kWh: Needs confirmation (needs confirmation).

Nissan Ariya Evolve e-4ORCE 87kWh: home charging — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-10; needs confirmation. This exact-trim equipment claim has not yet been researched.
Source: 

## Does Nissan Ariya use an LFP battery?

Nissan Ariya Evolve e-4ORCE 87kWh: Needs confirmation (needs confirmation).

Nissan Ariya Evolve e-4ORCE 87kWh: battery chemistry — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-10; needs confirmation. This exact-trim equipment claim has not yet been researched.
Source: 

## Can Nissan Ariya power appliances with V2L?

Nissan Ariya Evolve e-4ORCE 87kWh: Needs confirmation (needs confirmation).

Nissan Ariya Evolve e-4ORCE 87kWh: vehicle-to-load power — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-10; needs confirmation. This exact-trim equipment claim has not yet been researched.
Source: 

## Can this EV qualify for the electric-car FBT exemption?

Eligibility depends on the vehicle, acquisition and employer arrangement; a listed price alone does not confirm an exemption.

Nissan Ariya Evolve e-4ORCE 87kWh: fbt eligibility — Exact eligibility needs confirmation; basis: Source audit; evidence checked 2026-10-08; needs confirmation. The listed price alone does not establish FBT eligibility. The May 2026 announcement described proposed changes from April 2027 and April 2029; this audit has not established that those proposals are law. Confirm the current rules, acquisition conditions and taxable value with the ATO and your adviser.
Source: 

Methodology: http://localhost:3000/methodology
Glossary: http://localhost:3000/glossary
