from pathlib import Path
import json,hashlib,re,ast,shutil
O=Path('/tmp/nissan-packet/full-stage-v1');R=Path('/workspace/scratch/586427eef9f2/roadmark-104');S=Path('/tmp/nissan-packet/selected-preflight-v4');M=Path('/tmp/nissan-packet/typed-preparation-v2');C=Path('/tmp/renault-packet/full-stage-v1')
def pin(path):
 path=Path(path);h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return dict(path=str(path),bytes=path.stat().st_size,sha256=h.hexdigest())
def write(name,value):
 if name=='import-read-closure.json' and (O/name).exists():
  assert json.loads((O/name).read_text())==value;return
 with (O/name).open('x') as f:f.write(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
for p in O.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
syntax=json.loads((O/'syntax-only-check.json').read_text());assert syntax['exitCode']==0 and syntax['runtimeExecuted'] is False and syntax['typescriptCompilerAttempted'] is False;assert syntax['scriptSha256']==pin(O/'stage.mjs')['sha256']
old=json.loads((C/'manifest.json').read_text());registry=json.loads((R/'data/m1-brand-updates/registry.json').read_text());ids=['m1-'+name.removesuffix('.json') for name in registry['packets']];assert len(ids)==30 and ids[-1]=='m1-renault-2026-10-15'
packet=json.loads((M/'nissan-2026-10-15-candidate.json').read_text());result=json.loads((S/'result.json').read_text());assert result['status']=='selected_actual_consumers_and_exact_serialization_witness_pass'
selectedIds=[g['variantId'] for g in packet['versionGuards']];assert len(set(selectedIds))==4
review=Path('/tmp/nissan-review/selected-preflight-v4-results-v1.json');assert json.loads(review.read_text())['result']['sha256']==pin(S/'result.json')['sha256'];assert json.loads(review.read_text())['result']['path']==str(S/'result.json')
files={Path(p['path']) for p in json.loads((S/'source-pins.json').read_text())}
files.update(Path(p['path']) for p in old['pins'] if p['path'].startswith(str(R)) or p['path'].startswith(('/tmp/mercedes-staging-plan/','/tmp/xpeng-staging-plan/')))
refs=dict(acceptedManifest=old['acceptedManifest'],storageClosure=pin(O/'storage-read-closure.json'),packet=pin(M/'nissan-2026-10-15-candidate.json'),reconciliation=pin(M/'nissan-market-reconciliation.json'),census=pin(M/'census-and-dispositions.json'),expectedReview=pin(S/'expected-review.json'),selectedBefore=pin('/tmp/nissan-research/retained-before-cars-v1.json'),selectedAfter=pin(S/'selected-after-cars.json'),selectedResult=pin(S/'result.json'),selectedTerminal=pin(S/'run/terminal.json'),selectedReadiness=pin('/tmp/nissan-review/selected-preflight-v4-readiness-v1.json'),selectedOutputReview=pin(review),acceptedRenaultCars=pin(C/'output/car-digest-comparison.json'),acceptedRenaultFields=pin(C/'output/research-field-digests.json'),acceptedRenaultC1=pin(C/'output/global-c1-comparison.json'),acceptedRenaultReceipt=pin(C/'output/stage-receipt.json'),acceptedRenaultTerminal=pin(C/'run/terminal.json'),acceptedNormalReport=pin('/tmp/renault-packet/report-comparison-v4/normal-coverage-asof-2026-10-15/stdout.log'),acceptedNormalTerminal=pin('/tmp/renault-packet/report-comparison-v4/normal-coverage-asof-2026-10-15/terminal.json'),script=pin(O/'stage.mjs'),wrapper=pin(O/'run.py'))
names=[n+'.json' for n in ['selected-after-cars','selected-packs','portable','claims','feature-claims','availability-claims','undefined-witnesses','claim-undefined-witnesses','report-undefined-witnesses']]+[id+'-report.md' for id in selectedIds]
artifacts={name:pin(S/name) for name in names}
reconciliationPaths=[(R/'scripts/reporting'/name).resolve() for name in re.findall(r'import \w+ from "(\.\./\.\./data/m1-[^"]+\.json)";',(R/'scripts/reporting/load.ts').read_text())];assert len(reconciliationPaths)==30
reconciliationInputs=[pin(p) for p in reconciliationPaths];rawInputs=[pin(p['path']) for p in old['rawOverlayInputs']]
files.update(Path(p['path']) for p in [*refs.values(),*artifacts.values(),*reconciliationInputs,*rawInputs]);files.update(p for p in O.glob('*') if p.is_file());files.update([R/'scripts/reporting/load.ts',S/'run/after-pins.json',S/'prepared-command.json',S/'source-pins.json',S/'selected-result-manifest-v1.json',C/'manifest.json',C/'full-stage-result-manifest-v1.json',Path('/tmp/renault-review/full-stage-v1-results-v1.json'),Path('/tmp/renault-review/report-comparison-v4-results-v1.json')])
files.update(p for p in (S/'run').glob('*') if p.is_file());files.update(R/'data/m1-brand-updates'/name for name in registry['packets'])
closure=json.loads((O/'storage-read-closure.json').read_text());assert len(closure)==21
accepted=json.loads(Path(old['acceptedManifest']['path']).read_text());acceptedPins={(str((Path(accepted['anchors'][row['anchor']])/row['file']).resolve()),row['bytes'],row['sha256']) for row in accepted['inputPins']}
for row in closure:
 assert pin(row['path'])==row;assert (row['path'],row['bytes'],row['sha256']) in acceptedPins;files.add(Path(row['path']))
queue=[p for p in files if p.suffix in ['.ts','.tsx','.mts','.mjs'] and (str(p).startswith(str(R)) or p.parent==O)];seen=set();edges=[];external=set()
while queue:
 p=queue.pop()
 if p in seen:continue
 seen.add(p)
 pattern=r'''(?:from\s*|import\s*\(?\s*|require\(\s*|compiledSource\(\s*)["']([^"']+)["']'''
 for spec in re.findall(pattern,p.read_text()):
  if spec.startswith('@/'):root=R/'src'/spec[2:]
  elif spec.startswith(('./src/','./tests/','./scripts/')) and p.parent==O:root=R/spec
  elif spec.startswith(('src/','tests/','scripts/')):root=R/spec
  elif spec.startswith('.'):root=(p.parent/spec).resolve()
  elif spec.startswith('/'):root=Path(spec)
  else:external.add(spec);continue
  hit=next((f for f in [root,Path(str(root)+'.ts'),Path(str(root)+'.tsx'),Path(str(root)+'.mjs'),Path(str(root)+'.json'),root/'index.ts'] if f.is_file()),None)
  assert hit,('Unresolved local import',str(p),spec)
  files.add(hit);edges.append(dict(importer=str(p),specifier=spec,resolved=pin(hit)))
  if hit.suffix in ['.ts','.tsx','.mts','.mjs']:queue.append(hit)
write('import-read-closure.json',dict(status='static_local_import_closure_pinned',roots=sorted(str(p) for p in seen),edges=sorted(edges,key=lambda x:(x['importer'],x['specifier'])),externalPackageOrNodeSpecifiers=sorted(external),dynamicInputs='Explicit registered packet JSON, 30 reconciliation inputs, retained 21 storage files, raw overlays and selected artifact references are separately enumerated and pinned. Loader source is inspected only; production catalogue loader execution is forbidden.',packageScope='All local implementation/data imports are pinned here; selected-v4 source pins additionally retain the actual installed TypeScript, tsx, esbuild and Linux esbuild binary file inventories, the absolute Node executable, and package/lock/tsconfig. No runtime imports execute during preparation.',runtimePackageClosure=pin(S/'input-closure.json')))
files.add(O/'import-read-closure.json')
for p in [R/'package.json',R/'pnpm-lock.yaml',R/'tsconfig.json']:
 assert p.is_file();files.add(p)
m=dict(schemaVersion=1,status='frozen_pending_independent_command_review_and_root_execution_grant',mode='derived-prefix20-through-Renault30-then-Nissan31-no-broad-features',asOf='2026-10-15',repo=str(R),nodeVersion='v24.19.0',nodeExecutable=str(Path(shutil.which('node')).resolve()),execArgv=['--max-old-space-size=448','--max-semi-space-size=1','--expose-gc','--import','tsx'],timeoutSeconds=420,killAfterSeconds=10,automaticRetry=False,productionRegistrationAuthorized=False,canonicalRecaptureAuthorized=False,normalFullReportInStage=False,rootExecutionGrantRequired=True,exclusiveHeavySlotRequired=True,**refs,importClosure=pin(O/'import-read-closure.json'),selectedArtifacts=artifacts,storageIndex=old['storageIndex'],registeredPacketIds=ids,selectedIds=selectedIds,rawOverlayInputs=rawInputs,reconciliationInputs=reconciliationInputs,output=str(O/'output'),runOutput=str(O/'run'),expected=dict(beforeCatalogue=430,afterCatalogue=430,beforeTierOne=353,afterTierOne=353,beforeOnSale=312,afterOnSale=312,beforePackets=30,afterPackets=31,changedRetainedCars=4,unchangedPeers=426,newModels=0,newVersions=0,sourcesAdded=22,specificFacts=176,termCells=12,coreCells=68,earnedCells=188,selectedFeatureClaims=276,pairComparisons=190,crossBasisComparisons=24,totalComparisons=214,expiryBoundaryCars=4,intendedNegativeRejections=7,currentOfficialListReviewsAdded=1,settledInventoryRecordsAdded=1,leafDispositionsPreservedWithoutFabricatedInventory=True,globalReviewedModels=106,globalReviewedVersions=242,globalIssueCount=187,globalSettledInventoryCount=65,globalC1Complete=False),pins=[pin(p) for p in sorted(files)],scope='Restore retained409 prefix20 once; reproduce every accepted complete-car/all14-field digest through Renault30 before refreshing four Nissan rows. No helper changes. Exactly four selected packs, 188 fact/term claims, 276 feature claims, 190 ordinary plus 24 cross-basis comparisons, four actual October31/November1 offer-boundary checks, complete untouched facts and seven negative guards. Exact live/written ownership and selected artifacts; complete global ranking and expected C1 structures; all426 peers remain exact. Actual totals430/353/312. Preserve ARIYA epoch and LEAF non-admission dispositions without invented inventory IDs, source distinctions and incompatible measurement bases. No broad feature replay, normal report, default loader, live edit, registration, canonical recapture, compiler retry, server, browser or automatic retry. One later normal report after separately guarded integration remains required.')
write('manifest.json',m);h=pin(O/'manifest.json')['sha256'];command=[m['nodeExecutable'],*m['execArgv'],m['script']['path'],'--manifest',str(O/'manifest.json'),'--manifest-sha256',h]
write('root-grant-template.json',dict(authorized=False,exclusiveHeavySlotGranted=False,action='run_single_bounded_nissan_full_stage',preparedManifestSha256=h,command=command,automaticRetry=False,note='Template only; explicit root grant and exclusive heavy slot required.'))
print(json.dumps(dict(manifest=pin(O/'manifest.json'),script=refs['script'],wrapper=refs['wrapper'],pins=len(files),localImportEdges=len(edges),reconciliationInputs=len(reconciliationInputs),executed=False),indent=2))
