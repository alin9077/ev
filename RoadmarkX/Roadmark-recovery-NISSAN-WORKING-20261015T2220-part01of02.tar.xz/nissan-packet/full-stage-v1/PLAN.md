# Nissan31 bounded full-stage plan v1

Preparation only. Execution requires independent readiness, an exact root grant and an exclusive heavy slot. Current full-project TypeScript and release remain UNPASSED. No compiler retry is included.

## Accepted four-row packet and selected proof

The typed-v2 candidate SHA-256 is `6aa651b6932721365dfdee38c92fd19d9dd62cf50cb42ec6c348d495f00c9585`. It refreshes four existing Australian MY25 ARIYA launch grades: ENGAGE, ADVANCE, ADVANCE+ and EVOLVE. No model, variant, identity, manual feature or configuration rows are added. It appends 22 sources and declares 176 guarded facts plus 12 shared-term applications, four availability updates and four summary pairs.

Selected-v4 result SHA-256 is `63af21b45603550ed36a66da4330e15e48cdac4b96bbcf2992f45979d97d4d8d`, independently accepted in `/tmp/nissan-review/selected-preflight-v4-results-v1.json`. The actual consumers proved four packs, 188 effective fact/term cells, 276 feature claims, 68 core cells (65 Confirmed and three AC Check), 190 ordinary comparisons plus 24 cross-basis comparisons, and seven intended negative guard rejections. The four October offers were checked with actual expiry, discovery, factClaim and featureClaim behavior on October 31 and November 1, preserving unexpired primary MSRP. All 317 untouched facts and exact fact-key sets were proved. All nine selected JSON artifacts and four Markdown reports are exact parity targets, with producer-owned undefined witnesses retained rather than globally stripped.

## Restore and reproduce the accepted baseline

Restore retained409/prefix20 once. Pin the actual descriptor-resolved 21-file storage closure: three recursive indexes, three replacement-car JSON files, base complete-car JSONL and all 14 research streams. Assert strict JSON shape before complete-car and all-field digests. Reproduce accepted stages corrected21, current22, current23, current24, candidate25, candidate26, candidate27, candidate28, candidate29 and candidate30. All stage digests are compared to the accepted Renault30 artifacts; the raw producer metadata and sole packet-ID-list composition adjustment are recorded.

Run actual prepareBrandResearch/applyBrandUpdates for Nissan31. Sources are append-only, metadata gains the packet ID, and only four variant availability values/evidence change. All other research fields remain exact. Before identities, facts, shared terms, availability and summary dependencies are guarded. The resulting four complete cars must equal the accepted selected output; all 426 peers and catalogue order remain exact. Actual eligibility helpers must preserve 430 catalogue / 353 Tier 1 / 312 on-sale versions.

Check source-addition neutrality in every complete accepted car, all research, all 30 earlier packets and nine raw overlays, including nested reviews and dictionary keys. New source IDs cannot revive accepted references.

## Bounded actual consumers

Only four selected packs replay effective-feature, regrading, brand-feature and shared-term producers, with complete global source and issue context. No broad feature replay is permitted. Negative mutants retain selected models, variants and 276 feature rows plus global context, rather than cloning the full catalogue research. Reproduce accepted written pack, portable, claim, feature-claim, availability, optional-witness and report files byte-for-byte. Compare complete comparisonProof, crossBasisProof, expiryBoundaryProof and untouchedFactProof, along with claim-source, live/portable/written/hydrated and summary parity. All live inputs must remain unchanged.

Preserve separate confidence and comparison compatibility. Named-grade WLTP combined values remain Confirmed; known usable batteries and explicit 10–80% charge windows compare. Unknown cargo methods and unspecified-start charging observations remain incompatible. Canonical roadside facts and features show the one-year base with the conditional extension and dealer-limited towing terms. October driveaway offers remain separately Reported with exact terms and expiry; the before-on-road MSRP ladder remains primary.

## Complete global ranking and C1 expectations

For all seven actual ranking attributes, derive complete expected groups from unchanged peers plus the refreshed four. Assert group ordering and insertion-order ties, numeric interleaving, rank/tie arithmetic, all fact and reason objects, full excluded traversal order and full unranked alphabetical order. Bind repeated cars to their complete-car digests. All four Nissan rows rank for range, price, length, DC duration, seats and towing; cargo remains held for unknown method. Peer memberships and within-group order remain exact.

Mirror the actual loader's 30 reconciliation imports without executing the loader. Baseline C1 must equal both accepted Renault30 stage output and the independently accepted actual Renault normal report. Its exact baseline is 105 reviewed models / 238 reviewed versions / 192 issues / 64 settled inventory. The complete expected Nissan31 structure is 106 / 242 / 187 / 65:

- Append the one ARIYA model review and its four reviewed version IDs in reconciliation order
- Remove exactly the four Nissan version_unreviewed issues and record:nissan-ariya inventory_unresolved issue
- Insert only record:nissan-ariya into settled inventory using actual inherited inventory traversal
- Preserve every other issue, count, evidence array and ordering exactly
- Keep global C1 false because independent whole-market lists remain incomplete

Pin and inspect the source-bound census. Current Australian BEV membership is exactly the four ARIYA grades, with no additions. ZE1 LEAF/e+ has no qualifying current new-stock or new-order proof; generic enquiry cards do not establish residual supply, and no nationwide stock-exhaustion conclusion is made. Third-generation LEAF's Australian introduction remains indefinitely paused. Neither has an inherited inventory row or lead to settle; do not fabricate an exclusion or review ID. Other overseas/facelift leads and PHEVs retain their separate non-admission dispositions.

## Frozen closure and execution envelope

Pin all actual retained storage, transitive local implementation imports, dynamic evidence-regrading ledger, compiled evidence-consumers source, registry and 30 packet files, 30 reconciliation JSON files, nine raw overlays, inherited inventory, source packet/review receipts, selected before/after/proof outputs, accepted Renault stage/normal report evidence and all command files. Retain selected-v4's installed runtime package inventory for TypeScript, tsx, esbuild and its Linux binary, plus the resolved absolute Node executable. This is a stronger package closure than the older Renault manifest. The default catalogue and reporting loaders remain blocked.

One later granted run uses Node v24.19.0, 448 MiB old space, 1 MiB semi-space, exposed GC, 420-second timeout and 10-second kill grace. Before/after pins, invocation, raw wait status, elapsed time, peak RSS and stdout/stderr hashes are preserved. There is no automatic retry or inferred reason for a termination. The syntax-only check already passed under 64/1 MiB, 10 seconds plus two-second kill grace, with no imports, runtime stage or compiler execution.

Outputs cover stage-by-stage complete-car/all-14-field digests, metadata transitions, selected actual artifacts and witnesses, source-neutrality proof, complete rankings, complete C1 expected equality, LEAF dispositions and stage receipt. Full-stage acceptance is separate from guarded live registration and the later actual normal report. This command does not edit live files, register, recapture canonical data, run a normal report, start a server/browser, build, publish or retry TypeScript.
