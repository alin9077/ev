from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
B=Path('/tmp/nissan-packet/post-registration-checks-v1')
def pin(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
s=json.loads((B/'sequence.json').read_text());checks=[];files=[]
for p in s['sequence']:
 assert pin(p['path'])==p;m=json.loads(Path(p['path']).read_text());d=Path(m['runOutput']);r=json.loads((d/'result.json').read_text());t=json.loads((d/'terminal.json').read_text());a=json.loads((d/'after-pins.json').read_text());v=json.loads((d/'scope-verification.json').read_text())
 assert r['passed']is True and r['exitCode']==t['exitCode']==0 and r['manifestSha256']==p['sha256'] and a['passed']is True and v['passed']is True
 assert (d/'stderr.log').stat().st_size==0 and not t['watchdogFired']
 paths=['registration-target-metadata-before.json','invocation.json','started.json','stdout.log','stderr.log','terminal.json','after-pins.json','scope-verification.json','result.json'];files.extend(pin(d/n)for n in paths)
 checks.append(dict(name=m['id'],manifest=p,result=pin(d/'result.json'),terminal=pin(d/'terminal.json'),passed=True,exitCode=0,seconds=t['elapsedSeconds'],maxRssKiB=t['maxRssKiB'],expectedTests=m.get('expectedTests')))
assert len(checks)==5
for p in json.loads(Path(s['sourcePins']['path']).read_text()):assert pin(p['path'])==p
out=dict(status='all_five_scoped_gates_pass_pending_independent_result_review',at=datetime.now(timezone.utc).isoformat(),sequence=pin(B/'sequence.json'),rootGrants=[pin(B/'root-execution-grant-first-three-v1.json'),pin(B/'root-execution-grant-last-two-v1.json')],checks=checks,files=files,sourcePins=s['sourcePins'],all266SourcePinsExact=True,currentProjectTypeScript='UNPASSED: both unknown-cause KGM SIGKILL attempts preserved; no compiler retry',normalReportExecuted=False,comparatorExecuted=False,automaticRetry=False)
with (B/'results-manifest-v1.json').open('x')as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps(dict(manifest=pin(B/'results-manifest-v1.json'),checks=checks),indent=2))
