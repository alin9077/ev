import test from "node:test";
import assert from "node:assert/strict";
import { applyBrandUpdates, prepareBrandResearch, brandVersionSnapshot, applyBrandTermFeatures, type BrandUpdatePacket } from "../src/lib/brand-updates";
import { storePortablePacks, hydratePortablePacks } from "../src/lib/portable-packs";
import { featureClaim } from "../src/lib/citable";
import { hasEarnedBuyerGrade } from "../src/lib/evidence-grading";
import type { Car, Fact, Feature, Research, Source, Pack } from "../src/lib/types";
function fixture() {
  const source: Source = {
    id: "fixture-maker-2026-10-14",
    url: "https://maker.example/au/specifications",
    title: "Synthetic fixture specification",
    publisher: "Maker",
    source_type: "manufacturer",
    published_date: null,
    accessed_date: "2026-10-14",
    market: "AU",
    supports: "Synthetic exact-version measurements for behavioural tests",
  };
  const fact: Fact = {
    key: "range_km",
    label: "Claimed range",
    value: 450,
    unit: "km",
    basis: "WLTP",
    comparisonBasis: "WLTP",
    status: "standard",
    sourceIds: [source.id],
    date: "2026-10-14",
    market: "AU",
    scope: "Maker Example Base",
    qualifications: [],
    issues: [],
  };
  const car: Car = {
    id: "fixture_maker_example__base__1",
    modelId: "fixture_maker_example",
    family: "fixture-maker-example",
    slug: "base-1",
    brand: "Maker",
    model: "Example",
    trim: "Base",
    year: null,
    generation: "Current",
    drive: "RWD",
    vehicleClass: "passenger",
    availability: "current_or_order_listed",
    availabilityEvidence: {
      checkedAt: "2026-10-14",
      orderStatus: "unverified",
      stockStatus: "unverified",
      sourceIds: [source.id],
      qualifications: ["Stock unverified."],
    },
    facts: {
      range_km: fact,
      seats: {
        ...fact,
        key: "seats",
        label: "Seats",
        value: 5,
        unit: "",
        basis: "Occupied seats",
        comparisonBasis: "Occupied seats",
      },
    },
    issues: [],
  };
  const research: Research = {
    schema_version: "fixture",
    metadata: {
      as_of: "2026-10-14",
      baseline_variant_id: car.id,
      record_count: 1,
      criterion_count: 1,
      feature_row_count: 1,
    },
    models: [
      {
        id: car.modelId,
        brand: car.brand,
        model: car.model,
        generation: car.generation,
      },
    ],
    variants: [
      {
        id: car.id,
        model_id: car.modelId,
        brand: car.brand,
        model: car.model,
        trim: car.trim,
        model_year: null,
        record_state: car.availability,
        price_aud: null,
        price_basis: "",
        range_km: null,
        range_cycle: "",
        seats: null,
        source_ids: [source.id],
        notes: [],
        variant_review_date: "2026-10-14",
        drive: "RWD",
        vehicle_class: "passenger",
      },
    ],
    criteria: [
      {
        key: "fixture",
        label: "Fixture",
        group: "Fixture",
        definition: "Fixture",
      },
    ],
    trim_equipment: [{ variant_id: car.id, source_ids: [] }],
    feature_evidence: [
      {
        variant_id: car.id,
        model_id: car.modelId,
        criterion: "fixture",
        value: "Needs confirmation",
        status: "not_verified",
        conditions: "Unknown",
        source_ids: [],
        evidence_scope: "Fixture",
        last_evidence_date: "2026-10-14",
        reviewed_date: "2026-10-14",
        verification_state: "unverified",
      },
    ],
    update_eligibility: [
      {
        variant_id: car.id,
        model_id: car.modelId,
        documented_family_minimum: null,
        exact_total_known: false,
        exact_total: null,
        scope: "Unknown",
        meaning: "Research pending",
        source_ids: [],
        observation_window_start: "2026-10-14",
        observation_window_end: "2026-10-14",
      },
    ],
    update_events: [],
    configuration_history: [],
    sources: [source],
    publication_issues: [],
    prior_update_summary: [],
  };
  const packet: BrandUpdatePacket = {
    schemaVersion: 1,
    id: "m1-fixture-2026-10-14",
    brand: car.brand,
    reviewedAt: "2026-10-14",
    reviewedBy: "Fixture review",
    sources: [source],
    models: [],
    variants: [],
    versionGuards: [{ variantId: car.id, before: brandVersionSnapshot(car) }],
    versionUpdates: [],
    facts: [],
    availability: [],
    summaries: [],
  };
  const grade = (input: Fact, owner = packet): Fact => ({
    ...structuredClone(input),
    buyerGrade: "confirmed",
    gradeReview: {
      reviewedAt: owner.reviewedAt,
      overlayId: owner.id,
      reason: "Exact Australian version confirmed by maker fixture",
      evidenceScope: "exact_au_version",
      sourceIds: [...input.sourceIds],
    },
  });
  return { car, source, fact, research, packet, grade };
}


function reviewedDriveawayFixture(state?: string) {
  const data = fixture();
  const price: Fact = {
    ...data.grade(data.fact),
    key: "price_aud",
    label: "Published price",
    value: 39990,
    unit: "AUD",
    basis: state
      ? "Maker state driveaway offer"
      : "Maker national driveaway offer",
    comparisonBasis: "Driveaway",
    status: "conditional",
    buyerGrade: "check",
    qualifications: ["Private retail buyers; metallic paint excluded."],
    conditionExplanation:
      "Order by the stated deadline; subject to allocation.",
    validUntil: "2026-12-15",
    priceEvidence: {
      rung: state ? 4 : 2,
      basisTag: state
        ? `Maker's ${state} driveaway`
        : "Maker's national driveaway",
      sourceKey: "fixture_driveaway_offer",
      sourcePointer: data.source.url,
      ...(state ? { state } : {}),
      originalBasis: "Maker's explicitly published driveaway offer",
      rankingEligible: true,
    },
  };
  data.car.facts.price_aud = price;
  const feature: Feature = {
    ...data.research.feature_evidence[0],
    criterion: "driveaway_price",
    value: "Request an older quote",
    conditions: "Superseded quotation conditions.",
    gradeReviewStatus: "review_required",
    usability_notes: ["Superseded quote note."],
    confirmation_needed: "Superseded quote request.",
  };
  return { ...data, price, feature };
}

test("reviewed national and state driveaway facts project value, provenance and conditions into feature claims", () => {
  for (const state of [undefined, "NSW"]) {
    const { car, source, price, feature, research } =
      reviewedDriveawayFixture(state);
    const unrelated: Feature = { ...feature, criterion: "unrelated_fixture" };
    const before = structuredClone({ car, source, feature, unrelated });
    const features = applyBrandTermFeatures(car, [feature, unrelated]);
    const projected = features[0];
    assert.equal(projected.value, "A$39,990");
    assert.equal(projected.status, price.status);
    assert.equal(projected.buyerGrade, price.buyerGrade);
    assert.deepEqual(projected.gradeReview, price.gradeReview);
    assert.equal(Object.hasOwn(projected, "gradeReviewStatus"), false);
    assert.deepEqual(projected.source_ids, price.sourceIds);
    assert.equal(projected.last_evidence_date, price.date);
    assert.equal(projected.reviewed_date, price.gradeReview!.reviewedAt);
    assert.equal(projected.evidence_scope, price.scope);
    assert.match(
      projected.conditions,
      /Private retail buyers; metallic paint excluded/,
    );
    assert.match(
      projected.conditions,
      /Order by the stated deadline; subject to allocation/,
    );
    assert.match(projected.conditions, /Offer deadline: 2026-12-15/);
    assert.equal(
      projected.conditions.includes("Driveaway price applies in NSW."),
      !!state,
    );
    assert.ok(
      projected.condition_label!.includes(price.priceEvidence!.basisTag),
    );
    assert.deepEqual(projected.usability_notes, []);
    assert.equal(projected.confirmation_needed, "");
    assert.doesNotMatch(projected.conditions, /Superseded/);
    assert.equal(features[1], unrelated);
    const pack: Pack = {
      car,
      features,
      eligibility: research.update_eligibility[0],
      events: [],
      configuration: [],
      sources: [source],
    };
    const claim = featureClaim(pack, "driveaway_price", "Driveaway price")!;
    assert.equal(claim.value, "A$39,990");
    assert.equal(claim.evidenceDate, price.date);
    assert.equal(claim.buyerGrade, "check");
    assert.equal(claim.gradeReviewStatus, undefined);
    assert.deepEqual(claim.gradeReview, price.gradeReview);
    assert.deepEqual(
      claim.sources.map((citation) => citation.id),
      price.sourceIds,
    );
    assert.equal(claim.sources[0].url, source.url);
    assert.equal(claim.sources[0].accessed_date, source.accessed_date);
    assert.ok(claim.basis.includes(price.priceEvidence!.basisTag));
    assert.match(claim.qualifications.join(" "), /Offer deadline: 2026-12-15/);
    assert.equal(
      claim.qualifications
        .join(" ")
        .includes("Driveaway price applies in NSW."),
      !!state,
    );
    assert.doesNotMatch(claim.sentence, /Superseded|review required/i);
    assert.deepEqual({ car, source, feature, unrelated }, before);
    projected.source_ids.push("local-mutation");
    projected.gradeReview!.sourceIds.push("local-mutation");
    assert.deepEqual({ car, source, feature, unrelated }, before);
  }
});

test("before-on-road canonical prices preserve separately sourced driveaway feature evidence", () => {
  const { car, price, feature } = reviewedDriveawayFixture();
  car.facts.price_aud = {
    ...price,
    comparisonBasis: "Before on-road costs",
    basis: "Maker list price before on-road costs",
    status: "standard",
    buyerGrade: "confirmed",
    priceEvidence: {
      ...price.priceEvidence!,
      rung: 1,
      basisTag: "Maker list price",
    },
  };
  const before = structuredClone({ car, feature });
  const projected = applyBrandTermFeatures(car, [feature])[0];
  assert.equal(projected, feature);
  assert.deepEqual({ car, feature }, before);
});

test("withdrawn or incomplete canonical driveaway reviews never replace the separate feature", () => {
  const { car, price, feature } = reviewedDriveawayFixture("NSW");
  const variants: Fact[] = [
    { ...price, gradeReviewStatus: "review_required" },
    { ...price, buyerGrade: undefined },
    { ...price, gradeReview: undefined },
    { ...price, priceEvidence: undefined },
    { ...price, value: null },
  ];
  for (const unreviewed of variants) {
    const candidate = {
      ...car,
      facts: { ...car.facts, price_aud: unreviewed },
    };
    const before = structuredClone({ candidate, feature });
    assert.equal(applyBrandTermFeatures(candidate, [feature])[0], feature);
    assert.deepEqual({ candidate, feature }, before);
  }
});

test("a separately reviewed driveaway offer updates its answer without replacing the higher-rung list price", () => {
  const { car, price, feature } = reviewedDriveawayFixture("NSW");
  car.facts.price_aud = {
    ...price,
    value: 35990,
    comparisonBasis: "Before on-road costs",
    basis: "Maker list price before on-road costs",
  };
  const offer = { ...price, key: "promotional_driveaway_aud" };
  car.facts.promotional_driveaway_aud = offer;
  const original = structuredClone({ car, feature });
  const projected = applyBrandTermFeatures(car, [feature])[0];
  assert.equal(projected.value, "A$39,990");
  assert.equal(car.facts.price_aud.value, 35990);
  assert.match(projected.conditions, /Offer deadline: 2026-12-15/);
  assert.match(projected.conditions, /applies in NSW/);
  assert.deepEqual(projected.source_ids, offer.sourceIds);
  assert.deepEqual(projected.gradeReview, offer.gradeReview);
  assert.deepEqual({ car, feature }, original);
  for (const invalid of [
    { ...offer, gradeReviewStatus: "review_required" as const },
    { ...offer, priceEvidence: undefined },
    { ...offer, comparisonBasis: "Before on-road costs" },
    { ...offer, value: null },
  ]) {
    const candidate = {
      ...car,
      facts: { ...car.facts, promotional_driveaway_aud: invalid },
    };
    assert.equal(applyBrandTermFeatures(candidate, [feature])[0], feature);
  }
});

test("supplemental driveaway offers require the same price provenance as canonical prices", () => {
  const { car, price, packet, research } = reviewedDriveawayFixture();
  const offer = { ...price, key: "promotional_driveaway_aud" };
  packet.facts = [{ variantId: car.id, before: null, after: offer }];
  assert.equal(
    applyBrandUpdates([car], research, [packet])[0].facts
      .promotional_driveaway_aud.value,
    price.value,
  );
  for (const invalid of [
    { ...offer, priceEvidence: undefined },
    {
      ...offer,
      priceEvidence: {
        ...offer.priceEvidence!,
        sourcePointer: "",
      },
    },
    { ...offer, comparisonBasis: "Before on-road costs" },
  ]) {
    assert.throws(
      () =>
        applyBrandUpdates([car], research, [
          {
            ...packet,
            facts: [{ variantId: car.id, before: null, after: invalid }],
          },
        ]),
      /price|driveaway/i,
    );
  }
});

test("brand price validation rejects basis flips on flexible rungs without losing legitimate reported prices", () => {
  for (const rung of [3, 5, 6] as const) {
    for (const comparisonBasis of [
      "Before on-road costs",
      "Driveaway",
    ] as const) {
      const { car, price, packet, research } = reviewedDriveawayFixture();
      const reported = rung >= 5;
      const fact: Fact = {
        ...price,
        comparisonBasis,
        basis: `Named version price · ${comparisonBasis}`,
        buyerGrade: reported ? "reported" : "check",
        resolvedElsewhere: reported,
        gradeReview: {
          ...price.gradeReview!,
          evidenceScope: reported ? "secondary_or_sibling" : "exact_au_version",
        },
        priceEvidence: {
          ...price.priceEvidence!,
          rung,
          basisTag: `Named version price · ${comparisonBasis}`,
          originalBasis: `Published price ${comparisonBasis}`,
          rankingEligible: !reported,
          ...(rung === 5 ? { publisher: "Example Motoring" } : {}),
        },
      };
      packet.facts = [{ variantId: car.id, before: price, after: fact }];
      const before = structuredClone({ car, research, packet });
      const updated = applyBrandUpdates([car], research, [packet])[0].facts
        .price_aud;
      assert.equal(updated.value, fact.value);
      assert.equal(updated.comparisonBasis, comparisonBasis);
      assert.equal(updated.buyerGrade, reported ? "reported" : "check");
      assert.equal(updated.priceEvidence?.rankingEligible, !reported);
      const corrupted = structuredClone(packet);
      corrupted.facts[0].after.comparisonBasis =
        comparisonBasis === "Driveaway" ? "Before on-road costs" : "Driveaway";
      assert.throws(
        () => applyBrandUpdates([car], research, [corrupted]),
        /comparison basis contradicts retained price provenance/,
      );
      assert.deepEqual({ car, research, packet }, before);
    }
  }
});


function publishedDriveawayFixture() {
  const data = reviewedDriveawayFixture("NSW");
  const published: Fact = {
    ...structuredClone(data.price),
    key: "published_driveaway_aud",
    label: "Published driveaway estimate",
    value: 43990,
    basis: "Maker driveaway estimate · NSW 2000",
    qualifications: ["NSW 2000; standard paint and interior; private purchaser.", "Estimated total; confirm the final retailer price."],
    conditionExplanation: "Postcode-specific estimate, not a promotional offer or accepted order.",
    priceEvidence: {
      ...data.price.priceEvidence!,
      sourceKey: "published_driveaway_aud",
      basisTag: "Maker driveaway estimate · NSW",
      originalBasis: "Published driveaway estimate for NSW 2000",
    },
  };
  delete published.validUntil;
  data.car.facts.price_aud = {
    ...structuredClone(data.price), value: 35990,
    comparisonBasis: "Before on-road costs", basis: "Maker list price before on-road costs",
    buyerGrade: "confirmed", status: "standard", qualifications: [],
    priceEvidence: { ...data.price.priceEvidence!, rung: 1, basisTag: "Before on-road costs", originalBasis: "Maker list price before on-road costs" },
  };
  delete data.car.facts.price_aud.validUntil;
  return { ...data, published };
}

test("ordinary published driveaway estimates retain the list-price primary and exact state/source qualifications", () => {
  const { car, source, research, packet, published, feature } = publishedDriveawayFixture();
  packet.facts = [{ variantId: car.id, before: null, after: published }];
  const before = structuredClone({ car, source, research, packet, feature });
  const prepared = prepareBrandResearch(research, [packet]);
  const updated = applyBrandUpdates([car], prepared, [packet])[0];
  const unrelated: Feature = { ...feature, criterion: "unrelated_fixture" };
  const features = applyBrandTermFeatures(updated, [feature, unrelated], prepared.sources);
  const projected = features[0];
  assert.equal(updated.facts.price_aud.value, 35990);
  assert.equal(updated.facts.price_aud.comparisonBasis, "Before on-road costs");
  assert.equal(projected.value, "A$43,990");
  assert.equal(projected.verification_state, "reviewed_published_driveaway_price");
  assert.equal(projected.buyerGrade, "check");
  assert.deepEqual(projected.source_ids, published.sourceIds);
  assert.deepEqual(projected.gradeReview, published.gradeReview);
  assert.equal(projected.last_evidence_date, published.date);
  assert.equal(projected.reviewed_date, published.gradeReview!.reviewedAt);
  assert.match(projected.condition_label!, /estimate.*NSW/i);
  assert.match(projected.conditions, /NSW 2000/);
  assert.match(projected.conditions, /not a promotional offer/);
  assert.match(projected.conditions, /applies in NSW/);
  assert.doesNotMatch(projected.conditions, /Offer deadline|Superseded/);
  assert.equal(Object.hasOwn(projected, "validUntil"), false);
  assert.equal(Object.hasOwn(projected, "gradeReviewStatus"), false);
  assert.equal(features[1], unrelated);
  const pack: Pack = { car: updated, features, sources: prepared.sources, eligibility: research.update_eligibility[0], events: [], configuration: [] };
  const claim = featureClaim(pack, "driveaway_price", "Driveaway price", packet.reviewedAt)!;
  assert.equal(claim.value, "A$43,990");
  assert.equal(claim.evidenceDate, published.date);
  assert.equal(claim.buyerGrade, "check");
  assert.equal(claim.sources[0].url, source.url);
  assert.match(claim.basis, /estimate.*NSW/i);
  assert.match(claim.qualifications.join(" "), /NSW 2000/);
  const stored = storePortablePacks({ [car.id]: pack });
  assert.deepEqual(hydratePortablePacks(stored, prepared.sources), { [car.id]: pack });
  const written = JSON.parse(JSON.stringify(stored));
  const hydrated = hydratePortablePacks(written, prepared.sources);
  assert.deepEqual(hydrated, { [car.id]: pack });
  assert.deepEqual(featureClaim(hydrated[car.id], "driveaway_price", "Driveaway price", packet.reviewedAt), claim);
  assert.deepEqual({ car, source, research, packet, feature }, before);
});

test("ordinary driveaway fallback preserves main then promotional precedence", () => {
  const { car, source, price, feature, published } = publishedDriveawayFixture();
  car.facts.published_driveaway_aud = published;
  car.facts.promotional_driveaway_aud = { ...price, key: "promotional_driveaway_aud", value: 40990 };
  const list = car.facts.price_aud;
  car.facts.price_aud = { ...price, value: 41990 };
  assert.equal(applyBrandTermFeatures(car, [feature], [source])[0].value, "A$41,990");
  car.facts.price_aud = list;
  assert.equal(applyBrandTermFeatures(car, [feature], [source])[0].value, "A$40,990");
  delete car.facts.promotional_driveaway_aud;
  assert.equal(applyBrandTermFeatures(car, [feature], [source])[0].value, "A$43,990");
  delete car.facts.published_driveaway_aud;
  assert.equal(applyBrandTermFeatures(car, [feature], [source])[0], feature);
});

test("ordinary driveaway packet admission rejects invalid ladder provenance, units, state and basis", () => {
  const { car, research, packet, published } = publishedDriveawayFixture();
  const invalid: Fact[] = [
    { ...published, priceEvidence: undefined },
    { ...published, priceEvidence: { ...published.priceEvidence!, sourcePointer: "" } },
    { ...published, priceEvidence: { ...published.priceEvidence!, sourceKey: "" } },
    { ...published, priceEvidence: { ...published.priceEvidence!, state: "Australia" } },
    { ...published, priceEvidence: { ...published.priceEvidence!, originalBasis: "Before on-road costs" } },
    { ...published, priceEvidence: { ...published.priceEvidence!, rung: 1 } },
    { ...published, comparisonBasis: "Before on-road costs" },
    { ...published, comparisonBasis: "" },
    { ...published, unit: "USD" },
    { ...published, value: -1 },
    { ...published, sourceIds: [] },
    { ...published, sourceIds: [published.sourceIds[0], published.sourceIds[0]] },
  ];
  for (const after of invalid) assert.throws(() => applyBrandUpdates([car], research, [{ ...packet, facts: [{ variantId: car.id, before: null, after }] }]), /price|driveaway|source|grade|fact|state|provenance/i);
});

test("ordinary driveaway projection requires current earned provenance and never projects a before-ORC value", () => {
  const { car, source, feature, published } = publishedDriveawayFixture();
  for (const candidate of [
    { ...published, comparisonBasis: "Before on-road costs" },
    { ...published, market: "NZ" },
    { ...published, status: "not_verified" as const },
    { ...published, gradeReviewStatus: "review_required" as const },
    { ...published, buyerGrade: undefined },
    { ...published, gradeReview: undefined },
    { ...published, priceEvidence: undefined },
    { ...published, priceEvidence: { ...published.priceEvidence!, sourcePointer: "" } },
    { ...published, priceEvidence: { ...published.priceEvidence!, state: "XX" } },
    { ...published, value: null },
    { ...published, sourceIds: [published.sourceIds[0], published.sourceIds[0]] },
  ]) {
    const changed = { ...car, facts: { ...car.facts, published_driveaway_aud: candidate } };
    assert.equal(applyBrandTermFeatures(changed, [feature], [source])[0], feature);
  }
  const current = { ...car, facts: { ...car.facts, published_driveaway_aud: published } };
  assert.equal(applyBrandTermFeatures(current, [feature])[0], feature, "new ordinary fallback requires source context");
  for (const sources of [[], [{ ...source, access_limitation: "Source withdrawn" }], [{ ...source, publication_hold: "Hold" }], [{ ...source, conflict: "Conflicting current source" }], [{ ...source, market: "NZ" }], [{ ...source, accessed_date: "2027-01-01" }]]) {
    assert.equal(applyBrandTermFeatures(current, [feature], sources)[0], feature);
  }
});

test("withdrawn reused driveaway projections lose their earned grade without damaging independent fallbacks", () => {
  const { car, source, feature, published } = publishedDriveawayFixture();
  const current = { ...car, facts: { ...car.facts, published_driveaway_aud: published } };
  const projected = applyBrandTermFeatures(current, [feature], [source])[0];
  const unrelated = { ...feature, criterion: "unrelated_fixture" };
  for (const [candidate, sources] of [
    [car, [source]],
    [{ ...current, facts: { ...current.facts, published_driveaway_aud: { ...published, value: null } } }, [source]],
    [{ ...current, facts: { ...current.facts, published_driveaway_aud: { ...published, gradeReviewStatus: "review_required" } } }, [source]],
    [{ ...current, facts: { ...current.facts, published_driveaway_aud: { ...published, comparisonBasis: "Before on-road costs" } } }, [source]],
    [current, []],
  ] as [Car, Source[]][]) {
    const before = structuredClone({ candidate, sources, projected, unrelated });
    for (const state of ["reviewed_published_driveaway_price", "reviewed_canonical_driveaway_price"]) {
      const reused = { ...projected, verification_state: state };
      const result = applyBrandTermFeatures(candidate, [reused, unrelated], sources);
      assert.equal(result[0].value, projected.value);
      assert.deepEqual(result[0].source_ids, projected.source_ids);
      assert.equal(result[0].buyerGrade, undefined);
      assert.equal(result[0].gradeReview, undefined);
      assert.equal(result[0].gradeReviewStatus, "review_required");
      assert.equal(hasEarnedBuyerGrade(result[0], sources, "2026-10-14"), false);
      assert.equal(result[1], unrelated);
      const pack: Pack = { car: candidate, features: result, sources, eligibility: { variant_id: candidate.id } as Pack["eligibility"], events: [], configuration: [] };
      const claim = featureClaim(pack, "driveaway_price", "Driveaway price", "2026-10-14")!;
      assert.equal(claim.gradeReviewStatus, "review_required");
      assert.equal(claim.buyerGrade, undefined);
      assert.match(claim.sentence, /review required/i);
    }
    assert.equal(applyBrandTermFeatures(candidate, [feature], sources)[0], feature);
    assert.deepEqual({ candidate, sources, projected, unrelated }, before);
  }
});
