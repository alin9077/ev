from pathlib import Path
import hashlib,json
R=Path('/workspace/scratch/586427eef9f2/roadmark-104'); O=Path('/tmp/deepal-packet/published-driveaway-validation-v1'); P=Path('/tmp/deepal-packet/published-driveaway-proposal-v2'); O.mkdir(exist_ok=False)
def pin(p):
 p=Path(p); b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
expected=json.loads(Path('/tmp/deepal-packet/selected-preflight-v2/expected-review.json').read_text())
expected['publishedDriveawayValues']={'deepal_e07_current__rwd__20261010':70058,'deepal_e07_current__awd_performance__20261010':79508}
save(O/'expected-review.json',expected)
# Exact bounded excerpts from the proposed test file: fixture, six pre-existing price tests,
# and five added tests. Imports are narrowed to the actual dependencies of those excerpts.
tests=(P/'tests/brand-updates.test.ts').read_text(); segments=[]
for name,start,end in [('fixture','function fixture() {','test("dated fact updates'),('driveaway_fixture_and_six_retained_tests','function reviewedDriveawayFixture(state?: string) {','test("a guarded valid replacement'),('published_fixture_and_five_added_tests','function publishedDriveawayFixture() {',None)]:
 a=tests.index(start);b=tests.index(end,a) if end else len(tests);segment=tests[a:b];segments.append(dict(name=name,startLine=tests[:a].count('\n')+1,endLine=tests[:b].count('\n'),sha256=hashlib.sha256(segment.encode()).hexdigest(),text=segment))
imports='''import test from "node:test";
import assert from "node:assert/strict";
import { applyBrandUpdates, prepareBrandResearch, brandVersionSnapshot, applyBrandTermFeatures, type BrandUpdatePacket } from "../src/lib/brand-updates";
import { storePortablePacks, hydratePortablePacks } from "../src/lib/portable-packs";
import { featureClaim } from "../src/lib/citable";
import { hasEarnedBuyerGrade } from "../src/lib/evidence-grading";
import type { Car, Fact, Feature, Research, Source, Pack } from "../src/lib/types";
'''
(O/'bounded-price-tests.ts').write_text(imports+'\n'.join(x['text'] for x in segments))
save(O/'test-extraction.json',dict(source=pin(P/'tests/brand-updates.test.ts'),segments=[{k:v for k,v in x.items() if k!='text'} for x in segments],testCount=11,status='prepared_not_executed',imports='Narrowed dependency imports; test bodies and fixture bodies are exact proposed-file excerpts.'))
s=Path('/tmp/deepal-packet/selected-preflight-v2/check.mjs').read_text().replace("'/tmp/deepal-packet/selected-preflight-v2'",repr(str(O))).replace("'/tmp/deepal-packet/v5/deepal-2026-10-15.json'","'/tmp/deepal-packet/v6/deepal-2026-10-15.json'").replace('bde29788d6aa73cb6cb0f7119713d68c67f16cc9807bd11e38fb3bd34737fc24','cef6b8712653ad1d504c65945d0790ec631f6748474e71ab6cada9ee859e4848')
s=s.replace("import fs from 'node:fs';", "import fs from 'node:fs';import vm from 'node:vm';")
old="const require=createRequire(repo+'/package.json');const brand=require('./src/lib/brand-updates.ts');"
new="""const require=createRequire(repo+'/package.json'),ts=require('typescript');
// Read only the frozen /tmp proposal; resolve unchanged imports against the real repo.
// This is the same transpile/vm mechanism as the project's compiledSource helper.
function compileFrozen(sourcePath,relativePath,overrides={}){const filename=repo+'/'+relativePath,source=fs.readFileSync(sourcePath,'utf8'),output=ts.transpileModule(source,{fileName:filename,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true}}).outputText;const scoped=createRequire(filename),module={exports:{}},load=id=>Object.hasOwn(overrides,id)?overrides[id]:scoped(id);vm.runInThisContext('(function(require,module,exports){'+output+'\\n})',{filename})(load,module,module.exports);return module.exports;}
const proposal='/tmp/deepal-packet/published-driveaway-proposal-v2';const brand=compileFrozen(proposal+'/src/lib/brand-updates.ts','src/lib/brand-updates.ts');"""
assert old in s;s=s.replace(old,new)
old="const factory=packets=>compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets:packets}}).createEvidenceConsumers(defaults);const initial=factory(brandUpdatePackets),final=factory([...brandUpdatePackets,packet]);"
new="""const initial=compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets}}).createEvidenceConsumers(defaults);
const final=compileFrozen(proposal+'/src/lib/evidence-consumers.ts','src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets:[...brandUpdatePackets,packet]},'./brand-updates':brand}).createEvidenceConsumers(defaults);
// Synchronous registered callbacks, not a test-runner fork: eleven exact test bodies,
// exercised sequentially under the same one-process memory/deadline envelope.
const testCases=[],testResults=[];compileFrozen(out+'/bounded-price-tests.ts','tests/brand-updates.test.ts',{'node:test':(name,fn)=>testCases.push({name,fn}),'../src/lib/brand-updates':brand});assert.equal(testCases.length,11);
for(const t of testCases){const start=performance.now();await t.fn();testResults.push({name:t.name,status:'passed',elapsedMs:performance.now()-start});}
fs.writeFileSync(out+'/price-tests.json',JSON.stringify({status:'passed',testCount:testResults.length,tests:testResults},null,2)+'\\n',{flag:'wx'});"""
assert old in s;s=s.replace(old,new)
start=s.index("}else{assert.equal(f.comparisonBasis,'Before on-road costs');")
end=s.index("}continue;}assert.deepEqual(feature,prior.features.find",start)
new="""}else{assert.equal(f.comparisonBasis,'Before on-road costs');assert(expected.expectedBeforeOrcIds.includes(car.id));const published=car.facts.published_driveaway_aud;assert(published);assert.equal(published.value,expected.publishedDriveawayValues[car.id]);assert.equal(feature.value,'A$'+published.value.toLocaleString('en-AU'));assert.notEqual(feature.value,'A$'+f.value.toLocaleString('en-AU'));assert.equal(feature.verification_state,'reviewed_published_driveaway_price');assert.equal(feature.buyerGrade,'check');assert.deepEqual(feature.source_ids,published.sourceIds);assert.deepEqual(feature.gradeReview,published.gradeReview);assert.equal(feature.last_evidence_date,'2026-10-15');assert.equal(feature.reviewed_date,'2026-10-15');assert.match(feature.condition_label,/estimate.*NSW/i);assert.match(feature.conditions,/2000/);assert.match(feature.conditions,/Driveaway price applies in NSW/);assert.doesNotMatch(feature.conditions,/not yet been researched|Superseded|Offer deadline/i);assert(!Object.hasOwn(feature,'validUntil'));assert(!Object.hasOwn(feature,'gradeReviewStatus'));priceFeatureRefreshes++;producerProofs.push({phase:'after',variantId:car.id,kind:'ordinary_published_driveaway_projection',producer:'proposed actual applyBrandTermFeatures with current effective sources; price_aud remains before-ORC',primaryPrice:structuredClone(f),publishedFact:structuredClone(published),feature:structuredClone(feature)});"""
s=s[:start]+new+s[end:]
s=s.replace('assert.equal(priceFeatureRefreshes,1);','assert.equal(priceFeatureRefreshes,3);')
s=s.replace("else{assert(expected.expectedBeforeOrcIds.includes(o.variantId));const frame=producerFrames.get('after\\0'+o.variantId);assert.deepEqual(a,frame.regraded.find(f=>f.criterion===o.criterion));}","else{assert.fail('Fresh reviewed price projections must not retain optional undefined properties: '+o.pointer);}")
s=s.replace("explicitDriveawayFeatureRefreshes:priceFeatureRefreshes,beforeOrcSourceFallbacks:2", "explicitDriveawayFeatureRefreshes:priceFeatureRefreshes,beforeOrcPrimaryPricesPreserved:2,ordinaryPublishedDriveawayProjections:2,priceRegressionTests:testResults")
s=s.replace("status:'selected_actual_consumers_and_exact_serialization_witness_pass'", "status:'proposed_ordinary_driveaway_selected_actual_validation_pass'")
# Assert exact citable and written portable answer parity independently for both ordinary totals.
needle="assert.deepEqual(readJson(out+'/selected-packs.json'),copy);"
insert="""for(const id of expected.expectedBeforeOrcIds){const live=featureClaim(afterPacks[id],'driveaway_price','driveaway_price',packet.reviewedAt),written=featureClaim(hydratePortablePacks(readJson(out+'/portable.json'),data.sources)[id],'driveaway_price','driveaway_price',packet.reviewedAt);assert.deepEqual(written,live);assert.equal(live.value,'A$'+expected.publishedDriveawayValues[id].toLocaleString('en-AU'));assert.equal(live.evidenceDate,'2026-10-15');assert.equal(live.buyerGrade,'check');assert(live.sources.length);assert.match(live.basis,/estimate.*NSW/i);assert.match(live.qualifications.join(' '),/2000/);assert.doesNotMatch(live.sentence,/not yet been researched|Needs confirmation|review required|Offer deadline/i);}
"""
assert needle in s;s=s.replace(needle,insert+needle)
(O/'check.mjs').write_text(s)
pins=json.loads(Path('/tmp/deepal-packet/selected-preflight-v2/source-pins.json').read_text())
pins=[p for p in pins if p['path']!='/tmp/deepal-packet/selected-preflight-v2/expected-review.json']
for p in [O/'expected-review.json',O/'bounded-price-tests.ts',O/'test-extraction.json',P/'manifest.json',P/'proposal.patch',*[P/f for f in ['src/lib/brand-updates.ts','src/lib/evidence-consumers.ts','tests/brand-updates.test.ts']],R/'tests/brand-updates.test.ts',Path('/tmp/deepal-research/normalized-review-v6.json'),Path('/tmp/deepal-packet/v6/v5-to-v6-fact-delta.json')]:pins.append(pin(p))
save(O/'source-pins.json',pins)
wrapper=Path('/tmp/deepal-packet/selected-preflight-v2/run.py').read_text().replace('4dcca516c56c203f9b9087b8f46f9e47cf560c4b2383e66d8585583c3f070a53',pin(O/'check.mjs')['sha256']).replace('bde29788d6aa73cb6cb0f7119713d68c67f16cc9807bd11e38fb3bd34737fc24','cef6b8712653ad1d504c65945d0790ec631f6748474e71ab6cada9ee859e4848')
(O/'run.py').write_text(wrapper)
manifest=dict(status='prepared_not_executed',script=pin(O/'check.mjs'),sourcePins=pin(O/'source-pins.json'),packet=pin('/tmp/deepal-packet/v6/deepal-2026-10-15.json'),reconciliation=pin('/tmp/deepal-packet/reconciliation-v2/m1-deepal-market-reconciliation-2026-10-15.json'),wrapper=pin(O/'run.py'),proposal=pin(P/'proposal.patch'),command=['node','--max-old-space-size=448','--max-semi-space-size=1','--import','tsx',str(O/'check.mjs'),'--root-execution-granted'],workdir=str(R),timeoutSeconds=180,automaticRetry=False,rootExecutionGrantRequired=True,scope='One process: six retained price-regression tests and five new ordinary-estimate tests using exact fixture/test-body excerpts and frozen proposed brand helper; then selected actual original/proposed consumers for three retained Deepal before/after cars, 64 exact fact guards plus6 termcells,51 coregrades,all207 featureclaims,sourceclosure,ranking,cleansummaries,availability,C1 body/trimidentities with S05unresolved,and live/writtenportableparity. Three canonical price answers including the two sourced ordinary NSW2000 E07 estimates with unchanged before-ORC primary prices. Same-run derived optional-property witnesses. No live edits/fullcatalogue hydration/global-neutrality claim/compiler typecheck/retry. TranspileModule is the existing actual-function harness mechanism, not a full-project compile.')
save(O/'prepared-command.json',manifest)
print(json.dumps(dict(manifest=pin(O/'prepared-command.json'),script=manifest['script'],wrapper=manifest['wrapper'],proposal=manifest['proposal'],pinCount=len(pins)),indent=2))
