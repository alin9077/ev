# Deepal: refreshed cold full-project TypeScript gate v2

Status: prepared only. No wrapper, Node, TypeScript, test, validator, hydration, scan, install, generated-type command, compression or server was run during preparation. No repository file was edited. This packet is not an execution grant.

## Exact proposed check

From `/workspace/scratch/586427eef9f2/roadmark-104`, the wrapper would run exactly:

```text
/usr/bin/timeout --signal=TERM --kill-after=10s 900s /opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node --max-old-space-size=768 --max-semi-space-size=1 /workspace/scratch/586427eef9f2/roadmark-104/node_modules/typescript/bin/tsc --noEmit --tsBuildInfoFile /tmp/deepal-packet/full-project-typescript-v2/run/full-project.tsbuildinfo
```

The original implicit `tsconfig.json` selection, all includes/excludes, strictness, skipLibCheck, incremental mode, generated types and normal transitive resolution stay intact. The only compiler-option override beyond noEmit is the fresh cache destination. No root-file list is supplied to TypeScript. The live `tsconfig.tsbuildinfo` is content-pinned before and after. A new output directory is required and is never reused or removed.

The process-group watchdog acts only if the timeout supervisor remains alive beyond 920 seconds. Core dumps are disabled in the child. Inherited NODE_OPTIONS, NODE_PATH, NODE_COMPILE_CACHE, TS_NODE_PROJECT, TS_NODE_COMPILER_OPTIONS and TS_NODE_TRANSPILE_ONLY are removed; NODE_DISABLE_COMPILE_CACHE=1. Exactly one compiler attempt is permitted. No automatic retry, fallback checker, resource increase, install or regeneration is provided. V8 heap flags are not an OS RSS cap.

## Fresh freeze and application verification

This v2 supersedes the unexecuted v1 preparation after an independently accepted one-file test correction. v1 remains untouched. The seven-file Deepal registration remains unchanged. Only tests/citable.test.ts has changed since v1: 10,193 to 13,548 bytes with its expected mtime update; all 361 root names and every other recorded root/directory stat remain unchanged. Its new SHA-256 is `7950677521142cb6f99df055fe82551c8a293e292f644c8f26e5d8f01c55adf2`.

The correction manifest SHA-256 is `331857f1b924f0be081c780b6e5f9d6e822c8acac8d3d4a2a69f6435db0640b0`; application result is `2cd22c182169015bcb77f4c18ec1349bc2568523e2da36b6fc988fde658e6ff0`; independent readback is `007195e7b4f129a5026c8665fcaa7935464a22504822fa2c57649ea768a301e1`. The stale VW fixture was corrected without product-code or catalogue changes. The original 143-test result remains failed (142 passed, 1 failed); no status is rewritten. Focused checks and a fresh 144-test aggregate still need accepted passing receipts before this compiler gate can run.

- Exact registration manifest SHA-256: `a50e418f43a2c1ad9c03d044b0761c575226eaf5db47b58ed7ed8f5f3dddc0c5`
- All seven live targets match their accepted byte counts and after hashes
- Independent application readback review SHA-256: `c6502d1a545450e91caf24c2cf8949cdd9d5b0b6efe9b1b9d6354d3016980e36`
- Current root names were refreshed from the original configured globs: exactly 361, with no additions or removals
- Pattern counts: next-env=1; src TypeScript=117; src TSX=54; tests=168; scripts=17; .next/types=4; .next/dev/types=0
- Before the later citable correction, only four configured-root stat records differed from accepted Audi v2: `src/lib/brand-updates.ts`, `src/lib/evidence-consumers.ts`, `tests/brand-updates.test.ts`, and `scripts/reporting/load.ts`. Each has only the expected byte-size and mtime changes from registration. Directory metadata is unchanged
- The other three applied targets are the registry JSON replacement and the new Deepal packet/reconciliation JSON files. They are content-pinned data inputs, not additional tsconfig roots
- All 134 v1 named content pins still match, including all 32 old Audi named pins. The expanded 141-pin set retains all seven targets, all 26 ordered packets, loader-selected reconciliation JSON, directly named consumer data, relevant unchanged source/test helpers, config, compiler/dependency entrypoints, generated types, live cache and accepted proof receipts; adds an explicit content pin for tests/citable.test.ts, the three correction application/readback records, and the exact focused-check sequence/two manifests
- `metadata-delta.json` records the sole new citable metadata change against v1; the preserved v1 application-verification.json remains pinned for seven-target readback. `correction-provenance.json` retains the failed aggregate and accepted correction provenance
- Stat metadata is not a whole-project byte freeze. No whole-tree content recapture is claimed

The successful Audi v2 precedent completed in 43.455958 seconds with 874,928 KiB wait4 max RSS, exit 0, unchanged pins and exact 361-root proof. That evidence is retained in `prior-attempts.json` alongside the older OOM/diagnostic history. It does not establish a Deepal pass or reserve current memory. Runtime versions come from the accepted precedent, with installed-package content pins and runtime metadata reverified without invoking Node.

## Required reviews and grant

The focused correction gate is additional to, and does not replace, any of the five original preceding checks. Its exact sequence is `/tmp/deepal-packet/vw-citable-focused-checks-v1/sequence.json`, SHA-256 `a1eee9f728fe11f56b3d20c9c31ebbb3e3a1dcbb74a888106a620546d45555a6`. The order is `one-file-lint`, then `focused-citable-tests` (all 14 tests). Root must set focusedCorrectionChecksAccepted=true and provide a focusedCorrectionVerification pin. That future JSON requires status="accepted", correctionManifestSha256 equal to the correction manifest above, and checks in this order, each with name, passed=true, exitCode=0, and manifest/result/terminal content pins. Manifest paths/hashes must match the frozen focused manifests in the TypeScript manifest. Results require passed=true, exitCode=0 and matching manifestSha256; terminals require exitCode=0.

The original five-check names and straight passing contract remain unchanged. Market-view/four-file lint may use their accepted retained results; behavioural-suites must point to the fresh post-correction 144-test aggregate. The wrapper checks its manifest expectedTests=144. The retained failed 143-test aggregate can never satisfy that gate. Live-brand-safety and structural-validation still require their own successful receipts. src/lib/data.ts was already content-pinned in v1 and remains unchanged; its SHA-256 is `a1deee5939dd30856494d49e152c0b2f51caeaec5ccdff02275689beb70afaab`.

1. Independently review this exact manifest, wrapper, pins and root inventory. The readiness JSON must have `status: "accepted"`, and `manifest`/`wrapper` objects containing the exact corresponding path and SHA-256
2. Independently accept the five preceding gates: market-view, changed-file-lint, behavioural-suites, live-brand-safety, structural-validation
3. Produce a preceding-check verification JSON with `status: "accepted"`, the exact `applicationManifestSha256`, and `checks` in that exact order. Each item needs `name`, `passed: true`, `exitCode: 0`, and `manifest`, `result`, `terminal` content pins (`path`, `bytes`, `sha256`, optional `realpath`). Each pinned result must contain `passed: true`, `exitCode: 0`, and its manifest SHA-256; each terminal must show exit 0. A reviewer acceptance receipt with those fields satisfies this contract
4. Root fills a separate grant using `root-grant-template.json`, confirms accepted application, correction, focused checks and all five prerequisites and the exclusive heavy slot, and changes status to `root_execution_granted`. The template itself is never executable authority
5. Only then may root invoke the wrapper with exact manifest and grant hashes:

```text
python /tmp/deepal-packet/full-project-typescript-v2/run.py /tmp/deepal-packet/full-project-typescript-v2/manifest.json <EXACT_MANIFEST_SHA256> <ROOT_GRANT_PATH> <EXACT_ROOT_GRANT_SHA256>
```

Do not run `prepare.py` again or modify a frozen artifact after acceptance. Any changed proposal needs a new exact review and grant. Do not substitute an earlier Audi focused-correction receipt, v1 readiness or the failed behavioural result for these v2 prerequisites.

## Receipts and pass standard

Only `/tmp/deepal-packet/full-project-typescript-v2/run/**` may be written by an authorised run. Retain invocation, start PID/process-group, stdout/stderr, wait4 terminal/resource receipt, after-pins, fresh-cache scope-verification and final result. Failures remain in place. Preflight rejection after valid grant, process-setup failure and caught wrapper interruption also retain failure/terminal/result records; none authorises a retry.

Pass requires all of: compiler exit 0, unchanged named input hashes and configured-root metadata, fresh installed-TypeScript tsbuildinfo whose root IDs resolve to exactly the refreshed 361 roots, unchanged live cache, and no watchdog intervention. A missing/invalid cache or missing prerequisite blocks a pass. This is a fresh cold full-project TypeScript check, not a literal package-script run and not `next build`. It does not claim global M1 completion, browser QA, publishing or normal-report acceptance.

## Static preparation checks

Preparation used Python filesystem metadata/hash operations, bounded named source/dependency reads and Python AST parsing only. `run.py` was inspected, not imported or executed. `prepare.py` reproduces how these artifacts were assembled, but its output files are create-only. `static-verification.json` records the final static consistency pass.
