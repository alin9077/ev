"""Prepare only: refresh v1 for the reviewed one-file VW citable fixture correction."""
from pathlib import Path
from datetime import datetime, timezone
import ast, copy, hashlib, json
B=Path('/tmp/deepal-packet/full-project-typescript-v2')
V=Path('/tmp/deepal-packet/full-project-typescript-v1')
C=Path('/tmp/deepal-packet/vw-citable-fixture-correction-v1')
R=Path('/workspace/scratch/586427eef9f2/roadmark-104')
REVIEW=Path('/tmp/deepal-review/VW-CITABLE-CORRECTION-READBACK.json')
CORRECTION_SHA='331857f1b924f0be081c780b6e5f9d6e822c8acac8d3d4a2a69f6435db0640b0'
RESULT_SHA='2cd22c182169015bcb77f4c18ec1349bc2568523e2da36b6fc988fde658e6ff0'
READBACK_SHA='007195e7b4f129a5026c8665fcaa7935464a22504822fa2c57649ea768a301e1'
FOCUSED=Path('/tmp/deepal-packet/vw-citable-focused-checks-v1')
TARGET_SHA='7950677521142cb6f99df055fe82551c8a293e292f644c8f26e5d8f01c55adf2'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while x:=f.read(1024*1024):h.update(x)
 return h.hexdigest()
def pin(p):
 p=Path(p);return {'path':str(p),'realpath':str(p.resolve()),'bytes':p.stat().st_size,'sha256':sha(p)}
def verify(p):
 actual=pin(p['path']);assert all(actual[k]==v for k,v in p.items()),p['path'];return actual
def meta(p):
 p=Path(p)
 if not p.exists():return {'path':str(p),'exists':False}
 s=p.stat();return {'path':str(p),'exists':True,'realpath':str(p.resolve()),'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'mode':s.st_mode,'isDirectory':p.is_dir(),'isSymlink':p.is_symlink()}
def write(n,v):
 with (B/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
assert sha(V/'manifest.json')=='aaefcc3c5a854cd8b8f21786de266f7942f2834e8b1dce1d539b15c8d77a8c87'
m=json.loads((V/'manifest.json').read_text())
for key in ['wrapper','preparer','inputPins','projectRootMetadata','priorAttempts','metadataDelta']:verify(m[key])
assert not (V/'run').exists() and not (V/'root-grant.json').exists()
assert sha(C/'manifest.json')==CORRECTION_SHA
assert sha(C/'application/result.json')==RESULT_SHA and sha(REVIEW)==READBACK_SHA
correction=json.loads((C/'manifest.json').read_text())
application=json.loads((C/'application/result.json').read_text())
readback=json.loads(REVIEW.read_text())
target=Path(correction['target'])
assert target==R/'tests/citable.test.ts'
assert application['passed'] is True and application['manifestSha256']==CORRECTION_SHA
assert application['afterSha256']==TARGET_SHA and sha(target)==TARGET_SHA
assert target.stat().st_size==application['bytes']==correction['after']['bytes']==13548
assert application['productionEdits'] is False and application['testFilesChanged']==1
assert readback['status']=='accepted' and readback['independentLiveBytesEqualAcceptedAfter'] is True
for key,path in [('applicationManifest',C/'manifest.json'),('applicationResult',C/'application/result.json'),('liveTarget',target)]:
 verify(readback[key]);assert readback[key]['path']==str(path)
config=json.loads((R/'tsconfig.json').read_text());assert config==m['originalConfig']
oldscope=json.loads((V/'project-root-metadata.json').read_text())
by_pattern={pat:sorted({str(p.resolve()) for p in R.glob(pat) if p.is_file()}) for pat in config['include']}
paths=sorted({p for group in by_pattern.values() for p in group})
assert paths==oldscope['configuredRootFilePaths'] and len(paths)==361
scope=copy.deepcopy(oldscope);scope['fileMetadata']=[meta(p) for p in paths]
scope['directoryState']=[meta(p['path']) for p in oldscope['directoryState']]
assert scope['directoryState']==oldscope['directoryState']
assert {k:len(v) for k,v in by_pattern.items()}==scope['matchedByConfiguredPattern']
changes=[{'before':before,'after':after} for before,after in zip(oldscope['fileMetadata'],scope['fileMetadata']) if before!=after]
assert len(changes)==1 and changes[0]['after']['path']==str(target)
assert {k for k in changes[0]['before'] if changes[0]['before'][k]!=changes[0]['after'][k]}=={'bytes','mtimeNs'}
assert changes[0]['before']['bytes']==correction['before']['bytes']
write('project-root-metadata.json',scope)
pins=[verify(p) for p in json.loads((V/'input-pins.json').read_text())]
assert len(pins)==134 and str(target) not in {p['path'] for p in pins}
data_pin=next(p for p in pins if p['path']==str(R/'src/lib/data.ts'))
assert data_pin['sha256']=='a1deee5939dd30856494d49e152c0b2f51caeaec5ccdff02275689beb70afaab'
assert sha(FOCUSED/'sequence.json')=='a1eee9f728fe11f56b3d20c9c31ebbb3e3a1dcbb74a888106a620546d45555a6'
focused_sequence=json.loads((FOCUSED/'sequence.json').read_text())
focused_manifests=[verify(p) for p in focused_sequence['sequence']]
assert [json.loads(Path(p['path']).read_text())['id'] for p in focused_manifests]==['one-file-lint','focused-citable-tests']
newpins=[pin(target),pin(C/'manifest.json'),pin(C/'application/result.json'),pin(REVIEW),pin(FOCUSED/'sequence.json'),*focused_manifests]
for p in newpins:pins.append(p)
write('input-pins.json',pins)
write('metadata-delta.json',{'supersededUnexecutedPreparation':pin(V/'manifest.json'),'configuredRootNamesUnchanged':True,'configuredRootCountBefore':361,'configuredRootCountAfter':361,'addedRoots':[],'removedRoots':[],'directoryStateUnchanged':True,'onlyMetadataChanges':changes,'unchangedV1ContentPinCount':134,'addedExplicitContentPins':newpins,'alreadyPinnedDataTsUnchanged':data_pin,'explanation':'Only tests/citable.test.ts changed from v1, by the independently accepted test-only correction. It was previously metadata-covered and is now explicitly content-pinned. All 134 prior named content pins, 361 root names, generated types, config, runtime metadata and live cache remain unchanged. No prior failed runtime result is relabelled.'})
with (B/'prior-attempts.json').open('x') as f:f.write((V/'prior-attempts.json').read_text())
proofs=[verify(p) for p in correction['proofs']]
failed_path=R.parent/'roadmark-104-qa/deepal-sequential-checks/behavioural-suites/result.json'
failed=json.loads(failed_path.read_text());assert failed['passed'] is False and failed['exitCode']==1
write('correction-provenance.json',{'status':'accepted_application_not_runtime_verification','manifest':pin(C/'manifest.json'),'applicationResult':pin(C/'application/result.json'),'independentReadback':pin(REVIEW),'liveTarget':pin(target),'acceptedTestCount':14,'priorFailedBehaviouralResult':pin(failed_path),'priorFailedBehaviouralCounts':{'tests':143,'passed':142,'failed':1},'priorFailureRetainedAndNotRelabelled':True,'proofs':proofs,'v1UnexecutedPreparationPreserved':{'manifest':pin(V/'manifest.json'),'wrapper':pin(V/'run.py'),'runDirectoryAbsent':True},'focusedRuntimeVerificationStillRequired':True,'fresh144TestAggregateStillRequired':True})
wrapper=(V/'run.py').read_text().replace(str(V),str(B))
wrapper=wrapper.replace("assert g['precedingChecksAccepted'] is True\n", "assert g['precedingChecksAccepted'] is True\nassert g['focusedCorrectionChecksAccepted'] is True\ncheck(g['focusedCorrectionVerification'])\n")
wrapper=wrapper.replace("    for c in receipt['checks']:\n", "    for c in receipt['checks']:\n        if c['name'] == 'behavioural-suites':\n            assert json.loads(Path(c['manifest']['path']).read_text())['expectedTests'] == 144\n")
wrapper=wrapper.replace("g['precedingCheckVerification'], g['applicationVerification'], *pins", "g['precedingCheckVerification'], g['applicationVerification'], g['focusedCorrectionVerification'], *pins")
insert='''    focused = json.loads(Path(g['focusedCorrectionVerification']['path']).read_text())
    assert focused['status'] == 'accepted'
    assert focused['correctionManifestSha256'] == m['fixtureCorrection']['manifest']['sha256']
    assert [c['name'] for c in focused['checks']] == m['requiredFocusedCorrectionChecks']
    for c, expected_manifest in zip(focused['checks'], m['focusedCorrectionManifests']):
        assert c['manifest']['path'] == expected_manifest['path'] and c['manifest']['sha256'] == expected_manifest['sha256']
        assert c['passed'] is True and c['exitCode'] == 0
        for field in ['manifest', 'result', 'terminal']:
            check(c[field])
        result = json.loads(Path(c['result']['path']).read_text())
        terminal = json.loads(Path(c['terminal']['path']).read_text())
        assert result['passed'] is True and result['exitCode'] == 0
        assert terminal['exitCode'] == 0
        assert result['manifestSha256'] == c['manifest']['sha256']
    correction = json.loads(Path(m['fixtureCorrection']['applicationResult']['path']).read_text())
    readback = json.loads(Path(m['fixtureCorrection']['independentReadback']['path']).read_text())
    assert correction['passed'] is True and correction['manifestSha256'] == m['fixtureCorrection']['manifest']['sha256']
    assert correction['afterSha256'] == m['fixtureCorrection']['liveTarget']['sha256']
    assert readback['status'] == 'accepted' and readback['independentLiveBytesEqualAcceptedAfter'] is True
    assert readback['applicationManifest']['sha256'] == m['fixtureCorrection']['manifest']['sha256']
    assert readback['applicationResult']['sha256'] == m['fixtureCorrection']['applicationResult']['sha256']

'''
wrapper=wrapper.replace('def check_inputs():\n',insert+'def check_inputs():\n')
ast.parse(wrapper)
with (B/'run.py').open('x') as f:f.write(wrapper)
m['id']='deepal-cold-full-project-typescript-768-v2';m['preparedAt']=datetime.now(timezone.utc).isoformat()
m['command'][-1]=str(B/'run/full-project.tsbuildinfo')
m['wrapper']=pin(B/'run.py');m['preparer']=pin(B/'prepare.py')
for key,name in [('inputPins','input-pins.json'),('projectRootMetadata','project-root-metadata.json'),('priorAttempts','prior-attempts.json'),('metadataDelta','metadata-delta.json')]:m[key]=pin(B/name)
m['cacheHandling']['newCachePath']=str(B/'run/full-project.tsbuildinfo')
m['scopePreservation']['compilerOptionOverrides']['tsBuildInfoFile']=str(B/'run/full-project.tsbuildinfo')
m['allowedWrites']=[str(B/'run')+'/**']
m['fixtureCorrection']={'manifest':pin(C/'manifest.json'),'applicationResult':pin(C/'application/result.json'),'independentReadback':pin(REVIEW),'liveTarget':pin(target),'provenance':pin(B/'correction-provenance.json')}
m['requiredFocusedCorrectionChecks']=['one-file-lint','focused-citable-tests']
m['focusedCorrectionManifests']=focused_manifests
m['focusedCorrectionSequence']=pin(FOCUSED/'sequence.json')
assert len(m['requiredFocusedCorrectionChecks'])==2
m['focusedCorrectionVerificationContract']={'status':'accepted','correctionManifestSha256':CORRECTION_SHA,'checks':'Exactly requiredFocusedCorrectionChecks order; each item has name, passed=true, exitCode=0 and manifest/result/terminal content pins. Each result must contain passed=true, exitCode=0 and matching manifestSha256; terminal exitCode=0. The first check is exact one-file lint and the second is the full 14-test citable suite. Manifest paths and hashes must also equal focusedCorrectionManifests.'}
m['executionConditions'].insert(2,'Reviewer accepts the exact post-correction 14-test citable suite and one-file lint, with pinned manifest/result/terminal receipts')
m['executionConditions'].append('Five preceding checks retain their original names and straight passed/exit-0 contract; behavioural-suites must be the fresh 144-test aggregate after correction, not the retained 142-pass/1-fail result')
m['supersededPreparation']={'manifest':pin(V/'manifest.json'),'reason':'v1 configured-root metadata predated the accepted one-file citable fixture correction','executed':False,'preserved':True}
for entry in m['runtimeMetadata']:assert meta(entry['path'])==entry
write('manifest.json',m)
g=json.loads((V/'root-grant-template.json').read_text())
g['manifest']={'path':str(B/'manifest.json'),'sha256':sha(B/'manifest.json')};g['wrapper']=m['wrapper']
g['focusedCorrectionChecksAccepted']=False
g['focusedCorrectionVerification']={'path':'REPLACE_WITH_FOCUSED_CORRECTION_CHECKS_ACCEPTANCE_PATH','bytes':0,'sha256':'REPLACE'}
g['instruction']='Template only. Root must confirm exact v2 reviewer readiness, accepted Deepal application and citable correction, accepted focused 14-test suite/one-file lint and all five preceding checks including a fresh passing 144-test aggregate, then write a separate root_execution_granted receipt for this manifest/wrapper and exclusive slot. v1 and the previous 142-pass/1-fail result remain retained; no execution or retry is granted by this template.'
write('root-grant-template.json',g)
assert not (B/'run').exists() and not (V/'run').exists()
print(json.dumps({'manifest':pin(B/'manifest.json'),'wrapper':pin(B/'run.py'),'inputPinCount':len(pins),'configuredRoots':361,'onlyMetadataChange':str(target),'dataTsAlreadyPinnedUnchanged':True,'noExecution':True},indent=2))
