from pathlib import Path
import json,hashlib,re,ast
R=Path('/workspace/scratch/586427eef9f2/roadmark-104');B=Path('/tmp/deepal-packet/vw-citable-focused-checks-v1');V=Path('/tmp/deepal-packet/post-registration-checks-v2');Q=R.parent/'roadmark-104-qa/deepal-fixture-focused-checks'
def pin(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def meta(p):
 p=Path(p)
 if not p.exists():return {'path':str(p),'exists':False}
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
def write(n,x):
 with (B/n).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
with (B/'run.py').open('x') as f:f.write((V/'run.py').read_text())
assert pin(R/'tests/citable.test.ts')['sha256']=='7950677521142cb6f99df055fe82551c8a293e292f644c8f26e5d8f01c55adf2'
metadata=json.load(open('/tmp/deepal-packet/full-project-typescript-v1/project-root-metadata.json'));changes=[]
for i,p in enumerate(metadata['fileMetadata']):
 actual=meta(p['path'])
 if actual!=p:
  assert p['path']==str(R/'tests/citable.test.ts');changes.append(dict(before=p,after=actual));metadata['fileMetadata'][i]=actual
assert len(changes)==1
for p in metadata['directoryState']:assert meta(p['path'])==p
write('root-metadata.json',metadata);write('metadata-delta.json',dict(changes=changes,rootsRemain=361))
pins={p['path']:p for p in json.load(open(V/'source-pins.json'))}
for rel in ['tests/citable.test.ts','src/lib/data.ts']:pins[str(R/rel)]=pin(R/rel)
write('source-pins.json',[pins[k] for k in sorted(pins)])
names=re.findall(r'\btest\("([^"\n]*)"\s*,',(R/'tests/citable.test.ts').read_text());assert len(names)==14
write('test-inventory.json',{'tests/citable.test.ts':dict(names=names,count=14,source=pin(R/'tests/citable.test.ts'))})
common=dict(status='frozen_not_executed_requires_review_and_root_grant',repo=str(R),qaRoot=str(Q),killAfterSeconds=10,automaticRetry=False,parallelExecutionAllowed=False,sourceMutationsAuthorized=False,sourcePins=pin(B/'source-pins.json'),rootMetadata=pin(B/'root-metadata.json'),testInventory=pin(B/'test-inventory.json'),wrapper=pin(B/'run.py'),environmentRemovals=['NODE_OPTIONS','NODE_PATH','NODE_COMPILE_CACHE','TS_NODE_PROJECT','TS_NODE_COMPILER_OPTIONS','TS_NODE_TRANSPILE_ONLY'],environmentOverrides={'NODE_DISABLE_COMPILE_CACHE':'1','FORCE_COLOR':'0','ESLINT_USE_FLAT_CONFIG':'true'})
node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node';eslint=str((R/'node_modules/eslint/bin/eslint.js').resolve())
extra=[pin('/tmp/deepal-packet/vw-citable-fixture-correction-v1/manifest.json'),pin('/tmp/deepal-packet/vw-citable-fixture-correction-v1/application/result.json'),pin('/tmp/deepal-review/VW-CITABLE-CORRECTION-READBACK.json')]
lint={**common,'id':'one-file-lint','kind':'lint','command':[node,'--max-old-space-size=256','--max-semi-space-size=1',eslint,'--no-config-lookup','--config',str(R/'eslint.config.mjs'),'--no-ignore','--no-cache','--concurrency','off','--max-warnings','0','--format','json','--','tests/citable.test.ts'],'timeoutSeconds':180,'runOutput':str(Q/'one-file-lint'),'prerequisites':[],'extraPins':[*extra,pin(eslint)],'lintFiles':['tests/citable.test.ts']}
write('one-file-lint.json',lint)
test={**common,'id':'focused-citable-tests','kind':'tests','command':[node,'--max-old-space-size=512','--max-semi-space-size=1','--import','tsx','--test','--test-reporter=tap','--test-concurrency=1','tests/citable.test.ts'],'timeoutSeconds':600,'runOutput':str(Q/'focused-citable-tests'),'prerequisites':[dict(manifest=pin(B/'one-file-lint.json'),resultPath=str(Q/'one-file-lint/result.json'))],'extraPins':extra,'testFiles':['tests/citable.test.ts'],'expectedTests':14}
write('focused-citable-tests.json',test)
write('sequence.json',dict(status='frozen_not_executed_requires_review_and_root_grant',sequence=[pin(B/'one-file-lint.json'),pin(B/'focused-citable-tests.json')],sourcePins=common['sourcePins'],rootMetadata=common['rootMetadata'],qaRoot=str(Q),priorFailed143TestAggregateRetained=True,focusedSuccessDoesNotRelabelOriginalFailure=True,plannedContinuation='Fresh144-test aggregate, then still-unrun7safety tests and structural validation under new grants'))
write('root-grant-template.json',dict(status='NOT_GRANTED',heavySlotExclusive=False,automaticRetry=False,parallelExecutionAllowed=False,granted=[],sequence=pin(B/'sequence.json'),reviewerAcceptance=None,registrationVerification=pin('/tmp/deepal-review/REGISTRATION-READBACK-AND-CHECK-PLAN-REVIEW.json')))
ast.parse((B/'run.py').read_text());ast.parse((B/'prepare.py').read_text());print(json.dumps(dict(sequence=pin(B/'sequence.json'),wrapper=pin(B/'run.py'),commands=[pin(B/'one-file-lint.json'),pin(B/'focused-citable-tests.json')]),indent=2))
