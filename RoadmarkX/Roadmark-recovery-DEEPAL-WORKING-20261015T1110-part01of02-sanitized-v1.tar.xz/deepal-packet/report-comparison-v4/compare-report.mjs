/** One saved normal report versus accepted Audi25, with selected-only actual producers. */
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readJson,fileHash,streamRows} from '/tmp/xpeng-staging-plan/baseline-io.mjs';
const repo='/workspace/scratch/586427eef9f2/roadmark-104';
const prep='/tmp/deepal-packet/report-comparison-v4';
const qa='/workspace/scratch/586427eef9f2/roadmark-104-qa/deepal-continuation-checks';
assert.equal(process.cwd(),repo);
const out=qa+'/report-comparison-v4-artifacts';assert(!fs.existsSync(out));fs.mkdirSync(out);
const write=(name,value)=>fs.writeFileSync(out+'/'+name+'.json',JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const require=createRequire(repo+'/package.json'),ts=require('typescript');
const normalPath=qa+'/normal-coverage-asof-2026-10-15/stdout.log';
const baselinePath='/workspace/scratch/586427eef9f2/roadmark-104-qa/audi-sequential-checks/normal-coverage-asof-2026-10-15/stdout.log';
assert.equal(fileHash(baselinePath),'0e971290adb305fd261321df5272b469a84e30f7e759f24efb658ddb9d7c6e1a');
const normal=readJson(normalPath),baseline=readJson(baselinePath);
const normalTerminal=readJson(qa+'/normal-coverage-asof-2026-10-15/terminal.json');assert.equal(normalTerminal.exitCode,0);assert.equal(normalTerminal.stdoutSha256,fileHash(normalPath));
function differences(a,b,path=''){
 if(Object.is(a,b))return[];
 if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return[{path,before:a,after:b}];
 const out=[];for(const key of new Set([...Object.keys(a),...Object.keys(b)])){
  const p=path+'/'+key.replaceAll('~','~0').replaceAll('/','~1');
  if(!Object.hasOwn(a,key))out.push({path:p,operation:'add',after:b[key]});
  else if(!Object.hasOwn(b,key))out.push({path:p,operation:'remove',before:a[key]});
  else out.push(...differences(a[key],b[key],p));
 }return out;
}
write('exhaustive-normal-versus-audi-diff',differences(baseline,normal));
const selectedResult=readJson('/tmp/deepal-packet/published-driveaway-validation-v2/result.json');
const selectedAfter=selectedResult.selectedCoverage;
const before=readJson('/tmp/deepal-research/retained-before-cars.json');
const packs=readJson('/tmp/deepal-packet/full-stage-v4/output/selected-packs.json');
const after=readJson('/tmp/deepal-packet/full-stage-v4/output/selected-after-cars.json');
const selectedIds=new Set(before.map(c=>c.id)),modelIds=new Set(before.map(c=>c.modelId));
assert.equal(selectedIds.size,3);assert.equal(selectedResult.otherRetainedEffectiveFeaturesDeepEqual,true);
// Accepted complete-car hashes include every peer value, basis, unit, grade and identity.
const acceptedAudiDigests=readJson('/tmp/audi-packet/full-stage-v1/output/car-digest-comparison.json').candidate25;
const acceptedStageDigests=readJson('/tmp/deepal-packet/full-stage-v4/output/car-digest-comparison.json');
assert.deepEqual(acceptedStageDigests.candidate25,acceptedAudiDigests);
assert.equal(acceptedStageDigests.candidate26.length,427);
const oldPeerDigests=acceptedStageDigests.candidate25.filter(c=>!selectedIds.has(c.id)),newPeerDigests=acceptedStageDigests.candidate26.filter(c=>!selectedIds.has(c.id));
assert.equal(oldPeerDigests.length,424);assert.deepEqual(newPeerDigests,oldPeerDigests);
write('accepted-peer-car-value-and-basis-proof',{acceptedAudiSha256:fileHash('/tmp/audi-packet/full-stage-v1/output/car-digest-comparison.json'),acceptedDeepalStageSha256:fileHash('/tmp/deepal-packet/full-stage-v4/output/car-digest-comparison.json'),exactCompletePeerCars:424,allPeerValuesBasesUnitsGradesAndIdentitiesUnchanged:true,proof:'Complete-car byte digests from independently accepted actual stage; normal report source/input pins retain the same chain',peers:newPeerDigests});
const manifest=readJson('/tmp/mercedes-staging-plan/consumer-preparation/v5/manifests/report-v5.json');
const index=readJson('/tmp/mercedes-staging-plan/staging-preparation/staging-artifacts/canonical-v1/staged-storage-index.json');
const base={},reads=[];
for(const [key,ref]of Object.entries(index.research)){
 const values=[];
 await streamRows(manifest.anchors,ref,row=>{
  const keep=['variants','feature_evidence_variant_context'].includes(key)?selectedIds.has(row.id):['feature_evidence','trim_equipment','update_eligibility'].includes(key)?selectedIds.has(row.variant_id):key==='models'?modelIds.has(row.id):true;
  if(keep)values.push(row);
 });base[key]=ref.array?values:values[0];reads.push({key,inputRows:ref.rows,retainedRows:values.length,sha256:ref.sha256});
}
assert.equal(base.variants.length,3);assert.equal(base.feature_evidence.length,207);
function compile(path,relative,overrides={},append=''){
 const filename=repo+'/'+relative,source=fs.readFileSync(path,'utf8')+append;
 const output=ts.transpileModule(source,{fileName:filename,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,esModuleInterop:true}}).outputText;
 const scoped=createRequire(filename),module={exports:{}};
 vm.runInThisContext('(function(require,module,exports){'+output+'\n})',{filename})(id=>Object.hasOwn(overrides,id)?overrides[id]:scoped(id),module,module.exports);return module.exports;
}
const oldRoot='/tmp/deepal-packet/registration-v1/before';
const oldBrand=compile(oldRoot+'/src/lib/brand-updates.ts','src/lib/brand-updates.ts');
const oldConsumer=compile(oldRoot+'/src/lib/evidence-consumers.ts','src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets:[]},'./brand-updates':oldBrand});
const {applyFeatureRegrading}=require('./src/lib/evidence-regrading.ts');
const beforeFeatures=[],producerReceipts=[];
for(const car of before){
 const raw=base.feature_evidence.filter(f=>f.variant_id===car.id&&f.criterion==='driveaway_price');assert.equal(raw.length,1);
 const history=base.feature_evidence_variant_context.find(v=>v.id===car.id);
 const sourceCar=history?{...car,configurationEvidence:history.configuration_evidence}:car;
 const sourceRows=oldConsumer.effectiveFeaturesFromRows(sourceCar,base,raw);
 const regraded=applyFeatureRegrading(car,sourceRows,base.sources);
 const rows=oldBrand.applyBrandTermFeatures(car,regraded,base.sources);assert.equal(rows.length,1);
 const current=packs[car.id].features;assert.equal(current.length,69);
 beforeFeatures.push(...current.map(f=>f.criterion==='driveaway_price'?rows[0]:f));
 producerReceipts.push({carId:car.id,raw:raw[0],source:sourceRows[0],regraded:regraded[0],originalDriveaway:rows[0],otherCriteriaReplayed:0});
}
assert.equal(beforeFeatures.length,207);
const reports=compile(repo+'/scripts/reporting/reports.ts','scripts/reporting/reports.ts',{},'\nexport { coreFact, gradePattern };\n');
const inventory=require('./src/lib/market-inventory-data.ts').default;
const deepalInventory={...inventory,records:inventory.records.filter(r=>r.brand==='Deepal'),unverifiedLeads:inventory.unverifiedLeads.filter(r=>r.brand==='Deepal')};
const emptyRegistry={schemaVersion:1,checkedAt:'2026-10-15',notes:[],publishedLists:[],currentVersionReviews:[],listResolutions:[],catalogueOnlyDifferences:[],inventoryResolutions:[]};
const selectedBefore=reports.buildCoverageReport({cars:before,sources:base.sources,features:beforeFeatures,inventory:deepalInventory,m1Reconciliation:emptyRegistry},normal.asOf);
const afterSources=[...base.sources,...readJson(repo+'/data/m1-brand-updates/deepal-2026-10-15.json').sources];
const afterFeatures=Object.values(packs).flatMap(p=>p.features);
const afterFresh=reports.buildStaleReport({cars:after,features:afterFeatures},normal.asOf);
assert.deepEqual({overdue:afterFresh.overdue,invalid:afterFresh.invalid,dueNext30Days:afterFresh.due.length,excludedHistory:afterFresh.historical},selectedAfter.ageing);
const oldDeepal=baseline.brandProgress.find(b=>b.brand==='Deepal');
// Whole written parity plus exact own-undefined ownership from the actual C1 issue producer.
write('selected-before-report',selectedBefore);
assert.deepEqual(readJson(out+'/selected-before-report.json').brandProgress.find(b=>b.brand==='Deepal'),oldDeepal);
const {buildMarketReconciliation}=require('./scripts/reporting/m1-reconciliation.ts');
const issueFixtureInventory={records:[],unverifiedLeads:[]};
const issueFixture=buildMarketReconciliation(emptyRegistry,[],issueFixtureInventory,normal.asOf);
assert.equal(issueFixture.registryValid,true);assert.equal(issueFixture.independentListCount,0);
assert.deepEqual(issueFixture.issues.map(i=>i.code),['independent_lists','empty_catalogue']);
const liveDeepal=selectedBefore.brandProgress.find(b=>b.brand==='Deepal');
const producedIssues=issueFixture.issues.filter(i=>i.code==='independent_lists'),expectedIssues=oldDeepal.closureIssues.filter(i=>i.code==='independent_lists'),liveIssues=liveDeepal.closureIssues.filter(i=>i.code==='independent_lists');
assert.equal(producedIssues.length,1);assert.equal(expectedIssues.length,1);assert.equal(liveIssues.length,1);
const producedIssue=producedIssues[0],expectedIssue=expectedIssues[0],liveIssue=liveIssues[0];
assert.deepEqual(Object.keys(expectedIssue).sort(),['code','reason']);
assert.deepEqual(Object.keys(producedIssue).sort(),['brand','code','reason','reference']);
assert.deepEqual(Object.keys(liveIssue).sort(),['brand','code','reason','reference']);
const issueOwnership=[];
for(const property of ['brand','reference']){
 const actual=Object.getOwnPropertyDescriptor(liveIssue,property),producer=Object.getOwnPropertyDescriptor(producedIssue,property);
 for(const descriptor of [actual,producer]){assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value'));assert.equal(descriptor.value,undefined);}
 assert.deepEqual(actual,producer);assert(!Object.hasOwn(expectedIssue,property));
 issueOwnership.push({property,ownUndefined:true,enumerable:true,producer:'actual buildMarketReconciliation → add(code,reason) creates both optional own properties; pinned m1-reconciliation.ts'});
}
write('selected-before-c1-issue-producer',{fixtureRegistry:emptyRegistry,fixtureCars:[],fixtureInventory:issueFixtureInventory,asOf:normal.asOf,issue:producedIssue,exactOwnership:issueOwnership});
assert.deepEqual(readJson(out+'/selected-before-c1-issue-producer.json').issue,expectedIssue);
const expectedLiveDeepal=structuredClone(oldDeepal),issueIndex=expectedLiveDeepal.closureIssues.findIndex(i=>i.code==='independent_lists');
assert.equal(issueIndex,liveDeepal.closureIssues.findIndex(i=>i.code==='independent_lists'));
expectedLiveDeepal.closureIssues[issueIndex]=producedIssue;assert.deepEqual(liveDeepal,expectedLiveDeepal);
write('selected-freshness-producer-proof',{reads,actualDriveawayProducers:producerReceipts,before:selectedBefore.ageing,after:selectedAfter.ageing,otherSelectedFeaturesFromAcceptedParity:true});
const peer=(rows,key='carId')=>rows.filter(r=>!selectedIds.has(r[key]));
const deep=(rows,key='carId')=>rows.filter(r=>selectedIds.has(r[key]));
const pct=(n,d)=>d?Math.round(n/d*1000)/10:null;
const expected=structuredClone(baseline);
assert.deepEqual([normal.allCatalogueVersions,normal.tierOneVersions,normal.onSaleVersions],[427,350,309]);
assert.equal(normal.asOf,'2026-10-15');
assert.deepEqual(normal.brandProgress.filter(b=>b.brand!=='Deepal'),baseline.brandProgress.filter(b=>b.brand!=='Deepal'));
const newDeepal=selectedAfter.brandProgress.find(b=>b.brand==='Deepal');
assert.deepEqual(normal.brandProgress.find(b=>b.brand==='Deepal'),newDeepal);
expected.brandProgress=baseline.brandProgress.map(b=>b.brand==='Deepal'?newDeepal:b);
const reasonCounts=(cars,sources,key)=>{
 const counts=new Map();for(const car of cars){const cell=reports.coreFact(car,key),grade=reports.existingGrade(cell.fact,reports.hasValue(cell.fact?.value),sources,normal.asOf);
 if(grade!=='Confirmed'){const reason=cell.ungraded?'Drive value exists without a per-fact grade':reports.gradePattern(cell.fact,cell.issue,grade);counts.set(reason,(counts.get(reason)||0)+1);}}
 return counts;
};
const explanations=[];
expected.core=baseline.core.map((old,i)=>{
 const b=selectedBefore.core[i],a=selectedAfter.core[i];assert.equal(old.key,b.key);assert.equal(a.key,b.key);
 const grades=Object.fromEntries(Object.keys(old.grades).map(k=>[k,old.grades[k]-b.grades[k]+a.grades[k]]));
 const filled=old.filled-b.filled+a.filled,reviewed=old.total-grades.Unreviewed;
 let explanation=null;
 if(grades.Confirmed/old.total<0.5){
  assert(old.explanation,'Changed under-half threshold needs a separately reviewed complete reason inventory');
  const oldCounts=reasonCounts(before,base.sources,old.key),newCounts=reasonCounts(after,afterSources,old.key);
  const pairs=old.explanation.split(/; (?=\d+: )/).map(s=>{const m=s.match(/^(\d+): ([\s\S]*)$/);assert(m);return[m[2],Number(m[1])];});
  assert.equal(pairs.map(([r,n])=>`${n}: ${r}`).join('; '),old.explanation);
  const next=pairs.map(([r,n])=>[r,n-(oldCounts.get(r)||0)+(newCounts.get(r)||0)]).sort((a,b)=>b[1]-a[1]);
  explanation=next.map(([r,n])=>{assert(n>0);return`${n}: ${r}`;}).join('; ');
  explanations.push({key:old.key,oldTopReasons:pairs,selectedBeforeCounts:[...oldCounts],selectedAfterCounts:[...newCounts],expectedNewTopReasons:next,condition:'If the real normal report introduces another reason/tie/tail, exact comparison fails and needs narrow additional review; no blanket explanation waiver'});
 }
 return{...old,filled,filledPercent:pct(filled,old.total),confirmedPercent:pct(grades.Confirmed,old.total),grades,reviewed,reviewedPercent:pct(reviewed,old.total),gradingPasses:old.total>0&&grades.Unreviewed===0,passes:old.total>0&&filled/old.total*100>=old.target,explanation};
});
write('global-core-delta-and-reason-proof',explanations);
const groupKey=g=>JSON.stringify([g.vehicleClass,g.basis,g.unit]);
// Guarded excerpt of the actual production group comparator; no alternate sorting rule.
const discoveryPath=repo+'/src/lib/discovery.ts',discoverySource=fs.readFileSync(discoveryPath,'utf8');
const groupComparatorText='(a, b) =>\n        b.entries.length - a.entries.length || a.basis.localeCompare(b.basis)';
const groupComparatorContext='.sort(\n      '+groupComparatorText+',\n    );';
assert.equal(discoverySource.split(groupComparatorContext).length,2);
assert(discoverySource.indexOf(groupComparatorContext)>discoverySource.indexOf('export function rankAttribute('));
const groupOrder=vm.runInThisContext('('+groupComparatorText+')',{filename:discoveryPath+':actual-group-order-excerpt'});
const sortingGroup=g=>({...g,entries:Array(g.count)});
function groupSegments(ranking){
 const map=new Map();let offset=0;
 for(const group of ranking.groups){
  assert.deepEqual(Object.keys(group),['vehicleClass','basis','unit','count']);assert(Number.isInteger(group.count)&&group.count>0);
  const key=groupKey(group);assert(!map.has(key));const ids=ranking.rankedIds.slice(offset,offset+group.count);assert.equal(ids.length,group.count);offset+=group.count;
  map.set(key,{group,ids});
 }
 assert.equal(offset,ranking.rankedIds.length);assert.equal(new Set(ranking.rankedIds).size,offset);return map;
}
const rankingGroupProof=[];
expected.rankings=baseline.rankings.map((old,i)=>{
 const actual=normal.rankings[i],b=selectedBefore.rankings[i],a=selectedAfter.rankings[i];assert.equal(actual.key,old.key);assert.equal(b.key,old.key);assert.equal(a.key,old.key);
 const oldSegments=groupSegments(old),newSegments=groupSegments(actual),selectedBeforeSegments=groupSegments(b),selectedAfterSegments=groupSegments(a);
 const perGroup=[];
 for(const key of new Set([...oldSegments.keys(),...newSegments.keys(),...selectedBeforeSegments.keys(),...selectedAfterSegments.keys()])){
  const oldIds=oldSegments.get(key)?.ids||[],newIds=newSegments.get(key)?.ids||[],beforeIds=selectedBeforeSegments.get(key)?.ids||[],afterIds=selectedAfterSegments.get(key)?.ids||[];
  assert.deepEqual(oldIds.filter(id=>selectedIds.has(id)),beforeIds);
  assert.deepEqual(newIds.filter(id=>selectedIds.has(id)),afterIds);
  const oldPeers=oldIds.filter(id=>!selectedIds.has(id)),newPeers=newIds.filter(id=>!selectedIds.has(id));assert.deepEqual(newPeers,oldPeers,'Exact peer membership/order within class+basis+unit: '+old.key+'/'+key);
  assert.equal(newIds.length,oldIds.length-beforeIds.length+afterIds.length);
  perGroup.push({key,peerIds:oldPeers,selectedBeforeIds:beforeIds,selectedAfterIds:afterIds,beforeCount:oldIds.length,afterCount:newIds.length});
 }
 assert.deepEqual(peer(actual.excluded),peer(old.excluded));assert.deepEqual(deep(actual.excluded),a.excluded);
 for(const group of actual.groups)assert.deepEqual(Object.keys(group),['vehicleClass','basis','unit','count']);
 const counts=new Map(old.groups.map(g=>[groupKey(g),g.count]));
 for(const g of b.groups)counts.set(groupKey(g),(counts.get(groupKey(g))||0)-g.count);
 for(const g of a.groups)counts.set(groupKey(g),(counts.get(groupKey(g))||0)+g.count);
 assert.deepEqual(new Map(actual.groups.map(g=>[groupKey(g),g.count])),new Map([...counts].filter(([,n])=>n>0)));
 const expectedGroups=[...counts].filter(([,n])=>n>0).map(([key,count])=>{const [vehicleClass,basis,unit]=JSON.parse(key);return{vehicleClass,basis,unit,count};});
 // No ambiguous production-comparator tie may be waived by incidental report order.
 for(let j=0;j<expectedGroups.length;j++)for(let k=j+1;k<expectedGroups.length;k++)assert.notEqual(groupOrder(sortingGroup(expectedGroups[j]),sortingGroup(expectedGroups[k])),0,'A group comparator tie needs separately established insertion provenance');
 expectedGroups.sort((x,y)=>groupOrder(sortingGroup(x),sortingGroup(y)));assert.deepEqual(actual.groups,expectedGroups);
 rankingGroupProof.push({key:old.key,perGroup,oldOrder:old.groups.map(groupKey),newOrder:expectedGroups.map(groupKey),allGroupSizeChangesAccountedBySelectedDeepal:true,exactPeerMembershipAndRelativeOrderWithinGroups:true,actualProductionGroupComparator:true,ambiguousComparatorTies:0});
 const exclusionReasons={};for(const item of actual.excluded)exclusionReasons[item.reason]=(exclusionReasons[item.reason]||0)+1;
 const ranked=old.ranked-b.ranked+a.ranked;assert.equal(actual.rankedIds.length,ranked);assert.equal(actual.excluded.length,normal.onSaleVersions-ranked);
 return{...old,ranked,percent:pct(ranked,normal.onSaleVersions),rankedIds:actual.rankedIds,passes:ranked/normal.onSaleVersions>=0.9,groups:actual.groups,excluded:actual.excluded,exclusionReasons};
});
write('ranking-group-order-and-peer-proof',{sourcePath:discoveryPath,sourceSha256:fileHash(discoveryPath),exactComparatorText:groupComparatorText,groups:rankingGroupProof});
for(const key of ['gaps','summaryGaps']){
 assert.deepEqual(peer(normal[key]),peer(baseline[key]));assert.deepEqual(deep(normal[key]),selectedAfter[key]);
 expected[key]=normal[key];
}
for(const key of ['missingModels','unresolvedLeads']){
 assert.deepEqual(normal[key].filter(r=>r.brand!=='Deepal'),baseline[key].filter(r=>r.brand!=='Deepal'));
 assert.deepEqual(normal[key].filter(r=>r.brand==='Deepal'),selectedAfter[key]);expected[key]=normal[key];
}
const c1=readJson('/tmp/deepal-packet/full-stage-v4/output/global-c1-comparison.json');
assert.deepEqual(baseline.reconciliation,c1.before);expected.reconciliation=c1.after;
expected.pairedOnSale=baseline.pairedOnSale-selectedBefore.pairedOnSale+selectedAfter.pairedOnSale;
expected.pairedOnSalePercent=pct(expected.pairedOnSale,normal.onSaleVersions);
const intersect=rows=>rows[0].rankedIds.filter(id=>rows.every(r=>r.rankedIds.includes(id))).length;
assert.equal(baseline.inAllRankings,intersect(baseline.rankings));expected.inAllRankings=intersect(expected.rankings);expected.inAllRankingsPercent=pct(expected.inAllRankings,normal.onSaleVersions);
const reviewedCoreCells=expected.core.reduce((s,c)=>s+c.reviewed,0),totalCoreCells=normal.onSaleVersions*17;
expected.grading={reviewedCoreCells,totalCoreCells,reviewedPercent:pct(reviewedCoreCells,totalCoreCells)};
expected.gradeNote=baseline.gradeNote.replace(`${baseline.grading.reviewedCoreCells}/${baseline.grading.totalCoreCells}`,`${reviewedCoreCells}/${totalCoreCells}`);
for(const [key,property,negate]of [['brandsResearchCompleted','researchCompleted',false],['brandsResearchRemaining','researchCompleted',true],['brandsDone','done',false],['brandsRemaining','done',true]])expected[key]=expected.brandProgress.filter(b=>negate?!b[property]:b[property]).map(b=>b.brand);
for(const key of ['overdue','invalid','excludedHistory']){
 assert.deepEqual(peer(normal.ageing[key]),peer(baseline.ageing[key]));assert.deepEqual(deep(normal.ageing[key]),selectedAfter.ageing[key]);expected.ageing[key]=normal.ageing[key];
}
expected.ageing.dueNext30Days=baseline.ageing.dueNext30Days-selectedBefore.ageing.dueNext30Days+selectedAfter.ageing.dueNext30Days;
const rc=expected.reconciliation,core=expected.core,ranks=expected.rankings,age=expected.ageing;
expected.criteria=[
 {id:'C1',pass:rc.pass,detail:`${rc.reviewedModels} exact current model lists reviewed; ${rc.settledListEntryCount}/${rc.listEntryCount} entries settled across ${rc.independentListCount} independent lists; ${rc.issues.length} blockers. ${expected.missingModels.length} unmatched audit models; ${expected.unresolvedLeads.length} unresolved leads.`,sources:baseline.criteria[0].sources},
 {id:'C2',pass:core.every(c=>c.passes),detail:`${core.filter(c=>c.passes).length}/${core.length} core fields meet their target; ${expected.gaps.length} version/field gaps, each with a reason in --details or --json.`},
 {id:'C3',pass:core.every(c=>c.gradingPasses&&(c.confirmedPercent>=50||!!c.explanation)),detail:`${reviewedCoreCells}/${totalCoreCells} core cells have earned reviews; ${core.filter(c=>c.confirmedPercent!==null&&c.confirmedPercent<50).length} fields below half Confirmed have patterns in --details. No grade quota is applied.`},
 {id:'C4',pass:expected.tierOneVersions>0&&expected.summaryGaps.length===0,detail:`${expected.tierOneVersions-expected.summaryGaps.length}/${expected.tierOneVersions} Tier 1 versions have both a supported strength and trade-off (${expected.pairedOnSale}/${normal.onSaleVersions} on sale).`},
 {id:'C5',pass:ranks.every(r=>r.passes),detail:`${ranks.filter(r=>r.passes).length}/6 ranking lists reach 90% of on-sale Tier 1 versions; measurement groups stay separate.`},
 {id:'C6',pass:age.overdue.length===0&&age.invalid.length===0,detail:`${age.overdue.length} aged claims and ${age.invalid.length} invalid/future/undated claims across all Tier 1 versions, including availability and equipment. Model-year changes still require a recorded review.`}
];
write('expected-versus-normal-diff',differences(expected,normal));
assert.deepEqual(normal,expected,'Every report leaf must equal the explicitly accounted expectation; no ignored global/peer fields');
for(const path of ['src/lib/data.ts','src/lib/catalogue.ts','src/lib/research.ts'])assert(!require.cache[repo+'/'+path]);
fs.writeFileSync(out+'/normal-coverage-formatted.txt',reports.formatCoverageReport(normal)+'\n',{flag:'wx'});
write('result',{passed:true,normalReportSha256:fileHash(normalPath),baselineSha256:fileHash(baselinePath),exhaustiveDifferences:differences(baseline,normal).length,allNormalLeavesAccounted:true,peerBrandObjectsExact:normal.brandProgress.filter(b=>b.brand!=='Deepal').length,peerRankRelativeOrderWithinMeasurementGroupsExact:true,groupOrderEqualsActualProducer:true,peerCompleteCarDigestsExact:424,globalC1EqualsAcceptedStage:true,ordinaryProductionReportRanSeparately:true,normalReportSubstituted:false,selectedOldDriveawayProducers:3,otherCriteriaReplayed:0,broadFeatureReplay:false,defaultLoaderCalls:0,selectedFreshnessBefore:selectedBefore.ageing,selectedFreshnessAfter:selectedAfter.ageing,counts:{catalogue:427,tierOne:350,onSale:309}});
console.log(JSON.stringify({passed:true,result:out+'/result.json',sha256:fileHash(out+'/result.json')}));
