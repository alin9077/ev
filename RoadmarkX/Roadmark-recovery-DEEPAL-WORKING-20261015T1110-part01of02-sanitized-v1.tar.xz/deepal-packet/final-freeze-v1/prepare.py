from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,os,stat
B=Path('/tmp/deepal-packet/final-freeze-v1');W=Path('/workspace/scratch/586427eef9f2');Q=W/'roadmark-104-qa'
def pin(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def row(p,category):
 p=Path(p);s=p.lstat();r=dict(path=str(p),category=category,bytes=s.st_size,mode=s.st_mode,mtimeNs=s.st_mtime_ns)
 if stat.S_ISLNK(s.st_mode):r.update(kind='symlink',target=os.readlink(p),targetFollowed=False)
 else:assert stat.S_ISREG(s.st_mode),str(p);r['kind']='file'
 return r
scopePath=Path('/tmp/deepal-packet/backup-scope-v1/scope-v2.json');scope=json.loads(scopePath.read_text());rows=[]
for r in scope['researchExactAllowlist']:
 x=row(r['path'],'research_author_frozen');assert x['kind']=='file' and x['bytes']==r['bytes'];rows.append(x)
roots=[('/tmp/deepal-packet','packet_history_and_commands'),('/tmp/deepal-review','independent_reviews'),(str(Q/'deepal-sequential-checks'),'initial_checks_including_failed_aggregate'),(str(Q/'deepal-fixture-focused-checks'),'focused_correction_checks'),(str(Q/'deepal-continuation-checks'),'continuation_report_and_failed_successful_comparators')]
# Metadata only. os.walk does not follow directory symlinks; record links instead.
for root,category in roots:
 for current,dirs,files in os.walk(root,followlinks=False):
  dirs.sort();files.sort()
  if Path(current)==B:dirs[:]=[];continue
  for name in list(dirs):
   p=Path(current)/name
   if p.is_symlink():rows.append(row(p,category));dirs.remove(name)
  for name in files:rows.append(row(Path(current)/name,category))
visual=W/'roadmark-104-visual-qa-20261015';visualNames=['visual-qa-blocker-receipt.json','snapshot-manifest.json','launch-receipt.json','stop-receipt.json','market-check.log','server.log']
for n in visualNames:rows.append(row(visual/n,'compact_current_source_preview_receipt'))
reg=json.loads(Path('/tmp/deepal-packet/registration-v1/manifest.json').read_text());docs=json.loads(Path('/tmp/deepal-packet/docs-status-v3/manifest.json').read_text())
expected=[dict(target=r['target'],after=r['after'])for r in reg['writes']]+[dict(target=str(W/'roadmark-104/tests/citable.test.ts'),after=dict(bytes=13548,sha256='7950677521142cb6f99df055fe82551c8a293e292f644c8f26e5d8f01c55adf2'))]+[dict(target=r['target'],after=r['after'])for r in docs['writes']]
assert len(expected)==11;live=[]
for r in expected:
 p=pin(r['target']);assert p['bytes']==r['after']['bytes'] and p['sha256']==r['after']['sha256'];live.append(p);rows.append(row(r['target'],'live_registered_test_docs_status_target'))
assert len({r['path']for r in rows})==len(rows)
rows.sort(key=lambda r:r['path'])
failed=[dict(name='Full-stagev2 live/written citation optional-property mismatch',terminal=pin('/tmp/deepal-packet/full-stage-v2/run/terminal.json'),diagnosis=pin('/tmp/deepal-packet/full-stage-v2/failure-diagnosis.json')),dict(name='Full-stagev3 live/written C1 issue optional-property mismatch',terminal=pin('/tmp/deepal-packet/full-stage-v3/run/terminal.json'),diagnosis=pin('/tmp/deepal-packet/full-stage-v3/failure-diagnosis.json')),dict(name='Original143-test aggregate:142passed/1stale VW fixture failure',terminal=pin(Q/'deepal-sequential-checks/behavioural-suites/terminal.json'),result=pin(Q/'deepal-sequential-checks/behavioural-suites/result.json')),dict(name='Saved-report comparatorv3 cross-measurement-group ordering mismatch',terminal=pin(Q/'deepal-continuation-checks/report-comparison/terminal.json'),result=pin(Q/'deepal-continuation-checks/report-comparison/result.json'))]
for f in failed:assert json.loads(Path(f['terminal']['path']).read_text())['exitCode']!=0
x=dict(status='author_frozen_metadata_exact_allowlist_pending_backup_capture_and_independent_final_receipt',frozenAt=datetime.now(timezone.utc).isoformat(),noFurtherPayloadEdits=True,metadataOnlyInventory=True,contentCaptureOrPrivacyScanPerformed=False,researchScope=pin(scopePath),payloadRoots=[r for r,_ in roots],researchFiles=194,files=rows,totalFiles=len(rows),regularFileBytes=sum(r['bytes']for r in rows if r['kind']=='file'),symlinkCount=sum(r['kind']=='symlink'for r in rows),sourceAndStatusAfterPins=live,knownSanitizedSupport=scope['knownSanitizedSupport'],excluded=[*scope['excludedReconstructibleCaches'],dict(path=str(visual/'snapshot'),reason='Redundant259455351-byte current-source preview snapshot, dependency links and generated .next/cache excluded; six compact proofs retained',deletionAuthorized=False),dict(path=str(B),reason='Inventory, preparer and final acceptance are pinned separately to avoid a circular inventory hash')],retainedFailures=failed,otherLimits=dict(selectedPreflightV2='Diagnostic terminal pass exposed two stale E07 driveaway consumer answers; v6 canonical fallback remedy and accepted validation retained',sourceResearchV1toV6='All original/superseded candidates retained, not labelled as executed failures',preview='Terminal browser-to-preview reachability refusal; clean server stop and352unchanged originals; no screenshots or real-device/UI pass',normalReport='Exactly one actual production report, retained unchanged; failedv3 and successfulv4 comparisons retained'),independentDocsReadback=pin('/tmp/deepal-review/DOCS-STATUS-V3-READBACK.json'),finalRuntimeAcceptance=pin('/tmp/deepal-review/NORMAL-REPORT-AND-COMPARISON-ACCEPTANCE.json'),externalDependencies='Reuse retained accepted baseline/Audi chain inputs by their exact manifest references; before-copy pointer mapping is owned and checked by backup. No broad recapture or original credential recovery.',finalReviewerReceiptPolicy='Reviewer directory frozen except one final retention-acceptance receipt; pin that separately after this inventory review. No payload mutation needed.',preparer=pin(__file__))
p=B/'inventory.json';p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n');print(json.dumps(dict(inventory=pin(p),files=len(rows),bytes=x['regularFileBytes'],symlinks=x['symlinkCount'],liveTargets=len(live)),indent=2))
