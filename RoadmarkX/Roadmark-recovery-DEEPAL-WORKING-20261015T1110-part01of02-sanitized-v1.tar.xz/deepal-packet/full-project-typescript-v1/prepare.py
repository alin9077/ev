"""Static Deepal gate preparation from accepted Audi evidence; never starts product code."""
from pathlib import Path
from datetime import datetime, timezone
import ast, copy, hashlib, json, re
B = Path('/tmp/deepal-packet/full-project-typescript-v1')
A = Path('/tmp/audi-packet/full-project-typescript-v2')
D = Path('/tmp/deepal-packet/registration-v1')
R = Path('/workspace/scratch/586427eef9f2/roadmark-104')
APP_SHA = 'a50e418f43a2c1ad9c03d044b0761c575226eaf5db47b58ed7ed8f5f3dddc0c5'
REVIEW = Path('/tmp/deepal-review/REGISTRATION-READBACK-AND-CHECK-PLAN-REVIEW.json')
REVIEW_SHA = 'c6502d1a545450e91caf24c2cf8949cdd9d5b0b6efe9b1b9d6354d3016980e36'
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        while d:=f.read(1024*1024): h.update(d)
    return h.hexdigest()
def pin(p):
    p=Path(p); return {'path':str(p),'realpath':str(p.resolve()),'bytes':p.stat().st_size,'sha256':sha(p)}
def meta(p):
    p=Path(p)
    if not p.exists(): return {'path':str(p),'exists':False}
    s=p.stat();return {'path':str(p),'exists':True,'realpath':str(p.resolve()),'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'mode':s.st_mode,'isDirectory':p.is_dir(),'isSymlink':p.is_symlink()}
def write(n,v):
    with (B/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def verify(p):
    actual=pin(p['path'])
    assert all(actual[k]==v for k,v in p.items()), p['path']
    return actual
assert sha(D/'manifest.json')==APP_SHA
app=json.loads((D/'manifest.json').read_text()); result=json.loads((D/'application/result.json').read_text())
assert result['passed'] is True and result['manifestSha256']==APP_SHA
assert len(app['writes'])==len(result['writes'])==7
applied=[]
for w,receipt in zip(app['writes'],result['writes']):
    p=pin(w['target']); assert p['bytes']==w['after']['bytes'] and p['sha256']==w['after']['sha256']
    assert receipt=={'target':w['target'],'sha256':p['sha256']}
    applied.append(p)
assert sha(REVIEW)==REVIEW_SHA
review=json.loads(REVIEW.read_text())
assert review['allSevenLiveHashesAndBytesMatchAcceptedPayloads'] is True
assert review['manifestSha256']==APP_SHA and review['applicationReceiptSha256']==sha(D/'application/result.json')
m=json.loads((A/'manifest.json').read_text()); ar=json.loads((A/'run/result.json').read_text())
assert ar['passed'] is True and ar['fullProjectTypecheckPassed'] is True and ar['pinsPassed'] is True and ar['scopePassed'] is True
assert ar['manifestSha256']==sha(A/'manifest.json')=='40134fe13618503f5130287e44580e6cc31d4e799ebb0570dfd5c7d6650f6b45'
assert pin(A/'run.py')==m['wrapper']
oldscope=json.loads((A/'project-root-metadata.json').read_text())
config=json.loads((R/'tsconfig.json').read_text());assert config==m['originalConfig']
by_pattern={pat:sorted({str(p.resolve()) for p in R.glob(pat) if p.is_file()}) for pat in config['include']}
paths=sorted({p for v in by_pattern.values() for p in v})
assert paths==oldscope['configuredRootFilePaths'] and len(paths)==361
scope=copy.deepcopy(oldscope)
scope['matchedByConfiguredPattern']={k:len(v) for k,v in by_pattern.items()}
scope['fileMetadata']=[meta(p) for p in paths]
scope['directoryState']=[meta(p['path']) for p in oldscope['directoryState']]
changed=[{'before':old,'after':new} for old,new in zip(oldscope['fileMetadata'],scope['fileMetadata']) if old!=new]
expected_changed={str(R/w['relativePath']) for w in app['writes'] if w['relativePath'].endswith('.ts')}
assert {x['after']['path'] for x in changed}==expected_changed and len(changed)==4
assert all({k for k in x['before'] if x['before'][k]!=x['after'][k]}=={'bytes','mtimeNs'} for x in changed)
assert scope['directoryState']==oldscope['directoryState']
scope['note']='Evidence-only root inventory, never supplied to tsc. Original transitive import/type resolution stays enabled. Metadata is not a whole-project content freeze. Named config, tools, generated types, live cache, applied targets and relevant source/data dependencies receive explicit content pins.'
write('project-root-metadata.json',scope)
oldpins=json.loads((A/'input-pins.json').read_text())
pins=[verify(p) for p in oldpins]
assert len(pins)==32
# Only named dependency content reads; no project-wide source/data scan or hydration.
named=['src/lib/brand-update-registry.ts','src/lib/types.ts','src/lib/brand-configuration-updates.ts','src/lib/corrections.ts','src/lib/config.ts','src/lib/availability-corrections.ts','src/lib/correction-guards.ts','src/lib/evidence-grading.ts','src/lib/price-ladder.ts','src/lib/selling-points.ts','src/lib/evidence-regrading.ts','src/lib/configuration-evidence.ts','src/lib/research-refresh.ts','src/lib/feature-corrections.ts','src/lib/launch-evidence.ts','src/lib/data.ts','src/lib/market-inventory-data.ts','src/lib/evidence-date.ts','src/lib/citable.ts','src/lib/portable-packs.ts','src/lib/validate.ts','src/components/ui.tsx','tests/helpers/compiled-source.ts','scripts/reporting/m1-reconciliation.ts','scripts/reporting/reports.ts','scripts/report-coverage.ts','src/lib/discovery.ts','src/lib/freshness.ts']
registry=json.loads((R/'data/m1-brand-updates/registry.json').read_text())
before_registry=json.loads((D/'before/data/m1-brand-updates/registry.json').read_text())
assert registry['schemaVersion']==1 and len(registry['packets'])==26
assert registry['packets'][:-1]==before_registry['packets'] and registry['packets'][-1]=='deepal-2026-10-15.json'
named += ['data/m1-brand-updates/'+name for name in registry['packets']]
# Loader/consumer direct JSON imports are explicit, bounded source-selected inputs.
for source in ['scripts/reporting/load.ts','src/lib/evidence-consumers.ts']:
    sourcepath=R/source
    for rel in re.findall(r'from\s+[\"\']([^\"\']+\.json)[\"\']',sourcepath.read_text()):
        named.append(str((sourcepath.parent/rel).resolve().relative_to(R)))
newpins=[*applied,*[pin(R/name) for name in named]]
for p in newpins:
    if p['path'] not in {x['path'] for x in pins}:pins.append(p)
proofpaths=[D/'manifest.json',D/'application/result.json',D/'CHECK-PLAN.md',REVIEW]
proofpaths += [Path(p['path']) for p in app['proofs'] if p['path'].endswith('.json') and ('full-stage-v4' in p['path'] or 'REVIEW' in p['path'] or 'published-driveaway-validation-v2/result.json' in p['path'])]
for p in proofpaths:
    q=pin(p)
    if q['path'] not in {x['path'] for x in pins}:pins.append(q)
write('input-pins.json',pins)
write('application-verification.json',{'status':'static_seven_target_readback_passed','applicationManifest':pin(D/'manifest.json'),'applicationResult':pin(D/'application/result.json'),'independentReadbackReview':pin(REVIEW),'allSevenAfterHashesVerified':True,'targets':applied,'registryPrior25UnchangedAndDeepalAppended26':True})
write('metadata-delta.json',{'previousAcceptedManifest':pin(A/'manifest.json'),'previousAcceptedResult':pin(A/'run/result.json'),'rootFileNamesUnchanged':True,'configuredRootCountBefore':361,'configuredRootCountAfter':len(paths),'addedRoots':[],'removedRoots':[],'configuredPatternCounts':scope['matchedByConfiguredPattern'],'onlyConfiguredRootMetadataChanges':changed,'directoryStateUnchanged':True,'unchangedOriginalContentPinCount':len(oldpins),'allSevenAppliedContentPins':applied,'explanation':'Four existing configured TypeScript roots changed exactly as registered. The other three target changes are the registry JSON replacement plus new Deepal packet and reconciliation JSON; these are pinned imported/runtime data, not new tsconfig roots. No generated types were refreshed and no config or dependency install changed.'})
prior=json.loads((A/'prior-attempts.json').read_text());terminal=json.loads((A/'run/terminal.json').read_text())
prior.append({'classification':'Accepted successful Audi cold full-project TypeScript precedent, not a Deepal check','command':m['command'],'nodeFlags':m['command'][1:3],'timeoutSeconds':900,'elapsedSeconds':terminal['elapsedSeconds'],'exitCode':0,'maxRssKiB':terminal['maxRssKiB'],'pinsPassed':True,'scopePassed':True,'configuredRootCount':361,'retainedEvidence':[pin(A/n) for n in ['manifest.json','run.py','input-pins.json','project-root-metadata.json','run/invocation.json','run/terminal.json','run/result.json','run/after-pins.json','run/scope-verification.json','run/stdout.log','run/stderr.log']]})
write('prior-attempts.json',prior)
wrapper=(A/'run.py').read_text().replace(str(A),str(B))
wrapper=wrapper.replace("assert g['focusedCorrectionChecksAccepted'] is True\ncheck(g['focusedCorrectionVerification'])", "assert g['deepalApplicationAccepted'] is True\nassert g['applicationVerification'] == m['deepalApplication']['independentReadbackReview']\ncheck(g['applicationVerification'])\nassert g['precedingChecksAccepted'] is True\ncheck(g['precedingCheckVerification'])")
wrapper=wrapper.replace("check(g['reviewerAcceptance'])\n", "check(g['reviewerAcceptance'])\nreadiness = json.loads(Path(g['reviewerAcceptance']['path']).read_text())\nassert readiness['status'] == 'accepted'\nassert readiness['manifest']['path'] == mp and readiness['manifest']['sha256'] == mh\nassert readiness['wrapper']['path'] == m['wrapper']['path'] and readiness['wrapper']['sha256'] == m['wrapper']['sha256']\n",1)
wrapper=wrapper.replace("g['focusedCorrectionVerification']", "g['precedingCheckVerification'], g['applicationVerification']")
insert='''def check_preceding():
    receipt = json.loads(Path(g['precedingCheckVerification']['path']).read_text())
    assert receipt['status'] == 'accepted'
    assert receipt['applicationManifestSha256'] == m['deepalApplication']['manifest']['sha256']
    expected = m['requiredPrecedingChecks']
    assert [c['name'] for c in receipt['checks']] == expected
    for c in receipt['checks']:
        assert c['passed'] is True and c['exitCode'] == 0
        for field in ['manifest', 'result', 'terminal']:
            check(c[field])
        result = json.loads(Path(c['result']['path']).read_text())
        terminal = json.loads(Path(c['terminal']['path']).read_text())
        assert result['passed'] is True and result['exitCode'] == 0
        assert terminal['exitCode'] == 0
        assert result['manifestSha256'] == c['manifest']['sha256']
    application = json.loads(Path(m['deepalApplication']['result']['path']).read_text())
    review = json.loads(Path(g['applicationVerification']['path']).read_text())
    assert application['passed'] is True and application['manifestSha256'] == m['deepalApplication']['manifest']['sha256']
    assert review['allSevenLiveHashesAndBytesMatchAcceptedPayloads'] is True
    assert review['manifestSha256'] == application['manifestSha256']
    assert review['applicationReceiptSha256'] == m['deepalApplication']['result']['sha256']

'''
wrapper=wrapper.replace('def check_inputs():\n',insert+'def check_inputs():\n    check_preceding()\n')
wrapper=wrapper.replace("assert m['command'][1:3] == ['--max-old-space-size=768', '--max-semi-space-size=1']", "assert m['command'][:4] == ['/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node', '--max-old-space-size=768', '--max-semi-space-size=1', '/workspace/scratch/586427eef9f2/roadmark-104/node_modules/typescript/bin/tsc']\nassert m['supervisorWatchdogSeconds'] == 920")
wrapper=wrapper.replace("check_inputs()\nout = BASE / 'run'", "out = BASE / 'run'")
wrapper=wrapper.replace("env = os.environ.copy()", """try:
    check_inputs()
except Exception as error:
    write('preflight-failure.json', {'at': now(), 'error': repr(error), 'processStarted': False, 'automaticRetry': False})
    write('terminal.json', {'at': now(), 'exitCode': None, 'processStarted': False, 'classification': 'input_or_prerequisite_rejected', 'automaticRetry': False})
    write('result.json', {'at': now(), 'passed': False, 'exitCode': None, 'manifestSha256': mh, 'rootGrantSha256': gh, 'processStarted': False, 'fullProjectTypecheckPassed': False, 'automaticRetry': False, 'furtherAttemptRequiresNewApproval': True})
    raise

env = os.environ.copy()""")
wrapper=wrapper.replace("                                   'automaticRetry': False})\n        raise", """                                   'automaticRetry': False})
        write('terminal.json', {'at': now(), 'exitCode': None, 'processStarted': False, 'classification': 'process_setup_failed', 'automaticRetry': False})
        write('result.json', {'at': now(), 'passed': False, 'exitCode': None, 'manifestSha256': mh, 'rootGrantSha256': gh, 'processStarted': False, 'fullProjectTypecheckPassed': False, 'automaticRetry': False, 'furtherAttemptRequiresNewApproval': True})
        raise""")
wrapper=wrapper.replace("    except BaseException:\n", "    except BaseException as error:\n")
wrapper=wrapper.replace("            os.wait4(p.pid, 0)\n        except ChildProcessError:\n            pass\n        raise", """            _, interrupted_status, interrupted_usage = os.wait4(p.pid, 0)
        except ChildProcessError:
            interrupted_status, interrupted_usage = None, None
        so.flush(); se.flush(); os.fsync(so.fileno()); os.fsync(se.fileno())
        write('terminal.json', {'at': now(), 'exitCode': os.waitstatus_to_exitcode(interrupted_status) if interrupted_status is not None else None, 'rawWaitStatus': interrupted_status, 'elapsedSeconds': time.monotonic() - start, 'maxRssKiB': interrupted_usage.ru_maxrss if interrupted_usage is not None else None, 'resourceSource': 'os.wait4', 'classification': 'wrapper_interrupted', 'error': repr(error), 'stdoutSha256': sha(out / 'stdout.log'), 'stderrSha256': sha(out / 'stderr.log'), 'automaticRetry': False})
        write('result.json', {'at': now(), 'passed': False, 'manifestSha256': mh, 'rootGrantSha256': gh, 'fullProjectTypecheckPassed': False, 'classification': 'wrapper_interrupted', 'automaticRetry': False, 'furtherAttemptRequiresNewApproval': True})
        raise""")
ast.parse(wrapper)
with (B/'run.py').open('x') as f:f.write(wrapper)
m['id']='deepal-cold-full-project-typescript-768-v1'
m['preparedAt']=datetime.now(timezone.utc).isoformat()
m['command'][-1]=str(B/'run/full-project.tsbuildinfo')
m['wrapper']=pin(B/'run.py');m['preparer']=pin(B/'prepare.py')
for k,n in [('inputPins','input-pins.json'),('projectRootMetadata','project-root-metadata.json'),('priorAttempts','prior-attempts.json'),('metadataDelta','metadata-delta.json')]:m[k]=pin(B/n)
m['cacheHandling']['newCachePath']=str(B/'run/full-project.tsbuildinfo')
m['scopePreservation']['compilerOptionOverrides']['tsBuildInfoFile']=str(B/'run/full-project.tsbuildinfo')
m['allowedWrites']=[str(B/'run')+'/**']
m['scopePreservation']['configuredRootsObserved']=len(paths)
m['scopePreservation']['postRunProof']='Fresh tsbuildinfo root IDs must resolve to exactly the 361 freshly verified unchanged configured roots; missing cache or a mismatch prevents a passed claim.'
m['timeoutRationale']='Reuse accepted Audi v2 successful 768/1 MiB envelope: 43.455958 seconds and 874928 KiB wait4 max RSS. This is not a guarantee for Deepal. Retain the single 900-second timeout, 10-second kill grace and 920-second supervisor watchdog. No retry or resource escalation.'
m['memoryLimits']['note']='V8 heap flags do not cap total RSS. Precedent max RSS is evidence, not a current reserved memory budget or success guarantee. Root must grant the exclusive heavy slot.'
m['runtimeVersionProvenance']='Versions retained from accepted Audi v2; every installed package content pin and runtime stat record reverified without invoking node or compiler.'
for p in m['runtimeMetadata']:assert meta(p['path'])==p
m['claimLimits']=['Fresh cold full-project tsc check, not literal package script and not next build','Existing skipLibCheck and every other configured checker option are preserved','Earlier OOMs, Audi corrected diagnostic and successful Audi precedent remain history','Deepal staging and preceding focused/runtime checks do not satisfy this gate','Preparation stat inventory is not a whole-project content hash; named relevant inputs have explicit content pins']
m['approvedFinalDataContext']={'catalogueVersions':427,'tierOneVersions':350,'onSaleVersions':309,'packets':26}
m['preparationVerification']='Static Python metadata/hash collection and AST parse only; wrapper, compiler, Node runtime and tests not executed'
m.pop('separateRecheckAuthorization')
m['deepalApplication']={'manifest':pin(D/'manifest.json'),'result':pin(D/'application/result.json'),'independentReadbackReview':pin(REVIEW),'localVerification':pin(B/'application-verification.json'),'allSevenAfterHashesVerified':True}
m['requiredPrecedingChecks']=['market-view','changed-file-lint','behavioural-suites','live-brand-safety','structural-validation']
m['executionConditions']=['Independent review accepts this exact manifest and wrapper','Independent application readback remains pinned and all seven live target hashes match','Reviewer accepts all five preceding sequential gates with exact manifest/result/terminal pins','Root grants this exact manifest and wrapper, accepted prerequisites and the exclusive heavy slot','Fresh output directory/cache absent; exactly one compiler process attempt, no retries']
m['reviewerReadinessContract']={'status':'accepted','manifest':'Object containing this exact manifest path and SHA-256','wrapper':'Object containing this exact wrapper path and SHA-256'}
m['precedingCheckVerificationContract']={'status':'accepted','applicationManifestSha256':APP_SHA,'checks':'Exactly requiredPrecedingChecks order; each item has name, passed=true, exitCode=0 and manifest/result/terminal content pins. Each result must contain passed=true, exitCode=0 and matching manifestSha256; terminal exitCode=0.'}
write('manifest.json',m)
g={'status':'TEMPLATE_NOT_A_GRANT','manifest':{'path':str(B/'manifest.json'),'sha256':sha(B/'manifest.json')},'wrapper':m['wrapper'],'reviewerReadinessConfirmed':False,'reviewerAcceptance':{'path':'REPLACE_WITH_EXACT_REVIEWER_ACCEPTANCE_PATH','bytes':0,'sha256':'REPLACE'},'deepalApplicationAccepted':False,'applicationVerification':pin(REVIEW),'precedingChecksAccepted':False,'precedingCheckVerification':{'path':'REPLACE_WITH_FIVE_PRECEDING_CHECKS_ACCEPTANCE_PATH','bytes':0,'sha256':'REPLACE'},'heavySlotExclusive':True,'automaticRetry':False,'parallelExecutionAllowed':False,'maximumAttempts':1,'coldCacheRelocationApproved':True,'instruction':'Template only. Root must confirm exact reviewer readiness, accepted Deepal application and all five preceding checks, then write a separate root_execution_granted receipt for this manifest/wrapper and exclusive slot. No execution is granted by preparation, history or this template.'}
write('root-grant-template.json',g)
assert not (B/'run').exists()
print(json.dumps({'manifest':pin(B/'manifest.json'),'wrapper':pin(B/'run.py'),'inputPinCount':len(pins),'configuredRootCount':len(paths),'metadataChangedRoots':len(changed),'allSevenHashesVerified':True,'wrapperNotExecuted':True},indent=2))
