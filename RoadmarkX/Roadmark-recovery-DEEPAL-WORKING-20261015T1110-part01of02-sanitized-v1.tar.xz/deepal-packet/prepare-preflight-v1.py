from pathlib import Path
import json,hashlib
R=Path('/tmp/deepal-research');P=Path('/tmp/deepal-packet');O=P/'selected-preflight-v1';O.mkdir(exist_ok=True);repo=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def read(p):return json.loads(Path(p).read_text())
def write(p,x):Path(p).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
packetpath=P/'v5/deepal-2026-10-15.json';reconpath=P/'reconciliation-v2/m1-deepal-market-reconciliation-2026-10-15.json'
packet=read(packetpath);n=read(R/'normalized-review-v5.json');recon=read(reconpath);before=read(R/'retained-before-cars.json');ids=[x['id'] for x in before]
attrs=['length_mm','range_km','price_aud','dc_charge_time_min','towing_braked_kg','seats','boot_l']
# Reviewed semantic expectations, independent of the actual consumer output.
def eligible(f):return f['buyerGrade'] in ['confirmed','check'] and bool(f['comparisonBasis'].strip()) and not f.get('conflictId')
expected=dict(coreKeys=list(n['variants'][0]['coreFacts']),bodyByModelId={v['modelId']:'SUV' for v in n['variants']},currentListIds=ids,onSaleIds=ids,rankingIds={k:[v['id'] for v in n['variants'] if eligible(v['coreFacts'][k])] for k in attrs},normalizedRankPolicy=[dict(variantId=v['id'],key=k,numeric=isinstance(f['value'],(int,float)),eligible=eligible(f),buyerGrade=f['buyerGrade'],value=f['value'],comparisonBasis=f['comparisonBasis']) for v in n['variants'] for k,f in v['coreFacts'].items()],expectedSettledInventory=['record:deepal-s07','record:deepal-e07'],expectedUnresolvedInventory=['lead:deepal-s05'],factUpdates=len(packet['facts']),termCells=sum(len(t['applicableVariantIds']) for t in packet['brandTerms']),allFeatureClaims=3*69,expectedDriveawayCanonicalProjectionIds=[ids[0]],expectedBeforeOrcIds=ids[1:])
write(O/'expected-review.json',expected)
s=Path('/tmp/audi-packet/selected-preflight-v3/check.mjs').read_text()
s=s.replace('seven retained and seventeen proposed Audi rows only','three retained Deepal before/after rows only').replace('/tmp/audi-packet/selected-preflight-v3',str(O)).replace('/tmp/audi-packet/v1/audi-2026-10-15.json',str(packetpath)).replace('4a85ee0d92c7a49e3e2265791516658699dfe2320d3e52e2ce39b58b2f6d172e',pin(packetpath)['sha256']).replace('/tmp/audi-research/retained-before-cars.json',str(R/'retained-before-cars.json'))
s=s.replace('assert.equal(before.length,7)','assert.equal(before.length,3)').replace('assert.equal(base.variants.length,7);assert.equal(base.feature_evidence.length,7*69);assert.equal(base.feature_evidence_variant_context.length,7);','assert.equal(base.variants.length,3);assert.equal(base.feature_evidence.length,207);assert.equal(base.feature_evidence_variant_context.length,3);')
s=s.replace("assert.equal(brandUpdatePackets.length,24);assert.equal(brandUpdatePackets.at(-1).id,'m1-skoda-2026-10-15');","assert.equal(brandUpdatePackets.length,25);assert.equal(brandUpdatePackets.at(-1).id,'m1-audi-2026-10-15');")
s=s.replace('brandUpdatePackets.slice(-4)','brandUpdatePackets.slice(-5)').replace("assert.notEqual(prior.brand,'Audi')","assert.notEqual(prior.brand,'Deepal')")
s=s.replace('assert.equal(after.length,17);assert.equal(data.variants.length,17);assert.equal(data.feature_evidence.length,17*69);','assert.equal(after.length,3);assert.equal(data.variants.length,3);assert.equal(data.feature_evidence.length,207);')
# Selected exact retained car parity against accepted Audi25, without full catalogue hydration.
needle='const expected=readJson(out+\'/expected-review.json\');const base={},reads=[];'
replacement="""const parity=readJson('/tmp/deepal-research/audi25-peer-parity.json');assert.equal(parity.rows.length,3);
for(const car of before){const row=parity.rows.find(x=>x.id===car.id);assert(row);assert.equal(row.acceptedAudi25Sha256,digestRows([car]).sha256);}
const expected=readJson(out+'/expected-review.json');const base={},reads=[];"""
# Receipt field names are read directly below during preparation, not guessed.
parity=read(R/'audi25-peer-parity.json')
replacement="const parity=readJson('/tmp/deepal-research/audi25-peer-parity.json');assert.deepEqual(parity,"+json.dumps(parity,separators=(',',':'))+");\n"+needle
assert needle in s;s=s.replace(needle,replacement)
start=s.index('// Actual generated-before availability witness.')
end=s.index('for(const edit of packet.summaries)',start)
s=s[:start]+"""assert.equal(packet.variants.length,0);assert.equal(packet.models.length,0);assert.equal(packet.features.length,0);assert.equal(packet.configurationUpdates.length,0);
for(const edit of packet.availability){const b=before.find(c=>c.id===edit.variantId),a=after.find(c=>c.id===edit.variantId);assert.deepEqual({availability:b.availability,evidence:b.availabilityEvidence},edit.before);assert.equal(a.availability,edit.after.availability);assert.deepEqual(a.availabilityEvidence,edit.after.evidence);}
"""+s[end:]
start=s.index('const optionalFields=')
end=s.index('\nfunction observe',start)
s=s[:start]+"""const producerFrames=new Map();
for(const [phase,cars,consumer,research]of [['before',before,initial,base],['after',after,final,data]])for(const car of cars){const input=consumer.sourceEffectiveFeatures(car,research),snapshot=structuredClone(input),regraded=applyFeatureRegrading(car,input,research.sources);assert.deepEqual(input,snapshot);producerFrames.set(phase+'\\0'+car.id,{input,regraded});producerProofs.push({phase,variantId:car.id,producer:'actual sourceEffectiveFeatures → actual applyFeatureRegrading',inputRows:input.length,outputRows:regraded.length,inputUnchanged:true});}
"""+s[end:]
start=s.index('function observe(');end=s.index('for(const car of before){const pack=',start)
s=s[:start]+"""function observe(car,pack,phase){const pointers=[];function visit(value,pointer){if(value===undefined){const match=pointer.match(/\\/features\\/(\\d+)\\/([^/]+)$/);assert(match,'Unexpected undefined outside feature: '+pointer);const rowIndex=Number(match[1]),property=match[2],feature=pack.features[rowIndex],descriptor=Object.getOwnPropertyDescriptor(feature,property);assert(descriptor&&Object.hasOwn(descriptor,'value')&&descriptor.value===undefined&&descriptor.enumerable);assert(selected.has(car.id));const frame=producerFrames.get(phase+'\\0'+car.id),sourceRow=frame.input.find(f=>f.criterion===feature.criterion),regradedRow=frame.regraded.find(f=>f.criterion===feature.criterion);assert(sourceRow&&regradedRow);let producer;
 if(property==='gradeReviewStatus'){assert(feature.gradeReview);assert(Object.hasOwn(regradedRow,property));assert.equal(regradedRow[property],undefined);producer='src/lib/evidence-regrading.ts:185; actual earned retained-feature branch explicitly sets gradeReviewStatus undefined';}
 else if(property==='condition_label'){assert.equal(feature.buyerGrade,'check');assert(!Object.hasOwn(sourceRow,property)||sourceRow[property]===undefined);assert(Object.hasOwn(regradedRow,property));assert.equal(regradedRow[property],undefined);producer='src/lib/evidence-regrading.ts:188; actual Check branch retains original optional condition_label';}
 else if(property==='confirmation_needed'){assert.equal(feature.criterion,'novated_fbt');for(const row of [sourceRow,regradedRow]){const d=Object.getOwnPropertyDescriptor(row,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);}const raw=(phase==='before'?base:data).feature_evidence.find(f=>f.variant_id===car.id&&f.criterion===feature.criterion);assert(raw);const rawSnapshot=structuredClone(raw),audited=auditedFeature(raw);assert.deepEqual(raw,rawSnapshot);const ad=Object.getOwnPropertyDescriptor(audited,property);assert(ad&&ad.enumerable&&Object.hasOwn(ad,'value')&&ad.value===undefined);producer='src/lib/launch-evidence.ts:84; actual auditedFeature(raw selected row) creates confirmation_needed undefined';}
 else if(['buyerGrade','gradeReview'].includes(property)){assert.equal(feature.gradeReviewStatus,'review_required');assert(Object.hasOwn(regradedRow,property));assert.equal(regradedRow[property],undefined);producer='src/lib/evidence-regrading.ts:168–170; actual unmatched retained-feature branch withdraws optional review';}
 else assert.fail('Unclassified optional undefined: '+pointer);
 observations.push({phase,variantId:car.id,pointer,rowIndex,criterion:feature.criterion,property,ownUndefined:true,enumerable:true,producer,sourceProperty:{own:Object.hasOwn(sourceRow,property),valueKind:sourceRow[property]===undefined?'undefined':typeof sourceRow[property]},actualRegradedProperty:{own:Object.hasOwn(regradedRow,property),valueKind:regradedRow[property]===undefined?'undefined':typeof regradedRow[property]},typeDefinition:'src/lib/types.ts Feature optional '+property});pointers.push(pointer);return;}if(!value||typeof value!=='object')return;for(const k of Object.keys(value))visit(value[k],pointer+'/'+k.replaceAll('~','~0').replaceAll('/','~1'));}visit(pack,'/packs/'+car.id);assertDeclaredJson(pack,'/packs/'+car.id,new Set(pointers));}
"""+s[end:]
start=s.index(' const prior=beforePacks[car.id];for(const feature')
end=s.index(' for(const f of Object.values(car.facts)',start)
s=s[:start]+""" const prior=beforePacks[car.id];assert(prior);for(const feature of pack.features){if(feature.criterion==='driveaway_price'){const f=car.facts.price_aud;if(f.comparisonBasis==='Driveaway'){assert.equal(feature.value,'A$'+f.value.toLocaleString('en-AU'));assert.deepEqual(feature.source_ids,f.sourceIds);assert.equal(feature.buyerGrade,f.buyerGrade);assert.equal(feature.verification_state,'reviewed_canonical_driveaway_price');assert(expected.expectedDriveawayCanonicalProjectionIds.includes(car.id));priceFeatureRefreshes++;}else{assert.equal(f.comparisonBasis,'Before on-road costs');assert(expected.expectedBeforeOrcIds.includes(car.id));const frame=producerFrames.get('after\\0'+car.id),fallback=frame.regraded.find(x=>x.criterion==='driveaway_price');assert(fallback);assert.deepEqual(feature,fallback,'Before-ORC must not project as driveaway; preserve exact source-effective fallback');assert.notEqual(feature.verification_state,'reviewed_canonical_driveaway_price');producerProofs.push({phase:'after',variantId:car.id,kind:'before_orc_driveaway_fallback',producer:'sourceEffectiveFeatures → applyFeatureRegrading; applyBrandTermFeatures has no eligible driveaway canonical fact',feature:structuredClone(feature)});}continue;}assert.deepEqual(feature,prior.features.find(f=>f.criterion===feature.criterion),'No unrelated feature replay: '+car.id+'/'+feature.criterion);}
"""+s[end:]
s=s.replace("assert.equal(car.year,onSale?2026:2027);","assert.equal(car.year,null);")
s=s.replace('assert.equal(priceFeatureRefreshes,9);assert.equal(earnedCells,339);assert.equal(featureClaims,1173);assert.equal(after.filter(isOnSale).length,9);assert.equal(after.filter(isOnSale).length-before.filter(isOnSale).length,2);','assert.equal(priceFeatureRefreshes,1);assert.equal(earnedCells,expected.factUpdates+expected.termCells);assert.equal(featureClaims,207);assert.equal(after.filter(isOnSale).length,3);assert.equal(after.filter(isOnSale).length-before.filter(isOnSale).length,0);')
s=s.replace('assert.equal(ranks.excluded.length,17-ranked.length)','assert.equal(ranks.excluded.length,3-ranked.length)')
start=s.index('for(const o of observations.filter(x=>x.phase===\'after\'&&selected.has')
end=s.index('// Same-run actual C1',start)
s=s[:start]+"""for(const o of observations.filter(x=>x.phase==='after')){const prior=observations.find(x=>x.phase==='before'&&x.pointer===o.pointer&&x.criterion===o.criterion&&x.property===o.property);const a=afterPacks[o.variantId].features[o.rowIndex],b=beforePacks[o.variantId].features[o.rowIndex];assert.equal(a.criterion,b.criterion);if(o.criterion!=='driveaway_price'){assert(prior,'Unchanged feature omission needs exact before witness: '+o.pointer);if(o.property==='gradeReviewStatus')assert.deepEqual(a.gradeReview,b.gradeReview);}else{assert(expected.expectedBeforeOrcIds.includes(o.variantId));const frame=producerFrames.get('after\\0'+o.variantId);assert.deepEqual(a,frame.regraded.find(f=>f.criterion===o.criterion));}}
"""+s[end:]
s=s.replace('// Same-run actual C1 identity proof for exact current MY26 and future order-open MY27 bodies/grades.','// Same-run actual C1 proof: exact current Deepal SUV bodies/grades, with S05 unresolved.')
s=s.replace('/tmp/audi-packet/v1/m1-audi-market-reconciliation-2026-10-15.json',str(reconpath)).replace('e79baaa35e7a5e351fdaef7f0bc184dece852727be0b4f253496048f94b44a06',pin(reconpath)['sha256'])
s=s.replace("const audi=s=>typeof s==='string'&&s.toLowerCase()==='audi';", "const deepal=s=>typeof s==='string'&&s.toLowerCase()==='deepal';").replace('audi(r.brand)','deepal(r.brand)').replace('audi(b.brand)','deepal(b.brand)')
s=s.replace('assert.equal(inventory.records.length,5);assert.equal(inventory.unverifiedLeads.length,3);','assert.equal(inventory.records.length,2);assert.equal(inventory.unverifiedLeads.length,1);')
s=s.replace('assert.equal(eligible.length,17);','assert.equal(eligible.length,3);').replace('assert.equal(c1.reviewedModels,7);assert.equal(c1.reviewedVersions,17);','assert.equal(c1.reviewedModels,2);assert.equal(c1.reviewedVersions,3);')
s=s.replace('assert.equal(selectedCoverage.allCatalogueVersions,17);assert.equal(selectedCoverage.tierOneVersions,17);assert.equal(selectedCoverage.onSaleVersions,9);','assert.equal(selectedCoverage.allCatalogueVersions,3);assert.equal(selectedCoverage.tierOneVersions,3);assert.equal(selectedCoverage.onSaleVersions,3);').replace('assert.equal(brandProgress.currentVersionReviews.length,7);','assert.equal(brandProgress.currentVersionReviews.length,2);')
s=s.replace('beforeCars:7,afterCars:17,coreCells:289','beforeCars:3,afterCars:3,coreCells:51').replace('nonDriveawayFeaturesUnverified:8','beforeOrcSourceFallbacks:2').replace('producerProofs,generatedAvailabilityProof,observations','producerProofs,observations').replace('expectedOnSaleDelta:2','expectedOnSaleDelta:0')
assert 'newAuditProof' not in s and 'generatedAvailabilityProof' not in s and "audi(" not in s
(O/'check.mjs').write_text(s)
# Exact same-run selected witnesses define JSON omission permission; no previous brand count is copied.
paths=[]
for x in read('/tmp/audi-packet/selected-preflight-v3/source-pins.json'):
 path=x['path']
 if path.startswith('/tmp/audi-research/') or path.startswith('/tmp/audi-packet/'):continue
 paths.append(path)
paths += [str(R/x) for x in ['retained-before-cars.json','retained-before-selection-receipt.json','audi25-peer-parity.json','normalized-review-v5.json','normalized-census-v2.json','source-index-review-v5.json']]+[str(O/'expected-review.json'),str(reconpath)]
write(O/'source-pins.json',[pin(p) for p in dict.fromkeys(paths)])
w=Path('/tmp/audi-packet/selected-preflight-v3/run.py').read_text().replace('177b7a439bf61f699914d6220313627cd515c7e16c9eee811da70541f37ad04f',pin(O/'check.mjs')['sha256']).replace('4a85ee0d92c7a49e3e2265791516658699dfe2320d3e52e2ce39b58b2f6d172e',pin(packetpath)['sha256']);(O/'run.py').write_text(w)
m=dict(status='prepared_not_executed',script=pin(O/'check.mjs'),sourcePins=pin(O/'source-pins.json'),packet=pin(packetpath),reconciliation=pin(reconpath),wrapper=pin(O/'run.py'),command=['node','--max-old-space-size=448','--max-semi-space-size=1','--import','tsx',str(O/'check.mjs'),'--root-execution-granted'],workdir=str(repo),timeoutSeconds=180,automaticRetry=False,rootExecutionGrantRequired=True,scope='Three retained Deepal before/after cars only. Actual prepare/apply, 64 exact fact guards plus 6 term cells, 51 core grades, all207 feature claims, source closure, actual rank policy, clean summary dependencies, exact availability guards, live/written portable parity. Optional-property locations are proven from same-run selected source and regrade producer outputs; no copied count. One S07 canonical driveaway refresh and two E07 explicit before-ORC source-effective fallbacks are separately asserted. Actual C1 identities for two SUV model families/three grades and unresolved S05 lead. No new hardware/equipment, full catalogue hydration, source edits or automatic retry.')
write(O/'prepared-command.json',m)
print(json.dumps(dict(prepared=pin(O/'prepared-command.json'),script=m['script'],wrapper=m['wrapper'],packet=m['packet'],rankingExpectedCounts={k:len(v) for k,v in expected['rankingIds'].items()},executed=False),indent=2))
