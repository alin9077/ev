"""One exact granted post-registration gate; exclusive, bounded, no retry."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,re,resource,signal,subprocess,sys,time

def now():return datetime.now(timezone.utc).isoformat()
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def check(p):
 f=Path(p['path']);assert f.is_file() and f.stat().st_size==p['bytes'] and digest(f)==p['sha256'],str(f)
def meta(p):
 p=Path(p)
 if not p.exists():return {'path':str(p),'exists':False}
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
assert len(sys.argv)==5,'run.py MANIFEST SHA ROOT_GRANT SHA'
mp,mh,gp,gh=sys.argv[1:];assert digest(mp)==mh and digest(gp)==gh
m=json.loads(Path(mp).read_text());g=json.loads(Path(gp).read_text())
assert m['status']=='frozen_not_executed_requires_review_and_root_grant'
assert g['status']=='root_execution_granted' and g['heavySlotExclusive'] is True
assert g['automaticRetry'] is False and g['parallelExecutionAllowed'] is False
assert any(p['path']==str(Path(mp).resolve()) and p['sha256']==mh for p in g['granted'])
assert m['automaticRetry'] is False and m['sourceMutationsAuthorized'] is False
assert m['killAfterSeconds']==10 and 0<m['timeoutSeconds']<=900
for key in ['sequence','reviewerAcceptance','registrationVerification']:check(g[key])
s=json.loads(Path(g['sequence']['path']).read_text())
assert any(p['path']==str(Path(mp).resolve()) and p['sha256']==mh for p in s['sequence'])
assert m['sourcePins']==s['sourcePins'] and m['rootMetadata']==s['rootMetadata']
assert m['wrapper']['path']==str(Path(__file__).resolve())
pins=json.loads(Path(m['sourcePins']['path']).read_text())
metadata=json.loads(Path(m['rootMetadata']['path']).read_text())
allpins=[m['wrapper'],m['sourcePins'],m['rootMetadata'],m['testInventory'],*pins,*m['extraPins'],g['sequence'],g['reviewerAcceptance'],g['registrationVerification']]
def check_all():
 assert digest(mp)==mh and digest(gp)==gh
 for p in allpins:check(p)
 for expected in metadata['fileMetadata']+metadata['directoryState']:assert meta(expected['path'])==expected,expected['path']
 for prior in m['prerequisites']:
  check(prior['manifest']);r=json.loads(Path(prior['resultPath']).read_text());assert r['passed'] is True and r['exitCode']==0 and r['manifestSha256']==prior['manifest']['sha256']
check_all()
base=Path(m['qaRoot']);base.mkdir(exist_ok=True,parents=True)
lock=(base/'.sequential-check.lock').open('a+');fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
out=Path(m['runOutput']);assert out.parent==base and out.name==m['id'];out.mkdir(exist_ok=False)
def write(n,x):
 with (out/n).open('x') as f:json.dump(x,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
env=os.environ.copy()
for name in m['environmentRemovals']:env.pop(name,None)
env.update(m['environmentOverrides'])
cmd=['/usr/bin/timeout','--signal=TERM','--kill-after=10s',str(m['timeoutSeconds'])+'s',*m['command']]
write('invocation.json',dict(at=now(),manifestSha256=mh,grantSha256=gh,cwd=m['repo'],command=m['command'],supervisedCommand=cmd,beforePinsPassed=True,automaticRetry=False,sourceMutationsAuthorized=False,environmentRemovals=m['environmentRemovals'],environmentOverrides=m['environmentOverrides']))
def setup():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
start=time.monotonic()
with (out/'stdout.log').open('x') as so,(out/'stderr.log').open('x') as se:
 try:p=subprocess.Popen(cmd,cwd=m['repo'],env=env,stdout=so,stderr=se,start_new_session=True,preexec_fn=setup)
 except Exception as e:write('setup-failure.json',dict(at=now(),error=repr(e),processStarted=False));raise
 write('started.json',dict(at=now(),pid=p.pid,processGroup=os.getpgid(p.pid)))
 watchdog=False
 try:
  while True:
   pid,status,usage=os.wait4(p.pid,os.WNOHANG)
   if pid:break
   if time.monotonic()-start>m['timeoutSeconds']+20:
    watchdog=True;os.killpg(p.pid,signal.SIGKILL);_,status,usage=os.wait4(p.pid,0);break
   time.sleep(.25)
 except BaseException:
  try:os.killpg(p.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  try:os.wait4(p.pid,0)
  except ChildProcessError:pass
  raise
 code=os.waitstatus_to_exitcode(status);p.returncode=code
 so.flush();se.flush();os.fsync(so.fileno());os.fsync(se.fileno())
terminal=dict(at=now(),exitCode=code,rawWaitStatus=status,elapsedSeconds=time.monotonic()-start,maxRssKiB=usage.ru_maxrss,userSeconds=usage.ru_utime,systemSeconds=usage.ru_stime,watchdogFired=watchdog,resourceSource='os.wait4; max RSS is not summed simultaneous process-tree memory',stdoutSha256=digest(out/'stdout.log'),stderrSha256=digest(out/'stderr.log'),automaticRetry=False)
write('terminal.json',terminal)
pinsok=False
try:check_all();pinsok=True;write('after-pins.json',dict(at=now(),passed=True,count=len(allpins)))
except Exception as e:write('after-pins.json',dict(at=now(),passed=False,error=repr(e)))
verified=False
try:
 stdout=(out/'stdout.log').read_text();stderr=(out/'stderr.log').read_text()
 assert code==0 and not watchdog and not stderr,'Process failed, watchdog fired or unexpected stderr retained'
 if m['kind']=='market':assert stdout=='Market view verified without writing\n'
 elif m['kind']=='lint':
  rows=json.loads(stdout);assert len(rows)==len(m['lintFiles'])
  assert sorted(r['filePath'] for r in rows)==sorted(str(Path(m['repo'])/p) for p in m['lintFiles'])
  assert all(r['errorCount']==r['warningCount']==r['fatalErrorCount']==0 and not r['messages'] for r in rows)
 elif m['kind']=='tests':
  inventory=json.loads(Path(m['testInventory']['path']).read_text());names=[]
  for f in m['testFiles']:names+=inventory[f]['names']
  observed=re.findall(r'^# Subtest: (.*)$',stdout,re.M);assert sorted(observed)==sorted(names)
  for label,n in [('tests',len(names)),('pass',len(names)),('fail',0),('cancelled',0),('skipped',0),('todo',0)]:assert re.search(r'^# '+label+r' '+str(n)+r'$',stdout,re.M),label
  assert not re.search(r'^not ok\b',stdout,re.M)
 elif m['kind']=='structural':
  r=json.loads(stdout);assert r['result']=='PASS';assert r['counts']['variants']==427
 elif m['kind']=='normal-report':
  r=json.loads(stdout);assert [r['allCatalogueVersions'],r['tierOneVersions'],r['onSaleVersions']]==[427,350,309] and r['asOf']=='2026-10-15'
 elif m['kind']=='comparison':
  r=json.loads(Path(m['comparisonResult']).read_text());assert r['passed'] is True and r['allNormalLeavesAccounted'] is True and r['broadFeatureReplay'] is False
 else:raise AssertionError('Unknown gate kind')
 verified=True;write('scope-verification.json',dict(passed=True,kind=m['kind'],expectedTests=m.get('expectedTests'),sourceScopeUnchanged=True))
except Exception as e:write('scope-verification.json',dict(passed=False,error=repr(e),kind=m['kind']))
passed=code==0 and pinsok and verified and not watchdog
write('result.json',dict(at=now(),passed=passed,exitCode=code,manifestSha256=mh,pinsPassed=pinsok,scopePassed=verified,automaticRetry=False,nextBuildClaim=False))
print(json.dumps(terminal));print(json.dumps(dict(passed=passed,result=str(out/'result.json'))));sys.exit(0 if passed else 1)
