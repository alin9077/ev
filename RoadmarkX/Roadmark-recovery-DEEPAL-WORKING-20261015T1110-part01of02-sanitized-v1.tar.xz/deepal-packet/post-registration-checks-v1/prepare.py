from pathlib import Path
import json,hashlib,re,ast
R=Path('/workspace/scratch/586427eef9f2/roadmark-104');B=Path('/tmp/deepal-packet/post-registration-checks-v1');Q=R.parent/'roadmark-104-qa/deepal-sequential-checks';T=Path('/tmp/deepal-packet/full-project-typescript-v1')
def pin(p):
 p=Path(p);h=hashlib.sha256(p.read_bytes()).hexdigest();return dict(path=str(p),bytes=p.stat().st_size,sha256=h)
def write(n,x):
 with (B/n).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
reg=json.loads(Path('/tmp/deepal-packet/registration-v1/manifest.json').read_text());app=json.loads(Path('/tmp/deepal-packet/registration-v1/application/result.json').read_text());assert app['passed']
pins={p['path']:p for p in json.loads(Path('/tmp/audi-packet/post-registration-checks-v1/source-pins.json').read_text())}
# Reuse unchanged accepted named content pins; only exact newly applied paths are replaced.
for row in reg['writes']:
 p=pin(row['target']);assert p['sha256']==row['after']['sha256'];pins[p['path']]=p
files=['brand-updates','evidence-consumers','price-ladder','fact-validity','citable','market-review-reconciliation','m1-coverage-tracking','coverage-reports','c1-order-eligibility','availability-ranking']
tests=['tests/'+n+'.test.ts' for n in files];live='tests/brand-live-safety.test.ts';inventory={}
for rel in [*tests,live]:
 p=R/rel;s=p.read_text();names=re.findall(r'\btest\("([^"\n]*)"\s*,',s)
 if rel.endswith('evidence-consumers.test.ts'):
  stages=['sourceResearch','research','catalogue','audit','registry','refresh','corrections','regrade','packet','terms'];assert 'for (const stage of '+json.dumps(stages)+')' in s
  names += ['moved consumers preserve the first '+x+' failure' for x in stages]
 if rel.endswith('c1-order-eligibility.test.ts'):
  statuses=re.search(r'for \(const status of \[([^\]]+)\]',s);assert statuses
  values=re.findall(r'"([^"]+)"',statuses.group(1));assert len(values)==3
  names += ['C1 admits sourced explicit '+x+' without changing on-sale status' for x in values]
 inventory[rel]=dict(names=names,count=len(names),source=pin(p));pins[str(p)]=pin(p)
assert sum(inventory[t]['count'] for t in tests)==143
write('test-inventory.json',inventory)
extraNamed=['scripts/report-coverage.ts','scripts/reporting/load.ts','scripts/reporting/reports.ts','scripts/validate.ts','scripts/generate-market-view.mjs','eslint.config.mjs','tests/helpers/compiled-source.ts','src/lib/price-ladder.ts','src/lib/correction-guards.ts','src/lib/fact-validity.ts']
for rel in extraNamed:pins[str(R/rel)]=pin(R/rel)
# No earlier fixture fix is overwritten by an Audi pre-TypeScript pin.
pins[str(R/'tests/evidence-consumers.test.ts')]=pin(R/'tests/evidence-consumers.test.ts')
write('source-pins.json',[pins[p] for p in sorted(pins)])
node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
base=lambda heap:[node,'--max-old-space-size='+str(heap),'--max-semi-space-size=1']
common=dict(status='frozen_not_executed_requires_review_and_root_grant',repo=str(R),qaRoot=str(Q),killAfterSeconds=10,automaticRetry=False,parallelExecutionAllowed=False,sourceMutationsAuthorized=False,sourcePins=pin(B/'source-pins.json'),rootMetadata=pin(T/'project-root-metadata.json'),testInventory=pin(B/'test-inventory.json'),wrapper=pin(B/'run.py'),environmentRemovals=['NODE_OPTIONS','NODE_PATH','NODE_COMPILE_CACHE','TS_NODE_PROJECT','TS_NODE_COMPILER_OPTIONS','TS_NODE_TRANSPILE_ONLY'],environmentOverrides={'NODE_DISABLE_COMPILE_CACHE':'1','FORCE_COLOR':'0','ESLINT_USE_FLAT_CONFIG':'true'})
lint=['src/lib/brand-updates.ts','src/lib/evidence-consumers.ts','tests/brand-updates.test.ts','scripts/reporting/load.ts']
eslint=str((R/'node_modules/eslint/bin/eslint.js').resolve())
configs=[
 dict(id='market-view',kind='market',command=base(128)+['scripts/generate-market-view.mjs','--check'],timeoutSeconds=60),
 dict(id='changed-file-lint',kind='lint',command=base(256)+[eslint,'--no-config-lookup','--config',str(R/'eslint.config.mjs'),'--no-ignore','--no-cache','--concurrency','off','--max-warnings','0','--format','json','--',*lint],timeoutSeconds=180,lintFiles=lint),
 dict(id='behavioural-suites',kind='tests',command=base(512)+['--import','tsx','--test','--test-reporter=tap','--test-concurrency=1',*tests],timeoutSeconds=600,testFiles=tests,expectedTests=143),
 dict(id='live-brand-safety',kind='tests',command=base(512)+['--import','tsx','--test','--test-reporter=tap','--test-concurrency=1',live],timeoutSeconds=600,testFiles=[live],expectedTests=7),
 dict(id='structural-validation',kind='structural',command=base(448)+['--import','tsx','scripts/validate.ts'],timeoutSeconds=900),
]
sequence=[];previous=None
for c in configs:
 m={**common,**c,'runOutput':str(Q/c['id']),'prerequisites':[] if previous is None else [previous],'extraPins':[]}
 if c['kind']=='lint':m['extraPins']=[pin(eslint)]
 write(c['id']+'.json',m);p=pin(B/(c['id']+'.json'));sequence.append(p);previous=dict(manifest=p,resultPath=str(Q/c['id']/'result.json'))
sequence.append(pin(T/'manifest.json'))
normal={**common,'id':'normal-coverage-asof-2026-10-15','kind':'normal-report','command':base(448)+['--import','tsx','scripts/report-coverage.ts','--as-of','2026-10-15','--json'],'timeoutSeconds':900,'runOutput':str(Q/'normal-coverage-asof-2026-10-15'),'prerequisites':[dict(manifest=pin(T/'manifest.json'),resultPath=str(T/'run/result.json'))],'extraPins':[]}
write(normal['id']+'.json',normal);sequence.append(pin(B/(normal['id']+'.json')))
extra=['/tmp/xpeng-staging-plan/baseline-io.mjs','/tmp/mercedes-staging-plan/consumer-preparation/v5/manifests/report-v5.json','/tmp/mercedes-staging-plan/staging-preparation/staging-artifacts/canonical-v1/staged-storage-index.json','/tmp/deepal-research/retained-before-cars.json','/tmp/deepal-packet/published-driveaway-validation-v2/result.json','/tmp/deepal-packet/full-stage-v4/output/selected-packs.json','/tmp/deepal-packet/full-stage-v4/output/selected-after-cars.json','/tmp/deepal-packet/full-stage-v4/output/global-c1-comparison.json','/tmp/deepal-packet/registration-v1/before/src/lib/brand-updates.ts','/tmp/deepal-packet/registration-v1/before/src/lib/evidence-consumers.ts','/workspace/scratch/586427eef9f2/roadmark-104-qa/audi-sequential-checks/normal-coverage-asof-2026-10-15/stdout.log']
comp={**common,'id':'report-comparison','kind':'comparison','command':base(448)+['--import','tsx',str(B/'compare-report.mjs')],'timeoutSeconds':180,'runOutput':str(Q/'report-comparison'),'prerequisites':[dict(manifest=sequence[-1],resultPath=str(Q/normal['id']/'result.json'))],'extraPins':[pin(B/'compare-report.mjs'),*[pin(p) for p in extra]],'comparisonResult':str(Q/'report-comparison-artifacts/result.json')}
write(comp['id']+'.json',comp);sequence.append(pin(B/(comp['id']+'.json')))
write('sequence.json',dict(status='frozen_not_executed_requires_review_and_root_grant',sequence=sequence,sourcePins=common['sourcePins'],rootMetadata=common['rootMetadata'],qaRoot=str(Q),applicationManifest=pin('/tmp/deepal-packet/registration-v1/manifest.json'),applicationReceipt=pin('/tmp/deepal-packet/registration-v1/application/result.json'),applicationReadback=pin('/tmp/deepal-review/REGISTRATION-READBACK-AND-CHECK-PLAN-REVIEW.json'),plan=pin('/tmp/deepal-packet/registration-v1/CHECK-PLAN.md'),noAutomaticRetry=True,oneNormalFullReport=True,extraBroadFeatureReplay=False,fullProjectTypeScriptManifest=pin(T/'manifest.json'),typeScriptUsesDedicatedWrapper=True,priorFiveGateAcceptanceRequiredBeforeTypeScript=True))
write('root-grant-template.json',dict(status='NOT_GRANTED',heavySlotExclusive=False,automaticRetry=False,parallelExecutionAllowed=False,granted=[],sequence=pin(B/'sequence.json'),reviewerAcceptance=None,registrationVerification=pin('/tmp/deepal-review/REGISTRATION-READBACK-AND-CHECK-PLAN-REVIEW.json')))
ast.parse((B/'run.py').read_text());ast.parse((B/'prepare.py').read_text())
print(json.dumps(dict(sequence=pin(B/'sequence.json'),wrapper=pin(B/'run.py'),comparator=pin(B/'compare-report.mjs'),pins=len(pins),testCount=143),indent=2))
