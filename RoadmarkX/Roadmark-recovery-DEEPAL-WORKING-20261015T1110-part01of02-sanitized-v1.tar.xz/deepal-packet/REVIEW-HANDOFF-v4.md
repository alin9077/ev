# Deepal M1 candidate, 15 October 2026

## Useful result

Three existing exact Australian BEV versions; no additions or availability-count change. The 51 core cells are proposed as 46 Confirmed, 2 Check and 3 Reported. E07 prices become explicit maker before-ORC A$64,900 RWD / A$73,900 AWD Performance. S07 A$47,990 remains a driveaway-from campaign for 20-inch wheels and non-premium paint, not the standard 19-inch configuration.

## Frozen review inputs

- Candidate: `v5/deepal-2026-10-15.json` (v1/v2/v3/v4 are superseded drafts, retained)
- Candidate receipt: `v5/assembly-receipt.json`
- Normalized claims: `/tmp/deepal-research/normalized-review-v5.json`
- Source index and capture hashes: `/tmp/deepal-research/source-index-review-v5.json`
- Combined census: `/tmp/deepal-research/normalized-census-v2.json`
- Reconciliation: `reconciliation-v2/m1-deepal-market-reconciliation-2026-10-15.json`
- Residual/global findings: `/tmp/deepal-research/residuals/REPORT.md` and `normalized_census.json`
- Recall findings: `/tmp/deepal-research/recall/recall-findings.json`
- Exact accepted baseline: `/tmp/deepal-research/retained-before-cars.json`, selected by bounded reader; `retained-before-selection-receipt.json` and `audi25-peer-parity.json`

## Decisions for independent review

1. S07 current page has 19-inch / 20-inch selections but no active custom-price-selector section, model-id input or MLP definition. Only the current 20-inch campaign price is printed. No unobserved S07 API payload/model ID was fabricated. Current maker home/model/offer/linked brochure and targeted maker-price searches did not establish a higher applicable before-ORC price. Historical launch prices remain historical. Proposed highest supported rung is 3 with explicit wheel/paint/eligibility conditions.
2. E07 public calculator requests succeeded without authentication. Exact variant IDs map to current UI names. The MLP on-road definition is explicit in the model-page modal; price JSON alone would not establish it. NSW driveaway estimates are supplemental, with displayed totals and conditions retained.
3. Strict 10–80% charging: S07 ~50 min from two Australian reviews. E07 RWD 30 min is a model-level EV Central report whose main spec panel names RWD; AWD ~20 min is from an exact Chasing Cars review. Conflicting model/sibling observations and zecar's inconsistent 21/22-minute estimates remain explicit. All are Reported and unranked. Maker 30–80% times remain separate. Review whether the RWD model-level selection is sufficiently scoped; do not turn these into manufacturer figures.
4. E07 AC time conflict found in independent review: brochure 13 h for 0–100% versus live webpage about 16 h for full charge, starting SOC unspecified. Both are Check/held; RWD summary now depends only on the clean 7 kW maximum. AWD webpage 3.9-second headline versus precise 3.96-second brochure is explicitly recorded as differing display precision, not a fabricated second test.
5. S07 range stays 475 km Check, with explicit WLTP-label/ADR81/02-footnote conflict and ranking hold. No summary depends on it or the conflicted E07 10–80% figures.
6. S05 remains an unresolved interest-only lead. Current manufacturer named-grade lists for S07/E07 can close honestly without inventing S05 Australian grades or orders. Six live New residual ads map to existing versions; sold/demo/placeholders and global/REEV leads remain separate.
7. Official E07 recall affects 218 listed 2025 vehicles, all variants within that set. Current three-anchor documents are not proof a particular earlier VIN was remedied. Confirm exact vehicle recall status before purchase. Resumption is separately Reported; no official lifting date or stop-drive restriction is inferred.
8. Unknown gross/usable capacity, cargo measurement protocol and mirror inclusion remain visible and unranked where applicable. Brand warranty is private-use scoped; no battery-retention guarantee is invented.

## Scope and security

Data-only scratch candidate. No repository edits, full catalogue load, tests, compiler, scans, compression, browser, user-computer access, upload or publication. Current catalogue remains 427 / Tier 1 350 / on sale 309 until authorised application and verification.

A publicly linked API support script contained a credential-like literal. It was never used in a request. Only a clearly redacted support copy and original-hash/redaction metadata remain. Do not re-fetch or expose the original script. Safe support: `/tmp/deepal-research/sources/api-manager-js-receipt.json`; sanitized `.html` and `.txt` files use `[REDACTED_PUBLIC_API_KEY]`. These support files are not candidate source records. Cookie/authentication headers were not captured; all price requests were unauthenticated.

Publication metadata correction in v4: official recall 10 March 2026; CarExpert resumption report 7 July 2026; DiscoverAuto S07 review 13 January 2025. Checked date remains 15 October 2026.

Provenance correction in v5: AWD acceleration fact and its summary dependency now cite both current brochure and current E07 webpage for the 3.96 / 3.9 display-precision qualification.
