from pathlib import Path
import hashlib,json
old=Path('/tmp/deepal-packet/published-driveaway-validation-v1');new=Path('/tmp/deepal-packet/published-driveaway-validation-v2');new.mkdir(exist_ok=False);repo=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
for name in ['check.mjs','expected-review.json','bounded-price-tests.ts','test-extraction.json']:
 (new/name).write_text((old/name).read_text().replace(str(old),str(new)))
pins=json.loads((old/'source-pins.json').read_text())
for i,p in enumerate(pins):
 if p['path'].startswith(str(old)+'/'):pins[i]=pin(p['path'].replace(str(old),str(new)))
for f in ['src/lib/price-ladder.ts','src/lib/correction-guards.ts','src/lib/fact-validity.ts','src/lib/freshness.ts','src/lib/config.ts','src/lib/corrections.ts','data/price-ladder-guards-2026-10-13.json','data/price-ladder-existing-candidates-2026-10-13.json','data/price-ladder-premium-candidates-2026-10-13.json']:
 assert not any(p['path']==str(repo/f) for p in pins);pins.append(pin(repo/f))
save(new/'source-pins.json',pins)
m=json.loads((old/'prepared-command.json').read_text());oldScript=m['script']['sha256'];m['script']=pin(new/'check.mjs');m['sourcePins']=pin(new/'source-pins.json');m['command']=[p.replace(str(old),str(new)) for p in m['command']]
(new/'run.py').write_text((old/'run.py').read_text().replace(oldScript,m['script']['sha256']));m['wrapper']=pin(new/'run.py');m['scope']+=' Direct price-ladder, source/review guards, offer validity and their small unchanged runtime dependencies are pinned.'
save(new/'prepared-command.json',m)
print(json.dumps(dict(manifest=pin(new/'prepared-command.json'),script=m['script'],wrapper=m['wrapper'],sourcePins=m['sourcePins'],pinCount=len(pins)),indent=2))
