from pathlib import Path
import hashlib,json,difflib
repo=Path('/workspace/scratch/586427eef9f2/roadmark-104');O=Path('/tmp/deepal-packet/published-driveaway-proposal-v1')
s=(repo/'src/lib/brand-updates.ts').read_text()
s=s.replace('["price_aud", "promotional_driveaway_aud"].includes(fact.key)', '["price_aud", "promotional_driveaway_aud", "published_driveaway_aud"].includes(fact.key)')
s=s.replace('fact.key === "promotional_driveaway_aud" &&\n      fact.comparisonBasis !== "Driveaway"', '["promotional_driveaway_aud", "published_driveaway_aud"].includes(fact.key) &&\n      fact.comparisonBasis !== "Driveaway"')
needle='    const price = fact.priceEvidence;\n'
assert s.count(needle)==1
s=s.replace(needle,'    if (fact.key === "published_driveaway_aud" && fact.unit !== "AUD")\n      fail("published driveaway price must use AUD");\n'+needle)
needle='/** Canonical reviewed facts also feed their equipment/question rows. */'
helper='''/** Ordinary published driveaway totals are not promotional offers. Source context
 * is required for this fallback so a withdrawn source/review cannot keep it active.
 * Packet admission applies the same full fact/source and price-ladder guards as
 * price_aud and promotional_driveaway_aud; this repeats those price guards at use.
 */
function publishedDriveawayFact(car: Car, sources: Source[]): Fact | undefined {
  const fact = car.facts.published_driveaway_aud;
  const price = fact?.priceEvidence;
  const asOf = fact?.gradeReview?.reviewedAt ?? "";
  if (
    !fact || fact.key !== "published_driveaway_aud" ||
    fact.unit !== "AUD" || fact.comparisonBasis !== "Driveaway" ||
    !["AU", "Australia"].includes(fact.market) ||
    fact.status !== (fact.buyerGrade === "confirmed" ? "standard" : "conditional") ||
    typeof fact.value !== "number" || !price ||
    !text(price.basisTag) || !text(price.originalBasis) ||
    typeof price.rankingEligible !== "boolean" ||
    (price.rung === 5 && !text(price.publisher)) ||
    price.rung === 1 ||
    (price.rung >= 5 && fact.buyerGrade !== "reported") ||
    !fact.gradeReview ||
    !sameReviewedState(fact.sourceIds, fact.gradeReview.sourceIds) ||
    !hasEarnedBuyerGrade(fact, sources, asOf) ||
    !usableCorrectionSources(fact.sourceIds, sources, asOf) ||
    priceCandidateRejection({
      variantId: car.id,
      value: fact.value,
      sourceIds: fact.sourceIds,
      date: fact.date,
      ...price,
      comparisonBasis: "Driveaway",
      qualifications: fact.qualifications,
      validUntil: fact.validUntil,
    }, car.id, sources, asOf)
  ) return undefined;
  return fact;
}

'''
assert needle in s;s=s.replace(needle,helper+needle)
s=s.replace('export function applyBrandTermFeatures(\n  car: Car,\n  features: Feature[],\n): Feature[] {','export function applyBrandTermFeatures(\n  car: Car,\n  features: Feature[],\n  sources: Source[] = [],\n): Feature[] {')
needle='  const reviewedRoadside =\n';assert s.count(needle)==1
# Preserve the established main/promotional eligibility and order exactly.
start=s.index('  const price = [car.facts.price_aud, car.facts.promotional_driveaway_aud].find(')
end=s.index(needle,start)
block=s[start:end];assert block.endswith('  );\n');block=block[:-5]+'  ) ?? publishedDriveawayFact(car, sources);\n'
s=s[:start]+block+s[end:]
s=s.replace('// Its separately reviewed driveaway offer still owns the driveaway answer.','// Its separately reviewed driveaway offer still owns the driveaway answer.\n  // An ordinary published estimate is only the third fallback, never a promotion.')
old='''        feature.criterion === "roadside_assistance" &&
        feature.verification_state === "reviewed_brand_au_terms"
'''
new='''        (feature.criterion === "roadside_assistance" &&
          feature.verification_state === "reviewed_brand_au_terms") ||
        (feature.criterion === "driveaway_price" &&
          ["reviewed_canonical_driveaway_price", "reviewed_published_driveaway_price"].includes(
            feature.verification_state,
          ))
'''
assert old in s;s=s.replace(old,new)
s=s.replace('''      verification_state: isPrice
        ? "reviewed_canonical_driveaway_price"
        : "reviewed_brand_au_terms",''','''      verification_state: isPrice
        ? fact.key === "published_driveaway_aud"
          ? "reviewed_published_driveaway_price"
          : "reviewed_canonical_driveaway_price"
        : "reviewed_brand_au_terms",''')
(O/'src/lib/brand-updates.ts').write_text(s)
s=(repo/'src/lib/evidence-consumers.ts').read_text();needle='''      : regraded,
  );''';assert s.count(needle)==1;s=s.replace(needle,'''      : regraded,
    d.sources,
  );''');(O/'src/lib/evidence-consumers.ts').write_text(s)
# Proposed test additions use the existing synthetic fixture; no catalogue imports.
(O/'tests/brand-updates.test.ts').write_text((repo/'tests/brand-updates.test.ts').read_text()+Path('/tmp/deepal-packet/published-driveaway-tests-addition.ts').read_text())
files=['src/lib/brand-updates.ts','src/lib/evidence-consumers.ts','tests/brand-updates.test.ts'];patch=''
for f in files:patch+=''.join(difflib.unified_diff((repo/f).read_text().splitlines(True),(O/f).read_text().splitlines(True),fromfile='a/'+f,tofile='b/'+f))
(O/'proposal.patch').write_text(patch)
manifest=dict(status='proposal_only_not_executed_or_applied',productionEdits=False,testsRun=False,compilerRun=False,files=[dict(path=f,baseSha256=hashlib.sha256((repo/f).read_bytes()).hexdigest(),proposalSha256=hashlib.sha256((O/f).read_bytes()).hexdigest()) for f in files],patchSha256=hashlib.sha256((O/'proposal.patch').read_bytes()).hexdigest())
(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
