# Ordinary published driveaway projection proposal

Prepared under /tmp only. No source edit, compiler, test or runtime has been executed for this proposal. The accepted v5 candidate and diagnostic remain unchanged.

## Confirmed gap

The actual v5 E07 driveaway question outputs are “Needs confirmation”, checked 10 October, no citations, and “not yet researched”, despite current NSW 2000 estimates in supplemental facts. Main before-ORC prices are already correct. The diagnostic lives at `/tmp/deepal-packet/selected-preflight-v2/driveaway-answer-diagnostic.json`.

## Narrow contract

- Add the semantically explicit canonical fact `published_driveaway_aud` for ordinary published driveaway totals/estimates, independent of promotional offers
- Packet admission routes this fact through existing earned-grade, exact-source, price-ladder, positive-price, provenance, explicit-basis and state guards. AUD and Driveaway are required
- Preserve the existing main-price then promotional-offer selector and precedence. Only when neither is eligible may the ordinary fact supply the question answer
- Ordinary projection additionally requires the effective source collection and repeats existing ladder/source/review checks. The real consumer supplies its current sources. Old two-argument calls retain previous main/promotional behavior but cannot project the new ordinary fact
- Project exact amount, state/estimate basis, sources, checked date and qualifications. No offer deadline is fabricated
- A reused canonical or ordinary driveaway projection loses its earned grade when no valid price fact remains. Its history stays visible. Independent source-row fallbacks and unrelated feature rows remain unchanged
- Keep the manual driveaway feature-override ban intact
- Do not alter main `price_aud`, price selection/ranking, unrelated equipment, whole-market data or availability

## Candidate

`/tmp/deepal-packet/v6/deepal-2026-10-15.json`, SHA cef6b8712653ad1d504c65945d0790ec631f6748474e71ab6cada9ee859e4848

Only the two ordinary NSW supplemental after-facts change: field name, label, full rung-4/state provenance and explicit non-promotional/no-expiry qualification. Their null before-guards are unchanged. Existing main before-ORC facts, all 51 core-cell values/grades, summaries, terms, availability and other after-facts are identical. Exact delta is `v6/v5-to-v6-fact-delta.json`. Reconciliation v2 remains unchanged.

## Proposed files and tests

- `src/lib/brand-updates.ts`: admission and ordinary fallback, with reused-driveaway review withdrawal
- `src/lib/evidence-consumers.ts`: pass the current source collection to the canonical projection helper
- `tests/brand-updates.test.ts`: five new synthetic-fixture tests covering successful amount/state/source/date projection, no invented deadline, main/promotional/published precedence, invalid ladder provenance/state/units/basis, source/review withdrawal, no before-ORC projection, retained independent fallback, untouched unrelated features and source-linked portable/citable parity

The exact patch and baseline/proposal hashes are in `proposal.patch` and `manifest.json`. Reviewer acceptance of field, packet and helper semantics is required before any runtime grant. Later actual selected validation must use the proposed helper/consumer pair and revised v6 candidate together, while keeping default catalogue loaders forbidden.

V2 changes tests only: explicit duplicate fact source IDs, source-conflict withdrawal, and a withdrawn citable claim stating Review required. Production proposal files are byte-identical to v1. Candidate v6 remains immutable and unchanged. No checks executed.
