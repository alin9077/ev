from pathlib import Path
import hashlib,json,difflib
R=Path('/workspace/scratch/586427eef9f2/roadmark-104')
B=Path('/tmp/deepal-packet/registration-v1')
P=Path('/tmp/deepal-packet/published-driveaway-proposal-v2')
def sha(b): return hashlib.sha256(b).hexdigest()
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def save(p,b):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
changed={p:(P/p).read_bytes() for p in ['src/lib/brand-updates.ts','src/lib/evidence-consumers.ts','tests/brand-updates.test.ts']}
r='data/m1-brand-updates/registry.json'; old=(R/r).read_text(); registry=json.loads(old)
assert len(registry['packets'])==25 and registry['packets'][-1]=='audi-2026-10-15.json'
needle='    "audi-2026-10-15.json"\n'; assert old.count(needle)==1
changed[r]=old.replace(needle,'    "audi-2026-10-15.json",\n    "deepal-2026-10-15.json"\n').encode()
r='scripts/reporting/load.ts'; old=(R/r).read_text()
needle='import audiReconciliation from "../../data/m1-audi-market-reconciliation-2026-10-15.json";\n';assert old.count(needle)==1
new=old.replace(needle,needle+'import deepalReconciliation from "../../data/m1-deepal-market-reconciliation-2026-10-15.json";\n')
needle='      audiReconciliation as M1MarketReconciliation,\n';assert new.count(needle)==1
changed[r]=new.replace(needle,needle+'      deepalReconciliation as M1MarketReconciliation,\n').encode()
newfiles={
'data/m1-brand-updates/deepal-2026-10-15.json':Path('/tmp/deepal-packet/v6/deepal-2026-10-15.json'),
'data/m1-deepal-market-reconciliation-2026-10-15.json':Path('/tmp/deepal-packet/reconciliation-v2/m1-deepal-market-reconciliation-2026-10-15.json')}
rows=[];patch=[]
for rel,content in [*changed.items(),*((r,p.read_bytes()) for r,p in newfiles.items())]:
 target=R/rel;before=target.read_bytes() if target.exists() else None
 assert (before is None)==(rel in newfiles)
 if before is not None:save(B/'before'/rel,before)
 save(B/'after'/rel,content)
 rows.append(dict(relativePath=rel,target=str(target),operation='create' if before is None else 'replace',before=None if before is None else dict(bytes=len(before),sha256=sha(before)),after=pin(B/'after'/rel),beforeCopy=None if before is None else pin(B/'before'/rel)))
 patch.extend(difflib.unified_diff((before or b'').decode().splitlines(True),content.decode().splitlines(True),fromfile='/dev/null' if before is None else 'a/'+rel,tofile='b/'+rel))
save(B/'registration.patch',''.join(patch).encode())
proofs=[
'/tmp/deepal-packet/full-stage-v4/manifest.json',
'/tmp/deepal-packet/full-stage-v4/output/stage-receipt.json',
'/tmp/deepal-packet/full-stage-v4/run/terminal.json',
'/tmp/deepal-review/FULL-STAGE-V4-RESULT-REVIEW.json',
'/tmp/deepal-packet/published-driveaway-validation-v2/result.json',
'/tmp/deepal-review/PUBLISHED-DRIVEAWAY-VALIDATION-RESULT-REVIEW.json',
'/tmp/deepal-packet/published-driveaway-proposal-v2/proposal.patch',
'/tmp/deepal-packet/v6/deepal-2026-10-15.json',
'/tmp/deepal-packet/reconciliation-v2/m1-deepal-market-reconciliation-2026-10-15.json']
manifest=dict(schemaVersion=1,status='frozen_preparation_only_requires_bundle_review_and_root_application_grant',repo=str(R),writes=rows,proofs=[pin(p) for p in proofs],patch=pin(B/'registration.patch'),applicator=pin(B/'apply.py'),expected=dict(catalogue=427,tierOne=350,onSale=309,packets=26,changedCars=3,unchangedPeers=424,newModels=0,newVersions=0,manualFeatureUpdates=0),scope=dict(existingFiles=5,newFiles=2,helperSemantics='Exact accepted published-driveaway proposal v2',packet='Exact accepted v6',reconciliation='Exact accepted reconciliation-v2',registry='Append only, preserve first 25 ordered entries',reportLoader='One import and one last combineM1Reconciliations argument',reportImplementationChanged=False,heroChanged=False,immutableSnapshotChanged=False,sourceCapturesAddedToRepository=False),automaticRetry=False,rootGrantRequired=True,heavyChecksAllowed=False,rollback='No automatic rollback or deletion; retain journal and exact before copies for separately authorised recovery')
save(B/'manifest.json',(json.dumps(manifest,indent=2)+'\n').encode())
save(B/'root-grant-template.json',(json.dumps(dict(status='NOT_GRANTED',action='apply_exact_deepal_registration',manifest=pin(B/'manifest.json'),reviewerAcceptance=None,allowedTargets=[x['target'] for x in rows],automaticRetry=False,heavyExecutionAuthorized=False),indent=2)+'\n').encode())
print(json.dumps(dict(manifest=pin(B/'manifest.json'),patch=pin(B/'registration.patch'),targets=[dict(path=x['relativePath'],before=x['before'],after=x['after']['sha256']) for x in rows]),indent=2))
