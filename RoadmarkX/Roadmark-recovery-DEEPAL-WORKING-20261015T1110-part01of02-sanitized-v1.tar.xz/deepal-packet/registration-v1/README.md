# Deepal26 minimal guarded registration

Preparation only. Source application is not authorised by this bundle. The independently accepted full-stage v4 passed; a separate bundle review and exact root application grant are still required. Backup currently owns the heavy slot.

## Seven exact targets

Five replacements: src/lib/brand-updates.ts, src/lib/evidence-consumers.ts, tests/brand-updates.test.ts, data/m1-brand-updates/registry.json, scripts/reporting/load.ts. Two new files: data/m1-brand-updates/deepal-2026-10-15.json and data/m1-deepal-market-reconciliation-2026-10-15.json.

The first three are byte-identical to the independently accepted ordinary-driveaway proposal v2. The packet is accepted v6, and reconciliation is accepted reconciliation-v2. Registry changes only append Deepal as packet 26. The loader changes only add its import and final combineM1Reconciliations argument. Reports.ts, data/catalogue/research loaders, Model Y hero, original research, history, all prior packets, rendering and generated market view are untouched.

All exact before and after hashes, file sizes, absent-target guards and supporting accepted receipts are in manifest.json. Before copies are retained. registration.patch is explanatory; apply.py writes the frozen after bytes rather than applying a fuzzy patch. It validates every guard before any source write, checks each result, records progress, and never retries, rolls back, deletes or invokes project code. A partial-write failure is retained and needs separately authorised recovery.

## Intended application command, still blocked on review and root grant

python -I /tmp/deepal-packet/registration-v1/apply.py /tmp/deepal-packet/registration-v1/manifest.json a50e418f43a2c1ad9c03d044b0761c575226eaf5db47b58ed7ed8f5f3dddc0c5 ROOT_GRANT_PATH ROOT_GRANT_SHA256

Use a separately persisted root grant based on root-grant-template.json, with the exact reviewer-acceptance pin and all seven targets. No grant is present now. Python isolated mode prevents environment optimisation from removing assertions. Application receipt output is registration-v1/application; the directory must not already exist.

## Fixed expectations

427 catalogue versions, 350 Tier 1, 309 on sale; 26 dated packets. No new models, versions, identities, model years, configuration rows or manual feature edits. Exactly three Deepal cars change; 424 peer cars remain identical. Ordinary estimates preserve NSW 2000 qualifications and before-ORC primaries. S07's 20-inch campaign condition, held range-method conflict, E07 AC-time conflict and exact-vehicle recall caution remain visible. S05 remains unresolved.

Application is not a normal-report, TypeScript, build, visual or release pass. CHECK-PLAN.md describes separately scheduled gates. Each runnable check still needs frozen pins, review and an exclusive slot grant. Earlier selected/full-stage failures remain retained.
