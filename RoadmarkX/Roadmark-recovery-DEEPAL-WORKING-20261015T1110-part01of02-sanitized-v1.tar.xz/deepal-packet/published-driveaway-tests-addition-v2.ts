
function publishedDriveawayFixture() {
  const data = reviewedDriveawayFixture("NSW");
  const published: Fact = {
    ...structuredClone(data.price),
    key: "published_driveaway_aud",
    label: "Published driveaway estimate",
    value: 43990,
    basis: "Maker driveaway estimate · NSW 2000",
    qualifications: ["NSW 2000; standard paint and interior; private purchaser.", "Estimated total; confirm the final retailer price."],
    conditionExplanation: "Postcode-specific estimate, not a promotional offer or accepted order.",
    priceEvidence: {
      ...data.price.priceEvidence!,
      sourceKey: "published_driveaway_aud",
      basisTag: "Maker driveaway estimate · NSW",
      originalBasis: "Published driveaway estimate for NSW 2000",
    },
  };
  delete published.validUntil;
  data.car.facts.price_aud = {
    ...structuredClone(data.price), value: 35990,
    comparisonBasis: "Before on-road costs", basis: "Maker list price before on-road costs",
    buyerGrade: "confirmed", status: "standard", qualifications: [],
    priceEvidence: { ...data.price.priceEvidence!, rung: 1, basisTag: "Before on-road costs", originalBasis: "Maker list price before on-road costs" },
  };
  delete data.car.facts.price_aud.validUntil;
  return { ...data, published };
}

test("ordinary published driveaway estimates retain the list-price primary and exact state/source qualifications", () => {
  const { car, source, research, packet, published, feature } = publishedDriveawayFixture();
  packet.facts = [{ variantId: car.id, before: null, after: published }];
  const before = structuredClone({ car, source, research, packet, feature });
  const prepared = prepareBrandResearch(research, [packet]);
  const updated = applyBrandUpdates([car], prepared, [packet])[0];
  const unrelated: Feature = { ...feature, criterion: "unrelated_fixture" };
  const features = applyBrandTermFeatures(updated, [feature, unrelated], prepared.sources);
  const projected = features[0];
  assert.equal(updated.facts.price_aud.value, 35990);
  assert.equal(updated.facts.price_aud.comparisonBasis, "Before on-road costs");
  assert.equal(projected.value, "A$43,990");
  assert.equal(projected.verification_state, "reviewed_published_driveaway_price");
  assert.equal(projected.buyerGrade, "check");
  assert.deepEqual(projected.source_ids, published.sourceIds);
  assert.deepEqual(projected.gradeReview, published.gradeReview);
  assert.equal(projected.last_evidence_date, published.date);
  assert.equal(projected.reviewed_date, published.gradeReview!.reviewedAt);
  assert.match(projected.condition_label!, /estimate.*NSW/i);
  assert.match(projected.conditions, /NSW 2000/);
  assert.match(projected.conditions, /not a promotional offer/);
  assert.match(projected.conditions, /applies in NSW/);
  assert.doesNotMatch(projected.conditions, /Offer deadline|Superseded/);
  assert.equal(Object.hasOwn(projected, "validUntil"), false);
  assert.equal(Object.hasOwn(projected, "gradeReviewStatus"), false);
  assert.equal(features[1], unrelated);
  const pack: Pack = { car: updated, features, sources: prepared.sources, eligibility: research.update_eligibility[0], events: [], configuration: [] };
  const claim = featureClaim(pack, "driveaway_price", "Driveaway price", packet.reviewedAt)!;
  assert.equal(claim.value, "A$43,990");
  assert.equal(claim.evidenceDate, published.date);
  assert.equal(claim.buyerGrade, "check");
  assert.equal(claim.sources[0].url, source.url);
  assert.match(claim.basis, /estimate.*NSW/i);
  assert.match(claim.qualifications.join(" "), /NSW 2000/);
  const stored = storePortablePacks({ [car.id]: pack });
  assert.deepEqual(hydratePortablePacks(stored, prepared.sources), { [car.id]: pack });
  const written = JSON.parse(JSON.stringify(stored));
  const hydrated = hydratePortablePacks(written, prepared.sources);
  assert.deepEqual(hydrated, { [car.id]: pack });
  assert.deepEqual(featureClaim(hydrated[car.id], "driveaway_price", "Driveaway price", packet.reviewedAt), claim);
  assert.deepEqual({ car, source, research, packet, feature }, before);
});

test("ordinary driveaway fallback preserves main then promotional precedence", () => {
  const { car, source, price, feature, published } = publishedDriveawayFixture();
  car.facts.published_driveaway_aud = published;
  car.facts.promotional_driveaway_aud = { ...price, key: "promotional_driveaway_aud", value: 40990 };
  const list = car.facts.price_aud;
  car.facts.price_aud = { ...price, value: 41990 };
  assert.equal(applyBrandTermFeatures(car, [feature], [source])[0].value, "A$41,990");
  car.facts.price_aud = list;
  assert.equal(applyBrandTermFeatures(car, [feature], [source])[0].value, "A$40,990");
  delete car.facts.promotional_driveaway_aud;
  assert.equal(applyBrandTermFeatures(car, [feature], [source])[0].value, "A$43,990");
  delete car.facts.published_driveaway_aud;
  assert.equal(applyBrandTermFeatures(car, [feature], [source])[0], feature);
});

test("ordinary driveaway packet admission rejects invalid ladder provenance, units, state and basis", () => {
  const { car, research, packet, published } = publishedDriveawayFixture();
  const invalid: Fact[] = [
    { ...published, priceEvidence: undefined },
    { ...published, priceEvidence: { ...published.priceEvidence!, sourcePointer: "" } },
    { ...published, priceEvidence: { ...published.priceEvidence!, sourceKey: "" } },
    { ...published, priceEvidence: { ...published.priceEvidence!, state: "Australia" } },
    { ...published, priceEvidence: { ...published.priceEvidence!, originalBasis: "Before on-road costs" } },
    { ...published, priceEvidence: { ...published.priceEvidence!, rung: 1 } },
    { ...published, comparisonBasis: "Before on-road costs" },
    { ...published, comparisonBasis: "" },
    { ...published, unit: "USD" },
    { ...published, value: -1 },
    { ...published, sourceIds: [] },
    { ...published, sourceIds: [published.sourceIds[0], published.sourceIds[0]] },
  ];
  for (const after of invalid) assert.throws(() => applyBrandUpdates([car], research, [{ ...packet, facts: [{ variantId: car.id, before: null, after }] }]), /price|driveaway|source|grade|fact|state|provenance/i);
});

test("ordinary driveaway projection requires current earned provenance and never projects a before-ORC value", () => {
  const { car, source, feature, published } = publishedDriveawayFixture();
  for (const candidate of [
    { ...published, comparisonBasis: "Before on-road costs" },
    { ...published, market: "NZ" },
    { ...published, status: "not_verified" as const },
    { ...published, gradeReviewStatus: "review_required" as const },
    { ...published, buyerGrade: undefined },
    { ...published, gradeReview: undefined },
    { ...published, priceEvidence: undefined },
    { ...published, priceEvidence: { ...published.priceEvidence!, sourcePointer: "" } },
    { ...published, priceEvidence: { ...published.priceEvidence!, state: "XX" } },
    { ...published, value: null },
    { ...published, sourceIds: [published.sourceIds[0], published.sourceIds[0]] },
  ]) {
    const changed = { ...car, facts: { ...car.facts, published_driveaway_aud: candidate } };
    assert.equal(applyBrandTermFeatures(changed, [feature], [source])[0], feature);
  }
  const current = { ...car, facts: { ...car.facts, published_driveaway_aud: published } };
  assert.equal(applyBrandTermFeatures(current, [feature])[0], feature, "new ordinary fallback requires source context");
  for (const sources of [[], [{ ...source, access_limitation: "Source withdrawn" }], [{ ...source, publication_hold: "Hold" }], [{ ...source, conflict: "Conflicting current source" }], [{ ...source, market: "NZ" }], [{ ...source, accessed_date: "2027-01-01" }]]) {
    assert.equal(applyBrandTermFeatures(current, [feature], sources)[0], feature);
  }
});

test("withdrawn reused driveaway projections lose their earned grade without damaging independent fallbacks", () => {
  const { car, source, feature, published } = publishedDriveawayFixture();
  const current = { ...car, facts: { ...car.facts, published_driveaway_aud: published } };
  const projected = applyBrandTermFeatures(current, [feature], [source])[0];
  const unrelated = { ...feature, criterion: "unrelated_fixture" };
  for (const [candidate, sources] of [
    [car, [source]],
    [{ ...current, facts: { ...current.facts, published_driveaway_aud: { ...published, value: null } } }, [source]],
    [{ ...current, facts: { ...current.facts, published_driveaway_aud: { ...published, gradeReviewStatus: "review_required" } } }, [source]],
    [{ ...current, facts: { ...current.facts, published_driveaway_aud: { ...published, comparisonBasis: "Before on-road costs" } } }, [source]],
    [current, []],
  ] as [Car, Source[]][]) {
    const before = structuredClone({ candidate, sources, projected, unrelated });
    for (const state of ["reviewed_published_driveaway_price", "reviewed_canonical_driveaway_price"]) {
      const reused = { ...projected, verification_state: state };
      const result = applyBrandTermFeatures(candidate, [reused, unrelated], sources);
      assert.equal(result[0].value, projected.value);
      assert.deepEqual(result[0].source_ids, projected.source_ids);
      assert.equal(result[0].buyerGrade, undefined);
      assert.equal(result[0].gradeReview, undefined);
      assert.equal(result[0].gradeReviewStatus, "review_required");
      assert.equal(hasEarnedBuyerGrade(result[0], sources, "2026-10-14"), false);
      assert.equal(result[1], unrelated);
      const pack: Pack = { car: candidate, features: result, sources, eligibility: { variant_id: candidate.id } as Pack["eligibility"], events: [], configuration: [] };
      const claim = featureClaim(pack, "driveaway_price", "Driveaway price", "2026-10-14")!;
      assert.equal(claim.gradeReviewStatus, "review_required");
      assert.equal(claim.buyerGrade, undefined);
      assert.match(claim.sentence, /review required/i);
    }
    assert.equal(applyBrandTermFeatures(candidate, [feature], sources)[0], feature);
    assert.deepEqual({ candidate, sources, projected, unrelated }, before);
  }
});
