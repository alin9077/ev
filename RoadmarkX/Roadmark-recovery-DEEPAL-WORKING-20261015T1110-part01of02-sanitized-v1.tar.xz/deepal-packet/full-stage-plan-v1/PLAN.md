# Deepal26 bounded full-stage plan

Status: preparation only. No stage process, broad feature replay, registration, source edit, server, browser check, compiler or archive action is authorised by this plan. The selected actual-function result is independently accepted. A frozen runnable command and a separate root resource-slot grant are still required.

## Fixed result expectations

- Accepted Audi25: 427 catalogue versions, 350 Tier 1, 309 on sale, 25 packets
- Proposed Deepal26: exactly the same 427 / 350 / 309, 26 packets
- No new models or versions; no identity, model-year, configuration or manual feature updates
- Exactly 3 existing Deepal cars may change; all 424 peer complete-car digests and identities must be identical
- Exactly 64 specific fact updates plus 6 inherited term cells; 51 core cells: 46 Confirmed, 2 Check, 3 Reported
- All 207 selected effective feature claims checked; no unrelated selected feature changes. S07 retains its conditional 20-inch campaign answer. Two E07 ordinary NSW estimates project through the new canonical field, with primary before-ORC prices unchanged
- Two supported current model lists, three named grades; S05 remains an unresolved interest-only lead. No global C1 completion claim

## A. Restore and prove the accepted current baseline once

Use the retained409 storage index and accepted prefix20 manifest, with existing bounded storage readers. Restore the full staging snapshot once for composition, never to discover/select Deepal IDs. Selection is the already accepted explicit three-ID set. Reproduce only EQA21, Leapmotor22, Mazda23, Skoda24 and Audi25 in sequence. At every transition compare every complete-car digest and all 14 research-field digests to the accepted Audi full-stage artifact. Do not replay packets 1–20, recapture canonical storage, or write a whole-catalogue cache.

Use original registered helper semantics for baseline reproduction. Read the frozen /tmp proposed helper only for Deepal26 and the targeted parity comparison. Validate exactly 25 registered packet IDs before staging. Enforce original Model Y hero, source history and immutable snapshot preservation through the unchanged peer digests and current source pins.

## B. Generic helper neutrality, without broad feature replay

During the already restored baseline pass, inspect all 424 peer cars for own-property presence of published_driveaway_aud, retaining compact witnesses bound to the accepted full-car hashes. Presence alone is potentially affected, even if null or apparently ineligible; do not infer away a case.

Inspect all current raw driveaway rows and the pinned upstream feature overlays for reviewed_canonical_driveaway_price or reviewed_published_driveaway_price markers. Include current generated raw rows from the accepted overlay chain. Retain exact compact witnesses and their owner IDs/source paths. A marker with unresolved ownership is a blocker. Verify no upstream source-effective/regrading producer introduces either marker and the manual driveaway override ban is unchanged. Check preceding packet feature edits cannot target driveaway_price.

All existing source rows must remain byte-for-byte equal and the 23 new Deepal source IDs must be absent from peer fact/raw-feature/publication-issue references. This guards against source additions reviving a peer review independently of the helper change.

Only the union of peer IDs with the new ordinary field or a reused marker receives an actual targeted driveaway check. Use the real exported effectiveFeaturesFromRows with that car's single raw driveaway row and original historical configuration context, then actual applyFeatureRegrading and the original/proposed applyBrandTermFeatures. The packet driveaway override ban establishes that intervening manual feature updates cannot alter this criterion. Compare exact output objects and citable source/date/condition claims. Prove original/proposed source-row transformation is identical. Do not invoke a peer's full 69-feature pack or replay unrelated criteria. If an affected peer differs, stop; do not silently accept the difference or change the field.

The two changed code files must remain precisely the reviewed proposal; main/promotional selection and all unrelated criteria remain unchanged. A zero potential-peer set is a legitimate proved result, not a skipped broad test.

## C. Apply Deepal26 under exact guards and replay selected consumers

Validate exact version/fact/term/availability guards; compose metadata packet IDs without changing other metadata; apply only candidate v6. Check the three staged cars equal the independently accepted selected output. No additions: models, variants, raw feature rows, equipment rows, update eligibility and historical configuration contexts retain their counts and contents except the explicit variant metadata/fact-derived changes allowed by prepareBrandResearch. Existing source rows remain unchanged; only 23 reviewed sources are appended.

Call the actual proposed consumer for the three staged cars, with default loaders forbidden. Reproduce all 70 earned cells, 207 complete feature claims, clean summary dependencies, held ranking conflicts, exact availability and source closure. Compare exact selected packs and written portable reconstruction to the accepted validation. Every optional undefined path must match its actual selected witness and producer; the accepted 16-before/16-after observations are evidence, not a blanket normalisation allowance.

Build actual current-list reconciliation with the accepted global reconciliation inputs plus Deepal. Verify exact SUV model/body/trim identities, the two settled Deepal records and unresolved S05 lead. No full report loader is called here. The stage outputs are structural/selected proofs and digests, not a fresh normal full coverage report.

## D. Separate guarded integration and fresh normal report gate

After independent stage review and separate root authority, the minimal integration set is the reviewed helper/consumer/test changes, Deepal packet, packet registration, reconciliation file and reconciliation-loader registration. Preserve the manual driveaway edit ban. No unrelated source changes.

A separate reviewed execution slot then runs one actual normal full coverage report through the production loader at 2026-10-15. Its inherent all-car effectiveFeatures work is explicitly part of this normal report gate, not duplicated in staging. Do not substitute a derived report or label selected results as normal coverage.

Compare the full normal JSON/text output with the accepted Audi25 baseline. Require exact equality for every non-Deepal brandProgress object, non-Deepal reconciliation issue/review/disposition, peer-ranked membership/order/exclusion detail, peer gap/summary-gap/ageing entries, unmatched inventory and leads outside Deepal. Permit only explicitly audited Deepal rows and the consequent recomputed global aggregates. Record an exhaustive path-level diff; each changed aggregate must be accounted for by actual selected Deepal contributions and the two current-list resolutions. Reject any unexplained peer/global difference. Confirm 427 / 350 / 309 and no additions again.

Other scoped tests, full-project TypeScript, documentation, backups and any current-source visual QA remain separately scheduled gates. Do not start a dev server during staging or backup work; the October 14 build is not current-source QA.

## Proposed stage envelope and artifacts

One process, Node old-space 448 MiB, semi-space 1 MiB, explicit GC allowed, timeout 420 seconds plus 10-second termination grace, wait4 terminal receipt, no automatic retry. Exact command/manifest pins will be reviewed before a grant. No other heavy work overlaps.

Output only: transition/digest receipts, three selected cars/packs/portable claims, peer field/marker inventory, targeted peer driveaway parity receipts, current-list reconciliation proof, selected ranking/optional-property proofs, and final immutable-input receipt. Expected under 10 MiB; no full-catalogue or all-feature materialisation on disk. A missing input, mismatched pin, peer difference, unreviewed property path or resource failure stops the run and retains evidence.
