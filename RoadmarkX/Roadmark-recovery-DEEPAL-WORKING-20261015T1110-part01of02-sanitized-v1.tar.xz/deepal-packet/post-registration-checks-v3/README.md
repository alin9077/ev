# Deepal continuation v3 — prepared, not executed

The original 143-test aggregate remains a failed historical result: 142 passed and one stale VW charging fixture failed. Its output is retained untouched under deepal-sequential-checks. The independently approved one-file correction preserves the historical caution/nonmutation test using the exact packet11 beforeguard and adds explicit current 26-minute, source/date/basis/claim assertions. No VW or Deepal production data changed for this correction.

## Order and preserved passes

The original market-view and four-file lint passes remain pinned retained gates. A separately reviewed focused sequence must first pass one-file lint and all 14 citable tests. This continuation then runs exactly:

1. A fresh aggregate of the same ten behavioral test files, now 144 tests (512 MiB old-space, 1 MiB semi-space, 600 seconds plus 10-second kill period)
2. Seven live-brand safety tests (512/1 MiB, 600+10 seconds)
3. Structural validation (448/1 MiB, 900+10 seconds)
4. The dedicated fresh full-project TypeScript v2 check (768/1 MiB, 900+10 seconds, its own reviewed wrapper and exact prerequisite-acceptance contract)
5. One actual normal production coverage report, as of 2026-10-15 (448/1 MiB, 900+10 seconds)
6. The exhaustive saved-report comparison (448/1 MiB, 180+10 seconds)

Every command needs its exact root grant and exclusive heavy slot. Stop on failure. No automatic retry, parallel command, broad all-tests suite, build, server, source edit or generated-type refresh is authorized. Each output directory is new and create-only. The generic wrapper remains byte-identical to the accepted v2 wrapper and records wait4 resources, terminal status, output hashes, source-pin/root-metadata checks and scope verification per process. V8 heap flags are not OS RSS caps. TypeScript keeps the original project configuration and uses only a fresh /tmp tsbuildinfo destination.

## Exact preparation deltas

The source list contains 137 pins: the former 136, with the applied citable hash refreshed and src/lib/data.ts added as a direct content pin for the normal loader. Root metadata now points to independently reviewed TypeScript v2: all 361 root names stay fixed and only the accepted citable stat record changed from v1. Test inventory has one additional explicit current-fact test. All seven production registration after-hashes remain fixed.

The comparator has only two types of edits from its retained v2: output/preparation paths point to this fresh continuation, and the known C1 representation boundary uses an exact producer-bound reconstruction. It writes and reads the selected-before report and compares its full written Deepal brand object to the accepted written Audi object. For live equality, the actual buildMarketReconciliation producer must yield exactly one independent_lists issue, with exactly the expected keys and own enumerable undefined brand/reference descriptors. Its written issue must equal the accepted issue. Only that unique issue is replaced in a clone of the accepted object before complete live deep equality. No blanket normalization or optional-property allowance is added. The patch is retained as comparator-v2-to-v3.patch.

All other comparison assertions are unchanged. They preserve exact unrelated brand/peer output, peer ranking relative order after filtering Deepal, unchanged exclusions, selected contribution math, whole written global C1 parity, freshness accounting, and full expected-versus-actual report equality. The actual normal report uses the unchanged production entrypoint/load path and performs its normal effective-feature work once. The comparator uses three selected cars and only their actual old driveaway producers; it does not perform a second broad feature replay or substitute a derived report for the actual normal report.

## Fail-closed boundaries

Counts must remain 427 catalogue versions, 350 Tier 1 and 309 on sale. Structural counts additionally remain 170 families, 193 generations, 69 criteria, 29,463 evidence rows, 348 current, 43 outgoing and 36 provisional; 3,707 source references and 15 publication issues. No models or versions are added.

The known selected-old freshness contribution is computed through actual selected functions, never inferred from the global due count. If the complete report does not match that exact contribution, it fails. The core explanation adjustment uses actual selected old/new reason counts while retaining the accepted report's visible reason ordering. If an unseen reason, tie or truncated tail changes the true result, exact whole-report equality fails; additional narrowly scoped inspection and approval are then required. No explanation/freshness waiver is permitted.

Original v1/v2 preparations, v2 behavioral failure, staging failures and all reviews remain retained. Preparation is not a successful runtime gate, global M1 completion, current-source browser QA or publication.
