from pathlib import Path
import json,hashlib,difflib,ast
O=Path('/tmp/deepal-packet/post-registration-checks-v3');B=Path('/tmp/deepal-packet/report-comparison-v4');B.mkdir(exist_ok=False)
def pin(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def write(n,x):
 with (B/n).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
(B/'run.py').write_text((O/'run.py').read_text());s=(O/'compare-report.mjs').read_text();s=s.replace("const prep='/tmp/deepal-packet/post-registration-checks-v3';","const prep='/tmp/deepal-packet/report-comparison-v4';").replace("const out=qa+'/report-comparison-artifacts'","const out=qa+'/report-comparison-v4-artifacts'")
anchor="assert.equal(selectedIds.size,3);assert.equal(selectedResult.otherRetainedEffectiveFeaturesDeepEqual,true);"
new=anchor+"""
// Accepted complete-car hashes include every peer value, basis, unit, grade and identity.
const acceptedAudiDigests=readJson('/tmp/audi-packet/full-stage-v1/output/car-digest-comparison.json').candidate25;
const acceptedStageDigests=readJson('/tmp/deepal-packet/full-stage-v4/output/car-digest-comparison.json');
assert.deepEqual(acceptedStageDigests.candidate25,acceptedAudiDigests);
assert.equal(acceptedStageDigests.candidate26.length,427);
const oldPeerDigests=acceptedStageDigests.candidate25.filter(c=>!selectedIds.has(c.id)),newPeerDigests=acceptedStageDigests.candidate26.filter(c=>!selectedIds.has(c.id));
assert.equal(oldPeerDigests.length,424);assert.deepEqual(newPeerDigests,oldPeerDigests);
write('accepted-peer-car-value-and-basis-proof',{acceptedAudiSha256:fileHash('/tmp/audi-packet/full-stage-v1/output/car-digest-comparison.json'),acceptedDeepalStageSha256:fileHash('/tmp/deepal-packet/full-stage-v4/output/car-digest-comparison.json'),exactCompletePeerCars:424,allPeerValuesBasesUnitsGradesAndIdentitiesUnchanged:true,proof:'Complete-car byte digests from independently accepted actual stage; normal report source/input pins retain the same chain',peers:newPeerDigests});"""
assert s.count(anchor)==1;s=s.replace(anchor,new)
anchor="const groupKey=g=>JSON.stringify([g.vehicleClass,g.basis,g.unit]);"
new=anchor+"""
// Guarded excerpt of the actual production group comparator; no alternate sorting rule.
const discoveryPath=repo+'/src/lib/discovery.ts',discoverySource=fs.readFileSync(discoveryPath,'utf8');
const groupComparatorText='(a, b) =>\\n        b.entries.length - a.entries.length || a.basis.localeCompare(b.basis)';
const groupComparatorContext='.sort(\\n      '+groupComparatorText+',\\n    );';
assert.equal(discoverySource.split(groupComparatorContext).length,2);
assert(discoverySource.indexOf(groupComparatorContext)>discoverySource.indexOf('export function rankAttribute('));
const groupOrder=vm.runInThisContext('('+groupComparatorText+')',{filename:discoveryPath+':actual-group-order-excerpt'});
const sortingGroup=g=>({...g,entries:Array(g.count)});
function groupSegments(ranking){
 const map=new Map();let offset=0;
 for(const group of ranking.groups){
  assert.deepEqual(Object.keys(group),['vehicleClass','basis','unit','count']);assert(Number.isInteger(group.count)&&group.count>0);
  const key=groupKey(group);assert(!map.has(key));const ids=ranking.rankedIds.slice(offset,offset+group.count);assert.equal(ids.length,group.count);offset+=group.count;
  map.set(key,{group,ids});
 }
 assert.equal(offset,ranking.rankedIds.length);assert.equal(new Set(ranking.rankedIds).size,offset);return map;
}
const rankingGroupProof=[];"""
assert s.count(anchor)==1;s=s.replace(anchor,new)
old=""" assert.deepEqual(old.rankedIds.filter(id=>selectedIds.has(id)),b.rankedIds);
 assert.deepEqual(actual.rankedIds.filter(id=>!selectedIds.has(id)),old.rankedIds.filter(id=>!selectedIds.has(id)));
 assert.deepEqual(actual.rankedIds.filter(id=>selectedIds.has(id)),a.rankedIds);
 assert.equal(new Set(actual.rankedIds).size,actual.rankedIds.length);"""
new=""" const oldSegments=groupSegments(old),newSegments=groupSegments(actual),selectedBeforeSegments=groupSegments(b),selectedAfterSegments=groupSegments(a);
 const perGroup=[];
 for(const key of new Set([...oldSegments.keys(),...newSegments.keys(),...selectedBeforeSegments.keys(),...selectedAfterSegments.keys()])){
  const oldIds=oldSegments.get(key)?.ids||[],newIds=newSegments.get(key)?.ids||[],beforeIds=selectedBeforeSegments.get(key)?.ids||[],afterIds=selectedAfterSegments.get(key)?.ids||[];
  assert.deepEqual(oldIds.filter(id=>selectedIds.has(id)),beforeIds);
  assert.deepEqual(newIds.filter(id=>selectedIds.has(id)),afterIds);
  const oldPeers=oldIds.filter(id=>!selectedIds.has(id)),newPeers=newIds.filter(id=>!selectedIds.has(id));assert.deepEqual(newPeers,oldPeers,'Exact peer membership/order within class+basis+unit: '+old.key+'/'+key);
  assert.equal(newIds.length,oldIds.length-beforeIds.length+afterIds.length);
  perGroup.push({key,peerIds:oldPeers,selectedBeforeIds:beforeIds,selectedAfterIds:afterIds,beforeCount:oldIds.length,afterCount:newIds.length});
 }"""
assert s.count(old)==1;s=s.replace(old,new)
old=""" const oldPeerGroups=old.groups.filter(g=>g.count-(b.groups.find(x=>groupKey(x)===groupKey(g))?.count||0)>0).map(groupKey);
 assert.deepEqual(actual.groups.filter(g=>oldPeerGroups.includes(groupKey(g))).map(groupKey),oldPeerGroups);"""
new=""" const expectedGroups=[...counts].filter(([,n])=>n>0).map(([key,count])=>{const [vehicleClass,basis,unit]=JSON.parse(key);return{vehicleClass,basis,unit,count};});
 // No ambiguous production-comparator tie may be waived by incidental report order.
 for(let j=0;j<expectedGroups.length;j++)for(let k=j+1;k<expectedGroups.length;k++)assert.notEqual(groupOrder(sortingGroup(expectedGroups[j]),sortingGroup(expectedGroups[k])),0,'A group comparator tie needs separately established insertion provenance');
 expectedGroups.sort((x,y)=>groupOrder(sortingGroup(x),sortingGroup(y)));assert.deepEqual(actual.groups,expectedGroups);
 rankingGroupProof.push({key:old.key,perGroup,oldOrder:old.groups.map(groupKey),newOrder:expectedGroups.map(groupKey),allGroupSizeChangesAccountedBySelectedDeepal:true,exactPeerMembershipAndRelativeOrderWithinGroups:true,actualProductionGroupComparator:true,ambiguousComparatorTies:0});"""
assert s.count(old)==1;s=s.replace(old,new)
needle="""for(const key of ['gaps','summaryGaps']){""";s=s.replace(needle,"""write('ranking-group-order-and-peer-proof',{sourcePath:discoveryPath,sourceSha256:fileHash(discoveryPath),exactComparatorText:groupComparatorText,groups:rankingGroupProof});
"""+needle)
s=s.replace('peerRankRelativeOrderExact:true,globalC1EqualsAcceptedStage:true','peerRankRelativeOrderWithinMeasurementGroupsExact:true,groupOrderEqualsActualProducer:true,peerCompleteCarDigestsExact:424,globalC1EqualsAcceptedStage:true')
(B/'compare-report.mjs').write_text(s);(B/'comparator-v3-to-v4.patch').write_text(''.join(difflib.unified_diff((O/'compare-report.mjs').read_text().splitlines(True),s.splitlines(True),fromfile=str(O/'compare-report.mjs'),tofile=str(B/'compare-report.mjs'))))
m=json.loads((O/'report-comparison.json').read_text());m.update(id='report-comparison-v4',runOutput=m['qaRoot']+'/report-comparison-v4',command=m['command'][:-1]+[str(B/'compare-report.mjs')],wrapper=pin(B/'run.py'),comparisonResult=m['qaRoot']+'/report-comparison-v4-artifacts/result.json')
m['extraPins']=[p for p in m['extraPins'] if p['path']!=str(O/'compare-report.mjs')]+[pin(B/'compare-report.mjs')]
for p in ['/tmp/audi-packet/full-stage-v1/output/car-digest-comparison.json','/tmp/deepal-packet/full-stage-v4/output/car-digest-comparison.json','/tmp/deepal-review/FULL-STAGE-V4-RESULT-REVIEW.json',m['qaRoot']+'/normal-coverage-asof-2026-10-15/stdout.log',m['qaRoot']+'/normal-coverage-asof-2026-10-15/terminal.json',m['qaRoot']+'/normal-coverage-asof-2026-10-15/result.json',m['qaRoot']+'/report-comparison/result.json',m['qaRoot']+'/report-comparison/terminal.json']:
 m['extraPins'].append(pin(p))
write('report-comparison-v4.json',m)
oldseq=json.loads((O/'sequence.json').read_text());seq={k:v for k,v in oldseq.items() if k in ['status','sourcePins','rootMetadata','qaRoot','applicationManifest','applicationReceipt','applicationReadback']};seq.update(sequence=[pin(B/'report-comparison-v4.json')],normalReportRerunAuthorized=False,savedNormalReport=pin(m['qaRoot']+'/normal-coverage-asof-2026-10-15/stdout.log'),retainedFailedComparison=pin(m['qaRoot']+'/report-comparison/result.json'),priorSequence=pin(O/'sequence.json'),noAutomaticRetry=True,extraBroadFeatureReplay=False);write('sequence.json',seq)
g=json.loads((O/'root-grant-template.json').read_text());g['sequence']=pin(B/'sequence.json');write('root-grant-template.json',g)
ast.parse((B/'run.py').read_text());print(json.dumps(dict(sequence=pin(B/'sequence.json'),manifest=pin(B/'report-comparison-v4.json'),comparator=pin(B/'compare-report.mjs'),wrapper=pin(B/'run.py')),indent=2))
