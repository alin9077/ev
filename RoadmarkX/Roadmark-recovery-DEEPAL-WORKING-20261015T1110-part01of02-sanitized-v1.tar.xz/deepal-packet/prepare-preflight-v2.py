from pathlib import Path
import json,hashlib
A=Path('/tmp/deepal-packet/selected-preflight-v1');O=Path('/tmp/deepal-packet/selected-preflight-v2');O.mkdir(exist_ok=True)
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def write(p,x):Path(p).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
s=(A/'check.mjs').read_text().replace(str(A),str(O))
s=s.replace('observations=[],claims=[],producerProofs=[]','observations=[],claims=[],featureClaimRows=[],producerProofs=[]')
needle="assert.deepEqual(claim.sources.map(s=>s.id),[...new Set(feature.source_ids)]);featureClaims++;"
assert s.count(needle)==1;s=s.replace(needle,"assert.deepEqual(claim.sources.map(s=>s.id),[...new Set(feature.source_ids)]);featureClaimRows.push({variantId:car.id,criterion:feature.criterion,claim});featureClaims++;")
s=s.replace("portable:stored,claims,'undefined-witnesses':observations", "portable:stored,claims,'feature-claims':featureClaimRows,'undefined-witnesses':observations")
s=s.replace('selectedFeatureClaims:featureClaims,','selectedFeatureClaims:featureClaims,featureClaimOutputRows:featureClaimRows.length,')
(O/'check.mjs').write_text(s);(O/'expected-review.json').write_bytes((A/'expected-review.json').read_bytes())
pins=[pin(x['path'].replace(str(A),str(O))) for x in json.load(open(A/'source-pins.json'))];pins.append(pin('/tmp/deepal-research/raw-driveaway-feature-witnesses.json'));write(O/'source-pins.json',pins)
m=json.load(open(A/'prepared-command.json'));oldsha=m['script']['sha256'];m.update(script=pin(O/'check.mjs'),sourcePins=pin(O/'source-pins.json'),command=[x.replace(str(A),str(O)) for x in m['command']]);m['scope']+=' All207 complete featureClaim outputs are written separately, so the exact E07 driveaway feature and buyer claim can be reviewed without reconstructing it. Fallback equality is diagnostic only, not semantic approval of unresearched wording.'
w=(A/'run.py').read_text().replace(oldsha,m['script']['sha256']);(O/'run.py').write_text(w);m['wrapper']=pin(O/'run.py');write(O/'prepared-command.json',m)
print(json.dumps(dict(prepared=pin(O/'prepared-command.json'),script=m['script'],wrapper=m['wrapper'],packet=m['packet'],executed=False),indent=2))
