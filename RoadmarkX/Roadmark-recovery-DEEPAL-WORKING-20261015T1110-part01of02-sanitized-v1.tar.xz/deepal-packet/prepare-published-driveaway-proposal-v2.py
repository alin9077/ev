from pathlib import Path
old=Path('/tmp/deepal-packet/published-driveaway-tests-addition.ts').read_text()
s=old.replace('    { ...published, sourceIds: [] },','    { ...published, sourceIds: [] },\n    { ...published, sourceIds: [published.sourceIds[0], published.sourceIds[0]] },')
s=s.replace('    { ...published, value: null },\n  ]) {','    { ...published, value: null },\n    { ...published, sourceIds: [published.sourceIds[0], published.sourceIds[0]] },\n  ]) {')
s=s.replace('[{ ...source, publication_hold: "Hold" }],','[{ ...source, publication_hold: "Hold" }], [{ ...source, conflict: "Conflicting current source" }],')
s=s.replace('      assert.equal(result[1], unrelated);','''      assert.equal(result[1], unrelated);
      const pack: Pack = { car: candidate, features: result, sources, eligibility: { variant_id: candidate.id } as Pack["eligibility"], events: [], configuration: [] };
      const claim = featureClaim(pack, "driveaway_price", "Driveaway price", "2026-10-14")!;
      assert.equal(claim.gradeReviewStatus, "review_required");
      assert.equal(claim.buyerGrade, undefined);
      assert.match(claim.sentence, /review required/i);''')
assert s!=old
Path('/tmp/deepal-packet/published-driveaway-tests-addition-v2.ts').write_text(s)
p=Path('/tmp/deepal-packet/published-driveaway-proposal-v2')
(p/'src/lib').mkdir(parents=True,exist_ok=False);(p/'tests').mkdir()
b=Path('/tmp/deepal-packet/prepare-published-driveaway-proposal-v1.py').read_text().replace("published-driveaway-proposal-v1'","published-driveaway-proposal-v2'").replace("published-driveaway-tests-addition.ts'","published-driveaway-tests-addition-v2.ts'")
Path('/tmp/deepal-packet/build-published-driveaway-proposal-v2.py').write_text(b)
exec(compile(b,'proposal-assembly','exec'))
(p/'README.md').write_text(Path('/tmp/deepal-packet/published-driveaway-proposal-v1/README.md').read_text()+'\nV2 changes tests only: explicit duplicate fact source IDs, source-conflict withdrawal, and a withdrawn citable claim stating Review required. Production proposal files are byte-identical to v1. Candidate v6 remains immutable and unchanged. No checks executed.\n')
