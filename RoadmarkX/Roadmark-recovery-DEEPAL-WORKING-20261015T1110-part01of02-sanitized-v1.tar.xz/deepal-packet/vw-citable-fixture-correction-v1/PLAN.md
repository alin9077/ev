# Exact test-only correction proposal

Not applied or run. Root authorised preparation after the 142-pass / one-fail Deepal behavioural gate. No VW source fact or product code change is proposed.

The accepted Volkswagen packet11 guard preserves the historical unknown/null charging fact with its Kia station-example issue. Its accepted after fact is 26 min, DC 10–80%, standard/Confirmed, two maker source IDs, checked 14 October. Accepted Audi25 and Deepal26 VW complete-car hashes are identical. The old test mistakenly applied its historical assertion to the current reviewed pack.

Only tests/citable.test.ts changes. One explicit current-data test verifies the exact accepted after object, 26-minute value, 10–80% basis, grade/status, source IDs/date, complete claim/source provenance, current sentence and nonmutation. The original generic historical caution/nonmutation test remains, using a structured-cloned pack with only that exact retained packet beforeguard substituted. It verifies both the historical fixture and live current pack/retained guard remain untouched. Every other test body remains byte-identical. The test-file count becomes 14; the entire planned behavioural suite becomes 144 if rerun.

Application: one exact before-hash guarded replacement, retained before copy, journal/fsync, after-hash verification, only after independent diff review and root's explicit application grant. No automatic application/rollback/retry is included here.

Focused rerun proposal, after application and independent readback:
1. Installed ESLint on tests/citable.test.ts only, original config, no cache, max warnings zero, JSON output; Node 256 MiB old-space / 1 MiB semi-space, 180+10 seconds
2. Actual complete tests/citable.test.ts file, 14 expected exact TAP titles, no skips/failures/todo/cancellations; Node 512/1 MiB, --import tsx --test --test-reporter=tap --test-concurrency=1, 600+10 seconds

Both receive newly frozen input pins and refreshed original-scope metadata, raw wait4 terminal/resource/log receipts and independent review. No old manifest is rerun or modified. Preserve the original failed behavioural logs/receipts. The remaining first-five gates and fresh full-project TypeScript/normal report remain blocked on separately reviewed continuation: the original full suite's one failed result must never be relabelled a complete pass. Root may choose a fresh exact 144-test gate or a separately explicit reviewed compositional acceptance of unchanged prior successes plus all 14 focused current tests; neither is assumed by this proposal.
