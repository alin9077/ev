from pathlib import Path
import hashlib,json,difflib
R=Path('/workspace/scratch/586427eef9f2/roadmark-104');B=Path('/tmp/deepal-packet/vw-citable-fixture-correction-v1');target=R/'tests/citable.test.ts';old=target.read_text()
start=old.index('test("bounded VW report uses generic charging cautions')
end=old.index('\ntest("manufacturer phase labels',start)
newtest='''function vwChargingReviewFixture() {
  const packet = JSON.parse(
    readFileSync(
      new URL("../data/m1-brand-updates/volkswagen-2026-10-14.json", import.meta.url),
      "utf8",
    ),
  ) as { facts: { variantId: string; before: Fact; after: Fact }[] };
  const review = packet.facts.find(
    (edit) =>
      edit.variantId === "volkswagen_idbuzz_my26_pro_swb__20261010" &&
      edit.after.key === "dc_charge_time_min",
  );
  assert.ok(review, "retain the exact reviewed Volkswagen charging before/after fixture");
  return review;
}

test("current VW charging report retains the reviewed 26-minute 10–80% figure and exact sources", () => {
  const selected = pack("volkswagen_idbuzz_my26_pro_swb__20261010", snapshot);
  const before = JSON.stringify(selected);
  const review = vwChargingReviewFixture();
  const fact = selected.car.facts.dc_charge_time_min;
  assert.deepEqual(fact, review.after);
  assert.equal(fact.value, 26);
  assert.equal(fact.status, "standard");
  assert.equal(fact.buyerGrade, "confirmed");
  assert.equal(fact.date, "2026-10-14");
  assert.equal(fact.gradeReview?.reviewedAt, "2026-10-14");
  assert.equal(fact.basis, "DC 10–80% state-of-charge, published 26 min");
  assert.equal(fact.comparisonBasis, "DC 10–80%");
  assert.deepEqual(fact.sourceIds, [
    "m1-volkswagen-2026-10-14-idbuzz_vw_buzz_page",
    "m1-volkswagen-2026-10-14-idbuzz_vw_buzz_my25_pdf",
  ]);
  assert.deepEqual(fact.qualifications, []);
  assert.deepEqual(fact.issues, []);
  const report = makeReport([selected], "/cars/vw-current-fixture", "2026-10-15");
  const charging = report.keyFacts.find((claim) => claim.key === "dc_charge_time_min")!;
  assert.equal(charging.value, "26 min");
  assert.equal(charging.status, "standard");
  assert.equal(charging.buyerGrade, "confirmed");
  assert.equal(charging.evidenceDate, fact.date);
  assert.equal(charging.basis, fact.basis);
  assert.deepEqual(charging.gradeReview, fact.gradeReview);
  assert.deepEqual(charging.sources.map((source) => source.id), fact.sourceIds);
  for (const source of charging.sources) {
    const retained = selected.sources.find((row) => row.id === source.id)!;
    assert.ok(retained);
    assert.equal(source.url, retained.url);
    assert.equal(source.accessed_date, retained.accessed_date);
    assert.equal(source.published_date, retained.published_date);
  }
  assert.deepEqual(charging.qualifications, []);
  assert.match(charging.sentence, /26 min; basis: DC 10–80%/);
  assert.match(charging.sentence, /evidence checked 2026-10-14; confirmed/);
  assert.doesNotMatch(charging.sentence, /Kia test|350 kW|charge windows and test conditions match|needs confirmation/i);
  assert.ok(selected.car.buyerSummary?.strength);
  assert.equal(JSON.stringify(selected), before);
});

test("bounded VW report uses generic charging cautions without changing raw evidence or guarded copy", () => {
  const current = pack("volkswagen_idbuzz_my26_pro_swb__20261010", snapshot);
  const currentBefore = JSON.stringify(current);
  const review = vwChargingReviewFixture();
  const guardBefore = JSON.stringify(review.before);
  const selected = structuredClone(current);
  // Exercise the exact historical held fact, not a downgrade of current evidence.
  selected.car.facts.dc_charge_time_min = structuredClone(review.before);
  const before = JSON.stringify(selected);
  const report = makeReport([selected], "/cars/vw-historical-fixture", "2026-10-15");
  const charging = report.keyFacts.find(
    (claim) => claim.key === "dc_charge_time_min",
  )!;
  assert.equal(charging.status, "not_verified");
  assert.equal(selected.car.facts.dc_charge_time_min.value, null);
  assert.match(charging.sentence, /charge windows and test conditions match/);
  assert.doesNotMatch(charging.sentence, /Kia test|350 kW/);
  assert.ok(
    selected.car.facts.dc_charge_time_min.issues.some((issue) =>
      issue.publication_action.includes("Kia test"),
    ),
  );
  assert.ok(selected.car.buyerSummary?.strength);
  assert.equal(JSON.stringify(selected), before);
  assert.equal(JSON.stringify(current), currentBefore);
  assert.equal(JSON.stringify(review.before), guardBefore);
});
'''
new=old[:start]+newtest+old[end:]
new=new.replace('import assert from "node:assert/strict";','import assert from "node:assert/strict";\nimport { readFileSync } from "node:fs";\nimport type { Fact } from "../src/lib/types";',1)
def save(n,s):
 with (B/n).open('x') as f:f.write(s)
def pin(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
save('before-citable.test.ts',old);save('after-citable.test.ts',new)
save('correction.patch',''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/tests/citable.test.ts',tofile='b/tests/citable.test.ts')))
proofs=['/workspace/scratch/586427eef9f2/roadmark-104/data/m1-brand-updates/volkswagen-2026-10-14.json','/tmp/audi-packet/full-stage-v1/output/car-digest-comparison.json','/tmp/deepal-packet/full-stage-v4/output/car-digest-comparison.json','/workspace/scratch/586427eef9f2/roadmark-104-qa/deepal-sequential-checks/behavioural-suites/result.json','/workspace/scratch/586427eef9f2/roadmark-104-qa/deepal-sequential-checks/behavioural-suites/terminal.json','/workspace/scratch/586427eef9f2/roadmark-104-qa/deepal-sequential-checks/behavioural-suites/stdout.log','/workspace/scratch/586427eef9f2/roadmark-104/src/lib/citable.ts','/workspace/scratch/586427eef9f2/roadmark-104/src/lib/compare.ts','/workspace/scratch/586427eef9f2/roadmark-104/src/lib/issue-presentation.ts']
m=dict(status='test_only_proposal_not_applied_or_executed',target=str(target),before=pin(B/'before-citable.test.ts'),after=pin(B/'after-citable.test.ts'),patch=pin(B/'correction.patch'),proofs=[pin(p) for p in proofs],productionFactsChanged=False,productionCodeChanged=False,otherTestBodiesChanged=False,previousTests=13,proposedTests=14,priorFailurePreserved=True,applicationRequiresRootGrant=True,executionRequiresNewReviewedFrozenCommandAndHeavySlot=True)
save('manifest.json',json.dumps(m,indent=2)+'\n');print(json.dumps(dict(manifest=pin(B/'manifest.json'),patch=m['patch'],after=m['after']),indent=2))
