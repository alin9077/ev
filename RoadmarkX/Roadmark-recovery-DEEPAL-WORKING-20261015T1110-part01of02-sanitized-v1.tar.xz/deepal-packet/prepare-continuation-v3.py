from pathlib import Path
import json,hashlib,ast,difflib
B=Path('/tmp/deepal-packet/post-registration-checks-v3');O=Path('/tmp/deepal-packet/post-registration-checks-v2');B.mkdir(exist_ok=False)
(B/'run.py').write_text((O/'run.py').read_text())
s=(O/'compare-report.mjs').read_text().replace('post-registration-checks-v2','post-registration-checks-v3').replace('roadmark-104-qa/deepal-sequential-checks','roadmark-104-qa/deepal-continuation-checks')
old="""assert.deepEqual(selectedBefore.brandProgress.find(b=>b.brand==='Deepal'),oldDeepal);
write('selected-before-report',selectedBefore);write('selected-freshness-producer-proof'"""
new="""// Whole written parity plus exact own-undefined ownership from the actual C1 issue producer.
write('selected-before-report',selectedBefore);
assert.deepEqual(readJson(out+'/selected-before-report.json').brandProgress.find(b=>b.brand==='Deepal'),oldDeepal);
const {buildMarketReconciliation}=require('./scripts/reporting/m1-reconciliation.ts');
const issueFixtureInventory={records:[],unverifiedLeads:[]};
const issueFixture=buildMarketReconciliation(emptyRegistry,[],issueFixtureInventory,normal.asOf);
assert.equal(issueFixture.registryValid,true);assert.equal(issueFixture.independentListCount,0);
assert.deepEqual(issueFixture.issues.map(i=>i.code),['independent_lists','empty_catalogue']);
const liveDeepal=selectedBefore.brandProgress.find(b=>b.brand==='Deepal');
const producedIssues=issueFixture.issues.filter(i=>i.code==='independent_lists'),expectedIssues=oldDeepal.closureIssues.filter(i=>i.code==='independent_lists'),liveIssues=liveDeepal.closureIssues.filter(i=>i.code==='independent_lists');
assert.equal(producedIssues.length,1);assert.equal(expectedIssues.length,1);assert.equal(liveIssues.length,1);
const producedIssue=producedIssues[0],expectedIssue=expectedIssues[0],liveIssue=liveIssues[0];
assert.deepEqual(Object.keys(expectedIssue).sort(),['code','reason']);
assert.deepEqual(Object.keys(producedIssue).sort(),['brand','code','reason','reference']);
assert.deepEqual(Object.keys(liveIssue).sort(),['brand','code','reason','reference']);
const issueOwnership=[];
for(const property of ['brand','reference']){
 const actual=Object.getOwnPropertyDescriptor(liveIssue,property),producer=Object.getOwnPropertyDescriptor(producedIssue,property);
 for(const descriptor of [actual,producer]){assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value'));assert.equal(descriptor.value,undefined);}
 assert.deepEqual(actual,producer);assert(!Object.hasOwn(expectedIssue,property));
 issueOwnership.push({property,ownUndefined:true,enumerable:true,producer:'actual buildMarketReconciliation → add(code,reason) creates both optional own properties; pinned m1-reconciliation.ts'});
}
write('selected-before-c1-issue-producer',{fixtureRegistry:emptyRegistry,fixtureCars:[],fixtureInventory:issueFixtureInventory,asOf:normal.asOf,issue:producedIssue,exactOwnership:issueOwnership});
assert.deepEqual(readJson(out+'/selected-before-c1-issue-producer.json').issue,expectedIssue);
const expectedLiveDeepal=structuredClone(oldDeepal),issueIndex=expectedLiveDeepal.closureIssues.findIndex(i=>i.code==='independent_lists');
assert.equal(issueIndex,liveDeepal.closureIssues.findIndex(i=>i.code==='independent_lists'));
expectedLiveDeepal.closureIssues[issueIndex]=producedIssue;assert.deepEqual(liveDeepal,expectedLiveDeepal);
write('selected-freshness-producer-proof'"""
assert s.count(old)==1;s=s.replace(old,new);(B/'compare-report.mjs').write_text(s)
(B/'comparator-v2-to-v3.patch').write_text(''.join(difflib.unified_diff((O/'compare-report.mjs').read_text().splitlines(True),s.splitlines(True),fromfile=str(O/'compare-report.mjs'),tofile=str(B/'compare-report.mjs'))))
p=(O/'prepare.py').read_text().replace('post-registration-checks-v2','post-registration-checks-v3').replace('roadmark-104-qa/deepal-sequential-checks','roadmark-104-qa/deepal-continuation-checks').replace("T=Path('/tmp/deepal-packet/full-project-typescript-v1')","T=Path('/tmp/deepal-packet/full-project-typescript-v2')").replace('==143','==144').replace('expectedTests=143','expectedTests=144').replace('testCount=143','testCount=144')
p=p.replace("extraNamed=['scripts/report-coverage.ts'","extraNamed=['src/lib/data.ts','scripts/report-coverage.ts'")
p=p.replace("configs=[\n dict(id='market-view',kind='market',command=base(128)+['scripts/generate-market-view.mjs','--check'],timeoutSeconds=60),\n dict(id='changed-file-lint',kind='lint',command=base(256)+[eslint,'--no-config-lookup','--config',str(R/'eslint.config.mjs'),'--no-ignore','--no-cache','--concurrency','off','--max-warnings','0','--format','json','--',*lint],timeoutSeconds=180,lintFiles=lint),", "configs=[")
p=p.replace("sequence=[];previous=None", """O=Path('/tmp/deepal-packet/post-registration-checks-v2');F=Path('/tmp/deepal-packet/vw-citable-focused-checks-v1')
oldqa=R.parent/'roadmark-104-qa/deepal-sequential-checks';focusqa=R.parent/'roadmark-104-qa/deepal-fixture-focused-checks'
retained=[]
for name in ['market-view','changed-file-lint']:
 result=oldqa/name/'result.json';assert json.loads(result.read_text())['passed']
 retained.append(dict(name=name,manifest=pin(O/(name+'.json')),result=pin(result),terminal=pin(oldqa/name/'terminal.json')))
focused=[dict(manifest=pin(F/(name+'.json')),resultPath=str(focusqa/name/'result.json')) for name in ['one-file-lint','focused-citable-tests']]
initial=[dict(manifest=r['manifest'],resultPath=r['result']['path']) for r in retained]+focused
provenance=[pin('/tmp/deepal-packet/vw-citable-fixture-correction-v1/manifest.json'),pin('/tmp/deepal-packet/vw-citable-fixture-correction-v1/application/result.json'),pin('/tmp/deepal-review/VW-CITABLE-CORRECTION-READBACK.json'),*[p for r in retained for p in [r['result'],r['terminal']]]]
sequence=[];previous=None""")
p=p.replace("'prerequisites':[] if previous is None else [previous],'extraPins':[]", "'prerequisites':initial if previous is None else [previous],'extraPins':provenance")
p=p.replace("sequence=sequence,sourcePins=common['sourcePins']", "sequence=sequence,retainedPassingGates=retained,focusedPrerequisites=focused,originalAggregateFailure=pin(oldqa/'behavioural-suites/result.json'),freshAggregateTests=144,sourcePins=common['sourcePins']")
p=p.replace("'extraPins':[]}","'extraPins':provenance}")
p=p.replace("'extraPins':[pin(B/'compare-report.mjs'),", "'extraPins':[*provenance,pin(B/'compare-report.mjs'),")
(B/'prepare.py').write_text(p);ast.parse(p);ast.parse((B/'run.py').read_text());print(B)
