import urllib.request,json,hashlib,datetime
from pathlib import Path
root=Path('/tmp/deepal-research/sources')
url='https://www.deepal.com.au/umbraco/api/custompricing/vehicles'
for name,vid in [('e07-rwd-nsw-prices','f47b8f9a-9c9d-4ed5-bf80-67622ffdb8ff'),('e07-awd-nsw-prices','a2f1d4e9-7b6c-42a3-b1d2-8a7e5d9f1f2a')]:
 payload={'postCode':'2000','modelId':'81d4cd5b-bac3-4fa2-8dff-b5e5e4fbc88f','variantIds':[vid],'colorIndex':0,'interiorIndex':0,'selectedExtraPrices':[]}
 receipt={'url':url,'method':'POST read-only public vehicle price calculator','payload':payload,'checkedAt':'2026-10-15','authenticationHeadersSent':False,'headersRecorded':False,'observationSource':'Current model HTML identifies model/variant IDs; public customPriceSelector.js and apiManager.js establish endpoint and request shape; no form, account, order or quote submission.'}
 try:
  req=urllib.request.Request(url,data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'},method='POST');r=urllib.request.urlopen(req,timeout=30);b=r.read();receipt.update(status=r.status,bytes=len(b),sha256=hashlib.sha256(b).hexdigest());(root/(name+'.json')).write_bytes(b);print(name,r.status,len(b)); print(json.dumps(json.loads(b),indent=2)[:6000])
 except Exception as e:receipt['error']=str(e);print(name,str(e))
 (root/(name+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
