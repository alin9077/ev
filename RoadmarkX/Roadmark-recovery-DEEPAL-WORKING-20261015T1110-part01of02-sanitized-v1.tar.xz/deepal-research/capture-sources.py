from pathlib import Path
import urllib.request,json,hashlib,datetime,concurrent.futures,re
from html.parser import HTMLParser
ROOT=Path('/tmp/deepal-research/sources');ROOT.mkdir(exist_ok=True)
class Text(HTMLParser):
 def __init__(self):super().__init__();self.skip=0;self.parts=[];self.links=[];self.scripts=[]
 def handle_starttag(self,t,a):
  d=dict(a)
  if t in ['script','style']:self.skip+=1
  if t=='script' and d.get('src'):self.scripts.append(d['src'])
  if t=='a' and d.get('href'):self.links.append(d['href'])
  if t in ['p','div','li','h1','h2','h3','h4','tr','br']:self.parts.append('\n')
 def handle_endtag(self,t):
  if t in ['script','style'] and self.skip:self.skip-=1
  if t in ['p','div','li','tr']:self.parts.append('\n')
 def handle_data(self,d):
  if not self.skip:self.parts.append(d)
def get(item):
 name,url=item; now=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt={'url':url,'checkedAt':now,'method':'unauthenticated public GET','requestHeadersRecorded':False,'cookieOrAuthenticationHeadersRecorded':False}
 try:
  r=urllib.request.urlopen(url,timeout=45);b=r.read(); typ=r.headers.get('Content-Type','');receipt.update(status=r.status,finalUrl=r.url,contentType=typ,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
  suffix='.pdf' if 'pdf' in typ or url.endswith('.pdf') else '.html'
  if suffix=='.html':
   raw=b.decode('utf-8','replace'); clean=re.sub(r'(<input[^>]+name=["\']__RequestVerificationToken["\'][^>]+value=)["\'][^"\']+["\']',r'\1"[REDACTED-PUBLIC-FORM-TOKEN]"',raw,flags=re.I);b=clean.encode(); receipt['savedSha256']=hashlib.sha256(b).hexdigest();receipt['bodySanitization']='Redacts public form anti-forgery tokens only if present; no factual text changed.'
   p=Text();p.feed(clean); text='\n'.join(' '.join(x.split()) for x in ''.join(p.parts).splitlines() if x.strip());(ROOT/(name+'.txt')).write_text(text);(ROOT/(name+'-links.json')).write_text(json.dumps({'links':p.links,'scripts':p.scripts},indent=2))
  (ROOT/(name+suffix)).write_bytes(b)
 except Exception as e:receipt['error']=str(e)
 (ROOT/(name+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(name,receipt.get('status'),receipt.get('bytes'),receipt.get('error',''))
if __name__=='__main__':
 items=json.load(open(__import__('sys').argv[1]));
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:list(ex.map(get,items))
