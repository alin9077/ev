/** Exact production research() replay from original source plus the full registry; no cars. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {roots,readJson,fileHash,verifyPins,compareRows,writeNew} from './helpers.mjs';
const pins=readJson(roots.proof+'/input-verification.json'),phasePins=readJson(roots.proof+'/research-phase-inputs.json');assert.equal(pins.status,'passed_for_derived_only_replay');verifyPins(pins);verifyPins(phasePins);
const read=fs.readFileSync,baseFile=roots.repo+'/data/au_ev_all_variants_2026-10-06.json';let baseReads=0;
fs.readFileSync=function(file,...args){if(path.resolve(String(file))===baseFile&&args[0]==='utf8')baseReads++;return read.call(fs,file,...args)};
const require=createRequire(roots.repo+'/src/lib/data.ts'),api=require('./data.ts'),{australianEvidenceDate}=require('./evidence-date.ts');assert.equal(australianEvidenceDate(),'2026-10-15');assert.equal(typeof global.gc,'function');global.gc();console.log('Research-only imports collected',process.memoryUsage());
const data=api.research();assert.equal(baseReads,1);console.log('Actual full research loaded without cars',Object.keys(data).length,process.memoryUsage());global.gc();
const priorIndex=readJson(roots.polestar+'/replay-snapshot-index.json');assert.equal(Object.keys(data).length,14);assert.deepEqual(Object.keys(data).sort(),Object.keys(priorIndex.research).sort());
const index={schemaVersion:2,mode:'fresh_actual_research_only_no_catalogue_hydration',asOf:'2026-10-15',timeZone:'Australia/Sydney',research:{}};
for(const[key,value]of Object.entries(data)){const array=Array.isArray(value),file='capture-phased640-original/replay-snapshot/research-'+key+'.jsonl';assert.equal(array,priorIndex.research[key].array);index.research[key]={anchor:'research',file,array,...await compareRows(roots.research+'/'+file,array?value:[value])};console.log('Full fresh research equality',key,index.research[key].rows);global.gc()}
assert.equal(baseReads,1);assert.equal(australianEvidenceDate(),'2026-10-15');verifyPins(pins);verifyPins(phasePins);
writeNew('fresh-research-storage-index.json',index);
writeNew('fresh-research-receipt.json',{status:'passed_pending_successful_measured_terminal',mode:index.mode,asOf:index.asOf,baseReads,all14RetainedFieldsByteEqual:true,originalCompositionFailureRetained:true,metadataNotRewritten:true,reason:'Production prepareBrandResearch intentionally replaces invocation-scope packet IDs and is not idempotent; this phase starts from sourceResearch plus the entire actual registered packet set through public research().',indexSha256:fileHash(roots.proof+'/fresh-research-storage-index.json'),baseInputVerificationSha256:fileHash(roots.proof+'/input-verification.json'),phaseInputVerificationSha256:fileHash(roots.proof+'/research-phase-inputs.json'),resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage(),freshCarsVerified:false,derivedBaselineAccepted:false});
console.log('ACTUAL RESEARCH-ONLY EQUALITY PASSED; no car or baseline acceptance claim');
