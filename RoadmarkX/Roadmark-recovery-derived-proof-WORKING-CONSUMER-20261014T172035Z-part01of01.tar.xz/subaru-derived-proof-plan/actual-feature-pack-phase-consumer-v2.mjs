/** Actual selected-car consumers; full population was proved independently in core phase. */
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {roots,readJson,fileHash,digestRows,readResearch,writeNew} from './helpers.mjs';
import {openConsumerPhaseInputs} from './consumer-transition-helpers.mjs';
const proof=openConsumerPhaseInputs(),core=proof.coreReceipt,index=proof.storageIndex;
const coreHash=proof.manifest.coreReceipt.sha256;
const require=createRequire(roots.repo+'/package.json');
const {createEvidenceConsumers}=require('./src/lib/evidence-consumers.ts');
const forbidden=()=>{throw new Error('Derived consumer phase must never load a fallback source, research or catalogue')};
const {effectiveFeatures,pack}=createEvidenceConsumers({sourceResearch:forbidden,research:forbidden,catalogue:forbidden});
const {storePortablePacks,hydratePortablePacks}=require('./src/lib/portable-packs.ts');
assert.equal(typeof global.gc,'function');global.gc();console.log('Actual lightweight consumers imported and collected',process.memoryUsage());
const data=await readResearch(index),subaruFile=roots.research+'/capture-attempt640-original/subaru-live-before.json',subaru=readJson(subaruFile),polestar=readJson(roots.polestar+'/after.json');assert.equal(subaru.length,9);assert.equal(polestar.length,14);
const selected=[...subaru,...polestar],selectedHashes=new Map(selected.map(car=>[car.id,digestRows([car])]));
for(const car of selected){const reviewed=core.carHashes.find(row=>row.id===car.id);assert(reviewed);assert.equal(selectedHashes.get(car.id).sha256,reviewed.afterSha256);assert.equal(selectedHashes.get(car.id).bytes,reviewed.bytes)}
const featureFile=roots.research+'/capture-attempt640-original/subaru-feature-before.json',features=subaru.flatMap(car=>effectiveFeatures(car,data));assert.equal(JSON.stringify(features,null,2),fs.readFileSync(featureFile,'utf8'),'Complete original fifth Subaru feature file byte equality');console.log('All original nine Subaru feature sets match',features.length,process.memoryUsage());global.gc();
const approved=readJson(roots.polestar+'/staged-packs.json'),actual={};for(const car of polestar){const value=pack(car.id,{data,cars:selected});assert.deepEqual(JSON.parse(JSON.stringify(value)),approved[car.id],'Complete actual Polestar pack: '+car.id);actual[car.id]=value;global.gc()}
assert.deepEqual(Object.keys(actual).sort(),Object.keys(approved).sort());assert.equal(Object.keys(actual).length,14);assert.deepEqual(hydratePortablePacks(storePortablePacks(actual),data.sources),actual,'Complete actual Polestar portable parity');
for(const car of selected)assert.deepEqual(digestRows([car]),selectedHashes.get(car.id),'Selected full car input unchanged');
assert.deepEqual(Object.keys(data).sort(),Object.keys(index.research).sort());for(const[key,value]of Object.entries(data)){const d=digestRows(Array.isArray(value)?value:[value]),row=index.research[key];assert.equal(d.sha256,row.sha256,'Complete research input unchanged after actual consumer calls: '+key);assert.equal(d.rows,row.rows);assert.equal(d.bytes,row.bytes);global.gc()}
proof.verify();
writeNew('actual-feature-pack-receipt.json',{status:'passed',mode:'Actual selected-car consumers on the fully proven derived baseline; no fresh hydration',asOf:'2026-10-15',originalSubaruCars:9,originalSubaruFeatureRows:features.length,fifthOriginalFileSha256:fileHash(featureFile),actualPolestarPacks:14,actualPortableExact:true,fullResearchAndSelectedCarsUnchanged:true,coreReceiptSha256:coreHash,inputVerificationSha256:proof.manifest.inputVerification.sha256,consumerPhaseManifestSha256:proof.manifestSha256,reviewedSourceTransitionSha256:proof.manifest.sourceTransitionReview.sha256,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
writeNew('derived-index.awaiting-terminal-review.json',{...index,consumerPhaseManifestSha256:proof.manifestSha256,reviewedSourceTransitionSha256:proof.manifest.sourceTransitionReview.sha256,acceptance:'complete_derived_value_checks_pending_independent_terminal_review',phaseReceipts:{core:fileHash(roots.proof+'/core-oracle-receipt.json'),actualFeaturesAndPacks:fileHash(roots.proof+'/actual-feature-pack-receipt.json')},completeReportsRegenerated:false,requiredBeforeAcceptance:['Complete actual-feature/report replay at both 2026-10-14 and 2026-10-15','Successful measured phase terminals and independent approval'],allFiveOriginalSubaruFilesByteEqual:true,originalSubaruCars:9,proposedSubaruCars:11,freshV2Capture:false,finalLoaderEquivalence:false,currentFullTypecheckVerified:false,subaruRegistrationAuthorized:false});
console.log('DERIVED VALUE CHECKS PASSED; independent terminal review and release gates remain');
