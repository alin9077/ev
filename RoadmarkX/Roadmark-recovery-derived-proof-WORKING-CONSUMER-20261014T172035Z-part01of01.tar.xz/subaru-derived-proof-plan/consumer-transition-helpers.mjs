/** Versioned consumer-only proof pins; never rewrites any historical expectation. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {roots,readJson,fileHash,verifyPins,locate} from './helpers.mjs';
export function openConsumerPhaseInputs(){
 const manifestFile=roots.proof+'/consumer-phase-manifest.json',manifest=readJson(manifestFile),manifestSha256=fileHash(manifestFile);
 assert.equal(manifest.schemaVersion,1);assert.equal(manifest.mode,'derived-only-reviewed-consumer-transition');
 const artifacts={};
 for(const key of ['inputVerification','compositionInputs','coreReceipt','coreTerminal','storageIndex','sourceTransitionReview','beforeSourceInventory','currentSourceInventory']){
  const row=manifest[key];assert(row);const file=locate(row);assert.equal(fileHash(file),row.sha256,'Phase artifact hash: '+key);artifacts[key]=readJson(file);
 }
 const {inputVerification,compositionInputs,coreReceipt,coreTerminal,storageIndex,sourceTransitionReview,beforeSourceInventory,currentSourceInventory}=artifacts;
 assert.equal(inputVerification.status,'passed_for_derived_only_replay');assert.equal(compositionInputs.mode,'explicit-derived-composition-v2');
 assert.equal(coreTerminal.returncode,0);assert.equal(coreTerminal.signal,null);
 assert.equal(coreReceipt.inputVerificationSha256,manifest.inputVerification.sha256);assert.equal(coreReceipt.compositionInputsSha256,manifest.compositionInputs.sha256);assert.equal(coreReceipt.storageIndexSha256,manifest.storageIndex.sha256);
 assert(coreReceipt.all397RetainedCarRowsByteEqual&&coreReceipt.all14ResearchFieldsByteEqual&&coreReceipt.allOriginalObjectsUnchanged&&coreReceipt.allNonPolestarCarValuesEqual);
 assert.equal(storageIndex.asOf,'2026-10-15');assert.equal(storageIndex.cars.rows,397);assert.equal(Object.keys(storageIndex.research).length,14);
 assert.equal(sourceTransitionReview.status,'approved_for_consumer_phase_pin_transition');assert.deepEqual(manifest.sourceChanges,sourceTransitionReview.sourceChanges);assert.equal(sourceTransitionReview.priorCoreReceiptSha256,manifest.coreReceipt.sha256);
 const pinnedProofScripts=new Set(manifest.extraPins.filter(row=>row.anchor==='proof').map(row=>row.file));
 for(const file of ['consumer-transition-helpers.mjs','actual-feature-pack-phase-consumer-v2.mjs','stream-baseline-effective-features-consumer-v2.mjs','replay-complete-baseline-reports-consumer-v2.mjs','additional-report-phase-helpers.mjs'])assert(pinnedProofScripts.has(file),'Required actual phase script omitted: '+file);
 const changes=new Map(manifest.sourceChanges.map(row=>[path.join(roots.repo,row.file),row]));assert.equal(changes.size,manifest.sourceChanges.length);
 const beforeMap=new Map(beforeSourceInventory.files.map(row=>[row.file,row])),currentMap=new Map(currentSourceInventory.files.map(row=>[row.file,row]));
 assert.equal(beforeMap.size,beforeSourceInventory.files.length);assert.equal(currentMap.size,currentSourceInventory.files.length);
 assert.deepEqual([...currentMap.keys()].sort(),[...beforeMap.keys(),...manifest.sourceChanges.filter(row=>row.beforeSha256===null).map(row=>row.file)].sort(),'Exact source inventory additions');
 const historicalPins=new Map(inputVerification.executionInputs.map(row=>[row.path,row]));assert.equal(historicalPins.size,inputVerification.executionInputs.length);
 for(const change of manifest.sourceChanges){
  assert(change.file.startsWith('src/')||change.file.startsWith('tests/'),'Only explicitly reviewed production/test boundary');
  const absolute=path.join(roots.repo,change.file);assert(absolute.startsWith(roots.repo+'/'));
  if(change.beforeSha256===null){assert(!historicalPins.has(absolute));assert(!beforeMap.has(change.file));assert.equal(change.beforeFile,null)}
  else{assert.equal(historicalPins.get(absolute)?.sha256,change.beforeSha256);assert.equal(beforeMap.get(change.file)?.sha256,change.beforeSha256);assert.equal(fileHash(locate(change.beforeFile)),change.beforeSha256,'Complete historical before bytes retained')}
  assert.equal(currentMap.get(change.file)?.sha256,change.afterSha256);
 }
 for(const[file,row]of beforeMap){const change=changes.get(path.join(roots.repo,file));assert.equal(currentMap.get(file)?.sha256,change?.afterSha256??row.sha256,'No other source change: '+file)}
 const verify=()=>{
  assert.equal(fileHash(manifestFile),manifestSha256,'Consumer proof manifest unchanged');
  for(const key of ['inputVerification','compositionInputs','coreReceipt','coreTerminal','storageIndex','sourceTransitionReview','beforeSourceInventory','currentSourceInventory'])assert.equal(fileHash(locate(manifest[key])),manifest[key].sha256,'Phase artifact unchanged: '+key);
  // The original manifest itself is immutable. Only a reviewed current path is checked against its explicitly retained before/after transition.
  for(const row of inputVerification.executionInputs){const change=changes.get(row.path);if(change){assert.equal(row.sha256,change.beforeSha256);assert.equal(fileHash(locate(change.beforeFile)),row.sha256);assert.equal(fileHash(row.path),change.afterSha256)}else assert.equal(fileHash(row.path),row.sha256,'Historical pin changed without an approved transition: '+row.path)}
  verifyPins(compositionInputs);
  for(const row of currentSourceInventory.files){const file=path.join(roots.repo,row.file);assert(file.startsWith(roots.repo+'/'));assert.equal(fileHash(file),row.sha256,'Complete current source pin: '+row.file);assert.equal(fs.statSync(file).size,row.bytes)}
  for(const row of manifest.extraPins){const file=locate(row);assert.equal(fileHash(file),row.sha256,'Additional consumer phase pin: '+row.file);if(row.bytes!==undefined)assert.equal(fs.statSync(file).size,row.bytes)}
  for(const change of manifest.sourceChanges)assert.equal(fileHash(path.join(roots.repo,change.file)),change.afterSha256);
 };
 verify();return {...artifacts,manifest,manifestSha256,verify};
}
