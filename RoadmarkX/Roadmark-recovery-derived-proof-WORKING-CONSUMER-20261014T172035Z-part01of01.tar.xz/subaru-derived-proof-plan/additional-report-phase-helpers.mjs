import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {roots,readJson,fileHash,verifyPins} from './helpers.mjs';
export function boundedProofPath(file){assert.equal(typeof file,'string');const resolved=path.resolve(roots.proof,file);assert(resolved.startsWith(roots.proof+'/'),'Proof artifact locator escaped anchor');return resolved}
export function openReportPhaseInputs(){
 const file=boundedProofPath('additional-report-phase-manifest.json'),manifest=readJson(file),manifestSha256=fileHash(file);
 assert.equal(manifest.schemaVersion,1);assert.equal(manifest.mode,'derived-only-complete-report');
 assert.deepEqual(manifest.scriptPins.map(row=>row.file).sort(),['additional-report-phase-helpers.mjs','replay-complete-baseline-reports.mjs','stream-baseline-effective-features.mjs']);
 const artifacts={};
 for(const key of ['inputVerification','coreReceipt','storageIndex','actualPackReceipt']){
  const row=manifest[key];assert(row);const p=boundedProofPath(row.file);assert.equal(fileHash(p),row.sha256,'Added phase artifact pin: '+key);artifacts[key]=readJson(p);
 }
 assert.equal(artifacts.inputVerification.status,'passed_for_derived_only_replay');
 assert(artifacts.coreReceipt.all397RetainedCarRowsByteEqual && artifacts.coreReceipt.all14ResearchFieldsByteEqual && artifacts.coreReceipt.allOriginalObjectsUnchanged && artifacts.coreReceipt.allNonPolestarCarValuesEqual);
 assert.equal(artifacts.coreReceipt.inputVerificationSha256,manifest.inputVerification.sha256);
 assert.equal(artifacts.coreReceipt.storageIndexSha256,manifest.storageIndex.sha256);
 assert.equal(artifacts.actualPackReceipt.status,'passed');assert.equal(artifacts.actualPackReceipt.actualPolestarPacks,14);assert.equal(artifacts.actualPackReceipt.originalSubaruFeatureRows,621);assert(artifacts.actualPackReceipt.actualPortableExact && artifacts.actualPackReceipt.fullResearchAndSelectedCarsUnchanged);
 assert.equal(artifacts.actualPackReceipt.coreReceiptSha256,manifest.coreReceipt.sha256);
 const verify=()=>{
  assert.equal(fileHash(file),manifestSha256,'Added phase manifest unchanged');
  for(const key of ['inputVerification','coreReceipt','storageIndex','actualPackReceipt'])assert.equal(fileHash(boundedProofPath(manifest[key].file)),manifest[key].sha256,'Added phase artifact unchanged: '+key);
  for(const row of manifest.scriptPins)assert.equal(fileHash(boundedProofPath(row.file)),row.sha256,'Added phase script changed: '+row.file);
  verifyPins(artifacts.inputVerification);
 };
 verify();return {...artifacts,manifest,manifestSha256,verify};
}
export function writeExclusive(name,value){const file=boundedProofPath(name);assert(!fs.existsSync(file),'Never overwrite a completed additional proof artifact: '+name);fs.writeFileSync(file,JSON.stringify(value,null,2)+'\n',{flag:'wx'});return {file:name,sha256:fileHash(file)}}
