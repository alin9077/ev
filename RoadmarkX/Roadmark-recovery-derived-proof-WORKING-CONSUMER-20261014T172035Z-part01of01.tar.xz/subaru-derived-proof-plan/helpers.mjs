import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {StandardRowUtf8Buffer} from '/workspace/scratch/586427eef9f2/roadmark-104-qa/catalogue-snapshot-reuse/standard-row-utf8-buffer.mjs';
export const roots={repo:'/workspace/scratch/586427eef9f2/roadmark-104',qa:'/workspace/scratch/586427eef9f2/roadmark-104-qa',research:'/tmp/subaru-research',polestar:'/tmp/polestar-research',proof:'/tmp/subaru-derived-proof-plan'};
const buffer=new StandardRowUtf8Buffer();
export const readJson=(file)=>JSON.parse(fs.readFileSync(file,'utf8'));
export function fileHash(file){const h=crypto.createHash('sha256'),b=Buffer.alloc(262144),fd=fs.openSync(file,'r');try{let n;while((n=fs.readSync(fd,b,0,b.length,null))>0)h.update(b.subarray(0,n));}finally{fs.closeSync(fd)}return h.digest('hex')}
export function locate(row){assert(Object.hasOwn(roots,row.anchor));const file=path.resolve(roots[row.anchor],row.file);assert(file.startsWith(roots[row.anchor]+'/'),'Storage locator leaves its explicit anchor');return file}
export function verifyPins(pins){for(const row of pins.executionInputs)assert.equal(fileHash(row.path),row.sha256,'Pinned input changed: '+row.path)}
export function digestRows(rows){const h=crypto.createHash('sha256');let bytes=0;for(const row of rows){const b=buffer.encode(JSON.stringify(row)+'\n');h.update(b);bytes+=b.length}return{rows:rows.length,bytes,sha256:h.digest('hex')}}
export async function readRows(file){const rows=[];for await(const line of readline.createInterface({input:fs.createReadStream(file),crlfDelay:Infinity})){assert(line.length>0,'No omitted blank rows');rows.push(JSON.parse(line))}return rows}
export async function compareRows(file,values){const h=crypto.createHash('sha256');let rows=0,bytes=0;for await(const line of readline.createInterface({input:fs.createReadStream(file),crlfDelay:Infinity})){assert(rows<values.length,'Extra retained row: '+file);const text=JSON.stringify(values[rows])+'\n';assert.equal(line+'\n',text,'Complete retained row mismatch: '+file+' #'+rows);const b=buffer.encode(text);h.update(b);bytes+=b.length;rows++;if(rows%50===0)global.gc?.()}assert.equal(rows,values.length,'Missing retained rows: '+file);assert.equal(bytes,fs.statSync(file).size,'Exact complete file bytes');const sha256=h.digest('hex');assert.equal(fileHash(file),sha256,'Exact whole retained file digest');return{rows,bytes,sha256}}
export async function readResearch(index){const data={};for(const[key,row]of Object.entries(index.research)){const file=locate(row);assert.equal(fileHash(file),row.sha256);const list=await readRows(file);assert.equal(list.length,row.rows);assert(row.array||list.length===1);data[key]=row.array?list:list[0]}return data}
export function writeNew(name,value){const file=path.join(roots.proof,name);assert(!fs.existsSync(file),'Do not overwrite completed proof artifact: '+name);fs.writeFileSync(file,JSON.stringify(value,null,2)+'\n',{flag:'wx'});return{file,sha256:fileHash(file)}}
