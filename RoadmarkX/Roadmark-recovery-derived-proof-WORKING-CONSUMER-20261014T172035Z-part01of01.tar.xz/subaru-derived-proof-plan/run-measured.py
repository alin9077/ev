import os,sys,pathlib,json,time,datetime,subprocess
root=pathlib.Path('/tmp/subaru-derived-proof-plan');name=sys.argv[1];command=sys.argv[2:]
assert name and '/' not in name and command
out=root/name;out.mkdir(exist_ok=False)
started=time.time();started_iso=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/'stdout.log').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
 p=subprocess.Popen(command,stdout=stdout,stderr=stderr)
 _,status,usage=os.wait4(p.pid,0);code=os.waitstatus_to_exitcode(status);p.returncode=code
result={'command':command,'returncode':code,'signal':-code if code<0 else None,'startedAt':started_iso,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsedSeconds':time.time()-started,'maxRssKiB':usage.ru_maxrss,'userSeconds':usage.ru_utime,'systemSeconds':usage.ru_stime,'inheritedNodeOptions':os.environ.get('NODE_OPTIONS'),'mode':'Derived-only proof; no fresh catalogue hydration or registration'}
(out/'terminal.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));sys.exit(0 if code==0 else 1)
