/** Full-value derived oracle only. No data.ts import or fresh catalogue hydration. */
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {prepareBrandResearch,applyBrandUpdates} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-updates.ts';
import {roots,readJson,fileHash,verifyPins,digestRows,readRows,compareRows,writeNew} from './helpers.mjs';
const pins=readJson(roots.proof+'/input-verification.json');
assert.equal(pins.status,'passed_for_derived_only_replay');verifyPins(pins);
assert.equal(typeof global.gc,'function');global.gc();
console.log('Core-only imports ready',process.memoryUsage());
const priorIndex=readJson(roots.polestar+'/replay-snapshot-index.json');let rd:any={};
for(const[key,row]of Object.entries(priorIndex.research) as any){const list=await readRows(roots.polestar+'/'+row.file);assert(row.array||list.length===1);rd[key]=row.array?list:list[0]}
let before:any=await readRows(roots.polestar+'/'+priorIndex.cars);assert.equal(before.length,395);
const originalFields=Object.keys(rd),originalResearchHashes=Object.fromEntries(Object.entries(rd).map(([k,v])=>[k,digestRows(Array.isArray(v)?v:[v])]));
const beforeCarHashes=before.map((c:any)=>({id:c.id,brand:c.brand,...digestRows([c])}));
const packet=readJson(roots.polestar+'/polestar-2026-10-14.json');
assert.equal(packet.brand,'Polestar');assert.equal(fileHash(roots.repo+'/data/m1-brand-updates/polestar-2026-10-14.json'),fileHash(roots.polestar+'/polestar-2026-10-14.json'));
const registry=readJson(roots.repo+'/data/m1-brand-updates/registry.json');assert.equal(registry.packets.at(-1),'polestar-2026-10-14.json');assert(!registry.packets.some((name:string)=>name.startsWith('subaru-')));
const data=prepareBrandResearch(rd,[packet]),cars=applyBrandUpdates(before,data,[packet]);assert.equal(cars.length,397);
assert.equal(new Set(cars.map((c:any)=>c.id)).size,397);assert.deepEqual(Object.keys(rd),originalFields);
for(const[key,value]of Object.entries(rd))assert.deepEqual(digestRows(Array.isArray(value)?value:[value]),originalResearchHashes[key],'Original complete research unchanged: '+key);
for(let i=0;i<before.length;i++)assert.deepEqual({id:before[i].id,brand:before[i].brand,...digestRows([before[i]])},beforeCarHashes[i],'Original complete car unchanged');
const oldById=new Map(beforeCarHashes.map((row:any)=>[row.id,row])),carHashes:any[]=[];
for(const car of cars){const now=digestRows([car]),old:any=oldById.get(car.id);if(car.brand!=='Polestar'){assert(old);assert.equal(now.sha256,old.sha256,'Complete non-Polestar car equality: '+car.id);assert.equal(now.bytes,old.bytes)}carHashes.push({id:car.id,brand:car.brand,beforeSha256:old?.sha256??null,afterSha256:now.sha256,bytes:now.bytes})}
before=null;rd=null;global.gc();
console.log('All 397 derived cars and original object immutability checked; prior bindings released',process.memoryUsage());
const carStorage={anchor:'qa',file:'catalogue-snapshot-reuse/after448/cars.jsonl',...await compareRows(roots.qa+'/catalogue-snapshot-reuse/after448/cars.jsonl',cars)};
const index:any={schemaVersion:2,mode:'derived_only_retained_storage',asOf:'2026-10-15',timeZone:'Australia/Sydney',cars:carStorage,research:{}};
assert.equal(Object.keys(data).length,14);assert.deepEqual(Object.keys(data).sort(),Object.keys(priorIndex.research).sort());
for(const[key,value]of Object.entries(data)){const array=Array.isArray(value),file='capture-phased640-original/replay-snapshot/research-'+key+'.jsonl';index.research[key]={anchor:'research',file,array,...await compareRows(roots.research+'/'+file,array?value:[value])};console.log('Complete research equality',key,index.research[key].rows);global.gc()}
const tier1=(c:any)=>!c.vehicleClass||['passenger','ute'].includes(c.vehicleClass),subaru=cars.filter((c:any)=>c.brand==='Subaru'&&tier1(c)),polestar=cars.filter((c:any)=>c.brand==='Polestar'&&tier1(c));assert.equal(subaru.length,9);assert.equal(polestar.length,14);
const originals:any={'subaru-live-before.json':subaru,'subaru-source-before.json':data.sources,'subaru-models-before.json':data.models.filter((m:any)=>m.brand==='Subaru'),'subaru-variants-before.json':data.variants.filter((v:any)=>v.brand==='Subaru')};
const originalFiles=[];for(const[name,value]of Object.entries(originals)){const file=roots.research+'/capture-attempt640-original/'+name;assert.equal(JSON.stringify(value,null,2),fs.readFileSync(file,'utf8'),'Complete original file bytes: '+name);originalFiles.push({file,sha256:fileHash(file)})}
assert.deepEqual(JSON.parse(JSON.stringify(polestar)),readJson(roots.polestar+'/after.json'),'All approved Polestar car values');
verifyPins(pins);
writeNew('derived-storage-index.pending.json',index);
writeNew('core-oracle-receipt.json',{status:'phase1_passed_pending_actual_feature_and_pack_phase',mode:'Derived-only historical-chain equality, not fresh v2 hydration or final loader equivalence',asOf:'2026-10-15',inputVerificationSha256:fileHash(roots.proof+'/input-verification.json'),priorCars:395,currentCars:397,originalSubaruCars:9,proposedSubaruCars:11,polestarCars:14,all397RetainedCarRowsByteEqual:true,all14ResearchFieldsByteEqual:true,allOriginalObjectsUnchanged:true,allNonPolestarCarValuesEqual:true,allFourStructuralSubaruOriginalFilesByteEqual:true,allApprovedPolestarCarValuesEqual:true,originalFiles,carHashes,storageIndexSha256:fileHash(roots.proof+'/derived-storage-index.pending.json'),pending:['Full fifth original Subaru effective-feature file','Actual Polestar packs and portable parity','Complete actual-feature/report replay at both 2026-10-14 and 2026-10-15','Final input recheck and independent terminal acceptance'],releaseBlockers:['Fresh v2 full-value equivalence','Current full typecheck','Subaru final packet review and registration'],resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log('CORE ORACLE PASSED; derived baseline acceptance still pending phase 2');
