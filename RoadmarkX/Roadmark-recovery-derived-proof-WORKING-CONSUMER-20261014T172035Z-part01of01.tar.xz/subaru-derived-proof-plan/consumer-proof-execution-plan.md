# Proposed consumer proof execution sequence

Prepared only; waits for root's serialized slot release, successful focused boundary tests, independently reviewed exact source transition, and frozen consumer-phase-manifest.json. Each phase uses the actual newly separated production consumer with throwing fallback loaders and only explicit proven snapshots. No broad data.ts import or catalogue hydration occurs.

Working directory: /workspace/scratch/586427eef9f2/roadmark-104
Common wrapper: python3 /tmp/subaru-derived-proof-plan/run-measured.py <new-attempt-directory> node --max-old-space-size=320 --max-semi-space-size=1 --expose-gc --import tsx <phase-script>

1. actual-feature-pack-phase-consumer-v2.mjs
   New attempt directory: actual-feature-pack-consumer-v2-attempt1
   Requires the successful complete derived core receipt. Compare all 621 original Subaru feature rows and all 14 full approved Polestar packs, then exact portable round-trip. Recheck all 14 Research fields and every selected car. Report measured terminal result before continuing.
2. stream-baseline-effective-features-consumer-v2.mjs
   New attempt directory: complete-feature-stream-consumer-v2-attempt1
   Requires the successful prior actual-pack receipt and same manifest/source transition. Stream 397 actual feature sets (69 criteria each), exact original Subaru/approved Polestar feature checks, all per-car/Research immutability checks, full output hashes and complete counts/order. Report measured terminal result before continuing.
3. replay-complete-baseline-reports-consumer-v2.mjs
   New attempt directory: complete-report-replay-consumer-v2-attempt1
   Requires the successful actual feature receipt/index/file and prior pack receipt. Use all 397 full proven cars, all 3,432 sources and all 27,393 actual feature rows through the actual report loader/coverage builder. Compare the entire unchanged historical approved reports separately at 2026-10-14 and 2026-10-15; preserve complete outputs and hashes.

All original 747 lineage/execution pins, the original 15 composition pins, prior failures and accepted core outputs remain immutable. A separately reviewed source-transition manifest records exact retained-before and applied-after hashes for only approved source/test changes; no original expectations are replaced. All new helper, phase, review, focused-test and source-inventory artifacts are pinned before and after each phase.

Stop at any assertion failure or signal termination; preserve its terminal/log/partial outputs and ask root to reassess rather than automatically retry. The plan's 320 MiB heap is a bounded initial route, not a predicted resource limit or guaranteed completion. Do not infer the cause of a signal9 event.

A successful phase is not final baseline acceptance. Independent verification of all three measured successful terminals and exact receipt/input links is required before an accepted-derived-index can be written. Fresh full-loader equivalence, current complete TypeScript checking, normal top-level report execution and Subaru registration remain separate open gates.
