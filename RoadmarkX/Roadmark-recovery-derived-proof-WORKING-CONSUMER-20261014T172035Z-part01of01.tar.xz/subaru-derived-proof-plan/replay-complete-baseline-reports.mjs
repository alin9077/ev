/** Complete report inputs from proven full cars/sources and independently generated actual feature rows. */
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {roots,readJson,fileHash,locate,digestRows,readRows} from './helpers.mjs';
import {openReportPhaseInputs,writeExclusive,boundedProofPath} from './additional-report-phase-helpers.mjs';
assert.equal(process.cwd(),roots.repo,'Compile the exact actual report loader from the repo working directory');
const proof=openReportPhaseInputs(),index=proof.storageIndex;
const featureReceiptFile=boundedProofPath('baseline-effective-features-receipt.json'),featureReceipt=readJson(featureReceiptFile),featureReceiptHash=fileHash(featureReceiptFile);assert.equal(featureReceipt.status,'passed');assert.equal(featureReceipt.additionalPhaseManifestSha256,proof.manifestSha256);
const featureIndexFile=boundedProofPath(featureReceipt.index.file);assert.equal(fileHash(featureIndexFile),featureReceipt.index.sha256);const featureIndex=readJson(featureIndexFile);assert.equal(featureIndex.cars,397);assert.equal(featureIndex.features.rows,397*69);assert.equal(featureIndex.additionalPhaseManifestSha256,proof.manifestSha256);
assert.equal(typeof global.gc,'function');global.gc();
const carFile=locate(index.cars),sourceFile=locate(index.research.sources),featureFile=boundedProofPath(featureIndex.features.file);
for(const[file,sha]of [[carFile,index.cars.sha256],[sourceFile,index.research.sources.sha256],[featureFile,featureIndex.features.sha256]])assert.equal(fileHash(file),sha);
const cars=await readRows(carFile),sources=await readRows(sourceFile),features=await readRows(featureFile);assert.equal(cars.length,397);assert.equal(sources.length,index.research.sources.rows);assert.equal(features.length,397*69);
const byCar=new Map(),seen=new Set(),featureProofs=new Map(featureIndex.perCar.map(row=>[row.id,row]));
for(const feature of features){assert(featureProofs.has(feature.variant_id));const rows=byCar.get(feature.variant_id)||[];rows.push(feature);byCar.set(feature.variant_id,rows);}
assert.equal(byCar.size,397);assert.equal(featureProofs.size,397);
function verifiedFeatures(car){const p=featureProofs.get(car.id),rows=byCar.get(car.id);assert(p&&rows);const cd=digestRows([car]),fd=digestRows(rows);assert.equal(cd.sha256,p.carSha256);assert.equal(cd.bytes,p.carBytes);assert.equal(fd.sha256,p.featureSha256);assert.equal(fd.bytes,p.featureBytes);assert.equal(fd.rows,p.featureRows);return rows;}
for(const car of cars){assert(!seen.has(car.id));seen.add(car.id);verifiedFeatures(car);}
assert.equal(digestRows(cars).sha256,index.cars.sha256);assert.deepEqual(digestRows(sources),{rows:index.research.sources.rows,bytes:index.research.sources.bytes,sha256:index.research.sources.sha256});assert.deepEqual(digestRows(features),{rows:featureIndex.features.rows,bytes:featureIndex.features.bytes,sha256:featureIndex.features.sha256});global.gc();
const require=createRequire(roots.repo+'/package.json');
const {compiledSource}=require(roots.repo+'/tests/helpers/compiled-source.ts');
const {buildCoverageReport}=require(roots.repo+'/scripts/reporting/reports.ts');
// ReportInput consumes sources, not the other research fields. All 14 fields were separately proved and rechecked in the actual feature phase.
// This override supplies the exact validated effectiveFeatures outputs rather than importing catalogue-construction globals.
const loader=compiledSource('scripts/reporting/load.ts',{'../../src/lib/data':{catalogueSnapshot:()=>{throw new Error('Fresh hydration is not permitted in this derived report phase')},effectiveFeatures:(car,data)=>{assert.equal(data.sources,sources);return verifiedFeatures(car)}}});
const input=loader.loadReportInput({data:{sources},cars});assert.equal(input.cars,cars);assert.equal(input.sources,sources);assert.deepEqual(input.features,features);global.gc();
const results=[];
for(const[asOf,expected]of [['2026-10-14',roots.polestar+'/staged-report.json'],['2026-10-15',roots.qa+'/polestar-sequential-checks/coverage.stdout']]){
 const report=buildCoverageReport(input,asOf);assert.deepEqual(JSON.parse(JSON.stringify(report)),readJson(expected),'Complete exact report equality: '+asOf);
 const output=writeExclusive('baseline-complete-report-'+asOf+'.json',report);results.push({asOf,expected,expectedSha256:fileHash(expected),output});console.log('Complete report exact equality passed',asOf);global.gc();
}
for(const car of cars)verifiedFeatures(car);assert.equal(digestRows(cars).sha256,index.cars.sha256);assert.equal(digestRows(sources).sha256,index.research.sources.sha256);assert.equal(digestRows(input.features).sha256,featureIndex.features.sha256);
assert.equal(fileHash(featureReceiptFile),featureReceiptHash);assert.equal(fileHash(featureIndexFile),featureReceipt.index.sha256);assert.equal(fileHash(featureFile),featureIndex.features.sha256);proof.verify();
writeExclusive('baseline-complete-report-receipt.json',{status:'passed',mode:'Complete derived-only reports using every proven car/source and all actual effectiveFeatures rows; no fresh hydration',cars:397,features:397*69,sources:sources.length,dates:['2026-10-14','2026-10-15'],results,allReportInputsComplete:true,allInputObjectsUnchanged:true,actualReportLoaderUsed:true,actualCoverageBuilderUsed:true,actualFeaturesProvidedFromIndependentFullPopulationStream:true,featureReceiptSha256:featureReceiptHash,additionalPhaseManifestSha256:proof.manifestSha256,finalIndependentAcceptanceStillRequired:true,openGates:['Fresh v2 complete hydration/equality not established','Current full TypeScript check not passed','Subaru staging and registration not accepted'],resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log('Complete derived-only report proof passed; reviewer must accept all phase receipts before canonical staging');
