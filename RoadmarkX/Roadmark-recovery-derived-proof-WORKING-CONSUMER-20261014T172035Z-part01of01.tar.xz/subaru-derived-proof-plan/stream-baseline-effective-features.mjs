/** Actual effectiveFeatures for every proven baseline car, retaining only one car at a time. */
import fs from 'node:fs';
import readline from 'node:readline';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {roots,readJson,fileHash,locate,digestRows,readResearch} from './helpers.mjs';
import {openReportPhaseInputs,writeExclusive,boundedProofPath} from './additional-report-phase-helpers.mjs';
import {StandardRowUtf8Buffer} from '/workspace/scratch/586427eef9f2/roadmark-104-qa/catalogue-snapshot-reuse/standard-row-utf8-buffer.mjs';
const proof=openReportPhaseInputs(),index=proof.storageIndex,core=proof.coreReceipt;
const require=createRequire(roots.repo+'/src/lib/data.ts');const {effectiveFeatures}=require('./data.ts');
assert.equal(typeof global.gc,'function');global.gc();console.log('Actual feature module imported and collected',process.memoryUsage());
const data=await readResearch(index);assert.equal(Object.keys(data).length,14);global.gc();
const carFile=locate(index.cars);assert.equal(fileHash(carFile),index.cars.sha256);assert.equal(index.cars.rows,397);
const coreCars=new Map(core.carHashes.map(row=>[row.id,row]));assert.equal(coreCars.size,397);
const approvedPolestar=readJson(roots.polestar+'/staged-packs.json'),originalSubaru=readJson(roots.research+'/capture-attempt640-original/subaru-feature-before.json');
const outputName='baseline-effective-features.jsonl',output=boundedProofPath(outputName);assert(!fs.existsSync(output));
const fd=fs.openSync(output,'wx'),buffer=new StandardRowUtf8Buffer(),aggregate=crypto.createHash('sha256');
const perCar=[],ids=new Set();let totalRows=0,totalBytes=0,matchedPolestar=0,matchedSubaru=0;
try{
 for await(const line of readline.createInterface({input:fs.createReadStream(carFile),crlfDelay:Infinity})){
  assert(line.length>0);const car=JSON.parse(line),before=digestRows([car]),expected=coreCars.get(car.id);assert(expected);assert.equal(before.sha256,expected.afterSha256);assert.equal(before.bytes,expected.bytes);assert(!ids.has(car.id));ids.add(car.id);
  const features=effectiveFeatures(car,data);assert.equal(features.length,69);assert.equal(new Set(features.map(f=>f.criterion)).size,69);assert(features.every(f=>f.variant_id===car.id));
  if(approvedPolestar[car.id]){assert.deepEqual(JSON.parse(JSON.stringify(features)),approvedPolestar[car.id].features,'Full approved Polestar feature rows: '+car.id);matchedPolestar++;}
  if(car.brand==='Subaru'){assert.deepEqual(JSON.parse(JSON.stringify(features)),originalSubaru.filter(f=>f.variant_id===car.id),'Full original Subaru feature rows: '+car.id);matchedSubaru++;}
  const hash=crypto.createHash('sha256');let bytes=0;
  for(const feature of features){const row=buffer.encode(JSON.stringify(feature)+'\n');let written=0;while(written<row.length){const n=fs.writeSync(fd,row,written,row.length-written);assert(n>0,'Full synchronous write must advance');written+=n;}aggregate.update(row);hash.update(row);bytes+=row.length;totalBytes+=row.length;totalRows++;}
  assert.deepEqual(digestRows([car]),before,'Actual feature calculation did not mutate complete car');
  perCar.push({id:car.id,carSha256:before.sha256,carBytes:before.bytes,featureRows:features.length,featureBytes:bytes,featureSha256:hash.digest('hex')});
  if(perCar.length%25===0){global.gc();console.log('Complete feature sets written',perCar.length,process.memoryUsage());}
 }
}finally{fs.closeSync(fd)}
assert.equal(perCar.length,397);assert.equal(ids.size,397);assert.equal(totalRows,397*69);assert.equal(matchedPolestar,14);assert.equal(matchedSubaru,9);
const sha256=aggregate.digest('hex');assert.equal(fileHash(output),sha256);assert.equal(fs.statSync(output).size,totalBytes);
assert.deepEqual(Object.keys(data).sort(),Object.keys(index.research).sort());
for(const[key,value]of Object.entries(data)){const d=digestRows(Array.isArray(value)?value:[value]),expected=index.research[key];assert.equal(d.sha256,expected.sha256,'Full research field unchanged: '+key);assert.equal(d.rows,expected.rows);assert.equal(d.bytes,expected.bytes);global.gc();}
assert.equal(fileHash(carFile),index.cars.sha256);proof.verify();
const featureIndex=writeExclusive('baseline-effective-features-index.json',{schemaVersion:1,mode:'Actual full-population effectiveFeatures stream on derived-only baseline',asOf:'2026-10-15',cars:397,features:{file:outputName,rows:totalRows,bytes:totalBytes,sha256},perCar,originalSubaruRowsMatched:621,approvedPolestarPacksMatched:14,additionalPhaseManifestSha256:proof.manifestSha256,coreReceiptSha256:proof.manifest.coreReceipt.sha256,actualPackReceiptSha256:proof.manifest.actualPackReceipt.sha256});
writeExclusive('baseline-effective-features-receipt.json',{status:'passed',mode:'Actual complete feature stream; no fresh catalogue hydration',cars:397,featureRows:totalRows,allCompleteCarHashesVerified:true,all14ResearchFieldsUnchanged:true,fullOriginalSubaruFeaturesEqual:true,allApprovedPolestarFeaturesEqual:true,inputHashesRechecked:true,index:featureIndex,additionalPhaseManifestSha256:proof.manifestSha256,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log('Complete 397-car actual feature stream passed; full dated report replay remains pending');
