# Reviewed derived-only composition rule v2

This is a versioned reconstruction rule, not a change to production or an assertion that a fresh loader completed. The original core-oracle.mts and failed core-oracle-attempt1 remain unchanged.

Let P be the complete, ordered 16-packet registry captured before Polestar, Q the final single Polestar packet, and F(S, packets) the unchanged production prepareBrandResearch function. The retained prior Research value is F(S,P). The actual call F(F(S,P),Q) is retained as the single-packet result. The derived complete-registry value changes only that result's metadata.brand_update_packet_ids to the exact production expression packets.map(packet => packet.id), evaluated over the independently pinned P+Q registry.

Code-level basis in src/lib/brand-updates.ts:
- orderedPackets validates individual packets, unique IDs and nondecreasing reviewed dates. The full registry must additionally be checked for both cross-boundary conditions; prior IDs must exactly equal its 16-entry prefix and Q must be its exact final approved packet.
- Each packet's state transformation runs in order and reads the accumulated models, variants, sources and criteria. The loop does not read metadata. Splitting the same sequence at the final packet preserves its accumulated state.
- feature_evidence_variant_context is projected to the same ordered id, model_id, record_state and optional configuration_evidence keys. Reapplying that projection to an already projected context is idempotent. The actual retained prior context is checked against this projection, with no normalization of expected values.
- added_variant_count and added_feature_row_count increment by the respective row-length deltas. For the independently checked nonnegative safe integer counts/lengths here, consecutive increments telescope to the full-registry increment without numeric rounding.
- brand_update_packet_ids is the only noncumulative invocation-scoped assignment. It is assigned after the loop and is not consumed by that loop. Its complete-registry value is obtained from the actual registered packet JSONs, never copied from expected retained metadata.
- All remaining fields are copied or transformed by the identical ordered packet loop. This argument does not substitute for comparison: every complete retained Research field, including the entire metadata object and feature context, must still match exact JSONL bytes and hashes.

Runtime safeguards:
1. Recheck all 747 original lineage/execution pins plus the versioned proof, new script, and independent review receipt before and after execution.
2. Require exact current registry = prior registry plus final Polestar; exact prior metadata IDs = all prior packet IDs; unique full IDs; chronological full dates; actual final registered packet bytes = independently approved packet bytes. Keep no Subaru registration. Parse each pinned full packet separately and retain only its id/reviewedAt header; the full final registered-versus-approved byte hash check remains mandatory. Release each temporary packet before the next.
3. Require the unchanged full production function bytes to contain the exact invocation-scoped assignment. Pin that whole file and record its hash.
4. Preserve the full actual single-packet metadata JSONL before deriving the complete-registry ID field. Record complete raw Research field digests. Assert all nonmetadata fields are the same values/references and every other metadata property and property order is unchanged. Recheck the complete raw result after car application.
5. Compare all 397 full cars, every non-Polestar car, all 14 complete Research fields, four structural Subaru original files and all approved Polestar cars. Use unchanged retained expectation bytes, standard JSON.stringify and the proven UTF-8 buffer. Do not ignore, filter or relabel a mismatch.
6. Only after all comparisons succeed, produce a reconstructible index for the raw single-packet result: existing exact retained files for unchanged fields and the preserved raw metadata file. The accepted-derived index remains pending the actual feature/pack and both complete dated report phases.

Known boundaries: no complete retained pre-prepare sourceResearch snapshot was found in the inspected full replay/source-snapshot inventories. The first failed composition compared all 397 car rows but stopped at metadata, so later Research field equality remains unproved until this version succeeds. Fresh v2 loader equivalence and current full TypeScript checking remain open release gates.
