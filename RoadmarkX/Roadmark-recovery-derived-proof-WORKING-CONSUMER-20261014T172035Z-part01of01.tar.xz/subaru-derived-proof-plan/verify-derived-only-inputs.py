"""Serialized, bounded-memory preflight for the explicit Polestar-to-Subaru chain.
Derived-only input proof. Successful fresh hydration is explicitly not required or claimed.
This preparation cannot authorize a run; root controls the serialized heavy slot.
Exact reviewed transition files are fixed below. Static approval does not claim dynamic equivalence.
"""
import pathlib,json,hashlib,difflib,datetime
W=pathlib.Path('/tmp/subaru-derived-proof-plan');R=pathlib.Path('/tmp/subaru-research');P=pathlib.Path('/tmp/polestar-research');repo=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104');Q=repo.parent/'roadmark-104-qa/polestar-sequential-checks';L=repo.parent/'roadmark-104-qa/catalogue-snapshot-reuse'
buffer=bytearray(1024*1024);view=memoryview(buffer)
def sha(path):
 h=hashlib.sha256()
 with pathlib.Path(path).open('rb') as f:
  while n:=f.readinto(buffer):h.update(view[:n])
 return h.hexdigest()
prior=json.load((P/'replay-provenance-manifest.json').open());verification=[];inputs={};differences=[]
def retain(path):
 path=pathlib.Path(path);digest=sha(path);inputs[str(path)]=dict(path=str(path),sha256=digest,bytes=path.stat().st_size);return digest
retain(P/'replay-provenance-manifest.json')
for row in prior['snapshot']:
 assert retain(P/row['file'])==row['sha256'],('Immutable pre-Polestar snapshot',row['file'])
retain(P/'replay-snapshot-index.json')
patchPath=L/'changed-files.json';patch=json.load(patchPath.open());retain(patchPath)
static=json.load((L/'independent-static-review.json').open());assert static['status']=='passed';retain(L/'independent-static-review.json')
changes={r['file']:dict(file=r['file'],before=r['beforeSha256'],after=r['afterSha256']) for r in patch['files']};assert len(changes)==len(patch['files'])
assert set(changes)=={'src/lib/data.ts','scripts/reporting/load.ts','scripts/validate.ts','tests/catalogue-snapshot.test.ts'}
assert sorted(static['productionFiles'])==sorted(f for f in changes if not f.startswith('tests/'))
for file,row in changes.items():
 if row['before'] is not None:assert retain(L/'before'/file)==row['before'],('Original loader source retained byte-exact',file)
assert retain(R/'pre-loader-fix-source/data.ts')==changes['src/lib/data.ts']['before']
# Preserve the reviewed original -> v1 -> v2 loader lineage, never reset the parent hash.
v2Path=L/'v2-changed-files.json';v2=json.load(v2Path.open());retain(v2Path)
v2review=json.load((L/'independent-v2-static-review.json').open());assert v2review['status']=='passed';retain(L/'independent-v2-static-review.json')
assert {r['file'] for r in v2['files']}==set(changes)
for row in v2['files']:
 c=changes[row['file']];assert c['before']==row['originalSha256'] and c['after']==row['v1Sha256']
 assert retain(L/'v1'/row['file'])==row['v1Sha256']
 c['v1']=c['after'];c['after']=row['v2Sha256']
v1Inputs=json.load((L/'v1-inputs-before-v2.json').open());v2Inputs=json.load((L/'v2-source-freeze-inputs.json').open());retain(L/'v1-inputs-before-v2.json');retain(L/'v2-source-freeze-inputs.json')
v1Map={r['file']:r for r in v1Inputs['files']};v2Map={r['file']:r for r in v2Inputs['files']};assert set(v1Map)==set(v2Map)
assert {f for f in v1Map if v1Map[f]['sha256']!=v2Map[f]['sha256']}=={'src/lib/data.ts','tests/catalogue-snapshot.test.ts'}
for file,row in v2Map.items():assert retain(repo/file)==row['sha256'],('Full frozen v2 source input',file)
for file in ['v1/changed-files.json','v1-to-v2-data.patch','v1-to-v2-tests.patch','v2-focused-test.log','v2-focused-lint.log','v2-typecheck.log','v2-typecheck.exit']:retain(L/file)
oldChanges={r['file']:r for r in json.load((R/'prior-polestar-code-differences.json').open())};retain(R/'prior-polestar-code-differences.json')
for row in prior['sourceCode']:
 file=row['file'];expected=row['sha256'];current=retain(repo/file)
 if file in oldChanges:
  assert oldChanges[file]['before']==expected
  before=Q/('registry.json.before' if file.endswith('registry.json') else 'load.ts.before');assert retain(before)==expected
  expected=oldChanges[file]['now']
 if file in changes:
  assert changes[file]['before']==expected,('Loader patch starts at exact integrated Polestar source',file)
  expected=changes[file]['after']
 assert current==expected,('Unreviewed source change',file,current,expected)
 if current!=row['sha256']:differences.append(dict(file=file,before=row['sha256'],after=current,chain=['final approved Polestar registration']*(file in oldChanges)+['statically reviewed original-to-v1 loader patch','statically reviewed v1-to-v2 request-cache refinement']*(file in changes)))
 known={r['file'] for r in prior['sourceCode']}
for file,row in changes.items():
 if file not in known:
  assert row['before'] is None,('Unexpected new-file parent',file)
  assert retain(repo/file)==row['after']
# Compare integration semantic bridge against retained pre-registration originals.
oldRegistry=json.load((Q/'registry.json.before').open());newRegistry=json.load((R/'pre-loader-fix-source/registry.json').open());assert newRegistry=={**oldRegistry,'packets':oldRegistry['packets']+['polestar-2026-10-14.json']}
assert retain(R/'pre-loader-fix-source/registry.json')==oldChanges['data/m1-brand-updates/registry.json']['now']
oldLoad=(Q/'load.ts.before').read_text();integratedLoad=(R/'pre-loader-fix-source/load.ts').read_text();expectedLoad=oldLoad.replace('import cheryReconciliation from "../../data/m1-chery-market-reconciliation-2026-10-14.json";','import cheryReconciliation from "../../data/m1-chery-market-reconciliation-2026-10-14.json";\nimport polestarReconciliation from "../../data/m1-polestar-market-reconciliation-2026-10-14.json";').replace('      cheryReconciliation as M1MarketReconciliation,','      cheryReconciliation as M1MarketReconciliation,\n      polestarReconciliation as M1MarketReconciliation,');assert integratedLoad==expectedLoad
assert retain(R/'pre-loader-fix-source/load.ts')==oldChanges['scripts/reporting/load.ts']['now']
# Documented versioned extension for seven .mjs files omitted by the original manifest.
extensionPath=R/'source-manifest-extension-mjs.json';extension=json.load(extensionPath.open());retain(extensionPath)
retain(extension['prePolestarWholeSourceManifest']);retain(extension['postPolestarWholeSourceManifest'])
preCapture=json.load(open(extension['prePolestarWholeSourceManifest']));postCapture=json.load(open(extension['postPolestarWholeSourceManifest']))
preCaptureRows={r['path']:r for r in preCapture['files']};postCaptureRows={r['path']:r for r in postCapture['files']}
for row in extension['rows']:
 file=row['file'];assert file not in known and file.endswith('.mjs')
 assert row['prePolestarRecord']==preCaptureRows[file] and row['postPolestarRecord']==postCaptureRows[file]
 assert preCaptureRows[file]['originalSHA256']==preCaptureRows[file]['sha256']==postCaptureRows[file]['originalSHA256']==postCaptureRows[file]['sha256']==row['sha256']
 assert pathlib.Path(row['prePolestarCaptureFile'])==pathlib.Path(preCapture['stagingSource'])/file and pathlib.Path(row['postPolestarCaptureFile'])==pathlib.Path(postCapture['stagingSource'])/file
 assert retain(row['prePolestarCaptureFile'])==retain(row['postPolestarCaptureFile'])==retain(repo/file)==row['sha256'],('Historical omitted .mjs equality',file)
 known.add(file)
assert len(extension['rows'])==7
# No other data/src/scripts/tests code files may appear without explicit receipt.
allCurrent={str(p.relative_to(repo)) for root in ['data','src','scripts','tests'] for p in (repo/root).rglob('*') if p.is_file() and p.suffix in ['.json','.ts','.tsx','.js','.mjs','.cjs']}
newPolestar={'data/m1-brand-updates/polestar-2026-10-14.json','data/m1-polestar-market-reconciliation-2026-10-14.json'}
assert allCurrent-known==newPolestar|{f for f in changes if f not in known},('Unexpected added source/code files',sorted(allCurrent-known))
assert known-allCurrent==set(),('Missing prior source/code files',sorted(known-allCurrent))
for local,registered in [('polestar-2026-10-14.json','data/m1-brand-updates/polestar-2026-10-14.json'),('polestar-reconciliation-2026-10-14.json','data/m1-polestar-market-reconciliation-2026-10-14.json')]:assert retain(P/local)==retain(repo/registered),('Approved final artifact differs',local)
for file in ['staged-packs.json','after.json','features-after.json','staged-report.json','canonical-baseline-meta.json','canonical-baseline-meta-v2.json','canonical-packet-at-baseline.json','canonical-amendment-proof.json','new-feature-before.json','new-feature-before-v2.json','new-feature-before-manifest.json']:retain(P/file)
for file in ['coverage.stdout','coverage-asof-2026-10-14.stdout']:retain(Q/file)
assert json.load((P/'staged-report.json').open())==json.load((Q/'coverage-asof-2026-10-14.stdout').open())
assert json.load((Q/'coverage.stdout').open())['asOf']=='2026-10-15'
for p in sorted((R/'capture-phased640-original/replay-snapshot').glob('research-*.jsonl')):retain(p)
for file in ['subaru-live-before.json','subaru-source-before.json','subaru-feature-before.json','subaru-models-before.json','subaru-variants-before.json']:retain(R/'capture-attempt640-original'/file)
# Preserve incomplete fresh capture honestly; its complete car file is independently proved later.
for p in sorted((L/'after448').glob('*')):
 if p.is_file():retain(p)
for file in ['after448.log','after448.exit','after448-measurement.json','capture.mjs','before-data.cjs','run-measured.py','data-before.sha256','original-before.sha256','data.patch','reporting.patch','validate.patch','focused-test.log','focused-lint.log','root-validation.metrics.json','root-validation.stdout','root-validation.stderr']:retain(L/file)
assert json.load((L/'after448-measurement.json').open())['returncode']==-9
for line in (L/'data-before.sha256').read_text().splitlines():
 expected,file=line.split('  ',1);assert retain(repo/file)==expected,('Full immutable data input hash',file)
for line in (L/'original-before.sha256').read_text().splitlines():
 expected,file=line.split('  ',1);assert retain(repo/'data'/file)==expected,('Original full source input hash',file)
# No successful fresh v2 phase exists. It is an explicit unresolved gate, never a fabricated input.
# Every failed full-export artifact remains immutable historical evidence, not an accepted capture.
failedHistory=[]
for directory in ['after','after448','v2-fresh-cars','v2-fresh-cars-gc50','v2-fresh-cars-gc50-416','v2-fresh-car-digests','v2-fresh-car-digests-buffer']:
 d=L/directory;assert d.is_dir(),('Missing preserved failed export',directory)
 paths=[]
 for f in sorted(d.rglob('*')):
  if f.is_file():retain(f);paths.append(str(f))
 failedHistory.append(dict(directory=str(d),files=paths,acceptedAsSuccessfulCapture=False))
for file in ['after.log','after.exit','after-measurement.json','capture-split.mjs','run-split.py','capture-split-gc50.mjs','run-split-gc50.py','run-split-gc50-416.py','digest-backed-proof-plan.md','capture-digests-gc50.mjs','run-digests-gc50.py','capture-digests-buffer.mjs','run-digests-buffer.py','standard-row-utf8-buffer.mjs','verify-row-buffer-equivalence.mjs','row-buffer-equivalence.json','row-buffer-equivalence.log','row-buffer-equivalence.exit','row-buffer-equivalence-measurement.json']:retain(L/file)
for directory in ['capture-attempt640-original','capture-phased640-original']:
 for f in sorted((R/directory).rglob('*')):
  if f.is_file():retain(f)
for prefix in ['capture-before704','capture-before640','capture-before-phased640','capture-before-phased640-v2']:
 for suffix in ['.log','.exit','-resource-usage.json']:retain(R/(prefix+suffix))
for file in ['capture-before.ts','capture-before-phased-first.ts','capture-before-phased.ts']:retain(R/file)
for file in ['package.json','pnpm-lock.yaml','tsconfig.json']:
 if (repo/file).exists():retain(repo/file)
for file in ['derive-before-v1.ts','read-replay-snapshot.ts','verify-derivation-inputs.py','verify-derivation-inputs-v2.py','verify-derivation-inputs-v3.py']:retain(R/file)
retain(pathlib.Path('/tmp/subaru-independent-review/capture-research-phase.mjs'))
retain(pathlib.Path('/tmp/subaru-independent-review/derive-before-v2.ts'))
retain(pathlib.Path('/tmp/subaru-independent-review/derive-before-v3.ts'))
retain(W/'verify-derived-only-inputs.py')
# Phase scripts will be pinned explicitly after reviewer finalizes them; no run until supplied.
phasePins=json.load((W/'reviewed-phase-script-list.json').open());retain(W/'reviewed-phase-script-list.json')
assert phasePins['executionMode']=='derived-only'
for file in phasePins['files']:retain(W/file)
out=dict(status='passed_for_derived_only_replay',checkedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),mode='Derived-only snapshot lineage input preflight; no fresh v2 hydration claim',acceptedBaseline=False,allowedScope='Input verification and independent derived replay only; no registry integration or live publication',openGates=['Fresh v2 complete hydration/equality not established','Current full TypeScript check not passed','Subaru canonical fixture/staging/registration not accepted'],priorCompleteSnapshotFiles=len(prior['snapshot']),priorSourceCodeFiles=len(prior['sourceCode']),historicallyPinnedOmittedMjsFiles=len(extension['rows']),sourceCodeDifferences=differences,onlyPolestarIntegrationAndStaticallyReviewedLoaderPatch=True,loaderDynamicEquivalenceStillRequired=True,loaderLineage='original -> v1 -> v2, all original/v1 bytes retained',successfulFreshV2DigestPhases=[],freshFullValueEqualityStillPending=True,preservedFailedProductionCaptureAttempts=failedHistory,fullV2InputCount=len(v2Map),incompleteFreshCapture='after448 exited -9; complete cars and partial research retained, no successful full fresh baseline claimed',priorSnapshotComplete=True,finalRegisteredPolestarByteEqualApproved=True,reportDatesSeparate=['2026-10-14','2026-10-15'],executionInputs=list(inputs.values()),repeatAllInputHashesAtEndRequired=True)
(W/'input-verification.json').write_text(json.dumps(out,indent=2));print('Verified',len(inputs),'execution inputs')
