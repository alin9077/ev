# Independent acceptance plan for a proposed evidence-consumer boundary

Status: review requirements only. No source application or broad data.ts run is authorized by this document. The accepted core receipt remains a derived-only historical value proof; it is not a fresh-loader pass.

## Static boundary
- Pin the complete current v2 source before any application. Preserve its exact data.ts and all changed test originals, and record only the independently approved file transition. Do not reset any historical manifest or expected baseline.
- Compare exact function bodies, default parameter expressions, formatting helpers, feature index construction and shared warning logic before/after movement. Catalogue source builder body and cache wrappers must remain byte-identical.
- Audit all runtime imports of the new module and every production dependency for a path back to data.ts. Type-only references must erase. The consumer module must not load catalogue additions, buyer summary/identity ledgers or retained fact-fill ledgers.
- Ensure the factory creates no React cache and invokes no loader callback during creation. Bind once after existing catalogue/research callbacks initialize. Disclose function declaration to exported-const effects on TDZ, stack locations and Function.toString; audit all import-time call sites and cycles.
- Confirm tests/helpers/compiled-source.ts overrides remain effective at the new boundary. Existing fixture callers must explicitly compile the new module with the same overrides and inject it into their data.ts compilation. Keep all current assertions and malformed-source rejection tests.

## Focused behavior checks
1. sourceEffectiveFeatures without data calls sourceResearch exactly once. Supplying data calls no loader.
2. effectiveFeatures without data calls research exactly once; its inner source-feature calculation receives that exact object and never calls sourceResearch. Supplying data calls neither loader.
3. pack without snapshot resolves research then catalogue in the original order. Explicit complete snapshots call neither. Unknown IDs and malformed source references throw the identical messages before publishing a pack.
4. Repeated factory creation and calls neither mutate imported overlays nor add a cache. Existing v2 request-cache tests retain source read/prepare/build counts and identity sharing.
5. Preserve function name, arity and existing TypeScript call signatures. Typecheck the complete project using the unchanged scope when an approved resource route is available; a focused transpile is not a full typecheck.
6. Preserve historical variant-context warnings, source feature precedence, first-match and duplicate handling, source-ID order, editorial merging, refreshed/approved feature guards, evidence regrading, packet guards, and term inheritance.
7. Preserve pack source closure across configuration, facts/issues, availability, summaries, features, eligibility, events and configuration history. Test each missing-source path, including configuration-source errors.
8. Preserve event cleaning/order, eligibility overrides, configuration history merging and safe-URL handling; no new data normalization.
9. Existing source-hash, foreign/secondary promotion, dedicated price-basis and malformed-feature negative tests must remain active.

## Actual retained-value consumers after approved application
- First compare all 621 actual Subaru feature rows, byte-for-byte, to capture-attempt640-original/subaru-feature-before.json, using all 14 proven Research fields and the exact nine original cars. Recheck all input hashes and immutability.
- Rebuild all 14 actual Polestar packs from exact derived inputs; compare every full field to the approved pack set and perform complete portable store/hydrate parity with all sources.
- Stream all 397 actual effectiveFeatures outputs, preserving every car/criterion order, 69 unique criteria per car, 27,393 total rows, complete source and research immutability and per-car hashes. This is a consumer proof on derived values, not fresh catalogue hydration.
- Feed all proven cars, sources and exact feature rows through the actual report loader/build functions and compare complete reports independently at 2026-10-14 and 2026-10-15. No filtered/normalized or brand-only report comparison.
- Only successful terminal receipts for every required phase, plus unchanged before/after pins and independent approval, permit derived-baseline acceptance and Subaru canonical staging. Fresh v2 loader equivalence, current full TypeScript check and registration authorization remain separate open gates.
