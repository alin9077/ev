"""Explicit reviewed source transition. Retains, never replaces, all historical pins."""
import pathlib,json,hashlib,datetime,re
W=pathlib.Path('/tmp/subaru-derived-proof-plan');R=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104');Q=R.parent/'roadmark-104-qa';D=Q/'evidence-consumer-boundary-proposal-2026-10-14'
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(262144),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_text())
def put(p,value):
 with pathlib.Path(p).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def ref(p):
 p=pathlib.Path(p)
 for anchor,root in [('proof',W),('qa',Q),('repo',R)]:
  if p.is_relative_to(root):return dict(anchor=anchor,file=str(p.relative_to(root)),sha256=sha(p),bytes=p.stat().st_size)
 raise AssertionError(p)
base=read(W/'input-verification.json');assert base['status']=='passed_for_derived_only_replay';oldPins={row['path']:row for row in base['executionInputs']};assert len(oldPins)==747
composition=read(W/'composition-v2-inputs.json');assert len(composition['executionInputs'])==15
final=read(D/'final-change-manifest.json');assert sha(D/'final-change-manifest.json')=='d85175779b289ed8ad0f2383aefbe5c26136da0eda9f3bb9f6ed1604032a317b'
approval=read(D/'independent-static-approval.json');assert approval['status']=='approved_for_root_decision_on_application_and_focused_tests';assert sha(D/'proposal.patch')==approval['proposalSha256']==final['approvedPatchSha256']
reviewed={row['path']:row for row in approval['files']};assert len(reviewed)==5
changes=[]
for row in final['files']:
 file=row['path'];assert sha(R/file)==row['afterSha256']
 if file in reviewed:assert row['beforeSha256']==reviewed[file]['beforeSha256'] and row['afterSha256']==reviewed[file]['proposedSha256']
 else:assert file in ['tests/evidence-consumers.test.ts','tests/fixtures/evidence-consumers/data-before.ts.txt'] and row['beforeSha256'] is None
 beforeFile=None
 if row['beforeSha256'] is not None:
  assert oldPins[str(R/file)]['sha256']==row['beforeSha256'];assert sha(D/'before'/file)==row['beforeSha256'];beforeFile=ref(D/'before'/file)
 else:assert str(R/file) not in oldPins
 changes.append(dict(file=file,beforeSha256=row['beforeSha256'],afterSha256=row['afterSha256'],beforeFile=beforeFile))
assert len(changes)==7
assert sha(R/'tests/fixtures/evidence-consumers/data-before.ts.txt')==sha(D/'before/src/lib/data.ts')=='5298772968b4c7e671bad630726d39f615e2e49a3aa07ecf5b629ee5c502ee24'
oldInventory=read(Q/'catalogue-snapshot-reuse/v2-source-freeze-inputs.json');newInventory=read(W/'consumer-current-source-inventory.json');old={row['file']:row for row in oldInventory['files']};new={row['file']:row for row in newInventory['files']};c={row['file']:row for row in changes}
assert len(old)==515 and len(new)==518
assert set(new)-set(old)=={row['file'] for row in changes if row['beforeSha256'] is None};assert not set(old)-set(new)
assert {f for f in old if old[f]['sha256']!=new[f]['sha256']}=={row['file'] for row in changes if row['beforeSha256'] is not None}
for file,row in new.items():
 assert sha(R/file)==row['sha256'];assert (R/file).stat().st_size==row['bytes']
 assert row['sha256']==(c[file]['afterSha256'] if file in c else old[file]['sha256'])
for row in base['executionInputs']:
 file=pathlib.Path(row['path']);relative=str(file.relative_to(R)) if file.is_relative_to(R) else None
 if relative in c:assert sha(file)==c[relative]['afterSha256'] and row['sha256']==c[relative]['beforeSha256']
 else:assert sha(file)==row['sha256'],('Unreviewed historical pin change',file)
for row in composition['executionInputs']:assert sha(row['path'])==row['sha256']
for name in ['focused-core-tests-frozen','focused-guards','focused-lint-final']:assert (D/(name+'.exit')).read_text().strip()=='0'
assert 'ℹ pass 43' in (D/'focused-core-tests-frozen.log').read_text() and 'ℹ fail 0' in (D/'focused-core-tests-frozen.log').read_text()
assert 'ℹ pass 163' in (D/'focused-guards.log').read_text() and 'ℹ fail 0' in (D/'focused-guards.log').read_text()
probe=read(D/'import-probe-terminal.json');assert probe['status']=='PASS' and probe['returnCode']==0 and probe['completedProbe'] and probe['inputsUnchanged']
probeResult=read(D/'import-probe-result.json');assert not probeResult['forbiddenLedgerReads'] and not probeResult['factoryDefaultsCalled']
core=read(W/'core-oracle-receipt.json');terminal=read(W/'core-oracle-composed-v2-attempt1/terminal.json');assert terminal['returncode']==0 and terminal['signal'] is None;assert core['all397RetainedCarRowsByteEqual'] and core['all14ResearchFieldsByteEqual']
helperReview=read(W/'consumer-helper-selected-independent-review.json');assert helperReview['status']=='approved_for_pinned_execution'
for row in helperReview['scriptPins']:assert sha(W/row['file'])==row['sha256']
streamReview=read(W/'consumer-stream-report-independent-review.json');assert streamReview['status']=='approved_for_pinned_execution_after_focused_tests_and_root_slot'
for row in streamReview['files']:assert sha(W/row['file'])==row['sha256']
review=dict(status='approved_for_consumer_phase_pin_transition',checkedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceChanges=changes,priorCoreReceiptSha256=sha(W/'core-oracle-receipt.json'),approvedPatchSha256=sha(D/'proposal.patch'),finalChangeManifestSha256=sha(D/'final-change-manifest.json'),independentStaticApprovalSha256=sha(D/'independent-static-approval.json'),beforeSourceInventorySha256=sha(Q/'catalogue-snapshot-reuse/v2-source-freeze-inputs.json'),currentSourceInventorySha256=sha(W/'consumer-current-source-inventory.json'),oldSourceFiles=515,currentSourceFiles=518,allOtherHistorical747PinsUnchanged=True,all15CompositionPinsUnchanged=True,addedTestAndExactOracleIndependentlyRead=True,focusedTestsPassed=43,guardTestsSelectedPassed=163,guardTestsExplicitlyExcluded=3,focusedLintPassed=True,actualImportProbePassed=True,timingLimitation='No new contemporaneous full pre-application scan was made; exact per-file before/application pins and the successful prior core proof establish historical lineage. This current full scan is contemporaneous with consumer proof preparation. The original 515 inventory includes one regenerable pyc hash record, not archived cache bytes.',freshLoaderValidation=False,currentFullTypecheckVerified=False)
put(W/'consumer-source-transition-review.json',review)
extra=[]
for p in sorted(D.rglob('*')):
 if p.is_file():extra.append(ref(p))
for name in ['consumer-transition-helpers.mjs','actual-feature-pack-phase-consumer-v2.mjs','stream-baseline-effective-features-consumer-v2.mjs','replay-complete-baseline-reports-consumer-v2.mjs','additional-report-phase-helpers.mjs','consumer-helper-selected-independent-review.json','consumer-stream-report-independent-review.json','consumer-proof-execution-plan.md','consumer-refactor-acceptance-plan.md','prepare-consumer-phase-manifest.py','composition-transition-v2.json','actual-single-packet-output-index-v2.json','actual-single-packet-metadata-v2.jsonl']:
 extra.append(ref(W/name))
for folder in ['core-oracle-composed-v2-attempt1','consumer-current-inventory-attempt1']:
 for p in sorted((W/folder).iterdir()):
  if p.is_file():extra.append(ref(p))
extra.append(ref(Q/'catalogue-snapshot-reuse/hash-inputs.py'))
manifest=dict(schemaVersion=1,mode='derived-only-reviewed-consumer-transition',asOf='2026-10-15',inputVerification=ref(W/'input-verification.json'),compositionInputs=ref(W/'composition-v2-inputs.json'),coreReceipt=ref(W/'core-oracle-receipt.json'),coreTerminal=ref(W/'core-oracle-composed-v2-attempt1/terminal.json'),storageIndex=ref(W/'derived-storage-index.pending.json'),sourceTransitionReview=ref(W/'consumer-source-transition-review.json'),beforeSourceInventory=ref(Q/'catalogue-snapshot-reuse/v2-source-freeze-inputs.json'),currentSourceInventory=ref(W/'consumer-current-source-inventory.json'),sourceChanges=changes,extraPins=extra,acceptedBaseline=False,freshLoaderValidation=False,currentFullTypecheckVerified=False,subaruRegistrationAuthorized=False)
put(W/'consumer-phase-manifest.json',manifest)
print(json.dumps({'status':'passed_explicit_transition_and_manifest_preparation','beforeFiles':515,'currentFiles':518,'reviewedChangedOrNewPaths':7,'historicalPins':747,'compositionPins':15,'extraPins':len(extra),'manifestSha256':sha(W/'consumer-phase-manifest.json'),'timingLimitationRetained':True}))
