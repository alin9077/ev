"""Independent bounded file/receipt verification; no application import or expectation rewrite."""
import pathlib,json,hashlib,datetime
W=pathlib.Path('/tmp/subaru-derived-proof-plan');R=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104');Q=R.parent/'roadmark-104-qa';roots={'proof':W,'repo':R,'qa':Q,'research':pathlib.Path('/tmp/subaru-research'),'polestar':pathlib.Path('/tmp/polestar-research')}
def read(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(262144),b''):h.update(b)
 return h.hexdigest()
def locate(row):
 root=roots[row['anchor']];p=(root/row['file']).resolve();assert p.is_relative_to(root);return p
inputs=read(W/'final-verification-inputs.json');inputHash=sha(W/'final-verification-inputs.json')
def pins():
 for row in inputs['executionInputs']:assert sha(row['path'])==row['sha256'],row['path']
pins()
m=read(W/'consumer-phase-manifest.json');mh=sha(W/'consumer-phase-manifest.json')
for key in ['inputVerification','compositionInputs','coreReceipt','coreTerminal','storageIndex','sourceTransitionReview','beforeSourceInventory','currentSourceInventory']:assert sha(locate(m[key]))==m[key]['sha256'],key
base=read(locate(m['inputVerification']));changes={str(R/row['file']):row for row in m['sourceChanges']}
for row in base['executionInputs']:
 change=changes.get(row['path'])
 if change:assert row['sha256']==change['beforeSha256'] and sha(locate(change['beforeFile']))==row['sha256'];assert sha(row['path'])==change['afterSha256']
 else:assert sha(row['path'])==row['sha256'],row['path']
for row in read(locate(m['compositionInputs']))['executionInputs']:assert sha(row['path'])==row['sha256']
for row in m['extraPins']:assert sha(locate(row))==row['sha256'],row['file']
current=read(locate(m['currentSourceInventory']));final=read(W/'consumer-final-source-inventory.json');assert final['files']==current['files'] and len(final['files'])==518
for row in final['files']:assert sha(R/row['file'])==row['sha256'] and (R/row['file']).stat().st_size==row['bytes']
recovery=read(W/'feature-recovery-v3-inputs.json');rh=sha(W/'feature-recovery-v3-inputs.json')
for row in recovery['executionInputs']:assert sha(row['path'])==row['sha256']
phaseDirs={'core':'core-oracle-composed-v2-attempt1','selectedConsumers':'actual-feature-pack-consumer-v2-attempt1','fullFeatures':'complete-feature-stream-consumer-recovery-v3-attempt1','completeReports':'complete-report-replay-consumer-v2-attempt1'}
terminals={}
for key,directory in phaseDirs.items():
 p=W/directory/'terminal.json';t=read(p);assert t['returncode']==0 and t['signal'] is None;terminals[key]={'file':str(p.relative_to(W)),'sha256':sha(p),'elapsedSeconds':t['elapsedSeconds'],'maxRssKiB':t['maxRssKiB']}
core=read(locate(m['coreReceipt']));index=read(locate(m['storageIndex']));selected=read(W/'actual-feature-pack-receipt.json');fr=read(W/'baseline-effective-features-receipt.json');report=read(W/'baseline-complete-report-receipt.json')
assert core['currentCars']==397 and core['originalSubaruCars']==9 and core['proposedSubaruCars']==11 and len(core['carHashes'])==397
for key in ['all397RetainedCarRowsByteEqual','all14ResearchFieldsByteEqual','allOriginalObjectsUnchanged','allNonPolestarCarValuesEqual','allFourStructuralSubaruOriginalFilesByteEqual','allApprovedPolestarCarValuesEqual']:assert core[key]
assert selected['status']=='passed' and selected['originalSubaruFeatureRows']==621 and selected['actualPolestarPacks']==14 and selected['actualPortableExact'] and selected['fullResearchAndSelectedCarsUnchanged']
assert selected['coreReceiptSha256']==m['coreReceipt']['sha256']
for receipt in [selected,fr,report]:assert receipt['consumerPhaseManifestSha256']==mh and receipt['reviewedSourceTransitionSha256']==m['sourceTransitionReview']['sha256']
assert fr['status']=='passed' and fr['cars']==397 and fr['featureRows']==27393 and fr['recoveryManifestSha256']==rh
for key in ['allCompleteCarHashesVerified','all14ResearchFieldsUnchanged','fullOriginalSubaruFeaturesEqual','allApprovedPolestarFeaturesEqual','inputHashesRechecked']:assert fr[key]
assert fr['actualPackReceiptSha256']==sha(W/'actual-feature-pack-receipt.json')
assert report['status']=='passed' and report['cars']==397 and report['features']==27393 and report['sources']==3432 and report['dates']==['2026-10-14','2026-10-15']
assert report['featureReceiptSha256']==sha(W/'baseline-effective-features-receipt.json') and report['actualPackReceiptSha256']==sha(W/'actual-feature-pack-receipt.json')
for key in ['allReportInputsComplete','allInputObjectsUnchanged','actualReportLoaderUsed','actualCoverageBuilderUsed','actualFeaturesProvidedFromIndependentFullPopulationStream']:assert report[key]
def file_rows(p,expected):
 h=hashlib.sha256();n=0;b=0
 with p.open('rb') as f:
  for line in f:assert line.endswith(b'\n');h.update(line);n+=1;b+=len(line)
 assert (n,b,h.hexdigest())==(expected['rows'],expected['bytes'],expected['sha256']);return n
assert len(index['research'])==14
for key,row in index['research'].items():file_rows(locate(row),row)
carFile=locate(index['cars']);file_rows(carFile,index['cars']);ids=[];nonPolestar=0
with carFile.open('rb') as f:
 for i,line in enumerate(f):
  car=json.loads(line);expected=core['carHashes'][i];assert car['id']==expected['id'] and car['brand']==expected['brand'];assert hashlib.sha256(line).hexdigest()==expected['afterSha256'] and len(line)==expected['bytes'];ids.append(car['id'])
  if car['brand']!='Polestar':assert expected['beforeSha256']==expected['afterSha256'];nonPolestar+=1
assert len(ids)==len(set(ids))==397 and nonPolestar==383
fi=read(W/fr['index']['file']);assert sha(W/fr['index']['file'])==fr['index']['sha256'];assert fi['consumerPhaseManifestSha256']==mh and fi['recoveryManifestSha256']==rh
featureFile=W/fi['features']['file'];file_rows(featureFile,fi['features']);assert len(fi['perCar'])==397 and fi['features']['rows']==27393
with featureFile.open('rb') as f:
 for i,expected in enumerate(fi['perCar']):
  assert expected['id']==ids[i] and expected['carSha256']==core['carHashes'][i]['afterSha256'];h=hashlib.sha256();b=0;criteria=[]
  for _ in range(69):
   line=f.readline();assert line.endswith(b'\n');feature=json.loads(line);assert feature['variant_id']==ids[i];criteria.append(feature['criterion']);h.update(line);b+=len(line)
  assert len(set(criteria))==69 and expected['featureRows']==69 and b==expected['featureBytes'] and h.hexdigest()==expected['featureSha256']
 assert f.read()==b''
old=W/'baseline-effective-features.jsonl';oldRows=sum(1 for _ in old.open('rb'));assert oldRows==20700
with old.open('rb') as a,featureFile.open('rb') as b:
 while chunk:=a.read(262144):assert b.read(len(chunk))==chunk,'Interrupted prefix differs from fresh full replay'
assert sha(old)=='6ca6b35c8e7bbf20d682f3683e26d662e77d0f4d80f37a75401871849181fe0f'
expectedReports={'2026-10-14':roots['polestar']/'staged-report.json','2026-10-15':Q/'polestar-sequential-checks/coverage.stdout'}
for row in report['results']:
 expected=expectedReports[row['asOf']];actual=W/row['output']['file'];assert str(expected)==row['expected'];assert sha(expected)==row['expectedSha256'];assert sha(actual)==row['output']['sha256'];assert read(actual)==read(expected),'Complete report differs'
assert {row['asOf'] for row in report['results']}==set(expectedReports)
for row in core['originalFiles']:assert sha(row['file'])==row['sha256']
assert sha(roots['research']/'capture-attempt640-original/subaru-feature-before.json')==selected['fifthOriginalFileSha256']
assert not (W/'complete-feature-stream-consumer-v2-attempt1/terminal.json').exists()
assert read(W/'process-visibility-correction.json')['originalInterruptionReceiptUnchanged']
pins();assert sha(W/'final-verification-inputs.json')==inputHash
out={'status':'passed_all_required_derived_baseline_checks','mode':'Derived-only; no fresh full-loader or full typecheck claim','asOf':'2026-10-15','timeZone':'Australia/Sydney','cars':397,'unchangedNonPolestarCars':383,'researchFields':14,'sources':3432,'originalSubaruCars':9,'proposedSubaruCars':11,'allFiveOriginalFilesMatched':True,'actualPolestarPacks':14,'actualPortableExact':True,'featureRows':27393,'fullReportsComparedAt':['2026-10-14','2026-10-15'],'sourceFilesUnchangedAcrossConsumerPhases':518,'historicalInputPinsPreserved':747,'compositionPinsPreserved':15,'originalInterruptedRows':20700,'originalInterruptedPrefixByteEqual':True,'originalInterruptedAttemptStatus':'Unrecoverable session with no terminal; unchanged partial output. ps visibility was incomplete; no signal/cause inferred.','terminals':terminals,'inputVerificationSha256':sha(W/'input-verification.json'),'consumerPhaseManifestSha256':mh,'recoveryManifestSha256':rh,'sourceTransitionReviewSha256':m['sourceTransitionReview']['sha256'],'finalVerificationInputsSha256':inputHash,'finalSourceInventorySha256':sha(W/'consumer-final-source-inventory.json'),'processVisibilityCorrectionSha256':sha(W/'process-visibility-correction.json'),'openGates':['Fresh full-loader/equality verification','Current complete TypeScript check','Normal top-level report execution','Subaru final packet review and registration'],'acceptedIndexWritten':False}
with (W/'final-independent-verification.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps(out,indent=2))
