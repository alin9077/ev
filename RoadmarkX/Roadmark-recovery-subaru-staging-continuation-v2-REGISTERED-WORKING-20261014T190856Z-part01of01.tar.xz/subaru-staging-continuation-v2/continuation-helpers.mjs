/** Read-only, fail-closed proof of the separately reviewed seven-status continuation. */
import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
const root='/tmp/subaru-staging-continuation-v2',original='/tmp/subaru-staging-plan',candidate=original+'/candidate';
const sha=value=>crypto.createHash('sha256').update(value).digest('hex');
const hash=file=>sha(fs.readFileSync(file));
const json=file=>JSON.parse(fs.readFileSync(file,'utf8'));
const expected={
 stage:'0244f1e320dd6f5a0d52b4365e20c3e27e4905caaca4c7cfd2eec5ebb22844be',
 before:'96bf6f12b3cbb77dd915faa58a5231c4c8631e77c7d793e1deb940d5d8ab2337',
 corrected:'6a21431aacaee96d10924ec854773c855d64b59d19ab313fa20e2a22f0f39b9c',
 canonical:'9a63183e6d50485ae56afc7ad7f8e36e71799d8d823477a78a66ce8fa95bc687',
 fixture:'22a93fca02c181de0de290fad10a3cbc7ad61ea34f9753bd90232dd9b1d87eaf',
 proposal:'312b89eda1a2676701c2ea98bb47faf240a52626e5e505299bcf334950ab5f50',
 proposalApproval:'17cc9923d0b749d5e500e02ea7a63f3f84e089bf4cbe83c6deb506f71e53cd64',
};
const cloneNames=['stage-core-subaru.mjs','staged-values.mjs','stage-selected-consumers-subaru.mjs','stage-negative-guards-subaru.mjs','stage-full-feature-stream-subaru.mjs','stage-complete-report-subaru.mjs'];
const originalNames=['stage_inputs.py','build-packet-derived-v2.py','stage-proof-helpers.mjs','compose-subaru-research.mjs','composition-17-to-18.md','capture-canonical-subaru.mjs',...cloneNames,'prepare-stage-inputs.py','run-stage-measured.py'];
const changedPaths=[26,29,33,35,39,145,226].map(index=>`features[${index}].after.status`);
function checkPin(row){assert(row&&typeof row.path==='string'&&row.path.startsWith('/'));assert.match(row.sha256,/^[0-9a-f]{64}$/);assert(Number.isSafeInteger(row.bytes)&&row.bytes>=0);assert.equal(hash(row.path),row.sha256,'Continuation pin changed: '+row.path);assert.equal(fs.statSync(row.path).size,row.bytes)}
function pathsChanged(a,b,path=''){
 assert.equal(Array.isArray(a),Array.isArray(b),'No type change: '+path);
 assert.equal(a===null,b===null,'No null/type change: '+path);
 assert.equal(typeof a,typeof b,'No type change: '+path);
 if(a!==null&&typeof a==='object'){
  assert.deepEqual(Object.keys(a),Object.keys(b),'Every key, cardinality and property order unchanged: '+path);
  return Object.keys(a).flatMap(key=>pathsChanged(a[key],b[key],Array.isArray(a)?path+'['+key+']':path?path+'.'+key:key));
 }
 return Object.is(a,b)?[]:[path];
}
export function openSubaruContinuation(proof){
 const manifestFile=root+'/continuation-manifest.json',manifestSha256=hash(manifestFile);
 assert.match(process.env.SUBARU_CONTINUATION_MANIFEST_SHA256||'',/^[0-9a-f]{64}$/,'Invoke only with the independently sealed continuation manifest SHA');
 assert.equal(manifestSha256,process.env.SUBARU_CONTINUATION_MANIFEST_SHA256,'Exact externally selected continuation manifest');
 const manifest=json(manifestFile);
 assert.equal(manifest.schemaVersion,1);assert.equal(manifest.mode,'subaru-feature-status-v2-continuation');assert.equal(manifest.status,'approved_for_execution');assert.equal(manifest.asOf,'2026-10-15');
 assert.equal(manifest.contract.path,root+'/continuation-contract.json');checkPin(manifest.contract);
 assert.equal(manifest.amendmentReview.path,'/tmp/subaru-staging-review/feature-status-v2-continuation-review.json');checkPin(manifest.amendmentReview);
 const contract=json(manifest.contract.path),contractSha256=manifest.contract.sha256,review=json(manifest.amendmentReview.path),amendmentReviewSha256=manifest.amendmentReview.sha256;
 assert.equal(contract.schemaVersion,1);assert.equal(contract.mode,'exact-seven-feature-status-continuation');assert.equal(contract.asOf,'2026-10-15');assert.equal(contract.candidateId,'m1-subaru-2026-10-15');
 for(const key of ['candidateRegistered','freshLoaderValidation','currentFullTypecheckVerified','registryEditsAuthorized','canonicalRecaptured','historicalExpectationsReset'])assert.equal(contract[key],false);
 assert.equal(proof.manifestSha256,expected.stage);assert.equal(proof.manifest.executionInputs.length,1072);assert.equal(contract.originalPinCount,1072);
 const pins=new Map(contract.executionInputs.map(row=>[row.path,row]));assert.equal(pins.size,contract.executionInputs.length);
 const requirePin=(row,path,expectedSha)=>{assert.equal(row.path,path);assert.deepEqual(pins.get(path),row,'Mandatory full continuation pin: '+path);if(expectedSha)assert.equal(row.sha256,expectedSha);return row};
 const mandatory=[];
 function requireInput(key,path,expectedSha){const row=requirePin(contract[key],path,expectedSha);mandatory.push(row);return row}
 requireInput('originalStageManifest',original+'/stage-inputs.json',expected.stage);
 requireInput('beforePacket',candidate+'/subaru-2026-10-15.json',expected.before);
 requireInput('correctedPacket',candidate+'/subaru-2026-10-15-feature-status-v2.json',expected.corrected);
 requireInput('canonicalPacket',candidate+'/canonical-packet-original.json',expected.canonical);
 requireInput('originalFeatureFixture',candidate+'/new-feature-before.json',expected.fixture);
 requireInput('canonicalMetadata',candidate+'/canonical-baseline-meta.json');
 requireInput('canonicalSelectedCars',candidate+'/canonical-selected-cars.json');
 requireInput('canonicalRawMetadata',candidate+'/canonical-raw-metadata.json');
 requireInput('canonicalCompositionTransition',candidate+'/canonical-composition-transition.json');
 requireInput('transitionProposal',original+'/feature-status-v2-transition-proposal.json',expected.proposal);
 requireInput('transitionReceipt',original+'/feature-status-v2-transition.json');
 requireInput('proposalApproval','/tmp/subaru-staging-review/feature-status-v2-proposal-review.json',expected.proposalApproval);
 requireInput('producer',original+'/produce-feature-status-v2.py');
 const checks='/workspace/scratch/586427eef9f2/roadmark-104-qa/subaru-derived-staging-checks';
 for(const [key,dir,name]of [['failedCoreReceipt','core-attempt1','terminal.json'],['failedCoreStdout','core-attempt1','stdout.log'],['failedCoreStderr','core-attempt1','stderr.log'],['producerTerminal','feature-status-v2-produce-attempt1','terminal.json'],['producerStdout','feature-status-v2-produce-attempt1','stdout.log'],['producerStderr','feature-status-v2-produce-attempt1','stderr.log']])requireInput(key,checks+'/'+dir+'/'+name);
 requireInput('transitionMetadata',root+'/transition-metadata.json');
 requireInput('helperDiff',root+'/diffs/continuation-helpers.mjs.patch');
 const originalPins=new Map(proof.manifest.executionInputs.map(row=>[row.path,row]));
 assert.equal(contract.originalScriptPins.length,originalNames.length);
 originalNames.forEach((name,index)=>{const row=requirePin(contract.originalScriptPins[index],original+'/'+name);assert.equal(row.sha256,originalPins.get(row.path)?.sha256);if(originalPins.get(row.path)?.bytes!==undefined)assert.equal(row.bytes,originalPins.get(row.path).bytes);mandatory.push(row)});
 assert.equal(contract.newScriptPins.length,cloneNames.length+1);
 [...cloneNames,'continuation-helpers.mjs'].forEach((name,index)=>{const row=requirePin(contract.newScriptPins[index],root+'/'+name);mandatory.push(row)});
 assert.equal(contract.scriptTransitions.length,cloneNames.length);
 cloneNames.forEach((name,index)=>{const row=contract.scriptTransitions[index];assert.deepEqual(row.original,contract.originalScriptPins.find(pin=>pin.path===original+'/'+name));assert.deepEqual(row.continuation,contract.newScriptPins[index]);mandatory.push(requirePin(row.diff,root+'/diffs/'+name+'.patch'))});
 assert.deepEqual([...pins.keys()].sort(),[...new Set(mandatory.map(row=>row.path))].sort(),'Every mandatory pin, no substituted execution inventory');
 assert.deepEqual(contract.changedPaths,changedPaths);
 assert.equal(review.status,'approved_for_pinned_subaru_feature_status_v2_continuation');assert.equal(review.contractSha256,contractSha256);assert.equal(review.originalStageInputManifestSha256,expected.stage);
 assert.equal(review.beforePacketSha256,expected.before);assert.equal(review.correctedPacketSha256,expected.corrected);assert.equal(review.canonicalPacketSha256,expected.canonical);assert.equal(review.originalFeatureFixtureSha256,expected.fixture);
 assert.deepEqual(review.changedPaths,changedPaths);assert.deepEqual(review.scriptPins,contract.newScriptPins);assert.deepEqual(review.sourceDiffPins,[...contract.scriptTransitions.map(row=>row.diff),contract.helperDiff]);
 for(const key of ['allOriginalAlgorithmsAssertionsAndCompleteComparisonsPreserved','original1072PinsUnchanged','exactCorrectedPacketInspected','allOtherPacketValuesUnchanged','featureFreeCanonicalExactlyEqual'])assert.equal(review[key],true);
 for(const key of ['canonicalRecaptured','historicalExpectationsReset','candidateRegistered','freshLoaderValidation','currentFullTypecheckVerified','registryEditsAuthorized'])assert.equal(review[key],false);
 const verify=()=>{
  assert.equal(hash(manifestFile),manifestSha256,'Continuation manifest unchanged before/after');checkPin(manifest.contract);checkPin(manifest.amendmentReview);
  for(const row of contract.executionInputs)checkPin(row);
  assert.equal(hash(original+'/stage-inputs.json'),proof.manifestSha256,'Original 1072-pin contract was not reset');
  const proposal=json(contract.transitionProposal.path),transition=json(contract.transitionReceipt.path),before=json(contract.beforePacket.path),after=json(contract.correctedPacket.path),canonical=json(contract.canonicalPacket.path),meta=json(contract.canonicalMetadata.path),fixture=json(contract.originalFeatureFixture.path),proposalApproval=json(contract.proposalApproval.path);
  assert.equal(before.id,contract.candidateId);assert.equal(after.id,contract.candidateId);assert.equal(before.features.length,293);assert.equal(after.features.length,293);
  assert.equal(proposal.exactChangedFields,7);assert.equal(proposal.changes.length,7);assert.deepEqual(proposal.changes.map(row=>row.path),changedPaths);assert.deepEqual(pathsChanged(before,after),changedPaths);
  const reconstructed=structuredClone(before);
  for(const change of proposal.changes){
   assert.equal(change.path,`features[${change.index}].after.status`);assert.deepEqual(before.features[change.index],change.beforeRow);assert.deepEqual(after.features[change.index],change.proposedAfterRow);
   assert.equal(change.variantId,change.beforeRow.variantId);assert.equal(change.criterion,change.beforeRow.criterion);assert.equal(change.beforeRow.after.status,'standard');assert.equal(change.proposedAfterRow.after.status,'conditional');
   reconstructed.features[change.index].after.status='conditional';
  }
  assert.deepEqual(reconstructed,after,'Exactly seven status changes and all other complete values unchanged');assert.equal(JSON.stringify(reconstructed),JSON.stringify(after),'Complete packet property order unchanged');
  for(const value of [before,after]){const featureFree=structuredClone(value);featureFree.features=[];assert.deepEqual(featureFree,canonical,'Complete feature-free canonical packet equality')}
  assert.equal(meta.generationCount,1);assert.equal(meta.baselineGenerationCount,1);assert.equal(meta.stageInputManifestSha256,expected.stage);assert.equal(meta.featureRows,138);assert.equal(fixture.length,138);
  for(const [key,pinKey]of [['canonical','canonicalPacket'],['newFeatureFixture','originalFeatureFixture'],['selectedCars','canonicalSelectedCars'],['rawMetadata','canonicalRawMetadata'],['compositionTransition','canonicalCompositionTransition']])assert.deepEqual(meta[key],{file:contract[pinKey].path,sha256:contract[pinKey].sha256,bytes:contract[pinKey].bytes});
  assert.deepEqual(proposal.beforePacket,contract.beforePacket);assert.equal(proposal.proposedAfterPacket.path,contract.correctedPacket.path);assert.equal(proposal.proposedAfterPacket.sha256,expected.corrected);assert.equal(proposal.proposedAfterPacket.bytes,contract.correctedPacket.bytes);
  assert.equal(proposal.canonicalPacket.sha256,expected.canonical);assert.equal(proposal.originalFeatureFixture.sha256,expected.fixture);
  assert.equal(transition.status,'produced_exact_independently_approved_feature_status_copy');assert.deepEqual(transition.beforePacket,contract.beforePacket);assert.deepEqual(transition.afterPacket,contract.correctedPacket);assert.deepEqual(transition.fullChangedRows,proposal.changes);assert.deepEqual(transition.exhaustiveChangedPaths,changedPaths);
  assert.equal(transition.proposalSha256,expected.proposal);assert.equal(transition.independentReviewSha256,expected.proposalApproval);assert.equal(transition.canonicalRecaptured,false);assert.equal(transition.registered,false);assert.equal(transition.originalInputsNotOverwritten,true);
  assert.equal(proposalApproval.status,'approved_exact_seven_status_amendment');assert.equal(proposalApproval.proposalSha256,expected.proposal);assert.equal(proposalApproval.beforePacket.sha256,expected.before);assert.equal(proposalApproval.approvedAfterPacket.sha256,expected.corrected);assert.deepEqual(proposalApproval.exactChangedFields,changedPaths);
  const failed=json(contract.failedCoreReceipt.path),produced=json(contract.producerTerminal.path);assert.equal(failed.returncode,1);assert.equal(failed.signal,null);assert.equal(failed.command.at(-1),original+'/stage-core-subaru.mjs');assert.equal(produced.returncode,0);assert.equal(produced.signal,null);assert.equal(produced.command.at(-1),contract.producer.path);
  assert.equal(hash(manifestFile),manifestSha256);checkPin(manifest.contract);checkPin(manifest.amendmentReview);
 };
 verify();
 return {manifest,manifestSha256,contract,contractSha256,amendmentReviewSha256,packetFile:contract.correctedPacket.path,packetSha256:expected.corrected,beforePacketFile:contract.beforePacket.path,beforePacketSha256:expected.before,verify};
}
