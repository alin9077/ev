# Guarded configuration scope updates

Implemented an optional `BrandUpdatePacket.configurationUpdates` path for existing bounded Tier 1 versions. Each row carries an exact full before snapshot, non-null full after snapshot, reason, explicit source snapshots and exact current packet fact dependencies.

Only live scope fields may change: ranking eligibility, scope text, source IDs, buyer-visible conditions, required null holds, ranking count and the typed configuration review. Every other historical source/build field stays exactly unchanged. Complete-record eligibility and complete/bounded counts cannot be promoted. Null before is rejected by this narrow update path; new evidence scopes belong to exact-version admission.

Removed nulls require explicit scalar mappings to current exact facts. Non-identical field names use a small allowlist with measurement-basis checks, so unrelated proxy facts and composite hold releases fail closed. Historical pricing, charging and projection-boundary objects are retained exactly and explicitly marked historical. Unresolved null holds stay unchanged.

Preparation and catalogue application independently guard identity, full before state, unique existing target, brand, Tier 1 and sources. Preparation verifies proof against this packet's facts or brand terms; application checks actual post-packet facts. Later dependent fact edits require a new configuration review. Independent fact grades, measurement bases, freshness, source holds, and current availability still control rankings.

Original configuration context is retained beside historical identity/availability for source-feature reconstruction. Reviewed features retain exact before guards; configuration changes do not silently rebase them.

## Verification

- 80/80 configuration, brand and feature regression tests passed
- Additional historical configuration/feature guard regression passed
- Full TypeScript check passed (`tsc --noEmit --incremental false`)
- Focused ESLint of all changed source and tests passed
- Independent Volkswagen replay is delegated separately and pending at this writing

Before copies, a unified patch, per-file hashes and logs are beside this note. No frozen research snapshots, Volkswagen packet, packet registry or global ranking logic were edited by this change.
