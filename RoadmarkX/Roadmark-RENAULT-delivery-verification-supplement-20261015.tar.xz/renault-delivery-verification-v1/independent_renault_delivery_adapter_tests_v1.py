#!/usr/bin/env python3
"""Metadata-only controlled tests; no archive, seed, remote or live-source payload read."""
import ast,copy,datetime,hashlib,importlib.util,json,pathlib,resource,sys,tempfile,types
sys.dont_write_bytecode=True
C=pathlib.Path(__file__).resolve().parent;P=pathlib.Path;LIMIT=256*1024*1024
resource.setrlimit(resource.RLIMIT_AS,(LIMIT,LIMIT))
def fp(p):
 b=P(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def main():
 path=C/'independent_renault_delivery_adapter_v1.py';assert fp(path)['sha256']=='7d4d97bc2b4625df01d39ed57e49e88f472a3b45725213cec2b74afdc691b03b'
 s=importlib.util.spec_from_file_location('checked_adapter',path);g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
 denial=g.denial();raw=json.loads((C/'library-archives-provider-results.json').read_bytes());request=json.loads((C/'library-archives-host-create-request.json').read_bytes());archives=json.loads((C/'ARCHIVE-PLAN-v2.json').read_bytes())['archives'];expected={a['filename']:a for a in archives}
 original=ast.parse((C/g.BASE).read_bytes());original_fn=next(n for n in original.body if isinstance(n,ast.FunctionDef) and n.name=='documents');modified=copy.deepcopy(original_fn);comp=next(n for n in ast.walk(modified) if isinstance(n,ast.Compare) and ast.unparse(n.left)=='DOCS[3].read_bytes()');rhs=copy.deepcopy(comp.comparators[0]);comp.comparators[0]=ast.BinOp(left=rhs,op=ast.Add(),right=ast.Constant(value=g.FOOTER.encode()));ast.fix_missing_locations(modified)
 compiled=compile(ast.Module(body=[modified],type_ignores=[]),str(C/g.BASE)+'#exact-summary-footer-adaptation','exec');ns=dict(g.M.__dict__);exec(compiled,ns);assert ns['documents'].__code__.co_code==g.M.documents.__code__.co_code and ns['documents'].__code__.co_consts==g.M.documents.__code__.co_consts
 expr=compile(ast.fix_missing_locations(ast.Expression(body=comp)),'summary-adaptation-test','eval');base=b'AUTHORED BRIEF\n';working='WORKING';body=base+('\n\n## Recovery note\n\n'+working+'\n').encode();cases=[]
 class Bytes:
  def __init__(self,b):self.b=b
  def read_bytes(self):return self.b
 for label,value,accepted in [('summary-exact-footer',body+g.FOOTER.encode(),True),('summary-missing-footer',body,False),('summary-altered-authored-text',b'X'+body+g.FOOTER.encode(),False),('summary-duplicate-footer',body+2*g.FOOTER.encode(),False)]:
  got=eval(expr,{'DOCS':[None,None,None,Bytes(value)],'P':lambda unused:Bytes(base),'sr':{'payloadPath':'controlled-fixture'},'scope':{'workingResult':working}});assert got is accepted;cases.append({'case':label,'expected':accepted,'observed':got,'result':'PASS'})
 tmp=P(tempfile.mkdtemp(prefix='renault-native-adapter-metadata-tests-'));g.C=tmp;real_os=g.os;realpin=g.pin;table={};pins={}
 def pin(p):
  p=str(p)
  if p in pins:return pins[p]
  return fp(p)
 def ref(name):return pin(tmp/name)
 def install(mutate=None):
  nonlocal table,pins
  rows=copy.deepcopy(raw);q=copy.deepcopy(request);ids=[];norm=[];witness=[];returned=[]
  for path,row in zip(q['files'],rows['structuredContent']['results']):
   name=P(path).name;flags={'providerCreateConfirmed':True,'localBytesVerified':True,'createReceiptAndLocalIdentityVerified':True,'nativeByteReadbackVerified':False,'verificationBasis':'EXACT_SERVER_CREATE_TUPLE_AND_LOCAL_HASH'};a={'filename':name,'localPath':path,**g.sh(expected[name]),'library_file_id':row['library_file_id'],'file_id':row['file_id'],'version':row['current_version_number'],**flags};ids.append(a)
   norm.append({'local_path':path,'purpose':'create_library_file','status':'succeeded','file_id':a['file_id'],'library_file_id':a['library_file_id'],'file_name':name,'local_metadata_applied':True,'current_version_number':a['version'],'returnedXattrsApplied':row['xattrs'],'nativeByteReadbackVerified':False});witness.append({k:a[k] for k in ['filename','library_file_id','file_id','version','bytes','sha256',*flags]});returned.append({'filename':name,'returnedXattrs':row['xattrs'],'allReturnedXattrsApplied':True,'noUnreturnedIdentityXattrAdded':True})
  table={str(tmp/'library-archives-host-create-request.json'):q,str(tmp/'library-archives-provider-results.json'):rows}
  pins={str(tmp/g.DELIVERY):fp(C/g.DELIVERY)}
  def remember(name,obj):
   p=str(tmp/name);b=(json.dumps(obj,sort_keys=True)+'\n').encode();table[p]=obj;pins[p]={'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
  remember('library-archives-host-create-request.json',q);remember('library-archives-provider-results.json',rows)
  identity={'status':'CREATE_CONFIRMED_NATIVE_BYTE_READBACK_UNPASSED','acceptanceScope':g.SCOPE,'nativeByteReadbackVerified':False,'exactHostRequest':ref('library-archives-host-create-request.json'),'exactProviderResponse':ref('library-archives-provider-results.json'),'normalizer':pin(tmp/g.DELIVERY),'blockedReadbackEvidence':denial,'files':ids};remember('ARCHIVE-UPLOAD-IDENTITIES.json',identity)
  normalized={'route':'OFFICIAL_ABSOLUTE_PATH_HOST_CREATE','exactHostRequest':ref('library-archives-host-create-request.json'),'exactProviderResponse':ref('library-archives-provider-results.json'),'results':norm};remember('library-archives-results.json',normalized)
  readback={'status':'DENIED_SCOPE_VIOLATION','legacyFilenameDoesNotAssertReadback':True,'nativeByteReadbackVerified':False,'nativeMaterializationAttemptsForThisPhase':1,'blockedReadbackEvidence':denial,'createConfirmedIdentities':ref('ARCHIVE-UPLOAD-IDENTITIES.json'),'returnedAttributes':returned,'statement':g.NOTE};remember('ARCHIVE-NATIVE-READBACK-v1.json',readback)
  if mutate:mutate(rows,identity,normalized,witness,readback)
  (tmp/'library-archives-verified.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in witness))
  g.load=lambda p:table[str(p)];g.pin=pin;g.denial=lambda:denial;g.check=lambda p,r:None;g.pair=lambda p:None;g.os=real_os
 def case(label,mutation=None,accepted=False,attrs=False):
  install(mutation)
  if attrs:g.os=types.SimpleNamespace(listxattr=lambda p:real_os.listxattr(p)+['user.library-file-id'],getxattr=real_os.getxattr)
  try:g.native('archives',expected);got=True
  except AssertionError:got=False
  assert got is accepted,(label,got);cases.append({'case':label,'expected':accepted,'observed':got,'result':'PASS'})
 case('actual-five-create-tuple-positive',accepted=True)
 case('provider-id-altered',lambda rows,*rest:rows['structuredContent']['results'][0].update(library_file_id='libfile_changed'))
 case('provider-path-altered',lambda rows,*rest:rows['structuredContent']['results'][0].update(path='/wrong'))
 case('provider-size-altered',lambda rows,*rest:rows['structuredContent']['results'][0].update(file_size_bytes=1))
 case('provider-extra-xattr',lambda rows,*rest:rows['structuredContent']['results'][0]['xattrs'].append({'name':'user.library-file-id','value':'unreturned'}))
 case('identity-readback-true',lambda rows,identity,*rest:identity.update(nativeByteReadbackVerified=True))
 case('witness-readback-true',lambda rows,identity,norm,witness,*rest:witness[0].update(nativeByteReadbackVerified=True))
 case('missing-provider-row',lambda rows,*rest:rows['structuredContent']['results'].pop())
 case('fabricated-local-id-xattr',attrs=True)
 case('provider-error',lambda rows,*rest:rows.update(isError=True))
 result={'result':'PASS_CONTROLLED_METADATA_ADAPTER_TESTS','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checker':fp(path),'testScript':fp(__file__),'sealedBase':fp(C/g.BASE),'deliveryAdapter':fp(C/g.DELIVERY),'actualProviderMetadata':fp(C/'library-archives-provider-results.json'),'actualDeniedEvidence':denial,'exactSummaryFunctionOnlyOneRhsAddition':True,'cases':cases,'caseCount':len(cases),'scope':{'archivePayloadReads':0,'seedPayloadReads':0,'metadataOnly':True,'nativeXattrsReadOnly':True,'controlledNativeFixtures':True,'noNativeNormalizationOutputsWritten':True,'noRemoteReadOrUpload':True},'resources':{'addressSpaceLimitBytes':LIMIT,'maxRssKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
 out=C/'INDEPENDENT-RENAULT-DELIVERY-ADAPTER-TESTS-v1.json'
 with out.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({'result':result['result'],'cases':len(cases),'output':fp(out)}))
if __name__=='__main__':main()
