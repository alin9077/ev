#!/usr/bin/env python3
"""Delivery-only adapter: explicit create receipts; native byte readback remains unpassed."""
import datetime,hashlib,importlib.util,json,os,pathlib,sys,tarfile,io,lzma
from capture_v1 import C,R,P,pin,check,identity,load,dump
BASES={'builder':('build_delivery_v4.py','4229243b2972fe978bc88a5311a6b4ef72749fb5493d603f51003edb63511071'),'finisher':('finalize_delivery_v2.py','d11db39f6d1f26ecf5cc94894e2c1f7d9f8061485e7104c7932af3e455d10698')}
DATE='20261015';D=C/'deliverables';NOTE='Local recovery replay passed. Native persistence is confirmed by server create receipts and matching local hashes; native byte-readback remains unpassed because the Library materialization request was denied by the selected-folder access boundary.'
SCOPE='DOCUMENT_CONTENT_AND_SERVER_CREATE_IDENTITY_ONLY'
ARTIFACT='Roadmark-RENAULT-delivery-verification-supplement-20261015.tar.xz'
def ref(p):return {'path':str(p),**pin(p)}
def mod(kind):
 n,h=BASES[kind];p=C/n;assert pin(p)['sha256']==h;s=importlib.util.spec_from_file_location('sealed_'+kind,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def denied():
 p=C/'library-archives-materialize-provider-results.json';d=load(p);assert d['isError'] is True and d['structuredContent']['error_code']=='FORBIDDEN';assert "403" in d['structuredContent']['error'] and "scope_violation" in d['structuredContent']['error'] and 'outside the Library folders selected for this user turn' in d['structuredContent']['error'];return {'request':ref(C/'library-archives-materialize-request.json'),'response':ref(p),'scope':'The recorded denial concerns the five archive identities in this exact request; later files are not claimed individually attempted or denied.','retries':0,'alternateReadRoutes':0}

def expected(phase):
 if phase=='archives':return {a['filename']:{'localPath':a['file'],**{k:a[k] for k in ['bytes','sha256']}} for a in load(C/'ARCHIVE-PLAN-v2.json')['archives']}
 if phase=='supplement':
  p=load(C/'DELIVERY-SUPPLEMENT-PACKAGE-v1.json');return {p['filename']:{'localPath':p['file'],**{k:p[k] for k in ['bytes','sha256']}}}
 n={'documents':'DOCUMENT-PRIVACY-SELECTION-v1.json','active':'ACTIVE-PRIVACY-SELECTION-v1.json'}[phase]
 return {P(r['localPath']).name:r for r in load(C/n)['files']}

def normalize(phase):
 assert phase in ['archives','supplement','documents','active'];pre={'archives':'ARCHIVE','supplement':'DELIVERY-SUPPLEMENT','documents':'DOCUMENT','active':'ACTIVE'}[phase]
 reqpath=C/f'library-{phase}-host-create-request.json';rawpath=C/f'library-{phase}-provider-results.json';req=load(reqpath);raw=load(rawpath);assert raw.get('isError') is False;rows=raw['structuredContent']['results'];paths=req['files'] if 'files' in req else [req['file']];want=expected(phase);assert len(rows)==len(paths)==len(want) and len(set(paths))==len(paths)
 files=[];results=[];witness=[];returned=[]
 for path,row in zip(paths,rows):
  p=P(path);name=p.name;assert name in want and str(p)==want[name]['localPath'];assert row['operation']=='create_library_file' and row['status']=='succeeded' and row['file_name']==name;assert row['file_size_bytes']==want[name]['bytes'];assert row['library_file_id'].startswith('libfile_') and row['file_id'].startswith('file_') and isinstance(row['current_version_number'],int)
  check(p,want[name]);attrs=row['xattrs'];assert len({x['name'] for x in attrs})==len(attrs);assert attrs==[{'name':'user.library-file-version','value':str(row['current_version_number'])}], 'unexpected provider xattr requires separate review'
  for x in attrs:os.setxattr(p,x['name'],x['value'].encode())
  assert 'user.library-file-id' not in os.listxattr(p),'no unreturned identity attribute may be fabricated'
  for x in attrs:assert os.getxattr(p,x['name']).decode()==x['value']
  got,_=check(p,want[name]);a={'filename':name,'localPath':str(p),**got,'library_file_id':row['library_file_id'],'file_id':row['file_id'],'version':row['current_version_number'],'providerCreateConfirmed':True,'localBytesVerified':True,'createReceiptAndLocalIdentityVerified':True,'nativeByteReadbackVerified':False,'verificationBasis':'EXACT_SERVER_CREATE_TUPLE_AND_LOCAL_HASH'};files.append(a)
  results.append({'local_path':str(p),'purpose':'create_library_file','status':'succeeded','file_id':a['file_id'],'library_file_id':a['library_file_id'],'file_name':name,'local_metadata_applied':True,'current_version_number':a['version'],'returnedXattrsApplied':attrs,'nativeByteReadbackVerified':False})
  witness.append({k:a[k] for k in ['filename','library_file_id','file_id','version','bytes','sha256','providerCreateConfirmed','localBytesVerified','createReceiptAndLocalIdentityVerified','nativeByteReadbackVerified','verificationBasis']});returned.append({'filename':name,'returnedXattrs':attrs,'allReturnedXattrsApplied':True,'noUnreturnedIdentityXattrAdded':True})
 assert len({a['library_file_id'] for a in files})==len(files)
 basis={'status':'CREATE_CONFIRMED_NATIVE_BYTE_READBACK_UNPASSED','acceptanceScope':SCOPE,'nativeByteReadbackVerified':False,'exactHostRequest':ref(reqpath),'exactProviderResponse':ref(rawpath),'normalizer':ref(P(__file__).resolve()),'blockedReadbackEvidence':denied(),'files':files}
 dump(C/f'{pre}-UPLOAD-IDENTITIES.json',basis);dump(C/f'library-{phase}-results.json',{'route':'OFFICIAL_ABSOLUTE_PATH_HOST_CREATE','exactHostRequest':ref(reqpath),'exactProviderResponse':ref(rawpath),'results':results})
 with (C/f'library-{phase}-verified.jsonl').open('x') as f:
  for w in witness:f.write(json.dumps(w)+'\n')
 dump(C/f'{pre}-NATIVE-READBACK-v1.json',{'status':'DENIED_SCOPE_VIOLATION' if phase=='archives' else 'NOT_ATTEMPTED_AFTER_KNOWN_SCOPE_BOUNDARY','legacyFilenameDoesNotAssertReadback':True,'nativeByteReadbackVerified':False,'nativeMaterializationAttemptsForThisPhase':1 if phase=='archives' else 0,'blockedReadbackEvidence':denied(),'createConfirmedIdentities':ref(C/f'{pre}-UPLOAD-IDENTITIES.json'),'returnedAttributes':returned,'statement':NOTE})
 print(json.dumps({'phase':phase,'createConfirmed':len(files),'nativeByteReadbackVerified':False}))

def supplemental():
 d=load(C/'DELIVERY-SUPPLEMENT-UPLOAD-IDENTITIES.json');assert len(d['files'])==1 and d['files'][0]['filename']==ARTIFACT and d['nativeByteReadbackVerified'] is False;return {'purpose':'Separate delivery-verification helper and access-boundary evidence; not part of the unchanged 142-archive recovery set.','identity':d['files'][0],'package':ref(C/'DELIVERY-SUPPLEMENT-PACKAGE-v1.json'),'memberInventory':ref(C/'DELIVERY-SUPPLEMENT-MEMBER-INVENTORY-v1.json'),'privacyGate':ref(C/'DELIVERY-SUPPLEMENT-PRIVACY-GATE-v1.json'),'nativeIdentityReceipt':ref(C/'DELIVERY-SUPPLEMENT-UPLOAD-IDENTITIES.json'),'nativeByteReadbackVerified':False}

def records(paths):
 out=[]
 for p in sorted(set(paths)):
  assert p.suffix in ['.json','.jsonl','.log','.md','.txt'];b=p.read_bytes();out.append({'file':ref(p),'utf8':b.decode('utf8')})
 return out

def late(phase):
 names=['DELIVERY-SUPPLEMENT-MEMBER-INVENTORY-v1.json','DELIVERY-SUPPLEMENT-PACKAGE-v1.json','DELIVERY-SUPPLEMENT-PRIVACY-SELECTION-v1.json','DELIVERY-SUPPLEMENT-PRIVACY-GATE-v1.json','DELIVERY-SUPPLEMENT-UPLOAD-IDENTITIES.json','DELIVERY-SUPPLEMENT-NATIVE-READBACK-v1.json','scan-delivery-supplement-v1.resources.json','scan-delivery-supplement-v1.resources.invocation.json','library-supplement-host-create-request.json','library-supplement-provider-results.json','library-supplement-results.json','library-supplement-verified.jsonl']
 for p in (['archives'] if phase=='docs' else ['documents']):names.extend([f'library-{p}-host-create-request.json',f'library-{p}-provider-results.json',f'library-{p}-results.json',f'library-{p}-verified.jsonl'])
 return [C/n for n in names]

def annotate(d):
 d.update({'nativePersistenceStatus':'CREATE_CONFIRMED_NATIVE_BYTE_READBACK_UNPASSED','nativeByteReadbackVerified':False,'deliveryVerificationAcceptanceScope':SCOPE,'nativePersistenceLimitation':NOTE,'blockedReadbackEvidence':denied(),'supplementalDeliveryVerificationArtifact':supplemental(),'deliveryAdapter':ref(P(__file__).resolve()),'sealedBaseHelpers':{k:ref(C/v[0]) for k,v in BASES.items()}})
 return d

def replace_prepared(p,d):
 # Only outputs freshly created by this same adapter invocation, before independent review/privacy/upload.
 p.write_text(json.dumps(d,indent=2)+'\n')

def build(phase):
 assert phase in ['docs','active','final'];targets=([D/f'Roadmark-RECOVERY-MANIFEST-RENAULT-WORKING-{DATE}.json',D/f'Roadmark-RECOVERY-VERIFICATION-RENAULT-WORKING-{DATE}.json',D/f'Roadmark-RECOVERY-INDEX-RENAULT-WORKING-{DATE}.md',D/f'Roadmark-RENAULT-M1-UPDATE-{DATE}.md'] if phase=='docs' else [D/f'Roadmark-RECOVERY-ACTIVE-STATE-RENAULT-WORKING-{DATE}.json'] if phase=='active' else [C/'FINAL-RENAULT-UPLOAD-RECEIPTS.json']);assert not any(p.exists() for p in targets)
 m=mod('builder' if phase=='docs' else 'finisher');getattr(m,phase)()
 if phase=='docs':
  manifest=annotate(load(targets[0]));manifest['status']='LOCAL_RECOVERY_VERIFIED_SERVER_CREATE_CONFIRMED_NATIVE_READBACK_UNPASSED_RELEASE_UNPASSED';replace_prepared(targets[0],manifest)
  ver=annotate(load(targets[1]));ver['status']='LOCAL_RECOVERY_VERIFIED_SERVER_CREATE_CONFIRMED_NATIVE_READBACK_UNPASSED_RELEASE_UNPASSED';seen={r['file']['path'] for r in ver['postSealEvidence']};ver['postSealEvidence']+=records([p for p in late('docs') if str(p) not in seen]);replace_prepared(targets[1],ver)
  text=targets[2].read_text();targets[2].write_text(text.replace('\n\n','\n\n'+NOTE+'\n\n',1))
  targets[3].write_text(targets[3].read_text()+'\n\n## Persistence verification boundary\n\n'+NOTE+'\n')
 else:
  d=annotate(load(targets[0]));d['status']='LOCAL_RECOVERY_VERIFIED_SERVER_CREATE_CONFIRMED_NATIVE_READBACK_UNPASSED_RELEASE_UNPASSED'
  if phase=='active':
   seen={r['file']['path'] for r in d['lateMetadata']};d['lateMetadata']+=records([p for p in late('active') if str(p) not in seen])
  replace_prepared(targets[0],d)
 print(json.dumps({'phase':phase,'acceptanceScope':SCOPE,'nativeByteReadbackVerified':False,'supplementOutsideRecoveryArchiveCount':True}))

def package():
 sel=C/'DELIVERY-SUPPLEMENT-PRIVACY-SELECTION-v1.json';gate=C/'DELIVERY-SUPPLEMENT-PRIVACY-GATE-v1.json';rows=load(sel)['files'];g=load(gate);assert g['status']=='clean' and not g['findings'] and not g['errors'] and g['selectionPin']==pin(sel);assert len(g['files'])==len(rows);want={str(P(r['localPath'])):{k:r[k] for k in ['bytes','sha256']} for r in rows};assert len(want)==len(rows) and {r['path']:{k:r[k] for k in ['bytes','sha256']} for r in g['files']}==want
 out=R/ARTIFACT;assert not out.exists();members=[]
 with tarfile.open(out,'w:xz',preset=0) as t:
  for r in rows:
   p=P(r['localPath']);check(p,r);b=p.read_bytes();assert {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}==want[str(p)];name='renault-delivery-verification-v1/'+p.name;assert name not in {x['path'] for x in members};ti=tarfile.TarInfo(name);ti.size=len(b);ti.mode=0o644;ti.mtime=0;t.addfile(ti,io.BytesIO(b));members.append({'path':name,'originalPath':str(p),**want[str(p)]})
 got=[]
 with tarfile.open(out,'r:xz') as t:
  for m in t:
   assert m.isfile();b=t.extractfile(m).read();got.append({'path':m.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 assert got==[{k:r[k] for k in ['path','bytes','sha256']} for r in members]
 with lzma.open(out,'rb') as f:
  while f.read(65536):pass
 dump(C/'DELIVERY-SUPPLEMENT-PACKAGE-v1.json',{'filename':ARTIFACT,'file':str(out),**pin(out),'members':members,'memberCount':len(members),'uncompressedBytes':sum(r['bytes'] for r in members),'privacyGate':ref(gate),'selection':ref(sel),'localFullMemberReplayAndXzEof':'PASS','outsideRecoveryArchiveSet':True,'unchangedRecoveryArchiveCount':142,'packager':ref(P(__file__).resolve())});print(json.dumps({'supplement':ARTIFACT,'members':len(members),'bytes':out.stat().st_size,'outsideRecoveryArchiveSet':True}))
if __name__=='__main__':
 if sys.argv[1]=='normalize':normalize(sys.argv[2])
 elif sys.argv[1]=='package':package()
 else:build(sys.argv[1])
