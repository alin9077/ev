#!/usr/bin/env python3
"""Narrow delivery checker adapter. Native bytes were not read back from Library."""
import ast,datetime,hashlib,importlib.util,json,lzma,os,pathlib,resource,sys,tarfile,time
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent
BASE='independent_renault_documents_v2.py';BASE_SHA='eb34195318a89e430377a25d9736d7173deabcae08b0759ad861f9623732a23c'
DELIVERY='delivery_native_adapter_v3.py';DELIVERY_SHA='f5bec06d762fca6b3d34ea13f7e7f17d2f5353dbbd379a5e1b13e967aabbc474'
SCOPE='DOCUMENT_CONTENT_AND_SERVER_CREATE_IDENTITY_ONLY'
STATUS='LOCAL_RECOVERY_VERIFIED_SERVER_CREATE_CONFIRMED_NATIVE_READBACK_UNPASSED_RELEASE_UNPASSED'
NOTE='Local recovery replay passed. Native persistence is confirmed by server create receipts and matching local hashes; native byte-readback remains unpassed because the Library materialization request was denied by the selected-folder access boundary.'
FOOTER='\n\n## Persistence verification boundary\n\n'+NOTE+'\n'
ARTIFACT='Roadmark-RENAULT-delivery-verification-supplement-20261015.tar.xz'
DENIED_REQUEST={'bytes':1124,'sha256':'53900a9dedf217e23dfb3f36bb89496837dfd56eb9538ffa12f4f8987f47b64f'}
DENIED_RESPONSE={'bytes':471,'sha256':'af23d23b0db94c9feb98c3d896f9bd10acc57cf48a7d7b4467d641815f404703'}
REPLAY_PIN={'bytes':27838,'sha256':'08017b2c13b7f2ac041f0ba28904aacd799254cb12662e6fd3ae8a06fcb78f53'}
MODE=None;SUPPLEMENT_REPLAY=None

def import_base():
 p=C/BASE;b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==BASE_SHA
 spec=importlib.util.spec_from_file_location('sealed_renault_document_checker',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 # Preserve the whole exact function, except add FOOTER to the one original summary RHS.
 tree=ast.parse(b,filename=str(p));fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='documents')
 matches=[n for n in ast.walk(fn) if isinstance(n,ast.Compare) and ast.unparse(n.left)=='DOCS[3].read_bytes()']
 assert len(matches)==1 and len(matches[0].ops)==1 and isinstance(matches[0].ops[0],ast.Eq)
 assert ast.unparse(matches[0].comparators[0])=="P(sr['payloadPath']).read_bytes() + ('\\n\\n## Recovery note\\n\\n' + scope['workingResult'] + '\\n').encode()"
 matches[0].comparators[0]=ast.BinOp(left=matches[0].comparators[0],op=ast.Add(),right=ast.Constant(value=FOOTER.encode()))
 module=ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[]));exec(compile(module,str(p)+'#exact-summary-footer-adaptation','exec'),m.__dict__)
 return m
M=import_base();ck=M.ck;load=M.load;pin=M.pin;sh=M.sh;check=M.check;checkref=M.checkref;pair=M.pair
BASE_RETAINED=M.retained;BASE_SEED=M.seed_accounting

def denial():
 q=C/'library-archives-materialize-request.json';p=C/'library-archives-materialize-provider-results.json';check(q,DENIED_REQUEST);check(p,DENIED_RESPONSE);d=load(p)
 ck(d.get('isError') is True and d['structuredContent']=={'error':"HTTP error prior to action invocation. HTTPException: 403: {'code': 'scope_violation', 'message': 'The requested file is outside the Library folders selected for this user turn.'}",'error_code':'FORBIDDEN'},'exact access denial differs')
 rows=load(C/'library-archives-provider-results.json')['structuredContent']['results'];items=load(q)['items'];ck(items==[{k:r[k] for k in ['file_id','file_name','library_file_id']} for r in rows],'denied request archive identities differ')
 return {'request':pin(q),'response':pin(p),'scope':'The recorded denial concerns the five archive identities in this exact request; later files are not claimed individually attempted or denied.','retries':0,'alternateReadRoutes':0}

def supplement_metadata():
 invpath=C/'DELIVERY-SUPPLEMENT-MEMBER-INVENTORY-v1.json';inv=load(invpath);ck(inv['status']=='EXACT_DELIVERY_ONLY_SUPPLEMENT' and inv['outsideRecoveryArchiveSet'] is True and inv['unchangedRecoveryArchiveCount']==142,'supplement scope differs')
 rows=inv['files'];ck(len({r['originalPath'] for r in rows})==len(rows) and len({r['path'] for r in rows})==len(rows),'duplicate supplement metadata members')
 for r in rows:
  p=P(r['originalPath']);ck(p.parent==C and r['path']=='renault-delivery-verification-v1/'+p.name,'supplement member outside exact namespace');check(p,r)
 own=[r for r in rows if r['originalPath']==str(P(__file__).resolve())];ck(len(own)==1 and sh(own[0])==sh(pin(__file__)),'current adapter not retained exactly once')
 check(C/DELIVERY,{'sha256':DELIVERY_SHA,'bytes':(C/DELIVERY).stat().st_size});ck(any(r['originalPath']==str(C/DELIVERY) and r['sha256']==DELIVERY_SHA for r in rows),'delivery adapter not retained')
 expected=[{'path':r['path'],'originalPath':r['originalPath'],**sh(r)} for r in rows]+[{'path':'renault-delivery-verification-v1/'+invpath.name,'originalPath':str(invpath),**sh(pin(invpath))}]
 selection=C/'DELIVERY-SUPPLEMENT-PRIVACY-SELECTION-v1.json';sel=load(selection);want={r['originalPath']:sh(r) for r in expected};ck({r['localPath']:sh(r) for r in sel['files']}==want and len(sel['files'])==len(want),'supplement selection differs')
 M.privacy_gate('DELIVERY-SUPPLEMENT-PRIVACY-GATE-v1.json',[P(r['localPath']) for r in sel['files']],'scan-delivery-supplement-v1.resources.json')
 t=pair(C/'scan-delivery-supplement-v1.resources.json');ck(t['command']==['python3','scan_documents_v1.py',str(selection),str(C/'DELIVERY-SUPPLEMENT-PRIVACY-GATE-v1.json')],'supplement privacy command scope differs')
 package=load(C/'DELIVERY-SUPPLEMENT-PACKAGE-v1.json');ck(package['filename']==ARTIFACT and package['file']==str(C.parents[1]/ARTIFACT) and package['outsideRecoveryArchiveSet'] is True and package['unchangedRecoveryArchiveCount']==142,'supplement package scope differs');ck(package['memberCount']==len(expected) and package['uncompressedBytes']==sum(r['bytes'] for r in expected),'supplement member totals differ');ck(package['members']==expected,'supplement package member order or pins differ');ck(package['localFullMemberReplayAndXzEof']=='PASS','packager replay missing');checkref(package['privacyGate']);checkref(package['selection']);ck(package['privacyGate']==pin(C/'DELIVERY-SUPPLEMENT-PRIVACY-GATE-v1.json') and package['selection']==pin(selection),'supplement package privacy linkage differs');ck(package['packager']==pin(C/DELIVERY),'supplement packager differs')
 return inv,package,expected

def replay_supplement(package,expected):
 global SUPPLEMENT_REPLAY
 if SUPPLEMENT_REPLAY is not None:return SUPPLEMENT_REPLAY
 if MODE=='documents':
  p=P(package['file']);before=M.identity(p);h=hashlib.sha256();count=0
  with p.open('rb') as f:
   while b:=f.read(65536):count+=len(b);h.update(b)
  ck({'bytes':count,'sha256':h.hexdigest()}==sh(package),'supplement compressed byte hash differs');got=[]
  with tarfile.open(p,'r:xz') as t:
   for member in t:
    ck(member.isfile() and not member.issym() and not member.islnk(),'supplement nonregular member');f=t.extractfile(member);mh=hashlib.sha256();n=0
    while b:=f.read(65536):n+=len(b);mh.update(b)
    got.append({'path':member.name,'bytes':n,'sha256':mh.hexdigest()})
  ck(got==[{k:r[k] for k in ['path','bytes','sha256']} for r in expected],'independent supplement member replay differs')
  with lzma.open(p,'rb') as f:
   while f.read(65536):pass
  ck(M.identity(p)==before,'supplement changed during replay')
  SUPPLEMENT_REPLAY={'result':'PASS_EXACT_DELIVERY_ONLY_SUPPLEMENT_MEMBERS_AND_XZ_EOF','package':pin(C/'DELIVERY-SUPPLEMENT-PACKAGE-v1.json'),'archive':{'path':str(p),**sh(package)},'members':len(got),'uncompressedBytes':sum(x['bytes'] for x in got),'nativeByteReadbackVerified':False}
 else:
  receipt=load(C/M.NAMES['documents']);scoped_receipt(receipt);checkref(receipt['checkerScript']);ck(receipt['checkerScript']==pin(__file__),'scoped supplement checker differs');dt=pair(C/'independent-documents-v1.resources.json');ck(dt['command']==['python3','independent_renault_delivery_adapter_v1.py','documents'],'document replay terminal command differs');r=receipt['supplementalArtifactReplay'];ck(r['result']=='PASS_EXACT_DELIVERY_ONLY_SUPPLEMENT_MEMBERS_AND_XZ_EOF' and r['package']==pin(C/'DELIVERY-SUPPLEMENT-PACKAGE-v1.json') and r['archive']=={'path':package['file'],**sh(package)} and r['members']==len(expected) and r['nativeByteReadbackVerified'] is False,'prior independent supplement proof differs');SUPPLEMENT_REPLAY=r
 return SUPPLEMENT_REPLAY

def retained():
 kept=BASE_RETAINED();inv,package,expected=supplement_metadata();ck(not(set(kept)&{r['originalPath'] for r in inv['files']}),'supplement duplicates already retained source paths');kept.update({r['originalPath']:sh(r) for r in expected});replay_supplement(package,expected);return kept

def native(phase,expected):
 upper={'archives':'ARCHIVE','supplement':'DELIVERY-SUPPLEMENT','documents':'DOCUMENT','active':'ACTIVE'}[phase];ip=C/f'{upper}-UPLOAD-IDENTITIES.json';identity=load(ip);ck(identity['status']=='CREATE_CONFIRMED_NATIVE_BYTE_READBACK_UNPASSED' and identity['acceptanceScope']==SCOPE and identity['nativeByteReadbackVerified'] is False,'native acceptance boundary missing');ck(identity['normalizer']==pin(C/DELIVERY),'normalizer pin differs');ck(identity['blockedReadbackEvidence']==denial(),'native denial provenance differs')
 ident=identity['files'];by={r['filename']:r for r in ident};ck(len(by)==len(ident) and set(by)==set(expected) and len({r['library_file_id'] for r in ident})==len(ident),'native identity scope differs')
 qp=C/f'library-{phase}-host-create-request.json';rp=C/f'library-{phase}-provider-results.json';q=load(qp);raw=load(rp);paths=q['files'] if 'files' in q else [q['file']];ck(raw.get('isError') is False,'create provider error');rows=raw['structuredContent']['results'];norm=load(C/f'library-{phase}-results.json');witness=[json.loads(s) for s in (C/f'library-{phase}-verified.jsonl').read_text().splitlines()];ck(len(paths)==len(set(paths))==len(rows)==len(ident)==len(norm['results'])==len(witness),'native provider counts differ');ck(identity['exactHostRequest']==norm['exactHostRequest']==pin(qp) and identity['exactProviderResponse']==norm['exactProviderResponse']==pin(rp),'raw request/provider pin differs');ck(norm['route']=='OFFICIAL_ABSOLUTE_PATH_HOST_CREATE','unreviewed native route')
 attr_records=[]
 for path,row,r,w in zip(paths,rows,norm['results'],witness):
  p=P(path);name=p.name;ck(name in by and p.is_absolute(),'unexpected native file');a=by[name];ck(a['localPath']==path and sh(a)==sh(expected[name]),'native local hash binding differs');ck(row['operation']=='create_library_file' and row['status']=='succeeded' and row['path']=='/'+name and row['file_name']==name and row['file_size_bytes']==a['bytes'],'exact provider tuple differs');ck(a['library_file_id']==row['library_file_id'] and a['file_id']==row['file_id'] and type(a['version']) is int and a['version']==row['current_version_number'],'provider identity differs');ck(a['library_file_id'].startswith('libfile_') and a['file_id'].startswith('file_'),'invalid native identifiers')
  attrs=[{'name':'user.library-file-version','value':str(a['version'])}];ck(row['xattrs']==attrs and set(os.listxattr(p))=={x['name'] for x in attrs},'returned/applied attribute set differs');ck(all(os.getxattr(p,x['name']).decode()==x['value'] for x in attrs),'returned attribute bytes differ')
  flags={'providerCreateConfirmed':True,'localBytesVerified':True,'createReceiptAndLocalIdentityVerified':True,'nativeByteReadbackVerified':False,'verificationBasis':'EXACT_SERVER_CREATE_TUPLE_AND_LOCAL_HASH'};ck(all(a[k]==v for k,v in flags.items()),'native scope flags differ');ck(w=={k:a[k] for k in ['filename','library_file_id','file_id','version','bytes','sha256',*flags]},'local create witness differs');ck(r=={'local_path':path,'purpose':'create_library_file','status':'succeeded','file_id':a['file_id'],'library_file_id':a['library_file_id'],'file_name':name,'local_metadata_applied':True,'current_version_number':a['version'],'returnedXattrsApplied':attrs,'nativeByteReadbackVerified':False},'normalized provider row differs')
  if phase in ['archives','supplement']:ck(M.identity(p)[0]==a['bytes'],'local archive size differs')
  else:check(p,a)
  attr_records.append({'filename':name,'returnedXattrs':attrs,'allReturnedXattrsApplied':True,'noUnreturnedIdentityXattrAdded':True})
 readback=load(C/f'{upper}-NATIVE-READBACK-v1.json');ck(readback=={'status':'DENIED_SCOPE_VIOLATION' if phase=='archives' else 'NOT_ATTEMPTED_AFTER_KNOWN_SCOPE_BOUNDARY','legacyFilenameDoesNotAssertReadback':True,'nativeByteReadbackVerified':False,'nativeMaterializationAttemptsForThisPhase':1 if phase=='archives' else 0,'blockedReadbackEvidence':denial(),'createConfirmedIdentities':pin(ip),'returnedAttributes':attr_records,'statement':NOTE},'truthful native readback witness differs')
 if phase=='archives':check(C/'INDEPENDENT-RENAULT-RECOVERY-VERIFICATION-v1.json',REPLAY_PIN);pair(C/'independent-recovery-v2.resources.json')
 return ident

def seed_accounting(name,passes):
 ck((name,passes) in [('SEED-READ-ACCOUNTING-after-docs-v1.json',6),('SEED-READ-ACCOUNTING-after-active-v1.json',7)],'unreviewed seed adaptation');result=BASE_SEED(name,passes+1);completed=[p for p in result['phases'] if p['invocation']['path']=='scan-delivery-supplement-v1.resources.invocation.json'];ck(len(completed)==1 and completed[0]['outcome']=='PASS','extra seed pass is not exact supplement scan');return result

def scoped_receipt(d):
 ck(d['acceptanceScope']==SCOPE and d['nativeByteReadbackVerified'] is False and d['nativePersistenceStatus']=='CREATE_CONFIRMED_NATIVE_BYTE_READBACK_UNPASSED' and d['blockedReadbackEvidence']==denial(),'independent receipt scope differs');ck(d['sealedBaseChecker']==pin(C/BASE) and d['deliveryAdapter']==pin(C/DELIVERY),'independent helper pins differ')

def boundary(document,supplement):
 ck(document['status']==STATUS and document['nativePersistenceStatus']=='CREATE_CONFIRMED_NATIVE_BYTE_READBACK_UNPASSED' and document['nativeByteReadbackVerified'] is False and document['deliveryVerificationAcceptanceScope']==SCOPE and document['nativePersistenceLimitation']==NOTE and document['blockedReadbackEvidence']==denial(),'document persistence limitation differs');ck(document['deliveryAdapter']==pin(C/DELIVERY),'document delivery adapter pin differs');a=document['supplementalDeliveryVerificationArtifact'];ck(a['identity']==supplement and a['nativeByteReadbackVerified'] is False and 'not part of the unchanged 142-archive recovery set' in a['purpose'],'supplement identity/scope absent')
 for k,n in [('package','DELIVERY-SUPPLEMENT-PACKAGE-v1.json'),('memberInventory','DELIVERY-SUPPLEMENT-MEMBER-INVENTORY-v1.json'),('privacyGate','DELIVERY-SUPPLEMENT-PRIVACY-GATE-v1.json'),('nativeIdentityReceipt','DELIVERY-SUPPLEMENT-UPLOAD-IDENTITIES.json')]:ck(a[k]==pin(C/n),'supplement dependency pointer differs')
 for kind,name,sha in [('builder','build_delivery_v4.py','4229243b2972fe978bc88a5311a6b4ef72749fb5493d603f51003edb63511071'),('finisher','finalize_delivery_v2.py','d11db39f6d1f26ecf5cc94894e2c1f7d9f8061485e7104c7932af3e455d10698')]:ck(document['sealedBaseHelpers'][kind]==pin(C/name) and pin(C/name)['sha256']==sha,'sealed delivery helper pin differs')

def extra_checks(mode,result):
 inv,package,expected=supplement_metadata();supp=native('supplement',{ARTIFACT:package})[0];replay_supplement(package,expected)
 targets=[M.DOCS[1],M.DOCS[2]]+([M.ACTIVE] if mode in ['active','persisted','terminal'] else [])+([C/'FINAL-RENAULT-UPLOAD-RECEIPTS.json'] if mode in ['persisted','terminal'] else [])
 for p in targets:boundary(load(p),supp)
 index=M.DOCS[0].read_text();ck(index.count(NOTE)==1 and ARTIFACT in index and supp['library_file_id'] in index and supp['sha256'] in index and str(supp['bytes']) in index,'index lacks exact supplement identity/limitation');ck(M.DOCS[3].read_text().endswith(FOOTER),'summary boundary footer missing')
 kept={**retained(),**M.embedded(load(M.DOCS[2])['postSealEvidence'])};required=['DELIVERY-SUPPLEMENT-MEMBER-INVENTORY-v1.json','DELIVERY-SUPPLEMENT-PACKAGE-v1.json','DELIVERY-SUPPLEMENT-PRIVACY-SELECTION-v1.json','DELIVERY-SUPPLEMENT-PRIVACY-GATE-v1.json','DELIVERY-SUPPLEMENT-UPLOAD-IDENTITIES.json','DELIVERY-SUPPLEMENT-NATIVE-READBACK-v1.json','scan-delivery-supplement-v1.resources.json','scan-delivery-supplement-v1.resources.invocation.json','library-supplement-host-create-request.json','library-supplement-provider-results.json','library-supplement-results.json','library-supplement-verified.jsonl','library-archives-host-create-request.json','library-archives-provider-results.json','library-archives-results.json','library-archives-verified.jsonl','library-archives-materialize-request.json','library-archives-materialize-provider-results.json']
 for stage,args in [('normalize-archives-v1',['normalize','archives']),('package-delivery-supplement-v1',['package']),('normalize-supplement-v1',['normalize','supplement'])]:
  t=pair(C/(stage+'.resources.json'));ck(t['command']==['python3',DELIVERY,*args],'delivery phase terminal command differs');required.extend([stage+'.resources.json',stage+'.resources.invocation.json','run-logs/'+stage+'.stdout.log','run-logs/'+stage+'.stderr.log'])
 for n in required:ck(kept.get(str(C/n))==sh(pin(C/n)),'late supplement/access evidence not recoverable '+n)
 for folder in ['seed-read-invocations','audi-seed-read-invocations','deepal-seed-read-invocations']:
  terminal=pair(C/'scan-delivery-supplement-v1.resources.json');rows=[p for p in (C/folder).glob('*.json') if (lambda d:d['processId']==terminal['childPid'] and terminal['startedAt']<=d['completedAt']<=terminal['endedAt'])(load(p))];ck(len(rows)==1 and kept.get(str(rows[0]))==sh(pin(rows[0])),'supplement seed ledger not retained')
 if mode!='documents':scoped_receipt(load(C/M.NAMES['documents']))
 if mode in ['persisted','terminal']:scoped_receipt(load(C/M.NAMES['active']))
 allids=[r['library_file_id'] for r in result.get('files',result.get('nativeArchiveIdentities',[]))]+[supp['library_file_id']];ck(len(allids)==len(set(allids)),'supplement native ID collides')
 result.update({'seedCompletedInvocations':7 if mode=='documents' else 8,'supplementalArtifactReplay':SUPPLEMENT_REPLAY,'supplementalArtifactIdentity':supp,'supplementOutside142ArchiveRecoverySet':True,'nativeIdentityChecks':'Exact server create tuple, request, matching local hash evidence, and all and only returned version xattrs; native byte-readback unpassed'})
 return result
M.retained=retained;M.native=native;M.seed_accounting=seed_accounting

def main():
 global MODE
 ck(len(sys.argv)==2 and sys.argv[1] in M.NAMES,'documents|active|persisted|terminal required');MODE=sys.argv[1];resource.setrlimit(resource.RLIMIT_AS,(M.LIMIT,M.LIMIT));out=C/M.NAMES[MODE];ck(not out.exists(),'immutable acceptance already exists');start=time.monotonic();result=getattr(M,MODE)();result=extra_checks(MODE,result)
 record={'schemaVersion':2,'result':'PASS_INDEPENDENT_RENAULT_'+MODE.upper(),'acceptanceScope':SCOPE,'nativePersistenceStatus':'CREATE_CONFIRMED_NATIVE_BYTE_READBACK_UNPASSED','nativeByteReadbackVerified':False,'blockedReadbackEvidence':denial(),'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checkerScript':pin(__file__),'sealedBaseChecker':pin(C/BASE),'deliveryAdapter':pin(C/DELIVERY),'adaptations':['Strict actual create tuple and only returned local xattrs','Exact supplemental retention and independent new-artifact member/XZ replay','Exactly one additional supplement seed pass','One pinned documents() AST summary RHS footer addition; every other sealed content assertion unchanged'],**result,'scope':{'oldRecoveryArchivePayloadReads':0,'supplementArchiveReplay':MODE=='documents','seedPayloadReads':0,'noExcludedRawRead':True,'noNativeReadbackAttempt':True,'noUploadOrExternalMutation':True,'noCompilerBuildOrUiExecution':True},'resources':{'wallSeconds':round(time.monotonic()-start,3),'maxRssKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'addressSpaceLimitBytes':M.LIMIT}}
 with out.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
 print(json.dumps({'result':record['result'],'acceptanceScope':SCOPE,'nativeByteReadbackVerified':False,'output':pin(out)}))
if __name__=='__main__':main()
