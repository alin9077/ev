exec(open('/tmp/audi-research/build-normalized.py').read())
# Body-wide Q4 storage applies across each named body, per the maker paragraph scope.
for v in V:
 c=v['coreFacts'];e=v['extraFacts'];vid=v['id']
 if 'audi_q4_suv_my27' in vid:
  c['boot_l']=f('boot_l',515,['au-q4-page'],'Rear seats up; measurement protocol unstated','confirmed','',loc='Generic Q4 SUV cargo paragraph, outside the quattro-only Performance in numbers block',qual=['Maker body-wide storage applies to both MY27 SUV grades. No VDA or other protocol is inferred; not ranked.'],scope='explicit_au_range',rank=False)
  e['max_total_cargo_l']=f('max_total_cargo_l',1487,['au-q4-page'],'Rear seats folded; protocol unstated','confirmed','',loc='Q4 SUV body-wide cargo paragraph',scope='explicit_au_range',unit='L',rank=False)
 if 'audi_q4_sportback_my27' in vid:
  e['max_total_cargo_l']=f('max_total_cargo_l',1460,['au-q4-sportback-page'],'Rear seats folded; protocol unstated','confirmed','',loc='Q4 Sportback body-wide cargo paragraph',scope='explicit_au_range',unit='L',rank=False)
 if 'audi_q4_' in vid and '150kw' in vid:
  source='q4-rb-performance-sportback' if 'sportback' in vid else 'q4-rb-performance-suv'
  for k,val in [('length_mm',4591),('width_mm',1865),('height_mm',1602 if 'sportback' in vid else 1619)]:c[k]=f(k,val,[source],'Reported same-body MY27 quattro sibling dimension','reported','',loc='Exact MY27 Australian quattro performance structured record; carried sibling observation',qual=['The exact base record omits dimensions. Same-body MY27 sibling figure is visible as Reported and unranked; no exact-base confirmation claimed.'])
 if 'audi_q6_sportback_my26' in vid:
  c['seats']=f('seats',5,['au-q6-generation','ce-q6-sportback-review'],'Reported seating from related Q6 SUV body','reported','',qual=['Audi confirms five seats for the Q6 SUV; Sportback review is consistent with the layout but the exact MY26 Sportback maker count is not printed. Carried sibling value, not independently confirmed.'])
 if vid==B[1]['id']:
  c['height_mm']['buyerGrade']='check';c['height_mm']['status']='conditional';c['height_mm']['rankingEligible']=False;c['height_mm']['comparisonBasis']='';c['height_mm']['conflictId']='sq6_suv_height_sources';c['height_mm']['sourceKeys'].append('rb-q6-sq6-web')
 if 'sport_edition' in vid:
  v['availability']['sourceKeys'].append('ce-q6-my27');v['availability']['qualifications'].append('MY26 identity is explicit in the Australian MY27 price-change report for both Sport edition bodies; maker legal footnote directly states MY26 only for the SUV.')
  if 'sportback' in vid:c['price_aud'].pop('validUntil',None);c['price_aud']['qualifications'].append('Do not import the SUV legal expiry or WA/private-buyer conditions into this Sportback offer. Maker body says until October; legal footnote has different SUV-only timing.')
 if vid==B[4]['id']:
  c['boot_l']['buyerGrade']='check';c['boot_l']['status']='conditional';c['boot_l']['sourceKeys'].append('gt-gt-carexpert-review');c['boot_l']['conflictId']='s_gt_boot_405_350';c['boot_l']['qualifications'].append('Two Australian secondary sources disagree:405L database versus350L local review. Current AU B&O equipment may matter, but no causal adjustment is inferred. Both observations remain unranked.')
# Improve legibility of human-facing observations without changing identifiers or numeric values.
import re
fixes={'21-minute10–80%':'21-minute 10–80%','published21-minute':'published 21-minute','is4771mm':'is 4771 mm','has75.8kWh':'has 75.8 kWh','its225kW':'its 225 kW','SQ6’s270kW':'SQ6’s 270 kW','paint,20-inch':'paint, 20-inch','is95900':'is A$95,900','inconsistent95900/95500':'inconsistent A$95,900/A$95,500','The95900':'The A$95,900','by31October2026':'by 31 October 2026','first half of2027':'first half of 2027','announced71650before-on-road':'announced A$71,650 before-on-road','a59kWh':'a 59 kWh','and150kW':'and 150 kW','250kW and a claimed5.4-second0–100km/h':'250 kW and a claimed 5.4-second 0–100 km/h','Audi’s494/509km':'Audi’s 494/509 km','the150kW':'the 150 kW','its59kWh':'its 59 kWh','quattro’s77kWh':'quattro’s 77 kWh','first-half2027':'first-half 2027','olderMY26':'older MY26','Exact150kW':'Exact 150 kW','base150kW':'base 150 kW','European391–451km':'European 391–451 km','performance-page11kW':'performance-page 11 kW','11September2026':'11 September 2026','225kW/21min':'225 kW/21 min','body says95500':'body says A$95,500','quotes95900':'quotes A$95,900','SUV95900':'SUV A$95,900','delivered1–31October2026':'delivered 1–31 October 2026','says20min':'says 20 min','says21min':'says 21 min','no20–21':'no 20–21','MY26/global':'MY26/global','driveaway;':' driveaway;','seconds to100km/h':' seconds to 100 km/h','normal operation and':'normal operation and ','is{':'is {'}
def tidy(x):
 if isinstance(x,str):
  for a,b in fixes.items():x=x.replace(a,b)
  x=re.sub(r'(?<=\d)(kW|kWh|km|mm|L|seconds|before on-road)',r' \1',x)
  x=re.sub(r'(is|with)(?=\d)',r'\1 ',x)
  return x
 if isinstance(x,list):return [tidy(y) for y in x]
 if isinstance(x,dict):return {k:(y if k in ['id','modelId','sourceKeys','primarySourceKey','sourcePointer','conflictId','dependencies'] else tidy(y)) for k,y in x.items()}
 return x
N['variants']=tidy(V);N['status']='normalized proposal v2 frozen for independent review';p=R/'normalized-review-v2.json';p.write_text(json.dumps(N,indent=2,ensure_ascii=False)+'\n');print('v2',hashlib.sha256(p.read_bytes()).hexdigest())
