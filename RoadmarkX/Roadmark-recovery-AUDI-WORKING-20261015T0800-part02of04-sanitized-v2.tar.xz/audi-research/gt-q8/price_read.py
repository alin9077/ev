import urllib.request,json,pathlib,hashlib,datetime
D=pathlib.Path('/tmp/audi-research/gt-q8')
def req(n,u,p=None):
 
 try:r=urllib.request.urlopen(urllib.request.Request(u,data=json.dumps(p).encode() if p else None,headers={'Content-Type':'application/json','User-Agent':'Mozilla/5.0'}),timeout=30)
 except urllib.error.HTTPError as e:print(e.read().decode());raise
 b=r.read();(D/(n+'.json')).write_bytes(b)
 with open(D/'manifest.jsonl','a') as f:f.write(json.dumps(dict(name=n,url=u,request_body=p,final_url=r.url,status=r.status,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),body_path=str(D/(n+'.json')),captured_at=datetime.datetime.now(datetime.timezone.utc).isoformat()))+'\n')
 return json.loads(b)
u='https://api-graphql.audiproduction.com.au/graphql'
q='query ($skip: Int, $take: Int, $sort: VariantDtoSortInput!, $filter: VariantDtoFilterInput) { variantList(skip:$skip,take:$take,order:[$sort],where:$filter) { items { variantId name modelId } totalCount } }'
p={'query':q,'variables':{'skip':0,'take':50,'sort':{'name':'ASC'},'filter':{'status':{'eq':True},'startingPriceCalculator':{'eq':True}}}}
r=req('calculator-current-variants',u,p)
for v in r.get('data',{}).get('variantList',{}).get('items',[]):
 if 'GT' not in v['name']:continue
 print(v)
 q='query ($skip: Int, $take: Int, $sort: EngineDtoSortInput!, $filter: EngineDtoFilterInput) { engineList(skip:$skip,take:$take,order:[$sort],where:$filter) { items { value:engineId label:name modelCode year } totalCount } }'
 p={'query':q,'variables':{'skip':0,'take':50,'sort':{'displayOrder':'ASC'},'filter':{'status':{'eq':True},'variantId':{'eq':v['variantId']}}}}
 e=req('calculator-engines-'+str(v['variantId']),u,p);print(e)
 for eng in e.get('data',{}).get('engineList',{}).get('items',[]):
  pu=f"https://api.myaudi.com.au/1/legacy/GetPrice?variantId={v['variantId']}&state=NSW&engineId={eng['value']}"
  print(req('calculator-price-'+str(eng['value'])+'-NSW',pu))
