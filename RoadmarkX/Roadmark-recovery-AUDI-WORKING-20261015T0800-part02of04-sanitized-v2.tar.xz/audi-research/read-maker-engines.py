from pathlib import Path
import sys,json,concurrent.futures
sys.path.insert(0,'/tmp/audi-research');from importlib.machinery import SourceFileLoader
m=SourceFileLoader('maker','/tmp/audi-research/read-maker-api.py').load_module();q=json.load(open('/tmp/audi-research/sources/au-price-calculator-observed-queries.json'))
ids=[207,208,213,239,221,240,236,190,238]
def f(i):
 x=m.request('au-calculator-engines-'+str(i),'https://api-graphql.audiproduction.com.au/graphql',dict(query=q[4],variables=dict(skip=0,take=50,sort={'displayOrder':'ASC'},filter={'status':{'eq':True},'variantId':{'eq':i}})))
 return i,x
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as e:
 for i,x in e.map(f,ids):print(i,json.dumps(x))
