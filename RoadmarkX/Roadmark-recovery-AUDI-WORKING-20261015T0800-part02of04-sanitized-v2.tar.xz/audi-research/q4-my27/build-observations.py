import json,hashlib,pathlib,datetime
b=pathlib.Path('/tmp/audi-research/q4-my27'); p=pathlib.Path('/tmp/audi-research/sources')
sources={}
for key in ['au-q4-page','au-q4-sportback-page','au-q4-new','ce-q4-my27-pricing']:
 r=json.loads((p/(key+'-receipt.json')).read_text()); sources[key]={'url':r['url'],'checkedAt':r['checkedAt'],'capturePath':r['rawPath'],'sha256':r['rawSha256'],'type':'primary' if key.startswith('au-') else 'secondary','captureKind':'public HTTP response body'}
records={
 'rb-base-suv':('https://www.redbook.com.au/cars/details/2026-audi-q4-e-tron-auto-my27/SPOT-ITM-699401?Cr=58','redbook-discovery-web.json'),
 'rb-base-sportback':('https://www.redbook.com.au/cars/details/2026-audi-q4-e-tron-auto-my27/SPOT-ITM-699402?Cr=77','redbook-discovery-web.json'),
 'rb-performance-suv':('https://www.redbook.com.au/cars/details/2026-audi-q4-e-tron-performance-s-line-auto-e-quattro-my27/SPOT-ITM-699403?Cr=12','redbook-suv-final-web.json'),
 'rb-performance-sportback':('https://www.redbook.com.au/cars/details/2026-audi-q4-e-tron-performance-s-line-auto-e-quattro-my27/SPOT-ITM-699404?Cr=45','suv-performance-discovery-web.json')
}
for key,(url,file) in records.items():
 sources[key]={'url':url,'checkedDate':'2026-10-15','capturePath':str(b/file),'sha256':hashlib.sha256((b/file).read_bytes()).hexdigest(),'type':'secondary','captureKind':'public web search indexed body; exact AU MY27 structured record, not dealer advertisement','limitations':'Direct HTTP capture returned 403 for supplied Sportback URLs; repeated exact web-open variants often cache-missed. Source fields are from indexed public record bodies. Generic editorial overview still describes the outgoing 45/55 and is not used. Indexed range values vary by cache snapshot; maker values supersede them.'}
def fact(value,unit,status,src,basis=None,reason=None):
 d={'value':value,'unit':unit,'status':status,'sources':src}
 if basis:d['basis']=basis
 if reason:d['reason']=reason
 return d
rows=[]
for body in ['SUV','Sportback']:
 for grade in ['150 kW RWD','quattro performance 250 kW AWD']:
  perf=grade.startswith('quattro'); bk='suv' if body=='SUV' else 'sportback'; rb='rb-'+('performance' if perf else 'base')+'-'+bk; mk='au-q4-page' if body=='SUV' else 'au-q4-sportback-page'
  row={'modelYear':'MY27','name':'Audi Q4 '+('Sportback ' if body=='Sportback' else '')+'e-tron '+grade,'market':'Australia','body':body,'grade':grade,'facts':{}}
  f=row['facts'];f['seats']=fact(5,'seats','secondaryReported',[rb],'Exact MY27 Australian record Seat Capacity field; current maker page does not independently give count')
  f['acceleration0to100']=fact(5.4 if perf else 8.2,'seconds','primary' if perf else 'secondaryReported',[mk] if perf else [rb],'Maker exact performance highlight' if perf else 'Exact MY27 AU RedBook structured Acceleration 0–100km/h field; no AU maker confirmation in checked pages/article. International launch sources quote 8.1 s and are not substituted')
  if perf:
   for key,value in [('length',4591),('width',1865),('height',1619 if body=='SUV' else 1602),('wheelbase',2773)]:
    f[key]=fact(value,'mm','secondaryReported',[rb],'Exact MY27 grade/body structured dimension; width field does not state mirror inclusion/exclusion')
   f['brakedTowing']=fact(1800,'kg','secondaryReported',[rb],'Exact MY27 grade/body Towing Capacity (braked) field; confirm vehicle towbar/load restrictions before towing')
   f['bootSeatsUp']=fact(515 if body=='SUV' else None,'L','primary' if body=='SUV' else 'Not published',[mk] if body=='SUV' else [mk,rb], 'Current AU MY27 page named quattro performance; no VDA/SAE measurement method stated' if body=='SUV' else None, None if body=='SUV' else 'Current AU MY27 Sportback page publishes folded volume only; exact RedBook MY27 record has no cargo volume. Old 535 L value is not carried forward')
   f['bootSeatsFolded']=fact(1487 if body=='SUV' else 1460,'L','primary',[mk],'Current AU MY27 page named quattro performance; rear seats folded; method not stated')
  else:
   for key in ['length','width','height','wheelbase']:
    f[key]=fact(None,'mm','Not published',[mk,rb],reason='No exact base-grade dimensions on current AU maker page or indexed MY27 150 kW RedBook record. Performance-grade dimensions and MY25 PDF not transferred')
   f['brakedTowing']=fact(None,'kg','Not published',[mk,rb],reason='Current AU maker page and exact MY27 base RedBook record do not publish a braked limit; RedBook unbraked 750 kg cannot substitute')
   for key in ['bootSeatsUp','bootSeatsFolded']:
    f[key]=fact(None,'L','Not published',[mk,rb],reason='MY27 maker page is headed by quattro performance. Storage paragraph is body-generic but does not explicitly confirm 150 kW applicability; exact base RedBook record omits cargo volume. Conservative gap retained')
   f['australianRange']=fact(None,'km','Not confirmed',['ce-q4-my27-pricing','au-q4-new'],reason='CarExpert explicitly states Audi Australia has not confirmed local base-model range. European range is not an Australian substitute')
  rows.append(row)
out={'asOfDate':'2026-10-15','scope':'Bounded MY27 Australian Q4 core-fact gap check, four announced grades; no further residual dealer ads','sources':sources,'observations':rows,'priorityRules':['Exact MY27 AU structured fields only; generic outgoing 45/55 RedBook prose rejected','Primary current AU MY27 maker storage observations apply conservatively to named performance grade only','No unqualified MY25 carry-forward; no European range/towing/dimensions substituted for an Australian gap','Secondary indexed records are marked secondaryReported, not primary confirmed'],'sourceQualityNotes':['AU maker New horizons prices are $71,650 for either 150 kW body, $81,650 performance SUV and $83,250 performance Sportback. Earlier parent handoff with $83,250 for both performance bodies was corrected; RedBook agrees','Maker SUV cargo is 515/1487 L; do not silently use old 520/1490 L. Current Sportback page only provides 1460 L folded','Range cycle remains parent-owned conflict: maker product-page footnote ADR 81/02 versus maker magazine WLTP. RedBook cached range varies and does not resolve it','Current performance records show 5 seats, 1800 kg braked towing. Base braked towing absent; a 750 kg unbraked value is present but out of requested scope','Two relevant source classes checked per gap: current Australian manufacturer material and exact Australian RedBook MY27 records. Additional searches located exact records but did not broaden to residual ads or foreign specifications'],'strengthsTradeoffs':[{'appliesTo':'150 kW RWD SUV / Sportback','strength':'Lower entry price: $71,650 before on-road costs, saving $10,000 versus performance SUV or $11,600 versus performance Sportback','tradeoff':'150 kW and 59 kWh usable battery versus 250 kW and 77 kWh for performance; secondary AU acceleration 8.2 s versus maker 5.4 s; local base range not yet confirmed','sources':['au-q4-new','ce-q4-my27-pricing','rb-base-suv','rb-base-sportback']},{'appliesTo':'quattro performance SUV','strength':'AWD and maker 5.4-second acceleration with 515 L seats-up /1487 L folded cargo; exact AU secondary record reports 1800 kg braked towing','tradeoff':'Costs $10,000 more before on-road costs than base SUV; 494 km advertised range has a cycle-basis conflict documented separately','sources':['au-q4-page','au-q4-new','rb-performance-suv']},{'appliesTo':'quattro performance Sportback','strength':'Maker advertised range is 509 km, 15 km above performance SUV, with the same 250 kW and 5.4-second acceleration','tradeoff':'$1600 more than performance SUV and current folded cargo claim is 1460 L versus SUV 1487 L; seats-up boot remains unpublished for MY27 AU in checked sources','sources':['au-q4-sportback-page','au-q4-page','au-q4-new']}],'stoppingCondition':'Current maker body pages and announcement plus exact RedBook MY27 records checked. Remaining absent or ambiguous base-grade facts retained as Not published; no broader speculative research'}
(b/'my27-core-observations.json').write_text(json.dumps(out,indent=2)+'\n')
index=[]
for path in sorted(b.iterdir()):
 if path.is_file() and path.name!='capture-index.json':index.append({'file':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(b/'capture-index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps({'report':str(b/'my27-core-observations.json'),'variants':len(rows),'sources':len(sources),'files':len(index)}))
