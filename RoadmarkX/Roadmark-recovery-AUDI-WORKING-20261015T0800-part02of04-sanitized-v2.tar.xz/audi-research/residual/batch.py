import subprocess,concurrent.futures
jobs=[
('perth-lct','https://www.audicentreperth.com.au/en/audi-offers/q4-q6-lct-offer/'),
('asg-q6-sb857070','https://autosportsgroup.com.au/857070-1831260-audi-q6etron-2025/'),
('zag-q6-sb-n57089','https://www.zag.com.au/stock/details/OAG-AD-25294736/2025-audi-q6-e-tron-demo'),
('asg-q4-suv843246','https://autosportsgroup.com.au/843246-1585960-audi-q4etron-2024/'),
('asg-q4-sb843224','https://autosportsgroup.com.au/843224-1588476-audi-q4etron-2024/'),
('asg-q4-55sb840016','https://autosportsgroup.com.au/840016-1519559-audi-q4-2024/'),
('zag-q4-55suv','https://www.zag.com.au/stock/details/OAG-AD-25743769/2024-audi-q4-e-tron-used'),
('melbourne-q4-n58088','https://shop.audicentremelbourne.com.au/listing/2025-audi-q4-e-tron-n58088/'),
('carsguide-q6-placeholder','https://www.carsguide.com.au/car/14861774/audi/q6/suv'),
('carsguide-q4-placeholder','https://www.carsguide.com.au/car/14919016/audi/q4-e-tron/suv'),
]
def run(j):return subprocess.run(['python','/tmp/audi-research/residual/capture.py',*j],capture_output=True,text=True).stdout
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as e:
 for x in e.map(run,jobs):print(x,flush=True)
