from pathlib import Path
import urllib.request,json,hashlib,datetime,sys
root=Path('/tmp/audi-research/sources')
def request(name,url,payload=None):
 req=urllib.request.Request(url,data=json.dumps(payload).encode() if payload else None,headers={'User-Agent':'Mozilla/5.0','Content-Type':'application/json'} if payload else {'User-Agent':'Mozilla/5.0'})
 try:
  r=urllib.request.urlopen(req,timeout=60);b=r.read();p=root/(name+'.json');p.write_bytes(b)
  receipt=dict(key=name,url=url,checkedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),status=r.status,finalUrl=r.url,rawPath=str(p),rawBytes=len(b),rawSha256=hashlib.sha256(b).hexdigest(),request=payload or {},retrieval='Read-only public maker calculator endpoint, exact observed frontend query; no auth or user data')
  (root/(name+'-receipt.json')).write_text(json.dumps(receipt,indent=2));return json.loads(b)
 except Exception as e:print(type(e).__name__,str(e));return {}
if __name__=='__main__':
 q=json.load(open(root/'au-price-calculator-observed-queries.json'))
 out=request('au-calculator-electric-variants','https://api-graphql.audiproduction.com.au/graphql',dict(query=q[0],variables=dict(skip=0,take=50,sort={'name':'ASC'},filter={'status':{'eq':True},'electric':{'eq':True}})))
 print(json.dumps(out,indent=2))
