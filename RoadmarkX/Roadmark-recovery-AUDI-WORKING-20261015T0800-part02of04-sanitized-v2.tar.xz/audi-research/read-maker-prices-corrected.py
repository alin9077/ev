import sys,json,concurrent.futures
from importlib.machinery import SourceFileLoader
m=SourceFileLoader('maker','/tmp/audi-research/read-maker-api.py').load_module()
root=m.root
q=json.load(open(root/'au-price-calculator-observed-queries.json'))
x=m.request('au-calculator-visible-electric-variants','https://api-graphql.audiproduction.com.au/graphql',dict(query=q[0],variables=dict(skip=0,take=50,sort={'name':'ASC'},filter={'status':{'eq':True},'electric':{'eq':True},'startingPriceCalculator':{'eq':True}})))
print('VISIBLE',json.dumps(x))
rows=[]
for i in [207,208,213,239,221,240]:
 for e in json.load(open(root/f'au-calculator-engines-{i}.json'))['data']['engineList']['items']: rows.append((i,e))
def f(row):
 i,e=row;url=f'https://api.myaudi.com.au/1/legacy/GetPrice?variantId={i}&state=NSW&engineId={e["value"]}'
 x=m.request('au-calculator-price-'+str(e['value']),url);return i,e,x
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as e:
 for i,engine,x in e.map(f,rows):print(i,engine,json.dumps(x))
