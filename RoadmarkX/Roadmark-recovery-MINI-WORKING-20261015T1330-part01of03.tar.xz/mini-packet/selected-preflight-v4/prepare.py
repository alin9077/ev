from pathlib import Path
import json,hashlib,re
O=Path('/tmp/mini-packet/selected-preflight-v4');R=Path('/tmp/mini-research');REPO=Path('/workspace/scratch/586427eef9f2/roadmark-104');P=Path('/tmp/mini-packet')
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def write(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
packet=json.loads((P/'mini-2026-10-15-candidate-v3.json').read_text());before=json.loads((R/'retained-before-cars.json').read_text());ids=[c['id'] for c in before];model={c['id']:c['model'] for c in before};facts={(x['variantId'],x['after']['key']):x['after'] for x in packet['facts']}
core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','length_mm','width_mm','height_mm','towing_braked_kg','zero_to_100_s','power_kw','drive','warranty','battery_warranty']
policy=[]
for i in ids:
 for k in core:
  if k in ['drive','warranty','battery_warranty']:continue
  f=facts[i,k]
  eligible=k in ['length_mm','height_mm','seats','zero_to_100_s','power_kw','ac_kw'] or (k=='range_km' and model[i]!='Countryman Electric') or (k=='battery_kwh' and model[i]!='Countryman Electric') or (k in ['dc_peak_kw','dc_charge_time_min'] and not ('countryman' in i and '__82ga_' in i))
  policy.append({'variantId':i,'key':k,'eligible':eligible,'value':f['value'],'buyerGrade':f['buyerGrade'],'comparisonBasis':f['comparisonBasis'],'reason':'Source-reviewed exact value/basis and explicit conflict/price/maximum-range holds; not derived from consumer results.'})
expected={'packetSha256':pin(P/'mini-2026-10-15-candidate-v3.json')['sha256'],'coreKeys':core,'currentListIds':ids,'bodyByModelId':{'mini_cooper_j01':'Hatchback','mini_aceman_j05':'SUV','mini_countryman_u25_bev':'SUV'},'normalizedRankPolicy':policy,'rankingIds':{k:[x['variantId'] for x in policy if x['key']==k and x['eligible']] for k in ['length_mm','range_km','price_aud','dc_charge_time_min','towing_braked_kg','seats','boot_l']},'expectedSettledInventory':['record:mini-cooper','record:mini-aceman','record:mini-countryman'],'factUpdates':153,'termCells':30,'allFeatureClaims':690,'roadsideCanonicalProjections':10,'nonDriveawaySourceFallbacks':10,'expectedOnSaleDelta':0,'fullCatalogueHydration':False,'optionalPropertyCount':'Not guessed; exact same-run producer-owned paths required.'}
write(O/'expected-review.json',expected)
files=set()
# Reuse accepted helper/input boundaries and current repo versions, not obsolete hashes.
for x in json.loads(Path('/tmp/deepal-packet/selected-preflight-v2/source-pins.json').read_text()):
 f=Path(x['path'])
 if str(f).startswith(str(REPO)) or str(f).startswith(('/tmp/xpeng-staging-plan/','/tmp/mercedes-staging-plan/')):files.add(f)
for f in [P/'mini-2026-10-15-candidate-v3.json',P/'mini-market-reconciliation-v3.json',R/'research-manifest-v6.json',R/'residual-census-v2.json',R/'source-gaps-v2.json',R/'retained-before-cars.json',R/'retained-before-selection-receipt.json',Path('/tmp/deepal-packet/full-stage-v4/output/car-digest-comparison.json'),O/'expected-review.json',O/'check.mjs',O/'run.py',O/'prepare.py',Path('/tmp/mini-review/final-review-receipt.json'),REPO/'package.json',REPO/'pnpm-lock.yaml']:files.add(f)
for s in packet['sources']:
 files.add(Path(s['capturePath']))
 if s.get('provenancePath'):files.add(Path(s['provenancePath']))
registry=json.loads((REPO/'data/m1-brand-updates/registry.json').read_text())
for f in registry['packets']:files.add(REPO/'data/m1-brand-updates'/f)
files.update([O/'inventory-resolution-review.json',R/'countryman-alias-audit-v1.json',Path('/tmp/mini-review/preflight-v2-readiness-receipt.json')])
files.update(Path('/tmp/mini-packet/selected-preflight-v2/run')/name for name in ['invocation.json','started.json','terminal.json','after-pins.json','stderr.log','stdout.log'])
files.update([R/'grade-alignment-audit-v1.json',P/'light-static-check-v3.json',P/'core-fact-proposal-v3.json'])
files.update(Path('/tmp/mini-packet/selected-preflight-v3')/name for name in ['result.json','run/terminal.json','run/after-pins.json'])
# Pin static relative import closure of the actual producer modules; no imports executed.
queue=[f for f in files if str(f).startswith(str(REPO)) and f.suffix in ['.ts','.tsx']];seen=set()
while queue:
 f=queue.pop()
 if f in seen:continue
 seen.add(f)
 for spec in re.findall(r'''(?:from\s*|import\s*\(?\s*|require\(\s*)["']([^"']+)["']''',f.read_text()):
  if not spec.startswith('.'):continue
  root=(f.parent/spec).resolve();choices=[root,Path(str(root)+'.ts'),Path(str(root)+'.tsx'),Path(str(root)+'.json'),root/'index.ts']
  hit=next((p for p in choices if p.is_file()),None)
  if hit:
   files.add(hit)
   if hit.suffix in ['.ts','.tsx']:queue.append(hit)
write(O/'source-pins.json',[pin(f) for f in sorted(files)])
m={'status':'prepared_not_executed','script':pin(O/'check.mjs'),'sourcePins':pin(O/'source-pins.json'),'packet':pin(P/'mini-2026-10-15-candidate-v3.json'),'reconciliation':pin(P/'mini-market-reconciliation-v3.json'),'expectedReview':pin(O/'expected-review.json'),'wrapper':pin(O/'run.py'),'command':['node','--max-old-space-size=448','--max-semi-space-size=1','--import','tsx',str(O/'check.mjs'),'--root-execution-granted'],'workdir':str(REPO),'timeoutSeconds':180,'killGraceSeconds':10,'automaticRetry':False,'rootExecutionGrantRequired':True,'exclusiveHeavySlotRequired':True,'scope':'Exactly ten retained MINI before/after cars; actual prepare/apply, 153 guarded facts and 30 term applications, 170 core grades, 690 feature claims, source closure, reviewed rankings, 20 claim-only summary clauses, 10 availability guards and 3 current model reviews. Exact same-run producer-owned optional paths for source/regraded features and citable citations, plus live/written portable and claim parity. Pre-call structured clones guard original/proposed research, selected cars and live packs; exact summary source snapshots and unchanged identities are asserted. Three inherited inventory records are frozen in full; all three settlements and the separate complete three-model/ten-version list remain mandatory, with one source-bound Countryman alias. No helper change, broad catalogue hydration, test/build/server, source edit, registration or automatic retry.'}
write(O/'prepared-command.json',m)
write(O/'root-grant-template.json',{'authorized':False,'exclusiveHeavySlotGranted':False,'action':'run_single_selected_mini_preflight','preparedManifestSha256':pin(O/'prepared-command.json')['sha256'],'command':m['command'],'automaticRetry':False,'note':'Template only. Root must independently review and create an explicit grant after the backup releases the heavy slot.'})
print(json.dumps({'preparedManifest':pin(O/'prepared-command.json'),'script':m['script'],'sourcePins':m['sourcePins'],'wrapper':m['wrapper'],'pinCount':len(files),'executed':False},indent=2))
