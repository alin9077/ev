# MINI selected actual-consumer preflight — prepared only

Candidate v3 contains the independently requested exact ten-fact grade/basis correction. The selected v3 command passed technically for the superseded candidate v2; that result and the earlier v2 failure remain untouched. This v4 command has not run and requires independent source/command review and a fresh explicit root grant of the exclusive heavy slot.

## Narrow v4 correction

Five current named-grade manufacturer WLTP maxima become Confirmed: Cooper SE Favoured 400 km, JCW Electric 371 km, Paul Smith Edition 400 km, Aceman SE 406 km and JCW 355 km. The explicit comparison group is WLTP maximum. A published maximum alone does not justify Check; no tested-delivery or generic laboratory condition is imposed. Five Countryman range cells remain Check because E/SE ALL4 columns cover multiple named packages with 18/19/20-inch choices without package-specific maxima.

Five exact style-selected Countryman maker from-prices also become Confirmed. They remain rung 3, include GST and A$2,500 delivery, and remain unranked because registration/state charges are not itemized and neither allowed road-cost grouping is established. The four BASIC_LINE model responses remain Check for named-style applicability; Paul Smith remains Reported at A$60,990 before ORC. Evidence confidence and ranking compatibility are separate.

Only ten after-fact objects change; all numbers, source evidence, before guards, identities, summaries, availability, reconciliation v3, helpers and the runtime envelope remain unchanged. Summary dependencies use none of the corrected facts and therefore need no edits. Expected range eligibility changes for exactly the five regraded maxima; all price ranking exclusions remain intact. The command assertions are byte-identical to v3 apart from candidate/output paths. The wrapper and exact three-record inventory proof are byte-identical.

See candidate-v2-to-v3.patch, v3-to-v4-script.patch, correction-provenance.json and /tmp/mini-research/grade-alignment-audit-v1.json. No consumer, test, build, server or live edit was executed in preparation.

## Frozen command

Manifest: `/tmp/mini-packet/selected-preflight-v4/prepared-command.json`

SHA256: `6b0971f09153fe4c8afdadf70f54a28ce1529134bc803fa33236ee4d28862546`

After independent command review and an explicit root grant releasing the exclusive heavy slot, the wrapper invocation is:

```sh
python /tmp/mini-packet/selected-preflight-v4/run.py \
  /tmp/mini-packet/selected-preflight-v4/prepared-command.json \
  6b0971f09153fe4c8afdadf70f54a28ce1529134bc803fa33236ee4d28862546 \
  /tmp/mini-packet/selected-preflight-v4/root-execution-grant.json
```

The actual child command is pinned in the manifest: Node with 448 MiB old-space, 1 MiB semi-space and the installed `tsx` loader, executing only `check.mjs`. Supervision is 180 seconds plus a 10-second termination grace. Heap flags are not OS RSS limits. No automatic retry, concurrent command or widening of scope is authorized. The grant template is explicitly unauthorized; preparation does not create a grant.

## Inputs and bounded read path

- Exactly ten full MINI before rows from `retained-before-cars.json`, each matched against its retained receipt and the accepted post-Deepal26 digest
- Actual retained research streamed through the already accepted baseline reader and indexed source files; only the ten variants, ten historic variant contexts, three models and 690 feature rows are retained. Shared source/criteria/context arrays remain source inputs; no production catalogue loader is called
- Live registry must still contain exactly 26 accepted packets ending with Deepal; every preceding packet is checked not to target a MINI row or apply a shared term to one
- Candidate v3 contains only the ten reviewed corrections; reconciliation v3 retains the scoped alias addition. All 197 input pins, including the selected sources, import closure, existing helper modules, registry packets and source-review receipt, are checked before and after execution
- The project's existing compiled-source helper binds the actual evidence-consumer module to the proposed registry sequence. It changes only the injected registry value for this isolated call. No producer/helper implementation is replaced

## Required checks

1. Actual `prepareBrandResearch` and `applyBrandUpdates`, with all ten identity guards, 153 exact before-fact guards, 30 shared-term guards and ten full availability guards
2. All 170 core cells earn their proposed grades. The remaining three net-battery conflict cells and ten roadside applications are also checked, for 183 updated effective cells
3. Twenty summaries keep exact claim-only dependency facts, source IDs and the producer's complete fact-plus-source freshness entries. Unrelated facts cannot become freshness proxies
4. Exactly 69 criteria per selected car, 690 full feature claims. Only the ten canonical roadside projections may change; all unrelated retained feature rows must remain equal. All ten driveaway answers must be the exact actual source-effective fallback, since neither the GST/delivery maker amounts nor Paul Smith's before-ORC price is a driveaway quote
5. Actual fact claims and feature claims must preserve source closure, grades, explicit Not published nulls, conditions and current evidence dates
6. Actual ranking policy is compared against source-reviewed expectations for every numeric core field, plus every supported discovery attribute. All prices, the five Countryman maxima with unresolved style attribution, cargo without protocol, width without mirror basis, null tow ratings and genuine conflicts stay excluded. The five directly named-grade maxima are eligible in the explicit WLTP maximum group. Clean eligible values remain eligible
7. Three current model reviews cover the exact ten identities and the three existing MINI inventory families, independently bound to complete frozen original records. Countryman remains a required settlement. Global independent-list closure stays false; residual/arriving findings remain in the separate census
8. Actual in-memory portable storage/hydration must equal complete live packs. Written JSON/readback and written portable hydration must equal only an independently cloned representation with the exact proven optional paths removed. Live objects stay unchanged
9. Re-running actual citable producers against hydrated written packs must reproduce the live claims. Each serialized citation omission must be an own enumerable undefined `limitation` or `checked` field, tied to the actual source metadata and actual citable-producer replay
10. Feature optional omissions are accepted only at exact selected row/index/criterion/property locations, proven from the same-run source/regrade/final projection and, where applicable, actual `auditedFeature(raw)` output. Counts are observed, never copied from Deepal. Any novel optional property or producer mismatch fails
11. The written C1/report boundary permits only the exact actual `independent_lists` issue's own undefined `brand`/`reference` fields, at the three precise report locations. Full written readback equality and unchanged live result are checked
12. Default catalogue/research loader calls must remain zero and production loader modules must remain absent from the require cache. The before cars, input research and live packs must remain unchanged

## Outputs and failure boundary

Create-only outputs are restricted to this preparation directory and its `run` subdirectory: complete selected cars, packs, portable storage, 183 fact claims, 690 feature claims, exact feature/citation/report omission witnesses, selected coverage, rank proofs and result; the wrapper records invocation, terminal status, wait4 memory/resource evidence, stdout/stderr hashes and before/after pins.

The success status in the script is a conditional future output, not a completed test claim. An unexpected omission, stale pin, producer mismatch, source guard failure or timeout stops the command. Keep its raw output and seek a separately reviewed narrow correction; do not normalize arbitrary values, raise memory, retry automatically or alter a helper to force a pass.
