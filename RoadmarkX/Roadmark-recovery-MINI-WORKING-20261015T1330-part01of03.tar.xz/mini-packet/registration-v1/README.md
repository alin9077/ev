# MINI minimal guarded registration

Preparation only. Exactly four writes: two new JSON files, append-only registry position 27, and one import plus final reconciliation argument in the report loader. Candidate v3 and reconciliation v3 remain byte-identical. No helper or test changes.

Application requires independent full-stage result acceptance, bundle review and a separate exact root application grant. The applicator checks all before hashes and proposed bytes before writing, journals each write, and stops on any failure without automatic retry or rollback. Tests, compilers and normal reports are separately authorized gates.
