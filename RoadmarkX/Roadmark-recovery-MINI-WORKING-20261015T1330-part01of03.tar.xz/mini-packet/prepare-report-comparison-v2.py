from pathlib import Path
import difflib,json,hashlib
A=Path('/tmp/mini-packet/report-comparison-v1');B=Path('/tmp/mini-packet/report-comparison-v2');B.mkdir(exist_ok=False)
s=(A/'compare-report.mjs').read_text().replace(str(A),str(B))
s=s.replace("const {buildMarketReconciliation}=require('./scripts/reporting/m1-reconciliation.ts');","const {buildMarketReconciliation,inventoryRecordId}=require('./scripts/reporting/m1-reconciliation.ts');")
needle="const pct=(n,d)=>d?Math.round(n/d*1000)/10:null;"
s=s.replace(needle,needle+"""
const catalogueOrder=new Map(completeBefore.map((car,index)=>[car.id,index]));
assert.equal(catalogueOrder.size,427);assert.deepStrictEqual(completeAfter.map(car=>car.id),completeBefore.map(car=>car.id));
const recordOrder=new Map(inventory.records.map((row,index)=>[inventoryRecordId(row),index]));
const leadOrder=new Map(inventory.unverifiedLeads.map((row,index)=>[inventoryRecordId(row),index]));
assert.equal(recordOrder.size,inventory.records.length);assert.equal(leadOrder.size,inventory.unverifiedLeads.length);
function orderedRows(rows,order,key='carId'){
 assert.equal(new Set(rows.map(row=>row[key])).size,rows.length);
 for(const row of rows)assert(order.has(row[key]),'Row lacks producer input identity '+row[key]);
 return [...rows].sort((a,b)=>order.get(a[key])-order.get(b[key]));
}
function orderedAgeing(rows){
 assert.equal(new Set(rows.map(row=>JSON.stringify([row.carId,row.kind,row.key]))).size,rows.length);
 for(const row of rows){assert(catalogueOrder.has(row.carId));assert(['fact','availability','equipment'].includes(row.kind));}
 // Actual freshnessEntries finishes all cars' facts/availability before iterating features.
 // Each already accepted same-car subsequence is preserved by stable sort; peer and MINI identities are disjoint.
 return [...rows].sort((a,b)=>(a.kind==='equipment'?1:0)-(b.kind==='equipment'?1:0)||catalogueOrder.get(a.carId)-catalogueOrder.get(b.carId));
}
const fullArrayOrderProof=[];
""")
old=""" assert.deepStrictEqual(peer(actual.excluded),peer(old.excluded));assert.deepStrictEqual(deep(actual.excluded),a.excluded);
 const exclusionReasons={};for(const item of actual.excluded)exclusionReasons[item.reason]=(exclusionReasons[item.reason]||0)+1;
 const ranked=old.ranked-b.ranked+a.ranked;assert.equal(actual.rankedIds.length,ranked);assert.equal(actual.excluded.length,normal.onSaleVersions-ranked);"""
new=""" assert.deepStrictEqual(orderedRows(old.excluded,catalogueOrder),old.excluded);
 const expectedExcluded=orderedRows([...peer(old.excluded),...a.excluded],catalogueOrder);
 assert.deepStrictEqual(actual.excluded,expectedExcluded);
 const exclusionReasons={};for(const item of expectedExcluded)exclusionReasons[item.reason]=(exclusionReasons[item.reason]||0)+1;
 const ranked=old.ranked-b.ranked+a.ranked;assert.equal(projection.rankedIds.length,ranked);assert.equal(expectedExcluded.length,normal.onSaleVersions-ranked);
 fullArrayOrderProof.push({path:'rankings/'+old.key+'/excluded',producer:'rankAttribute input-catalogue traversal',beforeRows:old.excluded.length,afterRows:expectedExcluded.length,completeEquality:true});"""
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('groups:projection.groups,excluded:actual.excluded,exclusionReasons','groups:projection.groups,excluded:expectedExcluded,exclusionReasons')
start=s.index("for(const key of ['gaps','summaryGaps']){");end=s.index("const c1=readJson",start)
s=s[:start]+"""assert.deepStrictEqual(peer(normal.gaps),peer(baseline.gaps));assert.deepStrictEqual(deep(normal.gaps),selectedAfter.gaps);assert.deepStrictEqual(normal.gaps,expected.gaps);
assert.deepStrictEqual(orderedRows(baseline.summaryGaps,catalogueOrder),baseline.summaryGaps);
expected.summaryGaps=orderedRows([...peer(baseline.summaryGaps),...selectedAfter.summaryGaps],catalogueOrder);
assert.deepStrictEqual(normal.summaryGaps,expected.summaryGaps);
fullArrayOrderProof.push({path:'summaryGaps',producer:'Tier 1 input-catalogue filter/map order',beforeRows:baseline.summaryGaps.length,afterRows:expected.summaryGaps.length,completeEquality:true});
for(const [key,order]of [['missingModels',recordOrder],['unresolvedLeads',leadOrder]]){
 assert.deepStrictEqual(orderedRows(baseline[key],order,'id'),baseline[key]);
 const peers=baseline[key].filter(row=>row.brand!=='MINI'),selectedRows=selectedAfter[key];
 assert(selectedRows.every(row=>row.brand==='MINI'));
 expected[key]=orderedRows([...peers,...selectedRows],order,'id');assert.deepStrictEqual(normal[key],expected[key]);
 fullArrayOrderProof.push({path:key,producer:'Actual inherited inventory filter/map traversal via inventoryRecordId',beforeRows:baseline[key].length,afterRows:expected[key].length,completeEquality:true});
}
"""+s[end:]
old="""for(const key of ['overdue','invalid','excludedHistory']){
 assert.deepEqual(peer(normal.ageing[key]),peer(baseline.ageing[key]));assert.deepEqual(deep(normal.ageing[key]),selectedAfter.ageing[key]);expected.ageing[key]=normal.ageing[key];
}"""
new="""for(const key of ['overdue','invalid','excludedHistory']){
 assert.deepStrictEqual(orderedAgeing(baseline.ageing[key]),baseline.ageing[key]);
 expected.ageing[key]=orderedAgeing([...peer(baseline.ageing[key]),...selectedAfter.ageing[key]]);
 assert.deepStrictEqual(normal.ageing[key],expected.ageing[key]);
 fullArrayOrderProof.push({path:'ageing/'+key,producer:'freshnessEntries fact/availability phase in catalogue order, then feature phase in catalogue order; accepted same-car order retained',beforeRows:baseline.ageing[key].length,afterRows:expected.ageing[key].length,completeEquality:true});
}
write('full-array-producer-order-proof',fullArrayOrderProof);"""
assert s.count(old)==1;s=s.replace(old,new)
(B/'compare-report.mjs').write_text(s)
readme=(A/'README.md').read_text()+'''\nV2 independently composes every full excluded/summary/inventory/ageing array from unchanged peer values and accepted selected values in the actual catalogue/inventory/producer traversal order. Baseline order is proved first. No array in the expected report is copied from the new normal output. V1 remains retained as a preparation with an interleaving-proof gap; neither version has run.\n'''
(B/'README.md').write_text(readme)
(B/'v1-to-v2.patch').write_text(''.join(difflib.unified_diff((A/'compare-report.mjs').read_text().splitlines(True),s.splitlines(True),fromfile=str(A/'compare-report.mjs'),tofile=str(B/'compare-report.mjs'))))
prepare=(A/'prepare-manifests.py').read_text().replace(str(A),str(B));(B/'prepare-manifests.py').write_text(prepare)
print(str(B))
