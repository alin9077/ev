# MINI documentation and status preparation

Exactly three proposed live documentary writes: new `roadmark-104/docs/MINI_M1_UPDATE.md`, append-only `roadmark-104/docs/M1_PROGRESS.md`, and a history-preserving `roadmark-104-qa/work-status.json` transition. This bundle is prepared only; nothing is applied.

`prepare.py` reads the actual accepted normal report and receipts, keeps exact before copies, creates after copies, and records every pin and diff. The progress prefix is byte-identical; all previous status-history entries and unaffected historical/back-up fields remain structurally exact. Every superseded current field is archived in the new history entry. The before status is also preserved byte-for-byte.

Application requires a separately accepted independent document review and an exact root grant. The independent review JSON must contain `status: accepted` and `manifest.sha256` naming this bundle. Fill the root grant from `root-grant-template.json` with that review's path, byte length and SHA-256; do not change the manifest or allowed targets. Pin the completed grant itself. The applicator invocation is `python apply.py MANIFEST MANIFEST_SHA256 ROOT_GRANT ROOT_GRANT_SHA256`. Preparation is not a grant.

The applicator checks its own/preparer/proof/payload pins, all exact target before hashes, the target allowlist, append-only progress and full history preservation before writing. It journals only the three reviewed writes and their readbacks. It stops on any error without retry, rollback or deletion. No tests, catalogue hydration, report generation, compiler, build, server, browser, preview, archive, upload, M2 or publication work is authorized by this bundle.

The earlier Deepal 26-packet preview blocker remains historical. No MINI preview or visual pass is asserted. Current source has 27 packets; the next brand remains awaiting selection. Historical backup receipts and Library IDs are preserved without implying a new MINI recovery delivery.

Revision v2 preserves the entire frozen v1 bundle. Only wording is corrected: exact Cooper SE Favoured naming, bounded warranty-use classes, and pending recovery status appropriate after documentary application. No source, QA or earlier bundle file is changed.
