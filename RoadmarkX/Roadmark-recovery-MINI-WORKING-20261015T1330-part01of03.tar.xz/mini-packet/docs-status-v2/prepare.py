"""Prepare the three MINI documentary writes; never apply live changes."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import copy
import difflib
import hashlib
import json

BASE = Path('/tmp/mini-packet/docs-status-v2')
WORKSPACE = Path('/workspace/scratch/586427eef9f2')
REPO = WORKSPACE / 'roadmark-104'
QA = WORKSPACE / 'roadmark-104-qa'
NORMAL = Path('/tmp/mini-packet/report-comparison-v2/normal-coverage-asof-2026-10-15/stdout.log')
COMPARISON = Path('/tmp/mini-packet/report-comparison-v2/artifacts/result.json')
REVIEW = Path('/tmp/mini-review')
NOW = datetime.now(timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def pin(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')

def write_bytes(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(value)

def read_json(path):
    return json.loads(Path(path).read_text())

expected = {
    REPO / 'data/m1-brand-updates/mini-2026-10-15.json': '14c9007e7708d70de30e0aabd4f5ab3c56dbf38cfde65a44a04f065ee147e916',
    REPO / 'data/m1-mini-market-reconciliation-2026-10-15.json': 'e82ebd0a3f1d72e358d95150d2b8f45495b8ac226d151e13edb341ab02b8dfae',
    Path('/tmp/mini-packet/registration-v1/manifest.json'): 'be800ea1eca26be7f3c9e2f89f4047fafa6bdf5457d75944bc7ffa8264e9c190',
    NORMAL: '0cd717ad3b1db049e14559010770b9b5dfb1e9ed05718ca7635d82a6bbde4464',
    COMPARISON: 'f94ef8f4e5ac27a883befd907fc36d16ef7d35df41aa3c099afbfe59eda51339',
    REVIEW / 'report-comparison-v2-output-review.json': 'a2a74287cacf0083b10944f0a3c1780b7d4fa8c570dc17fbba6dd6d6bdf848eb',
}
for path, digest in expected.items():
    assert sha(path) == digest, str(path)
assert not (BASE / 'manifest.json').exists()
assert not (REPO / 'docs/MINI_M1_UPDATE.md').exists()
status_raw = (QA / 'work-status.json').read_bytes()
old = json.loads(status_raw)
progress_raw = (REPO / 'docs/M1_PROGRESS.md').read_bytes()
report = read_json(NORMAL)
comparison = read_json(COMPARISON)
brand = next(row for row in report['brandProgress'] if row['brand'] == 'MINI')
registration = read_json('/tmp/mini-packet/registration-v1/manifest.json')
five_gates = read_json(REVIEW / 'post-registration-five-gate-results-v1.json')
tsc = read_json(REVIEW / 'full-project-typescript-v1-output-review.json')
output_review = read_json(REVIEW / 'report-comparison-v2-output-review.json')
assert old['currentBrand'] == 'Deepal' and old['nextBrand'] == 'MINI'
assert len(old['workStatusHistory']) == 7
assert report['asOf'] == '2026-10-15'
assert [report['allCatalogueVersions'], report['tierOneVersions'], report['onSaleVersions']] == [427, 350, 309]
assert report['grading']['reviewedCoreCells'] == 5026 and report['grading']['totalCoreCells'] == 5253
assert len(report['gaps']) == 312 and len(report['missingModels']) == 19 and len(report['unresolvedLeads']) == 24
assert len(report['brandsResearchCompleted']) == 13 and len(report['brandsResearchRemaining']) == 43
assert brand['researchCompleted'] and not brand['done']
assert brand['criteria'] == {'C1': False, 'C2': False, 'C3': True, 'C4': True, 'C5': False, 'C6': True}
assert brand['coreGaps'] == 10 and brand['missingSummaries'] == 0 and brand['agedOrInvalidClaims'] == 0
assert len(brand['currentVersionReviews']) == 3
assert sum(len(row['versions']) for row in brand['currentVersionReviews']) == 10
assert sum(row['filled'] for row in brand['core']) == 160
assert sum(row['reviewed'] for row in brand['core']) == 170
core_grades = {grade: sum(row['grades'][grade] for row in brand['core']) for grade in ['Confirmed', 'Check', 'Reported', 'Not published', 'Unreviewed']}
assert core_grades == {'Confirmed': 136, 'Check': 23, 'Reported': 1, 'Not published': 10, 'Unreviewed': 0}
assert [row['key'] for row in brand['core'] if row['confirmedPercent'] < 50] == ['towing_braked_kg']
assert comparison['passed'] and comparison['exhaustiveDifferences'] == 2610
assert comparison['peerCompleteCarDigestsExact'] == 417 and comparison['peerBrandObjectsExact'] == 55
assert read_json('/tmp/mini-packet/report-comparison-v2/artifacts/expected-versus-normal-diff.json') == []
assert five_gates['status'] == 'accepted' and all(row['passed'] and row['exitCode'] == 0 for row in five_gates['checks'])
assert tsc['status'] == 'accepted' and tsc['passed'] and tsc['exitCode'] == 0
assert output_review['status'] == 'accepted'
for helper in registration['unchangedHelperPins']:
    assert pin(helper['path']) == helper

# The table is copied verbatim from the accepted actual-report formatter output.
formatted_path = Path('/tmp/mini-packet/report-comparison-v2/artifacts/normal-coverage-formatted.txt')
table_lines = [line for line in formatted_path.read_text().splitlines() if line.startswith('|')]
assert len(table_lines) == 3
core_by_key = {row['key']: row for row in report['core']}
for key in ['price_aud', 'range_km', 'battery_kwh', 'dc_charge_time_min', 'seats', 'boot_l', 'warranty']:
    row = core_by_key[key]
    assert f"{row['filledPercent']:.1f}% / {row['confirmedPercent']:.1f}%" in table_lines[2]
buyer = (BASE / 'buyer-update.md').read_text()
assert buyer.count('{{COVERAGE_TABLE}}') == 1
buyer = buyer.replace('{{COVERAGE_TABLE}}', '\n'.join(table_lines))
append = (BASE / 'progress-append.md').read_bytes()
assert append.startswith(b'\n\n')
write_bytes(BASE / 'before/roadmark-104/docs/M1_PROGRESS.md', progress_raw)
write_bytes(BASE / 'before/roadmark-104-qa/work-status.json', status_raw)
write_bytes(BASE / 'after/roadmark-104/docs/MINI_M1_UPDATE.md', buyer.encode())
write_bytes(BASE / 'after/roadmark-104/docs/M1_PROGRESS.md', progress_raw + append)

qa_path = '/tmp/mini-packet/post-registration-checks-v1/run'
tests = dict(
    brand='MINI', freshTenFileAggregate=dict(passed=144, failed=0, skipped=0, terminal=qa_path + '/behavioural-suites/terminal.json'),
    separateLiveSafety=dict(passed=7, failed=0, skipped=0, terminal=qa_path + '/live-brand-safety/terminal.json'),
    distinctScopedTestsAcrossTheseRuns=151, singleFullProjectAggregate=False, fullProjectSuite=False,
    acceptance=str(REVIEW / 'post-registration-five-gate-results-v1.json'))
typecheck = dict(
    state='Passed cold full-project check with all original configured roots and compiler options', exitCode=0,
    configuredRoots=361, actualCompilerRoots=361, cacheOnlyOverride='Fresh /tmp tsBuildInfoFile; original live cache unchanged',
    literalPackageScript=False, oldSpaceMiB=768, semiSpaceMiB=1, timeoutSeconds=900, killGraceSeconds=10,
    elapsedSeconds=tsc['elapsedSeconds'], wait4MaxRssKiB=tsc['maxRssKiB'], stdoutBytes=0, stderrBytes=0,
    freshCacheRootsExactlyVerified=True, unchangedRootMetadataRows=360, onlyAcceptedLoaderMetadataTransition=True,
    acceptance=str(REVIEW / 'full-project-typescript-v1-output-review.json'))
prior_attempts = [
    dict(stage='selected preflight v2', classification='actual failed assertion', state='retained',
         detail='Countryman inherited inventory identity did not match Countryman Electric without a structured sourced alias; consumer correctly failed closed',
         evidence=str(REVIEW / 'preflight-v2-failure-diagnosis.json')),
    dict(stage='selected preflight v3', classification='superseded successful candidate pass', state='retained',
         detail='Reconciliation v3 sourced alias passed; earlier candidate was later superseded by narrow earned-grade corrections for five named WLTP maxima and five exact Countryman prices',
         evidence=str(REVIEW / 'preflight-v3-output-review.json')),
    dict(stage='full stage v1', classification='held unexecuted preparation', state='retained',
         detail='Duplicate binding, strict shape-check ordering, complete global C1 accounting and terminal storage-pin closure corrected before full stage v2; no runtime failure is claimed',
         evidence=str(REVIEW / 'full-stage-v1-readiness-review.json')),
    dict(stage='normal report/comparator v1', classification='held unexecuted preparation', state='retained',
         detail='Independent full-array interleaving proof was missing; neither the normal report nor comparator v1 was executed. Corrected version 2 executed once each',
         evidence=str(REVIEW / 'report-comparison-v1-readiness-review.json')),
]
coverage = dict(catalogue=427, tier1=350, onSale=309, registeredPackets=27, coreReviewed=5026,
                coreDenominator=5253, strictGaps=312, reviewedModels=101, reviewedVersions=231,
                c1Issues=200, unmatchedAuditModels=19, unresolvedLeads=24,
                researchCompletedBrands=13, researchRemainingBrands=43,
                rankings=output_review['globalResults']['ranked'], criteria=output_review['globalResults']['criteria'])
mini_coverage = dict(onSale=10, currentMakerReviews=3, currentMakerVersions=10,
                     coreCells=170, filled=160, gaps=10, coreGrades=core_grades,
                     unsupportedSummaries=0, agedOrInvalidClaims=0,
                     criteria=brand['criteria'], rankings=brand['rankings'], closureIssues=brand['closureIssues'],
                     onlyUnderHalfConfirmedField='Braked towing: ten explicit two-source absences, never zero ratings',
                     halfConfirmedFields=['price_aud', 'range_km', 'battery_kwh', 'ac_kw'])
working = dict(
    brand='MINI', researchCompleted=True, releaseReady=False,
    packetSha256=expected[REPO / 'data/m1-brand-updates/mini-2026-10-15.json'],
    reconciliationSha256=expected[REPO / 'data/m1-mini-market-reconciliation-2026-10-15.json'],
    registrationManifestSha256=expected[Path('/tmp/mini-packet/registration-v1/manifest.json')],
    validateExit=0, coverageExit=0, changedFileLintExit=0, marketViewExit=0,
    successfulRunDirectory=qa_path, relevantTests=tests, fullTypecheck=typecheck,
    coverage=coverage, miniCoverage=mini_coverage,
    sourceInputsVerified=dict(postRegistrationContentPins=193, fullProjectRoots=361,
                             unchangedRootMetadataRows=360, exactRegistrationTargets=4,
                             unchangedHelperPins=8, unchangedAcceptedFullStageInputs=285),
    selectedStage=dict(state='Selected v4 passed for final candidate v3 and reconciliation v3',
                       cars=10, factAndTermClaims=183, effectiveFeatureClaims=690,
                       summaryClauses=20, summaryDependencies=27,
                       acceptance=str(REVIEW / 'preflight-v4-output-review.json')),
    fullStage=dict(state='Derived full stage v2 passed', completeCars=427, unchangedPeers=417,
                   researchFieldsPerAcceptedStage=14, retainedStorageFiles=21, pinsVerified=287,
                   selectedArtifactsExactToV4=True, completeGlobalC1ExpectedObjectExact=True,
                   acceptance=str(REVIEW / 'full-stage-v2-output-review.json')),
    fullProjectSuite='No current clean full-project test-suite aggregate', productionBuild='Unverified current source',
    realDeviceMobile='Unverified; no MINI preview, browser, screenshot or phone-viewport attempt',
    visualPreview=dict(state='Not attempted for MINI', attempted=False, screenshots=[],
                       appRendered=False, phoneViewportVerified=False, protectedHeroVisuallyInspected=False,
                       historicalDeepalPreview='Earlier 26-packet isolated preview had net::ERR_CONNECTION_REFUSED; retained unchanged under deepalWorking.visualPreview, not a MINI UI result'),
    report=str(NORMAL), reportSha256=sha(NORMAL), reportBytes=NORMAL.stat().st_size,
    reportComparison=dict(state='One actual normal report and separate saved-output comparator v2 passed',
                          result=str(COMPARISON), resultSha256=sha(COMPARISON), exhaustiveDifferences=2610,
                          expectedVersusNormalDiff=[], allNormalLeavesAccounted=True,
                          unchangedPeerCars=417, unchangedPeerBrandObjects=55,
                          completeProducerArrayInterleavingVerified=True,
                          peerRankMembershipAndOrderWithinMeasurementGroupsExact=True,
                          groupOrderEqualsActualProducer=True,
                          completeCoreReasonInventory=True, selectedBeforeFeatureRows=690,
                          unchangedSelectedNonRoadsideFeatureRows=680, peerFeaturesReplayed=0),
    reportAcceptance=str(REVIEW / 'report-comparison-v2-output-review.json'),
    reportAcceptanceSha256=expected[REVIEW / 'report-comparison-v2-output-review.json'],
    historicalAttemptsRetained=prior_attempts,
    newCanonicalCapture=False, extraBroadFeatureReplay=False, ordinaryReportInherentFeatureWork=True,
    helpersChanged=False, testsChanged=False, equipmentResearchExpanded=False, uiLayoutChangesApplied=False,
    publicationAuthorized=False)
research = dict(
    versions=10, retainedRefreshes=10, additions=0, currentMakerFamilies=3, currentMakerVersions=10,
    families={'Cooper': 3, 'Aceman': 2, 'Countryman Electric': 5}, onSale=10,
    coreObservations=170, filledCoreCells=160, confirmed=136, check=23, reported=1, notPublished=10,
    specificFactUpdates=153, sharedTerms=3, sharedTermApplications=30, earnedFactAndTermCells=183,
    effectiveFeatureClaims=690, guardedAvailabilityUpdates=10, summaryClauses=20,
    selectedPricesAud={
        'Cooper SE Favoured': 61489.70, 'Cooper JCW Electric': 66490.30,
        'Cooper SE Paul Smith Edition': 60990, 'Aceman SE': 63489.50, 'Aceman JCW': 68490.10,
        'Countryman E Classic': 71490, 'Countryman E Favoured': 74490,
        'Countryman SE ALL4 Classic': 76490, 'Countryman SE ALL4 Favoured': 79490,
        'Countryman SE ALL4 JCW Sport': 82490.01},
    makerPriceBasis='Nine maker from-prices include GST and A$2,500 delivery; other road-cost grouping unresolved, all unranked. Never relabel before on-road or driveaway; no subtraction or rounding',
    countrymanPriceGrades='Five exact style-selected amounts Confirmed; road-cost grouping affects ranking rather than evidence confidence',
    cooperAcemanPriceGrades='Four BASIC_LINE maker responses Check for actual named-style applicability',
    paulSmithPrice='A$60,990 before on-road costs from CarExpert; Reported and unranked after exact maker price absent at two sources',
    confirmedNamedWltpMaximaKm={'Cooper SE Favoured': 400, 'Cooper JCW Electric': 371, 'Cooper SE Paul Smith Edition': 400, 'Aceman SE': 406, 'Aceman JCW': 355},
    rangeBasis='Five directly named maxima Confirmed in explicit WLTP maximum group; no generic delivered-wheel or laboratory downgrade',
    countrymanRangeChecks='E 501 km and SE ALL4 467 km remain Check across five grades because maker columns span styles and 18/19/20-inch choices without exact package-specific maxima',
    batteryConflicts=['Regular Cooper extra usable observation: 49.8 kWh net brochure versus 49.2 kWh web',
                      'Paul Smith dedicated 48.2 kWh net versus 49.2 kWh web/secondary; no regular-sibling 49.8 substitution',
                      'Countryman 66 kWh net grade pages versus 64.8 kWh technical/charging and ambiguous Usable/Gross 66 kWh table'],
    acemanUsableBatteryKwh=49.2,
    charging='Countryman E 95 versus 130 kW conflict and 29-minute 10–80% time held conditional/unranked; Cooper 30-minute and Aceman 31-minute claims refreshed, not newly discovered',
    roadside='Eight-year BEV warranty-brochure versus five-year model-brochure conflict retained as Check',
    towing='Ten Not published results after exact official brochure plus technical TRAILER_LOAD_ID null; absence and towbar availability are not zero ratings',
    measurementGaps=['Cargo protocol and seat-loading boundary unstated', 'Width mirror basis unstated', 'Vehicle DC peak does not establish timed-test station rating'],
    residualCensus=dict(untamed='Arriving; order eligibility and exact purchasable identity unestablished',
                        victory1965='Limited-edition residual-new lead; unsold New stock/order acceptance unverified',
                        eGradeLeads='Cooper E, Aceman E/E Classic and Countryman E Core maker-versus-calendar-guide differences retained',
                        oxford='Excluded on explicit Australian petrol evidence',
                        researchCompletionBoundary='Report marks bounded current named-list/core research complete; separate residual/edition observations remain visible, not resolved nationwide stock claims'),
    physicalStockVerified=False, factoryOrderAcceptanceVerified=False, wholeMarketC1Closed=False,
    noNationalBestClaim=True, sourceEvidence='Sanitized public sources; no keys or tokens saved',
    sourceGaps='/tmp/mini-research/source-gaps-v2.json', residualCensusSource='/tmp/mini-research/residual-census-v2.json',
    researchHandoff='/tmp/mini-packet/RESEARCH-HANDOFF-v2.md')
changes = dict(
    updatedAt=NOW, currentBrand='MINI', previousBrand='Deepal', nextBrand='awaiting selection',
    brandPacket='data/m1-brand-updates/mini-2026-10-15.json',
    brandReconciliation='data/m1-mini-market-reconciliation-2026-10-15.json',
    state='MINI working integration independently accepted and research-complete; 151 scoped tests, market-view, lint, structural validation, cold full-project TypeScript and one actual normal report/strict saved-output comparison pass; MINI C1/C2/C5 and broader M1/release gates remain open',
    coverageReport=str(NORMAL), latestFreshRegisteredCoverageReport=str(NORMAL),
    coverageReportScope='One actual unchanged normal production report at 2026-10-15; exact complete saved-output comparison accounts for all 2,610 changes from accepted Deepal 26, with an empty expected diff, 417 unchanged peer cars, 55 unchanged peer brand objects and full producer-array interleaving',
    currentIntegrationBlocker='No remaining scoped MINI runtime blocker. MINI C1/C2/C5, global C1–C5, production build, current full-project test-suite aggregate and real-device/mobile checks remain open. Prior failed and unexecuted preparation attempts remain separately labelled and preserved',
    latestWorkingBrandChecks=working, latestFreshRelevantTests=tests,
    currentWorkingSourceSnapshotScope='Exact four-file MINI registration plus this three-file documentary transition. No MINI recovery archive/capture/delivery claimed; every historical source, backup record and Library ID remains preserved with its original scope',
    currentAggregateStatus='Fresh ten-file 144-test aggregate and separate seven live-safety tests pass: 151 distinct scoped tests. Cold full-project TypeScript passes with all 361 original roots and only a fresh output-cache destination. One actual normal report and comparator v2 pass. No current full-project test-suite, production-build or mobile pass',
    miniWorking=working, miniResearchStatus=research,
    miniPendingRecovery=dict(state='Pending final retention acceptance and separately authorized backup capture/delivery; no MINI archive or backup delivery is claimed',
                             researchDirectory='/tmp/mini-research', packetDirectory='/tmp/mini-packet', reviewDirectory='/tmp/mini-review',
                             qaDirectories=['/tmp/mini-packet/post-registration-checks-v1', '/tmp/mini-packet/full-project-typescript-v1', '/tmp/mini-packet/report-comparison-v2'],
                             publicationAuthorized=False))
new = copy.deepcopy(old)
previous = {key: copy.deepcopy(old[key]) for key in changes if key in old}
new.update(changes)
new['workStatusHistory'].append(dict(
    supersededAt=NOW,
    scope='Current MINI working/report/check transition only; all exact superseded current fields and every earlier entry/backup record retained',
    previous=previous,
    beforeSnapshot=str(BASE / 'before/roadmark-104-qa/work-status.json'),
    beforeSha256=hashlib.sha256(status_raw).hexdigest()))
assert new['workStatusHistory'][:-1] == old['workStatusHistory']
assert new['workStatusHistory'][-1]['previous'] == previous
for key in old:
    if key not in changes and key != 'workStatusHistory':
        assert new[key] == old[key], key
assert new['deepalWorking'] == old['deepalWorking']
assert new['backup'] == old['backup']
save(BASE / 'after/roadmark-104-qa/work-status.json', new)

relative_targets = ['roadmark-104/docs/MINI_M1_UPDATE.md', 'roadmark-104/docs/M1_PROGRESS.md', 'roadmark-104-qa/work-status.json']
writes = []
patch = []
for relative in relative_targets:
    target = WORKSPACE / relative
    after = BASE / 'after' / relative
    before_copy = BASE / 'before' / relative if target.exists() else None
    before = pin(target) if target.exists() else None
    if before:
        assert before_copy.read_bytes() == target.read_bytes()
    writes.append(dict(relativePath=relative, target=str(target), operation='replace' if before else 'create',
                       before=before, beforeCopy=pin(before_copy) if before else None, after=pin(after)))
    patch.extend(difflib.unified_diff((before_copy.read_text() if before_copy else '').splitlines(True),
                                      after.read_text().splitlines(True), fromfile=relative if before else '/dev/null', tofile=relative))
write_bytes(BASE / 'docs-status.patch', ''.join(patch).encode())
ast.parse((BASE / 'apply.py').read_text())
ast.parse((BASE / 'prepare.py').read_text())
proof_paths = list(expected) + [
    REVIEW / 'preflight-v2-failure-diagnosis.json', REVIEW / 'preflight-v3-output-review.json', REVIEW / 'preflight-v4-output-review.json',
    REVIEW / 'full-stage-v1-readiness-review.json', REVIEW / 'full-stage-v2-output-review.json',
    REVIEW / 'registration-v1-live-readback.json', REVIEW / 'post-registration-five-gate-results-v1.json',
    REVIEW / 'full-project-typescript-v1-output-review.json', REVIEW / 'report-comparison-v1-readiness-review.json',
    Path('/tmp/mini-packet/report-comparison-v2/artifacts/expected-versus-normal-diff.json'), formatted_path,
    Path('/tmp/mini-research/source-gaps-v2.json'), Path('/tmp/mini-research/residual-census-v2.json'),
    Path('/tmp/mini-packet/RESEARCH-HANDOFF-v2.md'),
    WORKSPACE / 'roadmark-104-visual-qa-20261015/visual-qa-blocker-receipt.json',
    REPO / 'AGENTS.md', REPO / 'docs/DOT-BRIEF-103.md', REPO / 'docs/DEEPAL_M1_UPDATE.md',
    Path('/tmp/mini-packet/docs-status-v1/manifest.json'),
    BASE / 'buyer-update.md', BASE / 'progress-append.md', BASE / 'README.md']
proofs = [pin(path) for path in proof_paths]
proofs += copy.deepcopy(registration['unchangedHelperPins'])
# Pin all four current registration payloads against the accepted live readback.
readback = read_json(REVIEW / 'registration-v1-live-readback.json')
for row in readback['liveReadback']:
    current = pin(row['path'])
    assert all(current[key] == row[key] for key in ['path', 'bytes', 'sha256'])
    if current['path'] not in {proof['path'] for proof in proofs}:
        proofs.append(current)
manifest = dict(
    schemaVersion=1, status='prepared_requires_independent_review_and_root_grant', preparedAt=NOW,
    repo=str(WORKSPACE), supersedesPreparation=pin('/tmp/mini-packet/docs-status-v1/manifest.json'),
    revisionScope='Wording only: exact SE Favoured grade name, bounded warranty-use classes, and post-application pending recovery state; all v1 artifacts retained unchanged',
    writes=writes, rootGrantRequired=True, automaticRetry=False, heavyChecksAllowed=False,
    applicator=pin(BASE / 'apply.py'), preparer=pin(BASE / 'prepare.py'), patch=pin(BASE / 'docs-status.patch'), proofs=proofs,
    scope=dict(exactDocumentaryTargets=3, applied=False, newFiles=1, replacedFiles=2,
               liveSourceEdits=False, projectExecution=False, archiveWork=False, previewAttempt=False,
               currentPacketCount=27, currentNextBrand='awaiting selection'),
    reportEvidence=dict(normalReport=pin(NORMAL), comparisonResult=pin(COMPARISON), independentAcceptance=pin(REVIEW / 'report-comparison-v2-output-review.json')),
    historicalPreview='Earlier Deepal 26-packet browser-to-preview reachability failure retained unchanged; no MINI screenshot, viewport, hero visual or mobile verification',
    historyPreservation=dict(statusPriorTopLevelKeys=len(old), unchangedHistoricalFields=[key for key in old if key not in changes and key != 'workStatusHistory'],
                             changedCurrentFields=list(changes), exactSupersededCurrentFields=list(previous),
                             priorHistoryEntries=len(old['workStatusHistory']), newHistoryEntries=len(new['workStatusHistory']),
                             progressOriginalPrefixPreserved=True, allHistoricalBackupFieldsPreserved=True,
                             exactCompleteStatusBeforeSnapshot=pin(BASE / 'before/roadmark-104-qa/work-status.json')))
save(BASE / 'manifest.json', manifest)
save(BASE / 'root-grant-template.json', dict(
    status='NOT_GRANTED', action='apply_exact_mini_docs_status', manifest=pin(BASE / 'manifest.json'),
    automaticRetry=False, heavyExecutionAuthorized=False,
    allowedTargets=[row['target'] for row in writes], reviewerAcceptance=None))
# Confirm preparation did not touch any live target or pinned proof.
for row in writes:
    if row['before']:
        assert pin(row['target']) == row['before']
    else:
        assert not Path(row['target']).exists()
for proof in proofs:
    assert pin(proof['path']) == proof
assert not (BASE / 'application').exists()
print(json.dumps(dict(preparedOnly=True, manifest=pin(BASE / 'manifest.json'), writes=writes,
                      priorHistoryEntries=7, afterHistoryEntries=8, liveTargetsUnchanged=True), indent=2))
