from pathlib import Path
import sys,json,subprocess,os,time,hashlib
from datetime import datetime,timezone
manifest=Path(sys.argv[1]);expected=sys.argv[2];grantpath=Path(sys.argv[3])
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(65536),b''):h.update(block)
 return h.hexdigest()
assert sha(manifest)==expected
m=json.loads(manifest.read_text());grant=json.loads(grantpath.read_text())
assert m['timeoutSeconds']==420 and m['killAfterSeconds']==10 and m['automaticRetry'] is False
assert m['execArgv']==['--max-old-space-size=448','--max-semi-space-size=1','--expose-gc','--import','tsx']
assert m['productionRegistrationAuthorized'] is False and m['canonicalRecaptureAuthorized'] is False and m['normalFullReportInStage'] is False
assert os.environ.get('NODE_OPTIONS') is None
cmd=['node',*m['execArgv'],m['script']['path'],'--manifest',str(manifest),'--manifest-sha256',expected]
assert grant['authorized'] is True and grant['exclusiveHeavySlotGranted'] is True
assert grant['action']=='run_single_bounded_mini_full_stage' and grant['preparedManifestSha256']==expected
assert grant['command']==cmd and grant['automaticRetry'] is False
assert sha(__file__)==m['wrapper']['sha256']
def now():return datetime.now(timezone.utc).isoformat()
def checkpins():
 assert sha(manifest)==expected
 for p in m['pins']:
  f=Path(p['path']);assert f.stat().st_size==p['bytes'];assert sha(f)==p['sha256'],p['path']
checkpins();out=Path(m['runOutput']);out.mkdir(exist_ok=False)
def write(name,value):
 with (out/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
wrapped=['/usr/bin/timeout','--signal=TERM','--kill-after=10s','420s',*cmd]
write('invocation.json',dict(at=now(),cwd=m['repo'],command=cmd,supervisedCommand=wrapped,manifestSha256=expected,grantSha256=sha(grantpath),wrapperSha256=sha(__file__),beforePinsPassed=True,automaticRetry=False,liveSourceMutationsAuthorized=False))
start=time.monotonic()
with (out/'stdout.log').open('x') as stdout,(out/'stderr.log').open('x') as stderr:
 p=subprocess.Popen(wrapped,cwd=m['repo'],stdout=stdout,stderr=stderr,start_new_session=True)
 write('started.json',dict(at=now(),pid=p.pid,processGroup=os.getpgid(p.pid)))
 _,status,usage=os.wait4(p.pid,0);code=os.waitstatus_to_exitcode(status);p.returncode=code
 stdout.flush();stderr.flush();os.fsync(stdout.fileno());os.fsync(stderr.fileno())
terminal=dict(at=now(),exitCode=code,rawWaitStatus=status,elapsedSeconds=time.monotonic()-start,maxRssKiB=usage.ru_maxrss,stdoutSha256=sha(out/'stdout.log'),stderrSha256=sha(out/'stderr.log'),automaticRetry=False,timeoutInterpretation='Raw wait status retained; cause not inferred')
write('terminal.json',terminal)
try:checkpins();write('after-pins.json',dict(at=now(),passed=True,count=len(m['pins']),manifestSha256=expected))
except Exception as error:write('after-pins.json',dict(at=now(),passed=False,error=repr(error)));raise
print(json.dumps(terminal));print((out/'stdout.log').read_text()[-3500:]);print((out/'stderr.log').read_text()[-4500:]);sys.exit(0 if code==0 else 1)
