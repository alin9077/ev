/** MINI27 bounded full-stage draft: no broad effective-feature replay or normal report. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {fileHash,readJson,readResearch,digestRows,assertResearchUnchanged} from '/tmp/xpeng-staging-plan/baseline-io.mjs';
import {readCompleteCars} from '/tmp/mercedes-staging-plan/staging-preparation/shape-first-v3/read-complete-storage.mjs';
import {assertDeclaredJson} from '/tmp/mercedes-staging-plan/consumer-preparation/v5/feature-json-parity.mjs';
const args=process.argv.slice(2);assert.equal(args.length,4);assert.equal(args[0],'--manifest');assert.equal(args[2],'--manifest-sha256');assert.equal(fileHash(args[1]),args[3]);
const m=readJson(args[1]),repo=m.repo,out=m.output,pins=m.pins;
assert.equal(process.cwd(),repo);assert.equal(process.env.NODE_OPTIONS,undefined);assert.equal(typeof global.gc,'function');assert.equal(process.version,m.nodeVersion);assert.deepEqual(process.execArgv,m.execArgv);
assert.equal(m.mode,'derived-prefix20-through-Deepal26-then-MINI27-no-broad-features');assert.equal(m.productionRegistrationAuthorized,false);assert.equal(m.canonicalRecaptureAuthorized,false);assert.equal(m.normalFullReportInStage,false);
function checkPins(){for(const p of pins){assert.equal(fs.statSync(p.path).size,p.bytes);assert.equal(fileHash(p.path),p.sha256,p.path);}}
checkPins();assert(!fs.existsSync(out));fs.mkdirSync(out);
function write(name,obj){fs.writeFileSync(out+'/'+name+'.json',JSON.stringify(obj,null,2)+'\n',{flag:'wx'});}
function progress(phase){const fd=fs.openSync(path.join(m.runOutput,'progress.jsonl'),'a');try{fs.writeSync(fd,JSON.stringify({at:new Date().toISOString(),phase})+'\n');fs.fsyncSync(fd);}finally{fs.closeSync(fd);}console.log(phase);}
const fieldDigests=data=>Object.fromEntries(Object.entries(data).map(([key,value])=>[key,digestRows(Array.isArray(value)?value:[value])])),carDigests=cars=>cars.map(car=>({id:car.id,...digestRows([car])}));
function fullResearchExact(data,expected,label){assertDeclaredJson(data,'/'+label,new Set());assert.deepStrictEqual(fieldDigests(data),expected);}
function fullCarsExact(cars,expected,label){assertDeclaredJson(cars,'/'+label,new Set());assert.deepStrictEqual(carDigests(cars),expected);}
progress('Restoring accepted retained409/prefix20 once');
const accepted=readJson(m.acceptedManifest.path),anchors=accepted.anchors,inputPins=new Map(accepted.inputPins.map(row=>[row.anchor+'\0'+row.file,row]));
const proof={anchors,assertPinned(ref){const pin=inputPins.get(ref.anchor+'\0'+ref.file);assert(pin);assert.equal(ref.sha256,pin.sha256);assert.equal(ref.bytes,pin.bytes);}};
let restored=await readCompleteCars(proof,m.storageIndex),cars=restored.cars;const index=restored.index;restored=null;
assert.equal(cars.length,409);for(const ref of Object.values(index.research))proof.assertPinned(ref);
let data=await readResearch(anchors,index,Object.keys(index.research));assert.equal(Object.keys(data).length,14);assertResearchUnchanged(data,index);assert.deepStrictEqual(data.variants.map(row=>row.id),cars.map(car=>car.id));
const require=createRequire(repo+'/package.json'),brand=require('./src/lib/brand-updates.ts');
const {prepareBrandResearch,applyBrandUpdates,brandVersionSnapshot,applyBrandFeatureUpdates,applyBrandTermFeatures}=brand;
const {brandUpdatePackets}=require('./src/lib/brand-update-registry.ts');assert.equal(brandUpdatePackets.length,26);assert.deepStrictEqual(brandUpdatePackets.map(p=>p.id),m.registeredPacketIds);assert.equal(brandUpdatePackets.at(-1).id,'m1-deepal-2026-10-15');assert.deepStrictEqual(data.metadata.brand_update_packet_ids,m.registeredPacketIds.slice(0,20));
const acceptedCarStages=readJson(m.acceptedDeepalCars.path),acceptedFieldStages=readJson(m.acceptedDeepalFields.path),carStages={baseline20:carDigests(cars)},fieldStages={baseline20:fieldDigests(data)},transitions=[];
fullResearchExact(data,acceptedFieldStages.baseline20,'baseline20Research');fullCarsExact(cars,acceptedCarStages.baseline20,'baseline20Cars');
function compose(base,p,ids){const raw=prepareBrandResearch(base,[p]);assert.deepStrictEqual(Object.keys(raw),Object.keys(base));assert.deepStrictEqual(raw.metadata.brand_update_packet_ids,[p.id]);const result={...raw,metadata:{...raw.metadata,brand_update_packet_ids:ids}};for(const key of Object.keys(raw))if(key!=='metadata')assert.equal(result[key],raw[key]);transitions.push({packetId:p.id,beforeMetadata:digestRows([base.metadata]),rawMetadata:structuredClone(raw.metadata),composedMetadata:structuredClone(result.metadata),onlyCompositionPath:'metadata.brand_update_packet_ids'});return result;}
for(const [offset,stage,count]of [[20,'corrected21',409],[21,'current22',413],[22,'current23',413],[23,'current24',417],[24,'candidate25',427],[25,'candidate26',427]]){
 const packet=brandUpdatePackets[offset],priorData=data,priorCars=cars,priorFields=fieldDigests(data),priorDigests=carDigests(cars);
 data=compose(priorData,packet,m.registeredPacketIds.slice(0,offset+1));cars=applyBrandUpdates(priorCars,data,[packet]);assert.equal(cars.length,count);assert.equal(data.variants.length,count);assert.deepStrictEqual(data.variants.map(row=>row.id),cars.map(car=>car.id));
 fullResearchExact(priorData,priorFields,'priorResearch');fullCarsExact(priorCars,priorDigests,'priorCars');
 fullResearchExact(data,acceptedFieldStages[stage],stage+'Research');fullCarsExact(cars,acceptedCarStages[stage],stage+'Cars');
 carStages[stage]=carDigests(cars);fieldStages[stage]=fieldDigests(data);global.gc();progress('Accepted '+stage+' complete-car and all14-field digests reproduced');
}
const base=data,currentCars=cars,currentFields=fieldStages.candidate26,currentDigests=carStages.candidate26;
const expected=readJson(m.expectedReview.path),packetPath=m.packet.path,packet=readJson(packetPath),packetSnapshot=structuredClone(packet);
assert.equal(fileHash(packetPath),expected.packetSha256);assert.equal(packet.id,'m1-mini-2026-10-15');
const selected=new Set(m.selectedIds),before=currentCars.filter(car=>selected.has(car.id)),beforeSnapshot=structuredClone(before),modelIds=new Set(before.map(car=>car.modelId));
assert.equal(selected.size,10);assert.equal(before.length,10);assert.deepStrictEqual(before.map(car=>car.id),expected.currentListIds);assert.deepStrictEqual(before,readJson(m.selectedBefore.path));
for(const prior of brandUpdatePackets){assert.notEqual(prior.brand,'MINI');for(const row of [...prior.facts,...prior.variants,...prior.versionGuards,...prior.availability,...prior.summaries,...(prior.features??[]),...(prior.configurationUpdates??[])])assert(!selected.has(row.variantId??row.id));for(const term of prior.brandTerms??[])assert(term.applicableVariantIds.every(id=>!selected.has(id)));}
const peerCars=currentCars.filter(car=>!selected.has(car.id)),peerIds=new Set(peerCars.map(car=>car.id));assert.equal(peerCars.length,417);
const sourceIdsAdded=new Set(packet.sources.map(source=>source.id));assert.equal(sourceIdsAdded.size,46);assert.equal(packet.sources.length,46);assert.equal(packet.facts.length,153);
const sourceReferenceProof=[];
function inspectSourceReferences(value,label,pointer=''){if(typeof value==='string'){assert(!sourceIdsAdded.has(value),'New source already referenced '+label+pointer);return;}if(!value||typeof value!=='object')return;for(const [key,item]of Object.entries(value)){assert(!sourceIdsAdded.has(key),'New source already a dictionary key '+label+pointer);inspectSourceReferences(item,label,pointer+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));}}
for(const [label,value]of [['accepted complete research',base],['accepted complete cars',currentCars],['accepted packets',brandUpdatePackets]]){inspectSourceReferences(value,label);sourceReferenceProof.push({input:label,newSourceReferences:0,nestedGradeReviewsAndKeysIncluded:true});}
for(const pin of m.rawOverlayInputs){inspectSourceReferences(require(pin.path),pin.path);sourceReferenceProof.push({input:pin.path,sha256:pin.sha256,newSourceReferences:0,nestedGradeReviewsAndKeysIncluded:true});}
write('source-reference-neutrality',{peerCars:417,helperChanges:false,sourceRowsAdded:46,inspections:sourceReferenceProof,broadFeatureReplay:false});
data=compose(base,packet,[...m.registeredPacketIds,packet.id]);cars=applyBrandUpdates(currentCars,data,[packet]);
const candidateFields=fieldDigests(data),candidateDigests=carDigests(cars),after=cars.filter(car=>selected.has(car.id)),afterSnapshot=structuredClone(after);
assert.equal(cars.length,427);assert.equal(data.variants.length,427);assert.equal(after.length,10);assert.deepStrictEqual(after,readJson(m.selectedAfter.path));
fullResearchExact(base,currentFields,'baseResearch');fullCarsExact(currentCars,currentDigests,'currentCars');assertDeclaredJson(data,'/candidateResearch',new Set());assertDeclaredJson(cars,'/candidateCars',new Set());
assert.deepStrictEqual(data.sources.slice(0,base.sources.length),base.sources);assert.equal(data.sources.length,base.sources.length+46);
for(const key of Object.keys(base))if(!['metadata','variants','sources'].includes(key))assert.deepStrictEqual(data[key],base[key]);
for(const key of Object.keys(base.metadata))if(key!=='brand_update_packet_ids')assert.deepStrictEqual(data.metadata[key],base.metadata[key]);assert.deepStrictEqual(data.metadata.brand_update_packet_ids,[...m.registeredPacketIds,packet.id]);
let unchangedPeers=0;
for(const [index,old]of currentCars.entries()){const car=cars[index];assert.equal(car.id,old.id);if(peerIds.has(old.id)){assert.deepStrictEqual(car,old);assert.deepStrictEqual(data.variants.find(row=>row.id===old.id),base.variants.find(row=>row.id===old.id));unchangedPeers++;}else{const touched=new Set([...packet.facts.filter(edit=>edit.variantId===old.id).map(edit=>edit.after.key),...packet.brandTerms.filter(term=>term.applicableVariantIds.includes(old.id)).map(term=>term.key)]);for(const [key,fact]of Object.entries(old.facts))if(!touched.has(key))assert.deepStrictEqual(car.facts[key],fact);for(const key of Object.keys(old))if(!['facts','availability','availabilityEvidence','buyerSummary'].includes(key))assert.deepStrictEqual(car[key],old[key]);}}
assert.equal(unchangedPeers,417);assert.deepStrictEqual(candidateDigests.filter(row=>peerIds.has(row.id)),currentDigests.filter(row=>peerIds.has(row.id)));
const reads=Object.entries(currentFields).map(([field,ref])=>({field,inputRows:ref.rows,retainedRows:ref.rows,sha256:ref.sha256,scope:'full accepted research for structural composition; only ten feature packs replayed'}));
progress('MINI27 applied under full peer/research/source isolation; checking ten actual packs');

for(const guard of packet.versionGuards)assert.deepEqual(brandVersionSnapshot(before.find(c=>c.id===guard.variantId)),guard.before);
for(const edit of packet.facts){assert.deepEqual(before.find(c=>c.id===edit.variantId).facts[edit.after.key]??null,edit.before);assert.deepEqual(after.find(c=>c.id===edit.variantId).facts[edit.after.key],edit.after);}
for(const term of packet.brandTerms)for(const id of term.applicableVariantIds){assert.deepEqual(before.find(c=>c.id===id).facts[term.key]??null,term.before[id]);assert.deepEqual(after.find(c=>c.id===id).facts[term.key],term.fact);}
for(const car of after){
 const prior=before.find(c=>c.id===car.id);
 assert.deepStrictEqual(car.configurationEvidence,prior.configurationEvidence);
 assert.deepStrictEqual(brandVersionSnapshot(car),brandVersionSnapshot(prior));
}
for(const key of ['variants','models','versionUpdates','features','configurationUpdates'])assert.equal(packet[key].length,0);
for(const edit of packet.availability){
 const b=before.find(c=>c.id===edit.variantId),a=after.find(c=>c.id===edit.variantId);
 assert.deepEqual({availability:b.availability,evidence:b.availabilityEvidence},edit.before);
 assert.deepEqual({availability:a.availability,evidence:a.availabilityEvidence},edit.after);
}
for(const edit of packet.summaries){
 const car=after.find(c=>c.id===edit.variantId);
 for(const side of ['strength','tradeoff']){
  assert.equal(car.buyerSummary[side].label,edit[side].label);assert.equal(car.buyerSummary[side].text,edit[side].text);
  const expectedFreshness=edit[side].dependencies.flatMap(({expected:f})=>[f.date,...f.sourceIds.map(id=>data.sources.find(source=>source.id===id).accessed_date)].map(checkedAt=>({checkedAt,key:f.key,...(f.modelYearChangedAt?{modelYearChangedAt:f.modelYearChangedAt}:{})})));
  assert.deepStrictEqual(car.buyerSummary[side].freshness,expectedFreshness);
  const expectedClauseSourceIds=[...new Set(edit[side].dependencies.flatMap(({expected:f})=>f.sourceIds))];
  assert.deepStrictEqual(car.buyerSummary[side].sourceIds,expectedClauseSourceIds);
  for(const dep of edit[side].dependencies){assert.deepEqual(car.facts[dep.key],dep.expected);assert.notEqual(dep.expected.value,null);assert.equal(dep.expected.issues.length,0);}
 }
 const expectedGuardSourceIds=[...new Set(['strength','tradeoff'].flatMap(side=>edit[side].dependencies.flatMap(({expected:f})=>f.sourceIds)))];
 assert.deepStrictEqual(car.buyerSummary.guardSourceIds,expectedGuardSourceIds);
 assert.deepStrictEqual(car.buyerSummary.expectedSourceSnapshots,packet.sources.filter(source=>expectedGuardSourceIds.includes(source.id)));
 assert.deepStrictEqual(car.buyerSummary.conditions,edit.conditions??[]);
 assert.equal(car.buyerSummary.checkedAt,packet.reviewedAt);
}
const {compiledSource}=require('./tests/helpers/compiled-source.ts');
let defaultCalls=0;const forbidden=()=>{defaultCalls++;throw new Error('FORBIDDEN_DEFAULT_CATALOGUE_LOADER');};
const defaults={sourceResearch:forbidden,research:forbidden,catalogue:forbidden};
const factory=packets=>compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets:packets}}).createEvidenceConsumers(defaults);
const initial=factory(brandUpdatePackets),final=factory([...brandUpdatePackets,packet]);
const {hasEarnedBuyerGrade}=require('./src/lib/evidence-grading.ts');
const {factClaim,featureClaim}=require('./src/lib/citable.ts');
const {buyerAvailabilityText}=require('./src/lib/buyer-availability.ts');
const {isOnSale,isCurrentListEligible,isTierOne,buildCoverageReport}=require('./scripts/reporting/reports.ts');
const {auditedFeature}=require('./src/lib/launch-evidence.ts');
const {applyFeatureRegrading}=require('./src/lib/evidence-regrading.ts');
const beforePacks={},afterPacks={},observations=[],claims=[],featureClaims=[],claimOmissions=[],producerProofs=[],frames=new Map();
for(const [phase,cars,consumer,research,packets]of [['before',before,initial,base,brandUpdatePackets],['after',after,final,data,[...brandUpdatePackets,packet]]])for(const car of cars){
 const input=consumer.sourceEffectiveFeatures(car,research),snap=structuredClone(input),regraded=applyFeatureRegrading(car,input,research.sources);
 assert.deepEqual(input,snap);
 const branded=applyBrandFeatureUpdates(car,regraded,research,packets),projected=applyBrandTermFeatures(car,branded,research.sources);
 frames.set(phase+'\0'+car.id,{input,regraded,branded,projected,research});
 producerProofs.push({phase,variantId:car.id,producer:'Actual sourceEffectiveFeatures -> applyFeatureRegrading -> applyBrandFeatureUpdates -> applyBrandTermFeatures',inputRows:input.length,outputRows:projected.length,inputUnchanged:true});
}
function observePack(car,pack,phase){
 const pointers=[];
 function visit(value,pointer){
  if(value===undefined){
   const match=pointer.match(/\/features\/(\d+)\/([^/]+)$/);assert(match,'Unexpected undefined outside feature: '+pointer);
   const rowIndex=Number(match[1]),property=match[2],feature=pack.features[rowIndex],descriptor=Object.getOwnPropertyDescriptor(feature,property);
   assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value')&&descriptor.value===undefined);
   const frame=frames.get(phase+'\0'+car.id),sourceRow=frame.input.find(f=>f.criterion===feature.criterion),regraded=frame.regraded.find(f=>f.criterion===feature.criterion),projected=frame.projected.find(f=>f.criterion===feature.criterion);
   assert(sourceRow&&regraded&&projected);assert.deepEqual(feature,projected);
   let producer;
   if(property==='gradeReviewStatus'){
    assert(feature.gradeReview);assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts earned retained-feature branch explicitly sets gradeReviewStatus undefined';
   }else if(property==='condition_label'){
    assert.equal(feature.buyerGrade,'check');assert(!Object.hasOwn(sourceRow,property)||sourceRow[property]===undefined);assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts Check branch retains source optional condition_label';
   }else if(property==='confirmation_needed'){
    assert.equal(feature.criterion,'novated_fbt');
    for(const row of [sourceRow,regraded]){const d=Object.getOwnPropertyDescriptor(row,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);}
    const raw=frame.research.feature_evidence.find(f=>f.variant_id===car.id&&f.criterion===feature.criterion);assert(raw);
    const snap=structuredClone(raw),audited=auditedFeature(raw);assert.deepEqual(raw,snap);
    const d=Object.getOwnPropertyDescriptor(audited,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);
    producer='launch-evidence.ts actual auditedFeature(raw exact novated_fbt row) creates confirmation_needed undefined';
   }else if(['buyerGrade','gradeReview'].includes(property)){
    assert.equal(feature.gradeReviewStatus,'review_required');assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts unmatched retained-feature branch withdraws optional review';
   }else assert.fail('Unclassified optional undefined: '+pointer);
   observations.push({phase,variantId:car.id,pointer,rowIndex,criterion:feature.criterion,property,ownUndefined:true,enumerable:true,producer,sourceProperty:{own:Object.hasOwn(sourceRow,property),valueKind:sourceRow[property]===undefined?'undefined':typeof sourceRow[property]},regradedProperty:{own:Object.hasOwn(regraded,property),valueKind:regraded[property]===undefined?'undefined':typeof regraded[property]},actualFinalProjectionMatched:true});
   pointers.push(pointer);return;
  }
  if(!value||typeof value!=='object')return;
  for(const key of Object.keys(value))visit(value[key],pointer+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));
 }
 visit(pack,'/packs/'+car.id);assertDeclaredJson(pack,'/packs/'+car.id,new Set(pointers));
}
function observeClaim(claim,pack,pointer,replay,record=true){
 assert.deepEqual(replay(),claim,'Actual citable producer replay must match');
 const clone=structuredClone(claim),pointers=[];
 function visit(value,path){
  if(value===undefined){
   const match=path.match(/\/sources\/(\d+)\/(limitation|checked)$/);assert(match,'Unclassified citable undefined: '+path);
   const i=Number(match[1]),key=match[2],citation=claim.sources[i],source=pack.sources.find(s=>s.id===citation.id);assert(source);
   const d=Object.getOwnPropertyDescriptor(citation,key);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);
   assert(!source[key==='limitation'?'access_limitation':'full_text_checked_date']);
   pointers.push(path);if(record)claimOmissions.push({pointer:path,sourceId:source.id,property:key,ownUndefined:true,enumerable:true,producer:'Actual citable.ts citations() falsey source-metadata branch; actual factClaim/featureClaim replay matches'});
   delete clone.sources[i][key];return;
  }
  if(!value||typeof value!=='object')return;
  for(const key of Object.keys(value))visit(value[key],path+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));
 }
 visit(claim,pointer);assertDeclaredJson(claim,pointer,new Set(pointers));assert.deepEqual(JSON.parse(JSON.stringify(claim)),clone);return clone;
}
for(const car of before){const pack=initial.pack(car.id,{data:base,cars:before});beforePacks[car.id]=pack;assert.equal(pack.features.length,69);observePack(car,pack,'before');}
let earnedCells=0,roadsideRefreshes=0,driveawayFallbacks=0;
for(const car of after){
 const pack=final.pack(car.id,{data,cars:after});afterPacks[car.id]=pack;assert.equal(pack.features.length,69);assert.equal(new Set(pack.features.map(f=>f.criterion)).size,69);observePack(car,pack,'after');
 for(const feature of pack.features){
  if(feature.criterion==='roadside_assistance'){
   const fact=car.facts.roadside_assistance;
   assert.equal(feature.value,String(fact.value));assert.equal(feature.buyerGrade,'check');assert.equal(feature.verification_state,'reviewed_brand_au_terms');assert.deepEqual(feature.source_ids,fact.sourceIds);
   assert(feature.conditions.includes(fact.conditionExplanation));assert.match(feature.conditions,/eight years|8 years/i);assert.match(feature.conditions,/five years|5 years/i);roadsideRefreshes++;
  }else if(feature.criterion==='driveaway_price'){
   const f=car.facts.price_aud;assert.notEqual(f.comparisonBasis,'Driveaway');assert(!car.facts.promotional_driveaway_aud);assert(!car.facts.published_driveaway_aud);
   const fallback=frames.get('after\0'+car.id).regraded.find(f=>f.criterion==='driveaway_price');assert.deepEqual(feature,fallback);
   assert.notEqual(feature.verification_state,'reviewed_canonical_driveaway_price');assert.notEqual(feature.verification_state,'reviewed_published_driveaway_price');driveawayFallbacks++;
  }else assert.deepEqual(feature,beforePacks[car.id].features.find(f=>f.criterion===feature.criterion),'Unrelated retained feature changed: '+car.id+'/'+feature.criterion);
 }
 for(const fact of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===packet.id)){
  assert(hasEarnedBuyerGrade(fact,data.sources,packet.reviewedAt));const claim=factClaim(pack,fact,packet.reviewedAt);
  assert.equal(claim.buyerGrade,fact.buyerGrade);assert.deepEqual(claim.sources.map(s=>s.id),fact.sourceIds);
  if(fact.buyerGrade==='not_published'){assert.equal(fact.value,null);assert.equal(claim.value,'Not published');}
  const row={variantId:car.id,key:fact.key,claim};observeClaim(claim,pack,'/claims/'+claims.length+'/claim',()=>factClaim(pack,fact,packet.reviewedAt));claims.push(row);earnedCells++;
 }
 for(const feature of pack.features){
  const claim=featureClaim(pack,feature.criterion,feature.criterion,packet.reviewedAt);assert(claim);assert.deepEqual(claim.sources.map(s=>s.id),[...new Set(feature.source_ids)]);
  observeClaim(claim,pack,'/feature-claims/'+featureClaims.length+'/claim',()=>featureClaim(pack,feature.criterion,feature.criterion,packet.reviewedAt));featureClaims.push({variantId:car.id,criterion:feature.criterion,claim});
 }
 assert.equal(buyerAvailabilityText(car),'On sale now');assert(isOnSale(car));assert(isCurrentListEligible(car,data.sources,packet.reviewedAt));assert.equal(car.year,null);
 assert.equal(car.availabilityEvidence.physicalStockVerified,false);assert.equal(car.availabilityEvidence.factoryOrderAcceptanceVerified,false);
 for(const key of expected.coreKeys)assert(hasEarnedBuyerGrade(car.facts[key],data.sources,packet.reviewedAt));
}
assert.equal(earnedCells,183);assert.equal(featureClaims.length,690);assert.equal(roadsideRefreshes,10);assert.equal(driveawayFallbacks,10);
assert.equal(after.filter(isOnSale).length,10);assert.equal(after.filter(isOnSale).length-before.filter(isOnSale).length,0);
const {exclusionReason,rankAttribute,attributes}=require('./src/lib/discovery.ts');
const policy={asOf:packet.reviewedAt},rankingProof=[],rankCounts={};
for(const row of expected.normalizedRankPolicy){
 const car=after.find(c=>c.id===row.variantId),fact=car.facts[row.key],reason=exclusionReason(car,fact,data.sources,policy);
 assert.equal(reason===null,row.eligible,'Ranking mismatch '+car.id+'/'+row.key);
 if(fact.buyerGrade==='reported'||fact.issues.length||!fact.comparisonBasis.trim()||fact.value===null||fact.priceEvidence?.rankingEligible===false)assert(reason);
 rankingProof.push({variantId:car.id,key:row.key,eligible:reason===null,reason});
}
for(const attribute of attributes){
 const ranks=rankAttribute(after,data.sources,attribute.key,policy),ranked=ranks.groups.flatMap(g=>g.entries.map(e=>e.car.id));
 assert.deepEqual(new Set(ranked),new Set(expected.rankingIds[attribute.key]));assert.equal(ranks.excluded.length,10-ranked.length);
 for(const group of ranks.groups)for(const entry of group.entries){assert.equal(entry.fact.comparisonBasis,group.basis);assert.equal(entry.fact.unit,group.unit);}
 rankCounts[attribute.key]={ranked,excluded:ranks.excluded};
}
for(const o of observations.filter(x=>x.phase==='after')){
 const prior=observations.find(x=>x.phase==='before'&&x.pointer===o.pointer&&x.criterion===o.criterion&&x.property===o.property);
 const a=afterPacks[o.variantId].features[o.rowIndex],b=beforePacks[o.variantId].features[o.rowIndex];assert.equal(a.criterion,b.criterion);
 assert.notEqual(o.criterion,'roadside_assistance','Fresh canonical roadside projection must not inherit optional undefined fields');
 assert(prior,'Unchanged feature omission needs exact before witness: '+o.pointer);
 if(o.property==='gradeReviewStatus')assert.deepEqual(a.gradeReview,b.gradeReview);
}
const reconciliation=readJson('/tmp/mini-packet/mini-market-reconciliation-v3.json');
const allInventory=require('./src/lib/market-inventory-data.ts').default;
const isMini=s=>typeof s==='string'&&s.toUpperCase()==='MINI';
const inventory={...allInventory,records:allInventory.records.filter(r=>isMini(r.brand)),unverifiedLeads:allInventory.unverifiedLeads.filter(r=>isMini(r.brand))};
assert.equal(inventory.records.length,3);assert.equal(inventory.unverifiedLeads.length,0);
const inventoryProof=readJson(m.inventoryReview.path);
assert.equal(fileHash(inventoryProof.originalInventory.path),inventoryProof.originalInventory.sha256);
assert.deepStrictEqual(inventory.records,inventoryProof.records);assert.deepStrictEqual(inventory.unverifiedLeads,inventoryProof.unverifiedLeads);
assert(inventory.records.every(record=>!record.vehicleClass||['passenger','ute'].includes(record.vehicleClass)));
const {inventoryRecordId}=require('./scripts/reporting/m1-reconciliation.ts');
const actualInventoryIds=inventory.records.map(record=>'record:'+inventoryRecordId(record));
assert.equal(new Set(actualInventoryIds).size,3);
assert.deepStrictEqual(new Set(expected.expectedSettledInventory),new Set(actualInventoryIds));
assert.deepStrictEqual(expected.expectedSettledInventory,inventoryProof.expectedSettlement);
assert.deepStrictEqual(reconciliation.currentVersionReviews.map(review=>review.id),inventoryProof.currentVersionReviewIds);
assert.deepStrictEqual(new Set(reconciliation.inventoryResolutions.map(row=>row.kind+':'+row.inventoryId)),new Set(actualInventoryIds));
assert.equal(reconciliation.inventoryResolutions.length,3);
const countrymanReview=reconciliation.currentVersionReviews.find(review=>review.id===inventoryProof.countrymanReviewId);
assert(countrymanReview);assert.deepStrictEqual(countrymanReview.publishedModelAliases,[inventoryProof.countrymanAlias]);
assert.deepStrictEqual(countrymanReview.versions.map(version=>version.carId),inventoryProof.countrymanVersionIds);assert.equal(countrymanReview.versions.length,5);
for(const review of reconciliation.currentVersionReviews){
 assert.equal(review.bodyStyle,expected.bodyByModelId[review.modelId]);
 for(const version of review.versions){const car=after.find(c=>c.id===version.carId);assert(car);assert.equal(car.modelId,review.modelId);assert.equal(car.model,review.model);assert.equal(car.model,version.model);assert.equal(car.trim,version.trim);assert.equal(car.year,version.modelYear);}
}
const {buildMarketReconciliation}=require('./scripts/reporting/m1-reconciliation.ts');
const c1=buildMarketReconciliation(reconciliation,after,inventory,packet.reviewedAt);
assert.equal(c1.reviewedModels,3);assert.equal(c1.reviewedVersions,10);assert.deepEqual(new Set(c1.reviewedVersionIds),selected);
assert.deepEqual(new Set(c1.settledInventory),new Set(expected.expectedSettledInventory));
assert(!c1.issues.some(i=>['version_review','version_unreviewed','inventory_unresolved'].includes(i.code)));assert(c1.issues.some(i=>i.code==='independent_lists'));assert.equal(c1.pass,false);
const selectedCoverage=buildCoverageReport({cars:after,sources:data.sources,features:Object.values(afterPacks).flatMap(p=>p.features),inventory,m1Reconciliation:reconciliation},packet.reviewedAt);
assert.equal(selectedCoverage.allCatalogueVersions,10);assert.equal(selectedCoverage.tierOneVersions,10);assert.equal(selectedCoverage.onSaleVersions,10);
const progress=selectedCoverage.brandProgress.find(b=>isMini(b.brand));assert(progress);assert.equal(progress.currentVersionReviews.length,3);assert.equal(progress.unreviewedCoreGrades,0);assert.equal(progress.missingSummaries,0);assert.equal(progress.criteria.C1,false);
const {storePortablePacks,hydratePortablePacks}=require('./src/lib/portable-packs.ts');
const snapshot=structuredClone(afterPacks),writtenExpected=structuredClone(afterPacks);
const stored=storePortablePacks(afterPacks);
assert.deepStrictEqual(afterPacks,snapshot);
assert.deepEqual(hydratePortablePacks(stored,data.sources),afterPacks);
for(const o of observations.filter(x=>x.phase==='after')){const row=writtenExpected[o.variantId].features[o.rowIndex];assert(Object.hasOwn(row,o.property));assert.equal(row[o.property],undefined);delete row[o.property];}
assert.deepEqual(JSON.parse(JSON.stringify(afterPacks)),writtenExpected);
assert.deepEqual(hydratePortablePacks(JSON.parse(JSON.stringify(stored)),data.sources),writtenExpected);assert.deepEqual(afterPacks,snapshot);
for(const [name,obj]of Object.entries({'selected-after-cars':after,'selected-packs':afterPacks,portable:stored,claims,'feature-claims':featureClaims,'undefined-witnesses':observations,'claim-undefined-witnesses':claimOmissions}))fs.writeFileSync(out+'/'+name+'.json',JSON.stringify(obj,null,2)+'\n',{flag:'wx'});
const writtenPacks=readJson(out+'/selected-packs.json'),hydrated=hydratePortablePacks(readJson(out+'/portable.json'),data.sources);
assert.deepEqual(writtenPacks,writtenExpected);assert.deepEqual(hydrated,writtenExpected);
// Actual citable producers must agree for live packs and serialized/re-hydrated packs.
for(const row of claims){const fact=after.find(c=>c.id===row.variantId).facts[row.key];assert.deepEqual(factClaim(hydrated[row.variantId],fact,packet.reviewedAt),row.claim);}
for(const row of featureClaims)assert.deepEqual(featureClaim(hydrated[row.variantId],row.criterion,row.criterion,packet.reviewedAt),row.claim);
for(const [name,rows]of [['claims',claims],['feature-claims',featureClaims]]){
 const written=readJson(out+'/'+name+'.json');
 for(let i=0;i<rows.length;i++){
  const pack=afterPacks[rows[i].variantId],replay=()=>name==='claims'?factClaim(pack,after.find(c=>c.id===rows[i].variantId).facts[rows[i].key],packet.reviewedAt):featureClaim(pack,rows[i].criterion,rows[i].criterion,packet.reviewedAt);
  const clone=observeClaim(rows[i].claim,pack,'/'+name+'/'+i+'/claim',replay,false);assert.deepEqual(written[i],{...rows[i],claim:clone});
 }
}
assert.equal(defaultCalls,0);for(const f of ['src/lib/data.ts','src/lib/catalogue.ts','src/lib/research.ts'])assert(!require.cache[repo+'/'+f]);
fullResearchExact(base,currentFields,'baseResearch');assert.deepStrictEqual(before,beforeSnapshot);fullResearchExact(data,candidateFields,'candidateResearch');assert.deepStrictEqual(after,afterSnapshot);assert.deepStrictEqual(packet,packetSnapshot);assert.deepStrictEqual(afterPacks,snapshot);checkPins();
const result={status:'selected_actual_consumers_and_exact_serialization_witness_pass',packetSha256:fileHash(packetPath),beforeCars:10,afterCars:10,coreCells:170,earnedPacketCells:earnedCells,selectedFeatureClaims:featureClaims.length,roadsideRefreshes,driveawayFallbacks,otherRetainedFeaturesUnchanged:true,readInputs:reads,currentListProof:c1,selectedCoverage,rankingProof,rankCounts,producerProofs,optionalFeaturePaths:observations,optionalCitationPaths:claimOmissions,inMemoryPortableExact:true,writtenPortableExact:true,writtenClaimReadback:true,livePacksUnchanged:true,productionCatalogueHydration:false,defaultLoaderCalls:defaultCalls,sourceEdits:false,expectedOnSaleDelta:0};
// Written C1/report shape retains only the exact omissions owned by the actual issue producer.
assert.deepEqual(buildMarketReconciliation(reconciliation,after,inventory,packet.reviewedAt),c1);
assert.deepEqual(selectedCoverage.reconciliation,c1);
assert.equal(c1.issues.length,1);assert.equal(c1.issues[0].code,'independent_lists');
assert.deepEqual(Object.keys(c1.issues[0]).sort(),['brand','code','reason','reference']);
const resultSnapshot=structuredClone(result),resultWritten=structuredClone(result),reportOmissions=[];
function reportShape(value,path,clone,parent){
 if(value===undefined){
  assert(/^\/result\/(currentListProof\/issues\/0|selectedCoverage\/reconciliation\/issues\/0|selectedCoverage\/brandProgress\/0\/closureIssues\/0)\/(brand|reference)$/.test(path),'Unexpected report undefined: '+path);
  assert.deepEqual(parent,c1.issues[0]);const property=path.split('/').at(-1),descriptor=Object.getOwnPropertyDescriptor(parent,property);
  assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value')&&descriptor.value===undefined);
  reportOmissions.push({pointer:path,property,ownUndefined:true,enumerable:true,producer:'Actual buildMarketReconciliation independent_lists issue via add(code, reason), no brand/reference arguments'});
  return;
 }
 if(!value||typeof value!=='object')return;
 for(const key of Object.keys(value)){
  reportShape(value[key],path+'/'+key.replaceAll('~','~0').replaceAll('/','~1'),clone?.[key],value);
  if(value[key]===undefined)delete clone[key];
 }
}
reportShape(result,'/result',resultWritten,null);
assertDeclaredJson(result,'/result',new Set(reportOmissions.map(x=>x.pointer)));
assert.deepEqual(JSON.parse(JSON.stringify(result)),resultWritten);assert.deepEqual(result,resultSnapshot);
fs.writeFileSync(out+'/report-undefined-witnesses.json',JSON.stringify(reportOmissions,null,2)+'\n',{flag:'wx'});
fs.writeFileSync(out+'/result.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
assert.deepEqual(readJson(out+'/result.json'),resultWritten);assert.deepStrictEqual(result,resultSnapshot);
fullResearchExact(base,currentFields,'baseResearch');assert.deepStrictEqual(before,beforeSnapshot);fullResearchExact(data,candidateFields,'candidateResearch');assert.deepStrictEqual(after,afterSnapshot);assert.deepStrictEqual(packet,packetSnapshot);assert.deepStrictEqual(afterPacks,snapshot);
progress('Ten selected packs, 183 fact claims, 690 feature claims and exact portable/citable ownership proved');

// The newly accepted selected run is a separate written witness. Never compare written claims directly to live claims.
const acceptedSelected=readJson(m.selectedResult.path);
assert.equal(acceptedSelected.status,'selected_actual_consumers_and_exact_serialization_witness_pass');assert.equal(acceptedSelected.packetSha256,m.packet.sha256);
for(const [name,pin]of Object.entries(m.selectedArtifacts))assert.equal(fileHash(out+'/'+name+'.json'),pin.sha256,'Exact selected written artifact '+name);
const acceptedWrittenPacks=readJson(m.selectedArtifacts['selected-packs'].path);
const acceptedWrittenClaims=readJson(m.selectedArtifacts.claims.path),acceptedWrittenFeatureClaims=readJson(m.selectedArtifacts['feature-claims'].path);
const regeneratedFacts=acceptedWrittenClaims.map(row=>({variantId:row.variantId,key:row.key,claim:factClaim(acceptedWrittenPacks[row.variantId],acceptedWrittenPacks[row.variantId].car.facts[row.key],m.asOf)}));
const regeneratedFeatures=acceptedWrittenFeatureClaims.map(row=>({variantId:row.variantId,criterion:row.criterion,claim:featureClaim(acceptedWrittenPacks[row.variantId],row.criterion,row.criterion,m.asOf)}));
assert.deepStrictEqual(claims,regeneratedFacts);assert.deepStrictEqual(featureClaims,regeneratedFeatures);
assert.deepStrictEqual(observations,acceptedSelected.optionalFeaturePaths);assert.deepStrictEqual(claimOmissions,acceptedSelected.optionalCitationPaths);
assert.deepStrictEqual(readJson(out+'/result.json').selectedCoverage,acceptedSelected.selectedCoverage);
// Full structural ranking comparison: peers stay exact inside compatible groups; whole groups may move.
const discoverySource=fs.readFileSync(repo+'/src/lib/discovery.ts','utf8');
const comparatorSource='(a, b) =>\n        b.entries.length - a.entries.length || a.basis.localeCompare(b.basis)';
assert.equal(discoverySource.split(comparatorSource).length,2,'Unique production group-sort expression');
const groupCompare=(a,b)=>b.entries.length-a.entries.length||a.basis.localeCompare(b.basis);
const groupKey=group=>JSON.stringify([group.vehicleClass,group.basis,group.unit]);
const globalRankProof=[];
function groupProof(ranking,inputCars,attribute){
 const byKey=new Map(ranking.groups.map(group=>[groupKey(group),group]));assert.equal(byKey.size,ranking.groups.length);
 const memberGroup=new Map();for(const group of ranking.groups)for(const entry of group.entries){assert(!memberGroup.has(entry.car.id));memberGroup.set(entry.car.id,groupKey(group));assert.deepStrictEqual(entry.fact,entry.car.facts[attribute.key]);}
 const insertionKeys=[];for(const car of inputCars){const key=memberGroup.get(car.id);if(key&&!insertionKeys.includes(key))insertionKeys.push(key);}
 assert.equal(insertionKeys.length,ranking.groups.length);
 const predicted=insertionKeys.map(key=>byKey.get(key)).sort(groupCompare);assert.deepStrictEqual(predicted.map(groupKey),ranking.groups.map(groupKey));
 for(const group of ranking.groups){
  const ordered=[...group.entries].sort((a,b)=>(Number(a.fact.value)-Number(b.fact.value))*(attribute.direction==='lower'?1:-1)||a.car.id.localeCompare(b.car.id));
  assert.deepStrictEqual(ordered.map(row=>row.car.id),group.entries.map(row=>row.car.id));
  for(const row of group.entries){const value=Number(row.fact.value);assert.equal(row.rank,group.entries.findIndex(entry=>Number(entry.fact.value)===value)+1);assert.equal(row.tied,group.entries.filter(entry=>Number(entry.fact.value)===value).length>1);}
 }
 return {insertionKeys,sortedKeys:ranking.groups.map(groupKey),groups:ranking.groups.map(group=>({key:groupKey(group),count:group.entries.length,ids:group.entries.map(row=>row.car.id),selectedIds:group.entries.filter(row=>selected.has(row.car.id)).map(row=>row.car.id),peerIds:group.entries.filter(row=>peerIds.has(row.car.id)).map(row=>row.car.id)}))};
}
for(const attribute of attributes){
 const old=rankAttribute(currentCars,base.sources,attribute.key,policy),next=rankAttribute(cars,data.sources,attribute.key,policy);
 const a=groupProof(old,currentCars,attribute),b=groupProof(next,cars,attribute),aBy=new Map(a.groups.map(group=>[group.key,group])),bBy=new Map(b.groups.map(group=>[group.key,group]));
 for(const key of new Set([...aBy.keys(),...bBy.keys()])){
  const oldGroup=aBy.get(key),newGroup=bBy.get(key),oldPeers=oldGroup?.peerIds??[],newPeers=newGroup?.peerIds??[];
  assert.deepStrictEqual(newPeers,oldPeers,'Peer order within compatible group '+attribute.key+'/'+key);
  assert.equal(newGroup?.count??0,(oldGroup?.count??0)-(oldGroup?.selectedIds.length??0)+(newGroup?.selectedIds.length??0));
 }
 assert.deepStrictEqual(next.excluded.filter(row=>peerIds.has(row.carId)),old.excluded.filter(row=>peerIds.has(row.carId)));
 assert.deepStrictEqual(next.unranked.filter(row=>peerIds.has(row.car.id)),old.unranked.filter(row=>peerIds.has(row.car.id)));
 assert.deepStrictEqual(new Set(b.groups.flatMap(group=>group.selectedIds)),new Set(expected.rankingIds[attribute.key]));
 globalRankProof.push({attribute:attribute.key,before:a,after:b,peerExclusions:next.excluded.filter(row=>peerIds.has(row.carId)),peerMembershipAndWithinGroupOrderExact:true,productionGroupComparator:comparatorSource,insertionTiesProvedFromActualInputOrder:true,selectedCountDeltasExact:true});
}
write('global-ranking-comparison',globalRankProof);
// Actual global C1 only: match loader import inputs without importing or invoking its full loader.
const actualPaths=[...fs.readFileSync(repo+'/scripts/reporting/load.ts','utf8').matchAll(/import \w+ from "(\.\.\/\.\.\/data\/m1-[^"]+\.json)";/g)].map(match=>path.resolve(repo+'/scripts/reporting',match[1]));assert.deepStrictEqual(actualPaths,m.reconciliationInputs.map(pin=>pin.path));assert.equal(actualPaths.length,26);
const {combineM1Reconciliations}=require('./scripts/reporting/m1-reconciliation.ts');
const baseReconciliation=combineM1Reconciliations(...m.reconciliationInputs.map(pin=>require(pin.path)));
const baselineC1=buildMarketReconciliation(baseReconciliation,currentCars.filter(isTierOne).filter(car=>isCurrentListEligible(car,base.sources,m.asOf)),allInventory,m.asOf);
const acceptedStageGlobal=readJson(m.acceptedDeepalC1.path).after,acceptedReport=readJson(m.acceptedNormalReport.path),normalTerminal=readJson(m.acceptedNormalTerminal.path);
assert.equal(normalTerminal.exitCode,0);assert.equal(normalTerminal.stdoutSha256,m.acceptedNormalReport.sha256);
const fixtureRegistry={schemaVersion:1,checkedAt:m.asOf,publishedLists:[],currentVersionReviews:[],listResolutions:[],inventoryResolutions:[],catalogueOnlyDifferences:[]},fixtureInventory={records:[],unverifiedLeads:[]};
const fixture=buildMarketReconciliation(fixtureRegistry,[],fixtureInventory,m.asOf);assert.deepStrictEqual(fixture.issues.map(issue=>issue.code),['independent_lists','empty_catalogue']);
const producedIssue=fixture.issues[0],issueOwnership=[];assert.deepStrictEqual(Object.keys(producedIssue).sort(),['brand','code','reason','reference']);
for(const property of ['brand','reference']){const descriptor=Object.getOwnPropertyDescriptor(producedIssue,property);assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value'));assert.equal(descriptor.value,undefined);issueOwnership.push({property,ownUndefined:true,enumerable:true,producer:'Actual buildMarketReconciliation fixture add(code,reason)'});}
function c1Written(live,label){
 const snapshot=structuredClone(live),clone=structuredClone(live),indices=live.issues.map((issue,index)=>issue.code==='independent_lists'?index:-1).filter(index=>index>=0);assert.equal(indices.length,1);
 const index=indices[0],issue=live.issues[index];assert.deepStrictEqual(issue,producedIssue);const allowed=new Set();
 for(const property of ['brand','reference']){assert.deepStrictEqual(Object.getOwnPropertyDescriptor(issue,property),Object.getOwnPropertyDescriptor(producedIssue,property));allowed.add('/'+label+'/issues/'+index+'/'+property);delete clone.issues[index][property];}
 assertDeclaredJson(live,'/'+label,allowed);assert.deepStrictEqual(JSON.parse(JSON.stringify(live)),clone);assert.deepStrictEqual(live,snapshot);return clone;
}
const baselineWritten=c1Written(baselineC1,'baselineC1');assert.deepStrictEqual(baselineWritten,acceptedStageGlobal);assert.deepStrictEqual(baselineWritten,acceptedReport.reconciliation);
const expectedLive=structuredClone(acceptedStageGlobal),independentIndex=expectedLive.issues.findIndex(issue=>issue.code==='independent_lists');assert.equal(independentIndex,baselineC1.issues.findIndex(issue=>issue.code==='independent_lists'));expectedLive.issues[independentIndex]=producedIssue;assert.deepStrictEqual(baselineC1,expectedLive);
const proposedReconciliation=combineM1Reconciliations(baseReconciliation,reconciliation),globalC1=buildMarketReconciliation(proposedReconciliation,cars.filter(isTierOne).filter(car=>isCurrentListEligible(car,data.sources,m.asOf)),allInventory,m.asOf);
assert.equal(baselineC1.reviewedModels,98);assert.equal(baselineC1.reviewedVersions,221);assert.equal(globalC1.reviewedModels,101);assert.equal(globalC1.reviewedVersions,231);assert.equal(globalC1.registryValid,true);assert.equal(globalC1.pass,false);
const inventorySet=new Set(expected.expectedSettledInventory),nonMiniIssue=issue=>!isMini(issue.brand)&&!selected.has(issue.reference)&&!inventorySet.has(issue.reference);
assert.deepStrictEqual(globalC1.issues.filter(nonMiniIssue),baselineC1.issues.filter(nonMiniIssue));assert.equal(globalC1.issues.filter(issue=>!nonMiniIssue(issue)).length,0);assert.equal(baselineC1.issues.filter(issue=>!nonMiniIssue(issue)).length,13);
assert.deepStrictEqual(globalC1.settledInventory.filter(id=>!inventorySet.has(id)),baselineC1.settledInventory.filter(id=>!inventorySet.has(id)));
assert.deepStrictEqual(new Set(globalC1.settledInventory.filter(id=>inventorySet.has(id))),inventorySet);
assert.deepStrictEqual(globalC1.reviewedVersionIds.filter(id=>!selected.has(id)),baselineC1.reviewedVersionIds);
assert.deepStrictEqual(globalC1.validModelReviewIds.filter(id=>!inventoryProof.currentVersionReviewIds.includes(id)),baselineC1.validModelReviewIds);
assert.deepStrictEqual(cars.map(car=>car.id),currentCars.map(car=>car.id));assert.equal(cars.length,427);assert.equal(cars.filter(isTierOne).length,350);assert.equal(cars.filter(isTierOne).filter(isOnSale).length,309);
write('baseline-global-c1',baselineC1);write('global-c1-comparison',{before:baselineWritten,after:c1Written(globalC1,'globalC1'),baselineMatchesAcceptedDeepalAndNormal:true,nonMiniIssuesReviewsDispositionsExact:true,issueOwnership,normalFullReportRun:false});
progress('Global compatible-group ranking and C1 structure proved without broad features');
fullResearchExact(base,currentFields,'baseResearch');fullCarsExact(currentCars,currentDigests,'currentCars');fullResearchExact(data,candidateFields,'candidateResearch');fullCarsExact(cars,candidateDigests,'candidateCars');
assert.deepStrictEqual(before,beforeSnapshot);assert.deepStrictEqual(after,afterSnapshot);assert.deepStrictEqual(packet,packetSnapshot);assert.deepStrictEqual(afterPacks,snapshot);assert.equal(defaultCalls,0);
for(const file of ['src/lib/data.ts','src/lib/catalogue.ts','src/lib/research.ts','scripts/reporting/load.ts'])assert(!require.cache[repo+'/'+file]);checkPins();
write('metadata-composition',transitions);write('car-digest-comparison',{...carStages,candidate27:candidateDigests});write('research-field-digests',{...fieldStages,candidate27:candidateFields});
write('stage-receipt',{status:'bounded_structural_selected_stage_pass_pending_independent_review',manifestSha256:args[3],packetSha256:m.packet.sha256,originalBaselineCars:409,acceptedCurrentCars:427,stagedCars:427,tierOneVersions:350,onSaleVersions:309,untouchedPeerCars:417,newModels:0,newVersions:0,versionUpdates:0,configurationUpdates:0,manualFeatureUpdates:0,sourceRowsAdded:46,allAcceptedStagesThroughDeepal26ExactlyReproduced:true,all14ResearchFieldsProved:true,strictJsonShapeBeforeDigest:true,actualSelectedCars:10,actualFactAndTermClaims:earnedCells,actualFeatureClaims:featureClaims.length,roadsideRefreshes,driveawayFallbacks,otherSelectedFeaturesExact:true,actualOptionalWitnessesExact:true,inMemoryPortableExact:true,writtenPortableExact:true,writtenClaimReadback:true,selectedC1:c1Written(c1,'selectedC1'),globalC1Counts:{reviewedModels:globalC1.reviewedModels,reviewedVersions:globalC1.reviewedVersions,pass:globalC1.pass},sourceAdditionsDoNotReviveAcceptedReferences:true,allPeerDigestsAndIdentitiesExact:true,peerOrderExactWithinCompatibleRankingGroups:true,productionGroupSortingAndInsertionTieProvenance:true,broadFeatureReplay:false,normalFullReportRun:false,normalFullReportRequiredAfterGuardedIntegration:true,defaultLoaderCalls:defaultCalls,liveSourceEdits:false,productionRegistration:false,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log(JSON.stringify({status:'passed',receipt:out+'/stage-receipt.json',sha256:fileHash(out+'/stage-receipt.json'),noBroadFeatureReplay:true}));
