from pathlib import Path
import json,hashlib,re
O=Path('/tmp/mini-packet/full-stage-v1');P=Path('/tmp/mini-packet');R=Path('/workspace/scratch/586427eef9f2/roadmark-104');S=P/'selected-preflight-v4';D=Path('/tmp/deepal-packet/full-stage-v4');PLAN=P/'full-stage-plan-v1/PLAN.md'
def pin(path):
 path=Path(path);h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(65536),b''):h.update(block)
 return dict(path=str(path),bytes=path.stat().st_size,sha256=h.hexdigest())
def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
old=json.loads((D/'manifest.json').read_text());registry=json.loads((R/'data/m1-brand-updates/registry.json').read_text());ids=['m1-'+name.removesuffix('.json') for name in registry['packets']];assert len(ids)==26 and ids[-1]=='m1-deepal-2026-10-15'
selected=json.loads((S/'expected-review.json').read_text());result=json.loads((S/'result.json').read_text());assert result['packetSha256']==selected['packetSha256'] and result['status']=='selected_actual_consumers_and_exact_serialization_witness_pass'
files={Path(p['path']) for p in json.loads((S/'source-pins.json').read_text())}
files.update(Path(p['path']) for p in old['pins'] if p['path'].startswith(str(R)) or p['path'].startswith(('/tmp/mercedes-staging-plan/','/tmp/xpeng-staging-plan/')))
refs={'acceptedManifest':old['acceptedManifest'],'packet':pin(P/'mini-2026-10-15-candidate-v3.json'),'reconciliation':pin(P/'mini-market-reconciliation-v3.json'),'expectedReview':pin(S/'expected-review.json'),'inventoryReview':pin(S/'inventory-resolution-review.json'),'selectedBefore':pin('/tmp/mini-research/retained-before-cars.json'),'selectedAfter':pin(S/'selected-after-cars.json'),'selectedResult':pin(S/'result.json'),'selectedTerminal':pin(S/'run/terminal.json'),'selectedReadiness':pin('/tmp/mini-review/preflight-v4-readiness-receipt.json'),'selectedOutputReview':pin('/tmp/mini-review/preflight-v4-output-review.json'),'acceptedDeepalCars':pin(D/'output/car-digest-comparison.json'),'acceptedDeepalFields':pin(D/'output/research-field-digests.json'),'acceptedDeepalC1':pin(D/'output/global-c1-comparison.json'),'acceptedDeepalReceipt':pin(D/'output/stage-receipt.json'),'acceptedDeepalTerminal':pin(D/'run/terminal.json'),'acceptedNormalReport':pin('/workspace/scratch/586427eef9f2/roadmark-104-qa/deepal-continuation-checks/normal-coverage-asof-2026-10-15/stdout.log'),'acceptedNormalTerminal':pin('/workspace/scratch/586427eef9f2/roadmark-104-qa/deepal-continuation-checks/normal-coverage-asof-2026-10-15/terminal.json'),'script':pin(O/'stage.mjs'),'wrapper':pin(O/'run.py')}
artifacts={name:pin(S/(name+'.json')) for name in ['selected-after-cars','selected-packs','portable','claims','feature-claims','undefined-witnesses','claim-undefined-witnesses','report-undefined-witnesses']}
reconciliationPaths=[(R/'scripts/reporting'/name).resolve() for name in re.findall(r'import \w+ from "(\.\./\.\./data/m1-[^"]+\.json)";',(R/'scripts/reporting/load.ts').read_text())];assert len(reconciliationPaths)==26
reconciliationInputs=[pin(path) for path in reconciliationPaths];rawInputs=[pin(p['path']) for p in old['rawOverlayInputs']]
files.update(Path(p['path']) for p in [*refs.values(),*artifacts.values(),*reconciliationInputs,*rawInputs]);files.update([PLAN,O/'prepare-manifest.py',R/'scripts/reporting/load.ts',S/'run/after-pins.json',S/'prepared-command.json',S/'source-pins.json'])
files.update(R/'data/m1-brand-updates'/name for name in registry['packets'])
queue=[f for f in files if str(f).startswith(str(R)) and f.suffix in ['.ts','.tsx']];seen=set()
while queue:
 f=queue.pop()
 if f in seen:continue
 seen.add(f)
 for spec in re.findall(r'''(?:from\s*|import\s*\(?\s*|require\(\s*)["']([^"']+)["']''',f.read_text()):
  if not spec.startswith('.'):continue
  root=(f.parent/spec).resolve();hit=next((p for p in [root,Path(str(root)+'.ts'),Path(str(root)+'.tsx'),Path(str(root)+'.json'),root/'index.ts'] if p.is_file()),None)
  if hit:
   files.add(hit)
   if hit.suffix in ['.ts','.tsx']:queue.append(hit)
m=dict(schemaVersion=1,status='frozen_pending_independent_command_review_and_root_execution_grant',mode='derived-prefix20-through-Deepal26-then-MINI27-no-broad-features',asOf='2026-10-15',repo=str(R),nodeVersion='v24.19.0',execArgv=['--max-old-space-size=448','--max-semi-space-size=1','--expose-gc','--import','tsx'],timeoutSeconds=420,killAfterSeconds=10,automaticRetry=False,productionRegistrationAuthorized=False,canonicalRecaptureAuthorized=False,normalFullReportInStage=False,rootExecutionGrantRequired=True,exclusiveHeavySlotRequired=True,**refs,selectedArtifacts=artifacts,storageIndex=old['storageIndex'],registeredPacketIds=ids,selectedIds=selected['currentListIds'],rawOverlayInputs=rawInputs,reconciliationInputs=reconciliationInputs,output=str(O/'output'),runOutput=str(O/'run'),expected=dict(beforeCatalogue=427,afterCatalogue=427,beforeTierOne=350,afterTierOne=350,beforeOnSale=309,afterOnSale=309,beforePackets=26,afterPackets=27,changedRetainedCars=10,unchangedPeers=417,sourcesAdded=46,specificFacts=153,termCells=30,coreCells=170,earnedCells=183,selectedFeatureClaims=690,currentModels=3,currentNamedGrades=10,settledInventoryRecords=3,globalC1Complete=False),pins=[pin(path) for path in sorted(files)],scope='Restore retained409 prefix20 once; reproduce every accepted complete-car/all14-field digest through EQA21, Leap22, Mazda23, Skoda24, Audi25, Deepal26 before MINI27. No helper changes. Exactly ten selected packs, 183 fact claims, 690 feature claims, exact live/written ownership and global structural ranking/C1 checks. Strict whole-value JSON shape plus byte digests guard full research/cars without full clones. 417 peer cars unchanged and 427/350/309 counts fixed. No broad feature replay, normal report, production loader, live edit, registration, canonical recapture, server or automatic retry. One later normal production report after separately guarded integration remains required.')
save(O/'manifest.json',m);h=pin(O/'manifest.json')['sha256'];command=['node',*m['execArgv'],m['script']['path'],'--manifest',str(O/'manifest.json'),'--manifest-sha256',h]
save(O/'root-grant-template.json',dict(authorized=False,exclusiveHeavySlotGranted=False,action='run_single_bounded_mini_full_stage',preparedManifestSha256=h,command=command,automaticRetry=False,note='Template only; a new explicit root grant and released exclusive heavy slot are required.'))
print(json.dumps({'manifest':pin(O/'manifest.json'),'script':refs['script'],'wrapper':refs['wrapper'],'pins':len(files),'reconciliationInputs':len(reconciliationInputs),'executed':False},indent=2))
