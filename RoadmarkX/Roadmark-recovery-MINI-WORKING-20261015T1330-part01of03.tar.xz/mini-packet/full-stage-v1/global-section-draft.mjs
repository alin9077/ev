// The newly accepted selected run is a separate written witness. Never compare written claims directly to live claims.
const acceptedSelected=readJson(m.selectedResult.path);
assert.equal(acceptedSelected.status,'selected_actual_consumers_and_exact_serialization_witness_pass');assert.equal(acceptedSelected.packetSha256,m.packet.sha256);
for(const [name,pin]of Object.entries(m.selectedArtifacts))assert.equal(fileHash(out+'/'+name+'.json'),pin.sha256,'Exact selected written artifact '+name);
const acceptedWrittenPacks=readJson(m.selectedArtifacts['selected-packs'].path);
const acceptedWrittenClaims=readJson(m.selectedArtifacts.claims.path),acceptedWrittenFeatureClaims=readJson(m.selectedArtifacts['feature-claims'].path);
const regeneratedFacts=acceptedWrittenClaims.map(row=>({variantId:row.variantId,key:row.key,claim:factClaim(acceptedWrittenPacks[row.variantId],acceptedWrittenPacks[row.variantId].car.facts[row.key],m.asOf)}));
const regeneratedFeatures=acceptedWrittenFeatureClaims.map(row=>({variantId:row.variantId,criterion:row.criterion,claim:featureClaim(acceptedWrittenPacks[row.variantId],row.criterion,row.criterion,m.asOf)}));
assert.deepStrictEqual(claims,regeneratedFacts);assert.deepStrictEqual(featureClaims,regeneratedFeatures);
assert.deepStrictEqual(observations,acceptedSelected.optionalFeaturePaths);assert.deepStrictEqual(claimOmissions,acceptedSelected.optionalCitationPaths);
assert.deepStrictEqual(readJson(out+'/result.json').selectedCoverage,acceptedSelected.selectedCoverage);
// Full structural ranking comparison: peers stay exact inside compatible groups; whole groups may move.
const discoverySource=fs.readFileSync(repo+'/src/lib/discovery.ts','utf8');
const comparatorSource='(a, b) =>\n        b.entries.length - a.entries.length || a.basis.localeCompare(b.basis)';
assert.equal(discoverySource.split(comparatorSource).length,2,'Unique production group-sort expression');
const groupCompare=(a,b)=>b.entries.length-a.entries.length||a.basis.localeCompare(b.basis);
const groupKey=group=>JSON.stringify([group.vehicleClass,group.basis,group.unit]);
const globalRankProof=[];
function groupProof(ranking,inputCars,attribute){
 const byKey=new Map(ranking.groups.map(group=>[groupKey(group),group]));assert.equal(byKey.size,ranking.groups.length);
 const memberGroup=new Map();for(const group of ranking.groups)for(const entry of group.entries){assert(!memberGroup.has(entry.car.id));memberGroup.set(entry.car.id,groupKey(group));assert.deepStrictEqual(entry.fact,entry.car.facts[attribute.key]);}
 const insertionKeys=[];for(const car of inputCars){const key=memberGroup.get(car.id);if(key&&!insertionKeys.includes(key))insertionKeys.push(key);}
 assert.equal(insertionKeys.length,ranking.groups.length);
 const predicted=insertionKeys.map(key=>byKey.get(key)).sort(groupCompare);assert.deepStrictEqual(predicted.map(groupKey),ranking.groups.map(groupKey));
 for(const group of ranking.groups){
  const ordered=[...group.entries].sort((a,b)=>(Number(a.fact.value)-Number(b.fact.value))*(attribute.direction==='lower'?1:-1)||a.car.id.localeCompare(b.car.id));
  assert.deepStrictEqual(ordered.map(row=>row.car.id),group.entries.map(row=>row.car.id));
  for(const row of group.entries){const value=Number(row.fact.value);assert.equal(row.rank,group.entries.findIndex(entry=>Number(entry.fact.value)===value)+1);assert.equal(row.tied,group.entries.filter(entry=>Number(entry.fact.value)===value).length>1);}
 }
 return {insertionKeys,sortedKeys:ranking.groups.map(groupKey),groups:ranking.groups.map(group=>({key:groupKey(group),count:group.entries.length,ids:group.entries.map(row=>row.car.id),selectedIds:group.entries.filter(row=>selected.has(row.car.id)).map(row=>row.car.id),peerIds:group.entries.filter(row=>peerIds.has(row.car.id)).map(row=>row.car.id)}))};
}
for(const attribute of attributes){
 const old=rankAttribute(currentCars,base.sources,attribute.key,policy),next=rankAttribute(cars,data.sources,attribute.key,policy);
 const a=groupProof(old,currentCars,attribute),b=groupProof(next,cars,attribute),aBy=new Map(a.groups.map(group=>[group.key,group])),bBy=new Map(b.groups.map(group=>[group.key,group]));
 for(const key of new Set([...aBy.keys(),...bBy.keys()])){
  const oldGroup=aBy.get(key),newGroup=bBy.get(key),oldPeers=oldGroup?.peerIds??[],newPeers=newGroup?.peerIds??[];
  assert.deepStrictEqual(newPeers,oldPeers,'Peer order within compatible group '+attribute.key+'/'+key);
  assert.equal(newGroup?.count??0,(oldGroup?.count??0)-(oldGroup?.selectedIds.length??0)+(newGroup?.selectedIds.length??0));
 }
 assert.deepStrictEqual(next.excluded.filter(row=>peerIds.has(row.carId)),old.excluded.filter(row=>peerIds.has(row.carId)));
 assert.deepStrictEqual(next.unranked.filter(row=>peerIds.has(row.car.id)),old.unranked.filter(row=>peerIds.has(row.car.id)));
 assert.deepStrictEqual(new Set(b.groups.flatMap(group=>group.selectedIds)),new Set(expected.rankingIds[attribute.key]));
 globalRankProof.push({attribute:attribute.key,before:a,after:b,peerExclusions:next.excluded.filter(row=>peerIds.has(row.carId)),peerMembershipAndWithinGroupOrderExact:true,productionGroupComparator:comparatorSource,insertionTiesProvedFromActualInputOrder:true,selectedCountDeltasExact:true});
}
write('global-ranking-comparison',globalRankProof);
// Actual global C1 only: match loader import inputs without importing or invoking its full loader.
const actualPaths=[...fs.readFileSync(repo+'/scripts/reporting/load.ts','utf8').matchAll(/import \w+ from "(\.\.\/\.\.\/data\/m1-[^"]+\.json)";/g)].map(match=>path.resolve(repo+'/scripts/reporting',match[1]));assert.deepStrictEqual(actualPaths,m.reconciliationInputs.map(pin=>pin.path));assert.equal(actualPaths.length,26);
const {combineM1Reconciliations}=require('./scripts/reporting/m1-reconciliation.ts');
const baseReconciliation=combineM1Reconciliations(...m.reconciliationInputs.map(pin=>require(pin.path)));
const baselineC1=buildMarketReconciliation(baseReconciliation,currentCars.filter(isTierOne).filter(car=>isCurrentListEligible(car,base.sources,m.asOf)),allInventory,m.asOf);
const acceptedStageGlobal=readJson(m.acceptedDeepalC1.path).after,acceptedReport=readJson(m.acceptedNormalReport.path),normalTerminal=readJson(m.acceptedNormalTerminal.path);
assert.equal(normalTerminal.exitCode,0);assert.equal(normalTerminal.stdoutSha256,m.acceptedNormalReport.sha256);
const fixtureRegistry={schemaVersion:1,checkedAt:m.asOf,publishedLists:[],currentVersionReviews:[],listResolutions:[],inventoryResolutions:[],catalogueOnlyDifferences:[]},fixtureInventory={records:[],unverifiedLeads:[]};
const fixture=buildMarketReconciliation(fixtureRegistry,[],fixtureInventory,m.asOf);assert.deepStrictEqual(fixture.issues.map(issue=>issue.code),['independent_lists','empty_catalogue']);
const producedIssue=fixture.issues[0],issueOwnership=[];assert.deepStrictEqual(Object.keys(producedIssue).sort(),['brand','code','reason','reference']);
for(const property of ['brand','reference']){const descriptor=Object.getOwnPropertyDescriptor(producedIssue,property);assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value'));assert.equal(descriptor.value,undefined);issueOwnership.push({property,ownUndefined:true,enumerable:true,producer:'Actual buildMarketReconciliation fixture add(code,reason)'});}
function c1Written(live,label){
 const snapshot=structuredClone(live),clone=structuredClone(live),indices=live.issues.map((issue,index)=>issue.code==='independent_lists'?index:-1).filter(index=>index>=0);assert.equal(indices.length,1);
 const index=indices[0],issue=live.issues[index];assert.deepStrictEqual(issue,producedIssue);const allowed=new Set();
 for(const property of ['brand','reference']){assert.deepStrictEqual(Object.getOwnPropertyDescriptor(issue,property),Object.getOwnPropertyDescriptor(producedIssue,property));allowed.add('/'+label+'/issues/'+index+'/'+property);delete clone.issues[index][property];}
 assertDeclaredJson(live,'/'+label,allowed);assert.deepStrictEqual(JSON.parse(JSON.stringify(live)),clone);assert.deepStrictEqual(live,snapshot);return clone;
}
const baselineWritten=c1Written(baselineC1,'baselineC1');assert.deepStrictEqual(baselineWritten,acceptedStageGlobal);assert.deepStrictEqual(baselineWritten,acceptedReport.reconciliation);
const expectedLive=structuredClone(acceptedStageGlobal),independentIndex=expectedLive.issues.findIndex(issue=>issue.code==='independent_lists');assert.equal(independentIndex,baselineC1.issues.findIndex(issue=>issue.code==='independent_lists'));expectedLive.issues[independentIndex]=producedIssue;assert.deepStrictEqual(baselineC1,expectedLive);
const proposedReconciliation=combineM1Reconciliations(baseReconciliation,reconciliation),globalC1=buildMarketReconciliation(proposedReconciliation,cars.filter(isTierOne).filter(car=>isCurrentListEligible(car,data.sources,m.asOf)),allInventory,m.asOf);
assert.equal(baselineC1.reviewedModels,98);assert.equal(baselineC1.reviewedVersions,221);assert.equal(globalC1.reviewedModels,101);assert.equal(globalC1.reviewedVersions,231);assert.equal(globalC1.registryValid,true);assert.equal(globalC1.pass,false);
const inventorySet=new Set(expected.expectedSettledInventory),nonMiniIssue=issue=>!isMini(issue.brand)&&!selected.has(issue.reference)&&!inventorySet.has(issue.reference);
assert.deepStrictEqual(globalC1.issues.filter(nonMiniIssue),baselineC1.issues.filter(nonMiniIssue));assert.equal(globalC1.issues.filter(issue=>!nonMiniIssue(issue)).length,0);assert.equal(baselineC1.issues.filter(issue=>!nonMiniIssue(issue)).length,13);
assert.deepStrictEqual(globalC1.settledInventory.filter(id=>!inventorySet.has(id)),baselineC1.settledInventory.filter(id=>!inventorySet.has(id)));
assert.deepStrictEqual(new Set(globalC1.settledInventory.filter(id=>inventorySet.has(id))),inventorySet);
assert.deepStrictEqual(globalC1.reviewedVersionIds.filter(id=>!selected.has(id)),baselineC1.reviewedVersionIds);
assert.deepStrictEqual(globalC1.validModelReviewIds.filter(id=>!inventoryProof.currentVersionReviewIds.includes(id)),baselineC1.validModelReviewIds);
assert.deepStrictEqual(cars.map(car=>car.id),currentCars.map(car=>car.id));assert.equal(cars.length,427);assert.equal(cars.filter(isTierOne).length,350);assert.equal(cars.filter(isTierOne).filter(isOnSale).length,309);
write('baseline-global-c1',baselineC1);write('global-c1-comparison',{before:baselineWritten,after:c1Written(globalC1,'globalC1'),baselineMatchesAcceptedDeepalAndNormal:true,nonMiniIssuesReviewsDispositionsExact:true,issueOwnership,normalFullReportRun:false});
progress('Global compatible-group ranking and C1 structure proved without broad features');
fullResearchExact(base,currentFields,'baseResearch');fullCarsExact(currentCars,currentDigests,'currentCars');fullResearchExact(data,candidateFields,'candidateResearch');fullCarsExact(cars,candidateDigests,'candidateCars');
assert.deepStrictEqual(before,beforeSnapshot);assert.deepStrictEqual(after,afterSnapshot);assert.deepStrictEqual(packet,packetSnapshot);assert.deepStrictEqual(afterPacks,snapshot);assert.equal(defaultCalls,0);
for(const file of ['src/lib/data.ts','src/lib/catalogue.ts','src/lib/research.ts','scripts/reporting/load.ts'])assert(!require.cache[repo+'/'+file]);checkPins();
write('metadata-composition',transitions);write('car-digest-comparison',{...carStages,candidate27:candidateDigests});write('research-field-digests',{...fieldStages,candidate27:candidateFields});
write('stage-receipt',{status:'bounded_structural_selected_stage_pass_pending_independent_review',manifestSha256:args[3],packetSha256:m.packet.sha256,originalBaselineCars:409,acceptedCurrentCars:427,stagedCars:427,tierOneVersions:350,onSaleVersions:309,untouchedPeerCars:417,newModels:0,newVersions:0,versionUpdates:0,configurationUpdates:0,manualFeatureUpdates:0,sourceRowsAdded:46,allAcceptedStagesThroughDeepal26ExactlyReproduced:true,all14ResearchFieldsProved:true,strictJsonShapeBeforeDigest:true,actualSelectedCars:10,actualFactAndTermClaims:earnedCells,actualFeatureClaims:featureClaims.length,roadsideRefreshes,driveawayFallbacks,otherSelectedFeaturesExact:true,actualOptionalWitnessesExact:true,inMemoryPortableExact:true,writtenPortableExact:true,writtenClaimReadback:true,selectedC1:c1Written(c1,'selectedC1'),globalC1Counts:{reviewedModels:globalC1.reviewedModels,reviewedVersions:globalC1.reviewedVersions,pass:globalC1.pass},sourceAdditionsDoNotReviveAcceptedReferences:true,allPeerDigestsAndIdentitiesExact:true,peerOrderExactWithinCompatibleRankingGroups:true,productionGroupSortingAndInsertionTieProvenance:true,broadFeatureReplay:false,normalFullReportRun:false,normalFullReportRequiredAfterGuardedIntegration:true,defaultLoaderCalls:defaultCalls,liveSourceEdits:false,productionRegistration:false,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log(JSON.stringify({status:'passed',receipt:out+'/stage-receipt.json',sha256:fileHash(out+'/stage-receipt.json'),noBroadFeatureReplay:true}));
