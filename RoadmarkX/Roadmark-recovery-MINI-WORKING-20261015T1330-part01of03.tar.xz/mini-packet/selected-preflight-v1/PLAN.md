# MINI selected actual-consumer preflight — prepared only

The source candidate is independently accepted for isolated staged validation. This command has not run. The backup owns the heavy slot. No live registration, helper change, project build, server, browser or broad catalogue hydration is included.

## Frozen command

Manifest: `/tmp/mini-packet/selected-preflight-v1/prepared-command.json`

SHA256: `a994d3f8b7690536aff6b22b8098d05de51ac957d72ce9e86c780f858dbecd8f`

After independent command review and an explicit root grant releasing the exclusive heavy slot, the wrapper invocation is:

```sh
python /tmp/mini-packet/selected-preflight-v1/run.py \
  /tmp/mini-packet/selected-preflight-v1/prepared-command.json \
  a994d3f8b7690536aff6b22b8098d05de51ac957d72ce9e86c780f858dbecd8f \
  /tmp/mini-packet/selected-preflight-v1/root-execution-grant.json
```

The actual child command is pinned in the manifest: Node with 448 MiB old-space, 1 MiB semi-space and the installed `tsx` loader, executing only `check.mjs`. Supervision is 180 seconds plus a 10-second termination grace. Heap flags are not OS RSS limits. No automatic retry, concurrent command or widening of scope is authorized. The grant template is explicitly unauthorized; preparation does not create a grant.

## Inputs and bounded read path

- Exactly ten full MINI before rows from `retained-before-cars.json`, each matched against its retained receipt and the accepted post-Deepal26 digest
- Actual retained research streamed through the already accepted baseline reader and indexed source files; only the ten variants, ten historic variant contexts, three models and 690 feature rows are retained. Shared source/criteria/context arrays remain source inputs; no production catalogue loader is called
- Live registry must still contain exactly 26 accepted packets ending with Deepal; every preceding packet is checked not to target a MINI row or apply a shared term to one
- Candidate v2 and reconciliation v2 remain unchanged. All 182 input pins, including the selected sources, import closure, existing helper modules, registry packets and source-review receipt, are checked before and after execution
- The project's existing compiled-source helper binds the actual evidence-consumer module to the proposed registry sequence. It changes only the injected registry value for this isolated call. No producer/helper implementation is replaced

## Required checks

1. Actual `prepareBrandResearch` and `applyBrandUpdates`, with all ten identity guards, 153 exact before-fact guards, 30 shared-term guards and ten full availability guards
2. All 170 core cells earn their proposed grades. The remaining three net-battery conflict cells and ten roadside applications are also checked, for 183 updated effective cells
3. Twenty summaries keep exact claim-only dependency facts, source IDs and the producer's complete fact-plus-source freshness entries. Unrelated facts cannot become freshness proxies
4. Exactly 69 criteria per selected car, 690 full feature claims. Only the ten canonical roadside projections may change; all unrelated retained feature rows must remain equal. All ten driveaway answers must be the exact actual source-effective fallback, since neither the GST/delivery maker amounts nor Paul Smith's before-ORC price is a driveaway quote
5. Actual fact claims and feature claims must preserve source closure, grades, explicit Not published nulls, conditions and current evidence dates
6. Actual ranking policy is compared against source-reviewed expectations for every numeric core field, plus every supported discovery attribute. Prices, maximum WLTP, cargo without protocol, width without mirror basis, null tow ratings and genuine conflicts stay excluded. Clean eligible values remain eligible
7. Three current model reviews cover the exact ten identities and the three existing MINI inventory families. Global independent-list closure stays false; residual/arriving findings remain in the separate census
8. Actual in-memory portable storage/hydration must equal complete live packs. Written JSON/readback and written portable hydration must equal only an independently cloned representation with the exact proven optional paths removed. Live objects stay unchanged
9. Re-running actual citable producers against hydrated written packs must reproduce the live claims. Each serialized citation omission must be an own enumerable undefined `limitation` or `checked` field, tied to the actual source metadata and actual citable-producer replay
10. Feature optional omissions are accepted only at exact selected row/index/criterion/property locations, proven from the same-run source/regrade/final projection and, where applicable, actual `auditedFeature(raw)` output. Counts are observed, never copied from Deepal. Any novel optional property or producer mismatch fails
11. The written C1/report boundary permits only the exact actual `independent_lists` issue's own undefined `brand`/`reference` fields, at the three precise report locations. Full written readback equality and unchanged live result are checked
12. Default catalogue/research loader calls must remain zero and production loader modules must remain absent from the require cache. The before cars, input research and live packs must remain unchanged

## Outputs and failure boundary

Create-only outputs are restricted to this preparation directory and its `run` subdirectory: complete selected cars, packs, portable storage, 183 fact claims, 690 feature claims, exact feature/citation/report omission witnesses, selected coverage, rank proofs and result; the wrapper records invocation, terminal status, wait4 memory/resource evidence, stdout/stderr hashes and before/after pins.

The success status in the script is a conditional future output, not a completed test claim. An unexpected omission, stale pin, producer mismatch, source guard failure or timeout stops the command. Keep its raw output and seek a separately reviewed narrow correction; do not normalize arbitrary values, raise memory, retry automatically or alter a helper to force a pass.
