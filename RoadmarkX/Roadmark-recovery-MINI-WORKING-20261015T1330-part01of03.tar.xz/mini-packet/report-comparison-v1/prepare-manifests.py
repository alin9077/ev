from pathlib import Path
import json,hashlib,re
R=Path('/workspace/scratch/586427eef9f2/roadmark-104');B=Path('/tmp/mini-packet/report-comparison-v1');P=Path('/tmp/mini-packet/post-registration-checks-v1');T=Path('/tmp/mini-packet/full-project-typescript-v1')
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def write(n,x):
 with (B/n).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
# Static local dependency traversal only. No project imports or parsers are executed.
seen=set();edges=[];external=set();explicit=[]
def visit(p):
 p=Path(p).resolve()
 if p in seen:return
 seen.add(p)
 if p.suffix not in ['.ts','.tsx','.js','.mjs']:return
 text=p.read_text()
 specs=re.findall(r'''(?:\bfrom\s*|\bimport\s*|\brequire\s*\(\s*)["']([^"']+)["']''',text)
 for spec in specs:
  if not spec.startswith('.'):
   external.add(spec);continue
  base=p.parent/spec;candidates=[base,*(Path(str(base)+suffix) for suffix in ['.ts','.tsx','.js','.mjs','.json']),*(base/('index'+suffix) for suffix in ['.ts','.tsx','.js','.mjs'])]
  match=next((c.resolve() for c in candidates if c.is_file()),None);assert match,(p,spec)
  assert match.is_relative_to(R);edges.append(dict(fromPath=str(p),specifier=spec,toPath=str(match)));visit(match)
 for rel in re.findall(r'''["'](data/[a-zA-Z0-9_.\-/]+\.json)["']''',text):
  target=R/rel;assert target.is_file();explicit.append(dict(fromPath=str(p),relativePath=rel,target=str(target)));seen.add(target)
for rel in ['scripts/report-coverage.ts','src/lib/evidence-consumers.ts','tests/helpers/compiled-source.ts','src/lib/launch-evidence.ts','src/lib/brand-updates.ts']:visit(R/rel)
# Dynamic packet loader is resolved against the exact fixed registration.
registry=json.loads((R/'data/m1-brand-updates/registry.json').read_text());assert len(registry['packets'])==27
seen.add(R/'data/m1-brand-updates/registry.json')
for name in registry['packets']:seen.add(R/'data/m1-brand-updates'/name)
seen.add(R/'node_modules/typescript/lib/typescript.js')
prior=json.loads((P/'source-pins.json').read_text());pins={p['path']:p for p in prior}
for f in seen:
 p=pin(f)
 if str(f) in pins:assert pins[str(f)]==p
 else:pins[str(f)]=p
write('source-pins.json',[pins[k] for k in sorted(pins)])
write('static-import-closure.json',dict(entrypoints=['scripts/report-coverage.ts','src/lib/evidence-consumers.ts','tests/helpers/compiled-source.ts','src/lib/launch-evidence.ts','src/lib/brand-updates.ts'],relativeEdges=edges,explicitJsonReads=explicit,dynamicRegistryPackets=registry['packets'],packageImports=sorted(external),files=[pin(p) for p in sorted(seen)]))
with (B/'run.py').open('xb') as f:f.write((P/'run.py').read_bytes())
base=json.loads((P/'structural-validation.json').read_text())
for key in ['id','kind','command','timeoutSeconds','expectedStructuralCounts','expectedSourceReferences','expectedPublicationIssues','expectedApprovedExternalAssets','immutableResearchSha256','runOutput','prerequisites','extraPins']:base.pop(key,None)
base.update(qaRoot=str(B),sourcePins=pin(B/'source-pins.json'),wrapper=pin(B/'run.py'))
normal=dict(base,id='normal-coverage-asof-2026-10-15',kind='normal-report',command=['/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','--max-old-space-size=448','--max-semi-space-size=1','--import','tsx','scripts/report-coverage.ts','--as-of','2026-10-15','--json'],timeoutSeconds=900,runOutput=str(B/'normal-coverage-asof-2026-10-15'),prerequisites=[dict(manifest=pin(T/'manifest.json'),resultPath=str(T/'run/result.json'))],extraPins=[pin(B/'static-import-closure.json'),pin('/tmp/mini-review/registration-v1-live-readback.json')])
write('normal-coverage-asof-2026-10-15.json',normal)
extra=[B/'compare-report.mjs',B/'README.md',B/'static-import-closure.json',Path('/tmp/mini-review/registration-v1-live-readback.json'),Path('/tmp/mini-review/full-stage-v2-output-review.json'),Path('/tmp/mini-review/full-stage-v2-group-sort-review.json'),Path('/tmp/mini-packet/full-stage-v2/manifest.json'),Path('/tmp/mini-packet/full-stage-v2/output/stage-receipt.json'),Path('/tmp/mini-packet/full-stage-v2/run/terminal.json'),Path('/tmp/mini-packet/selected-preflight-v4/result.json'),Path('/tmp/mini-research/retained-before-cars.json'),Path('/tmp/mini-packet/full-stage-v2/output/selected-packs.json'),Path('/tmp/mini-packet/full-stage-v2/output/selected-after-cars.json'),Path('/tmp/mini-packet/full-stage-v2/output/car-digest-comparison.json'),Path('/tmp/deepal-packet/full-stage-v4/output/car-digest-comparison.json'),Path('/tmp/mercedes-staging-plan/consumer-preparation/v5/manifests/report-v5.json'),Path('/tmp/mercedes-staging-plan/staging-preparation/staging-artifacts/canonical-v1/staged-storage-index.json'),Path('/tmp/mini-review/full-stage-v1-storage-closure.json'),Path('/tmp/deepal-packet/full-stage-v4/output/research-field-digests.json'),Path('/tmp/mini-packet/full-stage-v2/output/research-field-digests.json'),Path('/tmp/mini-packet/full-stage-v2/output/global-ranking-comparison.json'),Path('/tmp/mini-packet/full-stage-v2/output/global-c1-comparison.json'),Path('/tmp/xpeng-staging-plan/baseline-io.mjs'),Path('/tmp/mercedes-staging-plan/staging-preparation/shape-first-v3/read-complete-storage.mjs'),Path('/tmp/xpeng-staging-plan/staging-v1/read-complete-storage.mjs'),Path('/tmp/mercedes-staging-plan/consumer-preparation/v5/feature-json-parity.mjs'),Path('/workspace/scratch/586427eef9f2/roadmark-104-qa/deepal-continuation-checks/normal-coverage-asof-2026-10-15/stdout.log'),Path('/workspace/scratch/586427eef9f2/roadmark-104-qa/deepal-continuation-checks/normal-coverage-asof-2026-10-15/terminal.json')]
extra += [Path('/tmp/'+rel+'/selected-after-cars.json') for rel in ['leapmotor-staging/v4-timeout/output','mazda-staging/full-v2/output','skoda-packet/full-stage-v1/output','audi-packet/full-stage-v1/output','deepal-packet/full-stage-v4/output']]
extra += [Path(p['path']) for p in json.loads(Path('/tmp/mini-review/full-stage-v1-storage-closure.json').read_text())]
extra=sorted(set(extra))
comparison=dict(base,id='report-comparison',kind='comparison',command=['/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','--max-old-space-size=448','--max-semi-space-size=1','--import','tsx',str(B/'compare-report.mjs')],timeoutSeconds=180,runOutput=str(B/'report-comparison'),comparisonResult=str(B/'artifacts/result.json'),prerequisites=[dict(manifest=pin(B/'normal-coverage-asof-2026-10-15.json'),resultPath=str(B/'normal-coverage-asof-2026-10-15/result.json'))],extraPins=[pin(p) for p in extra])
write('report-comparison.json',comparison)
sequence=dict(status='frozen_not_executed_requires_review_and_root_grant',sequence=[pin(B/'normal-coverage-asof-2026-10-15.json'),pin(B/'report-comparison.json')],sourcePins=base['sourcePins'],rootMetadata=base['rootMetadata'],qaRoot=str(B),registrationManifest=base['registrationManifest'],registrationTargets=base['registrationTargets'],normalReportRuns=1,normalReportSubstitutionAllowed=False,priorChecksAndFullProjectTypeScriptRequired=True,noAutomaticRetry=True,extraBroadFeatureReplay=False,coreReasonReconstruction='Digest-verified complete cars and sources, actual production coreCoverage; no peer feature work',executionAuthorized=False)
write('sequence.json',sequence)
g=json.loads((P/'root-grant-template.json').read_text());g['sequence']=pin(B/'sequence.json');g['granted']=[pin(B/'normal-coverage-asof-2026-10-15.json'),pin(B/'report-comparison.json')];g['reviewerAcceptance']=None;g['registrationVerification']=pin('/tmp/mini-review/registration-v1-live-readback.json');write('root-grant-template.json',g)
write('static-verification.json',dict(status='static_preparation_only',projectRuntimeCommandsExecuted=0,sourcePins=len(pins),normalEntry='unchanged scripts/report-coverage.ts through loadReportInput and full effectiveFeatures',comparatorAdditionalPins=len(comparison['extraPins']),exactRetainedStorageClosure=21,wrapperByteIdenticalToPreparedFiveGateWrapper=pin(B/'run.py')['sha256']==pin(P/'run.py')['sha256'],noSourceChanges=True,maximumNormalReportAttempts=1,maximumComparatorAttempts=1,normalLimits='448/1 MiB;900+10 seconds',comparatorLimits='448/1 MiB;180+10 seconds'))
print(json.dumps(dict(sequence=pin(B/'sequence.json'),normal=pin(B/'normal-coverage-asof-2026-10-15.json'),comparison=pin(B/'report-comparison.json'),comparator=pin(B/'compare-report.mjs'),sourcePins=len(pins)),indent=2))
