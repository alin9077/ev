/** One saved normal report versus accepted Deepal26; exact core reasons and selected-only features. */
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import path from 'node:path';
import {readJson,fileHash,streamRows,digestRows} from '/tmp/xpeng-staging-plan/baseline-io.mjs';
import {readCompleteCars} from '/tmp/mercedes-staging-plan/staging-preparation/shape-first-v3/read-complete-storage.mjs';
import {assertDeclaredJson} from '/tmp/mercedes-staging-plan/consumer-preparation/v5/feature-json-parity.mjs';
const repo='/workspace/scratch/586427eef9f2/roadmark-104';
const prep='/tmp/mini-packet/report-comparison-v1';
const qa='/tmp/mini-packet/report-comparison-v1';
assert.equal(process.cwd(),repo);
const out=qa+'/artifacts';assert(!fs.existsSync(out));fs.mkdirSync(out);
const write=(name,value)=>fs.writeFileSync(out+'/'+name+'.json',JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const require=createRequire(repo+'/package.json'),ts=require('typescript');
const normalPath=qa+'/normal-coverage-asof-2026-10-15/stdout.log';
const baselinePath='/workspace/scratch/586427eef9f2/roadmark-104-qa/deepal-continuation-checks/normal-coverage-asof-2026-10-15/stdout.log';
assert.equal(fileHash(baselinePath),'6153972132d6094f497a148d3d850b3ba645efd486a6c9da417dd4ae93ee002a');
const normal=readJson(normalPath),baseline=readJson(baselinePath);
const normalTerminal=readJson(qa+'/normal-coverage-asof-2026-10-15/terminal.json');assert.equal(normalTerminal.exitCode,0);assert.equal(normalTerminal.stdoutSha256,fileHash(normalPath));
function differences(a,b,path=''){
 if(Object.is(a,b))return[];
 if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return[{path,before:a,after:b}];
 const out=[];for(const key of new Set([...Object.keys(a),...Object.keys(b)])){
  const p=path+'/'+key.replaceAll('~','~0').replaceAll('/','~1');
  if(!Object.hasOwn(a,key))out.push({path:p,operation:'add',after:b[key]});
  else if(!Object.hasOwn(b,key))out.push({path:p,operation:'remove',before:a[key]});
  else out.push(...differences(a[key],b[key],p));
 }return out;
}
write('exhaustive-normal-versus-deepal-diff',differences(baseline,normal));
const selectedResult=readJson('/tmp/mini-packet/selected-preflight-v4/result.json');
const selectedAfter=selectedResult.selectedCoverage;
const before=readJson('/tmp/mini-research/retained-before-cars.json');
const packs=readJson('/tmp/mini-packet/full-stage-v2/output/selected-packs.json');
const after=readJson('/tmp/mini-packet/full-stage-v2/output/selected-after-cars.json');
const selectedIds=new Set(before.map(c=>c.id)),modelIds=new Set(before.map(c=>c.modelId));
assert.equal(selectedIds.size,10);assert.equal(selectedResult.otherRetainedFeaturesUnchanged,true);
const selectedSnapshots={before:structuredClone(before),after:structuredClone(after),packs:structuredClone(packs),result:structuredClone(selectedResult)};
const acceptedStageDigests=readJson('/tmp/mini-packet/full-stage-v2/output/car-digest-comparison.json');
const acceptedDeepalDigests=readJson('/tmp/deepal-packet/full-stage-v4/output/car-digest-comparison.json');
assert.deepStrictEqual(acceptedStageDigests.candidate26,acceptedDeepalDigests.candidate26);
assert.equal(acceptedStageDigests.candidate27.length,427);
const oldPeerDigests=acceptedStageDigests.candidate26.filter(c=>!selectedIds.has(c.id)),newPeerDigests=acceptedStageDigests.candidate27.filter(c=>!selectedIds.has(c.id));
assert.equal(oldPeerDigests.length,417);assert.deepStrictEqual(newPeerDigests,oldPeerDigests);
write('accepted-peer-car-value-and-basis-proof',{exactCompletePeerCars:417,allPeerValuesBasesUnitsGradesAndIdentitiesUnchanged:true,peers:newPeerDigests});
const manifest=readJson('/tmp/mercedes-staging-plan/consumer-preparation/v5/manifests/report-v5.json');
const index=readJson('/tmp/mercedes-staging-plan/staging-preparation/staging-artifacts/canonical-v1/staged-storage-index.json');
const base={},reads=[];
const stageManifest=readJson('/tmp/mini-packet/full-stage-v2/manifest.json');
const closure=readJson(stageManifest.storageClosure.path),closureMap=new Map(closure.map(p=>[p.path,p])),readPaths=new Set();
const acceptedInputPins=new Map(manifest.inputPins.map(row=>[row.anchor+'\0'+row.file,row]));
const proof={anchors:manifest.anchors,assertPinned(ref){const pin=acceptedInputPins.get(ref.anchor+'\0'+ref.file),absolute=path.resolve(manifest.anchors[ref.anchor],ref.file),direct=closureMap.get(absolute);assert(pin&&direct);assert.equal(pin.sha256,ref.sha256);assert.equal(pin.bytes,ref.bytes);assert.equal(direct.sha256,ref.sha256);assert.equal(direct.bytes,ref.bytes);readPaths.add(absolute);}};
let restored=await readCompleteCars(proof,stageManifest.storageIndex),completeBefore=restored.cars;restored=null;
const carDigests=cars=>cars.map(car=>({id:car.id,...digestRows([car])}));
assertDeclaredJson(completeBefore,'/prefix20',new Set());assert.deepStrictEqual(carDigests(completeBefore),acceptedDeepalDigests.baseline20);
for(const [key,ref]of Object.entries(index.research))proof.assertPinned(ref);

for(const [key,ref]of Object.entries(index.research)){
 const values=[];
 await streamRows(manifest.anchors,ref,row=>{
  const keep=['variants','feature_evidence_variant_context'].includes(key)?selectedIds.has(row.id):['feature_evidence','trim_equipment','update_eligibility'].includes(key)?selectedIds.has(row.variant_id):key==='models'?modelIds.has(row.id):true;
  if(keep)values.push(row);
 });base[key]=ref.array?values:values[0];reads.push({key,inputRows:ref.rows,retainedRows:values.length,sha256:ref.sha256});
}
assert.equal(base.variants.length,10);assert.equal(base.feature_evidence.length,690);
assert.deepStrictEqual([...readPaths].sort(),[...closureMap.keys()].sort());
function compile(path,relative,overrides={},append=''){
 const filename=repo+'/'+relative,source=fs.readFileSync(path,'utf8')+append;
 const output=ts.transpileModule(source,{fileName:filename,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,esModuleInterop:true}}).outputText;
 const scoped=createRequire(filename),module={exports:{}};
 vm.runInThisContext('(function(require,module,exports){'+output+'\n})',{filename})(id=>Object.hasOwn(overrides,id)?overrides[id]:scoped(id),module,module.exports);return module.exports;
}
// No feature replay for peers. Reconstruct complete cars from already accepted written values.
const {brandUpdatePackets}=require('./src/lib/brand-update-registry.ts');
assert.equal(brandUpdatePackets.length,27);assert.equal(brandUpdatePackets.at(-1).id,'m1-mini-2026-10-15');
const priorPackets=brandUpdatePackets.slice(0,26),packet=brandUpdatePackets.at(-1);
assert.deepStrictEqual(priorPackets.map(p=>p.id),stageManifest.registeredPacketIds);
const sourceMap=new Map(base.sources.map(source=>[source.id,source]));assert.equal(sourceMap.size,base.sources.length);
for(const p of priorPackets.slice(20))for(const source of p.sources){if(sourceMap.has(source.id))assert.deepStrictEqual(sourceMap.get(source.id),source);else sourceMap.set(source.id,structuredClone(source));}
base.sources=[...sourceMap.values()];
assert.deepStrictEqual(digestRows(base.sources),readJson('/tmp/deepal-packet/full-stage-v4/output/research-field-digests.json').candidate26.sources);
const eqa=priorPackets[20];assert.equal(eqa.id,'m1-mercedes-benz-towing-basis-2026-10-15');assert.equal(eqa.facts.length,1);assert.equal(eqa.summaries.length,0);assert.equal(eqa.variants.length,0);assert.equal(eqa.availability.length,0);assert.equal(eqa.versionUpdates.length,0);
const edit=eqa.facts[0],originalEqa=completeBefore.find(car=>car.id===edit.variantId);assert.deepStrictEqual(originalEqa.facts[edit.after.key],edit.before);
completeBefore=completeBefore.map(car=>car.id===edit.variantId?{...car,facts:{...car.facts,[edit.after.key]:structuredClone(edit.after)}}:car);
assertDeclaredJson(completeBefore,'/corrected21',new Set());assert.deepStrictEqual(carDigests(completeBefore),acceptedDeepalDigests.corrected21);
const replacements=[
 ['current22','/tmp/leapmotor-staging/v4-timeout/output/selected-after-cars.json'],
 ['current23','/tmp/mazda-staging/full-v2/output/selected-after-cars.json'],
 ['current24','/tmp/skoda-packet/full-stage-v1/output/selected-after-cars.json'],
 ['candidate25','/tmp/audi-packet/full-stage-v1/output/selected-after-cars.json'],
 ['candidate26','/tmp/deepal-packet/full-stage-v4/output/selected-after-cars.json'],
];
for(const [stage,file]of replacements){
 const rows=readJson(file),replacementMap=new Map(rows.map(car=>[car.id,car]));assert.equal(rows.length,replacementMap.size);
 const existing=new Set(completeBefore.map(car=>car.id));completeBefore=completeBefore.map(car=>replacementMap.get(car.id)??car);completeBefore.push(...rows.filter(car=>!existing.has(car.id)));
 assertDeclaredJson(completeBefore,'/'+stage,new Set());assert.deepStrictEqual(carDigests(completeBefore),acceptedDeepalDigests[stage]);
}
assert.equal(completeBefore.length,427);assert.deepStrictEqual(completeBefore.filter(car=>selectedIds.has(car.id)),before);
const afterMap=new Map(after.map(car=>[car.id,car])),completeAfter=completeBefore.map(car=>afterMap.get(car.id)??car);
assertDeclaredJson(completeAfter,'/completeAfter',new Set());assert.deepStrictEqual(carDigests(completeAfter),acceptedStageDigests.candidate27);
const beforeSourceSnapshot=digestRows(base.sources),afterSources=[...base.sources,...packet.sources];
assert.deepStrictEqual(digestRows(afterSources),readJson('/tmp/mini-packet/full-stage-v2/output/research-field-digests.json').candidate27.sources);
const baseSnapshot=structuredClone(base),packetSnapshot=structuredClone(packet);
const {compiledSource}=require('./tests/helpers/compiled-source.ts');
let defaultCalls=0;const forbidden=()=>{defaultCalls++;throw new Error('FORBIDDEN_DEFAULT_LOADER');};
const consumer=compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets:priorPackets}}).createEvidenceConsumers({sourceResearch:forbidden,research:forbidden,catalogue:forbidden});
const {applyFeatureRegrading}=require('./src/lib/evidence-regrading.ts');
const {applyBrandFeatureUpdates,applyBrandTermFeatures}=require('./src/lib/brand-updates.ts');
const {auditedFeature}=require('./src/lib/launch-evidence.ts');
const beforeFeatures=[],producerReceipts=[],frames=new Map(),observations=[];
function observePack(car,pack,phase){
 const pointers=[];
 function visit(value,pointer){
  if(value===undefined){
   const match=pointer.match(/\/features\/(\d+)\/([^/]+)$/);assert(match,'Unexpected undefined outside feature: '+pointer);
   const rowIndex=Number(match[1]),property=match[2],feature=pack.features[rowIndex],descriptor=Object.getOwnPropertyDescriptor(feature,property);
   assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value')&&descriptor.value===undefined);
   const frame=frames.get(phase+'\0'+car.id),sourceRow=frame.input.find(f=>f.criterion===feature.criterion),regraded=frame.regraded.find(f=>f.criterion===feature.criterion),projected=frame.projected.find(f=>f.criterion===feature.criterion);
   assert(sourceRow&&regraded&&projected);assert.deepEqual(feature,projected);
   let producer;
   if(property==='gradeReviewStatus'){
    assert(feature.gradeReview);assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts earned retained-feature branch explicitly sets gradeReviewStatus undefined';
   }else if(property==='condition_label'){
    assert.equal(feature.buyerGrade,'check');assert(!Object.hasOwn(sourceRow,property)||sourceRow[property]===undefined);assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts Check branch retains source optional condition_label';
   }else if(property==='confirmation_needed'){
    assert.equal(feature.criterion,'novated_fbt');
    for(const row of [sourceRow,regraded]){const d=Object.getOwnPropertyDescriptor(row,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);}
    const raw=frame.research.feature_evidence.find(f=>f.variant_id===car.id&&f.criterion===feature.criterion);assert(raw);
    const snap=structuredClone(raw),audited=auditedFeature(raw);assert.deepEqual(raw,snap);
    const d=Object.getOwnPropertyDescriptor(audited,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);
    producer='launch-evidence.ts actual auditedFeature(raw exact novated_fbt row) creates confirmation_needed undefined';
   }else if(['buyerGrade','gradeReview'].includes(property)){
    assert.equal(feature.gradeReviewStatus,'review_required');assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts unmatched retained-feature branch withdraws optional review';
   }else assert.fail('Unclassified optional undefined: '+pointer);
   observations.push({phase,variantId:car.id,pointer,rowIndex,criterion:feature.criterion,property,ownUndefined:true,enumerable:true,producer,sourceProperty:{own:Object.hasOwn(sourceRow,property),valueKind:sourceRow[property]===undefined?'undefined':typeof sourceRow[property]},regradedProperty:{own:Object.hasOwn(regraded,property),valueKind:regraded[property]===undefined?'undefined':typeof regraded[property]},actualFinalProjectionMatched:true});
   pointers.push(pointer);return;
  }
  if(!value||typeof value!=='object')return;
  for(const key of Object.keys(value))visit(value[key],pointer+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));
 }
 visit(pack,'/packs/'+car.id);assertDeclaredJson(pack,'/packs/'+car.id,new Set(pointers));
}
for(const car of before){
 const input=consumer.sourceEffectiveFeatures(car,base),inputSnapshot=structuredClone(input),regraded=applyFeatureRegrading(car,input,base.sources);
 const branded=applyBrandFeatureUpdates(car,regraded,base,priorPackets),projected=applyBrandTermFeatures(car,branded,base.sources);
 assert.deepStrictEqual(input,inputSnapshot);frames.set('before\0'+car.id,{input,regraded,branded,projected,research:base});
 const features=consumer.effectiveFeatures(car,base);assert.equal(features.length,69);assert.deepStrictEqual(features,projected);
 observePack(car,{features},'before');beforeFeatures.push(...features);
 producerReceipts.push({carId:car.id,criteria:69,sourceRows:input.length,actualCanonicalRows:features.length});
}
assert.equal(beforeFeatures.length,690);assert.deepStrictEqual(observations,selectedResult.optionalFeaturePaths.filter(row=>row.phase==='before'));
const beforeFeatureSnapshot=structuredClone(beforeFeatures);
write('selected-before-features',beforeFeatures);
const beforeWrittenFeatures=readJson(out+'/selected-before-features.json');
for(const car of before)for(const feature of beforeWrittenFeatures.filter(f=>f.variant_id===car.id&&f.criterion!=='roadside_assistance'))assert.deepStrictEqual(feature,packs[car.id].features.find(f=>f.criterion===feature.criterion));
assert.deepStrictEqual(base,baseSnapshot);assert.deepStrictEqual(before,selectedSnapshots.before);
const reports=compile(repo+'/scripts/reporting/reports.ts','scripts/reporting/reports.ts',{},'\nexport { coreFact, gradePattern, coreCoverage };\n');
const inventory=require('./src/lib/market-inventory-data.ts').default;
const miniInventory={...inventory,records:inventory.records.filter(r=>r.brand==='MINI'),unverifiedLeads:inventory.unverifiedLeads.filter(r=>r.brand==='MINI')};
const emptyRegistry={schemaVersion:1,checkedAt:'2026-10-15',notes:[],publishedLists:[],currentVersionReviews:[],listResolutions:[],catalogueOnlyDifferences:[],inventoryResolutions:[]};
const selectedBefore=reports.buildCoverageReport({cars:before,sources:base.sources,features:beforeFeatures,inventory:miniInventory,m1Reconciliation:emptyRegistry},normal.asOf);

const selectedBeforeSnapshot=structuredClone(selectedBefore);
const oldMini=baseline.brandProgress.find(b=>b.brand==='MINI');
// Whole written parity plus exact own-undefined ownership from the actual C1 issue producer.

const {buildMarketReconciliation}=require('./scripts/reporting/m1-reconciliation.ts');
const issueFixtureInventory={records:[],unverifiedLeads:[]};
const issueFixture=buildMarketReconciliation(emptyRegistry,[],issueFixtureInventory,normal.asOf);
assert.equal(issueFixture.registryValid,true);assert.equal(issueFixture.independentListCount,0);
assert.deepEqual(issueFixture.issues.map(i=>i.code),['independent_lists','empty_catalogue']);
const liveMini=selectedBefore.brandProgress.find(b=>b.brand==='MINI');
const producedIssues=issueFixture.issues.filter(i=>i.code==='independent_lists'),expectedIssues=oldMini.closureIssues.filter(i=>i.code==='independent_lists'),liveIssues=liveMini.closureIssues.filter(i=>i.code==='independent_lists');
assert.equal(producedIssues.length,1);assert.equal(expectedIssues.length,1);assert.equal(liveIssues.length,1);
const producedIssue=producedIssues[0],expectedIssue=expectedIssues[0],liveIssue=liveIssues[0];
assert.deepEqual(Object.keys(expectedIssue).sort(),['code','reason']);
assert.deepEqual(Object.keys(producedIssue).sort(),['brand','code','reason','reference']);
assert.deepEqual(Object.keys(liveIssue).sort(),['brand','code','reason','reference']);
const issueOwnership=[];
for(const property of ['brand','reference']){
 const actual=Object.getOwnPropertyDescriptor(liveIssue,property),producer=Object.getOwnPropertyDescriptor(producedIssue,property);
 for(const descriptor of [actual,producer]){assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value'));assert.equal(descriptor.value,undefined);}
 assert.deepEqual(actual,producer);assert(!Object.hasOwn(expectedIssue,property));
 issueOwnership.push({property,ownUndefined:true,enumerable:true,producer:'actual buildMarketReconciliation → add(code,reason) creates both optional own properties; pinned m1-reconciliation.ts'});
}
write('selected-before-c1-issue-producer',{fixtureRegistry:emptyRegistry,fixtureCars:[],fixtureInventory:issueFixtureInventory,asOf:normal.asOf,issue:producedIssue,exactOwnership:issueOwnership});
assert.deepEqual(readJson(out+'/selected-before-c1-issue-producer.json').issue,expectedIssue);
const expectedLiveMini=structuredClone(oldMini),issueIndex=expectedLiveMini.closureIssues.findIndex(i=>i.code==='independent_lists');
assert.equal(issueIndex,liveMini.closureIssues.findIndex(i=>i.code==='independent_lists'));
expectedLiveMini.closureIssues[issueIndex]=producedIssue;assert.deepEqual(liveMini,expectedLiveMini);
assert.deepStrictEqual(selectedBefore.reconciliation.issues[0],producedIssue);
const beforeReportWritten=structuredClone(selectedBefore),beforeReportOmissions=[];
for(const [pointer,live,clone]of [
 ['/selectedBefore/reconciliation/issues/0',selectedBefore.reconciliation.issues[0],beforeReportWritten.reconciliation.issues[0]],
 ['/selectedBefore/brandProgress/0/closureIssues/0',liveMini.closureIssues[0],beforeReportWritten.brandProgress[0].closureIssues[0]],
]){
 assert.deepStrictEqual(live,producedIssue);
 for(const property of ['brand','reference']){assert.deepStrictEqual(Object.getOwnPropertyDescriptor(live,property),Object.getOwnPropertyDescriptor(producedIssue,property));beforeReportOmissions.push(pointer+'/'+property);delete clone[property];}
}
assertDeclaredJson(selectedBefore,'/selectedBefore',new Set(beforeReportOmissions));assert.deepStrictEqual(selectedBefore,selectedBeforeSnapshot);
write('selected-before-report',selectedBefore);assert.deepStrictEqual(readJson(out+'/selected-before-report.json'),beforeReportWritten);assert.deepStrictEqual(beforeReportWritten.brandProgress[0],oldMini);

write('selected-freshness-producer-proof',{reads,actualSelectedFeatureProducers:producerReceipts,before:selectedBefore.ageing,after:selectedAfter.ageing,otherSelectedFeaturesFromAcceptedParity:true});
const peer=(rows,key='carId')=>rows.filter(r=>!selectedIds.has(r[key]));
const deep=(rows,key='carId')=>rows.filter(r=>selectedIds.has(r[key]));
const pct=(n,d)=>d?Math.round(n/d*1000)/10:null;
const expected=structuredClone(baseline);
assert.deepEqual([normal.allCatalogueVersions,normal.tierOneVersions,normal.onSaleVersions],[427,350,309]);
assert.equal(normal.asOf,'2026-10-15');
assert.deepEqual(normal.brandProgress.filter(b=>b.brand!=='MINI'),baseline.brandProgress.filter(b=>b.brand!=='MINI'));
const newMini=selectedAfter.brandProgress.find(b=>b.brand==='MINI');
assert.deepEqual(normal.brandProgress.find(b=>b.brand==='MINI'),newMini);
expected.brandProgress=baseline.brandProgress.map(b=>b.brand==='MINI'?newMini:b);
const beforeSourceIndex=new Map(base.sources.map(source=>[source.id,source])),afterSourceIndex=new Map(afterSources.map(source=>[source.id,source]));
const reasonCounts=(cars,sources,key)=>{
 const sourceIndex=sources===base.sources?beforeSourceIndex:afterSourceIndex;
 const counts=new Map();for(const car of cars){const cell=reports.coreFact(car,key),grade=reports.existingGrade(cell.fact,reports.hasValue(cell.fact?.value),sources,normal.asOf,sourceIndex);
 if(grade!=='Confirmed'){const reason=cell.ungraded?'Drive value exists without a per-fact grade':reports.gradePattern(cell.fact,cell.issue,grade);counts.set(reason,(counts.get(reason)||0)+1);}}
 return counts;
};
const onSaleBefore=completeBefore.filter(reports.isTierOne).filter(reports.isOnSale),onSaleAfter=completeAfter.filter(reports.isTierOne).filter(reports.isOnSale);
assert.equal(onSaleBefore.length,309);assert.equal(onSaleAfter.length,309);
const completeBeforeCore=reports.coreCoverage(onSaleBefore,base.sources,normal.asOf,beforeSourceIndex);
const completeAfterCore=reports.coreCoverage(onSaleAfter,afterSources,normal.asOf,afterSourceIndex);
assert.deepStrictEqual(completeBeforeCore.core,baseline.core);assert.deepStrictEqual(completeBeforeCore.gaps,baseline.gaps);
expected.core=completeAfterCore.core;expected.gaps=completeAfterCore.gaps;
const explanations=[];
for(const [i,old]of baseline.core.entries()){
 const b=selectedBefore.core[i],a=selectedAfter.core[i],next=expected.core[i];assert.equal(old.key,b.key);assert.equal(a.key,b.key);assert.equal(next.key,old.key);
 assert.equal(next.filled,old.filled-b.filled+a.filled);assert.equal(next.total,old.total);
 for(const grade of Object.keys(old.grades))assert.equal(next.grades[grade],old.grades[grade]-b.grades[grade]+a.grades[grade]);
 const beforeReasons=[...reasonCounts(onSaleBefore,base.sources,old.key)],afterReasons=[...reasonCounts(onSaleAfter,afterSources,old.key)];
 explanations.push({key:old.key,beforeFullReasons:beforeReasons,afterFullReasons:afterReasons,beforeExplanation:old.explanation,afterExplanation:next.explanation,producer:'Actual coreCoverage and gradePattern with complete digest-verified cars, source registry and original catalogue order; no truncated-tail inference'});
}
write('global-core-complete-reason-inventory',explanations);
const groupKey=g=>JSON.stringify([g.vehicleClass,g.basis,g.unit]);
// Guarded excerpt of the actual production group comparator; no alternate sorting rule.
const discoveryPath=repo+'/src/lib/discovery.ts',discoverySource=fs.readFileSync(discoveryPath,'utf8');
const groupComparatorText='(a, b) =>\n        b.entries.length - a.entries.length || a.basis.localeCompare(b.basis)';
const groupComparatorContext='.sort(\n      '+groupComparatorText+',\n    );';
assert.equal(discoverySource.split(groupComparatorContext).length,2);
assert(discoverySource.indexOf(groupComparatorContext)>discoverySource.indexOf('export function rankAttribute('));
const groupOrder=vm.runInThisContext('('+groupComparatorText+')',{filename:discoveryPath+':actual-group-order-excerpt'});
const sortingGroup=g=>({...g,entries:Array(g.count)});
function groupSegments(ranking){
 const map=new Map();let offset=0;
 for(const group of ranking.groups){
  assert.deepEqual(Object.keys(group),['vehicleClass','basis','unit','count']);assert(Number.isInteger(group.count)&&group.count>0);
  const key=groupKey(group);assert(!map.has(key));const ids=ranking.rankedIds.slice(offset,offset+group.count);assert.equal(ids.length,group.count);offset+=group.count;
  map.set(key,{group,ids});
 }
 assert.equal(offset,ranking.rankedIds.length);assert.equal(new Set(ranking.rankedIds).size,offset);return map;
}
const stageRankings=readJson('/tmp/mini-packet/full-stage-v2/output/global-ranking-comparison.json');
const rankingGroupProof=[];
function projectedStageGroups(stage,memberIds){
 const members=new Set(memberIds),index=new Map(completeBefore.map((car,i)=>[car.id,i]));assert.equal(members.size,memberIds.length);
 const groups=stage.groups.map(g=>{const ids=g.ids.filter(id=>members.has(id)),[vehicleClass,basis,unit]=JSON.parse(g.key);return{vehicleClass,basis,unit,count:ids.length,ids};}).filter(g=>g.count);
 assert.equal(groups.reduce((sum,g)=>sum+g.count,0),memberIds.length);
 // Buckets are inserted at first matching car in actual catalogue order; stable sort preserves comparator ties.
 groups.sort((a,b)=>Math.min(...a.ids.map(id=>index.get(id)))-Math.min(...b.ids.map(id=>index.get(id))));
 const insertionKeys=groups.map(groupKey);groups.sort((a,b)=>groupOrder(sortingGroup(a),sortingGroup(b)));
 return{groups:groups.map(({ids,...group})=>group),rankedIds:groups.flatMap(g=>g.ids),insertionKeys,segments:groups};
}
expected.rankings=baseline.rankings.map((old,i)=>{
 const actual=normal.rankings[i],b=selectedBefore.rankings[i],a=selectedAfter.rankings[i],stage=stageRankings.find(row=>row.attribute===old.key);assert(stage);
 assert.equal(actual.key,old.key);assert.equal(b.key,old.key);assert.equal(a.key,old.key);
 const oldProjection=projectedStageGroups(stage.before,old.rankedIds);assert.deepStrictEqual(oldProjection.groups,old.groups);assert.deepStrictEqual(oldProjection.rankedIds,old.rankedIds);
 const membership=[...old.rankedIds.filter(id=>!selectedIds.has(id)),...a.rankedIds];
 const projection=projectedStageGroups(stage.after,membership);assert.deepStrictEqual(actual.groups,projection.groups);assert.deepStrictEqual(actual.rankedIds,projection.rankedIds);
 const oldSegments=groupSegments(old),newSegments=groupSegments(actual),selectedBeforeSegments=groupSegments(b),selectedAfterSegments=groupSegments(a),perGroup=[];
 for(const key of new Set([...oldSegments.keys(),...newSegments.keys(),...selectedBeforeSegments.keys(),...selectedAfterSegments.keys()])){
  const oldIds=oldSegments.get(key)?.ids||[],newIds=newSegments.get(key)?.ids||[],beforeIds=selectedBeforeSegments.get(key)?.ids||[],afterIds=selectedAfterSegments.get(key)?.ids||[];
  assert.deepStrictEqual(oldIds.filter(id=>selectedIds.has(id)),beforeIds);assert.deepStrictEqual(newIds.filter(id=>selectedIds.has(id)),afterIds);
  assert.deepStrictEqual(newIds.filter(id=>!selectedIds.has(id)),oldIds.filter(id=>!selectedIds.has(id)));
  assert.equal(newIds.length,oldIds.length-beforeIds.length+afterIds.length);
  perGroup.push({key,peerIds:oldIds.filter(id=>!selectedIds.has(id)),selectedBeforeIds:beforeIds,selectedAfterIds:afterIds,beforeCount:oldIds.length,afterCount:newIds.length});
 }
 assert.deepStrictEqual(peer(actual.excluded),peer(old.excluded));assert.deepStrictEqual(deep(actual.excluded),a.excluded);
 const exclusionReasons={};for(const item of actual.excluded)exclusionReasons[item.reason]=(exclusionReasons[item.reason]||0)+1;
 const ranked=old.ranked-b.ranked+a.ranked;assert.equal(actual.rankedIds.length,ranked);assert.equal(actual.excluded.length,normal.onSaleVersions-ranked);
 rankingGroupProof.push({key:old.key,perGroup,oldOrder:old.groups.map(groupKey),newOrder:projection.groups.map(groupKey),actualProductionGroupComparator:true,insertionKeys:projection.insertionKeys,exactNumericInterleavingFromAcceptedStage:true});
 return{...old,ranked,percent:pct(ranked,normal.onSaleVersions),rankedIds:projection.rankedIds,passes:ranked/normal.onSaleVersions>=0.9,groups:projection.groups,excluded:actual.excluded,exclusionReasons};
});
write('ranking-group-order-and-peer-proof',{sourcePath:discoveryPath,sourceSha256:fileHash(discoveryPath),exactComparatorText:groupComparatorText,groups:rankingGroupProof});
for(const key of ['gaps','summaryGaps']){
 assert.deepEqual(peer(normal[key]),peer(baseline[key]));assert.deepEqual(deep(normal[key]),selectedAfter[key]);
 if(key==='gaps')assert.deepStrictEqual(normal[key],expected.gaps);else expected[key]=normal[key];
}
for(const key of ['missingModels','unresolvedLeads']){
 assert.deepEqual(normal[key].filter(r=>r.brand!=='MINI'),baseline[key].filter(r=>r.brand!=='MINI'));
 assert.deepEqual(normal[key].filter(r=>r.brand==='MINI'),selectedAfter[key]);expected[key]=normal[key];
}
const c1=readJson('/tmp/mini-packet/full-stage-v2/output/global-c1-comparison.json');
assert.deepEqual(baseline.reconciliation,c1.before);expected.reconciliation=c1.after;
expected.pairedOnSale=baseline.pairedOnSale-selectedBefore.pairedOnSale+selectedAfter.pairedOnSale;
expected.pairedOnSalePercent=pct(expected.pairedOnSale,normal.onSaleVersions);
const intersect=rows=>rows[0].rankedIds.filter(id=>rows.every(r=>r.rankedIds.includes(id))).length;
assert.equal(baseline.inAllRankings,intersect(baseline.rankings));expected.inAllRankings=intersect(expected.rankings);expected.inAllRankingsPercent=pct(expected.inAllRankings,normal.onSaleVersions);
const reviewedCoreCells=expected.core.reduce((s,c)=>s+c.reviewed,0),totalCoreCells=normal.onSaleVersions*17;
expected.grading={reviewedCoreCells,totalCoreCells,reviewedPercent:pct(reviewedCoreCells,totalCoreCells)};
expected.gradeNote=baseline.gradeNote.replace(`${baseline.grading.reviewedCoreCells}/${baseline.grading.totalCoreCells}`,`${reviewedCoreCells}/${totalCoreCells}`);
for(const [key,property,negate]of [['brandsResearchCompleted','researchCompleted',false],['brandsResearchRemaining','researchCompleted',true],['brandsDone','done',false],['brandsRemaining','done',true]])expected[key]=expected.brandProgress.filter(b=>negate?!b[property]:b[property]).map(b=>b.brand);
for(const key of ['overdue','invalid','excludedHistory']){
 assert.deepEqual(peer(normal.ageing[key]),peer(baseline.ageing[key]));assert.deepEqual(deep(normal.ageing[key]),selectedAfter.ageing[key]);expected.ageing[key]=normal.ageing[key];
}
expected.ageing.dueNext30Days=baseline.ageing.dueNext30Days-selectedBefore.ageing.dueNext30Days+selectedAfter.ageing.dueNext30Days;
const rc=expected.reconciliation,core=expected.core,ranks=expected.rankings,age=expected.ageing;
expected.criteria=[
 {id:'C1',pass:rc.pass,detail:`${rc.reviewedModels} exact current model lists reviewed; ${rc.settledListEntryCount}/${rc.listEntryCount} entries settled across ${rc.independentListCount} independent lists; ${rc.issues.length} blockers. ${expected.missingModels.length} unmatched audit models; ${expected.unresolvedLeads.length} unresolved leads.`,sources:baseline.criteria[0].sources},
 {id:'C2',pass:core.every(c=>c.passes),detail:`${core.filter(c=>c.passes).length}/${core.length} core fields meet their target; ${expected.gaps.length} version/field gaps, each with a reason in --details or --json.`},
 {id:'C3',pass:core.every(c=>c.gradingPasses&&(c.confirmedPercent>=50||!!c.explanation)),detail:`${reviewedCoreCells}/${totalCoreCells} core cells have earned reviews; ${core.filter(c=>c.confirmedPercent!==null&&c.confirmedPercent<50).length} fields below half Confirmed have patterns in --details. No grade quota is applied.`},
 {id:'C4',pass:expected.tierOneVersions>0&&expected.summaryGaps.length===0,detail:`${expected.tierOneVersions-expected.summaryGaps.length}/${expected.tierOneVersions} Tier 1 versions have both a supported strength and trade-off (${expected.pairedOnSale}/${normal.onSaleVersions} on sale).`},
 {id:'C5',pass:ranks.every(r=>r.passes),detail:`${ranks.filter(r=>r.passes).length}/6 ranking lists reach 90% of on-sale Tier 1 versions; measurement groups stay separate.`},
 {id:'C6',pass:age.overdue.length===0&&age.invalid.length===0,detail:`${age.overdue.length} aged claims and ${age.invalid.length} invalid/future/undated claims across all Tier 1 versions, including availability and equipment. Model-year changes still require a recorded review.`}
];
write('expected-versus-normal-diff',differences(expected,normal));
assert.deepEqual(normal,expected,'Every report leaf must equal the explicitly accounted expectation; no ignored global/peer fields');
assertDeclaredJson(completeBefore,'/completeBefore',new Set());assert.deepStrictEqual(carDigests(completeBefore),acceptedStageDigests.candidate26);assertDeclaredJson(completeAfter,'/completeAfter',new Set());assert.deepStrictEqual(carDigests(completeAfter),acceptedStageDigests.candidate27);
assertDeclaredJson(base.sources,'/beforeSources',new Set());assertDeclaredJson(afterSources,'/afterSources',new Set());assert.deepStrictEqual(digestRows(afterSources),readJson('/tmp/mini-packet/full-stage-v2/output/research-field-digests.json').candidate27.sources);assert.deepStrictEqual(digestRows(base.sources),beforeSourceSnapshot);assert.deepStrictEqual(base,baseSnapshot);assert.deepStrictEqual(packet,packetSnapshot);
assert.deepStrictEqual(before,selectedSnapshots.before);assert.deepStrictEqual(after,selectedSnapshots.after);assert.deepStrictEqual(packs,selectedSnapshots.packs);assert.deepStrictEqual(selectedResult,selectedSnapshots.result);assert.deepStrictEqual(beforeFeatures,beforeFeatureSnapshot);assert.deepStrictEqual(selectedBefore,selectedBeforeSnapshot);assert.equal(defaultCalls,0);
for(const path of ['src/lib/data.ts','src/lib/catalogue.ts','src/lib/research.ts'])assert(!require.cache[repo+'/'+path]);
fs.writeFileSync(out+'/normal-coverage-formatted.txt',reports.formatCoverageReport(normal)+'\n',{flag:'wx'});
write('result',{passed:true,normalReportSha256:fileHash(normalPath),baselineSha256:fileHash(baselinePath),exhaustiveDifferences:differences(baseline,normal).length,allNormalLeavesAccounted:true,peerBrandObjectsExact:normal.brandProgress.filter(b=>b.brand!=='MINI').length,peerRankRelativeOrderWithinMeasurementGroupsExact:true,groupOrderEqualsActualProducer:true,peerCompleteCarDigestsExact:417,globalC1EqualsAcceptedStage:true,ordinaryProductionReportRanSeparately:true,normalReportSubstituted:false,selectedOldFeatureProducers:690,peerFeaturesReplayed:0,completeCoreReasonInventory:true,broadFeatureReplay:false,defaultLoaderCalls:0,selectedFreshnessBefore:selectedBefore.ageing,selectedFreshnessAfter:selectedAfter.ageing,counts:{catalogue:427,tierOne:350,onSale:309}});
console.log(JSON.stringify({passed:true,result:out+'/result.json',sha256:fileHash(out+'/result.json')}));
