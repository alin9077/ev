# MINI post-registration checks v1: prepared commands only

No validation command, project parser, compiler, test, wrapper, normal report, build or generated-type refresh has run in this preparation. No live source has been edited. Registration is a separate action. These commands are not ready to execute until the exact independent review, accepted registration readback and root execution grant exist.

## Scope and order

1. Market view: existing `scripts/generate-market-view.mjs --check`, 128 MiB old-space, 1 MiB semi-space, 60 seconds
2. Changed-file lint: only `scripts/reporting/load.ts`, the sole changed TS/JS file, existing flat config, no cache, no fixes, no warnings, 256/1 MiB and 180 seconds
3. Behavioral suites: the accepted ten explicit files, 144 named tests, single test concurrency, TAP, 512/1 MiB and 600 seconds
4. Live brand safety: existing seven named tests, single test concurrency, 512/1 MiB and 600 seconds
5. Structural validation: existing `scripts/validate.ts`, 448/1 MiB and 900 seconds
6. Genuine cold full-project TypeScript: dedicated sibling manifest/wrapper under `../full-project-typescript-v1`, 768/1 MiB and 900 seconds

Every process has a 10-second TERM-to-KILL grace and a supervisor watchdog 20 seconds past its main timeout. V8 flags are not an OS RSS cap. One process at a time, explicit exclusive heavy-slot grant, shared nonblocking lock, no retry, no resource escalation and fresh create-only output directories. Stop on any failure. One gate being green does not authorize the next gate.

The normal coverage report and saved-report comparator are deliberately not in this deliverable. Their owner must arrange them separately, after these required gates. No earlier Deepal pass can substitute for a fresh MINI gate.

## Frozen registration and source immutability

The only registration paths are:
- `data/m1-brand-updates/registry.json`, preserving the first 26 entries and appending `mini-2026-10-15.json` as entry 27
- `scripts/reporting/load.ts`, adding `miniReconciliation` import and final combine argument
- `data/m1-brand-updates/mini-2026-10-15.json`
- `data/m1-mini-market-reconciliation-2026-10-15.json`

The input pins use exact proposed after bytes/hashes for these four live paths and separately pin their prepared after copies and final registration manifest. Unchanged named source/data/compiler/runtime inputs retain the accepted Deepal content or metadata pins. All 361 original configured root names stay fixed. Every unchanged root stat stays exact; only load.ts's preparation-time stat is replaced by an explicitly bounded registration transition. Its exact expected content is still mandatory. All four registration targets must be ordinary real files; the wrappers record their actual post-registration stats before each command and demand identical stats after it. No wildcard stat exception or filesystem copy is used.

Structural expectation: 427 variants, 170 families, 193 generations, 69 criteria, 29,463 evidence rows, 348 current, 43 outgoing, 36 provisional; 3,753 source references; 15 publication issues; zero approved external assets; exact immutable-research hash. The selected stage's source addition is 46 over Deepal's 3,707. Coverage counts remain a separate report gate, expected 427 catalogue / 350 Tier 1 / 309 on sale.

## Exact review and grant contracts

`root-grant-template.json` is NOT a grant. Root must write a separate receipt with status `root_execution_granted`, `heavySlotExclusive: true`, `automaticRetry: false`, `parallelExecutionAllowed: false`, exact granted manifest path/hash entries, and valid content pins for `sequence`, `reviewerAcceptance`, and `registrationVerification`.

The reviewerAcceptance file must have:
- `status: "accepted"`
- `sequence: {path, sha256}` matching this exact sequence
- `wrapper: {path, sha256}` matching this exact generic wrapper

The registrationVerification file must have:
- `status: "accepted"`
- `manifestSha256` matching the frozen MINI registration manifest
- `allFourLiveHashesAndBytesMatchAcceptedPayloads: true`
- `applicationReceipt: {path, bytes, sha256}`

The pinned application receipt must itself have `passed: true` and matching `manifestSha256`. These fields are required for both this wrapper and the dedicated TypeScript wrapper. Receipt preparation cannot stand in for independently checked live registration.

For an authorized generic gate only:
`python run.py MANIFEST_PATH MANIFEST_SHA256 ROOT_GRANT_PATH ROOT_GRANT_SHA256`

Do not call that command during preparation. Each gate's exact command is in its own JSON manifest. The sequence pins the five manifests and then the dedicated TypeScript manifest. That sixth gate requires its own exact review/grant and all five fresh preceding outcomes accepted with manifest/result/terminal pins.

## Retained accepted patterns and claim limits

The generic wrapper derives from accepted Deepal post-registration v3. The exact patch is retained. Changes bind MINI registration, exact post-registration stats, original configured roots/runtime metadata, shared lock, and source-reference/immutable-research assertions. Command supervision, resource receipts, stream hashes, TAP names/counts, no-write market output, lint output inspection, before/after pins and create-only outputs retain the accepted pattern.

The 144-test inventory is carried only after verifying every test source hash unchanged. No checkpoint-byte tests, helper edits, broad all-tests run, full effective-feature replay, browser work, server, install, archive work, publication or user-computer access is added. The ordinary existing structural command does execute its normal catalogue-wide integrity work when later authorized; preparation has not executed it.

Only the explicit runtime result and independent review can establish a pass. Preparation, a syntax glance or an older passing run cannot.
