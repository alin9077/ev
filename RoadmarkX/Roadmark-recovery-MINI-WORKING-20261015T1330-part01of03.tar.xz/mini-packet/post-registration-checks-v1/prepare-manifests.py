"""Static-hash preparation only. No project parser, test, compiler or wrapper execution."""
from pathlib import Path
from datetime import datetime, timezone
import copy, hashlib, json
R=Path('/workspace/scratch/586427eef9f2/roadmark-104')
B=Path('/tmp/mini-packet/post-registration-checks-v1')
T=Path('/tmp/mini-packet/full-project-typescript-v1')
O=Path('/tmp/deepal-packet/post-registration-checks-v3')
OT=Path('/tmp/deepal-packet/full-project-typescript-v2')
A=Path('/tmp/mini-packet/registration-v1')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while x:=f.read(1024*1024):h.update(x)
 return h.hexdigest()
def pin(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def verify(p):
 actual=pin(p['path']);assert all(actual[k]==v for k,v in p.items() if k!='realpath'),p['path']
 if 'realpath' in p:assert str(Path(p['path']).resolve())==p['realpath']
 return actual
def write(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def meta(p):
 p=Path(p)
 if not p.exists():return dict(path=str(p),exists=False)
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
reg=json.loads((A/'manifest.json').read_text())
writes=json.loads((A/'prepared-writes.json').read_text())
assert reg['writes']==writes
expected=['data/m1-brand-updates/registry.json','scripts/reporting/load.ts','data/m1-brand-updates/mini-2026-10-15.json','data/m1-mini-market-reconciliation-2026-10-15.json']
assert [w['relativePath'] for w in writes]==expected
transitions=[]
for w in writes:
 assert Path(w['target'])==R/w['relativePath']
 verify(w['after'])
 if w['before'] is None:assert not Path(w['target']).exists()
 else:assert pin(w['target'])==dict(path=w['target'],**w['before']);verify(w['beforeCopy'])
 transitions.append(dict(path=w['target'],bytes=w['after']['bytes'],sha256=w['after']['sha256']))
oldregistry=json.loads((R/'data/m1-brand-updates/registry.json').read_text())
newregistry=json.loads((A/'after/data/m1-brand-updates/registry.json').read_text())
assert newregistry['schemaVersion']==oldregistry['schemaVersion']==1
assert newregistry['packets'][:-1]==oldregistry['packets'] and len(newregistry['packets'])==27 and newregistry['packets'][-1]=='mini-2026-10-15.json'
assert set(newregistry)==set(oldregistry)=={'schemaVersion','packets'}
config=json.loads((R/'tsconfig.json').read_text())
oldts=json.loads((OT/'manifest.json').read_text())
assert config==oldts['originalConfig']
for v in oldts['runtimeMetadata']:assert meta(v['path'])==v
scope=json.loads((OT/'project-root-metadata.json').read_text())
rootpaths=sorted({str(p.resolve()) for pat in config['include'] for p in R.glob(pat) if p.is_file()})
assert rootpaths==scope['configuredRootFilePaths'] and len(rootpaths)==361
for v in scope['fileMetadata']+scope['directoryState']:assert meta(v['path'])==v
load=str(R/'scripts/reporting/load.ts')
removed=[v for v in scope['fileMetadata'] if v['path']==load];assert len(removed)==1
scope['fileMetadata']=[v for v in scope['fileMetadata'] if v['path']!=load]
scope['status']='pre_registration_metadata_frozen_no_compiler_invocation'
scope['method']='Exact configured root names and unchanged root stats retained from accepted Deepal v2. Only load.ts has an explicit expected-byte registration transition.'
scope['registrationStatTransitions']=[dict(before=removed[0],expectedAfter=next(p for p in transitions if p['path']==load),runtimeContract='Bind exact after bytes and SHA; capture live post-registration stat before command and require identical stat after command')]
scope['note']='Full original 361-root compiler scope is unchanged. Only load.ts is removed from preparation-time stat equality because registration replaces it. Every unchanged root stat remains exact. All four live registration targets are content-pinned and receive exact per-command pre/post stat guards. No source is replaced, generated or excluded from TypeScript.'
write(T/'project-root-metadata.json',scope)
pins={}
for file in [O/'source-pins.json',OT/'input-pins.json']:
 for p in json.loads(file.read_text()):
  actual=verify(p)
  if actual['path'] in pins:assert pins[actual['path']]==actual
  pins[actual['path']]=actual
for p in transitions:pins[p['path']]=p
for w in writes:
 p=pin(w['after']['path']);pins[p['path']]=p
for pth in [A/'prepared-writes.json',A/'manifest.json',R/'eslint.config.mjs',(R/'node_modules/eslint/bin/eslint.js').resolve()]:
 p=pin(pth);pins[p['path']]=p
ordered=[pins[k] for k in sorted(pins)]
write(B/'source-pins.json',ordered)
write(T/'input-pins.json',ordered)
inventory=json.loads((O/'test-inventory.json').read_text())
for p in inventory.values():verify(p['source'])
write(B/'test-inventory.json',inventory)
node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
base=lambda heap:[node,'--max-old-space-size='+str(heap),'--max-semi-space-size=1']
lock=str(B/'.exclusive-heavy.lock')
common=dict(status='frozen_not_executed_requires_review_and_root_grant',repo=str(R),qaRoot=str(B/'run'),exclusiveLock=lock,killAfterSeconds=10,automaticRetry=False,parallelExecutionAllowed=False,sourceMutationsAuthorized=False,sourcePins=pin(B/'source-pins.json'),rootMetadata=pin(T/'project-root-metadata.json'),testInventory=pin(B/'test-inventory.json'),wrapper=pin(B/'run.py'),registrationManifest=pin(A/'manifest.json'),registrationTargets=transitions,originalConfig=config,runtimeMetadata=oldts['runtimeMetadata'],environmentRemovals=oldts['environmentRemovals'],environmentOverrides={'NODE_DISABLE_COMPILE_CACHE':'1','FORCE_COLOR':'0','ESLINT_USE_FLAT_CONFIG':'true'})
behavior=json.loads((O/'behavioural-suites.json').read_text())['testFiles'];live=['tests/brand-live-safety.test.ts']
assert sum(inventory[p]['count'] for p in behavior)==144 and inventory[live[0]]['count']==7
eslint=str((R/'node_modules/eslint/bin/eslint.js').resolve())
configs=[
 dict(id='market-view',kind='market',command=base(128)+['scripts/generate-market-view.mjs','--check'],timeoutSeconds=60),
 dict(id='changed-file-lint',kind='lint',command=base(256)+[eslint,'--no-config-lookup','--config',str(R/'eslint.config.mjs'),'--no-ignore','--no-cache','--concurrency','off','--max-warnings','0','--format','json','--','scripts/reporting/load.ts'],timeoutSeconds=180,lintFiles=['scripts/reporting/load.ts']),
 dict(id='behavioural-suites',kind='tests',command=base(512)+['--import','tsx','--test','--test-reporter=tap','--test-concurrency=1',*behavior],timeoutSeconds=600,testFiles=behavior,expectedTests=144),
 dict(id='live-brand-safety',kind='tests',command=base(512)+['--import','tsx','--test','--test-reporter=tap','--test-concurrency=1',*live],timeoutSeconds=600,testFiles=live,expectedTests=7),
 dict(id='structural-validation',kind='structural',command=base(448)+['--import','tsx','scripts/validate.ts'],timeoutSeconds=900,expectedStructuralCounts={'variants':427,'families':170,'generations':193,'criteria':69,'evidence':29463,'current':348,'outgoing':43,'provisional':36},expectedSourceReferences=3753,expectedPublicationIssues=15,expectedApprovedExternalAssets=0,immutableResearchSha256='010ded194b4d61cd7be606ce0cc332fa7e32906bba70abff2b5c38541e634657'),
]
sequence=[];previous=None
for c in configs:
 m={**common,**c,'runOutput':str(B/'run'/c['id']),'prerequisites':[] if previous is None else [previous],'extraPins':[]}
 write(B/(c['id']+'.json'),m)
 p=pin(B/(c['id']+'.json'));sequence.append(p);previous=dict(manifest=p,resultPath=str(B/'run'/c['id']/'result.json'))
# Preserve full-project configuration, installed compiler/runtime pins and accepted envelope.
m=copy.deepcopy(oldts)
for k in ['preparer','priorAttempts','metadataDelta','deepalApplication','fixtureCorrection','requiredFocusedCorrectionChecks','focusedCorrectionManifests','focusedCorrectionSequence','focusedCorrectionVerificationContract','supersededPreparation']:m.pop(k,None)
m.update(id='mini-cold-full-project-typescript-768-v1',preparedAt=datetime.now(timezone.utc).isoformat(),wrapper=pin(T/'run.py'),inputPins=pin(T/'input-pins.json'),projectRootMetadata=pin(T/'project-root-metadata.json'),miniApplication={'manifest':pin(A/'manifest.json')},registrationTargets=transitions,exclusiveLock=lock,precedingCheckManifests=sequence.copy())
m['command'][-1]=str(T/'run/full-project.tsbuildinfo')
m['cacheHandling']['newCachePath']=m['command'][-1]
m['scopePreservation']['compilerOptionOverrides']['tsBuildInfoFile']=m['command'][-1]
m['allowedWrites']=[str(T/'run')+'/**',lock]
m['timeoutRationale']='Reuse accepted Deepal v2 successful 768/1 MiB envelope: 26.374 seconds and 878716 KiB wait4 maximum RSS. This is precedent, not a MINI success or OS-memory guarantee. One 900-second attempt, 10-second kill grace, 920-second watchdog, exclusive root-granted heavy slot; no retry or escalation.'
m['approvedFinalDataContext']={'catalogueVersions':427,'tierOneVersions':350,'onSaleVersions':309,'packets':27}
m['claimLimits']=['Cold full-project tsc check using original config, not literal package script and not Next build','Existing skipLibCheck and every configured checking option preserved','All prior failed attempts and passing Deepal precedent remain history; none is a MINI pass','Preparation is command-only and no runtime gate has run','361 configured root names unchanged; 360 exact preparation-time root stats plus exact load.ts content transition and per-command stat capture']
m['preparationVerification']='Static JSON reading, metadata and SHA collection only. No wrapper execution, project parser, compiler, Node, test, build or generated-type refresh.'
m['runtimeVersionProvenance']='Retained accepted Deepal v2 versions; unchanged installed package content pins and runtime stat records verified without invocation.'
m['executionConditions']=['Exact independent manifest/wrapper readiness acceptance','Applied four-file registration independently accepted with exact manifest hash and pinned successful application receipt','All five fresh MINI preceding gates accepted with exact manifest/result/terminal pins in order','Exact root grant plus exclusive heavy slot and shared nonblocking lock','New create-only output directory/cache; only one attempt and no source writes','No source/helper/test edits, dependency install, type generation, scope override, stale cache seeding or resource escalation']
m['precedingCheckVerificationContract']['applicationManifestSha256']=m['miniApplication']['manifest']['sha256']
m['precedingCheckVerificationContract']['checks']='Exactly requiredPrecedingChecks in order, with exact precedingCheckManifests pins; passed=true, exitCode=0; pin and inspect each manifest/result/terminal. Behavioural count must remain 144.'
m['applicationVerificationContract']={'status':'accepted','manifestSha256':m['miniApplication']['manifest']['sha256'],'allFourLiveHashesAndBytesMatchAcceptedPayloads':True,'applicationReceipt':'Exact path, bytes and SHA-256 pin; receipt passed=true and manifestSha256 matches'}
m['sourceMetadataContract']=scope['note']
write(T/'manifest.json',m)
sequence.append(pin(T/'manifest.json'))
write(B/'sequence.json',dict(status='frozen_not_executed_requires_review_and_root_grant',sequence=sequence,sourcePins=common['sourcePins'],rootMetadata=common['rootMetadata'],qaRoot=str(B/'run'),registrationManifest=pin(A/'manifest.json'),registrationTargets=transitions,fullProjectTypeScriptManifest=pin(T/'manifest.json'),typeScriptUsesDedicatedWrapper=True,priorFiveGateAcceptanceRequiredBeforeTypeScript=True,noAutomaticRetry=True,normalReportAndComparatorIncluded=False,executionAuthorized=False))
write(B/'root-grant-template.json',dict(status='NOT_GRANTED',heavySlotExclusive=False,automaticRetry=False,parallelExecutionAllowed=False,granted=[],sequence=pin(B/'sequence.json'),reviewerAcceptance=None,registrationVerification=None))
g=dict(status='TEMPLATE_NOT_A_GRANT',manifest={'path':str(T/'manifest.json'),'sha256':sha(T/'manifest.json')},wrapper=m['wrapper'],reviewerReadinessConfirmed=False,reviewerAcceptance=None,miniApplicationAccepted=False,applicationVerification=None,precedingChecksAccepted=False,precedingCheckVerification=None,heavySlotExclusive=False,automaticRetry=False,parallelExecutionAllowed=False,maximumAttempts=1,coldCacheRelocationApproved=False,instruction='Template only. Independent readiness, four-file registration readback, all five exact fresh MINI preceding checks, and exact root execution grant are required. No execution, retries or escalation authorized by preparation.')
write(T/'root-grant-template.json',g)
write(B/'preparation-status.json',dict(status='prepared_not_executed',sequence=pin(B/'sequence.json'),wrapper=pin(B/'run.py'),sourcePinCount=len(ordered),configuredRootCount=361,unchangedRootStatCount=360,onlyRootStatTransition=load,testCount=144,liveSafetyTestCount=7,registrationManifest=pin(A/'manifest.json'),projectParsersRun=False,testsRun=False,compilerRun=False,wrappersRun=False,sourceEdits=False))
for p in [B/'run',T/'run']:assert not p.exists()
for v in scope['fileMetadata']+scope['directoryState']+[removed[0]]:assert meta(v['path'])==v
for w in writes:
 if w['before'] is None:assert not Path(w['target']).exists()
 else:assert pin(w['target'])==dict(path=w['target'],**w['before'])
print(json.dumps({'sequence':pin(B/'sequence.json'),'typescriptManifest':pin(T/'manifest.json'),'sourcePinCount':len(ordered),'executed':False},indent=2))
