"""Preparation only. Adapt accepted wrappers; does not run or parse them."""
from pathlib import Path
import difflib
B=Path('/tmp/mini-packet/post-registration-checks-v1')
T=Path('/tmp/mini-packet/full-project-typescript-v1')
OLD=Path('/tmp/deepal-packet/post-registration-checks-v3/run.py')
OLDT=Path('/tmp/deepal-packet/full-project-typescript-v2/run.py')
def save(p,s):
 with p.open('x') as f:f.write(s)
def replace(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
s=OLD.read_text()
s=replace(s,"assert r['sourceReferences']==3707 and r['publicationIssues']==15", "assert r['sourceReferences']==m['expectedSourceReferences'] and r['publicationIssues']==m['expectedPublicationIssues']")
s=replace(s,"allpins=[m['wrapper'],m['sourcePins'],m['rootMetadata'],m['testInventory'],*pins,*m['extraPins'],g['sequence'],g['reviewerAcceptance'],g['registrationVerification']]", "allpins=[m['wrapper'],m['sourcePins'],m['rootMetadata'],m['testInventory'],m['registrationManifest'],*pins,*m['extraPins'],g['sequence'],g['reviewerAcceptance'],g['registrationVerification']]\nregistration_metadata = None")
s=replace(s,"def check_all():\n", "def check_all():\n global registration_metadata\n")
s=replace(s," for expected in metadata['fileMetadata']+metadata['directoryState']:assert meta(expected['path'])==expected,expected['path']", """ for expected in metadata['fileMetadata']+metadata['directoryState']:assert meta(expected['path'])==expected,expected['path']
 repo=Path(m['repo'])
 config=json.loads((repo/'tsconfig.json').read_text())
 roots=sorted({str(p.resolve()) for pattern in config['include'] for p in repo.glob(pattern) if p.is_file()})
 assert config==m['originalConfig'] and roots==metadata['configuredRootFilePaths']
 review=json.loads(Path(g['registrationVerification']['path']).read_text())
 assert review['status']=='accepted' and review['manifestSha256']==m['registrationManifest']['sha256']
 assert review['allFourLiveHashesAndBytesMatchAcceptedPayloads'] is True
 check(review['applicationReceipt'])
 application=json.loads(Path(review['applicationReceipt']['path']).read_text())
 assert application['passed'] is True and application['manifestSha256']==m['registrationManifest']['sha256']
 readiness=json.loads(Path(g['reviewerAcceptance']['path']).read_text())
 assert readiness['status']=='accepted' and readiness['sequence']['path']==g['sequence']['path'] and readiness['sequence']['sha256']==g['sequence']['sha256']
 assert readiness['wrapper']['path']==m['wrapper']['path'] and readiness['wrapper']['sha256']==m['wrapper']['sha256']
 current=[meta(p['path']) for p in m['registrationTargets']]
 for target,actual in zip(m['registrationTargets'],current):
  check(target)
  assert actual['exists'] and actual['realpath']==target['path'] and not actual['isSymlink'] and not actual['isDirectory']
 if registration_metadata is None:registration_metadata=current
 else:assert current==registration_metadata,'Registration-target metadata changed during gate'
""")
s=replace(s,"lock=(base/'.sequential-check.lock').open('a+');fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)", "lock=Path(m['exclusiveLock']).open('a+');fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)")
s=replace(s,"env=os.environ.copy()", "write('registration-target-metadata-before.json',registration_metadata)\nenv=os.environ.copy()")
s=replace(s,"sourceScopeUnchanged=True", "sourceScopeUnchanged=True,registrationTargetMetadataUnchanged=True")
s=replace(s," r=json.loads(stdout);assert r['result']=='PASS';assert r['counts']==m['expectedStructuralCounts'];assert r['sourceReferences']==m['expectedSourceReferences'] and r['publicationIssues']==m['expectedPublicationIssues']", " r=json.loads(stdout);assert r['result']=='PASS';assert r['counts']==m['expectedStructuralCounts'];assert r['sourceReferences']==m['expectedSourceReferences'] and r['publicationIssues']==m['expectedPublicationIssues'];assert r['sha256']==m['immutableResearchSha256'] and r['approvedExternalAssets']==m['expectedApprovedExternalAssets']")
s=replace(s,"metadata['fileMetadata']+metadata['directoryState']","metadata['fileMetadata']+metadata['directoryState']+m['runtimeMetadata']")
save(B/'run.py',s)
save(B/'accepted-wrapper-to-mini.patch',''.join(difflib.unified_diff(OLD.read_text().splitlines(True),s.splitlines(True),fromfile=str(OLD),tofile=str(B/'run.py'))))
s=OLDT.read_text().replace('/tmp/deepal-packet/full-project-typescript-v2',str(T)).replace('deepalApplication','miniApplication').replace('Deepal','MINI')
s=replace(s,'import hashlib\n','import hashlib\nimport fcntl\n')
s=replace(s,"assert g['applicationVerification'] == m['miniApplication']['independentReadbackReview']\n",'')
s=replace(s,"assert g['focusedCorrectionChecksAccepted'] is True\ncheck(g['focusedCorrectionVerification'])\n",'')
s=replace(s,"    application = json.loads(Path(m['miniApplication']['result']['path']).read_text())", "    check(m['miniApplication']['manifest'])\n    review = json.loads(Path(g['applicationVerification']['path']).read_text())\n    assert review['status'] == 'accepted'\n    check(review['applicationReceipt'])\n    application = json.loads(Path(review['applicationReceipt']['path']).read_text())")
s=replace(s,"    assert review['allSevenLiveHashesAndBytesMatchAcceptedPayloads'] is True", "    assert review['allFourLiveHashesAndBytesMatchAcceptedPayloads'] is True")
s=replace(s,"    assert review['applicationReceiptSha256'] == m['miniApplication']['result']['sha256']\n",'')
a=s.index("    focused = json.loads(");b=s.index('def check_inputs():',a);s=s[:a]+s[b:]
s=replace(s,"def check_inputs():\n", "registration_metadata = None\n\ndef check_inputs():\n    global registration_metadata\n")
s=replace(s,"g['applicationVerification'], g['focusedCorrectionVerification'], *pins", "g['applicationVerification'], m['miniApplication']['manifest'], *pins")
s=replace(s,"        assert meta(expected['path']) == expected, expected['path']\n", """        assert meta(expected['path']) == expected, expected['path']
    current = [meta(p['path']) for p in m['registrationTargets']]
    for target, actual in zip(m['registrationTargets'], current):
        check(target)
        assert actual['exists'] and actual['realpath'] == target['path'] and not actual['isSymlink'] and not actual['isDirectory']
    if registration_metadata is None:
        registration_metadata = current
    else:
        assert current == registration_metadata, 'Registration-target metadata changed during compiler attempt'
""")
s=replace(s,"out = BASE / 'run'\nout.mkdir", "lock = Path(m['exclusiveLock']).open('a+')\nfcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)\nout = BASE / 'run'\nout.mkdir")
s=replace(s,"env = os.environ.copy()", "write('registration-target-metadata-before.json', registration_metadata)\nenv = os.environ.copy()")
s=replace(s,"        assert c['passed'] is True and c['exitCode'] == 0", "        assert c['manifest'] == m['precedingCheckManifests'][expected.index(c['name'])]\n        assert c['passed'] is True and c['exitCode'] == 0")
save(T/'run.py',s)
save(T/'accepted-wrapper-to-mini.patch',''.join(difflib.unified_diff(OLDT.read_text().splitlines(True),s.splitlines(True),fromfile=str(OLDT),tofile=str(T/'run.py'))))
print('Prepared wrapper text and exact review patches only; neither wrapper parsed or executed.')
