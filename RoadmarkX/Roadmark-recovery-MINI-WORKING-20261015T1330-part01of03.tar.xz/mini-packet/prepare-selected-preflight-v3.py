from pathlib import Path
import json,hashlib,difflib
from datetime import datetime,timezone
A=Path('/tmp/mini-packet/selected-preflight-v2');O=Path('/tmp/mini-packet/selected-preflight-v3');P=Path('/tmp/mini-packet');R=Path('/tmp/mini-research');REPO=Path('/workspace/scratch/586427eef9f2/roadmark-104')
O.mkdir(exist_ok=True);assert not list(O.iterdir())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def write(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False);f.write('\n')
def replace_once(text,a,b):
 assert text.count(a)==1,(text.count(a),a[:100]);return text.replace(a,b)
old=json.loads((P/'mini-market-reconciliation-v2.json').read_text());new=json.loads(json.dumps(old))
review=next(r for r in new['currentVersionReviews'] if r['modelId']=='mini_countryman_u25_bev')
assert 'publishedModelAliases' not in review
alias={'name':'Countryman','reason':'Checked 2026-10-15. The current official Australian U25 BEV brochure, published July 2026 for production from July 2026, titles this battery-electric SUV family All-Electric MINI Countryman and names Countryman E Classic, E Favoured, SE ALL4 Classic, SE ALL4 Favoured and SE ALL4 JCW Sport. Those five grades are the inherited mini-countryman BEV record and the five retained mini_countryman_u25_bev versions whose catalogue model label is Countryman Electric. This naming equivalence is limited to that current Australian BEV family and those five reviewed identities; it does not include petrol Countryman, future Untamed or residual E Core, and does not establish physical stock or accepted orders.','sourceUrls':review['officialSourceUrls']}
review['publishedModelAliases']=[alias]
assert json.loads((P/'mini-market-reconciliation-v3.json').read_text())==new  # Preserved exact output from interrupted static preparation
probe=json.loads(json.dumps(new));del next(r for r in probe['currentVersionReviews'] if r['modelId']=='mini_countryman_u25_bev')['publishedModelAliases'];assert probe==old
invpath=REPO/'data/market-inventory-2026-10-10.json';allinv=json.loads(invpath.read_text());records=[r for r in allinv['records'] if isinstance(r.get('brand'),str) and r['brand'].upper()=='MINI'];leads=[r for r in allinv['unverifiedLeads'] if isinstance(r.get('brand'),str) and r['brand'].upper()=='MINI'];assert len(records)==3 and not leads
write(O/'inventory-resolution-review.json',{'checkedAt':'2026-10-15','originalInventory':pin(invpath),'records':records,'unverifiedLeads':leads,'expectedSettlement':['record:mini-cooper','record:mini-aceman','record:mini-countryman'],'currentVersionReviewIds':[r['id'] for r in new['currentVersionReviews']],'countrymanReviewId':review['id'],'countrymanAlias':alias,'countrymanVersionIds':[v['carId'] for v in review['versions']],'scope':'All three original Tier 1 MINI records remain required inventory dispositions; current-list coverage independently remains three models and ten exact identities. The full records are exact source JSON copies, not normalized or replaced.'})
audit={'status':'source_bound_alias_correction_only_not_executed','checkedAt':'2026-10-15','failedRun':{'manifest':pin(A/'prepared-command.json'),'terminal':pin(A/'run/terminal.json'),'stderr':pin(A/'run/stderr.log'),'afterPins':pin(A/'run/after-pins.json')},'diagnosis':'The inherited passenger record mini-countryman has model Countryman with an empty modelAliases array. Its current version review uses the retained catalogue label Countryman Electric. modelNameMatches accepts structured source-bound publishedModelAliases but does not inspect prose notes. The absent alias caused an inventory_unresolved result; Countryman must remain in the required settlement set.','producer':{'path':str(REPO/'scripts/reporting/m1-reconciliation.ts'),'matchingLines':'176–190 and 684–709','inventoryFilterLines':'501–509','helperChange':False},'alias':alias,'support':[{'capture':pin(R/'sources/mini_countryman_current_pdf.pdf'),'text':pin(R/'sources/mini_countryman_current_pdf.txt'),'provenance':pin(R/'sources/mini_countryman_current_pdf-provenance.json'),'pages':[1,3,4,6,7,9,10,11,13],'supports':'All-Electric MINI Countryman family naming; five E/SE ALL4 grades; July 2026 publication and production scope.'},{'capture':pin(R/'sources/countryman.txt'),'provenance':pin(R/'sources/countryman-provenance.json'),'supports':'Official Australian all-electric Countryman model page, including Countryman SE ALL4 in Favoured Trim. The page separately links petrol Countryman; no petrol identity is brought into this review.'}],'candidateUnchanged':pin(P/'mini-2026-10-15-candidate-v2.json'),'reconciliationBefore':pin(P/'mini-market-reconciliation-v2.json'),'reconciliationAfter':pin(P/'mini-market-reconciliation-v3.json'),'inventoryReview':pin(O/'inventory-resolution-review.json'),'noRetryExecuted':True}
write(R/'countryman-alias-audit-v1.json',audit)
manifest=json.loads((R/'research-manifest-v4.json').read_text());manifest['status']='Bounded source candidate v2 remains unchanged; reconciliation v3 adds only the official-source-bound Countryman naming alias after the preserved selected v2 failure. Alias/source correction awaits independent review. No live integration.';manifest['nextGate']='Review source-bound reconciliation alias and refrozen selected preflight; execution requires a new explicit root grant and exclusive heavy slot. No automatic retry or live registration.'
for a in manifest['supportingArtifacts']:
 if a['path']==str(P/'mini-market-reconciliation-v2.json'):a.update(path=str(P/'mini-market-reconciliation-v3.json'),sha256=sha(P/'mini-market-reconciliation-v3.json'))
manifest['supportingArtifacts'].append(pin(R/'countryman-alias-audit-v1.json'));write(R/'research-manifest-v5.json',manifest)
s=(A/'check.mjs').read_text().replace(str(A),str(O)).replace('mini-market-reconciliation-v2.json','mini-market-reconciliation-v3.json')
s=replace_once(s,"assert.equal(inventory.records.length,3);assert.equal(inventory.unverifiedLeads.length,0);", """assert.equal(inventory.records.length,3);assert.equal(inventory.unverifiedLeads.length,0);
const inventoryProof=readJson(out+'/inventory-resolution-review.json');
assert.equal(fileHash(inventoryProof.originalInventory.path),inventoryProof.originalInventory.sha256);
assert.deepStrictEqual(inventory.records,inventoryProof.records);assert.deepStrictEqual(inventory.unverifiedLeads,inventoryProof.unverifiedLeads);
assert(inventory.records.every(record=>!record.vehicleClass||['passenger','ute'].includes(record.vehicleClass)));
const {inventoryRecordId}=require('./scripts/reporting/m1-reconciliation.ts');
const actualInventoryIds=inventory.records.map(record=>'record:'+inventoryRecordId(record));
assert.equal(new Set(actualInventoryIds).size,3);
assert.deepStrictEqual(new Set(expected.expectedSettledInventory),new Set(actualInventoryIds));
assert.deepStrictEqual(expected.expectedSettledInventory,inventoryProof.expectedSettlement);
assert.deepStrictEqual(reconciliation.currentVersionReviews.map(review=>review.id),inventoryProof.currentVersionReviewIds);
assert.deepStrictEqual(new Set(reconciliation.inventoryResolutions.map(row=>row.kind+':'+row.inventoryId)),new Set(actualInventoryIds));
assert.equal(reconciliation.inventoryResolutions.length,3);
const countrymanReview=reconciliation.currentVersionReviews.find(review=>review.id===inventoryProof.countrymanReviewId);
assert(countrymanReview);assert.deepStrictEqual(countrymanReview.publishedModelAliases,[inventoryProof.countrymanAlias]);
assert.deepStrictEqual(countrymanReview.versions.map(version=>version.carId),inventoryProof.countrymanVersionIds);assert.equal(countrymanReview.versions.length,5);""")
(O/'check.mjs').write_text(s);(O/'run.py').write_bytes((A/'run.py').read_bytes())
prep=(A/'prepare.py').read_text().replace(str(A),str(O)).replace('mini-market-reconciliation-v2.json','mini-market-reconciliation-v3.json').replace('research-manifest-v4.json','research-manifest-v5.json')
prep=replace_once(prep,"# Pin static relative import closure", "files.update([O/'inventory-resolution-review.json',R/'countryman-alias-audit-v1.json',Path('/tmp/mini-review/preflight-v2-readiness-receipt.json')])\nfiles.update(Path('/tmp/mini-packet/selected-preflight-v2/run')/name for name in ['invocation.json','started.json','terminal.json','after-pins.json','stderr.log','stdout.log'])\n# Pin static relative import closure")
prep=prep.replace('Pre-call structured clones guard original/proposed research, selected cars and live packs; exact summary source snapshots and unchanged identities are asserted.', 'Pre-call structured clones guard original/proposed research, selected cars and live packs; exact summary source snapshots and unchanged identities are asserted. Three inherited inventory records are frozen in full; all three settlements and the separate complete three-model/ten-version list remain mandatory, with one source-bound Countryman alias.')
(O/'prepare.py').write_text(prep)
(O/'v2-to-v3.patch').write_text(''.join(difflib.unified_diff((A/'check.mjs').read_text().splitlines(True),s.splitlines(True),fromfile=str(A/'check.mjs'),tofile=str(O/'check.mjs'))))
write(O/'correction-provenance.json',{'status':'prepared_not_executed','scope':'One exact source-bound Countryman alias in reconciliation plus frozen original inventory and stronger record-bound settlement assertions; no fact, identity, source content, producer/helper, policy expectation, wrapper or runtime envelope changes.','failedV2Manifest':pin(A/'prepared-command.json'),'failedV2Terminal':pin(A/'run/terminal.json'),'candidate':pin(P/'mini-2026-10-15-candidate-v2.json'),'aliasAudit':pin(R/'countryman-alias-audit-v1.json'),'reconciliation':pin(P/'mini-market-reconciliation-v3.json'),'wrapperByteIdentical':(A/'run.py').read_bytes()==(O/'run.py').read_bytes(),'expectedSettledInventoryUnchanged':True,'allThreeModelsAndTenVersionsRequired':True,'executed':False})
print(json.dumps({'created':str(O),'reconciliation':pin(P/'mini-market-reconciliation-v3.json'),'sourceManifest':pin(R/'research-manifest-v5.json'),'executed':False},indent=2))
