from pathlib import Path
import json
B=Path('/tmp/mini-packet/report-comparison-v1');B.mkdir(exist_ok=False)
s=Path('/tmp/deepal-packet/report-comparison-v4/compare-report.mjs').read_text()
s=s.replace('/tmp/deepal-packet/report-comparison-v4','/tmp/mini-packet/report-comparison-v1').replace("const qa='/workspace/scratch/586427eef9f2/roadmark-104-qa/deepal-continuation-checks';","const qa='/tmp/mini-packet/report-comparison-v1';")
s=s.replace("const out=qa+'/report-comparison-v4-artifacts'","const out=qa+'/artifacts'")
s=s.replace("/workspace/scratch/586427eef9f2/roadmark-104-qa/audi-sequential-checks/normal-coverage-asof-2026-10-15/stdout.log","/workspace/scratch/586427eef9f2/roadmark-104-qa/deepal-continuation-checks/normal-coverage-asof-2026-10-15/stdout.log")
s=s.replace('0e971290adb305fd261321df5272b469a84e30f7e759f24efb658ddb9d7c6e1a','6153972132d6094f497a148d3d850b3ba645efd486a6c9da417dd4ae93ee002a')
s=s.replace("import {readJson,fileHash,streamRows} from '/tmp/xpeng-staging-plan/baseline-io.mjs';","import path from 'node:path';\nimport {readJson,fileHash,streamRows,digestRows} from '/tmp/xpeng-staging-plan/baseline-io.mjs';\nimport {readCompleteCars} from '/tmp/mercedes-staging-plan/staging-preparation/shape-first-v3/read-complete-storage.mjs';\nimport {assertDeclaredJson} from '/tmp/mercedes-staging-plan/consumer-preparation/v5/feature-json-parity.mjs';")
s=s.replace('/tmp/deepal-packet/published-driveaway-validation-v2/result.json','/tmp/mini-packet/selected-preflight-v4/result.json').replace('/tmp/deepal-research/retained-before-cars.json','/tmp/mini-research/retained-before-cars.json').replace('/tmp/deepal-packet/full-stage-v4/output/selected-packs.json','/tmp/mini-packet/full-stage-v2/output/selected-packs.json').replace('/tmp/deepal-packet/full-stage-v4/output/selected-after-cars.json','/tmp/mini-packet/full-stage-v2/output/selected-after-cars.json')
start=s.index('assert.equal(selectedIds.size,3);');end=s.index("const manifest=readJson",start)
s=s[:start]+'''assert.equal(selectedIds.size,10);assert.equal(selectedResult.otherRetainedFeaturesUnchanged,true);
const selectedSnapshots={before:structuredClone(before),after:structuredClone(after),packs:structuredClone(packs),result:structuredClone(selectedResult)};
const acceptedStageDigests=readJson('/tmp/mini-packet/full-stage-v2/output/car-digest-comparison.json');
const acceptedDeepalDigests=readJson('/tmp/deepal-packet/full-stage-v4/output/car-digest-comparison.json');
assert.deepStrictEqual(acceptedStageDigests.candidate26,acceptedDeepalDigests.candidate26);
assert.equal(acceptedStageDigests.candidate27.length,427);
const oldPeerDigests=acceptedStageDigests.candidate26.filter(c=>!selectedIds.has(c.id)),newPeerDigests=acceptedStageDigests.candidate27.filter(c=>!selectedIds.has(c.id));
assert.equal(oldPeerDigests.length,417);assert.deepStrictEqual(newPeerDigests,oldPeerDigests);
write('accepted-peer-car-value-and-basis-proof',{exactCompletePeerCars:417,allPeerValuesBasesUnitsGradesAndIdentitiesUnchanged:true,peers:newPeerDigests});
''' +s[end:]
s=s.replace("const base={},reads=[];","""const base={},reads=[];
const stageManifest=readJson('/tmp/mini-packet/full-stage-v2/manifest.json');
const closure=readJson(stageManifest.storageClosure.path),closureMap=new Map(closure.map(p=>[p.path,p])),readPaths=new Set();
const acceptedInputPins=new Map(manifest.inputPins.map(row=>[row.anchor+'\\0'+row.file,row]));
const proof={anchors:manifest.anchors,assertPinned(ref){const pin=acceptedInputPins.get(ref.anchor+'\\0'+ref.file),absolute=path.resolve(manifest.anchors[ref.anchor],ref.file),direct=closureMap.get(absolute);assert(pin&&direct);assert.equal(pin.sha256,ref.sha256);assert.equal(pin.bytes,ref.bytes);assert.equal(direct.sha256,ref.sha256);assert.equal(direct.bytes,ref.bytes);readPaths.add(absolute);}};
let restored=await readCompleteCars(proof,stageManifest.storageIndex),completeBefore=restored.cars;restored=null;
const carDigests=cars=>cars.map(car=>({id:car.id,...digestRows([car])}));
assertDeclaredJson(completeBefore,'/prefix20',new Set());assert.deepStrictEqual(carDigests(completeBefore),acceptedDeepalDigests.baseline20);
for(const [key,ref]of Object.entries(index.research))proof.assertPinned(ref);
""")
s=s.replace("assert.equal(base.variants.length,3);assert.equal(base.feature_evidence.length,207);","assert.equal(base.variants.length,10);assert.equal(base.feature_evidence.length,690);\nassert.deepStrictEqual([...readPaths].sort(),[...closureMap.keys()].sort());")
start=s.index("const oldRoot='/tmp/deepal-packet/registration-v1/before';");end=s.index("const reports=compile",start)
s=s[:start]+'''// No feature replay for peers. Reconstruct complete cars from already accepted written values.
const {brandUpdatePackets}=require('./src/lib/brand-update-registry.ts');
assert.equal(brandUpdatePackets.length,27);assert.equal(brandUpdatePackets.at(-1).id,'m1-mini-2026-10-15');
const priorPackets=brandUpdatePackets.slice(0,26),packet=brandUpdatePackets.at(-1);
assert.deepStrictEqual(priorPackets.map(p=>p.id),stageManifest.registeredPacketIds);
const sourceMap=new Map(base.sources.map(source=>[source.id,source]));assert.equal(sourceMap.size,base.sources.length);
for(const p of priorPackets.slice(20))for(const source of p.sources){if(sourceMap.has(source.id))assert.deepStrictEqual(sourceMap.get(source.id),source);else sourceMap.set(source.id,structuredClone(source));}
base.sources=[...sourceMap.values()];
assert.deepStrictEqual(digestRows(base.sources),readJson('/tmp/deepal-packet/full-stage-v4/output/research-field-digests.json').candidate26.sources);
const eqa=priorPackets[20];assert.equal(eqa.id,'m1-mercedes-benz-towing-basis-2026-10-15');assert.equal(eqa.facts.length,1);assert.equal(eqa.summaries.length,0);assert.equal(eqa.variants.length,0);assert.equal(eqa.availability.length,0);assert.equal(eqa.versionUpdates.length,0);
const edit=eqa.facts[0],originalEqa=completeBefore.find(car=>car.id===edit.variantId);assert.deepStrictEqual(originalEqa.facts[edit.after.key],edit.before);
completeBefore=completeBefore.map(car=>car.id===edit.variantId?{...car,facts:{...car.facts,[edit.after.key]:structuredClone(edit.after)}}:car);
assert.deepStrictEqual(carDigests(completeBefore),acceptedDeepalDigests.corrected21);
const replacements=[
 ['current22','/tmp/leapmotor-staging/v4-timeout/output/selected-after-cars.json'],
 ['current23','/tmp/mazda-staging/full-v2/output/selected-after-cars.json'],
 ['current24','/tmp/skoda-packet/full-stage-v1/output/selected-after-cars.json'],
 ['candidate25','/tmp/audi-packet/full-stage-v1/output/selected-after-cars.json'],
 ['candidate26','/tmp/deepal-packet/full-stage-v4/output/selected-after-cars.json'],
];
for(const [stage,file]of replacements){
 const rows=readJson(file),replacementMap=new Map(rows.map(car=>[car.id,car]));assert.equal(rows.length,replacementMap.size);
 const existing=new Set(completeBefore.map(car=>car.id));completeBefore=completeBefore.map(car=>replacementMap.get(car.id)??car);completeBefore.push(...rows.filter(car=>!existing.has(car.id)));
 assertDeclaredJson(completeBefore,'/'+stage,new Set());assert.deepStrictEqual(carDigests(completeBefore),acceptedDeepalDigests[stage]);
}
assert.equal(completeBefore.length,427);assert.deepStrictEqual(completeBefore.filter(car=>selectedIds.has(car.id)),before);
const afterMap=new Map(after.map(car=>[car.id,car])),completeAfter=completeBefore.map(car=>afterMap.get(car.id)??car);
assert.deepStrictEqual(carDigests(completeAfter),acceptedStageDigests.candidate27);
const beforeSourceSnapshot=digestRows(base.sources),afterSources=[...base.sources,...packet.sources];
assert.deepStrictEqual(digestRows(afterSources),readJson('/tmp/mini-packet/full-stage-v2/output/research-field-digests.json').candidate27.sources);
const baseSnapshot=structuredClone(base),packetSnapshot=structuredClone(packet);
const {compiledSource}=require('./tests/helpers/compiled-source.ts');
let defaultCalls=0;const forbidden=()=>{defaultCalls++;throw new Error('FORBIDDEN_DEFAULT_LOADER');};
const consumer=compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets:priorPackets}}).createEvidenceConsumers({sourceResearch:forbidden,research:forbidden,catalogue:forbidden});
const {applyFeatureRegrading}=require('./src/lib/evidence-regrading.ts');
const {applyBrandFeatureUpdates,applyBrandTermFeatures}=require('./src/lib/brand-updates.ts');
const {auditedFeature}=require('./src/lib/launch-evidence.ts');
const beforeFeatures=[],producerReceipts=[],frames=new Map(),observations=[];
''' +s[end:]
# Add exact optional producer observer from accepted selected preflight, unchanged.
obs=Path('/tmp/mini-packet/selected-preflight-v4/check.mjs').read_text();obs=obs[obs.index('function observePack('):obs.index('function observeClaim(')]
pos=s.index("const reports=compile")
s=s[:pos]+obs+'''for(const car of before){
 const input=consumer.sourceEffectiveFeatures(car,base),inputSnapshot=structuredClone(input),regraded=applyFeatureRegrading(car,input,base.sources);
 const branded=applyBrandFeatureUpdates(car,regraded,base,priorPackets),projected=applyBrandTermFeatures(car,branded,base.sources);
 assert.deepStrictEqual(input,inputSnapshot);frames.set('before\\0'+car.id,{input,regraded,branded,projected,research:base});
 const features=consumer.effectiveFeatures(car,base);assert.equal(features.length,69);assert.deepStrictEqual(features,projected);
 observePack(car,{features},'before');beforeFeatures.push(...features);
 producerReceipts.push({carId:car.id,criteria:69,sourceRows:input.length,actualCanonicalRows:features.length});
}
assert.equal(beforeFeatures.length,690);assert.deepStrictEqual(observations,selectedResult.optionalFeaturePaths.filter(row=>row.phase==='before'));
const beforeFeatureSnapshot=structuredClone(beforeFeatures);
write('selected-before-features',beforeFeatures);
const beforeWrittenFeatures=readJson(out+'/selected-before-features.json');
for(const car of before)for(const feature of beforeWrittenFeatures.filter(f=>f.variant_id===car.id&&f.criterion!=='roadside_assistance'))assert.deepStrictEqual(feature,packs[car.id].features.find(f=>f.criterion===feature.criterion));
assert.deepStrictEqual(base,baseSnapshot);assert.deepStrictEqual(before,selectedSnapshots.before);
''' +s[pos:]
s=s.replace("'\\nexport { coreFact, gradePattern };\\n'","'\\nexport { coreFact, gradePattern, coreCoverage };\\n'")
# Rename brand identifiers/prose without changing actual baseline paths.
s=s.replace("brand==='Deepal'","brand==='MINI'").replace("brand!=='Deepal'","brand!=='MINI'").replace("b.brand==='Deepal'","b.brand==='MINI'").replace("b.brand!=='Deepal'","b.brand!=='MINI'")
s=s.replace('oldDeepal','oldMini').replace('newDeepal','newMini').replace('liveDeepal','liveMini').replace('expectedLiveDeepal','expectedLiveMini').replace('deepalInventory','miniInventory')
s=s.replace("const afterSources=[...base.sources,...readJson(repo+'/data/m1-brand-updates/deepal-2026-10-15.json').sources];\nconst afterFeatures=Object.values(packs).flatMap(p=>p.features);\nconst afterFresh=reports.buildStaleReport({cars:after,features:afterFeatures},normal.asOf);\nassert.deepEqual({overdue:afterFresh.overdue,invalid:afterFresh.invalid,dueNext30Days:afterFresh.due.length,excludedHistory:afterFresh.historical},selectedAfter.ageing);","")
s=s.replace("actualDriveawayProducers:producerReceipts","actualSelectedFeatureProducers:producerReceipts")
# Full exact core reason inventory replaces truncated-top-two inference.
start=s.index('const explanations=[];');end=s.index('const groupKey=',start)
s=s[:start]+'''const onSaleBefore=completeBefore.filter(reports.isTierOne).filter(reports.isOnSale),onSaleAfter=completeAfter.filter(reports.isTierOne).filter(reports.isOnSale);
assert.equal(onSaleBefore.length,309);assert.equal(onSaleAfter.length,309);
const completeBeforeCore=reports.coreCoverage(onSaleBefore,base.sources,normal.asOf,new Map(base.sources.map(source=>[source.id,source])));
const completeAfterCore=reports.coreCoverage(onSaleAfter,afterSources,normal.asOf,new Map(afterSources.map(source=>[source.id,source])));
assert.deepStrictEqual(completeBeforeCore.core,baseline.core);assert.deepStrictEqual(completeBeforeCore.gaps,baseline.gaps);
expected.core=completeAfterCore.core;expected.gaps=completeAfterCore.gaps;
const explanations=[];
for(const [i,old]of baseline.core.entries()){
 const b=selectedBefore.core[i],a=selectedAfter.core[i],next=expected.core[i];assert.equal(old.key,b.key);assert.equal(a.key,b.key);assert.equal(next.key,old.key);
 assert.equal(next.filled,old.filled-b.filled+a.filled);assert.equal(next.total,old.total);
 for(const grade of Object.keys(old.grades))assert.equal(next.grades[grade],old.grades[grade]-b.grades[grade]+a.grades[grade]);
 const beforeReasons=[...reasonCounts(onSaleBefore,base.sources,old.key)],afterReasons=[...reasonCounts(onSaleAfter,afterSources,old.key)];
 explanations.push({key:old.key,beforeFullReasons:beforeReasons,afterFullReasons:afterReasons,beforeExplanation:old.explanation,afterExplanation:next.explanation,producer:'Actual coreCoverage and gradePattern with complete digest-verified cars, source registry and original catalogue order; no truncated-tail inference'});
}
write('global-core-complete-reason-inventory',explanations);
''' +s[end:]
# Replace whole ranking block with stage numeric order plus report-scope production sorting.
start=s.index('const rankingGroupProof=[];');end=s.index("for(const key of ['gaps','summaryGaps'])",start)
s=s[:start]+'''const stageRankings=readJson('/tmp/mini-packet/full-stage-v2/output/global-ranking-comparison.json');
const rankingGroupProof=[];
function projectedStageGroups(stage,memberIds){
 const members=new Set(memberIds),index=new Map(completeBefore.map((car,i)=>[car.id,i]));assert.equal(members.size,memberIds.length);
 const groups=stage.groups.map(g=>{const ids=g.ids.filter(id=>members.has(id)),[vehicleClass,basis,unit]=JSON.parse(g.key);return{vehicleClass,basis,unit,count:ids.length,ids};}).filter(g=>g.count);
 assert.equal(groups.reduce((sum,g)=>sum+g.count,0),memberIds.length);
 // Buckets are inserted at first matching car in actual catalogue order; stable sort preserves comparator ties.
 groups.sort((a,b)=>Math.min(...a.ids.map(id=>index.get(id)))-Math.min(...b.ids.map(id=>index.get(id))));
 const insertionKeys=groups.map(groupKey);groups.sort((a,b)=>groupOrder(sortingGroup(a),sortingGroup(b)));
 return{groups:groups.map(({ids,...group})=>group),rankedIds:groups.flatMap(g=>g.ids),insertionKeys,segments:groups};
}
expected.rankings=baseline.rankings.map((old,i)=>{
 const actual=normal.rankings[i],b=selectedBefore.rankings[i],a=selectedAfter.rankings[i],stage=stageRankings.find(row=>row.attribute===old.key);assert(stage);
 assert.equal(actual.key,old.key);assert.equal(b.key,old.key);assert.equal(a.key,old.key);
 const oldProjection=projectedStageGroups(stage.before,old.rankedIds);assert.deepStrictEqual(oldProjection.groups,old.groups);assert.deepStrictEqual(oldProjection.rankedIds,old.rankedIds);
 const membership=[...old.rankedIds.filter(id=>!selectedIds.has(id)),...a.rankedIds];
 const projection=projectedStageGroups(stage.after,membership);assert.deepStrictEqual(actual.groups,projection.groups);assert.deepStrictEqual(actual.rankedIds,projection.rankedIds);
 const oldSegments=groupSegments(old),newSegments=groupSegments(actual),selectedBeforeSegments=groupSegments(b),selectedAfterSegments=groupSegments(a),perGroup=[];
 for(const key of new Set([...oldSegments.keys(),...newSegments.keys(),...selectedBeforeSegments.keys(),...selectedAfterSegments.keys()])){
  const oldIds=oldSegments.get(key)?.ids||[],newIds=newSegments.get(key)?.ids||[],beforeIds=selectedBeforeSegments.get(key)?.ids||[],afterIds=selectedAfterSegments.get(key)?.ids||[];
  assert.deepStrictEqual(oldIds.filter(id=>selectedIds.has(id)),beforeIds);assert.deepStrictEqual(newIds.filter(id=>selectedIds.has(id)),afterIds);
  assert.deepStrictEqual(newIds.filter(id=>!selectedIds.has(id)),oldIds.filter(id=>!selectedIds.has(id)));
  assert.equal(newIds.length,oldIds.length-beforeIds.length+afterIds.length);
  perGroup.push({key,peerIds:oldIds.filter(id=>!selectedIds.has(id)),selectedBeforeIds:beforeIds,selectedAfterIds:afterIds,beforeCount:oldIds.length,afterCount:newIds.length});
 }
 assert.deepStrictEqual(peer(actual.excluded),peer(old.excluded));assert.deepStrictEqual(deep(actual.excluded),a.excluded);
 const exclusionReasons={};for(const item of actual.excluded)exclusionReasons[item.reason]=(exclusionReasons[item.reason]||0)+1;
 const ranked=old.ranked-b.ranked+a.ranked;assert.equal(actual.rankedIds.length,ranked);assert.equal(actual.excluded.length,normal.onSaleVersions-ranked);
 rankingGroupProof.push({key:old.key,perGroup,oldOrder:old.groups.map(groupKey),newOrder:projection.groups.map(groupKey),actualProductionGroupComparator:true,insertionKeys:projection.insertionKeys,exactNumericInterleavingFromAcceptedStage:true});
 return{...old,ranked,percent:pct(ranked,normal.onSaleVersions),rankedIds:projection.rankedIds,passes:ranked/normal.onSaleVersions>=0.9,groups:projection.groups,excluded:actual.excluded,exclusionReasons};
});
write('ranking-group-order-and-peer-proof',{sourcePath:discoveryPath,sourceSha256:fileHash(discoveryPath),exactComparatorText:groupComparatorText,groups:rankingGroupProof});
''' +s[end:]
# Gap expected value should remain exact core producer, not overwritten from actual.
s=s.replace("expected[key]=normal[key];\n}","if(key==='gaps')assert.deepStrictEqual(normal[key],expected.gaps);else expected[key]=normal[key];\n}",1)
s=s.replace('/tmp/deepal-packet/full-stage-v4/output/global-c1-comparison.json','/tmp/mini-packet/full-stage-v2/output/global-c1-comparison.json')
# Immutability terminal guards before report result.
pos=s.index("for(const path of ['src/lib/data.ts'")
s=s[:pos]+'''assert.deepStrictEqual(carDigests(completeBefore),acceptedStageDigests.candidate26);assert.deepStrictEqual(carDigests(completeAfter),acceptedStageDigests.candidate27);
assert.deepStrictEqual(digestRows(base.sources),beforeSourceSnapshot);assert.deepStrictEqual(base,baseSnapshot);assert.deepStrictEqual(packet,packetSnapshot);
assert.deepStrictEqual(before,selectedSnapshots.before);assert.deepStrictEqual(after,selectedSnapshots.after);assert.deepStrictEqual(packs,selectedSnapshots.packs);assert.deepStrictEqual(selectedResult,selectedSnapshots.result);assert.deepStrictEqual(beforeFeatures,beforeFeatureSnapshot);assert.equal(defaultCalls,0);
''' +s[pos:]
s=s.replace('peerCompleteCarDigestsExact:424','peerCompleteCarDigestsExact:417').replace('selectedOldDriveawayProducers:3,otherCriteriaReplayed:0','selectedOldFeatureProducers:690,peerFeaturesReplayed:0,completeCoreReasonInventory:true').replace("/** One saved normal report versus accepted Audi25, with selected-only actual producers. */","/** One saved normal report versus accepted Deepal26; exact core reasons and selected-only features. */").replace('exhaustive-normal-versus-audi-diff','exhaustive-normal-versus-deepal-diff')
(B/'compare-report.mjs').write_text(s)
(B/'README.md').write_text('''# MINI saved normal-report comparison preparation\n\nNo execution. Requires guarded registration, all earlier checks, a fresh root grant and exclusive slot. One actual unchanged production coverage report runs separately. The comparator reads its saved JSON and the accepted Deepal26 normal report. It does not replace the normal report.\n\nComplete baseline cars are reconstructed from the accepted retained prefix20 storage and accepted complete selected replacement cars for packets22–26. The one EQA21 towing fact is guarded against its exact before-state and after-car digest. Every car at each stage and all427 Deepal26/MINI27 complete-car digests must match the accepted full stage before use. Sources are appended without overwrite and must match the accepted complete-source field digests. This is structural restoration only, with no research hydration or feature replay for peers.\n\nActual production coreCoverage computes all17 core fields and all low-grade reason counts in catalogue order. Its complete before core and gaps must equal Deepal26. Its after core is checked against selected numerical deltas and the saved normal output. No truncated explanation tail is inferred.\n\nOnly the ten MINI cars run actual effective-feature producers to reproduce baseline freshness and selected brand output. Their own-undefined paths are compared to accepted preflight producer witnesses. Live C1 optional issue properties are reconstructed only through the actual issue producer; complete written equality remains separate.\n\nAll rankings preserve peer membership/order within class+basis+unit. Complete numeric interleaving is projected from the accepted stage groups to the exact on-sale membership. Group order uses the actual production comparator and first-member catalogue insertion order, including ties. All unrelated report leaves are compared, followed by complete expected-versus-actual report equality. No broad feature replay, new normal-report retry, helper edit or unscoped normalisation.\n''')
print(str(B/'compare-report.mjs'))
