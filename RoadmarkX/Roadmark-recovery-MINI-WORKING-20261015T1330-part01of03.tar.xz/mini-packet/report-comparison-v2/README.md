# MINI saved normal-report comparison preparation

No execution. Requires guarded registration, all earlier checks, a fresh root grant and exclusive slot. One actual unchanged production coverage report runs separately. The comparator reads its saved JSON and the accepted Deepal26 normal report. It does not replace the normal report.

Complete baseline cars are reconstructed from the accepted retained prefix20 storage and accepted complete selected replacement cars for packets22–26. The one EQA21 towing fact is guarded against its exact before-state and after-car digest. Every car at each stage and all427 Deepal26/MINI27 complete-car digests must match the accepted full stage before use. Sources are appended without overwrite and must match the accepted complete-source field digests. This is structural restoration only, with no research hydration or feature replay for peers.

Actual production coreCoverage computes all17 core fields and all low-grade reason counts in catalogue order. Its complete before core and gaps must equal Deepal26. Its after core is checked against selected numerical deltas and the saved normal output. No truncated explanation tail is inferred.

Only the ten MINI cars run actual effective-feature producers to reproduce baseline freshness and selected brand output. Their own-undefined paths are compared to accepted preflight producer witnesses. Live C1 optional issue properties are reconstructed only through the actual issue producer; complete written equality remains separate.

All rankings preserve peer membership/order within class+basis+unit. Complete numeric interleaving is projected from the accepted stage groups to the exact on-sale membership. Group order uses the actual production comparator and first-member catalogue insertion order, including ties. All unrelated report leaves are compared, followed by complete expected-versus-actual report equality. No broad feature replay, new normal-report retry, helper edit or unscoped normalisation.

V2 independently composes every full excluded/summary/inventory/ageing array from unchanged peer values and accepted selected values in the actual catalogue/inventory/producer traversal order. Baseline order is proved first. No array in the expected report is copied from the new normal output. V1 remains retained as a preparation with an interleaving-proof gap; neither version has run.
