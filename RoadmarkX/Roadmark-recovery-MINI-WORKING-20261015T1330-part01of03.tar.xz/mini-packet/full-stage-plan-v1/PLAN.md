# MINI27 bounded full-stage plan

Status: preparation only. Candidate v3 has exactly ten source-grade/basis corrections to the earlier selected v3 technical pass. Selected v4 source/command review passed and the freshly authorized run terminated successfully on 15 October at 12:23:34 UTC, with independent actual-output review accepted for that selected scope. This full-stage command requires its own independent readiness review and explicit root execution grant. Backup owns the heavy slot. This plan authorizes no execution or live change.

## Fixed scope and expected outcome

- Accepted Deepal26: 427 catalogue versions, 350 Tier 1, 309 on sale, 26 packets
- Proposed MINI27: the same 427 / 350 / 309, 27 packets; no models, versions, identity/model-year, configuration or manual feature additions
- Exactly ten retained MINI cars may change; all 417 peer complete-car digests, identities, values, sources and order must remain exact
- 153 specific fact updates and 30 shared-term applications; 170 core cells and 183 updated effective cells
- Candidate v3 core grades: 136 Confirmed, 23 Check, 10 Not published, 1 Reported. No quota-based grading
- All 690 selected feature claims; only ten canonical roadside projections change. All ten driveaway claims remain actual source/regrading fallbacks; no maker amount is converted into driveaway
- Three complete current model reviews and ten named grades; all three inherited MINI inventory records must settle through the exact original record bindings and sourced Countryman alias
- Whole-market C1 remains false. Untamed, Victory and residual historical/stock findings remain scoped in the census

## Restore the accepted current baseline once

Use the retained409 storage index and accepted prefix20 manifest through the existing bounded storage readers. Selection is the frozen ten-ID set, not a catalogue discovery operation. Reproduce the accepted ordered transitions:

1. baseline20: 409 cars
2. corrected21 EQA towing: 409
3. current22 Leapmotor: 413
4. current23 Mazda: 413
5. current24 Skoda: 417
6. candidate25 Audi: 427
7. candidate26 Deepal: 427

At every stage require equality with the accepted Deepal full-stage complete ordered per-car digest array and all 14 complete research-field digests. Compare the exact variant-to-car ID order and cumulative registered packet IDs. Do not replay packets 1–20, recapture canonical storage, generate a whole-catalogue cache or invoke a production catalogue loader.

Use current unchanged production helpers. Current brand-updates.ts matches the accepted Deepal helper. Metadata composition owns only metadata.brand_update_packet_ids: the raw prepare call names only the applied packet; the stage explicitly composes cumulative IDs and preserves every other returned field reference. Original input objects must remain unchanged. Strict plain-JSON shape checks reject hidden own-undefined/accessor/symbol/nonfinite/sparse changes before digest comparison; selected live objects retain pre-call structuredClone/deepStrictEqual snapshots.

## Apply MINI27 without peer feature replay

Apply only candidate v3 after its exact before guards. All old source rows remain exact; exactly 46 reviewed source rows are appended. No source replacement, model addition, raw feature edit or historical context change is allowed. Every other complete research field remains unchanged except explicit variant metadata and the cumulative packet IDs.

Inspect retained complete research/cars, preceding packets and the pinned raw upstream overlay inputs for references to new MINI source IDs, including nested grade reviews and object keys. A reused reference is a blocker because a source append could otherwise revive a peer claim. All preceding packets and MINI terms must have disjoint explicit targets. With unchanged helper implementations, unchanged peer cars/raw rows/sources and no new-source references, do not replay a peer's 69-feature pack or any extra broad feature pass.

The ten staged cars must equal the newly accepted selected-v4 output exactly. Preserve all unaffected fields on those cars and all 417 complete peer cars. Stage the actual ten before/after packs using only the actual registry injection; default loaders throw. Reproduce the accepted 183 fact claims, 690 feature claims, summaries/dependencies, availability, source closure, ranking eligibility and exact three-record inventory proof.

## Serialization and producer-owned fields

Keep the selected preflight's exact ownership checks. Snapshot live packs before storage. Compare live-to-live through actual producers and written-to-written artifacts/readback. Reconstruct accepted written claims with the actual citable producers when comparing against live claims. The only allowed feature/citation/report omissions are exact same-run own enumerable undefined properties at producer-proven paths; do not strip arbitrary undefined values.

For global C1, compare the written baseline with both accepted Deepal stage output and the successful saved normal production report. Reconstruct its independent_lists issue from the actual buildMarketReconciliation fixture to establish the two omitted live properties, brand and reference. No other global report omission is silently normalized.

## Rankings and global structural checks

Run actual attribute-ranking and current-list functions over the restored cars, without all-car feature computation. Keep full peer membership, values/bases/units and relative order inside each exact vehicle-class/basis/unit group. Selected-only changes can alter group sizes and therefore reorder complete groups. Require actual production group sorting by member count descending then basis.localeCompare, including independently established bucket insertion order for ties. Never compare flattened cross-group peer order as if immutable. Competition ranks/ties must follow actual values, and peer exclusions/unranked details must remain exact.

The five directly named Cooper/Aceman/Paul Smith maxima rank in the explicit WLTP maximum group. The five Countryman maxima remain Check/unranked because the E/SE ALL4 columns cover multiple named packages with 18/19/20-inch choices without package-specific maxima. No numerical per-wheel effect is claimed. All prices remain unranked: five exact style-selected Countryman from-prices are Confirmed, four BASIC_LINE applicability prices are Check, Paul Smith is Reported, but road-cost groups cannot be invented.

Actual global C1 must reproduce the accepted Deepal baseline first, then change only by adding three MINI reviews/ten versions and settling its three records. Every non-MINI issue, review and disposition remains exact; complete C1 is still false. Reconfirm 427 / 350 / 309.

## Separate later integration and normal-report gate

Only after independent full-stage acceptance and separate root authority: copy the exact candidate packet and reconciliation, append their registry/loader registrations and update scoped documentation. No helper change is proposed.

Then run one ordinary full production coverage report in a separately granted exclusive slot at 2026-10-15. Its inherent all-car feature work is the exhaustive reporting gate, not duplicated in this stage. Compare the saved report against the accepted Deepal26 normal report: exact non-MINI brandProgress, peer gaps/summary gaps/ageing, inventory/leads, source/grade explanations and compatible-group rank membership/order/exclusions. Allow only explicitly evidenced MINI deltas and recomputed aggregates. Record every changed path and finish with exact whole-report equality against the accounted expected result. Keep failed comparator evidence; no normal-report rerun just to repair a comparator.

Buyer documentation must distinguish evidence confidence from comparison compatibility. Explain the nine maker GST-plus-A$2,500-delivery from-amounts, missing registration/state-charge itemization, four BASIC_LINE named-style applicability gaps and Paul Smith's reported A$60,990 before-ORC fallback. Explain exact-grade maxima versus unresolved Countryman package attribution. Do not use generic laboratory, model-year or delivered-build caveats as per-fact downgrades. Preserve battery/DC/roadside conflicts and all explicit Not published towing entries.

## Proposed envelope and outputs

One process: Node 448 MiB old-space / 1 MiB semi-space, explicit GC, 420 seconds plus 10-second termination grace, wait4 terminal receipt, immutable input pins, no automatic retry. Heap flags are not an OS RSS limit. A frozen manifest, independent review and fresh explicit root grant are prerequisites.

Create-only outputs: transition metadata, full per-car and all-14-field digest receipts, source-reference inspection, ten selected cars/packs/portable/claims and exact optional witnesses, actual compatible-group ranking proof, baseline/proposed global C1, and final structural receipt. No full-catalogue or all-feature output cache. A pin mismatch, undeclared change, ownership mismatch, unresolved source reference or timeout stops the run and preserves evidence. No heavy work overlaps backup.
