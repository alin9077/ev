from pathlib import Path
import json,hashlib,collections
P=Path('/tmp/mini-packet');R=Path('/tmp/mini-research');D='2026-10-15'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
p=json.loads((P/'mini-2026-10-15-candidate-v1.json').read_text()); B={c['id']:c for c in json.loads((R/'retained-before-cars.json').read_text())}; new=[]
for row in p['facts']:
 a=row['after'];c=B[row['variantId']]
 if a['key']=='width_mm':a['label']='Published width'
 if a['key']=='price_aud':a['label']='Published price'
 if c['model']=='Aceman' and a['key']=='battery_kwh':
  a['value']=49.2;a['basis']='Usable battery capacity';a['comparisonBasis']='Usable battery capacity';a['qualifications']=['Current brochure explicitly gives 54.2 kWh gross / 49.2 kWh net. Retain the established usable core basis; gross capacity remains a separate historical fact.']
 if c['model']=='Aceman' and a['key']=='battery_usable_kwh':continue
 new.append(row)
p['facts']=new
for s in p['sources']:
 if s['id']=='m1_mini_20261015_carexpert_paul_smith':
  f=R/'reviewer-secondary/carexpert-paul-smith.json';s['capturePath']=str(f);s['captureSha256']=sha(f);s['provenancePath']=str(R/'reviewer-secondary/carexpert-paul-smith-read-receipt.json')
write(P/'mini-2026-10-15-candidate-v2.json',p)
core=json.loads((P/'core-fact-proposal-v1.json').read_text()); facts={(r['variantId'],r['after']['key']):r['after'] for r in p['facts']}
for c in core['versions']:
 for k,x in c['facts'].items():
  f=facts[(c['variantId'],k)];x.update({'value':f['value'],'basis':f['basis'],'comparisonBasis':f['comparisonBasis'],'sourceIds':f['sourceIds']})
write(P/'core-fact-proposal-v2.json',core)
# Anonymous endpoint receipts have empty header value sets, never copies of credentials.
receipts=[]
for s in p['sources']:
 if s['id'].split('20261015_')[1].startswith(('price_','range_','tech_')) and s['url'].endswith('.json') or 'productdata.api.bmw' in s['url']:
  receipts.append({'url':s['url'],'method':'GET','explicitHeaders':{},'authenticationProvided':False,'clientKeysProvided':False,'cookiesProvided':False,'bodyProvided':False,'capturePath':s['capturePath'],'captureSha256':s['captureSha256'],'provenancePath':s.get('provenancePath'),'receiptBasis':'Recorded public urllib.request.urlopen(URL) request; source bytes allowed to persist only after factual allowlist/credential-key removal. No value from runtime configuration was supplied.'})
write(R/'anonymous-get-receipts-v1.json',{'checkedAt':D,'requests':receipts})
# Pure artifact checks only: no catalogue construction, route execution or project test commands.
checks={'beforeFacts':True,'beforeTerms':True,'beforeIdentity':True,'beforeAvailability':True,'sourceHashes':True,'summaryDependencies':True,'gradeCounts':dict(collections.Counter(r['after']['buyerGrade'] for r in p['facts']))}
for r in p['facts']:assert r['before']==B[r['variantId']]['facts'].get(r['after']['key'])
for r in p['brandTerms']:
 for i,b in r['before'].items():assert b==B[i]['facts'].get(r['key'])
for r in p['versionGuards']:assert r['before']=={k:B[r['variantId']][k] for k in r['before']}
for r in p['availability']:assert r['before']=={'availability':B[r['variantId']]['availability'],'evidence':B[r['variantId']]['availabilityEvidence']}
for s in p['sources']:assert sha(Path(s['capturePath']))==s['captureSha256']
for r in p['summaries']:
 for clause in ['strength','tradeoff']:
  for dep in r[clause]['dependencies']:assert dep['expected']==facts[(r['variantId'],dep['key'])]
write(P/'light-static-check-v2.json',{'status':'PASS for pure JSON snapshot/hash/dependency checks only','scope':'Not importer validation, catalogue/report validation, typecheck, tests or build','candidateSha256':sha(P/'mini-2026-10-15-candidate-v2.json'),'checks':checks,'counts':{'guards':10,'specificFacts':len(p['facts']),'brandTermApplications':30,'coreCells':170,'supplementalNetCells':3,'sharedRoadsideApplications':10,'availabilityUpdates':10,'summaryClauses':20}})
m=json.loads((R/'research-manifest-v1.json').read_text());m['candidate']={'path':str(P/'mini-2026-10-15-candidate-v2.json'),'sha256':sha(P/'mini-2026-10-15-candidate-v2.json'),'status':'v2 frozen for independent review; fixes v1 width/price labels, Aceman basis and exact Paul Smith price support'};m['sourceIndex']=p['sources'];m['sourceFiles']=[]
for root in [R,R/'sources',R/'reviewer-secondary']:
 for f in sorted(root.iterdir()):
  if f.is_file() and f.suffix not in ['.py','.png'] and not f.name.startswith('research-manifest'):
   m['sourceFiles'].append({'path':str(f),'bytes':f.stat().st_size,'sha256':sha(f)})
m['supportingArtifacts']=[{'path':str(f),'sha256':sha(f)} for f in [P/'core-fact-proposal-v2.json',P/'mini-market-reconciliation-v1.json',P/'light-static-check-v2.json',R/'residual-census-v1.json',R/'source-gaps-v1.json',R/'anonymous-get-receipts-v1.json']]
write(R/'research-manifest-v2.json',m)
print('v2',len(p['facts']),'facts',sha(P/'mini-2026-10-15-candidate-v2.json'));print('manifest',sha(R/'research-manifest-v2.json'));print(checks)
