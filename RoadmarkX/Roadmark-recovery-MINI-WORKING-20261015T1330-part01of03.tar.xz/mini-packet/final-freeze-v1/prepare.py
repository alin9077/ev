from pathlib import Path
from datetime import datetime, timezone
import json, hashlib, os, stat
B = Path('/tmp/mini-packet/final-freeze-v1')
W = Path('/workspace/scratch/586427eef9f2')
R = W / 'roadmark-104'
REVIEW = Path('/tmp/mini-review')
def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def row(path, category):
    path = Path(path)
    s = path.lstat()
    r = dict(path=str(path), category=category, bytes=s.st_size, mode=s.st_mode, mtimeNs=s.st_mtime_ns)
    if stat.S_ISLNK(s.st_mode):
        r.update(kind='symlink', target=os.readlink(path), targetFollowed=False)
    else:
        assert stat.S_ISREG(s.st_mode), str(path)
        r['kind'] = 'file'
    return r
out = B / 'inventory.json'
assert not out.exists(), 'Freeze inventory is write-once'
docs_path = Path('/tmp/mini-packet/docs-status-v2/manifest.json')
readback_path = REVIEW / 'docs-status-v2-live-readback.json'
final_receipt_path = REVIEW / 'final-retention-v1-acceptance.json'
assert not final_receipt_path.exists(), 'Final receipt follows the frozen inventory'
reg = json.loads(Path('/tmp/mini-packet/registration-v1/manifest.json').read_text())
docs = json.loads(docs_path.read_text())
readback = json.loads(readback_path.read_text())
assert readback['status'] == 'accepted', 'Independent docs readback must be accepted'
roots = [('/tmp/mini-research', 'sanitized_public_research_and_source_history'), ('/tmp/mini-packet', 'packet_commands_qa_and_all_attempt_history'), ('/tmp/mini-review', 'independent_reviews')]
exclude_files = {
    '/tmp/mini-research/__pycache__/capture_public_json.cpython-312.pyc': 'Reconstructible Python bytecode; source script retained',
    '/tmp/mini-research/__pycache__/capture_sources.cpython-312.pyc': 'Reconstructible Python bytecode; source script retained',
    '/tmp/mini-packet/post-registration-checks-v1/.exclusive-heavy.lock': 'Empty lock file from completed sequential gates; no process or state reconstruction requires it',
}
rows = []
excluded = []
for root, category in roots:
    for current, dirs, files in os.walk(root, followlinks=False):
        dirs.sort(); files.sort()
        if Path(current) == B:
            dirs[:] = []
            continue
        for name in list(dirs):
            path = Path(current) / name
            if path.is_symlink():
                rows.append(row(path, category)); dirs.remove(name)
        for name in files:
            path = Path(current) / name
            if str(path) in exclude_files:
                excluded.append(dict(**row(path, 'excluded_reconstructible'), reason=exclude_files[str(path)], deletionAuthorized=False))
            else:
                rows.append(row(path, category))
assert len(excluded) == len(exclude_files)
assert next(r for r in excluded if r['path'].endswith('.lock'))['bytes'] == 0
visual = W / 'roadmark-104-visual-qa-20261015'
visual_names = ['visual-qa-blocker-receipt.json', 'snapshot-manifest.json', 'launch-receipt.json', 'stop-receipt.json', 'market-check.log', 'server.log']
for name in visual_names:
    rows.append(row(visual / name, 'historical_deepal_preview_compact_receipt_not_MINI_visual_QA'))
expected = [dict(target=r['target'], after=r['after']) for r in reg['writes']] + [dict(target=r['target'], after=r['after']) for r in docs['writes']]
assert len(expected) == 7
live = []
for r in expected:
    p = pin(r['target'])
    assert p['bytes'] == r['after']['bytes'] and p['sha256'] == r['after']['sha256'], r['target']
    live.append(p)
    rows.append(row(r['target'], 'live_registered_docs_status_target'))
assert len({r['path'] for r in rows}) == len(rows)
rows.sort(key=lambda r: r['path'])
failed_terminal = Path('/tmp/mini-packet/selected-preflight-v2/run/terminal.json')
assert json.loads(failed_terminal.read_text())['exitCode'] == 1
x = dict(
    schemaVersion=1,
    status='author_frozen_metadata_exact_allowlist_pending_backup_capture_and_independent_final_receipt',
    frozenAt=datetime.now(timezone.utc).isoformat(),
    noFurtherPayloadEdits=True,
    metadataOnlyInventory=True,
    contentCaptureOrPrivacyScanPerformed=False,
    inventoryHashScope='Only seven exact live targets and small named receipts/provenance are hashed here; payload walk records metadata only. Backup owns separate authorized capture and privacy scan.',
    payloadRoots=[root for root, _ in roots],
    files=rows,
    totalFiles=len(rows),
    regularFileBytes=sum(r['bytes'] for r in rows if r['kind'] == 'file'),
    symlinkCount=sum(r['kind'] == 'symlink' for r in rows),
    sourceAndStatusAfterPins=live,
    excluded=excluded + [dict(path=str(B), reason='Inventory, preparer and final reviewer acceptance pinned separately to avoid circularity', deletionAuthorized=False), dict(path=str(visual / 'snapshot'), reason='Historical redundant Deepal preview snapshot/dependencies/cache excluded; six compact terminal proofs retained; this is not MINI visual QA', deletionAuthorized=False)],
    publicImageProvenance=pin('/tmp/mini-research/source-render-provenance-v1.json'),
    knownSanitizedSupport=dict(
        sourceEvidenceManifest=pin('/tmp/mini-research/research-manifest-v6.json'),
        anonymousRequestReceipts=pin('/tmp/mini-research/anonymous-get-receipts-v1.json'),
        officialHTML='Visible text and public links only; scripts, styles, attributes, iframes, runtime configuration and credential-like URL parameters discarded before persistence; no-value provenance retained.',
        officialJSON='Factual model, technical, pricing and range allowlists only; no runtime provider configuration, authentication headers, cookies, client keys or token values used or retained. Generated technical image URLs/links omitted before freeze.',
        PDFs='Five unchanged public manufacturer PDFs with adjacent provenance and factual text extracts. Three local page-4 renders are source-inspection evidence only.',
        secondary='Bounded factual extracts and web tool receipts, with exact source attribution. No third-party prose reused as buyer copy.',
        classificationCautions='Credential-related field names and false/empty request flags are deliberate no-value provenance. Prices and taxes, source URLs, public model/style codes, source and file hashes, test identifiers and generated TypeScript paths are ordinary factual/proof material, not authentication secrets.',
        knownSensitiveValuesRetained=False,
        privacyScanClaim=False),
    retainedFailures=[dict(name='Selected preflight v2: inherited Countryman inventory alias did not resolve', terminal=pin(failed_terminal), diagnosis=pin('/tmp/mini-review/preflight-v2-failure-diagnosis.json'), disposition='Preserved; exact sourced publishedModelAliases correction reviewed before separately granted v3 run. Three-model expectation retained.')],
    otherAttemptHistory=dict(
        selectedV1='Prepared only; static immutability gaps fixed in v2 before execution.',
        selectedV3='Technical pass on candidate v2, superseded by separately reviewed ten-fact grade correction and accepted candidate v3/v4 run; all artifacts retained.',
        selectedV4='Accepted current selected run, including all 690 selected feature claims and live/written optional ownership.',
        fullStageV1='Prepared only; static duplicate binding, representation and proof-boundary findings corrected in v2; no failed runtime is claimed.',
        fullStageV2='Accepted one bounded full-stage run; exact Deepal26 baseline and 417 unchanged peers.',
        reportComparatorV1='Prepared only; independent complete-array-order proof added in v2; no failed runtime is claimed.',
        reportComparatorV2='One accepted actual production normal report and one accepted saved-report comparator; all core explanation reasons and unrelated output order proved.',
        freshValidation='151 scoped behavioural/safety tests, lint, market-view, structural validation and original-config cold full-project TypeScript passed. No fresh full-suite, production-build, phone or MINI visual QA claim.'),
    independentDocsReadback=pin(readback_path),
    finalRuntimeAcceptance=pin('/tmp/mini-review/report-comparison-v2-output-review.json'),
    currentPacket=pin('/tmp/mini-packet/mini-2026-10-15-candidate-v3.json'),
    currentReconciliation=pin('/tmp/mini-packet/mini-market-reconciliation-v3.json'),
    retainedStorageReadClosure=pin('/tmp/mini-packet/full-stage-v2/output/retained-storage-read-closure.json'),
    externalDependencies='Reuse the already retained accepted Deepal26 recovery chain and its exact referenced Mercedes/Xpeng prefix20 storage, EQA21/Leap22/Mazda23/Skoda24/Audi25/Deepal26 proofs and replacement inputs. The retained 21-file actual storage closure and command manifests specify the exact paths/hashes. Backup owns mapping retained sanitized copies to original logical paths. No broad recapture or credential recovery.',
    reconstructionNotes='No MINI payload symlinks expected; metadata walker does not follow any. Dependency directories/node_modules and generated Next build caches are not added to this scope. Restore source plus retained accepted dependency mapping, preserving written JSON versus live optional-undefined ownership when running consumers. The cold TypeScript proof cache is intentionally retained as evidence of the 361-root scope, not as a prerequisite cache.',
    finalReviewerReceiptPolicy=dict(path=str(final_receipt_path), state='future_separate_acceptance_after_inventory_review', includedInPayload=False, reason='Avoid recursive inventory pins; reviewer directory otherwise frozen after docs readback.'),
    preparer=pin(__file__)
)
assert x['symlinkCount'] == 0, 'Unexpected link requires explicit review before freeze'
out.write_text(json.dumps(x, indent=2, ensure_ascii=False) + '\n')
print(json.dumps(dict(inventory=pin(out), files=x['totalFiles'], bytes=x['regularFileBytes'], symlinks=x['symlinkCount'], liveTargets=len(live)), indent=2))
