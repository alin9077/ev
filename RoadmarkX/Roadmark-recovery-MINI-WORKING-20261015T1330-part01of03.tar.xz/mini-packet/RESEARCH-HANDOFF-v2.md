# MINI source and identity audit — 15 October 2026

## Result

Ten existing Australian BEV version identities remain the complete supported current manufacturer named-grade list. No model/variant additions, removals, formal model-year assignments or historic-source edits are proposed. The light research work is complete; independent final review and any staged application are separate gates.

| Current retained version | Selected price A$ | Published basis | Peak DC | Claimed maximum WLTP |
|---|---:|---|---:|---:|
| Cooper SE Favoured | 61,489.70 | Maker from-price includes GST and $2,500 delivery | 95 kW | 400 km |
| Cooper JCW Electric | 66,490.30 | Same partially inclusive maker basis | 95 kW | 371 km |
| Cooper SE Paul Smith Edition | 60,990 | CarExpert, before on-road costs, Reported | 95 kW | 400 km |
| Aceman SE | 63,489.50 | Maker from-price includes GST and $2,500 delivery | 95 kW | 406 km |
| Aceman JCW | 68,490.10 | Same partially inclusive maker basis | 95 kW | 355 km |
| Countryman E Classic | 71,490 | Same partially inclusive maker basis | 95 / 130 kW conflict | 501 km |
| Countryman E Favoured | 74,490 | Same partially inclusive maker basis | 95 / 130 kW conflict | 501 km |
| Countryman SE ALL4 Classic | 76,490 | Same partially inclusive maker basis | 130 kW | 467 km |
| Countryman SE ALL4 Favoured | 79,490 | Same partially inclusive maker basis | 130 kW | 467 km |
| Countryman SE ALL4 JCW Sport | 82,490.01 | Same partially inclusive maker basis | 130 kW | 467 km |

All selected prices remain unranked. Registration/state charges are not itemized in the nine maker responses; no dealer-delivery subtraction, rounding, driveaway conversion or before-ORC relabeling is performed. Five exact style-selected Countryman maker amounts are Confirmed; road-cost grouping affects ranking, not evidence confidence. Four BASIC_LINE responses retain named-style applicability Checks. Paul Smith's exact trim response has no price; its dedicated brochure also supplies none, so the explicit independent before-ORC figure is the highest supported applicable fallback.

Five directly named Cooper/Aceman/Paul Smith WLTP maxima are Confirmed and rank within the explicit WLTP maximum group. Five Countryman maxima remain Check: the E/SE ALL4 range columns span named packages and 18/19/20-inch choices without package-specific maxima. No numeric per-wheel effect is claimed. Generic laboratory or delivered-build caveats do not lower evidence grades. Current-list evidence establishes neither physical stock nor accepted factory orders. Before-state advertisement evidence keeps its historic date.

## Main changes and gaps

- Complete proposed refresh of all 170 core cells: 136 Confirmed, 23 Check, 10 Not published, 1 Reported
- Ten missing `drive` Fact cells are added from exact maker drive declarations; existing identity drive values do not change
- Paul Smith price is newly filled at $60,990 Reported
- Five Countryman battery cells expose the brochure's 66 kWh net claim as Check with the incompatible 64.8 claim visible; two E DC cells expose 95 kW with the incompatible 130 kW claim visible
- Aceman preserves its established 49.2 kWh usable core basis; no unnecessary swap to its separate 54.2 gross figure
- Three additional usable-battery cells expose regular Cooper 49.8 and Paul Smith 48.2 net brochure claims, each with genuine conflicting alternatives visible and unranked
- Charging times already existed in the before-state; this is a refreshed sourced/basis review, not ten newly discovered numbers: Cooper 30, Aceman 31, Countryman 29 minutes, all explicit 10–80% DC. Countryman E timing remains conditional because of the peak/production conflict
- All ten braked towing ratings earn Not published after current exact brochure omission plus exact technical `TRAILER_LOAD_ID: null`. No zero is inferred
- Shared warranty remains 5 years / unlimited km for ordinary private use; commercial-use 200,000 km cap retained. Battery cover 8 years / 160,000 km for J01/J05/U25, with 70% capacity eligibility from first registration 1 April 2026 kept distinct
- Existing roadside term is revised to Check: warranty brochure 8 years BEV versus model brochures 5 years. Neither conflict is erased
- Cargo protocol/loading boundaries and width mirror basis remain explicitly unstated; numeric facts remain visible without invented normalized comparison bases
- Ten replacement strengths/trade-offs use only actual claim dependencies; unrelated price/MY/battery holds cannot suppress clean clauses

## Census differences

- Untamed: official Australian all-electric edition lead, secondary SE ALL4 early 2027 arrival; exact purchasable/order-open version unestablished. No identity added
- Untamed towbar: maker says unavailable in Australia; secondary 1,200 kg braked rating is a separate edition-specific claim, not evidence of towbar supply or a rating for current retained versions
- Victory 1965: retained limited-edition lead, 10 electric allocation; current unsold New stock/order acceptance unverified. Historical RedBook $66,990 price-when-new is not a maker current offer
- Cooper E, Aceman E / E Classic and Countryman E Core: independent calendar-year guides still list them; current maker named-grade lists omit them. E Core's removal is reported explicitly. Preserve residual New possibility instead of declaring all stock exhausted
- Oxford: excluded from BEVs on exact Australian secondary evidence of 40 Cooper S three-door petrol vehicles
- Earlier F56/history: no existing identity deleted; no new residual-stock identity fabricated

This is brand-only reconciliation, not whole-market C1 closure or national-best evidence.

## Frozen deliverables

- Candidate: `/tmp/mini-packet/mini-2026-10-15-candidate-v3.json`
  - SHA256 `14c9007e7708d70de30e0aabd4f5ab3c56dbf38cfde65a44a04f065ee147e916`
  - 153 specific fact changes, 3 shared terms / 30 applications, 10 full identity guards, 10 guarded availability updates, 20 claim-only summary clauses
- Final research manifest: `/tmp/mini-research/research-manifest-v6.json`
  - SHA256 `a238a519ab87c1a5ec016b8c9aed9d97ebc7ea4e6c61efbb9bfec7d04020ed7b`
- Core field matrix: `/tmp/mini-packet/core-fact-proposal-v3.json`
- Proposed reconciliation: `/tmp/mini-packet/mini-market-reconciliation-v3.json`
- Final census: `/tmp/mini-research/residual-census-v2.json`
- Gaps/conflicts: `/tmp/mini-research/source-gaps-v2.json`
- Source mapping: `/tmp/mini-research/source-support-map-v1.json`
- Anonymous no-value request receipts: `/tmp/mini-research/anonymous-get-receipts-v1.json`
- Full before states and exact accepted-row proof: `/tmp/mini-research/retained-before-cars.json` and `retained-before-selection-receipt.json`
- Static artifact check: `/tmp/mini-packet/light-static-check-v3.json`

## Source handling and next gate

Public GETs only, without supplied keys/tokens/auth headers/cookies. No raw runtime HTML was saved. HTML captures retain only visible content/public links; technical JSON retains model identity/specification rows/footnotes; public price/range responses retain factual vehicle data. PDFs are unchanged publicly linked documents. Each capture is hashed and has no-value provenance.

Before states were selected read-only from an existing JSONL snapshot and matched exactly against accepted post-Deepal26 row hashes. The selected v3 consumer run passed for the superseded candidate v2, without broad catalogue hydration. Candidate v3 now requires the newly prepared selected v4 check. Pure JSON checks pass for every before fact, brand term, identity, availability, source hash and summary dependency. This is not an importer/typecheck/test/build result.

Do not register this candidate directly. Parent should first receive independent source review, then coordinate any isolated staged guard/grade/report validation when the heavy slot is released. The earlier selected consumer runs and their terminal receipts are preserved. No live source, registry, project test/build, browser, server, archive, publication or user-computer action was performed by this worker. Expected catalogue counts remain 427 total / 350 Tier 1 / 309 on-sale because no identity/state class is added or removed; that is a proposal expectation, not a newly measured catalogue result.
