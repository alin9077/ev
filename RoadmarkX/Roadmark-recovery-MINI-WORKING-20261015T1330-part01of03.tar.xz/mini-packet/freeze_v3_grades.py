from pathlib import Path
import json,hashlib,collections,difflib
P=Path('/tmp/mini-packet');R=Path('/tmp/mini-research');A=P/'selected-preflight-v3';O=P/'selected-preflight-v4';O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def write(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False);f.write('\n')
old=json.loads((P/'mini-2026-10-15-candidate-v2.json').read_text());p=json.loads(json.dumps(old));B={c['id']:c for c in json.loads((R/'retained-before-cars.json').read_text())};changes=[]
for row in p['facts']:
 a=row['after'];i=row['variantId'];is_countryman='countryman' in i
 if a['key']=='range_km' and not is_countryman:
  a['status']='standard';a['buyerGrade']='confirmed';a['basis']='Manufacturer-declared maximum WLTP range for this named grade';a['comparisonBasis']='WLTP maximum';a['conditionExplanation']='';a['qualifications']=[f"The current Australian maker brochure assigns an up-to {a['value']} km WLTP maximum to this named grade; the maximum label is retained."]
  a['gradeReview']['reason']='The current Australian maker brochure maps this published WLTP maximum directly to the named Cooper/Aceman grade or dedicated Paul Smith edition. No specific unresolved option or measurement attribution is established for this stated maximum; a generic delivered-build or laboratory caveat does not lower its grade.'
 elif a['key']=='price_aud' and is_countryman:
  a['status']='standard';a['buyerGrade']='confirmed';a['qualifications'].append(a['conditionExplanation']);a['conditionExplanation']='';a['gradeReview']['reason']='The current Australian maker price response explicitly selects this Countryman model code and named Classic/Favoured/JCW Sport trim code. Its exact GST-and-delivery-inclusive from-amount is Confirmed; unresolved road-cost grouping prevents price ranking but does not reduce source confidence.'
 else:continue
 oldrow=next(x for x in old['facts'] if x['variantId']==i and x['after']['key']==a['key']);changed=[k for k in a if a[k]!=oldrow['after'].get(k)]
 assert all(a[k]==oldrow['after'][k] for k in ['value','unit','sourceIds','date','market','scope','issues'])
 changes.append({'variantId':i,'key':a['key'],'before':oldrow['after'],'after':a,'changedAfterFields':changed,'sourceSupport':[{'id':s['id'],'url':s['url'],'capturePath':s['capturePath'],'captureSha256':s['captureSha256']} for s in p['sources'] if s['id'] in a['sourceIds']]})
assert len(changes)==10 and collections.Counter(x['key'] for x in changes)=={'range_km':5,'price_aud':5}
for key in p:
 if key!='facts':assert p[key]==old[key]
assert [x['before'] for x in p['facts']]==[x['before'] for x in old['facts']]
write(P/'mini-2026-10-15-candidate-v3.json',p)
facts={(r['variantId'],r['after']['key']):r['after'] for r in p['facts']}
core=json.loads((P/'core-fact-proposal-v2.json').read_text())
for c in core['versions']:
 for k,x in c['facts'].items():
  f=facts[(c['variantId'],k)];x.update(value=f['value'],grade=f['buyerGrade'],basis=f['basis'],comparisonBasis=f['comparisonBasis'],sourceIds=f['sourceIds'],condition=f.get('conditionExplanation',''))
write(P/'core-fact-proposal-v3.json',core)
gaps=json.loads((R/'source-gaps-v1.json').read_text());assert gaps['measurementGaps'][0].startswith('All maximum WLTP');gaps['measurementGaps'][0]='Countryman E/SE ALL4 maxima span Classic/Favoured/JCW Sport packages and 18/19/20-inch choices without grade-specific maxima: five Check cells remain unranked. The five directly named Cooper/Aceman/Paul Smith maxima are Confirmed and comparable in the explicit WLTP maximum group; maximum wording or a generic laboratory caveat alone is not a condition.'
write(R/'source-gaps-v2.json',gaps)
for r in p['facts']:assert r['before']==B[r['variantId']]['facts'].get(r['after']['key'])
for r in p['brandTerms']:
 for i,b in r['before'].items():assert b==B[i]['facts'].get(r['key'])
for r in p['versionGuards']:assert r['before']=={k:B[r['variantId']][k] for k in r['before']}
for r in p['availability']:assert r['before']=={'availability':B[r['variantId']]['availability'],'evidence':B[r['variantId']]['availabilityEvidence']}
for s in p['sources']:assert sha(s['capturePath'])==s['captureSha256']
for r in p['summaries']:
 for side in ['strength','tradeoff']:
  for dep in r[side]['dependencies']:assert dep['expected']==facts[(r['variantId'],dep['key'])]
write(P/'light-static-check-v3.json',{'status':'PASS for pure JSON snapshot/hash/dependency and exact ten-fact delta checks only','scope':'No actual consumer, importer, report, typecheck, test or build run for this candidate','candidate':pin(P/'mini-2026-10-15-candidate-v3.json'),'changedFacts':10,'specificFacts':len(p['facts']),'specificGradeCounts':dict(collections.Counter(r['after']['buyerGrade'] for r in p['facts'])),'coreGradeCounts':{'confirmed':136,'check':23,'not_published':10,'reported':1},'summaryDependenciesUnchangedAndExact':True,'allNumericalValuesAndSourcesUnchanged':True,'beforeGuardsUnchanged':True})
write(R/'grade-alignment-audit-v1.json',{'status':'ten_fact_only_grade_basis_correction_pending_independent_review','checkedAt':'2026-10-15','briefRule':'DOT-BRIEF-103 section5.2: current named-version maker claims Confirmed; only real option/method applicability conditions Check. Maximum wording, generic laboratory caveats, delivered-build uncertainty and inability to fit a price ranking group do not by themselves reduce evidence confidence.','candidateBefore':pin(P/'mini-2026-10-15-candidate-v2.json'),'candidateAfter':pin(P/'mini-2026-10-15-candidate-v3.json'),'changes':changes,'unchanged':{'numericalValues':True,'sourceEvidence':True,'tenIdentities':True,'summaries':True,'CountrymanRangeCheck':5,'BasicLinePriceCheck':4,'PaulSmithPriceReported':1,'allPricesUnranked':True,'CountrymanBatteryDcAndRoadsideConflicts':True},'supersededSelectedTechnicalPass':{'result':pin(A/'result.json'),'terminal':pin(A/'run/terminal.json'),'scope':'Actual-consumer technical pass for candidate v2; retained as prior evidence only, not validation of candidate v3.'},'sourceConfidenceVersusRanking':'Five exact style-selected Countryman from-prices are Confirmed, rung3, includingGST and A$2500dealer delivery. Registration/state charges remain unitemized; no driveaway/before-ORC conversion or ranking is admitted. Four BASIC_LINE model responses still have named-style applicability gaps. Paul Smith retains reported60990beforeORC fallback.'})
m=json.loads((R/'research-manifest-v5.json').read_text());m['status']='Candidate v3 contains exactly ten grade/basis corrections after brief-alignment review; reconciliation v3 and all numerical/source evidence unchanged. Selected v3 pass applies to superseded candidate v2 only.';m['candidate']={'path':str(P/'mini-2026-10-15-candidate-v3.json'),'sha256':sha(P/'mini-2026-10-15-candidate-v3.json'),'status':'Five directly named grade WLTP maxima and five exact style-selected Countryman from-prices Confirmed; pending independent narrow source/command review.'}
for a in m['supportingArtifacts']:
 replacements={str(P/'core-fact-proposal-v2.json'):P/'core-fact-proposal-v3.json',str(P/'light-static-check-v2.json'):P/'light-static-check-v3.json',str(R/'source-gaps-v1.json'):R/'source-gaps-v2.json'}
 if a['path'] in replacements:a.update(pin(replacements[a['path']]))
m['supportingArtifacts'].append(pin(R/'grade-alignment-audit-v1.json'));write(R/'research-manifest-v6.json',m)
s=(A/'check.mjs').read_text().replace(str(A),str(O)).replace('mini-2026-10-15-candidate-v2.json','mini-2026-10-15-candidate-v3.json');(O/'check.mjs').write_text(s);(O/'run.py').write_bytes((A/'run.py').read_bytes());(O/'inventory-resolution-review.json').write_bytes((A/'inventory-resolution-review.json').read_bytes())
prep=(A/'prepare.py').read_text().replace(str(A),str(O)).replace('mini-2026-10-15-candidate-v2.json','mini-2026-10-15-candidate-v3.json').replace('research-manifest-v5.json','research-manifest-v6.json').replace('source-gaps-v1.json','source-gaps-v2.json')
needle="eligible=k in ['length_mm','height_mm','seats','zero_to_100_s','power_kw','ac_kw'] or "
assert prep.count(needle)==1;prep=prep.replace(needle,"eligible=k in ['length_mm','height_mm','seats','zero_to_100_s','power_kw','ac_kw'] or (k=='range_km' and model[i]!='Countryman Electric') or ")
prep=prep.replace("# Pin static relative import closure", "files.update([R/'grade-alignment-audit-v1.json',P/'light-static-check-v3.json',P/'core-fact-proposal-v3.json'])\nfiles.update(Path('/tmp/mini-packet/selected-preflight-v3')/name for name in ['result.json','run/terminal.json','run/after-pins.json'])\n# Pin static relative import closure")
(O/'prepare.py').write_text(prep)
(O/'v3-to-v4-script.patch').write_text(''.join(difflib.unified_diff((A/'check.mjs').read_text().splitlines(True),s.splitlines(True),fromfile=str(A/'check.mjs'),tofile=str(O/'check.mjs'))))
(O/'candidate-v2-to-v3.patch').write_text(''.join(difflib.unified_diff((P/'mini-2026-10-15-candidate-v2.json').read_text().splitlines(True),(P/'mini-2026-10-15-candidate-v3.json').read_text().splitlines(True),fromfile='candidate-v2.json',tofile='candidate-v3.json')))
write(O/'correction-provenance.json',{'status':'prepared_not_executed','scope':'Exact ten-fact-only grade/basis correction plus corresponding five range eligibility expectations. No numerical/source/identity/summary/reconciliation/helper/runtime-envelope changes.','candidate':pin(P/'mini-2026-10-15-candidate-v3.json'),'sourceAudit':pin(R/'grade-alignment-audit-v1.json'),'supersededSelectedPass':pin(A/'result.json'),'wrapperByteIdentical':(A/'run.py').read_bytes()==(O/'run.py').read_bytes(),'inventoryProofByteIdentical':(A/'inventory-resolution-review.json').read_bytes()==(O/'inventory-resolution-review.json').read_bytes(),'executed':False})
print(json.dumps({'candidate':pin(P/'mini-2026-10-15-candidate-v3.json'),'sourceManifest':pin(R/'research-manifest-v6.json'),'changedFacts':len(changes),'specificGradeCounts':dict(collections.Counter(r['after']['buyerGrade'] for r in p['facts'])),'runtimeExecuted':False},indent=2))
