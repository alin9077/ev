import json,copy
from pathlib import Path
R=Path('/tmp/bmw-research/sedans');p=R/'normalized-evidence.json';D=json.load(open(p))
def add(v,k,val,src,grade='confirmed',**kw):
 if any(f['key']==k for f in v['facts']):return
 v['facts'].append(dict(key=k,value=val,sourceKeys=[src] if isinstance(src,str) else src,grade=grade,**kw))
for v in D['variants']+D['unresolvedVariants']:
 code=v['modelCode'];src='sedan_bmw_i4_spec' if v['model']=='i4' else 'sedan_bmw_i5_spec' if v['model']=='i5 Sedan' else 'sedan_bmw_i7_spec' if code=='72HY' else 'sedan_bmw-i7-sedan-technical-data' if v['model']=='i7' else 'sedan_bmw_i5_touring_tech'
 add(v,'manufacturer_model_code',code,src)
 for k,val in [('warranty_years',5),('battery_warranty_years',8),('battery_warranty_km',160000),('roadside_assistance',{'years':8,'unlimited_km':True})]:add(v,k,val,'sedan_BMW_Supplementary_Warranty_Nov2022',evidenceScope='brand_au_terms')
 wm=next((f for f in v['facts'] if f['key']=='width_including_mirrors_mm'),None)
 if wm:add(v,'width_mirrors_mm',wm['value'],wm['sourceKeys'],basis='Width including mirrors')
 if v['model']=='i4':
  for k,val in [('torque_nm',400),('unladen_ec_weight_kg',2070),('gvm_kg',2550),('payload_kg',555),('top_speed_kph',190),('roof_load_kg',75)]:add(v,k,val,'sedan_bmw-i4-gran-coupe-technical-data',basis='EC unladen includes 75 kg driver; not Australian kerb/tare' if k=='unladen_ec_weight_kg' else 'Published manufacturer value')
  add(v,'ac_port','Type 2',src);add(v,'dc_port','CCS2',src)
  add(v,'dealer_advertised_driveaway_aud',104034,'sedan_bmw_i4_stock_alt',grade='reported',basis='Canberra BMW exact NEW-advertised VIN WBY52HD050FX08944; 0 km',comparison='Driveaway',reason='Freshly read exact ad on 14 October. This is an optioned dealer unit, not the base price and not physical stock verification.')
 elif v['model']=='i5 Sedan':
  m=v['drive']=='AWD';add(v,'production_revision','2026-07',src,basis='Production applicability, not formal model year');add(v,'torque_nm',820 if m else 430,src)
  if not m:add(v,'dealer_advertised_driveaway_aud',179900,'sedan_bmw_i5_stock',grade='reported',basis='Melbourne BMW exact NEW-advertised VIN WBY62HG0X0CY87239; 0 km',comparison='Driveaway',reason='Freshly read 14 October; exact advertised vehicle includes options and is not a base price or stock guarantee.')
# Promote the independently verified current Touring configurator.
t=next(v for v in D['unresolvedVariants'] if v['model']=='i5 Touring');D['unresolvedVariants'].remove(t);D['variants'].append(t)
t.update(id='bmw_i5_touring_current__32hh_m60_xdrive__20261014',modelId='bmw_i5_touring_current',modelCode='32HH',recordState='current_or_order_listed',generation='G61; current Australian configurable M60 xDrive Touring, exact code 32HH')
baseurl='https://configure.bmw.com.au/en_AU/configure/G61/32HH'
for suffix,title in [('tech','technical modal'),('standard','standard-equipment modal'),('price','price breakdown'),('location','VIC 3000 location')]:
 D['sources'].append({'key':'sedan_config_32hh_'+suffix,'url':baseurl,'title':'BMW Australia live i5 M60 Touring '+title,'publisher':'BMW Australia','file':'review/config-'+suffix+'-32HH.txt','source_type':'manufacturer_au_configurator','checkedAt':'2026-10-14','retrievalMethod':'Independent reviewer ordinary cloud-browser UI capture'})
for f in t['facts']:
 if f['key'] in ['power_kw','zero_to_100_s','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','length_mm','width_mm','height_mm','wheelbase_mm','towing_kg','max_total_cargo_l','manufacturer_model_code']:
  f['sourceKeys']=['sedan_config_32hh_tech'];f['grade']='check' if f['key']=='towing_kg' else 'confirmed'
  if f['key']=='manufacturer_model_code':f['value']='32HH'
 if f['key']=='price_aud':
  f.update(value=236211,sourceKeys=['sedan_config_32hh_price','sedan_config_32hh_location'],grade='check',priceRung=4,basis='Maker VIC 3000 recommended driveaway price; selected options $0',comparison='Driveaway',basisTag='Maker VIC driveaway',rankingEligible=True,condition='Representative VIC 3000 location and selected standard configuration. Final price varies by registration location, dealer delivery and optional equipment.',reason='Copy live MRDP exactly; base-price line excludes GST/LCT and has not been treated as a list price.')
add(t,'price_reported_list_aud',219900,'sedan_i5_touring_carexpert','reported',basis='Reported price before on-road costs',comparison='Before on-road costs')
add(t,'width_mirrors_mm',2156,'sedan_config_32hh_tech',basis='Width including mirrors')
for k,val in [('torque_nm',795),('unladen_ec_weight_kg',2425),('gvm_kg',2960),('payload_kg',610),('top_speed_kph',230),('towball_download_kg',80),('towing_unbraked_kg',750),('turning_circle_m',11.9)]:add(t,k,val,'sedan_config_32hh_tech',basis='EC unladen includes 75 kg driver' if k=='unladen_ec_weight_kg' else 'Published configurator value')
for k,val,criterion,txt in [('wheel_diameter_in',20,'wheel_tyre_options','20-inch 938 M wheels selected at $0; other wheel options are separate.'),('heat_pump',True,'heat_pump','Heat pump is explicitly listed in the configurator standard-equipment modal.'),('battery_preconditioning',True,'preconditioning','Standard-equipment modal lists battery pre-temperature setting; navigation-trigger scope is not specified.'),('climate_zones',4,'automatic_seat_climate','Four-zone climate control is listed.'),('wireless_charging',True,'wireless_charging','Wireless charging tray is listed.'),('power_tailgate',True,'power_tailgate','Automatic tailgate operation is listed.'),('adaptive_suspension_professional',True,'suspension','Adaptive Suspension Professional with Integral Active Steering and rear load-compensating air suspension.'),('audio_bowers_wilkins',True,'audio_system','Bowers & Wilkins Surround Sound is selected as standard at $0. Generic base-equipment modal says Harman Kardon; actual selected AU equipment controls.'),('driving_assistant_professional',True,'adas_standard','Selected configuration includes Driving Assistant Professional (5AU); driver remains responsible.'),('parking_assistant_professional',True,'parking_cameras','Selected configuration includes Parking Assistant Professional (5DW).'),('front_ventilated_seats',True,'front_ventilated_seats','Selected configuration includes active front-seat ventilation (453).'),('glass_roof',True,'glass_roof','Selected configuration includes panorama glass roof (402).')]:
 add(t,k,val,'sedan_config_32hh_standard' if k in ['heat_pump','battery_preconditioning','climate_zones','power_tailgate','adaptive_suspension_professional'] else 'sedan_config_32hh_tech')
 t['features'].append({'criterion':criterion,'value':txt,'keys':[k]})
t['availabilityReason']='Live Australian configurator successfully configured exact G61/32HH M60 xDrive Touring with technical data and MRDP on 14 October. This establishes current maker order listing, not accepted factory order or physical stock.'
t['sourceReviewNotes']=['The discontinued product URL and missing brochure do not defeat the live exact-model configurator.','Configurator technical modal explicitly says battery size (gross/net) 81.2 kWh without choosing a basis; retain published unlabelled capacity rather than guessing.','Live 32HH technical modal torque is 795 Nm; 2026 reviews and later 62HH used VIN report 820 Nm. Do not merge these into one exact-code torque claim.','Generic configurator standard-equipment description lists Harman Kardon and basic assistants; actual selected AU options show Bowers & Wilkins, 5AU and 5DW. Prefer the selected AU specification.','503 km is retained from the exact maker AU technical table. BMW does not display a range in the captured configurator technical modal.']
t['summary']={'strength':{'label':'Fast practical wagon','text':'A 570 L boot expanding to 1,700 L, 442 kW AWD and 3.9-second 0–100 km/h.','keys':['boot_l','max_total_cargo_l','power_kw','drive','zero_to_100_s']},'tradeoff':{'label':'Large and costly','text':'The maker’s representative VIC driveaway price is A$236,211, and the wagon is 5.06 m long.','keys':['price_aud','length_mm']}}
D['census']['current'].append('i5 M60 xDrive Touring 32HH; live AU configurator verified')
D['census']['unresolved'].remove('i5 M60 xDrive Touring')
# Fresh verification ledger for populated pre-existing aliases.
old=json.load(open('/tmp/bmw-research/bmw-live-before.json'));rows=[]
for v in D['variants']:
 ov=next((o for o in old if o['id']==v['id']),None)
 if not ov:continue
 by={f['key']:f for f in v['facts']}
 for k,f in ov['facts'].items():
  if f.get('value') is not None:rows.append({'variant':v['id'],'key':k,'oldValue':f['value'],'newValue':by.get(k,{}).get('value'),'disposition':'refreshed' if k in by else 'parent_shared_terms_or_guard_review'})
D['legacyReconciliation']=rows
json.dump(D,open(p,'w'),ensure_ascii=False,indent=2)
print('Normalized variants',len(D['variants']),'unresolved',len(D['unresolvedVariants']),'legacy missing',[r['key'] for r in rows if r['disposition']!='refreshed'])
