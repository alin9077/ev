from pathlib import Path
import ast,difflib,hashlib,json,sys
R=Path('/workspace/scratch/586427eef9f2/roadmark-104');B=Path('/tmp/renault-packet/registration-v1')
assert len(sys.argv)==2,'prepare.py INDEPENDENT_FULL_STAGE_OUTPUT_ACCEPTANCE'
accepted=Path(sys.argv[1]);assert accepted.is_file()
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def put(p,b):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
def write(n,x):put(B/n,(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode())
packet=Path('/tmp/renault-packet/typed-preparation-v4/renault-2026-10-15-candidate.json');recon=Path('/tmp/renault-packet/typed-preparation-v4/renault-market-reconciliation.json')
assert pin(packet)['sha256']=='6f89f00f147c45c5e1afdff24f8597da3b980d6f5230cd1ba5fb663754464605'
registry='data/m1-brand-updates/registry.json';loader='scripts/reporting/load.ts'
old=json.loads((R/registry).read_text());assert len(old['packets'])==29 and old['packets'][-1]=='cupra-2026-10-15.json'
new={**old,'packets':[*old['packets'],'renault-2026-10-15.json']};assert new['packets'][:-1]==old['packets']
s=(R/loader).read_text();imp='import cupraReconciliation from "../../data/m1-cupra-market-reconciliation-2026-10-15.json";';arg='      cupraReconciliation as M1MarketReconciliation,'
assert s.count(imp)==1 and s.count(arg)==1 and 'renaultReconciliation' not in s
newload=s.replace(imp,imp+'\nimport renaultReconciliation from "../../data/m1-renault-market-reconciliation-2026-10-15.json";').replace(arg,arg+'\n      renaultReconciliation as M1MarketReconciliation,')
proposals={registry:(json.dumps(new,indent=2)+'\n').encode(),loader:newload.encode(),'data/m1-brand-updates/renault-2026-10-15.json':packet.read_bytes(),'data/m1-renault-market-reconciliation-2026-10-15.json':recon.read_bytes()}
rows=[];patch=''
for index,(rel,after) in enumerate(proposals.items()):
 p=R/rel;before=p.read_bytes() if p.exists() else None;assert (before is None)==(index>=2)
 put(B/'after'/rel,after)
 if before is not None:put(B/'before'/rel,before)
 rows.append(dict(relativePath=rel,target=str(p),operation='create' if before is None else 'replace',before=None if before is None else {k:v for k,v in pin(p).items() if k!='path'},after=pin(B/'after'/rel),beforeCopy=None if before is None else pin(B/'before'/rel)))
 patch+=''.join(difflib.unified_diff((before or b'').decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+rel if before is not None else '/dev/null',tofile='b/'+rel))
assert [r['operation'] for r in rows]==['replace','replace','create','create']
write('prepared-writes.json',rows);put(B/'registration.patch',patch.encode())
app=Path('/tmp/cupra-packet/registration-v1/apply.py').read_text().replace('apply_exact_cupra_registration','apply_exact_renault_registration')
ast.parse(app);put(B/'apply.py',app.encode())
write('applicator-syntax-check.json',dict(status='passed_python_ast_parse_only',applicator=pin(B/'apply.py'),executed=False,compilerRun=False))
proofpaths=[str(accepted),'/tmp/renault-packet/full-stage-v1/manifest.json','/tmp/renault-packet/full-stage-v1/full-stage-result-manifest-v1.json','/tmp/renault-review/full-stage-v1-readiness-v1.json','/tmp/renault-packet/selected-preflight-v5/selected-result-manifest-v1.json','/tmp/renault-review/selected-preflight-v5-results-v1.json','/tmp/renault-review/typed-preparation-v4-findings-v1.json','/tmp/renault-review/source-review-v2-findings-v1.json','/tmp/renault-packet/source-review-v2/manifest.json','/tmp/renault-packet/typed-preparation-v4/manifest.json',str(packet),str(recon),'/tmp/kgm-packet/full-project-typescript-v1/run/terminal.json','/tmp/kgm-packet/full-project-typescript-v2/run/terminal.json','/tmp/kgm-packet/report-comparison-v2/typescript-failure-provenance.json']
proofs={}
def add(p):
 x=pin(p);prev=proofs.get(x['path']);assert not prev or prev==x;proofs[x['path']]=x
for p in proofpaths:add(p)
for p in ['/tmp/renault-packet/full-stage-v1/manifest.json','/tmp/renault-packet/full-stage-v1/full-stage-result-manifest-v1.json','/tmp/renault-packet/source-review-v2/manifest.json','/tmp/renault-packet/typed-preparation-v4/manifest.json']:
 for x in json.loads(Path(p).read_text())['pins']:
  assert pin(x['path'])==x,(x['path'],'retained proof drift');add(x['path'])
helper=['src/lib/brand-updates.ts','src/lib/brand-update-registry.ts','src/lib/evidence-consumers.ts','src/lib/discovery.ts','src/lib/data.ts','scripts/reporting/reports.ts','scripts/reporting/m1-reconciliation.ts','tests/brand-updates.test.ts']
readme='''# Renault30 minimal guarded registration

Preparation only. Four writes: byte-identical accepted packet and reconciliation JSON; registry append at position 30 preserving the first 29 entries; one report-loader import and final reconciliation argument. No helper, alias, test, inventory, immutable research, generated market-view or documentation change.

The four retained Renault rows preserve the reviewed source semantics and exact before snapshots: 92 specific updates, 12 shared-term applications, four availability refreshes and four buyer-summary pairs. Roadside fact and feature claims both say “5 years”; the numeric alias and all warranty/assistance conditions remain unchanged. Explicit unknown measurement bases, genuine 10–80% gaps, Megane reported price, charge and height conflicts, Megane MY24 technical-epoch hold and R5 Turbo 3E reservation conflict remain visible. No regular Renault 5 Australian admission is inferred.

The accepted full stage proved fixed 430 catalogue / 353 Tier 1 / 312 on-sale, all 426 peer cars unchanged, four retained cars refreshed, no additions and 24 new sources. Global C1 remains false: 105 models and 238 versions reviewed, 192 issues, 64 settled inventory entries. Scenic settles; Megane remains unresolved. Independent whole-market list coverage remains open.

Application requires independent bundle review and a separate exact root grant. The applicator checks all retained proof leaves, exact before hashes and proposed bytes; journals four writes; then checks post hashes and unchanged helpers. A failure preserves its journal and stops without automatic retry or rollback. The grant template is not authorization.

Later checks are separately reviewed: market-view check, loader-only lint, 144 behavioural tests, seven live-safety tests and structural validation, followed by one actual normal report and an exhaustive saved-output comparator. No extra broad feature replay. The older-packet empty-comparison-basis audit remains a deferred read-only sidecar, with no claim that older packets are affected. Full-project TypeScript and release remain UNPASSED after two preserved KGM SIGKILL failures of unknown cause; no compiler retry, build, server or publication is included.
'''
put(B/'README.md',readme.encode())
m=dict(schemaVersion=1,status='frozen_preparation_only_requires_bundle_review_and_root_application_grant',repo=str(R),writes=rows,proofs=list(proofs.values()),unchangedHelperPins=[pin(R/p) for p in helper],patch=pin(B/'registration.patch'),applicator=pin(B/'apply.py'),preparation=[pin(B/'prepare.py'),pin(B/'README.md'),pin(B/'prepared-writes.json'),pin(B/'applicator-syntax-check.json')],expected=dict(catalogue=430,tierOne=353,onSale=312,packets=30,changedExistingCars=4,unchangedPeers=426,newModels=0,newVersions=0,newSources=24,generatedFeatureRows=0,manualFeatureUpdates=0,C1=dict(pass_=False,reviewedModels=105,reviewedVersions=238,issues=192,settledInventory=64)),scope=dict(existingFiles=2,newFiles=2,helperSemantics='Unchanged accepted live helpers',packet='Exact accepted typed-v4 candidate',reconciliation='Exact accepted typed-v4 reconciliation',registry='Append only; preserve first 29 ordered entries',reportLoader='One import and one last combineM1Reconciliations argument',reportImplementationChanged=False,testsChanged=False,heroChanged=False,immutableSnapshotChanged=False,sourceCapturesAddedToRepository=False),currentProjectTypeScript='UNPASSED: two preserved unknown-cause KGM SIGKILL failures; no compiler retry',automaticRetry=False,rootGrantRequired=True,heavyChecksAllowed=False,rollback='No automatic rollback or deletion; retain journal and exact before copies for separately authorised recovery')
m['expected']['C1']['pass']=m['expected']['C1'].pop('pass_')
write('manifest.json',m)
write('root-grant-template.json',dict(status='NOT_GRANTED',action='apply_exact_renault_registration',manifest=pin(B/'manifest.json'),reviewerAcceptance=None,allowedTargets=[x['target'] for x in rows],automaticRetry=False,heavyExecutionAuthorized=False))
print(json.dumps(dict(manifest=pin(B/'manifest.json'),proofs=len(proofs),writes=rows),indent=2))
