from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,os,subprocess,difflib,runpy
P=Path('/tmp/renault-packet/report-comparison-v2'); B=Path('/tmp/renault-packet/report-comparison-v4'); E=Path('/tmp/renault-packet/report-comparison-v2-interruption-record-v2')
R=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def read(p):return json.loads(Path(p).read_text())
def write(p,x):
 with Path(p).open('x')as f:json.dump(x,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def text(p,x):
 with Path(p).open('x')as f:f.write(x);f.flush();os.fsync(f.fileno())
def meta(p):
 p=Path(p)
 if not p.exists():return dict(path=str(p),exists=False)
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
def check(x):assert pin(x['path'])==x,x['path']
B.mkdir(exist_ok=False);E.mkdir(exist_ok=False)
originalFiles=[pin(p) for p in sorted(P.rglob('*')) if p.is_file()]
for p in originalFiles:check(p)
process=subprocess.run(['ps','-eo','pid,ppid,pgid,stat,lstart,etime,args'],capture_output=True,text=True,check=True)
text(E/'process-snapshot.txt',process.stdout)
# Observe executable fields, excluding our own ps/python shell and unrelated text.
active=[]
for line in process.stdout.splitlines()[1:]:
 fields=line.split(None,10)
 if len(fields)==11:
  args=fields[10];exe=Path(args.split()[0]).name
  if exe in ['node','timeout'] or (exe.startswith('python') and len(args.split())>1 and args.split()[1]==str(P/'run.py')):active.append(line)
assert not active,active
out=P/'normal-coverage-asof-2026-10-15'
expected=['started.json','invocation.json','registration-target-metadata-before.json','stdout.log','stderr.log','terminal.json','after-pins.json','scope-verification.json','result.json','setup-failure.json']
state=[meta(out/n)for n in expected]
assert (out/'invocation.json').is_file() and (out/'started.json').is_file()
assert not any((out/n).exists()for n in ['terminal.json','after-pins.json','scope-verification.json','result.json'])
assert (out/'stdout.log').stat().st_size==(out/'stderr.log').stat().st_size==0
(E/'saved-invocation').mkdir()
saved=[]
for p in sorted(out.iterdir()):
 assert p.is_file();dst=E/'saved-invocation'/p.name
 with dst.open('xb')as f:f.write(p.read_bytes());f.flush();os.fsync(f.fileno())
 saved.append(dict(original=pin(p),copy=pin(dst),originalMetadata=meta(p)))
normal=read(P/'normal-coverage-asof-2026-10-15.json')
originalSourcePins=read(normal['sourcePins']['path']); originalProofPins=normal['extraPins']
assert len(originalSourcePins)==545 and len(originalProofPins)==217
for p in originalSourcePins+originalProofPins:check(p)
md=read(normal['rootMetadata']['path'])
for m in md['fileMetadata']+md['directoryState']+normal['runtimeMetadata']:assert meta(m['path'])==m,m['path']
config=read(R/'tsconfig.json');roots=sorted({str(p.resolve())for pattern in config['include']for p in R.glob(pattern)if p.is_file()})
assert config==normal['originalConfig'] and roots==md['configuredRootFilePaths']
for p in normal['registrationTargets']:check(p)
write(E/'record.json',dict(status='UNKNOWN_INTERRUPTED_WITHOUT_TERMINAL_EVIDENCE',observedAt=datetime.now(timezone.utc).isoformat(),originalSequence=pin(P/'sequence.json'),originalGrant=pin(P/'root-execution-grant.json'),originalReadiness=pin('/tmp/renault-review/report-comparison-v2-readiness-v1.json'),invocation=read(out/'invocation.json'),started=read(out/'started.json'),directoryState=state,originalFiles=originalFiles,savedEvidence=saved,processSnapshot=pin(E/'process-snapshot.txt'),matchingVisibleProcesses=active,exitCode=None,terminationSignal=None,elapsedToTerminalSeconds=None,interruptionCause='unknown',successClaim=False,failureClaim=False,reportOutputPresent=False,originalDirectoryUnmodified=True,sourcePinsVerified=545,proofPinsVerified=217,configuredRootsVerified=len(roots),registrationTargetsVerified=normal['registrationTargets'],rootAndRuntimeMetadataVerified=True,currentFullProjectTypeScript='UNPASSED',releaseAcceptanceClaim=False))
old=(P/'compare-report.mjs').read_text();new=old.replace(str(P),str(B));assert old.count(str(P))==2
text(B/'compare-report.mjs',new)
text(B/'v2-to-v4-comparator.patch',''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(P/'compare-report.mjs'),tofile=str(B/'compare-report.mjs'))))
for name in ['run.py','close-comparator-inputs.py']:
 with (B/name).open('xb')as f:f.write((P/name).read_bytes())
text(B/'check-syntax.py',(P/'check-syntax.py').read_text().replace(str(P),str(B)))
text(B/'PLAN.md',(P/'PLAN.md').read_text()+'''\n## Explicit one-attempt retry after UNKNOWN interruption\n\nThe v2 report invocation at 2026-10-15T20:00:19.501118+00:00 has no retained terminal receipt and empty logs. Its result and cause remain UNKNOWN. The exact original directory and copied invocation/stat/log evidence are retained and pinned in report-comparison-v2-interruption-record-v2/record.json. This v4 is a distinct proposed retry, not an automatic continuation and not evidence that v2 passed or failed. It needs fresh independent readiness and an explicit new root grant.\n\nRetain all original 545 source pins and 217 proof pins verbatim; add retry preparation and interruption evidence. The comparator changes only its two output-root constants; the supervisor is byte-identical. The normal command and 448/1 MiB, 900+10-second limits are unchanged. The comparator retains 448/1 MiB, 180+10-second limits, all assertions, complete-leaf equality and no peer feature replay. All new outputs are create-only. The first report's terminal absence is never repaired or filled by this attempt. Exactly one new normal invocation is proposed, followed by its comparator only if the new normal invocation is positively verified.\n''')
write(B/'retry-provenance.json',dict(status='PREPARED_RETRY_NOT_EXECUTED',interruptedAttempt=pin(E/'record.json'),originalAttemptOutcome='UNKNOWN',originalAttemptCause='unknown',originalAttemptTerminalAbsent=True,originalAttemptReportAbsent=True,originalKnownInvocations=1,newReportInvocationsAuthorized=0,plannedNewReportInvocations=1,plannedTotalKnownInvocationsIfGranted=2,automaticRetry=False,originalSequence=pin(P/'sequence.json'),originalReadiness=pin('/tmp/renault-review/report-comparison-v2-readiness-v1.json'),originalSourcePins=normal['sourcePins'],retainedOriginalSourcePinCount=545,retainedOriginalProofPinCount=217,originalWrapper=pin(P/'run.py'),retryWrapper=pin(B/'run.py'),comparatorDiff=pin(B/'v2-to-v4-comparator.patch'),comparatorOnlyChange='Two output-root constants: report-comparison-v2 to report-comparison-v4',compilerRetryIncluded=False,currentFullProjectTypeScript='UNPASSED',releaseAcceptanceClaim=False))
for p in B.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
for p in originalFiles:check(p)
print(json.dumps(dict(interruptionRecord=pin(E/'record.json'),retryProvenance=pin(B/'retry-provenance.json'),comparator=pin(B/'compare-report.mjs'),wrapper=pin(B/'run.py'),original545SourcesAnd217ProofsUnchanged=True),indent=2))
