"""Narrow documentary revision: buyer prose only; other after-images exact."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,difflib,ast,copy
P=Path('/tmp/renault-packet/docs-status-v3');B=Path('/tmp/renault-packet/docs-status-v4')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for v in iter(lambda:f.read(1024*1024),b''):h.update(v)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def put(p,b):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb')as f:f.write(b)
def write(p,x):put(p,(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode())
m=read(P/'manifest.json');assert pin(P/'manifest.json')['sha256']=='8f2c8bfbef44d19cf40e5207286428e6bfa06a1ba8623caf7f098f2ced33e302'
for p in m['proofs']:assert pin(p['path'])==p
for row in m['writes']:
 if row['before']:assert pin(row['target'])==row['before']
 else:assert not Path(row['target']).exists()
app=(P/'apply.py').read_text().replace(str(P),str(B));ast.parse(app);put(B/'apply.py',app.encode())
template=(B/'buyer-update.md').read_text();assert template.count('{{COVERAGE_TABLE}}')==1
fmt=Path('/tmp/renault-packet/report-comparison-v4/artifacts/normal-coverage-formatted.txt').read_text();table='\n'.join(x for x in fmt.splitlines()if x.startswith('|'));buyer=template.replace('{{COVERAGE_TABLE}}',table).encode()
patch='';changed=[]
for i,row in enumerate(m['writes']):
 rel=row['relativePath'];oldbytes=b''
 if row['beforeCopy']:oldbytes=Path(row['beforeCopy']['path']).read_bytes();put(B/'before'/rel,oldbytes);row['beforeCopy']=pin(B/'before'/rel)
 priorAfter=row['after'];data=buyer if i==0 else Path(priorAfter['path']).read_bytes();put(B/'after'/rel,data);row['after']=pin(B/'after'/rel)
 if i:assert row['after']['sha256']==priorAfter['sha256']
 elif row['after']['sha256']!=priorAfter['sha256']:changed.append(rel)
 patch+=''.join(difflib.unified_diff(oldbytes.decode().splitlines(True),data.decode().splitlines(True),fromfile=rel+' (before)',tofile=rel+' (after)'))
assert changed==['roadmark-104/docs/RENAULT_M1_UPDATE.md'];put(B/'docs-status.patch',patch.encode())
proofs={p['path']:p for p in m['proofs']}
for p in sorted(P.rglob('*')):
 if p.is_file():proofs[str(p)]=pin(p)
proofs[str(B/'buyer-update.md')]=pin(B/'buyer-update.md')
m.update(preparedAt=datetime.now(timezone.utc).isoformat(),applicator=pin(B/'apply.py'),preparer=pin(__file__),patch=pin(B/'docs-status.patch'),proofs=[proofs[k]for k in sorted(proofs)])
m['historyPreservation']['exactCompleteStatusBeforeSnapshot']=m['writes'][2]['beforeCopy']
m['narrowRevision']=dict(priorManifest=pin(P/'manifest.json'),reason='Independent reviewer requested roughly500–600-word buyer prose for the one-page brief; dense details remain in unchanged progress appendix.',changedAfterImages=changed,otherThreeAfterImagesByteIdentical=True,priorUnappliedPreparationPreserved=True)
ast.parse(Path(__file__).read_text());write(B/'manifest.json',m)
g=read(P/'root-grant-template.json');g['manifest']=pin(B/'manifest.json');write(B/'root-grant-template.json',g)
print(json.dumps(dict(manifest=pin(B/'manifest.json'),buyerWords=len(template.split()),buyerAfter= m['writes'][0]['after'],proofCount=len(proofs),otherThreeAfterImagesByteIdentical=True),indent=2))
