from pathlib import Path
O=Path('/tmp/renault-packet/full-stage-v1');C=Path('/tmp/cupra-packet/full-stage-v2');S=Path('/tmp/renault-packet/selected-preflight-v5')
old=(C/'stage.mjs').read_text();prefix=old[:old.index("const material='/tmp/cupra-packet/typed-preparation-v4';")]
prefix=prefix.replace('CUPRA29 bounded full-stage draft','Renault30 bounded full-stage preparation').replace('derived-prefix20-through-KGM28-then-CUPRA29-no-broad-features','derived-prefix20-through-CUPRA29-then-Renault30-no-broad-features').replace('brandUpdatePackets.length,28','brandUpdatePackets.length,29').replace("brandUpdatePackets.at(-1).id,'m1-kgm-2026-10-15'","brandUpdatePackets.at(-1).id,'m1-cupra-2026-10-15'").replace('m.acceptedKgmCars','m.acceptedCupraCars').replace('m.acceptedKgmFields','m.acceptedCupraFields').replace("[27,'candidate28',427]])","[27,'candidate28',427],[28,'candidate29',430]])")
struct=r'''
const base=data,currentCars=cars,currentFields=fieldStages.candidate29,currentDigests=carStages.candidate29;
const packetPath=m.packet.path,packet=readJson(packetPath),packetSnapshot=structuredClone(packet),expected=readJson(m.expectedReview.path);
assert.equal(fileHash(packetPath),expected.packetSha256);assert.equal(packet.id,'m1-renault-2026-10-15');
const selected=new Set(m.selectedIds),modelIds=new Set(packet.versionGuards.map(g=>g.before.modelId)),before=currentCars.filter(car=>selected.has(car.id)),beforeSnapshot=structuredClone(before);
assert.equal(selected.size,4);assert.equal(before.length,4);assert.deepEqual(before,readJson(m.selectedBefore.path));
for(const prior of brandUpdatePackets){assert.notEqual(prior.brand,'Renault');for(const row of [...prior.facts,...prior.variants,...prior.versionGuards,...prior.availability,...prior.summaries,...(prior.features??[]),...(prior.configurationUpdates??[])])assert(!selected.has(row.variantId??row.id));for(const term of prior.brandTerms??[])assert(term.applicableVariantIds.every(id=>!selected.has(id)));}
const peerCars=currentCars.filter(car=>!selected.has(car.id)),peerIds=new Set(peerCars.map(car=>car.id));assert.equal(peerCars.length,426);
const sourceIdsAdded=new Set(packet.sources.map(source=>source.id));assert.equal(sourceIdsAdded.size,24);assert.equal(packet.sources.length,24);assert.equal(packet.facts.length,92);assert.equal(packet.models.length,0);assert.equal(packet.variants.length,0);
const sourceReferenceProof=[];
function inspectSourceReferences(value,label,pointer=''){if(typeof value==='string'){assert(!sourceIdsAdded.has(value),'New source already referenced '+label+pointer);return;}if(!value||typeof value!=='object')return;for(const [key,item]of Object.entries(value)){assert(!sourceIdsAdded.has(key),'New source already a dictionary key '+label+pointer);inspectSourceReferences(item,label,pointer+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));}}
for(const [label,value]of [['accepted complete research',base],['accepted complete cars',currentCars],['accepted packets',brandUpdatePackets]]){inspectSourceReferences(value,label);sourceReferenceProof.push({input:label,newSourceReferences:0,nestedGradeReviewsAndKeysIncluded:true});}
for(const pin of m.rawOverlayInputs){inspectSourceReferences(require(pin.path),pin.path);sourceReferenceProof.push({input:pin.path,sha256:pin.sha256,newSourceReferences:0,nestedGradeReviewsAndKeysIncluded:true});}
write('source-reference-neutrality',{peerCars:426,helperChanges:false,sourceRowsAdded:24,inspections:sourceReferenceProof,broadFeatureReplay:false});
data=compose(base,packet,[...m.registeredPacketIds,packet.id]);cars=applyBrandUpdates(currentCars,data,[packet]);
assertDeclaredJson(data,'/candidateResearchBeforeDigest',new Set());assertDeclaredJson(cars,'/candidateCarsBeforeDigest',new Set());
const candidateFields=fieldDigests(data),candidateDigests=carDigests(cars),after=cars.filter(car=>selected.has(car.id)),afterSnapshot=structuredClone(after);
assert.equal(cars.length,430);assert.equal(data.variants.length,430);assert.equal(after.length,4);assert.deepEqual(after,readJson(m.selectedAfter.path));
fullResearchExact(base,currentFields,'baseResearch');fullCarsExact(currentCars,currentDigests,'currentCars');
assert.deepEqual(data.sources.slice(0,base.sources.length),base.sources);assert.deepEqual(data.sources.slice(base.sources.length),packet.sources);
for(const key of Object.keys(base))if(!['metadata','sources','variants'].includes(key))assert.deepEqual(data[key],base[key],key);
const expectedMetadata={...base.metadata,brand_update_packet_ids:[...m.registeredPacketIds,packet.id]};assert.deepEqual(data.metadata,expectedMetadata);
assert.deepEqual(data.variants.map(row=>row.id),base.variants.map(row=>row.id));
for(let i=0;i<data.variants.length;i++){
 const old=base.variants[i],actual=data.variants[i],edit=packet.availability.find(row=>row.variantId===old.id);
 assert.deepEqual(actual,edit?{...old,record_state:edit.after.availability,availability_evidence:edit.after.evidence}:old);
}
assert.deepEqual(cars.map(car=>car.id),currentCars.map(car=>car.id));assert.deepEqual(cars.filter(car=>peerIds.has(car.id)),peerCars);
assert.deepEqual(candidateDigests.filter(row=>peerIds.has(row.id)),currentDigests.filter(row=>peerIds.has(row.id)));
const changedIds=candidateDigests.filter((row,i)=>row.sha256!==currentDigests[i].sha256).map(row=>row.id);assert.deepEqual(new Set(changedIds),selected);
const unchangedPeers=426,reads=Object.entries(currentFields).map(([field,ref])=>({field,inputRows:ref.rows,retainedRows:ref.rows,sha256:ref.sha256,scope:'Full accepted structural research composition; effective feature replay only for four selected retained Renault cars'}));
assert.equal(packet.versionGuards.length,4);assert.equal(packet.brandTerms.reduce((n,t)=>n+t.applicableVariantIds.length,0),12);assert.equal(packet.availability.length,4);assert.equal(packet.summaries.length,4);
'''
selected=(S/'check.mjs').read_text();selected=selected[selected.index('for(const guard of packet.versionGuards)'):selected.index("console.log(JSON.stringify({status:result.status")]
selected=selected.replace("const {isOnSale,isCurrentListEligible,buildCoverageReport}","const {isOnSale,isCurrentListEligible,isTierOne,buildCoverageReport}")
selected=selected.replace('const progress=selectedCoverage.brandProgress.find','const selectedBrandProgress=selectedCoverage.brandProgress.find').replace('assert(progress);','assert(selectedBrandProgress);').replace('progress.currentVersionReviews','selectedBrandProgress.currentVersionReviews').replace('progress.unreviewedCoreGrades','selectedBrandProgress.unreviewedCoreGrades').replace('progress.missingSummaries','selectedBrandProgress.missingSummaries').replace('progress.criteria','selectedBrandProgress.criteria')
for form in ['deepStrictEqual','deepEqual']:
 selected=selected.replace(f'assert.{form}(base,baseSnapshot);',"fullResearchExact(base,currentFields,'baseResearch');").replace(f'assert.{form}(data,dataSnapshot);',"fullResearchExact(data,candidateFields,'candidateResearch');")
assert 'dataSnapshot' not in selected and 'baseSnapshot' not in selected
# Mutant helper calls clone only selected variant/feature/model rows, retaining complete global issue/source context.
selected=selected.replace('const negativeProof=[];','''const negativeResearch={...data,models:data.models.filter(row=>modelIds.has(row.id)),variants:data.variants.filter(row=>selected.has(row.id)),feature_evidence_variant_context:data.feature_evidence_variant_context.filter(row=>selected.has(row.id)),feature_evidence:data.feature_evidence.filter(row=>selected.has(row.variant_id)),trim_equipment:data.trim_equipment.filter(row=>selected.has(row.variant_id)),update_eligibility:data.update_eligibility.filter(row=>selected.has(row.variant_id))};
assert.equal(negativeResearch.variants.length,4);assert.equal(negativeResearch.feature_evidence.length,276);
const negativeProof=[];''').replace('research:structuredClone(data),packet:structuredClone(packet)','research:structuredClone(negativeResearch),packet:structuredClone(packet)').replace("inputsUnchanged:true});\n}","inputsUnchanged:true});global.gc();\n}")
selected=selected.replace("const reconciliation=readJson(expected.reconciliation.path);","const reconciliation=readJson(m.reconciliation.path);")
accepted=r'''
progress('Four selected packs,104 fact/term claims,276 feature claims,150 pair cases and seven guard rejections proved');
const acceptedSelected=readJson(m.selectedResult.path);assert.equal(acceptedSelected.status,'selected_actual_consumers_and_exact_serialization_witness_pass');assert.equal(acceptedSelected.packetSha256,m.packet.sha256);
for(const [name,pin]of Object.entries(m.selectedArtifacts))assert.equal(fileHash(out+'/'+name),pin.sha256,'Exact selected written artifact '+name);
const acceptedWrittenPacks=readJson(m.selectedArtifacts['selected-packs.json'].path);
const acceptedWrittenClaims=readJson(m.selectedArtifacts['claims.json'].path),acceptedWrittenFeatureClaims=readJson(m.selectedArtifacts['feature-claims.json'].path),acceptedAvailabilityClaims=readJson(m.selectedArtifacts['availability-claims.json'].path);
assert.deepEqual(claims,acceptedWrittenClaims.map(row=>({variantId:row.variantId,key:row.key,claim:factClaim(acceptedWrittenPacks[row.variantId],acceptedWrittenPacks[row.variantId].car.facts[row.key],m.asOf)})));
assert.deepEqual(featureClaims,acceptedWrittenFeatureClaims.map(row=>({variantId:row.variantId,criterion:row.criterion,claim:featureClaim(acceptedWrittenPacks[row.variantId],row.criterion,row.criterion,m.asOf)})));
assert.deepEqual(availabilityClaims,acceptedAvailabilityClaims.map(row=>({variantId:row.variantId,claim:factClaim(acceptedWrittenPacks[row.variantId],availabilityReportClaim(acceptedWrittenPacks[row.variantId].car),m.asOf)})));
assert.deepEqual(observations,acceptedSelected.optionalFeaturePaths);assert.deepEqual(claimOmissions,acceptedSelected.optionalCitationPaths);assert.deepEqual(readJson(out+'/result.json').selectedCoverage,acceptedSelected.selectedCoverage);assert.deepEqual(comparisonProof,acceptedSelected.comparisonProof);assert.deepEqual(negativeProof,acceptedSelected.negativeProof);
'''
rank=old[old.index('// Full structural ranking comparison:'):old.index('// Actual global C1 only:')]
a=rank.index('for(const attribute of attributes){');rank=rank[:a]+r'''for(const attribute of attributes){
 const old=rankAttribute(currentCars,base.sources,attribute.key,policy),next=rankAttribute(cars,data.sources,attribute.key,policy),selectedRanking=rankAttribute(after,data.sources,attribute.key,policy);
 const buckets=new Map();
 for(const group of old.groups){const entries=group.entries.filter(row=>peerIds.has(row.car.id));if(entries.length)buckets.set(groupKey(group),{...group,entries});}
 for(const group of selectedRanking.groups){const key=groupKey(group),prior=buckets.get(key);if(prior)prior.entries.push(...group.entries);else buckets.set(key,{...group,entries:[...group.entries]});}
 const memberGroup=new Map();for(const [key,group]of buckets)for(const entry of group.entries){assert(!memberGroup.has(entry.car.id));memberGroup.set(entry.car.id,key);}
 const insertionKeys=[];for(const car of cars){const key=memberGroup.get(car.id);if(key&&!insertionKeys.includes(key))insertionKeys.push(key);}
 const expectedGroups=insertionKeys.map(key=>buckets.get(key));
 for(const group of expectedGroups){
  group.entries.sort((a,b)=>(Number(a.fact.value)-Number(b.fact.value))*(attribute.direction==='lower'?1:-1)||a.car.id.localeCompare(b.car.id));
  group.entries=group.entries.map(entry=>({...entry,rank:group.entries.findIndex(row=>Number(row.fact.value)===Number(entry.fact.value))+1,tied:group.entries.filter(row=>Number(row.fact.value)===Number(entry.fact.value)).length>1}));
 }
 expectedGroups.sort(groupCompare);assert.deepEqual(next.groups,expectedGroups,'Complete compatible groups equal unchanged peer entries plus exact selected entries');
 const exclusionById=new Map([...old.excluded.filter(row=>peerIds.has(row.carId)),...selectedRanking.excluded].map(row=>[row.carId,row]));
 const expectedExcluded=cars.filter(car=>exclusionById.has(car.id)).map(car=>exclusionById.get(car.id));assert.deepEqual(next.excluded,expectedExcluded,'Complete exclusions preserve actual catalogue traversal order');
 const expectedUnranked=[...old.unranked.filter(row=>peerIds.has(row.car.id)),...selectedRanking.unranked].sort(alphabetical);assert.deepEqual(next.unranked,expectedUnranked,'Complete unranked entries equal unchanged peers plus selected, in verified alphabetical order');
 const beforeRecords=rankingRecords(old,currentDigests),afterRecords=rankingRecords(next,candidateDigests),selectedRecords=rankingRecords(selectedRanking,candidateDigests);
 assertDeclaredJson(beforeRecords,'/beforeRankingRecords',new Set());assertDeclaredJson(afterRecords,'/afterRankingRecords',new Set());assertDeclaredJson(selectedRecords,'/selectedRankingRecords',new Set());
 const a=groupProof(old,currentCars,attribute),b=groupProof(next,cars,attribute),aBy=new Map(a.groups.map(group=>[group.key,group])),bBy=new Map(b.groups.map(group=>[group.key,group]));
 for(const key of new Set([...aBy.keys(),...bBy.keys()])){
  const oldGroup=aBy.get(key),newGroup=bBy.get(key),oldPeers=oldGroup?.peerIds??[],newPeers=newGroup?.peerIds??[];
  assert.deepEqual(newPeers,oldPeers,'Peer order within compatible group '+attribute.key+'/'+key);
  assert.equal(newGroup?.count??0,(oldGroup?.count??0)-(oldGroup?.selectedIds.length??0)+(newGroup?.selectedIds.length??0));
 }
 assert.deepEqual(next.excluded.filter(row=>peerIds.has(row.carId)),old.excluded.filter(row=>peerIds.has(row.carId)));
 assert.deepEqual(next.unranked.filter(row=>peerIds.has(row.car.id)),old.unranked.filter(row=>peerIds.has(row.car.id)));
 assert.deepEqual(new Set(b.groups.flatMap(group=>group.selectedIds)),new Set(expected.rankingIds[attribute.key]));
 globalRankProof.push({attribute:attribute.key,completeOrderedBefore:beforeRecords,completeOrderedAfter:afterRecords,completeSelectedRecords:selectedRecords,fullGroupsEqualUnchangedPeersPlusSelected:true,fullExcludedInCatalogueOrder:true,fullUnrankedEqualAlphabeticalPeersPlusSelected:true,productionAlphabeticalComparator:alphabeticalSource,fullCarDigestBindingsVerified:true,before:a,after:b,peerExclusions:next.excluded.filter(row=>peerIds.has(row.carId)),peerMembershipAndWithinGroupOrderExact:true,productionGroupComparator:comparatorSource,insertionTiesProvedFromActualInputOrder:true,selectedCountDeltasExact:true});
}
write('global-ranking-comparison',globalRankProof);
'''
c1=old[old.index('// Actual global C1 only:'):old.index('assert.equal(baselineC1.reviewedModels,103);')]
c1=c1.replace('actualPaths.length,28','actualPaths.length,29').replace('const {combineM1Reconciliations,inventoryRecordId}','const {combineM1Reconciliations}').replace('m.acceptedKgmC1','m.acceptedCupraC1')
end=r'''
assert.equal(baselineC1.reviewedModels,103);assert.equal(baselineC1.reviewedVersions,234);assert.equal(globalC1.reviewedModels,105);assert.equal(globalC1.reviewedVersions,238);assert.equal(globalC1.registryValid,true);assert.equal(globalC1.pass,false);
const nonRenaultIssue=issue=>issue.brand!=='Renault'&&!selected.has(issue.reference)&&!['record:renault-megane-e-tech','record:renault-scenic-e-tech'].includes(issue.reference);
assert.deepEqual(globalC1.issues.filter(nonRenaultIssue),baselineC1.issues.filter(nonRenaultIssue));
assert.deepEqual(baselineC1.issues.filter(issue=>!nonRenaultIssue(issue)).map(issue=>issue.reference),[...selected,'record:renault-megane-e-tech','record:renault-scenic-e-tech']);
assert.deepEqual(globalC1.issues.filter(issue=>!nonRenaultIssue(issue)).map(issue=>issue.reference),['record:renault-megane-e-tech']);
for(const list of [currentCars,cars]){assert.equal(list.length,430);assert.equal(list.filter(isTierOne).length,353);assert.equal(list.filter(isTierOne).filter(isOnSale).length,312);}
const expectedGlobalEvidence=structuredClone(baselineWritten.evidence);assert.deepEqual(Object.keys(expectedGlobalEvidence).sort(),Object.keys(reconciliation).sort());expectedGlobalEvidence.checkedAt=[baselineWritten.evidence.checkedAt,reconciliation.checkedAt].sort().at(-1);
for(const key of ['notes','publishedLists','currentVersionReviews','listResolutions','catalogueOnlyDifferences','inventoryResolutions'])expectedGlobalEvidence[key]=[...baselineWritten.evidence[key],...reconciliation[key]];
assert.deepEqual(proposedReconciliation,expectedGlobalEvidence);
const expectedIssues=baselineWritten.issues.filter(issue=>!(issue.code==='version_unreviewed'&&selected.has(issue.reference))&&!(issue.code==='inventory_unresolved'&&issue.reference==='record:renault-scenic-e-tech'));
const originalInventoryOrder=[...allInventory.records.filter(record=>!record.vehicleClass||['passenger','ute'].includes(record.vehicleClass)).map(record=>'record:'+inventoryRecordId(record)),...allInventory.unverifiedLeads.filter(record=>!record.vehicleClass||['passenger','ute'].includes(record.vehicleClass)).map(record=>'lead:'+inventoryRecordId(record))];
const allExpectedSettlements=new Set([...baselineWritten.settledInventory,'record:renault-scenic-e-tech']);
const expectedGlobalWritten={...structuredClone(baselineWritten),registryCheckedAt:expectedGlobalEvidence.checkedAt,reviewedModels:105,reviewedVersions:238,reviewedVersionIds:[...baselineWritten.reviewedVersionIds,...m.selectedIds],validModelReviewIds:[...baselineWritten.validModelReviewIds,...reconciliation.currentVersionReviews.map(review=>review.id)],settledInventory:originalInventoryOrder.filter(id=>allExpectedSettlements.has(id)),issues:expectedIssues,evidence:expectedGlobalEvidence};
assert.equal(expectedGlobalWritten.settledInventory.length,baselineWritten.settledInventory.length+1);assert.equal(expectedGlobalWritten.issues.length,baselineWritten.issues.length-5);
const globalWritten=c1Written(globalC1,'globalC1');assert.deepEqual(globalWritten,expectedGlobalWritten,'Complete proposed C1 equality, all counters, exact issue order and evidence arrays');
assert(reconciliation.notes.some(note=>note.includes('R5 Turbo 3E')&&note.includes('unresolved')));assert(!reconciliation.currentVersionReviews.some(review=>/Turbo|Renault 5/.test(review.model)));assert(!reconciliation.inventoryResolutions.some(row=>/r5|renault-5/.test(row.inventoryId)));
write('baseline-global-c1',baselineC1);write('global-c1-comparison',{before:baselineWritten,after:globalWritten,expectedCompleteAfter:expectedGlobalWritten,completeExpectedWrittenEquality:true,baselineMatchesAcceptedCupraAndNormal:true,nonRenaultIssuesReviewsDispositionsExact:true,issueOwnership,normalFullReportRun:false,meganeResidualUnresolved:true,r5TurboConflictRetainedWithoutFabricatedInventoryId:true});
progress('Global compatible-group rankings and complete expected C1 gaps proved without broad features');
fullResearchExact(base,currentFields,'baseResearch');fullCarsExact(currentCars,currentDigests,'currentCars');fullResearchExact(data,candidateFields,'candidateResearch');fullCarsExact(cars,candidateDigests,'candidateCars');assert.deepEqual(before,beforeSnapshot);assert.deepEqual(after,afterSnapshot);assert.deepEqual(packet,packetSnapshot);assert.deepEqual(afterPacks,snapshot);assert.equal(defaultCalls,0);
for(const file of ['src/lib/data.ts','src/lib/catalogue.ts','src/lib/research.ts','scripts/reporting/load.ts'])assert(!require.cache[repo+'/'+file]);checkPins();
write('metadata-composition',transitions);write('car-digest-comparison',{...carStages,candidate30:candidateDigests});write('research-field-digests',{...fieldStages,candidate30:candidateFields});
write('stage-receipt',{status:'bounded_structural_selected_stage_pass_pending_independent_review',manifestSha256:args[3],packetSha256:m.packet.sha256,originalBaselineCars:409,acceptedCurrentCars:430,stagedCars:430,tierOneVersions:353,onSaleVersions:312,untouchedPeerCars:426,changedRetainedCars:4,newModels:0,newVersions:0,versionUpdates:0,configurationUpdates:0,manualFeatureUpdates:0,sourceRowsAdded:24,allAcceptedStagesThroughCupra29ExactlyReproduced:true,all14ResearchFieldsProved:true,strictJsonShapeBeforeDigest:true,all21RetainedStorageFilesPinnedBeforeAndAfter:true,completeGlobalC1ExpectedEquality:true,actualSelectedCars:4,actualFactAndTermClaims:earnedCells,actualFeatureClaims:featureClaims.length,roadsideCanonicalProjections:4,roadsideFactAndFeatureClaimText:'5 years',pairComparisonCases:comparisonProof.length,intendedNegativeRejections:negativeProof.length,actualOptionalWitnessesExact:true,inMemoryPortableExact:true,writtenPortableExact:true,writtenClaimReadback:true,selectedC1:c1Written(c1,'selectedC1'),globalC1Counts:{reviewedModels:globalC1.reviewedModels,reviewedVersions:globalC1.reviewedVersions,pass:globalC1.pass},sourceAdditionsDoNotReviveAcceptedReferences:true,allPeerDigestsAndIdentitiesExact:true,peerOrderExactWithinCompatibleRankingGroups:true,productionGroupSortingAndInsertionTieProvenance:true,broadFeatureReplay:false,normalFullReportRun:false,normalFullReportRequiredAfterGuardedIntegration:true,defaultLoaderCalls:defaultCalls,liveSourceEdits:false,productionRegistration:false,currentProjectTypeScript:'UNPASSED; no compiler retry',resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log(JSON.stringify({status:'passed',receipt:out+'/stage-receipt.json',sha256:fileHash(out+'/stage-receipt.json'),noBroadFeatureReplay:true}));
'''
with (O/'stage.mjs').open('x') as f:f.write(prefix+struct+selected+accepted+rank+c1+end)
with (O/'run.py').open('x') as f:f.write((C/'run.py').read_text().replace('run_single_bounded_cupra_full_stage','run_single_bounded_renault_full_stage'))
with (O/'storage-read-closure.json').open('xb') as f:f.write((C/'storage-read-closure.json').read_bytes())
syntax=(C/'check-syntax.py').read_text().replace(str(C),str(O)).replace("authorization='Include a bounded syntax-only check in preparation so obvious parse errors are caught without a runtime stage attempt.'","authorization='Root requested syntax checking the composed Renault full-stage harness before readiness; no stage or compiler execution.'")
with (O/'check-syntax.py').open('x') as f:f.write(syntax)
print('Prepared full-stage composition, no runtime executed; syntax-only check is next.')
