/** Renault30 bounded full-stage preparation: no broad effective-feature replay or normal report. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {fileHash,readJson,readResearch,digestRows,assertResearchUnchanged} from '/tmp/xpeng-staging-plan/baseline-io.mjs';
import {readCompleteCars} from '/tmp/mercedes-staging-plan/staging-preparation/shape-first-v3/read-complete-storage.mjs';
import {assertDeclaredJson} from '/tmp/mercedes-staging-plan/consumer-preparation/v5/feature-json-parity.mjs';
const args=process.argv.slice(2);assert.equal(args.length,4);assert.equal(args[0],'--manifest');assert.equal(args[2],'--manifest-sha256');assert.equal(fileHash(args[1]),args[3]);
const m=readJson(args[1]),repo=m.repo,out=m.output,pins=m.pins;
assert.equal(process.cwd(),repo);assert.equal(process.env.NODE_OPTIONS,undefined);assert.equal(typeof global.gc,'function');assert.equal(process.version,m.nodeVersion);assert.deepEqual(process.execArgv,m.execArgv);
assert.equal(m.mode,'derived-prefix20-through-CUPRA29-then-Renault30-no-broad-features');assert.equal(m.productionRegistrationAuthorized,false);assert.equal(m.canonicalRecaptureAuthorized,false);assert.equal(m.normalFullReportInStage,false);
function checkPins(){for(const p of pins){assert.equal(fs.statSync(p.path).size,p.bytes);assert.equal(fileHash(p.path),p.sha256,p.path);}}
checkPins();assert(!fs.existsSync(out));fs.mkdirSync(out);
function write(name,obj){fs.writeFileSync(out+'/'+name+'.json',JSON.stringify(obj,null,2)+'\n',{flag:'wx'});}
function progress(phase){const fd=fs.openSync(path.join(m.runOutput,'progress.jsonl'),'a');try{fs.writeSync(fd,JSON.stringify({at:new Date().toISOString(),phase})+'\n');fs.fsyncSync(fd);}finally{fs.closeSync(fd);}console.log(phase);}
const fieldDigests=data=>Object.fromEntries(Object.entries(data).map(([key,value])=>[key,digestRows(Array.isArray(value)?value:[value])])),carDigests=cars=>cars.map(car=>({id:car.id,...digestRows([car])}));
function fullResearchExact(data,expected,label){assertDeclaredJson(data,'/'+label,new Set());assert.deepStrictEqual(fieldDigests(data),expected);}
function fullCarsExact(cars,expected,label){assertDeclaredJson(cars,'/'+label,new Set());assert.deepStrictEqual(carDigests(cars),expected);}
progress('Restoring accepted retained409/prefix20 once');
const accepted=readJson(m.acceptedManifest.path),anchors=accepted.anchors,inputPins=new Map(accepted.inputPins.map(row=>[row.anchor+'\0'+row.file,row]));
const storageClosure=readJson(m.storageClosure.path),storagePins=new Map(storageClosure.map(pin=>[pin.path,pin])),storageReads=new Set();
assert.equal(storagePins.size,21);
const proof={anchors,assertPinned(ref){
 const pin=inputPins.get(ref.anchor+'\0'+ref.file);assert(pin);assert.equal(ref.sha256,pin.sha256);assert.equal(ref.bytes,pin.bytes);
 const absolute=path.resolve(anchors[ref.anchor],ref.file),terminalPin=storagePins.get(absolute);assert(terminalPin,'Actual retained input missing terminal pin '+absolute);
 assert.equal(terminalPin.sha256,ref.sha256);assert.equal(terminalPin.bytes,ref.bytes);assert(pins.some(pin=>pin.path===absolute&&pin.sha256===ref.sha256&&pin.bytes===ref.bytes));storageReads.add(absolute);
}};
let restored=await readCompleteCars(proof,m.storageIndex),cars=restored.cars;const index=restored.index;restored=null;
assert.equal(cars.length,409);for(const ref of Object.values(index.research))proof.assertPinned(ref);
let data=await readResearch(anchors,index,Object.keys(index.research));assert.equal(Object.keys(data).length,14);assertDeclaredJson(data,'/initialResearch',new Set());assertDeclaredJson(cars,'/initialCars',new Set());assertResearchUnchanged(data,index);assert.deepStrictEqual(data.variants.map(row=>row.id),cars.map(car=>car.id));
assert.deepStrictEqual([...storageReads].sort(),[...storagePins.keys()].sort());
write('retained-storage-read-closure',{actualReadFiles:[...storageReads].sort(),all21FilesPinnedBeforeAndAfter:true,rootStorageIndex:m.storageIndex,acceptedManifest:m.acceptedManifest});
const require=createRequire(repo+'/package.json'),brand=require('./src/lib/brand-updates.ts');
const {prepareBrandResearch,applyBrandUpdates,brandVersionSnapshot,applyBrandFeatureUpdates,applyBrandTermFeatures}=brand;
const {brandUpdatePackets}=require('./src/lib/brand-update-registry.ts');assert.equal(brandUpdatePackets.length,29);assert.deepStrictEqual(brandUpdatePackets.map(p=>p.id),m.registeredPacketIds);assert.equal(brandUpdatePackets.at(-1).id,'m1-cupra-2026-10-15');assert.deepStrictEqual(data.metadata.brand_update_packet_ids,m.registeredPacketIds.slice(0,20));
const acceptedCarStages=readJson(m.acceptedCupraCars.path),acceptedFieldStages=readJson(m.acceptedCupraFields.path),carStages={baseline20:carDigests(cars)},fieldStages={baseline20:fieldDigests(data)},transitions=[];
fullResearchExact(data,acceptedFieldStages.baseline20,'baseline20Research');fullCarsExact(cars,acceptedCarStages.baseline20,'baseline20Cars');
function compose(base,p,ids){const raw=prepareBrandResearch(base,[p]);assert.deepStrictEqual(Object.keys(raw),Object.keys(base));assert.deepStrictEqual(raw.metadata.brand_update_packet_ids,[p.id]);const result={...raw,metadata:{...raw.metadata,brand_update_packet_ids:ids}};for(const key of Object.keys(raw))if(key!=='metadata')assert.equal(result[key],raw[key]);transitions.push({packetId:p.id,beforeMetadata:digestRows([base.metadata]),rawMetadata:structuredClone(raw.metadata),composedMetadata:structuredClone(result.metadata),onlyCompositionPath:'metadata.brand_update_packet_ids'});return result;}
for(const [offset,stage,count]of [[20,'corrected21',409],[21,'current22',413],[22,'current23',413],[23,'current24',417],[24,'candidate25',427],[25,'candidate26',427],[26,'candidate27',427],[27,'candidate28',427],[28,'candidate29',430]]){
 const packet=brandUpdatePackets[offset],priorData=data,priorCars=cars,priorFields=fieldDigests(data),priorDigests=carDigests(cars);
 data=compose(priorData,packet,m.registeredPacketIds.slice(0,offset+1));cars=applyBrandUpdates(priorCars,data,[packet]);assert.equal(cars.length,count);assert.equal(data.variants.length,count);assert.deepStrictEqual(data.variants.map(row=>row.id),cars.map(car=>car.id));
 fullResearchExact(priorData,priorFields,'priorResearch');fullCarsExact(priorCars,priorDigests,'priorCars');
 fullResearchExact(data,acceptedFieldStages[stage],stage+'Research');fullCarsExact(cars,acceptedCarStages[stage],stage+'Cars');
 carStages[stage]=carDigests(cars);fieldStages[stage]=fieldDigests(data);global.gc();progress('Accepted '+stage+' complete-car and all14-field digests reproduced');
}


const base=data,currentCars=cars,currentFields=fieldStages.candidate29,currentDigests=carStages.candidate29;
const packetPath=m.packet.path,packet=readJson(packetPath),packetSnapshot=structuredClone(packet),expected=readJson(m.expectedReview.path);
assert.equal(fileHash(packetPath),expected.packetSha256);assert.equal(packet.id,'m1-renault-2026-10-15');
const selected=new Set(m.selectedIds),modelIds=new Set(packet.versionGuards.map(g=>g.before.modelId)),before=currentCars.filter(car=>selected.has(car.id)),beforeSnapshot=structuredClone(before);
assert.equal(selected.size,4);assert.equal(before.length,4);assert.deepEqual(before,readJson(m.selectedBefore.path));
for(const prior of brandUpdatePackets){assert.notEqual(prior.brand,'Renault');for(const row of [...prior.facts,...prior.variants,...prior.versionGuards,...prior.availability,...prior.summaries,...(prior.features??[]),...(prior.configurationUpdates??[])])assert(!selected.has(row.variantId??row.id));for(const term of prior.brandTerms??[])assert(term.applicableVariantIds.every(id=>!selected.has(id)));}
const peerCars=currentCars.filter(car=>!selected.has(car.id)),peerIds=new Set(peerCars.map(car=>car.id));assert.equal(peerCars.length,426);
const sourceIdsAdded=new Set(packet.sources.map(source=>source.id));assert.equal(sourceIdsAdded.size,24);assert.equal(packet.sources.length,24);assert.equal(packet.facts.length,92);assert.equal(packet.models.length,0);assert.equal(packet.variants.length,0);
const sourceReferenceProof=[];
function inspectSourceReferences(value,label,pointer=''){if(typeof value==='string'){assert(!sourceIdsAdded.has(value),'New source already referenced '+label+pointer);return;}if(!value||typeof value!=='object')return;for(const [key,item]of Object.entries(value)){assert(!sourceIdsAdded.has(key),'New source already a dictionary key '+label+pointer);inspectSourceReferences(item,label,pointer+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));}}
for(const [label,value]of [['accepted complete research',base],['accepted complete cars',currentCars],['accepted packets',brandUpdatePackets]]){inspectSourceReferences(value,label);sourceReferenceProof.push({input:label,newSourceReferences:0,nestedGradeReviewsAndKeysIncluded:true});}
for(const pin of m.rawOverlayInputs){inspectSourceReferences(require(pin.path),pin.path);sourceReferenceProof.push({input:pin.path,sha256:pin.sha256,newSourceReferences:0,nestedGradeReviewsAndKeysIncluded:true});}
write('source-reference-neutrality',{peerCars:426,helperChanges:false,sourceRowsAdded:24,inspections:sourceReferenceProof,broadFeatureReplay:false});
data=compose(base,packet,[...m.registeredPacketIds,packet.id]);cars=applyBrandUpdates(currentCars,data,[packet]);
assertDeclaredJson(data,'/candidateResearchBeforeDigest',new Set());assertDeclaredJson(cars,'/candidateCarsBeforeDigest',new Set());
const candidateFields=fieldDigests(data),candidateDigests=carDigests(cars),after=cars.filter(car=>selected.has(car.id)),afterSnapshot=structuredClone(after);
assert.equal(cars.length,430);assert.equal(data.variants.length,430);assert.equal(after.length,4);assert.deepEqual(after,readJson(m.selectedAfter.path));
fullResearchExact(base,currentFields,'baseResearch');fullCarsExact(currentCars,currentDigests,'currentCars');
assert.deepEqual(data.sources.slice(0,base.sources.length),base.sources);assert.deepEqual(data.sources.slice(base.sources.length),packet.sources);
for(const key of Object.keys(base))if(!['metadata','sources','variants'].includes(key))assert.deepEqual(data[key],base[key],key);
const expectedMetadata={...base.metadata,brand_update_packet_ids:[...m.registeredPacketIds,packet.id]};assert.deepEqual(data.metadata,expectedMetadata);
assert.deepEqual(data.variants.map(row=>row.id),base.variants.map(row=>row.id));
for(let i=0;i<data.variants.length;i++){
 const old=base.variants[i],actual=data.variants[i],edit=packet.availability.find(row=>row.variantId===old.id);
 assert.deepEqual(actual,edit?{...old,record_state:edit.after.availability,availability_evidence:edit.after.evidence}:old);
}
assert.deepEqual(cars.map(car=>car.id),currentCars.map(car=>car.id));assert.deepEqual(cars.filter(car=>peerIds.has(car.id)),peerCars);
assert.deepEqual(candidateDigests.filter(row=>peerIds.has(row.id)),currentDigests.filter(row=>peerIds.has(row.id)));
const changedIds=candidateDigests.filter((row,i)=>row.sha256!==currentDigests[i].sha256).map(row=>row.id);assert.deepEqual(new Set(changedIds),selected);
const unchangedPeers=426,reads=Object.entries(currentFields).map(([field,ref])=>({field,inputRows:ref.rows,retainedRows:ref.rows,sha256:ref.sha256,scope:'Full accepted structural research composition; effective feature replay only for four selected retained Renault cars'}));
assert.equal(packet.versionGuards.length,4);assert.equal(packet.brandTerms.reduce((n,t)=>n+t.applicableVariantIds.length,0),12);assert.equal(packet.availability.length,4);assert.equal(packet.summaries.length,4);
for(const guard of packet.versionGuards)assert.deepEqual(brandVersionSnapshot(before.find(c=>c.id===guard.variantId)),guard.before);
for(const edit of packet.facts){assert.deepEqual(before.find(c=>c.id===edit.variantId).facts[edit.after.key]??null,edit.before);assert.deepEqual(after.find(c=>c.id===edit.variantId).facts[edit.after.key],edit.after);}
for(const term of packet.brandTerms)for(const id of term.applicableVariantIds){assert.deepEqual(before.find(c=>c.id===id).facts[term.key]??null,term.before[id]);assert.deepEqual(after.find(c=>c.id===id).facts[term.key],term.fact);}
for(const car of after){
 const prior=before.find(c=>c.id===car.id);
 assert.deepStrictEqual(car.configurationEvidence,prior.configurationEvidence);
 assert.deepStrictEqual(brandVersionSnapshot(car),brandVersionSnapshot(prior));
}
for(const key of ['variants','models','versionUpdates','features','configurationUpdates'])assert.equal(packet[key].length,0);
for(const edit of packet.availability){
 const b=before.find(c=>c.id===edit.variantId),a=after.find(c=>c.id===edit.variantId);
 assert.deepEqual({availability:b.availability,evidence:b.availabilityEvidence},edit.before);
 assert.deepEqual({availability:a.availability,evidence:a.availabilityEvidence},edit.after);
}
for(const edit of packet.summaries){
 const car=after.find(c=>c.id===edit.variantId);
 for(const side of ['strength','tradeoff']){
  assert.equal(car.buyerSummary[side].label,edit[side].label);assert.equal(car.buyerSummary[side].text,edit[side].text);
  const expectedFreshness=edit[side].dependencies.flatMap(({expected:f})=>[f.date,...f.sourceIds.map(id=>data.sources.find(source=>source.id===id).accessed_date)].map(checkedAt=>({checkedAt,key:f.key,...(f.modelYearChangedAt?{modelYearChangedAt:f.modelYearChangedAt}:{})})));
  assert.deepStrictEqual(car.buyerSummary[side].freshness,expectedFreshness);
  const expectedClauseSourceIds=[...new Set(edit[side].dependencies.flatMap(({expected:f})=>f.sourceIds))];
  assert.deepStrictEqual(car.buyerSummary[side].sourceIds,expectedClauseSourceIds);
  for(const dep of edit[side].dependencies){assert.deepEqual(car.facts[dep.key],dep.expected);assert.notEqual(dep.expected.value,null);assert.equal(dep.expected.issues.length,0);}
 }
 const expectedGuardSourceIds=[...new Set(['strength','tradeoff'].flatMap(side=>edit[side].dependencies.flatMap(({expected:f})=>f.sourceIds)))];
 assert.deepStrictEqual(car.buyerSummary.guardSourceIds,expectedGuardSourceIds);
 assert.deepStrictEqual(car.buyerSummary.expectedSourceSnapshots,packet.sources.filter(source=>expectedGuardSourceIds.includes(source.id)));
 assert.deepStrictEqual(car.buyerSummary.conditions,edit.conditions??[]);
 assert.equal(car.buyerSummary.checkedAt,packet.reviewedAt);
}
// Each selected-only mutation must hit its intended guard and leave its supplied inputs untouched.
const negativeResearch={...data,models:data.models.filter(row=>modelIds.has(row.id)),variants:data.variants.filter(row=>selected.has(row.id)),feature_evidence_variant_context:data.feature_evidence_variant_context.filter(row=>selected.has(row.id)),feature_evidence:data.feature_evidence.filter(row=>selected.has(row.variant_id)),trim_equipment:data.trim_equipment.filter(row=>selected.has(row.variant_id)),update_eligibility:data.update_eligibility.filter(row=>selected.has(row.variant_id))};
assert.equal(negativeResearch.variants.length,4);assert.equal(negativeResearch.feature_evidence.length,276);
const negativeProof=[];
function rejectMutation(name,mutate,pattern){
 const input={cars:structuredClone(before),research:structuredClone(negativeResearch),packet:structuredClone(packet)};
 mutate(input);const snapshot=structuredClone(input);let error;
 try{applyBrandUpdates(input.cars,input.research,[input.packet]);}catch(caught){error=caught;}
 assert(error instanceof Error,`${name}: intended invalid input was accepted`);assert.match(error.message,pattern,`${name}: wrong rejection path`);
 assert.deepEqual(input,snapshot,`${name}: rejection mutated supplied inputs`);
 negativeProof.push({name,actualError:error.message,expectedErrorPattern:pattern.source,rejected:true,inputsUnchanged:true});global.gc();
}
rejectMutation('exact identity guard',({packet:p})=>{p.versionGuards[0].before.trim+=' changed';},/Brand update: reviewed version changed:/);
rejectMutation('specific fact beforeguard',({packet:p})=>{p.facts[0].before.qualifications.push('changed beforeguard');},/Brand update: fact before snapshot changed:.*\/price_aud$/);
rejectMutation('shared warranty beforeguard',({packet:p})=>{p.brandTerms[0].before[p.versionGuards[0].variantId].value='changed beforeguard';},/Brand update: fact before snapshot changed:.*\/warranty$/);
rejectMutation('availability beforeguard',({packet:p})=>{p.availability[0].before.evidence.qualifications.push('changed beforeguard');},/Availability correction conflict .*reviewed snapshot changed or variant missing/);
rejectMutation('summary exact dependency',({packet:p})=>{p.summaries[0].strength.dependencies[0].expected.value=999;},/Brand update: summary dependency changed:.*\/range_km$/);
rejectMutation('source exact snapshot',({packet:p})=>{p.sources[0].title+=' changed';},/Brand update: source snapshot changed:/);
rejectMutation('earned grade provenance',({packet:p})=>{p.facts.find(row=>row.after.key==='range_km').after.gradeReview.overlayId='wrong-overlay';},/Brand update: invalid fact or unearned grade: range_km/);
assert.equal(negativeProof.length,7);assert.deepEqual(before,beforeSnapshot);fullResearchExact(data,candidateFields,'candidateResearch');assert.deepEqual(packet,packetSnapshot);
const {compiledSource}=require('./tests/helpers/compiled-source.ts');
let defaultCalls=0;const forbidden=()=>{defaultCalls++;throw new Error('FORBIDDEN_DEFAULT_CATALOGUE_LOADER');};
const defaults={sourceResearch:forbidden,research:forbidden,catalogue:forbidden};
const factory=packets=>compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets:packets}}).createEvidenceConsumers(defaults);
const initial=factory(brandUpdatePackets),final=factory([...brandUpdatePackets,packet]);
const {hasEarnedBuyerGrade}=require('./src/lib/evidence-grading.ts');
const {factClaim,featureClaim,makeReport,reportMarkdown}=require('./src/lib/citable.ts');
const {availabilityReportClaim}=require('./src/lib/availability-corrections.ts');
const {buyerAvailabilityText}=require('./src/lib/buyer-availability.ts');
const {isOnSale,isCurrentListEligible,isTierOne,buildCoverageReport}=require('./scripts/reporting/reports.ts');
const {auditedFeature}=require('./src/lib/launch-evidence.ts');
const {applyFeatureRegrading}=require('./src/lib/evidence-regrading.ts');
const beforePacks={},afterPacks={},observations=[],claims=[],featureClaims=[],claimOmissions=[],producerProofs=[],frames=new Map();
for(const [phase,cars,consumer,research,packets]of [['before',before,initial,base,brandUpdatePackets],['after',after,final,data,[...brandUpdatePackets,packet]]])for(const car of cars){
 const input=consumer.sourceEffectiveFeatures(car,research),snap=structuredClone(input),regraded=applyFeatureRegrading(car,input,research.sources);
 assert.deepEqual(input,snap);
 const branded=applyBrandFeatureUpdates(car,regraded,research,packets),projected=applyBrandTermFeatures(car,branded,research.sources);
 frames.set(phase+'\0'+car.id,{input,regraded,branded,projected,research});
 producerProofs.push({phase,variantId:car.id,producer:'Actual sourceEffectiveFeatures -> applyFeatureRegrading -> applyBrandFeatureUpdates -> applyBrandTermFeatures',inputRows:input.length,outputRows:projected.length,inputUnchanged:true});
}
function observePack(car,pack,phase){
 const pointers=[];
 function visit(value,pointer){
  if(value===undefined){
   const match=pointer.match(/\/features\/(\d+)\/([^/]+)$/);assert(match,'Unexpected undefined outside feature: '+pointer);
   const rowIndex=Number(match[1]),property=match[2],feature=pack.features[rowIndex],descriptor=Object.getOwnPropertyDescriptor(feature,property);
   assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value')&&descriptor.value===undefined);
   const frame=frames.get(phase+'\0'+car.id),sourceRow=frame.input.find(f=>f.criterion===feature.criterion),regraded=frame.regraded.find(f=>f.criterion===feature.criterion),projected=frame.projected.find(f=>f.criterion===feature.criterion);
   assert(sourceRow&&regraded&&projected);assert.deepEqual(feature,projected);
   let producer;
   if(property==='gradeReviewStatus'){
    assert(feature.gradeReview);assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts earned retained-feature branch explicitly sets gradeReviewStatus undefined';
   }else if(property==='condition_label'){
    assert.equal(feature.buyerGrade,'check');assert(!Object.hasOwn(sourceRow,property)||sourceRow[property]===undefined);assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts Check branch retains source optional condition_label';
   }else if(property==='confirmation_needed'){
    assert.equal(feature.criterion,'novated_fbt');
    for(const row of [sourceRow,regraded]){const d=Object.getOwnPropertyDescriptor(row,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);}
    const raw=frame.research.feature_evidence.find(f=>f.variant_id===car.id&&f.criterion===feature.criterion);assert(raw);
    const snap=structuredClone(raw),audited=auditedFeature(raw);assert.deepEqual(raw,snap);
    const d=Object.getOwnPropertyDescriptor(audited,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);
    producer='launch-evidence.ts actual auditedFeature(raw exact novated_fbt row) creates confirmation_needed undefined';
   }else if(['buyerGrade','gradeReview'].includes(property)){
    assert.equal(feature.gradeReviewStatus,'review_required');assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts unmatched retained-feature branch withdraws optional review';
   }else assert.fail('Unclassified optional undefined: '+pointer);
   observations.push({phase,variantId:car.id,pointer,rowIndex,criterion:feature.criterion,property,ownUndefined:true,enumerable:true,producer,sourceProperty:{own:Object.hasOwn(sourceRow,property),valueKind:sourceRow[property]===undefined?'undefined':typeof sourceRow[property]},regradedProperty:{own:Object.hasOwn(regraded,property),valueKind:regraded[property]===undefined?'undefined':typeof regraded[property]},actualFinalProjectionMatched:true});
   pointers.push(pointer);return;
  }
  if(!value||typeof value!=='object')return;
  for(const key of Object.keys(value))visit(value[key],pointer+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));
 }
 visit(pack,'/packs/'+car.id);assertDeclaredJson(pack,'/packs/'+car.id,new Set(pointers));
}
function observeClaim(claim,pack,pointer,replay,record=true){
 assert.deepEqual(replay(),claim,'Actual citable producer replay must match');
 const clone=structuredClone(claim),pointers=[];
 function visit(value,path){
  if(value===undefined){
   const match=path.match(/\/sources\/(\d+)\/(limitation|checked)$/);assert(match,'Unclassified citable undefined: '+path);
   const i=Number(match[1]),key=match[2],citation=claim.sources[i],source=pack.sources.find(s=>s.id===citation.id);assert(source);
   const d=Object.getOwnPropertyDescriptor(citation,key);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);
   assert(!source[key==='limitation'?'access_limitation':'full_text_checked_date']);
   pointers.push(path);if(record)claimOmissions.push({pointer:path,sourceId:source.id,property:key,ownUndefined:true,enumerable:true,producer:'Actual citable.ts citations() falsey source-metadata branch; actual factClaim/featureClaim replay matches'});
   delete clone.sources[i][key];return;
  }
  if(!value||typeof value!=='object')return;
  for(const key of Object.keys(value))visit(value[key],path+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));
 }
 visit(claim,pointer);assertDeclaredJson(claim,pointer,new Set(pointers));assert.deepEqual(JSON.parse(JSON.stringify(claim)),clone);return clone;
}
for(const car of before){const pack=initial.pack(car.id,{data:base,cars:before});beforePacks[car.id]=pack;assert.equal(pack.features.length,69);observePack(car,pack,'before');}
let earnedCells=0,roadsideRefreshes=0;const gradeCounts={},availabilityClaims=[];
for(const car of after){
 const pack=final.pack(car.id,{data,cars:after});afterPacks[car.id]=pack;assert.equal(pack.features.length,69);assert.equal(new Set(pack.features.map(f=>f.criterion)).size,69);observePack(car,pack,'after');
 for(const feature of pack.features){
  if(feature.criterion==='roadside_assistance'){
   const fact=car.facts.roadside_assistance;
   assert.equal(feature.value,String(fact.value));assert.equal(feature.buyerGrade,'confirmed');assert.equal(feature.status,'standard');assert.equal(feature.verification_state,'reviewed_brand_au_terms');assert.deepEqual(feature.source_ids,fact.sourceIds);
   for(const condition of fact.qualifications)assert(feature.conditions.includes(condition));assert.equal(fact.value,'5 years');assert.equal(fact.unit,'');assert.equal(feature.value,'5 years');roadsideRefreshes++;
  }else assert.deepEqual(feature,beforePacks[car.id].features.find(f=>f.criterion===feature.criterion),'Unrelated retained feature changed: '+car.id+'/'+feature.criterion);
 }
 for(const fact of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===packet.id)){
  assert(hasEarnedBuyerGrade(fact,data.sources,packet.reviewedAt));const claim=factClaim(pack,fact,packet.reviewedAt);
  assert.equal(claim.buyerGrade,fact.buyerGrade);assert.deepEqual(claim.sources.map(s=>s.id),fact.sourceIds);if(fact.key==='roadside_assistance'){assert.equal(claim.value,'5 years');assert(!claim.qualifications.some(q=>q.includes('text tool')));}
  if(fact.buyerGrade==='not_published'){assert.equal(fact.value,null);assert.equal(claim.value,'Not published');}
  const row={variantId:car.id,key:fact.key,claim};observeClaim(claim,pack,'/claims/'+claims.length+'/claim',()=>factClaim(pack,fact,packet.reviewedAt));claims.push(row);earnedCells++;
 }
 for(const feature of pack.features){
  const claim=featureClaim(pack,feature.criterion,feature.criterion,packet.reviewedAt);assert(claim);assert.deepEqual(claim.sources.map(s=>s.id),[...new Set(feature.source_ids)]);if(feature.criterion==='roadside_assistance'){assert.equal(claim.value,'5 years');assert(!claim.qualifications.some(q=>q.includes('text tool')));}
  observeClaim(claim,pack,'/feature-claims/'+featureClaims.length+'/claim',()=>featureClaim(pack,feature.criterion,feature.criterion,packet.reviewedAt));featureClaims.push({variantId:car.id,criterion:feature.criterion,claim});
 }
 assert.equal(buyerAvailabilityText(car),'On sale now');assert(isOnSale(car));assert(isCurrentListEligible(car,data.sources,packet.reviewedAt));assert.equal(car.year,car.model==='Megane E-Tech'?null:2026);
 assert.equal(car.availabilityEvidence.orderStatus,car.model==='Megane E-Tech'?'listed_unconfirmed':'accepting_orders_advertised');
 assert.equal(car.availabilityEvidence.physicalStockVerified,false);assert.equal(car.availabilityEvidence.factoryOrderAcceptanceVerified,false);
 for(const key of expected.coreKeys){const fact=car.facts[key];assert(hasEarnedBuyerGrade(fact,data.sources,packet.reviewedAt));gradeCounts[fact.buyerGrade]=(gradeCounts[fact.buyerGrade]??0)+1;}
 const availability=factClaim(pack,availabilityReportClaim(car),packet.reviewedAt);observeClaim(availability,pack,'/availability-claims/'+availabilityClaims.length+'/claim',()=>factClaim(pack,availabilityReportClaim(car),packet.reviewedAt));availabilityClaims.push({variantId:car.id,claim:availability});
 assert.deepEqual(availability.sources.map(source=>source.id),car.availabilityEvidence.sourceIds);
 const charge=car.facts.dc_charge_time_min;assert.equal(charge.value,null);assert.equal(charge.buyerGrade,'not_published');
 const duration=car.facts.dc_15_80_time_min;assert.equal(duration.comparisonBasis,'15–80% state of charge at '+(car.model==='Megane E-Tech'?'130':'150')+' kW DC station');assert(duration.qualifications.some(q=>q.includes('No interpolation to 10–80%')));
 assert.equal(car.facts.battery_kwh.comparisonBasis,'Battery capacity basis not established');assert.equal(car.facts.battery_kwh.issues.length,1);assert.equal(car.facts.boot_l.comparisonBasis,'Cargo measurement method not stated');
 if(car.model==='Megane E-Tech'){
  assert.equal(car.facts.price_aud.value,54990);assert.equal(car.facts.price_aud.buyerGrade,'reported');assert.equal(car.facts.price_aud.priceEvidence.rankingEligible,false);
  for(const [key,words]of [['height_mm',['1,505','1,500','CarsGuide']],['dc_15_80_time_min',['30','35','15–80%']]]){const fact=car.facts[key],claim=factClaim(pack,fact,packet.reviewedAt);assert.equal(fact.buyerGrade,'check');assert(fact.issues.length);const visible=[claim.sentence,...claim.qualifications].join(' ');for(const word of words)assert(visible.includes(word));}
  assert.equal(car.facts.width_mm.comparisonBasis,'Width measurement basis not established');assert.equal(car.facts.width_mm.issues.length,1);assert.equal(car.facts.drive.buyerGrade,'reported');assert.equal(car.drive,'Unknown');
 }else{assert.equal(car.facts.price_aud.buyerGrade,'confirmed');assert.equal(car.facts.price_aud.comparisonBasis,'Before on-road costs');}

}
assert.equal(earnedCells,104);assert.equal(featureClaims.length,276);assert.equal(roadsideRefreshes,4);assert.deepEqual(gradeCounts,{reported:2,confirmed:61,not_published:4,check:1});
assert.equal(after.filter(isOnSale).length,4);assert.equal(after.filter(isOnSale).length-before.filter(isOnSale).length,0);
const {exclusionReason,rankAttribute,attributes}=require('./src/lib/discovery.ts');
const policy={asOf:packet.reviewedAt},rankingProof=[],rankCounts={};
for(const row of expected.normalizedRankPolicy){
 const car=after.find(c=>c.id===row.variantId),fact=car.facts[row.key],reason=exclusionReason(car,fact,data.sources,policy);
 assert.equal(reason===null,row.eligible,'Ranking mismatch '+car.id+'/'+row.key);
 if(fact.buyerGrade==='reported'||fact.issues.length||!fact.comparisonBasis.trim()||fact.value===null||fact.priceEvidence?.rankingEligible===false)assert(reason);
 rankingProof.push({variantId:car.id,key:row.key,eligible:reason===null,reason});
}
for(const row of expected.supplementalRankPolicy){
 const car=after.find(c=>c.id===row.variantId),fact=car.facts[row.key],reason=exclusionReason(car,fact,data.sources,policy);
 assert.deepEqual(fact.issues,row.issues);assert.equal(reason===null,row.eligible,'Supplemental ranking mismatch '+car.id+'/'+row.key);
 rankingProof.push({variantId:car.id,key:row.key,eligible:reason===null,reason,supplemental:true});
}
for(const attribute of attributes){
 const ranks=rankAttribute(after,data.sources,attribute.key,policy),ranked=ranks.groups.flatMap(g=>g.entries.map(e=>e.car.id));
 assert.deepEqual(new Set(ranked),new Set(expected.rankingIds[attribute.key]));assert.equal(ranks.excluded.length,4-ranked.length);
 for(const group of ranks.groups)for(const entry of group.entries){assert.equal(entry.fact.comparisonBasis,group.basis);assert.equal(entry.fact.unit,group.unit);}
 rankCounts[attribute.key]={ranked,excluded:ranks.excluded};
}
for(const o of observations.filter(x=>x.phase==='after')){
 const prior=observations.find(x=>x.phase==='before'&&x.pointer===o.pointer&&x.criterion===o.criterion&&x.property===o.property);
 const a=afterPacks[o.variantId].features[o.rowIndex],b=beforePacks[o.variantId].features[o.rowIndex];assert.equal(a.criterion,b.criterion);
 assert.notEqual(o.criterion,'roadside_assistance','Fresh canonical term projection must not inherit optional undefined fields');
 assert(prior,'Unchanged feature omission needs exact before witness: '+o.pointer);
 if(o.property==='gradeReviewStatus')assert.deepEqual(a.gradeReview,b.gradeReview);
}
const {compareFacts}=require('./src/lib/compare.ts');
const comparisonProof=[];
function pairCheck(a,b,key,state){
 const left=a.facts[key],right=b.facts[key],result=compareFacts(left,right);assert.equal(result.state,state,`${a.id}/${b.id}/${key}`);
 if(state==='comparable'){assert.equal(typeof left.value,'number');assert.equal(typeof right.value,'number');assert.equal(result.delta,right.value-left.value);}
 else{assert(!Object.hasOwn(result,'delta'));assert.equal(result.delta,undefined);}
 comparisonProof.push({left:a.id,right:b.id,key,leftBasis:left.comparisonBasis,rightBasis:right.comparisonBasis,result});
}
for(let i=0;i<after.length;i++)for(let j=i;j<after.length;j++){
 const a=after[i],b=after[j],hasMegane=a.model==='Megane E-Tech'||b.model==='Megane E-Tech';
 for(const key of ['battery_kwh','boot_l'])pairCheck(a,b,key,'different_basis');
 pairCheck(a,b,'width_mm',hasMegane?'different_basis':'comparable');
 pairCheck(a,b,'height_mm',hasMegane?'conditional':'comparable');
 pairCheck(a,b,'dc_charge_time_min','unknown');
 pairCheck(a,b,'dc_15_80_time_min',hasMegane?'conditional':'comparable');
 for(const key of ['length_mm','range_km','seats','ac_kw','dc_peak_kw','power_kw','zero_to_100_s','towing_braked_kg'])pairCheck(a,b,key,'comparable');
 pairCheck(a,b,'price_aud',hasMegane?'conditional':'comparable');
}
assert.equal(comparisonProof.length,150);
const cleanLengths=rankCounts.length_mm.ranked;assert.deepEqual(new Set(cleanLengths),selected);
for(const car of after){assert(exclusionReason(car,car.facts.battery_kwh,data.sources,policy));assert(exclusionReason(car,car.facts.boot_l,data.sources,policy));}
assert(exclusionReason(after[0],after[0].facts.width_mm,data.sources,policy));
const reconciliation=readJson(m.reconciliation.path);
const allInventory=require('./src/lib/market-inventory-data.ts').default;
const isRenault=s=>s==='Renault';
const inventory={...allInventory,records:allInventory.records.filter(r=>isRenault(r.brand)),unverifiedLeads:allInventory.unverifiedLeads.filter(r=>isRenault(r.brand))};
const inherited=readJson('/tmp/renault-research/inherited-inventory-extract-v1.json').sections;
assert.deepEqual(inventory.records,inherited.records);assert.deepEqual(inventory.unverifiedLeads,inherited.unverifiedLeads);
assert.equal(inventory.records.length,4);assert.equal(inventory.records.filter(r=>r.vehicleClass==='van').length,2);assert.equal(inventory.unverifiedLeads.length,0);
const {inventoryRecordId,buildMarketReconciliation}=require('./scripts/reporting/m1-reconciliation.ts');
assert.deepEqual(inventory.records.filter(r=>r.vehicleClass==='passenger').map(inventoryRecordId),['renault-megane-e-tech','renault-scenic-e-tech']);
assert.deepEqual(reconciliation.inventoryResolutions.map(r=>[r.kind,r.inventoryId,r.outcome]),[['record','renault-megane-e-tech','unresolved'],['record','renault-scenic-e-tech','included']]);
for(const review of reconciliation.currentVersionReviews){
 assert.equal(review.bodyStyle,expected.bodyByModelId[review.modelId]);
 for(const version of review.versions){const car=after.find(c=>c.id===version.carId);assert(car);assert.equal(car.modelId,review.modelId);assert.equal(car.model,review.model);assert.equal(car.model,version.model);assert.equal(car.trim,version.trim);assert.equal(car.year,version.modelYear);}
}
const c1=buildMarketReconciliation(reconciliation,after,inventory,packet.reviewedAt);
assert.equal(c1.reviewedModels,2);assert.equal(c1.reviewedVersions,4);assert.deepEqual(new Set(c1.reviewedVersionIds),selected);
assert.deepEqual(c1.settledInventory,['record:renault-scenic-e-tech']);assert.equal(c1.pass,false);
assert.deepEqual(c1.issues.map(i=>i.code),['independent_lists','inventory_unresolved']);assert.equal(c1.issues[1].reference,'record:renault-megane-e-tech');
const selectedCoverage=buildCoverageReport({cars:after,sources:data.sources,features:Object.values(afterPacks).flatMap(p=>p.features),inventory,m1Reconciliation:reconciliation},packet.reviewedAt);
assert.equal(selectedCoverage.allCatalogueVersions,4);assert.equal(selectedCoverage.tierOneVersions,4);assert.equal(selectedCoverage.onSaleVersions,4);
const selectedBrandProgress=selectedCoverage.brandProgress.find(b=>isRenault(b.brand));assert(selectedBrandProgress);assert.equal(selectedBrandProgress.currentVersionReviews.length,2);assert.equal(selectedBrandProgress.unreviewedCoreGrades,0);assert.equal(selectedBrandProgress.missingSummaries,0);assert.equal(selectedBrandProgress.criteria.C1,false);
const {storePortablePacks,hydratePortablePacks}=require('./src/lib/portable-packs.ts');
const snapshot=structuredClone(afterPacks),writtenExpected=structuredClone(afterPacks);
const stored=storePortablePacks(afterPacks);
assert.deepStrictEqual(afterPacks,snapshot);
assert.deepEqual(hydratePortablePacks(stored,data.sources),afterPacks);
for(const o of observations.filter(x=>x.phase==='after')){const row=writtenExpected[o.variantId].features[o.rowIndex];assert(Object.hasOwn(row,o.property));assert.equal(row[o.property],undefined);delete row[o.property];}
assert.deepEqual(JSON.parse(JSON.stringify(afterPacks)),writtenExpected);
assert.deepEqual(hydratePortablePacks(JSON.parse(JSON.stringify(stored)),data.sources),writtenExpected);assert.deepEqual(afterPacks,snapshot);
for(const [name,obj]of Object.entries({'selected-after-cars':after,'selected-packs':afterPacks,portable:stored,claims,'feature-claims':featureClaims,'availability-claims':availabilityClaims,'undefined-witnesses':observations,'claim-undefined-witnesses':claimOmissions}))fs.writeFileSync(out+'/'+name+'.json',JSON.stringify(obj,null,2)+'\n',{flag:'wx'});
const writtenPacks=readJson(out+'/selected-packs.json'),hydrated=hydratePortablePacks(readJson(out+'/portable.json'),data.sources);
assert.deepEqual(writtenPacks,writtenExpected);assert.deepEqual(hydrated,writtenExpected);
// Actual citable producers must agree for live packs and serialized/re-hydrated packs.
for(const row of claims){const fact=after.find(c=>c.id===row.variantId).facts[row.key];assert.deepEqual(factClaim(hydrated[row.variantId],fact,packet.reviewedAt),row.claim);}
for(const row of featureClaims)assert.deepEqual(featureClaim(hydrated[row.variantId],row.criterion,row.criterion,packet.reviewedAt),row.claim);
for(const row of availabilityClaims)assert.deepEqual(factClaim(hydrated[row.variantId],availabilityReportClaim(after.find(c=>c.id===row.variantId)),packet.reviewedAt),row.claim);
for(const [name,rows]of [['claims',claims],['feature-claims',featureClaims],['availability-claims',availabilityClaims]]){
 const written=readJson(out+'/'+name+'.json');
 for(let i=0;i<rows.length;i++){
  const pack=afterPacks[rows[i].variantId],replay=()=>name==='claims'?factClaim(pack,after.find(c=>c.id===rows[i].variantId).facts[rows[i].key],packet.reviewedAt):name==='availability-claims'?factClaim(pack,availabilityReportClaim(after.find(c=>c.id===rows[i].variantId)),packet.reviewedAt):featureClaim(pack,rows[i].criterion,rows[i].criterion,packet.reviewedAt);
  const clone=observeClaim(rows[i].claim,pack,'/'+name+'/'+i+'/claim',replay,false);assert.deepEqual(written[i],{...rows[i],claim:clone});
 }
}
const reportProof=[];
for(const car of after){
 const pack=afterPacks[car.id],path='/cars/'+car.family+'/'+car.slug,report=makeReport([pack],path,packet.reviewedAt),markdown=reportMarkdown(report);
 assert.deepEqual(makeReport([hydrated[car.id]],path,packet.reviewedAt),report);assert.equal(reportMarkdown(makeReport([writtenPacks[car.id]],path,packet.reviewedAt)),markdown);
 fs.writeFileSync(out+'/'+car.id+'-report.md',markdown,{flag:'wx'});assert.equal(fs.readFileSync(out+'/'+car.id+'-report.md','utf8'),markdown);
 reportProof.push({variantId:car.id,path,markdownFile:out+'/'+car.id+'-report.md',actualLiveWrittenHydratedReportEqual:true});
}
assert.equal(defaultCalls,0);for(const f of ['src/lib/data.ts','src/lib/catalogue.ts','src/lib/research.ts'])assert(!require.cache[repo+'/'+f]);
fullResearchExact(base,currentFields,'baseResearch');assert.deepStrictEqual(before,beforeSnapshot);fullResearchExact(data,candidateFields,'candidateResearch');assert.deepStrictEqual(after,afterSnapshot);assert.deepStrictEqual(packet,packetSnapshot);assert.deepStrictEqual(afterPacks,snapshot);checkPins();
const result={status:'selected_actual_consumers_and_exact_serialization_witness_pass',packetSha256:fileHash(packetPath),beforeCars:4,afterCars:4,coreCells:68,coreGradeCounts:gradeCounts,earnedPacketCells:earnedCells,selectedFeatureClaims:featureClaims.length,roadsideRefreshes,reportProof,otherRetainedFeaturesUnchanged:true,readInputs:reads,currentListProof:c1,selectedCoverage,rankingProof,rankCounts,comparisonProof,negativeProof,producerProofs,optionalFeaturePaths:observations,optionalCitationPaths:claimOmissions,inMemoryPortableExact:true,writtenPortableExact:true,writtenClaimReadback:true,livePacksUnchanged:true,productionCatalogueHydration:false,defaultLoaderCalls:defaultCalls,sourceEdits:false,scopeTargetNeutrality:{selectedTierOneOnly:true,tierTwoTargets:0,nonRenaultTargets:0,fullCataloguePeerEquality:'NOT RUN; later full-stage gate'},expectedOnSaleDelta:0,fullProjectTypeScript:'UNPASSED; no compiler retry'};
// Written C1/report shape retains only the exact omissions owned by the actual issue producer.
assert.deepEqual(buildMarketReconciliation(reconciliation,after,inventory,packet.reviewedAt),c1);
assert.deepEqual(selectedCoverage.reconciliation,c1);
assert.equal(c1.issues.length,2);assert.equal(c1.issues[0].code,'independent_lists');
assert.deepEqual(Object.keys(c1.issues[0]).sort(),['brand','code','reason','reference']);
const resultSnapshot=structuredClone(result),resultWritten=structuredClone(result),reportOmissions=[];
function reportShape(value,path,clone,parent){
 if(value===undefined){
  assert(/\/(brand|reference)$/.test(path),'Unexpected report undefined: '+path);
  assert.deepEqual(parent,c1.issues[0]);const property=path.split('/').at(-1),descriptor=Object.getOwnPropertyDescriptor(parent,property);
  assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value')&&descriptor.value===undefined);
  reportOmissions.push({pointer:path,property,ownUndefined:true,enumerable:true,producer:'Actual buildMarketReconciliation independent_lists issue via add(code, reason), no brand/reference arguments'});
  return;
 }
 if(!value||typeof value!=='object')return;
 for(const key of Object.keys(value)){
  reportShape(value[key],path+'/'+key.replaceAll('~','~0').replaceAll('/','~1'),clone?.[key],value);
  if(value[key]===undefined)delete clone[key];
 }
}
reportShape(result,'/result',resultWritten,null);
assertDeclaredJson(result,'/result',new Set(reportOmissions.map(x=>x.pointer)));
assert.deepEqual(JSON.parse(JSON.stringify(result)),resultWritten);assert.deepEqual(result,resultSnapshot);
fs.writeFileSync(out+'/report-undefined-witnesses.json',JSON.stringify(reportOmissions,null,2)+'\n',{flag:'wx'});
fs.writeFileSync(out+'/result.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
assert.deepEqual(readJson(out+'/result.json'),resultWritten);assert.deepStrictEqual(result,resultSnapshot);
fullResearchExact(base,currentFields,'baseResearch');assert.deepStrictEqual(before,beforeSnapshot);fullResearchExact(data,candidateFields,'candidateResearch');assert.deepStrictEqual(after,afterSnapshot);assert.deepStrictEqual(packet,packetSnapshot);assert.deepStrictEqual(afterPacks,snapshot);

progress('Four selected packs,104 fact/term claims,276 feature claims,150 pair cases and seven guard rejections proved');
const acceptedSelected=readJson(m.selectedResult.path);assert.equal(acceptedSelected.status,'selected_actual_consumers_and_exact_serialization_witness_pass');assert.equal(acceptedSelected.packetSha256,m.packet.sha256);
for(const [name,pin]of Object.entries(m.selectedArtifacts))assert.equal(fileHash(out+'/'+name),pin.sha256,'Exact selected written artifact '+name);
const acceptedWrittenPacks=readJson(m.selectedArtifacts['selected-packs.json'].path);
const acceptedWrittenClaims=readJson(m.selectedArtifacts['claims.json'].path),acceptedWrittenFeatureClaims=readJson(m.selectedArtifacts['feature-claims.json'].path),acceptedAvailabilityClaims=readJson(m.selectedArtifacts['availability-claims.json'].path);
assert.deepEqual(claims,acceptedWrittenClaims.map(row=>({variantId:row.variantId,key:row.key,claim:factClaim(acceptedWrittenPacks[row.variantId],acceptedWrittenPacks[row.variantId].car.facts[row.key],m.asOf)})));
assert.deepEqual(featureClaims,acceptedWrittenFeatureClaims.map(row=>({variantId:row.variantId,criterion:row.criterion,claim:featureClaim(acceptedWrittenPacks[row.variantId],row.criterion,row.criterion,m.asOf)})));
assert.deepEqual(availabilityClaims,acceptedAvailabilityClaims.map(row=>({variantId:row.variantId,claim:factClaim(acceptedWrittenPacks[row.variantId],availabilityReportClaim(acceptedWrittenPacks[row.variantId].car),m.asOf)})));
assert.deepEqual(observations,acceptedSelected.optionalFeaturePaths);assert.deepEqual(claimOmissions,acceptedSelected.optionalCitationPaths);assert.deepEqual(readJson(out+'/result.json').selectedCoverage,acceptedSelected.selectedCoverage);assert.deepEqual(comparisonProof,acceptedSelected.comparisonProof);assert.deepEqual(negativeProof,acceptedSelected.negativeProof);
// Full structural ranking comparison: peers stay exact inside compatible groups; whole groups may move.
const discoverySource=fs.readFileSync(repo+'/src/lib/discovery.ts','utf8');
const comparatorSource='(a, b) =>\n        b.entries.length - a.entries.length || a.basis.localeCompare(b.basis)';
assert.equal(discoverySource.split(comparatorSource).length,2,'Unique production group-sort expression');
const groupCompare=(a,b)=>b.entries.length-a.entries.length||a.basis.localeCompare(b.basis);
const groupKey=group=>JSON.stringify([group.vehicleClass,group.basis,group.unit]);
const alphabeticalSource='unranked.sort((a, b) =>\n    `${a.car.brand} ${a.car.model} ${a.car.trim}`.localeCompare(\n      `${b.car.brand} ${b.car.model} ${b.car.trim}`,\n    ),\n  );';
assert.equal(discoverySource.split(alphabeticalSource).length,2,'Unique production unranked alphabetical comparator');
const alphabetical=(a,b)=>`${a.car.brand} ${a.car.model} ${a.car.trim}`.localeCompare(`${b.car.brand} ${b.car.model} ${b.car.trim}`);
function rankingRecords(ranking,digests){
 const byId=new Map(digests.map(row=>[row.id,row]));
 function entryRecord(entry){const {car,...fields}=entry;const digest=byId.get(car.id);assert(digest);assert.deepEqual({id:car.id,...digestRows([car])},digest);return {carId:car.id,carDigest:{...digest},...fields};}
 return {groups:ranking.groups.map(group=>({...group,entries:group.entries.map(entryRecord)})),excluded:ranking.excluded.map(row=>{const digest=byId.get(row.carId);assert(digest);return {...row,carDigest:{...digest}};}),unranked:ranking.unranked.map(entryRecord)};
}
const globalRankProof=[];
function groupProof(ranking,inputCars,attribute){
 const byKey=new Map(ranking.groups.map(group=>[groupKey(group),group]));assert.equal(byKey.size,ranking.groups.length);
 const memberGroup=new Map();for(const group of ranking.groups)for(const entry of group.entries){assert(!memberGroup.has(entry.car.id));memberGroup.set(entry.car.id,groupKey(group));assert.deepStrictEqual(entry.fact,entry.car.facts[attribute.key]);}
 const insertionKeys=[];for(const car of inputCars){const key=memberGroup.get(car.id);if(key&&!insertionKeys.includes(key))insertionKeys.push(key);}
 assert.equal(insertionKeys.length,ranking.groups.length);
 const predicted=insertionKeys.map(key=>byKey.get(key)).sort(groupCompare);assert.deepStrictEqual(predicted.map(groupKey),ranking.groups.map(groupKey));
 for(const group of ranking.groups){
  const ordered=[...group.entries].sort((a,b)=>(Number(a.fact.value)-Number(b.fact.value))*(attribute.direction==='lower'?1:-1)||a.car.id.localeCompare(b.car.id));
  assert.deepStrictEqual(ordered.map(row=>row.car.id),group.entries.map(row=>row.car.id));
  for(const row of group.entries){const value=Number(row.fact.value);assert.equal(row.rank,group.entries.findIndex(entry=>Number(entry.fact.value)===value)+1);assert.equal(row.tied,group.entries.filter(entry=>Number(entry.fact.value)===value).length>1);}
 }
 return {insertionKeys,sortedKeys:ranking.groups.map(groupKey),groups:ranking.groups.map(group=>({key:groupKey(group),count:group.entries.length,ids:group.entries.map(row=>row.car.id),selectedIds:group.entries.filter(row=>selected.has(row.car.id)).map(row=>row.car.id),peerIds:group.entries.filter(row=>peerIds.has(row.car.id)).map(row=>row.car.id)}))};
}
for(const attribute of attributes){
 const old=rankAttribute(currentCars,base.sources,attribute.key,policy),next=rankAttribute(cars,data.sources,attribute.key,policy),selectedRanking=rankAttribute(after,data.sources,attribute.key,policy);
 const buckets=new Map();
 for(const group of old.groups){const entries=group.entries.filter(row=>peerIds.has(row.car.id));if(entries.length)buckets.set(groupKey(group),{...group,entries});}
 for(const group of selectedRanking.groups){const key=groupKey(group),prior=buckets.get(key);if(prior)prior.entries.push(...group.entries);else buckets.set(key,{...group,entries:[...group.entries]});}
 const memberGroup=new Map();for(const [key,group]of buckets)for(const entry of group.entries){assert(!memberGroup.has(entry.car.id));memberGroup.set(entry.car.id,key);}
 const insertionKeys=[];for(const car of cars){const key=memberGroup.get(car.id);if(key&&!insertionKeys.includes(key))insertionKeys.push(key);}
 const expectedGroups=insertionKeys.map(key=>buckets.get(key));
 for(const group of expectedGroups){
  group.entries.sort((a,b)=>(Number(a.fact.value)-Number(b.fact.value))*(attribute.direction==='lower'?1:-1)||a.car.id.localeCompare(b.car.id));
  group.entries=group.entries.map(entry=>({...entry,rank:group.entries.findIndex(row=>Number(row.fact.value)===Number(entry.fact.value))+1,tied:group.entries.filter(row=>Number(row.fact.value)===Number(entry.fact.value)).length>1}));
 }
 expectedGroups.sort(groupCompare);assert.deepEqual(next.groups,expectedGroups,'Complete compatible groups equal unchanged peer entries plus exact selected entries');
 const exclusionById=new Map([...old.excluded.filter(row=>peerIds.has(row.carId)),...selectedRanking.excluded].map(row=>[row.carId,row]));
 const expectedExcluded=cars.filter(car=>exclusionById.has(car.id)).map(car=>exclusionById.get(car.id));assert.deepEqual(next.excluded,expectedExcluded,'Complete exclusions preserve actual catalogue traversal order');
 const expectedUnranked=[...old.unranked.filter(row=>peerIds.has(row.car.id)),...selectedRanking.unranked].sort(alphabetical);assert.deepEqual(next.unranked,expectedUnranked,'Complete unranked entries equal unchanged peers plus selected, in verified alphabetical order');
 const beforeRecords=rankingRecords(old,currentDigests),afterRecords=rankingRecords(next,candidateDigests),selectedRecords=rankingRecords(selectedRanking,candidateDigests);
 assertDeclaredJson(beforeRecords,'/beforeRankingRecords',new Set());assertDeclaredJson(afterRecords,'/afterRankingRecords',new Set());assertDeclaredJson(selectedRecords,'/selectedRankingRecords',new Set());
 const a=groupProof(old,currentCars,attribute),b=groupProof(next,cars,attribute),aBy=new Map(a.groups.map(group=>[group.key,group])),bBy=new Map(b.groups.map(group=>[group.key,group]));
 for(const key of new Set([...aBy.keys(),...bBy.keys()])){
  const oldGroup=aBy.get(key),newGroup=bBy.get(key),oldPeers=oldGroup?.peerIds??[],newPeers=newGroup?.peerIds??[];
  assert.deepEqual(newPeers,oldPeers,'Peer order within compatible group '+attribute.key+'/'+key);
  assert.equal(newGroup?.count??0,(oldGroup?.count??0)-(oldGroup?.selectedIds.length??0)+(newGroup?.selectedIds.length??0));
 }
 assert.deepEqual(next.excluded.filter(row=>peerIds.has(row.carId)),old.excluded.filter(row=>peerIds.has(row.carId)));
 assert.deepEqual(next.unranked.filter(row=>peerIds.has(row.car.id)),old.unranked.filter(row=>peerIds.has(row.car.id)));
 assert.deepEqual(new Set(b.groups.flatMap(group=>group.selectedIds)),new Set(expected.rankingIds[attribute.key]));
 globalRankProof.push({attribute:attribute.key,completeOrderedBefore:beforeRecords,completeOrderedAfter:afterRecords,completeSelectedRecords:selectedRecords,fullGroupsEqualUnchangedPeersPlusSelected:true,fullExcludedInCatalogueOrder:true,fullUnrankedEqualAlphabeticalPeersPlusSelected:true,productionAlphabeticalComparator:alphabeticalSource,fullCarDigestBindingsVerified:true,before:a,after:b,peerExclusions:next.excluded.filter(row=>peerIds.has(row.carId)),peerMembershipAndWithinGroupOrderExact:true,productionGroupComparator:comparatorSource,insertionTiesProvedFromActualInputOrder:true,selectedCountDeltasExact:true});
}
write('global-ranking-comparison',globalRankProof);
// Actual global C1 only: mirror current loader imports without running its full loader.
const actualPaths=[...fs.readFileSync(repo+'/scripts/reporting/load.ts','utf8').matchAll(/import \w+ from "(\.\.\/\.\.\/data\/m1-[^"]+\.json)";/g)].map(match=>path.resolve(repo+'/scripts/reporting',match[1]));assert.deepEqual(actualPaths,m.reconciliationInputs.map(pin=>pin.path));assert.equal(actualPaths.length,29);
const {combineM1Reconciliations}=require('./scripts/reporting/m1-reconciliation.ts');
const baseReconciliation=combineM1Reconciliations(...m.reconciliationInputs.map(pin=>require(pin.path)));
const baselineC1=buildMarketReconciliation(baseReconciliation,currentCars.filter(isTierOne).filter(car=>isCurrentListEligible(car,base.sources,m.asOf)),allInventory,m.asOf);
const acceptedStageGlobal=readJson(m.acceptedCupraC1.path).after,acceptedReport=readJson(m.acceptedNormalReport.path),normalTerminal=readJson(m.acceptedNormalTerminal.path);assert.equal(normalTerminal.exitCode,0);assert.equal(normalTerminal.stdoutSha256,m.acceptedNormalReport.sha256);
const fixtureRegistry={schemaVersion:1,checkedAt:m.asOf,publishedLists:[],currentVersionReviews:[],listResolutions:[],inventoryResolutions:[],catalogueOnlyDifferences:[]},fixtureInventory={records:[],unverifiedLeads:[]};
const fixture=buildMarketReconciliation(fixtureRegistry,[],fixtureInventory,m.asOf);assert.deepEqual(fixture.issues.map(issue=>issue.code),['independent_lists','empty_catalogue']);
const producedIssue=fixture.issues[0],issueOwnership=[];assert.deepEqual(Object.keys(producedIssue).sort(),['brand','code','reason','reference']);
for(const property of ['brand','reference']){const descriptor=Object.getOwnPropertyDescriptor(producedIssue,property);assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value'));assert.equal(descriptor.value,undefined);issueOwnership.push({property,ownUndefined:true,enumerable:true,producer:'Actual buildMarketReconciliation fixture add(code,reason)'});}
function c1Written(live,label){const snapshot=structuredClone(live),clone=structuredClone(live),indices=live.issues.map((issue,index)=>issue.code==='independent_lists'?index:-1).filter(index=>index>=0);assert.equal(indices.length,1);const index=indices[0],issue=live.issues[index];assert.deepEqual(issue,producedIssue);const allowed=new Set();for(const property of ['brand','reference']){assert.deepEqual(Object.getOwnPropertyDescriptor(issue,property),Object.getOwnPropertyDescriptor(producedIssue,property));allowed.add('/'+label+'/issues/'+index+'/'+property);delete clone.issues[index][property];}assertDeclaredJson(live,'/'+label,allowed);assert.deepEqual(JSON.parse(JSON.stringify(live)),clone);assert.deepEqual(live,snapshot);return clone;}
const baselineWritten=c1Written(baselineC1,'baselineC1');assert.deepEqual(baselineWritten,acceptedStageGlobal);assert.deepEqual(baselineWritten,acceptedReport.reconciliation);
const expectedLive=structuredClone(acceptedStageGlobal),independentIndex=expectedLive.issues.findIndex(issue=>issue.code==='independent_lists');expectedLive.issues[independentIndex]=producedIssue;assert.deepEqual(baselineC1,expectedLive);
const proposedReconciliation=combineM1Reconciliations(baseReconciliation,reconciliation),globalC1=buildMarketReconciliation(proposedReconciliation,cars.filter(isTierOne).filter(car=>isCurrentListEligible(car,data.sources,m.asOf)),allInventory,m.asOf);

assert.equal(baselineC1.reviewedModels,103);assert.equal(baselineC1.reviewedVersions,234);assert.equal(globalC1.reviewedModels,105);assert.equal(globalC1.reviewedVersions,238);assert.equal(globalC1.registryValid,true);assert.equal(globalC1.pass,false);
const nonRenaultIssue=issue=>issue.brand!=='Renault'&&!selected.has(issue.reference)&&!['record:renault-megane-e-tech','record:renault-scenic-e-tech'].includes(issue.reference);
assert.deepEqual(globalC1.issues.filter(nonRenaultIssue),baselineC1.issues.filter(nonRenaultIssue));
assert.deepEqual(baselineC1.issues.filter(issue=>!nonRenaultIssue(issue)).map(issue=>issue.reference),[...selected,'record:renault-megane-e-tech','record:renault-scenic-e-tech']);
assert.deepEqual(globalC1.issues.filter(issue=>!nonRenaultIssue(issue)).map(issue=>issue.reference),['record:renault-megane-e-tech']);
for(const list of [currentCars,cars]){assert.equal(list.length,430);assert.equal(list.filter(isTierOne).length,353);assert.equal(list.filter(isTierOne).filter(isOnSale).length,312);}
const expectedGlobalEvidence=structuredClone(baselineWritten.evidence);assert.deepEqual(Object.keys(expectedGlobalEvidence).sort(),Object.keys(reconciliation).sort());expectedGlobalEvidence.checkedAt=[baselineWritten.evidence.checkedAt,reconciliation.checkedAt].sort().at(-1);
for(const key of ['notes','publishedLists','currentVersionReviews','listResolutions','catalogueOnlyDifferences','inventoryResolutions'])expectedGlobalEvidence[key]=[...baselineWritten.evidence[key],...reconciliation[key]];
assert.deepEqual(proposedReconciliation,expectedGlobalEvidence);
const expectedIssues=baselineWritten.issues.filter(issue=>!(issue.code==='version_unreviewed'&&selected.has(issue.reference))&&!(issue.code==='inventory_unresolved'&&issue.reference==='record:renault-scenic-e-tech'));
const originalInventoryOrder=[...allInventory.records.filter(record=>!record.vehicleClass||['passenger','ute'].includes(record.vehicleClass)).map(record=>'record:'+inventoryRecordId(record)),...allInventory.unverifiedLeads.filter(record=>!record.vehicleClass||['passenger','ute'].includes(record.vehicleClass)).map(record=>'lead:'+inventoryRecordId(record))];
const allExpectedSettlements=new Set([...baselineWritten.settledInventory,'record:renault-scenic-e-tech']);
const expectedGlobalWritten={...structuredClone(baselineWritten),registryCheckedAt:expectedGlobalEvidence.checkedAt,reviewedModels:105,reviewedVersions:238,reviewedVersionIds:[...baselineWritten.reviewedVersionIds,...m.selectedIds],validModelReviewIds:[...baselineWritten.validModelReviewIds,...reconciliation.currentVersionReviews.map(review=>review.id)],settledInventory:originalInventoryOrder.filter(id=>allExpectedSettlements.has(id)),issues:expectedIssues,evidence:expectedGlobalEvidence};
assert.equal(expectedGlobalWritten.settledInventory.length,baselineWritten.settledInventory.length+1);assert.equal(expectedGlobalWritten.issues.length,baselineWritten.issues.length-5);
const globalWritten=c1Written(globalC1,'globalC1');assert.deepEqual(globalWritten,expectedGlobalWritten,'Complete proposed C1 equality, all counters, exact issue order and evidence arrays');
assert(reconciliation.notes.some(note=>note.includes('R5 Turbo 3E')&&note.includes('unresolved')));assert(!reconciliation.currentVersionReviews.some(review=>/Turbo|Renault 5/.test(review.model)));assert(!reconciliation.inventoryResolutions.some(row=>/r5|renault-5/.test(row.inventoryId)));
write('baseline-global-c1',baselineC1);write('global-c1-comparison',{before:baselineWritten,after:globalWritten,expectedCompleteAfter:expectedGlobalWritten,completeExpectedWrittenEquality:true,baselineMatchesAcceptedCupraAndNormal:true,nonRenaultIssuesReviewsDispositionsExact:true,issueOwnership,normalFullReportRun:false,meganeResidualUnresolved:true,r5TurboConflictRetainedWithoutFabricatedInventoryId:true});
progress('Global compatible-group rankings and complete expected C1 gaps proved without broad features');
fullResearchExact(base,currentFields,'baseResearch');fullCarsExact(currentCars,currentDigests,'currentCars');fullResearchExact(data,candidateFields,'candidateResearch');fullCarsExact(cars,candidateDigests,'candidateCars');assert.deepEqual(before,beforeSnapshot);assert.deepEqual(after,afterSnapshot);assert.deepEqual(packet,packetSnapshot);assert.deepEqual(afterPacks,snapshot);assert.equal(defaultCalls,0);
for(const file of ['src/lib/data.ts','src/lib/catalogue.ts','src/lib/research.ts','scripts/reporting/load.ts'])assert(!require.cache[repo+'/'+file]);checkPins();
write('metadata-composition',transitions);write('car-digest-comparison',{...carStages,candidate30:candidateDigests});write('research-field-digests',{...fieldStages,candidate30:candidateFields});
write('stage-receipt',{status:'bounded_structural_selected_stage_pass_pending_independent_review',manifestSha256:args[3],packetSha256:m.packet.sha256,originalBaselineCars:409,acceptedCurrentCars:430,stagedCars:430,tierOneVersions:353,onSaleVersions:312,untouchedPeerCars:426,changedRetainedCars:4,newModels:0,newVersions:0,versionUpdates:0,configurationUpdates:0,manualFeatureUpdates:0,sourceRowsAdded:24,allAcceptedStagesThroughCupra29ExactlyReproduced:true,all14ResearchFieldsProved:true,strictJsonShapeBeforeDigest:true,all21RetainedStorageFilesPinnedBeforeAndAfter:true,completeGlobalC1ExpectedEquality:true,actualSelectedCars:4,actualFactAndTermClaims:earnedCells,actualFeatureClaims:featureClaims.length,roadsideCanonicalProjections:4,roadsideFactAndFeatureClaimText:'5 years',pairComparisonCases:comparisonProof.length,intendedNegativeRejections:negativeProof.length,actualOptionalWitnessesExact:true,inMemoryPortableExact:true,writtenPortableExact:true,writtenClaimReadback:true,selectedC1:c1Written(c1,'selectedC1'),globalC1Counts:{reviewedModels:globalC1.reviewedModels,reviewedVersions:globalC1.reviewedVersions,pass:globalC1.pass},sourceAdditionsDoNotReviveAcceptedReferences:true,allPeerDigestsAndIdentitiesExact:true,peerOrderExactWithinCompatibleRankingGroups:true,productionGroupSortingAndInsertionTieProvenance:true,broadFeatureReplay:false,normalFullReportRun:false,normalFullReportRequiredAfterGuardedIntegration:true,defaultLoaderCalls:defaultCalls,liveSourceEdits:false,productionRegistration:false,currentProjectTypeScript:'UNPASSED; no compiler retry',resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log(JSON.stringify({status:'passed',receipt:out+'/stage-receipt.json',sha256:fileHash(out+'/stage-receipt.json'),noBroadFeatureReplay:true}));
