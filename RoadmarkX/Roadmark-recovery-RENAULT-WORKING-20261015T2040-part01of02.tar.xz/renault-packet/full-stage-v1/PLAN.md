# Renault30 bounded full-stage plan v1

Prepared only. This file does not authorize stage execution, live changes, registration or a compiler retry.

## Accepted candidate and selected evidence

Typed-v4 candidate SHA-256 is `6f89f00f147c45c5e1afdff24f8597da3b980d6f5230cd1ba5fb663754464605`. It refreshes four existing Tier 1 cars: one Megane Techno EV60 and three MY26 Scenic variants. It adds no model, variant, identity, configuration or manual feature rows. The exact roadside-only correction changes seven candidate pointers and preserves the policy duration, limits, sources and dates; both actual fact and feature claims now say “5 years”. All prior preparations and the earlier technical-pass outputs remain preserved.

Selected-v5 actual-consumer result SHA-256 is `e8a2168fd8e55c465cb8e454b6091dc89c6b055c928f9179f23bbd8b30efdb91`, independently accepted by receipt `d6b429a4e074d83a23c2a482146e0177f82a291ea297c7463fbc71ede540b4df`. The result proves four packs, 276 complete effective feature claims, 104 fact/shared-term cells, 150 self/pair comparisons and seven intended negative guard rejections with unchanged inputs. The 68 core cells remain 61 Confirmed, one Check, two Reported and four Not published. Four canonical roadside features are refreshed; all other retained feature rows remain exact.

The current accepted baseline is CUPRA29: 430 catalogue / 353 Tier 1 / 312 on-sale Tier 1. The proposed Renault30 totals remain 430 / 353 / 312. Current project TypeScript and release are UNPASSED following earlier unexplained compiler terminations. This work does not retry the compiler.

## Single bounded computation

Restore the accepted retained 409-row/prefix-20 storage once. Pin all 21 actual storage files, the locator, accepted anchor manifest, complete source/import closure and all 14 research fields. Reproduce the accepted complete-car and all-14-field digests at each stage: EQA21, Leapmotor22, Mazda23, Skoda24, Audi25, Deepal26, MINI27, KGM28 and CUPRA29. The only research composition adjustment is the actual ordered packet-ID list in metadata, with the real raw producer result retained as proof.

Run actual prepareBrandResearch/applyBrandUpdates against CUPRA29. Exact guards cover four complete retained identities, 92 specific facts, 12 shared-term applications, four availability snapshots and every summary dependency/source snapshot. The proposed structural changes are limited to appending 24 fresh source records, refreshing the four variants' availability evidence, and appending the packet ID in metadata. All other research fields/values remain exact. All 426 peers remain byte-digest-equal, including their catalogue order; the only changed complete cars are the four selected Renault rows. Counts are checked with actual eligibility helpers.

Check that none of the 24 new source IDs existed anywhere in accepted research, cars, prior packets or retained raw overlays, including nested review objects and dictionary keys. This supports source-addition neutrality rather than assuming a fresh source can never revive an old reference.

No broad effective-feature replay. Only four selected packs use the actual effective-feature, audit/regrading, brand feature and shared-term producers with complete global issue/source context. Reproduce all accepted selected JSON and Markdown artifacts exactly. Preserve the actual producer-owned optional-property witnesses, in-memory/portable/written/hydrated equality, availability/citable claims, summary dependencies, 150 comparisons, rankings and seven negative cases. Negative mutants use only the four selected variant/model/feature rows plus complete global evidence context, keeping the memory envelope bounded.

## Complete ranking and C1 checks

For each of the seven actual ranking attributes, derive the full expected groups from unchanged peer entries plus refreshed selected entries. Verify production group sorting and input-order ties, numeric ordering, rank/tie values, complete exclusions in catalogue order, and complete unranked entries in the verified alphabetical order. Peers keep group membership and relative order. Output every fact/rank/tie/reason; repeated Car objects are bound to exact ID and independently proved complete-car digest. Clean overall lengths rank; unknown battery, cargo and mirror-width bases remain held. Explicit unknown-basis comparisons must reject even when their unknown labels match.

Mirror the current reporting loader's 29 reconciliation imports without invoking its loader. Baseline C1 must equal accepted CUPRA29 stage output and the actual normal CUPRA report. Build the complete expected Renault result from that frozen baseline:

- reviewed models 103 to 105; reviewed versions 234 to 238
- append only the exact current Renault review IDs and evidence arrays
- remove the four Renault version-unreviewed issues and the Scenic unresolved inventory issue
- add only Scenic to settled inventory in the inherited inventory order
- keep the Megane unresolved inventory issue exactly and preserve all non-Renault issues, evidence, list counters and ordering
- expect 197 to 192 issues and 63 to 64 settled inventory records

Megane MY24 technical applicability remains unresolved; current unyeared Megane evidence is distinct from residual MY24 stock and a future facelift. R5 Turbo 3E live reservations versus the earlier fully-presold report remains an explicit lead conflict, with no fabricated inventory ID or model review. Ordinary Renault 5 is not confirmed for Australia. Independent whole-market list requirements remain open, so global C1 does not pass.

Price and method holds are preserved: Megane reported $54,990 before on-road costs does not reuse an expired maker offer; Scenic published prices are before on-road costs. No 15–80% time is converted to 10–80%; the four genuine duration gaps remain. Megane charge-duration and height conflicts remain visible. Cargo, battery and Megane mirror measurement bases remain unknown where sources do not establish them.

## Envelope, outputs and later gates

One separately granted run with an exclusive heavy slot: Node v24.19.0, 448 MiB old space, 1 MiB semi-space, exposed GC, 420-second timeout and 10-second kill grace. Pin checks run before and after. Record invocation, raw wait status, exit code, duration, peak RSS and stdout/stderr hashes. No automatic retry or inference about an unexplained kill.

The composed script already passed a bounded syntax-only check: 10 seconds, Node 64 MiB, no imports or runtime execution. That is not TypeScript validation. The exact syntax receipt is pinned.

Outputs include all stage-by-stage complete-car/all-field digests, selected packs/claims/portable/Markdown, exact optional witnesses, source-reference neutrality, complete ranking structures, complete expected C1 comparison, metadata transitions and a stage receipt. No default catalogue loader, live source edit, registration, canonical recapture, broad feature replay, full normal report, server, browser or compiler is part of this command. A separately reviewed guarded integration and one later actual normal report remain required. Full-stage outputs require independent review before integration readiness.
