"""Static preparation of exactly five gates. No project parser or compiler invocation."""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,sys,runpy
R=Path('/workspace/scratch/586427eef9f2/roadmark-104');B=Path('/tmp/renault-packet/post-registration-checks-v4');A=Path('/tmp/renault-packet/registration-v1');O=Path('/tmp/cupra-packet/post-registration-checks-v1');T=Path('/tmp/kgm-packet/full-project-typescript-v1')
assert len(sys.argv)==2,'prepare.py INDEPENDENT_FULL_STAGE_OUTPUT_ACCEPTANCE'
fullStageReview=Path(sys.argv[1]);assert fullStageReview.is_file()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while x:=f.read(1024*1024):h.update(x)
 return h.hexdigest()
def pin(p):p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def verify(p):
 a=pin(p['path']);assert all(a[k]==v for k,v in p.items() if k!='realpath'),p['path']
 if 'realpath' in p:assert str(Path(p['path']).resolve())==p['realpath']
 return a
def write(p,x):
 with Path(p).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def meta(p):
 p=Path(p)
 if not p.exists():return dict(path=str(p),exists=False)
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
reg=json.loads((A/'manifest.json').read_text());writes=json.loads((A/'prepared-writes.json').read_text());assert reg['writes']==writes
assert [w['relativePath'] for w in writes]==['data/m1-brand-updates/registry.json','scripts/reporting/load.ts','data/m1-brand-updates/renault-2026-10-15.json','data/m1-renault-market-reconciliation-2026-10-15.json']
transitions=[]
for w in writes:
 verify(w['after']);assert Path(w['target'])==R/w['relativePath']
 if w['before'] is None:assert not Path(w['target']).exists()
 else:assert pin(w['target'])==dict(path=w['target'],**w['before']);verify(w['beforeCopy'])
 transitions.append(dict(path=w['target'],bytes=w['after']['bytes'],sha256=w['after']['sha256']))
oldregistry=json.loads((R/'data/m1-brand-updates/registry.json').read_text());newregistry=json.loads((A/'after/data/m1-brand-updates/registry.json').read_text())
assert newregistry['packets'][:-1]==oldregistry['packets'] and len(newregistry['packets'])==30 and newregistry['packets'][-1]=='renault-2026-10-15.json'
config=json.loads((R/'tsconfig.json').read_text());oldts=json.loads((T/'manifest.json').read_text());assert config==oldts['originalConfig']
for v in oldts['runtimeMetadata']:assert meta(v['path'])==v
scope=json.loads((T/'project-root-metadata.json').read_text());rootpaths=sorted({str(p.resolve())for pat in config['include']for p in R.glob(pat)if p.is_file()})
assert rootpaths==scope['configuredRootFilePaths'] and len(rootpaths)==361
for v in scope['fileMetadata']+scope['directoryState']:assert meta(v['path'])==v
load=str(R/'scripts/reporting/load.ts');assert not any(v['path']==load for v in scope['fileMetadata']);beforeload=meta(load)
scope.update(status='pre_registration_metadata_frozen_no_compiler_invocation',method='Retained KGM configured-root names and exact unchanged root stats; only load.ts has the explicit Renault30 content transition.',registrationStatTransitions=[dict(before=beforeload,expectedAfter=next(p for p in transitions if p['path']==load),runtimeContract='Bind expected post-registration bytes; capture then preserve target stat for each command')],note='361 configured root names are retained as an input-integrity guard only, not a TypeScript run. 360 unchanged root stats remain exact. All four registration targets receive per-command exact content and stat guards. Current full-project TypeScript remains UNPASSED.')
write(B/'project-root-metadata.json',scope)
pins={}
for p in json.loads((O/'source-pins.json').read_text()):a=verify(p);pins[a['path']]=a
for p in transitions:pins[p['path']]=p
for w in writes:p=pin(w['after']['path']);pins[p['path']]=p
for pth in [A/'manifest.json',A/'prepared-writes.json',R/'eslint.config.mjs',(R/'node_modules/eslint/bin/eslint.js').resolve()]:p=pin(pth);pins[p['path']]=p
closure=runpy.run_path(str(B/'close-inputs.py'))['build_closure'](R,A,B)
for p in closure:
 if p['path'] in pins:assert pins[p['path']]==p,p['path']
 pins[p['path']]=p
for f in [B/'close-inputs.py',B/'static-input-closure.json',Path('/tmp/renault-review/post-registration-v2-readiness-findings-v1.json')]:
 p=pin(f);pins[p['path']]=p
write(B/'source-pins.json',[pins[k]for k in sorted(pins)])
inventory=json.loads((O/'test-inventory.json').read_text())
for x in inventory.values():verify(x['source'])
write(B/'test-inventory.json',inventory)
# Preserve the accepted generic supervisor and guards. Unused report branch becomes manifest-bound.
wrapper=(O/'run.py').read_text().replace("==[427,350,309] and r['asOf']=='2026-10-15'","==m['expectedReportCounts'] and r['asOf']==m['asOf']")
ast.parse(wrapper)
with (B/'run.py').open('x')as f:f.write(wrapper)
write(B/'wrapper-syntax-check.json',dict(status='passed_python_ast_parse_only',wrapper=pin(B/'run.py'),wrapperExecuted=False,compilerRun=False))
node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node';base=lambda n:[node,'--max-old-space-size='+str(n),'--max-semi-space-size=1']
proofpaths=[str(fullStageReview),'/tmp/renault-packet/full-stage-v1/output/stage-receipt.json','/tmp/renault-packet/full-stage-v1/output/research-field-digests.json','/tmp/renault-review/selected-preflight-v5-results-v1.json','/tmp/kgm-packet/full-project-typescript-v1/run/terminal.json','/tmp/kgm-packet/full-project-typescript-v2/run/terminal.json','/tmp/kgm-packet/report-comparison-v2/typescript-failure-provenance.json']
extra=[pin(p)for p in proofpaths]
common=dict(status='frozen_not_executed_requires_review_and_root_grant',repo=str(R),qaRoot=str(B/'run'),exclusiveLock=str(B/'.exclusive-heavy.lock'),killAfterSeconds=10,automaticRetry=False,parallelExecutionAllowed=False,sourceMutationsAuthorized=False,sourcePins=pin(B/'source-pins.json'),rootMetadata=pin(B/'project-root-metadata.json'),testInventory=pin(B/'test-inventory.json'),wrapper=pin(B/'run.py'),registrationManifest=pin(A/'manifest.json'),registrationTargets=transitions,originalConfig=config,runtimeMetadata=oldts['runtimeMetadata'],environmentRemovals=oldts['environmentRemovals'],environmentOverrides={'NODE_DISABLE_COMPILE_CACHE':'1','FORCE_COLOR':'0','ESLINT_USE_FLAT_CONFIG':'true'},currentProjectTypeScript='UNPASSED; two retained KGM SIGKILL failures of unknown cause; no compiler retry')
behavior=json.loads((O/'behavioural-suites.json').read_text())['testFiles'];live=['tests/brand-live-safety.test.ts'];assert sum(inventory[p]['count']for p in behavior)==144 and inventory[live[0]]['count']==7
configs=[dict(id='market-view',kind='market',command=base(128)+['scripts/generate-market-view.mjs','--check'],timeoutSeconds=60),dict(id='changed-file-lint',kind='lint',command=base(256)+[str((R/'node_modules/eslint/bin/eslint.js').resolve()),'--no-config-lookup','--config',str(R/'eslint.config.mjs'),'--no-ignore','--no-cache','--concurrency','off','--max-warnings','0','--format','json','--','scripts/reporting/load.ts'],timeoutSeconds=180,lintFiles=['scripts/reporting/load.ts']),dict(id='behavioural-suites',kind='tests',command=base(512)+['--import','tsx','--test','--test-reporter=tap','--test-concurrency=1',*behavior],timeoutSeconds=600,testFiles=behavior,expectedTests=144),dict(id='live-brand-safety',kind='tests',command=base(512)+['--import','tsx','--test','--test-reporter=tap','--test-concurrency=1',*live],timeoutSeconds=600,testFiles=live,expectedTests=7),dict(id='structural-validation',kind='structural',command=base(448)+['--import','tsx','scripts/validate.ts'],timeoutSeconds=900,expectedStructuralCounts={'variants':430,'families':171,'generations':194,'criteria':69,'evidence':29670,'current':351,'outgoing':43,'provisional':36},expectedSourceReferences=3809,expectedPublicationIssues=15,expectedApprovedExternalAssets=0,immutableResearchSha256='010ded194b4d61cd7be606ce0cc332fa7e32906bba70abff2b5c38541e634657')]
sequence=[];previous=None
for c in configs:
 m={**common,**c,'runOutput':str(B/'run'/c['id']),'prerequisites':[]if previous is None else[previous],'extraPins':extra}
 write(B/(c['id']+'.json'),m);p=pin(B/(c['id']+'.json'));sequence.append(p);previous=dict(manifest=p,resultPath=str(B/'run'/c['id']/'result.json'))
write(B/'sequence.json',dict(status='frozen_not_executed_requires_review_and_root_grant',sequence=sequence,sourcePins=common['sourcePins'],rootMetadata=common['rootMetadata'],qaRoot=str(B/'run'),registrationManifest=common['registrationManifest'],registrationTargets=transitions,preparation=[pin(B/'prepare.py'),pin(B/'wrapper-syntax-check.json')],currentProjectTypeScript=common['currentProjectTypeScript'],compilerIncluded=False,noAutomaticRetry=True,normalReportAndComparatorIncluded=False,executionAuthorized=False))
write(B/'root-grant-template.json',dict(status='NOT_GRANTED',heavySlotExclusive=False,automaticRetry=False,parallelExecutionAllowed=False,granted=[],sequence=pin(B/'sequence.json'),reviewerAcceptance=None,registrationVerification=None))
write(B/'preparation-status.json',dict(status='prepared_not_executed',sequence=pin(B/'sequence.json'),wrapper=pin(B/'run.py'),sourcePinCount=len(pins),configuredRootCount=361,unchangedRootStatCount=360,onlyRootStatTransition=load,testCount=144,liveSafetyTestCount=7,registrationManifest=pin(A/'manifest.json'),projectParsersRun=False,testsRun=False,compilerRun=False,wrappersRun=False,sourceEdits=False))
assert not (B/'run').exists()
for v in scope['fileMetadata']+scope['directoryState']+[beforeload]:assert meta(v['path'])==v
print(json.dumps(dict(sequence=pin(B/'sequence.json'),sourcePinCount=len(pins),executed=False),indent=2))
