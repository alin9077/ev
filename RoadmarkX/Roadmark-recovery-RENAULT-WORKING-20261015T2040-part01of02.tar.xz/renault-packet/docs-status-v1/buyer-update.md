# Renault M1 update · 15 October 2026

## 1. What changed for a buyer
- Four existing versions are refreshed: Megane Techno EV60 and Scenic Techno EV60 / Techno Long Range EV87 / Esprit Alpine EV87. [Scenic maker prices](https://www.renault.com.au/vehicles/scenic-e-tech/) are **A$55,990 / A$59,990 / A$65,990 before on-road costs**, with WLTP combined ranges **430 / 625 / 625 km**. [Megane](https://www.renault.com.au/vehicles/megane-e-tech/) retains 454 km; its **A$54,990 before-on-road price is Reported by CarsGuide**, since the current maker page says POA. Expired offers and the separate MY24 dealer price are not applied
- **68 core cells reviewed, 64 filled: 61 Confirmed, one Check, two Reported and four Not published.** Every version has a supported strength and trade-off. All four genuine DC 10–80% times remain unavailable after two-source checks. Published 15–80% figures stay separately labelled; none is converted. Three unsupported inherited charging-ranking entries are removed
- Confirmed battery and boot numbers remain visible with their limits: battery gross/usable basis and boot measurement method are unstated. Boot values therefore remain unranked. Megane's 1,768 mm width has no confirmed mirror treatment; Scenic's 1,864 mm means mirrors folded. Megane's height is **1,505 versus 1,500 mm**, and its 15–80% time **30 versus 35 minutes** across sources, with comparison holds
- [Vehicle warranty](https://www.renault.com.au/warranty/) is **five years / 100,000 km**; battery cover is **eight years / 160,000 km**, with the maker's published 70% capacity term. That wording does not establish a test, remedy floor or replacement entitlement. [Roadside assistance](https://www.renault.com.au/roadside-assistance/) now consistently reads **“5 years”** in facts and equipment. Benefit limits, care conditions and demonstrator balances remain attached; no fresh warranty start is invented
- Current maker lists cover both families, but listing is not physical stock or an accepted order. Scenic's inherited family is reconciled; Megane's separate MY24 residual advertisement still lacks a proven match to the current technical specification. The distinct R5 Turbo 3E reservation/allocation conflict remains open. Regular Renault 5 and overseas/future updates are not added as current Australian versions

## 2. Fresh coverage report

{{COVERAGE_TABLE}}

Figures are filled / Confirmed; warranty means vehicle warranty; “In rankings” means all six lists. Totals: **430 catalogue / 353 Tier 1 / 312 on sale**, across 30 dated packets. Global review: **5,098/5,304 core cells; 292 strict gaps**. Renault C3/C4/C6 pass; C1/C2/C5 remain open. Global C1–C5 remain open and C6 passes. No national-best claim is made.

**Research done (14):** Audi, BYD, GAC, Geely, IM, Jaecoo, KGM, Kia, MG, MINI, Mazda, Tesla, Toyota, Zeekr. **Remaining (42):** ACE EV, Abarth, Alfa Romeo, BMW, CUPRA, Cadillac, Chery, Chevrolet, Deepal, Denza, Fiat, Ford, GMC, GWM, Genesis, Honda, Hyundai, Isuzu, JAC, Jaguar, Jeep, LDV, Leapmotor, Lexus, Lotus, Maserati, Mercedes-Benz, Nissan, Polestar, Porsche, Renault, Roev, Subaru, Suzuki, Tembo, Volkswagen, Voltra, Volvo, XPENG, ZERO Automotive, smart, Škoda. Renault is not research-complete; no brand meets all C1–C6.

**Unmatched audit entries (18; sale eligibility unresolved):** BMW i3/i5; GMC Hummer EV SUV/Pickup/Sierra EV; LDV MIFA 9/eT60/eTerron 9; Mercedes-Benz EQV; ACE EV Yewt/Mini Yewt; Chevrolet Silverado EV; Ford F-150 Lightning; JAC T9 EV; Roev HiLux conversion; Tembo Tusker; Maserati GranTurismo/GranCabrio/Grecale. C1 has 105 model reviews, 238 version reviews and 192 issues; two complete independent lists remain absent. There are 23 unresolved leads. The R5 Turbo 3E conflict is separately retained without inventing an inventory identity.

## 3. Phone screenshots
Unavailable: no Renault preview, browser or screenshot attempt occurred. Phone and protected-hero visual checks remain unverified; the hero source is unchanged.

## 4. What did not work
**Current full-project TypeScript and release remain unpassed.** Two earlier KGM compiler attempts ended in unknown-cause SIGKILL, with empty output and no fresh cache. No Renault compiler retry occurred. The first actual Renault normal-report invocation was interrupted without a terminal receipt or report output; its result and cause remain **UNKNOWN**. A separately authorized fresh attempt passed, followed by its saved-output comparison. These are two actual report invocations: one unknown, one successful.

Market-view, changed-file lint, **151 scoped tests**, structural validation, the fresh actual normal report and exhaustive comparator pass and are independently accepted. All **426 other cars** remain exact; all 2,029 report changes are accounted for. This is not a full-project suite, build, mobile or release pass. Earlier rejected preparations and the corrected roadside display are preserved in the audit history.

## 5. Decisions needed
None for this factual update. M1 remains unfinished; M2 and publishing have not started. Next brand awaits selection. Renault recovery capture/delivery is pending.

[Detailed audit and check receipts](M1_PROGRESS.md) · [Dated packet](../data/m1-brand-updates/renault-2026-10-15.json) · [Reconciliation](../data/m1-renault-market-reconciliation-2026-10-15.json)
