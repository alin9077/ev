"""Apply exactly four reviewed Renault documentary files after an exact root grant.

This file is preparation only. It never invokes a project producer, test, compiler,
server, browser or archive operation. There is no automatic retry or rollback.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import sys

BASE = Path('/tmp/renault-packet/docs-status-v1')
WORKSPACE = Path('/workspace/scratch/586427eef9f2')
RELATIVE_TARGETS = [
    'roadmark-104/docs/RENAULT_M1_UPDATE.md',
    'roadmark-104/docs/M1_PROGRESS.md',
    'roadmark-104-qa/work-status.json',
    'roadmark-104/docs/BACKLOG.md',
]

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def check(pin):
    path = Path(pin['path'])
    assert path.is_file() and not path.is_symlink(), str(path)
    assert path.stat().st_size == pin['bytes'] and sha(path) == pin['sha256'], str(path)

def now():
    return datetime.now(timezone.utc).isoformat()

assert len(sys.argv) == 5, 'apply.py MANIFEST SHA256 ROOT_GRANT SHA256'
manifest_path, manifest_hash, grant_path, grant_hash = sys.argv[1:]
assert Path(manifest_path).resolve() == BASE / 'manifest.json'
assert sha(manifest_path) == manifest_hash and sha(grant_path) == grant_hash
manifest = json.loads(Path(manifest_path).read_text())
grant = json.loads(Path(grant_path).read_text())
assert grant['status'] == 'root_application_granted'
assert grant['action'] == 'apply_exact_renault_docs_status'
assert grant['manifest']['path'] == str(Path(manifest_path).resolve())
assert grant['manifest']['sha256'] == manifest_hash
check(grant['manifest'])
assert grant['automaticRetry'] is False and grant['heavyExecutionAuthorized'] is False
assert manifest['rootGrantRequired'] is True
assert manifest['automaticRetry'] is False and manifest['heavyChecksAllowed'] is False
check(grant['reviewerAcceptance'])
review = json.loads(Path(grant['reviewerAcceptance']['path']).read_text())
assert review['status'] == 'accepted', 'Independent documentary review must be accepted'
assert review['manifest']['sha256'] == manifest_hash, 'Review must name this exact manifest'
check(manifest['applicator'])
assert Path(__file__).resolve() == Path(manifest['applicator']['path'])
check(manifest['preparer'])
check(manifest['patch'])
for proof in manifest['proofs']:
    check(proof)
assert Path(manifest['repo']).resolve() == WORKSPACE
assert len(manifest['writes']) == 4
assert [row['relativePath'] for row in manifest['writes']] == RELATIVE_TARGETS
assert grant['allowedTargets'] == [str(WORKSPACE / relative) for relative in RELATIVE_TARGETS]
for row in manifest['writes']:
    path = Path(row['target'])
    assert path == WORKSPACE / row['relativePath']
    assert path.resolve() == path and path.parent.is_dir() and not path.is_symlink()
    assert Path(row['after']['path']) == BASE / 'after' / row['relativePath']
    check(row['after'])
    if row['before'] is None:
        assert row['operation'] == 'create' and not path.exists()
        assert row['beforeCopy'] is None
    else:
        assert row['operation'] == 'replace'
        assert Path(row['beforeCopy']['path']) == BASE / 'before' / row['relativePath']
        check(row['beforeCopy'])
        check(row['before'])
        assert row['before']['path'] == str(path)
        assert row['beforeCopy']['sha256'] == row['before']['sha256']
progress = manifest['writes'][1]
assert Path(progress['after']['path']).read_bytes().startswith(Path(progress['beforeCopy']['path']).read_bytes())
backlog = manifest['writes'][3]
assert Path(backlog['after']['path']).read_bytes() == Path(backlog['beforeCopy']['path']).read_bytes() + manifest['backlogAppend'].encode()
old_status = json.loads(Path(manifest['writes'][2]['beforeCopy']['path']).read_text())
new_status = json.loads(Path(manifest['writes'][2]['after']['path']).read_text())
assert new_status['workStatusHistory'][:-1] == old_status['workStatusHistory']
changed_fields = set(manifest['historyPreservation']['changedCurrentFields'])
assert new_status['workStatusHistory'][-1]['previous'] == {
    key: old_status[key] for key in changed_fields if key in old_status
}
for key in old_status:
    if key not in changed_fields and key != 'workStatusHistory':
        assert new_status[key] == old_status[key], key

out = BASE / 'application'
out.mkdir(exist_ok=False)

def receipt(name, value):
    with (out / name).open('x') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())

receipt('started.json', dict(at=now(), manifestSha256=manifest_hash, grantSha256=grant_hash,
                            beforeGuardsPassed=True, heavyExecution=False))
completed = []
try:
    for index, row in enumerate(manifest['writes'], 1):
        path = Path(row['target'])
        content = Path(row['after']['path']).read_bytes()
        assert hashlib.sha256(content).hexdigest() == row['after']['sha256']
        if row['operation'] == 'create':
            with path.open('xb') as stream:
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
        else:
            assert sha(path) == row['before']['sha256']
            with path.open('wb') as stream:
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
        assert sha(path) == row['after']['sha256']
        completed.append(dict(target=str(path), sha256=sha(path)))
        receipt(f'write-{index}.json', completed[-1])
    for row in manifest['writes']:
        assert sha(row['target']) == row['after']['sha256']
    for proof in manifest['proofs']:
        check(proof)
    receipt('result.json', dict(at=now(), passed=True, manifestSha256=manifest_hash,
                               grantSha256=grant_hash, writes=completed,
                               heavyExecution=False, automaticRetry=False))
except Exception as error:
    receipt('failure.json', dict(at=now(), error=repr(error), completedWrites=completed,
                                automaticRollback=False, automaticRetry=False))
    raise
print(json.dumps(dict(passed=True, writes=len(completed), receipt=str(out / 'result.json'))))
