#!/usr/bin/env python3
"""Build exact fresh-over-prior restore metadata and human-readable delivery documents."""
import datetime,json,sys
from capture_v1 import *
LABEL='RENAULT-WORKING-20261015T2040';DATE='20261015';D=C/'deliverables'
def ref(p):return {'path':str(p),**pin(p)}
def retained_metadata(p):
 b=p.read_bytes();return {'file':{'path':str(p), 'bytes':len(b),'sha256':sha(b)},'utf8':b.decode('utf8')}
def receipts():
 want={a['filename']:a for a in load(C/'ARCHIVE-PLAN.json')['archives']};result=[];seen=set()
 for p in sorted(C.glob('scan-fresh-*.json')):
  if '.resources.' in p.name:continue
  d=load(p)
  if 'regularFilesScanned' not in d:continue
  assert d['status']=='clean';name=d['archive'];assert name in want and name not in seen;seen.add(name);a=want[name];assert d['archivePin']=={k:a[k] for k in ['bytes','sha256']};assert d['regularFilesScanned']==a['members']
  terminal=p.with_name(p.stem+'.resources.json');invocation=p.with_name(p.stem+'.resources.invocation.json');t=load(terminal);i=load(invocation)
  assert t['exitCode']==0 and not t['timedOut'];assert t['command']==i['command'];assert a['file'] in t['command'] and str(p) in t['command']
  result.append({'report':ref(p),'archive':name,'archivePin':d['archivePin'],'terminal':ref(terminal),'invocation':ref(invocation)})
 assert seen==set(want);return result
def postseal_evidence(scans):
 # Preserve newly generated receipt bytes absent from the sealed support archive.
 kept={r['originalPath'] for r in load(C/'SUPPORT-MEMBER-INVENTORY.json')['files']};kept.update(r['originalPath'] for r in load(C/'SUPPORT-REUSE-MAPPING.json')['files']);paths=set()
 for r in scans:
  for key in ['report','terminal','invocation']:
   q=P(r[key]['path'])
   if str(q) not in kept:paths.add(q)
 for folder in ['seed-read-invocations','audi-seed-read-invocations','deepal-seed-read-invocations']:
  paths.update(q for q in (C/folder).glob('*.json') if str(q) not in kept)
 paths.add(C/'ARCHIVE-UPLOAD-IDENTITIES.json')
 paths.add(C/'ARCHIVE-NATIVE-READBACK-v1.json')
 paths.add(C/'INDEPENDENT-RENAULT-RECOVERY-VERIFICATION-v1.json')
 paths.add(C/'INDEPENDENT-NEW-MEMBER-REPLAY-MANIFEST-v1.json')
 paths.add(C/'independent-recovery-v1.resources.json')
 paths.add(C/'independent-recovery-v1.resources.invocation.json')
 # Exact late metadata whitelist; no executable source or payload tree walk.
 late=['SUPPORT-SELECTION-v2.json','SUPPORT-MEMBER-INVENTORY.json','SUPPORT-PATTERN-SELECTION-v1.json','SUPPORT-PATTERN-CANDIDATES-v2.json','support-package.json','ARCHIVE-PLAN.json','RESTORE-PLAN.json']
 for name in ['prepare-support-v2','preflight-support-patterns-v2','package-support-v1','build-plan-v1']:
  late.extend([name+'.resources.json',name+'.resources.invocation.json','run-logs/'+name+'.stdout.log','run-logs/'+name+'.stderr.log'])
 paths.update(C/name for name in late)
 return [retained_metadata(q) for q in sorted(paths)]
def restore_plan():
 basepath=BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-CUPRA-WORKING-20261015.json';base=load(basepath);br=load(BASE/'FINAL-CUPRA-UPLOAD-RECEIPTS.json');new=load(C/'ARCHIVE-PLAN.json')['archives'];source=load(C/'source-package.json');oldsource=br['files'][0]['filename'];ars=[{**a,'new':False} for a in base['archivesInRestoreOrder'] if a['filename']!=oldsource];assert len(ars)==137
 for a in new:ars.append({k:v for k,v in a.items() if k!='memberFiles'})
 for i,a in enumerate(ars,1):a['restoreOrder']=i
 files={r['path']:r for r in base['files'] if not r['path'].startswith('roadmark/')}
 fresh=[]
 for a in new:
  for r in a['memberFiles']:files[r['path']]=r;fresh.append(r)
 assert len(fresh)==len({r['path'] for r in fresh})
 p={'status':'EXACT_NEW_ARCHIVES_PLUS_REUSED_PRIOR_CHAIN','archivesInRestoreOrder':ars,'files':list(files.values()),'newFiles':fresh,'newArchives':new,'source':source,'baseManifest':ref(basepath),'baseFinalReceipt':ref(BASE/'FINAL-CUPRA-UPLOAD-RECEIPTS.json'),'baseTerminalReceipt':ref(BASE/'INDEPENDENT-CUPRA-TERMINAL-CLOSURE-v1.json'),'fullSourceFiles':700,'sourceArchiveMembers':701,'sourceChangedPaths':load(C/'FROZEN-CAPTURE-SCOPE.json')['sourceChangedPaths'],'baseArchivesReused':137,'archiveCount':len(ars),'logicalFiles':len(files),'logicalBytes':sum(r['bytes'] for r in files.values()),'freshFiles':len(fresh),'freshBytes':sum(r['bytes'] for r in fresh),'sourceFullCloneCreated':False}
 dump(C/'RESTORE-PLAN.json',p);return p
def bind_identities(p):
 identities=load(C/'ARCHIVE-UPLOAD-IDENTITIES.json')['files'];by={r['filename']:r for r in identities};assert set(by)=={a['filename'] for a in p['newArchives']}
 def bind(a):
  if a['filename'] not in by:return dict(a)
  r=by[a['filename']];assert (a['bytes'],a['sha256'])==(r['bytes'],r['sha256']);return {**a,**{k:r[k] for k in ['library_file_id','file_id','version']}}
 return {**p,'source':bind(p['source']),'archivesInRestoreOrder':[bind(a) for a in p['archivesInRestoreOrder']],'newArchives':[bind(a) for a in p['newArchives']]}
def docs():
 D.mkdir(exist_ok=True);p=bind_identities(load(C/'RESTORE-PLAN.json'));scope=load(C/'FROZEN-CAPTURE-SCOPE.json');br=load(BASE/'FINAL-CUPRA-UPLOAD-RECEIPTS.json');ind=load(C/'INDEPENDENT-RENAULT-RECOVERY-VERIFICATION-v1.json');assert str(ind['result']).startswith('PASS');scans=receipts();assert len(scans)==len(p['newArchives'])
 manifest={'schemaVersion':10,'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'title':'Roadmark Renault30 working recovery','status':'WORKING_FACTUAL_UPDATE_BROADER_RELEASE_GATES_OPEN','workState':scope['workingResult'],'source':{k:v for k,v in p['source'].items() if k!='memberFiles'},'baseRecovery':{'sourceLibraryFileId':br['sourceLibraryFileId'],'manifestLibraryFileId':br['manifestLibraryFileId'],'activeReceiptLibraryFileId':br['activeReceiptLibraryFileId'],'manifest':p['baseManifest'],'finalReceipt':p['baseFinalReceipt'],'terminalReceipt':p['baseTerminalReceipt'],'priorArchiveCount':138,'priorLogicalFiles':14062,'priorFreshVerifiedFiles':1378},'archivesInRestoreOrder':p['archivesInRestoreOrder'],'newArchives':[{k:v for k,v in a.items() if k!='memberFiles'} for a in p['newArchives']],'files':p['files'],'counts':{k:p[k] for k in ['fullSourceFiles','sourceArchiveMembers','archiveCount','logicalFiles','logicalBytes','freshFiles','freshBytes','baseArchivesReused']},'currentValidation':scope['currentValidation'],'captureScope':ref(C/'FROZEN-CAPTURE-SCOPE.json'),'copyOnlySanitation':load(C/'COPY-SANITATION-MAPPING.json'),'independentVerification':ref(C/'INDEPENDENT-RENAULT-RECOVERY-VERIFICATION-v1.json'),'privacyVerification':scans,'currentImageProvenance':load(C/'IMAGE-PROVENANCE.json'),'currentRawRuntimeExclusion':scope['rawRuntimeExclusion'],'freshSupportReuse':ref(C/'SUPPORT-REUSE-MAPPING.json'),'dependencyClosure':ref(C/'INDEPENDENT-RENAULT-REFERENCE-CLOSURE-v1.json'),'inheritedDependencyReconstruction':{'receipt':ref(C/'INDEPENDENT-RENAULT-REFERENCE-CLOSURE-v1.json'),'count':291,'dependencies':load(C/'INDEPENDENT-RENAULT-REFERENCE-CLOSURE-v1.json')['inheritedDependencyProposal']['dependencies'],'dependenciesCanonicalSha256':load(C/'INDEPENDENT-RENAULT-REFERENCE-CLOSURE-v1.json')['inheritedDependencyProposal']['canonicalSha256'],'relocatedMemberPointers':0,'newRecords':15,'originalExpectedPathsAndHashesUnchanged':True},'postSealEvidenceLocation':'Exact post-seal receipt bytes are embedded in the matching recovery verification document.','inheritedRecoveryMetadata':'All unchanged sanitation/replay/exclusion/image and dependency provenance remains in the exact CUPRA manifest and its retained chain; referenced identities are immutable historical evidence, not newly rescanned proof.','inheritedBoundaries':['Original CUPRA interrupted scan outcome remains UNKNOWN; separately completed seed reads remain counted, and the later successful scan is distinct.','CUPRA local-only redundant diagnostic-diff disclosure is preserved by its exact prior manifest and receipts.','Unavailable original mutable CUPRA-v1 preparation bytes are not reconstructed or claimed retained.','Two KGM compiler attempts ended in unknown-cause SIGKILL; no current full-project TypeScript or release pass.','Earlier raw excluded Deepal/KGM/CUPRA payloads are not read, recovered or refetched.','Historical product/browser/phone screenshots or passes are not current Renault UI verification.'],'restoreInstructions':['Fetch the exact archives listed in restoreOrder; 137 prior archives are reused unchanged.','Extract in restoreOrder into one clean recovery directory; use the new standalone source archive in place of the CUPRA source archive.','Verify every resulting regular file against files; expected project directory is roadmark with700 project files plus its embedded manifest.','Use the copy-only mapping only when reconstructing exact original ordinary-prose receipts; stored copied hashes and original expected hashes are distinct.','Apply the original-path and compact dependency mappings when replaying retained scripts in another filesystem. No dependency installation, application execution or release validation is performed by this restore check.'],'noDeletionOrReplacement':True,'noPinnedSourceOrStatusMutation':True,'noExecutableSourceTextEmbedded':True,'fullProjectTypeScriptPassed':False,'releaseReady':False}
 dump(D/f'Roadmark-RECOVERY-MANIFEST-RENAULT-WORKING-{DATE}.json',manifest)
 verification={'status':'RECOVERY_VERIFIED_APPLICATION_RELEASE_UNPASSED','counts':manifest['counts'],'independent':ind,'privacyReports':scans,'postSealEvidence':postseal_evidence(scans),'currentValidation':scope['currentValidation'],'limitations':manifest['inheritedBoundaries'],'scope':'Fresh new archive members independently replayed, prior chain exact metadata reused; no broad historical archive scan or full clone','fullProjectTypeScriptPassed':False,'releaseReady':False}
 dump(D/f'Roadmark-RECOVERY-VERIFICATION-RENAULT-WORKING-{DATE}.json',verification)
 lines=['# Roadmark Renault30 working recovery','','This is a verified working safety save. Current full-project TypeScript and release acceptance remain open.','',scope['workingResult'],'',f"Source: {p['source']['filename']} ({p['source']['bytes']:,} bytes; SHA-256 {p['source']['sha256']})",f"Restore set: {p['archiveCount']} archives; {p['logicalFiles']:,} logical files; {p['freshFiles']:,} fresh verified members. {p['baseArchivesReused']} prior archives reused without a broad base scan.",'','## Restore','']+manifest['restoreInstructions']+['','## Boundaries','']+manifest['inheritedBoundaries']+['','## Archive order','']
 for a in p['archivesInRestoreOrder']:lines.append(f"{a['restoreOrder']}. {a['filename']} | {a['bytes']} bytes | SHA-256 {a['sha256']} | Library {a.get('library_file_id','pending new-file persistence')}")
 with (D/f'Roadmark-RECOVERY-INDEX-RENAULT-WORKING-{DATE}.md').open('x') as f:f.write('\n'.join(lines)+'\n')
 sr=next(r for r in load(C/'source-capture.json')['files'] if r['path']=='docs/RENAULT_M1_UPDATE.md');sp=P(sr['payloadPath']);check(sp,sr);before=identity(sp);raw=sp.read_bytes();assert identity(sp)==before and {'bytes':len(raw),'sha256':sha(raw)}=={k:sr[k] for k in ['bytes','sha256']};summary=raw.decode('utf8')
 with (D/f'Roadmark-RENAULT-M1-UPDATE-{DATE}.md').open('x') as f:f.write(summary+'\n\n## Recovery note\n\n'+scope['workingResult']+'\n')
 print(json.dumps({'documents':4,'archiveCount':p['archiveCount'],'logicalFiles':p['logicalFiles']}))
if __name__=='__main__':{'plan':restore_plan,'docs':docs}[sys.argv[1]]()
