#!/usr/bin/env python3
"""Resolve exact frozen JSON references from metadata only; no external payload reads."""
import collections, copy, datetime, hashlib, json, pathlib, resource, time
P=pathlib.Path; C=P(__file__).resolve().parent; B=C.parent/'cupra-working-20261015T1745'; W=C.parents[2]; LIMIT=256*1024*1024

def pin(p):
 p=P(p);h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while q:=f.read(65536):h.update(q);n+=len(q)
 return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
def load(p):return json.loads(P(p).read_text())
def core(r):return {k:r[k] for k in ('path','bytes','sha256')}
def key(r):return r['bytes'],r['sha256']
def check(p,r):
 got=pin(p);assert all(got[k]==r[k] for k in ('bytes','sha256')),str(p);return got

def main():
 resource.setrlimit(resource.RLIMIT_AS,(LIMIT,LIMIT));start=time.monotonic()
 mp=B/'deliverables/Roadmark-RECOVERY-MANIFEST-CUPRA-WORKING-20261015.json';check(mp,{'bytes':3476229,'sha256':'d1eaf85b9254160820f9f98e622cb6ad821b8d85a8c7bf1dd8e237d4faa6b12b'})
 scope=load(C/'FROZEN-CAPTURE-SCOPE.json');base=load(mp);old={r['path']:r for r in base['files']};assert len(old)==14062
 cap=load(C/'proof-capture-v1.json');src=load(C/'source-capture.json');assert len(cap['files'])==608 and len(src['files'])==700
 assert {r['originalPath'] for r in cap['files']}=={r['path'] for r in scope['files']}
 aps=[load(C/'source-package.json')]+load(C/'proof-packages-v1.json')['archives'];newidx={};archive_by_name={a['filename']:a for a in base['archivesInRestoreOrder']+aps}
 for a in aps:
  for r in a['memberFiles']:
   assert r['path'] not in newidx;newidx[r['path']]={'member':core(r),'archives':[a['filename']],'partResolution':'Exact single archive'}
 pri=load(B/'INDEPENDENT-CUPRA-DEPENDENCY-PROPOSAL-v1.json');mapping={r['member']['path']:copy.deepcopy(r['mapping']) for r in pri['resolvedCupraRequirements']}
 priorplan=load(B/'RESTORE-PLAN.json')
 # Reuse the pinned historical Audi archive-plan authority from the accepted CUPRA proposal.
 audiPin=next(r for r in pri['metadataMappingSources'] if r['path'].endswith('/audi-working-20261015T0800/ARCHIVE-PLAN-v4.json'))
 check(audiPin['path'],audiPin);audiPlan=load(audiPin['path'])
 for a in audiPlan['archives']:
  for r in a['memberFiles']:
   if r['path'] in old and core(r)==core(old[r['path']]):mapping.setdefault(r['path'],{'archives':[a['filename']],'partResolution':'Exact single archive','member':core(r),'mappingBasisRef':audiPin['path']})
 for a in priorplan['newArchives']:
  for r in a['memberFiles']:mapping[r['path']]={'archives':[a['filename']],'partResolution':'Exact single archive','member':core(r),'mappingBasisRef':str(B/'RESTORE-PLAN.json')}
 allfresh=collections.defaultdict(set);allold=collections.defaultdict(set);originals=collections.defaultdict(set)
 for n,r in newidx.items():allfresh[key(r['member'])].add(n)
 for n,r in old.items():allold[key(r)].add(n)
 renames=load(C/'PROSE-KEY-RENAME-APPROVALS.json')['files'];rename_by={r['restorePath']:r for r in renames};assert len(rename_by)==10
 for r in cap['files']:
  if (r['bytes'],r['sha256'])!=(r['originalBytes'],r['originalSHA256']):
   assert r['path'] in rename_by;originals[(r['originalBytes'],r['originalSHA256'])].add(r['path'])
 byoriginal={r['originalPath']:r for r in cap['files']};requirements={};metadata=[]
 def visit(v,origin):
  if isinstance(v,dict):
   if isinstance(v.get('path'),str) and v['path'].startswith('/') and isinstance(v.get('bytes'),int) and isinstance(v.get('sha256'),str) and len(v['sha256'])==64:
    requirements.setdefault((v['path'],v['bytes'],v['sha256']),set()).add(origin)
   for x in v.values():visit(x,origin)
  elif isinstance(v,list):
   for x in v:visit(x,origin)
 for r in scope['files']:
  if P(r['path']).suffix!='.json':continue
  row=byoriginal[r['path']];p=P(row['payloadPath']);got=check(p,row);v=load(p);visit(v,len(metadata));metadata.append({'originalPath':r['path'],'storedMember':row['path'],'storedPin':{k:got[k] for k in ('bytes','sha256')}})
 def logical(path):
  p=P(path)
  if p.is_relative_to('/tmp'):return p.relative_to('/tmp').as_posix()
  if p.is_relative_to(W/'roadmark-104'):return 'roadmark/'+p.relative_to(W/'roadmark-104').as_posix()
  if p.is_relative_to(W):return p.relative_to(W).as_posix()
  return None
 def pick(names,path):
  n=logical(path)
  if n in names:return n
  # Identical content copies are acceptable only with explicit destination mapping.
  return sorted(names)[0]
 result=[];counts=collections.Counter();external=[];excluded=[];deps=copy.deepcopy(base['inheritedDependencyReconstruction']['dependencies']);depby={r['originalPath']:r for r in deps};newrecords=0;newvariants=0;archive_names=set()
 for (path,n,h),origins in sorted(requirements.items()):
  k=(n,h);r={'expected':{'path':path,'bytes':n,'sha256':h},'nominatedBy':sorted(origins)}
  if allfresh[k]:
   name=pick(allfresh[k],path);m=newidx[name];r.update(kind='fresh-exact',member=name,archives=m['archives']);archive_names.update(m['archives'])
  elif originals[k]:
   name=pick(originals[k],path);a=rename_by[name];m=newidx[name];r.update(kind='fresh-reversible-original',member=name,archives=m['archives'],storedPin={z:a[z] for z in ('bytes','sha256')},inverse={'replaceKeyOnce':{'from':'approvalScope','to':'authorization'},'valueAndOtherBytesUnchanged':True,'mapping':str(C/'COPY-SANITATION-MAPPING.json')});archive_names.update(m['archives'])
  elif allold[k]:
   possible=allold[k];direct=logical(path);name=direct if direct in possible else pick(possible,path);assert name in mapping,'No exact archive attribution '+name;m=mapping[name]
   assert set(m['archives'])<=set(archive_by_name)
   if 'member' in m:assert core(m['member'])==core(old[name]),name
   r.update(kind='base-exact',member=name,archives=m['archives'],partResolution=m['partResolution']);archive_names.update(m['archives']);external.append(r)
   pr={'expected':r['expected'],'reconstructFrom':'exact inherited recommended-chain member','member':core(old[name])}
   if path not in depby:
    new={'originalPath':path,'pins':[pr]};deps.append(new);depby[path]=new;newrecords+=1
   elif not any(x['expected']==pr['expected'] and x['member']==pr['member'] for x in depby[path]['pins']):depby[path]['pins'].append(pr);newvariants+=1
  else:
   p=P(path)
   if path=='/usr/bin/timeout':category='external-system-binary'
   elif p.is_relative_to(W/'roadmark-104/node_modules'):category='installed-package-toolchain'
   elif p.is_relative_to(W/'roadmark-104/.next'):category='generated-next-types'
   elif path==str(W/'roadmark-104/tsconfig.tsbuildinfo'):category='reconstructible-compiler-cache'
   else:raise AssertionError('Unresolved non-runtime reference '+path)
   r.update(kind='reference-only-runtime-exclusion',category=category,reconstruction='Not supplied by recovery; require a separately authorized compatible runtime and check the recorded expected pin before historical proof rerun. Generated bytes are not promised to reproduce exactly.');excluded.append(r)
  counts[r['kind']]+=1;result.append(r)
 assert len(result)==957 and len(excluded)==27 and len(external)==140 and counts['fresh-reversible-original']==9
 changed={'roadmark/'+n for n in scope['sourceChangedPaths']};intersections=[x for d in base['inheritedDependencyReconstruction']['dependencies'] for x in d['pins'] if x['member']['path'] in changed];assert not intersections
 for d in deps:
  for r in d['pins']:assert core(old[r['member']['path']])==core(r['member']) and key(r['expected'])==key(r['member'])
 raw=json.dumps(deps,sort_keys=True,separators=(',',':')).encode();pins=[pin(p) for p in [mp,B/'RESTORE-PLAN.json',B/'INDEPENDENT-CUPRA-DEPENDENCY-PROPOSAL-v1.json',C/'FROZEN-CAPTURE-SCOPE.json',C/'proof-capture-v1.json',C/'source-capture.json',C/'source-package.json',C/'proof-packages-v1.json',C/'PROSE-KEY-RENAME-APPROVALS.json',C/'COPY-SANITATION-MAPPING.json']]
 out={'schemaVersion':1,'result':'PASS_EXACT_METADATA_ONLY_REFERENCE_CLOSURE','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script':pin(__file__),'inputPins':pins+[audiPin],'priorMetadataPreparationFailure':pin(C/'REFERENCE-CLOSURE-v1-PREPARATION-FAILURE.json'),'summary':dict(counts),'metadataSources':metadata,'requirements':result,'archiveIdentities':[{k:a[k] for k in ('filename','bytes','sha256','library_file_id','file_id','version') if k in a} for a in [archive_by_name[n] for n in sorted(archive_names)]],'originalExpectedPathsAndHashesUnchanged':True,'transformedBytesNeverClaimOriginalHash':True,'inheritedSanitationAuthorities':{'baseManifest':pin(mp),'jsonPointers':['/copyOnlySanitation','/inheritedCopyOnlySanitation','/currentRawCaptureReplayLimitation','/inheritedCurrentRawCaptureReplayLimitation']},'inheritedDependencyProposal':{'inheritedRecords':len(base['inheritedDependencyReconstruction']['dependencies']),'newRecords':newrecords,'newPinVariants':newvariants,'proposedRecords':len(deps),'canonicalSha256':hashlib.sha256(raw).hexdigest(),'dependencies':deps,'inheritedChangedSourceIntersections':intersections},'scope':{'externalPayloadReads':0,'archivePayloadReads':0,'seedValueReads':0,'metadataOnly':True,'noLiveWrites':True,'excludedRuntimeBytesNotReadOrRecaptured':True,'freshReplayStillRequired':True},'resources':{'wallSeconds':round(time.monotonic()-start,3),'maxRssKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'addressSpaceLimitBytes':LIMIT}}
 dest=C/'INDEPENDENT-RENAULT-REFERENCE-CLOSURE-v1.json'
 with dest.open('x') as f:json.dump(out,f,indent=2);f.write('\n')
 print(json.dumps({'output':pin(dest),'requirements':len(result),'counts':dict(counts),'newDependencyRecords':newrecords,'newPinVariants':newvariants,'dependencyRecords':len(deps)}))
if __name__=='__main__':main()
