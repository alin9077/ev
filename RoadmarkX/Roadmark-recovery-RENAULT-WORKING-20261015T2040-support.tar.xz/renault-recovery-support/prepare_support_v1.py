#!/usr/bin/env python3
"""Capture an explicit compact support selection; reuse exact retained code bytes."""
import shutil,sys
from capture_v1 import *
def main():
 selection=load(C/'SUPPORT-SELECTION-v1.json');basepath=BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-CUPRA-WORKING-20261015.json';base=load(basepath);by={}
 for r in base['files']:by.setdefault((r['bytes'],r['sha256']),[]).append(r)
 authorityPath=C/'SUPPORT-REUSE-ARCHIVE-AUTHORITY.json';authority=load(authorityPath);attribution={r['member']['path']:r for r in authority['files']}
 out=C/'support-staging-v1';out.mkdir(exist_ok=False);rows=[];reuse=[]
 for r in selection['files']:
  p=P(r['originalPath']);got,ident=check(p,r);name=r['localRelativePath'];safe(name)
  matches=by.get((got['bytes'],got['sha256']),[])
  if matches:
   available=[m for m in matches if m['path'] in attribution];assert available,'Missing exact archive attribution: '+name
   m=sorted(available,key=lambda x:x['path'])[0];a=attribution[m['path']];assert a['member']==m
   reuse.append({'originalPath':str(p),'localRelativePath':name,'retainedMember':m['path'],**got,'kind':'exact-prior-member-reuse','retainedArchive':a['archive'],'archiveMappingAuthority':a['metadataAuthority']});continue
  dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True)
  with p.open('rb') as src,dest.open('xb') as dst:
   shutil.copyfileobj(src,dst,CHUNK)
  check(dest,got);assert identity(p)==ident
  rows.append({'path':'renault-recovery-support/'+name,'payloadPath':str(dest),'originalPath':str(p),**got})
 mapping={'result':'EXACT_PRIOR_MEMBER_REUSE','files':reuse,'baseManifest':{'path':str(basepath),**pin(basepath)},'archiveAttributionAuthority':{'path':str(authorityPath),**pin(authorityPath)},'reconstruction':'After restoring the prior chain, copy the exact retainedMember bytes to each localRelativePath in this checkpoint when replaying support scripts; verify hash first. No embedded source text duplication.'}
 dump(C/'SUPPORT-REUSE-MAPPING.json',mapping)
 # Include the reconstruction mapping once as a new support member.
 p=C/'SUPPORT-REUSE-MAPPING.json';dest=out/p.name;shutil.copyfile(p,dest);rows.append({'path':'renault-recovery-support/'+p.name,'payloadPath':str(dest),'originalPath':str(p),**pin(dest)})
 dump(C/'SUPPORT-MEMBER-INVENTORY.json',{'result':'EXPLICIT_UNIQUE_SUPPORT_SELECTION','files':rows,'reusedFiles':len(reuse),'selectionPin':pin(C/'SUPPORT-SELECTION-v1.json'),'sourceCodeEmbeddedInMetadata':False})
 dump(C/'SUPPORT-PATTERN-SELECTION-v1.json',{'files':rows})
 print(json.dumps({'newSupportMembers':len(rows),'reusedExactMembers':len(reuse),'newBytes':sum(r['bytes'] for r in rows)}))
if __name__=='__main__':main()
