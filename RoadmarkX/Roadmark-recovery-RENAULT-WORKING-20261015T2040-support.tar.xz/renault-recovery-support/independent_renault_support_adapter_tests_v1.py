#!/usr/bin/env python3
"""Exercise only the exact syntax classifier; no main, archive or seed invocation."""
import ast,copy,datetime,hashlib,importlib.util,json,pathlib,resource,sys
sys.dont_write_bytecode=True
C=pathlib.Path(__file__).resolve().parent;LIMIT=268435456

def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def main():
 resource.setrlimit(resource.RLIMIT_AS,(LIMIT,LIMIT));assert len(sys.argv)==3;script=C/sys.argv[1];assert script.parent==C and script.name.startswith('scan_support_v') and script.suffix=='.py';assert pin(script)['sha256']==sys.argv[2];ast.parse(script.read_bytes());spec=importlib.util.spec_from_file_location('tested_support_classifier',script);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 review=C/'INDEPENDENT-RENAULT-SUPPORT-SYNTAX-CLASSIFICATION-v1.json';d=json.loads(review.read_bytes());rows=d['exactSupportCodeClassifications'];name=rows[0]['member'];data=(C/'capture_v1.py').read_bytes();expected=[r['exactFinding'] for r in rows];tests=[]
 def record(kind,action,expect_assert=False):
  try:value=action()
  except AssertionError:
   assert expect_assert,kind;tests.append({'case':kind,'outcome':'EXPECTED_REJECTION'});return
  assert not expect_assert,kind;tests.append({'case':kind,'outcome':'PASS'});return value
 remaining,classified=record('two exact pinned candidates',lambda:m.classify(copy.deepcopy(expected),data,name));assert not remaining and len(classified)==2
 record('missing exact candidate',lambda:m.classify(copy.deepcopy(expected[:1]),data,name),True)
 record('duplicate exact candidate',lambda:m.classify(copy.deepcopy(expected+[expected[0]]),data,name),True)
 altered=copy.deepcopy(expected);altered[0]['location']['charStart']+=1;record('altered finding position',lambda:m.classify(altered,data,name),True)
 extra={'kind':'independent-unreviewed-candidate','location':{'line':1,'charStart':0,'charEnd':1}};remaining,classified=record('extra candidate remains blocking',lambda:m.classify(copy.deepcopy(expected+[extra]),data,name));assert remaining==[extra] and len(classified)==2
 record('changed file bytes',lambda:m.classify(copy.deepcopy(expected),data+b'\n',name),True)
 remaining,classified=record('different member receives no exception',lambda:m.classify(copy.deepcopy(expected),data,'unrelated-support/member.py'));assert remaining==expected and classified==[]
 out={'result':'PASS_EXACT_SUPPORT_SYNTAX_ADAPTER_TESTS','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'testedScript':pin(script),'testScript':pin(pathlib.Path(__file__).resolve()),'classification':pin(review),'exactFile':pin(C/'capture_v1.py'),'tests':tests,'currentMetadataImports':['scan_support module definitions','capture helper and its reviewed sanitizer module definitions'],'scannerMainInvoked':False,'archivePayloadReads':0,'seedPayloadReads':0,'excludedRawReads':0,'scope':'Only classifier callable with exact approved public code bytes and synthetic in-memory candidate mutations','resources':{'addressSpaceLimitBytes':LIMIT,'maxRssKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
 output=C/(script.stem+'-independent-tests-v1.json')
 with output.open('x') as f:json.dump(out,f,indent=2);f.write('\n')
 print(json.dumps({'result':out['result'],'cases':len(tests),'output':pin(output)}))
if __name__=='__main__':main()
