#!/usr/bin/env python3
"""Scan exact final recovery documents using the reviewed inherited detectors and seed scope."""
import sys,datetime
from require_privacy_contract_v1 import verified_contract
from capture_v1 import *
def main():
 verified_contract()
 from privacy_v1 import seed_sets,scan,scan_patterns,ByteSearch,classify_exact_matches
 selection=P(sys.argv[1]);out=P(sys.argv[2]);assert selection.parent.resolve()==C and out.parent.resolve()==C
 rows=load(selection)['files'];forms,blocking,public,benign,counts=seed_sets();primary,runtime=scan.patterns();results=[];findings=[]
 for r in rows:
  p=P(r['localPath']);got,ident=check(p,r);b=p.read_bytes();assert identity(p)==ident and {'bytes':len(b),'sha256':sha(b)}==got
  ps,us,bc=scan_patterns(b,p.name,primary,runtime,benign);search=ByteSearch(forms);block=ByteSearch(blocking);pub=ByteSearch(public)
  for start in range(0,len(b),CHUNK):q=b[start:start+CHUNK];search.feed(q);block.feed(q);pub.feed(q)
  unresolved,collisions=classify_exact_matches(search,block,pub,bool(ps or us));bad={'file':p.name,'primary':ps,'runtime':us,'exactMatches':[{'byteStart':a,'byteEndExclusive':z} for a,z in unresolved]}
  if ps or us or unresolved:findings.append(bad)
  results.append({'path':str(p),**got,'classifiedPublicLexicalCollisions':len(collisions),'recognizedBenignRuntimeCandidateCount':bc});del b;scan.release_memory()
 result={'status':'clean' if not findings else 'review-required','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':results,'fileCount':len(results),'selectionPin':pin(selection),'seedCounts':counts,'findings':findings,'errors':[],'limitations':['No universal secret-free claim','No decryption or recursive unpacking','Exact reviewed inherited detector and value-variant scope only']};dump(out,result);print(json.dumps({'status':result['status'],'files':len(results),'findings':len(findings)}));sys.exit(0 if not findings else 2)
if __name__=='__main__':main()
