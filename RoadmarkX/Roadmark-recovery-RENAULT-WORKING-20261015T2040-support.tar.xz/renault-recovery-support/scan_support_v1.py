#!/usr/bin/env python3
"""Compose two exact reviewed syntax classifications after unchanged inherited checks."""
import hashlib,json,pathlib
C=pathlib.Path(__file__).resolve().parent
CLASSIFICATION='INDEPENDENT-RENAULT-SUPPORT-SYNTAX-CLASSIFICATION-v1.json'
CLASSIFICATION_PIN={'bytes':3874,'sha256':'e2e152fbe0691f6bbbaac7c7599ae1d36e0ca1d34a1dd329361023967314de7c'}
def classify(candidates,data,name):
 from capture_v1 import check,load
 p=C/CLASSIFICATION;check(p,CLASSIFICATION_PIN);rows=[r for r in load(p)['exactSupportCodeClassifications'] if r['member']==name]
 if not rows:return candidates,[]
 actual={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};assert len(rows)==2 and all(r['filePin']==actual for r in rows)
 expected=[r['exactFinding'] for r in rows];assert len({json.dumps(f,sort_keys=True) for f in expected})==len(expected);kept=[];classified=[]
 for candidate in candidates:
  if candidate not in expected:kept.append(candidate);continue
  r=rows[expected.index(candidate)];assert hashlib.sha256(data[r['byteStart']:r['byteEndExclusive']]).hexdigest()==r['matchedSyntaxSHA256'];classified.append({'member':name,'filePin':actual,'finding':candidate,'classification':r['classification']})
 assert len(classified)==2 and sorted(json.dumps(r['finding'],sort_keys=True) for r in classified)==sorted(json.dumps(r,sort_keys=True) for r in expected),'Missing, duplicate or changed exact syntax candidates'
 return kept,classified
def main():
 from require_privacy_contract_v1 import verified_contract
 from capture_v1 import check,load
 verified_contract();contract=load(C/'RENAULT-SUPPORT-PRIVACY-CONTRACT-v1.json');assert contract['result']=='INDEPENDENTLY_ACCEPTED_EXACT_SUPPORT_SYNTAX_ADAPTER';check(pathlib.Path(contract['review']['path']),contract['review']);assert any(r['filename']==pathlib.Path(__file__).name for r in contract['localPins'])
 for r in contract['localPins']:check(C/r['filename'],r)
 check(C/CLASSIFICATION,CLASSIFICATION_PIN)
 import deepal_scan_additions_v2 as deepal
 original=deepal.code_context
 def composed(candidates,data,name):
  remaining,prior=original(candidates,data,name);remaining,current=classify(remaining,data,name);return remaining,prior+current
 deepal.code_context=composed
 from privacy_v1 import main as unchanged_main
 unchanged_main()
if __name__=='__main__':main()
