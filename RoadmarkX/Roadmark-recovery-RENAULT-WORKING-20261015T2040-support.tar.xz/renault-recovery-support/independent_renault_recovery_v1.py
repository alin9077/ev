#!/usr/bin/env python3
"""Independent exact fresh-only archive replay; metadata reuse for inherited history."""
import collections, datetime, hashlib, json, lzma, pathlib, resource, stat, sys, tarfile, time
P=pathlib.Path; C=P(__file__).resolve().parent; B=C.parent/'cupra-working-20261015T1745'; W=C.parents[2]; LIMIT=256*1024*1024; CHUNK=65536
INV=P('/tmp/renault-packet/final-freeze-v1/inventory.json'); ACCEPT=P('/tmp/renault-review/final-retention-v1-accepted.json')
INV_PIN={'bytes':182371,'sha256':'bdbf600563607bf1fe1b5bba63ee1503348ed688378621fca07f08af5c3ccc79'}
ACCEPT_PIN={'bytes':7406,'sha256':'325ca37ea43fb6e28ff84a1252c6cd8257977639969741349431ece3a52ba7e1'}
BASE_MANIFEST_PIN={'bytes':3476229,'sha256':'d1eaf85b9254160820f9f98e622cb6ad821b8d85a8c7bf1dd8e237d4faa6b12b'}
BASE_SOURCE_PIN={'bytes':125338,'sha256':'691ab2bad8c065de8d3b5b02ae22efc85ec99f69981bb372b70a16ff4c69b23a'}
BASE_TERMINAL_PIN={'bytes':14526,'sha256':'61b6d3eda5c9bf3e09bf8b232c4c075732e738bfd729fefbe5115323c6401a7f'}

def ck(value,why):
 if not value:raise AssertionError(why)
def load(p):return json.loads(P(p).read_text())
def core(r):return {k:r[k] for k in ('path','bytes','sha256')}
def sh(r):return {k:r[k] for k in ('bytes','sha256')}
def safe(n):
 p=P(n);ck(bool(n) and not p.is_absolute() and '..' not in p.parts and str(p)==n and '\\' not in n,'unsafe member '+n)
def identity(p):
 p=P(p);s=p.lstat();ck(stat.S_ISREG(s.st_mode) and not any(x.is_symlink() for x in p.parents),'nonregular/symlink '+str(p));return (s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev,s.st_mode)
def pin(p):
 p=P(p);before=identity(p);h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while q:=f.read(CHUNK):h.update(q);n+=len(q)
 ck(identity(p)==before and n==before[0],'unstable file '+str(p));return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
def check(p,r):
 x=pin(p);ck(sh(x)==sh(r),'pin differs '+str(p));return x
def bytespin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def rows(a):
 d={r['path']:core(r) for r in a};ck(len(d)==len(a),'duplicate member list');return d
def logical(p):
 p=P(p)
 if p.is_relative_to('/tmp'):return p.relative_to('/tmp').as_posix()
 if p.is_relative_to(W/'roadmark-104'):return 'roadmark/'+p.relative_to(W/'roadmark-104').as_posix()
 if p.is_relative_to(W):return p.relative_to(W).as_posix()
 raise AssertionError('unapproved fresh path '+str(p))
def token(name):return json.dumps(name).encode()+b':'
def bound_pair(path,expect_success=True):
 t=load(path);ip=P(path).with_name(P(path).stem+'.invocation.json');i=load(ip)
 ck(t['command']==i['command'] and t['childPid']==i['childPid'] and t['startedAt']==i['startedAt'],'invocation/terminal pair differs')
 ck(t['addressSpaceLimitBytes']==i['addressSpaceLimitBytes']==LIMIT and t['wallLimitSeconds']==i['wallLimitSeconds']==600,'resource envelope differs')
 if expect_success:ck(t['exitCode']==0 and not t['timedOut'],'terminal not successful')
 return t,i,{'terminal':pin(path),'invocation':pin(ip)}

def main():
 ck(len(sys.argv)==2 and sys.argv[1]=='--fresh-only','explicit --fresh-only required');resource.setrlimit(resource.RLIMIT_AS,(LIMIT,LIMIT));started=time.monotonic()
 output=C/'INDEPENDENT-RENAULT-RECOVERY-VERIFICATION-v1.json';ck(not output.exists(),'immutable output already exists')
 inputpins=[check(INV,INV_PIN),check(ACCEPT,ACCEPT_PIN),check(B/'source-package.json',BASE_SOURCE_PIN),check(B/'deliverables/Roadmark-RECOVERY-MANIFEST-CUPRA-WORKING-20261015.json',BASE_MANIFEST_PIN),check(B/'INDEPENDENT-CUPRA-TERMINAL-CLOSURE-v1.json',BASE_TERMINAL_PIN)]
 inv=load(INV);accept=load(ACCEPT);base=load(B/'deliverables/Roadmark-RECOVERY-MANIFEST-CUPRA-WORKING-20261015.json');basefiles=rows(base['files']);scope=load(C/'FROZEN-CAPTURE-SCOPE.json');cap=load(C/'proof-capture-v1.json');sourcecap=load(C/'source-capture.json');sp=load(C/'source-package.json');proof=load(C/'proof-packages-v1.json')['archives'];support=load(C/'support-package.json');allarchives=[sp]+proof+[support];plan=load(C/'ARCHIVE-PLAN.json');ck(plan['archives']==allarchives,'final archive plan differs from package manifests')
 for name in ['FROZEN-CAPTURE-SCOPE.json','proof-capture-v1.json','source-capture.json','source-package.json','proof-packages-v1.json','support-package.json','ARCHIVE-PLAN.json','COPY-SANITATION-MAPPING.json','PROSE-KEY-RENAME-APPROVALS.json','INDEPENDENT-RENAULT-REFERENCE-CLOSURE-v1.json','SUPPORT-MEMBER-INVENTORY.json','SUPPORT-REUSE-MAPPING.json','RENAULT-PRIVACY-ADAPTER-CONTRACT.json']:
  inputpins.append(pin(C/name))
 ck(accept['status']=='accepted' and accept['inventory']=={'path':str(INV),**INV_PIN} and accept['preparer']==inv['preparer'] and accept['liveTargetPins']==inv['sourceAndStatusAfterPins'],'final independent acceptance binding differs')
 ck(inv['preparer']=={'path':'/tmp/renault-packet/final-freeze-v1/prepare.py','bytes':9721,'sha256':'ada0b24d7d9d6ec9583b5a4b2e4eac3a385e8d0ef55a610decd58484cdfaaa12'},'preparer pin differs')
 ck(len(inv['files'])==605 and inv['totalFiles']==605 and sum(r['bytes'] for r in inv['files'])==inv['regularFileBytes']==41791599,'author inventory counts')
 approved={r['path']:r for r in inv['files']};extras={str(INV),str(ACCEPT),inv['preparer']['path']};frozen={r['path']:r for r in scope['files']};captured={r['originalPath']:r for r in cap['files']};ck(len(frozen)==len(captured)==608 and set(frozen)==set(captured)==set(approved)|extras,'605+3 exact capture coverage')
 ck(len(sourcecap['files'])==scope['expectedSourceFiles']==700,'source project count');ck(len(sp['memberFiles'])==sp['members']==701 and sp['bytes']<15000000,'source archive count or size')
 changed={logical(r['path']):r for r in inv['sourceAndStatusAfterPins'] if P(r['path']).is_relative_to(W/'roadmark-104')};ck(len(changed)==7,'source changes');expected=rows(load(B/'source-package.json')['memberFiles']);expected.pop('roadmark/SOURCE-FILE-MANIFEST.json');ck(len(expected)==697,'base source count')
 for n,r in changed.items():expected[n]={'path':n,**sh(r)}
 ck(len(expected)==700,'source overlay count');actualsource=rows(sp['memberFiles']);embedded=actualsource.pop('roadmark/SOURCE-FILE-MANIFEST.json');ck(actualsource==expected,'source member identity overlay differs')
 ck({logical(r['originalPath']) for r in cap['files'] if r['captureMethod']=='covered-by-full-source'}==set(changed),'source coverage differs')
 ck(len(cap['changedFiles'])==601 and {r['path'] for r in cap['changedFiles']}=={logical(p) for p in frozen}-set(changed),'fresh proof member scope differs')
 maps=load(C/'COPY-SANITATION-MAPPING.json');approvals=load(C/'PROSE-KEY-RENAME-APPROVALS.json');rename={r['restorePath']:r for r in maps['files']};ck(len(rename)==10 and maps['files']==approvals['files'],'ten exact inverse maps differ')
 ck(maps['originalExpectedPinsUnchanged'] and maps['originalsUnchanged'] and not maps['secretMaterialChanged'],'copy-only scope differs')
 keep={'roadmark/SOURCE-FILE-MANIFEST.json','renault-packet/final-freeze-v1/inventory.json','renault-review/final-retention-v1-accepted.json','renault-packet/report-comparison-v2-interruption-record-v2/record.json','renault-packet/report-comparison-v4/results-manifest-v1.json','renault-review/report-comparison-v4-results-v1.json','renault-packet/post-registration-checks-v6/results-manifest-v1.json'}|set(rename)
 for r in inv['retainedFailures']['preparationFailurePaths']:keep.add(logical(r))
 for r in cap['files']:
  if r['path'].endswith('/terminal.json') and ('report-comparison-v4/' in r['path'] or 'post-registration-checks-v6/run/' in r['path']):keep.add(r['path'])
 saved={};seenall={};archivechecks=[]
 for a in allarchives:
  ap=P(a['file']);check(ap,a);expectedmembers=rows(a['memberFiles']);seen={};before=identity(ap)
  with lzma.open(ap,'rb') as stream:
   with tarfile.open(fileobj=stream,mode='r|') as tar:
    for member in tar:
     safe(member.name);ck(member.isfile() and member.name not in seen and member.name in expectedmembers,'unsafe, duplicate or unlisted archive member');h=hashlib.sha256();n=0;pieces=[] if member.name in keep or member.name.startswith('recovery-metadata/') else None
     with tar.extractfile(member) as f:
      while q:=f.read(CHUNK):h.update(q);n+=len(q);pieces.append(q) if pieces is not None else None
     row={'path':member.name,'bytes':n,'sha256':h.hexdigest()};ck(row==expectedmembers[member.name] and n==member.size,'member hash/size mismatch '+member.name);seen[member.name]=row
     ck(member.name not in seenall,'duplicate across fresh archives');seenall[member.name]=row
     if pieces is not None:saved[member.name]=b''.join(pieces)
   while stream.read(CHUNK):pass
  ck(seen==expectedmembers and identity(ap)==before,'incomplete or unstable archive');archivechecks.append({'archive':a['filename'],'pin':sh(a),'members':len(seen),'memberBytes':sum(r['bytes'] for r in seen.values()),'xzEofVerified':True})
 manifest=json.loads(saved['roadmark/SOURCE-FILE-MANIFEST.json']);ck(manifest['root']=='roadmark' and rows([{'path':'roadmark/'+r['path'],**sh(r)} for r in manifest['files']])==expected,'embedded source manifest differs')
 sourcepins={r['path']:r for r in inv['sourceAndStatusAfterPins']};originalchecks=[];inversechecks=[]
 for p,f in frozen.items():
  r=captured[p];name=logical(p);ck(r['path']==name,'restore mapping differs');ck(seenall[name]=={'path':name,**sh(r)},'captured member missing');state=identity(P(p));ck(state[0]==f['bytes'] and state[1]==f['mtimeNsAtFreeze'] and state[5]==f['mode'],'freeze stat differs '+p)
  old={'bytes':r['originalBytes'],'sha256':r['originalSHA256']};check(p,old)
  known=f.get('sha256') or f.get('knownSha256') or f.get('declaredSha256')
  if known:ck(old['sha256']==known,'frozen declared hash differs '+p)
  if p in sourcepins:ck(old==sh(sourcepins[p]),'live target pin differs')
  if name in rename:
   a=rename[name];b=saved[name];ck(bytespin(b)==sh(a) and old=={'bytes':a['originalBytes'],'sha256':a['originalSHA256']},'inverse mapping pin differs');ck(b.count(token('approvalScope'))==1 and token('authorization') not in b,'inverse exact token boundary');original=b.replace(token('approvalScope'),token('authorization'),1);ck(bytespin(original)==old,'inverse original hash differs');beforeobj=json.loads(original);afterobj=json.loads(b);v=beforeobj.pop('authorization');ck(afterobj.pop('approvalScope')==v and beforeobj==afterobj,'inverse changed value or other fields');inversechecks.append({'member':name,'stored':sh(a),'reconstructedOriginal':old,'allOtherBytesAndValuePreserved':True})
  else:ck(sh(r)==old,'unapproved transformation '+name)
  originalchecks.append({'originalPath':p,'member':name,'originalPin':old,'declaredHashChecked':bool(known) or p in sourcepins})
 ck(len(inversechecks)==10,'not all inverse maps replayed')
 for a in proof:
  metas=[r for r in a['memberFiles'] if r['path'].startswith('recovery-metadata/')];ck(len(metas)==1,'proof embedded metadata count');meta=json.loads(saved[metas[0]['path']]);listed=rows(meta['files']);actual={r['path']:core(r) for r in a['memberFiles'] if not r['path'].startswith('recovery-metadata/') and not r['path'].startswith('renault-safety-support/')};ck(listed==actual,'proof embedded manifest differs')
  for r in meta['files']:
   c=next(x for x in cap['changedFiles'] if x['path']==r['path']);ck((r['originalBytes'],r['originalSHA256'])==(c['originalBytes'],c['originalSHA256']),'original proof pins changed')
 def doc(n):return json.loads(saved[n])
 ai=doc('renault-packet/final-freeze-v1/inventory.json');ar=doc('renault-review/final-retention-v1-accepted.json');ck(ai==inv and ar==accept,'archived authoritative metadata differs')
 cv=ar['validationScope'];facts={'catalogue':430,'tier1':353,'onSale':312,'packetCount':30,'retainedRefreshes':4,'additions':0,'unchangedPeers':426,'reviewedCore':68,'filledCore':64,'confirmed':61,'check':1,'reported':2,'notPublished':4,'scopedTests':151}
 ck(all(cv[k]==v for k,v in facts.items()),'current factual counts differ');ck(all(cv[k] is False for k in ['fullProjectTypecheckPassed','releaseReady','researchCompleted','currentCleanFullSuite','productionBuildVerified','phoneMobileVerified','publicationAuthorized']),'unpassed boundary changed')
 attempt=cv['reportAttempts'];ck(attempt['totalKnownNormalReportInvocations']==2 and attempt['originalAttemptOutcome']=='UNKNOWN' and attempt['originalAttemptTerminalAbsent'] and attempt['freshActualNormalReportOutcome']=='PASSED' and not attempt['automaticRetry'],'report history conflated')
 unk=doc('renault-packet/report-comparison-v2-interruption-record-v2/record.json');ck(unk['status']=='UNKNOWN_INTERRUPTED_WITHOUT_TERMINAL_EVIDENCE' and unk['interruptionCause']=='unknown' and unk['exitCode'] is None and unk['terminationSignal'] is None and not unk['successClaim'] and not unk['failureClaim'] and not unk['reportOutputPresent'],'original report UNKNOWN lost')
 normalprefix='renault-packet/report-comparison-v2/normal-coverage-asof-2026-10-15/';ck(normalprefix+'terminal.json' not in seenall and normalprefix+'result.json' not in seenall,'original missing terminal invented')
 report=doc('renault-packet/report-comparison-v4/results-manifest-v1.json');review=doc('renault-review/report-comparison-v4-results-v1.json');ck(len(report['checks'])==2 and all(x['passed'] for x in report['checks']) and review['status']=='accepted' and review['allGatesSerialExitZeroEmptyStderrNoWatchdog'],'fresh report acceptance differs')
 for x in report['checks']:
  term=doc(logical(x['terminal']['path']));ck(bytespin(saved[logical(x['terminal']['path'])])==sh(x['terminal']) and term['exitCode']==0 and not term['watchdogFired'],'fresh report terminal differs')
 gates=doc('renault-packet/post-registration-checks-v6/results-manifest-v1.json');ck(len(gates['checks'])==5 and all(x['passed'] and x['exitCode']==0 for x in gates['checks']),'five scoped gates missing')
 for x in gates['checks']:
  n=logical(x['terminal']['path']);term=doc(n);ck(bytespin(saved[n])==sh(x['terminal']) and term['exitCode']==0 and not term['watchdogFired'],'scoped gate terminal differs')
 ck(sum(x['expectedTests'] or 0 for x in gates['checks'])==151,'scoped test total differs')
 ck(len(inv['retainedFailures']['preparationFailurePaths'])==6 and all(logical(n) in saved for n in inv['retainedFailures']['preparationFailurePaths']),'six original preparation failures missing')
 kgm=inv['retainedFailures']['compilerAttempts'];ck(len(kgm)==2 and all(r['exitCode']==-9 and r['cause']=='unknown' and not r['fullProjectTypecheckPassed'] for r in kgm),'historical KGM failures altered')
 closure=load(C/'INDEPENDENT-RENAULT-REFERENCE-CLOSURE-v1.json');ck(closure['result']=='PASS_EXACT_METADATA_ONLY_REFERENCE_CLOSURE' and len(closure['requirements'])==957,'reference closure not accepted');finalfiles={n:r for n,r in basefiles.items() if not n.startswith('roadmark/')};finalfiles.update(seenall);reusedars={a['filename']:a for a in base['archivesInRestoreOrder'] if a['filename']!=base['source']['filename']};archiveby={**reusedars,**{a['filename']:a for a in allarchives}}
 for r in closure['requirements']:
  e=r['expected'];kind=r['kind']
  if kind=='reference-only-runtime-exclusion':continue
  ck(set(r['archives'])<=set(archiveby),'dependency points to omitted archive')
  if kind=='fresh-reversible-original':ck(sh(e)==next(x['reconstructedOriginal'] for x in inversechecks if x['member']==r['member']),'original inverse reference differs')
  else:ck(sh(e)==sh(finalfiles[r['member']]),'reference member pin differs')
  if kind.startswith('fresh'):ck(r['member'] in seenall,'fresh reference not replayed')
  else:ck(r['member'] in basefiles and finalfiles[r['member']]==basefiles[r['member']],'inherited member changed')
 dp=closure['inheritedDependencyProposal'];ck(dp['inheritedRecords']==276 and dp['newRecords']==15 and dp['proposedRecords']==len(dp['dependencies'])==291 and not dp['newPinVariants'] and not dp['inheritedChangedSourceIntersections'],'dependency proposal differs');ck(hashlib.sha256(json.dumps(dp['dependencies'],sort_keys=True,separators=(',',':')).encode()).hexdigest()==dp['canonicalSha256'],'dependency canonical hash differs')
 for a in closure['archiveIdentities']:
  expectedarchive=archiveby[a['filename']];ck(all(a[k]==expectedarchive[k] for k in a),'closure archive identity differs')
 sinv=load(C/'SUPPORT-MEMBER-INVENTORY.json');srows=rows(sinv['files']);actualsupport=rows(support['memberFiles']);supportmeta=[n for n in actualsupport if n.startswith('recovery-metadata/')];ck(len(supportmeta)==1,'support metadata count');actualsupport.pop(supportmeta[0]);ck(actualsupport==srows,'support inventory differs');ck(json.loads(saved[supportmeta[0]])==sinv,'embedded support inventory differs')
 reuse=load(C/'SUPPORT-REUSE-MAPPING.json');reusefiles=reuse['files']
 for r in reusefiles:
  ck(r['retainedMember'] in finalfiles and sh(r)==sh(finalfiles[r['retainedMember']]),'support reuse member differs')
  ar=r['retainedArchive'];ck(ar==reusedars[ar['filename']],'support retained native archive differs');authority=r['archiveMappingAuthority'];check(authority['path'],authority);package=load(authority['path']);ck(package['filename']==ar['filename'] and sh(package)==sh(ar) and rows(package['memberFiles'])[r['retainedMember']]==finalfiles[r['retainedMember']],'support metadata archive/member attribution differs')
  if 'originalPath' in r and P(r['originalPath']).is_relative_to(C):check(r['originalPath'],r)
 own=[r for r in sinv['files'] if P(r['originalPath']).resolve()==P(__file__).resolve()];ck(len(own)==1 and sh(own[0])==sh(pin(__file__)),'independent verifier exact bytes not retained once')
 privacy=[];seenprivacy=set();terminals=[]
 for reportpath in sorted(C.glob('scan-fresh-*.json')):
  if '.resources.' in reportpath.name:continue
  x=load(reportpath)
  if 'regularFilesScanned' not in x:continue
  ck(x['status']=='clean' and not any(x[k] for k in ['exactValueMatches','primaryHeaderCandidates','unclassifiedRuntimeCandidates','errors']),'privacy finding remains');name=x['archive'];ck(name in {a['filename'] for a in allarchives} and name not in seenprivacy,'duplicate or unrelated privacy report');seenprivacy.add(name);a=next(a for a in allarchives if a['filename']==name);ck(sh(x['archivePin'])==sh(a) and rows(x['members'])==rows(a['memberFiles']),'privacy report identities differ');tp=reportpath.with_name(reportpath.stem+'.resources.json');t,i,bp=bound_pair(tp);ck(str(reportpath) in t['command'] and a['file'] in t['command'],'privacy terminal targets differ');privacy.append({'report':pin(reportpath),**bp,'archive':name});terminals.append((t,i))
 ck(seenprivacy=={a['filename'] for a in allarchives},'not every fresh archive has one clean successful privacy report')
 failure=load(C/'INDEPENDENT-RENAULT-SCAN03-FAILURE-REVIEW-v1.json');ck(failure['failureBoundary']['seedPayloadReads']==0 and failure['failureBoundary']['archivePayloadReads']==0,'known pre-read failure boundary differs');ft,fi,fp=bound_pair(C/'scan-fresh-03.resources.json',False);ck(ft['exitCode']==1 and not ft['timedOut'],'retained scan failure changed')
 ledgerrows=[];groups={}
 for directory,countkey,count in [('seed-read-invocations','exactPinnedMembersReadAndVerified',200),('audi-seed-read-invocations','payloadReadOperations',6),('deepal-seed-read-invocations','payloadReadOperations',5)]:
  rs=[]
  for p in sorted((C/directory).glob('*.json')):
   d=load(p);ck(d[countkey]==count,'seed ledger count differs');rs.append((p,d));ledgerrows.append({'kind':directory,'receipt':pin(p),'processId':d['processId'],'completedAt':d['completedAt'],'reads':count})
  groups[directory]=rs
 expectedruns=len(allarchives);ck(all(len(v)==expectedruns for v in groups.values()),'unaccounted seed invocation or missing completed stage')
 for t,i in terminals:
  for directory,rs in groups.items():
   matches=[d for p,d in rs if d['processId']==t['childPid'] and t['startedAt']<=d['completedAt']<=t['endedAt']];ck(len(matches)==1,'seed ledger not uniquely bound to successful invocation')
 for rs in groups.values():ck(not any(d['processId']==ft['childPid'] and ft['startedAt']<=d['completedAt']<=ft['endedAt'] for p,d in rs),'unexpected pre-read-failure seed ledger')
 baseterm=load(B/'INDEPENDENT-CUPRA-TERMINAL-CLOSURE-v1.json');unknownbindings=[r for r in baseterm['seedTerminalBindings'] if r.get('scanOutcome')=='UNKNOWN_INTERRUPTED_NO_TERMINAL_RECEIPT'];ck(len(unknownbindings)==3 and all(r['terminal'] is None and not r['successfulScanClaim'] for r in unknownbindings),'inherited interrupted scan facts changed')
 freshmanifest=C/'INDEPENDENT-NEW-MEMBER-REPLAY-MANIFEST-v1.json'
 with freshmanifest.open('x') as f:json.dump({'result':'PASS_FRESH_MEMBER_HASH_REPLAY','archives':archivechecks,'files':list(seenall.values()),'inverseMappings':inversechecks,'scopeOriginalFiles':608},f,indent=2);f.write('\n')
 out={'schemaVersion':1,'result':'PASS_EXACT_FRESH_ONLY_RENAULT_RECOVERY','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verifierScript':pin(__file__),'inputPins':inputpins,'archiveChecks':archivechecks,'freshArchiveCount':len(allarchives),'freshMembers':len(seenall),'freshBytes':sum(r['bytes'] for r in seenall.values()),'sourceProjectFiles':700,'sourceArchiveMembers':701,'sourceBytes':sp['bytes'],'authorInventoryFiles':605,'separateFreezeExtras':3,'capturedOriginalsRehashed':len(originalchecks),'originalChecksCanonicalSha256':hashlib.sha256(json.dumps(originalchecks,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'memberReplayManifest':pin(freshmanifest),'inverseMappings':inversechecks,'exactReferenceClosure':pin(C/'INDEPENDENT-RENAULT-REFERENCE-CLOSURE-v1.json'),'referenceRequirements':957,'referenceOnlyRuntimePrerequisites':27,'dependencyRecords':291,'privacyVerification':privacy,'currentSeedAccounting':{'completedInvocations':expectedruns,'historicalMemberReads':200*expectedruns,'localValueReads':48*expectedruns,'localIntegrityReads':48*expectedruns,'audiPayloadReads':6*expectedruns,'deepalCopiedPayloadReads':5*expectedruns,'ledgerBindings':ledgerrows,'failedPreconditionAttempt':{**fp,'seedReads':0,'archiveReads':0},'actualInvocationAccounting':True,'localCountBasis':'Unchanged selector control flow and completed downstream Audi stage per successful invocation'},'preservedOutcomes':{'renaultOriginalReportV2':'UNKNOWN; cause unknown; no terminal/result inferred','renaultFreshReportV4':'separate PASSED normal report and exhaustive comparison','renaultOriginalPreparationFailures':6,'recoveryMetadataPreparationFailures':2,'recoveryPrivacyPreconditionFailures':1,'cupraOriginalInterruptedScan':'UNKNOWN with separately counted completed seed reads and later distinct successful scan','inheritedCupraCompletedSeedInvocations':7,'kgmCompilerAttempts':2,'kgmCompilerExitCode':-9,'kgmCompilerCause':'unknown','fullProjectTypeScriptPassed':False,'releaseReady':False},'scope':{'freshArchivesReplayedThroughXZEOF':True,'priorChainReusedByExactMetadataAndTerminalReceipts':True,'inheritedArchivePayloadReads':0,'independentVerifierSeedReads':0,'freshOriginalPayloadReadsOnly':608,'noFullSourceClone':True,'noExcludedRawReadRefetchOrRecovery':True,'noProductCompilerBuildOrUiExecution':True,'noPublishOrUpload':True},'resources':{'wallSeconds':round(time.monotonic()-started,3),'maxRssKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'addressSpaceLimitBytes':LIMIT,'chunkBytes':CHUNK}}
 with output.open('x') as f:json.dump(out,f,indent=2);f.write('\n')
 print(json.dumps({'result':out['result'],'freshArchives':len(allarchives),'freshMembers':len(seenall),'originalFiles':608,'sourceProjectFiles':700,'output':pin(output)}))
if __name__=='__main__':main()
