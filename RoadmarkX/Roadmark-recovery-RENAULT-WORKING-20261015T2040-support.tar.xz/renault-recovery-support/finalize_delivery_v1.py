#!/usr/bin/env python3
"""Bind exact persisted native identities to working-state recovery receipts."""
import datetime,sys
from capture_v1 import *
D=C/'deliverables';DATE='20261015'
def ref(p):return {'path':str(p),**pin(p)}
def identity_files(name):
 d=load(C/name);rows=d['files'];assert len({r['filename'] for r in rows})==len(rows)
 for r in rows:
  assert r['library_file_id'].startswith('libfile_') and r['file_id'].startswith('file_') and isinstance(r['version'],int)
  check(P(r['localPath']),r)
 return rows
def late_metadata():
 kept={r['originalPath'] for r in load(C/'SUPPORT-MEMBER-INVENTORY.json')['files']};kept.update(r['originalPath'] for r in load(C/'SUPPORT-REUSE-MAPPING.json')['files'])
 verification=load(D/f'Roadmark-RECOVERY-VERIFICATION-RENAULT-WORKING-{DATE}.json');kept.update(r['file']['path'] for r in verification['postSealEvidence'])
 names=['INDEPENDENT-RENAULT-DOCUMENT-CHECK-v1.json','independent-documents-v1.resources.json','independent-documents-v1.resources.invocation.json','DELIVERABLE-PRIVACY-GATE.json','scan-documents-v1.resources.json','scan-documents-v1.resources.invocation.json','SEED-READ-ACCOUNTING-after-docs-v1.json','ARCHIVE-UPLOAD-IDENTITIES.json','DOCUMENT-UPLOAD-IDENTITIES.json','ARCHIVE-NATIVE-READBACK-v1.json','DOCUMENT-NATIVE-READBACK-v1.json']
 paths={C/n for n in names}
 for folder in ['seed-read-invocations','audi-seed-read-invocations','deepal-seed-read-invocations']:paths.update(p for p in (C/folder).glob('*.json') if str(p) not in kept)
 result=[]
 for p in sorted(paths):
  b=p.read_bytes();result.append({'file':{'path':str(p),'bytes':len(b),'sha256':sha(b)},'utf8':b.decode('utf8')})
 return result
def active():
 archives=identity_files('ARCHIVE-UPLOAD-IDENTITIES.json');docs=identity_files('DOCUMENT-UPLOAD-IDENTITIES.json');assert len(docs)==4
 gate=load(C/'INDEPENDENT-RENAULT-DOCUMENT-CHECK-v1.json');assert str(gate['result']).startswith('PASS');p=load(C/'RESTORE-PLAN.json');scope=load(C/'FROZEN-CAPTURE-SCOPE.json');source=next(r for r in archives if r['filename']==p['source']['filename'])
 record={'schemaVersion':10,'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PERSISTED_RENAULT30_WORKING_RECOVERY_RELEASE_UNPASSED','sourceLibraryFileId':source['library_file_id'],'files':archives+docs,'counts':{k:p[k] for k in ['archiveCount','logicalFiles','freshFiles','fullSourceFiles','baseArchivesReused']},'currentValidation':scope['currentValidation'],'workingResult':scope['workingResult'],'originalRenaultReportOutcome':'UNKNOWN','freshRenaultReportOutcome':'PASSED','inheritedCupraInterruptedScanOutcome':'UNKNOWN','fullProjectTypeScriptPassed':False,'releaseReady':False,'independentRecovery':ref(C/'INDEPENDENT-RENAULT-RECOVERY-VERIFICATION-v1.json'),'independentDocuments':ref(C/'INDEPENDENT-RENAULT-DOCUMENT-CHECK-v1.json'),'lateMetadata':late_metadata(),'seedReadAccountingAsOfActivePreparation':load(C/'SEED-READ-ACCOUNTING-after-docs-v1.json'),'baseContinuity':{'finalReceipt':ref(BASE/'FINAL-CUPRA-UPLOAD-RECEIPTS.json'),'terminalReceipt':ref(BASE/'INDEPENDENT-CUPRA-TERMINAL-CLOSURE-v1.json'),'archiveReuse':137,'priorInterruptedScanAccountingUnchanged':True,'missingMutableCupraV1BytesNotReconstructed':True},'delivery':'Native files persisted; parent delivery confirmation is separate','noDeletionOrReplacement':True,'noPinnedSourceOrStatusMutation':True,'noExecutableSourceTextEmbedded':True}
 dump(D/f'Roadmark-RECOVERY-ACTIVE-STATE-RENAULT-WORKING-{DATE}.json',record)
 print('Active receipt prepared')
def final():
 archives=identity_files('ARCHIVE-UPLOAD-IDENTITIES.json');docs=identity_files('DOCUMENT-UPLOAD-IDENTITIES.json');active=identity_files('ACTIVE-UPLOAD-IDENTITIES.json');assert len(active)==1;files=archives+docs+active;p=load(C/'RESTORE-PLAN.json')
 by={r['filename']:r for r in files};doc=lambda kind:by[f'Roadmark-RECOVERY-{kind}-RENAULT-WORKING-{DATE}.json']['library_file_id']
 out={'schemaVersion':10,'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ALL_RENAULT_WORKING_RECOVERY_FILES_PERSISTED_BROADER_RELEASE_GATES_OPEN','sourceLibraryFileId':by[p['source']['filename']]['library_file_id'],'archiveLibraryFileIds':[r['library_file_id'] for r in archives],'indexLibraryFileId':by[f'Roadmark-RECOVERY-INDEX-RENAULT-WORKING-{DATE}.md']['library_file_id'],'manifestLibraryFileId':doc('MANIFEST'),'verificationLibraryFileId':doc('VERIFICATION'),'summaryLibraryFileId':by[f'Roadmark-RENAULT-M1-UPDATE-{DATE}.md']['library_file_id'],'activeReceiptLibraryFileId':active[0]['library_file_id'],'files':files,'counts':{k:p[k] for k in ['archiveCount','logicalFiles','logicalBytes','freshFiles','freshBytes','fullSourceFiles','baseArchivesReused']},'independentRecovery':ref(C/'INDEPENDENT-RENAULT-RECOVERY-VERIFICATION-v1.json'),'documentCheck':ref(C/'INDEPENDENT-RENAULT-DOCUMENT-CHECK-v1.json'),'activeCheck':ref(C/'INDEPENDENT-RENAULT-ACTIVE-CHECK-v1.json'),'seedReadAccounting':load(C/'SEED-READ-ACCOUNTING-after-active-v1.json'),'fullProjectTypeScriptPassed':False,'releaseReady':False,'delivery':'Pending parent native-attachment send confirmation','noDeletionOrReplacement':True,'noPinnedSourceOrStatusMutation':True,'noExecutableSourceTextEmbedded':True}
 dump(C/'FINAL-RENAULT-UPLOAD-RECEIPTS.json',out);print('Final upload receipt prepared')
if __name__=='__main__':{'active':active,'final':final}[sys.argv[1]]()
