#!/usr/bin/env python3
"""Append only a pinned, independently reviewed support-metadata supplement."""
import shutil
from capture_v1 import *
def main():
 selectionPath=C/'SUPPORT-SUPPLEMENT-SELECTION-v1.json';selection=load(selectionPath);original=C/'SUPPORT-MEMBER-INVENTORY.json';oldpin=pin(original);assert oldpin==selection['priorInventoryPin'];old=load(original);rows=list(old['files']);names={r['path'] for r in rows};sources={r['originalPath'] for r in rows};out=C/'support-supplement-v1';out.mkdir(exist_ok=False)
 saved=C/'SUPPORT-MEMBER-INVENTORY-before-classification.json';assert not saved.exists();original.rename(saved);check(saved,oldpin)
 additions=list(selection['files'])+[{'originalPath':str(saved),'localRelativePath':saved.name,**oldpin},{'originalPath':str(selectionPath),'localRelativePath':selectionPath.name,**pin(selectionPath)}];added=[]
 for r in additions:
  p=P(r['originalPath']);got,before=check(p,r);name=r['localRelativePath'];safe(name);member='renault-recovery-support/'+name;assert member not in names and str(p) not in sources;names.add(member);sources.add(str(p));dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True)
  with p.open('rb') as src,dest.open('xb') as dst:shutil.copyfileobj(src,dst,CHUNK)
  check(dest,got);assert identity(p)==before;added.append({'path':member,'payloadPath':str(dest),'originalPath':str(p),**got})
 receipt={'result':'EXACT_APPEND_ONLY_SUPPORT_METADATA_SUPPLEMENT','priorInventory':{'originalExpectedPath':str(original),'retainedPath':str(saved),**oldpin},'selection':{'path':str(selectionPath),**pin(selectionPath)},'previousRowsUnchanged':len(rows),'addedFiles':added,'seedReads':0,'archivePayloadReads':0,'sourceAndProofBytesUnchanged':True}
 rp=C/'SUPPORT-SUPPLEMENT-RECEIPT-v1.json';dump(rp,receipt);dest=out/rp.name;shutil.copyfile(rp,dest);added.append({'path':'renault-recovery-support/'+rp.name,'payloadPath':str(dest),'originalPath':str(rp),**pin(dest)})
 updated={**old,'files':rows+added,'supplementReceipt':{'path':str(rp),**pin(rp)},'priorInventoryPin':oldpin};dump(original,updated);dump(C/'SUPPORT-SUPPLEMENT-PATTERN-SELECTION-v1.json',{'files':added});print(json.dumps({'previousMembers':len(rows),'newMembers':len(added),'finalSupportMembers':len(rows)+len(added),'seedReads':0}))
if __name__=='__main__':main()
