#!/usr/bin/env python3
"""Pattern-only discovery over exact selected captured members; no seed access."""
import sys
from capture_v1 import *
from privacy_v1 import scan,scan_patterns
def main():
 selection=load(P(sys.argv[1]));out=P(sys.argv[2]);primary,runtime=scan.patterns();rows=[];n=0
 for r in selection['files']:
  p=P(r['payloadPath']);got,ident=check(p,r);data=p.read_bytes();assert identity(p)==ident
  ps,us,bc=scan_patterns(data,r['path'],primary,runtime,set());assert bc==0
  if ps or us:rows.append({'member':r['path'],'payloadPath':str(p),'filePin':got,'primary':ps,'runtime':us,'secretLikeValuesPersisted':False})
  n+=1;del data;scan.release_memory()
 dump(out,{'result':'REVIEW_REQUIRED' if rows else 'NO_PATTERN_CANDIDATES','filesInspected':n,'candidateFiles':rows,'seedReadsPerformed':False,'selectionPin':pin(P(sys.argv[1]))})
 print(json.dumps({'files':n,'candidateFiles':len(rows)}))
if __name__=='__main__':main()
