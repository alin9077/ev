#!/usr/bin/env python3
"""Count completed seed stages separately from scan outcomes; no seed values read."""
import datetime,sys
from capture_v1 import *
def ref(p):return {'path':str(p.relative_to(C)),**pin(p)}
def main():
 out=P(sys.argv[1]);assert out.parent.resolve()==C
 phases=[]
 for p in sorted(C.glob('scan-*.resources.invocation.json')):
  inv=load(p);terminal=p.with_name(p.name.replace('.invocation.json','.json'));t=load(terminal) if terminal.exists() else None
  phases.append({'invocation':ref(p),'start':inv['startedAt'],'pid':inv['childPid'],'end':t['endedAt'] if t else None,'terminal':ref(terminal) if t else None,'outcome':('PASS' if t['exitCode']==0 and not t['timedOut'] else 'NONZERO_OR_TIMEOUT') if t else 'UNKNOWN'})
 failureReview=C/'INDEPENDENT-RENAULT-SCAN03-FAILURE-REVIEW-v1.json';assert pin(failureReview)['sha256']=='e52b66ef43ebb122c0c056e4116da7ac8b32b7c67f8f2d8ad6e01ec4f2502b29';fr=load(failureReview);assert fr['result']=='ACCEPTED_KNOWN_ZERO_SEED_FAILURE_AND_EXACT_CORRECTED_RETRY';assert fr['failureBoundary']['seedPayloadReads']==0 and fr['failureBoundary']['archivePayloadReads']==0
 for key in ['failedInvocation','failedTerminal']:check(P(fr[key]['path']),fr[key])
 zeroName=P(fr['failedInvocation']['path']).name
 for phase in phases:
  phase['knownZeroSeedPreconditionFailure']=phase['invocation']['path']==zeroName
  if phase['knownZeroSeedPreconditionFailure']:phase['knownZeroReview']=ref(failureReview)
 summaries={}
 for kind,folder,unit in [('historical','seed-read-invocations',200),('audi','audi-seed-read-invocations',6),('deepal','deepal-seed-read-invocations',5)]:
  records=[]
  for p in sorted((C/folder).glob('*.json')):
   d=load(p);hits=[x for x in phases if d['processId']==x['pid'] and d['completedAt']>=x['start'] and (x['end'] is None or d['completedAt']<=x['end'])];assert len(hits)==1,(str(p),hits)
   records.append({'receipt':ref(p),'completedAt':d['completedAt'],'phaseInvocation':hits[0]['invocation'],'scanOutcome':hits[0]['outcome'],'phaseTerminal':hits[0]['terminal']})
  summaries[kind]={'completedInvocations':len(records),'perCompletedInvocationOperations':unit,'totalCompletedOperations':len(records)*unit,'records':records,'noValuesOrValueDigestsPersisted':True}
 # Unchanged control flow completes all48 local selectors and integrity checks before Audi completion.
 local={'completedInvocationsProvedByAudiLedger':summaries['audi']['completedInvocations'],'valueReadsPerCompletedInvocation':48,'integrityReadsPerCompletedInvocation':48,'totalProvedValueReads':48*summaries['audi']['completedInvocations'],'totalProvedIntegrityReads':48*summaries['audi']['completedInvocations'],'accountingMethod':'Derived from exact reviewed unchanged selector control flow and completed Audi stage; not per-file instrumentation','unknownPartialLocalReadsPossibleForPhasesWithoutAudiCompletion':[]}
 audiPhases={r['phaseInvocation']['path'] for r in summaries['audi']['records']}
 for p in phases:
  if p['invocation']['path'] not in audiPhases and not p['knownZeroSeedPreconditionFailure']:local['unknownPartialLocalReadsPossibleForPhasesWithoutAudiCompletion'].append(p['invocation'])
 record={'status':'EXPLICIT_STAGE_AND_TERMINAL_ACCOUNTING','asOf':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phases':phases,'stages':summaries,'inheritedLocal':local,'inheritedCupraAccounting':{'finalReceipt':{'path':str(BASE/'FINAL-CUPRA-UPLOAD-RECEIPTS.json'),**pin(BASE/'FINAL-CUPRA-UPLOAD-RECEIPTS.json')},'originalInterruptedScanOutcome':'UNKNOWN','completedStageReadAccountingPreservedSeparately':True},'renaultOriginalFactualReport':'UNKNOWN separate original report-v2; never recategorized as a recovery scan interruption','noSeedValuesReadByThisAccounting':True}
 dump(out,record);print(json.dumps({'phases':len(phases),'completedHistorical':summaries['historical']['completedInvocations'],'completedAudi':summaries['audi']['completedInvocations'],'completedDeepal':summaries['deepal']['completedInvocations']}))
if __name__=='__main__':main()
