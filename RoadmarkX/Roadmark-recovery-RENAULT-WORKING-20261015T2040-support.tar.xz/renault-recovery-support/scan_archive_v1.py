#!/usr/bin/env python3
from require_privacy_contract_v1 import verified_contract
if __name__=='__main__':
 verified_contract()
 from privacy_v1 import main
 main()
