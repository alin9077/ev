#!/usr/bin/env python3
"""Exact selected JSON sanitation candidates; metadata-only output, no value retention."""
from capture_v1 import *
def main():
 scope=load(C/'FROZEN-CAPTURE-SCOPE.json');rows=[];count=0
 for r in scope['files']:
  p=P(r['path']);assert p.lstat().st_mode==r['mode'],str(p)+' frozen mode'
  if p.suffix!='.json' and p.suffix.lower()!='.headers':continue
  got,ident=check(p,{'bytes':r['bytes'],'sha256':r.get('sha256') or r.get('knownSha256') or r.get('declaredSha256')});assert ident[1]==r['mtimeNsAtFreeze']
  b=p.read_bytes();assert identity(p)==ident
  sanitized,red=S.sanitize_json(b) if p.suffix=='.json' else S.sanitize_headers(b)
  if red:rows.append({'originalPath':str(p),'restorePath':restpath(p),**got,'locations':red,'sanitizedBytes':len(sanitized),'valueOrValueDigestRetained':False})
  count+=1
 dump(C/'JSON-SANITIZER-CANDIDATES-v1.json',{'result':'REVIEW_REQUIRED' if rows else 'NO_SANITIZER_CANDIDATES','filesInspected':count,'candidateFiles':rows,'originalsUnchanged':True,'sanitizedPayloadPersisted':False})
 print(json.dumps({'jsonAndHeaderFiles':count,'candidateFiles':len(rows)}))
if __name__=='__main__':main()
