#!/usr/bin/env python3
"""Pin exact inherited privacy helpers before any known-value seed access."""
from capture_v1 import *
def verified_contract():
 contract=load(C/'RENAULT-PRIVACY-ADAPTER-CONTRACT.json')
 assert contract['result']=='INDEPENDENTLY_ACCEPTED_RENAULT_PRIVACY_ADAPTER'
 check(P(contract['review']['path']),contract['review'])
 for r in contract['localPins']:check(C/r['filename'],r)
 for r in contract['inheritedPins']:check(P(r['path']),r)
 for r in contract['identicalCopies']:
  assert (C/r['filename']).read_bytes()==P(r['originalPath']).read_bytes()
 scope=load(C/'APPROVED-INHERITED-SEED-SCOPE.json');assert (scope['historicalPinnedMembers'],scope['historicalArchives'],scope['localSelectors'],scope['audiPayloadReadOperations'],scope['deepalCopiedCaptureSources'])==(200,21,48,6,5)
 assert scope['inMemoryOnly'] and scope['actualRepeatedReadAccounting'] and not scope['broadBaseScanOrClone'] and not scope['rawExcludedPayloadReadRecoveryRefetch']
 return contract
if __name__=='__main__':verified_contract()
