import fs from 'node:fs';
import assert from 'node:assert/strict';
import {catalogue,research,effectiveFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/data.ts';
import {prepareBrandResearch,applyBrandUpdates,applyBrandFeatureUpdates,applyBrandTermFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-updates.ts';
import {loadReportInput} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/load.ts';
import {buildCoverageReport,isOnSale} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/reports.ts';
import {combineM1Reconciliations} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/m1-reconciliation.ts';
import {featureClaim} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/citable.ts';
import {hydratePortablePacks,storePortablePacks} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/portable-packs.ts';
const root='/tmp/kia-research/';
const p=JSON.parse(fs.readFileSync(root+'kia-2026-10-14.json','utf8'));
const r=JSON.parse(fs.readFileSync(root+'kia-reconciliation-2026-10-14.json','utf8'));
const before=JSON.parse(JSON.stringify(catalogue())),rd=JSON.parse(JSON.stringify(research()));
const original=JSON.stringify({before,rd,p});
assert.deepEqual(before.filter(c=>c.brand==='Kia'),JSON.parse(fs.readFileSync(root+'before.json','utf8')),'before snapshot must still match current catalogue');
const data=prepareBrandResearch(rd,[p]);const cars=applyBrandUpdates(before,data,[p]);const beforeById=new Map(before.map(c=>[c.id,c]));
const features=cars.flatMap(car=>car.brand==='Kia'&&car.vehicleClass==='passenger'?applyBrandTermFeatures(car,applyBrandFeatureUpdates(car,effectiveFeatures(beforeById.get(car.id)||car,data),data,[p])):effectiveFeatures(car,data));
for(const car of cars.filter(c=>c.brand==='Kia'&&c.vehicleClass==='passenger')){
 const rows=features.filter(f=>f.variant_id===car.id);const pack={car,features:rows,sources:data.sources,eligibility:data.update_eligibility.find(r=>r.variant_id===car.id),events:[],configuration:[]};
 const restored=hydratePortablePacks(storePortablePacks({[car.id]:pack}),data.sources)[car.id];assert.deepEqual(JSON.parse(JSON.stringify(restored)),JSON.parse(JSON.stringify(pack)));
 for(const row of p.features.filter((f:any)=>f.variantId===car.id)){
  assert.deepEqual(rows.find(f=>f.criterion===row.criterion),row.after);const claim=featureClaim(restored,row.criterion,row.criterion)!;assert.equal(claim.value,row.after.value);assert.equal(claim.gradeReview?.overlayId,p.id);assert.equal(claim.gradeReviewStatus,undefined);assert.deepEqual(claim.sources.map(s=>s.id),row.after.source_ids);
 }
 assert.equal(car.availabilityEvidence.physicalStockVerified,false);assert.equal(car.facts.warranty.buyerGrade,'confirmed');assert.equal(car.facts.battery_warranty.buyerGrade,'confirmed');
 assert.match(car.facts.battery_warranty.value,car.model==='EV4'||Number(car.year)>=2027?/8 years \/ 160,000/:/7 years \/ 150,000/);
 if(car.facts.promotional_driveaway_aud?.value){const row=rows.find(f=>f.criterion==='driveaway_price')!;assert.ok(row.value.includes(Number(car.facts.promotional_driveaway_aud.value).toLocaleString('en-AU'))||car.facts.price_aud.comparisonBasis==='Driveaway');assert.equal(row.gradeReview?.overlayId,p.id);}
 if(car.id.includes('kia_ev3__gt_line_awd')){assert.doesNotMatch(car.trim,/provisional/);assert.equal(car.availability,'current_or_order_listed');assert.equal(car.facts.power_kw.value,195);}
 if(car.id.includes('kia_ev9_my26__gt_awd')){assert.equal(car.facts.seats.value,6);assert.equal(car.facts.boot_l.value,333);assert.equal(car.facts.boot_l.buyerGrade,'reported');}
 if(car.model==='EV3'||car.model==='EV5'){
  assert.doesNotMatch(rows.find(f=>f.criterion==='energy_use')!.value,/a year|annual|A\$/i);assert.doesNotMatch(rows.find(f=>f.criterion==='home_charging')!.value,/About|divided/);
 }
 if(p.variants.some((v:any)=>v.id===car.id)){assert.ok(Object.keys(car.facts).length<=25+p.facts.filter((f:any)=>f.variantId===car.id).length+3);assert.ok(!Object.keys(car.facts).some(k=>/^truck|hydrogen|solar_wing/.test(k)));}
}
assert.deepEqual(cars.find(c=>c.id==='kia_pv5_cargo_s_4dr_long_range_my26__20261010'),before.find(c=>c.id==='kia_pv5_cargo_s_4dr_long_range_my26__20261010'),'Tier2 Kia commercial record untouched');
const input=loadReportInput();input.cars=cars;input.sources=data.sources;input.features=features;input.m1Reconciliation=combineM1Reconciliations(input.m1Reconciliation!,r);
const report=buildCoverageReport(input,'2026-10-14');fs.writeFileSync(root+'staged-report.json',JSON.stringify(report,null,2));fs.writeFileSync(root+'after.json',JSON.stringify(cars.filter(c=>c.brand==='Kia'),null,2));fs.writeFileSync(root+'features-after.json',JSON.stringify(features.filter(c=>c.variant_id.startsWith('kia_')),null,2));assert.equal(JSON.stringify({before,rd,p}),original,'staging preserves original inputs');
const brand=report.brandProgress.find(x=>x.brand==='Kia')!;
console.log(JSON.stringify({researchCompleted:brand.researchCompleted,researchRemaining:brand.researchRemaining,onSaleVersions:brand.onSaleVersions,core:brand.core.map(x=>({key:x.key,grades:x.grades})),currentBodies:brand.currentVersionReviews.map(x=>({model:x.model,versions:x.versions.length})),gaps:report.gaps.filter(x=>x.brand==='Kia'),closureIssues:brand.closureIssues,criteria:brand.criteria,features:p.features.length},null,2));
assert.ok(brand.researchCompleted,JSON.stringify(brand.researchRemaining));assert.equal(brand.missingModels,0);assert.equal(brand.unresolvedLeads,0);assert.equal(brand.missingSummaries,0);assert.equal(brand.agedOrInvalidClaims,0);
console.log('PASS: current guards, feature chains/dependencies, citable/portable propagation, immutable inputs, staged report. Strict/global C1-C6 remain separate.');
