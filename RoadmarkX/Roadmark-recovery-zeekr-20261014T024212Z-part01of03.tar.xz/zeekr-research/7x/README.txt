Zeekr 7X Australian evidence, checked 2026-10-14

Read evidence.json for four exact existing versions, each with 17 core fields and storage extras. Sources are indexed in source-index.json. Full saved HTML has a corresponding .txt extraction. Maker brochure PDF page 9 was visually inspected; screenshot maker-brochure-page9.png is retained.

Three core trims are current in maker material. Retain the Black edition with current availability Not confirmed. No physical stock assertions. Do not include China 85 kWh / 900 V changes in current AU versions.

No repository files were changed.
