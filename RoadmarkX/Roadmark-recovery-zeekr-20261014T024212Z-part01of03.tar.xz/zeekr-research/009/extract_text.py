from html.parser import HTMLParser
from pathlib import Path
class T(HTMLParser):
 def __init__(self):super().__init__();self.t=[];self.hide=False
 def handle_starttag(self,tag,attrs):
  if tag in ['script','style']:self.hide=True
 def handle_endtag(self,tag):
  if tag in ['script','style']:self.hide=False
 def handle_data(self,d):
  if not self.hide and d.strip():self.t.append(d.strip())
for f in Path('/tmp/zeekr-research/009').glob('*.html'):
 p=T();p.feed(f.read_text());f.with_suffix('.txt').write_text('\n'.join(p.t))
