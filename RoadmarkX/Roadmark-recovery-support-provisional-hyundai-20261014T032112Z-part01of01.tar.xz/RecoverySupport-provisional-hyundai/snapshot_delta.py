#!/usr/bin/env python3
"""Capture and verify a changed-files recovery delta, preserving the earlier base."""
import argparse,datetime,hashlib,importlib.util,io,json,tarfile,time
from pathlib import Path
B=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("snapshot",B/"snapshot_recovery.py")
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
p=argparse.ArgumentParser();p.add_argument("--root",type=Path,required=True);p.add_argument("--baseline",type=Path,required=True);p.add_argument("--label",required=True);p.add_argument("--state",required=True);a=p.parse_args()
baseline=json.loads(a.baseline.read_text());old={f["path"]:f for f in baseline["files"]}
stamp=datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ");cut=B/"snapshots"/(a.label+"-"+stamp);cut.mkdir(parents=True)
start=r.now();full=[];changed=[];excluded=[]
for src in sorted(a.root.rglob("*")):
    if not(src.is_file() or src.is_symlink()):continue
    rel=src.relative_to(a.root);why=r.reason(src,rel)
    if why:excluded.append({"path":rel.as_posix(),"reason":why});continue
    for attempt in range(4):
        s1=src.stat();data=src.read_bytes();s2=src.stat()
        if (s1.st_mtime_ns,s1.st_size)==(s2.st_mtime_ns,s2.st_size):break
        time.sleep(.25)
    else:raise RuntimeError("Unstable file: "+str(src))
    origsha=r.digest(data);origbytes=len(data);redacted=[]
    if src.suffix==".json":data,redacted=r.sanitize_json(data)
    rec={"path":(Path(a.root.name)/rel).as_posix(),"bytes":len(data),"sha256":r.digest(data),"originalBytes":origbytes,"originalSHA256":origsha,"sourceMtimeNs":s2.st_mtime_ns}
    if redacted:rec["redactedHeaderPaths"]=redacted
    full.append(rec)
    if rec["path"] not in old or old[rec["path"]]["sha256"]!=rec["sha256"]:
        dest=cut/rec["path"];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);changed.append(rec)
finish=r.now();captured={x["path"] for x in full}
now_paths={(Path(a.root.name)/q.relative_to(a.root)).as_posix() for q in a.root.rglob("*") if q.is_file() and not r.reason(q,q.relative_to(a.root))}
if now_paths!=captured:raise RuntimeError("Directory file set changed during capture")
for rec in full:
    stat=(a.root/Path(rec["path"]).relative_to(a.root.name)).stat()
    if (stat.st_size,stat.st_mtime_ns)!=(rec["originalBytes"],rec["sourceMtimeNs"]):raise RuntimeError("Source changed during delta capture: "+rec["path"])
manifest={"schemaVersion":2,"kind":"delta","label":a.label,"state":a.state,"sourceRoot":str(a.root),"restoreRoot":a.root.name,"captureStartedAt":start,"captureCutoff":finish,"baselineManifest":str(a.baseline),"baselineCaptureCutoff":baseline["captureCutoff"],"fullCurrentFileManifest":full,"files":changed,"excluded":excluded,"missingSinceBaseline":sorted(old.keys()-captured),"sourceChangesDuringCapture":[],"restore":"First extract every retained QA baseline part, then extract every part of this delta into the same restore parent to overlay changed files. Keep the earlier archives unchanged. missingSinceBaseline is informational; no automated deletion is performed."}
r.write_json(cut/"RECOVERY-FILE-MANIFEST.json",manifest)
groups=[];cur=[];size=0
for rec in changed:
    if cur and size+rec["bytes"]>45_000_000:groups.append(cur);cur=[];size=0
    cur.append(rec);size+=rec["bytes"]
if cur:groups.append(cur)
if not groups:groups=[[]]
archives=[]
for n,group in enumerate(groups,1):
    output=B/f"Roadmark-recovery-{a.label}-{stamp}-part{n:02d}of{len(groups):02d}.tar.xz"
    m={**manifest,"part":n,"parts":len(groups),"files":group};data=(json.dumps(m,indent=2)+"\n").encode()
    support={f"recovery-metadata/{a.label}-{stamp}-part{n:02d}.json":data,f"recovery-metadata/{a.label}-{stamp}-part{n:02d}-RESTORE.txt":(manifest["restore"]+"\nState: "+a.state+"\n").encode()}
    expected={x["path"]:x for x in group}
    with tarfile.open(output,"w:xz",preset=6,format=tarfile.PAX_FORMAT) as tar:
        for rec in group:r.add(tar,rec["path"],(cut/rec["path"]).read_bytes())
        for name,data in support.items():r.add(tar,name,data);expected[name]={"bytes":len(data),"sha256":r.digest(data)}
    archives.append({"file":str(output),"filename":output.name,"label":a.label,"kind":"delta","part":n,"parts":len(groups),"captureStartedAt":start,"captureCutoff":finish,"state":a.state,**r.verify(output,expected)})
result={"archives":archives,"manifest":str(cut/"RECOVERY-FILE-MANIFEST.json"),"captureCutoff":finish,"files":len(full),"changedFiles":len(changed),"unchangedFiles":len(full)-len(changed),"missingSinceBaseline":manifest["missingSinceBaseline"],"excludedFiles":len(excluded),"sourceChangesDuringCapture":[]}
r.write_json(B/f"{a.label}-{stamp}-snapshot.json",result)
print(json.dumps(result,indent=2))

