import fs from 'node:fs';
import assert from 'node:assert/strict';
import {catalogue,research,effectiveFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/data.ts';
import {applyBrandFeatureUpdates} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-updates.ts';
const p=JSON.parse(fs.readFileSync('/tmp/tesla-research/tesla-2026-10-14.json','utf8'));
const before=JSON.parse(fs.readFileSync('/tmp/tesla-research/review-history/tesla-approved-ed099843f37d65d0b8dbbc949b77b5ca01141936c7921cef3b5d24fb2ffdc059.json','utf8'));
for(const key of Object.keys(before))assert.deepEqual(key==='features'?p.features.slice(0,8):p[key],before[key]);
const onlyNew={...p,features:p.features.filter((f:any)=>f.criterion==='performance_rear_motor')};
assert.equal(onlyNew.features.length,8);
const data=research(),cars=catalogue().filter(c=>c.brand==='Tesla');
const result=[];
for(const c of cars){const old=effectiveFeatures(c,data), snapshot=JSON.stringify(old);const next=applyBrandFeatureUpdates(c,old,data,[onlyNew]);assert.equal(JSON.stringify(old),snapshot);const f=next.find(x=>x.criterion==='performance_rear_motor')!;assert.ok(f.value);assert.ok(String(f.value).includes(String(c.facts.power_kw.value)));assert.equal(f.buyerGrade,c.facts.power_kw.buyerGrade);assert.equal(f.conditions.toLowerCase().includes('output not published'),false);result.push({id:c.id,value:f.value,grade:f.buyerGrade,conditions:f.conditions});}
fs.writeFileSync('/tmp/tesla-research/performance-feature-validation.json',JSON.stringify({passed:8,unchangedSections:true,immutableInputs:true,result},null,2));console.log(JSON.stringify(result,null,2));
