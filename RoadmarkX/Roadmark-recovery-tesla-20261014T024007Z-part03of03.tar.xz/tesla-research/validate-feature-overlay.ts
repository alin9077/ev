import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {prepareBrandResearch, applyBrandUpdates, applyBrandFeatureUpdates} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-updates.ts';
import {featureClaim} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/citable.ts';
import {hydratePortablePacks,storePortablePacks} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/portable-packs.ts';
const load=(name:string)=>JSON.parse(fs.readFileSync('/tmp/tesla-research/'+name+'.json','utf8'));
const packet=load('tesla-2026-10-14');
const base=load('before');const research=load('research-before');const prior=load('features-before');
const original=JSON.stringify({base,research,prior,packet});
const data=prepareBrandResearch(research,[packet]);const cars=applyBrandUpdates(base,data,[packet]);
for(const car of cars){
 const features=applyBrandFeatureUpdates(car,prior.filter((f:any)=>f.variant_id===car.id),data,[packet]);
 const storage=features.find((f:any)=>f.criterion==='storage')!;
 const row=packet.features.find((f:any)=>f.variantId===car.id)!;
 assert.deepEqual(storage,row.after);
 const pack={car,features,sources:data.sources,eligibility:data.update_eligibility.find((r:any)=>r.variant_id===car.id),events:[],configuration:[]};
 const restored=hydratePortablePacks(storePortablePacks({[car.id]:pack}),data.sources)[car.id];
 assert.deepEqual(restored,pack);
 const claim=featureClaim(restored,'storage','Storage')!;
 assert.equal(claim.value,row.after.value);assert.equal(claim.gradeReview?.overlayId,packet.id);
 assert.equal(claim.gradeReviewStatus,undefined);
 assert.deepEqual(claim.sources.map((s:any)=>s.id),row.after.source_ids);
 if(car.modelId==='tesla_model_3'){assert.doesNotMatch(claim.value,/977/);assert.match(claim.value,/594/);assert.match(claim.value,/88/);assert.match(claim.value,/Not published/);}
 console.log(car.id,storage.value);
}
assert.equal(JSON.stringify({base,research,prior,packet}),original);
console.log('PASS',cars.length,'Tesla rows; exact before/after, all dependencies, original immutability, citable and portable propagation');
console.log('PACKET_SHA256',createHash('sha256').update(fs.readFileSync('/tmp/tesla-research/tesla-2026-10-14.json')).digest('hex'));
