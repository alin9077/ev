# Tesla Australia terms and market exclusions
Checked: 14 October 2026 Australia/Sydney (research performed 13 October 2026 23:27-23:30 UTC).
Scope: new Australian-market vehicles. Public read-only source checks only.

## Ready-to-use ownership summary (state once at brand level)
New Model 3 and Model Y deliveries from 1 January 2026 receive a Basic Vehicle Limited Warranty of five years/unlimited kilometres under normal use, subject to the delivered vehicle's terms. Roadside assistance follows active basic-warranty eligibility, giving five years for current normal-use new vehicles; it operates 24/7. The former four-year/80,000 km terms should not be applied to 2026 deliveries. [T01, T02, T03, T04, T10]

## Battery and drive-unit warranty: exact current trim mapping
All are eight years, with the stated distance limit applying first and a minimum 70% battery-capacity retention guarantee:
- 160,000 km: Model 3 RWD; Model 3 Premium RWD; Model Y Premium RWD
- 192,000 km: Model 3 Premium LR RWD; Model 3 Performance AWD; Model Y Premium LR AWD; Model Y Performance AWD; Model Y L
This is the exact grouping on the live Tesla Australia warranty page, including the recently added non-Premium Model 3 RWD. Do not assume every rear-drive version has the shorter warranty: Premium Long Range RWD has 192,000 km. [T01]

## Useful qualifications
The AU PDF has effective date 2026/1/1. Basic warranty concerns defects under normal use; tyre wear, routine maintenance and damage from misuse, accidents or inappropriate repair are excluded. SRS is separately five years/100,000 km. Rust-through from inside the body panel is separately 12 years/unlimited kilometres. The support webpage incorrectly says unlimited miles for rust; the AU PDF says kilometres. [T02]
Battery remedies may use reconditioned/remanufactured parts; a replacement is not necessarily new or restored to new capacity. Ordinary degradation beyond the stated minimum-capacity promise is excluded. Intentional abuse, collision damage, unauthorised battery/drive-unit servicing, flooding and ignored battery-maintenance instructions are among exclusions. Australian Consumer Law rights remain applicable. [T02]

## Roadside scope and exclusions
Tesla's official Australia support page links the global English policy. It defines eligibility by an active Basic Vehicle Limited Warranty (or relevant used warranty/service agreement), rather than a separate fixed number of years. [T04]
- Warrantable undriveable breakdown: transportation up to 800 km to the nearest Tesla Service Centre
- Flat tyre: up to 80 km; policy requires Tesla repair/replacement for covered towing, while the tyre work remains payable
- Eligible lockout: assistance/transport up to 80 km, subject to circumstances and availability
- Flat high-voltage battery/out of range: assistance may be arranged but is not financially covered [T03, T04]
Other exclusions include return transport after repair, towing beyond limits, non-warrantable failures, collisions, depleted low-voltage battery from wear, off-road/extraction incidents, toll/ferry costs, storage, unauthorised independently arranged assistance and service outside the warranty region. One service call per incident; location and availability can limit service. Do not call this unlimited free breakdown recovery. [T04]

## Commercial-use discrepancy to retain
EV Central's 8 January 2026 report states five years/150,000 km for commercial uses such as ride-share, taxis and deliveries. Other Australian reporting agrees. However, the live official AU warranty page and downloaded AU PDF (effective 1 Jan 2026) do not state that commercial cap; the PDF says five years/unlimited kilometres under normal use. This is an unresolved source difference, not evidence that all commercial use is unlimited. For a general consumer comparison, state normal-use coverage and note that commercial-use terms need vehicle-specific confirmation. [T01, T02, T10]

## Excluded from current Australian new-vehicle retail range
- Model S: AU /models redirects to AU homepage. Tesla AU ordering guide names only Model 3 and Model Y. CarExpert's current Tesla range page explicitly excludes S and X. Exclude current Model S from an Australian orderable-new comparison. [T05, T06, T09]
- Model X: AU /modelx also redirects to AU homepage; same official ordering guide and independent corroboration. [T05, T07, T09]
- Cybertruck: current AU landing-page source has Get Updates as its CTA and no Order Now CTA; /en_au/cybertruck/design redirects to the informational AU Cybertruck page. CarExpert says it remains outside the regular local range pending launch timing/retail availability. Treat as not currently Australian-orderable. [T08, T09]
- Roadster: live AU landing page is now a reveal countdown, with targetTime 2026-10-16T01:00:00Z (16 October 2026 in Australia). The indexed text saying Reserve Now is stale relative to the live capture. The /en_au/roadster/reserve endpoint still returns a reservation page, but its payment flow was not tested. Tesla's AU reservation agreement says a reservation does not constitute a vehicle purchase/order. Therefore exclude it from presently configurable Australian retail vehicles and label it upcoming/reservation-related, rather than claiming there is no reservation endpoint. CarExpert's 14 September 2026 report corroborates the upcoming/reveal status, though its original 2 October reveal date is superseded by the current official countdown. [T11, T12, T13, T14]

## Evidence files
Source registry: sources.json
Live HTML/PDF acquisition log with final URLs, response status and SHA-256: download-manifest.json
Full search/open result captures: web-research-captures.json
Official PDFs: warranty-2026-01-01.pdf; roadside-policy.pdf; roadster-reservation-terms.pdf
Plain-text PDF extracts: warranty-2026-01-01.txt; roadside-policy.txt
PDF image captures: warranty-cover.png; warranty-coverage-page4.png; roadside-start.png
Live CTA/countdown snippets: live-page-checks.txt

