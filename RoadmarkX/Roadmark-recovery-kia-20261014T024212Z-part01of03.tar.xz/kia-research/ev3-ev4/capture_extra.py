import urllib.request,concurrent.futures,json,pathlib,hashlib
from html.parser import HTMLParser
root=pathlib.Path('/tmp/kia-research/ev3-ev4/sources')
src={
'ev4-my26-earth-dealer':'https://www.rockdalecitykia.com.au/new-cars/for-sale/kia/ev4/2026/earth-long-range/ct-my26/3845919/',
'ev3-ce-dimensions':'https://www.carexpert.com.au/kia/ev3/2026/exterior-and-dimensions',
'ev3-ce-launch':'https://www.carexpert.com.au/car-reviews/2025-kia-ev3-review-2',
'ev3-evcentral-awd':'https://evcentral.com.au/more-grip-but-no-gt-kia-ev3-awd-confirmed-for-australia-with-195kw-559km-range-and-local-chassis-tune/',
'ev4-carsguide-2027':'https://www.carsguide.com.au/kia/ev4/price/2027',
'ev4-accessories':'https://www.kia.com/au/cars/ev4/accessories.html',
'ev3-accessories':'https://www.kia.com/au/cars/ev3/accessories.html',
'ev3-ce-2027-dimensions':'https://www.carexpert.com.au/kia/ev3/2027/exterior-and-dimensions'
}
def dl(x):
 k,u=x
 try:
  r=urllib.request.urlopen(u,timeout=45);d=r.read();(root/(k+'.html')).write_bytes(d);return(k,r.status,len(d))
 except Exception as e:return(k,str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:print(list(ex.map(dl,src.items())))
class Txt(HTMLParser):
 def __init__(self):super().__init__();self.text=[];self.skip=0
 def handle_starttag(self,t,a):
  if t in ['script','style']:self.skip+=1
 def handle_endtag(self,t):
  if t in ['script','style']:self.skip-=1
 def handle_data(self,d):
  if not self.skip and d.strip():self.text.append(d.strip())
for p in root.glob('*.html'):
 parser=Txt();parser.feed(p.read_text());p.with_suffix('.txt').write_text('\n'.join(parser.text))
