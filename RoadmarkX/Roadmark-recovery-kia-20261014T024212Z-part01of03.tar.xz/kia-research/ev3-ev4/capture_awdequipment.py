import urllib.request,concurrent.futures,json,pathlib,hashlib,subprocess
from html.parser import HTMLParser
root=pathlib.Path('/tmp/kia-research/ev3-ev4/sources'); old=json.load(open('/tmp/kia-research/research-before.json'))['sources'];ids=['kia_ev3_manual','kia_service','kia_ev3_ancap','kia_ev3_ancap_report','kia_ota_index','r4_superchargers'];src=[x for x in old if x['id'] in ids];src.append({'id':'kia_offers','url':'https://www.kia.com/au/shopping-tools/offers.html','title':'Kia Australia current offers','publisher':'Kia Australia','source_type':'manufacturer'})
class Txt(HTMLParser):
 def __init__(self):super().__init__();self.text=[];self.skip=0
 def handle_starttag(self,t,a):
  if t in ['script','style']:self.skip+=1
 def handle_endtag(self,t):
  if t in ['script','style']:self.skip-=1
 def handle_data(self,d):
  if not self.skip and d.strip():self.text.append(d.strip())
def dl(s):
 k='awd_'+s['id'];u=s['url'];p=root/(k+('.pdf' if '.pdf' in u else '.html'));t=p.with_suffix('.txt')
 try:
  r=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=90);d=r.read();p.write_bytes(d)
  if p.suffix=='.pdf':subprocess.run(['pdftotext','-layout',str(p),str(t)],check=True)
  else:a=Txt();a.feed(d.decode('utf8','replace'));t.write_text('\n'.join(a.text))
  return dict(key=k,url=u,title=s['title'],publisher=s['publisher'],source_type=s['source_type'],published_date=None,accessed_date='2026-10-14',market='AU',file=str(p),textFile=str(t),sha256=hashlib.sha256(d).hexdigest(),textSha256=hashlib.sha256(t.read_bytes()).hexdigest(),note='Fresh full capture for scoped EV3 AWD equipment review; source scope must be retained.',supports=[])
 except Exception as e:return {'key':k,'url':u,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=7) as ex:out=list(ex.map(dl,src))
(root.parent/'awd-captured-sources.json').write_text(json.dumps(out,indent=2));print([(x['key'],x.get('error',len(pathlib.Path(x['file']).read_bytes()))) for x in out])
