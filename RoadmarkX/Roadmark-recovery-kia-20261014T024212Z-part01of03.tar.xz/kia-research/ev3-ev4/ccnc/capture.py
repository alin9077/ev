import urllib.request,json,hashlib,datetime,concurrent.futures,re
from pathlib import Path
from html.parser import HTMLParser
ROOT=Path('/tmp/kia-research/ev3-ev4/ccnc')
class Text(HTMLParser):
 def __init__(self): super().__init__(); self.skip=0;self.parts=[]
 def handle_starttag(self,t,a):
  if t in ('script','style'):self.skip+=1
  if t in ('div','p','li','tr','h1','h2','h3','h4','br','td'):self.parts.append('\n')
 def handle_endtag(self,t):
  if t in ('script','style'):self.skip=max(0,self.skip-1)
  if t in ('div','p','li','tr','h1','h2','h3','h4','td'):self.parts.append('\n')
 def handle_data(self,s):
  if not self.skip:self.parts.append(s)
sources=json.load(open('/tmp/kia-research/research-before.json'))['sources']
keys=['kia_ccnc_profiles','kia_ccnc_general','kia_ccnc_contacts','kia_ccnc_ev','kia_ccnc_sound','kia_ccnc_voice','kia_connect']
sources=[s for s in sources if s['id'] in keys]
def get(s):
 with urllib.request.urlopen(s['url'],timeout=60) as r:
  b=r.read(); headers=dict(r.headers);final=r.url;code=r.status
 key=s['id'];html=ROOT/(key+'.html');html.write_bytes(b)
 txt=Text();txt.feed(b.decode('utf-8-sig'));t='\n'.join(re.sub(r'\s+',' ',x).strip() for x in ''.join(txt.parts).splitlines() if x.strip().replace('\ufeff',''))+'\n';(ROOT/(key+'.txt')).write_text(t)
 (ROOT/(key+'.headers.json')).write_text(json.dumps(headers,indent=2))
 return {'source_key':key,'url':s['url'],'resolved_url':final,'title':s['title'],'publisher':s['publisher'],'market':'AU','scope':'Generic Australia ccNC operational manual; no MY2027 EV3 AWD identification' if key.startswith('kia_ccnc') else 'Australia Kia Connect overview; compatibility and grade caveats apply','retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'http_status':code,'content_type':headers.get('Content-Type'), 'raw_path':str(html),'text_path':str(ROOT/(key+'.txt')),'headers_path':str(ROOT/(key+'.headers.json')),'raw_sha256':hashlib.sha256(b).hexdigest(),'text_sha256':hashlib.sha256(t.encode()).hexdigest(),'bytes':len(b)}
with concurrent.futures.ThreadPoolExecutor(max_workers=7) as ex: results=list(ex.map(get,sources))
(ROOT/'source-index.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
