import json,datetime
from pathlib import Path
P=Path('/tmp/kia-research/ev3-ev4/ccnc')
idx=json.load(open(P/'source-index.json'))
for s in idx:
 s.update(key=s['source_key'],source_type='official_au_manufacturer_manual' if s['source_key'].startswith('kia_ccnc') else 'official_au_manufacturer',accessed_date='2026-10-14',published_date=None,file=s['raw_path'],textFile=s['text_path'],sha256=s['raw_sha256'],textSha256=s['text_sha256'],registration_status='staged_only_not_registered')
(P/'source-index.json').write_text(json.dumps(idx,indent=2)+'\n')
base_scope='Australian ccNC/Kia Connect documentation freshly captured 14 October 2026; operational carryover to the MY2027 EV3 GT-Line AWD is Reported where the source does not identify the exact variant. Current exact Australian MY27 brochure establishes associated equipment only.'
items=[
{
 'criterion':'cloud_profile_transfer','suggested_status':'conditional','suggested_evidence_grade':'reported',
 'suggested_fact':'Kia Connect account-linked settings backup and transfer, with compatible software',
 'conditions':'Kia Connect profile linking and compatible software are required. AU FAQ explicitly describes applying backed-up vehicle/navigation settings to another car. No verified scope for every seat, mirror or HUD setting, every receiving Kia, or the exact MY27 AWD software build. The manual supports two user profiles plus guest; local seat memory is a different feature.',
 'source_keys':['kia_connect','kia_ccnc_profiles','ev3_my27_brochure'],
 'source_assertions':[{'source_key':'kia_connect','exact_quote_anchor':'apply it later to another car','locator':'kia_connect.txt lines 161–162, FAQ: What is the User Profile transfer feature and how can I use it?','claim':'With compatible software, link the driver profile to the Kia Connect account, adjust vehicle/navigation settings through the app, back up settings and reuse them in another car.'},{'source_key':'kia_ccnc_profiles','locator':'kia_ccnc_profiles.txt lines 5–16 and 20–27','claim':'Up to two profiles; guest cannot configure profile settings. App authentication links the user and offers previously saved settings. Settings vary by model/specification.'}],
 'not_established':['Exact MY27 AWD software capability','Universal cross-model transfer','Complete seat/mirror/HUD transfer']
},
{
 'criterion':'remote_preconditioning','suggested_status':'conditional','suggested_evidence_grade':'reported',
 'suggested_fact':'Kia Connect app remote and scheduled cabin climate control',
 'conditions':'Remote cabin heating/cooling is described by the AU Kia Connect service page; exact MY27 AWD command availability is operational carryover. Requires activation, compatible phone/app, data, reception and GPS. Features vary by grade and may change. This does not establish battery fast-charge preparation. Generic ccNC departure-time climate scheduling is also documented.',
 'source_keys':['kia_connect','kia_ccnc_ev','ev3_my27_brochure'],
 'source_assertions':[{'source_key':'kia_connect','exact_quote_anchor':'remotely activate, set and schedule climate control','locator':'kia_connect.txt lines 14–15 and 164–168','claim':'The app offers remote cabin climate activation, temperature setting and scheduling; normal Kia Connect conditions and model/grade caveats apply.'},{'source_key':'kia_ccnc_ev','locator':'kia_ccnc_ev.txt lines 51–54','claim':'EV menu includes cabin-temperature scheduling for the next departure.'}],
 'not_established':['Exact MY27 AWD remote climate duration/limits','Battery conditioning merely from the remote cabin-climate claim']
},
{
 'criterion':'media_resume','suggested_status':'not_verified','suggested_evidence_grade':'not_published','suggested_fact':None,
 'conditions':'Actual source/account/track resumption after re-entry is unestablished. Generic AU ccNC settings document suppressing automatic media at startup and retaining playback after shutdown; these are narrower than universal resume and are not exact MY27 AWD test evidence. Keep unknown rather than converting these adjacent controls into a positive resume claim.',
 'source_keys':['kia_ccnc_general'],
 'source_assertions':[{'source_key':'kia_ccnc_general','exact_quote_anchors':['Media Off at vehicle start-up','Maintain media playback when vehicle is turned Off'],'locator':'kia_ccnc_general.txt lines 55–60; applicability caveat line 5','claim':'Startup setting prevents media turning on automatically. Shutdown setting keeps infotainment active for a limited time or until the driver door opens. Available settings vary by model/specification.'}],
 'not_established':['Source-specific resume','Account continuity','Playback position retention across shutdown/re-entry','Universal automatic playback'],
 'supplemental_reported_operation':'ccNC startup-off and retained-after-shutdown playback settings are documented, subject to model/specification.'
},
{
 'criterion':'phone_contacts','suggested_status':'conditional','suggested_evidence_grade':'reported',
 'suggested_fact':'Bluetooth contact download and on-screen calling, subject to phone permissions and compatibility',
 'conditions':'AU ccNC manual describes downloading phone contacts and selecting them to call. Phone may need to approve download; SIM-contact and speed-dial support vary by handset. Exact MY27 AWD operation is carryover, while current brochure independently confirms Bluetooth fitment. Contacts are phone-associated; switching phones hides the previous phone’s list and privacy mode hides downloaded data.',
 'source_keys':['kia_ccnc_contacts','ev3_my27_brochure'],
 'source_assertions':[{'source_key':'kia_ccnc_contacts','exact_quote_anchor':'You cannot download contacts if the download is prohibited by the phone.','locator':'kia_ccnc_contacts.txt lines 4 and 11–17, 19–27','claim':'Contacts can be downloaded from a connected mobile device and selected to call; download permissions, handset compatibility and operating state constrain behavior.'}],
 'not_established':['Every handset/SIM compatibility','Cloud contact/account sync independent of the phone']
},
{
 'criterion':'alert_sound_quality','suggested_status':'not_verified','suggested_evidence_grade':'not_published','suggested_fact':None,
 'conditions':'Pleasantness, intrusiveness and comparative sound quality remain unknown without matched listening/driver-assistance tests. Generic AU ccNC documentation supplies warning-volume, haptic and certain if-equipped mute controls; it does not prove a particular delivered MY27 AWD alert calibration or software update. Do not use adjustable warnings as a qualitative verdict.',
 'source_keys':['kia_ccnc_sound','ev3_my27_brochure'],
 'source_assertions':[{'source_key':'kia_ccnc_sound','exact_quote_anchors':['Warning volume','Haptic warning','Speed limit warning sound (if equipped)'],'locator':'kia_ccnc_sound.txt lines 5–6, 70–93','claim':'Documented warning-method options include warning volume, steering-wheel vibration and model/software-dependent sound toggles. Some functions depend on infotainment/amplifier specifications.'}],
 'not_established':['Matched MY27 AWD sound-quality judgment','Exact delivered sound/toggle software behavior'],
 'supplemental_reported_operation':'Generic AU ccNC warning-volume/haptic options, with if-equipped sound controls. Current brochure separately lists haptic steering-wheel feedback.'
},
{
 'criterion':'navigation_route_planner','suggested_status':'conditional','suggested_evidence_grade':'reported',
 'suggested_fact':'Charging-station search and routes via chargers when destination exceeds available range',
 'conditions':'Current MY27 AWD brochure confirms satellite navigation; charger-aware operational behavior comes from generic AU ccNC guidance and is Reported carryover. Charger information/status depends on third-party data and may differ from reality. The captured pages do not establish a complete automatically optimized charging itinerary, predicted arrival SOC, target departure SOC, charging-stop durations or station reliability for this exact AWD build.',
 'source_keys':['kia_ccnc_ev','kia_connect','ev3_my27_brochure'],
 'source_assertions':[{'source_key':'kia_ccnc_ev','exact_quote_anchor':'route with charging stations within the drivable range','locator':'kia_ccnc_ev.txt lines 20–29 and 30–36','claim':'When the destination exceeds available driving range, the system can guide a route through charging stations within range; users can search/filter charging stations and set one as destination. Range and charger data carry accuracy caveats.'},{'source_key':'kia_connect','locator':'kia_connect.txt lines 11–12; 164–166','claim':'EV charging-location service supplies nearby stations, plug availability and compatible connector information, subject to connectivity and changing grade availability.'}],
 'not_established':['Exact MY27 AWD arrival-SOC prediction','Automatic full charging-itinerary optimization','Charging-stop duration estimates','Unconditional live data accuracy']
},
{
 'criterion':'battery_preconditioning_navigation','suggested_status':'conditional','suggested_evidence_grade':'reported',
 'suggested_fact':'If battery-heater equipped, battery-conditioning mode can warm the battery for a navigated DC charging destination',
 'conditions':'The freshly captured AU EV3 MY25 manual explicitly describes a DC charging destination trigger within battery-conditioning mode. This is MY25 operational carryover, not verified MY27 AWD heater fitment. Manual says mode requires a battery heater, is relevant to a cold battery and may not operate when charge is low to preserve driving distance. Energy use can reduce range; software changes may alter operation. Current MY27 brochure does not establish heater fitment, so actual heater availability remains unknown, not absent.',
 'source_keys':['awd_kia_ev3_manual','kia_ccnc_ev','ev3_my27_brochure'],
 'source_assertions':[{'source_key':'awd_kia_ev3_manual','exact_quote_anchor':'This mode is available for the vehicles equipped with the battery heater.','locator':'/tmp/kia-research/ev3-ev4/sources/awd_kia_ev3_manual.txt lines 869–912; printed pages 26–27','claim':'An if-equipped battery-conditioning section says choosing a DC charging station as destination in that mode can raise the battery to an adequate arrival temperature and reduce charging time; heater fitment is required.'},{'source_key':'kia_ccnc_ev','locator':'kia_ccnc_ev.txt lines 68–72','claim':'Generic ccNC battery-conditioning setting adjusts battery temperature for fast-charging performance; this ccNC page alone does not establish navigation triggering.'}],
 'not_established':['Battery-heater fitment in exact MY27 GT-Line AWD','Exact MY27 AWD navigation-conditioning implementation','Navigation-triggered battery cooling','Manual/remote conditioning from this navigation-destination claim'],
 'unknown_dependency':{'name':'Exact MY27 AWD battery-heater fitment','evidence_grade':'not_published','fact':None}
},
{
 'criterion':'voice_assistant','suggested_status':'conditional','suggested_evidence_grade':'reported',
 'suggested_fact':'ccNC native phone, navigation, media, settings and compatible climate/vehicle voice commands',
 'conditions':'Generic AU ccNC command coverage is operational carryover; vehicle-control support varies by model/specification. Calling requires a Bluetooth phone with downloaded contacts. Connected-car AI voice recognition is explicitly if equipped and requires Kia Connect subscription; server content/commands can change. This generic AI label is not proof of a generative/ChatGPT assistant or exact MY27 AWD availability. The brochure’s Android Auto/Apple CarPlay voice-recognition rows are phone projection and cannot alone establish native assistant coverage.',
 'source_keys':['kia_ccnc_voice','kia_ccnc_general','ev3_my27_brochure'],
 'source_assertions':[{'source_key':'kia_ccnc_voice','exact_quote_anchor':'Connected-car AI voice recognition','locator':'kia_ccnc_voice.txt lines 8–15, 16–34, 40–48','claim':'Command table covers phone calls, settings search, navigation destinations/waypoints, radio/media and climate/other vehicle functions. Connected-car AI recognition is if equipped and unavailable without a Kia Connect subscription.'},{'source_key':'kia_ccnc_general','locator':'kia_ccnc_general.txt lines 39–44','claim':'Voice-recognition availability also depends on supported system language.'}],
 'not_established':['Generative/ChatGPT assistant on exact MY27 AWD','Every listed vehicle-control command on exact AWD','Universal language availability']
},
{
 'criterion':'app_connectivity','suggested_status':'standard','suggested_evidence_grade':'confirmed',
 'suggested_fact':'Kia Connect telematics fitted to Australian MY27 EV3 GT-Line AWD',
 'conditions':'Exact MY27 brochure confirms Kia Connect telematics including eCall, remote control and vehicle status; its footnote also describes real-time traffic; detailed operation is described in the AU service overview with grade/compatibility caveats. Service activation, compatible phone/app, mobile data, reception and GPS are required. Complimentary seven years starts from the vehicle warranty start date and does not restart on ownership transfer. Coverage uses Optus 4G; phone data is at user cost. Remote lock/unlock is not a phone driving key. Exact long-term price after the included term and exact AWD feature-by-feature command set are not established here.',
 'source_keys':['ev3_my27_brochure','kia_connect'],
 'source_assertions':[{'source_key':'ev3_my27_brochure','locator':'/tmp/kia-research/ev3-ev4/sources/ev3-current.txt lines 247–250; grade column GT-Line AWD LR; footnote 9 lines 293–295','claim':'Kia Connect telematics row is fitted across all five grades including GT-Line AWD LR; footnote describes remote vehicle control, status monitoring and real-time traffic with phone compatibility caveat.'},{'source_key':'kia_connect','exact_quote_anchor':'Free for 7 years','locator':'kia_connect.txt lines 53–55, 86–94, 154–168','claim':'Seven complimentary years run from warranty start; app and vehicle need working data/network coverage. AU services operate via Optus 4G with activation, compatible-device/app and GPS requirements.'}],
 'not_established':['Exact price or terms after included seven-year period','Phone-as-driving-key from remote app unlock'],
 'subclaim_grading':{'Kia Connect equipment on exact MY27 AWD':'confirmed','Detailed service behavior subject to AU service conditions':'reported','Post-seven-year pricing':'not_published'}
}
]
for i in items:i['evidence_scope']=base_scope;i['accessed_date']='2026-10-14'
payload={'scope':'Roadmark Kia EV3 GT-Line AWD MY2027 operational corrections, read-only staged research','completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'policy':'No omission is treated as absence. Pure unknowns retain null fact and not_published grade. Exact-trim equipment claims are separated from generic or MY25 operational carryover. No source registration, repo edits or publishing performed.','findings':items,'source_index':str(P/'source-index.json'),'external_staged_source_dependencies':['ev3_my27_brochure','awd_kia_ev3_manual']}
(P/'findings.json').write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n')
summary='''# EV3 AWD ccNC operation findings (14 October 2026)\n\nAll seven requested AU source pages retrieved successfully as full HTML with text, headers and SHA-256 hashes in source-index.json. None identifies the exact MY27 AWD operational build. The current MY27 brochure and the freshly captured MY25 EV3 manual are referenced from the parent capture.\n\n- Confirmed exact equipment: Kia Connect telematics in the MY27 AWD brochure. Detailed app behavior keeps AU activation, compatibility, mobile-data/GPS, grade and Optus 4G conditions; seven years begins with warranty.\n- Reported operational carryover: compatible-software cloud profile transfer; remote cabin climate; Bluetooth contacts/calling; charger search and route-via-chargers; native ccNC voice command categories.\n- Battery/navigation: MY25 EV3 manual describes DC-destination warming only if battery-heater equipped, with cold-battery/low-charge conditions. Exact MY27 AWD heater fitment stays unknown. Generic ccNC battery-setting text alone is insufficient for navigation triggering.\n- Pure unknowns: actual media resume by source/account and alert sound quality. Recommended fact is null and grade not_published. Documented startup/retained-playback settings or warning controls can be contextual notes, not substitute findings.\n- Not established: arrival SOC/full automatic charging itinerary, exact AWD generative assistant availability, universal cross-model/all-setting profile transfer. Do not turn missing coverage into absence.\n\nNine detailed criterion records with claim locators, bounded exact quote anchors, conditions and unestablished subclaims are in findings.json. All changes are confined to this staging directory.\n'''
(P/'summary.md').write_text(summary)
print('Wrote findings:',len(items));print('Source keys:',','.join(x['key'] for x in idx))
