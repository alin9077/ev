# EV3 AWD ccNC operation findings (14 October 2026)

All seven requested AU source pages retrieved successfully as full HTML with text, headers and SHA-256 hashes in source-index.json. None identifies the exact MY27 AWD operational build. The current MY27 brochure and the freshly captured MY25 EV3 manual are referenced from the parent capture.

- Confirmed exact equipment: Kia Connect telematics in the MY27 AWD brochure. Detailed app behavior keeps AU activation, compatibility, mobile-data/GPS, grade and Optus 4G conditions; seven years begins with warranty.
- Reported operational carryover: compatible-software cloud profile transfer; remote cabin climate; Bluetooth contacts/calling; charger search and route-via-chargers; native ccNC voice command categories.
- Battery/navigation: MY25 EV3 manual describes DC-destination warming only if battery-heater equipped, with cold-battery/low-charge conditions. Exact MY27 AWD heater fitment stays unknown. Generic ccNC battery-setting text alone is insufficient for navigation triggering.
- Pure unknowns: actual media resume by source/account and alert sound quality. Recommended fact is null and grade not_published. Documented startup/retained-playback settings or warning controls can be contextual notes, not substitute findings.
- Not established: arrival SOC/full automatic charging itinerary, exact AWD generative assistant availability, universal cross-model/all-setting profile transfer. Do not turn missing coverage into absence.

Nine detailed criterion records with claim locators, bounded exact quote anchors, conditions and unestablished subclaims are in findings.json. All changes are confined to this staging directory.
