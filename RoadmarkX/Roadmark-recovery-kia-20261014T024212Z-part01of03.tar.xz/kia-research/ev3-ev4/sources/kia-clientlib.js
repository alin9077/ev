/*

	= Common Script Library for the Omniture & Google Analytics

	-
	- Direct Tracking Attribute Notation
	-
	data-an-tr -> 'event' attribute
	data-an-ca -> 'event_category' attribute
	data-an-ac -> 'event_action' attribute
	data-an-la -> 'event_label' attribute
	"data-an-" <name> -> <name> attribute with replace from '-' to '_'

	-
	- Tracking Controller Attribute Notation
	-
	data-anctl-cond   : fire condition := load | click | scroll | focus
	  - load   : fire on document loaded (default condition for all elements except <a>, <button> element)
	  - click  : fire on click at current element (default condition for <a>, <button> element)
	  - scroll : fire on scroll to current element
	  - focus  : fire on focus current element
	data-anctl-scope  : indicate the indirect tracking target scope by jQuery CSS selector notation (default: current element)
	data-anctl-target : indicate the indirect tracking target by jQuery CSS selector notation

	-
	- Tracking Label Interpolation
	-
	-   Notaion:   "%{" <directive> ["?"] ":" <expression> "}"
	-   Available: data-an-la, data-an-<addition variable> (Can't used for data-an-tr, data-an-ca, data-an-ac)
	-
	attr: capture an attribute value from the current DOM element; eg) %{attr:href}
	dom : capture text from the inclosing DOM element by jQuery CSS selector notation; eg) %{dom:div.wrap > span.label}
	text: capture inclosing text from the current DOM element; eg) %{text:}

	-
	- CSS Class Definition
	-
	an_notrack  : skip tracking

	-
	- Importing into each country
	-
	Edit /etc/designs/kia-<country>/clientlib/js.txt
	Add this line to top: 
		# GTM 360 Tagging Library
		../../../kia-global/clientlib/js/lib/tagging.js

	-
	- Examples
	-

	1. Track on page load
	   - Mandatory attributes: data-an-tr, data-an-ca, data-an-ac
	   - Additional attributes: data-an-<any attribute name>
	   <div data-an-tr="fixed" data-an-ca="test" data-an-ac="test" data-an-la="test fixed"></div>
	   <div data-an-tr="fixed" data-an-ca="test" data-an-ac="test" data-an-la="test fixed" data-an-test-attr="additional"></div>

	2. Track for outbound link
	   - No tagging required
	   <a href="http://abc.com.test/" target="_blank">Outlink Test</a>

	3. Track for any internal links
	   - Mandatory attributes: data-an-tr, data-an-ca, data-an-ac
	   <a href="/content/kwcms/au/en.html#"
	      data-an-tr="link" data-an-ca="test" data-an-ac="test" data-an-la="test link" data-an-test-attr="additional"
	   >Link Test</a>

	4. Track for <button> tag
	   <button data-an-tr="button" data-an-ca="test" data-an-ac="test" data-an-la="Test Button">Button</button>

	5. Track for PDF download
	   - No tagging required
	   <a href="http://abc.com.test/test.pdf" target="_blank">PDF Test</a>

	6. Track for PDF download without ".pdf" extension in URl
	   - [data-is-pdf="true"] attribute is required
	   - [data-pdf-url] attribute is optional
	   <a href="http://abc.com.test/test.file" data-is-pdf="true">PDF Test 2</a>
	   <a href="http://abc.com.test/test.file" data-is-pdf="true" data-pdf-url="test.pdf">PDF Test 2</a>

	7. Skip(ignore) tracking
	   - Specify CSS class: 'an_notrack'
	   <a href="http://abc.com.test/" target="_blank" class="an_notrack">Ignore Test</a>

 */
;
(function($) {

	const _DEBUG = true;

	const EVAR_TRACK = "event";
	const EVAR_CATEGORY = "event_category";
	const EVAR_ACTION = "event_action";
	const EVAR_LABEL = "event_label";
	const EVAR_VEHICLE_NAME = "vehicle_name";

	const TRACK_PAGE_VIEW = "page_view";
    const TRACK_PIP_VIEW = "pip_view";
	const TRACK_GA_EVENT = "ga_event";
	const TRACK_NAVIGATION = "navigation";
	const TRACK_LINK_INTERACTION = "link_interaction";
	const TRACK_ACCORDION_INTERACTION = "accordion_interaction";
	const TRACK_FORM_INTERACTION = "form_interaction";
	const TRACK_DOWNLOAD = "saving";

	const CATEGORY_NAVIGATION = "navigation";
	const CATEGORY_FORM = "form";
	const CATEGORY_DOWNLOAD = "saving";

	const ATTR_COND = "data-anctl-cond";
	const ATTR_SCOPE = "data-anctl-scope";
	const ATTR_TARGET = "data-anctl-target";
	const ATTR_FREQ = "data-anctl-frequency";

	const COND_LOAD = "load";
	const COND_CLICK = "click";
	const COND_SCROLL = "scroll";
	const COND_FOCUS = "focus";

	const FREQ_ONCE = "once";
	const FREQ_EVERY = "every";

	const CPTPFX_ATTR = "attr";
	const CPTPFX_DOM = "dom";
	const CPTPFX_TEXT = "text";

	const IEXP_PFX = "%{"; // interpolation prefix
	const IEXP_SFX = "}"; // interpolation suffix

	let _KIA = window.KIA || {};

	let _dtmDataLayer = window.dtmDataLayer || {};

	let _dataLayer = window.dataLayer || [];

	let _tag = {

		// This property must be initialized by each country (eg: /apps/kia-australia/components/page/fragments/tagging/init.jsp)
		omnitureEnabled : false,

		dtmDataLayer : _dtmDataLayer
	};
	_KIA.tagging = _tag;

	let _gtm = {

		dataLayer : _dataLayer,

		track : function(name, category, action, label, args) {
			let params = _gtmTrack(name, category, action, label);
			if (args) {
				params = $.extend({}, params, args);
			}
			_dataLayer.push(params);
			if (_DEBUG) {
				console.log("[DEBUG] New track captured: " + _dumpParams(params));
				console.dir(_dataLayer);
			}
		},

		trackPageView : function(pageType, vehicleName, args) {
			let params = {
                //"event" : vehicleName ? TRACK_PIP_VIEW : TRACK_PAGE_VIEW, #58345#comment-561639 2023/01/13 수정
				"event" : TRACK_PAGE_VIEW,
				"page_type" : _lower(pageType)
			};
            if (vehicleName) {
                //KWCMSAU-131 br태그 제거
            	vehicleName = vehicleName.replace("<br>", " ");
				params[EVAR_VEHICLE_NAME] = _lower(vehicleName);
			}

            if (args) {
				params = $.extend({}, params, args);
			}
			_dataLayer.push(params);
			if (_DEBUG) {
				console.log("[DEBUG] New page view track captured: " + _dumpParams(params));
				console.dir(_dataLayer);
			}
		},

		trackGeneral : function(category, action, label, args) {
			_gtm.track(TRACK_GA_EVENT, category, action, _lower(label), args);
		},

		trackNavigation : function(action, label, args) {
			_gtm.track(TRACK_NAVIGATION, CATEGORY_NAVIGATION, action, _lower(label), args);
		},

		trackLink : function(action, label, args) {
			_gtm.track(TRACK_LINK_INTERACTION, CATEGORY_NAVIGATION, action, _lower(label), args);
		},

		trackAccordion : function(action, label, args) {
			_gtm.track(TRACK_ACCORDION_INTERACTION, CATEGORY_NAVIGATION, action, _lower(label), args);
		},

		trackForm : function(action, label, args) {
			_gtm.track(TRACK_FORM_INTERACTION, CATEGORY_FORM, action, _lower(label), args);
		},

		trackDownload : function(fileType, url, args) {
			_gtm.track(TRACK_DOWNLOAD, CATEGORY_DOWNLOAD, fileType, url, args);
		}
	};
	_KIA.tagging.gtm = _gtm;

	// expose to global
	//
	window.KIA = _KIA;
	window.dtmDataLayer = _dtmDataLayer;
	window.dataLayer = _dataLayer;

	//
	// PRIVATE FUNCTIONS
	//

	function _gtmTrack(name, category, action, label) {
		return {
			"event" : _lower(name),
			"event_category" : _lower(category),
			"event_action" : _lower(action),
			"event_label" : label
		};
	}

	function _lower(s) {
		return $.trim(s || "").toLowerCase();
	}

	//
	// TAGGING INITIALIZATION
	//

	let _timer = null;

	let $win = $(window);

	function _initTagging() {
		_timer = null;

		_checkCommonLinks();

		$("[data-an-tr]").each(function() {
			let $this = $(this);
			let r = _dispatchTagging($this);
			if (!_isValidTag(r.parameters)) {
				console.log("[TAGGING] Invalid tagging detected: " + _dumpParams(r.parameters));
				return;
			}
			_setupTaggingRule($this, r);
		});
	}

	function _dispatchTagging($elem) {
		let params = {};
		let dynVars = [];
		let attrs = $elem[0].attributes;
		for (let i = 0; i < attrs.length; i++) {
			let attr = attrs[i];
			if (attr.name.indexOf('data-an-') === 0) {
				let nm = attr.name.substring(8);
				if (nm === 'tr') {
					params[EVAR_TRACK] = _lower(attr.value);
				} else if (nm === 'ca') {
					params[EVAR_CATEGORY] = _lower(attr.value);
				} else if (nm === 'ac') {
					params[EVAR_ACTION] = _lower(attr.value);
				} else if (nm === 'la') {
					let val = $.trim(attr.value);
					if (val.indexOf(IEXP_PFX) >= 0) {
						dynVars.push(EVAR_LABEL);
					}
					params[EVAR_LABEL] = val;
				} else {
					let vname = nm.replace('-', '_');
					let val = $.trim(attr.value);
					if (val.indexOf(IEXP_PFX) >= 0) {
						dynVars.push(vname);
					}
					params[vname] = val;
				}
			}
		}
		return {
			parameters : params,
			dynamicVariables : dynVars
		};
	}

	function _setupTaggingRule($elem, paramRec) {

		function _parseRuleConfig($el, r) {

			function _parseLabelTemplate(s) {
				let tokens = [];
				while (s.length > 0) {
					let si = s.indexOf(IEXP_PFX);
					if (si < 0) { // no more interpolation
						tokens.push({
							text : s
						});
						break;
					}
					let ei = s.indexOf(IEXP_SFX, si);
					if (ei < 0) { // not found suffix (illegal expression)
						tokens.push({
							text : s
						});
						break;
					}

					tokens.push({
						text : s.substring(0, si)
					}); // add plain text

					let exp = $.trim(s.substring(si + IEXP_PFX.length, ei));
					s = s.substring(ei + IEXP_SFX.length);

					let idx = exp.indexOf(":");
					if (idx > 0) {
						let drtv = _lower(exp.substring(0, idx));
						let optional = false;
						if (drtv.indexOf('?') === drtv.length - 1) {
							optional = true;
							drtv = drtv.substring(0, drtv.length - 1);
						}

						let tgt = $.trim(exp.substring(idx + 1));
						if ((drtv === CPTPFX_ATTR || drtv === CPTPFX_DOM) && tgt !== "") {
							tokens.push({
								directive : drtv,
								target : tgt,
								optional : optional
							}); // add interpolation expression
							continue;
						}
						if (drtv === CPTPFX_TEXT) {
							tokens.push({
								directive : drtv,
								optional : optional
							});
							continue;
						}
					}

					// illegal syntax: no print
					console.log("[GTM] Illegal interpolation: " + exp);
				}
				return tokens;

			} // end function _parseLabelTemplate

			let cfg = {};

			let cond = _lower($el.attr(ATTR_COND));
			if (cond === "") {
				cond = $el.is("a") || $el.is("button") ? COND_CLICK : COND_LOAD;
			}
			cfg.cond = cond;

			let freq = _lower($el.attr(ATTR_FREQ));
			if (freq !== FREQ_ONCE) {
				freq = FREQ_EVERY;
			}
			cfg.frequency = freq; 

			let scope = $.trim($el.attr(ATTR_SCOPE));
			cfg.$scope = scope !== "" ? $(scope) : $el;

			let target = $.trim($el.attr(ATTR_TARGET));
			cfg.$target = target !== "" ? cfg.$scope.find(target) : $el;

			if (r.dynamicVariables.length > 0) {
				cfg.dynamics = [];
				for (let i = 0; i < r.dynamicVariables.length; i++) {
					let vname = r.dynamicVariables[i];
					let tokens = _parseLabelTemplate(r.parameters[vname]);
					cfg.dynamics.push({
						variableName : vname,
						templateTokens : tokens
					});
				}
			}

			return cfg;

		} // end function _parseRuleConfig

		function _fireTrack($el, cfg, p) {

			function _compileLabelTemplate($e, tokens) {
				let arr = [];
				for (let i = 0; i < tokens.length; i++) {
					let t = tokens[i];
					let val = "";
					if (t.directive) {
						if (t.directive === CPTPFX_ATTR) {
							val = $.trim($e.attr(t.target));
						} else if (t.directive === CPTPFX_DOM) {
							let $t = $e.find(t.target);
							if ($t.length > 0) {
								val = $.trim($t.text()).replace(/[ \t\r\n]+/gi, ' ');
							}
						} else if (t.directive === CPTPFX_TEXT) {
							val = $.trim($e.text()).replace(/[ \t\r\n]+/gi, ' ');
						}
						if (!t.optional && val === "") {
							val = "!!ERROR!!";
						}
					} else if (t.text) {
						val = t.text;
					}
					arr.push(val);
				}
				return arr.join("");

			} // end function _compileLabelTemplate

			if (_DEBUG) {
				console.log("[DEBUG] Fire tracking event");
				console.dir({
					element : $el,
					config : cfg,
					parameters : p
				});
			}

			let copyed = $.extend({}, p);
            //KWCMSAU-131 br태그 제거
            if(copyed.vehicle_name){
                copyed.vehicle_name = copyed.vehicle_name.replace("<br>", " ");

            }
			let errorFlag = false;

			if (cfg.dynamics) {
				for (let i = 0; i < cfg.dynamics.length; i++) {
					let dyn = cfg.dynamics[i];
					let val = _compileLabelTemplate($el, dyn.templateTokens);
					if (!errorFlag && val.indexOf("!!ERROR!!") >= 0) {
						errorFlag = true;
					}
					copyed[dyn.variableName] = val;
				}
			}
			if (errorFlag) {
				if (_DEBUG) {
					console.log("[DEBUG] Skip '" + cfg.cond + "' action track: ERROR DETECTED: " + _dumpParams(copyed));
				}
				return;
			}

			if (cfg.frequency === FREQ_ONCE && $el.get(0).gtm_tagFireFlag) {
				console.log("[DEBUG] Already fired GTM event; ignore current");
				return;
			}
			$el.get(0).gtm_tagFireFlag = true;

			if (!copyed[EVAR_LABEL] || copyed[EVAR_LABEL] === "") {
				copyed[EVAR_LABEL] = $.trim($el.text());
			}

			_dataLayer.push(copyed);

			if (_DEBUG) {
				console.log("[DEBUG] New '" + cfg.cond + "' action track captured: " + _dumpParams(copyed));
				console.dir(_dataLayer);
			}
		} // end function _fireTrack

		let params = paramRec.parameters;
		let cfg = _parseRuleConfig($elem, paramRec);

		// Fixed (on load) tracking
		//
		if (cfg.cond === COND_LOAD) {
			_fireTrack($elem, cfg, params);
		}

		// On click or focus tracking
		//
		else if (cfg.cond === COND_CLICK || cfg.cond === COND_FOCUS) {
			let event = (cfg.cond === COND_CLICK ? "click" : "focus") + ".gtm";
			cfg.$target.off(event).on(event, {
				config : cfg,
				tagParams : params
			}, function(evt) {
				_fireTrack($(this), evt.data.config, evt.data.tagParams);
			});
		}

		// On scroll tracking
		//
		else if (cfg.cond === COND_SCROLL) {
			let flagId = "_GTM_SCROLL_FLAG_";
			$win.on("scroll", {
				config : cfg,
				tagParams : params
			}, function(evt) {
				evt.data.config.$target.each(function(i, elem) {
					let $t = $(elem);
					let wtop = $win.scrollTop();
					let ctop = $t.offset().top;
					let cbottom = ctop + $t.height();
					if (wtop >= ctop && wtop <= cbottom) { // in range
						if (!elem[flagId]) { // fire
							elem[flagId] = true;
							_fireTrack($t, evt.data.config, evt.data.tagParams);
						}
					} else { // out of range
						if (elem[flagId]) { // clear
							elem[flagId] = false;
						}
					}
				});
			});
		}

		// Unknown tracking
		//
		else {
			console.log("Unknown track condition: " + cfg.cond + "; ignore current rule");
		}
	}

	function _isValidTag(params) {
		return params[EVAR_TRACK] && params[EVAR_CATEGORY] && params[EVAR_ACTION];
	}

	function _dumpParams(params) {
		let arr = [];
		for ( let ev in params) {
			arr.push(ev + "=[" + params[ev] + "]");
		}
		return arr.join("; ");
	}

	function _checkCommonLinks() {
		// A태그의 링크값(href)에 외부도메인이 걸려있을 경우. pdf외부링크는 제외.
		//
		$("a").not("[href$=\'.pdf\']").each(function() {
			let $this = $(this);
			if (!$this.is("[data-an-tr]") && !$this.hasClass("an_notrack") && !$this.is("[data-is-pdf=true]")) {
				// 링크의 도메인이 외부도메인인지 여부, 링크가 http로 시작하는지 여부
				let href = $this.prop('href');
				if (href.indexOf(document.domain) < 0 && href.startsWith("http")) {
                    $this.off('click.tag.anchor').on('click.tag.anchor', function() {
                        if( $this.hasClass("moment") )
                        {
                            _gtm.track('Outbound Links', 'navigation', 'outbound link', _lower($(this).attr('href')));
                        }
                        else
                        {
							_gtm.trackLink("outbound link", $(this).attr('href')); //eg: https://www.youtube.com/c/kiachile 
                        }
					});
				}


			}
		});

		// 판정기준1 : A태그의 링크값(href)에 pdf링크가 걸려있을 경우
		// 판정기준2 : A태그의 data-is-pdf 값이 true 일 경우
		// 판정기준  : 1,2 의 결과를 merge 하여 처리
		// KWCMSAU-102 byo complete페이지일 경우 제외
        let byoUrl = window.location.href;
        if(byoUrl.indexOf("complete") == -1){
            let arr1 = $.makeArray($("a[href$=\'.pdf\']"));
            let arr2 = $.makeArray($("a[data-is-pdf=true]"));
            if (arr1.length > 0 || arr2.length > 0) {
                let links = $.unique(arr1.concat(arr2));
                for ( let i in links) {
                    let $link = $(links[i]);
                    if (!$link.is("[data-an-tr]") && !$link.hasClass("an_notrack")) {
                        $link.off('click.tag.pdf').on('click.tag.pdf', function() {
                            //eg: https://www.kia.com/content/dam/kwcms/cl/es/files/fichas-tecnicas/FichasTecnic as/Ficha-T%C3%A9cnica-KiaSeltos.pdf
                            _gtm.trackDownload("pdf download", $(this).data('pdf-url') || $(this).attr('href'));
                        });
                    }
                }
            }
        }

	}

	$(function() {
		if (_timer) {
			clearTimeout(_timer);
		}
		_timer = setTimeout(_initTagging, 100);
	});

})(jQuery);
/*
 *  2014.09.22  zt
 *  kia center.js 
 * 
 */

$(document).ready(function() {
   if($(".bbs_event").length){
      eventsInit();
   }

   if($(".bbs_news").length){
      newsInit();
   }

   //faq,notice
});

var eventsInit = function(){
    var MOBILEWIDTH = 767, ieVer = msieversion(), viewportWidth, marginTop = 20, marginLeft = 20, hArray=[];
    var bbsliNum = 0, targetLineNum = 0, bbsliMaxNum, bbsMinHeight, isOpen = false, isTabFous = false;
	var lastWindowHeight = 800;
    var lastWindowWidth = 900;
    $(window).resize(function(){
		if($(window).height()!=lastWindowHeight || $(window).width()!=lastWindowWidth){
            lastWindowHeight = $(window).height();
            lastWindowWidth = $(window).width();
            eventResize();
        }
	}).resize();
    initCss();

    $(".bbs_type2 .bbs_li a.moreBtn").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        var $parentLi = $(this).parent().parent().parent();
        var idx = $(this).parent().parent().parent().index();

        if(!$parentLi.hasClass("bbs_open")){
            $(".bbs_li").removeClass("bbs_open");
            $parentLi.fadeOut(300, function(){
                $parentLi.addClass("bbs_open");           
                bbsliNum = idx;
                targetLineNum = $parentLi.attr("line");
                if($("*:focus").length){
                    isTabFous = true;    
                }
                if(ieVer < 9 && ieVer !== false){ 
                    openWebDetail(0.5);
                }else{
                    if(viewportWidth > MOBILEWIDTH){
                        openWebDetail(0.5);        
                    }else{
                        openMobileDetail(0.5);
                    }    
                }
            })
        }
    });
    
     $(".bbs_type2 .bbs_li a.closeBtn").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        var $parentLi = $(this).parent().parent();
        $parentLi.removeClass( "bbs_open" );
        if(ieVer < 9 && ieVer !== false){ 
            closeDetail(0.5);
        }else{
            if(viewportWidth > MOBILEWIDTH){
                closeDetail(0.5);     
            }else{
                isOpen = false;
            }   
        }
    });
    
    function initCss(){
        bbsliMaxNum = $(".bbs_li").length;
        for(var i =0; i < bbsliMaxNum ; i++){
            var liN = parseInt(i/3);
            hArray[liN] = 0;
        }
        
        $(".bbs_li").each(function(i,t){
            var hLine = parseInt(i/3);
            var vLine = i%3;
            var liHeight = $(".bbs_li").eq(i).height();
            if(hArray[hLine] <  liHeight){
                hArray[hLine] = liHeight;    
            }
            $(this).attr("line",hLine);
            $(this).attr("index",i);
            var top = arrSum(hArray,hLine) + (marginTop*hLine);
            $(this).css({"top":top, "left": vLine * 33.3+"%"});
        });
        bbsMinHeight =  arrSum(hArray,hArray.length) + (marginTop * hArray.length);
		if(bbsMinHeight < 380){bbsMinHeight = 380;}
        $(".bbs_type2").css({"overflow":"hidden","position":"relative","min-height":bbsMinHeight});
        $(".bbs_li").css({"position":"absolute"});
    }
    
    function eventResize(){
         throttle(eventSetPos);
    }
    
    function eventSetPos(){
        document.body.style.overflow = "hidden";
        viewportWidth = $(window).width();
        document.body.style.overflow = "";
        if(ieVer < 9 && ieVer !== false){ 
			
        }else{
            if(viewportWidth > MOBILEWIDTH){
               initCss();
               if(isOpen){
                   openWebDetail(0);
               }
            }else{
              $(".bbs_type2").css({"overflow":"","position":"relative","min-height":""});
              $(".bbs_li").css({"position":"relative","top":"","left":""});
               if(isOpen){
                   openMobileDetail(0);
               }
            }    
        }
    }
    
   function openWebDetail(duration){
       isOpen = true;
       var wrpHeight;
       hArray.length = 0;
       $(".bbs_li:not(.bbs_open)").each(function(i,t){
            var liN = parseInt(i/3);
            hArray[liN] = 0;
       });
       $(".bbs_li").eq(bbsliNum).fadeIn(300, function(){
            wrpHeight = $(this).find(".bbs_wrp").outerHeight()+marginTop;
            $(".bbs_li:not(.bbs_open)").each(function(i,t){
                  var hLine = parseInt(i/3);
                  var vLine = i%3;
                  var liHeight = $(this).height();

                  if(hArray[hLine] <  liHeight){
                      hArray[hLine] = liHeight;    
                  }
                  var top = arrSum(hArray,hLine) + (marginTop*hLine);
                  if(targetLineNum <= hLine){
                      TweenMax.to($(this), duration, {top:top + wrpHeight, left:vLine * 33.3+"%", ease:"easeOutQuart"});    
                  }else{
                      TweenMax.to($(this), duration, {top:top, left:vLine * 33.3+"%", ease:"easeOutQuart"});
                  }
             });
             var targetTop = arrSum(hArray,targetLineNum) + (marginTop*targetLineNum);
             TweenMax.to($(".bbs_li").eq(bbsliNum), duration, {top:targetTop, left:0, ease:"easeOutQuart", onComplete:openEnd});
             
             bbsMinHeight =  arrSum(hArray,hArray.length) + (marginTop * hArray.length);
             $(".bbs_type2").css({"min-height":bbsMinHeight+wrpHeight}); 
       });
    }
    
    function openMobileDetail(duration){
       isOpen = true;
       $(".bbs_li").eq(bbsliNum).fadeIn(300, function(){
          openEnd();
       });
    }
    
    function openEnd(){
        var scrollTop = $(".bbs_li").eq(bbsliNum).offset().top;
        $("body,html").stop().animate({"scrollTop": scrollTop}, 500, function(){
            if(isTabFous){
                $(".bbs_li").eq(bbsliNum).find("a.closeBtn").focus();    
            }
        });
    }
    
   function closeDetail(duration){
        isOpen = false;
        initCss();
        if(isTabFous){
            $(".bbs_li").eq(bbsliNum).find("a.moreBtn").focus();    
        }
    }    
};

var newsInit = function(){

    var MOBILEWIDTH = 767, ieVer = msieversion(), viewportWidth, marginTop = 20, marginLeft = 20, hArray=[];
    var bbsliNum = 0, targetLineNum = 0, bbsliMaxNum, bbsMinHeight, isOpen = false, isTabFous = false;
    var lastWindowHeight = 800;
    var lastWindowWidth = 900;
    $(window).resize(function(){
		if($(window).height()!=lastWindowHeight || $(window).width()!=lastWindowWidth){
            lastWindowHeight = $(window).height();
            lastWindowWidth = $(window).width();
            newsResize();
        }
	}).resize();

    initCss();

    $(".bbs_type2 .bbs_li a.moreBtn").on("click", function(e){

        e.stopPropagation();
        e.preventDefault();

        var $parentLi = $(this).parent().parent().parent();
        var $pParentLi = $(this).parent().parent().parent().parent().parent();

        $pParentLi.find(".bbs_wrp").find("#tiImg").each(function(i){
            $(this).show();
        });

        $pParentLi.find(".bbs_wrp").find("#diImg").each(function(i){
            $(this).hide();
        });

        var idx = $(this).parent().parent().parent().index();
        if(!$parentLi.hasClass("bbs_open")){
            $(".bbs_li").removeClass("bbs_open");
            $parentLi.fadeOut(300, function(){

                $parentLi.addClass("bbs_open");           
				var tImg = $parentLi.find("#tiImg");
                var dImg = $parentLi.find("#diImg");

                tImg.hide();
                dImg.show();

                bbsliNum = idx;
                targetLineNum = $parentLi.attr("line");
                if($("*:focus").length){
                    isTabFous = true;    
                }
                if(ieVer < 9 && ieVer !== false){ 
                    openWebDetail(0.5);
                }else{
                    if(viewportWidth > MOBILEWIDTH){
                        openWebDetail(0.5);        
                    }else{
                        openMobileDetail(0.5);
                    }    
                }
            })
        }
    });
    
     $(".bbs_type2 .bbs_li a.closeBtn").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();

        var $parentLi = $(this).parent().parent().parent();
        $parentLi.removeClass( "bbs_open" );
        var tImg = $parentLi.find("#tiImg");
        var dImg = $parentLi.find("#diImg");

        tImg.show();
        dImg.hide();

        if(ieVer < 9 && ieVer !== false){ 
            closeDetail(0.5);
        }else{
            if(viewportWidth > MOBILEWIDTH){
                closeDetail(0.5);     
            }else{
                isOpen = false;
            }   
        }
    });
    
    function initCss(){
        bbsliMaxNum = $(".bbs_li").length;
        for(var i =0; i < bbsliMaxNum ; i++){
            var liN = parseInt(i/3);
            hArray[liN] = 0;
        }
        
        $(".bbs_li").each(function(i,t){
            var hLine = parseInt(i/3);
            var vLine = i%3;
            var liHeight = $(".bbs_li").eq(i).height();
            if(hArray[hLine] <  liHeight){
                hArray[hLine] = liHeight;    
            }
            $(this).attr("line",hLine);
            $(this).attr("index",i);
            var top = arrSum(hArray,hLine) + (marginTop*hLine);
            $(this).css({"top":top, "left": vLine * 33.3+"%"});
        });
        bbsMinHeight =  arrSum(hArray,hArray.length) + (marginTop * hArray.length);
		if(bbsMinHeight < 380){bbsMinHeight = 380;}
        $(".bbs_type2").css({"overflow":"hidden","position":"relative","min-height":bbsMinHeight});
        $(".bbs_li").css({"position":"absolute"});
    }
    
    function newsResize(){
         throttle(newsSetPos);
    }
    
    function newsSetPos(){
        document.body.style.overflow = "hidden";
        viewportWidth = $(window).width();
        document.body.style.overflow = "";
        if(ieVer < 9 && ieVer !== false){ 
        }else{
            if(viewportWidth > MOBILEWIDTH){
               initCss();
               if(isOpen){
                   openWebDetail(0);
               }
            }else{
              $(".bbs_type2").css({"overflow":"","position":"relative","min-height":""});
              $(".bbs_li").css({"position":"relative","top":"","left":""});
               if(isOpen){
                   openMobileDetail(0);
               }
            }    
        }
    }
    
   function openWebDetail(duration){
       isOpen = true;
       var wrpHeight;
       hArray.length = 0;
       $(".bbs_li:not(.bbs_open)").each(function(i,t){
            var liN = parseInt(i/3);
            hArray[liN] = 0;
       });
       $(".bbs_li").eq(bbsliNum).fadeIn(300, function(){
            wrpHeight = $(this).find(".bbs_wrp").outerHeight()+marginTop;
            $(".bbs_li:not(.bbs_open)").each(function(i,t){
                  var hLine = parseInt(i/3);
                  var vLine = i%3;
                  var liHeight = $(this).height();

                  if(hArray[hLine] <  liHeight){
                      hArray[hLine] = liHeight;    
                  }
                  var top = arrSum(hArray,hLine) + (marginTop*hLine);
                  if(targetLineNum <= hLine){
                      TweenMax.to($(this), duration, {top:top + wrpHeight, left:vLine * 33.3+"%", ease:"easeOutQuart"});    
                  }else{
                      TweenMax.to($(this), duration, {top:top, left:vLine * 33.3+"%", ease:"easeOutQuart"});
                  }
             });
             var targetTop = arrSum(hArray,targetLineNum) + (marginTop*targetLineNum);
             TweenMax.to($(".bbs_li").eq(bbsliNum), duration, {top:targetTop, left:0, ease:"easeOutQuart", onComplete:openEnd});
             
             bbsMinHeight =  arrSum(hArray,hArray.length) + (marginTop * hArray.length);
             $(".bbs_type2").css({"min-height":bbsMinHeight+wrpHeight}); 
       });
    }
    
    function openMobileDetail(duration){
       isOpen = true;
       $(".bbs_li").eq(bbsliNum).fadeIn(300, function(){
          openEnd();
       });
    }
    
    function openEnd(){
        var scrollTop = $(".bbs_li").eq(bbsliNum).offset().top;
        $("body,html").stop().animate({"scrollTop": scrollTop}, 500, function(){
            if(isTabFous){
                $(".bbs_li").eq(bbsliNum).find("a.closeBtn").focus();    
            }
        });
    }
    
   function closeDetail(duration){
        isOpen = false;
        initCss();
        if(isTabFous){
            $(".bbs_li").eq(bbsliNum).find("a.moreBtn").focus();    
        }
    }
};



function arrSum(array,len) {
  var result = 0.0;
  for (var i = 0; i < len; i++)
    result += array[i];

  return result;
} 

function throttle(method,context) {
      clearTimeout(method.tId);
      method.tId = setTimeout(function(){
          method.call(context);
      },100);
 }

/* Font Face Observer v2.0.13 - © Bram Stein. License: BSD-3-Clause */
(function() {
    'use strict';
    var f, g = [];

    function l(a) { g.push(a);
        1 == g.length && f() }

    function m() { for (; g.length;) g[0](), g.shift() }
    f = function() { setTimeout(m) };

    function n(a) { this.a = p;
        this.b = void 0;
        this.f = []; var b = this; try { a(function(a) { q(b, a) }, function(a) { r(b, a) }) } catch (c) { r(b, c) } }
    var p = 2;

    function t(a) { return new n(function(b, c) { c(a) }) }

    function u(a) { return new n(function(b) { b(a) }) }

    function q(a, b) { if (a.a == p) { if (b == a) throw new TypeError; var c = !1; try { var d = b && b.then; if (null != b && "object" == typeof b && "function" == typeof d) { d.call(b, function(b) { c || q(a, b);
                        c = !0 }, function(b) { c || r(a, b);
                        c = !0 }); return } } catch (e) { c || r(a, e); return }
            a.a = 0;
            a.b = b;
            v(a) } }

    function r(a, b) { if (a.a == p) { if (b == a) throw new TypeError;
            a.a = 1;
            a.b = b;
            v(a) } }

    function v(a) { l(function() { if (a.a != p)
                for (; a.f.length;) { var b = a.f.shift(),
                        c = b[0],
                        d = b[1],
                        e = b[2],
                        b = b[3]; try { 0 == a.a ? "function" == typeof c ? e(c.call(void 0, a.b)) : e(a.b) : 1 == a.a && ("function" == typeof d ? e(d.call(void 0, a.b)) : b(a.b)) } catch (h) { b(h) } } }) }
    n.prototype.g = function(a) { return this.c(void 0, a) };
    n.prototype.c = function(a, b) { var c = this; return new n(function(d, e) { c.f.push([a, b, d, e]);
            v(c) }) };

    function w(a) { return new n(function(b, c) {
            function d(c) { return function(d) { h[c] = d;
                    e += 1;
                    e == a.length && b(h) } } var e = 0,
                h = [];
            0 == a.length && b(h); for (var k = 0; k < a.length; k += 1) u(a[k]).c(d(k), c) }) }

    function x(a) { return new n(function(b, c) { for (var d = 0; d < a.length; d += 1) u(a[d]).c(b, c) }) };
    window.Promise || (window.Promise = n, window.Promise.resolve = u, window.Promise.reject = t, window.Promise.race = x, window.Promise.all = w, window.Promise.prototype.then = n.prototype.c, window.Promise.prototype["catch"] = n.prototype.g);
}());

(function() {
    function l(a, b) { document.addEventListener ? a.addEventListener("scroll", b, !1) : a.attachEvent("scroll", b) }

    function m(a) { document.body ? a() : document.addEventListener ? document.addEventListener("DOMContentLoaded", function c() { document.removeEventListener("DOMContentLoaded", c);
            a() }) : document.attachEvent("onreadystatechange", function k() { if ("interactive" == document.readyState || "complete" == document.readyState) document.detachEvent("onreadystatechange", k), a() }) };

    function r(a) {
        this.a = document.createElement("div");
        this.a.setAttribute("aria-hidden", "true");
        this.a.appendChild(document.createTextNode(a));
        this.b = document.createElement("span");
        this.c = document.createElement("span");
        this.h = document.createElement("span");
        this.f = document.createElement("span");
        this.g = -1;
        this.b.style.cssText = "max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;";
        this.c.style.cssText = "max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;";
        this.f.style.cssText = "max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;";
        this.h.style.cssText = "display:inline-block;width:200%;height:200%;font-size:16px;max-width:none;";
        this.b.appendChild(this.h);
        this.c.appendChild(this.f);
        this.a.appendChild(this.b);
        this.a.appendChild(this.c)
    }

    function t(a, b) { a.a.style.cssText = "max-width:none;min-width:20px;min-height:20px;display:inline-block;overflow:hidden;position:absolute;width:auto;margin:0;padding:0;top:-999px;white-space:nowrap;font-synthesis:none;font:" + b + ";" }

    function y(a) { var b = a.a.offsetWidth,
            c = b + 100;
        a.f.style.width = c + "px";
        a.c.scrollLeft = c;
        a.b.scrollLeft = a.b.scrollWidth + 100; return a.g !== b ? (a.g = b, !0) : !1 }

    function z(a, b) {
        function c() { var a = k;
            y(a) && a.a.parentNode && b(a.g) } var k = a;
        l(a.b, c);
        l(a.c, c);
        y(a) };

    function A(a, b) { var c = b || {};
        this.family = a;
        this.style = c.style || "normal";
        this.weight = c.weight || "normal";
        this.stretch = c.stretch || "normal" }
    var B = null,
        C = null,
        E = null,
        F = null;

    function G() { if (null === C)
            if (J() && /Apple/.test(window.navigator.vendor)) { var a = /AppleWebKit\/([0-9]+)(?:\.([0-9]+))(?:\.([0-9]+))/.exec(window.navigator.userAgent);
                C = !!a && 603 > parseInt(a[1], 10) } else C = !1;
        return C }

    function J() { null === F && (F = !!document.fonts); return F }

    function K() { if (null === E) { var a = document.createElement("div"); try { a.style.font = "condensed 100px sans-serif" } catch (b) {}
            E = "" !== a.style.font } return E }

    function L(a, b) { return [a.style, a.weight, K() ? a.stretch : "", "100px", b].join(" ") }
    A.prototype.load = function(a, b) {
        var c = this,
            k = a || "BESbswy",
            q = 0,
            D = b || 3E3,
            H = (new Date).getTime();
        return new Promise(function(a, b) {
            if (J() && !G()) { var M = new Promise(function(a, b) {
                        function e() {
                            (new Date).getTime() - H >= D ? b() : document.fonts.load(L(c, '"' + c.family + '"'), k).then(function(c) { 1 <= c.length ? a() : setTimeout(e, 25) }, function() { b() }) }
                        e() }),
                    N = new Promise(function(a, c) { q = setTimeout(c, D) });
                Promise.race([N, M]).then(function() { clearTimeout(q);
                    a(c) }, function() { b(c) }) } else m(function() {
                function u() {
                    var b;
                    if (b = -1 !=
                        f && -1 != g || -1 != f && -1 != h || -1 != g && -1 != h)(b = f != g && f != h && g != h) || (null === B && (b = /AppleWebKit\/([0-9]+)(?:\.([0-9]+))/.exec(window.navigator.userAgent), B = !!b && (536 > parseInt(b[1], 10) || 536 === parseInt(b[1], 10) && 11 >= parseInt(b[2], 10))), b = B && (f == v && g == v && h == v || f == w && g == w && h == w || f == x && g == x && h == x)), b = !b;
                    b && (d.parentNode && d.parentNode.removeChild(d), clearTimeout(q), a(c))
                }

                function I() {
                    if ((new Date).getTime() - H >= D) d.parentNode && d.parentNode.removeChild(d), b(c);
                    else {
                        var a = document.hidden;
                        if (!0 === a || void 0 === a) f = e.a.offsetWidth,
                            g = n.a.offsetWidth, h = p.a.offsetWidth, u();
                        q = setTimeout(I, 50)
                    }
                }
                var e = new r(k),
                    n = new r(k),
                    p = new r(k),
                    f = -1,
                    g = -1,
                    h = -1,
                    v = -1,
                    w = -1,
                    x = -1,
                    d = document.createElement("div");
                d.dir = "ltr";
                t(e, L(c, "sans-serif"));
                t(n, L(c, "serif"));
                t(p, L(c, "monospace"));
                d.appendChild(e.a);
                d.appendChild(n.a);
                d.appendChild(p.a);
                document.body.appendChild(d);
                v = e.a.offsetWidth;
                w = n.a.offsetWidth;
                x = p.a.offsetWidth;
                I();
                z(e, function(a) { f = a;
                    u() });
                t(e, L(c, '"' + c.family + '",sans-serif'));
                z(n, function(a) { g = a;
                    u() });
                t(n, L(c, '"' + c.family + '",serif'));
                z(p, function(a) { h = a;
                    u() });
                t(p, L(c, '"' + c.family + '",monospace'))
            })
        })
    };
    "object" === typeof module ? module.exports = A : (window.FontFaceObserver = A, window.FontFaceObserver.prototype.load = A.prototype.load);
}());

/*
 *  2014.12.02  zt
 *  kia common.js
 */

if(window.console == undefined){console={log:function(){}};}
var MOBILE_WIDTH = 767, TABLET_WIDTH =1024, GNB_VISIBLE_HEIGHT = 830, IE_VER = msieversion();

$(document).ready(function() {
	//checkbox
   if($(".check_box").length){
		checkBoxInit();
   }
   //radiobutton
   if($(".radio_box").length){
		radioBoxInit();
   }

   //searchButton
   if($(".sch_open").length){
		searchButtonInit();
   }

   //accordion
   if($(".accordion").length){
		accordionInit();
   }

   //tab_type2
   if($(".tab_type2").length){
	   tabtype2Init();
   }

   //tab_type3
   if($(".tab_type3").length){
	   tabtype3Init();
   }

   // icon image Tab  2026.01.09
   if($(".cpnt__iconTab").length){
	   tabIconImageInit();
   }

	//faq,notice
   if($(".bbs_type1").length){
		//#44078
		//bbsType1Init();
   }

   //탭 클릭시 컨텐츠 변경
   if($('.tab_head').length) {
	   tabHeadInit();
   }

   //layerPopup
   if($(".popup_wrap").length){
		layerPopupInit();
   }
   if($(".set_location").length){
		setLocationPopupInit();
   }

   // 2024.10.24 #67325 disclaimer popup
   if($(".disclaimer__pop").length){
		disclaimerPopOpen();
   }


   //news filter
   if($(".offersFilter .filter_wrap").length || $(".bbs_news .filter_wrap").length || $(".bbs_promotion .filter_wrap").length){
	   filterInit();
   }

   //calendar
   if($('a.spr_calendar').length){
	   calendarInit();
   }

   if($('div.tableWrap').length){
		var twoTable;
		$('.tableWrap').each(function (i) {
			twoTable = new KIATwoTable($(this), {});
			twoTable.init();
		});

		//초기화 방법 : $(KIATwoTable 1번째 인자로 넣은 타깃).getInstance().reset();
		//ex) $('.tableWrap').eq(0).getInstance().reset();
   }

	//뉴스, 프로모션, 리스트에서 제목 2줄 말줄임표
	if ($('.bbs_type2').length) {
		$(".bbs_tit").dotdotdot({
			ellipsis : '...',
			wrap  : 'letter',
			watch : "window"
		});
	   window.onload=function(){
			$(".bbs_tit").trigger("update");
	   }
	}
});

function checkBoxInit(){
	$(".check_box").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		var targetFor = $(this).attr("for");
		var targetInput = $("input:checkbox[id="+targetFor+"]");
		if($(this).hasClass("c_on")){
			$(this).removeClass("c_on");
			 targetInput.attr("checked", false);
		}else{
			$(this).addClass("c_on");
			targetInput.attr("checked", true);
		}

		var advisorListContainer = $(this).closest(".car_list.advisorList");
		if (advisorListContainer.length > 0) advisorListContainer.trigger("advisorListChk.kia", $(this));
	});

	$("input:checkbox").on("click", function(e){
		var targetId = $(this).attr("id");
		var targetName = $(this).attr("name");
		var targetLabel = $("label[for='"+targetId+"']");
		 if(targetLabel.hasClass("c_on")){
			targetLabel.removeClass("c_on");
		}else{
			targetLabel.addClass("c_on");
		}
	});

	 $("input:checkbox").focusin(function(e){
		 var targetId = $(this).attr("id");
		 var targetLabel = $("label[for='"+targetId+"']");
		 targetLabel.addClass("focus");
	});
	$("input:checkbox").focusout(function(e){
		 var targetId = $(this).attr("id");
		 var targetLabel = $("label[for='"+targetId+"']");
		 targetLabel.removeClass("focus");
	});
}

function radioBoxInit(){
	$("input:radio").focusin(function(e){
		var targetId = $(this).attr("id");
		var targetName = $(this).attr("name");
		var targetLabel = $("label[for='"+targetId+"']");
		if($(this).is(':checked')){
			 $("input:radio[name="+targetName+"]").siblings().removeClass("r_on");
			 targetLabel.addClass("r_on");
			 //$(this).attr("title",targetLabel.text()+" 선택");
		}
		targetLabel.addClass("focus");
	});

	$("input:radio").focusout(function(e){
		  var targetId = $(this).attr("id");
		  var targetLabel = $("label[for='"+targetId+"']");
		  //$(this).removeAttr("title");
		  targetLabel.removeClass("focus");
	});


	$("input:radio").on("click", function(e){
		var targetId = $(this).attr("id");
		var targetName = $(this).attr("name");
		var targetLabel = $("label[for='"+targetId+"']");
		$("input:radio[name="+targetName+"]").siblings().removeClass("r_on");
		targetLabel.addClass("r_on");
		targetLabel.removeClass("focus");
	   //$(this).attr("title",targetLabel.text()+" 선택");
	});
}

function searchButtonInit(){
	$(".sch_open").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		$(this).css("display","none");
		$(this).siblings(".sch_round").css("display","block");
		$(this).parent().css("width","100%");
	});
}

function accordionInit(){
	 $(".accordion > a.btnOpen").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();

		if($(this).parent().hasClass("accordion_on")){

			$(this).parent().removeClass("accordion_on");
			$(this).find("span.cmm_spr").text("open");
		}else{
			$(".accordion").removeClass("accordion_on");
			$(".accordion").find("span.cmm_spr").text("open");
			$(this).parent().addClass("accordion_on");
			$(this).find("span.cmm_spr").text("close");
		}
	});

	$("ul.m_table_type2 > li> a.btnTit").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		if($(this).parent().hasClass("on")){
			$(this).parent().removeClass("on");
			$(this).find("span.cmm_spr").text("open");
		}else{
			$(this).parent().addClass("on");
			$(this).find("span.cmm_spr").text("close");
		}
	});

	//kia-flee02
	$(".accordion").on("click", "a.accordionTit", function(e){
		e.stopPropagation();
		e.preventDefault();
		var target = $(this);
		target.toggleClass('on');
		target.closest('li').find('.accordionCont').toggle();
	});
}

function tabtype2Init(){
	$("ul.tab_type2 > li > a.tab_a").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		$(this).parent().parent().find("li > a.tab_a").removeClass("tab_on");
		$(this).addClass("tab_on");
		var idx = $(this).parent().index();
		$(this).parent().parent().siblings().removeClass("tab_open");
		$(this).parent().parent().siblings().eq(idx).addClass("tab_open");
	});
}

 // icon image Tab  2026.01.09
function tabIconImageInit(){
    $('.cpnt__iconTab-box li').click(function() {
        $('.cpnt__iconTab-box li').removeClass('active__on');
        $(this).addClass('active__on');
    });
}


function tabtype3Init(){
	var viewportWidth, lastWindowWidth = 800, lastWindowHeight = 800;
	 $(".tab_type3 ul > li > a").on("click", function(e){
		//e.stopPropagation();
		//e.preventDefault();
		$(".tab_type3 ul > li > a").removeClass("tab_on");
		$(this).addClass("tab_on");
		var str = $(this).text();
		$(".tab_type3 a.input_box > span").text(str);

		if(viewportWidth < MOBILE_WIDTH ){
			if(IE_VER < 9 && IE_VER !== false){

			}else{
				$(".tab_type3 ul").css("display","none");
			}
		}
	});
	 //히든 텍스트 변경 #63229
	$('.tab_type3').closest('.inner').find('h4.hidden').text($(this).html());

	 $(".tab_type3 a.input_box").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		if($(".tab_type3 ul").css("display") == "none"){
			$(".tab_type3 ul").css("display","block");
		}else{
			$(".tab_type3 ul").css("display","none");
		}
	});

	$(window).resize(function() {
		if($(window).height()!=lastWindowHeight || $(window).width()!=lastWindowWidth){
			lastWindowHeight = $(window).height();
			lastWindowWidth = $(window).width();
			tabtype3Resize();
		}
	}).resize();

	function tabtype3Resize(){
		$(".tab_type3 ul").css("display","");
		document.body.style.overflow = "hidden";
		viewportWidth = $(window).width();
		document.body.style.overflow = "";
	}
}

function bbsType1Init(){
	$(".bbs_type1").on("click", "a.bbs_a", function(e){ // 리스트 출력 타이밍 컨테이너에 이벤트 적용
	//$(".bbs_type1 .bbs_li a.bbs_a").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		//var parentLi = $(this).parent().parent().parent().parent();
		var parentLi = $(this).closest('li');
		if(!parentLi.hasClass("bbs_open")){
		  $(".bbs_li").removeClass("bbs_open");
		}
		parentLi.toggleClass( "bbs_open" );
	});

	$(".answer_area a.a_view").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		$(this).parent().parent().addClass( "answer_open" );
	});

	$(".answer_area a.a_close").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		$(this).parent().parent().removeClass( "answer_open" );
	});
};

function layerPopupInit(){
	if($(".pip_wrap").length)return;
	var viewportWidth,viewportHeight, popupMarginLeft = 30 , popupMarginTop = 82;
	var lastWindowHeight = 800;
	var lastWindowWidth = 800;

	$(window).resize(function() {
		if($(window).height()!=lastWindowHeight || $(window).width()!=lastWindowWidth){
			lastWindowHeight = $(window).height();
			lastWindowWidth = $(window).width();
			popupResize();
		}
	}).resize();

	function popupResize(){
		$(".popup_wrap").css({"width":""});
		document.body.style.overflow = "hidden";
		viewportWidth = $(window).width();
		if($(window).height() < $(document).height()){
			viewportHeight = $(document).height();
		}else{
			viewportHeight = $(window).height();
		}
		document.body.style.overflow = "";

		var popWidth = viewportWidth - popupMarginLeft;
		$(".popup_wrap").css({"width":popWidth});
		popupPosSet();
	}

	function popupPosSet(){
		$(".popup_wrap").each(function(i,t){
			var h1 = $(window).height();
			var h2 = $(this).height();
			var w1 = $(window).width();
			var w2 = $(this).width();
			var popleft = w1/2 - w2/2 -popupMarginLeft/2;

			$(this).css( { position:"absolute" , left:popleft } );
		});
	}
}

function setLocationPopupInit(){
	var viewportWidth,viewportHeight, popupMarginLeft = 30 , popupMarginTop = 82;
	var lastWindowHeight = 800;
	var lastWindowWidth = 800;

	$(window).resize(function() {
		if($(window).height()!=lastWindowHeight || $(window).width()!=lastWindowWidth){
			lastWindowHeight = $(window).height();
			lastWindowWidth = $(window).width();
			popupResize();
		}
	}).resize();

	function popupResize(){
		$(".set_location").css({"width":""});
		document.body.style.overflow = "hidden";
		viewportWidth = $(window).width();
		if($(window).height() < $(document).height()){
			viewportHeight = $(document).height();
		}else{
			viewportHeight = $(window).height();
		}
		document.body.style.overflow = "";

		var popWidth = viewportWidth - popupMarginLeft;
		$(".set_location").css({"width":popWidth});
		popupPosSet();
	}

	function popupPosSet(){
		$(".set_location").each(function(i,t){
			var h1 = $(window).height();
			var h2 = $(this).height();
			var w1 = $(window).width();
			var w2 = $(this).width();
			var popleft = w1/2 - w2/2 -popupMarginLeft/2;

			$(this).css( { position:"absolute" , left:popleft } );
		});
	}
}



function tabHeadInit(){
	var viewportWidth, lastWindowWidth = 800, lastWindowHeight = 800;
	 $(".tab_head").on("click", "ul > li", function(e){
		e.stopPropagation();
		e.preventDefault();
		$(this).siblings("li").find("a").removeClass("tab_on");
		$(this).find("a").addClass("tab_on");
		var str = $(this).find("a").text();
		$(this).parent().siblings("a.input_box").find("span").text(str);
		//console.log(str)
		var idx = $(this).index();
		$(".tab_body").removeClass("current");
		$(".tab_body").eq(idx).addClass("current");

		if(viewportWidth < MOBILE_WIDTH ){
			if(IE_VER < 9 && IE_VER !== false){

			}else{
				$(this).parent().css("display","none");
			}
		}
		if($("*:focus").length > 0){
		   $(this).parent().siblings("a.input_box").focus();
		}
	});

	 $(".tab_head").on("click", "a.input_box", function(e){
		e.stopPropagation();
		e.preventDefault();
		if($(this).siblings("ul").css("display") == "none"){
			$(this).siblings("ul").css("display","block");
		}else{
			$(this).siblings("ul").css("display","none");
		}
	});

	$(window).resize(function() {
		if($(window).height()!=lastWindowHeight || $(window).width()!=lastWindowWidth){
			lastWindowHeight = $(window).height();
			lastWindowWidth = $(window).width();
			tabHeadResize();
		}
	}).resize();

	function tabHeadResize(){
		$(".tab_head ul").css("display","");
		document.body.style.overflow = "hidden";
		viewportWidth = $(window).width();
		document.body.style.overflow = "";
	}
};

function filterInit(){
	 var viewportWidth, lastWindowWidth = 800, lastWindowHeight = 800;
	 $(".filter_wrap ul > li > a").on("click", function(e){
		$(".filter_wrap ul > li > a").removeClass("on_r");
		$(this).addClass("on_r");
		var str = $(this).find("span").text();
		$("a.input_box > span").text(str);
		//console.log(str)
		if(viewportWidth <= TABLET_WIDTH ){
			if(IE_VER < 9 && IE_VER !== false){

			}else{
				$(".filter_wrap ul").css("display","none");
			}
		}
	});

	 $(".filter_wrap a.input_box").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		if($(".filter_wrap ul").css("display") == "none"){
			$(".filter_wrap ul").css("display","block");
		}else{
			$(".filter_wrap ul").css("display","none");
		}
	});

	$(window).resize(function() {
		if($(window).height()!=lastWindowHeight || $(window).width()!=lastWindowWidth){
			lastWindowHeight = $(window).height();
			lastWindowWidth = $(window).width();
			filterResize();
		}
	}).resize();

	function filterResize(){
		$(".filter_wrap ul").css("display","");
		document.body.style.overflow = "hidden";
		viewportWidth = $(window).width();
		document.body.style.overflow = "";
	}
}


function calendarInit() {
	var calendarDIV = $('.layer_calendar');
	if (calendarDIV.length > 0) calendarDIV.remove();

	var btn = $('a.spr_calendar');
	var calendar;

	btn.each(function () {
		calendar = new KIACalendar($(this), {});
		calendar.init();
	})

	calendarDIV = $('.layer_calendar');
	calendarDIV.on('select.calendar', function (e, year, month, day) {
		var now = new Date();
		var today = new Date(now.getFullYear(), now.getMonth(), now.getDate()+6); //#61073 예약가능일 +6일
		//KWCMSAU-185 monthChar to monthNumber
        var monthNumber = new Date(month + " 1").getMonth() + 1;
        var selectDay = new Date(year,monthNumber-1,day);
		if ( !$(this).siblings('a.spr_calendar').hasClass("prev_date") && selectDay <= today ){
			alert("Please choose a date no earlier than a week from today.");
			return;
		}
		if ( !$(this).siblings('a.spr_calendar').hasClass("next_date") && selectDay > today ){
			alert("You can not choose an after date.");
			return;
		}


		//KWCMSAU-185 calendar 표시 수정 -2025.11.03
        $(this).siblings('input').val(month +' '+  day  +', '+   year);
        $(this).siblings('input').change();
	});
}

/*
 *  @mainslider
 *  var slider = new mainSlider($object, false, false);
 *  slider.moveEnd = function(dragFlag , disX , conX){};
 *
 */
function mainSlider(obj, limit, css) {
	var self = this;
	this.tar = obj;
	this.limitlast = limit;
	this.usecss3 = css;
	this.init();
}

mainSlider.prototype = {
	init : function() {
		var self = this, sx, sy, conX, disX,disY, interval, dragFlag, scrollLock,firstCheck;
		if(self.usecss3){
			self.tar.css({"-webkit-transform" : "matrix(1,0,0,1,0,0)"});
		}
		self.tar.bind("touchstart", touchstart);
		//self.tar.bind("mousedown", mousestart);

		function mousestart(e) {
			e.stopPropagation();
			clearTimeout(interval);
			setTimeout(setTimer, 200);
			sx = e.pageX;
			sy = e.pageY;
			if(self.usecss3){
				var wx = matrixToArray(self.tar.css("-webkit-transform"))[4];
			}else{
				var wx =  self.tar.css("left");
			}

			conX = parseInt(wx);
			disX = 0;
			dragFlag = false;
			scrollLock = true;
			firstCheck = true;

			self.tar.bind("mousemove", mousemove).bind("mouseup", mouseend);
		}

		function mousemove(e) {
			e.stopPropagation();
			disX = sx - e.pageX;
			disY = sy - e.pageY;

			if (firstCheck) {
				if (Math.abs(disX) > Math.abs(disY)) {
					scrollLock = false;
				}
			}

			firstCheck = false;
			var scl = self.scrollLock;
			if (scl) {
				scrollLock = true;
			}

			if (!scrollLock) {
				e.preventDefault();
				 if(self.usecss3){
					var wx = matrixToArray(self.tar.css("-webkit-transform"))[4];
					if (self.limitlast) {
						if (targetX > 0) {
							self.tar.css("-webkit-transform", "matrix(1, 0, 0, 1, 0, 0)");
							return;
						} else if (targetX < -self.tar.width()) {
							self.tar.css("-webkit-transform", "matrix(1, 0, 0, 1, " + (-self.tar.width()) + ", 0)");
							return;
						}
					}
					 var targetX = conX - disX;
					 TweenMax.to(self.tar, 0, {x : targetX});
				}else{
					var wx =  self.tar.css("left");
					var targetX = conX - disX;
					TweenMax.to(self.tar, 0, {left : targetX});
				}
			} else {
				self.tar.unbind("mousemove", mousemove).unbind("mouseup", mouseend);
			}
		}

		function mouseend(e) {
			self.tar.unbind("mousemove", mousemove).unbind("mouseup", mouseend);
			e.stopPropagation();
			clearTimeout(interval);
			if (!scrollLock) {
				self.moveEnd(dragFlag, disX, conX);
			}
		}

		function touchstart(e) {
			e.stopPropagation();
			clearTimeout(interval);
			setTimeout(setTimer, 200);
			sx = e.originalEvent.touches[0].pageX;
			sy = e.originalEvent.touches[0].pageY;

			if(self.usecss3){
				var wx = matrixToArray(self.tar.css("-webkit-transform"))[4];
			}else{
				var wx =  self.tar.css("left");
			}

			conX = parseInt(wx);
			disX = 0;
			dragFlag = false;
			scrollLock = true;
			firstCheck = true;

			self.tar.bind("touchmove", touchmove).bind("touchend", touchend);
		}

		function touchmove(e) {
			e.stopPropagation();
			disX = sx - e.originalEvent.touches[0].pageX;
			disY = sy - e.originalEvent.touches[0].pageY;

			if (firstCheck) {
				if (Math.abs(disX) > Math.abs(disY)) {
					scrollLock = false;
				}
			}

			firstCheck = false;
			var scl = self.scrollLock;
			if (scl) {
				scrollLock = true;
			}

			if (!scrollLock) {
				e.preventDefault();
				 if(self.usecss3){
					var wx = matrixToArray(self.tar.css("-webkit-transform"))[4];
					if (self.limitlast) {
						if (targetX > 0) {
							self.tar.css("-webkit-transform", "matrix(1, 0, 0, 1, 0, 0)");
							return;
						} else if (targetX < -self.tar.width()) {
							self.tar.css("-webkit-transform", "matrix(1, 0, 0, 1, " + (-self.tar.width()) + ", 0)");
							return;
						}
					}
					 var targetX = conX - disX;
					 TweenMax.to(self.tar, 0, {x : targetX});
				}else{
					var wx =  self.tar.css("left");
					var targetX = conX - disX;
					TweenMax.to(self.tar, 0, {left : targetX});
				}
			} else {
				self.tar.unbind("touchmove", touchmove).unbind("touchend", touchend);
			}
		}

		function touchend(e) {
			self.tar.unbind("touchmove", touchmove).unbind("touchend", touchend);
			e.stopPropagation();
			clearTimeout(interval);
			if (!scrollLock) {
				self.moveEnd(dragFlag, disX, conX);
			}
		}

		function setTimer() {
			dragFlag = true;
		}

		function matrixToArray(str) {
			return str.match(/(-?[0-9\.]+)/g);
		}
	},

	destory : function() {
		var self = this;
		self.tar.off();
		self =null;
		delete self;
	},

	moveEnd : function(dragFlag , disX , conX) {
		this.moveEnd(dragFlag, disX, conX);
	},

	scrollLockFlag : function(dragFlag) {
		this.scrollLock = dragFlag;
	}
};


/*
 *  @onSwipeFnc
 *  var mainSwipe = new onSwipeFnc(object);
 *  mainSwipe.moveEnd = function(evt, dir, phase, swipetype, distance){};
 *
 */
function onSwipeFnc(el){
	this.el = el;
	this.init();
}

/* // GRO5 modify */
onSwipeFnc.prototype = {
	init : function() {
		var  self = this, touchsurface = $(self.el), dir, swipeType, startX, startY, distX, distY, threshold = 150, restraint = 100, allowedTime = 500, elapsedTime, startTime,
		handletouch = self.callback ||function(evt, dir, phase, swipetype, distance) {};
		var touched = false;
		touchsurface.on('touchstart', touchStart);


		function touchStart(e) {
			var touchobj = e.originalEvent.changedTouches[0];
			dir = 'none';
			swipeType = 'none';
			dist = 0;
			startX = touchobj.pageX;
			startY = touchobj.pageY;
			startTime = new Date().getTime();
			touchsurface.on('touchmove', touchMove);
			touchsurface.on('touchend', touchEnd);
		}

		function touchMove(e) {
			var touchobj = e.originalEvent.changedTouches[0];
			distX = touchobj.pageX - startX;
			distY = touchobj.pageY - startY;
			if (!touched){
				if (Math.abs(distX) > Math.abs(distY)) {
					touched = true;
					dir = (distX < 0) ? 'left' : 'right';
					e.preventDefault();
				}else{
					self.moveEnd(e, dir, 'end', swipeType, (dir == 'left' || dir == 'right') ? distX : distY);
					touchsurface.off('touchmove', touchMove);
					touchsurface.off('touchend', touchEnd);
				}
			}
			self.move(e, dir, (dir == 'left' || dir == 'right') ? distX : distY);
		}

		function touchEnd(e) {
			touched = false;
			var touchobj = e.originalEvent.changedTouches[0];
			elapsedTime = new Date().getTime() - startTime;
			if (elapsedTime <= allowedTime) {
				if (Math.abs(distX) >= threshold && Math.abs(distY) <= restraint) {
					swipeType = dir;
				} else if (Math.abs(distY) >= threshold && Math.abs(distX) <= restraint) {
					swipeType = dir;
				}
			}
			touchsurface.off('touchmove', touchMove);
			touchsurface.off('touchend', touchEnd);
			self.moveEnd(e, dir, 'end', swipeType, (dir == 'left' || dir == 'right') ? distX : distY);
		}
	},

	move : function(evt, dir, distance){
		//this.move(evt, dir, distance);
	},

	moveEnd : function(evt, dir, phase, swipetype, distance){
		this.moveEnd(evt, dir, phase, swipetype, distance);
	}
}
/* GRO5 modify // */


/*
 * @tapIndex focus
 * tapIndexFnc.Init($(".layer_Popup"));
 *
 */
var tapIndexFnc = {
	focusableElementsString : "a[href], area[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), iframe, object, embed, *[tabindex], *[contenteditable]",
	focusedElementBeforeModal : null,
	Init : function(con){
		var self = this;
		var obj = con;
		var o = obj.find('*');
		self.focusedElementBeforeModal = $(':focus');
		obj.keydown(function(event){self.trapTabKey($(obj),event);});
		obj.keydown(function(event){self.trapEscapeKey($(obj),event);});
		con.find(".closeBtn, .wide_close").keydown(function(event){self.trapSpaceKey($(obj),event);});
		o.filter(self.focusableElementsString).filter(':visible').first().focus();
	},

	Close :function(){
		 if(this.focusedElementBeforeModal){
			this.focusedElementBeforeModal.focus();
			this.focusedElementBeforeModal = null;
		}
	},

	trapSpaceKey : function(obj, evt){
		 if ( evt.which == 32 ) {
			evt.preventDefault();
		}
	},

	trapEscapeKey : function(obj, evt){
		 if ( evt.which == 27 ) {
			var o = obj.find('*');
			var cancelElement;
			cancelElement = o.filter(".cancel");
			cancelElement.click();
			evt.preventDefault();
		}
	},

	 trapTabKey : function(obj, evt){
		 if ( evt.which == 9 ) {
			var o = obj.find('*');
			var focusableItems = o.filter(this.focusableElementsString).filter(':visible');
			var focusedItem = $(':focus');
			var numberOfFocusableItems = focusableItems.length;
			var focusedItemIndex = focusableItems.index(focusedItem);
			if (evt.shiftKey) {
				if(focusedItemIndex == 0){
					focusableItems.get(numberOfFocusableItems-1).focus();
					evt.preventDefault();
				}
			} else {
				if(focusedItemIndex == numberOfFocusableItems-1){
					focusableItems.get(0).focus();
					evt.preventDefault();
				}
			}
		}
	}
}

//internet Explorer version check
function msieversion() {
		var ua = window.navigator.userAgent;
		var msie = ua.indexOf("MSIE ");

		if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)){
		   return parseInt(ua.substring(msie + 5, ua.indexOf(".", msie)));
		}
   return false;
}

//ie8 substr error fix
if ('ab'.substr(-1) != 'b') {
   String.prototype.substr = function(substr) {
	 return function(start, length) {
	   if (start < 0) start = this.length + start;
	   return substr.call(this, start, length);
	 }
   }(String.prototype.substr);
 }

//css3 support check
$.support.transition = (function(){
	var thisBody = document.body || document.documentElement,
	thisStyle = thisBody.style,
	support = thisStyle.transition !== undefined || thisStyle.WebkitTransition !== undefined || thisStyle.MozTransition !== undefined || thisStyle.MsTransition !== undefined || thisStyle.OTransition !== undefined;
	return support;
})();

/**
 * dim 팝업
 *
 *  ex)
 *  var dimPop = new OpenDimPop($(".popup_wrap"), $(".popup_wrap .pop_con"), {topValue:41});
 *
 *  dimPop.open(); //팝업 열기
 *  dimPop.close(); //팝업 닫기
 *
 * @param pTarget        ::: 팝업 컨테이너
 * @param hTarget        ::: 팝업 높이를 지정할 타깃 [default: pTarget]
 *
 * options {
 *     topValue : 0,        ::: 팝업이 화면보다 높을때 top 값 [default : 0]
 *     plusHeaderHeight : 0 ::: header 높이 추가값 [default : 0]
 * }
 *
 */
var OpenDimPop = (function ($) {
	var wddoObj = function (pTarget, hTarget, _options) {
		var scope,                          //스코프
			$pTarget = pTarget,             //팝업 타깃
			$hTarget = hTarget || pTarget,  //높이기준 타깃
			opts,                           //옵션
			defaults = defaultOptions();    //기본값

		function defaultOptions() {
			return {
				topValue : 0,
				plusHeaderHeight : 0
			};
		}

		scope = this;

		function init () {
			opts = $.extend(defaults, _options);

			if ($pTarget.length === 0) return;

			$pTarget.data('scope', scope);

			$pTarget.find("a.closeBtn").on("click", function(e){
				e.stopPropagation();
				e.preventDefault();
				close();


				//experience 유투브 영상 재생중 팝업창 닫을때 유투브 정지 03.26추가
				if($pTarget.find(".youtube").length){
					$(".youtube iframe").each(function(i,e){
						var iframe = $(this)[0].contentWindow;
						iframe.postMessage('{"event":"command","func":"pauseVideo","args":""}', 'https://www.youtube.com'); // 2026.06.29 postMessage 보안 * -> https://www.youtube.com
					});
				}

				//experience 유투브 영상 재생중 팝업창 닫을때 유투브 정지 03.26추가
				if($pTarget.find(".video_cont").length){
					var iframe = document.getElementById($pTarget.attr("id")).getElementsByTagName("iframe")[0].contentWindow;
					 iframe.postMessage('{"event":"command","func":"pauseVideo","args":""}', 'https://www.youtube.com'); //2026.06.29 postMessage 보안
				}

			});

			var dim = $pTarget.nextAll('.dimmed:eq(0)');
			dim.on("click", function(e){
				e.stopPropagation();
				e.preventDefault();
				close();
				//experience 유투브 영상 재생중 팝업창 닫을때 유투브 정지 03.26추가
				if($pTarget.find(".youtube").length){
					$(".youtube iframe").each(function(i,e){
						var iframe = $(this)[0].contentWindow;
						iframe.postMessage('{"event":"command","func":"pauseVideo","args":""}', 'https://www.youtube.com'); //2026.06.29 postMessage 보안
					});
				}

				//experience 유투브 영상 재생중 팝업창 닫을때 유투브 정지 03.26추가
				if($pTarget.find(".video_cont").length){
					var iframe = document.getElementById($pTarget.attr("id")).getElementsByTagName("iframe")[0].contentWindow;
					 iframe.postMessage('{"event":"command","func":"pauseVideo","args":""}', 'https://www.youtube.com'); //2026.06.29 postMessage 보안
				}
			});

			close();
		}

		init();

		function open() {
			if ($pTarget.length === 0) return;

			setTimeout(timeFun, 150);

			function timeFun() {
				var top = $(window).scrollTop();
				var h1 = $(window).height();
				var h2, t;
				var headerHeight = $("#header").outerHeight() + opts.plusHeaderHeight; //웹 90, 모바일 41

				//브라우저 높이가 기본높이 GNB_VISIBLE_HEIGHT 보다 낮고, 가로가 모바일크기가 아니면
				if ($(window).width() > TABLET_WIDTH) { headerHeight = 0; }

				//팝업 보이기
				$pTarget.show();

				h2 = $hTarget.outerHeight();

				if($(window).width() > TABLET_WIDTH){ //웹  // wsg tablet header
					t = top + h1/2 - h2/2 + headerHeight / 2;
				}else{ //타블릿 //모바일
					t = top + h1/2 - h2/2 - headerHeight;
				}

				//top 값이 상단으로 먹고 들어가면 topValue 값으로. 기본값 0
				if ( t < opts.topValue ){ t = opts.topValue; }

				//팝업 세로 위치 적용
				$pTarget.css( { position:"absolute" , top:t  } );

				//포커스 이동 
				if($("*:focus").length > 0){
				   tapIndexFnc.Init($pTarget);
				}
                $('.accpop__scrolly').scrollTop(0); // 2026.05.18 a태그 포커스 

				//딤 셋팅
				var dim = $pTarget.nextAll('.dimmed:eq(0)');
				dim.css({"height":""});
				var docH = $(document).height();
				dim.css({"height":docH,"position":"fixed"});
				dim.show();
			}
		}

		function close() {
			if ($pTarget.length === 0) return;

			$pTarget.hide();

			var dim = $('.dimmed').not(".carName + span");

			dim.hide();
			tapIndexFnc.Close();
		}

		//open
		this.open = function () {
			open();
		};

		//close
		this.close = function () {
			close();
		};

	};//end Obj

	return wddoObj;
}(jQuery));

/**
 * calendar :: wddo
 *
 *  // 1번째 인자로 달력을 열때 클릭할 버튼을 넣음
 *  var calendar = new KICalendar($('.btnCal:eq(0)'), {});
 *  calendar.init();
 *
 *  instance.getDate();            //날짜반환, Date 객체 반환
 *  instance.setDate(2014, 2, 12); //날짜지정 2014년 2월 12일 적용
 *  instance.setDisable(boolean);  //비활성화
 *
 * @param _btn          ::: 달력과 연결할 버튼 element
 * @param _options      ::: 옵션
 *
 * options object
 *  only    - 한 페이지에 한 달력이 열릴지 유무
 *  zindex  - 열릴 때 뎁스
 *  inputId - 일 클릭 이벤트에서 전달해줄 아이디
 */
var KIACalendar = (function ($) {
	var wddoObj = function (_btn, _options) {
		var scope,                          //스코프
			$btn = _btn,                    //달력버튼
			$target,                        //컨테이너
			$month,                         //월
			$prve,                          //이전
			$next,                          //다음
			now,                            //현재 날짜
			current,                        //이동 날짜
			monthArr,                       //달
			opts,                           //옵션
			defaults = defaultOptions(),    //기본값;
			zindex;                         //현재 뎁스

		function defaultOptions() {
			return {
				inputId: undefined,         //인풋 아이디
				only: true,                 //한 페이지에 한 달력이 열릴지 유무
				zindex: 840212,             //열릴 때 뎁스
				isDisable: false            //비활성화
			};
		}

		function init () {
			opts = $.extend(defaults, _options);

			current = new Date();
			now = new Date();
			monthArr = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

			createLayout();
			createDate();
			changeMonth();
			changeToday();
			initEvent();

			hide();

			$target.data('scope', scope);
		}

		function initEvent() {
			$btn.on('click', function (e) {
				if (!opts.isDisable) {
					if ($target.filter(':hidden').length > 0) {
						show();
						window.tab.setTarget($(this)[0]);
					} else {
						hide();
					}
				}

				e.preventDefault();
			});

			$next.on('click', function (e) {
				var target = (e.currentTarget);

				current.setMonth(current.getMonth() + 1);

				removeDate();
				createDate();
				changeMonth();
				changeToday();

				e.preventDefault();
			});

			$prve.on('click', function (e) {
				var target = (e.currentTarget);

				current.setMonth(current.getMonth() - 1);

				removeDate();
				createDate();
				changeMonth();
				changeToday();

				e.preventDefault();
			});

			$target.find('a.calbtn_x').on('click', function (e) {
				hide();

				e.preventDefault();
			});

			//일 클릭
			$target.find('tbody').on('click', 'a', function (e) {
				selectDate(current.getFullYear(), current.getMonth(), $(this).text());
				changeToday();
				hide();

				//event binding
				//$target.trigger('select.calendar', [scope.getDate(), opts.inputId]);
                //KWCMSAU-185 calendar 표시 수정 -2025.11.03
                $target.trigger('select.calendar', [current.getFullYear(), monthArr[current.getMonth()], force2Digits(parseInt($(this).text())), opts.inputId, current]);

				var tt = window.tab.getTarget();
				if (tt !== undefined) tt.focus();

				e.preventDefault();
			});
		}

		//달력 외 영역 이벤트
		function addDocumentEvent() {
			$(document).on('mousedown.calendar focusin.calendar touchstart.calendar', function (e) {
				if ($(e.target).closest('.layer_calendar').length ===  0 && $(e.target).get(0) !== $btn.get(0)) {
					//closeAll();
					hide();
				}
			});
		}

		function removeDocumentEvent() {
			$(document).off('mousedown.calendar focusin.calendar touchstart.calendar');
		}

		//날짜 삭제
		function removeDate() {
			var tbody = $target.find('tbody');

			tbody.find('> tr').remove();
		}

		//날짜 생성
		function createDate() {
			var date = new Date(current.getFullYear(), current.getMonth(), 1); //새로운 date 객체
			var tbody = $target.find('tbody');

			//일 빈공간 생성
			var i = 0;
			var max = 42; //최대 줄수 만큼의 일 갯수 (7*6)
			for (; i < max; i += 1)  {
				if ((i % 7) === 0) tbody.append('<tr></tr>');

				tbody.find('tr:last').append('<td></td>');
			}

			//일 채워 넣기
			i = 1;
			max = 41; //최대 일 수

			var targetTR = tbody.find('> tr:eq(0)');
			var idx, td;

            var now = new Date(); 
            var today = new Date(now.getFullYear(), now.getMonth(), now.getDate()+6); //#61073 예약 가능 시작일 가져오기

			for (; i <= max; i += 1) {
				date.setDate(i); //새로운 date 1씩 증가

				if (date.getMonth() === current.getMonth()) { //새로운 date와 비교하여 월이 같으면.. 즉, current 일수 만큼 반복
					idx = date.getDay(); //요일 0(일)~6

					if (date.getDay() === 0 && i !== 1) targetTR = targetTR.next(); //줄 내림

					td = targetTR.find('> td').eq(idx).append('<a href="#"></a>').find('> a').text(i).end(); //날짜 입력

                    if (new Date(date.getFullYear(),date.getMonth(),date.getDate()) <= today ){ //#61073 예약 가능 시작일보다 이전 일자면 remove 클래스 추가
						td.addClass("remove");
                    }

					if (date.getDay() === 0) td.addClass('sun'); //일
					if (date.getDay() === 6) td.addClass('sat'); //토
				}
			}

			//일 채워 넣고 남은 빈tr 삭제
			tbody.find('tr').filter(function () {
				return $(this).text().length === 0;
			}).remove();
		}

		//레이아웃 생성
		function createLayout() {
			$btn.after('<div class="layer_calendar">'
			+ '<div class="sel_month">'
			+ '<button type="button" class="btn"><span class="cmm_spr calbtn_l">month of Previous</span></button>'
			+ '<strong class="this">2014.12</strong>'
			+ '<button type="button" class="btn"><span class="cmm_spr calbtn_r">month of Next</span></button></div>'
			+ '<div class="sel_date"><table><caption>select of calendar</caption><thead><tr>'
			+ '<th scope="col" class="sun">S</th><th scope="col">M</th><th scope="col">T</th><th scope="col">W</th><th scope="col">T</th><th scope="col">F</th><th scope="col" class="sat">S</th>'
			+ '</tr></thead><tbody></tbody></table></div><a href="#" class="cmm_spr calbtn_x">Close</a></div>');

			$target = $btn.siblings('.layer_calendar');
			$month = $target.find('.sel_month > strong');
			$prve = $target.find('.calbtn_l').parent();
			$next = $target.find('.calbtn_r').parent();

			//zindex = $target.css('z-index');
			zindex =  $target.closest('div.layer_calendar').css('z-index');
		}

		//날짜 선택 시
		function selectDate(_year, _month, _date) {
			now.setFullYear(_year);
			now.setMonth(_month);
			now.setDate(_date);
		}

		//오늘 변경
		function changeToday(_date) {
			var tbody = $target.find('tbody');

			if (now.getFullYear() === current.getFullYear() && now.getMonth() === current.getMonth()) {
				tbody.find('> tr').not(':first').find('td').removeClass('today').find('> a').eq(now.getDate() - 1).parent().addClass('today');
			}
		}

		//월 변경
		function changeMonth() {
            //KWCMSAU-185
			$month.text(monthArr[current.getMonth()]  + ', ' + current.getFullYear());
		}

		//보이기
		function show() {
			//if (opts.only) closeAll(); // addDocumentEvent 대체

			$target.show();

			//$target.css('z-index', opts.zindex);
			$target.closest('div.layer_calendar').css('z-index', opts.zindex);

			if (opts.only) addDocumentEvent(); // 마우스 사용자를 위한
		}

		//숨기기
		function hide() {
			$target.hide();

			//$target.css('z-index', zindex);
			$target.closest('div.calendarWrap').css('z-index', zindex);

			if (opts.only) removeDocumentEvent();
		}

		function closeAll() {
			$('.layer_calendar').each(function () {
				$(this).getInstance().setHide();
			});
		}

		//숫자 1자릿수 앞에 0 붙이기
		function force2Digits(value) {
			return (value < 10) ? '0' + value.toString() : value.toString();
		}

		//public
		this.init = function () {
			scope = this;

			if ($btn.length === 0) return;

			init() ;
		};

		this.getDate = function () {
			return now;
			//return now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate();
		};

		this.setDate = function (_year, _month, _date) {
			now.setFullYear(_year);
			now.setMonth(_month - 1);
			now.setDate(_date);

			current.setFullYear(_year);
			current.setMonth(_month - 1);
			current.setDate(_date);

			removeDate();
			createDate();
			changeMonth();
			changeToday();
		};

		this.setHide = function () {
			hide();
		};

		this.setDisable = function (value) {
			opts.isDisable = value;
		};

	};//end Obj

	return wddoObj;
}(jQuery));

if (jQuery.fn.getInstance === undefined) jQuery.fn.getInstance = function () { return this.data('scope'); };

window.tab = {tabTarget: []};

window.tab.getTab = function (keydownEvent) {
	var e = keydownEvent,
		isDown;

	if (e.keyCode === 9) {
		isDown = (e.shiftKey) ? false : true;
	} else {
		isDown = undefined;
	}

	return isDown;
};

window.tab.setTarget = function(target) {
	this.tabTarget.push(target);
};

window.tab.getTarget = function() {
	return this.tabTarget.pop();
};

/**
 * 2단 table :: wddo
 *
 *  // 1번째 인자로 테이블 컨테이너를 넣음
 *  var twoTable = new KIATwoTable($('div.tableWrap'), {});
 *  twoTable.init();    //초기화
 *
 *  instance.resize();  //리사이징
 *  instance.reset();   //데이터변경에 대한 리셋
 *
 * @param _taget        ::: 두 테이블을 감싸고 있는 DIV
 * @param _options      ::: 옵션
 *
 * options object
 *  wViewTotal - 웹크기 일때 몇개 보여질지
 *  tViewTotal - 타블릿 크기 일때 몇개 보여질지
 */
var KIATwoTable = (function ($) {
	var wddoObj = function (_taget, _options) {
		var scope,                          //스코프
			$target = _taget,               //컨테이너
			$leftTABLE,                     //왼쪽 고정 테이블
			$rightTABLE,                    //오른쪽 스크롤 테이블
			colWidth,                       //열의 폭
			colLength,                      //총 열의 갯수
			maxRightTableWidth,             //테이블 전체크기
			viewLength,                     //보이는 열의 갯수
			defaults = defaultOptions(),    //기본값
			len;                            //변경되는 열의 갯수 (갯수가 변겨되면 resize 에서 수정)

		function defaultOptions() {
			return {
				wViewTotal : 2,
				tViewTotal : 2
			};
		}

		function init () {
			opts = $.extend(defaults, _options);

			$leftTABLE = $target.find('table.fixArea'),
			$rightTABLE = $target.find('table.scrollArea'),

			initLayout();
			initEvent();
			//resize(); //window load
			initTitleLayout();

			$target.find(".scrollArea tbody tr:eq(0) td").each(function(){
				var colspan = $(this).attr("colspan");
				var text = "";
				if($(this).find("p").length > 0){
					text = $(this).find("p").text(); //$(this).html(text)
				} else {
					text = $(this).text();
				}
				text = text.replace(/\n/g, "<br>");

				if(colspan !== undefined){
					$(this).replaceWith("<td class='tableTh' colspan='"+colspan+"'><div><span class='hidden'></span>"+text +"</div></td>");
				}else{
					$(this).replaceWith("<td class='tableTh'><div><span class='hidden'></span>"+text +"</div></td>");
				}
/*
				if(colspan !== undefined){
					$(this).replaceWith("<th class='tableTh' colspan='"+colspan+"'><div><span class='hidden'></span>"+text +"</div></th>");
				}else{
					$(this).replaceWith("<th class='tableTh'><div><span class='hidden'></span>"+text +"</div></th>");
				}
*/
			});

			$target.find(".scrollArea tbody tr:not(:eq(0)) td").each(function(){
				if($(this).find("span").length==0){
					$(this).prepend("<span class='hidden'></span>");
				}
			});

			$(".scrollArea").attr("border","0");

			createHint();

			$target.data('scope', scope);
		}

		function initLayout() {
			var leftTR = $leftTABLE.find('tbody tr');
			var rightTR = $rightTABLE.find('tbody tr');
			var trHeightArr = [], tbodyTrHeightArr = [], trMaxHeightArr = [];
			var trHeight;

			if(IE_VER < 9 && IE_VER !== false){
				len = opts.wViewTotal;
			}

			//왼쪽 테이블 초기 데이터
			leftTR.each(function(i,e) {
				$(this).css("height", "");
				trHeight = $(this).height();

				trHeightArr.push(trHeight);

				//오른쪽
				rightTR.eq(i).css("height", "");
				trHeight = rightTR.eq(i).height();
				tbodyTrHeightArr.push(trHeight);
			});

			//두 초기 데이터중 큰값 취합
			trMaxHeightArr = compareArr(trHeightArr, tbodyTrHeightArr)

			//왼쪽 테이블 데이터 적용
			var rowH = 0; //행 병합용 변수
			var maxH;
			leftTR.each(function(i, e) {
				maxH = trMaxHeightArr[i];

				$(this).css("height", maxH);

				//오른쪽
				rightTR.eq(i).css("height", maxH);

				//행 병합
				var currentTxt = $(this).text();
				var next = $(this).next();
				var nextTxt = next.text();

				if (next.length > 0 && currentTxt === nextTxt) {
					rowH += maxH;
					$(this).hide();
				} else {
					$(this).css("height", maxH + rowH);
					rowH = 0;
				}
			});

			//전체테이블 크기 지정
			colLength = rightTR.filter(':last').children().length;  //총 열갯수

			//보이는 열갯수
			viewLength = Math.min(colLength, len);

			//보이는 열갯수 보다 총 열갯수가 적으면
			if (viewLength >= colLength) {
				$rightTABLE.parent().css('overflow-x', 'hidden');
			} else {
				$rightTABLE.parent().css('overflow-x', 'scroll');
			}

			//1개의 열애대한 예외 처리
			colWidth = Math.round(($target.outerWidth() - $leftTABLE.closest('div').outerWidth()) / viewLength);
			if (colLength === 1) {
				maxRightTableWidth = colWidth * viewLength;
			} else {
				maxRightTableWidth = colWidth * colLength;
			}

			$rightTABLE.css('width', maxRightTableWidth);
		}

		//숨김 텍스트 정의
		function createHint() {
			var leftTR = $leftTABLE.find('tbody tr');
			var rightTR = $rightTABLE.find('tbody tr');

			rightTR.find('> td, th[class^="tableTh"]').each(function (i) { //모든 데이터셀 반복
				var target = $(this);

				var hiddenSpan = target.find('span.hidden');
				hiddenSpan.empty();

				var labelIndex = target.closest('tr').index();
				var titleIndex = target.index();
				var leftText = leftTR.eq(labelIndex).text();
				var txt = target.text();

				var titleText = "";

				//데이터들 th가 있는 tr 찾기.. 즉 타이틀 찾기
				var titleTR = target.closest('tbody').find('th').parent();

				titleTR.each(function (i) { // 타이틀 2개.. 0, 1
					if (i < labelIndex) { // 타이틀중 자신보다 상단에 있는 것만
						var colspanAttr = parseInt($(this).find('th').attr('colspan'));
						var colIndex = (!isNaN(colspanAttr)) ? getcol(titleIndex, $(this).find('th')) : titleIndex;  //% 계산에 의한 00, 11 이거나, 가로 인덱스 이거나

						//스크롤 없는 기본 테이블은 contents() 가 div 이므로 한번더 contents() 호출
						var content = ($(this).find('th').eq(colIndex).contents().is('div')) ? $(this).find('th').eq(colIndex).contents().contents() : $(this).find('th').eq(colIndex).contents();

						//colspan이 있는 것과 없는 타이틀을 구분 ? 있다 : 없다
						titleText += (!isNaN(colspanAttr)) ? $(this).find('th').eq(colIndex).find('span.scrollTh').text() + ' ' : content.not('span.hidden').text() + ' ';
					}
				});

				hiddenSpan.text(titleText + leftText);
				//
				//console.log(leftText, titleText, txt, '세로' + labelIndex, '가로' + titleIndex);
			});
		}

		//colspan 으로 합쳐진 감안한 해당 인덱스 찾기
		function getcol(idx, th) {
			var value = 0;
			var colspanAttr = parseInt(th.attr('colspan'));
			th.each(function (i) {
				if (idx < colspanAttr) {
					return false;
				} else {
					value ++;
					return false;
				}
			})

			return value;
		}

		//이벤트
		function initEvent() {
			var lastWindowHeight = 800, lastWindowWidth = 800;
			$(window).on('resize.twotable', function() {
				if ($(window).height() !== lastWindowHeight || $(window).width() !== lastWindowWidth) {
					lastWindowHeight = $(window).height();
					lastWindowWidth = $(window).width();
					resize();
				}
			});

			//스크롤에 영향을 받는 타이틀에만 이벤트 적용
			if ($rightTABLE.find('tbody tr').filter(':first').children().length === 1) {
				$rightTABLE.parent().on('scroll.twotable', function () {
					initTitleLayout();
				});
			}

			//
			$(window).load(function () {
				if(IE_VER < 9 && IE_VER !== false){
					initLayout();
				}else{
					resize();
				}
			});
		}

		//colspan 제목 중앙정렬
		function initTitleLayout() {
			var scrollTh = $target.find('.scrollTh');

			//테이블안에 두개 이상..
			scrollTh.each(function () {
				var t = $(this);
				var th = t.closest('th');
				var paddingLeft = parseInt(th.css('paddingLeft'));

				//스크롤에 영향을 받는 타이틀
				if ($rightTABLE.find('tbody tr').filter(':first').children().length === 1) { //영형 받음
					t.css({
						top : (t.parent().outerHeight() / 2) - (t.height() * 0.5),
						left : (colWidth * viewLength / 2) - (t.width() * 0.5) + ($rightTABLE.parent().scrollLeft() * 1)// - paddingLeft
					});
				} else { //안받음
					t.css({
						top : (t.parent().outerHeight() / 2) - (t.height() * 0.5),
						left : (th.outerWidth() / 2) - (t.width() * 0.5)// - paddingLeft
					});
				}
			});
		}

		//리사이징
		function resize() {
			document.body.style.overflow = "hidden";
			var viewportWidth = $(window).width();
			document.body.style.overflow = "";

			if(IE_VER < 9 && IE_VER !== false){

			}else{
				//테블릿
				if (viewportWidth <= 1024) {
					len = opts.tViewTotal;

					if (colLength === 1) {
						maxRightTableWidth = $target.width() - $leftTABLE.closest('div').width();
					} else {
						//$rightTABLE.find('tbody tr').children().css('width', colWidth);
						maxRightTableWidth = colWidth * colLength;
					}

					$rightTABLE.css('width', maxRightTableWidth);
				} else {
					len = opts.wViewTotal;
				}

				initLayout();
				initTitleLayout();

				//텍스트 줄내림의 딜레이에 의한 라인 어그러짐 방지
				stopTimer();
				startTimer();
			}

			//colspan 들어간 셀 제목 중앙정렬 padding 때문에 틀어져서 좌우 0처리
			$rightTABLE.find('th[colspan]').css({
				'paddingLeft' : 0,
				'paddingRight' : 0
			});
		}

		//텍스트 줄내림의 딜레의에 의한 라인 어그러짐 방지 타이머 함수
		var timeId;
		function startTimer() {
			timeId = setTimeout(function () {
				initLayout();

				timeId = undefined;
			}, 300);
		}

		function stopTimer() {
			if (timeId !== undefined) {
				clearTimeout(timeId);
				timeId = undefined;
			}
		}

		//배열 비교 함수
		function compareArr(arr1,arr2){
			var maxArr = [];
			for(var i = 0; i < arr1.length; i++){
				if(arr1[i] == 0){
					maxArr.push(0);
				}else{
					maxArr.push(Math.max(arr1[i],arr2[i]));
				}
			}
			return maxArr;
		}

		//public
		this.init = function () {
			scope = this;

			if ($target.length === 0) return;

			init() ;
			resize();
		};

		//resize
		this.resize = function () {
			resize();
		}

		//reset
		this.reset = function () {
			//console.log('reset');
			initLayout();
			initTitleLayout();
			resize();
		}

	};//end Obj

	return wddoObj;
}(jQuery));

function getCookie(cname){
	var name = cname + "=";
	var ca = document.cookie.split(";");
	
	for(var i = 0; i < ca.length ; i++){
		var c = ca[i];
		while(c.charAt(0) == " "){
			c = c.substring(1);
		}
		if(c.indexOf(name) == 0){
			return c.substring(name.length, c.length);
		}
	}
	return "";
}

// 2019.11.08 top 버튼 하단 스크롤 숨김 features test drive S
$(window).scroll(function(){

    if( $('#footer').length > 0 ) {
        var distanceTop = $('#footer').offset().top - $(window).height();
        if  ($(window).scrollTop() >= distanceTop){
            $(".btn_box").addClass("change");
        }
        else{
            $(".btn_box").removeClass("change");
        };
    }


});
// 2019.11.08 top 버튼 하단 스크롤 숨김 E

// new wsg footer acc button on s #50692

$(document).ready(function(){
    $(window).resize(function() {
        if($(window).width() <= 767) {
            $('#footer .f_navi .inner [class*=item] > div').addClass('mo_title');   
            $('#footer .f_navi .inner [class*=item]').removeClass('on'); 
        } else {
            $('#footer .f_navi .inner [class*=item] > div').removeClass('mo_title');
            $('#footer .f_navi .inner [class*=item]').removeClass('on');  
        }
    });

    //KWCMSAU-200 스크립트 수정
    $('.mo_title').each(function () {
        if ($(this).siblings('ul').length) {
            $(this).click(function () {
                var thisCki = $(this).parent().hasClass('on');
                if (thisCki) {
                    $(this).parent().toggleClass('on');
                } else {
                    $('#footer .f_navi .inner [class*=item]').removeClass('on');
                    $(this).parent().addClass('on');
                    // $(this).parent('.acc_title').next('.acc_contents').slideDown();
                }
                return false;
            })
        } else {
            $(this).addClass('no_item');
        }
    });

});
// new wsg footer acc button on e #50692






// 2021.02.08
/*
$(function() {
	$(".fe_inex_wrap[data-uniqueid^='exterior-'").each(function() {

        $(this).find(".exterior_wrap .play_button_box a").on('click', function(e) {
            vid_play_pause(this);
        });
    });
    
    var vid_play_pause = function(obj) {

        var myVideo = $(obj).closest('.exterior_wrap').find('video')[0];
        console.log(myVideo);
        if (myVideo.paused) { 
            myVideo.play(); 
            $(obj).closest('.play_button_box').hide();
        } else { 
            myVideo.pause(); 
        } 
    }
});


$(document).ready(function(){

    //kv button slide  slick slide 2020.03.04

    $(".nf_video_slide[data-uniqueid^='video-'").each(function() {

        var rtl = $(this).find('.v_slide').attr('dir');
        console.log(rtl)
console.log("video");
        // slick init
        window.kia.slick.init($(this).find('.v_slide'), rtl);

        // video popup
        $(this).find('.v_slide').find("div .video_item .play_button_box a").on('click', function(e) {
            e.stopPropagation();
            e.preventDefault();

            kia.popup.openVideo( $("#v_open")
                                , $(this).data("src") );
        });
    });
});
*/



function encodeRFC5987ValueChars (str) {
    return encodeURIComponent(str).
        // Note that although RFC3986 reserves "!", RFC5987 does not,
        // so we do not need to escape it
        replace(/['()]/g, escape). // %27 %28 %29
        replace(/\*/g, '%2A');//.
            // The following are not required for percent-encoding per RFC5987, 
            //  so we can allow for a little better readability over the wire: |`^
            //replace(/%(?:7C|60|5E)/g, unescape);
}
function decodeRFC5987ValueChars (str) {
    return decodeURIComponent(str);
}



//  GT media banner componant 적용  2022.10.11 #58447 S

$(document).ready(function(){



    //animation
    
    // Function which adds the 'animated' class to any '.animatable' in view
    var doAnimations = function() {
        
        // Calc current offset and get all animatables
        var offset = $(window).scrollTop() + $(window).height(),
            $animatables = $('.animatable');

        // Unbind scroll handler if we have no animatables
        if ($animatables.length == 0) {
            $(window).off('scroll', doAnimations);
        }

        // Check all animatables and animate them if necessary
        $animatables.each(function(i) {
            var $animatable = $(this);
            if (($animatable.offset().top  + 100 ) < offset) {
                $animatable.removeClass('animatable').addClass('animated');

            }
        });
        
    };
    // Hook doAnimations on scroll, and trigger a scroll
    $(window).on('scroll', doAnimations);
    $(window).trigger('scroll');


	 // 동영상

        var $comp = $(".gallery_img, .pop_con, .v_area"); 

    /* 사용 x
        var youtubePlay = function() {
          var iframeSrc = $(this).closest('.img-wrap').data('src');
		  console.log(iframeSrc);
          $(this).closest('.img-wrap').next('iframe').attr('src', iframeSrc + '?autoplay=1');
          $(this).closest('.img-wrap').addClass('video-play');
        };
	*/
        var videoPlay = function() {

            console.log($(this).closest('.img-wrap').next("#myVideo").length);

            $(this).closest('.img-wrap').addClass('video-play'); //video랑 youtube 동일한게 사용

            //20190624 youtube / video 분기처리 
            if( $(this).closest('.img-wrap').next("#myVideo").length < 1 ) {
				var iframeSrc = $(this).closest('.img-wrap').data('link-src') || $(this).closest('.img-wrap').data('src');
				$(this).closest('.img-wrap').next('iframe').attr('src', iframeSrc + '?autoplay=1');
            } else {
            	$(this).closest('.img-wrap').next("#myVideo").get(0).play();
            }
        };


        $(document).ready(function() {
          $comp.find('.btn-play').each(function() {
            //$(this).on('click', youtubePlay); // 마지막 videoPlay만 먹어서 변경 20190624
            $(this).on('click', videoPlay);
          });

            $comp.find("#myVideo").on("ended", function() {
                $(this).parents().find('.img-wrap').removeClass('video-play');
                $(this).get(0).pause();
            });
        });


	// 2024.10.24 #67325 S

    // disclaimer popup open
    $(".img_content_box .disclaimer__pop").find('.disclaimer__popupbtn').on("click", function(e){ 
        e.stopPropagation();
        e.preventDefault();
        
        $(this).next(".disclaimer__pop-box").show();

    });
	// disclaimer popup close
    $(".img_content_box .disclaimer__pop").find('.disclaimer__pop-close').on("click", function(e){ 
        e.stopPropagation();
        e.preventDefault();

        $(this).parents(".disclaimer__pop").find(".disclaimer__pop-box").hide();

    });


   // 2024.10.24 #67325 E






});

//  GT media banner componant 적용  2022.10.11 #58447 E


// 2024.10.25 #67325 paerformance 컴포넌트 disclaimer popup S

function disclaimerPopOpen() {
    $(".nf_tab_com[data-uniqueid^='paerformance-'").each(function() {
        var $AREAPOP = $(this);

        $AREAPOP.find('.disclaimer__popupbtn').on("click", function(e){
            //var tab_id = $(this).attr('data-tab');
            e.stopPropagation();
            e.preventDefault();
            $(this).parents('.nf_tab_com').find(".disclaimer__pop-box").show(),

			$(this).parents('.nf_tab_com').find(".disclaimer__pop-box").show(),
            $(this).parents('.nf_tab_com').find(".disclaimer__pop-box .disclaimer__pop-content").remove(),
            $AREAPOP.find(".disclaimer__pop-box").append("<div class='disclaimer__pop-content'><div class='disclaimer__pop-title'><span>Disclaimers</span></div><div class='disclaimer__pop-text'>" + $(this).data("contents") + "</div><div class='disclaimer__pop-close'><button type='button'><span>close</span></button></div>")
            disclaimerPopClose();            
            
        });
    });

}

function disclaimerPopClose(){
	$('.disclaimer__pop-close').on("click", function(e){ 
        e.stopPropagation();
        e.preventDefault();

        $(".disclaimer__pop-box").hide();

     });
}
// 2024.10.25 #67325 paerformance 컴포넌트 disclaimer popup e




// 2025.03.18 KWCMSAU-32
$(document).ready(function() {


    $(window).resize(function() {
        shsbtnShow()
    });
    var shsbtnShow = function() {
        if ($(window).scrollTop() > $("#header").outerHeight(true)) {
            $(".btn_box").css({
                display: "block"
            })
        } else {
            $(".btn_box").css({
                display: "none"
            })
        }
        
    };
    
    $(window).scroll(function(){
        shsbtnShow();
    }).scroll();
    
    $('.btn_box.top .topBtn').on('click',function(){
        $('html, body').animate({scrollTop : 0}, 400);
        return false;
    });


    // PIP CTA 버튼 존재 여부에 따른 top버튼 위치 2026.08.10
    if ($('.test_drive ').find('a').length > 0) {
        $(".picanto_16my").addClass('pip_cta');
    } else {
        $(".picanto_16my").removeClass('pip_cta');
    }

});
/*
	@filename	: function.js
    @filedesc	: javascript function(s)
	@date		: 2014.10.06
	@author		: Jinwoo.Yuk
*/
function fnDoSubmit(strURL, arrData, strTarget, strMethod) {
	var objTime = new Date();
	var strFormID = "frm" + objTime.getTime();

    var iFrameEL = $("<iframe src='' name='" + strTarget + "' style='width:0px;hegiht:0px;display:none;'>");
    if ($("iframe[name='" + strTarget + "']").length == 0) {
		iFrameEL.appendTo("body");
    }

	var formEL = $("<form />").attr("id", strFormID).attr("name", strFormID).attr("action", strURL);

	if(!strMethod) {
		strMethod = "post";
	}
	formEL.attr("method", strMethod);

	if(strTarget) {
		formEL.attr("target", strTarget);
	}

	for(index in arrData) {
		var strType = arrData[index].type;
		if(!strType) {
			strType = "hidden";
		}
		var strName = arrData[index].name;
		var strValue = arrData[index].value;
		$("<input />").attr("type", strType).attr("name", strName).val(strValue).appendTo(formEL);
	}
	formEL.appendTo("body");
	formEL.submit();
}
/**
 * @name	Popup
 * @desc	open popup
 * @author	Jinwoo.Yuk
 * @version	2013.04.23
*/
var Popup = function () {
	this.open = function (opt) {
		var def = {
			target: "_blank",
			href: null,
			width: screen.width / 2,
			height: screen.height / 2,
			titlebar: "no",
			status: "no",
			resizable: "no",
			toolbar: "no",
			scrollbars: "no",
			menubar: "no"
		};
		var options = $.extend(def, opt);
		var posY = (parseInt(screen.height / 2)) - (parseInt(options.height / 2));
		var posX = (parseInt(screen.width / 2)) - (parseInt(options.width / 2));
		var win = window.open(options.href, options.target, 'titlebar=' + options.titlebar + ', screenX=' + posX + ', screenY=' + posY + ', left=' + posX + ', top=' + posY + ', status=' + options.status + ', resizable=' + options.resizable + ', toolbar=' + options.toolbar + ', scrollbars=' + options.scrollbars + ', menubar=' + options.menubar + ', width=' + options.width + ', height=' + options.height);
		win.focus();
		return false;
	};
};

/**
 * @name     getUrlVars
 * @desc     get Parameter
 * @author   Jinwoo.Yuk
 * @version  2013.06.03
 * @use
    var allVars = $.getUrlVars();
    var byName = $.getUrlVar('name');
*/
$.extend({
    getUrlVars: function () {
        var vars = [], hash;
        var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
        for (var i = 0; i < hashes.length; i++) {
            hash = hashes[i].split('=');
            vars.push(hash[0]);
            vars[hash[0]] = hash[1];
        }
        return vars;
    },
    getUrlVar: function (name) {
        return $.getUrlVars()[name];
    }
});

/**
 * @name	move page
 * @desc	move page
 * @author	Jinwoo.Yuk
 * @version	2014.10.08
*/
function movePage(msg, page) {
    msg = (msg != "" && typeof(msg) == "string" && msg != undefined) ? msg : "";
    page = (page != undefined) ? page : "/";

    if (msg != "") {
        alert(msg);
    }
    document.location.href = page;
}


/**
 * @name	getCustomDate
 * @desc	get old date from now
 * @author	Jinwoo.Yuk
 * @version	2014.10.08
 * @use : type - 'd':day /'m':month /'y':year (toLowerCase('y') - char(1))
 *        gap - gap integer
 *        sFormat - date format (variable(s) :YYYY(year), MM(month), DD(day))
 *        isFirst - return first day
*/
function getCustomDate(type, gap, sFormat, isFirst) {
	var sDate = null;
	var toDay = new Date();
	var nDate = new Date(toDay);
	var strDateType = "YYYYMMDD";

	if (sFormat != undefined)
	{
		strDateType = sFormat;
	}

	switch (type) {
		case "d": //day
			nDate.setDate(nDate.getDate() - gap);
			break;
		case "m": //month
			nDate.setMonth(nDate.getMonth() - gap);
			break;
		case "y": //year
			nDate.setFullYear(nDate.getFullYear() - gap);
			break;
	}
	sDate = new Date(nDate);

	var strMonth = sDate.getMonth() + 1;
	strMonth = (strMonth < 10) ? ("0" + strMonth) : strMonth;

	var strDate = sDate.getDate();
	if (isFirst) {
		strDate = "01";
	} else {
		strDate = (strDate < 10) ? ("0" + strDate) : strDate;
	}

	strDateType = strDateType.replace("YYYY", sDate.getFullYear());
	strDateType = strDateType.replace("MM", strMonth);
	strDateType = strDateType.replace("DD", strDate);

	return strDateType;
}

/**
 * @name	numberFormat
 * @desc	1000 to 1,000
 * @author	Jinwoo.Yuk
 * @version	2014.10.08
*/
function numberFormat (val) {
    return val.split(/(?=(?:\d{3}){1,7}(?:\.|$))/g).join(',')
}


/**
 * @name	makeOption
 * @desc	make <option> element
 * @author	Jinwoo.Yuk
 * @version	2014.10.18
 * @use : makeOption(obj, type, rType, selVal, aList) 
 		obj : target <select> name
 		type : email
        rType : true (<option> auto parsing) / false (<option> return)
        selVal : selected value
        aList : option data array ex) [ [value, text], [value, text] ,...]
 */
var makeOptionList = {
    "email" : [
          ["", "Directly"]
        , ["naver.com", "Naver.com"]
        , ["hanmail.net", "Hanmail.net"]
        , ["nate.com", "Nate.com"]
        , ["gmail.com", "Gmail.com"]
        , ["hotmail.com", "Hotmail.com"]
        , ["outlook.com", "Outlook.com"]
        , ["bizhard.com", "Bizhard.com"]
    ]
};

function makeOption(obj, type, rType, selVal, aList) {
	var list = "";
    var option = "";

    if (type != "") list = makeOptionList[type];
    if (aList != undefined) list = aList;

    var selected = "";
    for (var i = 0, iCnt = list.length ; i < iCnt ; i++) {
        if (list[i][0] == selVal) selected = " selected";
        else selected = "";

		if (list[i].length > 1) {
			option += "<option value=\"" + list[i][0] + "\"" + selected + ">" + list[i][1] + "</option>";
		} else {
			option += "<option value=\"" + list[i][0] + "\"" + selected + ">" + list[i][0] + "</option>";
		}
    }

    if (rType) {
        $("select[name=" + obj + "]").eq(0).html(option).promise().done(function(){
        	$(".form_select").resetSS();
    	});
    } else {
        return option;
    }
}

/**
 * @name	jsonToserialize
 * @desc	JSON to serialize
 * @author	Jinwoo.Yuk
 * @version	2014.10.18
 * @use     jsonToserialize(json, '|', 'v')
*/
function jsonToserialize(oJson, cGubun, type) {
	var sSerial = "";
    $.each(oJson, function(k, v) {
        switch(type) {
            case "k": //key
				sSerial += (k + cGubun);
                break;
            case "v": //value
				sSerial += (v + cGubun);
                break;
            case "kv": //key=value
				sSerial += ((k + "=" + v) + cGubun);
                break;                
        }
    });
    return sSerial.substr(0, (sSerial.length - 1));
}

/**
 * @name	compareJson
 * @desc	compare json
 * @author	Jinwoo.Yuk
 * @version	2014.10.20
 * @use     compareJson({}, {});
*/
function compareJson(oriJson, targetJson) {
	var rJson = {};

	$.each(oriJson, function(k, v) {
		if (targetJson[k] != undefined)
		{
			if (oriJson[k] != targetJson[k]) rJson[k] = targetJson[k];
		}
	});

	$.each(targetJson, function(k, v) {
		if (oriJson[k] == undefined) rJson[k] = v; 
	});

	return rJson;
}

/**
 * @name	execJAjax
 * @desc	execute ajax by jquery
 * @author	Jinwoo.Yuk
 * @version	2014.10.20
 * @use		execJAjax(uri, type, datas, callback)
*/
function execJAjax(u, t, d, c, is_async) {
	if(is_async === undefined) {
		is_async = true;
	}
	
    $.ajax({
        type : t
        , data : d
        , url : u
        , async : is_async 
    }).done(function (data, status) {
        if (typeof(c) == "function") {
            c(data, status);
        }
    }); 
}

/**
 * @name	commonCodeLib
 * @desc	get common code in database
 * @use
 * 			commonCodeLib.init("LK01CT");	//master code
 *			var sValue = commonCodeLib.getValue("LK01CT04");	//detail code
 */
var commonCodeLib = {

	/**
	 * @name	comCdMap
	 */
	comCdMap : {},
	comCdList : [],

	/**
	 * @name	init
	 * @desc	Retrieve common code list
	 */
	init : function(majorCode,nCd) {
		//[Step-1] : Retrieve common code list
        execJAjax("/api/"+nCd+"/base/cc01/commonCode.selectCommonCodeList", "GET", {"sc.parentCd" : majorCode, "sc.delYn" : "N"}, function (data) {
			if (data.result == "Success") {
				//[Step-2] : Split by major code
				//sc.parentCd=LK01CT
				commonCodeLib.comCdList = data.dataInfo;

				//[Step-3] : Set to comCdMap variable
				for(var i=0; i< data.dataInfo.length; i++) {
					var comCd = data.dataInfo[i];
					commonCodeLib.comCdMap[comCd.code] = comCd.text;
				}
			}
		}, false);
		
		
	},
	
	/**
	 * @name	getValue
	 */
	getValue : function(code) {
		return this.comCdMap[code];
	}
};

/**
 * @name	fnNullConvert
 * @param	src > original string
 * @param	repalceStr > if string is null, replace this string
 */
function fnNullConvert(src, repalceStr) {
	
	var result = src;
	
	if(typeof(src) == "object") {
		result = {};
		
		for(var key in src) {
			
			if(src[key] == null) {
				if(repalceStr) {
					src[key] = repalceStr;
				} else {
					delete src[key];
				}
			} else if(typeof(src[key]) == "object") {
				src[key] = fnNullConvert(src[key], repalceStr);
				
			}
		}
		result = src;
	}
	
	if(src == null || src == undefined) {
		result = repalceStr;
	}
	
	return result;
}

/**
 * @name	fnMakeQueryParams
 * @param	jsonData
 * @returns	String of querystring
 */
function fnMakeQueryParams(jsonData) {
	var result = "";
	
	if(jsonData) {
		result = $.param(jsonData);
	}
	
	return result;
}

/**
 * @name	QueryStringToJSON
 * @returns
 */
function fnQueryStringToJSON(query) {
	
    var pairs = [];
    if(query) {
    	pairs = query.split('&');
    } 
    /*else {
    	pairs = location.search.slice(1).split('&');
    }*/
    
    var result = {};
    pairs.forEach(function(pair) {
        pair = pair.split('=');
        
        var key = decodeURIComponent(pair[0] || '');
        key = key.replace("[", ".").replace(/\]$/,"").replace(/\]\[/g,"");

        var value = decodeURIComponent(pair[1] || '');
        
        result[key] = value;
    });

    return JSON.parse(JSON.stringify(result));
}

/**
 * Array to String
 * @param arr
 * @param length
 * @param key
 */
function fnArrayToString (arr, length, key) {
	var ret = "";
	
	if (arr.length > 0) {
		for (var i = 0, iCnt = arr.length ; i < length ; i++) {
			ret += arr[i] + key;
		}
		
		ret = ret.substr(0, (ret.length - 1));
	}
	
	return ret;
}
/**
 * Get parameter map from suffix
 * The page ...page.html/a/b/c/d
 * will return Object {a: "b", c: "d"}
 */
function getSuffixMapFromURL(){
	var rt = null;
	var docUrl = document.location.pathname;
	var suffixMap = {};
	var suffix = (docUrl.indexOf(".html/") > -1) ? true : false;

	if(suffix) {
		var suffixArray = docUrl.split(".html/")[1].split("/");
		for(var i=0, iCnt=suffixArray.length; i < iCnt ; i+=2) {
			suffixMap[suffixArray[i]] =  suffixArray[i+1];
		}
		rt = suffixMap;
	}
	return rt;
}

/**
 * String  to formatted Strimg
 * ex) String.format("a{0} g{0} g{1}", "z", "x") 
 * will return String "az gz gx"
 * 
 * @param args...
 */
String.format = function(format) {
	var args = Array.prototype.slice.call(arguments, 1);
	return format.replace(/{(\d+)}/g, function(match, number) { 
		return typeof args[number] != 'undefined' ? args[number] : match;
	});
};

/**
 * @name	onlyNumber / removeChar
 * @desc	control input text only number
 * @author	JSY
 * @version	2015.04.06
 * @Use		<input type="text" onkeydown='return onlyNumber(event)' onkeyup='removeChar(event)' style='ime-mode:disabled;'>
 */
function onlyNumber(event){
    event = event || window.event;
    var keyID = (event.which) ? event.which : event.keyCode;
    if ( (keyID >= 48 && keyID <= 57) || (keyID >= 96 && keyID <= 105) || keyID == 8 || keyID == 9 || keyID == 46 || keyID == 37 || keyID == 39 ) 
        return;
    else
        return false;
}
function removeChar(event) {
    event = event || window.event;
    var keyID = (event.which) ? event.which : event.keyCode;
    if ( keyID == 8 || keyID == 46 || keyID == 37 || keyID == 39 ) 
        return;
    else
        event.target.value = event.target.value.replace(/[^0-9]/g, "");
}
(function($) {
	window.$GT = $.extend(window.$GT || {}, {
		topSearch: function(q, obj) {
			if (!obj) {
				obj = $("#txtTopSearch");
			} else {
				if (typeof(obj) === "string") {
					obj = $("#" + obj);
				} else {
					obj = $(obj);
				}
			}
			if (!q) {
				q = obj.val();
				if (!q || q == "") {
					q = obj.text();
				}
			}
			// FIXME select page by country & language

			var page = "/mx/util/search.html";
            location.href = page + "?" + $.param({
				q: q
			});
		}
	});
})(jQuery);
﻿/*
 *  2014.10.08  zt
 *  kia gnb.js 
 * 
 */

$(document).ready(function() {
   if($("#header").length){
      gnbInit();
   }

   if($(".info_fms").length){
      footerFamilySiteInit();
   }
});

var gnbInit = function(){
    var viewportWidth, isMobile = false, isTablet = false, carTab = 0, lastWindowHeight = 800, lastWindowWidth = 800;
    $(window).resize(function() {
        if($(window).height()!=lastWindowHeight || $(window).width()!=lastWindowWidth){
            lastWindowHeight = $(window).height();
            lastWindowWidth = $(window).width();
            gnbResize();
        }
    }).resize();
    
    $(".dth1_a").on("click", function(e){
        var hasSub = $(this).siblings(".dth2_u").length;
        if(hasSub){
            e.stopPropagation();
            e.preventDefault();
            if($(this).parent().hasClass("dth_on")){
                if(isTablet){   // wsg tablet mobile header 
                    $(".dth1_l").removeClass("dth_on");
                    $("#header").css("position", "relative"); // new wsg 추가 #50692
                    dimOpen();
                }else{
                    $(this).parents().find("#header").removeClass("over"); // new wsg 추가 #50692
                    gnbClose();    
                }
            }else{
                $(".gnb_area").addClass("open");
                $(".dth1_l").removeClass("dth_on");
                $(this).parent().addClass("dth_on");
                $(this).parents().find("#header").addClass("over"); // new wsg 추가 #50692
                dimOpen();
                if($(this).siblings(".dth_pip")){
                    $(".car_tab > a.sort_a").removeClass("sort_on");
                    $(".car_tab > a.sort_a:eq("+carTab+")").addClass("sort_on");
                    carGridSet(carTab);
                }    
            }    
        }
    });
    
    $("a.util_a:eq(0)").on("focus", function(e){
        if($(window).width() > MOBILE_WIDTH || (IE_VER < 9  && IE_VER !== false)){
            gnbClose();
        }
    });
    
    $("a.lg_a").on("focus", function(e){
         gnbClose();
    });
    $(".dth1_a").on("mousedown", function(e){
        $(this).data("mouseDown", true);
    });
    $(".dth1_a").on("mouseup", function(e){
        $(this).removeData("mouseDown");
    });
    
    $(".dth1_a").on("focus", function(e){
         if ($(this).data("mouseDown")){
             return;
         }
        var hasSub = $(this).siblings(".dth2_u").length;
        if(hasSub){
            e.stopPropagation();
            e.preventDefault();
            $(".gnb_area").addClass("open");
            $(".dth1_l").removeClass("dth_on");
            $(this).parent().addClass("dth_on");
            dimOpen();
            if($(this).siblings(".dth_pip")){
                $(".car_tab > a.sort_a").removeClass("sort_on");
                $(".car_tab > a.sort_a:eq("+carTab+")").addClass("sort_on");
                carGridSet(carTab);
            }    
        }
    });
    
    $(".gnb_dimmed").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        $(this).parents().find("#header").removeClass("over"); // new wsg 추가  #50692
        gnbClose();
    });

    $("a.open_gnb").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        if($(".gnb_area").hasClass("open")){
            $(this).parents().find("#header").removeClass("over"); // new wsg 추가 #50692
            gnbClose(); 
        }else{
            $(".gnb_area").addClass("open");
            $(this).parents().find("#header").addClass("over"); // new wsg 추가 #50692
            dimOpen();
        }
    });
    
    //cartab
    $(".car_tab > a.sort_a").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        $(".car_tab > a.sort_a").removeClass("sort_on");
        $(this).addClass("sort_on");
        var idx = $(this).index();
        carGridSet(idx);
    });
    

    $("a.sdth1_a").on("click", function(e){
        $(".sdth1_l").removeClass("sdth_on");
        $(this).parent().addClass("sdth_on");
    });
    
     //snb type1
    $(".snb_tit > a.open_snb").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        if($(this).hasClass("open")){
            $(this).removeClass("open");    
            $(".snb_nav").removeClass("open");
             snbClose();
        }else{
            $(this).addClass("open");    
            $(".snb_nav").addClass("open");
        }
    });
    
    //snb type2
    $(".snb_area > a.open_snb").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        if($(this).hasClass("open")){
            $(this).removeClass("open");    
            $(".snb_nav").removeClass("open");
            snbClose();
        }else{
            $(this).addClass("open");    
            $(".snb_nav").addClass("open");
        }
    });
    
    $(".sales_kit > a.kit").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        if($(this).parent().hasClass("open")){
            $(this).parent().removeClass("open");    
        }else{
            $(this).parent().addClass("open");    
        }
    });

    //new wsg S  2025 gnb search
    /*$("a.sch_act_btn").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
       $(this).hide();
        $(".u_sch_box").show();
    });*/
    // new wsg end

    function dimOpen(){
        var docH; 
        $(".gnb_dimmed").css("height",0);
        if(IE_VER < 9  && IE_VER !== false){
            docH = $(document).height()-112;
        }else{
            if(isMobile){
                docH= $(document).height(); 

            }else{
                docH = $(document).height()-112;
            }    
        }
        
        $(".gnb_dimmed").css("height",docH);
        $(".gnb_dimmed").show(); 
    }

    function gnbClose(){
        $(".dth1_l").removeClass("dth_on");
        $(".gnb_area").removeClass("open");   
        $(".gnb_dimmed").hide();
        //$("#header").css("position", "absolute"); // new wsg 삭제 #50692
    }
    
    function snbDimOpen(){
        $(".snb_dimmed").css("height",0);
        var docH = $(document).height();
        $(".snb_dimmed").css({"height":docH,"top":0});
        $(".snb_dimmed").show(); 
    }
    
              
    function snbClose(){
        $(".snb_area > a.open_snb").removeClass("open");
        $(".snb_tit > a.open_snb").removeClass("open");
        $(".snb_nav").removeClass("open");
        $(".sdth1_l").removeClass("sdth_on");
        $(".snb_dimmed").hide();
    }
    
    function carGridSet(idx){
        //wddo 쇼룸 차량 브라우저 넘어갈 때를 위한
        if ($('#header').outerHeight() + $('.dth_pip').height() > $(window).height()){ //차량박스들이 브라우저 높이를 넘어서면
            $("#header").css("position","absolute");
            $(".snb_wrap").css("position","absolute");
            $(".gnb_dimmed").css("position","fixed");
            dimOpen();
            
            if ($(window).scrollTop() !== 0) $(window).scrollTop(0);
        }
        
        $(".car_grid").removeClass("on");
        $(".car_grid:eq("+idx+")").addClass("on");
        carTab = idx;
        if(viewportWidth <= TABLET_WIDTH){return;}  // wsg tablet mobile header 
        var $carGrid = $(".grid_u:eq("+idx+") li.grid_l .grid_box");
        var delay = 0;
        var carGridLen = $carGrid.length-1;
        TweenMax.killAll();
        $carGrid.each(function(i){
            delay=delay+0.06;
            TweenMax.fromTo($(this), 0.4, {transformPerspective:500, rotationY:180}, {transformPerspective:500, rotationY:0, delay:delay, onComplete:rotateEnd, onCompleteParams:[$(this)]} );
        });
        function rotateEnd(self){
            $(self).css({"transform":""});
        }
    }

    function gnbResize(){
        document.body.style.overflow = "hidden";
        viewportWidth = $(window).width();
        document.body.style.overflow = "";
        
        if(IE_VER < 9 && IE_VER !== false){ 
                $("#header").css("position","fixed");
            	$("#header").removeClass('over');  //wsg tablet mobile header 추가
                $(".gnb_dimmed").css("position","fixed");
                if($(".snb_wrap").length){
                	$(".snb_wrap").css("position","absolute");
                }
                if(viewportWidth < 990){
                    $(".gnb_dimmed").css({"width":990});    
                }else{
                    $(".gnb_dimmed").css({"width":"100%"});
                }
        }else{
            if(viewportWidth > TABLET_WIDTH){
                isMobile  = false;
                isTablet = false;
                if($(".gnb_area").hasClass("open")){
                    gnbClose();
                }
                $("#header").css("position","fixed");
                $("#header").removeClass('over');  //wsg tablet mobile header 추가
                $(".gnb_dimmed").css("position","fixed");
                
            }else if(viewportWidth <= TABLET_WIDTH && viewportWidth > MOBILE_WIDTH){
                isMobile  = false;
                isTablet = true;
                if($(".gnb_area").hasClass("open")){
                    gnbClose();
                }
                $("#header").css("position","absolute");
                $("#header").removeClass('over');  //wsg tablet mobile header 추가
                $(".gnb_dimmed").css("position","fixed");
                $(".gnb_dimmed").css("top","0");
            }else{
                isMobile  = true;
                isTablet = true;
                if($(".gnb_area").hasClass("open")){  //wsg tablet mobile header 추가
                    gnbClose();
                }
                $(".gnb_dimmed").css({"width":"100%"});
                $("#header").css("position","relative");
                $("#header").removeClass('over');  //wsg tablet mobile header 추가
                $(".gnb_dimmed").css("position","fixed");
                $(".gnb_dimmed").css("top","0");
            }
            
            if($(".snb_wrap").length){
                snbPosSet();
                 if(viewportWidth <= TABLET_WIDTH && viewportWidth > MOBILE_WIDTH){
                    snbSwipe();
                 }else{
                     $(".snb_wrap.snb_pip .snb_nav").css({"width":"","margin-left":"","cursor":""});
                     $(".snb_wrap.snb_pip .snb_nav").off();
                 }
            }
        }
    }
    
    if($(".snb_wrap").length){
        //snb_wrap 웹에서 상단고정
        $(window).scroll(function(event) {
            snbPosSet();
       });
    }

    function snbPosSet(){
        var scrTop = $(window).scrollTop();
        if(isMobile){
            if(scrTop > 61){ 
             $(".snb_wrap").css({"position":"fixed","top":3});
             $("#content").css({"padding-top":38});
           }else{
             $(".snb_wrap").css({"position":"relative","top":3});
             $("#content").css({"padding-top":""});
           }
        }else if(isTablet){
            if(scrTop > 85){
             $(".snb_wrap").css({"position":"fixed","top":0});
           }else{
             $(".snb_wrap").css({"position":"relative","top":3}); // wsg tablet mobile header 
           }
            $("#content").css({"padding-top":""});
        }else{
            $(".snb_wrap").css({"position":"absolute","top":116});
            $("#content").css({"padding-top":""});
        }
    }

    
    function snbSwipe() {
        var snbUlWidth = 0, snbLimargin = 28, snbTitleWidth = 185, $snbNav = $(".snb_wrap.snb_pip .snb_nav");
        $(".sdth1_l").each(function() {
            snbUlWidth += $(this).outerWidth() + snbLimargin;
        });
        snbUlWidth -= snbLimargin-snbLimargin;
        
        var marginLimit = viewportWidth - snbTitleWidth - snbUlWidth - snbLimargin;
        var snbWidth = viewportWidth - snbTitleWidth;
        $snbNav.css("width", snbUlWidth);
        if(snbUlWidth < snbWidth){
            $snbNav.css({"width":"","margin-left":"","cursor":""});
            $snbNav.off();
            return;
        }
        $snbNav.css('cursor', "move").off("mousedown touchstart").on("mousedown touchstart", function(e) {
            if(e.pageX){
                var pos_x = parseInt($(this).css("margin-left")) - e.pageX;
            }else{
                var pos_x = parseInt($(this).css("margin-left")) - e.originalEvent.touches[0].pageX;
            }
            $(this).off("mousemove touchmove").on("mousemove touchmove", function(e) {
                e.preventDefault();
                if(e.pageX){
                    var left = e.pageX + pos_x;
                }else{
                    var left = e.originalEvent.touches[0].pageX + pos_x;
                }
                $(this).css({"margin-left" : left});
            }).off("mouseup touchend").on("mouseup touchend", function() {
                var lastMarginleft = parseInt($(this).css("margin-left"));
                if (lastMarginleft < marginLimit) {
                    TweenMax.to($(this), 0.4, {marginLeft : marginLimit, ease : "easeOutExpo"});
                } else if (lastMarginleft > 0) {
                    TweenMax.to($(this), 0.4, {marginLeft : 0, ease : "easeOutExpo"});
                }
                $(this).off("mousemove touchend");
            });
        });
    }
    
    changeH2();
};

//wddo gnb 히든 h2 텍스트 변경
var changeH2 = function () {
    
    var c_tit = setReplace($('div.content_title > h3.con_tit').text().toLowerCase(), ' ', '');
    var choose;
    var gnb = $('.gnb_area');
    var hidden = $('h2.hidden');
    
    //2뎁스에서 찾기
    var t;
    gnb.find('.dth2_a').each(function () {
        t = setReplace($(this).text().toLowerCase(), ' ', '');
        if ( c_tit === t ) {
            choose = $(this);
            return $(this);
        } 
    })

    var oneText = '';

    if (typeof choose !== 'undefined') { //존재하면
        oneText = choose.closest('.dth1_l').find('> a').text();
    } else { //존재하지 않으면
        if ($('.snb_wrap').length > 0) { //쇼룸 네비가 존재하면
            oneText = $('.dth1_l:first').find('> a').text();
        } else {
            oneText = 'Util Menu';
        }
    }
    
    hidden.text(oneText);

    function setReplace(str, oldSubStr, newSubStr) {
        return str.split(oldSubStr).join(newSubStr);
    }
};

//footer family
var footerFamilySiteInit = function(){
    $("a.fms_box").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        if($(".fms_wrp").hasClass("fms_open")){
            $(".fms_wrp").removeClass("fms_open");
        }else{
            $(".fms_wrp").addClass("fms_open");
        }
    });

    $("a.fms_x").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        $(".fms_wrp").removeClass("fms_open");
    });
    
    //다른곳 클릭시 닫힘 스크립트 추가 03.13
    if($("a.fms_box").length){
        $(document).bind('click.fms_box',function(){
           if($(".fms_wrp").hasClass("fms_open")){
                $(".fms_wrp").removeClass("fms_open");
            }
        });
    }
};

// new wsg s #50692

$(document).ready(function(){

    // new wsg header bg s

        var targetOffSet = $('#wrap').offset();
        $(window).scroll(function () {
            var position = $(document).scrollTop();

            if ($('#header').height() <= position) { 
                $('#header').addClass('wover');
            } else {
                $('#header').removeClass('wover');
            }

            if($(window).width() <= 767) {
                $('#header').removeClass('wover');

            } else if($(window).width() <= 1024) {
                $('#header').removeClass('wover');
            }

        });

	// new wsg header bg e

   	// new wsg search s

    	$("a.open_search").on("click", function(e){

			$('#header').addClass('msh_on'); // 2021.02.10 수정
           // $('.acc_filter .search_area').css('display','inline-block');
            $(this).hide();

        });
    	$("a.close_search").on("click", function(e){

			$('#header').removeClass('msh_on'); // 2021.02.10 수정
           // $('.acc_filter .search_area').css('display','inline-block');
            $('a.open_search').show();

        });
    // new wsg search e

});
// new wsg e #50692



// new GNB search owners오류 수정
$(document).ready(function(){

    setBtnResetSearch();
    initSearchGnb();
 	// box toggle
    $("a.sch_act_btn").on("click", function(e){
        //e.stopPropagation();
        e.preventDefault();
        $('.new__util-search').toggleClass('on');
        $('.gnb__sch__dimm').toggleClass('on');
        initSearchGnb();
    });

    // box close
    $(".new__util-search-close button").on("click", function(e){
        //e.stopPropagation();
        e.preventDefault();
        $(this).parents().find('.new__util-search').removeClass('on');
        $('.gnb__sch__dimm').removeClass('on');
        initSearchGnb();
    });

    $(".gnb__sch__dimm").on("click", function(e){
        //e.stopPropagation();
        e.preventDefault();
        $(this).removeClass('on');
        $('.new__util-search').removeClass('on');
        initSearchGnb();
    });

});

// key-up input
const searchInputt = document.querySelectorAll('.cmpnt-src-inputt');
if(searchInputt.length > 0) {
	window.addEventListener("DOMContentLoaded", setBtnReset);
	window.addEventListener("DOMContentLoaded", initSearch);
}

function setBtnResetSearch() {
	const btnResett = `
			<span>reset</span>
	`;
	const itemm = document.createElement('div');
	itemm.setAttribute('class', 'cmpnt-src__button--reset');
	itemm.innerHTML = btnResett;
	const targett = document.querySelector('.cmpnt-src-inputt');
	targett.insertBefore(itemm, null);
}

function initSearchGnb() {
	const btnResett = document.querySelector('.cmpnt-src__button--reset');
	const inputt = document.querySelector('.cmpnt-src-inputt input')
	inputt.addEventListener('keyup', function() {
		this.parentElement.classList.add('is-keyup');
        if(event.keyCode === 8 && input.value.length === 0) {
            this.parentElement.classList.remove('is-keyup');
        }    
	});

	btnResett.addEventListener('click', function() {
		this.parentElement.classList.remove('is-keyup');
		inputt.value = '';

	});
}  

// new GNB search end
/*
 *  2014.12.15  zt
 *  kia mappopup.js
 * googlemap 마커 클릭시 openmappopup호출
 */


function openMapPopup(infoTitle, info){
    $("#mapLayer .pop_tit").html(infoTitle);
    $("#mapLayer .pop_con").html(info);
    var mapInfoDimPop = new OpenDimPop($("#mapLayer"), $("#mapLayer"));
    mapInfoDimPop.open();
}


/*
 *  2014.12.02  zt
 *  kia main.js 
 * 
 */

$(document).ready(function() {
	if($(".main_inner").length) {
		mainInit();
		//proHInit(); // new wsg #50692

        // kia object
		window.kia = window.kia || {};
        // kia main object
        window.kia.main = $.extend(window.kia.main || {}, _mainObject);
        // main resieze event - 여러번 실행되지 않도록 조정.
		$(window).resize(function() {
            if(this.resizeTO) {
                clearTimeout(this.resizeTO);
            }
        	this.resizeTO = setTimeout(function() {
            	$(this).trigger('resizeEnd');
        	}, 0);

    	});
        $(window).on('resizeEnd', function() {
			window.kia.main.init();
        });

        $(window).on('load',function(){
            if($(".main_inner").length) {
                window.kia.main.setHeight();//mainInit();
            }
        });
	}
});

var _mainObject = {
    init : function() {
        // check image load

        if ( this.slide.$obj().eq(0).find(".promotion_box .img_area img")[0] && this.slide.$obj().eq(0).find(".promotion_box .img_area img")[0].complete === false ) {
            console.log('이미지가 완전히 로딩되지 않음');

            this.slide.$obj().eq(0).find(".promotion_box .img_area img").load(function () {
            	kia.main.setHeight();
        	});
        } else {
        	this.setHeight();
        }
    } // init end

    // 높이값 조정.
    , setHeight : function() {
        this.imgComp1.setHeight(); 
        this.imgComp2.setHeight();
        this.imgComp3.setHeight( this.imgComp1.getCurrentHeight()/2 || this.imgComp2.getCurrentHeight() );
    }
    
    /* 슬라이드 객체 */
    , slide : {
        $obj : function() { 
            return $('.main-type-cpnt');
		}
        , getCurrentObj : function() { //  현재 활성 슬라이드 객체
            return this.$obj().find('.main_wrap:visible').parent();
        }
        , getCurrentIdx : function() { // 현재 활성 슬라이드 인덱스
            return this.$obj().find('.main_wrap:visible').parent().index();
        }
    } // slide end
    
    /* 키비주얼 객체 */
    , keyvisual : {
        
    } // keyvisual end
    
    /* 프로모션box 객체 */
    , imgComp1 : {
        getCurrentObj : function() { // 현재 활성 슬라이드의 프로모션box 객체
            return kia.main.slide.getCurrentObj().find('.promotion_box');
        }
        , getCurrentHeight : function() { // 프로모션box 객체 내부 이미지 사이즈
            return this.getCurrentObj().find('.img_area').outerHeight();
        }
        , setHeight : function() { // 프로모션box 객체 내부 이미지 사이즈를 통해 프로모션box 객체의 높이값 세팅.
            console.log(this.getCurrentObj())
            this.getCurrentObj().parent().css('height', this.getCurrentHeight()+'px');
        }
        ,description : 'promotion box component'
    } // imgComp1 end
    
    /* 글로벌box 객체 */
    , imgComp2 : {
        getCurrentObj : function() { // 현재 활성 슬라이드의 글로벌box 객체
            return kia.main.slide.getCurrentObj().find('.global_box');
        }
        , getCurrentHeight : function() { // 글로벌box 객체 내부 이미지 사이즈
            return this.getCurrentObj().find('.img_area').outerHeight();
        }
        , setHeight : function() { // 글로벌box 객체 내부 이미지 사이즈를 통해 글로벌box 객체의 높이값 세팅.
            console.log(this.getCurrentObj())
            this.getCurrentObj().css('height', this.getCurrentHeight()+'px');
            
            
        }
        ,description : 'global box component'
    } // imgComp2 end

    /* 세일즈box 객체 */
    , imgComp3 : {
        getCurrentObj : function() { // 현재 활성 슬라이드의 세일즈box 객체
            return kia.main.slide.getCurrentObj().find('.main_sales_box .sales a');
        }
        , setHeight : function(val) { // 세일즈box 객체 내부 이미지 사이즈를 통해 세일즈box 객체의 높이값 세팅.
            console.log(this.getCurrentObj())
            this.getCurrentObj().css('height', val+'px');
            
        }
        ,description : 'sales box component'
    } // imgComp3 end
    
}; // mainObject end


// main promotion height 
/*
 var proHInit = function(){



     $(window).resize(function() {
         var width_size = window.innerWidth;

         var box1H = $('.mainType1 .promotion_box').find('img').outerHeight();
         var box2H = $('.mainType2 .global_box img').outerHeight();
         var box3H = $('.promotion_box img').outerHeight();
         var box5H = $('.mainType5 .promotion_box img').outerHeight();

        // alert(box1H);

        var box1H2 = box1H / 2;
        var box3H2 = box3H / 2;
        var box5H2 = box5H / 2;


        $('.main_box_left').css({ 'height': box1H + 'px' });
       	$('.main_box_left').css({ 'height': box3H + 'px' });
        $(' .main_box_left').css({ 'height': box5H + 'px' });

      	$('.main_sales_box .sales a').css({ 'height': box1H2 + 'px' });
      	$('.mainType1 .global_box').css({ 'height': box1H2 + 'px' });
        $('.mainType2 .main_sales_box .sales a').css({ 'height': box2H + 'px' });
         $('.mainType2 .global_box').css({ 'height': box2H + 'px' });
         $('.mainType3 .main_sales_box .sales a').css({ 'height': box3H2 + 'px' });
         $('.mainType3 .global_box').css({ 'height': box3H2 + 'px' });

     }).resize();


 }
 */



var mainInit = function(){
    var SUPPORT_CSS = $.support.transition, viewportWidth, mainNum=0, mainMaxNum=1, mainMaxNum = $(".main_wrap").length;
    var lastWindowHeight = 800, lastWindowWidth = 800;
    var MpcMode = false;
    $(window).resize(function() {
            if($(window).height()!=lastWindowHeight || $(window).width()!=lastWindowWidth){
                lastWindowHeight = $(window).height();
                lastWindowWidth = $(window).width();
                mainResize();
            }
     }).resize();

    /*mainpage stop js start 20180514 */
    $(window).ready(function(){
        //초기화면 기능 stop상태 20180620 YKJ 20190305 페이지 프로퍼티에서 on/off 설정할 수 있도록 변경, 기본값은 true
        //autoPlay(true);
        autoPlay(false);
        //proHInit(); // new wsg #50692
      });

	var autoPlayKey;

	function autoPlay(evt){
	  pagingMsg = "<span>"+(mainNum+1)+"</span>/"+mainMaxNum;
	  $(".main_inner .pagingNum").html(pagingMsg);

	  clearInterval(autoPlayKey);
	  mainPageHide();
	  if(evt == true){
		mainPageShow();
          var slideTime = $("#slideTime").val();
          if(slideTime==""){slideTime = 5000;};

          autoPlayKey = setInterval(function(){

		  var idx = mainNum+1;
		  if(idx == mainMaxNum){
			  idx = 0;
		  }

		  $(".main_wrap").css("display","none");
		  $(".main_wrap").eq(idx).css("display","block");

		  initMainTile(idx);
		},slideTime);

		$("a.playVisual").addClass("on");
		$("a.stopVisual").removeClass("on");

	  }else{

		$("a.playVisual").removeClass("on");
		$("a.stopVisual").addClass("on");

	  }
	}


	$("a.playVisual").on("click",function(e){
        e.stopPropagation();
        e.preventDefault();
        autoPlay(true);
    });
    $("a.stopVisual").on("click",function(e){
        e.stopPropagation();
        e.preventDefault();
        autoPlay(false);
    });
	/*mainpage stop js end 20180514 */




        
    $("a.mainNext").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        var idx = mainNum+1;
        if(idx == mainMaxNum){
            idx = 0;
        }
        $(".main_wrap").css("display","none");
        $(".main_wrap").eq(idx).css("display","block");
        $(".mainCenter .paging ul > li").removeClass("on");
        $(".mainCenter .paging ul").find("li:eq("+idx+")").addClass("on");
        $(this).on("keydown", function(e){
            if(e.keyCode == 9){
                e.stopPropagation();
                e.preventDefault();
                $(".mainPrev").focus();
                $(this).off("keydown");
            }
        });

        //2019.10.24 KBR
        initMainTile(idx,"R");   
        //proHInit(); // new wsg #50692
        kia.main.setHeight();
    });
    
     $("a.mainPrev").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        var idx = mainNum-1;
        if(idx < 0){
            idx = mainMaxNum-1;
        }
        $(".main_wrap").css("display","none");
        $(".main_wrap").eq(idx).css("display","block");
        $(".mainCenter .paging ul > li").removeClass("on");
        $(".mainCenter .paging ul").find("li:eq("+idx+")").addClass("on");

         //2019.10.24 KBR
        initMainTile(idx,"L");
        //proHInit(); // new wsg #50692
         kia.main.setHeight();
    });
    
    $(".share a.btnShare").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        if($(this).siblings(".shareList").css("display") == "none"){
            $(this).siblings(".shareList").css("display","block");    
        }else{
            $(this).siblings(".shareList").css("display","none");    
        }
    });
   
    $(".mainRolling").each(function(i,e){
        clickFnc(this);
        swipeFnc(this);
    });


    //new wsg 메인 인디케이터 추가 #50692 -2020.12.21 
    $(".main_kv_indicator .indi_box a").on('click', function(e) {
        e.stopPropagation();
        e.preventDefault();
        var idx = $(e.target).index();

        $(".main_wrap").css("display","none");
        $(".main_wrap").eq(idx).css("display","block");
        $(".mainCenter .paging ul > li").removeClass("on");
        $(".mainCenter .paging ul").find("li:eq("+idx+")").addClass("on");

        initMainTile(idx,"R");
        //proHInit(); // new wsg #50692
        kia.main.setHeight(); //#50973 추가
    }); 


        
    var mainSwipe = new onSwipeFnc(".main_wrap .mainCenterWrap .mainCenter");
     mainSwipe.moveEnd = function(evt, dir, phase, swipetype, distance){
         if(phase == "end"){
              if(dir == "right"){
                  var idx = mainNum-1;
                  if(idx < 0) {idx =0;}
                  $("a.mainPrev").trigger("click");
              }else if(dir == "left"){
                  var idx = mainNum+1;
                  if(idx > mainMaxNum) {idx = mainMaxNum;}
                  $("a.mainNext").trigger("click");
              }
          }        
      };
    
    function clickFnc(target){
        $(target).find(".paging ul > li > a ").on("click", function(e){
            e.stopPropagation();
            e.preventDefault();
            var idx = $(this).parent().index();
            if(viewportWidth > MOBILE_WIDTH){
                var ob = $(this).parent().parent().parent().siblings(".listWrap"); 
                var oldOb = $(this).parent().parent().find("li.on").index();
                var newOb = idx;
                if(oldOb != newOb) {
                    ob.find("ul li").eq(oldOb).css({transform: "rotateY(180deg)","display":"none"});
                    ob.find("ul li").eq(newOb).css({transform: "","display":"block"});
                    ob.find("ul").css("animation", "maintile 0.4s linear 0s").css("-webkit-animation", "maintile 0.4s linear 0s").css("-o-animation", "maintile 0.4s linear 0s").css("-ms-animation", "maintile 0.4s linear 0s");
                    setTimeout(function() {
                        ob.find("ul").attr("style", "");
                        ob.find("ul").css("animation", "").css("-webkit-animation", "").css("-o-animation", "").css("-ms-animation", "");
                    }, 400);
                }
            }else{
              
                $(this).parent().parent().parent().siblings(".listWrap").find("ul > li").css({"display":"none"});
                $(this).parent().parent().parent().siblings(".listWrap").find("ul > li").eq(idx).css({transform: "rotateY(0)","display":"block"});
            }
            $(this).parent().siblings().removeClass("on");
            $(this).parent().addClass("on");
        });
    }
    
    function swipeFnc(target){
        var localglobalSwipe = new onSwipeFnc(target);
        localglobalSwipe.moveEnd = function(evt, dir, phase, swipetype, distance){
            var targetNum = $(target).find(".paging ul > li.on").index();
            var targetMaxNum = $(target).find(".paging ul > li").length;
             if(phase == "end"){
                  if(dir == "right"){
                      var idx = targetNum-1;
                      if(idx < 0){idx =targetMaxNum-1;}
                      $(target).find(".paging ul > li:eq("+ idx +") > a").trigger("click");
                  }else if(dir == "left"){
                      var idx = targetNum+1;
                      if(idx > targetMaxNum-1){idx = 0;}
                      $(target).find(".paging ul > li:eq("+ idx +") > a").trigger("click");
                  }
              }        
        };
    } 
      
    function initMainTile(idx,pos){
       var $divTile = $(".main_wrap").eq(idx).find(".mainCenterWrap"); //2026.08.25
       var delay = 0;
       var delay_kv = 0;
       var tempBoxWidth = 307, tempBoxHeight = 262;
       if(viewportWidth < TABLET_WIDTH){
           tempBoxWidth = 153;
           tempBoxHeight = 131;
       }
       $divTile.css("animation", "").css("-webkit-animation", "").css("-o-animation", "").css("-ms-animation", "");
       if(SUPPORT_CSS && viewportWidth > MOBILE_WIDTH){
           $divTile.each(function(i){
                if(!$(this).hasClass("mainCenterWrap")) {
                    delay=delay+0.05;
                    $(this).css("animation", "maintile 0.4s linear "+delay+"s").css("-webkit-animation", "maintile 0.4s linear "+delay+"s").css("-o-animation", "maintile 0.4s linear "+delay+"s").css("-ms-animation", "maintile 0.4s linear "+delay+"s");
                } else {
                    var v = ($(this).width()/tempBoxWidth)+ 1;
                    var h = ($(this).height()/tempBoxHeight)+ 1;
                    var h2 = Math.floor(h/2);
                    for(var j=1;j<=h;j++) {for(var i=1;i<=v;i++) {
                        $(this).find(".mainCenter").append('<div class="ani ani'+i+'_'+j+'" style="position:absolute;left:'+((i-1)*tempBoxWidth)+'px;top:'+((j-1)*tempBoxHeight)+'px;width:'+tempBoxWidth+'px;height:'+tempBoxHeight+'px;"></div>');}
                    }
                    for(var j=1;j<=h;j++) { // h
                        for(var i=1;i<=v;i++) { // v
                            var ob = $(".ani"+i+"_"+j);
                            if(j<h2){
                               j2 = h-j+1; 
                            }else{
                               j2 = j;  
                            }
                            delay_kv = (100*i) + (80*j2);
                            ob.delay(delay_kv).animate({opacity:0}, 500);
                        }
                    }
                    setTimeout(function() {$(".ani").remove();}, delay_kv+100);
                }
            });
        }else{
             $divTile.each(function(i){
                delay=delay+50;
                $(this).css("animation", "").css("-webkit-animation", "").css("-o-animation", "").css("-ms-animation", "");
                $(this).stop().css("opacity",0).delay(delay).animate({opacity:1}, 200, function() {
                    $(this).css("opacity", 1);
                });
             });
        }
        mainNum = idx;

        //2019.10.24 KBR
        if(pos == "L"){
			dtmDataLayer.internal_link="conversion|main|contentbox"+mainNum+1+"|main left"; 
        	_satellite.track('internal_link');
            console.log(mainNum+1);
        }else if(pos == "R"){
			dtmDataLayer.internal_link="conversion|main|contentbox"+mainNum+1+"|main right"; 
        	_satellite.track('internal_link');
            console.log(mainNum+1);
        }

        $(".main_inner .pagingNum > span").html(mainNum+1);
    }
    
    /*mainpage stop hide/show js start 20180514 */
    function mainPageHide(){
		var MPC;
		$(".main_inner .pagingNum, a.mainNext, a.mainPrev, a.playVisual, a.stopVisual").off("mouseover").on("mouseover focusin", function(e){
			if(MpcMode == false){
				clearTimeout(MPC);
				$(".main_inner .pagingNum, .main_inner a.playVisual, .main_inner a.stopVisual").fadeIn();
			}
		});

		$(".main_inner .pagingNum, a.mainNext, a.mainPrev, a.playVisual, a.stopVisual").off("mouseout").on("mouseout focusout", function(e){
					//console.log(MpcMode);
			if(MpcMode == false){
				MPC = setTimeout(function(){
					$(".main_inner .pagingNum, .main_inner a.playVisual, .main_inner a.stopVisual").fadeOut();
					autoPlay(false);
				},1500);
			}
		});

    }

    function mainPageShow(){
        $(".main_inner .pagingNum, .main_inner a.playVisual, .main_inner a.stopVisual").stop().show();
        $(".main_inner .pagingNum, a.mainNext, a.mainPrev, a.playVisual, a.stopVisual").off("mouseover");
        $(".main_inner .pagingNum, a.mainNext, a.mainPrev, a.playVisual, a.stopVisual").off("mouseout");
    }
    /*mainpage stop hide/show  end 20180514 */
    
    function mainResize(){
        document.body.style.overflow = "hidden";
        viewportWidth = $(window).width();
        document.body.style.overflow = "";
        if(IE_VER < 9  && IE_VER !== false){
            
        }else{
            if(viewportWidth > TABLET_WIDTH){
                mainPageHide();
            }else{
                mainPageShow();
            }    
        }
    }
}

    

 /*
 *  2014.12.10  zt
 *  kia shoppingtools.js
 *
 */

$(document).ready(function() {
   //Build Your Own
   if($(".byo").length){
	   byoInit();
   }

   //Advisor
   if($(".car_advisor").length){
	  advisorInit();
   }

   //Compare car
   if($(".compare_car").length){
	  compareInit();
   }

   //finde a dealer
   if($(".findSearch").length){
	  findaDealerInit();
   }

	//Request
   if($(".stepType01").length){
	  //requestInit();
   }

   //shopping tools category click event
   if($(".byo .car_category").length){
	  cateGoryInit();
   }

   //dealer map click event
   if($(".dealer_a").length){
	  dealerClickInit();
   }
/*
   //offers
   if($(".offers").length){
	  offersInit();
   }
*/
   //payment
   if($('.payment_estimator').length) {
	   paymentInit();
   }

	// @GRO5
	// Find A Dealer
	if ($(".postcode_wrap").length){
		postcodeSet();
	}
});

function GetCookie (name) {
    var arg = name + "=";
    var alen = arg.length;
    var clen = document.cookie.length;

    var i = 0;

    while (i < clen) {
        var j = i + alen;

        if (document.cookie.substring(i, j) == arg)
            return getCookieVal (j);

        i = document.cookie.indexOf(" ", i) + 1;

        if (i == 0) break;
    }

    return null;
}

function getCookieVal (offset) {
    var endstr = document.cookie.indexOf (";", offset);

    if (endstr == -1) endstr = document.cookie.length;

    return unescape(document.cookie.substring(offset, endstr));

}


var byoInit = function(){
	var expertReviewNum = 0, expertReviewMaxNum =  $(".review_u.rSlide > li").length, expertReviewWidth = $(".byo_review").width();
	var lastWindowHeight = 800, lastWindowWidth = 800;

	//+ -버튼 기능 추가
	$(".item_h a.item_a").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		if($(this).parent().hasClass("on")){
			$(this).parent().removeClass("on");
		}else{
			$(this).parent().addClass("on");
		}
	});

	$(".review_u").css({"width":50000});
	//상당 인테리어,익스테리어 클릭이벤트
	$(".byo_preview .tab_type1 a.tab_link").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		if(!$(this).hasClass("tt1_on")){
			$(".byo_preview .tab_type1 a.tab_link").removeClass("tt1_on");
			var idx = $(this).index();
			$(this).addClass("tt1_on");
			$(".byo_preview .visual").hide();
			$(".byo_preview .visual").eq(idx).show();
			if(idx = 1){
				ineriorSwipe();
			}
		}
	});

	//인테리어 이미지 스틸컷
	var interiorNum = 0  ,interiorMaxNum = $(".inView ul.in_img li").length;
	$(".inView").on("click", "a.inViewLeft",function(e){
		e.stopPropagation();
		e.preventDefault();
		interiorNum = interiorNum-1;
		if(interiorNum < 0 ){interiorNum=interiorMaxNum-1;}
		interiorSlide(interiorNum);
	});

	$(".inView").on("click", "a.inViewRight",function(e){
		e.stopPropagation();
		e.preventDefault();
		interiorNum = interiorNum+1;
		if(interiorNum > interiorMaxNum-1){interiorNum=0;}
		interiorSlide(interiorNum);
	});

	$(".inView").on("click", ".pg_btn_area button.pg_btn",function(e){
		e.stopPropagation();
		e.preventDefault();
		var idx = $(this).index();
		interiorSlide(idx);
	});

	function interiorSlide(idx){
		$(".inView ul.in_img li").removeClass("on");
		$(".inView ul.in_img li").eq(idx).addClass("on");
		$(".inView .pg_btn_area button.pg_btn").removeClass("pg_btn_on");
		$(".inView .pg_btn_area button.pg_btn").eq(idx).addClass("pg_btn_on");
		interiorNum = idx;
	}

	//인테리어 이미지 스틸컷 스와이프
	function ineriorSwipe(){
		if($("ul.in_img").hasClass("js-swipe") || $("ul.in_img li").length < 2){
			return;
		}
		$("ul.in_img").addClass("js-swipe");
		var interiorSwipe = new onSwipeFnc("ul.in_img");
		interiorSwipe.moveEnd = function(evt, dir, phase, swipetype, distance){
			if(phase == "end"){
			 if(dir == "right"){
				 $(".inView a.inViewRight").trigger("click");
			 }else if(dir == "left"){
				 $(".inView a.inViewLeft").trigger("click");
				 }
			 }
		};
	}

	//trim all, automatic, manual클릭 이벤트
	$(".array_area a.array_a").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		$(".array_area a.array_a").removeClass("on");
		$(this).addClass("on");
		if($(this).hasClass("all")) {
			$(".trim_l").show();
		} else if($(this).hasClass("automatic")) {
			$(".trim_l").hide();
			$(".trim_l.auto").show();
		} else if($(this).hasClass("manual")) {
			$(".trim_l").hide();
			$(".trim_l.manual").show();
		}
	});

   //expert review 클릭이벤트
	$(".ctrl button.arrowBtn").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		var idx = $(this).index();
		if(idx == 0){
			expertReviewNum = expertReviewNum-1;
			if(expertReviewNum < 0){expertReviewNum = 0}
			expertReviewMove(expertReviewNum);
		}else{
			expertReviewNum = expertReviewNum+1;
			if(expertReviewNum > expertReviewMaxNum-1){expertReviewNum = expertReviewMaxNum-1}
			expertReviewMove(expertReviewNum);
		}
	});

	//expert review 스와이프 이벤트
	var reviewSwipe = new onSwipeFnc(".byo_review");
	reviewSwipe.moveEnd = function(evt, dir, phase, swipetype, distance){
		if(phase == "end"){
		 if(dir == "right"){
			 $(".ctrl button.arrowBtn:eq(0)").trigger("click");
		 }else if(dir == "left"){
			 $(".ctrl button.arrowBtn:eq(1)").trigger("click");
			 }
		 }
	};

	var dimPop = new OpenDimPop($(".popup_wrap"));

	//trim basic option클릭 이벤트
	$(".byoDetail a.option_a").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		//Springworks
		$(".pop_con").html($(this).parent().find(".basic_option").html());
		dimPop.open();
	});

	//summary +,-아이콘 클릭이벤트
	$(".byo_summary .sum_l a.item_a").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		var parent = $(this).parent().parent();
		if(parent.hasClass("on")){
			parent.removeClass("on");
		}else{
			parent.addClass("on");
		}
	});

	//byo step2 trim 초기화
	if ($(".trim_list").length) {
		//페이지 진입시 첫번째 트림자동선택
		$(".trim_list .trim_l input:eq(0)").trigger("click");
		trimTotalPriceSet();
	}

	$(".trim_list .trim_l label").on("click", function(e) {
		trimTotalPriceSet();
	});

	$(".trim_list .trim_l input").on("click", function(e) {
		trimTotalPriceSet();
	});

	//step2 totalprice 설정
	function trimTotalPriceSet() {
		var $obj = $(".trim_list .trim_l .form_chk > label.r_on");
		var name = $obj.text();
		var trimPrice = $obj.parent().siblings(".option_area").find("input[name=trimPrice]").val();
		var trimRRPPrice = $obj.parent().siblings(".option_area").find("input[name=trimRRPPrice]").val();
		var trimOfferPrice = $obj.parent().siblings(".option_area").find("input[name=trimOfferPrice]").val();
		var roadCost = commaNumber((parseFloat(trimPrice) - parseFloat(trimRRPPrice)).toFixed(2));
		var price = trimNumber($obj.parent().siblings(".option_area").find(".option_price").text());
		var priceField = $obj.parent().siblings(".option_area").find(".option_price").text();
		var addLi = "<li class='item_l'>" + name + "<em class='price'><span class='drive_away'>RRP</span> "+"$" + commaNumber(parseFloat(trimRRPPrice).toFixed(2)) + "</em></li>";
		if(priceField == "" || priceField == "undefined" || priceField == undefined) {
			$(".byo_summary .sum_l:eq(1)").hide();
			$(".offerPrice").hide();
			
            $(".byo_summary .sum_l:eq(0) .item_h .price").html("<a href='javascript:setLocation();' class='sylPopupOpen byo_set_location'>DRIVE AWAY<span class='ico_question'><span>Set your location to get local pricing</span></span></a>");

            $(".total .sylPopupOpen").remove();
			$(".total .bl_type5").after("<a href='javascript:setLocation();' class='sylPopupOpen byo_set_location'>DRIVE AWAY<span class='ico_question'><span>Set your location to get local pricing</span></span></a>");

			addLi = "<li class='item_l'>" + name + "<a href='javascript:setLocation();' class='sylPopupOpen byo_set_location'>DRIVE AWAY<span class='ico_question'><span>Set your location to get local pricing</span></span></a>";
		} else {			
			$(".byo_summary .sum_l:eq(0) .item_h .price").html("<span class='drive_away'>RRP</span> $" +commaNumber(parseFloat(trimRRPPrice).toFixed(2)));
			$(".byo_summary .total:eq(0) .total_price").html("<span class='drive_away'>Drive Away</span> $" +commaNumber(parseFloat(trimPrice).toFixed(2)));

			$(".byo_summary .sum_l:eq(1) .price").html("$"+roadCost);
			$(".byo_summary .sum_l:eq(1)").show();
			
			if( trimOfferPrice.replace(/(\s*)/g,'').match(/[^0-9.]/g) == null )
				trimOfferPrice = "<span class='drive_away'>Drive Away</span> $" +commaNumber(parseFloat(trimOfferPrice).toFixed(2));
			if( trimOfferPrice != "0.00" )
			{
				$(".byo_summary .offerPrice .total_price").html(trimOfferPrice);
				$(".offerPrice").show();
			}
		}
		
		//var addLi = "<li class='item_l'>" + name + "<em class='price'>"+"</em></li>";
		$(".byo_summary .sum_l:eq(0) .item_u").html(addLi);

		// Springworks
		//$(".basic_option_summary").html($obj.parent().siblings(".option_area").find(".basic_option").html());

		var optionHtml = $obj.parent().siblings(".option_area").find(".basic_option").html();

		if(optionHtml == "" || optionHtml == "undefined" || optionHtml == undefined) {
			$(".aside .option_a").css("display","none");
		} else {
			$(".aside .option_a").css("display","block");
		}

		$(".basic_option_summary").html(optionHtml);
	}


	//byo step3 color 초기화
	if($(".color_list").length){

		$(".byo_con").on("click",".color_list .color_l a.color_a", function(e){
			//springworks
			$("#exteriorImage").attr("src", $(this).attr("path"));
            $("#byo360vr_img").attr("vr360folder", $(this).attr("vr360folder"));
			e.stopPropagation();
			e.preventDefault();
			$(".color_l").removeClass("on");
			$(this).parent().addClass("on");

			var target = $(this);
			var li = target.closest('li');
			var idx = li.index();
			var colIdx = $("."+li.attr("color")).index();

			$(".byo_con .option_list .option_l").removeClass("on");
			$(".byo_con .option_list .option_l").hide();
			$("."+li.attr("color")).show();
			$(".byo_con .option_list:eq(0) .option_l input:eq("+colIdx+")").trigger("click");

			colorTotalPriceSet();
		});

		$(".option_list .option_l label").on("click", function(e) {
			colorTotalPriceSet();
		});

		$(".option_list .option_l input").on("click", function(e) {
			colorTotalPriceSet();
		});

		//페이지 진입시 첫번째 컬럭자동선택
		$(".color_list .color_l:eq(0) a.color_a").trigger("click");
		colorTotalPriceSet();
	}


	//step3 totalprice 설정
	function colorTotalPriceSet(){
		
		var dataTrimPrice = $("#dataTrimPrice").val();
		var dataTrimRRPPrice = $("#dataTrimRRPPrice").val();
		var dataTrimPremiumPrice = $("#dataTrimPremiumPrice").val();
		var dataTrimOfferPrice = $("#dataTrimOfferPrice").val();
		var dataTrimPremiumOfferPrice = $("#dataTrimPremiumOfferPrice").val();

		var trimPrice = trimNumber($(".byo_summary .sum_l:eq(0) .item_h .price").text());
		var trimPriceField = $(".byo_summary .sum_l:eq(0) .item_h .price").text();

		var $exObj = $(".color_list .color_l.on");
		var exname = $exObj.find(".color_info").contents().eq(0).text();
		var exprice = trimNumber2($exObj.find(".price").text());

		var $inObj = $(".option_list .option_l .form_chk > label.r_on");
		var inname = $inObj.text();
		var inprice = trimNumber2($inObj.parent().siblings(".price").text());

		var exLi = "<li class='item_l'><strong class='sort'>Exterior Colour</strong>" + exname + "<em class='price'><span class='drive_away'>RRP</span> " + "$"+commaNumber(exprice) + "</em></li>";
		var inLi = "<li class='item_l'><strong class='sort'>Interior Colour</strong>" + inname + "<em class='price'><span class='drive_away'>RRP</span> " + "$"+commaNumber(inprice) + "</em></li>";

		$(".byo_summary .sum_l:eq(1) .item_u").html(exLi + inLi);
		$(".byo_summary .sum_l:eq(1) .item_h .price").html("<span class='drive_away'>RRP</span> $"+commaNumber((parseFloat(exprice)+parseFloat(inprice)).toFixed(0)));

		var roadCost = "0.00";
		var totalPrice = "0";
		var totalOfferPrice = "0";
		if( parseInt(exprice) > 0 ) 
		{
			totalPrice = commaNumber(parseFloat(dataTrimPremiumPrice).toFixed(2));
			totalOfferPrice = dataTrimPremiumOfferPrice;
			if( dataTrimPremiumOfferPrice.replace(/(\s*)/g,'').match(/[^0-9.]/g) == null )
				totalOfferPrice = "<span class='drive_away'>Drive Away</span> $"+commaNumber(parseFloat(dataTrimPremiumOfferPrice).toFixed(2));
			if( !(trimPriceField == "" || trimPriceField == "undefined" || trimPriceField == undefined) )
				roadCost = commaNumber((parseFloat(dataTrimPremiumPrice) - parseFloat(dataTrimRRPPrice) - parseFloat(exprice)).toFixed(2));
		}
		else
		{ 
			totalPrice = commaNumber(parseFloat(dataTrimPrice).toFixed(2));
			totalOfferPrice = dataTrimOfferPrice;
			if( dataTrimOfferPrice.replace(/(\s*)/g,'').match(/[^0-9.]/g) == null )
				totalOfferPrice = "<span class='drive_away'>Drive Away</span> $"+commaNumber(parseFloat(dataTrimOfferPrice).toFixed(2));
			if( !(trimPriceField == "" || trimPriceField == "undefined" || trimPriceField == undefined) )
				roadCost = commaNumber((parseFloat(dataTrimPrice) - parseFloat(dataTrimRRPPrice)).toFixed(2));
		}
		$(".byo_summary .sum_l:eq(2) .price").html("$"+roadCost);
		
		if(trimPriceField == "" || trimPriceField == "undefined" || trimPriceField == undefined) {
            $(".offerPrice").hide();
            $(".total .sylPopupOpen").remove();
			$(".total .bl_type5").after("<a href='javascript:setLocation();' class='sylPopupOpen byo_set_location'>DRIVE AWAY<span class='ico_question'><span>Set your location to get local pricing</span></span></a>");
		} else {
			$(".byo_summary .total .total_price").html("<span class='drive_away'>Drive Away</span> $"+totalPrice);
			if( totalOfferPrice != "0.00" )
			{
				$(".byo_summary .offerPrice .total_price").html(" "+totalOfferPrice);
            	$(".offerPrice").show();
			}
		}
	}

	 //byo step4 option초기화
	if($(".optionCon").length){
		$(".byo_summary .sum_l:eq(2) .item_u").html("");
		$(".optionCon .form_chk label").on("click", function(e) {
			optionTotalPriceSet();
		});

		$(".optionCon .form_chk input").on("click", function(e) {
			optionTotalPriceSet();
		});

		optionTotalPriceSet();
	}

	 //step4 totalprice 설정
	function optionTotalPriceSet(){
		var trimPrice = trimNumber($(".byo_summary .sum_l:eq(0) .item_h .price").text());
		var colorPrice = trimNumber($(".byo_summary .sum_l:eq(1) .item_h .price").text());
		var trimPriceField = $(".byo_summary .sum_l:eq(0) .item_h .price").text();

		var optionLi = "";
		var optionPrice = 0;
		$(".optionCon .form_chk > label.c_on").each(function(i,e){
			var name = $(this).text();
			var price = trimNumber($(this).parent().parent().find(".price").text());
			optionPrice += price;
			optionLi += "<li class='item_l'>" + name + "<em class='price'><span class='drive_away'>Drive Away</span> " + "$"+commaNumber(price) + "</em></li>";
			//optionLi += "<li class='item_l'>" + name + "<em class='price'>" + "" + "</em></li>";
		});

		$(".byo_summary .sum_l:eq(2) .item_u").html(optionLi);

		var totalPrice = commaNumber((parseFloat(trimPrice) + parseFloat(colorPrice) + parseFloat(optionPrice)).toFixed(2));
		$(".byo_summary .sum_l:eq(2) .item_h .price").html("<span class='drive_away'>Drive Away</span> $"+commaNumber(optionPrice));
		//$(".byo_summary .sum_l:eq(2) .item_h .price").text("");
			//$(".byo_summary .total .total_price").text("$"+totalPrice);
		//$(".byo_summary .total .total_price").text("");

		if(trimPriceField == "" || trimPriceField == "undefined" || trimPriceField == undefined) {
			$(".byo_summary .total .total_price").html("<a href='#' class='sylPopupOpen byo_set_location'>Drive Away<span class='ico_question'><span>Set your location to get local pricing</span></span></a>");
		} else {
			$(".byo_summary .total .total_price").html("<span class='drive_away'>Drive Away</span> $"+totalPrice);
		}
	}

	//byo step5 accessories초기화
	if($(".byo_acc").length){
		$(".byo_summary .sum_l:eq(3) .item_u").html("");
		$(".option_box .form_chk label").on("click", function(e) {
			accTotalPriceSet();
		});

		$(".option_box .form_chk input").on("click", function(e) {
			accTotalPriceSet();
		});

		accTotalPriceSet();
	}

	//step5 totalprice 설정 #62013 step 사용으로 계산식 및 가격 정보 수정
	function accTotalPriceSet(){
		var trimPrice = trimNumber($(".byo_summary .sum_l:eq(0) .item_h .price").text());
		var colorPrice = trimNumber($(".byo_summary .sum_l:eq(1) .item_h .price").text());
		var optionPrice = trimNumber($(".byo_summary .sum_l:eq(2) .item_h .price").text());
		var trimPriceField = $(".byo_summary .sum_l:eq(0) .item_h .price").text();
        var dataTrimOfferPriceTotal = $("#dataTrimOfferPriceTotal").val();

		var accLi = "";
		var accPrice = 0;
		$(".option_box .form_chk > label.c_on").each(function(i,e){
			var name = $(this).parent().parent().find(".chx_title").text();
			var price = trimNumber($(this).parent().parent().find(".price").text());
            //alert(Math.round((a+b)*T)/T);
			//console.log($(this));
			//accPrice += price;

            accPrice = jsDigitMath(accPrice, price, 'plus');

			accLi += "<li class='item_l'>" + name + "<em class='price'>" + "$"+commaNumber(price)+ "</em></li>";
			//accLi += "<li class='item_l'>" + name + "<em class='price'>" + ""+ "</em></li>";
		});

		$(".byo_summary .sum_l:eq(2) .item_u").html(accLi);

		//var totalPrice = commaNumber(parseInt(trimPrice + colorPrice + optionPrice + accPrice));
        var totalPrice = 0;

        if(accPrice != 0){
            dataTrimOfferPriceTotal = jsDigitMath(dataTrimOfferPriceTotal, accPrice, 'plus');
        }else{
			dataTrimOfferPriceTotal = dataTrimOfferPriceTotal;
        }

		//alert(accPrice);
        //var T=Number('1e'+1);
		//alert(Math.round((trimPrice + colorPrice + optionPrice+accPrice)*T)/T);

		$(".byo_summary .sum_l:eq(2) .item_h .price").html("<span class='drive_away'>Drive Away</span> $"+commaNumber(accPrice));
		//$(".byo_summary .total .total_price").text("$"+totalPrice);

		if(trimPriceField == "" || trimPriceField == "undefined" || trimPriceField == undefined) {
			$(".byo_summary .total .total_price").html("");

            $(".total .sylPopupOpen").remove();
			$(".total .bl_type5").after("<a href='javascript:setLocation();' class='sylPopupOpen byo_set_location'>DRIVE AWAY<span class='ico_question'><span>Set your location to get local pricing</span></span></a>");
		} else {
			$(".byo_summary .total .total_price").html("<span class='drive_away'>Drive Away</span> $"+commaNumber(dataTrimOfferPriceTotal));
		}

		//$(".byo_summary .sum_l:eq(3) .item_h .price").text("");
		//$(".byo_summary .total .total_price").text("");
	}

    function jsDigitMath(value1, value2, type) {
        if(!isNaN(value1) || !isNaN(value2)){
            var num1, num2, digits, base, result1, result2, result;
     
            num1 = value1 * 100;
            num2 = value2 * 100;
     
            digit = 2;
     
            base = Math.pow(10, digit);
     
            num1 = Math.round(num1 * base) / base;
            num2 = Math.round(num2 * base) / base;

            result1 = Math.floor(num1);
            result2 = Math.floor(num2);
     
            switch(type)
            {
                case 'plus' : 
                    result = result1 + result2;
                break;
     
                case 'minus' : 
                    result = result1 - result2;
                break;
     
                case 'multiply' : 
                    result = result1 * result2;
                break;
     
                case 'divide' : 
                    result = result1 / result2;
                break;
     
                default : 
                    result = result1 + result2;
            }

            result = (result / 100).toFixed(2);
        }else{
            result = null;
        }
     
        return result;
    }

	function trimNumber(str){
		var price = parseFloat(str.replace(/[^0-9.]/g,'') *1);
        return price.toFixed(2);
	}
	function trimNumber2(str){
		var price = parseFloat(str.replace(/[^0-9.]/g,'') *1);
        return price.toFixed(0);
	}

	function commaNumber(str){
		return str.toString().replace(/\B(?=(\d{3}){1,7}(?!\d))/g, ',');
	}


	$(window).resize(function() {
		if($(window).height()!=lastWindowHeight || $(window).width()!=lastWindowWidth){
			lastWindowHeight = $(window).height();
			lastWindowWidth = $(window).width();
			byoResize();
		}
	}).resize();

	$(window).on("scroll",byoScrollFnc);

	function expertReviewMove(idx){
		TweenMax.to($(".review_u"), 0.5, {marginLeft: expertReviewWidth * -idx, ease:"easeOutQuart"});
	}

	function byoResize(){
		expertReviewWidth = $(".byo_review").width();
		$(".review_u").css({"margin-left":expertReviewWidth * -expertReviewNum});
		$(".review_l").css("width",expertReviewWidth);
	}

	//스크롤시 customer preferences 이미지 애니메이션
	function byoScrollFnc(){
		var scrollTop = $(window).scrollTop();
		var scrollBottom = scrollTop + $(window).height();

		if( $(".byo_graph").offset() ){
			var targetTop = $(".byo_graph").offset().top + 100;
			if(scrollBottom > targetTop){
				$(window).off("scroll",byoScrollFnc);
				$(".byo_graph .graph").each(function(i,e){
					var percentNum = $(this).find(".rate .num").text();
					var graphHeight = $(this).height()+1;
					//$(this).css("background-position","0px "+(graphHeight*-percentNum)+"px");
					graphAnimate(this, graphHeight, percentNum);
				});
			}
		}
	}

	function graphAnimate(obj, height, endNum) {
		var startNum = 0, duration = 1000;
		var $obj = $(obj);
		var range = endNum - startNum;
		var interDelay = 50;
		var startTime = new Date().getTime();
		var endNumTime = startTime + duration;
		var timer;
		timer = setInterval(animate, interDelay);
		animate();

		function animate() {
			var now = new Date().getTime();
			var remaining = Math.max((endNumTime - now) / duration, 0);
			var value = Math.round(endNum - (remaining * range));
			setPos(value);
			if (value == endNum) {
				clearInterval(timer);
			}
		}
		function setPos(val){
			$obj.css("background-position","0px "+(height*-val)+"px");
		}
	}

};

var advisorSlider, seatsSlider,halfCircularSlider;
var advisorInit = function(){
	var minPrice = 100, maxPrice = 3000, $amount1 = $( "#amount1" ), $amount2 = $( "#amount2" ), $amount3 = $( "#amount3" );
	//가격대 슬라이더
	advisorSlider = $( "#slider-range" ).slider({
		orientation: 'horizontal',
		range: true,
		step:100,
		min: minPrice,
		max: maxPrice,
		value: 0,
		values: [ 100, 3000 ],
		slide: function( event, ui ) {
			$amount1.val( "$" + ui.values[ 0 ] );
			$amount2.val( "$" + ui.values[ 1 ] );
		}
	});

	$amount1.val( "$" + $( "#slider-range" ).slider( "values", 0 ) );
	$amount2.val( "$" + $( "#slider-range" ).slider( "values", 1 ) );
	$("#amount1 ,#amount2").attr("maxlength","4");

	$amount1.add($amount2).focusin(function (e) {
		 var target = $(e.currentTarget);
		 var num = target.val().substr(1, target.val().length);

		 target.val(num);
	});

	$amount1.add($amount2).focusout(function (e) {
		var target = $(e.currentTarget);

		target.val("$" + target.val());
	});

	//$ 삭제함수
	function cutDollar(val) {
		var oneIdx = ( val.indexOf("$") < 0 ) ? 0 : val.indexOf("$") + 1;

		return parseInt(val.substr(oneIdx, val.length));
	}

	$amount1.change(function(e) {
		var low = cutDollar($amount1.val()), high = cutDollar($amount2.val());
		if(low < minPrice || isNaN(low)){ low = minPrice;}
		low = Math.min(low, high);
		$amount1.val(low);
		advisorSlider.slider("values", 0, low);
	});

	$amount2.change(function(e) {
	   var low = cutDollar($amount1.val()), high = cutDollar($amount2.val());
		if(high > maxPrice || isNaN(high)){ high = maxPrice;}
		high = Math.max(low, high);
		$amount2.val(high);
		advisorSlider.slider("values", 1, high);
	});

	$("#amount1 ,#amount2").keydown(function (e) {
		var code = e.keyCode || e.which;
		if(code == 13){
			$(this).change();
			return;
		}
		if ($.inArray(code, [0, 46, 8, 9, 27, 13, 110, 190]) !== -1 || (code == 65 && e.ctrlKey === true) ||(code >= 35 && code <= 40)) {
		   return;
		}
		if ((e.shiftKey || (code< 48 || code > 57)) && (code < 96 || code > 105)) {
			e.preventDefault();
		}
	});

	//연비등급
	/*
	$(".mileageSelect .inner > a").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		$(".mileageSelect .inner > a").removeClass("on");
		$(this).addClass("on");
	});
	*/
	var mileage = $(".mileageSelect");
	if (mileage.length > 0) {
		var mpgSlider = $('#mpgSlider');

		if (mpgSlider.is('a')) {
			mpgSlider.on('dragstart', function (e) {
				e.preventDefault();
			});

			mpgSlider.on('keydown', function (e) {
				var keycode = e.keyCode;
				var val = halfCircularSlider.getValue();

				if (keycode === 37 || keycode === 40) {
					val -= 1;

					if (val < 0) val = 0;
				} else if (keycode === 38 || keycode === 39) {
					val += 1;

					if (val > 100) val = 100;
				}

				halfCircularSlider.setValue(val);
			});
		}

		var mpgLabel = mileage.find('input');
		halfCircularSlider = mpgSlider.CircularSlider({
			min : 0,
			max: 100,
			value : 0,
			radius : 116,
			touch : true,
			animate : true,
			animateDuration: 0,
			labelSuffix: "MPG",
			handleDist: 88,
			shape: "Half Circle",
			slide : function(ui, val) {
				var slideVal = val.toString().toLowerCase();
				if(slideVal == "nan"){return;}
				ui.find('.jcs').css('background-position','0px '+(116*-val)+'px');
				mpgLabel.val(val + ' MPG');
			}
		});
		mpgLabel.on('focusin', function (e) {
			var target = $(e.currentTarget);
			var num = parseInt(target.val());

			target.val( num );
		});

		mpgLabel.on('focusout', function (e) {
			var target = $(e.currentTarget);
			var num = parseInt(target.val());
			var regex = /0|^[1-9][0-9]?$|^100$/;

			var obj = String(num).match(regex);
			var val = (isNaN(num) || obj === null) ? 0 : obj[0];
			target.val( val + ' MPG');

			halfCircularSlider.setValue(parseInt(val));
		});

		mpgLabel.on('keydown', function (e) {
			var target = $(e.currentTarget);
			var val = parseInt(target.val());
			if (e.keyCode === 13) {
				halfCircularSlider.setValue(val);
				target.val(val);
			}
		});

		$('.jcs-value').hide();
		$('.jcs-panel').prepend($('.jcs-indicator'));
	}

	seatsSlider = null;
	var sliderType = '';
	var sliderIndex = 2;

	setSeatsSlider();
	function setSeatsSlider() {
		if (lastWindowWidth == undefined) lastWindowWidth = $(window).width();
		seatsSlider = null;
		if (lastWindowWidth > 750) {
			sliderType = 'vertical';
			$("#slider-range2").find(".ui-slider-range").css({"width": "100%"});
		} else {
			sliderType = 'horizon';
			$("#slider-range2").find(".ui-slider-range").css({"height": "100%"});
			$("#slider-range2").find(".ui-slider-handle").css({"bottom": "0"});
		}

		seatsSlider = $( "#slider-range2" ).slider({
			orientation: sliderType,
			range: "min",
			min: 2,
			max: 10,
			value: sliderIndex,
			slide: function( event, ui ) {
				sliderIndex = ui.value;
				$amount3.val( ui.value + "seats" );
			}
		});
	}

	$amount3.val( $("#slider-range2").slider( "value" ) + "seats" );

	$amount3.change(function (e) {
		 var target = $(e.currentTarget);
		 var sliderOpts = seatsSlider.slider("option");
		 var val = parseInt($amount3.val());

		 if (val < sliderOpts.min) {
			 val = sliderOpts.min;
		 } else if (val > sliderOpts.max) {
			 val = sliderOpts.max
		 }

		 $amount3.val(val);
		 seatsSlider.slider("value", val);
	});

	$amount3.focusin(function (e) {
		 var target = $(e.currentTarget);
		 var num = parseInt(target.val());

		 target.val(num);
	});

	$amount3.focusout(function (e) {
		var target = $(e.currentTarget);

		target.val(target.val() + "seats");
	});

	var viewHeight, thisLi, nextLi, evenCheck, viewportWidth, carViewH, targetThis, targetA, repeatNum = 5;
	var lastWindowHeight = 800;
	var lastWindowWidth = 800;
	$(window).resize(function() {
		if($(window).height()!=lastWindowHeight || $(window).width()!=lastWindowWidth){
			lastWindowHeight = $(window).height();
			lastWindowWidth = $(window).width();
			carAdvisorResize();
			setSeatsSlider();
		}
	}).resize();

	//$(".car_box a.car_a").on("click", function(e){
	$("ul.car_u").on("click", "a.car_a", function(e){ //wddo
		e.stopPropagation();
		e.preventDefault();

		evenCheck = $(this).parent().parent().next().index() % 2;
		thisLi = $(this).parent().parent();
		targetThis = $(this).parent();
		targetA = $(this);

		$(".car_l").css("height","");
		$(".car_box a.car_a").removeAttr("title");
		if($(this).hasClass("on")){
			$(this).removeClass("on");
			thisLi.removeClass("on");
			thisLi.css("height","");
			targetThis = null;
			targetA = null;
		}else{
			$(".car_l").removeClass("on");
			$(".car_box a.car_a").removeClass("on");
			thisLi.addClass("on");
			$(this).addClass("on");
			$(this).attr("title","selected");
			$(".car_l:nth-child("+repeatNum+"n+1)").css("clear", "both");
			viewHeight = targetHeight();
			thisLi.css("height",viewHeight);
		}
	});

	$(".car_list").on("click",".carinfoWrap button", function(e){
		e.stopPropagation();
		e.preventDefault();
		targetA = $(".car_box a.car_a.on");
		targetA.trigger("click");
	});

	function targetHeight(){
		return targetThis.siblings(".car_info").outerHeight() + targetThis.outerHeight()+10;
	}

	function targetMobileHeight(){
		return targetThis.siblings(".car_info").outerHeight() + targetThis.outerHeight()+10;
	}

	function carAdvisorResize(){
		document.body.style.overflow = "hidden";
		viewportWidth = $(window).width();
		document.body.style.overflow = "";
		if(IE_VER < 9 && IE_VER !== false){
			 //return;
		}else{
			$("li.car_l").css("clear", "");
			 if(viewportWidth > 767){
				 if(viewportWidth < 1024){
					 repeatNum = 4;
				 }else{
					 repeatNum = 5;
				 }
			}else{
				repeatNum = 2;
			}
			if(targetThis !== null && targetThis !== undefined){
				viewHeight =  targetHeight();
				thisLi.css("height",viewHeight);
			}
			$(".car_l:nth-child("+repeatNum+"n+1)").css("clear", "both");
		}
	}

};

/*
 *  @compareContainer
 *  var compare = new compareContainer();
 *  compare.selectNumSet(idx); addcar 버튼 클릭시 선택값 입력
 *  compare.addCar(data); 차량추가
 *  compare.removeCar(idx); 차량제거
 *  compare.tableTrHeightSet(); compare-car02 데이타 입력시 테이블 tr높이 조정
 *  compare.reset(); 차량정보 초기화
 *  compare.openPopup() 차량 선택 팝업 오픈
 *  compare.closePopup() 차량 선택 팝업 닫기
 *  compare.resize() 리사이즈
 *
 */
function compareContainer(){
	this.selectNum = null;
	this.dimPop = new OpenDimPop($(".popup_addcar"), $(".popup_addcar .pop_con"), {topValue: 41});
};

compareContainer.prototype = {
	//차량클릭시 현재 인덱스
	selectNumSet : function(idx){
	   var self = this;
	   self.selectNum = idx;
	   self.openPopup();
	},
	//차량추가
	addCar : function(data){
		var self = this;
		var idx = self.selectNum;

		if($(".vs_wrap").length){
			//compare-car02
			compare2AddCar();
		}else{
			//compare-car01
			compare1AddCar();
		}

		$(".compareList:eq("+idx+")").addClass("addon");        //+ 화면을 자동차 화면으로
		var carNum = $(".compareList.addon").length;            //추가된 자동차 갯수
		$(".result_con > span, .resultCon > span").text(carNum);//추가된 자동차 갯수 숫자 text 변경

		self.closePopup();

		if($("*:focus").length > 0){
		   $(".compareList:eq("+idx+") a.selectClose").focus(); //자동차 추가리스트 x 버튼에 포커스
		}

        function commaNumber(str){
            return str.toString().replace(/\B(?=(\d{3}){1,7}(?!\d))/g, ',');
        }

		//compare-car01부분 data 입력
		function compare1AddCar(){
			var carImage = "<img src='"+data.result.img+"' alt='"+data.result.name+"'>";
			//var carInfo = "<strong>"+data.result.name+"</strong><span>"+data.result.spec+"</span><span class='addPrice'>"+data.result.price+"</span>";
			var carInfo = "<strong>"+data.result.name+"</strong><span>"+data.result.spec+"</span>";

			if(GetCookie("regionCode") != null && GetCookie("regionCode") != "") {
				if(data.result.displayPrice == "Y"){
					var url = "/api/kia_australia/common/trimPrice.selectPriceByTrim?regionCode="+GetCookie('regionCode')+"&modelCode="+data.result.carKey+"&trimCode="+data.result.trimCode;

					$.ajax({
						type : "GET",
						url : url,
						dataType: 'json',
						async : false
					}).done(function(data,status,header){
						if(status=="success") {
							carInfo += "<span class='addPrice'><span class='drive_away'>Drive Away</span><span class='price'> $ "+commaNumber(data.dataInfo[0].price)+"</span></span>";
						}
					});

					//carInfo+= "<span class='addPrice'>"+data.result.price+"</span>";
				}
			} else {
				//carInfo += "<a href='#' onclick='locationClick();'>Drive Away</a>";
                carInfo += "<a href='#' class='byo_set_location' onclick='locationClick();'>DRIVE AWAY<span class='ico_question'><span>Set your location to get local pricing</span></span></a>";
			}

			$(".compareList:eq("+idx+") .selectCar .cadImg").html(carImage);
			$(".compareList:eq("+idx+") .selectCar .selectCar_con").html(carInfo);
		}

		//compare-car02부분 data 입력  12.18변경
		function compare2AddCar(){
			var carImage = "<img src='"+data.result.img+"' alt='"+data.result.name+"'>";
			var carInfo = "<strong>"+data.result.name+"</strong><span>"+data.result.spec+"</span>";
			$(".compareList:eq("+idx+") .selectCar .cadImg").html(carImage);

            if(GetCookie("regionCode") != null && GetCookie("regionCode") != "") {
                var url = "/api/kia_australia/common/trimPrice.selectPriceByTrim?regionCode="+GetCookie('regionCode')+"&modelCode="+data.result.carKey+"&trimCode="+data.result.trimCode;
                
                $.ajax({
                    type : "GET",
                    url : url,
                    dataType: 'json',
                    async : false
                }).done(function(data2,status,header){
                    if(status=="success") {
                        carInfo += "<span class='addPrice'><span class='drive_away'>Drive Away</span><span class='price'> $ "+commaNumber(data2.dataInfo[0].price)+"</span></span>";

                        carInfo += "<input type='hidden' id='carKey_"+(idx+1)+"' name='carKey' value='"+data.result.carKey+"'/>";
                        carInfo += "<input type='hidden' id='carImgPath_"+(idx+1)+"' name='carImgPath' value='"+data.result.img+"'/>";
                        carInfo += "<input type='hidden' id='carName_"+(idx+1)+"' name='carName' value='"+data.result.name+"'/>";
                        carInfo += "<input type='hidden' id='trimCode_"+(idx+1)+"' name='trimCode' value='"+data.result.trimCode+"'/>";
                        carInfo += "<input type='hidden' id='trimName_"+(idx+1)+"' name='trimName' value='"+data.result.spec+"'/>";
                        carInfo += "<input type='hidden' id='price_"+(idx+1)+"' name='price' value='"+data2.dataInfo[0].price+"'/>";
                    }
                });

            } else {
                 carInfo += "<a href='#' class='byo_set_location' onclick='locationClick();'>DRIVE AWAY<span class='ico_question'><span>Set your location to get local pricing</span></span></a>";

                carInfo += "<input type='hidden' id='carKey_"+(idx+1)+"' name='carKey' value='"+data.result.carKey+"'/>";
                carInfo += "<input type='hidden' id='carImgPath_"+(idx+1)+"' name='carImgPath' value='"+data.result.img+"'/>";
                carInfo += "<input type='hidden' id='carName_"+(idx+1)+"' name='carName' value='"+data.result.name+"'/>";
                carInfo += "<input type='hidden' id='trimCode_"+(idx+1)+"' name='trimCode' value='"+data.result.trimCode+"'/>";
                carInfo += "<input type='hidden' id='trimName_"+(idx+1)+"' name='trimName' value='"+data.result.spec+"'/>";
                carInfo += "<input type='hidden' id='price_"+(idx+1)+"' name='price' value='"+data.result.price+"'/>";
            }


            $(".compareList:eq("+idx+") .selectCar .selectCar_con").html(carInfo);

            $('#carSelectLength').val(parseInt($('#carSelectLength').val()) +1);


			$(".vs_car tbody tr:not(:eq(0)) td:nth-child("+(idx+1)+")").each(function(i,e){
				if ($(this).find("a").length) {
					//change
					$(this).find("a").contents().eq(1).replaceWith(data.result.info[i]);
				}else {
					$(this).contents().eq(1).replaceWith(data.result.info[i]);

					//wddo 15.03.05 // a태그 감쌈
					$(this).contents().wrapAll("<a href='#' class='active_a'>");
				}
			});
			self.tableTrHeightSet();
		}

		function GetCookie (name) {
			var arg = name + "=";
			var alen = arg.length;
			var clen = document.cookie.length;

			var i = 0;

			while (i < clen) {
				var j = i + alen;

				if (document.cookie.substring(i, j) == arg)
					return getCookieVal (j);

				i = document.cookie.indexOf(" ", i) + 1;

				if (i == 0) break;
			}

			return null;
		}

		function getCookieVal (offset) {
			var endstr = document.cookie.indexOf (";", offset);

			if (endstr == -1) endstr = document.cookie.length;

			return unescape(document.cookie.substring(offset, endstr));

		}
	},
	//차량삭제
	removeCar : function(idx){
		var self = this;
		self.selectNum = null;
		var carNum = $(".compareList.addon").length;
		$(".result_con > span, .resultCon > span").text(carNum);
		if($(".vs_wrap").length){
			compare2RemoveCar();
		}

		if($("*:focus").length > 0){
		   $(".compareList:eq("+idx+") a.btnadd").focus();
		}

		function compare2RemoveCar(){
			$(".vs_car tbody tr:not(:eq(0)) td:nth-child("+(idx+1)+")").each(function(i,e){
				//wddo 15.03.05 // find('>a') 추가하여 변경
				$(this).find(">a").contents().eq(1).replaceWith("-");

				//wddo 15.03.05 // a태그 삭제
				$(this).find('>a').contents().unwrap();

				//wddo 15.03.05 // 테이블 활성화를 삭제한 경우 하단 비활성화
				if ($(this).closest("td").hasClass("active")) {
					$(".vs_car tbody tr th, .vs_car tbody tr td").removeClass("active"); // 테이블 활성화 삭제
					$("div.sales_box").removeClass("active");
				}
			});
			self.tableTrHeightSet();
		}
	},
	//데이타 테이블 높이 조정
	tableTrHeightSet : function(){
		var trHeightArr = [], tbodyTrHeightArr = [], trMaxHeightArr = [];
		//왼쪽 테이블 초기 데이터
		$(".vs_head .vs_item tbody tr").each(function(i,e){
			$(this).css("height", "");
			var trHeight = $(this).height();
			trHeightArr.push(trHeight);
		});

		//오른쪽 테이블 초기 데이터
		$(".vs_body .vs_car tbody tr").each(function(i,e){
			$(this).css("height", "");
			var trHeight = $(this).height();
			tbodyTrHeightArr.push(trHeight);
		});

		//두 초기 데이터중 큰값 취합
		trMaxHeightArr = compareArr(trHeightArr, tbodyTrHeightArr)

		//왼쪽 테이블 데이터 적용
		$(".vs_body .vs_car tbody tr").each(function(i,e){
			$(this).css("height", trMaxHeightArr[i]);
		});

		//오른쪽 테이블 데이터 적용
		$(".vs_head .vs_item tbody tr").each(function(i,e){
			$(this).css("height", trMaxHeightArr[i]);
		});

		function compareArr(arr1,arr2){
			var maxArr = [];
			for(var i = 0; i < arr1.length; i++){
				if(arr1[i] == 0){
					maxArr.push(0);
				}else{
					maxArr.push(Math.max(arr1[i],arr2[i]));
				}
			}
			return maxArr;
		}
	},
	//차량정보 초기화
	reset : function(){
		var self = this;
		self.selectNum = null;
		$(".resultCon > span").text("0");
		$(".compareList").removeClass("addon");
		//reset compare2
		if($(".vs_wrap").length){
			 $(".vs_car tbody tr:not(:eq(0)) td").each(function(i,e){
				//wddo 15.03.05 // find('>a') 추가하여 변경
				$(this).find(">a").contents().eq(1).replaceWith("-");

				//wddo 15.03.05 // a태그 삭제
				$(this).find('>a').contents().unwrap();
			});

			$(".vs_car tbody tr th, .vs_car tbody tr td").removeClass("active"); // 테이블 활성화 삭제
			$("div.sales_box").removeClass("active");
		}
	},
	 //차량 선택 팝업 오픈
	openPopup : function(){
		this.dimPop.open();
	},
	 //차량 선택 팝업 닫기
	closePopup : function(){
		this.dimPop.close();
	},
	//리사이즈 호출
	resize : function(){
		var self = this;
		document.body.style.overflow = "hidden";
		var viewportWidth = $(window).width();
		document.body.style.overflow = "";

		if(IE_VER < 9 && IE_VER !== false){
			 //return;
		}else{
		   self.tableTrHeightSet();
		   if(viewportWidth < 565){
			   var vswrapWidth = $(".vs_wrap").width();
			   var vsheadWidth = $(".vs_head").width();
			   $(".vs_body").css({"overflow-x" : "scroll", "width" : vswrapWidth-vsheadWidth});
			   $(".vs_car").css({"position" : "relative", "left" : 0, "width" : 440, "overflow" : "hidden"});
		   }else{
			   $(".vs_body").css({"overflow-x" : "", "width" : ""});
			   $(".vs_car").css({"position" : "", "left" : "", "width" : ""  , "overflow" : ""});
		   }
		}
	}
}

//compare-car 더미 데이타
var cardata = {"result":{"img": "img_sorento.png","name":"Picato1","spec": "Bi-Fuel Smart M/T","price": "$13.140",
 "info":["1,681mm","1,682mm","1,683mm", "1,684mm", "1,685mm", "1,686mm", "1,687mm", "1,688mm", "1,689mm",
 "1,690mm", "1,691mm", "1,692mm","1,693mm","1,694mm","1,695mm","1,696mm","1,697mm","1,698mm","1,699mm",
 "1,700mm","1,701mm","1,702mm","1,703mm","1,704mm","1,705mm"]}};

var compare = new compareContainer();

var compareInit = function(){
	var selectIndex, lastWindowHeight = 800, lastWindowWidth = 800;
	$(window).resize(function() {
		if($(window).height()!=lastWindowHeight || $(window).width()!=lastWindowWidth){
			lastWindowHeight = $(window).height();
			lastWindowWidth = $(window).width();
			compare.resize();
		}
	});

	$(window).load(function() {
		   compare.resize();
	});

	////////////////////////////////////////////////////////////////////// COMPARE CAR start


	//wddo 15.03.05 // 데이터 a태그 핸들러
	$(".vs_car tbody").on("click", "td > a", function (e) {
		var idx = $(this).closest('td').index();

		changeCompareCar(idx);

		//모바일용 셀렉트박스 같이 변경
		$(".sales_box .form_select option").eq(idx).prop("selected", true);
		$(".sales_box .form_select").resetSS();

		e.preventDefault();
	});

	//wddo 15.03.06 // 모바일 셀렉트 박스 변경
	$(".sales_box .form_select").on("change", function (e) {
		var target = $(e.currentTarget);
		var idx = target[0].selectedIndex;

		changeCompareCar(idx);
	});

	function changeCompareCar(idx) {
		$(".vs_car tbody tr th, .vs_car tbody tr td").removeClass("active"); // 테이블 활성화 삭제
		$(".vs_car tbody tr th:nth-child("+(idx+1)+"), .vs_car tbody tr td:nth-child("+(idx+1)+")").addClass("active"); // 테이블 활성화
		$("div.sales_box").addClass("active"); //하단 활성화
	}

	//리셋 버튼
	/* $("#resetBtn, #resetBtnM").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		compare.reset();
	}); */

	//차량선택화면 차량버튼
	$("ul.car_u").on("click", "a.car_a", function(e){
		e.stopPropagation();
		e.preventDefault();
		if($(this).hasClass("on")){
			$("a.car_a").removeClass("on");
			$("a.car_a").attr("title","");
			$(this).removeClass("on");
			$(this).attr("title","");
		}else{
			$("a.car_a").removeClass("on");
			$("a.car_a").attr("title","");
			$(this).addClass("on");
			$(this).attr("title","Select");
		}
	});

	//차량선택화면 add > 버튼
	$(".pop_compare a.btnLarge").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		 if($(".car_a.on").length < 1){
			alert("Please select a car");
			return;
		}
		if($(".radio_box.r_on").length < 1){
			alert("Please select a trim");
			return;
		}

		compare.addCar(cardata);
	});

	//리스트 추가 + 버튼
	$("a.btnadd").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		selectIndex = $(this).parent().parent().parent().index();
		//인덱스 저장
		compare.selectNumSet(selectIndex);
	});

	//추가된 리스트 오른상단 x 버튼
	$("a.selectClose").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		$(this).parent().parent().parent().removeClass("addon");
		selectIndex = $(this).parent().parent().parent().parent().index();
		compare.removeCar(selectIndex);
	});

	//차량선택화면 전체 닫기
	$(".popup_wrap a.closeBtn").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		selectIndex = null;
		if(compare){
			compare.closePopup();
		}
	});

	//차량선택화면 뒤 dim
	$(".dimmed").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		selectIndex = null;
		if(compare){
			compare.closePopup();
		}

		dimPop.close();
	});

	////////////////////////////////////////////////////////////////////// COMPARE CAR end

	var dimPop = new OpenDimPop($(".popup_tool"), $(".popup_tool .pop_con"), {topValue: 41});

	$("#emailBtn").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		dimPop.open();
	});

	$(".popup_tool a.btnMedium").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		dimPop.close();
	});


	$(".item_h1 a.item_a").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		if($(this).parent().hasClass("on")){
			$(this).parent().removeClass("on");
			$(".item_more1").removeClass("on");
		}else{
			$(this).parent().addClass("on");
			$(".item_more1").addClass("on");
		}
		compare.resize();
	});

	$(".item_h2 a.item_a").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		if($(this).parent().hasClass("on")){
			$(this).parent().removeClass("on");
			$(".item_more2").removeClass("on");
		}else{
			$(this).parent().addClass("on");
			$(".item_more2").addClass("on");
		}
		compare.resize();
	});

	$(".item_h3 a.item_a").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		if($(this).parent().hasClass("on")){
			$(this).parent().removeClass("on");
			$(".item_more3").removeClass("on");
		}else{
			$(this).parent().addClass("on");
			$(".item_more3").addClass("on");
		}
		compare.resize();
	});
};


var findaDealerInit = function(){
	/* 개발에서 삭제 요청 @wddo
	$(".schCon .schTab > ul > li > a").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		var idx = $(this).parent().index();
		$(this).parent().parent().parent().parent().find(".formArea").css("display","none");
		$(this).parent().parent().parent().parent().find(".formArea:eq("+idx+")").css("display","block");
	});
	*/
}

var requestInit = function(){
	var lastWindowHeight = 800, lastWindowWidth = 800;
	$(window).resize(function() {
		if($(window).height()!=lastWindowHeight || $(window).width()!=lastWindowWidth){
			lastWindowHeight = $(window).height();
			lastWindowWidth = $(window).width();
			requestStep1Resize();
		}
	}).resize();

	if($(".stepbar.bar01 .car .carList").length < 2){
		$(".stepbar.bar01 a.btn_carmore").remove();
	}

	$(".stepbar.bar01 a.btn_carmore").on("click", function(e){
		e.stopPropagation();
		e.preventDefault();
		if($(this).parent().hasClass("on")){
			$(this).parent().removeClass("on");
			$(this).parent().find(".carList:not(:eq(0))").css("display","none");
		}else{
			$(this).parent().addClass("on");
			$(this).parent().find(".carList:not(:eq(0))").css("display","block");
		}
	});

	function requestStep1Resize(){
		document.body.style.overflow = "hidden";
		var viewportWidth = $(window).width();
		document.body.style.overflow = "";
		if(IE_VER < 9 && IE_VER !== false){
			 //return;
		}else{
		   if(viewportWidth < MOBILE_WIDTH){
			   if(!$(".stepbar.bar01 .car").hasClass("on")){
					$(".stepbar.bar01 .car .carList:not(:eq(0))").css("display","none");
			   }
		   }else{
				$(".stepbar.bar01 .car .carList:not(:eq(0))").css("display","block");
		   }
		}
	}
};

var cateGoryInit = function(){
	var lastWindowHeight = 800, lastWindowWidth=800;
	$(window).resize(function() {
		if($(window).height()!=lastWindowHeight || $(window).width()!=lastWindowWidth){
			lastWindowHeight = $(window).height();
			lastWindowWidth = $(window).width();
			categoryResize();
		}
	}).resize();

	$(".category > span.form_chk:eq(0) input").trigger("click");
	$(".category > span.form_chk label, .category > span.form_chk input").on("click", function(e){


		var idx =  $(this).parent().index();

		$(this).parent().parent().parent().parent().find(".car_list").css("display","none");

		$("a.car_a").removeClass("on");
		$("a.car_a").attr("title","");
		if(idx == 0){
			 $(this).parent().parent().parent().parent().find(".car_list").css("display","block");
		}else{
			 $(this).parent().parent().parent().parent().find(".car_list:eq("+(idx-1)+")").css("display","block");
		}
		if($(".car_wrap").length){
			categoryResize();
		}
	});


	function categoryResize(){
		$(".filter_wrap ul").css("display","");
		document.body.style.overflow = "hidden";
		viewportWidth = $(window).width();
		document.body.style.overflow = "";
		var viewportWidth = $(window).width();
		var carWrapHeight = $(".car_wrap").height();
		if(IE_VER < 9 && IE_VER !== false){

		}else{
			if(viewportWidth > MOBILE_WIDTH){
				if(carWrapHeight >= 515){
					$(".car_wrap").css("overflow","hidden");
					$(".car_wrap").css("overflow-y","scroll")
				}else{
					 $(".car_wrap").css("overflow-y","");
					 $(".car_wrap").css("overflow","hidden");
				}
			}else{
			   $(".car_wrap").css("overflow-y","");
			   $(".car_wrap").css("overflow","");
			}
		}
	}

	//request brochure ,  request quote, e-mail subscription 일경우 3개까지 선택가능
	if($(".request_quote").length || $(".request_brochure").length || $(".email_subscription").length){
		$("div.car_wrap").on("click", "a.car_a", function (e) { // @wddo 페이지 로드후에 리스트 출력으로 인하여 타이밍문제로 컨테이너에 이벤트 적용
		//$("a.car_a").on("click", function(e){
			e.stopPropagation();
			e.preventDefault();

			if($(this).hasClass("on")){
				$(this).removeClass("on");
				$(this).attr("title","");
			} else {
				$(this).addClass("on");
				$(this).attr("title","Select");
			}

			/* @wddo :: 개발에서 컨트롤하기로 함
			if($(this).hasClass("on")){
				$(this).removeClass("on");
				$(this).attr("title","");
			}else{
				var len = $("a.car_a.on").length;
				if(len > 2){
					alert("차량은 최대 3대까지 선택 가능합니다.");
					return;
				}
				$(this).addClass("on");
				$(this).attr("title","Select");
			}
			var selectText = "Select Vehicles : ";
			$("a.car_a.on").each(function(i,e){
				var str = $(this).find(".car_name").text();
				selectText+=str+", ";
			});

			$(".stepCon .selData.hidden").text(selectText);
			*/
		});
	}else{
	//한개씩만 선택
		$("a.car_a").on("click", function(e){

		e.stopPropagation();
		e.preventDefault();
		if($(this).hasClass("on")){
			$("a.car_a").removeClass("on");
			$("a.car_a").attr("title","");
			$(this).removeClass("on");
			$(this).attr("title","");
		}else{
			$("a.car_a").removeClass("on");
			$("a.car_a").attr("title","");
			$(this).addClass("on");
			$(this).attr("title","Select");
		}
		var selectText = "Select Vehicles : " + $("a.car_a.on .car_name").text();
			$(".stepCon .selData.hidden").text(selectText);
			//springworks
			location.href = $(this).attr("href");
		});

		var paymentWrap = $('.payment_estimator');
		var stepContainer = paymentWrap.find('.stepWrap'); //타이틀포함 컨테이너
		var stepContent = paymentWrap.find('.stepCon'); //내용
		var stepNextBtn = paymentWrap.find('.step_ctrl > a.btnType1'); // 2개
		var stepPrevBtn = paymentWrap.find('a.btnType3'); // 2개
		var stepTitleBtn = paymentWrap.find('div.result a'); //2개
		var stepAct = 0;

		//초기화
		stepContent.not(':eq('+stepAct+')').slideUp(0);

		//next 버튼
		stepNextBtn.on('click', function (e) {
			e.stopPropagation();
			e.preventDefault();

			var target = $(e.currentTarget);

			switch (stepAct) {
				case 0 :
					if (paymentWrap.find('.car_a').hasClass('on')) {
						//선택한게 있으면
						stepAct = 1;
						changeStep();
						changeTitle();
					} else {
						//에러메세지
					}
					break;
				case 1 :
					if (paymentWrap.find('ul.trim_list label.r_on').length > 0) {
						//선택한게 있으면
						stepAct = 2;
						changeStep();
						changeTitle();
					} else {
						//에러메세지
					}
					break;
				default :
			}
		});

		//back 버튼
		stepPrevBtn.on('click', function (e) {
			e.stopPropagation();
			e.preventDefault();

			stepAct -= 1;
			changeStep();
		});

		//결과 타이틀
		stepTitleBtn.on('click', function (e) {
			e.stopPropagation();
			e.preventDefault();

			var target = $(e.currentTarget);
			var idx = target.closest('li').index();

			stepAct = idx;
			changeStep();
			changeTitle();
		});


		//타이틀 결과 변경

        var changeTitle = function(){
			switch (stepAct) {
				case 1 :
					var carA = paymentWrap.find('.car_a.on');
					paymentWrap.find('a.carList > img').attr('src', carA.find('img').attr('src'));
					paymentWrap.find('a.carList > span').text(carA.find('strong').text());
					break;
				case 2 :
					paymentWrap.find('.bar02 div.result > a').text(paymentWrap.find('ul.trim_list label.r_on').text());
					break;
				default :
			}
		}

		//스텝 변경 & 모션
        var changeStep = function(){
			stepContainer.removeClass('on').removeClass('paston');

			stepContainer.each(function (i) {
				if (stepAct > i) {
					stepContent.eq(i).slideUp(300);
					stepContainer.eq(i).addClass('paston');
					//닫힘 모션
				} else if (stepAct == i) {
					stepContent.eq(i).slideDown(300);
					stepContainer.eq(i).addClass('on');
					//열림 모션
				} else {
					stepContent.eq(i).slideUp(300);
				}
			});
		}

		//인풋, 셀렉트 이벤트
		paymentWrap.find('.scrollBody input').on('focusin', function (e) {
			$(this).data('value', $(this).val());
		});

		paymentWrap.find('.scrollBody input').on('focusout', function (e) {
			if ($(this).data('value') !== $(this).val()) {
				var idx = $(this).closest('td').index();
				changeValue(idx);
			}
		});

		paymentWrap.find('.scrollBody select').on('change', function (e) {
			var idx = $(this).closest('td').index();
			changeValue(idx);
		});

		//결과 값 변경 (일단 임의의 숫자) & 숫자 변경 효과
        var changeValue = function(idx) {
			var price = paymentWrap.find('.scrollBody tr:eq(1)');
			var payments = paymentWrap.find('.scrollBody tr:last');

			var priceValue = price.find('td:eq('+idx+') strong').text().substring(1);
			var paymentsValue = payments.find('td:eq('+idx+')').text().substring(1);

			//값 변경
			//price.find('td:eq('+idx+') strong').text( '$' + parseInt(priceValue) + ',' + Math.floor(Math.random() * 999) + '.00' );
			//payments.find('td:eq('+idx+')').text( '$' + Math.floor(Math.random() * 999) + '.00' );

			//모션
			price.find('td:eq('+idx+')').add(payments.find('td:eq('+idx+')')).css('opacity', 0).animate({
				'opacity': 1
			}, {queue:false, duration:400});
		}
	}
};

var dealerClickInit = function(){
	$("a.dealer_a").on("click", function(e){
	   $("a.dealer_a").removeClass("center_on");
	   $(this).addClass("center_on");
	   var selectText = "Select Vehicles : " + $("a.dealer_a.center_on .info dt").text();
	   $(".stepCon .selData.hidden").text(selectText);
	});
}
 
//@wddo
var offersInit = function () {
	 var dimPop = new OpenDimPop($(".popup_wrap"));

	 //shopping-tools/offers02_03
	 $("a.bl_type_a").on("click", function (e) {
		  e.stopPropagation();
		  e.preventDefault();
		  dimPop.open();
	 });

	 //shopping-tools/offers02_03
	 //Offers Select : All | Cash Back Offer | Special Low APR | Special Lease Offer
    /*
	 var ofsListContainer = $('.offersList');
	 var ofsList = ofsListContainer.find('div.listContents');

	 ofsList.hide();

	 var ofsCategoryRadio = $('div.category input[name="radio02"]');
	 var ofsCategoryLabel = ofsCategoryRadio.next('label');
	 var ofsCategoryAct = ofsCategoryLabel.filter('.r_on').parent().index() - 1;

	 ofsCategoryRadio.on('change', function (e) {

		var target = $(e.currentTarget);
		var idx = target.parent().index();

		ofsCategoryAct = idx - 1

		changeOfsCategory();
	 });

	 function changeOfsCategory() {
		 ofsList.hide();
		 if (ofsCategoryAct < 0) {
			 ofsList.show();
		 } else {
			 ofsList.eq(ofsCategoryAct).show();
		 }
	 }

	 changeOfsCategory();*/
}

//@wddo
var paymentInit = function () {
	var dimPop1 = new OpenDimPop($('.popup_wrap:eq(0)'));
	var dimPop2 = new OpenDimPop($('.popup_wrap:eq(1)'));

    /* #66211 주석처리
	$('.bl_type_a:eq(0)').on('click', function (e) {
		e.stopPropagation();
		e.preventDefault();

		dimPop1.open();
	});

	$('.bl_type_a:eq(1)').on('click', function (e) {
		e.stopPropagation();
		e.preventDefault();

		dimPop2.open();
	});
    */
}

// @GRO5
// Find A Dealer
var postcodeSet = function(){
	$(".postcode_wrap").each(function(){
		var $this = $(this);
		var $selectBtn = $(".select_btn", $this);
		$("input[type=radio]:checked", $this).each(function(){
			$("label[for="+$(this).attr("id")+"]").addClass("on");
		});
		$("label", $this).on("click", function(e){
			$this.removeClass("open");
		//	$this.closest(".formArea").removeAttr("style");
		});
		$(".select_btn", $this).on("click", function(e){
			e.preventDefault();
			$this.toggleClass("open");
		//	$this.closest(".formArea").css({"z-index":"100"});
		});
		$("input[type=radio]", $this).on("change focusin focusout", function(e){
			postcode($(this), e);
		});
		function postcode($radio, e){
			var $label = $("label[for="+$radio.attr("id")+"]");
			if (e.type == "focusin" ){
				$label.addClass("focus");
			} else if ( e.type == "focusout" ){
				$("input[name="+$radio.attr("name")+"]").each(function(){
					$("label[for="+$(this).attr("id")+"]").removeClass("focus");
				});
			} else if ( e.type == "change" ){
				$("input[name="+$radio.attr("name")+"]").each(function(){
					$("label[for="+$(this).attr("id")+"]").removeClass("on");
				});
				$label.addClass("on");
				$selectBtn.html($label.html());
			}
		}
	});
}

/*
 *  2014.12.15  zt
 *  kia service.js 
 */

$(document).ready(function() {     
    //manual
   if($(".manual").length){
      manualInit();
   }
   
   //shopping tools category click event
   if($(".book_service .car_category").length){
      serviceCateGoryInit();
   }
   
   //shopping tools category click event
   if($(".service_location .dealer_a, .book_service .dealer_a").length){
      serviceDealerClickInit();
   }
   
   //recall
   if($(".recall").length){
      recallInit();
   }
   
});

var manualInit = function(){
    $(".carSelect").on("click"," ul > li > a", function(e){
        e.stopPropagation();
        e.preventDefault();
        if($(this).parent().hasClass("on")){
            $(this).parent().removeClass("on");
        }else{
            $(".carSelect > ul > li").removeClass("on");
            $(this).parent().addClass("on");    
        }
        var carText = "Car : " + $(".carSelect > ul > li.on > a").text();
        $(".manual .btn_areaR .hidden > ul >li:eq(0)").text(carText);
    });
    
    $(".manualList").on("click", "ul > li > a",function(e){
        e.stopPropagation();
        e.preventDefault();
        if($(this).parent().hasClass("on")){
            $(this).parent().removeClass("on");
        }else{
            $(".manualList > ul > li").removeClass("on");
            $(this).parent().addClass("on");    
        }
        var manualText = "Manual : " + $(".manualList > ul > li.on > a").text();
        $(".manual .btn_areaR .hidden > ul >li:eq(1)").text(manualText);
    });
};


var serviceCateGoryInit = function(){
    var lastWindowHeight = 800, lastWindowWidth=800;
    $(window).resize(function() {
        if($(window).height()!=lastWindowHeight || $(window).width()!=lastWindowWidth){
            lastWindowHeight = $(window).height();
            lastWindowWidth = $(window).width();
            categoryResize();
        }
    }).resize();
    
    $(".category > span.form_chk:eq(0) input").trigger("click");
    $(".category > span.form_chk label, .category > span.form_chk input").on("click", function(e){
        var idx =  $(this).parent().index(); 
        $(this).parent().parent().parent().parent().find(".car_list").css("display","none");   
        $("a.car_a").removeClass("on");
        $("a.car_a").attr("title","");
        if(idx == 0){
             $(this).parent().parent().parent().parent().find(".car_list").css("display","block");
        }else{
             $(this).parent().parent().parent().parent().find(".car_list:eq("+(idx-1)+")").css("display","block");
        }
        if($(".car_wrap").length){
            categoryResize();
        }
    });
    
    function categoryResize(){
        $(".filter_wrap ul").css("display","");
        document.body.style.overflow = "hidden";
        viewportWidth = $(window).width();
        document.body.style.overflow = "";
        var viewportWidth = $(window).width();
        var carWrapHeight = $(".car_wrap").height();
        if(IE_VER < 9 && IE_VER !== false){ 
         
        }else{
            if(viewportWidth > MOBILE_WIDTH){
                if(carWrapHeight >= 515){
                    $(".car_wrap").css("overflow","hidden");
                    $(".car_wrap").css("overflow-y","scroll")                        
                }else{
                     $(".car_wrap").css("overflow-y","");
                     $(".car_wrap").css("overflow","hidden");
                }
            }else{
               $(".car_wrap").css("overflow-y","");
               $(".car_wrap").css("overflow","");
            }    
        }
    }
    
    //개발에서 컨트롤
    /*$(".car_wrap").on("click", "a.car_a", function(e){
        e.stopPropagation();
        e.preventDefault();
        if($(this).hasClass("on")){
            $("a.car_a").removeClass("on");
            $("a.car_a").attr("title","");
            $(this).removeClass("on");
            $(this).attr("title","");
        }else{
            $("a.car_a").removeClass("on");
            $("a.car_a").attr("title","");
            $(this).addClass("on");    
            $(this).attr("title","Select");
        }
        var selectText = "Select Vehicles : " + $("a.car_a.on .car_name").text();
        $(".stepCon .selData.hidden").text(selectText);
    });*/

};

var serviceDealerClickInit = function(){
    $("a.dealer_a").on("click", function(e){
       $("a.dealer_a").removeClass("center_on");
       $(this).addClass("center_on");
       var selectText = "Select Vehicles : " + $("a.dealer_a.center_on .info dt").text();
       $(".stepCon .selData.hidden").text(selectText);
    });
}

//wddo
var recallInit = function () {
     var dimPop = new OpenDimPop($(".popup_wrap"), $(".popup_wrap"), 0);
    
     $("a.bl_type_a").on("click", function (e) {
          dimPop.open();
     });
}

/*
 *  2015.01.06  zt
 *  kia experiance.js
 */

$(document).ready(function() {
   //tabSelectBox
   if($(".tabSelectBox").length){
       exTabSelectBoxInit();
   }

  //history slider
   if($(".tab_history").length){
       exHistorySliderInit();
   }

   //history of kia
   if($(".historyList").length){
       exHistoryInit();
   }

   //concept car, motoer show 썸네일 갤러리
   if($(".exkia_gallery").length){
       exkiaGalleryInit();
   }

   //promtion
   if($(".promotionCon").length && !$(".sound_gallery").length){
       exPromotionGalleryInit();
   }

   //promotion popup
   if($(".promotion_play").length){
       exPromotionPlayPopupInit();
   }

   //awards
   if($(".award_list").length){
       exAwardInit();
   }

   //social media
   if($(".cont_social").length){
       exSocialMediaInit();
   }

   //safety
   if($(".safety").length){
       exSafetyInit();
   }

    //wddo experience/tv/tv-commercial-video
    if($(".tvCon .tvList").length){
        exTvListInit();
    }

    //wddo experience/tv/tv-commercial-video-detail
    if($(".tvCon .slider_tv").length){
        exTvDetailInit();
    }

   //revies detail
   if($(".ex_bbsView").length){
       exImgGallerySet(".eximg_slider", 940, 504);
   }

   //experience .d-onScreen클래스가있으면 스크롤시 모션 추가
   if($(".d-onScreen").length){
      exScrollMotionInit();
   }

   //wddo experience/brand/film
   if($(".ex_visual.film").length) {
      exFilm();
   }

   //wddo experience/brand/campaign
   if($(".ex_visual.campaign").length) {
       exCampaign();
   }

   //wddo experience/brand/gearup
   if($(".ex_visual.gearup").length) {
       exGearUp();
   }

	//wddo experience/brand/roadtrip
   if($(".ex_visual.roadtrip").length) {
       exRoadTrip();
   }

    //wddo experience/brand/design
   if($(".ex_visual.design2").length) {
       exDesign();
   }

   //wddo experience/brand/taste
   if($(".taste").length){
       exTasteVideoSlider();
   }

   //wddo experience/brand/sound
   if($(".ex_visual.sound").length) {
       exSound();
   }

   //experience/innovation-story/driving.html sequence animation 03.09
   if($(".driving_mode .seq_wrap").length){
       exSeqInit();
   }
});

var exTabSelectBoxInit = function(){
     var viewportWidth, lastWindowWidth = 800, lastWindowHeight = 800;

     $(".tabSelectBox > ul > li").on("click", function(e){
         var target = $(e.currentTarget);

        //e.stopPropagation();
        //e.preventDefault();

        target.siblings("li").removeClass("tab_on");
        target.addClass("tab_on");

        //$(this).siblings("li").find("a").removeAttr("title");
        //$(this).find("a").attr("title","fold contents");

        var str = target.find("> a").text();
        $(".exkia_gallery h5.hidden").text(str);
        target.parent().siblings("a.input_box").find("span").text(str);

        if(viewportWidth < MOBILE_WIDTH ){
            if(IE_VER < 9 && IE_VER !== false){

            }else{
                if (!target.hasClass("dep2Has")) target.parent().css("display","none");
            }
        }
        if($("*:focus").length > 0){
           target.parent().siblings("a.input_box").focus();
        }

        //wddo 2depth open
        if (target.hasClass('dep2Has')) {
            var ul = target.find('> ul');

            if (!target.hasClass('on')) {
                target.addClass('on');
                ul.show();
            } else {
                target.removeClass('on');
                ul.hide();
            }
        }
    });

    //wddo 2depth A tag btn handler
    $(".tabSelectBox li.dep2Has ul").on("click", "a", function (e) {
         var target = $(e.currentTarget);
         var li = target.closest('li');
         var parentLi = target.closest('li.tab_on');

         li.siblings().andSelf().find('> a').removeClass('on');
         target.addClass('on');

        if(viewportWidth < MOBILE_WIDTH ){
            if(IE_VER < 9 && IE_VER !== false){

            } else {
                if (parentLi.hasClass("dep2Has")) parentLi.parent().css("display","none");
            }
        }
    });

     $(".tabSelectBox a.input_box").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        if($(this).siblings("ul").css("display") == "none"){
            $(this).siblings("ul").css("display","block");
        }else{
            $(this).siblings("ul").css("display","none");
        }
    });

    $(window).resize(function() {
        if($(window).height()!=lastWindowHeight || $(window).width()!=lastWindowWidth){
            lastWindowHeight = $(window).height();
            lastWindowWidth = $(window).width();
            tabtype3Resize();
        }
    }).resize();

    function tabtype3Resize(){
        $(".tabSelectBox ul").css("display","");
        document.body.style.overflow = "hidden";
        viewportWidth = $(window).width();
        document.body.style.overflow = "";
    }
};


var exHistorySliderInit = function(){

    var historyNum = 0, historyMaxNum = $(".history_list > li").length, historyLiWidth, viewLiLength = 8, $slider = $(".slideWrap .slider .history_list");
    var viewportWidth, lastWindowWidth = 800, lastWindowHeight = 800;
    if(historyMaxNum < 8){return;}
    historyNum = $(".history_list > li.tab_on").index() > 7 ? ($(".history_list > li.tab_on").index()+1) - 8 : 0;
    $(".slide_inner").on("click", "button.prevMove", function(e) {
        e.stopPropagation();
        e.preventDefault();
        historyNum = historyNum - 1;
        if (historyNum < 0) {historyNum = 0;}
        sliderMove(historyNum);
    });

    $(".slide_inner").on("click", "button.nextMove", function(e) {
        e.stopPropagation();
        e.preventDefault();
        historyNum = historyNum + 1;
        if (historyNum > historyMaxNum - 1) {historyNum = historyMaxNum - 1;}
        sliderMove(historyNum);
    });

    $(window).resize(function() {
        if ($(window).height() != lastWindowHeight || $(window).width() != lastWindowWidth) {
            lastWindowHeight = $(window).height();
            lastWindowWidth = $(window).width();
            historySliderResize();
        }
    }).resize();

    function historySliderResize() {
        document.body.style.overflow = "hidden";
        viewportWidth = $(window).width();
        document.body.style.overflow = "";
         if(IE_VER < 9 && IE_VER !== false){
                historyLiWidth = 940 / 8;
                viewLiLength = 8;
                $(".history_list li").css("width", historyLiWidth);
                sliderMove(historyNum);
        }else{
            if (viewportWidth > 1120) {
                historyLiWidth = 940 / 8;
                viewLiLength = 8;
                $(".history_list li").css("width", historyLiWidth);
                sliderMove(historyNum);
            } else if (viewportWidth < 1120 && viewportWidth > 767) {
                historyLiWidth = (viewportWidth - 104) / 6;
                viewLiLength = 5;
                $(".history_list li").css("width", historyLiWidth);
                sliderMove(historyNum);
            } else {
                $(".history_list li").css("width", "");
                TweenMax.killTweensOf($slider);
                $slider.css("margin-left", "");
            }
        }
    }

    function sliderMove(idx){
        var current = historyMaxNum - viewLiLength;
        if(current < historyNum){
            historyNum = current;
            return;
        }else if(current == historyNum){
            $("button.nextMove").removeClass("on");
        }else{
             $("button.nextMove").addClass("on");
        }

        historyNum = idx;
        TweenMax.to($slider, 0.5, {marginLeft: historyLiWidth * -idx, ease:"easeOutQuart"});

        if(historyNum > 0){
            $("button.prevMove").addClass("on");

        }else{
            $("button.prevMove").removeClass("on");
        }
    }
};

var exHistoryInit = function(){
     $(".historyList > li").each(function(i,e){
         if($(this).hasClass("toggleON")){
         $(this).find("a").attr("title","fold contents");
         }
     });

     $(".historyList  > li > a").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        $(this).parent().toggleClass("toggleON");
        if($(this).parent().hasClass("toggleON")){
            $(this).attr("title","fold contents");
        }else{
            $(this).removeAttr("title");
        }
    });
};

var exkiaGalleryInit = function(){
    //프로모션 갤러리일때는 제외
    if($(".exkia_gallery").hasClass("promotionCon")){return;}
    var viewportWidth, lastWindowWidth = 800, lastWindowHeight = 800, $thumbContainer = $(".exkia_gallery .thumnail");
    var thumbNum = 0, thumbMaxNum = $(".thumnail > li").length, thumbLiWidth = $(".thumnail > li").width()+10, viewLiLength =6;

    thumbAltSet();
    viewImgContainer(0);

    $(".exkia_gallery").on("click", ".thumbtn_l > a", function(e) {
        e.stopPropagation();
        e.preventDefault();
        thumbNum = thumbNum - 1;
        if (thumbNum < 0) {thumbNum = 0;}
        thumbContainerMove(thumbNum);
    });

    $(".exkia_gallery").on("click", ".thumbtn_r > a", function(e) {
        e.stopPropagation();
        e.preventDefault();
        thumbNum = thumbNum + 1;
        if (thumbNum > thumbMaxNum - 1) {thumbNum = thumbMaxNum - 1;}
        thumbContainerMove(thumbNum);
    });

    $(".exkia_gallery").on("click", "ul.thumnail li > a", function(e) {
        e.stopPropagation();
        e.preventDefault();
        $(".exkia_gallery .thumnail li > a span.off").removeClass("on");
        $(this).find("span.off").addClass("on");
        var idx = $(this).parent().index();
        viewImgContainer(idx);
    });

    $(".exkia_gallery").on("mouseenter", "ul.thumnail li > a", function(e) {
        e.stopPropagation();
        e.preventDefault();
        $(this).find("span.off").addClass("on");
    });

    $(".exkia_gallery").on("mouseleave", "ul.thumnail li > a", function(e) {
        e.stopPropagation();
        e.preventDefault();
        if (!$(this).closest('li').hasClass("tab_on")) {
            $(this).find("span.off").removeClass("on");
        }
    });

    $(window).resize(function() {
        if ($(window).height() != lastWindowHeight || $(window).width() != lastWindowWidth) {
            lastWindowHeight = $(window).height();
            lastWindowWidth = $(window).width();
            exkiaGalleryResize();
        }
    }).resize();

    function thumbAltSet(){
        $(".thumnail li").each(function(i,e){
            var carName = $(this).find(".carName").text();
            $(this).find(".imgArea img").attr("alt",carName);
        });
    }

    function viewImgContainer(idx){
        var $target = $(".imgWrap .imgDivision");
        $target.hide();
        $target.eq(idx).show();
        imgDivisionContainerSet($target.eq(idx));
        /* 데이타 로드형식으로 하면 데이타 로드후 imgDivision셋팅
        var $target = $(".imgWrap .imgDivision");
        imgDivisionContainerSet($target);*/
    }

    function tabletThumbPosSet(){
        if(IE_VER < 9 && IE_VER !== false){

        }else{
            if(thumbMaxNum < 7){
                var twidth = thumbMaxNum * thumbLiWidth;
                $thumbContainer.css({"width":twidth, "margin":"0 auto"});
                $(".thumbtn_l, .thumbtn_r").hide();
            }
        }
    }

    function thumbContainerMove(idx){
        var current = thumbMaxNum - viewLiLength;
        if(current < thumbNum){
            thumbNum = current;
            return;
        }
        thumbNum = idx;
        TweenMax.to($thumbContainer, 0.5, {marginLeft: (thumbLiWidth * -idx)-6, ease:"easeOutQuart"});
    }

    //썸네일 클릭시 gallery_view의 imgDivision 보이게 함
    function imgDivisionContainerSet(obj){
        var $container = obj,
        $prevBtn = $container.find(".btn_l > a"),
        $nextBtn = $container.find(".btn_r > a"),
        $pageBtn = $container.find(".pg_btn_area .pg_btn"),
        $imgContainer = $container.find(".imgArea"),
        imgMaxNum = $container.find(".pg_btn_area .pg_btn").length,
        currentImgNum = 0,
        ratio = 768 / 440,
        imgWidth = $imgContainer.find("li").width();

        $imgContainer.off();
        imgMove(0,0);

        $prevBtn.off().on("click", function(e){
            e.stopPropagation();
            e.preventDefault();
            var idx = currentImgNum - 1;
            if (idx < 0) {idx = 0;}
            imgMove(idx);
        });

        $nextBtn.off().on("click", function(e){
            e.stopPropagation();
            e.preventDefault();
            var idx = currentImgNum + 1;
            if (idx > imgMaxNum-1) {idx = imgMaxNum-1;}
            imgMove(idx);
        });

        $pageBtn.off().on("click", function(e){
            e.stopPropagation();
            e.preventDefault();
            var idx = $(this).index();
            imgMove(idx);
        });

        var imgSwipe = new onSwipeFnc($imgContainer);
        imgSwipe.moveEnd = function(evt, dir, phase, swipetype, distance) {
            if (phase == "end") {
                if (dir == "right") {
                    $prevBtn.trigger("click");
                } else if (dir == "left") {
                    $nextBtn.trigger("click");
                }
            }
        };

        function imgMove(idx, duration){
            if(typeof duration == "undefined"){duration =0.7;}
            $pageBtn.removeClass("pg_btn_on");
            $pageBtn.eq(idx).addClass("pg_btn_on");
            $pageBtn.removeAttr("title");
            $pageBtn.eq(idx).attr("title","selected");

			/* 2019.04.22 */
            if(imgWidth == 0)
            {
                imgWidth = 768;
            }

            TweenMax.to($imgContainer, duration, {marginLeft: (imgWidth * -idx), ease:"easeOutQuart"});
            currentImgNum = idx;
        }

        var lastWindowHeight = 800, lastWindowWidth = 800;
        $(window).resize(function() {
            if ($(window).height() != lastWindowHeight || $(window).width() != lastWindowWidth) {
                lastWindowHeight = $(window).height();
                lastWindowWidth = $(window).width();
                imgContainerResize();
            }
        }).resize();

        function imgContainerResize() {
            document.body.style.overflow = "hidden";
            var viewportWidth = $(window).width();
            document.body.style.overflow = "";
            if(IE_VER < 9 && IE_VER !== false){

            }else{
                //모바일 사이즈 일때 li width,height값 변경
                if (viewportWidth < 767) {
                    $imgContainer.css("height",viewportWidth/ratio);
                    $imgContainer.find("li").css("width", viewportWidth);
                    imgWidth = $imgContainer.find("li").width();
                } else {
                    $imgContainer.css("height", "");
                    $imgContainer.find("li").css("width", "");
                    imgWidth = $imgContainer.find("li").width();
                }
                TweenMax.killTweensOf($imgContainer);
                imgMove(currentImgNum, 0);
            }
        }
    }

    function exkiaGalleryResize() {
        document.body.style.overflow = "hidden";
        viewportWidth = $(window).width();
        document.body.style.overflow = "";
        if(IE_VER < 9 && IE_VER !== false){

        }else{
            if (viewportWidth > 1120) {
                TweenMax.killTweensOf($thumbContainer);
                $thumbContainer.css({"width":"", "margin":"","margin-left": ""});
            } else if (viewportWidth < 1120 && viewportWidth > 767) {
                thumbLiWidth = $(".thumnail > li").width()+10;
                thumbContainerMove(thumbNum);
                tabletThumbPosSet();
            } else {
                TweenMax.killTweensOf($thumbContainer);
                $thumbContainer.css({"width":"", "margin":"","margin-left": ""});
            }
        }
    }
};


var exPromotionGalleryInit = function(){
    var viewportWidth, lastWindowWidth = 800, lastWindowHeight = 800, $thumbContainer = $(".promotionCon .thumnail"),
    $promotionUlContainer = $(".promotion_view > ul"), $imgContainer = $(".promotion_view > ul > li .imgArea"),
    thumbNum = 0, thumbMaxNum = $(".thumnail > li").length, thumbLiWidth = $(".thumnail > li").width()+10, viewLiLength =6 ,
    imgLiWidth = $imgContainer.parent().width(), currentViewNum = 0 ,ratio = 768 / 440;

    thumbAltSet();

    //페이지 버튼 중앙정렬
    $(".pg_btn_area").css("margin-left", $(".pg_btn").length/2 *-14);

    //썸네일 좌측버튼
    $(".promotionCon").on("click", ".thumbtn_l > a", function(e) {
        e.stopPropagation();
        e.preventDefault();
        thumbNum = thumbNum - 1;
        if (thumbNum < 0) {thumbNum = 0;}
        thumbContainerMove(thumbNum);
    });

    //썸네일 우측버튼
    $(".promotionCon").on("click", ".thumbtn_r > a", function(e) {
        e.stopPropagation();
        e.preventDefault();
        thumbNum = thumbNum + 1;
        if (thumbNum > thumbMaxNum - 1) {thumbNum = thumbMaxNum - 1;}
        thumbContainerMove(thumbNum);
    });

    //썸네일 클릭
    $(".promotionCon").on("click", ".thumnail li > a", function(e) {
        e.stopPropagation();
        e.preventDefault();
        var idx = $(this).parent().index();
        viewImgContainerMove(idx);
		$(this).parent().addClass('tab_on').siblings().removeClass('tab_on');
    });


    //갤러리 버튼
    $(".promotion_view").on("click", ".pg_btn_area .pg_btn", function(e) {
        e.stopPropagation();
        e.preventDefault();
        var idx = $(this).index();
        $(".promotionCon ul.thumnail li:eq("+idx+") > a").trigger("click");
    });

    //갤러리 좌측버튼
    $(".promotionCon").on("click", ".btn_l > a", function(e) {
        e.stopPropagation();
        e.preventDefault();
        currentViewNum = currentViewNum - 1;
        if (currentViewNum < 0) {currentViewNum = 0;}
        viewImgContainerMove(currentViewNum);
    });

    //썸네일 우측버튼
    $(".promotionCon").on("click", ".btn_r > a", function(e) {
        e.stopPropagation();
        e.preventDefault();
        currentViewNum = currentViewNum + 1;
        if (currentViewNum > thumbMaxNum - 1) {currentViewNum = thumbMaxNum - 1;}
        viewImgContainerMove(currentViewNum);
    });

    //썸네일 마우스 오버
    $(".promotionCon").on("mouseenter", ".thumnail li > a", function(e) {
        e.stopPropagation();
        e.preventDefault();
        $(this).find("span.off").addClass("on");
    });

    //썸네일 마우스 아웃
    $(".promotionCon").on("mouseleave", ".thumnail li > a", function(e) {
        e.stopPropagation();
        e.preventDefault();
        if (!$(this).closest('li').hasClass("tab_on")) {
            $(this).find("span.off").removeClass("on");
        }
    });

    var promtionImgSwipe = new onSwipeFnc($imgContainer);
    promtionImgSwipe.moveEnd = function(evt, dir, phase, swipetype, distance) {
        if (phase == "end") {
            if (dir == "right") {
                $(".promotionCon .btn_l > a").trigger("click");
            } else if (dir == "left") {
                $(".promotionCon .btn_r > a").trigger("click");
            }
        }
    };
    $(window).resize(function() {
        if ($(window).height() != lastWindowHeight || $(window).width() != lastWindowWidth) {
            lastWindowHeight = $(window).height();
            lastWindowWidth = $(window).width();
            promotionGalleryResize();
        }
    }).resize();

    function thumbAltSet(){
        $(".thumnail li").each(function(i,e){
            var carName = $(this).find(".carName").text();
            $(this).find(".imgArea img").attr("alt",carName);
        });
    }

    function tabletThumbPosSet(){
        if(IE_VER < 9 && IE_VER !== false){

        }else{
            if(thumbMaxNum < 7){
                var twidth = thumbMaxNum * thumbLiWidth;
                $thumbContainer.css({"width":twidth, "margin":"0 auto"});
                $(".thumbtn_l, .thumbtn_r").hide();
            }
        }
    }
    //타블렛일때 썸네일 이동
    function thumbContainerMove(idx){
        var current = thumbMaxNum - viewLiLength;
        if(current < thumbNum){
            thumbNum = current;
            return;
        }
        thumbNum = idx;
        TweenMax.to($thumbContainer, 0.5, {marginLeft: (thumbLiWidth * -idx)-6, ease:"easeOutQuart"});
    }

    //이미지 이동
    function viewImgContainerMove(idx){
        $(".promotionCon .thumnail li > a span.off").removeClass("on");
        $(".promotionCon .thumnail li:eq("+idx+") > a span.off").addClass("on");
        $(".promotion_view .pg_btn_area .pg_btn").removeClass("pg_btn_on");
        $(".promotion_view .pg_btn_area .pg_btn").eq(idx).addClass("pg_btn_on");
        TweenMax.to($promotionUlContainer, 0.5, {marginLeft: (imgLiWidth * -idx), ease:"easeOutQuart"});
        currentViewNum = idx;
    }

    function promotionGalleryResize(){
        document.body.style.overflow = "hidden";
        viewportWidth = $(window).width();
        document.body.style.overflow = "";
        if(IE_VER < 9 && IE_VER !== false){

        }else{
            if (viewportWidth > 1120) {
                TweenMax.killTweensOf($imgContainer);
                TweenMax.killTweensOf($thumbContainer);
                $imgContainer.css("height", "");
                $imgContainer.parent().css("width", "");
                $(".btn_l , .btn_r").css("top", "");
                $(".pg_btn_area").css("top", "");
                imgLiWidth = $imgContainer.parent().width();
                $thumbContainer.css({"width":"", "margin":"","margin-left": ""});
            } else if (viewportWidth < 1120 && viewportWidth > 767) {
                thumbLiWidth = $(".thumnail > li").width()+10;
                thumbContainerMove(thumbNum);
                $imgContainer.css("height", "");
                $imgContainer.parent().css("width", "");
                $(".btn_l , .btn_r").css("top", "");
                $(".pg_btn_area").css("top", "");
                imgLiWidth = $imgContainer.parent().width();

                tabletThumbPosSet();
            } else {

                TweenMax.killTweensOf($imgContainer);
                TweenMax.killTweensOf($thumbContainer);
                $imgContainer.css("height",viewportWidth/ratio);
                $imgContainer.parent().css("width", viewportWidth);
                $thumbContainer.css({"width":"", "margin":"","margin-left": ""});
                imgLiWidth = $imgContainer.parent().width();
                $(".btn_l , .btn_r").css("top", (viewportWidth/ratio)/2);
                $(".pg_btn_area").css("top", (viewportWidth/ratio)-20);
            }
            viewImgContainerMove(currentViewNum);
        }
    }
};

var exPromotionPlayPopupInit = function (){
    var dimPop = new OpenDimPop($(".popup_wrap02"));

    //프로모션 유투브 팝업 클릭 이벤트
    $(".promotion_play > a").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        var videoTitle = $(this).find(".videoTit").text();
        var videoText = $(this).find(".videoTxt").text();
        $(".popup_wrap02 .img_more dt").text(videoTitle);
        $(".popup_wrap02 .img_more dd").text(videoText);
        dimPop.open();
    });
};


// @GRO5 2016-08-11 award_list 기존 소스 주석 처리함.
/* var exAwardInit = function(){
    var dimPop = new OpenDimPop($(".popup_wrap"));
    $(".award_list").on("click", "ul.list li > a", function(e) {
        e.preventDefault();
        $(".popup_wrap .pop_tit").text($(this).find("strong").text());
        $(".popup_wrap .award_con img").attr("src",$(this).find("img").attr("src"));
        $(".popup_wrap .award_con img").attr("alt",$(this).find("img").attr("alt"));
        $(".popup_wrap .award_txt").text($(this).find(".hidden").text());
        dimPop.open();
    });
}; */


// @GRO5 2016-08-11 award_list 수정
var exAwardInit = function(){
    var dimPop = new OpenDimPop($(".popup_wrap"));

    $(".award_list").on("click", "ul.list li > a", function(e) {
		var parent = $(this).closest("ul");
		var awardDesc = $(this).find(".award_desc").html(); // award 내용
		var reviewURL = $(this).find(".reivew_url").text(); // review URL
        e.preventDefault();

		if($(parent).hasClass("type_award_list")){
			$(".popup_wrap .award_txt").empty();
			$(".popup_wrap .award_txt").append(awardDesc);
			if (reviewURL == ".html" || reviewURL == "") {
				$(".popup_wrap .btn_area a").hide();
			} else {
				$(".popup_wrap .btn_area a").show();
				$(".popup_wrap .btn_area a").attr("href", reviewURL);
			}
		} else {
			$(".popup_wrap .award_txt").text($(this).find(".award_tit").text());
		};

		$(".popup_wrap .pop_tit").text($(this).find("strong").text());
        $(".popup_wrap .award_con img").attr("src",$(this).find("img").attr("src"));
        $(".popup_wrap .award_con img").attr("alt",$(this).find("img").attr("alt"));
        dimPop.open();
    });
};

var exSocialMediaInit = function(){
    $(".thBox a").on("mouseenter",  function(e) {
        e.stopPropagation();
        e.preventDefault();
        var target = $(this).find("span.over");
        TweenMax.to(target, 0.4, {left : "0%" ,ease : "easeInOutSine"});
    });

    $(".thBox a").on("mouseleave", function(e) {
        e.stopPropagation();
        e.preventDefault();
        var target = $(this).find("span.over");
        TweenMax.to(target, 0.4, {left : "-100%" ,ease : "easeInOutSine"});
    });
};

var exSafetyInit = function(){
    //드래그 셋팅
    exDragMaskSet(".car_body");
    //갤러리 셋팅
    exImgGallerySet(".eximg_slider", 940 , 504);
};

//wddo experience/tv/tv-commercial-video
var exTvListInit = function () {
    var listLen = $('.tvCon .tvList > ul > li').length;

    var totalSPAN = $('.tvCon .tvTop > span');
    var txt = totalSPAN.text();
    var totalStr = txt.substr(0, txt.indexOf(':') + 1);

    totalSPAN.text(totalStr + ' ' + listLen);
};

//wddo experience/tv/tv-commercial-video-detail
var exTvDetailInit = function() {


    var containerDIV = $('.tvCon');                             //컨테이너
    var listUL = containerDIV.find('.imgArea');                 //리스트 UL
    var listLI = listUL.find('> li')                            //리스트 LI
    var listVideoDIV = listLI.find('div.movie');                //리스트 iframe 감싸는 DIV
    var listMaskDIV = containerDIV.find('.slider_tv')           //마스킹 DIV
    var discriptionDIV = containerDIV.find('.tvcarTxt');        //설명 DIV
    var discriptionOpenA = discriptionDIV.find('.movie_explain > a');   //설명 열고닫는 버튼
    var leftBtn = containerDIV.find('button.btn_l');            //왼쪽 버튼
    var rightBtn = containerDIV.find('button.btn_r');           //오른쪽 버튼
    var pageSPAN = containerDIV.find('.tvdetailTop > span');    //페이징 SPAN

    var maxLen = listLI.length;                                 //아이템 갯수
    var act = parseInt($(".tvdetailTop em").text());			//활성화 넘버
    //var act = index;                                                //활성화 넘버
    var speed = 350;                                            //아이템 트렌지션 속도

    var maskWidth = listMaskDIV.outerWidth();                   //마스크 width
    var itemWidth = listLI.outerWidth();                        //아이템 width

    var itemMargin = parseInt(listLI.css('marginLeft'));        //아이템 여백 .. 100
    var itemDistance = parseInt(listLI.css('marginRight'));     //아이템 간격 .. 20
    var MARGIN_PAGELEFT = 14;                                   //좌측 페이지 간격
    var RANGE_TABLE_WIDTH = 1120;                               //리사이징 시점 타블릿 width
    var RANGE_MOBILE_WIDTH = 767;                               //리사이징 시점 모바일 width

    var browserWidth;                                           //브라우저 width
    var videoHeight;                                            //비디오 height
    var lastWindowHeight = 800, lastWindowWidth = 800;



    //init
    init();

    function init() {
        initLayout();
        addEvent();
        resize();
    }

    //레이아웃 초기화
    function initLayout() {
        discriptionOpenA.next().css('width', 'auto');

        changeDiscription();
        changePage();
    }

    //이벤트
    function addEvent() {
        //왼쪽 화살표
        leftBtn.on('click', function (e) {
            act -= 1;

            if (act < 0) act = 0;

            changeDiscription();
            changePage();

            move();

            e.preventDefault();
        });

        //오른쪽 화살표
        rightBtn.on('click', function (e) {
            act += 1;

            if (act > maxLen - 1) act = maxLen - 1;

            changeDiscription();
            changePage();

            move();

            e.preventDefault();
        });

        //설명 열고닫는 버튼
        discriptionOpenA.on('click', function (e) {
            var target = $(e.currentTarget);

            target.closest('.movie_explain').toggleClass('on');

            e.preventDefault();
        });

        //리사이징
        $(window).on('resize', function() {
            if ($(window).height() != lastWindowHeight || $(window).width() != lastWindowWidth) {
                lastWindowHeight = $(window).height();
                lastWindowWidth = $(window).width();
                if (IE_VER < 9 && IE_VER !== false) {

                } else {
                    resize();
                }
            }
        });
    }

    //변경 설명
    function changeDiscription() {
        discriptionDIV.hide().eq(act).show();
        discriptionOpenA.closest('.movie_explain').removeClass('on');
    }

    //변경 페이징
    function changePage() {
        pageSPAN.html('<em>' + (act + 1) + '</em>/' + maxLen);
    }

    //리스트 트렌지션
    function move() {
    	//유투브 재생정지 03.26추가
		$(".movie iframe").each(function(i,e){
			var iframe = $(this)[0].contentWindow;
			iframe .postMessage('{"event":"command","func":"pauseVideo","args":""}', '*');
		});

        listUL.animate({
            'marginLeft' : -(itemWidth + itemDistance) * act
        }, {queue:false, duration:speed})
    }

    //브라우저 리사이징
    function resize() {
        //browserWidth = window.innerWidth || $(document).width();
        browserWidth = $(window).width() - (MARGIN_PAGELEFT * 2);

        itemMargin = parseInt(listLI.css('marginLeft'));
        itemDistance = parseInt(listLI.css('marginRight'));

        if (browserWidth <= RANGE_TABLE_WIDTH) {
            //한계치보다 작아지면
            itemWidth = browserWidth - (itemMargin * 2);                            //아이템 1개의 크기 = 브라우저 가로크기 - 양쪽 마진
            maskWidth = getLinearFunction(0, RANGE_TABLE_WIDTH, 0, 1120, browserWidth);   //마스킹 크기 계산
            videoHeight = getLinearFunction(0, 920, 0, 520, itemWidth);             //가로에 세로 비율 맞추기
        } else {
            itemWidth = 920;
            maskWidth = 1120;
            videoHeight = 520;
        }

        listLI.css('width', itemWidth);                                 //비디오 가로 크기
        listVideoDIV.css('height', videoHeight);                        //비디오 세로 크기

        listMaskDIV.css('width', maskWidth);                            //전체 마스킹 (오른쪽 화살표 위치 영향) 크기 재조정
        listUL.css('marginLeft', (-(itemWidth + itemDistance) * act));  //화살표에 따른 리스트 트렌지션 재정렬

        leftBtn.add(rightBtn).css('top', videoHeight / 2);              //양쪽 화살표 세로 중앙정렬

        listLI.add(listUL).add(listMaskDIV).css('height', videoHeight + (676 - 520));
    }

    //리스트 변경에 따른 리셋 함수
    function reset() {
        listLI = listUL.find('> li');
        listVideoDIV = listLI.find('div.movie');

        maxLen = listLI.length;
        discriptionDIV = containerDIV.find('.tvcarTxt');
        discriptionOpenA = discriptionDIV.find('.movie_explain > a');
    }

    function getLinearFunction(a, b, c, d, x) {
        return (d - c) / (b - a) * (x - a) + c;
    }
};

var exScrollMotionInit = function(){
    var lastWindowHeight=800, lastWindowWidth = 800;
    $(window).resize(function() {
        if ($(window).height() != lastWindowHeight || $(window).width() != lastWindowWidth) {
            lastWindowHeight = $(window).height();
            lastWindowWidth = $(window).width();
            $(window).scroll();
        }
    })

    $(window).scroll(function(screvent) {
        var scrollTop = $(window).scrollTop();
        var winHeight = $(window).height();
        var winWidth = $(window).width();
        $(".d-onScreen").each(function(i, e) {
            if($(this).hasClass("js-onSceen-animateend"))return;

            var elemTop = $(this).offset().top -winHeight;
            var elemBottom = elemTop + $(this).outerHeight();
            var scrollBottom = scrollTop - winHeight
            var isScrollView = (elemTop <= scrollTop && elemBottom >= scrollBottom);
            var use3D = false;
            if(winWidth <= MOBILE_WIDTH){
                use3D = true;
            }
            //console.log(elemTop,elemBottom,scrollBottom,isScrollView)
            $(this).css({"position":"relative","opacity":0,"top":150});
            if(isScrollView){
               if(!$(this).hasClass("js-onSceen-animateend")){
                    var self = $(this);
                    function exScrollTweenEnd(){
                        //console.log(self);
                        self.css({"position":"","opacity":"","top":"", "transform":""});
                    }
                    //$(this).css("position","relative");
                    //TweenMax.fromTo($(this), 0.8, {top:150, opacity:0}, {top:0, force3D:use3D, opacity:1});
                    TweenMax.to($(this), 0.8, {top:0, force3D:use3D, opacity:1, onComplete:exScrollTweenEnd});
                    $(this).addClass("js-onSceen-animateend");

                }
            }
        });
    }).scroll();
};

function exDragMaskSet(obj){
    var $container = $(obj);
    var $dragBtn = $container.find(".btn_handle"), $carMove = $container.find(".carMove"),
    $maskImg = $container.find(".carMove .car_back"), $frontBtn = $container.find(".control_btn button.btnFront"),
    $backBtn = $container.find(".control_btn button.btnBack"), posArr = ["3%", "50%", "97%"], posxPercent;

    //마스크 마우스 드래그이벤트
    $dragBtn.find("button").on("mousedown", function(e) {
        $carMove.on("mousemove", function(event) {
            var posX = event.pageX - $(this).offset().left;
            posxPercent = 100 - Math.floor((posX / $carMove.width() * 100));
            if (posxPercent < 3 || posxPercent > 97) {return;}
            $dragBtn.css("right", posxPercent + "%");
            $maskImg.css("width", posxPercent + "%");
        });
    });

    //마스크 마우스 터치이벤트
    $dragBtn.find("button").on("touchstart", function(e) {
        e.preventDefault();
        $carMove.on("touchmove", function(event) {
            var posX = event.originalEvent.touches[0].pageX - $(this).offset().left
            posxPercent = 100 - Math.floor((posX / $carMove.width() * 100));
            if (posxPercent < 3 || posxPercent > 97) {return;}
            $dragBtn.css("right", posxPercent + "%");
            $maskImg.css("width", posxPercent + "%");
        });
    });

    //마스크 키보드 이벤트
    $dragBtn.find("button").on("focusin", function(e) {
       $(this).bind("keydown", function(e){
           var code = e.keyCode || e.which;
           if(code == 37){
               $frontBtn.trigger("click");
           }else if(code == 39){
               $backBtn.trigger("click");
           }
       });
    });

    $(document).on("mouseup", function(e) {
        $carMove.off();
    });

    $(document).on("touchend", function(e) {
        $carMove.off();
    });

    //view front 버튼 클릭 이벤트
    $frontBtn.on("click",  function(e) {
        e.stopPropagation();
        e.preventDefault();
        var mWidth = parseInt($maskImg.css("width"));
        var cWidth = parseInt($carMove.width()/2);
        var posArrIndex = 0;
        if(mWidth < cWidth){
            posArrIndex = 1;
        }else{
            posArrIndex = 2;
        }
        dragMaskPosSet(posArrIndex);
    });

    //view back 버튼 클릭 이벤트
    $backBtn.on("click", function(e) {
        e.stopPropagation();
        e.preventDefault();
        var mWidth = parseInt($maskImg.css("width"));
        var cWidth = parseInt($carMove.width()/2);
        var posArrIndex = 0;
        if(mWidth > cWidth){
            posArrIndex = 1;
        }else{
            posArrIndex = 0;
        }
        dragMaskPosSet(posArrIndex);
    });

    //마스크 넓이 변경
    function dragMaskPosSet(idx){
        TweenMax.to($dragBtn, 0.5, {right : posArr[idx], ease : "easeOutQuart"});
        TweenMax.to($maskImg, 0.5, {width : posArr[idx], ease : "easeOutQuart"});
    }
};


//ex쪽 갤러리 적용 스크립트
function exImgGallerySet(obj, defalutWidth, defaultHeight){
    var lastWindowHeight = 800, lastWindowWidth = 800;
    var $container = $(obj),
        $prevBtn = $container.find("button.btn_l"),
        $nextBtn = $container.find("button.btn_r"),
        $pageBtn = $container.find(".pg_btn_area .pg_btn"),
        $pageBtnContainer = $container.find(".pg_btn_area"),
        $imgContainer = $container.find(".imgArea"),
        imgMaxNum = $container.find(".pg_btn_area .pg_btn").length,
        currentImgNum = 0,
        ratio = defalutWidth / defaultHeight,
        imgWidth = $(obj).width();
        $pageBtnContainer.css("margin-top",0);
        $imgContainer.css({"width":(imgWidth * imgMaxNum),"overflow":"hidden"});
        $imgContainer.find("li").css("float","left");

    $imgContainer.off();
    imgMove(0,0);

    $prevBtn.off().on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        var idx = currentImgNum - 1;
        if (idx < 0) {idx = 0;}
        imgMove(idx);
    });

    $nextBtn.off().on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        var idx = currentImgNum + 1;
        if (idx > imgMaxNum-1) {idx = imgMaxNum-1;}
        imgMove(idx);
    });

    $pageBtn.off().on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        var idx = $(this).index();
        imgMove(idx);
    });


    var imgSwipe = new onSwipeFnc($imgContainer);
    imgSwipe.moveEnd = function(evt, dir, phase, swipetype, distance) {
        if (phase == "end") {
            if (dir == "right") {
                $prevBtn.trigger("click");
            } else if (dir == "left") {
                $nextBtn.trigger("click");
            }
        }
    };

    function imgMove(idx, duration) {
        if ( typeof duration == "undefined") {duration = 0.7;}
        $pageBtn.removeClass("pg_btn_on");
        $pageBtn.eq(idx).addClass("pg_btn_on");
        $pageBtn.removeAttr("title");
        $pageBtn.eq(idx).attr("title", "selected");
        TweenMax.to($imgContainer, duration, {marginLeft : (imgWidth * -idx),ease : "easeOutQuart"});
        var liHeight = $imgContainer.find("li:eq("+idx+")").height();
        $imgContainer.css("height", liHeight);
        currentImgNum = idx;
    }

    $(window).resize(function() {
        if ($(window).height() != lastWindowHeight || $(window).width() != lastWindowWidth) {
            lastWindowHeight = $(window).height();
            lastWindowWidth = $(window).width();
            exGalleryResize();
        }
    }).resize();

    function exGalleryResize() {
        document.body.style.overflow = "hidden";
        var viewportWidth = $(window).width();
        document.body.style.overflow = "";
        if (IE_VER < 9 && IE_VER !== false) {
                $nextBtn.css("top", (defalutWidth/ratio)/2 );
                $prevBtn.css("top", (defalutWidth/ratio)/2 );
                $pageBtnContainer.css("top", (defalutWidth/ratio)-20);
                imgWidth = $container.width();
                $imgContainer.css({"width":(imgWidth * imgMaxNum)});
                $imgContainer.find("li").css("width", imgWidth);
                $imgContainer.find("li img").css("width", imgWidth);
                TweenMax.killTweensOf($imgContainer);
                imgMove(currentImgNum, 0);
        } else {
             if (viewportWidth > 985) {
                $nextBtn.css("top", (defalutWidth/ratio)/2 );
                $prevBtn.css("top", (defalutWidth/ratio)/2 );
                $pageBtnContainer.css("top", (defalutWidth/ratio)-30);
            } else if (viewportWidth < 984 && viewportWidth > 767) {
                $nextBtn.css("top", (viewportWidth/ratio)/2 -20);
                $prevBtn.css("top", (viewportWidth/ratio)/2 -20);
                $pageBtnContainer.css("top", (viewportWidth/ratio)-60);
            } else {
                $nextBtn.css("top", (viewportWidth/ratio)/2 );
                $prevBtn.css("top", (viewportWidth/ratio)/2 );
                $pageBtnContainer.css("top", (viewportWidth/ratio)-40);
            }
            //리사이즈 일때 li width값 변경
            imgWidth = $container.width();

            $imgContainer.css({"width":(imgWidth * imgMaxNum)});
            $imgContainer.find("li").css("width", imgWidth);
            $imgContainer.find("li img").css("width", imgWidth);
            TweenMax.killTweensOf($imgContainer);
            imgMove(currentImgNum, 0);
        }
    }
}

var exFilm = function () {
    var dimPop1 = new OpenDimPop($("#film01"), $("#film01 .pop_con"));

    $("button.campaign_play:eq(0)").on("click", function (e) {
        dimPop1.open();
    });
};

var exCampaign = function () {
    var dimPop1 = new OpenDimPop($("#campaign01"), $("#campaign01 .pop_con"));
    var dimPop2 = new OpenDimPop($("#campaign02"), $("#campaign02 .pop_con"));

    $("button.campaign_play:eq(0)").on("click", function (e) {
        dimPop1.open();
    });

    $("button.campaign_play:eq(1)").on("click", function (e) {
        dimPop2.open();
    });
};

var exRoadTrip = function () {
    var dimPop1 = new OpenDimPop($("#roadtrip01"), $("#roadtrip01 .pop_con"));
    var dimPop2 = new OpenDimPop($("#roadtrip02"), $("#roadtrip02 .pop_con"));
    var dimPop3 = new OpenDimPop($("#roadtrip03"), $("#roadtrip03 .pop_con"));
    var dimPop4 = new OpenDimPop($("#roadtrip04"), $("#roadtrip04 .pop_con"));

    $("button.campaign_play:eq(0)").on("click", function (e) {
        dimPop1.open();
    });

    $("button.campaign_play:eq(1)").on("click", function (e) {
        dimPop2.open();
    });

    $("button.campaign_play:eq(2)").on("click", function (e) {
        dimPop3.open();
    });

    $("button.campaign_play:eq(3)").on("click", function (e) {
        dimPop4.open();
    });
};

var exDesign = function () {
    var dimPop1 = new OpenDimPop($("#design01"), $("#design01 .pop_con"));

    $("button.campaign_play:eq(0)").on("click", function (e) {
        dimPop1.open();
    });
};

var exGearUp = function () {
    var dimPop1 = new OpenDimPop($("#gearup01"), $("#gearup01 .pop_con"));
    var dimPop2 = new OpenDimPop($("#gearup02"), $("#gearup01"));
    var dimPop3 = new OpenDimPop($("#gearup03"), $("#gearup03 .pop_con"));
    var dimPop4 = new OpenDimPop($("#gearup04"), $("#gearup04 .pop_con"));
    var dimPop5 = new OpenDimPop($("#gearup05"), $("#gearup05 .pop_con"));

    $("button.campaign_play:eq(0)").on("click", function (e) {
        dimPop1.open();
    });

    $("button.campaign_play:eq(1)").on("click", function (e) {
        dimPop2.open();
    });

    $("button.campaign_play:eq(2)").on("click", function (e) {
        dimPop3.open();
    });

    $("button.campaign_play:eq(3)").on("click", function (e) {
        dimPop4.open();
    });

    $("button.campaign_play:eq(4)").on("click", function (e) {
        dimPop5.open();
    });
};


var exTasteVideoSlider = function () {
    var containerDIV = $('.brand_video');                       //컨테이너
    var listUL = containerDIV.find('div.imgArea > ul');         //리스트 UL
    var listLI = listUL.find('> li')                            //리스트 LI
    var listVideoDIV = listLI.find('div.movie');                //리스트 iframe 감싸는 DIV
    var listMaskDIV = containerDIV                              //마스킹 DIV
    var discriptionDIV = containerDIV.find('.text');            //설명 DIV
    var discriptionOpenA = discriptionDIV.find('.movie_explain > a');   //설명 열고닫는 버튼
    var leftBtn = containerDIV.find('button.btn_l');            //왼쪽 버튼
    var rightBtn = containerDIV.find('button.btn_r');           //오른쪽 버튼
    var pageDIV = containerDIV.find('.tmbArea');                //페이징

    var maxLen = listLI.length;                                 //아이템 갯수
    var act = 0;                                                //활성화 넘버
    var speed = 350;                                            //아이템 트렌지션 속도

    var maskWidth = listMaskDIV.outerWidth();                   //마스크 width
    var itemWidth = listLI.outerWidth();                        //아이템 width

    var itemDistance = 0;                                       //아이템 간격

    var browserWidth;                                           //브라우저 width
    var videoHeight;                                            //비디오 height
    var lastWindowHeight = 800, lastWindowWidth = 800;

    //init
    init();

    function init() {
        initLayout();
        addEvent();
        resize();
    }

    //레이아웃 초기화
    function initLayout() {
        discriptionOpenA.next().css('width', 'auto');

        changeDiscription();
        changePage();
    }

    //이벤트
    function addEvent() {
        //왼쪽 화살표
        leftBtn.on('click', function (e) {
            act -= 1;

            if (act < 0) act = 0;

            changeDiscription();
            changePage();

            move();

            e.preventDefault();
        });

        //오른쪽 화살표
        rightBtn.on('click', function (e) {
            act += 1;


            if (act > maxLen - 1) act = maxLen - 1;

            changeDiscription();
            changePage();

            move();

            e.preventDefault();
        });

        //섭네일
        pageDIV.on('click', 'a', function (e) {
             var target = $(e.currentTarget);
             var idx = target.closest('li').index();

             act = idx;

             changeDiscription();
             changePage();

             move();

             e.preventDefault();
        });

        //설명 열고닫는 버튼
        discriptionOpenA.on('click', function (e) {
            var target = $(e.currentTarget);

            target.closest('.movie_explain').toggleClass('on');

            e.preventDefault();
        });

        //리사이징
        $(window).on('resize', function() {
            if ($(window).height() != lastWindowHeight || $(window).width() != lastWindowWidth) {
                lastWindowHeight = $(window).height();
                lastWindowWidth = $(window).width();
                if (IE_VER < 9 && IE_VER !== false) {

                } else {
                    resize();
                }
            }
        });
    }

    //변경 설명
    function changeDiscription() {
        discriptionDIV.hide().eq(act).show();
        discriptionOpenA.closest('.movie_explain').removeClass('on');
    }

    //변경 페이징
    function changePage() {
        pageDIV.find('li').removeClass('on').eq(act).addClass('on');
    }

    //리스트 트렌지션
    function move() {
    	//유투브 재생정지 03.26추가
		$(".movie iframe").each(function(i,e){
			var iframe = $(this)[0].contentWindow;
			iframe .postMessage('{"event":"command","func":"pauseVideo","args":""}', '*');
		});

        listUL.animate({
            'marginLeft' : -(itemWidth + itemDistance) * act
        }, {queue:false, duration:speed})
    }

    //브라우저 리사이징
    function resize() {
        browserWidth = window.innerWidth || $(document).width();

        itemWidth = listLI.outerWidth();

        listUL.css('marginLeft', (-(itemWidth + itemDistance) * act));  //화살표에 따른 리스트 트렌지션 재정렬
    }

    //리스트 변경에 따른 리셋 함수
    function reset() {
        listLI = listUL.find('> li');
        listVideoDIV = listLI.find('div.movie');

        maxLen = listLI.length;
        discriptionDIV = containerDIV.find('.text');
        discriptionOpenA = discriptionDIV.find('.movie_explain > a');

        pageLI = containerDIV.find('.tmbArea li');
    }

    function getLinearFunction(a, b, c, d, x) {
        return (d - c) / (b - a) * (x - a) + c;
    }
};


var myAndroidFix, exSoundSelectIdx = 0; //jplayer 변수
var exSound = function () {
    var galleryDIV = $('.sound_gallery div[id^="sound_gallery"]');

    var gallery;
    galleryDIV.each(function () {
        gallery = new SoundGallery($(this), {});
        gallery.init();

        var iOS = (navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false );
        var isAndroid = (navigator.userAgent.toLowerCase().match(/(android)/g) ? true : false );
        if(isAndroid){
             $(this).find(".bellDown button").eq(1).hide();
        }

        if(iOS){
             $(this).find(".bellDown").hide();
             $(".bellNote").show();
        }else{
            $(".bellNote").hide();
        }
    });




    $('.sound_gallery .form_select').on('change', function (e) {
        var target = $(e.currentTarget);
        var selectIdx = target[0].selectedIndex;

        galleryDIV.hide().eq(selectIdx).show();

        //셀렉트 박스 변경시 음악재생 멈춤
        galleryDIV.find("a.coloring_sound").removeClass('stop');
        galleryDIV.find(".promotion_view ul li .play").fadeOut();
        exSoundSelectIdx = selectIdx;
        myAndroidFix.stop();
    });

	var dimPop1 = new OpenDimPop($("#sound01"), $("#sound01 .pop_con"));

    $("button.campaign_play:eq(0)").on("click", function (e) {
        dimPop1.open();
    });
};


var SoundGallery = (function ($) {
    var wddoObj = function (_taget, _options) {
        var scope,
            $target = _taget,
            defaults = defaultOptions(),
            viewportWidth,
            lastWindowWidth,
            lastWindowHeight,
            $promotionUlContainer,
            $imgContainer,
            $thumbContainer,
            thumbNum,
            thumbMaxNum,
            thumbLiWidth,
            viewLiLength,
            imgLiWidth,
            currentViewNum,
            ratio;

        var id = "#jquery_jplayer_1";
        //실서버 js경로 적용필요
        var options = {
            swfPath: "/content/dam/kwcms/gt/en/music/jquery.jplayer.swf",
            supplied: "mp3",
            wmode: "window",
            useStateClassSkin: true,
            autoBlur: false,
            smoothPlayBar: true,
            keyEnabled: true,
            remainingDuration: true,
            toggleDuration: true
        };

       //실서버  mp3경로 적용필요
       var Vibrant = [{mp3:"/content/dam/kwcms/gt/en/music/v01.mp3"},
            {mp3:"/content/dam/kwcms/gt/en/music/v02.mp3"},
            {mp3:"/content/dam/kwcms/gt/en/music/v03.mp3"},
            {mp3:"/content/dam/kwcms/gt/en/music/v04.mp3"},
            {mp3:"/content/dam/kwcms/gt/en/music/v05.mp3"},
            {mp3:"/content/dam/kwcms/gt/en/music/v06.mp3"},
            {mp3:"/content/dam/kwcms/gt/en/music/v07.mp3"},
            {mp3:"/content/dam/kwcms/gt/en/music/v08.mp3"}];

       var Distinct = [{mp3:"/content/dam/kwcms/gt/en/music/d01.mp3"},
            {mp3:"/content/dam/kwcms/gt/en/music/d02.mp3"},
            {mp3:"/content/dam/kwcms/gt/en/music/d03.mp3"},
            {mp3:"/content/dam/kwcms/gt/en/music/d04.mp3"},
            {mp3:"/content/dam/kwcms/gt/en/music/d05.mp3"},
            {mp3:"/content/dam/kwcms/gt/en/music/d06.mp3"},
            {mp3:"/content/dam/kwcms/gt/en/music/d07.mp3"},
            {mp3:"/content/dam/kwcms/gt/en/music/d08.mp3"}];

        function defaultOptions() {
            return {

            };
        }

        function init () {
            opts = $.extend(defaults, _options);
            lastWindowWidth = 800;
            lastWindowHeight = 800;
            $promotionUlContainer = $target.find(".promotion_view > ul");
            $imgContainer = $target.find(".promotion_view > ul > li .imgArea");
            $thumbContainer = $target.find(".thumnail");
            thumbNum = 0;
            thumbMaxNum = $target.find(".thumnail > li").length;
            thumbLiWidth = $target.find(".thumnail > li").width() + 10;
            viewLiLength = 6;
            imgLiWidth = $imgContainer.parent().width();
            currentViewNum = 0;
            ratio = 768 / 440;

            //페이지 버튼 중앙정렬
            $(".pg_btn_area").css("margin-left", $(".pg_btn").length/2 *-14);

            var promtionImgSwipe = new onSwipeFnc($imgContainer);
            promtionImgSwipe.moveEnd = function(evt, dir, phase, swipetype, distance) {
                if (phase == "end") {
                    if (dir == "right") {
                        $target.find(".btn_l > a").trigger("click");
                    } else if (dir == "left") {
                        $target.find(".btn_r > a").trigger("click");
                    }
                }
            };

            resize();

            $target.data('scope', scope);

           myAndroidFix = new jPlayerAndroidFix(id, Vibrant[0], options);
        };


        //썸네일 클릭
        $target.on("click", ".thumnail li > a", function(e) {
            e.stopPropagation();
            e.preventDefault();
            var idx = $(this).parent().index();
            viewImgContainerMove(idx);
            $target.find(".promotion_view ul li .play").fadeOut();

            //음악재생 정지
            myAndroidFix.stop();
            $(this).parent().siblings().find("a.coloring_sound").removeClass('stop');
            if($(this).hasClass("stop")){
                $(this).removeClass('stop');
            }else{
                if(exSoundSelectIdx == 1){
                    myAndroidFix.setMedia(Distinct[idx]).play();
                }else{
                    myAndroidFix.setMedia(Vibrant[idx]).play();
                }
                $target.find(".promotion_view ul li:eq("+idx+") .play").delay(300).fadeIn(3000);
                $(this).addClass('stop').siblings().removeClass('stop');
            }

            $(this).parent().addClass('tab_on').siblings().removeClass('tab_on');
            //ie8 pseudo버그 수정
            if(IE_VER < 9 && IE_VER !== false) {
                $("a.coloring_sound").trigger("blur");
                $(this).trigger("focus");
            }

        });

        //갤러리 좌측버튼
        $target.find(".promotion_view").on("click", ".btn_l > a", function(e) {
            e.stopPropagation();
            e.preventDefault();
            currentViewNum = currentViewNum - 1;
            if (currentViewNum < 0) {currentViewNum = 0;}
            viewImgContainerMove(currentViewNum);
            $("#jquery_jplayer_1").jPlayer('stop');
            $target.find("a.coloring_sound").removeClass('stop');
            $target.find(".promotion_view ul li .play").fadeOut();
            if(IE_VER < 9 && IE_VER !== false) {
                $("a.coloring_sound").trigger("focus");
                $(this).trigger("focus");
            }
        });

        //썸네일 우측버튼
        $target.find(".promotion_view").on("click", ".btn_r > a", function(e) {
            e.stopPropagation();
            e.preventDefault();
            currentViewNum = currentViewNum + 1;
            if (currentViewNum > thumbMaxNum - 1) {currentViewNum = thumbMaxNum - 1;}
            viewImgContainerMove(currentViewNum);
            $("#jquery_jplayer_1").jPlayer('stop');
            $target.find("a.coloring_sound").removeClass('stop');
            $target.find(".promotion_view ul li .play").fadeOut();
            if(IE_VER < 9 && IE_VER !== false) {
               $("a.coloring_sound").trigger("focus");
               $(this).trigger("focus");
            }
        });

        //썸네일 마우스 오버
        $target.find(".thumnail").on("mouseenter", "li > a", function(e) {
			var iOS = (navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false );
			if(iOS){
				return;
			}
            e.stopPropagation();
            e.preventDefault();
            $(this).find("span.off").addClass("on");
        });

        //썸네일 마우스 아웃
        $target.find(".thumnail").on("mouseleave", ".li > a", function(e) {
			var iOS = (navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false );
			if(iOS){
				return;
			}
            e.stopPropagation();
            e.preventDefault();
            if (!$(this).closest('li').hasClass("tab_on")) {
                $(this).find("span.off").removeClass("on");
            }
        });

        $(window).on("resize", function (e) {
           resize();
        });

        function resize() {
            if ($(window).height() != lastWindowHeight || $(window).width() != lastWindowWidth) {
                lastWindowHeight = $(window).height();
                lastWindowWidth = $(window).width();
                promotionGalleryResize();
            }
        }

        //이미지 이동
        function viewImgContainerMove(idx){
            $target.find(".thumnail li").removeClass("tab_on").eq(idx).addClass("tab_on");
            $target.find(".promotion_view .pg_btn_area .pg_btn").removeClass("pg_btn_on");
            $target.find(".promotion_view .pg_btn_area .pg_btn").eq(idx).addClass("pg_btn_on");
            TweenMax.to($promotionUlContainer, 0.5, {marginLeft: (imgLiWidth * -idx), ease:"easeOutQuart"});
            currentViewNum = idx;

             if (IE_VER < 9 && IE_VER !== false) {
                $("a.coloring_sound").trigger("blur");
            }
        }


        function promotionGalleryResize(){
            document.body.style.overflow = "hidden";
            viewportWidth = $(window).width();
            document.body.style.overflow = "";
            if(IE_VER < 9 && IE_VER !== false){

            }else{
                if (viewportWidth > 1120) {

                } else if (viewportWidth < 1120 && viewportWidth > 767) {

                } else {
                    TweenMax.killTweensOf($imgContainer);
                    TweenMax.killTweensOf($thumbContainer);
                    $imgContainer.parent().css("width", viewportWidth);
                    imgLiWidth = $imgContainer.parent().width();
                }

                viewImgContainerMove(currentViewNum);
            }
        }

        //public
        this.init = function () {
            scope = this;

            if ($target.length === 0) return;

            init() ;
        };
    };//end Obj

    return wddoObj;
}(jQuery));


var exSeqInit = function(){
   var seqArr = [61,31,61,76], seqframes=[], seqframes1 = [], seqframes2 = [], seqframes3 = [], seqframes4 = [], loaderimg;
   $(".seq_btn ul li > a").on("click", function(e){
        e.stopPropagation();
        e.preventDefault();
        var idx = $(this).parent().index();
        $(".seq_con.current").removeClass("current");
        $(".seq_con").eq(idx).addClass("current");
        seqLoad(idx);
   });

   //실서버 적용시 이미지 실제경로로 변경 필요
   seqImgInit();
   function seqImgInit(){
       for(var i=0; i < 62; i++){
            var url1 = "/content/dam/kwcms/gt/en/images/experience/sequence/drivemode1/drivemode1_"+i+".jpg";
            var url3 = "/content/dam/kwcms/gt/en/images/experience/sequence/drivemode3/drivemode3_"+i+".jpg";
            seqframes1.push(url1);
            seqframes3.push(url3);
        }
       for(var i=0; i < 32; i++){
            var url2 = "/content/dam/kwcms/gt/en/images/experience/sequence/drivemode2/drivemode2_"+i+".jpg";
            seqframes2.push(url2);
        }
       for(var i=0; i < 77; i++){
            var url4 = "/content/dam/kwcms/gt/en/images/experience/sequence/drivemode4/drivemode4_"+i+".jpg";
            seqframes4.push(url4);
        }
        var loaderimgUrl = "/content/dam/kwcms/gt/en/images/experience/sequence/loading.gif";
        loaderimg = $("<div id='exseqload'><img src='"+loaderimgUrl+"' alt='' /></div>").css({"position":"absolute","top":"54%","left":"47%"});
        seqframes = [seqframes1,seqframes2,seqframes3,seqframes4];
   }



   function seqLoad(idx){
       TweenMax.killAll();
       if($(".seq_con").eq(idx).hasClass("seqloadComplete")){
           seqPlay(idx);
       }else{
            var k=1,persent;
            $(".seq_con").eq(idx).append(loaderimg);
            $.imgpreload(seqframes[idx],{each: function(){
                    persent = parseInt(k / seqframes[idx].length * 100);
                    k++;
                },
                all: function(){
                    if($(".seq_con").eq(idx).find(".seq_img > img").length < 2){
                        for(var i=1; i < seqframes[idx].length; i++){
                            $(".seq_con").eq(idx).find(".seq_img").append("<img src='"+ seqframes[idx][i]+"' alt='' />");
                            $(".seq_con").eq(idx).find(".seq_img > img").eq(i).css({"position": "absolute", "top": "0px", "left": "0px", "visibility": "hidden"});;
                       }
                    }
                   $("#exseqload").remove();
                   $(".seq_con").eq(idx).addClass("seqloadComplete");
                   seqPlay(idx);
                }
            });
       }
   }

   var timer;
   function seqPlay(idx){
        var startnum = {score : 0};
        var fps = Math.floor(seqArr[idx] / 30);
        TweenMax.to(startnum, fps, {score : seqArr[idx],onUpdate : updateHandler});
        function updateHandler() {
            var seqNum = parseInt(startnum.score);
            $(".seq_con").eq(idx).find(".seq_img > img").eq(0).attr("src", seqframes[idx][seqNum]);
        }

   }

};


var jPlayerAndroidFix = (function($) {
    var fix = function(id, media, options) {
        this.playFix = false;
        this.init(id, media, options);
    };
    fix.prototype = {
        init: function(id, media, options) {
            var self = this;
            // Store the params
            this.id = id;
            this.media = media;
            this.options = options;
            // Make a jQuery selector of the id, for use by the jPlayer instance.
            this.player = $(this.id);
            // Make the ready event to set the media to initiate.
            this.player.bind($.jPlayer.event.ready, function(event) {
                // Use this fix's setMedia() method.
                self.setMedia(self.media);
            });

            // Apply Android fixes
            if($.jPlayer.platform.android) {
                // Fix playing new media immediately after setMedia.
                this.player.bind($.jPlayer.event.progress, function(event) {
                    if(self.playFixRequired) {
                        self.playFixRequired = false;
                        // Enable the contols again
                        // self.player.jPlayer('option', 'cssSelectorAncestor', self.cssSelectorAncestor);
                        // Play if required, otherwise it will wait for the normal GUI input.
                        if(self.playFix) {
                            self.playFix = false;
                            $(this).jPlayer("play");
                        }
                    }
                });
                // Fix missing ended events.
                this.player.bind($.jPlayer.event.ended, function(event) {
                    if(self.endedFix) {
                        self.endedFix = false;
                        setTimeout(function() {
                            self.setMedia(self.media);
                        },0);
                        // what if it was looping?
                    }
                    $("a.coloring_sound").removeClass('stop');
                });
                this.player.bind($.jPlayer.event.pause, function(event) {
                    if(self.endedFix) {
                        var remaining = event.jPlayer.status.duration - event.jPlayer.status.currentTime;
                        if(event.jPlayer.status.currentTime === 0 || remaining < 1) {
                            // Trigger the ended event from inside jplayer instance.
                            setTimeout(function() {
                                self.jPlayer._trigger($.jPlayer.event.ended);
                            },0);
                        }
                    }
                });
            }else{
                this.player.bind($.jPlayer.event.ended, function(event) {
                    $("a.coloring_sound").removeClass('stop');
                    if (IE_VER < 9 && IE_VER !== false) {
                        $("a.coloring_sound").trigger("blur");
                        $(this).trigger("focus");
                    }
                 });
            }

            // Instance jPlayer
            this.player.jPlayer(this.options);

            // Store a local copy of the jPlayer instance's object
            this.jPlayer = this.player.data('jPlayer');

            // Store the real cssSelectorAncestor being used.
            this.cssSelectorAncestor = this.player.jPlayer('option', 'cssSelectorAncestor');

            // Apply Android fixes
            this.resetAndroid();

            return this;
        },
        setMedia: function(media) {
            this.media = media;
            // Apply Android fixes
            this.resetAndroid();
            // Set the media
            this.player.jPlayer("setMedia", this.media);
            return this;
        },
        play: function() {
            // Apply Android fixes
            if($.jPlayer.platform.android && this.playFixRequired) {
                // Apply Android play fix, if it is required.
                this.playFix = true;
				this.player.jPlayer("play");
            } else {
                // Other browsers play it, as does Android if the fix is no longer required.
                this.player.jPlayer("play");
            }
        },
       stop: function() {
            // Apply Android fixes
            if($.jPlayer.platform.android && this.playFixRequired) {
                // Apply Android play fix, if it is required.
                this.playFix = true;
				this.player.jPlayer("stop");
            } else {
                // Other browsers play it, as does Android if the fix is no longer required.
                this.player.jPlayer("stop");
            }
        },
        resetAndroid: function() {
            // Apply Android fixes
            if($.jPlayer.platform.android) {
                this.playFix = false;
                this.playFixRequired = true;
                this.endedFix = true;
                // Disable the controls
                // this.player.jPlayer('option', 'cssSelectorAncestor', '#NeverFoundDisabled');
            }
        }
    };
    return fix;
})(jQuery);
/*! jPlayer 2.9.2 for jQuery ~ (c) 2009-2014 Happyworm Ltd ~ MIT License */
!function(a,b){"function"==typeof define&&define.amd?define(["jquery"],b):b("object"==typeof exports?require("jquery"):a.jQuery?a.jQuery:a.Zepto)}(this,function(a,b){a.fn.jPlayer=function(c){var d="jPlayer",e="string"==typeof c,f=Array.prototype.slice.call(arguments,1),g=this;return c=!e&&f.length?a.extend.apply(null,[!0,c].concat(f)):c,e&&"_"===c.charAt(0)?g:(this.each(e?function(){var e=a(this).data(d),h=e&&a.isFunction(e[c])?e[c].apply(e,f):e;return h!==e&&h!==b?(g=h,!1):void 0}:function(){var b=a(this).data(d);b?b.option(c||{}):a(this).data(d,new a.jPlayer(c,this))}),g)},a.jPlayer=function(b,c){if(arguments.length){this.element=a(c),this.options=a.extend(!0,{},this.options,b);var d=this;this.element.bind("remove.jPlayer",function(){d.destroy()}),this._init()}},"function"!=typeof a.fn.stop&&(a.fn.stop=function(){}),a.jPlayer.emulateMethods="load play pause",a.jPlayer.emulateStatus="src readyState networkState currentTime duration paused ended playbackRate",a.jPlayer.emulateOptions="muted volume",a.jPlayer.reservedEvent="ready flashreset resize repeat error warning",a.jPlayer.event={},a.each(["ready","setmedia","flashreset","resize","repeat","click","error","warning","loadstart","progress","suspend","abort","emptied","stalled","play","pause","loadedmetadata","loadeddata","waiting","playing","canplay","canplaythrough","seeking","seeked","timeupdate","ended","ratechange","durationchange","volumechange"],function(){a.jPlayer.event[this]="jPlayer_"+this}),a.jPlayer.htmlEvent=["loadstart","abort","emptied","stalled","loadedmetadata","canplay","canplaythrough"],a.jPlayer.pause=function(){a.jPlayer.prototype.destroyRemoved(),a.each(a.jPlayer.prototype.instances,function(a,b){b.data("jPlayer").status.srcSet&&b.jPlayer("pause")})},a.jPlayer.timeFormat={showHour:!1,showMin:!0,showSec:!0,padHour:!1,padMin:!0,padSec:!0,sepHour:":",sepMin:":",sepSec:""};var c=function(){this.init()};c.prototype={init:function(){this.options={timeFormat:a.jPlayer.timeFormat}},time:function(a){a=a&&"number"==typeof a?a:0;var b=new Date(1e3*a),c=b.getUTCHours(),d=this.options.timeFormat.showHour?b.getUTCMinutes():b.getUTCMinutes()+60*c,e=this.options.timeFormat.showMin?b.getUTCSeconds():b.getUTCSeconds()+60*d,f=this.options.timeFormat.padHour&&10>c?"0"+c:c,g=this.options.timeFormat.padMin&&10>d?"0"+d:d,h=this.options.timeFormat.padSec&&10>e?"0"+e:e,i="";return i+=this.options.timeFormat.showHour?f+this.options.timeFormat.sepHour:"",i+=this.options.timeFormat.showMin?g+this.options.timeFormat.sepMin:"",i+=this.options.timeFormat.showSec?h+this.options.timeFormat.sepSec:""}};var d=new c;a.jPlayer.convertTime=function(a){return d.time(a)},a.jPlayer.uaBrowser=function(a){var b=a.toLowerCase(),c=/(webkit)[ \/]([\w.]+)/,d=/(opera)(?:.*version)?[ \/]([\w.]+)/,e=/(msie) ([\w.]+)/,f=/(mozilla)(?:.*? rv:([\w.]+))?/,g=c.exec(b)||d.exec(b)||e.exec(b)||b.indexOf("compatible")<0&&f.exec(b)||[];return{browser:g[1]||"",version:g[2]||"0"}},a.jPlayer.uaPlatform=function(a){var b=a.toLowerCase(),c=/(ipad|iphone|ipod|android|blackberry|playbook|windows ce|webos)/,d=/(ipad|playbook)/,e=/(android)/,f=/(mobile)/,g=c.exec(b)||[],h=d.exec(b)||!f.exec(b)&&e.exec(b)||[];return g[1]&&(g[1]=g[1].replace(/\s/g,"_")),{platform:g[1]||"",tablet:h[1]||""}},a.jPlayer.browser={},a.jPlayer.platform={};var e=a.jPlayer.uaBrowser(navigator.userAgent);e.browser&&(a.jPlayer.browser[e.browser]=!0,a.jPlayer.browser.version=e.version);var f=a.jPlayer.uaPlatform(navigator.userAgent);f.platform&&(a.jPlayer.platform[f.platform]=!0,a.jPlayer.platform.mobile=!f.tablet,a.jPlayer.platform.tablet=!!f.tablet),a.jPlayer.getDocMode=function(){var b;return a.jPlayer.browser.msie&&(document.documentMode?b=document.documentMode:(b=5,document.compatMode&&"CSS1Compat"===document.compatMode&&(b=7))),b},a.jPlayer.browser.documentMode=a.jPlayer.getDocMode(),a.jPlayer.nativeFeatures={init:function(){var a,b,c,d=document,e=d.createElement("video"),f={w3c:["fullscreenEnabled","fullscreenElement","requestFullscreen","exitFullscreen","fullscreenchange","fullscreenerror"],moz:["mozFullScreenEnabled","mozFullScreenElement","mozRequestFullScreen","mozCancelFullScreen","mozfullscreenchange","mozfullscreenerror"],webkit:["","webkitCurrentFullScreenElement","webkitRequestFullScreen","webkitCancelFullScreen","webkitfullscreenchange",""],webkitVideo:["webkitSupportsFullscreen","webkitDisplayingFullscreen","webkitEnterFullscreen","webkitExitFullscreen","",""],ms:["","msFullscreenElement","msRequestFullscreen","msExitFullscreen","MSFullscreenChange","MSFullscreenError"]},g=["w3c","moz","webkit","webkitVideo","ms"];for(this.fullscreen=a={support:{w3c:!!d[f.w3c[0]],moz:!!d[f.moz[0]],webkit:"function"==typeof d[f.webkit[3]],webkitVideo:"function"==typeof e[f.webkitVideo[2]],ms:"function"==typeof e[f.ms[2]]},used:{}},b=0,c=g.length;c>b;b++){var h=g[b];if(a.support[h]){a.spec=h,a.used[h]=!0;break}}if(a.spec){var i=f[a.spec];a.api={fullscreenEnabled:!0,fullscreenElement:function(a){return a=a?a:d,a[i[1]]},requestFullscreen:function(a){return a[i[2]]()},exitFullscreen:function(a){return a=a?a:d,a[i[3]]()}},a.event={fullscreenchange:i[4],fullscreenerror:i[5]}}else a.api={fullscreenEnabled:!1,fullscreenElement:function(){return null},requestFullscreen:function(){},exitFullscreen:function(){}},a.event={}}},a.jPlayer.nativeFeatures.init(),a.jPlayer.focus=null,a.jPlayer.keyIgnoreElementNames="A INPUT TEXTAREA SELECT BUTTON";var g=function(b){var c,d=a.jPlayer.focus;d&&(a.each(a.jPlayer.keyIgnoreElementNames.split(/\s+/g),function(a,d){return b.target.nodeName.toUpperCase()===d.toUpperCase()?(c=!0,!1):void 0}),c||a.each(d.options.keyBindings,function(c,e){return e&&a.isFunction(e.fn)&&("number"==typeof e.key&&b.which===e.key||"string"==typeof e.key&&b.key===e.key)?(b.preventDefault(),e.fn(d),!1):void 0}))};a.jPlayer.keys=function(b){var c="keydown.jPlayer";a(document.documentElement).unbind(c),b&&a(document.documentElement).bind(c,g)},a.jPlayer.keys(!0),a.jPlayer.prototype={count:0,version:{script:"2.9.2",needFlash:"2.9.0",flash:"unknown"},options:{swfPath:"js",solution:"html, flash",supplied:"mp3",auroraFormats:"wav",preload:"metadata",volume:.8,muted:!1,remainingDuration:!1,toggleDuration:!1,captureDuration:!0,playbackRate:1,defaultPlaybackRate:1,minPlaybackRate:.5,maxPlaybackRate:4,wmode:"opaque",backgroundColor:"#000000",cssSelectorAncestor:"#jp_container_1",cssSelector:{videoPlay:".jp-video-play",play:".jp-play",pause:".jp-pause",stop:".jp-stop",seekBar:".jp-seek-bar",playBar:".jp-play-bar",mute:".jp-mute",unmute:".jp-unmute",volumeBar:".jp-volume-bar",volumeBarValue:".jp-volume-bar-value",volumeMax:".jp-volume-max",playbackRateBar:".jp-playback-rate-bar",playbackRateBarValue:".jp-playback-rate-bar-value",currentTime:".jp-current-time",duration:".jp-duration",title:".jp-title",fullScreen:".jp-full-screen",restoreScreen:".jp-restore-screen",repeat:".jp-repeat",repeatOff:".jp-repeat-off",gui:".jp-gui",noSolution:".jp-no-solution"},stateClass:{playing:"jp-state-playing",seeking:"jp-state-seeking",muted:"jp-state-muted",looped:"jp-state-looped",fullScreen:"jp-state-full-screen",noVolume:"jp-state-no-volume"},useStateClassSkin:!1,autoBlur:!0,smoothPlayBar:!1,fullScreen:!1,fullWindow:!1,autohide:{restored:!1,full:!0,fadeIn:200,fadeOut:600,hold:1e3},loop:!1,repeat:function(b){b.jPlayer.options.loop?a(this).unbind(".jPlayerRepeat").bind(a.jPlayer.event.ended+".jPlayer.jPlayerRepeat",function(){a(this).jPlayer("play")}):a(this).unbind(".jPlayerRepeat")},nativeVideoControls:{},noFullWindow:{msie:/msie [0-6]\./,ipad:/ipad.*?os [0-4]\./,iphone:/iphone/,ipod:/ipod/,android_pad:/android [0-3]\.(?!.*?mobile)/,android_phone:/(?=.*android)(?!.*chrome)(?=.*mobile)/,blackberry:/blackberry/,windows_ce:/windows ce/,iemobile:/iemobile/,webos:/webos/},noVolume:{ipad:/ipad/,iphone:/iphone/,ipod:/ipod/,android_pad:/android(?!.*?mobile)/,android_phone:/android.*?mobile/,blackberry:/blackberry/,windows_ce:/windows ce/,iemobile:/iemobile/,webos:/webos/,playbook:/playbook/},timeFormat:{},keyEnabled:!1,audioFullScreen:!1,keyBindings:{play:{key:80,fn:function(a){a.status.paused?a.play():a.pause()}},fullScreen:{key:70,fn:function(a){(a.status.video||a.options.audioFullScreen)&&a._setOption("fullScreen",!a.options.fullScreen)}},muted:{key:77,fn:function(a){a._muted(!a.options.muted)}},volumeUp:{key:190,fn:function(a){a.volume(a.options.volume+.1)}},volumeDown:{key:188,fn:function(a){a.volume(a.options.volume-.1)}},loop:{key:76,fn:function(a){a._loop(!a.options.loop)}}},verticalVolume:!1,verticalPlaybackRate:!1,globalVolume:!1,idPrefix:"jp",noConflict:"jQuery",emulateHtml:!1,consoleAlerts:!0,errorAlerts:!1,warningAlerts:!1},optionsAudio:{size:{width:"0px",height:"0px",cssClass:""},sizeFull:{width:"0px",height:"0px",cssClass:""}},optionsVideo:{size:{width:"480px",height:"270px",cssClass:"jp-video-270p"},sizeFull:{width:"100%",height:"100%",cssClass:"jp-video-full"}},instances:{},status:{src:"",media:{},paused:!0,format:{},formatType:"",waitForPlay:!0,waitForLoad:!0,srcSet:!1,video:!1,seekPercent:0,currentPercentRelative:0,currentPercentAbsolute:0,currentTime:0,duration:0,remaining:0,videoWidth:0,videoHeight:0,readyState:0,networkState:0,playbackRate:1,ended:0},internal:{ready:!1},solution:{html:!0,aurora:!0,flash:!0},format:{mp3:{codec:"audio/mpeg",flashCanPlay:!0,media:"audio"},m4a:{codec:'audio/mp4; codecs="mp4a.40.2"',flashCanPlay:!0,media:"audio"},m3u8a:{codec:'application/vnd.apple.mpegurl; codecs="mp4a.40.2"',flashCanPlay:!1,media:"audio"},m3ua:{codec:"audio/mpegurl",flashCanPlay:!1,media:"audio"},oga:{codec:'audio/ogg; codecs="vorbis, opus"',flashCanPlay:!1,media:"audio"},flac:{codec:"audio/x-flac",flashCanPlay:!1,media:"audio"},wav:{codec:'audio/wav; codecs="1"',flashCanPlay:!1,media:"audio"},webma:{codec:'audio/webm; codecs="vorbis"',flashCanPlay:!1,media:"audio"},fla:{codec:"audio/x-flv",flashCanPlay:!0,media:"audio"},rtmpa:{codec:'audio/rtmp; codecs="rtmp"',flashCanPlay:!0,media:"audio"},m4v:{codec:'video/mp4; codecs="avc1.42E01E, mp4a.40.2"',flashCanPlay:!0,media:"video"},m3u8v:{codec:'application/vnd.apple.mpegurl; codecs="avc1.42E01E, mp4a.40.2"',flashCanPlay:!1,media:"video"},m3uv:{codec:"audio/mpegurl",flashCanPlay:!1,media:"video"},ogv:{codec:'video/ogg; codecs="theora, vorbis"',flashCanPlay:!1,media:"video"},webmv:{codec:'video/webm; codecs="vorbis, vp8"',flashCanPlay:!1,media:"video"},flv:{codec:"video/x-flv",flashCanPlay:!0,media:"video"},rtmpv:{codec:'video/rtmp; codecs="rtmp"',flashCanPlay:!0,media:"video"}},_init:function(){var c=this;if(this.element.empty(),this.status=a.extend({},this.status),this.internal=a.extend({},this.internal),this.options.timeFormat=a.extend({},a.jPlayer.timeFormat,this.options.timeFormat),this.internal.cmdsIgnored=a.jPlayer.platform.ipad||a.jPlayer.platform.iphone||a.jPlayer.platform.ipod,this.internal.domNode=this.element.get(0),this.options.keyEnabled&&!a.jPlayer.focus&&(a.jPlayer.focus=this),this.androidFix={setMedia:!1,play:!1,pause:!1,time:0/0},a.jPlayer.platform.android&&(this.options.preload="auto"!==this.options.preload?"metadata":"auto"),this.formats=[],this.solutions=[],this.require={},this.htmlElement={},this.html={},this.html.audio={},this.html.video={},this.aurora={},this.aurora.formats=[],this.aurora.properties=[],this.flash={},this.css={},this.css.cs={},this.css.jq={},this.ancestorJq=[],this.options.volume=this._limitValue(this.options.volume,0,1),a.each(this.options.supplied.toLowerCase().split(","),function(b,d){var e=d.replace(/^\s+|\s+$/g,"");if(c.format[e]){var f=!1;a.each(c.formats,function(a,b){return e===b?(f=!0,!1):void 0}),f||c.formats.push(e)}}),a.each(this.options.solution.toLowerCase().split(","),function(b,d){var e=d.replace(/^\s+|\s+$/g,"");if(c.solution[e]){var f=!1;a.each(c.solutions,function(a,b){return e===b?(f=!0,!1):void 0}),f||c.solutions.push(e)}}),a.each(this.options.auroraFormats.toLowerCase().split(","),function(b,d){var e=d.replace(/^\s+|\s+$/g,"");if(c.format[e]){var f=!1;a.each(c.aurora.formats,function(a,b){return e===b?(f=!0,!1):void 0}),f||c.aurora.formats.push(e)}}),this.internal.instance="jp_"+this.count,this.instances[this.internal.instance]=this.element,this.element.attr("id")||this.element.attr("id",this.options.idPrefix+"_jplayer_"+this.count),this.internal.self=a.extend({},{id:this.element.attr("id"),jq:this.element}),this.internal.audio=a.extend({},{id:this.options.idPrefix+"_audio_"+this.count,jq:b}),this.internal.video=a.extend({},{id:this.options.idPrefix+"_video_"+this.count,jq:b}),this.internal.flash=a.extend({},{id:this.options.idPrefix+"_flash_"+this.count,jq:b,swf:this.options.swfPath+(".swf"!==this.options.swfPath.toLowerCase().slice(-4)?(this.options.swfPath&&"/"!==this.options.swfPath.slice(-1)?"/":"")+"jquery.jplayer.swf":"")}),this.internal.poster=a.extend({},{id:this.options.idPrefix+"_poster_"+this.count,jq:b}),a.each(a.jPlayer.event,function(a,d){c.options[a]!==b&&(c.element.bind(d+".jPlayer",c.options[a]),c.options[a]=b)}),this.require.audio=!1,this.require.video=!1,a.each(this.formats,function(a,b){c.require[c.format[b].media]=!0}),this.options=this.require.video?a.extend(!0,{},this.optionsVideo,this.options):a.extend(!0,{},this.optionsAudio,this.options),this._setSize(),this.status.nativeVideoControls=this._uaBlocklist(this.options.nativeVideoControls),this.status.noFullWindow=this._uaBlocklist(this.options.noFullWindow),this.status.noVolume=this._uaBlocklist(this.options.noVolume),a.jPlayer.nativeFeatures.fullscreen.api.fullscreenEnabled&&this._fullscreenAddEventListeners(),this._restrictNativeVideoControls(),this.htmlElement.poster=document.createElement("img"),this.htmlElement.poster.id=this.internal.poster.id,this.htmlElement.poster.onload=function(){(!c.status.video||c.status.waitForPlay)&&c.internal.poster.jq.show()},this.element.append(this.htmlElement.poster),this.internal.poster.jq=a("#"+this.internal.poster.id),this.internal.poster.jq.css({width:this.status.width,height:this.status.height}),this.internal.poster.jq.hide(),this.internal.poster.jq.bind("click.jPlayer",function(){c._trigger(a.jPlayer.event.click)}),this.html.audio.available=!1,this.require.audio&&(this.htmlElement.audio=document.createElement("audio"),this.htmlElement.audio.id=this.internal.audio.id,this.html.audio.available=!!this.htmlElement.audio.canPlayType&&this._testCanPlayType(this.htmlElement.audio)),this.html.video.available=!1,this.require.video&&(this.htmlElement.video=document.createElement("video"),this.htmlElement.video.id=this.internal.video.id,this.html.video.available=!!this.htmlElement.video.canPlayType&&this._testCanPlayType(this.htmlElement.video)),this.flash.available=this._checkForFlash(10.1),this.html.canPlay={},this.aurora.canPlay={},this.flash.canPlay={},a.each(this.formats,function(b,d){c.html.canPlay[d]=c.html[c.format[d].media].available&&""!==c.htmlElement[c.format[d].media].canPlayType(c.format[d].codec),c.aurora.canPlay[d]=a.inArray(d,c.aurora.formats)>-1,c.flash.canPlay[d]=c.format[d].flashCanPlay&&c.flash.available}),this.html.desired=!1,this.aurora.desired=!1,this.flash.desired=!1,a.each(this.solutions,function(b,d){if(0===b)c[d].desired=!0;else{var e=!1,f=!1;a.each(c.formats,function(a,b){c[c.solutions[0]].canPlay[b]&&("video"===c.format[b].media?f=!0:e=!0)}),c[d].desired=c.require.audio&&!e||c.require.video&&!f}}),this.html.support={},this.aurora.support={},this.flash.support={},a.each(this.formats,function(a,b){c.html.support[b]=c.html.canPlay[b]&&c.html.desired,c.aurora.support[b]=c.aurora.canPlay[b]&&c.aurora.desired,c.flash.support[b]=c.flash.canPlay[b]&&c.flash.desired}),this.html.used=!1,this.aurora.used=!1,this.flash.used=!1,a.each(this.solutions,function(b,d){a.each(c.formats,function(a,b){return c[d].support[b]?(c[d].used=!0,!1):void 0})}),this._resetActive(),this._resetGate(),this._cssSelectorAncestor(this.options.cssSelectorAncestor),this.html.used||this.aurora.used||this.flash.used?this.css.jq.noSolution.length&&this.css.jq.noSolution.hide():(this._error({type:a.jPlayer.error.NO_SOLUTION,context:"{solution:'"+this.options.solution+"', supplied:'"+this.options.supplied+"'}",message:a.jPlayer.errorMsg.NO_SOLUTION,hint:a.jPlayer.errorHint.NO_SOLUTION}),this.css.jq.noSolution.length&&this.css.jq.noSolution.show()),this.flash.used){var d,e="jQuery="+encodeURI(this.options.noConflict)+"&id="+encodeURI(this.internal.self.id)+"&vol="+this.options.volume+"&muted="+this.options.muted;if(a.jPlayer.browser.msie&&(Number(a.jPlayer.browser.version)<9||a.jPlayer.browser.documentMode<9)){var f='<object id="'+this.internal.flash.id+'" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" width="0" height="0" tabindex="-1"></object>',g=['<param name="movie" value="'+this.internal.flash.swf+'" />','<param name="FlashVars" value="'+e+'" />','<param name="allowScriptAccess" value="always" />','<param name="bgcolor" value="'+this.options.backgroundColor+'" />','<param name="wmode" value="'+this.options.wmode+'" />'];d=document.createElement(f);for(var h=0;h<g.length;h++)d.appendChild(document.createElement(g[h]))}else{var i=function(a,b,c){var d=document.createElement("param");d.setAttribute("name",b),d.setAttribute("value",c),a.appendChild(d)};d=document.createElement("object"),d.setAttribute("id",this.internal.flash.id),d.setAttribute("name",this.internal.flash.id),d.setAttribute("data",this.internal.flash.swf),d.setAttribute("type","application/x-shockwave-flash"),d.setAttribute("width","1"),d.setAttribute("height","1"),d.setAttribute("tabindex","-1"),i(d,"flashvars",e),i(d,"allowscriptaccess","always"),i(d,"bgcolor",this.options.backgroundColor),i(d,"wmode",this.options.wmode)}this.element.append(d),this.internal.flash.jq=a(d)}this.status.playbackRateEnabled=this.html.used&&!this.flash.used?this._testPlaybackRate("audio"):!1,this._updatePlaybackRate(),this.html.used&&(this.html.audio.available&&(this._addHtmlEventListeners(this.htmlElement.audio,this.html.audio),this.element.append(this.htmlElement.audio),this.internal.audio.jq=a("#"+this.internal.audio.id)),this.html.video.available&&(this._addHtmlEventListeners(this.htmlElement.video,this.html.video),this.element.append(this.htmlElement.video),this.internal.video.jq=a("#"+this.internal.video.id),this.internal.video.jq.css(this.status.nativeVideoControls?{width:this.status.width,height:this.status.height}:{width:"0px",height:"0px"}),this.internal.video.jq.bind("click.jPlayer",function(){c._trigger(a.jPlayer.event.click)}))),this.aurora.used,this.options.emulateHtml&&this._emulateHtmlBridge(),!this.html.used&&!this.aurora.used||this.flash.used||setTimeout(function(){c.internal.ready=!0,c.version.flash="n/a",c._trigger(a.jPlayer.event.repeat),c._trigger(a.jPlayer.event.ready)},100),this._updateNativeVideoControls(),this.css.jq.videoPlay.length&&this.css.jq.videoPlay.hide(),a.jPlayer.prototype.count++},destroy:function(){this.clearMedia(),this._removeUiClass(),this.css.jq.currentTime.length&&this.css.jq.currentTime.text(""),this.css.jq.duration.length&&this.css.jq.duration.text(""),a.each(this.css.jq,function(a,b){b.length&&b.unbind(".jPlayer")}),this.internal.poster.jq.unbind(".jPlayer"),this.internal.video.jq&&this.internal.video.jq.unbind(".jPlayer"),this._fullscreenRemoveEventListeners(),this===a.jPlayer.focus&&(a.jPlayer.focus=null),this.options.emulateHtml&&this._destroyHtmlBridge(),this.element.removeData("jPlayer"),this.element.unbind(".jPlayer"),this.element.empty(),delete this.instances[this.internal.instance]},destroyRemoved:function(){var b=this;a.each(this.instances,function(a,c){b.element!==c&&(c.data("jPlayer")||(c.jPlayer("destroy"),delete b.instances[a]))})},enable:function(){},disable:function(){},_testCanPlayType:function(a){try{return a.canPlayType(this.format.mp3.codec),!0}catch(b){return!1}},_testPlaybackRate:function(a){var b,c=.5;a="string"==typeof a?a:"audio",b=document.createElement(a);try{return"playbackRate"in b?(b.playbackRate=c,b.playbackRate===c):!1}catch(d){return!1}},_uaBlocklist:function(b){var c=navigator.userAgent.toLowerCase(),d=!1;return a.each(b,function(a,b){return b&&b.test(c)?(d=!0,!1):void 0}),d},_restrictNativeVideoControls:function(){this.require.audio&&this.status.nativeVideoControls&&(this.status.nativeVideoControls=!1,this.status.noFullWindow=!0)},_updateNativeVideoControls:function(){this.html.video.available&&this.html.used&&(this.htmlElement.video.controls=this.status.nativeVideoControls,this._updateAutohide(),this.status.nativeVideoControls&&this.require.video?(this.internal.poster.jq.hide(),this.internal.video.jq.css({width:this.status.width,height:this.status.height})):this.status.waitForPlay&&this.status.video&&(this.internal.poster.jq.show(),this.internal.video.jq.css({width:"0px",height:"0px"})))},_addHtmlEventListeners:function(b,c){var d=this;b.preload=this.options.preload,b.muted=this.options.muted,b.volume=this.options.volume,this.status.playbackRateEnabled&&(b.defaultPlaybackRate=this.options.defaultPlaybackRate,b.playbackRate=this.options.playbackRate),b.addEventListener("progress",function(){c.gate&&(d.internal.cmdsIgnored&&this.readyState>0&&(d.internal.cmdsIgnored=!1),d._getHtmlStatus(b),d._updateInterface(),d._trigger(a.jPlayer.event.progress))},!1),b.addEventListener("loadeddata",function(){c.gate&&(d.androidFix.setMedia=!1,d.androidFix.play&&(d.androidFix.play=!1,d.play(d.androidFix.time)),d.androidFix.pause&&(d.androidFix.pause=!1,d.pause(d.androidFix.time)),d._trigger(a.jPlayer.event.loadeddata))},!1),b.addEventListener("timeupdate",function(){c.gate&&(d._getHtmlStatus(b),d._updateInterface(),d._trigger(a.jPlayer.event.timeupdate))},!1),b.addEventListener("durationchange",function(){c.gate&&(d._getHtmlStatus(b),d._updateInterface(),d._trigger(a.jPlayer.event.durationchange))},!1),b.addEventListener("play",function(){c.gate&&(d._updateButtons(!0),d._html_checkWaitForPlay(),d._trigger(a.jPlayer.event.play))},!1),b.addEventListener("playing",function(){c.gate&&(d._updateButtons(!0),d._seeked(),d._trigger(a.jPlayer.event.playing))},!1),b.addEventListener("pause",function(){c.gate&&(d._updateButtons(!1),d._trigger(a.jPlayer.event.pause))},!1),b.addEventListener("waiting",function(){c.gate&&(d._seeking(),d._trigger(a.jPlayer.event.waiting))},!1),b.addEventListener("seeking",function(){c.gate&&(d._seeking(),d._trigger(a.jPlayer.event.seeking))},!1),b.addEventListener("seeked",function(){c.gate&&(d._seeked(),d._trigger(a.jPlayer.event.seeked))},!1),b.addEventListener("volumechange",function(){c.gate&&(d.options.volume=b.volume,d.options.muted=b.muted,d._updateMute(),d._updateVolume(),d._trigger(a.jPlayer.event.volumechange))},!1),b.addEventListener("ratechange",function(){c.gate&&(d.options.defaultPlaybackRate=b.defaultPlaybackRate,d.options.playbackRate=b.playbackRate,d._updatePlaybackRate(),d._trigger(a.jPlayer.event.ratechange))},!1),b.addEventListener("suspend",function(){c.gate&&(d._seeked(),d._trigger(a.jPlayer.event.suspend))},!1),b.addEventListener("ended",function(){c.gate&&(a.jPlayer.browser.webkit||(d.htmlElement.media.currentTime=0),d.htmlElement.media.pause(),d._updateButtons(!1),d._getHtmlStatus(b,!0),d._updateInterface(),d._trigger(a.jPlayer.event.ended))},!1),b.addEventListener("error",function(){c.gate&&(d._updateButtons(!1),d._seeked(),d.status.srcSet&&(clearTimeout(d.internal.htmlDlyCmdId),d.status.waitForLoad=!0,d.status.waitForPlay=!0,d.status.video&&!d.status.nativeVideoControls&&d.internal.video.jq.css({width:"0px",height:"0px"}),d._validString(d.status.media.poster)&&!d.status.nativeVideoControls&&d.internal.poster.jq.show(),d.css.jq.videoPlay.length&&d.css.jq.videoPlay.show(),d._error({type:a.jPlayer.error.URL,context:d.status.src,message:a.jPlayer.errorMsg.URL,hint:a.jPlayer.errorHint.URL})))},!1),a.each(a.jPlayer.htmlEvent,function(e,f){b.addEventListener(this,function(){c.gate&&d._trigger(a.jPlayer.event[f])},!1)})},_addAuroraEventListeners:function(b,c){var d=this;b.volume=100*this.options.volume,b.on("progress",function(){c.gate&&(d.internal.cmdsIgnored&&this.readyState>0&&(d.internal.cmdsIgnored=!1),d._getAuroraStatus(b),d._updateInterface(),d._trigger(a.jPlayer.event.progress),b.duration>0&&d._trigger(a.jPlayer.event.timeupdate))},!1),b.on("ready",function(){c.gate&&d._trigger(a.jPlayer.event.loadeddata)},!1),b.on("duration",function(){c.gate&&(d._getAuroraStatus(b),d._updateInterface(),d._trigger(a.jPlayer.event.durationchange))},!1),b.on("end",function(){c.gate&&(d._updateButtons(!1),d._getAuroraStatus(b,!0),d._updateInterface(),d._trigger(a.jPlayer.event.ended))},!1),b.on("error",function(){c.gate&&(d._updateButtons(!1),d._seeked(),d.status.srcSet&&(d.status.waitForLoad=!0,d.status.waitForPlay=!0,d.status.video&&!d.status.nativeVideoControls&&d.internal.video.jq.css({width:"0px",height:"0px"}),d._validString(d.status.media.poster)&&!d.status.nativeVideoControls&&d.internal.poster.jq.show(),d.css.jq.videoPlay.length&&d.css.jq.videoPlay.show(),d._error({type:a.jPlayer.error.URL,context:d.status.src,message:a.jPlayer.errorMsg.URL,hint:a.jPlayer.errorHint.URL})))},!1)},_getHtmlStatus:function(a,b){var c=0,d=0,e=0,f=0;isFinite(a.duration)&&(this.status.duration=a.duration),c=a.currentTime,d=this.status.duration>0?100*c/this.status.duration:0,"object"==typeof a.seekable&&a.seekable.length>0?(e=this.status.duration>0?100*a.seekable.end(a.seekable.length-1)/this.status.duration:100,f=this.status.duration>0?100*a.currentTime/a.seekable.end(a.seekable.length-1):0):(e=100,f=d),b&&(c=0,f=0,d=0),this.status.seekPercent=e,this.status.currentPercentRelative=f,this.status.currentPercentAbsolute=d,this.status.currentTime=c,this.status.remaining=this.status.duration-this.status.currentTime,this.status.videoWidth=a.videoWidth,this.status.videoHeight=a.videoHeight,this.status.readyState=a.readyState,this.status.networkState=a.networkState,this.status.playbackRate=a.playbackRate,this.status.ended=a.ended},_getAuroraStatus:function(a,b){var c=0,d=0,e=0,f=0;this.status.duration=a.duration/1e3,c=a.currentTime/1e3,d=this.status.duration>0?100*c/this.status.duration:0,a.buffered>0?(e=this.status.duration>0?a.buffered*this.status.duration/this.status.duration:100,f=this.status.duration>0?c/(a.buffered*this.status.duration):0):(e=100,f=d),b&&(c=0,f=0,d=0),this.status.seekPercent=e,this.status.currentPercentRelative=f,this.status.currentPercentAbsolute=d,this.status.currentTime=c,this.status.remaining=this.status.duration-this.status.currentTime,this.status.readyState=4,this.status.networkState=0,this.status.playbackRate=1,this.status.ended=!1},_resetStatus:function(){this.status=a.extend({},this.status,a.jPlayer.prototype.status)},_trigger:function(b,c,d){var e=a.Event(b);e.jPlayer={},e.jPlayer.version=a.extend({},this.version),e.jPlayer.options=a.extend(!0,{},this.options),e.jPlayer.status=a.extend(!0,{},this.status),e.jPlayer.html=a.extend(!0,{},this.html),e.jPlayer.aurora=a.extend(!0,{},this.aurora),e.jPlayer.flash=a.extend(!0,{},this.flash),c&&(e.jPlayer.error=a.extend({},c)),d&&(e.jPlayer.warning=a.extend({},d)),this.element.trigger(e)},jPlayerFlashEvent:function(b,c){if(b===a.jPlayer.event.ready)if(this.internal.ready){if(this.flash.gate){if(this.status.srcSet){var d=this.status.currentTime,e=this.status.paused;this.setMedia(this.status.media),this.volumeWorker(this.options.volume),d>0&&(e?this.pause(d):this.play(d))}this._trigger(a.jPlayer.event.flashreset)}}else this.internal.ready=!0,this.internal.flash.jq.css({width:"0px",height:"0px"}),this.version.flash=c.version,this.version.needFlash!==this.version.flash&&this._error({type:a.jPlayer.error.VERSION,context:this.version.flash,message:a.jPlayer.errorMsg.VERSION+this.version.flash,hint:a.jPlayer.errorHint.VERSION}),this._trigger(a.jPlayer.event.repeat),this._trigger(b);if(this.flash.gate)switch(b){case a.jPlayer.event.progress:this._getFlashStatus(c),this._updateInterface(),this._trigger(b);break;case a.jPlayer.event.timeupdate:this._getFlashStatus(c),this._updateInterface(),this._trigger(b);break;case a.jPlayer.event.play:this._seeked(),this._updateButtons(!0),this._trigger(b);break;case a.jPlayer.event.pause:this._updateButtons(!1),this._trigger(b);break;case a.jPlayer.event.ended:this._updateButtons(!1),this._trigger(b);break;case a.jPlayer.event.click:this._trigger(b);break;case a.jPlayer.event.error:this.status.waitForLoad=!0,this.status.waitForPlay=!0,this.status.video&&this.internal.flash.jq.css({width:"0px",height:"0px"}),this._validString(this.status.media.poster)&&this.internal.poster.jq.show(),this.css.jq.videoPlay.length&&this.status.video&&this.css.jq.videoPlay.show(),this.status.video?this._flash_setVideo(this.status.media):this._flash_setAudio(this.status.media),this._updateButtons(!1),this._error({type:a.jPlayer.error.URL,context:c.src,message:a.jPlayer.errorMsg.URL,hint:a.jPlayer.errorHint.URL});break;case a.jPlayer.event.seeking:this._seeking(),this._trigger(b);break;case a.jPlayer.event.seeked:this._seeked(),this._trigger(b);break;case a.jPlayer.event.ready:break;default:this._trigger(b)}return!1},_getFlashStatus:function(a){this.status.seekPercent=a.seekPercent,this.status.currentPercentRelative=a.currentPercentRelative,this.status.currentPercentAbsolute=a.currentPercentAbsolute,this.status.currentTime=a.currentTime,this.status.duration=a.duration,this.status.remaining=a.duration-a.currentTime,this.status.videoWidth=a.videoWidth,this.status.videoHeight=a.videoHeight,this.status.readyState=4,this.status.networkState=0,this.status.playbackRate=1,this.status.ended=!1},_updateButtons:function(a){a===b?a=!this.status.paused:this.status.paused=!a,a?this.addStateClass("playing"):this.removeStateClass("playing"),!this.status.noFullWindow&&this.options.fullWindow?this.addStateClass("fullScreen"):this.removeStateClass("fullScreen"),this.options.loop?this.addStateClass("looped"):this.removeStateClass("looped"),this.css.jq.play.length&&this.css.jq.pause.length&&(a?(this.css.jq.play.hide(),this.css.jq.pause.show()):(this.css.jq.play.show(),this.css.jq.pause.hide())),this.css.jq.restoreScreen.length&&this.css.jq.fullScreen.length&&(this.status.noFullWindow?(this.css.jq.fullScreen.hide(),this.css.jq.restoreScreen.hide()):this.options.fullWindow?(this.css.jq.fullScreen.hide(),this.css.jq.restoreScreen.show()):(this.css.jq.fullScreen.show(),this.css.jq.restoreScreen.hide())),this.css.jq.repeat.length&&this.css.jq.repeatOff.length&&(this.options.loop?(this.css.jq.repeat.hide(),this.css.jq.repeatOff.show()):(this.css.jq.repeat.show(),this.css.jq.repeatOff.hide()))},_updateInterface:function(){this.css.jq.seekBar.length&&this.css.jq.seekBar.width(this.status.seekPercent+"%"),this.css.jq.playBar.length&&(this.options.smoothPlayBar?this.css.jq.playBar.stop().animate({width:this.status.currentPercentAbsolute+"%"},250,"linear"):this.css.jq.playBar.width(this.status.currentPercentRelative+"%"));var a="";this.css.jq.currentTime.length&&(a=this._convertTime(this.status.currentTime),a!==this.css.jq.currentTime.text()&&this.css.jq.currentTime.text(this._convertTime(this.status.currentTime)));var b="",c=this.status.duration,d=this.status.remaining;this.css.jq.duration.length&&("string"==typeof this.status.media.duration?b=this.status.media.duration:("number"==typeof this.status.media.duration&&(c=this.status.media.duration,d=c-this.status.currentTime),b=this.options.remainingDuration?(d>0?"-":"")+this._convertTime(d):this._convertTime(c)),b!==this.css.jq.duration.text()&&this.css.jq.duration.text(b))},_convertTime:c.prototype.time,_seeking:function(){this.css.jq.seekBar.length&&this.css.jq.seekBar.addClass("jp-seeking-bg"),this.addStateClass("seeking")},_seeked:function(){this.css.jq.seekBar.length&&this.css.jq.seekBar.removeClass("jp-seeking-bg"),this.removeStateClass("seeking")},_resetGate:function(){this.html.audio.gate=!1,this.html.video.gate=!1,this.aurora.gate=!1,this.flash.gate=!1},_resetActive:function(){this.html.active=!1,this.aurora.active=!1,this.flash.active=!1},_escapeHtml:function(a){return a.split("&").join("&amp;").split("<").join("&lt;").split(">").join("&gt;").split('"').join("&quot;")},_qualifyURL:function(a){var b=document.createElement("div");
return b.innerHTML='<a href="'+this._escapeHtml(a)+'">x</a>',b.firstChild.href},_absoluteMediaUrls:function(b){var c=this;return a.each(b,function(a,d){d&&c.format[a]&&"data:"!==d.substr(0,5)&&(b[a]=c._qualifyURL(d))}),b},addStateClass:function(a){this.ancestorJq.length&&this.ancestorJq.addClass(this.options.stateClass[a])},removeStateClass:function(a){this.ancestorJq.length&&this.ancestorJq.removeClass(this.options.stateClass[a])},setMedia:function(b){var c=this,d=!1,e=this.status.media.poster!==b.poster;this._resetMedia(),this._resetGate(),this._resetActive(),this.androidFix.setMedia=!1,this.androidFix.play=!1,this.androidFix.pause=!1,b=this._absoluteMediaUrls(b),a.each(this.formats,function(e,f){var g="video"===c.format[f].media;return a.each(c.solutions,function(e,h){if(c[h].support[f]&&c._validString(b[f])){var i="html"===h,j="aurora"===h;return g?(i?(c.html.video.gate=!0,c._html_setVideo(b),c.html.active=!0):(c.flash.gate=!0,c._flash_setVideo(b),c.flash.active=!0),c.css.jq.videoPlay.length&&c.css.jq.videoPlay.show(),c.status.video=!0):(i?(c.html.audio.gate=!0,c._html_setAudio(b),c.html.active=!0,a.jPlayer.platform.android&&(c.androidFix.setMedia=!0)):j?(c.aurora.gate=!0,c._aurora_setAudio(b),c.aurora.active=!0):(c.flash.gate=!0,c._flash_setAudio(b),c.flash.active=!0),c.css.jq.videoPlay.length&&c.css.jq.videoPlay.hide(),c.status.video=!1),d=!0,!1}}),d?!1:void 0}),d?(this.status.nativeVideoControls&&this.html.video.gate||this._validString(b.poster)&&(e?this.htmlElement.poster.src=b.poster:this.internal.poster.jq.show()),"string"==typeof b.title&&(this.css.jq.title.length&&this.css.jq.title.html(b.title),this.htmlElement.audio&&this.htmlElement.audio.setAttribute("title",b.title),this.htmlElement.video&&this.htmlElement.video.setAttribute("title",b.title)),this.status.srcSet=!0,this.status.media=a.extend({},b),this._updateButtons(!1),this._updateInterface(),this._trigger(a.jPlayer.event.setmedia)):this._error({type:a.jPlayer.error.NO_SUPPORT,context:"{supplied:'"+this.options.supplied+"'}",message:a.jPlayer.errorMsg.NO_SUPPORT,hint:a.jPlayer.errorHint.NO_SUPPORT})},_resetMedia:function(){this._resetStatus(),this._updateButtons(!1),this._updateInterface(),this._seeked(),this.internal.poster.jq.hide(),clearTimeout(this.internal.htmlDlyCmdId),this.html.active?this._html_resetMedia():this.aurora.active?this._aurora_resetMedia():this.flash.active&&this._flash_resetMedia()},clearMedia:function(){this._resetMedia(),this.html.active?this._html_clearMedia():this.aurora.active?this._aurora_clearMedia():this.flash.active&&this._flash_clearMedia(),this._resetGate(),this._resetActive()},load:function(){this.status.srcSet?this.html.active?this._html_load():this.aurora.active?this._aurora_load():this.flash.active&&this._flash_load():this._urlNotSetError("load")},focus:function(){this.options.keyEnabled&&(a.jPlayer.focus=this)},play:function(a){var b="object"==typeof a;b&&this.options.useStateClassSkin&&!this.status.paused?this.pause(a):(a="number"==typeof a?a:0/0,this.status.srcSet?(this.focus(),this.html.active?this._html_play(a):this.aurora.active?this._aurora_play(a):this.flash.active&&this._flash_play(a)):this._urlNotSetError("play"))},videoPlay:function(){this.play()},pause:function(a){a="number"==typeof a?a:0/0,this.status.srcSet?this.html.active?this._html_pause(a):this.aurora.active?this._aurora_pause(a):this.flash.active&&this._flash_pause(a):this._urlNotSetError("pause")},tellOthers:function(b,c){var d=this,e="function"==typeof c,f=Array.prototype.slice.call(arguments);"string"==typeof b&&(e&&f.splice(1,1),a.jPlayer.prototype.destroyRemoved(),a.each(this.instances,function(){d.element!==this&&(!e||c.call(this.data("jPlayer"),d))&&this.jPlayer.apply(this,f)}))},pauseOthers:function(a){this.tellOthers("pause",function(){return this.status.srcSet},a)},stop:function(){this.status.srcSet?this.html.active?this._html_pause(0):this.aurora.active?this._aurora_pause(0):this.flash.active&&this._flash_pause(0):this._urlNotSetError("stop")},playHead:function(a){a=this._limitValue(a,0,100),this.status.srcSet?this.html.active?this._html_playHead(a):this.aurora.active?this._aurora_playHead(a):this.flash.active&&this._flash_playHead(a):this._urlNotSetError("playHead")},_muted:function(a){this.mutedWorker(a),this.options.globalVolume&&this.tellOthers("mutedWorker",function(){return this.options.globalVolume},a)},mutedWorker:function(b){this.options.muted=b,this.html.used&&this._html_setProperty("muted",b),this.aurora.used&&this._aurora_mute(b),this.flash.used&&this._flash_mute(b),this.html.video.gate||this.html.audio.gate||(this._updateMute(b),this._updateVolume(this.options.volume),this._trigger(a.jPlayer.event.volumechange))},mute:function(a){var c="object"==typeof a;c&&this.options.useStateClassSkin&&this.options.muted?this._muted(!1):(a=a===b?!0:!!a,this._muted(a))},unmute:function(a){a=a===b?!0:!!a,this._muted(!a)},_updateMute:function(a){a===b&&(a=this.options.muted),a?this.addStateClass("muted"):this.removeStateClass("muted"),this.css.jq.mute.length&&this.css.jq.unmute.length&&(this.status.noVolume?(this.css.jq.mute.hide(),this.css.jq.unmute.hide()):a?(this.css.jq.mute.hide(),this.css.jq.unmute.show()):(this.css.jq.mute.show(),this.css.jq.unmute.hide()))},volume:function(a){this.volumeWorker(a),this.options.globalVolume&&this.tellOthers("volumeWorker",function(){return this.options.globalVolume},a)},volumeWorker:function(b){b=this._limitValue(b,0,1),this.options.volume=b,this.html.used&&this._html_setProperty("volume",b),this.aurora.used&&this._aurora_volume(b),this.flash.used&&this._flash_volume(b),this.html.video.gate||this.html.audio.gate||(this._updateVolume(b),this._trigger(a.jPlayer.event.volumechange))},volumeBar:function(b){if(this.css.jq.volumeBar.length){var c=a(b.currentTarget),d=c.offset(),e=b.pageX-d.left,f=c.width(),g=c.height()-b.pageY+d.top,h=c.height();this.volume(this.options.verticalVolume?g/h:e/f)}this.options.muted&&this._muted(!1)},_updateVolume:function(a){a===b&&(a=this.options.volume),a=this.options.muted?0:a,this.status.noVolume?(this.addStateClass("noVolume"),this.css.jq.volumeBar.length&&this.css.jq.volumeBar.hide(),this.css.jq.volumeBarValue.length&&this.css.jq.volumeBarValue.hide(),this.css.jq.volumeMax.length&&this.css.jq.volumeMax.hide()):(this.removeStateClass("noVolume"),this.css.jq.volumeBar.length&&this.css.jq.volumeBar.show(),this.css.jq.volumeBarValue.length&&(this.css.jq.volumeBarValue.show(),this.css.jq.volumeBarValue[this.options.verticalVolume?"height":"width"](100*a+"%")),this.css.jq.volumeMax.length&&this.css.jq.volumeMax.show())},volumeMax:function(){this.volume(1),this.options.muted&&this._muted(!1)},_cssSelectorAncestor:function(b){var c=this;this.options.cssSelectorAncestor=b,this._removeUiClass(),this.ancestorJq=b?a(b):[],b&&1!==this.ancestorJq.length&&this._warning({type:a.jPlayer.warning.CSS_SELECTOR_COUNT,context:b,message:a.jPlayer.warningMsg.CSS_SELECTOR_COUNT+this.ancestorJq.length+" found for cssSelectorAncestor.",hint:a.jPlayer.warningHint.CSS_SELECTOR_COUNT}),this._addUiClass(),a.each(this.options.cssSelector,function(a,b){c._cssSelector(a,b)}),this._updateInterface(),this._updateButtons(),this._updateAutohide(),this._updateVolume(),this._updateMute()},_cssSelector:function(b,c){var d=this;if("string"==typeof c)if(a.jPlayer.prototype.options.cssSelector[b]){if(this.css.jq[b]&&this.css.jq[b].length&&this.css.jq[b].unbind(".jPlayer"),this.options.cssSelector[b]=c,this.css.cs[b]=this.options.cssSelectorAncestor+" "+c,this.css.jq[b]=c?a(this.css.cs[b]):[],this.css.jq[b].length&&this[b]){var e=function(c){c.preventDefault(),d[b](c),d.options.autoBlur?a(this).blur():a(this).focus()};this.css.jq[b].bind("click.jPlayer",e)}c&&1!==this.css.jq[b].length&&this._warning({type:a.jPlayer.warning.CSS_SELECTOR_COUNT,context:this.css.cs[b],message:a.jPlayer.warningMsg.CSS_SELECTOR_COUNT+this.css.jq[b].length+" found for "+b+" method.",hint:a.jPlayer.warningHint.CSS_SELECTOR_COUNT})}else this._warning({type:a.jPlayer.warning.CSS_SELECTOR_METHOD,context:b,message:a.jPlayer.warningMsg.CSS_SELECTOR_METHOD,hint:a.jPlayer.warningHint.CSS_SELECTOR_METHOD});else this._warning({type:a.jPlayer.warning.CSS_SELECTOR_STRING,context:c,message:a.jPlayer.warningMsg.CSS_SELECTOR_STRING,hint:a.jPlayer.warningHint.CSS_SELECTOR_STRING})},duration:function(a){this.options.toggleDuration&&(this.options.captureDuration&&a.stopPropagation(),this._setOption("remainingDuration",!this.options.remainingDuration))},seekBar:function(b){if(this.css.jq.seekBar.length){var c=a(b.currentTarget),d=c.offset(),e=b.pageX-d.left,f=c.width(),g=100*e/f;this.playHead(g)}},playbackRate:function(a){this._setOption("playbackRate",a)},playbackRateBar:function(b){if(this.css.jq.playbackRateBar.length){var c,d,e=a(b.currentTarget),f=e.offset(),g=b.pageX-f.left,h=e.width(),i=e.height()-b.pageY+f.top,j=e.height();c=this.options.verticalPlaybackRate?i/j:g/h,d=c*(this.options.maxPlaybackRate-this.options.minPlaybackRate)+this.options.minPlaybackRate,this.playbackRate(d)}},_updatePlaybackRate:function(){var a=this.options.playbackRate,b=(a-this.options.minPlaybackRate)/(this.options.maxPlaybackRate-this.options.minPlaybackRate);this.status.playbackRateEnabled?(this.css.jq.playbackRateBar.length&&this.css.jq.playbackRateBar.show(),this.css.jq.playbackRateBarValue.length&&(this.css.jq.playbackRateBarValue.show(),this.css.jq.playbackRateBarValue[this.options.verticalPlaybackRate?"height":"width"](100*b+"%"))):(this.css.jq.playbackRateBar.length&&this.css.jq.playbackRateBar.hide(),this.css.jq.playbackRateBarValue.length&&this.css.jq.playbackRateBarValue.hide())},repeat:function(a){var b="object"==typeof a;this._loop(b&&this.options.useStateClassSkin&&this.options.loop?!1:!0)},repeatOff:function(){this._loop(!1)},_loop:function(b){this.options.loop!==b&&(this.options.loop=b,this._updateButtons(),this._trigger(a.jPlayer.event.repeat))},option:function(c,d){var e=c;if(0===arguments.length)return a.extend(!0,{},this.options);if("string"==typeof c){var f=c.split(".");if(d===b){for(var g=a.extend(!0,{},this.options),h=0;h<f.length;h++){if(g[f[h]]===b)return this._warning({type:a.jPlayer.warning.OPTION_KEY,context:c,message:a.jPlayer.warningMsg.OPTION_KEY,hint:a.jPlayer.warningHint.OPTION_KEY}),b;g=g[f[h]]}return g}e={};for(var i=e,j=0;j<f.length;j++)j<f.length-1?(i[f[j]]={},i=i[f[j]]):i[f[j]]=d}return this._setOptions(e),this},_setOptions:function(b){var c=this;return a.each(b,function(a,b){c._setOption(a,b)}),this},_setOption:function(b,c){var d=this;switch(b){case"volume":this.volume(c);break;case"muted":this._muted(c);break;case"globalVolume":this.options[b]=c;break;case"cssSelectorAncestor":this._cssSelectorAncestor(c);break;case"cssSelector":a.each(c,function(a,b){d._cssSelector(a,b)});break;case"playbackRate":this.options[b]=c=this._limitValue(c,this.options.minPlaybackRate,this.options.maxPlaybackRate),this.html.used&&this._html_setProperty("playbackRate",c),this._updatePlaybackRate();break;case"defaultPlaybackRate":this.options[b]=c=this._limitValue(c,this.options.minPlaybackRate,this.options.maxPlaybackRate),this.html.used&&this._html_setProperty("defaultPlaybackRate",c),this._updatePlaybackRate();break;case"minPlaybackRate":this.options[b]=c=this._limitValue(c,.1,this.options.maxPlaybackRate-.1),this._updatePlaybackRate();break;case"maxPlaybackRate":this.options[b]=c=this._limitValue(c,this.options.minPlaybackRate+.1,16),this._updatePlaybackRate();break;case"fullScreen":if(this.options[b]!==c){var e=a.jPlayer.nativeFeatures.fullscreen.used.webkitVideo;(!e||e&&!this.status.waitForPlay)&&(e||(this.options[b]=c),c?this._requestFullscreen():this._exitFullscreen(),e||this._setOption("fullWindow",c))}break;case"fullWindow":this.options[b]!==c&&(this._removeUiClass(),this.options[b]=c,this._refreshSize());break;case"size":this.options.fullWindow||this.options[b].cssClass===c.cssClass||this._removeUiClass(),this.options[b]=a.extend({},this.options[b],c),this._refreshSize();break;case"sizeFull":this.options.fullWindow&&this.options[b].cssClass!==c.cssClass&&this._removeUiClass(),this.options[b]=a.extend({},this.options[b],c),this._refreshSize();break;case"autohide":this.options[b]=a.extend({},this.options[b],c),this._updateAutohide();break;case"loop":this._loop(c);break;case"remainingDuration":this.options[b]=c,this._updateInterface();break;case"toggleDuration":this.options[b]=c;break;case"nativeVideoControls":this.options[b]=a.extend({},this.options[b],c),this.status.nativeVideoControls=this._uaBlocklist(this.options.nativeVideoControls),this._restrictNativeVideoControls(),this._updateNativeVideoControls();break;case"noFullWindow":this.options[b]=a.extend({},this.options[b],c),this.status.nativeVideoControls=this._uaBlocklist(this.options.nativeVideoControls),this.status.noFullWindow=this._uaBlocklist(this.options.noFullWindow),this._restrictNativeVideoControls(),this._updateButtons();break;case"noVolume":this.options[b]=a.extend({},this.options[b],c),this.status.noVolume=this._uaBlocklist(this.options.noVolume),this._updateVolume(),this._updateMute();break;case"emulateHtml":this.options[b]!==c&&(this.options[b]=c,c?this._emulateHtmlBridge():this._destroyHtmlBridge());break;case"timeFormat":this.options[b]=a.extend({},this.options[b],c);break;case"keyEnabled":this.options[b]=c,c||this!==a.jPlayer.focus||(a.jPlayer.focus=null);break;case"keyBindings":this.options[b]=a.extend(!0,{},this.options[b],c);break;case"audioFullScreen":this.options[b]=c;break;case"autoBlur":this.options[b]=c}return this},_refreshSize:function(){this._setSize(),this._addUiClass(),this._updateSize(),this._updateButtons(),this._updateAutohide(),this._trigger(a.jPlayer.event.resize)},_setSize:function(){this.options.fullWindow?(this.status.width=this.options.sizeFull.width,this.status.height=this.options.sizeFull.height,this.status.cssClass=this.options.sizeFull.cssClass):(this.status.width=this.options.size.width,this.status.height=this.options.size.height,this.status.cssClass=this.options.size.cssClass),this.element.css({width:this.status.width,height:this.status.height})},_addUiClass:function(){this.ancestorJq.length&&this.ancestorJq.addClass(this.status.cssClass)},_removeUiClass:function(){this.ancestorJq.length&&this.ancestorJq.removeClass(this.status.cssClass)},_updateSize:function(){this.internal.poster.jq.css({width:this.status.width,height:this.status.height}),!this.status.waitForPlay&&this.html.active&&this.status.video||this.html.video.available&&this.html.used&&this.status.nativeVideoControls?this.internal.video.jq.css({width:this.status.width,height:this.status.height}):!this.status.waitForPlay&&this.flash.active&&this.status.video&&this.internal.flash.jq.css({width:this.status.width,height:this.status.height})},_updateAutohide:function(){var a=this,b="mousemove.jPlayer",c=".jPlayerAutohide",d=b+c,e=function(b){var c,d,e=!1;"undefined"!=typeof a.internal.mouse?(c=a.internal.mouse.x-b.pageX,d=a.internal.mouse.y-b.pageY,e=Math.floor(c)>0||Math.floor(d)>0):e=!0,a.internal.mouse={x:b.pageX,y:b.pageY},e&&a.css.jq.gui.fadeIn(a.options.autohide.fadeIn,function(){clearTimeout(a.internal.autohideId),a.internal.autohideId=setTimeout(function(){a.css.jq.gui.fadeOut(a.options.autohide.fadeOut)},a.options.autohide.hold)})};this.css.jq.gui.length&&(this.css.jq.gui.stop(!0,!0),clearTimeout(this.internal.autohideId),delete this.internal.mouse,this.element.unbind(c),this.css.jq.gui.unbind(c),this.status.nativeVideoControls?this.css.jq.gui.hide():this.options.fullWindow&&this.options.autohide.full||!this.options.fullWindow&&this.options.autohide.restored?(this.element.bind(d,e),this.css.jq.gui.bind(d,e),this.css.jq.gui.hide()):this.css.jq.gui.show())},fullScreen:function(a){var b="object"==typeof a;b&&this.options.useStateClassSkin&&this.options.fullScreen?this._setOption("fullScreen",!1):this._setOption("fullScreen",!0)},restoreScreen:function(){this._setOption("fullScreen",!1)},_fullscreenAddEventListeners:function(){var b=this,c=a.jPlayer.nativeFeatures.fullscreen;c.api.fullscreenEnabled&&c.event.fullscreenchange&&("function"!=typeof this.internal.fullscreenchangeHandler&&(this.internal.fullscreenchangeHandler=function(){b._fullscreenchange()}),document.addEventListener(c.event.fullscreenchange,this.internal.fullscreenchangeHandler,!1))},_fullscreenRemoveEventListeners:function(){var b=a.jPlayer.nativeFeatures.fullscreen;this.internal.fullscreenchangeHandler&&document.removeEventListener(b.event.fullscreenchange,this.internal.fullscreenchangeHandler,!1)},_fullscreenchange:function(){this.options.fullScreen&&!a.jPlayer.nativeFeatures.fullscreen.api.fullscreenElement()&&this._setOption("fullScreen",!1)},_requestFullscreen:function(){var b=this.ancestorJq.length?this.ancestorJq[0]:this.element[0],c=a.jPlayer.nativeFeatures.fullscreen;c.used.webkitVideo&&(b=this.htmlElement.video),c.api.fullscreenEnabled&&c.api.requestFullscreen(b)},_exitFullscreen:function(){var b,c=a.jPlayer.nativeFeatures.fullscreen;c.used.webkitVideo&&(b=this.htmlElement.video),c.api.fullscreenEnabled&&c.api.exitFullscreen(b)},_html_initMedia:function(b){var c=a(this.htmlElement.media).empty();a.each(b.track||[],function(a,b){var d=document.createElement("track");d.setAttribute("kind",b.kind?b.kind:""),d.setAttribute("src",b.src?b.src:""),d.setAttribute("srclang",b.srclang?b.srclang:""),d.setAttribute("label",b.label?b.label:""),b.def&&d.setAttribute("default",b.def),c.append(d)}),this.htmlElement.media.src=this.status.src,"none"!==this.options.preload&&this._html_load(),this._trigger(a.jPlayer.event.timeupdate)},_html_setFormat:function(b){var c=this;a.each(this.formats,function(a,d){return c.html.support[d]&&b[d]?(c.status.src=b[d],c.status.format[d]=!0,c.status.formatType=d,!1):void 0})},_html_setAudio:function(a){this._html_setFormat(a),this.htmlElement.media=this.htmlElement.audio,this._html_initMedia(a)},_html_setVideo:function(a){this._html_setFormat(a),this.status.nativeVideoControls&&(this.htmlElement.video.poster=this._validString(a.poster)?a.poster:""),this.htmlElement.media=this.htmlElement.video,this._html_initMedia(a)},_html_resetMedia:function(){this.htmlElement.media&&(this.htmlElement.media.id!==this.internal.video.id||this.status.nativeVideoControls||this.internal.video.jq.css({width:"0px",height:"0px"}),this.htmlElement.media.pause())},_html_clearMedia:function(){this.htmlElement.media&&(this.htmlElement.media.src="about:blank",this.htmlElement.media.load())},_html_load:function(){this.status.waitForLoad&&(this.status.waitForLoad=!1,this.htmlElement.media.load()),clearTimeout(this.internal.htmlDlyCmdId)},_html_play:function(a){var b=this,c=this.htmlElement.media;if(this.androidFix.pause=!1,this._html_load(),this.androidFix.setMedia)this.androidFix.play=!0,this.androidFix.time=a;else if(isNaN(a))c.play();else{this.internal.cmdsIgnored&&c.play();try{if(c.seekable&&!("object"==typeof c.seekable&&c.seekable.length>0))throw 1;c.currentTime=a,c.play()}catch(d){return void(this.internal.htmlDlyCmdId=setTimeout(function(){b.play(a)},250))}}this._html_checkWaitForPlay()},_html_pause:function(a){var b=this,c=this.htmlElement.media;if(this.androidFix.play=!1,a>0?this._html_load():clearTimeout(this.internal.htmlDlyCmdId),c.pause(),this.androidFix.setMedia)this.androidFix.pause=!0,this.androidFix.time=a;else if(!isNaN(a))try{if(c.seekable&&!("object"==typeof c.seekable&&c.seekable.length>0))throw 1;c.currentTime=a}catch(d){return void(this.internal.htmlDlyCmdId=setTimeout(function(){b.pause(a)},250))}a>0&&this._html_checkWaitForPlay()},_html_playHead:function(a){var b=this,c=this.htmlElement.media;this._html_load();try{if("object"==typeof c.seekable&&c.seekable.length>0)c.currentTime=a*c.seekable.end(c.seekable.length-1)/100;else{if(!(c.duration>0)||isNaN(c.duration))throw"e";c.currentTime=a*c.duration/100}}catch(d){return void(this.internal.htmlDlyCmdId=setTimeout(function(){b.playHead(a)},250))}this.status.waitForLoad||this._html_checkWaitForPlay()},_html_checkWaitForPlay:function(){this.status.waitForPlay&&(this.status.waitForPlay=!1,this.css.jq.videoPlay.length&&this.css.jq.videoPlay.hide(),this.status.video&&(this.internal.poster.jq.hide(),this.internal.video.jq.css({width:this.status.width,height:this.status.height})))},_html_setProperty:function(a,b){this.html.audio.available&&(this.htmlElement.audio[a]=b),this.html.video.available&&(this.htmlElement.video[a]=b)},_aurora_setAudio:function(b){var c=this;a.each(this.formats,function(a,d){return c.aurora.support[d]&&b[d]?(c.status.src=b[d],c.status.format[d]=!0,c.status.formatType=d,!1):void 0}),this.aurora.player=new AV.Player.fromURL(this.status.src),this._addAuroraEventListeners(this.aurora.player,this.aurora),"auto"===this.options.preload&&(this._aurora_load(),this.status.waitForLoad=!1)},_aurora_resetMedia:function(){this.aurora.player&&this.aurora.player.stop()},_aurora_clearMedia:function(){},_aurora_load:function(){this.status.waitForLoad&&(this.status.waitForLoad=!1,this.aurora.player.preload())},_aurora_play:function(b){this.status.waitForLoad||isNaN(b)||this.aurora.player.seek(b),this.aurora.player.playing||this.aurora.player.play(),this.status.waitForLoad=!1,this._aurora_checkWaitForPlay(),this._updateButtons(!0),this._trigger(a.jPlayer.event.play)},_aurora_pause:function(b){isNaN(b)||this.aurora.player.seek(1e3*b),this.aurora.player.pause(),b>0&&this._aurora_checkWaitForPlay(),this._updateButtons(!1),this._trigger(a.jPlayer.event.pause)},_aurora_playHead:function(a){this.aurora.player.duration>0&&this.aurora.player.seek(a*this.aurora.player.duration/100),this.status.waitForLoad||this._aurora_checkWaitForPlay()},_aurora_checkWaitForPlay:function(){this.status.waitForPlay&&(this.status.waitForPlay=!1)},_aurora_volume:function(a){this.aurora.player.volume=100*a},_aurora_mute:function(a){a?(this.aurora.properties.lastvolume=this.aurora.player.volume,this.aurora.player.volume=0):this.aurora.player.volume=this.aurora.properties.lastvolume,this.aurora.properties.muted=a},_flash_setAudio:function(b){var c=this;try{a.each(this.formats,function(a,d){if(c.flash.support[d]&&b[d]){switch(d){case"m4a":case"fla":c._getMovie().fl_setAudio_m4a(b[d]);break;case"mp3":c._getMovie().fl_setAudio_mp3(b[d]);break;case"rtmpa":c._getMovie().fl_setAudio_rtmp(b[d])}return c.status.src=b[d],c.status.format[d]=!0,c.status.formatType=d,!1}}),"auto"===this.options.preload&&(this._flash_load(),this.status.waitForLoad=!1)}catch(d){this._flashError(d)}},_flash_setVideo:function(b){var c=this;try{a.each(this.formats,function(a,d){if(c.flash.support[d]&&b[d]){switch(d){case"m4v":case"flv":c._getMovie().fl_setVideo_m4v(b[d]);break;case"rtmpv":c._getMovie().fl_setVideo_rtmp(b[d])}return c.status.src=b[d],c.status.format[d]=!0,c.status.formatType=d,!1}}),"auto"===this.options.preload&&(this._flash_load(),this.status.waitForLoad=!1)}catch(d){this._flashError(d)}},_flash_resetMedia:function(){this.internal.flash.jq.css({width:"0px",height:"0px"}),this._flash_pause(0/0)},_flash_clearMedia:function(){try{this._getMovie().fl_clearMedia()}catch(a){this._flashError(a)}},_flash_load:function(){try{this._getMovie().fl_load()}catch(a){this._flashError(a)}this.status.waitForLoad=!1},_flash_play:function(a){try{this._getMovie().fl_play(a)}catch(b){this._flashError(b)}this.status.waitForLoad=!1,this._flash_checkWaitForPlay()},_flash_pause:function(a){try{this._getMovie().fl_pause(a)}catch(b){this._flashError(b)}a>0&&(this.status.waitForLoad=!1,this._flash_checkWaitForPlay())},_flash_playHead:function(a){try{this._getMovie().fl_play_head(a)}catch(b){this._flashError(b)}this.status.waitForLoad||this._flash_checkWaitForPlay()},_flash_checkWaitForPlay:function(){this.status.waitForPlay&&(this.status.waitForPlay=!1,this.css.jq.videoPlay.length&&this.css.jq.videoPlay.hide(),this.status.video&&(this.internal.poster.jq.hide(),this.internal.flash.jq.css({width:this.status.width,height:this.status.height})))},_flash_volume:function(a){try{this._getMovie().fl_volume(a)}catch(b){this._flashError(b)}},_flash_mute:function(a){try{this._getMovie().fl_mute(a)}catch(b){this._flashError(b)}},_getMovie:function(){return document[this.internal.flash.id]},_getFlashPluginVersion:function(){var a,b=0;if(window.ActiveXObject)try{if(a=new ActiveXObject("ShockwaveFlash.ShockwaveFlash")){var c=a.GetVariable("$version");c&&(c=c.split(" ")[1].split(","),b=parseInt(c[0],10)+"."+parseInt(c[1],10))}}catch(d){}else navigator.plugins&&navigator.mimeTypes.length>0&&(a=navigator.plugins["Shockwave Flash"],a&&(b=navigator.plugins["Shockwave Flash"].description.replace(/.*\s(\d+\.\d+).*/,"$1")));return 1*b},_checkForFlash:function(a){var b=!1;return this._getFlashPluginVersion()>=a&&(b=!0),b},_validString:function(a){return a&&"string"==typeof a},_limitValue:function(a,b,c){return b>a?b:a>c?c:a},_urlNotSetError:function(b){this._error({type:a.jPlayer.error.URL_NOT_SET,context:b,message:a.jPlayer.errorMsg.URL_NOT_SET,hint:a.jPlayer.errorHint.URL_NOT_SET})},_flashError:function(b){var c;c=this.internal.ready?"FLASH_DISABLED":"FLASH",this._error({type:a.jPlayer.error[c],context:this.internal.flash.swf,message:a.jPlayer.errorMsg[c]+b.message,hint:a.jPlayer.errorHint[c]}),this.internal.flash.jq.css({width:"1px",height:"1px"})},_error:function(b){this._trigger(a.jPlayer.event.error,b),this.options.errorAlerts&&this._alert("Error!"+(b.message?"\n"+b.message:"")+(b.hint?"\n"+b.hint:"")+"\nContext: "+b.context)},_warning:function(c){this._trigger(a.jPlayer.event.warning,b,c),this.options.warningAlerts&&this._alert("Warning!"+(c.message?"\n"+c.message:"")+(c.hint?"\n"+c.hint:"")+"\nContext: "+c.context)},_alert:function(a){var b="jPlayer "+this.version.script+" : id='"+this.internal.self.id+"' : "+a;this.options.consoleAlerts?window.console&&window.console.log&&window.console.log(b):alert(b)},_emulateHtmlBridge:function(){var b=this;a.each(a.jPlayer.emulateMethods.split(/\s+/g),function(a,c){b.internal.domNode[c]=function(a){b[c](a)}}),a.each(a.jPlayer.event,function(c,d){var e=!0;a.each(a.jPlayer.reservedEvent.split(/\s+/g),function(a,b){return b===c?(e=!1,!1):void 0}),e&&b.element.bind(d+".jPlayer.jPlayerHtml",function(){b._emulateHtmlUpdate();var a=document.createEvent("Event");a.initEvent(c,!1,!0),b.internal.domNode.dispatchEvent(a)})})},_emulateHtmlUpdate:function(){var b=this;a.each(a.jPlayer.emulateStatus.split(/\s+/g),function(a,c){b.internal.domNode[c]=b.status[c]}),a.each(a.jPlayer.emulateOptions.split(/\s+/g),function(a,c){b.internal.domNode[c]=b.options[c]})},_destroyHtmlBridge:function(){var b=this;this.element.unbind(".jPlayerHtml");var c=a.jPlayer.emulateMethods+" "+a.jPlayer.emulateStatus+" "+a.jPlayer.emulateOptions;a.each(c.split(/\s+/g),function(a,c){delete b.internal.domNode[c]})}},a.jPlayer.error={FLASH:"e_flash",FLASH_DISABLED:"e_flash_disabled",NO_SOLUTION:"e_no_solution",NO_SUPPORT:"e_no_support",URL:"e_url",URL_NOT_SET:"e_url_not_set",VERSION:"e_version"},a.jPlayer.errorMsg={FLASH:"jPlayer's Flash fallback is not configured correctly, or a command was issued before the jPlayer Ready event. Details: ",FLASH_DISABLED:"jPlayer's Flash fallback has been disabled by the browser due to the CSS rules you have used. Details: ",NO_SOLUTION:"No solution can be found by jPlayer in this browser. Neither HTML nor Flash can be used.",NO_SUPPORT:"It is not possible to play any media format provided in setMedia() on this browser using your current options.",URL:"Media URL could not be loaded.",URL_NOT_SET:"Attempt to issue media playback commands, while no media url is set.",VERSION:"jPlayer "+a.jPlayer.prototype.version.script+" needs Jplayer.swf version "+a.jPlayer.prototype.version.needFlash+" but found "},a.jPlayer.errorHint={FLASH:"Check your swfPath option and that Jplayer.swf is there.",FLASH_DISABLED:"Check that you have not display:none; the jPlayer entity or any ancestor.",NO_SOLUTION:"Review the jPlayer options: support and supplied.",NO_SUPPORT:"Video or audio formats defined in the supplied option are missing.",URL:"Check media URL is valid.",URL_NOT_SET:"Use setMedia() to set the media URL.",VERSION:"Update jPlayer files."},a.jPlayer.warning={CSS_SELECTOR_COUNT:"e_css_selector_count",CSS_SELECTOR_METHOD:"e_css_selector_method",CSS_SELECTOR_STRING:"e_css_selector_string",OPTION_KEY:"e_option_key"},a.jPlayer.warningMsg={CSS_SELECTOR_COUNT:"The number of css selectors found did not equal one: ",CSS_SELECTOR_METHOD:"The methodName given in jPlayer('cssSelector') is not a valid jPlayer method.",CSS_SELECTOR_STRING:"The methodCssSelector given in jPlayer('cssSelector') is not a String or is empty.",OPTION_KEY:"The option requested in jPlayer('option') is undefined."},a.jPlayer.warningHint={CSS_SELECTOR_COUNT:"Check your css selector and the ancestor.",CSS_SELECTOR_METHOD:"Check your method name.",CSS_SELECTOR_STRING:"Check your css selector is a string.",OPTION_KEY:"Check your option name."}});
$(function(){
	$(".form_file").each(function(){
		var $fileClone = $("input[type=file]", this).clone(true);
		var $text = $("input[type=text]", this);
		var $reset = $(".reset", this);
		$("input[type=file]", this).on("change", function(){
			if ($(this).val() != ""){
				$text.val($(this).val());
				$reset.show();
			}
		});
		$reset.click(function(e){
			e.preventDefault();
			$("input[type=file]", this).replaceWith($fileClone);
			$text.val("");
			$reset.hide();
		});
	});

	$(".slide_tbl_wrap").on("click", ".tit a", function(e){
		e.preventDefault();
		var href = $(this).attr("href");
		$(href).stop().slideToggle(300);
		$(this).toggleClass("on");
		tableList.each(function(idx,ele){
			tableList[idx].Table.reInit(0);
		});
	});
	$(".slide_tbl_wrap .btn_expand").click(function(e){
		e.preventDefault();
		$(".slide_tbl_wrap .tit a").addClass("on");
		$(".slide_tbl_wrap .table_fixed_d").stop().slideDown(300);
		tableList.each(function(idx,ele){
			tableList[idx].Table.reInit(0);
		});
	});
	$(".slide_tbl_wrap .btn_collapse").on("click", function(e){
		e.preventDefault();
		$(".slide_tbl_wrap .tit a").removeClass("on");
		$(".slide_tbl_wrap .table_fixed_d").stop().slideUp(300);
	});

	$.fn.scrollTable = function(options){
		return this.each(function(idx,ele){
			var Table = {
				init : function(){
					Table.define();
					Table.onHandler();
					if(!Table.wrap.is(":visible")) return;
					Table.setMinWidth();
					Table.setBarPercent();
					Table.setScroll();
				},
				define : function(){
					Table.wrap = $(ele);
					Table.tabWrap = Table.wrap.find(".sec_scroll");
					Table.wrap.data("tableFixed");
					Table.table = Table.tabWrap.find("table");
					Table.scroll = Table.wrap.find(".table_scroll");
					Table.bar = Table.scroll.find(".bar");
					Table.evt = null;
					Table.startValX = 0;
					Table.startValY = 0;
					Table.barLeft = Table.getBarLeft();
					Table.maxBarLeft = 0;
					Table.maxScroll = 0;
					Table.cols = $.extend({
						"colsMobile" : 3,
						"colsTablet" : 5,
						"colsPc" : 7
					},Table.wrap.data());
					Table.average = $(".car_spec").length;
                	Table.table.find("col").removeAttr("style");
				},
				setMinWidth : function(){
					var baseCols = 1;
					var cols = Table.getCols();
					Table.wWidth = Table.wrap.outerWidth();
					var firstTrChild = Table.table.find("tr:first-child").eq(0).children();
					baseCols = Modernizr.mq("only all and (max-width:767px)") ? Table.cols["colsMobile"] : (Modernizr.mq("only all and (max-width: 1024px) and (min-width: 768px)") ? Table.cols["colsTablet"] : Table.cols["colsPc"] )

					var leftTh = Table.wWidth/baseCols;
					firstTrChild.each(function(i,e){
						var $td = $(e);
						var colsapn = $td.attr("colspan") || 1;
						$td.css("width", leftTh*colsapn);
						if(colsapn>1){
                            var $tr = Table.table.find("tr");

                            for(var n=0; n<$tr.length; n++){
                                var $t = $tr.eq(n).children(); //th and td
                                if( !$t.eq(i).attr("colspan") ){ //2
                                    $t.eq(i).css("width", leftTh*colsapn);
                                    for(var x=1; x<i; x++){
                                        $t.eq(i+x).css("width", leftTh);
                                    }
                                    break;
                                }
                            }
                        }
					})

					Table.tWidth = Table.table.outerWidth();
				},
				reInit : function(n){
					Table.setMinWidth();
					Table.setBarPercent();
					Table.setScroll();
					Table.moving(n);
					Table.startValX = 0;
					Table.startValY = 0;
					Table.evt = null;
				},
				onHandler : function(){
					$(window).on("resize", function(){
						if(Table.wrap.is(":visible")) Table.reInit();
					});
					var touchDir = null;
					Table.wrap.on("touchstart mousedown touchend mouseup touchmove mousemove touchcanel",function(e){
						var x,y;
						if(Table.evt) {
							if(e.type == "touchcanel"){
								Table.startValX = 0;
								Table.startValY = 0;
								Table.evt = null;
								touchDir = null;
							} else if(e.type == "touchend"){
								Table.startValX = 0;
								Table.startValY = 0;
								Table.evt = null;
								touchDir = null;
							} else if(e.type == "touchmove"){
								x = e.originalEvent.touches[0].pageX - Table.startValX;
								y = e.originalEvent.touches[0].pageY - Table.startValY;
								if(touchDir){
									if(touchDir == "y") {
										Table.startValX = 0;
										Table.startValY = 0;
										Table.evt = null;
										touchDir = null;
										return
									}
									else if(touchDir == "x") {
										e.preventDefault();
									}
								} else {
									if(Math.abs(x) > Math.abs(y)){
										touchDir = "x";
										e.preventDefault();
									} else if(Math.abs(y) > Math.abs(x)){
										touchDir = "y"
										Table.startValX = 0;
										Table.startValY = 0;
										Table.evt = null;
										touchDir = null;
										return
									}
								}
								Table.moving(Table.barLeft + x*(Table.evt == Table.bar[0] ? 1 : -1));
							} else if(e.type == "mouseup"){
								Table.startValX = 0;
								Table.startValY = 0;
								Table.evt = null;
								touchDir = null;
							} else if(e.type == "mousemove"){
								x = e.originalEvent.pageX - Table.startValX;
								y = e.originalEvent.pageY - Table.startValY;
								if(touchDir){
									if(touchDir == "y") return
									else if(touchDir == "x") e.preventDefault();
								} else {
									if(Math.abs(x) > Math.abs(y)){
										touchDir = "x";
										e.preventDefault();
									} else if(Math.abs(y) > Math.abs(x)){
										touchDir = "y"
										return
									}
								}
								if(e.buttons){
									Table.moving(Table.barLeft + x*(Table.evt == Table.bar[0] ? 1 : -1));
								} else {
									Table.startValX = 0;
									Table.startValY = 0;
									Table.evt = null;
									touchDir = null;
								}
							}

						} else {
							if(Table.wrap.find(e.target).length){
								if(e.type == "touchstart" || e.type == "mousedown"){
									Table.evt = e.target;
									var evt = e.originalEvent.touches ? e.originalEvent.touches[0] : e.originalEvent;
									Table.startValX = evt.pageX;
									Table.startValY = evt.pageY;
									Table.barLeft = Table.getBarLeft();
								}
							}
						}
					});
				},
				getCols : function(){
					var macCols = 0;
					Table.table.find("tr").each(function(i,tr){
						var cols = 0;
						$(tr).children().each(function(n,td){
							if($(td).is(":visible")) cols+=1;
						});
						macCols = macCols > cols ? macCols : cols;
					})
					return macCols;
				},

				getBarLeft : function(){
                    if( Table.bar.css("left") )	//#57335 속성값이 있을때만 동작하도록 수정
                    {
                        return parseInt(Table.bar.css("left").split("px")[0]);
                    }
                    else
                    {
                        return 0;
                    }
				},

				moving : function(X){
					var X = X || Table.getBarLeft();
					if(X < 0) X = 0;
					if(X > Table.maxBarLeft) X = Table.maxBarLeft;
                    /*20180709 scroll script modified YKJ*/
					//Table.bar.css("left", X);
                    $('.table_scroll .bar').css("left", X);

					var perBar = X/Table.maxBarLeft*100;
					var perTab = Math.round(Table.maxScroll/100*perBar);

					if( Table.wrap.data("tableFixed") == "y"){
						/*Table.table.find("tr").each(function(tr_i,tr){
							$(tr).children(".fixed_x").css({
								"left" : perTab
							})
						})*/
                        $('.fixed_x').css("left", perTab);

					}
                    $('.sec_scroll').scrollLeft(perTab);
					//Table.tabWrap.scrollLeft(perTab);
				},
				setBarPercent : function(){
					Table.barPercent = Math.floor(Table.wWidth/Table.tWidth*100);
					Table.bar.css("width", Table.barPercent+"%");
				},
				setScroll : function(){
					Table.maxScroll = Table.tabWrap[0].scrollWidth - Table.tabWrap[0].offsetWidth;
					if(Table.maxScroll<0) Table.maxScroll = 0;
					if( Table.maxScroll > 20 && Table.wWidth <= Table.tWidth ){
						Table.scroll.addClass("on")
					} else {
						Table.scroll.removeClass("on")
					}
					if(Table.scroll.hasClass("on")){
						Table.maxBarLeft = Table.scroll[0].offsetWidth - Table.bar[0].offsetWidth;
					}
				}
			}
			this.Table = Table;
			this.Table.init();
		});
	}
	//window.tableList = $("[data-table-fixed]").scrollTable();

	window.tableList = $("[class*=table_fixed_]").each(function(i,e){
		$(e).attr("data-table-fixed", $(e).find(".fixed_x").length ? "y" : "" )
	}).scrollTable();

	var Util = {}; //tab
	Util.commonTab = function(option){
		this.option = $.extend({
			class_name : ".common_tab",
			button : "a",
			index : null,
			desktopSize : 767,
			type : "2"
		},option);
	}

	var tabPt = Util.commonTab.prototype;

	tabPt.init = function(){
        console.log( " init : " + 1 );
		this.define();
        console.log( " init : " + 2 );
		this.onHandler();
        console.log( " init : " + 3 );
		this.switchOn();
        console.log( " init : " + 4 );
		this.setText();
        console.log( " init : " + 5 );
		this.setSize();
        console.log( " init : " + 6 );
	}

	tabPt.define = function(){
		var self = this;
		self.tabWrap = $(self.option.class_name);
		self.tabUl = self.tabWrap.addClass("tab_cpt"+self.option.type).children("ul");
		self.tabLi = self.tabUl.children("li");
		self.selectBtn = self.tabUl.prev(self.button);
		self.tabLi.each(function(){
			if($(this).children("ul").length) $(this).addClass("multi_depth");
		})
	}

	tabPt.onHandler = function(){
		var self = this;
		self.tabUl.on("click", "li a",function(e){
			var $parent = $(this).parent();
			if($parent.hasClass("multi_depth")){//There is smenu
				if($parent.hasClass("open")){
					self.switchOn();
				} else {
					self.opener( $parent );
				}
				return false;
			} else {//There is no smenu. go link
				if( $(this).attr("href") == "#" ) e.preventDefault();
				var $parents = $parent.parents("li");
				if( !$parents.length ){
					self.switchOn( $parent );
					self.setText( $parent );
				} else {
					self.switchOn( $parents );
					self.setText( $parents );
				}
				self.tabWrap.removeClass("open");
			}
		})

		self.selectBtn.on("click", function(){
			var $self = $(this).parent();
			$self.hasClass("open") ? $self.removeClass("open") : $self.addClass("open");
			return false;
		})

		$("body").on("click",function(e){
			e.stopPropagation();
			var $e = self.tabWrap.find(e.target);
			if(!self.tabWrap.find(e.target).length) {
				self.switchOn(null,true);
			}
		});

	}

	tabPt.switchOn = function($li, wrapClose){//close and on
		var self = this;
		var idx = $li ? $li.index() : self.option.index;
		self.option.index = idx;
		if(wrapClose) self.tabWrap.removeClass("open");
		self.tabLi.removeClass("open").removeClass("on").eq(idx).addClass("on");
	}

	tabPt.opener = function($li){
		var self = this;
		$li.siblings().removeClass("open").removeClass("on");
		$li.addClass("open");
	}

	tabPt.setText = function($li){
		var self = this;
		var $liEle = $li || self.tabLi.eq(self.option.index) || self.tabLi.filter(".on");
		if($liEle.length) self.selectBtn.text( $liEle.children("a").text() );
	}

	tabPt.setSize = function(){
		var self=this;
		var w=$(window).width(), max=54;

		self.tabLi.css({
			"width" : "auto",
			"height" : "auto"
		}).children("a").css("height", "auto");


		if( Modernizr.mq("only all and (min-width:768px)")  ){ //self.option.desktopSize < w
			if(self.option.type === "2"){ //768보다 클때
				var per = parseFloat( (100/self.tabLi.length).toFixed(2) );
				var one = per + (100-parseFloat( (per*self.tabLi.length).toFixed(2)));
				self.tabLi.css("width", per+"%").eq(0).css("width", one+"%");
			}
			if(self.option.type !== "3") {
				self.tabLi.each(function(i,e){

					var height = $(e).outerHeight();
					//console.log(height)
					max = height > max ? height : max;
				});
				self.tabLi.children("a").outerHeight(max);

			} else if(self.option.type == "3") {
				self.tabWrap.removeClass("tabMoblie");
			}
		} else { //768보다 작을때
			if( self.option.type == "3" && (self.tabUl.children().length > 2 || self.tabWrap.filter("[data-ng]").length ) ) {
				self.tabWrap.addClass("tabMoblie");
			}
		}
	}


	var newTabsA = [];
	$(".tab_cpt1").each(function(idx,ele){
		newTabsA[idx] = new Util.commonTab({
			"class_name" : ele,
			"type" : "1",
			"index" : $(ele).children("ul").children("li.on").index()
		});
		newTabsA[idx].init();
	});

	var newTabsB = [];
	$(".tab_cpt2").each(function(idx,ele){
		newTabsB[idx] = new Util.commonTab({
			"class_name" : ele,
			"type" : "2",
			"index" : $(ele).children("ul").children("li.on").index()
		});
		newTabsB[idx].init();
	});

	var newTabsC = [];
	$(".tab_cpt3").each(function(idx,ele){
		newTabsC[idx] = new Util.commonTab({
			"class_name" : ele,
			"type" : "3",
			"index" : $(ele).children("ul").children("li.on").index()
		});
		newTabsC[idx].init();
	});

	$(window).resize(function(){
		for(var a=0; a<newTabsA.length; a++){
			newTabsA[a].setSize();
		}
		for(var b=0; b<newTabsB.length; b++){
			newTabsB[b].setSize();
		}
		for(var c=0; c<newTabsC.length; c++){
			newTabsC[c].setSize();
		}
	}).resize();

	$.fn.commonPop = function(option){
		return this.each(function(idx, ele){
			var self=this,
			Pop = {
				"init" : function(){
					Pop.define();
					Pop.onHandler();
				},
				"define" : function(){
					Pop.$opener = $(ele);
					Pop.$pop = $(Pop.$opener.attr("href"));
					Pop.option = $.extend({
						"closer" : "btn_close",
						"top" : $("#header") || 0
					}, option);
					Pop.data = Pop.$opener.data();
				},
				"onHandler" : function(){
					Pop.$opener.on("click",function(e){
						e.preventDefault();
						Pop.open();
						Pop.$pop.data("parents",this);
					});
					Pop.$pop.off("click").on("click", function(e){
						e.stopPropagation();
						if(e.target == Pop.$pop[0] || e.target == Pop.$pop.find("a."+Pop.option.closer)[0] ){
							e.preventDefault();
							Pop.close();
						}
					});
				},
				"append" : function(){
					var html = '',
						o=Pop.option,
						d=Pop.data,
						btnCloseClass = (d.popType==2||d.popType==3) ? " btn2_close_gray1" : " btn2_close_red1";
						var btnText = d["btnText"] && d["btnText"].split(",");
						var btnClass = d["btnClass"] && d["btnClass"].split(",");
						var btnLink = d["btnLink"] && d["btnLink"].split(",");
					html+='<div class="pop_'+d.popType+' pop_con">';
					d.title && (html += '<strong>'+d.title+'</strong>');
					html += '<a href="#" class="'+o.closer+btnCloseClass+'" ><span>Close</span></a>';
					d.img && (html += '<img src="'+d.img+'" alt="'+d.imgAlt+'">');
					d.video && (html += '<div class="pop_video"><iframe src="'+d.video+'" title="'+d.videoTitle+'"></iframe></div>');
					if (d.buttonsClass || d.contextTitle || d.contextText || d.contextHtml){
						html += '<div class="pop_txt">';
					}
					if(d.contextHtml) {
						html += d.contextHtml
					} else {
						d.contextTitle &&
							   (html += '      <strong class="'+d.contextTitleClass+'">'+d.contextTitle+'</strong>');
						d.contextText &&
							   (html += '      <p class="'+d.contextTextClass+'">'+d.contextText+'</p>');
					}
					if(d.buttonsClass) {
						var pattern = /btn[0-9]+Text/;
						var btns = btnText.length;
						/*for(var key in d){
							if(key.match(pattern)) btns+=1;
						}*/

						html += '<div class="'+d.buttonsClass+'">';
						for(var i=1; i<=btns;i++){
							html += '<a href="'+btnLink[i-1]+'" class="'+btnClass[i-1]+'"><span>'+btnText[i-1]+'</span></a>';   //'+d["btn"+i+"Text"]+'
						}
						html += '</div>';
					}
					if (d.buttonsClass || d.contextTitle || d.contextText || d.contextHtml){
						html += '</div>';
					}
					html += '</div>';

					Pop.$pop.html(html);

					Pop.$pop.on("click", ".terms-nav a", function(e){
						e.preventDefault();
						var wrap = $(this).closest(".pop_con > div");
						var href = $(this).attr("href");
						var thisScrollTop = $(href).position().top - 20;
						wrap.animate({scrollTop : thisScrollTop+ "px"}, 300);
					});

				},
				"open" : function(){
					Pop.data.popType && Pop.append();
					Pop.$pop.addClass("show");
					Pop.setPosition();
					Pop.$pop.find("a."+Pop.option.closer).focus();
					cptSet();
				},
				"close" : function(){
					Pop.$pop.removeClass("show");
					Pop.$pop.data("parents").focus();
					Pop.$pop.removeAttr("data-parents");
				},
				"setPosition" : function(){
					var $popCon = Pop.$pop.children(".pop_con");
					var $img = $popCon.find("img");

					var fn = function(){
						var w = $(window);
						var bgTop = w.outerWidth() < 768 ? 0 : Pop.option.top.outerHeight();
						Pop.$pop.css({
							"top" : 0,
							"height" : $("body").outerHeight()
						})
						if(Pop.option.width) {
							$popCon.width(Pop.option.width);
							$popCon.css("margin-left", -$popCon.width()/2);
						}
						var wHeight = w.outerHeight()/2
						var pHeight =  $popCon.outerHeight()/2;
						var top = wHeight + w.scrollTop() - pHeight;
						$popCon.css({
							"top" : (w.scrollTop() < bgTop)
								 && ( (wHeight - pHeight) < bgTop) ? top+(Pop.option.top.outerHeight()-w.scrollTop())-(wHeight - pHeight) : top,
							"margin-top" : 0,
						});
					}

					$img.length ? $popCon.find("img").load(fn) : fn()

				}
			};
			Pop.init();
		})
	}
	$("[data-pop-type]").commonPop();

	if ($("[data-m], [data-t], [data-w]").length){
		cptSet();
	}
	if ($(".history_tab").length){
		historyInit();
	}
	if ($(".slider_gallery_tab").length || $(".gallery_article").length){
		sliderGalleryInit();
	}
});

var cptSet = function(){
	var cptTpye;
	var tabletWidth = 1024;
	var mobileWidth = 767;
	function cptSet(type){
		$("[data-m], [data-t], [data-w]").each(function(){
			cptTpye = type;
			$(this).removeClass($(this).data("m") +" "+ $(this).data("t") +" "+ $(this).data("w"));
			$(this).addClass($(this).data(type));
		});
	}
	$(window).resize(function(){
		if(cptTpye != "m" && Modernizr.mq("only all and (max-width:767px)")){
			cptSet("m");
		} else if(cptTpye != "t" && Modernizr.mq("only all and (max-width: 1024px) and (min-width: 768px)")){
			cptSet("t");
		} else if (cptTpye != "w" && Modernizr.mq("only all and (min-width: 1025px)")){
			cptSet("w");
		}
	}).resize();
}

var sliderGalleryInit = function(){
	$(".slider_gallery_tab").each(function(){
		var $this = $(this);
		var $selectBtn = $(".select_btn", $this);
		var $slide = $("ul", $this);
		var liLength = $("li", $slide).length;
		var marginVal = 12;
		var movePx = 125;
		var viewLength = 6;
		var viewIdx = 0;
		if (liLength <= viewLength){
			$("[class^='btn_']", $this).hide();
			$slide.width(movePx * liLength - marginVal).css({"left":"50%","margin-left": (movePx * liLength - marginVal)*-0.5+"px"});
		}
		$selectBtn.click(function(e){
			e.preventDefault();
			$this.toggleClass("open");
		});
		$("ul li a", $this).click(function(e){
			var $article = $(".gallery_article:eq("+$(this).parent().index()+")");
			e.preventDefault();
			$selectBtn.html($(".title", this).html());
			$this.removeClass("open");
			$(this).addClass("on").parent().siblings().find("a").removeClass("on");
			$article.addClass("on").siblings().removeClass("on");
			slideCtr($article, exIdx[$article.index()], 0);
		});
		$(".btn_prev", $this).click(function(e){
			e.preventDefault();
			if (0 < viewIdx){
				viewIdx -= 1;
				TweenMax.to($slide, 0.4, {left: viewIdx *-movePx, ease:"easeOutQuart"});
			}
		});
		$(".btn_next", $this).click(function(e){
			e.preventDefault();
			if (liLength - viewLength > viewIdx){
				viewIdx += 1;
				TweenMax.to($slide, 0.4, {left: viewIdx *-movePx, ease:"easeOutQuart"});
			}
		});
	});
	var exIdx = [0];
	var galleryImgHeight;
	var galleryVisible;
	$(window).resize(function(){
		galleryVisible = $(".gallery_article:visible");
		slideCtr(galleryVisible, exIdx[galleryVisible.index()], 0);
	}).resize();
	setTimeout(function(){
		alignSet($(".gallery_article:visible"), exIdx[galleryVisible.index()]);
	}, 100);
	function slideCtr($this, viewIdx, aniTime){
		var $slide = $(".gallery_img > ul", $this);
		var liLength = $("> li", $slide).length;
		var $paging = $(".paging", $this);
		var $prevBtn = $(".btn_prev", $this);
		var $nextBtn = $(".btn_next", $this);
		if ( liLength > 1){
			if (liLength == viewIdx + 1){
				$prevBtn.show();
				$nextBtn.hide();
			} else if (viewIdx == 0) {
				$prevBtn.hide();
				$nextBtn.show();
			} else {
				$prevBtn.show();
				$nextBtn.show();
			}
		}
		exIdx[$this.index()] = viewIdx;
		$paging.find("button:eq("+viewIdx+")").addClass("on").attr("title","selected").siblings().removeClass("on").removeAttr("title");
		TweenMax.to($slide, aniTime, {marginLeft: viewIdx *-$this.width()+"px", ease:"easeOutQuart"});
		alignSet($this, exIdx[$this.index()]);
	}
	function alignSet($this, viewIdx){
		galleryImgHeight = $(".gallery_article:visible .gallery_img > ul > li:eq("+viewIdx+") > img").height();
		TweenMax.to($(".btn_prev", $this), 0.2, {top: galleryImgHeight/2+"px", ease:"easeOutQuart"});
		TweenMax.to($(".btn_next", $this), 0.2, {top: galleryImgHeight/2+"px", ease:"easeOutQuart"});
		TweenMax.to($(".paging", $this), 0.2, {top: galleryImgHeight-22+"px", ease:"easeOutQuart"});
	}

	$(".gallery_article").each(function(){
		var viewIdx = 0;
		var $this = $(this);
		var $slide = $(".gallery_img > ul", $this);
		var liLength = $("> li", $slide).length;
		var $paging = $(".paging", $this);
		var $prevBtn = $(".btn_prev", $this);
		var $nextBtn = $(".btn_next", $this);
		var aniTime = 0.4;
		exIdx[$this.index()] = viewIdx;
		$paging.html("");
		for (i=1;i<=liLength;i++){
			$paging.append("<button type='button'>"+i+"</button>")
		}
		if (liLength <= 1) {
			$prevBtn.hide();
			$nextBtn.hide();
			$paging.hide();
		}
		$prevBtn.click(function(e){
			e.preventDefault();
			if (viewIdx > 0){
				viewIdx -= 1;
				slideCtr($this, viewIdx, aniTime);
			}
		});
		$nextBtn.click(function(e){
			e.preventDefault();
			if (liLength > viewIdx + 1){
				viewIdx += 1;
				slideCtr($this, viewIdx, aniTime);
			}
		});
		$("button", $paging).click(function(){
			var thisIdx = $(this).index();
			viewIdx = thisIdx;
			slideCtr($this, thisIdx, aniTime);
		});

		alignSet($this, viewIdx);
		$paging.find("button:eq("+viewIdx+")").addClass("on").attr("title","selected").siblings().removeClass("on").removeAttr("title");

		var imgSwipe = new onSwipeFnc($slide);
		var moveVal = 0;
		var limitSwipe = 20;
		imgSwipe.move = function(evt, dir, distance) {
			if( liLength <= 1 ) return;
			moveVal = viewIdx *-$this.width() + distance;
			if (viewIdx == 0){
				moveVal = Math.min( limitSwipe , Math.max(-$this.width(), moveVal));
			} else if (liLength == viewIdx + 1) {
				moveVal = Math.min((viewIdx-1)*$this.width(), Math.max(viewIdx *-$this.width() - limitSwipe, moveVal));
			} else {
				moveVal = Math.min(-(viewIdx-1)*$this.width(), Math.max((viewIdx + 1) *-$this.width() , moveVal));
			}
			$slide.css({"margin-left": moveVal+"px"});
		};
		imgSwipe.moveEnd = function(evt, dir, phase, swipetype, distance) {
			if (moveVal <= viewIdx *-$this.width() - 100 || moveVal >= viewIdx *-$this.width() + 100){
				if (phase == "end") {
					if (dir == "right") {
						$prevBtn.trigger("click");
					} else if (dir == "left") {
						$nextBtn.trigger("click");
					}
				}
			}
			slideCtr($this, viewIdx, aniTime);
		};
	});
}

var historyInit = function(){
	var tabletWidth = 1024;
	var mobileWidth = 767;
	var webLength = 8;
	var tabletLength = 6;
	var historyIdx = [];
	var viewLength = 0;
	var aniTime = 0.4;
	$(window).resize(function(){
		viewLengthSet();
		$(".history_tab").each(function(idx){
			var liLength = $(this).find("ul li").length;
			if (liLength - historyIdx[idx] <= viewLength){
				historyIdx[idx] =  liLength - viewLength > 0 ? liLength - viewLength : 0;
			}
			slideMove($(this), 0, historyIdx[idx] *-$(this).find("li:first-child").width());
			viewSet($(this), idx);
		});
	});
	function viewLengthSet(){
		var winWidth = $(window).width();
		if(winWidth <= tabletWidth){
			viewLength = tabletLength;
		} else if (winWidth > tabletWidth){
			viewLength = webLength;
		}
	}
	function viewSet($this, idx){
		var liLength = $("ul li", $this).length;
		liLengthSet($this, idx, liLength);
		btnSet($this, idx, liLength);
	}
	function liLengthSet($this, idx, liLength){
		if (liLength <= 7){
			$this.addClass("leng"+liLength);
		}
	}
	function btnSet($this, idx, liLength){
		if (viewLength < liLength){
			if (historyIdx[idx] == 0){
				$(".btn_prev", $this).removeClass("on");
				$(".btn_next", $this).addClass("on");
			} else if (historyIdx[idx] + viewLength == liLength){
				$(".btn_prev", $this).addClass("on");
				$(".btn_next", $this).removeClass("on");
			} else {
				$(".btn_next, .btn_prev", $this).addClass("on");
			}
		} else {
			$(".btn_next, .btn_prev", $this).removeClass("on");
		}
	}
	function slideMove($this, aniTime, moveVal){
		TweenMax.to($this.find("ul"), aniTime, {marginLeft: moveVal, ease:"easeOutQuart"});
	}
	$(".history_tab").each(function(idx){
		viewLengthSet();
		var $this = $(this);
		var $selectBtn = $(".select_btn", $this);
		var $slide = $("ul", $this);
		var liLength = $("li", $slide).length;
		var marginVal = 0;
		var onIdx = $("li.on", $slide).index();
		var viewIdx = Math.max(onIdx + viewLength > liLength ? liLength - viewLength : onIdx, 0);
		//var viewIdx = onIdx + 1 > viewLength ? onIdx + viewLength > liLength ? liLength - viewLength : onIdx : 0;
		historyIdx[idx] = viewIdx;
		slideMove($this, 0, historyIdx[idx] *-$("li:first-child", $slide).width());
		viewSet($this, idx);
		$selectBtn.html($("li.on", $slide).html());
		$selectBtn.click(function(e){
			e.preventDefault();
			$this.toggleClass("open");
		});
		$("ul li a", $this).click(function(e){
			var $article = $(".gallery_article:eq("+$(this).parent().index()+")");
			e.preventDefault();
			$selectBtn.html($(this).html());
			$this.removeClass("open");
			$(this).parent().addClass("on").siblings().removeClass("on");
			$article.show().siblings().hide();
		});
		$(".btn_prev", $this).on("click", function(e){
			e.preventDefault();
			if (0 < historyIdx[idx]){
				historyIdx[idx] -= 1;
				slideMove($this, aniTime, historyIdx[idx] *-$("li:first-child", $slide).width());
				btnSet($this, idx, liLength);
			}
		});
		$(".btn_next", $this).on("click", function(e){
			e.preventDefault();
			if (liLength - viewLength > historyIdx[idx]){
				historyIdx[idx] += 1;
				slideMove($this, aniTime, historyIdx[idx] *-$("li:first-child", $slide).width());
				btnSet($this, idx, liLength);
			}
		});
	});
}



$(function(){
	if( $("#isotope").length ){
		$("#isotope").prepend('<div class="grid_sizer" ></div>');
		/*!
		* Isotope PACKAGED v3.0.1
		*
		* Licensed GPLv3 for open source use
		* or Isotope Commercial License for commercial use
		*
		* http://isotope.metafizzy.co
		* Copyright 2016 Metafizzy
		*/
		
		!function(t,e){"use strict";"function"==typeof define&&define.amd?define("jquery-bridget/jquery-bridget",["jquery"],function(i){e(t,i)}):"object"==typeof module&&module.exports?module.exports=e(t,require("jquery")):t.jQueryBridget=e(t,t.jQuery)}(window,function(t,e){"use strict";function i(i,s,a){function u(t,e,n){var o,s="$()."+i+'("'+e+'")';return t.each(function(t,u){var h=a.data(u,i);if(!h)return void r(i+" not initialized. Cannot call methods, i.e. "+s);var d=h[e];if(!d||"_"==e.charAt(0))return void r(s+" is not a valid method");var l=d.apply(h,n);o=void 0===o?l:o}),void 0!==o?o:t}function h(t,e){t.each(function(t,n){var o=a.data(n,i);o?(o.option(e),o._init()):(o=new s(n,e),a.data(n,i,o))})}a=a||e||t.jQuery,a&&(s.prototype.option||(s.prototype.option=function(t){a.isPlainObject(t)&&(this.options=a.extend(!0,this.options,t))}),a.fn[i]=function(t){if("string"==typeof t){var e=o.call(arguments,1);return u(this,t,e)}return h(this,t),this},n(a))}function n(t){!t||t&&t.bridget||(t.bridget=i)}var o=Array.prototype.slice,s=t.console,r="undefined"==typeof s?function(){}:function(t){s.error(t)};return n(e||t.jQuery),i}),function(t,e){"function"==typeof define&&define.amd?define("ev-emitter/ev-emitter",e):"object"==typeof module&&module.exports?module.exports=e():t.EvEmitter=e()}("undefined"!=typeof window?window:this,function(){function t(){}var e=t.prototype;return e.on=function(t,e){if(t&&e){var i=this._events=this._events||{},n=i[t]=i[t]||[];return-1==n.indexOf(e)&&n.push(e),this}},e.once=function(t,e){if(t&&e){this.on(t,e);var i=this._onceEvents=this._onceEvents||{},n=i[t]=i[t]||{};return n[e]=!0,this}},e.off=function(t,e){var i=this._events&&this._events[t];if(i&&i.length){var n=i.indexOf(e);return-1!=n&&i.splice(n,1),this}},e.emitEvent=function(t,e){var i=this._events&&this._events[t];if(i&&i.length){var n=0,o=i[n];e=e||[];for(var s=this._onceEvents&&this._onceEvents[t];o;){var r=s&&s[o];r&&(this.off(t,o),delete s[o]),o.apply(this,e),n+=r?0:1,o=i[n]}return this}},t}),function(t,e){"use strict";"function"==typeof define&&define.amd?define("get-size/get-size",[],function(){return e()}):"object"==typeof module&&module.exports?module.exports=e():t.getSize=e()}(window,function(){"use strict";function t(t){var e=parseFloat(t),i=-1==t.indexOf("%")&&!isNaN(e);return i&&e}function e(){}function i(){for(var t={width:0,height:0,innerWidth:0,innerHeight:0,outerWidth:0,outerHeight:0},e=0;h>e;e++){var i=u[e];t[i]=0}return t}function n(t){var e=getComputedStyle(t);return e||a("Style returned "+e+". Are you running this code in a hidden iframe on Firefox? See http://bit.ly/getsizebug1"),e}function o(){if(!d){d=!0;var e=document.createElement("div");e.style.width="200px",e.style.padding="1px 2px 3px 4px",e.style.borderStyle="solid",e.style.borderWidth="1px 2px 3px 4px",e.style.boxSizing="border-box";var i=document.body||document.documentElement;i.appendChild(e);var o=n(e);s.isBoxSizeOuter=r=200==t(o.width),i.removeChild(e)}}function s(e){if(o(),"string"==typeof e&&(e=document.querySelector(e)),e&&"object"==typeof e&&e.nodeType){var s=n(e);if("none"==s.display)return i();var a={};a.width=e.offsetWidth,a.height=e.offsetHeight;for(var d=a.isBorderBox="border-box"==s.boxSizing,l=0;h>l;l++){var f=u[l],c=s[f],m=parseFloat(c);a[f]=isNaN(m)?0:m}var p=a.paddingLeft+a.paddingRight,y=a.paddingTop+a.paddingBottom,g=a.marginLeft+a.marginRight,v=a.marginTop+a.marginBottom,_=a.borderLeftWidth+a.borderRightWidth,I=a.borderTopWidth+a.borderBottomWidth,z=d&&r,x=t(s.width);x!==!1&&(a.width=x+(z?0:p+_));var S=t(s.height);return S!==!1&&(a.height=S+(z?0:y+I)),a.innerWidth=a.width-(p+_),a.innerHeight=a.height-(y+I),a.outerWidth=a.width+g,a.outerHeight=a.height+v,a}}var r,a="undefined"==typeof console?e:function(t){console.error(t)},u=["paddingLeft","paddingRight","paddingTop","paddingBottom","marginLeft","marginRight","marginTop","marginBottom","borderLeftWidth","borderRightWidth","borderTopWidth","borderBottomWidth"],h=u.length,d=!1;return s}),function(t,e){"use strict";"function"==typeof define&&define.amd?define("desandro-matches-selector/matches-selector",e):"object"==typeof module&&module.exports?module.exports=e():t.matchesSelector=e()}(window,function(){"use strict";var t=function(){var t=Element.prototype;if(t.matches)return"matches";if(t.matchesSelector)return"matchesSelector";for(var e=["webkit","moz","ms","o"],i=0;i<e.length;i++){var n=e[i],o=n+"MatchesSelector";if(t[o])return o}}();return function(e,i){return e[t](i)}}),function(t,e){"function"==typeof define&&define.amd?define("fizzy-ui-utils/utils",["desandro-matches-selector/matches-selector"],function(i){return e(t,i)}):"object"==typeof module&&module.exports?module.exports=e(t,require("desandro-matches-selector")):t.fizzyUIUtils=e(t,t.matchesSelector)}(window,function(t,e){var i={};i.extend=function(t,e){for(var i in e)t[i]=e[i];return t},i.modulo=function(t,e){return(t%e+e)%e},i.makeArray=function(t){var e=[];if(Array.isArray(t))e=t;else if(t&&"number"==typeof t.length)for(var i=0;i<t.length;i++)e.push(t[i]);else e.push(t);return e},i.removeFrom=function(t,e){var i=t.indexOf(e);-1!=i&&t.splice(i,1)},i.getParent=function(t,i){for(;t!=document.body;)if(t=t.parentNode,e(t,i))return t},i.getQueryElement=function(t){return"string"==typeof t?document.querySelector(t):t},i.handleEvent=function(t){var e="on"+t.type;this[e]&&this[e](t)},i.filterFindElements=function(t,n){t=i.makeArray(t);var o=[];return t.forEach(function(t){if(t instanceof HTMLElement){if(!n)return void o.push(t);e(t,n)&&o.push(t);for(var i=t.querySelectorAll(n),s=0;s<i.length;s++)o.push(i[s])}}),o},i.debounceMethod=function(t,e,i){var n=t.prototype[e],o=e+"Timeout";t.prototype[e]=function(){var t=this[o];t&&clearTimeout(t);var e=arguments,s=this;this[o]=setTimeout(function(){n.apply(s,e),delete s[o]},i||100)}},i.docReady=function(t){var e=document.readyState;"complete"==e||"interactive"==e?t():document.addEventListener("DOMContentLoaded",t)},i.toDashed=function(t){return t.replace(/(.)([A-Z])/g,function(t,e,i){return e+"-"+i}).toLowerCase()};var n=t.console;return i.htmlInit=function(e,o){i.docReady(function(){var s=i.toDashed(o),r="data-"+s,a=document.querySelectorAll("["+r+"]"),u=document.querySelectorAll(".js-"+s),h=i.makeArray(a).concat(i.makeArray(u)),d=r+"-options",l=t.jQuery;h.forEach(function(t){var i,s=t.getAttribute(r)||t.getAttribute(d);try{i=s&&JSON.parse(s)}catch(a){return void(n&&n.error("Error parsing "+r+" on "+t.className+": "+a))}var u=new e(t,i);l&&l.data(t,o,u)})})},i}),function(t,e){"function"==typeof define&&define.amd?define("outlayer/item",["ev-emitter/ev-emitter","get-size/get-size"],e):"object"==typeof module&&module.exports?module.exports=e(require("ev-emitter"),require("get-size")):(t.Outlayer={},t.Outlayer.Item=e(t.EvEmitter,t.getSize))}(window,function(t,e){"use strict";function i(t){for(var e in t)return!1;return e=null,!0}function n(t,e){t&&(this.element=t,this.layout=e,this.position={x:0,y:0},this._create())}function o(t){return t.replace(/([A-Z])/g,function(t){return"-"+t.toLowerCase()})}var s=document.documentElement.style,r="string"==typeof s.transition?"transition":"WebkitTransition",a="string"==typeof s.transform?"transform":"WebkitTransform",u={WebkitTransition:"webkitTransitionEnd",transition:"transitionend"}[r],h={transform:a,transition:r,transitionDuration:r+"Duration",transitionProperty:r+"Property",transitionDelay:r+"Delay"},d=n.prototype=Object.create(t.prototype);d.constructor=n,d._create=function(){this._transn={ingProperties:{},clean:{},onEnd:{}},this.css({position:"absolute"})},d.handleEvent=function(t){var e="on"+t.type;this[e]&&this[e](t)},d.getSize=function(){this.size=e(this.element)},d.css=function(t){var e=this.element.style;for(var i in t){var n=h[i]||i;e[n]=t[i]}},d.getPosition=function(){var t=getComputedStyle(this.element),e=this.layout._getOption("originLeft"),i=this.layout._getOption("originTop"),n=t[e?"left":"right"],o=t[i?"top":"bottom"],s=this.layout.size,r=-1!=n.indexOf("%")?parseFloat(n)/100*s.width:parseInt(n,10),a=-1!=o.indexOf("%")?parseFloat(o)/100*s.height:parseInt(o,10);r=isNaN(r)?0:r,a=isNaN(a)?0:a,r-=e?s.paddingLeft:s.paddingRight,a-=i?s.paddingTop:s.paddingBottom,this.position.x=r,this.position.y=a},d.layoutPosition=function(){var t=this.layout.size,e={},i=this.layout._getOption("originLeft"),n=this.layout._getOption("originTop"),o=i?"paddingLeft":"paddingRight",s=i?"left":"right",r=i?"right":"left",a=this.position.x+t[o];e[s]=this.getXValue(a),e[r]="";var u=n?"paddingTop":"paddingBottom",h=n?"top":"bottom",d=n?"bottom":"top",l=this.position.y+t[u];e[h]=this.getYValue(l),e[d]="",this.css(e),this.emitEvent("layout",[this])},d.getXValue=function(t){var e=this.layout._getOption("horizontal");return this.layout.options.percentPosition&&!e?t/this.layout.size.width*100+"%":t+"px"},d.getYValue=function(t){var e=this.layout._getOption("horizontal");return this.layout.options.percentPosition&&e?t/this.layout.size.height*100+"%":t+"px"},d._transitionTo=function(t,e){this.getPosition();var i=this.position.x,n=this.position.y,o=parseInt(t,10),s=parseInt(e,10),r=o===this.position.x&&s===this.position.y;if(this.setPosition(t,e),r&&!this.isTransitioning)return void this.layoutPosition();var a=t-i,u=e-n,h={};h.transform=this.getTranslate(a,u),this.transition({to:h,onTransitionEnd:{transform:this.layoutPosition},isCleaning:!0})},d.getTranslate=function(t,e){var i=this.layout._getOption("originLeft"),n=this.layout._getOption("originTop");return t=i?t:-t,e=n?e:-e,"translate3d("+t+"px, "+e+"px, 0)"},d.goTo=function(t,e){this.setPosition(t,e),this.layoutPosition()},d.moveTo=d._transitionTo,d.setPosition=function(t,e){this.position.x=parseInt(t,10),this.position.y=parseInt(e,10)},d._nonTransition=function(t){this.css(t.to),t.isCleaning&&this._removeStyles(t.to);for(var e in t.onTransitionEnd)t.onTransitionEnd[e].call(this)},d.transition=function(t){if(!parseFloat(this.layout.options.transitionDuration))return void this._nonTransition(t);var e=this._transn;for(var i in t.onTransitionEnd)e.onEnd[i]=t.onTransitionEnd[i];for(i in t.to)e.ingProperties[i]=!0,t.isCleaning&&(e.clean[i]=!0);if(t.from){this.css(t.from);var n=this.element.offsetHeight;n=null}this.enableTransition(t.to),this.css(t.to),this.isTransitioning=!0};var l="opacity,"+o(a);d.enableTransition=function(){if(!this.isTransitioning){var t=this.layout.options.transitionDuration;t="number"==typeof t?t+"ms":t,this.css({transitionProperty:l,transitionDuration:t,transitionDelay:this.staggerDelay||0}),this.element.addEventListener(u,this,!1)}},d.onwebkitTransitionEnd=function(t){this.ontransitionend(t)},d.onotransitionend=function(t){this.ontransitionend(t)};var f={"-webkit-transform":"transform"};d.ontransitionend=function(t){if(t.target===this.element){var e=this._transn,n=f[t.propertyName]||t.propertyName;if(delete e.ingProperties[n],i(e.ingProperties)&&this.disableTransition(),n in e.clean&&(this.element.style[t.propertyName]="",delete e.clean[n]),n in e.onEnd){var o=e.onEnd[n];o.call(this),delete e.onEnd[n]}this.emitEvent("transitionEnd",[this])}},d.disableTransition=function(){this.removeTransitionStyles(),this.element.removeEventListener(u,this,!1),this.isTransitioning=!1},d._removeStyles=function(t){var e={};for(var i in t)e[i]="";this.css(e)};var c={transitionProperty:"",transitionDuration:"",transitionDelay:""};return d.removeTransitionStyles=function(){this.css(c)},d.stagger=function(t){t=isNaN(t)?0:t,this.staggerDelay=t+"ms"},d.removeElem=function(){this.element.parentNode.removeChild(this.element),this.css({display:""}),this.emitEvent("remove",[this])},d.remove=function(){return r&&parseFloat(this.layout.options.transitionDuration)?(this.once("transitionEnd",function(){this.removeElem()}),void this.hide()):void this.removeElem()},d.reveal=function(){delete this.isHidden,this.css({display:""});var t=this.layout.options,e={},i=this.getHideRevealTransitionEndProperty("visibleStyle");e[i]=this.onRevealTransitionEnd,this.transition({from:t.hiddenStyle,to:t.visibleStyle,isCleaning:!0,onTransitionEnd:e})},d.onRevealTransitionEnd=function(){this.isHidden||this.emitEvent("reveal")},d.getHideRevealTransitionEndProperty=function(t){var e=this.layout.options[t];if(e.opacity)return"opacity";for(var i in e)return i},d.hide=function(){this.isHidden=!0,this.css({display:""});var t=this.layout.options,e={},i=this.getHideRevealTransitionEndProperty("hiddenStyle");e[i]=this.onHideTransitionEnd,this.transition({from:t.visibleStyle,to:t.hiddenStyle,isCleaning:!0,onTransitionEnd:e})},d.onHideTransitionEnd=function(){this.isHidden&&(this.css({display:"none"}),this.emitEvent("hide"))},d.destroy=function(){this.css({position:"",left:"",right:"",top:"",bottom:"",transition:"",transform:""})},n}),function(t,e){"use strict";"function"==typeof define&&define.amd?define("outlayer/outlayer",["ev-emitter/ev-emitter","get-size/get-size","fizzy-ui-utils/utils","./item"],function(i,n,o,s){return e(t,i,n,o,s)}):"object"==typeof module&&module.exports?module.exports=e(t,require("ev-emitter"),require("get-size"),require("fizzy-ui-utils"),require("./item")):t.Outlayer=e(t,t.EvEmitter,t.getSize,t.fizzyUIUtils,t.Outlayer.Item)}(window,function(t,e,i,n,o){"use strict";function s(t,e){var i=n.getQueryElement(t);if(!i)return void(u&&u.error("Bad element for "+this.constructor.namespace+": "+(i||t)));this.element=i,h&&(this.$element=h(this.element)),this.options=n.extend({},this.constructor.defaults),this.option(e);var o=++l;this.element.outlayerGUID=o,f[o]=this,this._create();var s=this._getOption("initLayout");s&&this.layout()}function r(t){function e(){t.apply(this,arguments)}return e.prototype=Object.create(t.prototype),e.prototype.constructor=e,e}function a(t){if("number"==typeof t)return t;var e=t.match(/(^\d*\.?\d*)(\w*)/),i=e&&e[1],n=e&&e[2];if(!i.length)return 0;i=parseFloat(i);var o=m[n]||1;return i*o}var u=t.console,h=t.jQuery,d=function(){},l=0,f={};s.namespace="outlayer",s.Item=o,s.defaults={containerStyle:{position:"relative"},initLayout:!0,originLeft:!0,originTop:!0,resize:!0,resizeContainer:!0,transitionDuration:"0.4s",hiddenStyle:{opacity:0,transform:"scale(0.001)"},visibleStyle:{opacity:1,transform:"scale(1)"}};var c=s.prototype;n.extend(c,e.prototype),c.option=function(t){n.extend(this.options,t)},c._getOption=function(t){var e=this.constructor.compatOptions[t];return e&&void 0!==this.options[e]?this.options[e]:this.options[t]},s.compatOptions={initLayout:"isInitLayout",horizontal:"isHorizontal",layoutInstant:"isLayoutInstant",originLeft:"isOriginLeft",originTop:"isOriginTop",resize:"isResizeBound",resizeContainer:"isResizingContainer"},c._create=function(){this.reloadItems(),this.stamps=[],this.stamp(this.options.stamp),n.extend(this.element.style,this.options.containerStyle);var t=this._getOption("resize");t&&this.bindResize()},c.reloadItems=function(){this.items=this._itemize(this.element.children)},c._itemize=function(t){for(var e=this._filterFindItemElements(t),i=this.constructor.Item,n=[],o=0;o<e.length;o++){var s=e[o],r=new i(s,this);n.push(r)}return n},c._filterFindItemElements=function(t){return n.filterFindElements(t,this.options.itemSelector)},c.getItemElements=function(){return this.items.map(function(t){return t.element})},c.layout=function(){this._resetLayout(),this._manageStamps();var t=this._getOption("layoutInstant"),e=void 0!==t?t:!this._isLayoutInited;this.layoutItems(this.items,e),this._isLayoutInited=!0},c._init=c.layout,c._resetLayout=function(){this.getSize()},c.getSize=function(){this.size=i(this.element)},c._getMeasurement=function(t,e){var n,o=this.options[t];o?("string"==typeof o?n=this.element.querySelector(o):o instanceof HTMLElement&&(n=o),this[t]=n?i(n)[e]:o):this[t]=0},c.layoutItems=function(t,e){t=this._getItemsForLayout(t),this._layoutItems(t,e),this._postLayout()},c._getItemsForLayout=function(t){return t.filter(function(t){return!t.isIgnored})},c._layoutItems=function(t,e){if(this._emitCompleteOnItems("layout",t),t&&t.length){var i=[];t.forEach(function(t){var n=this._getItemLayoutPosition(t);n.item=t,n.isInstant=e||t.isLayoutInstant,i.push(n)},this),this._processLayoutQueue(i)}},c._getItemLayoutPosition=function(){return{x:0,y:0}},c._processLayoutQueue=function(t){this.updateStagger(),t.forEach(function(t,e){this._positionItem(t.item,t.x,t.y,t.isInstant,e)},this)},c.updateStagger=function(){var t=this.options.stagger;return null===t||void 0===t?void(this.stagger=0):(this.stagger=a(t),this.stagger)},c._positionItem=function(t,e,i,n,o){n?t.goTo(e,i):(t.stagger(o*this.stagger),t.moveTo(e,i))},c._postLayout=function(){this.resizeContainer()},c.resizeContainer=function(){var t=this._getOption("resizeContainer");if(t){var e=this._getContainerSize();e&&(this._setContainerMeasure(e.width,!0),this._setContainerMeasure(e.height,!1))}},c._getContainerSize=d,c._setContainerMeasure=function(t,e){if(void 0!==t){var i=this.size;i.isBorderBox&&(t+=e?i.paddingLeft+i.paddingRight+i.borderLeftWidth+i.borderRightWidth:i.paddingBottom+i.paddingTop+i.borderTopWidth+i.borderBottomWidth),t=Math.max(t,0),this.element.style[e?"width":"height"]=t+"px"}},c._emitCompleteOnItems=function(t,e){function i(){o.dispatchEvent(t+"Complete",null,[e])}function n(){r++,r==s&&i()}var o=this,s=e.length;if(!e||!s)return void i();var r=0;e.forEach(function(e){e.once(t,n)})},c.dispatchEvent=function(t,e,i){var n=e?[e].concat(i):i;if(this.emitEvent(t,n),h)if(this.$element=this.$element||h(this.element),e){var o=h.Event(e);o.type=t,this.$element.trigger(o,i)}else this.$element.trigger(t,i)},c.ignore=function(t){var e=this.getItem(t);e&&(e.isIgnored=!0)},c.unignore=function(t){var e=this.getItem(t);e&&delete e.isIgnored},c.stamp=function(t){t=this._find(t),t&&(this.stamps=this.stamps.concat(t),t.forEach(this.ignore,this))},c.unstamp=function(t){t=this._find(t),t&&t.forEach(function(t){n.removeFrom(this.stamps,t),this.unignore(t)},this)},c._find=function(t){return t?("string"==typeof t&&(t=this.element.querySelectorAll(t)),t=n.makeArray(t)):void 0},c._manageStamps=function(){this.stamps&&this.stamps.length&&(this._getBoundingRect(),this.stamps.forEach(this._manageStamp,this))},c._getBoundingRect=function(){var t=this.element.getBoundingClientRect(),e=this.size;this._boundingRect={left:t.left+e.paddingLeft+e.borderLeftWidth,top:t.top+e.paddingTop+e.borderTopWidth,right:t.right-(e.paddingRight+e.borderRightWidth),bottom:t.bottom-(e.paddingBottom+e.borderBottomWidth)}},c._manageStamp=d,c._getElementOffset=function(t){var e=t.getBoundingClientRect(),n=this._boundingRect,o=i(t),s={left:e.left-n.left-o.marginLeft,top:e.top-n.top-o.marginTop,right:n.right-e.right-o.marginRight,bottom:n.bottom-e.bottom-o.marginBottom};return s},c.handleEvent=n.handleEvent,c.bindResize=function(){t.addEventListener("resize",this),this.isResizeBound=!0},c.unbindResize=function(){t.removeEventListener("resize",this),this.isResizeBound=!1},c.onresize=function(){this.resize()},n.debounceMethod(s,"onresize",100),c.resize=function(){this.isResizeBound&&this.needsResizeLayout()&&this.layout()},c.needsResizeLayout=function(){var t=i(this.element),e=this.size&&t;return e&&t.innerWidth!==this.size.innerWidth},c.addItems=function(t){var e=this._itemize(t);return e.length&&(this.items=this.items.concat(e)),e},c.appended=function(t){var e=this.addItems(t);e.length&&(this.layoutItems(e,!0),this.reveal(e))},c.prepended=function(t){var e=this._itemize(t);if(e.length){var i=this.items.slice(0);this.items=e.concat(i),this._resetLayout(),this._manageStamps(),this.layoutItems(e,!0),this.reveal(e),this.layoutItems(i)}},c.reveal=function(t){if(this._emitCompleteOnItems("reveal",t),t&&t.length){var e=this.updateStagger();t.forEach(function(t,i){t.stagger(i*e),t.reveal()})}},c.hide=function(t){if(this._emitCompleteOnItems("hide",t),t&&t.length){var e=this.updateStagger();t.forEach(function(t,i){t.stagger(i*e),t.hide()})}},c.revealItemElements=function(t){var e=this.getItems(t);this.reveal(e)},c.hideItemElements=function(t){var e=this.getItems(t);this.hide(e)},c.getItem=function(t){for(var e=0;e<this.items.length;e++){var i=this.items[e];if(i.element==t)return i}},c.getItems=function(t){t=n.makeArray(t);var e=[];return t.forEach(function(t){var i=this.getItem(t);i&&e.push(i)},this),e},c.remove=function(t){var e=this.getItems(t);this._emitCompleteOnItems("remove",e),e&&e.length&&e.forEach(function(t){t.remove(),n.removeFrom(this.items,t)},this)},c.destroy=function(){var t=this.element.style;t.height="",t.position="",t.width="",this.items.forEach(function(t){t.destroy()}),this.unbindResize();var e=this.element.outlayerGUID;delete f[e],delete this.element.outlayerGUID,h&&h.removeData(this.element,this.constructor.namespace)},s.data=function(t){t=n.getQueryElement(t);var e=t&&t.outlayerGUID;return e&&f[e]},s.create=function(t,e){var i=r(s);return i.defaults=n.extend({},s.defaults),n.extend(i.defaults,e),i.compatOptions=n.extend({},s.compatOptions),i.namespace=t,i.data=s.data,i.Item=r(o),n.htmlInit(i,t),h&&h.bridget&&h.bridget(t,i),i};var m={ms:1,s:1e3};return s.Item=o,s}),function(t,e){"function"==typeof define&&define.amd?define("isotope/js/item",["outlayer/outlayer"],e):"object"==typeof module&&module.exports?module.exports=e(require("outlayer")):(t.Isotope=t.Isotope||{},t.Isotope.Item=e(t.Outlayer))}(window,function(t){"use strict";function e(){t.Item.apply(this,arguments)}var i=e.prototype=Object.create(t.Item.prototype),n=i._create;i._create=function(){this.id=this.layout.itemGUID++,n.call(this),this.sortData={}},i.updateSortData=function(){if(!this.isIgnored){this.sortData.id=this.id,this.sortData["original-order"]=this.id,this.sortData.random=Math.random();var t=this.layout.options.getSortData,e=this.layout._sorters;for(var i in t){var n=e[i];this.sortData[i]=n(this.element,this)}}};var o=i.destroy;return i.destroy=function(){o.apply(this,arguments),this.css({display:""})},e}),function(t,e){"function"==typeof define&&define.amd?define("isotope/js/layout-mode",["get-size/get-size","outlayer/outlayer"],e):"object"==typeof module&&module.exports?module.exports=e(require("get-size"),require("outlayer")):(t.Isotope=t.Isotope||{},t.Isotope.LayoutMode=e(t.getSize,t.Outlayer))}(window,function(t,e){"use strict";function i(t){this.isotope=t,t&&(this.options=t.options[this.namespace],this.element=t.element,this.items=t.filteredItems,this.size=t.size)}var n=i.prototype,o=["_resetLayout","_getItemLayoutPosition","_manageStamp","_getContainerSize","_getElementOffset","needsResizeLayout","_getOption"];return o.forEach(function(t){n[t]=function(){return e.prototype[t].apply(this.isotope,arguments)}}),n.needsVerticalResizeLayout=function(){var e=t(this.isotope.element),i=this.isotope.size&&e;return i&&e.innerHeight!=this.isotope.size.innerHeight},n._getMeasurement=function(){this.isotope._getMeasurement.apply(this,arguments)},n.getColumnWidth=function(){this.getSegmentSize("column","Width")},n.getRowHeight=function(){this.getSegmentSize("row","Height")},n.getSegmentSize=function(t,e){var i=t+e,n="outer"+e;if(this._getMeasurement(i,n),!this[i]){var o=this.getFirstItemSize();this[i]=o&&o[n]||this.isotope.size["inner"+e]}},n.getFirstItemSize=function(){var e=this.isotope.filteredItems[0];return e&&e.element&&t(e.element)},n.layout=function(){this.isotope.layout.apply(this.isotope,arguments)},n.getSize=function(){this.isotope.getSize(),this.size=this.isotope.size},i.modes={},i.create=function(t,e){function o(){i.apply(this,arguments)}return o.prototype=Object.create(n),o.prototype.constructor=o,e&&(o.options=e),o.prototype.namespace=t,i.modes[t]=o,o},i}),function(t,e){"function"==typeof define&&define.amd?define("masonry/masonry",["outlayer/outlayer","get-size/get-size"],e):"object"==typeof module&&module.exports?module.exports=e(require("outlayer"),require("get-size")):t.Masonry=e(t.Outlayer,t.getSize)}(window,function(t,e){var i=t.create("masonry");return i.compatOptions.fitWidth="isFitWidth",i.prototype._resetLayout=function(){this.getSize(),this._getMeasurement("columnWidth","outerWidth"),this._getMeasurement("gutter","outerWidth"),this.measureColumns(),this.colYs=[];for(var t=0;t<this.cols;t++)this.colYs.push(0);this.maxY=0},i.prototype.measureColumns=function(){if(this.getContainerWidth(),!this.columnWidth){var t=this.items[0],i=t&&t.element;this.columnWidth=i&&e(i).outerWidth||this.containerWidth}var n=this.columnWidth+=this.gutter,o=this.containerWidth+this.gutter,s=o/n,r=n-o%n,a=r&&1>r?"round":"floor";s=Math[a](s),this.cols=Math.max(s,1)},i.prototype.getContainerWidth=function(){var t=this._getOption("fitWidth"),i=t?this.element.parentNode:this.element,n=e(i);this.containerWidth=n&&n.innerWidth},i.prototype._getItemLayoutPosition=function(t){t.getSize();var e=t.size.outerWidth%this.columnWidth,i=e&&1>e?"round":"ceil",n=Math[i](t.size.outerWidth/this.columnWidth);n=Math.min(n,this.cols);for(var o=this._getColGroup(n),s=Math.min.apply(Math,o),r=o.indexOf(s),a={x:this.columnWidth*r,y:s},u=s+t.size.outerHeight,h=this.cols+1-o.length,d=0;h>d;d++)this.colYs[r+d]=u;return a},i.prototype._getColGroup=function(t){if(2>t)return this.colYs;for(var e=[],i=this.cols+1-t,n=0;i>n;n++){var o=this.colYs.slice(n,n+t);e[n]=Math.max.apply(Math,o)}return e},i.prototype._manageStamp=function(t){var i=e(t),n=this._getElementOffset(t),o=this._getOption("originLeft"),s=o?n.left:n.right,r=s+i.outerWidth,a=Math.floor(s/this.columnWidth);a=Math.max(0,a);var u=Math.floor(r/this.columnWidth);u-=r%this.columnWidth?0:1,u=Math.min(this.cols-1,u);for(var h=this._getOption("originTop"),d=(h?n.top:n.bottom)+i.outerHeight,l=a;u>=l;l++)this.colYs[l]=Math.max(d,this.colYs[l])},i.prototype._getContainerSize=function(){this.maxY=Math.max.apply(Math,this.colYs);var t={height:this.maxY};return this._getOption("fitWidth")&&(t.width=this._getContainerFitWidth()),t},i.prototype._getContainerFitWidth=function(){for(var t=0,e=this.cols;--e&&0===this.colYs[e];)t++;return(this.cols-t)*this.columnWidth-this.gutter},i.prototype.needsResizeLayout=function(){var t=this.containerWidth;return this.getContainerWidth(),t!=this.containerWidth},i}),function(t,e){"function"==typeof define&&define.amd?define("isotope/js/layout-modes/masonry",["../layout-mode","masonry/masonry"],e):"object"==typeof module&&module.exports?module.exports=e(require("../layout-mode"),require("masonry-layout")):e(t.Isotope.LayoutMode,t.Masonry)}(window,function(t,e){"use strict";var i=t.create("masonry"),n=i.prototype,o={_getElementOffset:!0,layout:!0,_getMeasurement:!0};for(var s in e.prototype)o[s]||(n[s]=e.prototype[s]);var r=n.measureColumns;n.measureColumns=function(){this.items=this.isotope.filteredItems,r.call(this)};var a=n._getOption;return n._getOption=function(t){return"fitWidth"==t?void 0!==this.options.isFitWidth?this.options.isFitWidth:this.options.fitWidth:a.apply(this.isotope,arguments)},i}),function(t,e){"function"==typeof define&&define.amd?define("isotope/js/layout-modes/fit-rows",["../layout-mode"],e):"object"==typeof exports?module.exports=e(require("../layout-mode")):e(t.Isotope.LayoutMode)}(window,function(t){"use strict";var e=t.create("fitRows"),i=e.prototype;return i._resetLayout=function(){this.x=0,this.y=0,this.maxY=0,this._getMeasurement("gutter","outerWidth")},i._getItemLayoutPosition=function(t){t.getSize();var e=t.size.outerWidth+this.gutter,i=this.isotope.size.innerWidth+this.gutter;0!==this.x&&e+this.x>i&&(this.x=0,this.y=this.maxY);var n={x:this.x,y:this.y};return this.maxY=Math.max(this.maxY,this.y+t.size.outerHeight),this.x+=e,n},i._getContainerSize=function(){return{height:this.maxY}},e}),function(t,e){"function"==typeof define&&define.amd?define("isotope/js/layout-modes/vertical",["../layout-mode"],e):"object"==typeof module&&module.exports?module.exports=e(require("../layout-mode")):e(t.Isotope.LayoutMode)}(window,function(t){"use strict";var e=t.create("vertical",{horizontalAlignment:0}),i=e.prototype;return i._resetLayout=function(){this.y=0},i._getItemLayoutPosition=function(t){t.getSize();var e=(this.isotope.size.innerWidth-t.size.outerWidth)*this.options.horizontalAlignment,i=this.y;return this.y+=t.size.outerHeight,{x:e,y:i}},i._getContainerSize=function(){return{height:this.y}},e}),function(t,e){"function"==typeof define&&define.amd?define(["outlayer/outlayer","get-size/get-size","desandro-matches-selector/matches-selector","fizzy-ui-utils/utils","isotope/js/item","isotope/js/layout-mode","isotope/js/layout-modes/masonry","isotope/js/layout-modes/fit-rows","isotope/js/layout-modes/vertical"],function(i,n,o,s,r,a){return e(t,i,n,o,s,r,a)}):"object"==typeof module&&module.exports?module.exports=e(t,require("outlayer"),require("get-size"),require("desandro-matches-selector"),require("fizzy-ui-utils"),require("isotope/js/item"),require("isotope/js/layout-mode"),require("isotope/js/layout-modes/masonry"),require("isotope/js/layout-modes/fit-rows"),require("isotope/js/layout-modes/vertical")):t.Isotope=e(t,t.Outlayer,t.getSize,t.matchesSelector,t.fizzyUIUtils,t.Isotope.Item,t.Isotope.LayoutMode)}(window,function(t,e,i,n,o,s,r){function a(t,e){return function(i,n){for(var o=0;o<t.length;o++){var s=t[o],r=i.sortData[s],a=n.sortData[s];if(r>a||a>r){var u=void 0!==e[s]?e[s]:e,h=u?1:-1;return(r>a?1:-1)*h}}return 0}}var u=t.jQuery,h=String.prototype.trim?function(t){return t.trim()}:function(t){return t.replace(/^\s+|\s+$/g,"")},d=e.create("isotope",{layoutMode:"masonry",isJQueryFiltering:!0,sortAscending:!0});d.Item=s,d.LayoutMode=r;var l=d.prototype;l._create=function(){this.itemGUID=0,this._sorters={},this._getSorters(),e.prototype._create.call(this),this.modes={},this.filteredItems=this.items,this.sortHistory=["original-order"];for(var t in r.modes)this._initLayoutMode(t)},l.reloadItems=function(){this.itemGUID=0,e.prototype.reloadItems.call(this)},l._itemize=function(){for(var t=e.prototype._itemize.apply(this,arguments),i=0;i<t.length;i++){var n=t[i];n.id=this.itemGUID++}return this._updateItemsSortData(t),t},l._initLayoutMode=function(t){var e=r.modes[t],i=this.options[t]||{};this.options[t]=e.options?o.extend(e.options,i):i,this.modes[t]=new e(this)},l.layout=function(){return!this._isLayoutInited&&this._getOption("initLayout")?void this.arrange():void this._layout()},l._layout=function(){var t=this._getIsInstant();this._resetLayout(),this._manageStamps(),this.layoutItems(this.filteredItems,t),this._isLayoutInited=!0},l.arrange=function(t){this.option(t),this._getIsInstant();var e=this._filter(this.items);this.filteredItems=e.matches,this._bindArrangeComplete(),this._isInstant?this._noTransition(this._hideReveal,[e]):this._hideReveal(e),this._sort(),this._layout()},l._init=l.arrange,l._hideReveal=function(t){this.reveal(t.needReveal),this.hide(t.needHide)},l._getIsInstant=function(){var t=this._getOption("layoutInstant"),e=void 0!==t?t:!this._isLayoutInited;return this._isInstant=e,e},l._bindArrangeComplete=function(){function t(){e&&i&&n&&o.dispatchEvent("arrangeComplete",null,[o.filteredItems])}var e,i,n,o=this;this.once("layoutComplete",function(){e=!0,t()}),this.once("hideComplete",function(){i=!0,t()}),this.once("revealComplete",function(){n=!0,t()})},l._filter=function(t){var e=this.options.filter;e=e||"*";for(var i=[],n=[],o=[],s=this._getFilterTest(e),r=0;r<t.length;r++){var a=t[r];if(!a.isIgnored){var u=s(a);u&&i.push(a),u&&a.isHidden?n.push(a):u||a.isHidden||o.push(a)}}return{matches:i,needReveal:n,needHide:o}},l._getFilterTest=function(t){return u&&this.options.isJQueryFiltering?function(e){return u(e.element).is(t)}:"function"==typeof t?function(e){return t(e.element)}:function(e){return n(e.element,t)}},l.updateSortData=function(t){var e;t?(t=o.makeArray(t),e=this.getItems(t)):e=this.items,this._getSorters(),this._updateItemsSortData(e)},l._getSorters=function(){var t=this.options.getSortData;for(var e in t){var i=t[e];this._sorters[e]=f(i)}},l._updateItemsSortData=function(t){for(var e=t&&t.length,i=0;e&&e>i;i++){var n=t[i];n.updateSortData()}};var f=function(){function t(t){if("string"!=typeof t)return t;var i=h(t).split(" "),n=i[0],o=n.match(/^\[(.+)\]$/),s=o&&o[1],r=e(s,n),a=d.sortDataParsers[i[1]];
		return t=a?function(t){return t&&a(r(t))}:function(t){return t&&r(t)}}function e(t,e){return t?function(e){return e.getAttribute(t)}:function(t){var i=t.querySelector(e);return i&&i.textContent}}return t}();d.sortDataParsers={parseInt:function(t){return parseInt(t,10)},parseFloat:function(t){return parseFloat(t)}},l._sort=function(){var t=this.options.sortBy;if(t){var e=[].concat.apply(t,this.sortHistory),i=a(e,this.options.sortAscending);this.filteredItems.sort(i),t!=this.sortHistory[0]&&this.sortHistory.unshift(t)}},l._mode=function(){var t=this.options.layoutMode,e=this.modes[t];if(!e)throw new Error("No layout mode: "+t);return e.options=this.options[t],e},l._resetLayout=function(){e.prototype._resetLayout.call(this),this._mode()._resetLayout()},l._getItemLayoutPosition=function(t){return this._mode()._getItemLayoutPosition(t)},l._manageStamp=function(t){this._mode()._manageStamp(t)},l._getContainerSize=function(){return this._mode()._getContainerSize()},l.needsResizeLayout=function(){return this._mode().needsResizeLayout()},l.appended=function(t){var e=this.addItems(t);if(e.length){var i=this._filterRevealAdded(e);this.filteredItems=this.filteredItems.concat(i)}},l.prepended=function(t){var e=this._itemize(t);if(e.length){this._resetLayout(),this._manageStamps();var i=this._filterRevealAdded(e);this.layoutItems(this.filteredItems),this.filteredItems=i.concat(this.filteredItems),this.items=e.concat(this.items)}},l._filterRevealAdded=function(t){var e=this._filter(t);return this.hide(e.needHide),this.reveal(e.matches),this.layoutItems(e.matches,!0),e.matches},l.insert=function(t){var e=this.addItems(t);if(e.length){var i,n,o=e.length;for(i=0;o>i;i++)n=e[i],this.element.appendChild(n.element);var s=this._filter(e).matches;for(i=0;o>i;i++)e[i].isLayoutInstant=!0;for(this.arrange(),i=0;o>i;i++)delete e[i].isLayoutInstant;this.reveal(s)}};var c=l.remove;return l.remove=function(t){t=o.makeArray(t);var e=this.getItems(t);c.call(this,t);for(var i=e&&e.length,n=0;i&&i>n;n++){var s=e[n];o.removeFrom(this.filteredItems,s)}},l.shuffle=function(){for(var t=0;t<this.items.length;t++){var e=this.items[t];e.sortData.random=Math.random()}this.options.sortBy="random",this._sort(),this._layout()},l._noTransition=function(t,e){var i=this.options.transitionDuration;this.options.transitionDuration=0;var n=t.apply(this,e);return this.options.transitionDuration=i,n},l.getFilteredItemElements=function(){return this.filteredItems.map(function(t){return t.element})},d});
		
		
		
		var SetIsotope = {
			init : function(){
				this.define();
				this.setHeight();
				this.lazyLoadBg();
				this.setHtml();
				this.isotope();
				this.onHandler();
			},
			define : function(){
				this.gridWrap = $("#isotope");
				this.item = this.gridWrap.children(".grid_item");
				this.itemSmall = this.gridWrap.children(".grid_item").not(".big");
				this.itemBig = this.gridWrap.children(".grid_item.big");
				this.img = "img[data-lazy]:not(.jsPrint)";
			},
			lazyLoadBg : function(){
				if ($(".pgPdfBrochure").length > 0) {
					SetIsotope.img = "img.jsPrint[data-lazy], .bgContainerBgImage"
				}
				var dataSrc,dataSrc2,dataSrc3;
				if( Modernizr.mq("only all and (max-width:767px)")) {
					dataSrc = "data-mobile-src";
					dataSrc2 = "data-tablet-src";
					dataSrc3 = "data-pc-src";
				} else if(Modernizr.mq("only all and (max-width:1024px) and (min-width: 768px)" )) {
					dataSrc = "data-tablet-src";
					dataSrc2 = "data-mobile-src";
					dataSrc3 = "data-pc-src";
				} else {
					dataSrc = "data-pc-src";
					dataSrc2 = "data-mobile-src";
					dataSrc3 = "data-tablet-src";
				}
				SetIsotope.item.each(function(c,e) {
					var $this = $(e);
					if( !$this.children(".bg_div").length ) SetIsotope.item.prepend("<div class='bg_div'></div>")
					$this.children(".bg_div").css("background-image", 'url("' + ($this.find("img").attr(dataSrc) || $this.find("img").attr(dataSrc2) ) + '")');
				})
			},
			setHtml : function(){
				this.item.each(function(idx,ele){
					var $wrap = $(ele).find(".inner_item");
					$wrap.children().each(function(i,e){
						var $self = $(e);
						var clsName = $self.attr("class");
						switch(clsName){
							case "bg" :
								if(!$self.data("minSrc") && !$self.data("maxSrc")) $wrap.prev(".bg_div").addClass( $self.data("bgColor") );
							break;
							case "item_btns" :
								if(!$self.children().length) $self.addClass("none");
							break;
							default :
								if(!$self.text().replace(/^\s+|\s+$/g,"")) {
									$self.addClass("none");
								}
							break;
						}
						var dataClass = $self.data("class");
						if(dataClass) $self.addClass(dataClass);
					})
				});
			},
			isotope : function(){
				SetIsotope.$grid = SetIsotope.gridWrap.isotope({
					percentPosition: true,
					layoutMode: "masonry",
					itemSelector: ".grid_item",
					filter: $("[data-filter]").attr("data-filter"),
					masonry: {
						columnWidth: '.grid_sizer'
					},
					sortBy: "original-order"
				});
			},
			onHandler : function(){
				$(window).on("resize",SetIsotope.setHeight);
				SetIsotope.item.on("mouseenter mouseleave",function(e){
					var $wrap = $(this).find(".bg_div");
					e.type == "mouseenter" ? $wrap.addClass("over") : $wrap.removeClass("over")
				})
				$("#filter_sec").on("click", "[data-filter]", function(e) {
					var $this = $(this);
					var filter = $this.attr("data-filter");
					SetIsotope.gridWrap.isotope({
						filter : filter
					})
					$this.parent().addClass("on").siblings().removeClass("on");
					e.preventDefault();
				});
				$('[data-filter="*"]').click();
			},
			setHeight : function(){
				var w = Math.floor( SetIsotope.itemSmall.outerWidth() );
				SetIsotope.itemSmall.outerHeight(w);
				SetIsotope.itemBig.outerHeight( w*2 ) ;
			}
		}
				
		SetIsotope.init();
	}
	
});
(function(window, factory) {
	var lazySizes = factory(window, window.document, Date);
	window.lazySizes = lazySizes;
	if(typeof module == 'object' && module.exports){
		module.exports = lazySizes;
	}
}(typeof window != 'undefined' ?
      window : {}, function l(window, document, Date) { // Pass in the windoe Date function also for SSR because the Date class can be lost
	'use strict';
	/*jshint eqnull:true */

	var lazysizes, lazySizesCfg;

	(function(){
		var prop;

		var lazySizesDefaults = {
			lazyClass: 'lazyload',
			loadedClass: 'lazyloaded',
			loadingClass: 'lazyloading',
			preloadClass: 'lazypreload',
			errorClass: 'lazyerror',
			//strictClass: 'lazystrict',
			autosizesClass: 'lazyautosizes',
			srcAttr: 'data-src',
			srcsetAttr: 'data-srcset',
			sizesAttr: 'data-sizes',
			//preloadAfterLoad: false,
			minSize: 40,
			customMedia: {},
			init: true,
			expFactor: 1.5,
			hFac: 0.8,
			loadMode: 1,
			loadHidden: true,
			ricTimeout: 0,
			throttleDelay: 125,
		};

		lazySizesCfg = window.lazySizesConfig || window.lazysizesConfig || {};

		for(prop in lazySizesDefaults){
			if(!(prop in lazySizesCfg)){
				lazySizesCfg[prop] = lazySizesDefaults[prop];
			}
		}
	})();

	if (!document || !document.getElementsByClassName) {
		return {
			init: function () {},
			cfg: lazySizesCfg,
			noSupport: true,
		};
	}

	var docElem = document.documentElement;

	var supportPicture = window.HTMLPictureElement;

	var _addEventListener = 'addEventListener';

	var _getAttribute = 'getAttribute';

	/**
	 * Update to bind to window because 'this' becomes null during SSR
	 * builds.
	 */
	var addEventListener = window[_addEventListener].bind(window);

	var setTimeout = window.setTimeout;

	var requestAnimationFrame = window.requestAnimationFrame || setTimeout;

	var requestIdleCallback = window.requestIdleCallback;

	var regPicture = /^picture$/i;

	var loadEvents = ['load', 'error', 'lazyincluded', '_lazyloaded'];

	var regClassCache = {};

	var forEach = Array.prototype.forEach;

	var hasClass = function(ele, cls) {
		if(!regClassCache[cls]){
			regClassCache[cls] = new RegExp('(\\s|^)'+cls+'(\\s|$)');
		}
		return regClassCache[cls].test(ele[_getAttribute]('class') || '') && regClassCache[cls];
	};

	var addClass = function(ele, cls) {
		if (!hasClass(ele, cls)){
			ele.setAttribute('class', (ele[_getAttribute]('class') || '').trim() + ' ' + cls);
		}
	};

	var removeClass = function(ele, cls) {
		var reg;
		if ((reg = hasClass(ele,cls))) {
			ele.setAttribute('class', (ele[_getAttribute]('class') || '').replace(reg, ' '));
		}
	};

	var addRemoveLoadEvents = function(dom, fn, add){
		var action = add ? _addEventListener : 'removeEventListener';
		if(add){
			addRemoveLoadEvents(dom, fn);
		}
		loadEvents.forEach(function(evt){
			dom[action](evt, fn);
		});
	};

	var triggerEvent = function(elem, name, detail, noBubbles, noCancelable){
		var event = document.createEvent('Event');

		if(!detail){
			detail = {};
		}

		detail.instance = lazysizes;

		event.initEvent(name, !noBubbles, !noCancelable);

		event.detail = detail;

		elem.dispatchEvent(event);
		return event;
	};

	var updatePolyfill = function (el, full){
		var polyfill;
		if( !supportPicture && ( polyfill = (window.picturefill || lazySizesCfg.pf) ) ){
			if(full && full.src && !el[_getAttribute]('srcset')){
				el.setAttribute('srcset', full.src);
			}
			polyfill({reevaluate: true, elements: [el]});
		} else if(full && full.src){
			el.src = full.src;
		}
	};

	var getCSS = function (elem, style){
		return (getComputedStyle(elem, null) || {})[style];
	};

	var getWidth = function(elem, parent, width){
		width = width || elem.offsetWidth;

		while(width < lazySizesCfg.minSize && parent && !elem._lazysizesWidth){
			width =  parent.offsetWidth;
			parent = parent.parentNode;
		}

		return width;
	};

	var rAF = (function(){
		var running, waiting;
		var firstFns = [];
		var secondFns = [];
		var fns = firstFns;

		var run = function(){
			var runFns = fns;

			fns = firstFns.length ? secondFns : firstFns;

			running = true;
			waiting = false;

			while(runFns.length){
				runFns.shift()();
			}

			running = false;
		};

		var rafBatch = function(fn, queue){
			if(running && !queue){
				fn.apply(this, arguments);
			} else {
				fns.push(fn);

				if(!waiting){
					waiting = true;
					(document.hidden ? setTimeout : requestAnimationFrame)(run);
				}
			}
		};

		rafBatch._lsFlush = run;

		return rafBatch;
	})();

	var rAFIt = function(fn, simple){
		return simple ?
			function() {
				rAF(fn);
			} :
			function(){
				var that = this;
				var args = arguments;
				rAF(function(){
					fn.apply(that, args);
				});
			}
		;
	};

	var throttle = function(fn){
		var running;
		var lastTime = 0;
		var gDelay = lazySizesCfg.throttleDelay;
		var rICTimeout = lazySizesCfg.ricTimeout;
		var run = function(){
			running = false;
			lastTime = Date.now();
			fn();
		};
		var idleCallback = requestIdleCallback && rICTimeout > 49 ?
			function(){
				requestIdleCallback(run, {timeout: rICTimeout});

				if(rICTimeout !== lazySizesCfg.ricTimeout){
					rICTimeout = lazySizesCfg.ricTimeout;
				}
			} :
			rAFIt(function(){
				setTimeout(run);
			}, true)
		;

		return function(isPriority){
			var delay;

			if((isPriority = isPriority === true)){
				rICTimeout = 33;
			}

			if(running){
				return;
			}

			running =  true;

			delay = gDelay - (Date.now() - lastTime);

			if(delay < 0){
				delay = 0;
			}

			if(isPriority || delay < 9){
				idleCallback();
			} else {
				setTimeout(idleCallback, delay);
			}
		};
	};

	//based on http://modernjavascript.blogspot.de/2013/08/building-better-debounce.html
	var debounce = function(func) {
		var timeout, timestamp;
		var wait = 99;
		var run = function(){
			timeout = null;
			func();
		};
		var later = function() {
			var last = Date.now() - timestamp;

			if (last < wait) {
				setTimeout(later, wait - last);
			} else {
				(requestIdleCallback || run)(run);
			}
		};

		return function() {
			timestamp = Date.now();

			if (!timeout) {
				timeout = setTimeout(later, wait);
			}
		};
	};

	var loader = (function(){
		var preloadElems, isCompleted, resetPreloadingTimer, loadMode, started;

		var eLvW, elvH, eLtop, eLleft, eLright, eLbottom, isBodyHidden;

		var regImg = /^img$/i;
		var regIframe = /^iframe$/i;

		var supportScroll = ('onscroll' in window) && !(/(gle|ing)bot/.test(navigator.userAgent));

		var shrinkExpand = 0;
		var currentExpand = 0;

		var isLoading = 0;
		var lowRuns = -1;

		var resetPreloading = function(e){
			isLoading--;
			if(!e || isLoading < 0 || !e.target){
				isLoading = 0;
			}
		};

		var isVisible = function (elem) {
			if (isBodyHidden == null) {
				isBodyHidden = getCSS(document.body, 'visibility') == 'hidden';
			}

			return isBodyHidden || !(getCSS(elem.parentNode, 'visibility') == 'hidden' && getCSS(elem, 'visibility') == 'hidden');
		};

		var isNestedVisible = function(elem, elemExpand){
			var outerRect;
			var parent = elem;
			var visible = isVisible(elem);

			eLtop -= elemExpand;
			eLbottom += elemExpand;
			eLleft -= elemExpand;
			eLright += elemExpand;

			while(visible && (parent = parent.offsetParent) && parent != document.body && parent != docElem){
				visible = ((getCSS(parent, 'opacity') || 1) > 0);

				if(visible && getCSS(parent, 'overflow') != 'visible'){
					outerRect = parent.getBoundingClientRect();
					visible = eLright > outerRect.left &&
						eLleft < outerRect.right &&
						eLbottom > outerRect.top - 1 &&
						eLtop < outerRect.bottom + 1
					;
				}
			}

			return visible;
		};

		var checkElements = function() {
			var eLlen, i, rect, autoLoadElem, loadedSomething, elemExpand, elemNegativeExpand, elemExpandVal,
				beforeExpandVal, defaultExpand, preloadExpand, hFac;
			var lazyloadElems = lazysizes.elements;

            //console.log(lazyloadElems)
			if((loadMode = lazySizesCfg.loadMode) && isLoading < 8 && (eLlen = lazyloadElems.length)){

				i = 0;

				lowRuns++;

				for(; i < eLlen; i++){

					if(!lazyloadElems[i] || lazyloadElems[i]._lazyRace){continue;}

					if(!supportScroll || (lazysizes.prematureUnveil && lazysizes.prematureUnveil(lazyloadElems[i]))){unveilElement(lazyloadElems[i]);continue;}

					if(!(elemExpandVal = lazyloadElems[i][_getAttribute]('data-expand')) || !(elemExpand = elemExpandVal * 1)){
						elemExpand = currentExpand;
					}

					if (!defaultExpand) {
						defaultExpand = (!lazySizesCfg.expand || lazySizesCfg.expand < 1) ?
							docElem.clientHeight > 500 && docElem.clientWidth > 500 ? 500 : 370 :
							lazySizesCfg.expand;

						lazysizes._defEx = defaultExpand;

						preloadExpand = defaultExpand * lazySizesCfg.expFactor;
						hFac = lazySizesCfg.hFac;
						isBodyHidden = null;

						if(currentExpand < preloadExpand && isLoading < 1 && lowRuns > 2 && loadMode > 2 && !document.hidden){
							currentExpand = preloadExpand;
							lowRuns = 0;
						} else if(loadMode > 1 && lowRuns > 1 && isLoading < 6){
							currentExpand = defaultExpand;
						} else {
							currentExpand = shrinkExpand;
						}
					}

					if(beforeExpandVal !== elemExpand){
						eLvW = innerWidth + (elemExpand * hFac);
						elvH = innerHeight + elemExpand;
						elemNegativeExpand = elemExpand * -1;
						beforeExpandVal = elemExpand;
					}

					rect = lazyloadElems[i].getBoundingClientRect();

                    //console.log(rect)

                    //console.log( (eLbottom = rect.bottom) >= elemNegativeExpand )
                    //console.log( (eLtop = rect.top) <= elvH )
                    //console.log( (eLright = rect.right) >= elemNegativeExpand * hFac )
                    //console.log( (eLleft = rect.left) <= eLvW )
                    //console.log( (eLbottom || eLright || eLleft || eLtop) )
                    //console.log( (lazySizesCfg.loadHidden || isVisible(lazyloadElems[i])) )
                    //console.log( ((isCompleted && isLoading < 3 && !elemExpandVal && (loadMode < 3 || lowRuns < 4)) || isNestedVisible(lazyloadElems[i], elemExpand)) )



					if ((eLbottom = rect.bottom) >= elemNegativeExpand &&
						(eLtop = rect.top) <= elvH &&
						(eLright = rect.right) >= elemNegativeExpand * hFac &&
						(eLleft = rect.left) <= eLvW &&
						(eLbottom || eLright || eLleft || eLtop) &&
						(lazySizesCfg.loadHidden || isVisible(lazyloadElems[i])) &&
						((isCompleted && isLoading < 3 && !elemExpandVal && (loadMode < 3 || lowRuns < 4)) || isNestedVisible(lazyloadElems[i], elemExpand))){
//console.log('if============================================')
						unveilElement(lazyloadElems[i]);
						loadedSomething = true;
						if(isLoading > 9){break;}
					} else if(!loadedSomething && isCompleted && !autoLoadElem &&
						isLoading < 4 && lowRuns < 4 && loadMode > 2 &&
						(preloadElems[0] || lazySizesCfg.preloadAfterLoad) &&
						(preloadElems[0] || (!elemExpandVal && ((eLbottom || eLright || eLleft || eLtop) || lazyloadElems[i][_getAttribute](lazySizesCfg.sizesAttr) != 'auto')))){
//console.log('else if============================================')
						autoLoadElem = preloadElems[0] || lazyloadElems[i];
					} else {
//console.log('else===============================================')
                    }
				}

				if(autoLoadElem && !loadedSomething){
					unveilElement(autoLoadElem);
				}
			}
		};

		var throttledCheckElements = throttle(checkElements);
		//console.log(throttledCheckElements)
		var switchLoadingClass = function(e){
			var elem = e.target;

			if (elem._lazyCache) {
				delete elem._lazyCache;
				return;
			}

			resetPreloading(e);
			addClass(elem, lazySizesCfg.loadedClass);
			removeClass(elem, lazySizesCfg.loadingClass);
			addRemoveLoadEvents(elem, rafSwitchLoadingClass);
			triggerEvent(elem, 'lazyloaded');
		};
		var rafedSwitchLoadingClass = rAFIt(switchLoadingClass);
		var rafSwitchLoadingClass = function(e){
			rafedSwitchLoadingClass({target: e.target});
		};

		var changeIframeSrc = function(elem, src){
			try {
				elem.contentWindow.location.replace(src);
			} catch(e){
				elem.src = src;
			}
		};

		var handleSources = function(source){
			var customMedia;

			var sourceSrcset = source[_getAttribute](lazySizesCfg.srcsetAttr);

			if( (customMedia = lazySizesCfg.customMedia[source[_getAttribute]('data-media') || source[_getAttribute]('media')]) ){
				source.setAttribute('media', customMedia);
			}

			if(sourceSrcset){
				source.setAttribute('srcset', sourceSrcset);
			}
		};

		var lazyUnveil = rAFIt(function (elem, detail, isAuto, sizes, isImg){
			var src, srcset, parent, isPicture, event, firesLoad;

			if(!(event = triggerEvent(elem, 'lazybeforeunveil', detail)).defaultPrevented){

				if(sizes){
					if(isAuto){
						addClass(elem, lazySizesCfg.autosizesClass);
					} else {
						elem.setAttribute('sizes', sizes);
					}
				}

				srcset = elem[_getAttribute](lazySizesCfg.srcsetAttr);
				src = elem[_getAttribute](lazySizesCfg.srcAttr);

				if(isImg) {
					parent = elem.parentNode;
					isPicture = parent && regPicture.test(parent.nodeName || '');
				}

				firesLoad = detail.firesLoad || (('src' in elem) && (srcset || src || isPicture));

				event = {target: elem};

				addClass(elem, lazySizesCfg.loadingClass);

				if(firesLoad){
					clearTimeout(resetPreloadingTimer);
					resetPreloadingTimer = setTimeout(resetPreloading, 2500);
					addRemoveLoadEvents(elem, rafSwitchLoadingClass, true);
				}

				if(isPicture){
					forEach.call(parent.getElementsByTagName('source'), handleSources);
				}

				if(srcset){
					elem.setAttribute('srcset', srcset);
				} else if(src && !isPicture){
					if(regIframe.test(elem.nodeName)){
						changeIframeSrc(elem, src);
					} else {
						elem.src = src;
					}
				}

				if(isImg && (srcset || isPicture)){
					updatePolyfill(elem, {src: src});
				}
			}

			if(elem._lazyRace){
				delete elem._lazyRace;
			}
			removeClass(elem, lazySizesCfg.lazyClass);

			rAF(function(){
				// Part of this can be removed as soon as this fix is older: https://bugs.chromium.org/p/chromium/issues/detail?id=7731 (2015)
				var isLoaded = elem.complete && elem.naturalWidth > 1;

				if( !firesLoad || isLoaded){
					if (isLoaded) {
						addClass(elem, 'ls-is-cached');
					}
					switchLoadingClass(event);
					elem._lazyCache = true;
					setTimeout(function(){
						if ('_lazyCache' in elem) {
							delete elem._lazyCache;
						}
					}, 9);
				}
				if (elem.loading == 'lazy') {
					isLoading--;
				}
			}, true);
		});

		var unveilElement = function (elem){
			if (elem._lazyRace) {return;}
			var detail;

			var isImg = regImg.test(elem.nodeName);

			//allow using sizes="auto", but don't use. it's invalid. Use data-sizes="auto" or a valid value for sizes instead (i.e.: sizes="80vw")
			var sizes = isImg && (elem[_getAttribute](lazySizesCfg.sizesAttr) || elem[_getAttribute]('sizes'));
			var isAuto = sizes == 'auto';

			if( (isAuto || !isCompleted) && isImg && (elem[_getAttribute]('src') || elem.srcset) && !elem.complete && !hasClass(elem, lazySizesCfg.errorClass) && hasClass(elem, lazySizesCfg.lazyClass)){return;}

			detail = triggerEvent(elem, 'lazyunveilread').detail;

			if(isAuto){
				 autoSizer.updateElem(elem, true, elem.offsetWidth);
			}

			elem._lazyRace = true;
			isLoading++;

			lazyUnveil(elem, detail, isAuto, sizes, isImg);
		};

		var afterScroll = debounce(function(){
			lazySizesCfg.loadMode = 3;
			throttledCheckElements();
		});

		var altLoadmodeScrollListner = function(){
			if(lazySizesCfg.loadMode == 3){
				lazySizesCfg.loadMode = 2;
			}
			afterScroll();
		};

		var onload = function(){
			if(isCompleted){return;}
			if(Date.now() - started < 999){
				setTimeout(onload, 999);
				return;
			}


			isCompleted = true;

			lazySizesCfg.loadMode = 3;

			throttledCheckElements();

			addEventListener('scroll', altLoadmodeScrollListner, true);
		};

		return {
			_: function(){
				started = Date.now();

				lazysizes.elements = document.getElementsByClassName(lazySizesCfg.lazyClass);
				preloadElems = document.getElementsByClassName(lazySizesCfg.lazyClass + ' ' + lazySizesCfg.preloadClass);

				addEventListener('scroll', throttledCheckElements, true);

				addEventListener('resize', throttledCheckElements, true);

				addEventListener('pageshow', function (e) {
					if (e.persisted) {
						var loadingElements = document.querySelectorAll('.' + lazySizesCfg.loadingClass);

						if (loadingElements.length && loadingElements.forEach) {
							requestAnimationFrame(function () {
								loadingElements.forEach( function (img) {
									if (img.complete) {
										unveilElement(img);
									}
								});
							});
						}
					}
				});

				if(window.MutationObserver){
					new MutationObserver( throttledCheckElements ).observe( docElem, {childList: true, subtree: true, attributes: true} );
				} else {
					docElem[_addEventListener]('DOMNodeInserted', throttledCheckElements, true);
					docElem[_addEventListener]('DOMAttrModified', throttledCheckElements, true);
					setInterval(throttledCheckElements, 999);
				}

				addEventListener('hashchange', throttledCheckElements, true);

				//, 'fullscreenchange'
				['focus', 'mouseover', 'click', 'load', 'transitionend', 'animationend'].forEach(function(name){
					document[_addEventListener](name, throttledCheckElements, true);
				});

				if((/d$|^c/.test(document.readyState))){
					onload();
				} else {
					addEventListener('load', onload);
					document[_addEventListener]('DOMContentLoaded', throttledCheckElements);
					setTimeout(onload, 20000);
				}

				if(lazysizes.elements.length){
					checkElements();
					rAF._lsFlush();
				} else {
					throttledCheckElements();
				}
			},
			checkElems: throttledCheckElements,
			unveil: unveilElement,
			_aLSL: altLoadmodeScrollListner,
		};
	})();


	var autoSizer = (function(){
		var autosizesElems;

		var sizeElement = rAFIt(function(elem, parent, event, width){
			var sources, i, len;
			elem._lazysizesWidth = width;
			width += 'px';

			elem.setAttribute('sizes', width);

			if(regPicture.test(parent.nodeName || '')){
				sources = parent.getElementsByTagName('source');
				for(i = 0, len = sources.length; i < len; i++){
					sources[i].setAttribute('sizes', width);
				}
			}

			if(!event.detail.dataAttr){
				updatePolyfill(elem, event.detail);
			}
		});
		var getSizeElement = function (elem, dataAttr, width){
			var event;
			var parent = elem.parentNode;

			if(parent){
				width = getWidth(elem, parent, width);
				event = triggerEvent(elem, 'lazybeforesizes', {width: width, dataAttr: !!dataAttr});

				if(!event.defaultPrevented){
					width = event.detail.width;

					if(width && width !== elem._lazysizesWidth){
						sizeElement(elem, parent, event, width);
					}
				}
			}
		};

		var updateElementsSizes = function(){
			var i;
			var len = autosizesElems.length;
			if(len){
				i = 0;

				for(; i < len; i++){
					getSizeElement(autosizesElems[i]);
				}
			}
		};

		var debouncedUpdateElementsSizes = debounce(updateElementsSizes);

		return {
			_: function(){
				autosizesElems = document.getElementsByClassName(lazySizesCfg.autosizesClass);
				addEventListener('resize', debouncedUpdateElementsSizes);
			},
			checkElems: debouncedUpdateElementsSizes,
			updateElem: getSizeElement
		};
	})();

	var init = function(){
		if(!init.i && document.getElementsByClassName){
			init.i = true;
			autoSizer._();
			loader._();
		}
	};

	setTimeout(function(){
		if(lazySizesCfg.init){
			init();
		}
	});

	lazysizes = {
		cfg: lazySizesCfg,
		autoSizer: autoSizer,
		loader: loader,
		init: init,
		uP: updatePolyfill,
		aC: addClass,
		rC: removeClass,
		hC: hasClass,
		fire: triggerEvent,
		gW: getWidth,
		rAF: rAF,
	};

	return lazysizes;
}
));

document.addEventListener('lazybeforeunveil', function(e){
    /*
    var bg = e.target.getAttribute('data-bg');
    if(bg){
        e.target.style.backgroundImage = 'url(' + bg + ')';
    }
    */

    //console.log('lazyload')
    //console.log(e)
    if( e.target.tagName == 'VIDEO' ) {
        var $_target = $(e.target).find('source');
        $(e.target).attr('src', $_target.data('src'));



        $(e.target).attr('poster', $(e.target).data('poster'))
        //console.log(e.target.poster )
        //console.log('lazyload proc =========== >')
    }
});
!function(i){"use strict";"function"==typeof define&&define.amd?define(["jquery"],i):"undefined"!=typeof exports?module.exports=i(require("jquery")):i(jQuery)}(function(i){"use strict";var e=window.Slick||{};(e=function(){var e=0;return function(t,o){var s,n=this;n.defaults={accessibility:!0,adaptiveHeight:!1,appendArrows:i(t),appendDots:i(t),arrows:!0,asNavFor:null,prevArrow:'<button class="slick-prev" aria-label="Previous" type="button">Previous</button>',nextArrow:'<button class="slick-next" aria-label="Next" type="button">Next</button>',autoplay:!1,autoplaySpeed:3e3,centerMode:!1,centerPadding:"50px",cssEase:"ease",customPaging:function(e,t){return i('<button type="button" />').text(t+1)},dots:!1,dotsClass:"slick-dots",draggable:!0,easing:"linear",edgeFriction:.35,fade:!1,focusOnSelect:!1,focusOnChange:!1,infinite:!0,initialSlide:0,lazyLoad:"ondemand",mobileFirst:!1,pauseOnHover:!0,pauseOnFocus:!0,pauseOnDotsHover:!1,respondTo:"window",responsive:null,rows:1,rtl:!1,slide:"",slidesPerRow:1,slidesToShow:1,slidesToScroll:1,speed:500,swipe:!0,swipeToSlide:!1,touchMove:!0,touchThreshold:5,useCSS:!0,useTransform:!0,variableWidth:!1,vertical:!1,verticalSwiping:!1,waitForAnimate:!0,zIndex:1e3},n.initials={animating:!1,dragging:!1,autoPlayTimer:null,currentDirection:0,currentLeft:null,currentSlide:0,direction:1,$dots:null,listWidth:null,listHeight:null,loadIndex:0,$nextArrow:null,$prevArrow:null,scrolling:!1,slideCount:null,slideWidth:null,$slideTrack:null,$slides:null,sliding:!1,slideOffset:0,swipeLeft:null,swiping:!1,$list:null,touchObject:{},transformsEnabled:!1,unslicked:!1},i.extend(n,n.initials),n.activeBreakpoint=null,n.animType=null,n.animProp=null,n.breakpoints=[],n.breakpointSettings=[],n.cssTransitions=!1,n.focussed=!1,n.interrupted=!1,n.hidden="hidden",n.paused=!0,n.positionProp=null,n.respondTo=null,n.rowCount=1,n.shouldClick=!0,n.$slider=i(t),n.$slidesCache=null,n.transformType=null,n.transitionType=null,n.visibilityChange="visibilitychange",n.windowWidth=0,n.windowTimer=null,s=i(t).data("slick")||{},n.options=i.extend({},n.defaults,o,s),n.currentSlide=n.options.initialSlide,n.originalSettings=n.options,void 0!==document.mozHidden?(n.hidden="mozHidden",n.visibilityChange="mozvisibilitychange"):void 0!==document.webkitHidden&&(n.hidden="webkitHidden",n.visibilityChange="webkitvisibilitychange"),n.autoPlay=i.proxy(n.autoPlay,n),n.autoPlayClear=i.proxy(n.autoPlayClear,n),n.autoPlayIterator=i.proxy(n.autoPlayIterator,n),n.changeSlide=i.proxy(n.changeSlide,n),n.clickHandler=i.proxy(n.clickHandler,n),n.selectHandler=i.proxy(n.selectHandler,n),n.setPosition=i.proxy(n.setPosition,n),n.swipeHandler=i.proxy(n.swipeHandler,n),n.dragHandler=i.proxy(n.dragHandler,n),n.keyHandler=i.proxy(n.keyHandler,n),n.instanceUid=e++,n.htmlExpr=/^(?:\s*(<[\w\W]+>)[^>]*)$/,n.registerBreakpoints(),n.init(!0)}}()).prototype.activateADA=function(){this.$slideTrack.find(".slick-active").attr({"aria-hidden":"false"}).find("a, input, button, select").attr({tabindex:"0"})},e.prototype.addSlide=e.prototype.slickAdd=function(e,t,o){var s=this;if("boolean"==typeof t)o=t,t=null;else if(t<0||t>=s.slideCount)return!1;s.unload(),"number"==typeof t?0===t&&0===s.$slides.length?i(e).appendTo(s.$slideTrack):o?i(e).insertBefore(s.$slides.eq(t)):i(e).insertAfter(s.$slides.eq(t)):!0===o?i(e).prependTo(s.$slideTrack):i(e).appendTo(s.$slideTrack),s.$slides=s.$slideTrack.children(this.options.slide),s.$slideTrack.children(this.options.slide).detach(),s.$slideTrack.append(s.$slides),s.$slides.each(function(e,t){i(t).attr("data-slick-index",e)}),s.$slidesCache=s.$slides,s.reinit()},e.prototype.animateHeight=function(){var i=this;if(1===i.options.slidesToShow&&!0===i.options.adaptiveHeight&&!1===i.options.vertical){var e=i.$slides.eq(i.currentSlide).outerHeight(!0);i.$list.animate({height:e},i.options.speed)}},e.prototype.animateSlide=function(e,t){var o={},s=this;s.animateHeight(),!0===s.options.rtl&&!1===s.options.vertical&&(e=-e),!1===s.transformsEnabled?!1===s.options.vertical?s.$slideTrack.animate({left:e},s.options.speed,s.options.easing,t):s.$slideTrack.animate({top:e},s.options.speed,s.options.easing,t):!1===s.cssTransitions?(!0===s.options.rtl&&(s.currentLeft=-s.currentLeft),i({animStart:s.currentLeft}).animate({animStart:e},{duration:s.options.speed,easing:s.options.easing,step:function(i){i=Math.ceil(i),!1===s.options.vertical?(o[s.animType]="translate("+i+"px, 0px)",s.$slideTrack.css(o)):(o[s.animType]="translate(0px,"+i+"px)",s.$slideTrack.css(o))},complete:function(){t&&t.call()}})):(s.applyTransition(),e=Math.ceil(e),!1===s.options.vertical?o[s.animType]="translate3d("+e+"px, 0px, 0px)":o[s.animType]="translate3d(0px,"+e+"px, 0px)",s.$slideTrack.css(o),t&&setTimeout(function(){s.disableTransition(),t.call()},s.options.speed))},e.prototype.getNavTarget=function(){var e=this,t=e.options.asNavFor;return t&&null!==t&&(t=i(t).not(e.$slider)),t},e.prototype.asNavFor=function(e){var t=this.getNavTarget();null!==t&&"object"==typeof t&&t.each(function(){var t=i(this).slick("getSlick");t.unslicked||t.slideHandler(e,!0)})},e.prototype.applyTransition=function(i){var e=this,t={};!1===e.options.fade?t[e.transitionType]=e.transformType+" "+e.options.speed+"ms "+e.options.cssEase:t[e.transitionType]="opacity "+e.options.speed+"ms "+e.options.cssEase,!1===e.options.fade?e.$slideTrack.css(t):e.$slides.eq(i).css(t)},e.prototype.autoPlay=function(){var i=this;i.autoPlayClear(),i.slideCount>i.options.slidesToShow&&(i.autoPlayTimer=setInterval(i.autoPlayIterator,i.options.autoplaySpeed))},e.prototype.autoPlayClear=function(){var i=this;i.autoPlayTimer&&clearInterval(i.autoPlayTimer)},e.prototype.autoPlayIterator=function(){var i=this,e=i.currentSlide+i.options.slidesToScroll;i.paused||i.interrupted||i.focussed||(!1===i.options.infinite&&(1===i.direction&&i.currentSlide+1===i.slideCount-1?i.direction=0:0===i.direction&&(e=i.currentSlide-i.options.slidesToScroll,i.currentSlide-1==0&&(i.direction=1))),i.slideHandler(e))},e.prototype.buildArrows=function(){var e=this;!0===e.options.arrows&&(e.$prevArrow=i(e.options.prevArrow).addClass("slick-arrow"),e.$nextArrow=i(e.options.nextArrow).addClass("slick-arrow"),e.slideCount>e.options.slidesToShow?(e.$prevArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"),e.$nextArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"),e.htmlExpr.test(e.options.prevArrow)&&e.$prevArrow.prependTo(e.options.appendArrows),e.htmlExpr.test(e.options.nextArrow)&&e.$nextArrow.appendTo(e.options.appendArrows),!0!==e.options.infinite&&e.$prevArrow.addClass("slick-disabled").attr("aria-disabled","true")):e.$prevArrow.add(e.$nextArrow).addClass("slick-hidden").attr({"aria-disabled":"true",tabindex:"-1"}))},e.prototype.buildDots=function(){var e,t,o=this;if(!0===o.options.dots){for(o.$slider.addClass("slick-dotted"),t=i("<ul />").addClass(o.options.dotsClass),e=0;e<=o.getDotCount();e+=1)t.append(i("<li />").append(o.options.customPaging.call(this,o,e)));o.$dots=t.appendTo(o.options.appendDots),o.$dots.find("li").first().addClass("slick-active")}},e.prototype.buildOut=function(){var e=this;e.$slides=e.$slider.children(e.options.slide+":not(.slick-cloned)").addClass("slick-slide"),e.slideCount=e.$slides.length,e.$slides.each(function(e,t){i(t).attr("data-slick-index",e).data("originalStyling",i(t).attr("style")||"")}),e.$slider.addClass("slick-slider"),e.$slideTrack=0===e.slideCount?i('<div class="slick-track"/>').appendTo(e.$slider):e.$slides.wrapAll('<div class="slick-track"/>').parent(),e.$list=e.$slideTrack.wrap('<div class="slick-list"/>').parent(),e.$slideTrack.css("opacity",0),!0!==e.options.centerMode&&!0!==e.options.swipeToSlide||(e.options.slidesToScroll=1),i("img[data-lazy]",e.$slider).not("[src]").addClass("slick-loading"),e.setupInfinite(),e.buildArrows(),e.buildDots(),e.updateDots(),e.setSlideClasses("number"==typeof e.currentSlide?e.currentSlide:0),!0===e.options.draggable&&e.$list.addClass("draggable")},e.prototype.buildRows=function(){var i,e,t,o,s,n,r,l=this;if(o=document.createDocumentFragment(),n=l.$slider.children(),l.options.rows>1){for(r=l.options.slidesPerRow*l.options.rows,s=Math.ceil(n.length/r),i=0;i<s;i++){var d=document.createElement("div");for(e=0;e<l.options.rows;e++){var a=document.createElement("div");for(t=0;t<l.options.slidesPerRow;t++){var c=i*r+(e*l.options.slidesPerRow+t);n.get(c)&&a.appendChild(n.get(c))}d.appendChild(a)}o.appendChild(d)}l.$slider.empty().append(o),l.$slider.children().children().children().css({width:100/l.options.slidesPerRow+"%",display:"inline-block"})}},e.prototype.checkResponsive=function(e,t){var o,s,n,r=this,l=!1,d=r.$slider.width(),a=window.innerWidth||i(window).width();if("window"===r.respondTo?n=a:"slider"===r.respondTo?n=d:"min"===r.respondTo&&(n=Math.min(a,d)),r.options.responsive&&r.options.responsive.length&&null!==r.options.responsive){s=null;for(o in r.breakpoints)r.breakpoints.hasOwnProperty(o)&&(!1===r.originalSettings.mobileFirst?n<r.breakpoints[o]&&(s=r.breakpoints[o]):n>r.breakpoints[o]&&(s=r.breakpoints[o]));null!==s?null!==r.activeBreakpoint?(s!==r.activeBreakpoint||t)&&(r.activeBreakpoint=s,"unslick"===r.breakpointSettings[s]?r.unslick(s):(r.options=i.extend({},r.originalSettings,r.breakpointSettings[s]),!0===e&&(r.currentSlide=r.options.initialSlide),r.refresh(e)),l=s):(r.activeBreakpoint=s,"unslick"===r.breakpointSettings[s]?r.unslick(s):(r.options=i.extend({},r.originalSettings,r.breakpointSettings[s]),!0===e&&(r.currentSlide=r.options.initialSlide),r.refresh(e)),l=s):null!==r.activeBreakpoint&&(r.activeBreakpoint=null,r.options=r.originalSettings,!0===e&&(r.currentSlide=r.options.initialSlide),r.refresh(e),l=s),e||!1===l||r.$slider.trigger("breakpoint",[r,l])}},e.prototype.changeSlide=function(e,t){var o,s,n,r=this,l=i(e.currentTarget);switch(l.is("a")&&e.preventDefault(),l.is("li")||(l=l.closest("li")),n=r.slideCount%r.options.slidesToScroll!=0,o=n?0:(r.slideCount-r.currentSlide)%r.options.slidesToScroll,e.data.message){case"previous":s=0===o?r.options.slidesToScroll:r.options.slidesToShow-o,r.slideCount>r.options.slidesToShow&&r.slideHandler(r.currentSlide-s,!1,t);break;case"next":s=0===o?r.options.slidesToScroll:o,r.slideCount>r.options.slidesToShow&&r.slideHandler(r.currentSlide+s,!1,t);break;case"index":var d=0===e.data.index?0:e.data.index||l.index()*r.options.slidesToScroll;r.slideHandler(r.checkNavigable(d),!1,t),l.children().trigger("focus");break;default:return}},e.prototype.checkNavigable=function(i){var e,t;if(e=this.getNavigableIndexes(),t=0,i>e[e.length-1])i=e[e.length-1];else for(var o in e){if(i<e[o]){i=t;break}t=e[o]}return i},e.prototype.cleanUpEvents=function(){var e=this;e.options.dots&&null!==e.$dots&&(i("li",e.$dots).off("click.slick",e.changeSlide).off("mouseenter.slick",i.proxy(e.interrupt,e,!0)).off("mouseleave.slick",i.proxy(e.interrupt,e,!1)),!0===e.options.accessibility&&e.$dots.off("keydown.slick",e.keyHandler)),e.$slider.off("focus.slick blur.slick"),!0===e.options.arrows&&e.slideCount>e.options.slidesToShow&&(e.$prevArrow&&e.$prevArrow.off("click.slick",e.changeSlide),e.$nextArrow&&e.$nextArrow.off("click.slick",e.changeSlide),!0===e.options.accessibility&&(e.$prevArrow&&e.$prevArrow.off("keydown.slick",e.keyHandler),e.$nextArrow&&e.$nextArrow.off("keydown.slick",e.keyHandler))),e.$list.off("touchstart.slick mousedown.slick",e.swipeHandler),e.$list.off("touchmove.slick mousemove.slick",e.swipeHandler),e.$list.off("touchend.slick mouseup.slick",e.swipeHandler),e.$list.off("touchcancel.slick mouseleave.slick",e.swipeHandler),e.$list.off("click.slick",e.clickHandler),i(document).off(e.visibilityChange,e.visibility),e.cleanUpSlideEvents(),!0===e.options.accessibility&&e.$list.off("keydown.slick",e.keyHandler),!0===e.options.focusOnSelect&&i(e.$slideTrack).children().off("click.slick",e.selectHandler),i(window).off("orientationchange.slick.slick-"+e.instanceUid,e.orientationChange),i(window).off("resize.slick.slick-"+e.instanceUid,e.resize),i("[draggable!=true]",e.$slideTrack).off("dragstart",e.preventDefault),i(window).off("load.slick.slick-"+e.instanceUid,e.setPosition)},e.prototype.cleanUpSlideEvents=function(){var e=this;e.$list.off("mouseenter.slick",i.proxy(e.interrupt,e,!0)),e.$list.off("mouseleave.slick",i.proxy(e.interrupt,e,!1))},e.prototype.cleanUpRows=function(){var i,e=this;e.options.rows>1&&((i=e.$slides.children().children()).removeAttr("style"),e.$slider.empty().append(i))},e.prototype.clickHandler=function(i){!1===this.shouldClick&&(i.stopImmediatePropagation(),i.stopPropagation(),i.preventDefault())},e.prototype.destroy=function(e){var t=this;t.autoPlayClear(),t.touchObject={},t.cleanUpEvents(),i(".slick-cloned",t.$slider).detach(),t.$dots&&t.$dots.remove(),t.$prevArrow&&t.$prevArrow.length&&(t.$prevArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex").css("display",""),t.htmlExpr.test(t.options.prevArrow)&&t.$prevArrow.remove()),t.$nextArrow&&t.$nextArrow.length&&(t.$nextArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex").css("display",""),t.htmlExpr.test(t.options.nextArrow)&&t.$nextArrow.remove()),t.$slides&&(t.$slides.removeClass("slick-slide slick-active slick-center slick-visible slick-current").removeAttr("aria-hidden").removeAttr("data-slick-index").each(function(){i(this).attr("style",i(this).data("originalStyling"))}),t.$slideTrack.children(this.options.slide).detach(),t.$slideTrack.detach(),t.$list.detach(),t.$slider.append(t.$slides)),t.cleanUpRows(),t.$slider.removeClass("slick-slider"),t.$slider.removeClass("slick-initialized"),t.$slider.removeClass("slick-dotted"),t.unslicked=!0,e||t.$slider.trigger("destroy",[t])},e.prototype.disableTransition=function(i){var e=this,t={};t[e.transitionType]="",!1===e.options.fade?e.$slideTrack.css(t):e.$slides.eq(i).css(t)},e.prototype.fadeSlide=function(i,e){var t=this;!1===t.cssTransitions?(t.$slides.eq(i).css({zIndex:t.options.zIndex}),t.$slides.eq(i).animate({opacity:1},t.options.speed,t.options.easing,e)):(t.applyTransition(i),t.$slides.eq(i).css({opacity:1,zIndex:t.options.zIndex}),e&&setTimeout(function(){t.disableTransition(i),e.call()},t.options.speed))},e.prototype.fadeSlideOut=function(i){var e=this;!1===e.cssTransitions?e.$slides.eq(i).animate({opacity:0,zIndex:e.options.zIndex-2},e.options.speed,e.options.easing):(e.applyTransition(i),e.$slides.eq(i).css({opacity:0,zIndex:e.options.zIndex-2}))},e.prototype.filterSlides=e.prototype.slickFilter=function(i){var e=this;null!==i&&(e.$slidesCache=e.$slides,e.unload(),e.$slideTrack.children(this.options.slide).detach(),e.$slidesCache.filter(i).appendTo(e.$slideTrack),e.reinit())},e.prototype.focusHandler=function(){var e=this;e.$slider.off("focus.slick blur.slick").on("focus.slick blur.slick","*",function(t){t.stopImmediatePropagation();var o=i(this);setTimeout(function(){e.options.pauseOnFocus&&(e.focussed=o.is(":focus"),e.autoPlay())},0)})},e.prototype.getCurrent=e.prototype.slickCurrentSlide=function(){return this.currentSlide},e.prototype.getDotCount=function(){var i=this,e=0,t=0,o=0;if(!0===i.options.infinite)if(i.slideCount<=i.options.slidesToShow)++o;else for(;e<i.slideCount;)++o,e=t+i.options.slidesToScroll,t+=i.options.slidesToScroll<=i.options.slidesToShow?i.options.slidesToScroll:i.options.slidesToShow;else if(!0===i.options.centerMode)o=i.slideCount;else if(i.options.asNavFor)for(;e<i.slideCount;)++o,e=t+i.options.slidesToScroll,t+=i.options.slidesToScroll<=i.options.slidesToShow?i.options.slidesToScroll:i.options.slidesToShow;else o=1+Math.ceil((i.slideCount-i.options.slidesToShow)/i.options.slidesToScroll);return o-1},e.prototype.getLeft=function(i){var e,t,o,s,n=this,r=0;return n.slideOffset=0,t=n.$slides.first().outerHeight(!0),!0===n.options.infinite?(n.slideCount>n.options.slidesToShow&&(n.slideOffset=n.slideWidth*n.options.slidesToShow*-1,s=-1,!0===n.options.vertical&&!0===n.options.centerMode&&(2===n.options.slidesToShow?s=-1.5:1===n.options.slidesToShow&&(s=-2)),r=t*n.options.slidesToShow*s),n.slideCount%n.options.slidesToScroll!=0&&i+n.options.slidesToScroll>n.slideCount&&n.slideCount>n.options.slidesToShow&&(i>n.slideCount?(n.slideOffset=(n.options.slidesToShow-(i-n.slideCount))*n.slideWidth*-1,r=(n.options.slidesToShow-(i-n.slideCount))*t*-1):(n.slideOffset=n.slideCount%n.options.slidesToScroll*n.slideWidth*-1,r=n.slideCount%n.options.slidesToScroll*t*-1))):i+n.options.slidesToShow>n.slideCount&&(n.slideOffset=(i+n.options.slidesToShow-n.slideCount)*n.slideWidth,r=(i+n.options.slidesToShow-n.slideCount)*t),n.slideCount<=n.options.slidesToShow&&(n.slideOffset=0,r=0),!0===n.options.centerMode&&n.slideCount<=n.options.slidesToShow?n.slideOffset=n.slideWidth*Math.floor(n.options.slidesToShow)/2-n.slideWidth*n.slideCount/2:!0===n.options.centerMode&&!0===n.options.infinite?n.slideOffset+=n.slideWidth*Math.floor(n.options.slidesToShow/2)-n.slideWidth:!0===n.options.centerMode&&(n.slideOffset=0,n.slideOffset+=n.slideWidth*Math.floor(n.options.slidesToShow/2)),e=!1===n.options.vertical?i*n.slideWidth*-1+n.slideOffset:i*t*-1+r,!0===n.options.variableWidth&&(o=n.slideCount<=n.options.slidesToShow||!1===n.options.infinite?n.$slideTrack.children(".slick-slide").eq(i):n.$slideTrack.children(".slick-slide").eq(i+n.options.slidesToShow),e=!0===n.options.rtl?o[0]?-1*(n.$slideTrack.width()-o[0].offsetLeft-o.width()):0:o[0]?-1*o[0].offsetLeft:0,!0===n.options.centerMode&&(o=n.slideCount<=n.options.slidesToShow||!1===n.options.infinite?n.$slideTrack.children(".slick-slide").eq(i):n.$slideTrack.children(".slick-slide").eq(i+n.options.slidesToShow+1),e=!0===n.options.rtl?o[0]?-1*(n.$slideTrack.width()-o[0].offsetLeft-o.width()):0:o[0]?-1*o[0].offsetLeft:0,e+=(n.$list.width()-o.outerWidth())/2)),e},e.prototype.getOption=e.prototype.slickGetOption=function(i){return this.options[i]},e.prototype.getNavigableIndexes=function(){var i,e=this,t=0,o=0,s=[];for(!1===e.options.infinite?i=e.slideCount:(t=-1*e.options.slidesToScroll,o=-1*e.options.slidesToScroll,i=2*e.slideCount);t<i;)s.push(t),t=o+e.options.slidesToScroll,o+=e.options.slidesToScroll<=e.options.slidesToShow?e.options.slidesToScroll:e.options.slidesToShow;return s},e.prototype.getSlick=function(){return this},e.prototype.getSlideCount=function(){var e,t,o=this;return t=!0===o.options.centerMode?o.slideWidth*Math.floor(o.options.slidesToShow/2):0,!0===o.options.swipeToSlide?(o.$slideTrack.find(".slick-slide").each(function(s,n){if(n.offsetLeft-t+i(n).outerWidth()/2>-1*o.swipeLeft)return e=n,!1}),Math.abs(i(e).attr("data-slick-index")-o.currentSlide)||1):o.options.slidesToScroll},e.prototype.goTo=e.prototype.slickGoTo=function(i,e){this.changeSlide({data:{message:"index",index:parseInt(i)}},e)},e.prototype.init=function(e){var t=this;i(t.$slider).hasClass("slick-initialized")||(i(t.$slider).addClass("slick-initialized"),t.buildRows(),t.buildOut(),t.setProps(),t.startLoad(),t.loadSlider(),t.initializeEvents(),t.updateArrows(),t.updateDots(),t.checkResponsive(!0),t.focusHandler()),e&&t.$slider.trigger("init",[t]),!0===t.options.accessibility&&t.initADA(),t.options.autoplay&&(t.paused=!1,t.autoPlay())},e.prototype.initADA=function(){var e=this,t=Math.ceil(e.slideCount/e.options.slidesToShow),o=e.getNavigableIndexes().filter(function(i){return i>=0&&i<e.slideCount});e.$slides.add(e.$slideTrack.find(".slick-cloned")).attr({"aria-hidden":"true",tabindex:"-1"}).find("a, input, button, select").attr({tabindex:"-1"}),null!==e.$dots&&(e.$slides.not(e.$slideTrack.find(".slick-cloned")).each(function(t){var s=o.indexOf(t);i(this).attr({role:"tabpanel",id:"slick-slide"+e.instanceUid+t,tabindex:-1}),-1!==s&&i(this).attr({"aria-describedby":"slick-slide-control"+e.instanceUid+s})}),e.$dots.attr("role","tablist").find("li").each(function(s){var n=o[s];i(this).attr({role:"presentation"}),i(this).find("button").first().attr({role:"tab",id:"slick-slide-control"+e.instanceUid+s,"aria-controls":"slick-slide"+e.instanceUid+n,"aria-label":s+1+" of "+t,"aria-selected":null,tabindex:"-1"})}).eq(e.currentSlide).find("button").attr({"aria-selected":"true",tabindex:"0"}).end());for(var s=e.currentSlide,n=s+e.options.slidesToShow;s<n;s++)e.$slides.eq(s).attr("tabindex",0);e.activateADA()},e.prototype.initArrowEvents=function(){var i=this;!0===i.options.arrows&&i.slideCount>i.options.slidesToShow&&(i.$prevArrow.off("click.slick").on("click.slick",{message:"previous"},i.changeSlide),i.$nextArrow.off("click.slick").on("click.slick",{message:"next"},i.changeSlide),!0===i.options.accessibility&&(i.$prevArrow.on("keydown.slick",i.keyHandler),i.$nextArrow.on("keydown.slick",i.keyHandler)))},e.prototype.initDotEvents=function(){var e=this;!0===e.options.dots&&(i("li",e.$dots).on("click.slick",{message:"index"},e.changeSlide),!0===e.options.accessibility&&e.$dots.on("keydown.slick",e.keyHandler)),!0===e.options.dots&&!0===e.options.pauseOnDotsHover&&i("li",e.$dots).on("mouseenter.slick",i.proxy(e.interrupt,e,!0)).on("mouseleave.slick",i.proxy(e.interrupt,e,!1))},e.prototype.initSlideEvents=function(){var e=this;e.options.pauseOnHover&&(e.$list.on("mouseenter.slick",i.proxy(e.interrupt,e,!0)),e.$list.on("mouseleave.slick",i.proxy(e.interrupt,e,!1)))},e.prototype.initializeEvents=function(){var e=this;e.initArrowEvents(),e.initDotEvents(),e.initSlideEvents(),e.$list.on("touchstart.slick mousedown.slick",{action:"start"},e.swipeHandler),e.$list.on("touchmove.slick mousemove.slick",{action:"move"},e.swipeHandler),e.$list.on("touchend.slick mouseup.slick",{action:"end"},e.swipeHandler),e.$list.on("touchcancel.slick mouseleave.slick",{action:"end"},e.swipeHandler),e.$list.on("click.slick",e.clickHandler),i(document).on(e.visibilityChange,i.proxy(e.visibility,e)),!0===e.options.accessibility&&e.$list.on("keydown.slick",e.keyHandler),!0===e.options.focusOnSelect&&i(e.$slideTrack).children().on("click.slick",e.selectHandler),i(window).on("orientationchange.slick.slick-"+e.instanceUid,i.proxy(e.orientationChange,e)),i(window).on("resize.slick.slick-"+e.instanceUid,i.proxy(e.resize,e)),i("[draggable!=true]",e.$slideTrack).on("dragstart",e.preventDefault),i(window).on("load.slick.slick-"+e.instanceUid,e.setPosition),i(e.setPosition)},e.prototype.initUI=function(){var i=this;!0===i.options.arrows&&i.slideCount>i.options.slidesToShow&&(i.$prevArrow.show(),i.$nextArrow.show()),!0===i.options.dots&&i.slideCount>i.options.slidesToShow&&i.$dots.show()},e.prototype.keyHandler=function(i){var e=this;i.target.tagName.match("TEXTAREA|INPUT|SELECT")||(37===i.keyCode&&!0===e.options.accessibility?e.changeSlide({data:{message:!0===e.options.rtl?"next":"previous"}}):39===i.keyCode&&!0===e.options.accessibility&&e.changeSlide({data:{message:!0===e.options.rtl?"previous":"next"}}))},e.prototype.lazyLoad=function(){function e(e){i("img[data-lazy]",e).each(function(){var e=i(this),t=i(this).attr("data-lazy"),o=i(this).attr("data-srcset"),s=i(this).attr("data-sizes")||n.$slider.attr("data-sizes"),r=document.createElement("img");r.onload=function(){e.animate({opacity:0},100,function(){o&&(e.attr("srcset",o),s&&e.attr("sizes",s)),e.attr("src",t).animate({opacity:1},200,function(){e.removeAttr("data-lazy data-srcset data-sizes").removeClass("slick-loading")}),n.$slider.trigger("lazyLoaded",[n,e,t])})},r.onerror=function(){e.removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error"),n.$slider.trigger("lazyLoadError",[n,e,t])},r.src=t})}var t,o,s,n=this;if(!0===n.options.centerMode?!0===n.options.infinite?s=(o=n.currentSlide+(n.options.slidesToShow/2+1))+n.options.slidesToShow+2:(o=Math.max(0,n.currentSlide-(n.options.slidesToShow/2+1)),s=n.options.slidesToShow/2+1+2+n.currentSlide):(o=n.options.infinite?n.options.slidesToShow+n.currentSlide:n.currentSlide,s=Math.ceil(o+n.options.slidesToShow),!0===n.options.fade&&(o>0&&o--,s<=n.slideCount&&s++)),t=n.$slider.find(".slick-slide").slice(o,s),"anticipated"===n.options.lazyLoad)for(var r=o-1,l=s,d=n.$slider.find(".slick-slide"),a=0;a<n.options.slidesToScroll;a++)r<0&&(r=n.slideCount-1),t=(t=t.add(d.eq(r))).add(d.eq(l)),r--,l++;e(t),n.slideCount<=n.options.slidesToShow?e(n.$slider.find(".slick-slide")):n.currentSlide>=n.slideCount-n.options.slidesToShow?e(n.$slider.find(".slick-cloned").slice(0,n.options.slidesToShow)):0===n.currentSlide&&e(n.$slider.find(".slick-cloned").slice(-1*n.options.slidesToShow))},e.prototype.loadSlider=function(){var i=this;i.setPosition(),i.$slideTrack.css({opacity:1}),i.$slider.removeClass("slick-loading"),i.initUI(),"progressive"===i.options.lazyLoad&&i.progressiveLazyLoad()},e.prototype.next=e.prototype.slickNext=function(){this.changeSlide({data:{message:"next"}})},e.prototype.orientationChange=function(){var i=this;i.checkResponsive(),i.setPosition()},e.prototype.pause=e.prototype.slickPause=function(){var i=this;i.autoPlayClear(),i.paused=!0},e.prototype.play=e.prototype.slickPlay=function(){var i=this;i.autoPlay(),i.options.autoplay=!0,i.paused=!1,i.focussed=!1,i.interrupted=!1},e.prototype.postSlide=function(e){var t=this;t.unslicked||(t.$slider.trigger("afterChange",[t,e]),t.animating=!1,t.slideCount>t.options.slidesToShow&&t.setPosition(),t.swipeLeft=null,t.options.autoplay&&t.autoPlay(),!0===t.options.accessibility&&(t.initADA(),t.options.focusOnChange&&i(t.$slides.get(t.currentSlide)).attr("tabindex",0).focus()))},e.prototype.prev=e.prototype.slickPrev=function(){this.changeSlide({data:{message:"previous"}})},e.prototype.preventDefault=function(i){i.preventDefault()},e.prototype.progressiveLazyLoad=function(e){e=e||1;var t,o,s,n,r,l=this,d=i("img[data-lazy]",l.$slider);d.length?(t=d.first(),o=t.attr("data-lazy"),s=t.attr("data-srcset"),n=t.attr("data-sizes")||l.$slider.attr("data-sizes"),(r=document.createElement("img")).onload=function(){s&&(t.attr("srcset",s),n&&t.attr("sizes",n)),t.attr("src",o).removeAttr("data-lazy data-srcset data-sizes").removeClass("slick-loading"),!0===l.options.adaptiveHeight&&l.setPosition(),l.$slider.trigger("lazyLoaded",[l,t,o]),l.progressiveLazyLoad()},r.onerror=function(){e<3?setTimeout(function(){l.progressiveLazyLoad(e+1)},500):(t.removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error"),l.$slider.trigger("lazyLoadError",[l,t,o]),l.progressiveLazyLoad())},r.src=o):l.$slider.trigger("allImagesLoaded",[l])},e.prototype.refresh=function(e){var t,o,s=this;o=s.slideCount-s.options.slidesToShow,!s.options.infinite&&s.currentSlide>o&&(s.currentSlide=o),s.slideCount<=s.options.slidesToShow&&(s.currentSlide=0),t=s.currentSlide,s.destroy(!0),i.extend(s,s.initials,{currentSlide:t}),s.init(),e||s.changeSlide({data:{message:"index",index:t}},!1)},e.prototype.registerBreakpoints=function(){var e,t,o,s=this,n=s.options.responsive||null;if("array"===i.type(n)&&n.length){s.respondTo=s.options.respondTo||"window";for(e in n)if(o=s.breakpoints.length-1,n.hasOwnProperty(e)){for(t=n[e].breakpoint;o>=0;)s.breakpoints[o]&&s.breakpoints[o]===t&&s.breakpoints.splice(o,1),o--;s.breakpoints.push(t),s.breakpointSettings[t]=n[e].settings}s.breakpoints.sort(function(i,e){return s.options.mobileFirst?i-e:e-i})}},e.prototype.reinit=function(){var e=this;e.$slides=e.$slideTrack.children(e.options.slide).addClass("slick-slide"),e.slideCount=e.$slides.length,e.currentSlide>=e.slideCount&&0!==e.currentSlide&&(e.currentSlide=e.currentSlide-e.options.slidesToScroll),e.slideCount<=e.options.slidesToShow&&(e.currentSlide=0),e.registerBreakpoints(),e.setProps(),e.setupInfinite(),e.buildArrows(),e.updateArrows(),e.initArrowEvents(),e.buildDots(),e.updateDots(),e.initDotEvents(),e.cleanUpSlideEvents(),e.initSlideEvents(),e.checkResponsive(!1,!0),!0===e.options.focusOnSelect&&i(e.$slideTrack).children().on("click.slick",e.selectHandler),e.setSlideClasses("number"==typeof e.currentSlide?e.currentSlide:0),e.setPosition(),e.focusHandler(),e.paused=!e.options.autoplay,e.autoPlay(),e.$slider.trigger("reInit",[e])},e.prototype.resize=function(){var e=this;i(window).width()!==e.windowWidth&&(clearTimeout(e.windowDelay),e.windowDelay=window.setTimeout(function(){e.windowWidth=i(window).width(),e.checkResponsive(),e.unslicked||e.setPosition()},50))},e.prototype.removeSlide=e.prototype.slickRemove=function(i,e,t){var o=this;if(i="boolean"==typeof i?!0===(e=i)?0:o.slideCount-1:!0===e?--i:i,o.slideCount<1||i<0||i>o.slideCount-1)return!1;o.unload(),!0===t?o.$slideTrack.children().remove():o.$slideTrack.children(this.options.slide).eq(i).remove(),o.$slides=o.$slideTrack.children(this.options.slide),o.$slideTrack.children(this.options.slide).detach(),o.$slideTrack.append(o.$slides),o.$slidesCache=o.$slides,o.reinit()},e.prototype.setCSS=function(i){var e,t,o=this,s={};!0===o.options.rtl&&(i=-i),e="left"==o.positionProp?Math.ceil(i)+"px":"0px",t="top"==o.positionProp?Math.ceil(i)+"px":"0px",s[o.positionProp]=i,!1===o.transformsEnabled?o.$slideTrack.css(s):(s={},!1===o.cssTransitions?(s[o.animType]="translate("+e+", "+t+")",o.$slideTrack.css(s)):(s[o.animType]="translate3d("+e+", "+t+", 0px)",o.$slideTrack.css(s)))},e.prototype.setDimensions=function(){var i=this;!1===i.options.vertical?!0===i.options.centerMode&&i.$list.css({padding:"0px "+i.options.centerPadding}):(i.$list.height(i.$slides.first().outerHeight(!0)*i.options.slidesToShow),!0===i.options.centerMode&&i.$list.css({padding:i.options.centerPadding+" 0px"})),i.listWidth=i.$list.width(),i.listHeight=i.$list.height(),!1===i.options.vertical&&!1===i.options.variableWidth?(i.slideWidth=Math.ceil(i.listWidth/i.options.slidesToShow),i.$slideTrack.width(Math.ceil(i.slideWidth*i.$slideTrack.children(".slick-slide").length))):!0===i.options.variableWidth?i.$slideTrack.width(5e3*i.slideCount):(i.slideWidth=Math.ceil(i.listWidth),i.$slideTrack.height(Math.ceil(i.$slides.first().outerHeight(!0)*i.$slideTrack.children(".slick-slide").length)));var e=i.$slides.first().outerWidth(!0)-i.$slides.first().width();!1===i.options.variableWidth&&i.$slideTrack.children(".slick-slide").width(i.slideWidth-e)},e.prototype.setFade=function(){var e,t=this;t.$slides.each(function(o,s){e=t.slideWidth*o*-1,!0===t.options.rtl?i(s).css({position:"relative",right:e,top:0,zIndex:t.options.zIndex-2,opacity:0}):i(s).css({position:"relative",left:e,top:0,zIndex:t.options.zIndex-2,opacity:0})}),t.$slides.eq(t.currentSlide).css({zIndex:t.options.zIndex-1,opacity:1})},e.prototype.setHeight=function(){var i=this;if(1===i.options.slidesToShow&&!0===i.options.adaptiveHeight&&!1===i.options.vertical){var e=i.$slides.eq(i.currentSlide).outerHeight(!0);i.$list.css("height",e)}},e.prototype.setOption=e.prototype.slickSetOption=function(){var e,t,o,s,n,r=this,l=!1;if("object"===i.type(arguments[0])?(o=arguments[0],l=arguments[1],n="multiple"):"string"===i.type(arguments[0])&&(o=arguments[0],s=arguments[1],l=arguments[2],"responsive"===arguments[0]&&"array"===i.type(arguments[1])?n="responsive":void 0!==arguments[1]&&(n="single")),"single"===n)r.options[o]=s;else if("multiple"===n)i.each(o,function(i,e){r.options[i]=e});else if("responsive"===n)for(t in s)if("array"!==i.type(r.options.responsive))r.options.responsive=[s[t]];else{for(e=r.options.responsive.length-1;e>=0;)r.options.responsive[e].breakpoint===s[t].breakpoint&&r.options.responsive.splice(e,1),e--;r.options.responsive.push(s[t])}l&&(r.unload(),r.reinit())},e.prototype.setPosition=function(){var i=this;i.setDimensions(),i.setHeight(),!1===i.options.fade?i.setCSS(i.getLeft(i.currentSlide)):i.setFade(),i.$slider.trigger("setPosition",[i])},e.prototype.setProps=function(){var i=this,e=document.body.style;i.positionProp=!0===i.options.vertical?"top":"left","top"===i.positionProp?i.$slider.addClass("slick-vertical"):i.$slider.removeClass("slick-vertical"),void 0===e.WebkitTransition&&void 0===e.MozTransition&&void 0===e.msTransition||!0===i.options.useCSS&&(i.cssTransitions=!0),i.options.fade&&("number"==typeof i.options.zIndex?i.options.zIndex<3&&(i.options.zIndex=3):i.options.zIndex=i.defaults.zIndex),void 0!==e.OTransform&&(i.animType="OTransform",i.transformType="-o-transform",i.transitionType="OTransition",void 0===e.perspectiveProperty&&void 0===e.webkitPerspective&&(i.animType=!1)),void 0!==e.MozTransform&&(i.animType="MozTransform",i.transformType="-moz-transform",i.transitionType="MozTransition",void 0===e.perspectiveProperty&&void 0===e.MozPerspective&&(i.animType=!1)),void 0!==e.webkitTransform&&(i.animType="webkitTransform",i.transformType="-webkit-transform",i.transitionType="webkitTransition",void 0===e.perspectiveProperty&&void 0===e.webkitPerspective&&(i.animType=!1)),void 0!==e.msTransform&&(i.animType="msTransform",i.transformType="-ms-transform",i.transitionType="msTransition",void 0===e.msTransform&&(i.animType=!1)),void 0!==e.transform&&!1!==i.animType&&(i.animType="transform",i.transformType="transform",i.transitionType="transition"),i.transformsEnabled=i.options.useTransform&&null!==i.animType&&!1!==i.animType},e.prototype.setSlideClasses=function(i){var e,t,o,s,n=this;if(t=n.$slider.find(".slick-slide").removeClass("slick-active slick-center slick-current").attr("aria-hidden","true"),n.$slides.eq(i).addClass("slick-current"),!0===n.options.centerMode){var r=n.options.slidesToShow%2==0?1:0;e=Math.floor(n.options.slidesToShow/2),!0===n.options.infinite&&(i>=e&&i<=n.slideCount-1-e?n.$slides.slice(i-e+r,i+e+1).addClass("slick-active").attr("aria-hidden","false"):(o=n.options.slidesToShow+i,t.slice(o-e+1+r,o+e+2).addClass("slick-active").attr("aria-hidden","false")),0===i?t.eq(t.length-1-n.options.slidesToShow).addClass("slick-center"):i===n.slideCount-1&&t.eq(n.options.slidesToShow).addClass("slick-center")),n.$slides.eq(i).addClass("slick-center")}else i>=0&&i<=n.slideCount-n.options.slidesToShow?n.$slides.slice(i,i+n.options.slidesToShow).addClass("slick-active").attr("aria-hidden","false"):t.length<=n.options.slidesToShow?t.addClass("slick-active").attr("aria-hidden","false"):(s=n.slideCount%n.options.slidesToShow,o=!0===n.options.infinite?n.options.slidesToShow+i:i,n.options.slidesToShow==n.options.slidesToScroll&&n.slideCount-i<n.options.slidesToShow?t.slice(o-(n.options.slidesToShow-s),o+s).addClass("slick-active").attr("aria-hidden","false"):t.slice(o,o+n.options.slidesToShow).addClass("slick-active").attr("aria-hidden","false"));"ondemand"!==n.options.lazyLoad&&"anticipated"!==n.options.lazyLoad||n.lazyLoad()},e.prototype.setupInfinite=function(){var e,t,o,s=this;if(!0===s.options.fade&&(s.options.centerMode=!1),!0===s.options.infinite&&!1===s.options.fade&&(t=null,s.slideCount>s.options.slidesToShow)){for(o=!0===s.options.centerMode?s.options.slidesToShow+1:s.options.slidesToShow,e=s.slideCount;e>s.slideCount-o;e-=1)t=e-1,i(s.$slides[t]).clone(!0).attr("id","").attr("data-slick-index",t-s.slideCount).prependTo(s.$slideTrack).addClass("slick-cloned");for(e=0;e<o+s.slideCount;e+=1)t=e,i(s.$slides[t]).clone(!0).attr("id","").attr("data-slick-index",t+s.slideCount).appendTo(s.$slideTrack).addClass("slick-cloned");s.$slideTrack.find(".slick-cloned").find("[id]").each(function(){i(this).attr("id","")})}},e.prototype.interrupt=function(i){var e=this;i||e.autoPlay(),e.interrupted=i},e.prototype.selectHandler=function(e){var t=this,o=i(e.target).is(".slick-slide")?i(e.target):i(e.target).parents(".slick-slide"),s=parseInt(o.attr("data-slick-index"));s||(s=0),t.slideCount<=t.options.slidesToShow?t.slideHandler(s,!1,!0):t.slideHandler(s)},e.prototype.slideHandler=function(i,e,t){var o,s,n,r,l,d=null,a=this;if(e=e||!1,!(!0===a.animating&&!0===a.options.waitForAnimate||!0===a.options.fade&&a.currentSlide===i))if(!1===e&&a.asNavFor(i),o=i,d=a.getLeft(o),r=a.getLeft(a.currentSlide),a.currentLeft=null===a.swipeLeft?r:a.swipeLeft,!1===a.options.infinite&&!1===a.options.centerMode&&(i<0||i>a.getDotCount()*a.options.slidesToScroll))!1===a.options.fade&&(o=a.currentSlide,!0!==t?a.animateSlide(r,function(){a.postSlide(o)}):a.postSlide(o));else if(!1===a.options.infinite&&!0===a.options.centerMode&&(i<0||i>a.slideCount-a.options.slidesToScroll))!1===a.options.fade&&(o=a.currentSlide,!0!==t?a.animateSlide(r,function(){a.postSlide(o)}):a.postSlide(o));else{if(a.options.autoplay&&clearInterval(a.autoPlayTimer),s=o<0?a.slideCount%a.options.slidesToScroll!=0?a.slideCount-a.slideCount%a.options.slidesToScroll:a.slideCount+o:o>=a.slideCount?a.slideCount%a.options.slidesToScroll!=0?0:o-a.slideCount:o,a.animating=!0,a.$slider.trigger("beforeChange",[a,a.currentSlide,s]),n=a.currentSlide,a.currentSlide=s,a.setSlideClasses(a.currentSlide),a.options.asNavFor&&(l=(l=a.getNavTarget()).slick("getSlick")).slideCount<=l.options.slidesToShow&&l.setSlideClasses(a.currentSlide),a.updateDots(),a.updateArrows(),!0===a.options.fade)return!0!==t?(a.fadeSlideOut(n),a.fadeSlide(s,function(){a.postSlide(s)})):a.postSlide(s),void a.animateHeight();!0!==t?a.animateSlide(d,function(){a.postSlide(s)}):a.postSlide(s)}},e.prototype.startLoad=function(){var i=this;!0===i.options.arrows&&i.slideCount>i.options.slidesToShow&&(i.$prevArrow.hide(),i.$nextArrow.hide()),!0===i.options.dots&&i.slideCount>i.options.slidesToShow&&i.$dots.hide(),i.$slider.addClass("slick-loading")},e.prototype.swipeDirection=function(){var i,e,t,o,s=this;return i=s.touchObject.startX-s.touchObject.curX,e=s.touchObject.startY-s.touchObject.curY,t=Math.atan2(e,i),(o=Math.round(180*t/Math.PI))<0&&(o=360-Math.abs(o)),o<=45&&o>=0?!1===s.options.rtl?"left":"right":o<=360&&o>=315?!1===s.options.rtl?"left":"right":o>=135&&o<=225?!1===s.options.rtl?"right":"left":!0===s.options.verticalSwiping?o>=35&&o<=135?"down":"up":"vertical"},e.prototype.swipeEnd=function(i){var e,t,o=this;if(o.dragging=!1,o.swiping=!1,o.scrolling)return o.scrolling=!1,!1;if(o.interrupted=!1,o.shouldClick=!(o.touchObject.swipeLength>10),void 0===o.touchObject.curX)return!1;if(!0===o.touchObject.edgeHit&&o.$slider.trigger("edge",[o,o.swipeDirection()]),o.touchObject.swipeLength>=o.touchObject.minSwipe){switch(t=o.swipeDirection()){case"left":case"down":e=o.options.swipeToSlide?o.checkNavigable(o.currentSlide+o.getSlideCount()):o.currentSlide+o.getSlideCount(),o.currentDirection=0;break;case"right":case"up":e=o.options.swipeToSlide?o.checkNavigable(o.currentSlide-o.getSlideCount()):o.currentSlide-o.getSlideCount(),o.currentDirection=1}"vertical"!=t&&(o.slideHandler(e),o.touchObject={},o.$slider.trigger("swipe",[o,t]))}else o.touchObject.startX!==o.touchObject.curX&&(o.slideHandler(o.currentSlide),o.touchObject={})},e.prototype.swipeHandler=function(i){var e=this;if(!(!1===e.options.swipe||"ontouchend"in document&&!1===e.options.swipe||!1===e.options.draggable&&-1!==i.type.indexOf("mouse")))switch(e.touchObject.fingerCount=i.originalEvent&&void 0!==i.originalEvent.touches?i.originalEvent.touches.length:1,e.touchObject.minSwipe=e.listWidth/e.options.touchThreshold,!0===e.options.verticalSwiping&&(e.touchObject.minSwipe=e.listHeight/e.options.touchThreshold),i.data.action){case"start":e.swipeStart(i);break;case"move":e.swipeMove(i);break;case"end":e.swipeEnd(i)}},e.prototype.swipeMove=function(i){var e,t,o,s,n,r,l=this;return n=void 0!==i.originalEvent?i.originalEvent.touches:null,!(!l.dragging||l.scrolling||n&&1!==n.length)&&(e=l.getLeft(l.currentSlide),l.touchObject.curX=void 0!==n?n[0].pageX:i.clientX,l.touchObject.curY=void 0!==n?n[0].pageY:i.clientY,l.touchObject.swipeLength=Math.round(Math.sqrt(Math.pow(l.touchObject.curX-l.touchObject.startX,2))),r=Math.round(Math.sqrt(Math.pow(l.touchObject.curY-l.touchObject.startY,2))),!l.options.verticalSwiping&&!l.swiping&&r>4?(l.scrolling=!0,!1):(!0===l.options.verticalSwiping&&(l.touchObject.swipeLength=r),t=l.swipeDirection(),void 0!==i.originalEvent&&l.touchObject.swipeLength>4&&(l.swiping=!0,i.preventDefault()),s=(!1===l.options.rtl?1:-1)*(l.touchObject.curX>l.touchObject.startX?1:-1),!0===l.options.verticalSwiping&&(s=l.touchObject.curY>l.touchObject.startY?1:-1),o=l.touchObject.swipeLength,l.touchObject.edgeHit=!1,!1===l.options.infinite&&(0===l.currentSlide&&"right"===t||l.currentSlide>=l.getDotCount()&&"left"===t)&&(o=l.touchObject.swipeLength*l.options.edgeFriction,l.touchObject.edgeHit=!0),!1===l.options.vertical?l.swipeLeft=e+o*s:l.swipeLeft=e+o*(l.$list.height()/l.listWidth)*s,!0===l.options.verticalSwiping&&(l.swipeLeft=e+o*s),!0!==l.options.fade&&!1!==l.options.touchMove&&(!0===l.animating?(l.swipeLeft=null,!1):void l.setCSS(l.swipeLeft))))},e.prototype.swipeStart=function(i){var e,t=this;if(t.interrupted=!0,1!==t.touchObject.fingerCount||t.slideCount<=t.options.slidesToShow)return t.touchObject={},!1;void 0!==i.originalEvent&&void 0!==i.originalEvent.touches&&(e=i.originalEvent.touches[0]),t.touchObject.startX=t.touchObject.curX=void 0!==e?e.pageX:i.clientX,t.touchObject.startY=t.touchObject.curY=void 0!==e?e.pageY:i.clientY,t.dragging=!0},e.prototype.unfilterSlides=e.prototype.slickUnfilter=function(){var i=this;null!==i.$slidesCache&&(i.unload(),i.$slideTrack.children(this.options.slide).detach(),i.$slidesCache.appendTo(i.$slideTrack),i.reinit())},e.prototype.unload=function(){var e=this;i(".slick-cloned",e.$slider).remove(),e.$dots&&e.$dots.remove(),e.$prevArrow&&e.htmlExpr.test(e.options.prevArrow)&&e.$prevArrow.remove(),e.$nextArrow&&e.htmlExpr.test(e.options.nextArrow)&&e.$nextArrow.remove(),e.$slides.removeClass("slick-slide slick-active slick-visible slick-current").attr("aria-hidden","true").css("width","")},e.prototype.unslick=function(i){var e=this;e.$slider.trigger("unslick",[e,i]),e.destroy()},e.prototype.updateArrows=function(){var i=this;Math.floor(i.options.slidesToShow/2),!0===i.options.arrows&&i.slideCount>i.options.slidesToShow&&!i.options.infinite&&(i.$prevArrow.removeClass("slick-disabled").attr("aria-disabled","false"),i.$nextArrow.removeClass("slick-disabled").attr("aria-disabled","false"),0===i.currentSlide?(i.$prevArrow.addClass("slick-disabled").attr("aria-disabled","true"),i.$nextArrow.removeClass("slick-disabled").attr("aria-disabled","false")):i.currentSlide>=i.slideCount-i.options.slidesToShow&&!1===i.options.centerMode?(i.$nextArrow.addClass("slick-disabled").attr("aria-disabled","true"),i.$prevArrow.removeClass("slick-disabled").attr("aria-disabled","false")):i.currentSlide>=i.slideCount-1&&!0===i.options.centerMode&&(i.$nextArrow.addClass("slick-disabled").attr("aria-disabled","true"),i.$prevArrow.removeClass("slick-disabled").attr("aria-disabled","false")))},e.prototype.updateDots=function(){var i=this;null!==i.$dots&&(i.$dots.find("li").removeClass("slick-active").end(),i.$dots.find("li").eq(Math.floor(i.currentSlide/i.options.slidesToScroll)).addClass("slick-active"))},e.prototype.visibility=function(){var i=this;i.options.autoplay&&(document[i.hidden]?i.interrupted=!0:i.interrupted=!1)},i.fn.slick=function(){var i,t,o=this,s=arguments[0],n=Array.prototype.slice.call(arguments,1),r=o.length;for(i=0;i<r;i++)if("object"==typeof s||void 0===s?o[i].slick=new e(o[i],s):t=o[i].slick[s].apply(o[i].slick,n),void 0!==t)return t;return o}});


$(document).ready(function(){

    // video button play

    $(".app_video_play_btn").on("click", function(e){ 
        e.stopPropagation();
        e.preventDefault();

        $(this).parent('.video_box').addClass("play");
        $(this).hide();
        $(this).parent('.video_box.play').find('video')[0].play();
    });


});





function openTAB(evt, itemName) {
  // Declare all variables
  var i, tabcontent, tablinks;

  // Get all elements with class="tabcontent" and hide them
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Get all elements with class="tablinks" and remove the class "active"
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  // Show the current tab, and add an "active" class to the button that opened the tab
  document.getElementById(itemName).style.display = "block";
  evt.currentTarget.className += " active";

}





$(document).ready(function() {

        $('.list_slide_box').slick({
    
          	dots: false,
            arrows: true,
            infinite: false,
            speed: 300,
            slidesToScroll: 1,    
            slidesToShow: 4,
            responsive: [

                {
                    breakpoint: 1024,
                    settings: {
                        arrows: true,
                        slidesToShow: 4
                    }
                },

                {
                    breakpoint: 961,
                    settings: {
                        arrows: true,
                        slidesToShow: 3
                    }
                },

                {
                    breakpoint: 767,
                    settings: {
                        arrows: true,
                        slidesToScroll: 1,    
                        slidesToShow: 1,
                         swipe:false
                    }
                }
            ]

        }).resize();


        $(".tab_box .tablinks").on('click',function(e){
    
            e.preventDefault();
    
            $('.list_slide_box').slick('setPosition');
            $('.list_slide_box').resize();
            $('.list_slide_box').slick('refresh');
    
        });

        //slick
    
        // slick slider
        $(window).resize(function() {
            $('.list_slide_box').slick('resize');
        });

});



(function(window){
	var without_satellite = {
			pageBottom: function(){
				
			},
			track: function(tracktext){
				console.log('without_satellite : track msg => '+tracktext);
			}
	}
	window._satellite = without_satellite;
})(window);
