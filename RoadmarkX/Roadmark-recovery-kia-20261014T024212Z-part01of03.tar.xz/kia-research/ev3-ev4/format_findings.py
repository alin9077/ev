import json,re,pathlib
P=pathlib.Path('/tmp/kia-research/ev3-ev4')
fields={'note','supports','reason','basis','condition','conditions','text','value','metadataReason','qualifications','publicationNotes','featureCorrectionNotes','result','label','originalBasis','comparison','currentVersions','retainedResidual','bodyStyle'}
def fmt(s):
 s=re.sub(r'(?<=[A-Za-z])(?=\d)',' ',s)
 s=re.sub(r'(?<=\d)(?=[A-Za-z])',' ',s)
 s=re.sub(r'(?<=%)(?=[A-Za-z])',' ',s)
 s=re.sub(r'\bEV (\d)',r'EV\1',s);s=re.sub(r'\bMY (\d)',r'MY\1',s);s=s.replace('V 2 L','V2L').replace('Type 2','Type 2').replace('0–100 km/h','0–100 km/h')
 s=re.sub(r'(?<=\d)(?=[a-z])',' ',s)
 s=re.sub(r'(?<=[a-z])(?=\d)',' ',s)
 # Model MY string survived only once above; restore after final generic pass.
 s=s.replace('V 2 L','V2L'); s=re.sub(r'\bEV (\d)',r'EV\1',s);s=re.sub(r'\bMY (\d)',r'MY\1',s)
 return s

def walk(x,parent=None):
 if isinstance(x,dict):return{k:walk(v,k) for k,v in x.items()}
 if isinstance(x,list):return[walk(v,parent) for v in x]
 if isinstance(x,str) and parent in fields:return fmt(x)
 return x
for name in ['normalized-evidence.json','source-index.json']:
 x=walk(json.load(open(P/name)))
 if name=='normalized-evidence.json':
  for v in x['variants']:
   for f in v['features']:
    if 'not fitted' in f['value']:f['status']='unavailable'
   if v['model']=='EV4' and '_air_' in v['id']:v['summary']['strength']['text']='Five seats and a 490 L VDA boot with all rear seats in use.'
 (P/name).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
