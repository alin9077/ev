import json, pathlib, hashlib,re,subprocess
from html.parser import HTMLParser
ROOT=pathlib.Path('/tmp/kia-research/ev3-ev4'); S=ROOT/'sources'; DAY='2026-10-14'
class Txt(HTMLParser):
 def __init__(self):super().__init__();self.text=[];self.skip=0
 def handle_starttag(self,t,a):
  if t in ['script','style']:self.skip+=1
 def handle_endtag(self,t):
  if t in ['script','style']:self.skip-=1
 def handle_data(self,d):
  if not self.skip and d.strip():self.text.append(d.strip())
for p in S.glob('*.html'):
 t=Txt();t.feed(p.read_text());p.with_suffix('.txt').write_text('\n'.join(t.text))
sources=[]
def source(key,url,title,publisher,file,note,published=None,typ=None):
 p=S/file; t=p.with_suffix('.txt') if p.suffix in ['.pdf','.html'] else p
 if not p.exists():raise ValueError(file)
 if p.suffix=='.json':p.with_suffix('.txt').write_text(json.dumps(json.load(open(p)),indent=2));t=p.with_suffix('.txt')
 sources.append(dict(key=key,url=url,title=title,publisher=publisher,source_type=typ or ('official_au_manufacturer' if publisher=='Kia Australia' else 'reputable_au_secondary'),published_date=published,accessed_date=DAY,market='AU',file=str(p),textFile=str(t),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),textSha256=hashlib.sha256(t.read_bytes()).hexdigest(),note=note,supports=note))
for m in ['ev3','ev4']:
 source(m+'_my27_brochure',f'https://www.kia.com/content/dam/kwcms/au/en/images/pdf/{m}/kia-{m}-brochure.pdf',f'Kia {m.upper()} Australian MY27 mechanical and feature list','Kia Australia',m+'-current.pdf','Current exact Australian MY27 version columns; declared battery energy, charging windows and station power, WLTP combined, dimensions, 5-seat-up VDA rear cargo, towing and equipment. PDF creation metadata is not treated as publication date. Broad pending-inspection footer is a version-level note, not evidence of closed orders.')
 source(m+'_config',f'https://www.kia.com/au/shopping-tools/build-and-price.trim.{"ev4-sedan" if m=="ev4" else m}.html',f'Kia Australia {m.upper()} current grade configurator','Kia Australia',m+'-config.html','Current live Australian grade selection and configure path; does not establish accepted orders, delivery dates or physical dealer stock.')
 source(m+'_features',f'https://www.kia.com/au/cars/{m}/features.html',f'Kia Australia 2027 {m.upper()} model page','Kia Australia',m+'-features.html','Current MY27-labelled AU model page and named grades; full search for maker DC acceptance and cargo measurements; EV4 is sedan only.')
 source(m+'_offers',f'https://www.kia.com/au/shopping-tools/offers/car-offers/{m}.html',f'Kia Australia {m.upper()} October driveaway offers','Kia Australia',m+'-offers.html','Named grade national driveaway estimate, valid to31 October2026, participating dealers and private buyers only; includes12 months registration, CTP estimate for good driving record, stamp duty, statutory/dealer delivery; circumstances may vary. No MY/build exclusion appears in displayed terms.')
source('ev4_my26_brochure','https://cdn.mattaki.com/kia/static-assets/vehicles/brochures/kia_ev4_ebrochure.pdf','Kia EV4 Australian MY26 mechanical and feature list, maker document on dealer CDN','Kia Australia','ev4-my26.pdf','Maker-authored Australian MY26 brochure supplied through Australian Kia dealer network CDN. Exact three MY26 sedan columns, separate from MY27. Confirmed technical evidence for residual MY26 records; not proof of ongoing factory orders.')
source('ev3_awdpublished','https://www.carexpert.com.au/car-news/2027-kia-ev3-to-add-awd-flagship-in-australia','2027 Kia EV3 to add AWD flagship in Australia','CarExpert','ev3-ce-awd.html','July2026 historical reported version list and66490 AWD before-on-road price; current maker RRP is63950. Historical difference is disclosed, not silently used to alter maker number. Raw HTTP captured from public origin.carexpert.com.au mirror.','2026-07-09')
source('ev3_ce_review','https://www.carexpert.com.au/car-reviews/2026-kia-ev3-review','2026 Kia EV3 review','CarExpert','ev3-ce-review.html','Australian FWD review table reports100kW SR and127kW LR DC acceptance. Current MY27 maker leaves peak unpublished, so these MY26 FWD values are only Reported carryover; never extend peak to AWD. Raw HTTP captured from public origin.carexpert.com.au mirror.','2026-01-05')
source('ev3_ce_dimensions','https://www.carexpert.com.au/kia/ev3/2027/exterior-and-dimensions','2027 Kia EV3 exterior and dimensions, five exact configurations','CarExpert','ev3-ce-2027-dimensions.html','Five Australian MY27 configurations including AWD; VDA rear seats folded1251L explicitly listed across columns. Used only as Reported folded capacity, not as authority for conflicting current maker dimensions or charging power. Raw HTTP captured from public origin.carexpert.com.au mirror.')
source('ev4_ce_review','https://www.carexpert.com.au/car-reviews/2026-kia-ev4-review','2026 Kia EV4 review','CarExpert','ev4-ce-review.html','Australian MY26 sedan review table explicitly reports128kW DC acceptance for both batteries. MY27 use is labelled prior-MY/sibling carryover. Maker OBC10.5kW supersedes review10.3kW. Raw HTTP captured from public origin.carexpert.com.au mirror.','2026-01-30')
source('ev4_carsales_review','https://www.carsales.com.au/editorial/details/kia-ev4-2026-review-151298/','Kia EV4 2026 Review','carsales','ev4-carsales-review.html','Independent Australian launch review explicitly gives128kW peak DC across all three MY26 versions. Used as Reported secondary, not to overwrite maker charging time/station output.','2026-01-30')
source('ev4_hatch_gt','https://www.carexpert.com.au/car-news/kia-ev4-hatch-hi-po-gt-still-on-the-cards-for-australia','Kia EV4 Hatch, hi-po GT still on the cards for Australia','CarExpert','ev4-ce-hatch.html','Australian product boss business-case commentary: EV4 hatch/GT under consideration, not confirmed for local sale; current AU maker range remains sedan FWD. Raw HTTP captured from public origin.carexpert.com.au mirror.','2026-02-03')
source('ev4_carsguide_2027','https://www.carsguide.com.au/kia/ev4/price/2027','2027 Kia EV4 pricing and specs','CarsGuide','ev4-carsguide-2027.html','Independent current list confirms three MY27 FWD sedan grades; secondary quoted before-on-road prices match current maker API49,990/59,190/64,690.')
for m,model,trims in [('ev3','SV_RHD',['AIR-SR','AIR-LR','EAR-LR','GTL-LR','GTLAWD-LR']),('ev4','CT',['AIR','EARTH','GT-Line'])]:
 for trim in trims:
  key=m+'_price_'+trim.lower().replace('-','_')
  source(key,f'https://www.kia.com/api/kia_australia/common/trimPrice.selectPriceByTrim?regionCode=NSW&modelCode={model}&trimCode={trim}',f'Kia Australia {m.upper()} {trim} public configurator price data','Kia Australia',m+'-'+trim+'-price.json','Named trim dataInfo[0].trimInfo[0].rrpprice is maker RRP before on-road costs. NSW price/offerPrice fields are separate driveaway data; no arithmetic conversion. No authentication used. Public NSW setting locates quote, not the user.')
source('ev3_awd_color','https://www.kia.com/au/shopping-tools/build-and-price.color.ev3.GTLAWD-LR.html','Kia EV3 GT-Line AWD rendered colour-step configurator RRP','Kia Australia','ev3-awd-color-nsw.html','Named AWD page rendered with public regionCode=NSW and postcode2000 displays RRP63,950, agreeing with API. This is lower than July reported66,490; written dealer quote advised. No inferred correction from driveaway arithmetic.')
for key,file,url,title in [
 ('ev4_my26_air_ad','ev4-my26-air-dealer.html','https://www.gws.com.au/stock/details/153471-K18803/2026-kia-ev4-new','GWS MY26 EV4 Air new advertisement K18803'),
 ('ev4_my26_earth_ad','ev4-my26-earth-ogr.html','https://www.ogr.com.au/cars/new-white-2026-kia-ev4-1064653','OGR MY26 EV4 Earth new advertisement1064653'),
 ('ev4_my26_gt_ad','ev4-my26-gt-dealer.html','https://www.gws.com.au/stock/details/153471-K19022/2026-kia-ev4-new','GWS MY26 EV4 GT-Line new advertisement K19022')]:
 source(key,url,title,'OGR' if 'ogr' in file else 'GWS Kia',file,'Fresh full dealer advertisement explicitly identifies MY26 and New; evidence of advertised residual supply only, not physically verified stock or accepted factory order.',typ='original_dealer_http_response')

# Helpers for normalized fact and equipment evidence.
variants=[]
def fact(key,value,src,basis,comparison='',grade='confirmed',condition=None,reason=None,**kw):
 f=dict(key=key,value=value,sourceKeys=src if isinstance(src,list) else [src],grade=grade,basis=basis,comparison=comparison,reason=reason or 'The maker Australian brochure explicitly lists this value for the exact grade or entire named body range.',evidenceScope='secondary_or_sibling' if grade=='reported' else 'searched_not_found' if grade=='not_published' else 'exact_au_version',qualifications=[])
 if condition:f['condition']=condition
 f.update(kw);return f

def feature(criterion,value,keys,grade='confirmed',conditions='',reason='Current exact Australian brochure equipment row; removes inherited pre-publication qualifications.'):
 return dict(criterion=criterion,value=value,keys=keys,grade=grade,conditions=conditions,reason=reason)

def add_common(v,src,m,idx,year):
 is3=m=='ev3';sr=idx==0;gt=idx>=3 if is3 else idx==2;awd=is3 and idx==4;earth=idx==2 if is3 else idx==1
 battery=58.3 if sr else 81.4;charge=29 if sr else 31
 power=195 if awd else 150;drive='AWD' if awd else'FWD';tow=500 if sr else 1500 if awd else 1000
 rng=[436,604,563,563,559][idx] if is3 else [456,612,612][idx]
 accel=[7.5,7.7,7.9,7.9,6.6][idx] if is3 else [7.4,7.8,7.8][idx]
 length=(4310 if gt else 4300) if is3 else 4730; height=(1570 if gt else 1560) if is3 else 1480
 width=1850 if is3 else 1860;boot=460 if is3 else 490
 f=v['facts']
 f.extend([
 fact('range_km',rng,src,'WLTP combined laboratory range','WLTP combined'),
 fact('battery_kwh',battery,src,'Maker declared battery energy; gross/usable unspecified','Declared capacity (gross/usable unspecified)',qualifications=['Do not relabel published energy as gross or usable capacity.']),
 fact('dc_charge_time_min',charge,src,'DC10–80% on350kW test charger','DC10–80%',grade='check',condition=f'Approximate{charge}-minute10–80% Kia HQ test using a350kW DC station; actual time depends on charging conditions.350kW is station output, not vehicle acceptance.',qualifications=['Charging window remains exactly10–80%; no window conversion performed.']),
 fact('ac_kw',10.5,src,'Maximum onboard AC power, three-phase; single-phase6.9kW','AC kW',qualifications=['Three-phase supply is needed for10.5kW; single-phase maximum6.9kW.']),
 fact('seats',5,src,'Australian range seat capacity','Seats'),
 fact('boot_l',boot,src,'Rear cargo with all5 seats up; VDA litres','VDA seats up',qualifications=['Rear cargo only, excludes frunk. Maker does not state a separate parcel-shelf/roof loading-height boundary.']),
 fact('zero_to_100_s',accel,src,'Approximate manufacturer0–100km/h claim','0–100km/h'),
 fact('power_kw',power,src,'Published maximum vehicle power, no motor summation','Manufacturer total power'),
 fact('drive',drive,src,'Maker driven-wheel layout','Drive type'),
 fact('length_mm',length,src,'Overall length for named Australian grade','Body mm'),
 fact('width_mm',width,src,'Overall body width; mirror-to-mirror not declared','Body mm',qualifications=['Do not use as unfolded mirror width.']),
 fact('height_mm',height,src,'Overall height for named Australian grade','Body mm'),
 fact('towing_braked_kg',tow,src,'Manufacturer braked towing limit','Braked towing kg',grade='check',condition='Subject to applicable state regulations and suitable towbar design; verify plated vehicle, towbar and towball limits.'),
 fact('wheelbase_mm',2680 if is3 else 2820,src,'Manufacturer wheelbase','Wheelbase mm'),
 fact('ground_clearance_mm',140,src,'Maker minimum ground clearance','Ground clearance mm'),
 fact('turning_circle_m',10.4 if is3 else 10.9,src,'Maker minimum turning-circle diameter','Turning circle m'),
 fact('towing_unbraked_kg',500 if sr else 750,src,'Manufacturer unbraked towing limit','Unbraked towing kg',grade='check',condition='Subject to state regulations and towbar design.'),
 fact('dc_test_charger_kw',350,src,'Station output for published DC10–80% time','DC test charger kW'),
 fact('dc_charge_window','10–80%',src,'Exact published charge window'),
 fact('dc_10_80_at_50kw_minutes',55 if sr else 79,src,'Kia DC10–80% test with50kW station','DC10–80% on50kW',grade='check',condition='Approximate maker result with50kW charger; temperature and charging conditions change results.'),
 fact('ac_single_phase_kw',6.9,src,'Maximum single-phase onboard AC charging','AC single-phase kW'),
 fact('ac_phase_count',3,src,'Phase count for maximum10.5kW onboard charging'),
 fact('ac_time_charger_kw',11,src,'Station rating for timed AC10–100% test'),
 fact('ac_10_100_min',320 if sr else 435,src,'Published AC10–100% time,11kW charger and3-phase230V16A','AC10–100%',grade='check',condition='Maker timed test is10–100% with11kW three-phase charger; not0–100% or single-phase time.'),
 fact('ac_charge_window','10–100%',src,'Exact published AC charging window'),
 fact('ac_connector','Type2',src,'Maker Australian AC connector'),
 fact('dc_connector','CCS Type2',src,'Maker Australian DC connector'),
 fact('charge_port_location','Driver side front',src,'Maker charge-port location'),
 fact('battery_ah',158.2 if sr else 237.3,src,'Declared battery capacity in amp-hours'),
 fact('battery_mass_declared',(375 if sr else 470) if is3 else(380 if sr else 475),src,'Maker battery weight, not vehicle mass'),
 fact('battery_position','Under-floor',src,'Battery position'),
 fact('motor_location','Front and rear' if awd else'Front',src,'Motor positions'),
 fact('motor_type','Front permanent-magnet synchronous; rear induction' if awd else'Permanent magnet synchronous',src,'Maker motor types'),
 fact('torque_nm',385 if awd else 283,src,'Published maximum vehicle torque, not motor sum'),
 fact('top_speed_kmh',170,src,'Maker maximum speed'),
 fact('transmission','Single-speed reduction gear',src,'Maker transmission type'),
 fact('consumption_wh_km',[125,132,135,135,158][idx] if is3 else[143,149,149][idx],src,'MY27 WLTP combined energy consumption' if year==2027 else'MY26 WLTP combined energy consumption','WLTP combined Wh/km'),
 fact('tare_mass_kg',(1845 if sr else 2045 if awd else 1930) if is3 else(1805 if sr else 1912),src,'Maker declared tare mass, not relabelled kerb mass'),
 fact('gvm_kg',2270 if sr else 2480 if awd else 2355,src,'Maker gross vehicle mass'),
 fact('towball_download_kg',100,src,'Maker maximum towball download','Towball kg',grade='check',condition='Subject to state regulations and towbar design; verify fitted towbar limit.'),
 fact('front_suspension','MacPherson strut',src,'Maker front suspension'),
 fact('rear_suspension','Multi-link',src,'Maker rear suspension'),
 fact('wheel_diameter_in',17 if (idx<2 if is3 else sr) else 19,src,'Standard wheel diameter'),
 fact('tyres','215/60 R17' if (idx<2 if is3 else sr) else'215/50 R19',src,'Published standard tyre size'),
 fact('spare_wheel','Tyre mobility kit',src,'Maker listed spare wheel type'),
 ])
 if is3:
  f.append(fact('frunk_l',25,src,'Front storage VDA litres; separate from rear boot','VDA frunk'))
  f.append(fact('max_total_cargo_l',1251,'ev3_ce_dimensions','Rear seats folded; VDA litres per current Australian five-configuration CarExpert table','VDA seats folded',grade='reported',reason='Current Australian MY27 secondary table lists1251L with rear seats down in every named configuration; maker AU brochure publishes only seats-up rear and frunk. This is not added to boot or frunk.',qualifications=['Reported by CarExpert; current AU maker does not publish seats-folded volume.']))
  if awd:
   f.append(fact('dc_peak_kw',None,['ev3_my27_brochure','ev3_features'],'Not published for exact Australian GT-Line AWD','DC peak kW',grade='not_published',reason='Searched current AU MY27 brochure and model page: only test-station350kW and timed10–80% appear; neither gives vehicle peak acceptance. Prior135kW sibling value and CarExpert generic350kW field cannot establish AWD peak.',searchedSourceKeys=['ev3_my27_brochure','ev3_features']))
   f.append(fact('kerb_weight_kg',None,['ev3_my27_brochure','ev3_features'],'Not published as kerb mass for exact Australian AWD','Kerb weight kg',grade='not_published',reason='Current AU brochure specifies AWD tare2045kg only; model page does not publish kerb mass. Earlier1995kg is not supported by current exact AU evidence.',searchedSourceKeys=['ev3_my27_brochure','ev3_features']))
  else:
   f.append(fact('dc_peak_kw',100 if sr else 127,'ev3_ce_review','Australian MY26 FWD reported vehicle DC acceptance, carried to same MY27 battery/drive','DC peak kW',grade='reported',reason='CarExpert AU2026 FWD review gives100kW SR/127kW LR; current AU MY27 brochure and page do not publish vehicle peak. Cross-MY carryover remains Reported, never350kW station output.',qualifications=['Prior-model-year FWD Australian reported figure; confirm delivered MY27 capability.']))
   f.append(fact('kerb_weight_kg',1845 if sr else 1930,'ev3_ce_review','Australian FWD review reported vehicle weight','Kerb weight kg',grade='reported',reason='Australian MY26 FWD review reports1845/1930kg; current MY27 maker lists these as tare rather than kerb, so kerb classification remains Reported.',qualifications=['Maker MY27 labels its matching number tare; kerb classification is secondary.']))
  f.append(fact('battery_chemistry','Lithium-ion',src,'Maker battery type; cathode chemistry not specified'))
 else:
  f.append(fact('dc_peak_kw',128,['ev4_ce_review','ev4_carsales_review'],'Australian MY26 sedan reported vehicle DC peak'+('; carried to corresponding MY27 grade' if year==2027 else''),'DC peak kW',grade='reported',reason='Two Australian launch reviews explicitly state128kW maximum DC for both batteries. Maker exact brochure/page publish350kW station and29/31-minute test, not acceptance; MY27 inherits only as Reported.',qualifications=['Secondary claim; not derived from test-station rating.']+(['Prior-MY exact-battery/drivetrain carryover, not current maker-confirmed.'] if year==2027 else[])))
  f.extend([fact('kerb_weight_kg',1805 if sr else 1912,src,'Maker explicitly declared kerb weight','Kerb weight kg'),fact('kerb_mass_kg',1805 if sr else 1912,src,'Maker explicitly declared kerb weight'),fact('battery_chemistry','Lithium-ion NCM',src,'Maker battery type')])
  for key,desc in [('frunk_l','front storage capacity'),('max_total_cargo_l','rear cargo with seats folded')]:
   f.append(fact(key,None,[src,'ev4_features'],'Not published: '+desc,'',grade='not_published',reason='Searched exact MY'+str(year)+' Australian brochure and current AU model page;490L VDA rear cargo with5 seats up is published, but '+desc+' is not.',searchedSourceKeys=[src,'ev4_features']))
 # Equipment fields are independent evidence for summaries and visible corrections.
 equipped=earth or gt
 data={'heated_front_seats':equipped,'ventilated_front_seats':equipped if is3 else gt,'heated_steering_wheel':equipped if is3 else gt,'head_up_display':gt,'sunroof':gt,'power_tailgate':equipped if is3 else gt,'v2l_interior_outlet':True,'v2l_adapter_included':True if is3 else not sr,'wireless_phone_charging':True if is3 else gt,'rear_camera':True,'front_rear_parking_sensors':True,'child_isofix_positions':2,'child_top_tether_anchors':3,'speaker_count':8 if gt else 6,'premium_audio':'Harman Kardon' if gt else'6-speaker system','front_display_inches':12.3,'driver_display_inches':12.3,'climate_display_inches':5,'wired_wireless_carplay_android':True,'utility_mode':True,'ota_updates':True}
 if not is3:data['camera360']=gt
 for key,val in data.items():f.append(fact(key,val,src,'Maker standard equipment table'))
 # No sheet-absence binary inference is used for EV3 surround camera/heat pump.
 fs=v['features']
 fs.extend([
 feature('storage',f'{boot}L rear boot with5 seats up (VDA)'+(';25L front storage (VDA);1,251L rear seats folded, reported by CarExpert' if is3 else'; front and seats-folded capacity not published'),['boot_l','frunk_l','max_total_cargo_l'],'reported' if is3 else'confirmed',reason='Separates seats-up rear, front and seats-folded measurements; only latter EV3 value uses current Australian secondary table.'),
 feature('energy_use',str([125,132,135,135,158][idx] if is3 else[143,149,149][idx])+'Wh/km WLTP combined',['consumption_wh_km'],reason='Uses exact current maker Wh/km row; removes stale annual electricity-cost estimate and previous MY value.'),
 feature('home_charging',('5h20m' if sr else'7h15m')+' from10–100% on an11kW three-phase charger; onboard maximum10.5kW three-phase or6.9kW single-phase',['ac_10_100_min','ac_time_charger_kw','ac_charge_window','ac_kw','ac_single_phase_kw'],'check','Kia test uses3-phase230V16A; actual time varies with charging conditions.',reason='Replaces battery-capacity/rate estimate with exact maker charging window and test time.'),
 feature('performance_rear_motor',f'{power}kW / '+str(385 if awd else 283)+'Nm; '+('dual-motor AWD' if awd else'single front motor, FWD'),['power_kw','torque_nm','drive','motor_location']),
 feature('front_heated_seats','Heated front seats standard' if data['heated_front_seats'] else'Heated front seats not fitted',['heated_front_seats']),
 feature('front_ventilated_seats','Ventilated front seats standard' if data['ventilated_front_seats'] else'Ventilated front seats not fitted',['ventilated_front_seats']),
 feature('heated_steering_wheel','Heated steering wheel standard' if data['heated_steering_wheel'] else'Heated steering wheel not fitted',['heated_steering_wheel']),
 feature('v2l','Interior socket and exterior adaptor included' if data['v2l_adapter_included'] else'Interior V2L socket; exterior adaptor not included',['v2l_interior_outlet','v2l_adapter_included']),
 feature('parking_cameras','Surround-view camera, rear camera and front/rear sensors' if not is3 and gt else'Reversing camera and front/rear sensors',['rear_camera','front_rear_parking_sensors']+(['camera360'] if not is3 else[])),
 feature('child_seats','2ISOFIX positions and3top-tether anchors',['child_isofix_positions','child_top_tether_anchors']),
 feature('spare_tyre','Tyre mobility kit; no spare wheel',['spare_wheel']),
 feature('screens_hud','12.3-inch infotainment +12.3-inch driver +5-inch climate displays; '+('head-up display fitted' if gt else'head-up display not fitted'),['front_display_inches','driver_display_inches','climate_display_inches','head_up_display']),
 feature('audio_system','8-speaker Harman Kardon' if gt else'6-speaker audio',['speaker_count','premium_audio']),
 feature('glass_roof','Wide sunroof fitted' if gt else'Sunroof not fitted',['sunroof']),
 feature('power_tailgate',('Powered tailgate' if is3 else'Powered boot lid')+' fitted' if data['power_tailgate'] else'Powered tailgate/boot lid not fitted',['power_tailgate']),
 feature('wireless_charging','Qi wireless phone charger fitted' if data['wireless_phone_charging'] else'Wireless phone charger not fitted',['wireless_phone_charging']),
 feature('carplay_android_auto','Wired and wireless Apple CarPlay and Android Auto',['wired_wireless_carplay_android']),
 feature('camp_utility_mode','Utility mode fitted',['utility_mode']),
 ])
 return dict(sr=sr,gt=gt,earth=earth,awd=awd,rng=rng,tow=tow,charge=charge,power=power,accel=accel)

b=json.load(open('/tmp/kia-research/before.json'))
for car in b:
 if car['model'] not in ['EV3','EV4']:continue
 is3=car['model']=='EV3';m='ev3' if is3 else'ev4';year=car['year']
 idx=next(i for i,s in enumerate(['air_2wd_standard','air_2wd_long','earth_2wd_long','gt_line_2wd_long','gt_line_awd_long']) if s in car['id']) if is3 else (0 if '_air_' in car['id'] else 1 if '_earth_' in car['id'] else 2)
 trim=(['Air 2WD Standard Range','Air 2WD Long Range','Earth 2WD Long Range','GT-Line 2WD Long Range','GT-Line AWD Long Range'][idx] if is3 else ['Air Standard Range 2WD','Earth Long Range 2WD','GT-Line Long Range 2WD'][idx])
 if not is3:trim+=' · MY'+str(year)[2:]+(' residual New advertising' if year==2026 else'')
 v=dict(id=car['id'],model=car['model'],trim=trim,modelYear=year,drive='AWD' if is3 and idx==4 else'FWD',metadata={'trim':trim},metadataReason='Current maker MY27 grade is configurable; remove obsolete provisional identity wording.' if year==2027 else'Retain separate exact MY26 residual-new identity.',facts=[],features=[])
 src=m+'_my27_brochure' if year==2027 else'ev4_my26_brochure'
 ds=add_common(v,src,m,idx,year)
 price=[47600,53315,58600,63950,63950][idx] if is3 else [49990,59190,64690][idx]
 apikey=m+'_price_'+(['air_sr','air_lr','ear_lr','gtl_lr','gtlawd_lr'][idx] if is3 else ['air','earth','gt_line'][idx])
 offer=[46990,52990,58990,68490,None][idx] if is3 else[52990,62990,68490][idx]
 pq=['Base standard colour and equipment; on-road charges/options are additional.']
 if is3 and idx==4:pq+=['Current maker AWD page and price data display63,950; CarExpert reported66,490 on9 July2026. This historical discrepancy is disclosed; obtain a written quote before relying on the figure. No correction inferred from driveaway arithmetic.']
 if year==2027:
  v['facts'].insert(0,fact('price_aud',price,[apikey]+(['ev3_awd_color'] if is3 and idx==4 else[]),'Before on-road costs','Before on-road costs',reason='Current maker exact-trim configurator data labels rrpprice; selected highest available price-ladder rung.',priceRung=1,basisTag="Maker's list price",priceTag="Maker's list price",rankingEligible=True,originalBasis='RRP',sourcePointer='dataInfo[0].trimInfo[0].rrpprice',qualifications=pq))
 else:
  offercond='Private buyers at participating Kia dealers until31 October2026; advertised driveaway estimate assumes12months registration and CTP for a good-driving-record private buyer. Individual circumstances may change the amount.'
  v['facts'].insert(0,fact('price_aud',offer,'ev4_offers','Driveaway','Driveaway',grade='check',condition=offercond,reason='Fresh maker national offer explicitly names same EV4 grade and has no displayed MY/build exclusion; current MY27 RRP is not assigned to MY26. Selected rung2 ahead of historical reported list or unit-specific dealer price.',priceRung=2,basisTag="Maker's national driveaway",priceTag="Maker's national driveaway",rankingEligible=True,originalBasis='Drive Away estimate from',validUntil='2026-10-31',sourcePointer='Model Range > '+['Air','Earth','GT-Line'][idx]+'; Terms & Conditions > Drive Away Offer',qualifications=['Residual MY26 availability and offer application to the particular dealer vehicle should be established in a written quote.','No MY/build restriction appears in the captured current offer terms.']))
 if offer is not None:
  v['facts'].append(fact('promotional_driveaway_aud',offer,m+'_offers','Driveaway','Driveaway',grade='check',condition='Private buyers at participating Kia dealers until31October2026; CTP estimate assumes good driving record, individual circumstances may vary.',reason='Current national manufacturer offer names this grade; exact offer deadline and buyer restrictions preserved.',priceRung=2,basisTag="Maker's national driveaway",priceTag="Maker's national driveaway",rankingEligible=True,originalBasis='Drive Away estimate from',validUntil='2026-10-31',sourcePointer='Model Range > named grade; Drive Away Offer terms',qualifications=['Includes12months registration, CTP estimate, stamp duty and statutory/dealer delivery charges.']))
 if year==2026:
  ad=['ev4_my26_air_ad','ev4_my26_earth_ad','ev4_my26_gt_ad'][idx];adprice=[50888,62990,66990][idx]
  v['dealerObservation']={'priceAud':adprice,'basis':'Driveaway','sourceKey':ad,'unitReference':['K18803','1064653','K19022'][idx],'physicalStockConfirmed':False}
  v['availability']=dict(state='outgoing',sourceKeys=[src,ad],orderStatus='listed_unconfirmed',stockStatus='new_stock_listed',qualifications=['Exact MY26 grade is advertised New by an original Australian Kia dealer; physical possession, unsold status and delivery timing are unverified.','MY27 current factory range is separate; no MY26 factory-order acceptance inferred.'],reason='Fresh original dealer advertisement supports residual New supply; keeps this separate from MY27 current maker configuration.')
 else:
  v['availability']=dict(state='current_or_order_listed',sourceKeys=[src,m+'_config',m+'_features',apikey],orderStatus='listed_unconfirmed',stockStatus='unverified',qualifications=['Current Australian maker grade is selectable/configurable with live price data; accepted individual orders and delivery timing are not verified.','Pending product-inspection text is retained as a model-level publication note; it does not negate live current range/configurator evidence.'],reason='Current maker MY27-labelled family page, exact brochure column and selectable named grade with live price data establish current Australian listing, including EV3 AWD.')
 if is3:
  if idx==0:
   strength=('Compact five-seat practicality','A4,300mm five-seat SUV with460L of VDA rear cargo room.',['length_mm','seats','boot_l'])
   trade=('Light towing only','The braked trailer limit is500kg, subject to towbar and state requirements.',['towing_braked_kg'])
  elif idx==1:
   strength=('Long-range small SUV','The81.4kWh battery supports a declared604km WLTP combined range.',['battery_kwh','range_km'])
   trade=('Simpler front seats','Front-seat heating and ventilation are not fitted.',['heated_front_seats','ventilated_front_seats'])
  elif idx==2:
   strength=('Seat comfort included','Heated and ventilated front seats sit alongside563km WLTP combined range.',['heated_front_seats','ventilated_front_seats','range_km'])
   trade=('Front-drive performance','Its150kW front-drive layout has an approximate7.9-second0–100km/h claim.',['power_kw','drive','zero_to_100_s'])
  elif idx==3:
   strength=('Comfort and head-up display','Ventilated front seats and a head-up display are standard, with563km WLTP combined range.',['ventilated_front_seats','head_up_display','range_km'])
   trade=('Front-drive performance','GT-Line FWD uses a150kW front-drive layout with an approximate7.9-second0–100km/h claim.',['power_kw','drive','zero_to_100_s'])
  else:
   strength=('AWD and extra towing','The195kW AWD drivetrain supports a1,500kg braked towing rating, subject to towbar and state requirements.',['power_kw','drive','towing_braked_kg'])
   trade=('Half-hour DC stop','Kia’s10–80% test takes about31minutes on a350kW station; actual time varies with conditions.',['dc_charge_time_min','dc_test_charger_kw','dc_charge_window'])
 else:
  if idx==0:
   strength=('Five seats and a usable boot','Five seats and490L of rear cargo space measured with all seats up to VDA.',['seats','boot_l'])
   trade=('Light towing only','The braked trailer limit is500kg, subject to towbar and state requirements.',['towing_braked_kg'])
  elif idx==1:
   strength=('Range and heated seats','The81.4kWh battery brings612km WLTP combined range, with heated front seats.',['battery_kwh','range_km','heated_front_seats'])
   trade=('Some comfort equipment absent','Ventilated front seats and a head-up display are not fitted.',['ventilated_front_seats','head_up_display'])
  else:
   strength=('Comfort and parking equipment','Ventilated front seats, head-up display and surround-view camera are standard.',['ventilated_front_seats','head_up_display','camera360'])
   trade=('Comfort-focused performance','The150kW front-drive drivetrain has an approximate7.8-second0–100km/h claim.',['power_kw','drive','zero_to_100_s'])
 v['summary']={k:dict(label=x[0],text=x[1],keys=x[2]) for k,x in [('strength',strength),('tradeoff',trade)]}
 variants.append(v)

# Human-readable spacing for values and all prose. Preserve machine keys/URLs.
def readable(s):
 s=re.sub(r'(?<=[A-Za-z])(?=\d)', ' ',s)
 s=re.sub(r'(?<=\d)(?=[A-Za-z])', ' ',s)
 return s
# Avoid corrupting model names EV3/EV4, source pointers and chemical names: only repair handwritten lack of numeric spaces selectively.
for v in variants:
 for f in v['facts']:
  for k in ['basis','reason','condition']:
   if k in f:
    f[k]=re.sub(r'(?<!EV)(?<!MY)(?<!V)(?<!Type)(?<!NCM)(?<=\D)(?=\d)',lambda m:' ' if m.start()>0 and f[k][m.start()-1].isalpha() else'',f[k]) if False else f[k]
# Structured review notes and current closure.
result=dict(reviewedAt=DAY,brand='Kia',families=['EV3','EV4'],sources=sources,variants=variants,coverage={'existingVariantsReviewed':11,'newVariantsProposed':0,'currentFactoryVersions':8,'residualMY26Versions':3,'coreFactsHandledHere':15,'sharedWarrantyFactsHandledByParent':2,'missingCore':[{'variantId':'kia_ev3__gt_line_awd_long_range__5','key':'dc_peak_kw','reason':'Exact AU AWD vehicle peak acceptance not published; current maker sources give station power only.'}]},reconciliation=[
 dict(family='EV3',currentVersions=['Air2WD SR','Air2WD LR','Earth2WD LR','GT-Line2WD LR','GT-Line AWD LR'],sourceKeys=['ev3_config','ev3_my27_brochure','ev3_ce_dimensions'],excluded=[{'lead':'EV3 GT','reason':'Not present in current Australian maker range or configurator; July AU reporting distinguishes GT-Line AWD from unconfirmed GT. No current AU order listing established.','sourceKeys':['ev3_config','ev3_my27_brochure','ev3_awdpublished']}]),
 dict(family='EV4',currentVersions=['Air SR FWD sedan MY27','Earth LR FWD sedan MY27','GT-Line LR FWD sedan MY27'],retainedResidual=['Air SR FWD sedan MY26','Earth LR FWD sedan MY26','GT-Line LR FWD sedan MY26'],sourceKeys=['ev4_config','ev4_my27_brochure','ev4_carsguide_2027','ev4_my26_air_ad','ev4_my26_earth_ad','ev4_my26_gt_ad'],excluded=[{'lead':x,'reason':'Current maker AU selection and MY27 sheet cover only three FWD sedan grades; Australian reporting leaves hatch/GT business case under study. Overseas existence does not establish AU on-sale/orderable version.','sourceKeys':['ev4_config','ev4_features','ev4_my27_brochure','ev4_hatch_gt']} for x in ['EV4 hatch','EV4 AWD non-GT','EV4 GT hatch','EV4 GT sedan']])],publicationNotes=[
 {'sourceKey':'ev3_my27_brochure','note':'PDF metadata created28September2026; footer says as of27August2026 inspections still pending. Both precede14October. Neither footer nor metadata is assumed to be publication date. Current live configurator now lists AWD, resolving earlier provisional-only catalogue classification.'},
 {'sourceKey':'ev4_my27_brochure','note':'PDF metadata created10July2026; footer says MY27 inspections will occur when available, without a future date. Current maker MY27 model page and configurator support current listings. No proof of individual order acceptance or stock is inferred.'},
 {'sourceKey':'ev4_my26_brochure','note':'PDF metadata created12January2026. Explicit MY26 cover and exact columns retained, not overwritten by MY27 source.'},
 {'sourceKey':'ev3_price_gtlawd_lr','note':'Current maker API and rendered named AWD page publish63950; prior9July CarExpert publication was66490. Selected current maker rung1 per parent review; difference disclosed in price qualifications.'},
 {'sourceKey':'ev4_offers','note':'Displayed eligibility text contains no model-year/build restriction. It applies named grade prices nationally, private buyers only, participating dealers, to31October2026. MY26 use is marked conditional national offer and must be confirmed on written residual-stock quote.'}
],featureCorrectionNotes=['All EV3 storage, energy_use and home_charging rows need guarded replacement; old annual-cost and capacity/rate estimated charging times removed.','AWD pre-publication sentence stating Kia has not yet published AWD sheet is obsolete anywhere retained. This report replaces technical/basic equipment rows for which the current exact sheet supplies positive evidence; separate software/connected-service claims still need their existing source scope preserved.','EV3 AWD braked towing1500kg replaces1000kg; current tare2045kg is not labelled kerb.','EV3 current MY27 energy figures125/132/135/135/158Wh/km replace prior149/149/162/162 and AWD blank; values preserved exactly as current maker source, not recalculated.','EV3 folded cargo1251L retained only as Reported from exact2027 Australian CarExpert five-configuration table.','EV4 current MY27 broad inspection disclaimer is no longer a per-fact condition.'],failedOrExcludedSearches=[{'url':'https://www.rockdalecitykia.com.au/new-cars/for-sale/kia/ev4/2026/earth-long-range/ct-my26/3845919/','result':'Fresh full HTTP redirects to generic inventory; old web-search exact-ad text not used as current availability.'},{'url':'https://www.huntervalleymotorgroup.com.au/new-cars/for-sale/kia/ev4/2026/earth-long-range/ct-my26/3942126','result':'Fresh full HTTP generic inventory; old search exact-ad text not used.'},{'scope':'CarExpert www HTTP fetch','result':'403; source documents captured in full from public origin.carexpert.com.au mirror, also independently read via web tool. No source values sourced from403 response.'}])
(ROOT/'normalized-evidence.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
(ROOT/'source-index.json').write_text(json.dumps(sources,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(result['coverage'],indent=2));print('Facts',sum(len(v['facts']) for v in variants),'Features',sum(len(v['features']) for v in variants),'Sources',len(sources))
