# Kia EV5 and Niro EV review — 14 October 2026

## Result

- Four current MY26 EV5 mechanical versions, preserving existing IDs
- GT-Line Two-Tone is an extra-cost paint configuration within GT-Line, supported by the maker brochure paint footnote and four-column mechanical table
- Two new Niro EV outgoing residual records: GT-Line MY24 and GT-Line MY25, both explicitly advertised New by Australian Kia dealers
- No current factory-order Niro admitted. Kia Australia discontinuation is recorded separately from residual advertising
- No Niro S admitted. Current Carsales S listings and the exact Youngs Kia candidate show used/private/demo, with Youngs fresh HTML explicitly Demo. Search snippets and an old web redirect misleadingly suggested New

## Evidence and coverage

normalized-evidence.json contains six variants, 158 fact reviews, 18 source records, and reviewed equipment/summary dependencies. All 15 non-warranty core fields are populated for each; parent applies shared vehicle/battery warranty terms.

EV5 prices are maker live configurator RRP: AUD 56,770 / 61,170 / 64,770 / 71,770. Separate national driveaway offers are AUD 49,990 / 59,990 / 64,990 / 75,990, valid to 31 October 2026 under the maker private-buyer terms. No extra cashback has been subtracted.

Niro current prices use exact dealer advertisements: Bankstown MY24 AUD 47,888 driveaway; Rockdale/AAG MY25 AUD 50,490 driveaway. Both listings identify 2024 build year. The residual maker configurator says its price applies to 2025 builds, so its historical AUD 72,360 RRP is not presented as the current price for these cars.

Niro MY24 physical facts use the maker MY24 brochure. MY25 physical facts are carried from that sibling and remain Reported. DC peak uses explicit Australian secondary vehicle figures, never charger-station ratings: EV5 102/140 kW, Niro 83.8 kW. Rounding differences are disclosed.

PDF specification page 2 for each model was rendered and visually checked. Cargo bases preserve occupied seats versus folded seats and keep front storage separate. All quotes, source dates, downloaded documents, plain text, PNG checks, and hashes are under sources, source-index.json and evidence-manifest.json. Publication dates are only used where explicit; PDF metadata is disclosed as metadata. No future-dated publication is used.

## Important importer details

- Honour the supplied EV5 kerb_weight_kg label override to Tare weight and tare-only comparison basis; the maker row is not kerb mass
- Energy facts and feature values retain maker Wh/km units and do not repeat estimated annual running cost
- Niro new IDs have top-level generation, modelYear, modelId kia_niro_ev, state outgoing, orderStatus not_accepting_orders, stockStatus new_stock_listed
- A New advertisement establishes a listing only; no physical stock, registration history, accepted factory order, or delivery timing was verified
- The parent must account for CarsGuide retaining Niro as current while CarExpert and the maker current model range reflect withdrawal; the difference is resolved as residual-new advertising

No repository data or source registration was changed by this worker.
