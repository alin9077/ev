import json,pathlib,re,hashlib
P=pathlib.Path('/tmp/kia-research/ev5-niro');f=P/'normalized-evidence.json';x=json.load(open(f))
def clean(a,k=''):
 if isinstance(a,dict):return {kk:clean(v,kk) for kk,v in a.items()}
 if isinstance(a,list):return [clean(v,k) for v in a]
 if not isinstance(a,str) or k in ('url','file','textFile','id','modelId','key','sourceKeys','keys','sha256','sourcePointer'):return a
 # Plain authored text only: keep proper model codes MY24, EV5, SG2, AWD etc.
 a=re.sub(r'([a-z])(?=\d)',r'\1 ',a)
 a=re.sub(r'(?<=\d)(?=(?:km|kW|Wh|kg|minutes|AUD)\b)',' ',a)
 a=re.sub(r'(?<=[,:;])(?=[A-Za-z0-9])',' ',a)
 a=re.sub(r'(?<=·)(?=\S)',' ',a)
 a=re.sub(r'(?<=\S)(?=·)',' ',a)
 a=a.replace('km(WLTP','km (WLTP').replace('folded(VDA)','folded (VDA)').replace('MY24 andMY25','MY24 and MY25').replace('fromMY24','from MY24').replace('No350','No 350').replace('Manufacturer10','Manufacturer 10')
 return a
x=clean(x)
for v in x['variants']:
 if v.get('new'):
  v['availability']['state']='outgoing';v['availability']['orderStatus']='not_accepting_orders';v['generation']=v['metadata']['generation']
 for q in v['features']:
  if q['criterion']=='energy_use':
   val=next(z['value'] for z in v['facts'] if z['key']=='energy_use_wh_km');q['value']=f'{val} Wh/km (WLTP combined)';q['reason']='Original maker Wh/km measurement retained; no annual energy-cost estimate.'
 # Add proper spaces explicitly around inherited shorthand values.
 for q in v['facts']:
  if q['key']=='dc_charge_time_min' and v.get('new'):
   q['basis']='DC 10–80% on a 350 kW charger, maker test';q['comparison']='DC 10–80%';q['condition']='Maker timing uses a 350 kW test charger; the published time is 45 minutes on a 100 kW charger and 65 minutes on a 50 kW charger. Vehicle acceptance is a separate fact.'
  if q['key']=='zero_to_100_s':q['comparison']='0–100 km/h'
  if q['key']=='ac_charge_time_min' and v.get('new'):
   q['basis']='AC 10–100% on an 11 kW charger';q['comparison']='AC 10–100%';q['condition']='Manufacturer 10–100% window at 11 kW AC; no 0–100% conversion.'
 for q in v['features']:
  if q['criterion']=='home_charging' and v.get('new'):
   q['value']='6 h 20 min from 10–100% on 11 kW AC · 11 kW onboard maximum'
   q['conditions']='Timed claim uses the stated 11 kW supply and 10–100% window.'+(' MY25 is carried from the MY24 sibling.' if v['modelYear']==2025 else '')
f.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n');(P/'source-index.json').write_text(json.dumps(x['sources'],indent=2,ensure_ascii=False)+'\n')
manifest=[dict(file=str(a.relative_to(P)),bytes=a.stat().st_size,sha256=hashlib.sha256(a.read_bytes()).hexdigest()) for a in sorted((P/'sources').glob('*')) if a.is_file()]
(P/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
core={'price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg'}
assert len(x['variants'])==6
assert all(core<={z['key'] for z in v['facts']} for v in x['variants'])
assert all(len(v['facts'])==len({q['key'] for q in v['facts']}) for v in x['variants'])
assert all(pathlib.Path(s['file']).exists() for s in x['sources'])
assert all(not s.get('textFile') or pathlib.Path(s['textFile']).exists() for s in x['sources'])
print('Final:',len(x['variants']),'variants',sum(len(v['facts']) for v in x['variants']),'facts, all15 non-warranty corefields populated')
