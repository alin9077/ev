import urllib.request,subprocess,pathlib
p=pathlib.Path('/tmp/polestar-research/current')
for k,model in [('p2','2'),('p3','3'),('p4c','4-coupe'),('p4s','4-suv')]:
 u='https://www.polestar.com/au/configure/polestar-'+model
 b=urllib.request.urlopen(u,timeout=60).read();r=subprocess.run(['node','/tmp/polestar-research/extract-public-config.cjs',u],input=b,capture_output=True)
 assert r.returncode==0,r.stderr[-300:];p.joinpath(k+'-config-public.json').write_bytes(r.stdout);print(k,len(r.stdout),flush=True)
