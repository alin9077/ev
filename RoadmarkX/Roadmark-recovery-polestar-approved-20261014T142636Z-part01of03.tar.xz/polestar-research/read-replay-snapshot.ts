import fs from 'node:fs';
import {StringDecoder} from 'node:string_decoder';
function readRows(file:string){const rows:any[]=[];const fd=fs.openSync(file,'r'),buf=Buffer.alloc(1024*1024),decoder=new StringDecoder('utf8');let carry='';try{let n;while((n=fs.readSync(fd,buf,0,buf.length,null))>0){carry+=decoder.write(buf.subarray(0,n));let pos;while((pos=carry.indexOf('\n'))>=0){const line=carry.slice(0,pos);carry=carry.slice(pos+1);if(line)rows.push(JSON.parse(line));}}carry+=decoder.end();if(carry)rows.push(JSON.parse(carry));}finally{fs.closeSync(fd);}return rows;}
export function readReplaySnapshot(R:string){const index=JSON.parse(fs.readFileSync(R+'replay-snapshot-index.json','utf8')),rd:any={};for(const [k,v]of Object.entries(index.research) as any){const rows=readRows(R+v.file);rd[k]=v.array?rows:rows[0];}return {rd,before:readRows(R+index.cars)};}
export function incrementalDigest(value:any,hash:any):void{
 if(value===null||typeof value!=='object'){hash.update(JSON.stringify(value));return;}
 if(Array.isArray(value)){hash.update('[');value.forEach((v:any,i:number)=>{if(i)hash.update(',');incrementalDigest(v,hash)});hash.update(']');return;}
 hash.update('{');Object.entries(value).forEach(([k,v],i)=>{if(i)hash.update(',');hash.update(JSON.stringify(k)+':');incrementalDigest(v,hash)});hash.update('}');
}
