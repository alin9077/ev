"""Inventory every file, all extensions/hidden paths; only reviewed allowlist may be persisted."""
import pathlib,json,hashlib,re,datetime
R=pathlib.Path('/tmp/polestar-research');sha=lambda b:hashlib.sha256(b).hexdigest()
excluded={
'config-inspect.json':'Exploratory raw serialized runtime/scripts; local-only. Safe replacements are current/*-config-public.json with raw-response hash and transformation receipt.',
'config-data-TEMP.json':'Exploratory unsanitized decoded runtime; local-only. Safe public extracts retained separately.',
'polestar2-specs.html':'Original raw maker response with scripts/runtime; local-only. current/p2-spec.html/.txt are sanitized replacement, original-response hash retained.',
'price-browser.cjs':'Abandoned local Chromium exploration script; local-only. Supported cloud-browser attempts and outcomes are recorded in browser-price-attempts.json.',
'price-browser.log':'Raw local Chromium failure transcript includes ephemeral process/profile details; local-only. Resource receipt and bounded factual summary retained.',
'price-browser-retry.log':'Raw local Chromium retry transcript includes ephemeral process/profile details; local-only. Resource receipt and bounded factual summary retained.',
'extract-config.cjs':'Superseded exploratory runtime extraction code; local-only. Reviewed public-only extractor retained.',
'patch-normalized.py':'Obsolete one-shot draft editing script; local-only. Current builder retained.',
'original-polestar.json':'Exploratory historic extract also includes unrelated Volvo source rows; local-only. Full original before fixtures and original source snapshot retained instead.'}
# Only these auto-generated inventory files are excluded from their own self-reference.
selfs={'retention-manifest.json','retained-files.txt','retention-summary.json'}
patterns={
'executable HTML':re.compile(r'<(?:script|iframe)(?=[\s/>])',re.I),
'hidden form':re.compile(r'<input[^>]+type=[\"\']?hidden',re.I),
'authentication header':re.compile(r'(?im)^\s*(?:set-cookie|authorization)\s*:\s*\S+'),
'credential assignment':re.compile(r'(?i)(?:csrf[-_]?token|form_token|sessionid|access_token|refresh_token|api[_-]?key|auth[_-]?token)\s*[=:]\s*[\"\'][A-Za-z0-9_\-/+]{12,}'),
'capability URL query':re.compile(r'https?://[^\s\"<>]+[?&](?:token|auth|code|csrf|sessionid|sig)=[A-Za-z0-9_\-/+%]{16,}',re.I),
'private key block':re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')}
rows=[];findings=[]
for f in sorted(R.rglob('*')):
 if not f.is_file():continue
 rel=str(f.relative_to(R));data=f.read_bytes();excludedReason=excluded.get(rel)
 if rel in selfs:continue
 try:txt=data.decode('utf-8');encoding='utf-8'
 except UnicodeDecodeError:txt='';encoding='binary'
 hit={name:len(rx.findall(txt)) for name,rx in patterns.items() if rx.search(txt)}
 # Source-code regex literals can mention tags; that is not an executable capture or credential.
 code=f.suffix in ['.py','.ts','.cjs','.js']
 if code:hit={k:v for k,v in hit.items() if k not in ['executable HTML','hidden form']}
 action='exclude-local-only' if excludedReason else 'retain-reviewed'
 row=dict(path=rel,bytes=len(data),sha256=sha(data),encoding=encoding,action=action,reason=excludedReason or 'Public source capture, source/code recovery input, before fixture, canonical transition, or measured QA output; complete content scanned regardless extension.',contentScan=hit)
 rows.append(row)
 if action=='retain-reviewed' and (hit or encoding=='binary'):findings.append(row)
assert not findings,json.dumps(findings,indent=2)
manifest=dict(checkedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Every non-directory file recursively under the research root, including root-level, temporary, hidden and extensionless files. No extension-only scanning. Manifest self-files excluded only to prevent recursive hashing.',sourceRoot=str(R),policy='Backup and recovery must consume retained-files.txt allowlist only. Original excluded captures remain locally intact; do not copy the whole scratch directory.',allFilesInventoried=len(rows),retainedCount=sum(x['action']=='retain-reviewed' for x in rows),excludedCount=sum(x['action']=='exclude-local-only' for x in rows),retainedFindings=[],inertMarkupReview={'scope':'Three immutable replay JSONL files','finding':'162 occurrences of a literal locator_hint regex beginning <script[^>; these are original JSON string metadata, not HTML tags or executable code. Full tag detector requires actual whitespace, slash or closing bracket after tag name. Original snapshots unchanged.'},metadataFiles=sorted(selfs),rows=rows)
(R/'retention-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(R/'retained-files.txt').write_text(''.join(x['path']+'\n' for x in rows if x['action']=='retain-reviewed')+''.join(x+'\n' for x in sorted(selfs)))
summary={k:v for k,v in manifest.items() if k!='rows'};summary['manifestSha256']=sha((R/'retention-manifest.json').read_bytes());summary['allowlistSha256']=sha((R/'retained-files.txt').read_bytes());(R/'retention-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
