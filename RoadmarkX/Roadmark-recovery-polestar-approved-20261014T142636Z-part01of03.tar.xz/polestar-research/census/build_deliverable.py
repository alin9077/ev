import pathlib,json,hashlib,datetime
R=pathlib.Path('/tmp/polestar-research/census')
SPECS='p5_specs';CFG='p5_config_public';GUIDE='p5_carsguide_towing';SUP='p5_support';PRICE='p5_pricing_atlas';REVIEW='p5_car_expert_review'
def f(v,unit=None,status='Confirmed',basis=None,sources=None,qualification=None,**kw):
 d={'value':v,'status':status,'sourceIds':sources or [SPECS]}
 if unit:d['unit']=unit
 if basis:d['basis']=basis
 if qualification:d['qualification']=qualification
 d.update(kw);return d
rows=[]
for name,code,sv,pr,ran,power,torq,acc,height,alt in [('Dual motor - Launch edition','GC','PI',171100,678,550,812,3.9,1425,1429),('Performance - Launch edition','GA','PL',193100,558,650,1015,3.2,1419,1420)]:
 facts={
 'price_aud':f(pr,'AUD','Reported','Recommended price including applicable GST and LCT, excluding registration, stamp duty, insurance and dealer delivery',[PRICE,REVIEW], 'Atlas pricing date 2026-10-01; model labels omit Launch edition, mapped by official AU version identity and June AU review. Current official configurator numeric prices are absent; this is not a current official quote.'),
 'range_km':f(ran,'km',basis='WLTP range target/up to',sources=[SPECS,CFG],qualification='Current AU specs labels this Range target (WLTP). Configurator supports same value. Older AU launch reports 670/565 are superseded for this fact. Actual range varies.'),
 'battery_kwh':f(112,'kWh',basis='Published battery capacity; 800 V lithium-ion NMC',qualification='Official AU wording does not explicitly say gross or usable. Secondary AU review distinguishes 112 total and 106 usable; preserve published capacity label.'),
 'dc_peak_kw':f(350,'kW',basis='Maximum DC fast-charging rate',qualification='Peak, not sustained; do not derive 400 V capability from internal configurator field naming.'),
 'dc_charge_time_min':f(22,'min',basis='10–80% using 350 kW DC charger',qualification='Published charging time; conditions and temperature affect actual result.'),
 'ac_kw':f(11,'kW',basis='AC maximum/home or public charging',qualification='Official 0–100% time 11 hours.'),
 'seats':f(5,'seats',basis='4+1 seating configuration',sources=[SUP,'p5_overview'],qualification='Officially described as 4+1: four principal seats and an occasional fifth rear centre position, formed with centre armrest raised. Do not present as five equivalent full-size seats.'),
 'boot_l':f(365,'L',basis='Rear storage, seats up; includes 52 L underfloor',qualification='Measurement protocol such as VDA/SAE not stated. Separate 62 L front compartment is excluded.'),
 'zero_to_100_s':f(acc,'s',basis='Manufacturer claimed 0–100 km/h',sources=[SPECS,CFG]),
 'power_kw':f(power,'kW',basis='Maximum net power',sources=[SPECS,CFG]),
 'drive':f('AWD',basis='Dual electric motors; all-wheel drive',sources=[SPECS,CFG]),
 'length_mm':f(5087,'mm',sources=[SPECS,CFG]),
 'width_mm':f(2063,'mm',basis='Mirrors extended',sources=[SPECS,CFG],qualification='Mirrors folded 2015 mm; no body-only width established in these current official AU sources.'),
 'height_mm':f(height,'mm','Check','Current official AU specifications page value',[SPECS,CFG],f'Unresolved official-source conflict: specs page {height} mm; MY26 AU configurator {alt} mm. No explanation of measurement/load basis found. Do not silently resolve.',conflictingValues=[{'value':height,'sourceId':SPECS},{'value':alt,'sourceId':CFG}]),
 'towing_braked_kg':f(1800,'kg','Reported','Maximum braked trailer rating',[GUIDE,SPECS,'p5_towing_manual'],'CarsGuide 2026 table explicitly gives 1800 kg for both Launch editions; AU specs corroborates 1800 kg as Towing power. Current AU manual page has Braked trailer heading but no numerical table, so braked classification is not confirmed there. Optional semi-electric towbar; check vehicle-specific limits.'),
 'warranty':f('5 years',basis='Vehicle warranty',qualification='Model-specific AU specs states five years and service-plan condition. Parent should apply current general AU warranty terms for kilometre limit; do not infer unlimited from this page alone.'),
 'battery_warranty':f({'years':8,'km':160000,'minimum_soh_percent':70},basis='Whichever occurs first; repair/replacement if SoH below70%',qualification='Exact exclusions/terms subject to warranty documents.'),
 'torque_nm':f(torq,'Nm',sources=[SPECS,CFG]),
 'battery_usable_kwh':f(106,'kWh','Reported','Usable battery capacity',[REVIEW],'Australian review dated 2026-06-01; current official AU spec/config publish112 kWh capacity without usable split.'),
 'battery_voltage_v':f(800,'V'),
 'frunk_l':f(62,'L',basis='Front storage compartment'),
 'max_total_cargo_l':f(1128,'L',basis='Rear storage seats folded; includes52 L underfloor',qualification='This is published rear cargo maximum, not combined rear+front total. No addition performed;62 L frunk separately recorded.'),
 'body_configuration':f('Four-door performance GT / fastback-style rear hatch',basis='Manufacturer GT naming;4+1 cabin',sources=[SUP,'p5_overview'],qualification='Publications differ between four-door sedan/grand tourer and five-door fastback counting hatch. Avoid an unqualified numeric door count without a catalogue convention.'),
 'wheelbase_mm':f(3054,'mm',sources=[SPECS,CFG]),
 'kerb_weight_kg':f(2500,'kg',basis='Published curb weight',sources=[SPECS,CFG]),
 'top_speed_kmh':f(250,'km/h',sources=[SPECS,CFG])}
 equipment={
 'pilot_pack':f('Included',basis='Launch edition includes Pilot pack',sources=[SPECS,CFG]),
 'adaptive_cruise_control':f('Standard',basis='Included safety feature'),
 'pilot_assist':f('Standard on Launch edition',basis='Pilot pack included'),
 'lane_change_assist':f('Standard on Launch edition',basis='Pilot pack included'),
 'climate_pack':f('Included',basis='Launch edition includes Climate pack',sources=[SPECS,CFG]),
 'heated_front_seats':f('Standard'),
 'heated_rear_seats':f('Standard on Launch edition',basis='Climate pack included'),
 'heated_steering_wheel':f('Standard on Launch edition',basis='Climate pack included'),
 'heated_wiper_blades':f('Standard on Launch edition',basis='Climate pack included'),
 'head_up_display':f('Standard on Launch edition',basis='Graphical HUD with infrared windscreen included'),
 'surround_camera':f('360-degree with3D view',basis='Standard parking assistance'),
 'airbags':f(8,'airbags'),
 'centre_screen':f(14.5,'inch',basis='LCD; Android Automotive OS'),
 'driver_screen':f(9,'inch',basis='LCD'),
 'climate_zones':f(4,'zones'),
 'phone_wireless_charging':f(15,'W'),
 'apple_carplay':f('Future introduction',basis='Wireless Apple CarPlay',qualification='Official AU specifications says available with future introduction. Do not mark currently available.'),
 'apple_digital_key':f('Future introduction',basis='Digital key for Apple devices',qualification='Official AU specifications says available with future introduction.1 ultra-wideband key and2 NFC key cards are listed.'),
 'google_gemini':f('Future update',qualification='Official AU footnote: Google Gemini will be available in a future update.'),
 'connected_services_plus':f('First12 months included; renewable thereafter',qualification='Third-party apps and services subject to subscription/compatibility.'),
 'nappa_upgrade':f('Optional',basis='Bridge of Weir leather; ventilation;massage;14-way front seats;rear lumbar adjustment'),
 'towbar':f('Optional',basis='Semi-electric towbar')}
 if code=='GC':
  equipment.update({'wheels':f('20-inch Aero',sources=[SPECS,CFG]),'suspension':f('Passive dampers with coil springs and hydraulic rebound stops',sources=[SPECS,CFG]),'audio':f('300W10-speaker high-performance audio',sources=[SPECS,CFG]),'bowers_wilkins':f('Optional',qualification='21 speakers; power conflicts between official pages1610W and config1680W, do not publish a single wattage without Check')})
 else:
  equipment.update({'wheels':f('21-inch Performance',sources=[SPECS,CFG]),'suspension':f('MagneRide semi-active dampers with electromagnetic control',sources=[SPECS,CFG]),'audio':f('Bowers & Wilkins21-speaker audio',sources=[SPECS,CFG],qualification='Included; current official specs1610W versus config1680W conflict. Speaker count consistent; wattage unresolved.'),'headlining':f('MicroSuede',sources=[SPECS,CFG]),'swedish_gold_details':f('Seatbelts,brake callipers,valve caps',sources=[SPECS,CFG])})
 rows.append({'make':'Polestar','model':'5','modelYear':2026,'variant':name,'engineCode':code,'salesVersionCode':sv,'structureWeek':'202528','market':'AU','reviewDate':'2026-10-14','censusDisposition':'provisional announced/configurator presence; current orderability unconfirmed','availability':{'status':'Check','disableBtoOption':True,'disableCheckout':False,'estimatedDelivery':'January–February2027','physicalStockConfirmed':False,'sourceIds':[CFG],'qualification':'Default configuration response. Public configurator presence and delivery estimate do not establish ability to place a fresh order or physical stock. No checkout attempted.'},'coreFacts':{k:facts.pop(k) for k in ['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty','battery_warranty']},'extraFacts':facts,'equipment':equipment})
(R/'polestar5_normalized_rows.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
# Current residual evidence is bounded to what has been verified; no synthetic inventory.
census={'asOf':'2026-10-14','exhaustiveness':'Unresolved; current live exact-version residual-new inventory not obtained. Offers are eligibility evidence, not physical-stock proof. Generic marketplace new-to-order records are not stock records.','modelYears':[
 {'model':'2','modelYear':2026,'status':'Current official residual-year eligibility','sourceIds':['p2_offers'],'detail':'Oct1–Dec31 offer explicitly eligible pre-configuredMY26/MY27; no exact MY26 version/unit inventory verified. Current offer wording Rear motor is not sufficient to map all historical powertrains.'},
 {'model':'2','modelYear':2025,'status':'Unresolved residual-new','sourceUrls':['https://www.carsales.com.au/cars/new/polestar/2/','https://www.polestar.com/au/offers/private/polestar-2/'],'detail':'September cached official offer referencedMY25, but current offer no longer does. Carsales generic MY25 new-to-order records list SRSM,LRSM,LRDM,LRDM Performance; these establish catalogue identities only, not current remaining new stock.'},
 {'model':'2','modelYear':2024,'status':'Unresolved historical residual lead','sourceUrl':'https://www.carexpert.com.au/car-news/polestar-offers-end-of-financial-year-discounts-of-up-to-29000','detail':'Historical June2025 offer mentionedMY23/MY24 pre-configured vehicles. No current new unit verified; used/demo hits excluded.'},
 {'model':'2','modelYear':2023,'status':'Unresolved historical residual lead','sourceUrl':'https://www.carexpert.com.au/car-news/polestar-offers-end-of-financial-year-discounts-of-up-to-29000','detail':'Historical June2025 offer only; no current new-unit evidence.'},
 {'model':'3','modelYear':2025,'status':'Unresolved residual-new','sourceIds':['p3_offers'],'sourceUrls':['https://www.carsales.com.au/cars/new/2025/polestar/3/','https://www.carsguide.com.au/car/14862895/polestar/3/suv'],'detail':'Current official offerMY27 only. Generic MY25 new-to-order listings identify LRSM,LRDM,LRDM Performance and Plus-pack combinations; no live exact new unit verified. Do not map calendar2026 listings labelledMY25 to new800V generation.'},
 {'model':'3','modelYear':2024,'status':'Unresolved historical residual lead','detail':'Search returned used/demo MY24 examples; no current new unit verified.'},
 {'model':'3','modelYear':2026,'status':'AU identity unresolved; no new row established','detail':'Overseas MY26 naming/800V rollout must not be used to invent AU residualMY26 rows. Current AU facelift marketedMY27 by official configurator parent research.'},
 {'model':'4 coupé','modelYear':2025,'status':'Unresolved residual-new','sourceIds':['p4_offers','p4_my25_sold_listing'],'detail':'Cached September official offer referencedMY25/MY26; current Oct offerMY27 only. Category listing initially calledMY25 Dual Motor Dealer new; exact OAG-AD-26188173 page nowSold andDealer demo. Excluded. Generic LRSM/LRDM records are not stock proof.'},
 {'model':'4 coupé','modelYear':2026,'status':'Unresolved residual-new','sourceIds':['p4_offers'],'sourceUrls':['https://www.carsales.com.au/cars/new/2025/polestar/4/'],'detail':'Generic new-to-order LRSM,LRDM,Plus andPlus Performance variants remain discoverable; no current exact new unit verified. Historical September pre-configured offer is expired and not current availability evidence.'}
 ],'inventoryAccess':[{'model':m,'sourceId':sid,'result':'HTTP200 app shell; visible main text contains no inventory records. Read-only web extractor showed JavaScript required. No inventory absence inferred.'} for m,sid in [('2','p2_inventory'),('3','p3_inventory'),('4 coupé','p4_inventory')]],'doNotInfer':['No physical-stock promise from marketplace listings','No absence-of-stock conclusion from an empty JavaScript shell','No currently active September2026 offers','No overseasMY26-to-AUMY27 equivalence without local evidence']}
(R/'residual_census.json').write_text(json.dumps(census,ensure_ascii=False,indent=2))
# Source manifest hashes only persisted sanitised captures, not raw authenticated data.
manifest=[]
for p in sorted(R.glob('*.capture.json')):
 data=json.loads(p.read_text());urls=[]
 if isinstance(data,dict):urls=[data.get('source_url') or data.get('url')]
 elif isinstance(data,list):urls=[d.get('source_header','').split('\n')[0] for d in data]
 manifest.append({'sourceId':p.name.removesuffix('.capture.json'),'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'url':urls,'capturedAt':data.get('captured_at_utc',data.get('captured_at',data.get('checkedAt'))) if isinstance(data,dict) else '2026-10-14'})
(R/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print('rows',len(rows),'sources',len(manifest),'core counts',[len(r['coreFacts']) for r in rows])
