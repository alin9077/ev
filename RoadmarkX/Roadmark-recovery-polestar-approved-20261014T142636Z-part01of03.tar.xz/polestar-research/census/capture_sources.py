import urllib.request,html.parser,concurrent.futures,pathlib,json,hashlib,datetime,re,sys
ROOT=pathlib.Path('/tmp/polestar-research/census')
class TextParser(html.parser.HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.block=0;self.parts=[];self.block_tags={'script','style','noscript','iframe','form','button','input','header','footer','nav'}
 def handle_starttag(self,tag,attrs):
  if tag in self.block_tags and tag not in {'input'}:self.block+=1
  if not self.block:self.parts.append('\n')
 def handle_endtag(self,tag):
  if tag in self.block_tags and tag not in {'input'} and self.block:self.block-=1
  if not self.block:self.parts.append('\n')
 def handle_data(self,data):
  if not self.block:self.parts.append(data)
def capture(it):
 name,url=it
 try:
  with urllib.request.urlopen(url,timeout=70) as r:html=r.read().decode('utf-8','replace');status=r.status;final_url=r.url
  p=TextParser();p.feed(html)
  body='\n'.join(x.strip() for x in ''.join(p.parts).splitlines() if x.strip())
  body='\n'.join(x for x in body.splitlines() if not any(z in x.lower() for z in ['captcha','csrf','__cf_','access_token','cookieconsent','challenge-platform']))
  cap={'source_url':url,'final_url':final_url,'captured_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'http_status':status,'capture_type':'sanitized_nonexecuting_page_text','sanitization':'Scripts, styles, noscript, iframe, forms, buttons, inputs, headers, footers, navigation and capability/challenge markers removed. No headers, cookies, auth state, tokens or executable HTML retained.','text':body}
  path=ROOT/(name+'.capture.json');path.write_text(json.dumps(cap,ensure_ascii=False,indent=2));return name,status,len(body),hashlib.sha256(path.read_bytes()).hexdigest()
 except Exception as e:return name,'ERROR',type(e).__name__,str(e)
if __name__=='__main__':
 urls=json.loads(sys.stdin.read())
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
  for res in pool.map(capture,urls.items()):print(res,flush=True)
