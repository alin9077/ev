import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {effectiveFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/data.ts';
import {applyBrandUpdates,prepareBrandResearch} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-updates.ts';
import {readReplaySnapshot} from './read-replay-snapshot.ts';
const R='/tmp/polestar-research/';
const original=JSON.parse(fs.readFileSync(R+'canonical-packet-at-baseline.json','utf8'));original.features=[];
const amended=JSON.parse(fs.readFileSync(R+'polestar-2026-10-14.json','utf8'));amended.features=[];
const sha=(v:any)=>crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex');
const fileSha=(p:string)=>crypto.createHash('sha256').update(fs.readFileSync(R+p)).digest('hex');
const originalMeta=JSON.parse(fs.readFileSync(R+'canonical-baseline-meta.json','utf8'));assert.equal(sha(original),originalMeta.canonicalHash);
const amendments:any[]=[];const canonical=structuredClone(original);
for(let i=0;i<original.facts.length;i++){
 const old=original.facts[i],now=amended.facts[i];
 if(old.after.key!=='price_aud')continue;
 assert.equal(now.variantId,old.variantId);
 const paths:any[]=[];
 for(const field of ['basisTag','originalBasis']){
  const a=old.after.priceEvidence[field],b=now.after.priceEvidence[field];
  if(a!==b){paths.push({path:`facts[${i}].after.priceEvidence.${field}`,before:a,after:b});canonical.facts[i].after.priceEvidence[field]=b;}
 }
 assert(paths.length>0);amendments.push({variantId:old.variantId,factKey:'price_aud',paths,reason:'Retain explicit published before-on-road-costs label in dedicated provenance, separate from disclaimers, so contradictory comparisonBasis mutations are rejected. Amount, grade, source scope and ranking eligibility unchanged.'});
}
assert.equal(amendments.length,14);assert.deepEqual(canonical,amended,'All canonical differences are exactly the14 documented price-provenance amendments');
const {rd,before}=readReplaySnapshot(R);
const derive=(p:any)=>{const data=prepareBrandResearch(rd,[p]),cars=applyBrandUpdates(before,data,[p]);return JSON.parse(JSON.stringify(cars.filter((c:any)=>p.variants.some((v:any)=>v.id===c.id)).flatMap((c:any)=>effectiveFeatures(c,data))));};
const oldFeatures=derive(original);const fixture=JSON.parse(fs.readFileSync(R+'new-feature-before.json','utf8'));assert.deepEqual(oldFeatures,fixture,'Original complete baseline independently replayed');
const newFeatures=derive(amended);
const diffs:any[]=[];function diff(a:any,b:any,path=''){if(JSON.stringify(a)===JSON.stringify(b))return;if(a===null||b===null||typeof a!=='object'||typeof b!=='object'){diffs.push({path,before:a,after:b});return;}for(const k of new Set([...Object.keys(a),...Object.keys(b)]))diff(a[k],b[k],path+'/'+k)}diff(oldFeatures,newFeatures);
assert.equal(diffs.length,0,'Price provenance does not change any raw generated feature field; all138 original rows remain equal');
const file='new-feature-before-v2.json';assert(!fs.existsSync(R+file),'Versioned amendment never overwrites original or itself');fs.writeFileSync(R+file,JSON.stringify(newFeatures,null,2));assert.equal(fileSha(file),fileSha('new-feature-before.json'),'Complete raw fixture bytes unchanged');
const result={createdAt:new Date().toISOString(),reason:'Root-approved explicit provenance-only canonical amendment; original packet, fixture and hashes retained permanently.',originalCanonicalHash:sha(original),amendedCanonicalHash:sha(amended),originalFixture:'new-feature-before.json',amendedFixture:file,originalFixtureSha256:fileSha('new-feature-before.json'),amendedFixtureSha256:fileSha(file),amendments,featureRows:fixture.length,completeFeatureDiffs:diffs,unchangedCanonicalFieldsVerified:true,unchangedFeatureBytesVerified:true};
fs.writeFileSync(R+'canonical-amendment-proof.json',JSON.stringify(result,null,2));
fs.writeFileSync(R+'canonical-baseline-meta-v2.json',JSON.stringify({...originalMeta,createdAt:result.createdAt,generationCount:2,baselineGenerationCount:2,canonicalHash:sha(amended),originalCanonicalHash:sha(original),fixture:file,fixtureSha256:fileSha(file),note:'Explicit versioned provenance-only amendment. Complete original138 feature rows replayed and compared; zero field differences and byte-identical fixture. Original generation remains untouched. See canonical-amendment-proof.json.'},null,2));
console.log(JSON.stringify({originalCanonical:sha(original),amendedCanonical:sha(amended),prices:amendments.length,featureDiffs:diffs.length,featureBytesEqual:true}));
