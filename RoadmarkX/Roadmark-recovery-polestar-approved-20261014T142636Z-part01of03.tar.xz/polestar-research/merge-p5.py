m=json.loads((R/'census/p5_dimensions_manual.capture.json').read_text());src('p5_dimensions_manual',m['source_url'],'Polestar Australia MY26 Polestar5 manual dimensions with separate body and mirror widths','census/p5_dimensions_manual.capture.json',redactionNote=m['sanitization'])
# Executed inside normalization builder; preserve exact maker MY26 Launch identities.
for raw in json.loads((R/'census/polestar5_normalized_rows.json').read_text()):
 perf=raw['engineCode']=='GA';vid='polestar_5_my26__'+('performance' if perf else 'dual_motor')+'_launch_edition__20261014';facts=[];features=[]
 for key,f in {**raw['coreFacts'],**raw['extraFacts']}.items():
  if key in ['warranty','battery_warranty']:continue
  r=rf(key,f['value'],f['sourceIds'],grade=f['status'].lower(),basis=f.get('basis',key.replace('_',' ')),comparison='',qualifications=[f['qualification']] if f.get('qualification') else [],reason='Current source explicitly reviewed for exact Australian MY26 Launch edition; version identity from public maker configuration.')
  if f.get('unit'):r['unit']=f['unit']
  if key=='price_aud':r.update(priceRung=5,basisTag='Reported before on-road costs · CarExpert',originalBasis=f['basis'],comparison='Before on-road costs',reason='Current maker configuration does not expose a numerical quote. Atlas pricing dated1 October2026 and June Australian Launch-edition review agree on the figure; no tax conversion or discount calculation.')
  elif key=='dc_peak_kw':r.update(sourceKeys=['p5_specs','p5_support'],comparison='Maximum DC input',reason='Current AU support FAQ explicitly states vehicle charging speed up to350 kW DC; specifications independently states the350 kW station for the22-minute window.')
  elif key=='range_km':r.update(grade='check',comparison='WLTP target',condition='Maker labels this a WLTP range target/up-to result; final equipment and wheel configuration can alter range.')
  elif key=='width_mm':r.update(value=1979,sourceKeys=['p5_dimensions_manual'],basis='Body width excluding mirrors',comparison='Width excluding mirrors',qualifications=['MY26 AU manual identifies K Width1979 mm separately from L folded-out mirrors2063 mm and M folded-in mirrors2015 mm.'])
  elif key=='height_mm':r.update(grade='check',condition=f['qualification'],reason='Official specifications and exact MY26 configuration disagree by4 mm for Dual motor and1 mm for Performance; measurement/load basis is unresolved. The specifications-page figure is displayed with the conflict, not silently harmonised.')
  elif key=='boot_l':r.update(basis='Rear seats up including52 L underfloor; upper measurement boundary and VDA/SAE protocol unspecified',comparison='')
  elif key=='max_total_cargo_l':r.update(label='Rear cargo with seats folded',comparison='')
  elif key in ['length_mm','wheelbase_mm']:r.update(comparison='Body length' if key=='length_mm' else 'Wheelbase')
  elif key=='dc_charge_time_min':r.update(comparison='10–80% DC')
  elif key=='power_kw':r.update(comparison='Maximum net motor power')
  elif key=='zero_to_100_s':r.update(comparison='0–100 km/h')
  elif key=='seats':r.update(grade='check',condition='4+1 cabin: four principal seats plus an occasional rear-centre fifth position; not five equivalent full-size seats.',comparison='4+1 seating')
  elif key=='towing_braked_kg':r.update(comparison='Braked towing')
  facts.append(r)
 for key,val,basis in [('width_with_mirrors_mm',2063,'Width including mirrors extended'),('width_mirrors_folded_mm',2015,'Width with mirrors folded')]:facts.append(rf(key,val,['p5_dimensions_manual'],basis=basis,comparison='',unit='mm'))
 for key,f in raw['equipment'].items():
  facts.append(rf('equipment_'+key,f['value'],f['sourceIds'],basis=f.get('basis','Current MY26 Launch-edition equipment'),comparison='',qualifications=[f['qualification']] if f.get('qualification') else []))
 facts.append(rf('equipment_google_assistant','Google Assistant through Connected Services Plus',['p5_specs'],basis='Connected Services Plus first12 months included; renewable thereafter',comparison=''))
 def ff(criterion,value,keys,**kw):features.append(feat(criterion,value,['equipment_'+x for x in keys],**kw))
 for criterion,value,keys in [
 ('front_heated_seats','Heated front seats included',['heated_front_seats']),
 ('rear_heated_seats','Heated rear seats included with Launch-edition Climate pack',['heated_rear_seats','climate_pack']),
 ('heated_steering_wheel','Heated steering wheel included with Launch-edition Climate pack',['heated_steering_wheel','climate_pack']),
 ('adas_standard','Adaptive cruise, Pilot Assist and lane-change assistance included with Launch-edition Pilot pack',['adaptive_cruise_control','pilot_assist','lane_change_assist','pilot_pack']),
 ('parking_cameras','360-degree camera with3D view',['surround_camera']),
 ('screens_hud','14.5-inch centre screen,9-inch driver display and included head-up display',['centre_screen','driver_screen','head_up_display']),
 ('wireless_charging','15 W wireless phone charging',['phone_wireless_charging']),
 ('audio_system',raw['equipment']['audio']['value'],['audio']),
 ('voice_assistant','Google Assistant through Connected Services Plus, first12 months included; Google Gemini is announced for a future update',['google_assistant','google_gemini','connected_services_plus'])]:ff(criterion,value,keys)
 ff('front_ventilated_seats','Front ventilation is an extra with the Nappa upgrade',['nappa_upgrade'],status='optional')
 ff('phone_key','Apple digital key is announced for future introduction; do not count it as delivered',['apple_digital_key'],status='conditional',grade='check',condition='Maker expressly labels this a future introduction; activation/current delivery is not established.')
 ff('carplay_android_auto','Wireless Apple CarPlay is announced for future introduction; current Android Auto phone projection is not established',['apple_carplay'],status='conditional',grade='check',condition='Apple CarPlay is future-introduction equipment, not verified delivered functionality.')
 features.extend([
 feat('storage','365 L rear storage with seats up, including52 L underfloor;1128 L rear seats folded. Separate62 L front compartment.',['boot_l','max_total_cargo_l','frunk_l'],conditions='No combined front-plus-rear sum; measurement protocol and upper load boundary unspecified.'),
 feat('performance_rear_motor',f"AWD; {raw['coreFacts']['power_kw']['value']} kW total system output; 0–100 km/h in {raw['coreFacts']['zero_to_100_s']['value']} seconds.",['drive','power_kw','zero_to_100_s'],conditions='Total motor output is not rear-motor output.'),
 feat('home_charging','11 kW maximum onboard AC input',['ac_kw']),
 feat('warranty_service','Five-year vehicle warranty; eight-year/160,000 km battery warranty with70% state-of-health threshold',['warranty','battery_warranty'])])
 av=dict(state='announced_provisional',orderStatus='unverified',stockStatus='unverified',sourceKeys=['p5_config_public'],qualifications=['Exact Australian MY26 Launch-edition configuration is publicly listed. The model-market setting disables the built-to-order option for both engines; checkout setting alone does not establish fresh order acceptance.','Default delivery estimate is January–February2027. No checkout attempted, accepted order, physical unsold stock or guaranteed delivery established.'],reason='Public maker AU model-market configuration names two Launch editions and modelYear2026. Availability remains provisional because the model-wide built-to-order route is disabled and current fulfilment is not verified.')
 summary=dict(strength=dict(label='Rapid800 V charging',text='The maker quotes350 kW peak DC charging and22 minutes from10–80% on a350 kW charger.',keys=['battery_voltage_v','dc_peak_kw','dc_charge_time_min']),tradeoff=dict(label='An occasional fifth seat',text='The cabin has a4+1 layout: four principal seats and an occasional rear-centre position.',keys=['seats']))
 variants.append(dict(id=vid,modelId='polestar_5_my26',familyId='polestar-5',model='5',trim=raw['variant'],modelYear=2026,generation='MY2026 Australian Launch edition',drive='AWD',vehicleClass='passenger',facts=facts,features=features,availability=av,summary=summary,notes=['Official AU public configuration: structure week202528; engine'+raw['engineCode']+'; sales version'+raw['salesVersionCode']+'. No calendar2027 delivery estimate is substituted for official MY26.']))
