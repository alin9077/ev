import pathlib,json,hashlib,re,collections
R=pathlib.Path('/tmp/polestar-research');p=json.loads((R/'polestar-2026-10-14.json').read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
keys=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty','battery_warranty']
e=json.loads((R/'polestar-effective-facts.json').read_text());matrix=[dict(variantId=i,key=k,value=fs[k]['value'],grade=fs[k]['buyerGrade'],basis=fs[k]['basis'],comparisonBasis=fs[k]['comparisonBasis'],sourceIds=fs[k]['sourceIds'],reason=fs[k]['gradeReview']['reason'])for i,fs in e.items() for k in keys]
(R/'core-matrix.json').write_text(json.dumps(matrix,indent=2,ensure_ascii=False)+'\n')
sourceIndex=[];files={}
for s in p['sources']:
 row=dict(id=s['id'],url=s['url'],publisher=s['publisher'],sourceType=s['source_type'],checkedAt=s['accessed_date'],publishedAt=s['published_date'])
 for loc,h in [('capture_locator','capture_sha256'),('capture_text_locator','capture_text_sha256')]:
  if loc in s:
   f=R/s[loc];assert f.exists() and sha(f)==s[h];files[s[loc]]=dict(bytes=f.stat().st_size,sha256=s[h]);row[loc]=s[loc]
 if s['id'].endswith('p5_car_expert_review'):row['scopeNote']='Secondary June AU review labels the price table2027; official AU configuration explicitly identifies MY26. Maker model year is retained, numerical price remains Reported, and October Atlas corroborates amounts.'
 sourceIndex.append(row)
(R/'source-index.json').write_text(json.dumps(sourceIndex,indent=2)+'\n');(R/'source-hash-manifest.json').write_text(json.dumps(files,indent=2)+'\n')
issues=[];scan=[]
for sub in ['current','census']:
 for f in (R/sub).iterdir():
  if f.suffix not in ['.html','.txt','.json']:continue
  s=f.read_text(errors='replace');patterns={'script':r'<script\b','iframe':r'<iframe\b','hidden input':r'<input[^>]+type=[\"\']hidden','cookie header':r'(?im)^set-cookie\s*:','authorization header':r'(?im)^authorization\s*:\s*(?:bearer|basic)','csrf assignment':r'(?i)(?:csrf[-_]?token|form_token|sessionid|access_token)\s*[=:]\s*[\"\'][A-Za-z0-9_\-/+]{12,}'}
  found={k:len(re.findall(v,s))for k,v in patterns.items() if re.search(v,s)};scan.append({'path':str(f.relative_to(R)),'bytes':f.stat().st_size,'findings':found})
  if found:issues.append(scan[-1])
audit=dict(checkedAt='2026-10-14',method='Value-aware public-capture scan plus source-scope review; no response headers or browser state persisted',findings=issues,files=scan,privacyDecision='Only public manufacturer/dealer/publication pages, PDFs and factual browser-attempt summary. HTML sanitised before persistent packaging. No browser screenshots included; source PDF page renderings are technical source review.',immutableHistoricalSourcesPreserved=True)
(R/'privacy-review.json').write_text(json.dumps(audit,indent=2)+'\n')
summary=dict(checkedAt='2026-10-14',packet=p['id'],variantCount=len(e),newVersionCount=len(p['variants']),coreCells=len(matrix),coreGradeCounts=dict(collections.Counter(x['grade']for x in matrix)),twoSourceNotPublished=[x for x in matrix if x['grade']=='not_published'],factEdits=len(p['facts']),sharedTerms=len(p['brandTerms']),featureEdits=len(p['features']),summaryPairs=len(p['summaries']),sources=len(p['sources']),allSourceCapturesVerified=True,researchCompleted=False,unresolved=['Nationwide residual-new older Polestar2,3 and4 census','P5 current factory-order acceptance and new SUV fulfilment','Whole-market two independent published model-list reconciliation'],chargingIntegrity='Exact10–80% windows; P3 800 V and400 V results separate; station rating is not silently substituted for vehicle peak.11 kW AC standard; P4 22 kW separate option.',pricingIntegrity='Exact secondary AU before-ORC prices retained as Reported after maker-price retrieval failure. Maker offers remain separate, no tax conversion or discount deduction.',availabilityIntegrity='Current listing, future default build delivery and provisional/order-open status remain separate; no physical-stock or accepted-order claim')
(R/'evidence-completeness-audit.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n'); print(json.dumps(summary,ensure_ascii=False)[:800]); print('Privacy findings',len(issues))
