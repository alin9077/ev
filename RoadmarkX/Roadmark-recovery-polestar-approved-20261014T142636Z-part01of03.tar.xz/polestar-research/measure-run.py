import subprocess,resource,time,json,sys,pathlib
name=sys.argv[1];cmd=sys.argv[2:];start=time.time();result=subprocess.run(cmd);u=resource.getrusage(resource.RUSAGE_CHILDREN)
p={'operation':name,'exitCode':result.returncode,'elapsedSeconds':time.time()-start,'maxRssKiB':u.ru_maxrss,'userSeconds':u.ru_utime,'systemSeconds':u.ru_stime,'command':cmd,'meaning':'RUSAGE_CHILDREN peak resident set measurement for this serialized invocation; signal exit is retained as negative signal number.'}
pathlib.Path('/tmp/polestar-research/'+name+'-resource-usage.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(p));sys.exit(result.returncode if result.returncode>=0 else 128-result.returncode)
