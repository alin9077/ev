import fs from 'node:fs';
import {catalogue,research,effectiveFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/data.ts';
const root='/tmp/subaru-research/', r=research(), all=catalogue(), cars=all.filter(c=>c.brand==='Subaru'&&(c.vehicleClass===undefined||['passenger','ute'].includes(c.vehicleClass)));
fs.writeFileSync(root+'subaru-live-before.json',JSON.stringify(cars,null,2));
fs.writeFileSync(root+'subaru-source-before.json',JSON.stringify(r.sources,null,2));
fs.writeFileSync(root+'subaru-feature-before.json',JSON.stringify(cars.flatMap(c=>effectiveFeatures(c,r)),null,2));
fs.writeFileSync(root+'subaru-models-before.json',JSON.stringify(r.models.filter(c=>c.brand==='Subaru'),null,2));
fs.writeFileSync(root+'subaru-variants-before.json',JSON.stringify(r.variants.filter(c=>c.brand==='Subaru'),null,2));
console.log(cars.map(c=>({id:c.id,model:c.model,trim:c.trim,year:c.year,availability:c.availability,drive:c.drive,facts:Object.keys(c.facts).length})));
const dir=root+'replay-snapshot'; fs.mkdirSync(dir,{recursive:true});
const index:any={research:{},cars:'replay-snapshot/cars.jsonl'};
const writeRows=(file:string,rows:any[])=>{const fd=fs.openSync(root+file,'w');try{for(let i=0;i<rows.length;i++){fs.writeSync(fd,JSON.stringify(rows[i])+'\n');if(i%50===0)global.gc?.();}}finally{fs.closeSync(fd);}};
for(const [k,v] of Object.entries(r)){const file='replay-snapshot/research-'+k+'.jsonl';writeRows(file,Array.isArray(v)?v:[v]);index.research[k]={file,array:Array.isArray(v)};}
writeRows(index.cars,all);fs.writeFileSync(root+'replay-snapshot-index.json',JSON.stringify(index,null,2));
