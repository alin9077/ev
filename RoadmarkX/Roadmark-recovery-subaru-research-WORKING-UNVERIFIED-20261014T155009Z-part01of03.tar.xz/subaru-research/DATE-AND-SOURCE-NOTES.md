# Subaru source scope, 15 October 2026

All retrievals, reviews and report parity for this packet use 2026-10-15 in Australia/Sydney. Research began at 2026-10-14 14:24 UTC, after Australian midnight. UTC and Australian calendar dates are not silently interchanged.

Direct public HTTP recovered the live model/specification component JSON without executing it. Exact ModelLandingPage modelYear, modelVariants.name/year, manufacturersListPrice and isDriveAway=false establish the named version and before-on-road price. Spec-component zero price placeholders are ignored. No tax conversion or discount subtraction occurred.

Live default pages and all three current PDFs say MY27. Indexed search responses still say MY26; they do not override live sources. Exact /2026 Trailseeker and Uncharted model/spec pages are retained separately. MY26 Solterra current canonical route is unavailable; its technical/equipment figures are Reported from exact Australian secondary reporting and a dealer-hosted manufacturer-authored MY26 brochure. Its current price is Reported from the May 2026 price cut, not the superseded November 2025 launch price.

Top-level spec variants.features contains copied legacy Solterra 160 kW/485 km/free 5 yearservice/5 yearroadside text even for other models. That block is retained as source evidence but is not imported as current equipment. Exact spec/specFeatures tables, current PDFs and dedicated terms control the current data. Old/new source contradictions stay explicit.

Uncharted MY27: current website says approximately 30 minutes 10–80%; current brochure says 30 minutes 0–80%. The two claims remain separate with Check grade and an exact-window warning. AC time is not silently corrected from the PDF's 11 kW row to the website's 22 kW row. This packet publishes the unambiguous 22 kW maximum, not an invented corrected time.

Current range table rows explicitly say WLTP. Generic ADR 81/02/laboratory footers do not become a new cycle or a per-fact lab-test condition. Cargo protocol is not published; no VDA/SAE basis or volume sum is inferred. Ordinary folded volume and ceiling maximum have separate keys. VehicleDC acceptance is supported by explicit fast-charge-input/capability text as well as the technical table.

Current private-use warranty is 5 years/unlimitedkm; specified commercial use 5 years/150000 km. High-voltage battery manufacturing-defect cover is 8 years/160000 km. The current summary does not publish a capacity-retention threshold. Roadside is 12 months with opt-in at delivery and fewer than 5 vehicles under the Club Membership offer. Legacy MY24 free-service/5 year-roadside text is not inherited by MY26/MY27.

Six currentMY27 configurations and five independently rechecked New-advertisedMY26 residuals are included. No ad proves physical stock or order acceptance. The roof package is an option configuration, not an extra Uncharted marketing grade. The live MY26 no-roof lead is still option-ambiguous. Older MY24/MY 25 Solterra AWD/Touring current-new supply remains unresolved. Getaway and E-Outback foreign evidence does not establish Australian new-sale eligibility. Brand-only lists do not prove whole-market C 1 closure.

The supported dot cloud browser failed at tab creation (timeout/reset); inventory then reported CDP target closed. The independent reviewer separately reproduced a cloud browser timeout. No replacement Chromium, user computer, login, CAPTCHA or screenshot workflow was used. HTTP and PDF source research continued.

Servicing is represented separately from warranty. All 11 reviewed versions have an explicitly scoped five-year/75,000 km capped-price program: the MY26 Solterra manufacturer schedule is exact-year evidence, while current model brochures explicitly cover eligible MY26 onward vehicles. This does not import legacy complimentary servicing, infer a shared interval, or sum fees across models. The buyer criterion named Servicing contains the service program only.

Uncharted has a powered tailgate, but hands-free kick operation is not established. Its model/brochure/launch material names ten Harman Kardon speakers while exact web equipment rows mark both speaker choices with a dash; this remains a specific Check-grade source conflict rather than a Confirmed table claim.
