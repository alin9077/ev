import pathlib,hashlib,json,os
R=pathlib.Path('/tmp/subaru-research');repo=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104')
def sha(p):
 h=hashlib.sha256();b=bytearray(1024*1024);v=memoryview(b)
 with p.open('rb') as f:
  while n:=f.readinto(b):h.update(v[:n])
 return h.hexdigest()
rows=[]
for root in ['data','src','scripts','tests']:
 for p in sorted((repo/root).rglob('*')):
  if p.is_file() and p.suffix in ['.json','.ts','.tsx','.js','.mjs','.cjs']:rows.append(dict(file=str(p.relative_to(repo)),sha256=sha(p),mtimeNs=p.stat().st_mtime_ns,bytes=p.stat().st_size))
for name in ['package.json','pnpm-lock.yaml','tsconfig.json']:
 p=repo/name
 if p.exists():rows.append(dict(file=name,sha256=sha(p),mtimeNs=p.stat().st_mtime_ns,bytes=p.stat().st_size))
snap=[dict(file=str(p.relative_to(R)),sha256=sha(p),bytes=p.stat().st_size) for p in sorted((R/'replay-snapshot').glob('*')) if p.is_file()]
idx=R/'replay-snapshot-index.json';snap.append(dict(file=idx.name,sha256=sha(idx),bytes=idx.stat().st_size))
receipt=next(p for p in [R/'capture-before640-resource-usage.json',R/'capture-before704-resource-usage.json'] if p.exists() and json.load(p.open())['exitCode']==0);r=json.load(receipt.open());start=(receipt.stat().st_mtime-r['elapsedSeconds'])*1e9
out=dict(captureReceipt=receipt.name,sourceCode=rows,snapshot=snap,sourceCodeModificationTimesPrecedeCaptureStart=all(x['mtimeNs']<start for x in rows),note='Full captured research arrays and all catalogue rows are immutable replay inputs; exact source/code hashes guard their reuse. Hashing was serialized after original capture with1MiB reusable buffer; source/code mtimes precede original invocation start.')
assert out['sourceCodeModificationTimesPrecedeCaptureStart'],'Unexpected source/code change during original capture; do not claim immutable baseline'
(R/'replay-provenance-manifest.json').write_text(json.dumps(out,indent=2));print('source/code',len(rows),'snapshot',len(snap))
