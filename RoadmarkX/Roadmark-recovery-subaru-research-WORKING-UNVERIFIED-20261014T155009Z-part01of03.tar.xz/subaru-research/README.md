# Subaru Australian M1 evidence, checked 15 October 2026

Status: source research reconciled; final baseline, staged replay, independent replay and root registration are still pending. This document must not be read as completed integration approval.

## Bounded scope

Eleven exact Tier 1 passenger configurations are proposed: six current MY27 configurations across Solterra, Trailseeker and Uncharted, plus five individually rechecked advertised-new MY26 residual configurations. Two MY27 Solterra identities are additions. Panoramic-roof Uncharted is a selected option configuration, not another marketing grade. No dealer advertisement establishes physical stock or accepted factory orders.

Current live official pages and PDFs identify MY27. Retained exact MY26 pages and advertisements remain separate, and MY26 Solterra technical evidence is explicitly Reported where the accessible original maker brochure is dealer-hosted or the source is an Australian publication. Copied legacy marketing blocks are not used to populate current facts.

Older MY24/MY25 Solterra advertised-new availability and the exact no-roof MY26 Uncharted residual remain unresolved. No distinct Australian MY23 Solterra is established. Brand-only lists are not whole-market C1 lists; research closure remains open.

## Source and draft artifacts

- `normalized-evidence.json`: 11 identities, 646 proposed specific facts and 293 proposed equipment/service replacements, with explicit source keys and conditions
- `terms-normalized.json`: three shared Australian warranty, battery-warranty and roadside terms, with eligibility limits
- `subaru-reconciliation-2026-10-15.json`: bounded current cohorts and unresolved family census records
- `brand-model-list-reconciliation.json`: official/independent brand-list comparison and complete residual findings
- `DATE-AND-SOURCE-NOTES.md`: exact year, range, cargo, charging, audio, service and browser-access boundaries
- `residuals/`: independently captured exact advertised-new evidence, unresolved leads, sanitized source captures and inventory
- `*-public-data.json`, brochures and source text: public evidence. Public component data was extracted without executing runtime scripts; raw responses were not persisted, and their hashes remain in extraction manifests

## Baseline integrity and failed attempts

Every failed capture script, log, measured resource receipt and available original output is retained. Negative process return codes identify signals but do not establish their cause. The initial phased-script transpilation failure remains distinct from process signal terminations.

`capture-attempt640-original/` contains all five completed original Subaru files from the earlier attempt, plus its partial complete-market research output. `capture-phased640-original/` contains all 14 completed current research fields and partial catalogue output from the subsequent phased attempt. Neither partial attempt is labelled a successful full baseline.

The approved recovery approach is an explicit snapshot-backed derivation from the immutable complete pre-Polestar 395-car snapshot through only the final registered approved Polestar packet. `derive-before-v1.ts` and `verify-derivation-inputs.py` require every previous source/code and snapshot hash, exact integration/loader-patch deltas, all 14 current research fields, all non-Polestar car hashes, all five original Subaru files, all 14 actual Polestar packs and portable output, and separate exact 14/15 October reports. The complete execution-input hash set is checked before and after derivation. This is an independent oracle, not fresh hydration.

A fresh complete snapshot using the independently verified loader fix is preferred for the final Subaru baseline if successful. Independent approval of the provenance chain is required before the new-version canonical fixture or self-stage. Root's final integrated validation remains separate.

## Dates and retention

All Subaru review dates and staged/integrated report parity use 2026-10-15 in Australia/Sydney. UTC research took place on 14 October. Prior Polestar reports dated 14 and 15 October are separate immutable fixtures; dates are not normalized away.

Final retention inventory and backup allowlist will be generated after the packet and replay artifacts are frozen. Research files are not all implicitly approved for backup merely because they exist here. No browser screenshots were captured. Downloaded dealer photographs are public listing evidence, not screenshots; no credentials, cookies, CSRF values or browser-runtime capabilities should be included in retained captures.
