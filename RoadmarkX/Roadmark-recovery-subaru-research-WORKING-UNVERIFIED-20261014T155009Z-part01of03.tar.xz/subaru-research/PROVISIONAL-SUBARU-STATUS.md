# Subaru working safety save, 15 October 2026

This is unintegrated research and draft evidence, not a completed Subaru packet or approved baseline. No Subaru registry entry, new-version canonical feature fixture, staged full output, or independent candidate replay has been accepted. The source evidence is frozen while the separately retained loader/baseline proof is resolved.

## Proposed Australian Tier 1 scope

Eleven exact configurations:

- MY27 Solterra AWD and AWD Touring
- MY27 Trailseeker AWD and AWD Touring
- MY27 Uncharted AWD without panoramic roof and with the selected panoramic-roof option
- Separately advertised-new MY26 Solterra AWD and AWD Touring
- Separately advertised-new MY26 Trailseeker AWD and AWD Touring
- Separately advertised-new MY26 Uncharted AWD with panoramic roof

The normalized draft contains 646 specific facts, three shared Australian terms, 293 equipment/service replacements and 11 strength/trade-off pairs. Two MY27 Solterra identities would be additions. Current maker model/configuration fields supply nine before-on-road prices; exact current Australian publication supplies the two MY26 Solterra prices as Reported. No manual tax conversion occurs.

Current live default pages and brochures identify MY27. Exact residual model years remain separate. Advertisements do not prove physical stock, order acceptance or delivery timing. The no-roof MY26 Uncharted lead is option-ambiguous, and older MY24/MY25 Solterra advertised-new census remains unresolved; no distinct Australian MY23 is established. Brand directories and Subaru-only reviews do not close whole-market C1. M1 remains open.

## Evidence exceptions retained

- MY26 Solterra technical/equipment evidence is Reported where it comes from exact Australian secondary coverage or the dealer-hosted manufacturer-authored MY26 brochure
- Solterra acceleration is approximate Australian secondary evidence; MY27 application is explicitly sibling scope
- MY27 Uncharted's website 10–80% and brochure 0–80% charging claims remain separate with Check-grade conflict
- Uncharted's ten-speaker Harman Kardon description conflicts with dash-marked exact website equipment rows, so audio remains Check
- Uncharted power tailgate does not establish hands-free kick operation
- Cargo ordinary-folded and ceiling maximum values are separate; no VDA/SAE protocol is invented and capacities are unranked
- Current capped-price servicing is separate from warranty; legacy complimentary servicing/long roadside terms are not imported

## Interrupted captures and proof status

Every original failed capture, partial value output, script and measured resource receipt remains retained. A signal termination does not establish its cause. Complete old research rows and five completed original Subaru files remain useful evidence, but their interrupted parent attempts are not labelled successful full snapshots.

The separate loader work has preserved original, v1 and request-sharing v2 source transitions and fresh validation/failed capture receipts in the QA tree. A fresh full-value/digest equality proof is still pending. The prepared preflight versions and historical-source extension preserve all prior failures and the omitted seven .mjs files' links to both historical full-source backups.

This safety save preserves recoverable work while that proof continues. It does not change checkpoint 103's delivered milestone status or authorize M2.

## Privacy and image scope

Raw HTTP response bytes were hashed in memory and not persisted; the exclusion hashes remain in extraction/capture manifests. Retained HTML was sanitized, and component JSON contains public model/specification data rather than executed runtime scripts. A full backup privacy scan remains required before capture.

The five PDFs are public source brochures/servicing material. The 15 JPEGs are public dealer-listing photographs used to assess the unresolved MY26 Uncharted roof; exact source URLs and hashes are in residuals/uncharted_base_photo_sources.json. They are not browser screenshots. No browser screenshots were captured in this research directory.
