import fs from 'node:fs';
import {StringDecoder} from 'node:string_decoder';
import assert from 'node:assert/strict';
import {catalogue,research,effectiveFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/data.ts';
import {readReplaySnapshot} from './read-replay-snapshot.ts';
const root='/tmp/subaru-research/';
assert(!fs.existsSync(root+'replay-snapshot-index.json'),'Never replace a completed original snapshot');
const dir=root+'replay-snapshot';fs.mkdirSync(dir,{recursive:true});
const index:any={research:{},cars:'replay-snapshot/cars.jsonl'};
const counts:Record<string,number>={};
// Synchronous row writes finish before the next serialization. No write queue or full-array string.
const writeRows=(file:string,rows:any[])=>{const fd=fs.openSync(root+file,'w');try{for(let i=0;i<rows.length;i++)fs.writeSync(fd,JSON.stringify(rows[i])+'\n');}finally{fs.closeSync(fd);}counts[file]=rows.length;};
console.log('Phase1: complete effective research, without retaining a catalogue');
let r:any=research();global.gc?.();
for(const [k,v]of Object.entries(r)){const file='replay-snapshot/research-'+k+'.jsonl';writeRows(file,Array.isArray(v)?v:[v]);index.research[k]={file,array:Array.isArray(v)};console.log('Wrote research',k,counts[file]);global.gc?.();}
fs.writeFileSync(root+'subaru-source-before.json',JSON.stringify(r.sources,null,2));
fs.writeFileSync(root+'subaru-models-before.json',JSON.stringify(r.models.filter((c:any)=>c.brand==='Subaru'),null,2));
fs.writeFileSync(root+'subaru-variants-before.json',JSON.stringify(r.variants.filter((c:any)=>c.brand==='Subaru'),null,2));
r=null;global.gc?.();
console.log('Phase2: complete effective catalogue, after releasing research');
let all:any=catalogue();global.gc?.();
writeRows(index.cars,all);console.log('Wrote all catalogue rows',all.length);
const cars=all.filter((c:any)=>c.brand==='Subaru'&&(!c.vehicleClass||['passenger','ute'].includes(c.vehicleClass)));
fs.writeFileSync(root+'subaru-live-before.json',JSON.stringify(cars,null,2));
all=null;global.gc?.();
console.log('Phase3: exact Subaru feature baseline from fresh effective research');
r=research();global.gc?.();
fs.writeFileSync(root+'subaru-feature-before.json',JSON.stringify(cars.flatMap((c:any)=>effectiveFeatures(c,r)),null,2));
// The full research captured in phase1 must equal the later feature research, field for field.
for(const[k,v]of Object.entries(r)){
 const file=root+index.research[k].file,rows=Array.isArray(v)?v:[v];const fd=fs.openSync(file,'r'),buf=Buffer.alloc(65536),dec=new StringDecoder('utf8');let carry='',row=0,n;try{while((n=fs.readSync(fd,buf,0,buf.length,null))>0){carry+=dec.write(buf.subarray(0,n));let pos;while((pos=carry.indexOf('\n'))>=0){const line=carry.slice(0,pos);carry=carry.slice(pos+1);assert.equal(line,JSON.stringify(rows[row++]),'Full research row changed between phases: '+k)}}carry+=dec.end();assert.equal(carry,'');assert.equal(row,rows.length)}finally{fs.closeSync(fd)}
 console.log('Verified complete research equality',k,rows.length);global.gc?.();
}
r=null;global.gc?.();
for(const name of ['subaru-live-before.json','subaru-source-before.json','subaru-feature-before.json','subaru-models-before.json','subaru-variants-before.json'])assert.equal(fs.readFileSync(root+name,'utf8'),fs.readFileSync(root+'capture-attempt640-original/'+name,'utf8'),'Complete partial-attempt original equality: '+name);
fs.writeFileSync(root+'replay-snapshot-index.json',JSON.stringify(index,null,2));
fs.writeFileSync(root+'capture-phased-completeness.json',JSON.stringify({researchKeys:Object.keys(index.research),counts,subaruCars:cars.length,completeResearchPhaseEquality:true,previousCompleteBrandFilesByteEqual:true,scope:'Every research field, every catalogue row, complete original Subaru sources/models/variants/features preserved; no filtered baseline'},null,2));
console.log('Complete original capture passed',counts);
