/** Fresh pre-Subaru capture using the reviewed single-operation catalogue snapshot. */
import fs from 'node:fs';
import {StringDecoder} from 'node:string_decoder';
import assert from 'node:assert/strict';
import {catalogueSnapshot,effectiveFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/data.ts';
import {fileHash} from './verify-replay-inputs.ts';
const R='/tmp/subaru-research/';
assert(!fs.existsSync(R+'replay-snapshot-index.json'),'Never replace a completed original baseline');
assert(!fs.existsSync(R+'new-feature-before.json'),'Original baseline must precede canonical fixture');
const inputs=JSON.parse(fs.readFileSync(R+'fresh-capture-inputs.json','utf8'));
const verify=()=>{for(const row of inputs.sourceCode)assert.equal(fileHash('/workspace/scratch/586427eef9f2/roadmark-104/'+row.file),row.sha256,'Capture source/code drift: '+row.file)};
verify();
console.log('Fresh reviewed catalogueSnapshot(): complete research and all cars from one source read');
const {data,cars}=catalogueSnapshot();global.gc?.();
assert.equal(cars.length,397);assert.equal(new Set(cars.map(c=>c.id)).size,cars.length);
const original=R+'capture-phased640-original/replay-snapshot/';
const expectedFields=fs.readdirSync(original).filter(f=>/^research-.+\.jsonl$/.test(f)).map(f=>f.slice(9,-6)).sort();
assert.equal(expectedFields.length,14);assert.deepEqual(Object.keys(data).sort(),expectedFields);
const compareRows=(file:string,rows:any[])=>{const fd=fs.openSync(file,'r'),buffer=Buffer.alloc(65536),decoder=new StringDecoder('utf8');let carry='',row=0,n;try{while((n=fs.readSync(fd,buffer,0,buffer.length,null))>0){carry+=decoder.write(buffer.subarray(0,n));let pos;while((pos=carry.indexOf('\n'))>=0){const line=carry.slice(0,pos);carry=carry.slice(pos+1);assert(row<rows.length);assert.equal(line,JSON.stringify(rows[row++]),'Exact completed pre-fix current research: '+file)}}carry+=decoder.end();assert.equal(carry,'');assert.equal(row,rows.length);}finally{fs.closeSync(fd)}};
const index:any={research:{},cars:'replay-snapshot/cars.jsonl'};const counts:Record<string,number>={};
fs.mkdirSync(R+'replay-snapshot',{recursive:true});
const writeRows=(file:string,rows:any[])=>{const fd=fs.openSync(R+file,'w');try{for(const row of rows)fs.writeSync(fd,JSON.stringify(row)+'\n');}finally{fs.closeSync(fd)}counts[file]=rows.length};
for(const[key,value]of Object.entries(data)){
 const rows=Array.isArray(value)?value:[value];compareRows(original+'research-'+key+'.jsonl',rows);
 const file='replay-snapshot/research-'+key+'.jsonl';writeRows(file,rows);index.research[key]={file,array:Array.isArray(value)};console.log('Verified original and captured complete research field',key,rows.length);global.gc?.();
}
writeRows(index.cars,cars);
const selected=cars.filter(c=>c.brand==='Subaru'&&(!c.vehicleClass||['passenger','ute'].includes(c.vehicleClass)));
assert.equal(selected.length,9);
const files:Record<string,any>={
 'subaru-live-before.json':selected,'subaru-source-before.json':data.sources,
 'subaru-feature-before.json':selected.flatMap(c=>effectiveFeatures(c,data)),
 'subaru-models-before.json':data.models.filter(m=>m.brand==='Subaru'),
 'subaru-variants-before.json':data.variants.filter(v=>v.brand==='Subaru'),
};
for(const[name,value]of Object.entries(files)){const serialized=JSON.stringify(value,null,2);assert.equal(serialized,fs.readFileSync(R+'capture-attempt640-original/'+name,'utf8'),'All completed original Subaru bytes: '+name);fs.writeFileSync(R+name,serialized)}
verify();
fs.writeFileSync(R+'replay-snapshot-index.json',JSON.stringify(index,null,2));
fs.writeFileSync(R+'fresh-capture-completeness.json',JSON.stringify({status:'passed',mode:'Fresh single-operation catalogueSnapshot capture after independently reviewed loader fix',asOf:'2026-10-15',timeZone:'Australia/Sydney',researchKeys:Object.keys(data),counts,cars:cars.length,subaruCars:selected.length,all14OriginalCurrentResearchFieldsExactlyEqual:true,allFiveCompletedOriginalSubaruFilesByteEqual:true,sourceCodeHashesUnchangedThroughout:true,derivationOracleReviewStillRequired:true},null,2));
console.log('Fresh complete pre-Subaru baseline captured; independent full oracle equality remains separate.');
