import sys,json
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0,'/tmp/bmw-research/sedans')
from fetch_sources import get,root
q=[
['i4_carsales_2026','https://www.carsales.com.au/research/bmw/i4/2026/edrive35/'],
['i4_redbook_2026','https://www.redbook.com.au/cars/details/2026-bmw-i4-edrive35-g26-lci-auto/SPOT-ITM-683876'],
['i4_carsguide_towing','https://www.carsguide.com.au/bmw/i-series/i4/towing-capacity/2026'],
['i4_carexpert_review','https://www.carexpert.com.au/car-reviews/2026-bmw-i4-review'],
['i4_goauto_cull','https://www.goauto.com.au/amp/97617/bmw-i4-line-up-pared-back-to-single-variant.html'],
['i5_carsales_2026','https://www.carsales.com.au/research/bmw/i5/'],
['i5_carsales_edrive40','https://www.carsales.com.au/research/bmw/i5/2026/edrive40-m-sport/'],
['i5_carsales_m60','https://www.carsales.com.au/research/bmw/i5/2026/m60-xdrive/d411e139-ebd6-4101-a3d1-b24c7df003cf/'],
['i5_touring_carexpert','https://www.carexpert.com.au/car-reviews/2026-bmw-i5-touring-review'],
['i5_touring_carsales_order','https://www.carsales.com.au/cars/details/2026-bmw-i5-m60-xdrive-g61-auto-awd/SHRM-AD-6515621/'],
['i5_carsguide_2026','https://www.carsguide.com.au/bmw/i5/2026'],
['i5_carsguide_order','https://www.carsguide.com.au/buy-a-car/bmw/i5/m60-xdrive-variant/nsw/sydney-location'],
['i7_carexpert_launch','https://www.carexpert.com.au/car-news/2027-bmw-7-series-updated-luxury-limo-priced-for-australia-i7-ev-pricing-unchanged'],
['i7_carsguide_2026','https://www.carsguide.com.au/bmw/i7/price/2026'],
['i7_carsales_x60','https://www.carsales.com.au/research/bmw/i7/2026/xdrive60-m-sport/'],
['i4_carsales_m50_census','https://www.carsales.com.au/cars/bmw/i4/m50-badge/'],
['i4_carsales_edrive40_census','https://www.carsales.com.au/cars/bmw/i4/edrive40-badge/'],
['i7_carsales_census','https://www.carsales.com.au/cars/bmw/i7/'],
['bmw_models','https://www.bmw.com.au/en/models.html']
]
json.dump(q,open(root/'secondary_queue.json','w'),indent=2)
o=list(ThreadPoolExecutor(8).map(get,q)); json.dump(o,open(root/'secondary_retrievals.json','w'),indent=2); print(json.dumps(o,indent=2))
