import json,hashlib,copy
from pathlib import Path
R=Path('/tmp/bmw-research/sedans');D=json.load(open(R/'normalized-evidence.json'))
D['sources'].append({'key':'sedan_config_52hd_tech','url':'https://configure.bmw.com.au/en_AU/configure/G26/52HD','title':'BMW Australia exact 52HD i4 technical modal: five seats and 1600 kg towing','publisher':'BMW Australia','file':'review/config-tech-52HD.txt','source_type':'manufacturer_au_configurator','checkedAt':'2026-10-14'})
def add(v,k,value,s,grade='confirmed',**kw):
 if not any(x['key']==k for x in v['facts']):v['facts'].append(dict(key=k,value=value,sourceKeys=[s]if isinstance(s,str)else s,grade=grade,**kw))
i4=next(v for v in D['variants']if v['model']=='i4')
for f in i4['facts']:
 if f['key']=='seats':f.update(grade='confirmed',sourceKeys=['sedan_config_52hd_tech'],reason='Live exact 52HD maker configurator explicitly gives five seats, resolving conflicting page schema metadata.',evidenceScope='exact_au_version')
 if f['key']=='towing_kg':f.update(grade='check',sourceKeys=['sedan_config_52hd_tech'],basis='Braked trailer load at up to 12% gradient',comparison='Braked towing',condition='Confirm approved towbar and vehicle configuration; technical modal publishes the 12% braked rating.',reason='Live exact 52HD maker configurator explicitly gives 1600 kg braked, 75 kg towball and 750 kg unbraked.')
add(i4,'towball_download_kg',75,'sedan_config_52hd_tech');add(i4,'towing_unbraked_kg',750,'sedan_config_52hd_tech')
i4['sourceReviewNotes'].append('Five seats and 1600 kg braked towing now confirmed directly by exact 52HD configurator; web four-seat schema is superseded for these facts.')
for v in D['variants']+D['unresolvedVariants']:
 for f in v['facts']:
  if f.get('evidenceScope')=='explicit_au_body':f['evidenceScope']='explicit_au_range'
for v in D['variants']:
 facts={f['key']:f for f in v['facts']}
 if v['model']=='i4':
  for k,value in [('audio_power_w',205),('instrument_display_in',12.3),('centre_display_in',14.9),('front_electric_seats',True),('front_seat_lumbar',True),('driver_seat_memory',True),('parking_surround_view',True),('parking_front_rear_sensors',True),('reversing_assistant',True),('driving_assistant',True),('mode2_cable',True),('mode3_cable',True)]:add(v,k,value,'sedan_bmw_i4_spec')
 elif v['model']=='i5 Sedan':
  for k,value in [('audio_power_w',655),('front_electric_seats',True),('front_seat_lumbar',True),('driver_seat_memory',True),('active_cruise_stop_go',True),('steering_lane_control',True),('parking_surround_view',True),('parking_rear_camera',True)]:add(v,k,value,'sedan_bmw_i5_spec')
 elif v['model']=='i7':
  for k,value in [('audio_power_w',655),('rear_theatre_screen_in',31.3),('rear_outboard_heated_seats',True),('rear_outboard_ventilated_seats',True),('front_rear_massage',True)]:add(v,k,value,'sedan_bmw_i7_spec')
 # No remote-cabin function is inferred merely from cabin-preconditioning text.
 v['features']=[x for x in v['features']if x['criterion']!='remote_preconditioning']
 for x in v['features']:
  c=x['criterion']
  if c=='audio_system' and v['model']!='i5 Touring':x['keys']+=['audio_power_w']
  if c=='screens_hud' and v['model']=='i4':x['keys']+=['instrument_display_in','centre_display_in']
  if c=='carplay_android_auto':
   x['keys']=['apple_carplay','android_auto']if v['model']=='i4'else ['apple_carplay_wireless','android_auto_wireless']
  if c=='front_heated_seats' and v['model']in ('i4','i5 Sedan'):x['keys']+=['front_electric_seats','front_seat_lumbar','driver_seat_memory']
  if c=='front_heated_seats' and v['model']=='i7':x['keys']+=['front_ventilated_seats','rear_outboard_heated_seats','rear_outboard_ventilated_seats','front_rear_massage']
  if c=='parking_cameras' and v['model']=='i4':x['keys']+=['parking_surround_view','parking_front_rear_sensors','reversing_assistant']
  if c=='parking_cameras' and v['model']=='i5 Sedan':x['keys']+=['parking_surround_view','parking_rear_camera']
  if c=='adas_standard' and v['model']=='i4':x['keys']+=['driving_assistant']
  if c=='adas_standard' and v['model']=='i5 Sedan':x['keys']+=['active_cruise_stop_go','steering_lane_control']
  if c=='charging_cable' and v['model']=='i4':x['keys']=['ac_port','dc_port','mode2_cable','mode3_cable']
  if c=='automatic_seat_climate' and v['model']=='i5 Sedan':x['value']=('Four' if v['drive']=='AWD'else 'Two')+'-zone automatic climate control is standard.'
  # Every feature key must name a fact in the same version.
  x['keys']=list(dict.fromkeys(x['keys']))
  assert all(any(f['key']==k for f in v['facts'])for k in x['keys']),(v['id'],c,x['keys'])
# More precise date/equipment qualifiers go on the source review note, not all facts.
D['methodology']['range']='i4 and i5 sedan guide ADR81/02 remains the canonical cycle despite same-number web WLTP labels. No conversion. Touring published technical-page WLTP stays source-scoped.'
for s in D['sources']:
 p=R.parent/s['file'];assert p.exists(),p;s['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
json.dump(D,open(R/'normalized-evidence.json','w'),ensure_ascii=False,indent=2)
# Refresh core audit.
core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_kg','warranty','battery_warranty']
A=[]
for v in D['variants']+D['unresolvedVariants']:
 fs={f['key']:f for f in v['facts']};A.append({'id':v['id'],'status':v['recordState'],'core':{k:{'value':fs[k]['value'],'grade':fs[k]['grade']}for k in core},'missingCore':[k for k in core if fs[k]['value']is None]})
json.dump(A,open(R/'core-fact-audit.json','w'),ensure_ascii=False,indent=2)
print('Corrected primary 52HD seats/towing, evidence scopes and all feature dependencies')
