from urllib.request import Request,urlopen
from lxml import html
from pathlib import Path
import json
root=Path('/tmp/bmw-research/sedans')
u='https://www.bmw.com.au/en/models/bmw-i/i5/bmw-i5-technical-data.html'
r=urlopen(Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=40);s=r.read().decode();d=html.fromstring(s)
a=[]
for el in d.xpath('//*'):
 for k,v in el.attrib.items():
  if (k.startswith('data-') and ('32FK' in v or '42FK' in v or '62HG' in v or '42HG' in v)):
   a.append({'tag':el.tag,'attribute':k,'value':v})
root.joinpath('i5-technical-model-metadata.json').write_text(json.dumps({'url':u,'final_url':r.url,'checked_on':'2026-10-14','records':a},indent=2));print(json.dumps(a)[:15000])
