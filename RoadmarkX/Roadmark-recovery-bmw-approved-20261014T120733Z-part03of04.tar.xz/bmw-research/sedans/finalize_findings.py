from pathlib import Path
import json,hashlib
R=Path('/tmp/bmw-research/sedans');p=R/'normalized-evidence.json';D=json.load(open(p));allowed={r['criterion']for r in json.load(open('/tmp/bmw-research/bmw-feature-before.json'))}
# Complete direct M70 retrieval confirms its towing field is absent.
D['sources'].append({'key':'sedan_i7_carsales_m70_full','url':'https://www.carsales.com.au/research/bmw/i7/2026/m70-xdrive/37c631d5-32f6-4b2f-b5d9-d25b64a2c178/','title':'Carsales exact 2026 outgoing i7 M70 full specification; no towing field','publisher':'Carsales','file':'sedans/i7_carsales_m70.txt','source_type':'independent_au','checkedAt':'2026-10-14'})
D['sources'].append({'key':'sedan_config_82eh_unavailable','url':'https://configure.bmw.com.au/en_AU/configure/G70/82EH','title':'BMW Australia outgoing i7 M70 unavailable; redirects to 740 52HZ','publisher':'BMW Australia','file':'review/config-unavailable-82EH.txt','source_type':'manufacturer_au_configurator','checkedAt':'2026-10-14'})
for v in D['unresolvedVariants']:
 if v['modelCode']=='82EH':
  v['availabilityReason']='Live BMW AU configurator reports 82EH unavailable and redirects to petrol 740 52HZ. No fresh genuine residual NEW M70 ad recovered. Old product page is not current order evidence.'
  v['sourceReviewNotes'].append('Any A$310,353 price displayed after redirect belongs to BMW 740, not i7 M70, and is rejected.')
  for f in v['facts']:
   if f['key']=='towing_kg':f['sourceKeys']=['sedan_bmw-i7-sedan-technical-data','sedan_i7_carsales_m70_full']
# Reference selected option evidence by human-readable label, rather than relying on option codes.
D['sources'].append({'key':'sedan_config_32hh_options','url':'https://configure.bmw.com.au/en_AU/configure/G61/32HH','title':'BMW Australia i5 Touring selected current Australian options','publisher':'BMW Australia','file':'review/config-options-32HH.txt','source_type':'manufacturer_au_configurator','checkedAt':'2026-10-14'})
t=next(v for v in D['variants'] if v['model']=='i5 Touring')
for f in t['facts']:
 if f['key'] in ['audio_bowers_wilkins','driving_assistant_professional','parking_assistant_professional','front_ventilated_seats','glass_roof','wireless_charging']:f['sourceKeys']=['sedan_config_32hh_options']
# Stay within existing feature criteria, retaining novel equipment as facts.
for v in D['variants']:
 for x in v['features']:
  if x['criterion']=='preconditioning':
   if 'battery_preconditioning_navigation' in x['keys']:x['criterion']='battery_preconditioning_navigation'
   elif 'cabin_preconditioning' in x['keys']:x['criterion']='remote_preconditioning'
 v['features']=[x for x in v['features'] if x['criterion'] in allowed]
 existing={x['criterion']for x in v['features']};facts={f['key']:f for f in v['facts']}
 def feature(c,text,keys,**kw):
  if c not in existing:v['features'].append({'criterion':c,'value':text,'keys':keys,**kw});existing.add(c)
 feature('performance_rear_motor',str(facts['power_kw']['value'])+' kW '+v['drive']+' electric drivetrain.',['power_kw','drive'])
 feature('home_charging',str(facts['ac_kw']['value'])+' kW maximum onboard AC acceptance.',['ac_kw'])
 feature('storage',str(facts['boot_l']['value'])+' L published luggage capacity; maker does not identify VDA/SAE measurement.',['boot_l'])
 feature('warranty_service','Five-year unlimited-kilometre private-use vehicle warranty; BEV battery eight years/160,000 km, whichever first.',['warranty','battery_warranty'])
 feature('roadside_assistance','Eight-year unlimited-kilometre BEV roadside assistance; separate from vehicle warranty.',['roadside_assistance'])
# Maker i4 quote supplied by central price researcher.
D['sources'].append({'key':'sedan_config_52hd_price','url':'https://configure.bmw.com.au/en_AU/configure/G26/52HD','title':'BMW Australia i4 eDrive35 live Victoria MRDP, selected options $0','publisher':'BMW Australia','file':'sedans/config-price-52HD.txt','source_type':'manufacturer_au_configurator','checkedAt':'2026-10-14'})
i4=next(v for v in D['variants']if v['model']=='i4');old=next(f for f in i4['facts']if f['key']=='price_aud');i4['facts'].append(dict(old,key='price_reported_list_aud'));old.update(value=96896,sourceKeys=['sedan_config_52hd_price'],grade='check',priceRung=4,basis='Maker Victoria recommended driveaway price; selected options $0',basisTag='Maker VIC driveaway',comparison='Driveaway',rankingEligible=True,condition='Representative Victoria selected configuration, Alpine White, no priced options. Final price depends on delivery and registration details.',reason='Live price overview explicitly shows Victoria and MRDP A$96,896. The A$80,818 base line excludes GST/LCT and is not a tax-inclusive list price.')
json.dump(D,open(p,'w'),ensure_ascii=False,indent=2)
# Machine-auditable source/fact inventory.
core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_kg','warranty','battery_warranty']
a=[];keys={s['key']for s in D['sources']}
for v in D['variants']+D['unresolvedVariants']:
 fs={f['key']:f for f in v['facts']};assert len(fs)==len(v['facts']),v['id']
 for f in v['facts']:
  assert all(k in keys for k in f['sourceKeys']),(v['id'],f['key'])
 a.append({'id':v['id'],'status':v['recordState'],'core':{k:{'value':fs[k]['value'],'grade':fs[k]['grade']}for k in core},'missingCore':[k for k in core if fs[k]['value']is None]})
json.dump(a,open(R/'core-fact-audit.json','w'),ensure_ascii=False,indent=2)
print('Source reference validation passed. Current/arriving core gaps:',[(v['id'],v['missingCore'])for v in a[:len(D['variants'])]])
