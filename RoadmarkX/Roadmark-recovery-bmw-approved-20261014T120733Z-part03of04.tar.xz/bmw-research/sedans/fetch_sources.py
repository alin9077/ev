from urllib.request import Request,urlopen
from html.parser import HTMLParser
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json,re
root=Path('/tmp/bmw-research/sedans')
class Text(HTMLParser):
 def __init__(self): super().__init__();self.out=[]; self.skip=0
 def handle_starttag(self,tag,attrs):
  if tag in ('script','style'):self.skip+=1
 def handle_endtag(self,tag):
  if tag in ('script','style'):self.skip=max(0,self.skip-1)
 def handle_data(self,d):
  if not self.skip and d.strip():self.out.append(d.strip())
def get(t):
 name,url=t
 try:
  raw=urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=40).read()
  if name.endswith('.pdf'):root.joinpath(name).write_bytes(raw)
  else:
   h=Text();h.feed(raw.decode('utf-8','replace'));root.joinpath(name+'.txt').write_text('\n'.join(h.out));
   # Keep safe public model JSON schemas and technical data only; never durable raw scripts/cookies.
   blocks=re.findall(r'<script[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',raw.decode('utf-8','replace'),re.S)
   if blocks: root.joinpath(name+'.schema.json').write_text('\n'.join(blocks))
  return {'id':name,'url':url,'status':'retrieved','bytes':len(raw),'checked_on':'2026-10-14'}
 except Exception as e:return {'id':name,'url':url,'status':'failed','error':str(e),'checked_on':'2026-10-14'}
if __name__=='__main__':
 sources=json.load(open(root/'fetch_queue.json'))
 out=list(ThreadPoolExecutor(8).map(get,sources));json.dump(out,open(root/'source_retrievals.json','w'),indent=2);print(json.dumps(out,indent=2))
