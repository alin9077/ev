# BMW i4, i5 and i7 Australian evidence, checked 14 October 2026

## Result

Four currently configurable/listed versions: i4 eDrive35 M Sport Package 52HD; i5 Sedan eDrive40 62HG; i5 Sedan M60 xDrive 42HG; and i5 M60 xDrive Touring 32HH. The refreshed i7 60 xDrive M Sport 72HY is separately **arriving, expected Q4 2026**. All five have a populated 17-fact core in `normalized-evidence.json`; source-specific limitations are retained. Central price/terms research may supersede the two sedan secondary-price fallbacks.

| Exact version | Best captured price | Range and selected basis | Battery | DC / 10–80% | AC | Seats | Boot | 0–100 / power / drive | Dimensions, mm | Braked tow |
|---|---|---|---|---|---|---|---|---|---|---|
| i4 eDrive35 52HD | A$96,896 maker Victoria driveaway, options $0 | 448 km ADR81/02 | 66.4 kWh net | 180 kW / 32 min | 11 kW | 5 | 470 L; 1,290 expanded | 6.0 s / 210 kW / RWD | 4783 × 1852 × 1448 | 1600 kg, equipment condition |
| i5 Sedan eDrive40 62HG | A$155,900 reported list | 550 km ADR81/02 | 81.2 net / 84 gross kWh | 205 kW / 30 min | 22 kW | 5 | 490 L | 6.0 s / 250 kW / RWD | 5060 × 1900 × 1515 | 1500 kg, equipment condition |
| i5 Sedan M60 xDrive 42HG | A$215,900 reported list | 506 km ADR81/02 | 81.2 net / 84 gross kWh | 205 kW / 30 min | 22 kW | 5 | 490 L | 3.8 s / 442 kW / AWD | 5060 × 1900 × 1505 | 2000 kg, equipment condition |
| i5 M60 xDrive Touring 32HH | A$236,211 maker VIC 3000 driveaway, options $0 | 503 km, maker technical page labels WLTP | 81.2 kWh, gross/net ambiguous in configurator | 205 kW / 30 min | 22 kW | 5 | 570 L; 1700 expanded | 3.9 s / 442 kW / AWD | 5060 × 1900 × 1505 | 2000 kg, equipment condition |
| i7 60 xDrive 72HY, arriving | A$306,900 reported list | 581–727 km WLTP, configuration-dependent | 111.5 kWh net, exact FAQ | 250 kW / 28 min | 22 kW | 5 | 500 L | 4.8 s / 400 kW / AWD | 5395 × 1950 × 1558 | 2000 kg, equipment condition |

Body widths exclude mirrors. Boot figures are maker-declared litres; VDA/SAE and loading-line method are not established, so use a separate unknown-method comparison group. All share current BMW Australian private-use vehicle warranty 5 years/unlimited km and BEV battery warranty 8 years/160,000 km, whichever first. Commercial-use exceptions and warranty commencement remain in source terms. No battery-capacity percentage has been invented.

## Census decisions

- **i4:** current October 2025 AU guide contains only 52HD eDrive35. GoAuto’s 10 October 2025 report and current CarExpert review independently explain the Australian eDrive40/M50 withdrawal. National M50 listings examined were used/demo. No genuine residual NEW eDrive40/M50 unit was established. The overseas M60/xDrive40 must not be imported into the Australian range.
- **i5 Touring:** the normal product URL returns the homepage and brochure returns 404, but the independent reviewer successfully configured current Australian G61/32HH, obtained a maker MRDP and the technical/selected-options modals. Therefore admit the Touring as current maker order-listed. No accepted order or physical stock is asserted. Carsales SHRM-AD-6515621 explicitly says it is a generic publisher-created listing, not dealer inventory; it was only a lead.
- **i5 eDrive40/xDrive40 Touring:** no Australian maker/importer offering or genuine NEW ad established. Global material and an ev-wiki AU-labelled entry do not establish sale here.
- **New i7:** Australia-specific launch reporting names 60 xDrive only. BMW’s current page still says coming/expected Q4 2026. This is an arriving record, even though the current calendar is Q4.
- **Outgoing i7 M70 82EH:** current configurator says unavailable and redirects to petrol BMW 740 52HZ. Reject the redirected A$310,353 price. Retained M70 product/technical pages are not current order evidence. National i7 census returned used outgoing units and one generic new-to-order refreshed 60 xDrive. Residual genuine NEW supply remains unresolved.
- **Outgoing i7 xDrive60 52EJ:** keep separate from 72HY. Current technical selector and historical/secondary price records remain, but no fresh genuine NEW advertisement establishes residual supply. Do not merge old 101.7 kWh/195 kW/34-minute facts into the new 111.5 kWh/250 kW/28-minute version.
- **i7 eDrive50, 50 xDrive and refreshed M70:** no current Australian offering established; overseas specifications are not admitted.

## Corrections that matter

1. **Range cycle:** i4 448 and i5 550/506 are explicitly ADR81/02 in the local guides; the web tables label the identical numbers WLTP. i4 secondary 2026 sources also call 448 NEDC. Canonical guide-cycle values are retained, with separate web-label alternatives. No lab-cycle conversion or quiet WLTP ranking.
2. **i4 seats/towing:** fresh exact 52HD maker configurator resolves five seats and 1600 kg braked towing, plus 75 kg towball and 750 kg unbraked. Seats are Confirmed; towing is Check for approved vehicle/towbar configuration. This supersedes the public page’s four-seat schema and absent towing row. Secondary values are retained as corroboration.
3. **i4 charging:** exact technical table gives 0:32 for 10–80%; FAQ rounds to approximately 30 minutes. Use the table’s 32 minutes. The exact 52HD configurator explicitly gives 7:00 h for AC 0–100% at 11 kW, resolving the apparent 30-hour public-page typo without guesswork.
4. **i5 source codes:** current guide overview uses 62HG/42HG but inner equipment pages and live web metadata retain 32FK/42FK. Current named-grade equipment inheritance and stable G60 body data are usable; record the code discrepancy once instead of marking every fact conditional. Both local named-grade pages support 22 kW AC; the web’s 11/22 or 11 kW entries do not override the local equipment guide.
5. **i7 source conflict:** exact new-variant FAQ/table support 111.5 kWh net and 250 kW DC. Inner guide retains stale 52EJ code and says 118 gross/112 net and 235 kW; broad FAQ says up to 112.5. Preserve all source claims, use the live exact-variant figures, and ask dealer to resolve the discrepancy before purchase.

## Equipment reconciliation

- i4 standard: 18-inch wheels, electric glass sunroof, heated electric front sport seats, three-zone climate, head-up display, Active Cruise Control with Stop&Go, Driving Assistant, Parking Assistant Plus, 10-speaker/205 W HiFi, wireless charging, automatic tailgate, Apple CarPlay/Android Auto. Do not call standard wheels 19 inches, standard audio Harman Kardon, or standard assistance Driving Assistant Professional.
- i5 current guide: 20-inch wheels, panoramic roof, heated front seats, Driving Assistant Professional, Parking Assistant Professional, wireless smartphone integration, 17-speaker/655 W Bowers & Wilkins. The i5-specific 17-speaker entry replaces inherited 540d’s 18-speaker entry. M60 adds standard front ventilation, four-zone climate and active anti-roll stabilisation. eDrive40 front ventilation/four-zone climate require Comfort Package.
- Touring: actual selected AU configurator options confirm Bowers & Wilkins, Driving Assistant Professional, Parking Assistant Professional, front ventilation and panoramic roof. Generic base-equipment text says Harman Kardon/basic assistants; actual selected AU equipment controls. Heat pump is explicitly in the standard-equipment modal. Torque 795 Nm is exact 32HH configurator data, whereas later reviews/62HH used VINs report 820 Nm; do not silently combine them.
- New i7: AU guide lists 21-inch wheels, Sky Lounge roof, heated/ventilated/massaging seats, automatic doors, four-zone climate, 17-speaker/655 W Bowers & Wilkins and the 31.3-inch Theatre Screen. Website calls several of these optional; Theatre Screen specifically remains a Check item. Diamond audio is separate optional equipment.

## Feature-criterion audit

Removed cabin-zone claims from `automatic_seat_climate`: no evidence here establishes temperature/occupancy-based automatic seat heating or ventilation. Removed all total-output/drive-layout claims from `performance_rear_motor`: no rear-specific performance motor hardware or upgrade is established. All underlying cabin climate, system power and drive facts are unchanged. There were no `navigation_route_planner` mappings to remove; ordinary navigation and navigation-triggered battery preconditioning are not treated as evidence of automatic charging itineraries, arrival SOC or live charger planning. See `feature-criterion-audit.json`.

## Evidence and deliverables

- `normalized-evidence.json`: sources, five current/arriving variants, two unresolved outgoing i7 variants, facts, equipment, summaries, census and legacy reconciliation
- `core-fact-audit.json`: all 17 core facts and grades for every scoped version
- Every previously populated i4/i5 fact has a refreshed counterpart; no known value remains null merely due build/MY uncertainty
- `source_retrievals.json`, `secondary_retrievals.json`: retrieval outcomes including 404/403/redirect failures
- PDF/text captures and public vehicle metadata; no authenticated data, cookies, session/challenge/CSRF/client-secret values
- `pdf-renders/`: local PDF page renders, **not browser screenshots**; i4 p2, i5 p2/p4 and i7 p4 visually inspected
- Shared reviewer sources under `../review/` are cited directly and included in the manifest’s shared-source section

Factory acceptance, physical availability and warranty commencement have not been verified. Standard manufacturer lab caveats and formal-MY uncertainty are standing notes, not per-fact conditions.
