# Volkswagen M1 research — 14 October 2026

Staged research for Australian Tier 1 Volkswagen battery-electric cars and passenger ID. Buzz. ID. Buzz Cargo and e-Transporter remain Tier 2 and are not researched for inclusion. All packets are dated overlays; no historical packet/source rewrite or registry edit is permitted.

Sources are captured by family under id45, idbuzz and terms. Saved copies must remove runtime cookies, session/challenge/CSRF/client-secret capabilities while retaining facts, official product identifiers and source URLs. Each capture has a recorded hash and any redactions are documented.

The current complete version census, price ladder, all 17 core fields, genuine residual-new identities, equipment/canonical agreement, and supported strengths/trade-offs will be staged and independently reviewed before integration. Current-list closure is distinct from global two-independent-market-list C1 closure.
