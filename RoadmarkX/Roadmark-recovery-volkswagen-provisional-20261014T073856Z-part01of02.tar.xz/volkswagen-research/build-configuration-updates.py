import json,copy,pathlib
R=pathlib.Path('/tmp/volkswagen-research')
p=json.loads((R/'volkswagen-2026-10-14.json').read_text())
before={x['id']:x for x in json.loads((R/'volkswagen-live-before.json').read_text())}
e=json.loads((R/'volkswagen-effective-facts.json').read_text())
keys=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg']
release={'price_aud':['price_aud'],'battery_kwh':['battery_kwh'],'power_kw':['power_kw'],'zero_to_100_s':['zero_to_100_s'],'battery_usable_kwh':['battery_kwh'],'range_wltp_km':['range_km'],'range_cycle':['range_km'],'ac_charge_max_kw':['ac_kw'],'dc_charge_peak_kw':['dc_peak_kw'],'dc_10_80_min':['dc_charge_time_min'],'braked_tow_kg':['towing_braked_kg'],'towing_conditions':['towing_braked_kg'],'dimensions_mm':['length_mm','width_mm','height_mm'],'rear_cargo_l':['boot_l']}
rows=[]
for id,c in before.items():
 if not id.startswith('volkswagen_idbuzz_my26_'):continue
 b=copy.deepcopy(c['configurationEvidence']);a=copy.deepcopy(b);fs=e[id]
 deps=[dict(key=k,expected=fs[k]) for k in keys]
 ids=list(dict.fromkeys(s for d in deps for s in d['expected']['sourceIds']))
 a.update(rankingEligible=True,completeVehicleCountEligible=False,sourceIds=ids)
 a['countContribution']['rankableRecords']=1
 a['projectionScope']='Australia MY26 ID. Buzz '+c['trim']+' named-grade technical facts reviewed on 14 October 2026. '+b['projectionScope']+' Each price, technical fact and equipment answer keeps its own source/build scope; ranking eligibility is assessed per fact.'
 a['historicalProjectionScope']=b['projectionScope']
 a['historicalRequiredNulls']=copy.deepcopy(b['requiredNulls'])
 a['requiredNulls']={k:{**v,'reason':'This historical source-field quantity was not established in the 14 October review. The null applies only to this field, not to separately reviewed canonical facts.','historicalReason':v['reason']} for k,v in b['requiredNulls'].items() if k not in release}
 a['releasedHistoricalNulls']={k:dict(canonicalFactKeys=v,reason='The dated packet now reviews this quantity from current named-grade maker evidence and/or the exact retained price configuration. The original source-field observation remains unchanged in the immutable research ledger.') for k,v in release.items() if k in b['requiredNulls']}
 a['historicalPricingBoundary']=copy.deepcopy(b['pricingBoundary'])
 a['pricingBoundary']={**copy.deepcopy(b['pricingBoundary']),'canonicalCurrentPriceAud':fs['price_aud']['value'],'useForPriceRankings':True,'reviewedAt':'2026-10-14','canonicalPriceFactKey':'price_aud','scope':'Only the reviewed canonical price fact and its exact campaign/build/location/date qualifications may be ranked. Other historical amounts and options are not merged into it.'}
 a['historicalChargingBoundary']=copy.deepcopy(b['chargingBoundary'])
 a['chargingBoundary']={**copy.deepcopy(b['chargingBoundary']),'vehicleAcMaxKw':fs['ac_kw']['value'],'vehicleDcPeakKw':fs['dc_peak_kw']['value'],'chargeTimes':{'dc10To80Minutes':fs['dc_charge_time_min']['value'],'factKey':'dc_charge_time_min'},'homeChargingCriterion':'See independently guarded home_charging equipment answer; no cable-to-inlet inference.','reviewedAt':'2026-10-14','scope':'Current linked Australian brochure expressly states vehicle acceptance and exact 10–80% time for the named body/grade. No charger station output or connector subtype is inferred.'}
 a['projectionContract']={**copy.deepcopy(b['projectionContract']),'historicalContractOnly':True,'currentDatedOverlayId':p['id'],'currentPrecedence':'Original source projections and scoped amendments remain historical provenance. This full before-state-guarded dated configuration review supersedes only the explicitly released nulls and blanket ranking hold; canonical facts and equipment dependencies govern current claims.'}
 a['configurationReview']={'reviewedAt':'2026-10-14','overlayId':p['id'],'evidenceScope':'exact_au_version','reason':'Current Volkswagen Australia MY26 offers and exact retained MY26 configurator identities match the Pro SWB, Pro LWB and GTX LWB grades in the brochure directly linked by the current maker page. The MY25 filename alone is not a source conflict. Actual screen/cargo inconsistencies remain fact-level qualifications; MY27 changes are not inherited.','incompleteRecordReason':'Unreviewed historical source fields remain null. Cargo measurement methodology, full equipment/build compatibility and physical stock have not all been established. This does not declare a complete technical record.'}
 rows.append(dict(variantId=id,before=b,after=a,reason='Remove the historical all-facts ranking hold now that this exact MY26 named grade has independently reviewed canonical facts. Preserve incomplete-record status, original source/build boundaries and every per-fact grade/comparability restriction.',sourceIds=ids,dependencies=deps))
assert len(rows)==3
(R/'configuration-updates.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n')
print(json.dumps([{'variantId':r['variantId'],'sourceIds':len(r['sourceIds']),'dependencies':len(r['dependencies']),'releasedNulls':list(r['after']['releasedHistoricalNulls']),'retainedNulls':len(r['after']['requiredNulls'])} for r in rows],indent=2))
