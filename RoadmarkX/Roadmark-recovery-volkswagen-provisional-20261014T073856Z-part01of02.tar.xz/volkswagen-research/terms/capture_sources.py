import urllib.request, urllib.parse, json, hashlib, concurrent.futures, re, datetime
from pathlib import Path
from lxml import html
BASE=Path('/tmp/volkswagen-research/terms'); BASE.mkdir(parents=True,exist_ok=True)
SOURCES=[
('vw_id3_news','https://www.volkswagen.com.au/en/hybrid-and-electric/latest-ev-news-/new-id-3.html','Volkswagen Australia ID.3 overseas news, 8 March 2023'),
('vw_id7_news','https://www.volkswagen.com.au/en/hybrid-and-electric/latest-ev-news-/new-id-7-sedan.html','Volkswagen Australia ID.7 overseas concept news, 22 March 2023'),
('carexpert_id3','https://www.carexpert.com.au/volkswagen/id-3','CarExpert ID.3 model entry'),
('vw_warranty','https://www.volkswagen.com.au/en/owners-service/about-your-car/warranty.html','Volkswagen Australia warranty overview'),
('vw_warranty_terms','https://www.volkswagen.com.au/en/owners-service/about-your-car/warranty.html/__layer/layers/owners_services/warranty/5-yr-warranty-t-cs/master.layer','Volkswagen Australia 5 Year New Vehicle Warranty Terms and Conditions'),
('vw_roadside','https://www.volkswagen.com.au/en/owners-service/service-repairs-parts/roadside-assist.html','Volkswagen Australia Roadside Assistance'),
('vw_roadside_terms','https://www.volkswagen.com.au/en/owners-service/service-repairs-parts/roadside-assist.html/__layer/layers/owners_services/roadside_assist/vw-roadside-t-cs---purchased-on-or-after-1st-jan-2026/master.layer','Volkswagen Australia Roadside Assistance terms for policies starting on or after 1 March 2026'),
('vw_ev_range','https://www.volkswagen.com.au/en/range/ev.html','Volkswagen Australia EV range'),
('vw_models','https://www.volkswagen.com.au/en/models.html','Volkswagen Australia Models and Configurator'),
('carexpert_models','https://www.carexpert.com.au/volkswagen','CarExpert Volkswagen brand model directory'),
('carsguide_models','https://www.carsguide.com.au/volkswagen','CarsGuide Volkswagen brand model directory'),
('vw_on_ev','https://www.volkswagen.com.au/en/hybrid-and-electric/on-ev.html','Volkswagen Australia On EV ownership'),
('vw_transporter','https://www.volkswagen.com.au/en/models/transporter-van.html','Volkswagen Australia Transporter range'),
('vw_amarok','https://www.volkswagen.com.au/en/models/amarok.html','Volkswagen Australia Amarok range'),
('vw_buzz','https://www.volkswagen.com.au/en/models/id-buzz.html','Volkswagen Australia ID. Buzz passenger range'),
('vw_buzz_cargo','https://www.volkswagen.com.au/en/models/id-buzz-cargo.html','Volkswagen Australia ID. Buzz Cargo range'),
]
def run(s):
 id,url,title=s
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
  with urllib.request.urlopen(req,timeout=90) as r: raw=r.read();final=r.url;status=r.status
  tree=html.fromstring(raw)
  scripts=len(tree.xpath('//script'));styles=len(tree.xpath('//style')); hidden=len(tree.xpath('//input'))
  for e in tree.xpath('//script|//style|//noscript|//template|//iframe|//input'): e.drop_tree()
  # Factual visible text only. All runtime attributes, script data, form fields and headers are discarded.
  text='\n'.join(' '.join(x.split()) for x in tree.itertext() if x.strip())
  links=[]
  for a in tree.xpath('//a[@href]'):
   href=urllib.parse.urljoin(final,a.attrib['href']);p=urllib.parse.urlsplit(href)
   if p.scheme not in ('http','https'):continue
   pairs=urllib.parse.parse_qsl(p.query,keep_blank_values=True)
   pairs=[(k,v) for k,v in pairs if not re.search(r'cookie|session|token|csrf|challenge|secret|auth|client.?id|utm_|gclid|fbclid',k,re.I)]
   href=urllib.parse.urlunsplit((p.scheme,p.netloc,p.path,urllib.parse.urlencode(pairs),p.fragment))
   name=' '.join(a.text_content().split())
   if name and {'text':name,'url':href} not in links:links.append({'text':name,'url':href})
  content={'id':id,'url':url,'resolvedUrl':final,'title':title,'checkedAt':'2026-10-14','captureType':'sanitized_visible_text_and_public_links','text':text,'links':links}
  out=BASE/(id+'.json');out.write_text(json.dumps(content,indent=2,ensure_ascii=False)+'\n')
  (BASE/(id+'.txt')).write_text(text+'\n')
  return {'id':id,'title':title,'url':url,'resolvedUrl':final,'status':status,'checkedAt':'2026-10-14','captureDate':'2026-10-14','captureFile':out.name,'textFile':id+'.txt','captureSha256':hashlib.sha256(out.read_bytes()).hexdigest(),'rawResponseSha256':hashlib.sha256(raw).hexdigest(),'rawBytes':len(raw),'sanitization':{'scriptElementsRemoved':scripts,'styleElementsRemoved':styles,'inputElementsRemoved':hidden,'allHtmlAttributesDiscardedExceptSanitizedPublicLinks':True,'responseHeadersAndCookiesNotPersisted':True,'runtimeSessionChallengeCsrfClientSecretDataNotPersisted':True}}
 except Exception as e:return {'id':id,'url':url,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex: out=list(ex.map(run,SOURCES))
(BASE/'source-index.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps([{k:v for k,v in x.items() if k in ['id','error','status','rawBytes']} for x in out],indent=2))
