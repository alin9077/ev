# Volkswagen Australia: terms and family scope
Checked 14 October 2026. Prepared for Roadmark M1; no repository files changed.

## Ready to inherit
- Vehicle warranty: 5 years/unlimited kilometres, Confirmed for ordinary private use. The same baseline covers passenger and commercial vehicles. Taxi, ride-share and hire-car use is 5 years/150,000 km, whichever first; this is not a blanket cap on every commercial vehicle. New-car cover starts at original retail delivery, demonstrators at first dealer registration.
- BEV battery: 8 years/160,000 km, whichever first; capacity cover below 70% of initial usable/net energy. Confirmed. Repair-restoration schedule: 78% at 3 years/60,000 km; 74% at 5 years/100,000 km; 70% at 8 years/160,000 km. Do not relabel the higher restoration figures as separate claim triggers. No distinct passenger-versus-Cargo ID. Buzz base vehicle or battery period is published.
- Roadside: 24 months included from warranty start for ID.4, ID.5 and ID. Buzz, Confirmed/standard. Qualifying authorised-dealer scheduled service provides or tops up SIRA to up to 24 months; this does not stack another two years onto a valid policy. Essential Service/Essential Service Plus do not qualify. No fixed lifetime inclusion is claimed.

Primary sources:
- [Current Australian warranty terms](https://www.volkswagen.com.au/en/owners-service/about-your-car/warranty.html/__layer/layers/owners_services/warranty/5-yr-warranty-t-cs/master.layer)
- [Current linked roadside policy](https://www.volkswagen.com.au/en/owners-service/service-repairs-parts/roadside-assist.html/__layer/layers/owners_services/roadside_assist/vw-roadside-t-cs---purchased-on-or-after-1st-jan-2026/master.layer)

## Family reconciliation
The [maker model directory](https://www.volkswagen.com.au/en/models.html), [maker EV range](https://www.volkswagen.com.au/en/range/ev.html), [CarExpert Volkswagen directory](https://www.carexpert.com.au/volkswagen), and [CarsGuide Volkswagen directory](https://www.carsguide.com.au/volkswagen) reconcile to three current Tier 1 BEV families: ID.4, ID.5 and passenger ID. Buzz. These independently published Volkswagen brand directories are not whole-market EV lists. Exact model-year and trim closure is the companion workers' task, not proved by these family lists. The complete mixed-powertrain accounting covers CarsGuide's 17 current and 30 older entries plus CarExpert's 15 current and four discontinued entries. All 66 have explicit dispositions, reasons and source keys in brand-model-list-reconciliation.json and the normalized artifacts.

Differences resolved:
- Maker Pro/GTX cards collapse into ID.4 or ID.5 families
- Passenger ID. Buzz stays Tier 1; Cargo is Tier 2. CarsGuide combines people-mover/commercial roles under ID. Buzz
- CarsGuide's fourth Electric label is commercial Transporter. The electric van remains Tier 2; generic future crewvan/dual-cab seating text does not establish a BEV people-mover or ute
- Caddy/Caddy 5/body-style naming, California and Caravelle currency disagreements, maker grade splits and PHEV entries do not create another Tier 1 BEV
- Full maker card/filter counts mix grades, body styles and navigation cards. They are not family counts

ID.3 is expressly no longer current in CarExpert and appears among CarsGuide's older models. ID.7/Tourer, e-Golf and e-up! have no current official Australian new-range entry in the maker or either current directory. Current Amarok material expressly offers petrol/diesel; no BEV version is identified. Overseas news, accessories, private imports and prospective ID. Polo/ID.2/ID. EVERY1/ID. Tiguan names do not establish current official Australian ordering.

## Source quirks retained
- Generic roadside FAQ copy says one year. EV-specific current policy and main-page text explicitly say 24 months; use the specific policy
- Linked roadside policy applicability heading says purchases/SIRA starts on or after 1 March 2026. Its slug and footer retain January 2026 wording. Preserve both; older demonstrators may have an earlier policy
- eTransporter is an explicit 12-month roadside exception, retained as a scope guard only
- Absence-based lead exclusions are current-range conclusions, not claims that a model never existed or can never arrive

## Files and verification
facts.json and terms-normalized.json contain the requested sources/terms/reconciliation shape. source-index.json records URLs, capture and raw-response SHA-256 hashes, and redaction counts. factual-excerpts.json gives text-line pointers. Each source has readable TXT and sanitized public-text/link JSON captures. Raw HTML, HTTP headers, cookies, script state, hidden inputs and security/session data were not persisted. SHA256SUMS.txt covers the final deliverables.
