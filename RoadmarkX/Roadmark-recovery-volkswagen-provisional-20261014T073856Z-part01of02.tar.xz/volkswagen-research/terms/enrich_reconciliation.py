from pathlib import Path
import json,hashlib
b=Path('/tmp/volkswagen-research/terms')
facts=json.load(open(b/'facts.json')); rec=facts['reconciliation']
cg=json.load(open(b/'carsguide_models.json')); ce=json.load(open(b/'carexpert_models.json'))
sources={x['key']:x for x in facts['sources']}
older=cg['text'].split('All older Volkswagen models (30)\n',1)[1].split('\nVolkswagens for sale',1)[0].splitlines()
assert len(older)==30
cgcurrent=['Amarok','Caddy 5','California','Caravelle','Crafter','Golf','ID. Buzz','Id.4','Id.5','Multivan','Polo','T-Cross','T-ROC','Tayron','Tiguan','Touareg','Transporter']
cecurrent=['Amarok','Caddy','Crafter','Golf','ID.4','ID.5','ID.Buzz','Multivan','Polo','T-Cross','T-Roc','Tayron','Tiguan','Touareg','Transporter']
ceold=['Arteon','Caravelle','ID.3','Passat']
cgdetails=[a['url'] for a in cg['links'] if a['text']=='Explore details']
assert len(cgdetails)==17
bevs={'ID. Buzz':'volkswagen-id-buzz','ID.Buzz':'volkswagen-id-buzz','ID.4':'volkswagen-id-4','Id.4':'volkswagen-id-4','ID.5':'volkswagen-id-5','Id.5':'volkswagen-id-5'}
def current(name,key,url):
 d='excluded_non_bev_current_nameplate';family=[]
 reason='No BEV version for this nameplate appears in the current Australian maker model/EV range. Its mixed-powertrain directory listing does not establish battery-electric availability.'
 support=[key,'vw_models','vw_ev_range']
 if name in bevs:
  d='included_current_bev_family';family=[bevs[name]]
  reason='Current maker Australian BEV family and both brand directories agree. Include only its Australian BEV passenger variants; exact trim/model-year closure is documented separately.'
  if 'Buzz' in name:reason+=' Cargo variants grouped by the publisher are excluded from Tier 1 and retained in Tier 2.'
 elif name=='Transporter':
  d='outside_Tier1_commercial_van';family=['volkswagen-e-transporter'];support+=['vw_transporter']
  reason='Electric e-Transporter is inside this commercial van family and is Tier 2. Diesel variants are non-BEV. Blended future crewvan/dual-cab statements do not establish a BEV people-mover or ute.'
 elif name=='Crafter':
  d='outside_Tier1_non_bev_commercial_family'
  reason='Directory combines van and cab-chassis bodies; current maker range supplies no BEV version. No additional Tier 1 BEV is established and commercial research remains deferred.'
 elif name=='Caravelle':
  d='excluded_non_bev_directory_currency_difference';support+=['carexpert_models']
  reason='CarsGuide marks this people mover current while CarExpert marks it discontinued and maker current directory omits it. Neither directory/maker EV range establishes a BEV; residual non-BEV availability is outside scope.'
 elif name=='California':
  d='excluded_non_bev_directory_grouping_difference';support+=['carexpert_models']
  reason='CarsGuide has a separate California people-mover card; CarExpert omits the standalone name and maker lists Caddy California. None is established as a current Australian BEV by the maker EV range.'
 elif name in ['Caddy','Caddy 5']:
  d='excluded_non_bev_generation_and_body_grouping'
  reason='Directory generation/body grouping differs (Caddy, Caddy 5, Cargo and California), but no current Australian BEV version is established in the maker EV range.'
 elif name=='Amarok':
  support+=['vw_amarok'];reason='Maker current Amarok range explicitly offers petrol/diesel engines; no current electric Amarok is established. Electric accessories do not change its powertrain.'
 elif name in ['Tiguan','Tayron','Touareg']:
  reason='Maker lists combustion or plug-in-hybrid models in this family. Plug-in hybrids, including eHybrid and Touareg R, are not BEVs; none adds a current Tier 1 BEV.'
 return {'publishedName':name,'publishedSection':'current_cards','sourceUrl':sources[key]['url'],'modelLink':url,'sourceKeys':list(dict.fromkeys(support)),'checkedAt':'2026-10-14','disposition':d,'catalogueFamilies':family,'reason':reason}
def historical(name,key,url):
 support=[key,'vw_models','vw_ev_range'];family=[]
 d='noncurrent_no_current_AU_BEV_established'
 reason='Publisher places this entry in its older/discontinued section; no matching current official Australian BEV family appears in the maker model/EV range. An archive link is not present new-sale evidence.'
 if name in ['ID Buzz','ID.Buzz']:
  d='included_via_current_BEV_family_alias';family=['volkswagen-id-buzz'];support+=['vw_buzz']
  reason='Historical/alternate punctuation link maps to the current ID. Buzz family, already included via the current card. It is not an extra model family or evidence that every archived version is available new.'
  if name=='ID Buzz':reason+=' Its model-link URL is identical to the current ID. Buzz card URL.'
 elif name=='Caddy':
  d='noncurrent_generation_alias_non_bev';reason='Older Caddy entry is kept distinct from current Caddy 5 card; maker body-family naming differs. Neither establishes a current Australian BEV version.'
 elif name=='Touareg R':
  d='excluded_current_PHEV_alias';reason='Older-directory separate grade link overlaps the current maker Touareg R PHEV. A plug-in hybrid is excluded from the BEV catalogue even though this grade remains on the maker range.'
 elif name=='T7':
  d='noncurrent_generation_label_no_BEV';reason='Older-directory generation-name entry does not create a separate current BEV family. Current maker Multivan/Transporter names must not be converted to BEV availability by a T7 archive link.'
 elif name=='E-Golf':
  d='noncurrent_BEV_not_current_official_AU_new';reason='Historical electric Golf lead is absent from current official Australian BEV/model range and both current directory sections. Private imports or archived price/specification data are outside official new-car scope.';support+=['carexpert_models']
 elif name=='ID.3':
  d='noncurrent_BEV_not_current_official_AU_new';reason='CarExpert explicitly says ID.3 is not part of Volkswagen Australia current new-car range; CarsGuide places it among older models. Current maker range omits it. Overseas/news/accessory references do not establish Australian ordering.';support+=['carexpert_id3','carexpert_models','carsguide_models']
 elif name=='ID.7':
  d='noncurrent_BEV_not_current_official_AU_new';reason='Older-directory entry has no current official Australian new-range counterpart. Australian-domain maker ID.7 news concerns overseas/concept introduction, not local new-sale availability.';support+=['vw_id7_news','carexpert_models']
 elif name=='ID.Cross':
  d='noncurrent_future_or_overseas_BEV_lead';reason='Entry is in CarsGuide older-model list, not current cards; the name is absent from current maker Australian model/EV range and CarExpert current directory. No Australian ordering or new-sale evidence is established.';support+=['carexpert_models']
 elif name=='Up!':
  d='noncurrent_nameplate_and_e_up_lead';reason='Older Up! entry is not a current e-up! BEV listing. Neither Up! nor e-up! appears in the current maker Australian model/EV range; no official new BEV supply is established.'
 elif name=='Caravelle':
  d='noncurrent_non_bev_directory_currency_difference';reason='CarExpert labels Caravelle discontinued while CarsGuide still has a current people-mover card. Neither makes it a current BEV; non-BEV residual supply is outside this reconciliation.';support+=['carsguide_models']
 return {'publishedName':name,'publishedSection':'older_model_links' if key=='carsguide_models' else 'discontinued_models','sourceUrl':sources[key]['url'],'modelLink':url,'sourceKeys':list(dict.fromkeys(support)),'checkedAt':'2026-10-14','disposition':d,'catalogueFamilies':family,'reason':reason}
def link(x,name,discontinued=False):
 cand=[a['url'] for a in x['links'] if a['text']==name or (discontinued and a['text']==name+'Discontinued')]
 assert cand,(name,discontinued)
 return cand[0]
cge=[current(n,'carsguide_models',u) for n,u in zip(cgcurrent,cgdetails)]+[historical(n,'carsguide_models',link(cg,n)) for n in older]
cee=[current(n,'carexpert_models',link(ce,n)) for n in cecurrent]+[historical(n,'carexpert_models',link(ce,n,True)) for n in ceold]
lists=[{'id':'volkswagen-carsguide-brand-directory-20261014','publisher':'CarsGuide','datasetAttribution':'CarsGuide / Glass’s Information Services and other sources, as stated in page footer','sourceKey':'carsguide_models','sourceUrl':sources['carsguide_models']['url'],'observedAt':'2026-10-14','sourcePublicationDate':None,'scope':'Volkswagen mixed-powertrain brand directory; complete current cards and older-model links; not a whole-market EV list','sourceLabelCounts':{'currentModels':17,'olderModels':30,'electricCurrentModels':4},'transcribedCounts':{'currentCards':17,'olderLinks':30},'evidenceCaptures':['carsguide_models.json','carsguide_models.txt'],'currentPublishedNames':cgcurrent,'olderPublishedNames':older,'entries':cge},{'id':'volkswagen-carexpert-brand-directory-20261014','publisher':'CarExpert','datasetAttribution':'Independently published CarExpert brand directory; no underlying dataset attribution inferred from this capture','sourceKey':'carexpert_models','sourceUrl':sources['carexpert_models']['url'],'observedAt':'2026-10-14','sourcePublicationDate':None,'scope':'Volkswagen mixed-powertrain brand directory; complete current and explicitly discontinued model entries; not a whole-market EV list','sourceLabelCounts':{'currentModels':None,'discontinuedModels':None},'transcribedCounts':{'currentCards':15,'discontinuedEntries':4},'evidenceCaptures':['carexpert_models.json','carexpert_models.txt'],'currentPublishedNames':cecurrent,'noncurrentPublishedNames':ceold,'entries':cee}]
for d in rec['publishedDirectories']:
 l=next(l for l in lists if l['sourceKey']==d['sourceKey'])
 d['entries']=l['entries'];d['transcribedCounts']=l['transcribedCounts'];d['publishedCurrentNames']=l['currentPublishedNames']
 if 'olderPublishedNames' in l:d['olderPublishedNames']=l['olderPublishedNames'];d['displayedOlderCount']=30
rec['brandPublishedLists']=lists;rec['globalPublishedLists']=[]
rec['completeDirectoryAccounting']={'currentEntries':32,'olderOrDiscontinuedEntries':34,'totalEntries':66,'allEntriesHaveDisposition':True,'allEntriesHaveSourceKeys':True,'noWholeMarketClaim':True,'note':'Source sections and every visible published name are preserved, including historical aliases and non-BEV entries; family closure is not a BEV-only cherry-picked list.'}
rec['differences'].append({'items':['CarsGuide older ID Buzz','CarsGuide older ID.Buzz','CarsGuide older ID.7','CarsGuide older E-Golf','CarsGuide older ID.Cross'],'reason':'Complete 30-link older accordion is transcribed with per-entry dispositions. ID Buzz points to the same URL as current ID. Buzz and is an alias; ID.Buzz is another punctuation archive alias. Other archived BEV names do not establish current Australian official new supply.','resolution':'every_historical_entry_explicitly_accounted'})
for s in facts['sources']:
 s['redactions']['rawSensitiveCapturesPersisted']=False;s['redactions']['rawHtmlPersisted']=False
facts['sanitization']['rawSensitiveCapturesPersisted']=False
(b/'facts.json').write_text(json.dumps(facts,indent=2,ensure_ascii=False)+'\n')
(b/'terms-normalized.json').write_text(json.dumps({k:facts[k] for k in ['sources','terms','reconciliation']},indent=2,ensure_ascii=False)+'\n')
companion={'schemaVersion':1,'checkedAt':'2026-10-14','brand':'Volkswagen','globalPublishedLists':[],'brandPublishedLists':lists,'completeDirectoryAccounting':rec['completeDirectoryAccounting'],'closureConclusion':rec['closureConclusion'],'differences':rec['differences'],'leadDispositions':rec['leadDispositions'],'sanitization':facts['sanitization']}
(b/'brand-model-list-reconciliation.json').write_text(json.dumps(companion,indent=2,ensure_ascii=False)+'\n')
assert len(cge)==47 and len(cee)==19
for l in lists:
 for e in l['entries']:assert e['disposition'] and e['reason'] and e['sourceKeys']
print('Recorded all 66 directory entries: CarsGuide 17 current + 30 older; CarExpert 15 current + 4 discontinued.')
