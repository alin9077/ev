import json,pathlib,hashlib,re
D=pathlib.Path('/tmp/volkswagen-research/idbuzz');R=D/'retained'
L=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-103-archive/recovery99/history/checkpoint98-preimages/data/catalogue-additions-2026-10-10.json')
ledger=json.load(open(L));beforepath=pathlib.Path('/tmp/volkswagen-research/volkswagen-live-before.json');before=json.load(open(beforepath));packet=json.load(open(D/'normalized-evidence.json'));registry=json.load(open('/tmp/volkswagen-research/volkswagen-source-before.json'))
F={(f['variantId'],f['key']):(i,f)for i,f in enumerate(ledger['facts'])}
proof={'schemaVersion':'idbuzz.retained-admitted-proof.v1','checkedOn':'2026-10-14','captureDate':'2026-10-10','classification':'Derived excerpts from immutable previously admitted catalogue facts; NOT recovered whole website captures and NOT fresh web retrieval','originalRawCaptureRecovery':'No matching raw bytes found in authorized archive paths; six recorded whole-capture SHA256 values remain unverified locally','inputs':[{'path':str(L),'sha256':hashlib.sha256(L.read_bytes()).hexdigest()},{'path':str(beforepath),'sha256':hashlib.sha256(beforepath.read_bytes()).hexdigest()}],'mappings':[],'patchRecommendations':[],'derivedSources':[]}
patterns={'carplay_android_auto':['App-Connect incl. App-Connect Wireless'], 'front_heated_seats':['Seat heater for front seats'], 'heated_steering_wheel':['steering wheel.*heated'], 'wireless_charging':['Mobile phone interface with inductive charging'], 'parking_cameras':['Area View incl. rear view camera','Park Distance Control'], 'power_tailgate':['Power tailgate','Electric sliding door on the left','Electric sliding door on the right'], 'charging_cable':['Charging cable Mode 2','Charging cable mode 3'], 'adas_standard':['Adaptive Cruise Control','Lane change system Side Assist','Semi-automated driving assistance Travel Assist','Autonomous Emergency Braking Front Assist with Pedestrian and Cyclist Monitoring'], 'audio_system':['9 speakers','Harman Kardon sound system'], 'screens_hud':['Head-up display'], 'glass_roof':['Panoramic sunroof with smart glass'], 'navigation_route_planner':['Without navigation system']}
by_source={}
for v in packet['variants']:
 if v['modelYear']!=2026:continue
 old=next(b for b in before if b['id']==v['id']);vid=v['id']
 for new in v['facts']+v['features']:
  k=new.get('key',new.get('criterion'))
  if k not in ('seats','drive','price_aud') and k not in patterns:continue
  if k=='price_aud' and 'GTX'not in v['trim']:continue
  keys= ['seats']if k=='seats'else['drivetrain']if k=='drive'else['configured_mrdp_aud']if k=='price_aud'else [a for a,b in old['facts'].items()if b.get('value')is not None and any(re.search(p,b.get('label',''),re.I) for p in patterns[k])]
  entries=[]
  for key in keys:
   i,f=F[(vid,key)]; entry={'ledgerPointer':'#/facts/'+str(i),'key':key,'label':f['label'],'value':f['value'],'status':f['status'],'date':f['date'],'sourceIds':f['sourceIds'],'anchors':f.get('anchors',[]),'scope':f.get('scope'),'qualifications':f.get('qualifications')};entries.append(entry)
   for sk in f['sourceIds']:by_source.setdefault(sk,[]).append({'variantId':vid,**entry})
  options=[]
  if 'Pro' in v['trim'] and k in ('audio_system','screens_hud','glass_roof'):
   word='Panoramic'if k=='glass_roof'else'Head-up display with Harman Kardon'
   for j,o in enumerate(old['configurationEvidence'].get('options',[])):
    if word in o['name']:
     opt={'beforePointer':f'variant:{vid}/configurationEvidence/options/{j}','option':o};options.append(opt)
     for a in o['anchors']:by_source.setdefault('r10_vw26_'+a['source_id'],[]).append({'variantId':vid,**opt})
  m={'variantId':vid,'criterionOrKey':k,'proposedValue':new['value'],'admittedFacts':entries,'admittedOptions':options,'decision':'Previously admitted fact/option anchors cover the substance; date remains 2026-10-10. Do not describe as recovered raw capture.'}
  if k=='screens_hud'and'GTX'in v['trim']:
   m['decision']='No matching head-up display fact found in exact prior admitted equipment. Use current-linked maker brochure p19 Head-up display standard in GTX column plus maker current named-scope mapping; source date2026-10-14. Do not cite retained equipment source alone.'
   m['alternativeSourceKeys']=['vw_buzz_page','vw_buzz_my25_pdf']
  if k=='screens_hud'and'Pro'in v['trim']:
   m['decision']='Prior optional item explicitly says Head-up display with Harman Kardon sound system, MLP2200, unselected. Remove unsupported Infotainment package Plus name from MY26 wording; exact supported wording is optional Head-up display with Harman Kardon sound system. Option source is buzz26_swb_options/buzz26_lwb_options, not equipment source. Current-linked brochure p19 independently confirms both items optional.'
  if k=='audio_system'and'Pro'in v['trim']:
   m['decision']='Nine-speaker standard base is directly admitted equipment. Harman Kardon option is separately admitted options item paired with HUD; cite both source scopes or fresh current-linked brochure p19.'
  if k=='glass_roof'and'Pro'in v['trim']:
   m['decision']='Optional smart-glass roof directly admitted in options array (MLP3290, unselected). Cite correct options source or fresh current-linked brochure p21; existing equipment-only source citation is insufficient.'
  if k=='parking_cameras':m['decision']='Admitted Area View and front/rear Park Distance Control are exact. Either keep exact label Area View rather than adding 360-degree, or add current-linked maker brochure p10 four-camera comprehensive plan-view explanation for the surround-view gloss.'
  if k=='price_aud':m['decision']='117216 is a previously admitted configured_mrdp_aud fact, exact10Oct quote with NSW2000/no-options scope. Parent may apply new brief price ladder; do not call it fresh quotation or claim raw snapshot recovery.'
  proof['mappings'].append(m)
for key,rows in by_source.items():
 unique=[];seen=set()
 for row in rows:
  sig=json.dumps(row,sort_keys=True)
  if sig not in seen:seen.add(sig);unique.append(row)
 source=next((s for s in registry if s['id']==key),None)
 d={'classification':'DERIVED ADMITTED-LEDGER EXCERPTS, NOT ORIGINAL RAW CAPTURE','dateOfOriginalEvidence':'2026-10-10','derivedOn':'2026-10-14','sourceKey':key,'existingSource':source,'inputLedger':str(L),'inputLedgerSha256':proof['inputs'][0]['sha256'],'assertions':unique}
 p=R/(key+'-admitted-excerpts.json');p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n');proof['derivedSources'].append({'key':key,'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'originalRawSnapshotRecovered':False,'assertionCount':len(unique)})
proof['patchRecommendations']=[
 {'scope':'All six retained source objects','change':'Attach inspectable derived admitted-ledger excerpt files and hashes, explicitly label derived not fresh retrieval or recovered raw source; preserve10Oct date and original source metadata. Whole-capture SHA is an archived assertion, not locally reverified.'},
 {'scope':'MY26 Pro audio_system','change':'Cite equipment_vw_12f505c0b4074013 for nine speakers plus relevant admitted optional HUD/Harman source or current-linked brochurep19 for extra-cost Harman.'},
 {'scope':'MY26 Pro screens_hud','change':'Rename optional package to exact Head-up display with Harman Kardon sound system. Use correct option source or current-linked brochurep19, not equipment source alone.'},
 {'scope':'MY26 Pro glass_roof','change':'Use correct admitted options source or current-linked brochurep21; retain optional status/Check.'},
 {'scope':'MY26 GTX screens_hud','change':'Use current-linked maker brochurep19 standard GTX column; no prior admitted exact HUD fact recovered.'},
 {'scope':'MY26 parking_cameras','change':'Prefer exact Area View incl. rear-view camera and front/rear parking sensors; 360-degree gloss needs maker brochurep10 supporting four-camera plan-view system.'},
 {'scope':'MY26 wireless CarPlay/Android Auto','change':'No withdrawal: exact equipment_vw_93bedc302f228064 in all3 admitted rows establishes both wireless systems.'}]
(R/'admitted-assertion-supplement.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False)+'\n')
md=['# Retained MY26 proof supplement','','Original raw browser captures were not recovered. The included JSON excerpts are derived from immutable admitted catalogue facts, not fresh or reconstructed website captures. Original whole-capture hashes are preserved as metadata only; they were not locally reverified.','', '## Decisions','']
for p in proof['patchRecommendations']:md+=['- **'+p['scope']+':** '+p['change']]
md+=['','## Exact mapping','', '| Variant | Assertion | Existing admitted keys/pointers | Decision |','|---|---|---|---|']
for m in proof['mappings']:md.append('| '+m['variantId'].replace('volkswagen_idbuzz_my26_','').replace('__20261010','')+' | '+m['criterionOrKey']+' | '+ '; '.join(a['key']+' '+a['ledgerPointer']for a in m['admittedFacts'])+ ('; options '+','.join(o['beforePointer'].split('/')[-1]for o in m['admittedOptions'])if m['admittedOptions']else'')+' | '+m['decision']+' |')
(R/'report.md').write_text('\n'.join(md)+'\n'); print('Mapped',len(proof['mappings']),'assertions; derived',len(proof['derivedSources']),'source excerpt packets')
