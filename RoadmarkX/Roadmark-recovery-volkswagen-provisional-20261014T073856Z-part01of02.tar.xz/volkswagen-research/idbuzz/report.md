# Volkswagen ID. Buzz passenger: Australian M1 evidence

**As of 14 October 2026.** Eleven exact model-year/body/grade records prepared: three MY26 current configurator grades, two MY25 current maker campaign grades, one genuinely advertised New MY25 GTX, and five MY27 reported-order-open grades. Cargo is excluded. No independently named Australian six-seat grade established.

## Census result

- **Current maker configurations:** MY26 Pro SWB five-seat, Pro LWB seven-seat and GTX LWB seven-seat. [Current maker configurator](https://www.volkswagen.com.au/en/configurator.html/__app/id-buzz.app); retained exact build captures are dated 10 October, with original source objects and hashes preserved.
- **Current maker campaigns:** MY25 Pro SWB and Pro LWB remain explicitly advertised for New/Demo purchases during 1 October–31 December 2026. They qualify as current named maker offerings, while remaining New-unit inventory is unverified. [Current Australian model page](https://www.volkswagen.com.au/en/models/id-buzz.html)
- **Clean residual New supply:** MY25 GTX LWB, Macgregor stock V438628, VIN WV2ZZZEB2SH053963, 10 km, explicit Model Year 25; build May 2025, compliance August 2025. Direct live dealer capture succeeded. Advertised A$116,827 driveaway is unit-specific, not the canonical national list price. [Exact New dealer advertisement](https://macgregorvolkswagen.com.au/v438628-1688181-volkswagen-idbuzz-2025/)
- **MY27:** Pro SWB, Pro LWB, Pro+ SWB, Pro+ LWB and GTX LWB were explicitly reported Australian order-open on 29 July, with September arrival anticipated. Those are `announced_provisional`, with reported order status. No exact current maker MY27/Pro+ list, configurator or primary arrival evidence was recovered. Elapsed arrival dates do not prove delivery. [Carsales launch report](https://www.carsales.com.au/editorial/details/volkswagen-id-buzz-updated-for-2027-model-year-152571/); [GoAuto launch report](https://www.goauto.com.au/new-models/volkswagen/id-buzz/id-buzz-gains-new-variants-more-kit-for-my27/2026-07-29/99961.html)
- **Official full-current-list closure remains unresolved.** The five reported MY27 rows must not be represented as confirmed current manufacturer configurations. Generic new-car-to-order guide templates are not actual manufacturer or dealer stock.

## Price ladder and exact cohorts

| Cohort | Price AUD | Basis / grade | Availability evidence |
|---|---:|---|---|
| MY27 Pro SWB | $75,990 | Before on-road costs; reported; rung 5 | Reported order-open; primary census unresolved |
| MY27 Pro LWB | $80,990 | Before on-road costs; reported; rung 5 | Reported order-open; primary census unresolved |
| MY27 Pro+ SWB | $84,990 | Before on-road costs; reported; rung 5 | Reported order-open; primary census unresolved |
| MY27 Pro+ LWB | $89,990 | Before on-road costs; reported; rung 5 | Reported order-open; primary census unresolved |
| MY27 GTX LWB | $106,990 | Before on-road costs; reported; rung 5 | Reported order-open; primary census unresolved |
| MY26 Pro SWB | $79,990 | Driveaway; check; rung 2 | Current maker configuration |
| MY26 Pro LWB | $84,990 | Driveaway; check; rung 2 | Current maker configuration |
| MY26 GTX LWB | $117,216 | Driveaway; check; rung 3 | Current maker configuration |
| MY25 Pro SWB | $77,990 | Driveaway; check; rung 2 | Current maker New/Demo campaign; New unit unverified |
| MY25 Pro LWB | $84,990 | Driveaway; check; rung 2 | Current maker New/Demo campaign; New unit unverified |
| MY25 GTX LWB | $104,990 | Before on-road costs; reported; rung 5 | Live New dealer advertisement |

Campaign prices are manufacturer national driveaway **from** figures for private buyers, New/Demo, bought from 1 October and delivered by 31 December 2026, while stocks last; options/metallic paint extra; government, fleet, rental and other offers excluded. Those real conditions earn Check. MY26 GTX is a retained 10 October maker configurator quotation for reference NSW postcode 2000, not an assumption about the user’s location. MY25 GTX uses the exact model-year secondary price-when-new guide at rung 5. [Exact MY25 GTX price guide](https://www.carsales.com.au/research/volkswagen/id-buzz/2025/gtx/)

**MY27 LWB price conflict:** selected A$80,990 from exact RedBook MY27 guide 700958, also the named GoAuto table; Carsales 29 July prints A$79,990. This is a source-specific selection, not a vote. Both are secondary, the alternative remains in evidence, and the reported amount is unranked. [Exact MY27 Pro LWB guide](https://www.redbook.com.au/cars/details/2026-volkswagen-id-buzz-pro-bev560-eb-lwb-auto-my27/SPOT-ITM-700958?Cr=16)

## Technical facts

The current maker page links the May 2025/MY25 brochure with exact Pro SWB, Pro LWB and GTX LWB columns. Matching current MY26 mechanical/body facts earn Confirmed where no real change or conflicting current value was found; the filename alone is not a downgrade. Exact MY26 equipment/seat/drive anchors retain their original 10 October evidence date. MY27 data remain Reported, either from exact secondary guides or explicitly identified same-powertrain carry-over. [Current-linked Australian technical brochure](https://www.volkswagen.com.au/idhub/content/dam/onehub_pkw/importers/au/model/id-buzz/2025/VW_CV_ID%20Buzz%20GTX_2025_Brochure.pdf)

| Fact | Pro SWB / Pro+ SWB | Pro LWB / Pro+ LWB | GTX LWB |
|---|---:|---:|---:|
| Usable battery | 79 kWh | 86 kWh | 86 kWh |
| Gross battery | 84 kWh | 91 kWh | 91 kWh |
| WLTP combined range | 422 km | 452 km | 450 km |
| Explicit maximum DC capability | 185 kW | 200 kW | 200 kW |
| Exact DC 10–80% time | 26 minutes | 26 minutes | 26 minutes |
| Maximum AC acceptance | 11 kW, Reported | 11 kW, Reported | 11 kW, Reported |
| Seats | 5 | 7 | 7 |
| Boot, all occupied rows up | 1,121 L | 306 L | 306 L |
| 0–100 km/h | 7.6 s | 7.9 s | 6.4 s |
| Power / drive | 210 kW / RWD | 210 kW / RWD | 250 kW / AWD |
| Length × width × height | 4,712 × 1,985 × 1,927 mm | 4,962 × 1,985 × 1,924 mm | 4,962 × 1,985 × 1,924 mm |
| Maximum braked towing | 1,200 kg | 1,000 kg | 1,600 kg |

Pro+ exists only in the reported MY27 rows. Shared warranty and battery-warranty fields are deliberately delegated to the parent’s terms worker; this packet supplies the other 15 core fields plus separate gross/usable battery helper facts.

### Required basis qualifications

- **AC:** 11 kW is supported by Australian reviews explicitly labelling maximum AC charging. The maker’s “AC 3-phase 11 kW” charging-time condition alone does not prove onboard maximum. [Pro review](https://www.carexpert.com.au/car-reviews/2025-volkswagen-id-buzz-review-2); [GTX review](https://drivingenthusiast.com.au/2026/02/2026-volkswagen-id-buzz-gtx-review-video/)
- **DC:** the maker table explicitly calls 185/200 kW maximum vehicle DC charging. Exact 26-minute 10–80% is retained; generic family FAQ says around 30 minutes and is preserved as a conflicting less-specific statement, not substituted.
- **Boot:** occupied-row configuration is stated. No VDA/SAE, roof or load-cover method is inferred. LWB/GTX 1,340 L applies with third row folded, not all seven seats occupied. The separate maximum SWB values conflict: 2,205 L and 2,232 L within the brochure, and 2,223 L on a maker seating layer noted by the parent. No canonical maximum SWB cargo value is selected.
- **Towing:** Check because the Volkswagen Genuine Tow Bar is explicitly required and the maker qualifies actual loaded/accessory conditions. The towbar is not assumed fitted.
- **Width:** preserve 1,985 mm with the maker table’s mirror scope unspecified. Do not silently label the maker value “including mirrors”.
- Generic laboratory, temperature and real-world variation caveats are standing notes, not per-fact Check triggers.

## Buyer equipment and actual model-year changes

**MY25 and matching MY26 Pro:** wireless Apple CarPlay/Android Auto, wireless charging, heated front seats and steering wheel, electric sliding doors and tailgate, 360-degree Area View, adaptive cruise, lane/side assistance, front AEB, 19-inch Tilburg wheels and nine speakers. Head-up display/Harman Kardon package and smart-glass roof are optional, with explicit option status and Check. Mode 2 domestic and Mode 3 Type 2 cables are documented in the maker brochure.

**MY25 and MY26 GTX:** 21-inch Townsville wheels, ArtVelours, powered/massage front seats, smart-glass roof, head-up display and Harman Kardon audio are standard. The exact retained MY26 configurator says without navigation. Do not use phone mirroring as evidence of native navigation.

**MY27 reported changes:** revised infotainment, driver-attention monitoring, front cross-traffic assist, predictive speed limiter, driving-mode selection and dynamic road-sign display. Pro+ adds 20-inch Stockton Silver wheels, powered comfort/massage front seats, heated second row, Park Assist with memory, load platform/net/storage, upgraded interior and native navigation. GTX gains standard native navigation and Park Assist memory; base Pro navigation is optional. The A$4,390 Goodnight camping package is optional. [Named launch equipment](https://www.carsales.com.au/editorial/details/volkswagen-id-buzz-updated-for-2027-model-year-152571/); [Independent Australian launch report](https://www.goauto.com.au/new-models/volkswagen/id-buzz/id-buzz-gains-new-variants-more-kit-for-my27/2026-07-29/99961.html)

**Bidirectional charging:** MY27 reports explicitly say local testing is still pending. No operational Australian V2L, V2H, V2G, output kW or included adapter is asserted.

**Display conflict:** MY25 brochure standard-equipment pages say 10 inches, while feature table/interior text says 30.48 cm/12 inches. No MY25 exact screen diagonal is normalized. The retained exact MY26 configurator separately supplies 32.8 cm/12.9 inches; this is an actual year-specific distinction, not a blanket carry-over.

## Residual inventory reconciliation

- Clean live MY25 GTX at Macgregor is admitted as advertised New supply.
- MY25 Pro SWB/LWB retain current official campaign inclusion; remaining New stock is explicitly unverified.
- Townsville stock 544552/VIN WV2ZZZEB5SH008841 is a promising MY25 LWB New lead in search cache. Both exact dealer page and current stock-list HTTP fetches returned 403, so it is not upgraded to clean live supply.
- Brighton SWB and Osborne Park leads returned 404; Wakeling SWB and former Alto LWB redirected to generic stock. These failures do not prove sold status.
- Two live Alto LWB ads have MY25 titles but MY26 dealer comments and 2026 build fields. They are conflicting identity evidence, not clean residual MY25 supply.
- Gerald Slaven LWB is explicitly Sold in indexed content; direct retrieval was forbidden. Demo/used examples remain excluded as proof of New stock.

## Provenance and access

`evidence.json` is the normalized packet; `source-index.json` lists every source with URL, publisher, source type and capture/hash metadata where obtained. `sources.json` is the raw download-attempt history. Public factual captures are in `captures/`; `redaction-log.json` records stripping of script/style/noscript/iframe/input elements and runtime data. Public stock/VIN/model/configuration identifiers are retained. No cookies, response headers, session/challenge tokens, CSRF values or client secrets were saved.

One batch covering five exact MY26 maker configurator URLs and two review pages ended during polling with “Unified exec process failed: automatic approval review was cancelled”. The single authorized retry of the same poll returned “Unknown process id87598”. No fresh captures from that batch are claimed. The exact target set is recorded under `failedTool` in `evidence.json`; prior exact maker sources are preserved with their original source objects, dates and hashes.

Not-published checks are explicit for cargo methodology, a distinct Australian six-seat grade, MY25 native navigation and Australian bidirectional output/operation. At least two relevant sources/searches are recorded; lack of a claim is never converted into a definitive absence claim.

## Key primary source links

- [ID. Buzz | Electric Van | Volkswagen Australia Volkswagen Opens an external link Opens an external link Opens an external link Opens an external link Opens an external link Opens an external link Opens an external link Opens an external link Opens an external link Opens an external link Opens an external link Opens an external link](https://www.volkswagen.com.au/en/models/id-buzz.html)
- [Build your own Volkswagen  | Volkswagen Australia Volkswagen](https://www.volkswagen.com.au/en/configurator.html/__app/id-buzz.app)
- [E03359140_VW_CV_ID Buzz GTX_VWCBUZGTXMY25_BrochureSpec_May25_FA.indd](https://www.volkswagen.com.au/idhub/content/dam/onehub_pkw/importers/au/model/id-buzz/2025/VW_CV_ID%20Buzz%20GTX_2025_Brochure.pdf)
- [New 2025 Volkswagen ID. Buzz GTX | Large People Mover | V438628 | Macgregor Volkswagen Brisbane](https://macgregorvolkswagen.com.au/v438628-1688181-volkswagen-idbuzz-2025/)
- [2026 Volkswagen ID. Buzz Pro BEV560 EB MY26 for sale in Geelong, VIC (Deep Black)  | Rex Gorell Group](https://rexgorell.com.au/new-items/for-sale/volkswagen/id.-buzz/2026/pro-bev560/eb-my26/4097838/)
- [2026 Volkswagen ID. Buzz Pro BEV560 EB MY26 for sale in Geelong, VIC (Candy White & Pomelo Yellow)  | Rex Gorell Group](https://rexgorell.com.au/new-items/for-sale/volkswagen/id.-buzz/2026/pro-bev560/eb-my26/4056340/)
