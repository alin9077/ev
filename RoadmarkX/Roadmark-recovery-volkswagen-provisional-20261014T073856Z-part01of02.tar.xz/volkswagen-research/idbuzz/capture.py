import sys,json,urllib.request,hashlib,pathlib,datetime,re,concurrent.futures
from lxml import html
from pypdf import PdfReader
from io import BytesIO
D=pathlib.Path('/tmp/volkswagen-research/idbuzz');D.mkdir(exist_ok=True);(D/'captures').mkdir(exist_ok=True)
def fetch(t):
 key,url,pub,typ=t
 meta={'key':key,'url':url,'publisher':pub,'source_type':typ,'checkedOn':'2026-10-14','retrieval':'direct public HTTP','redactions':[]}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
  with urllib.request.urlopen(req,timeout=35) as r:
   raw=r.read();meta.update(httpStatus=r.status,finalUrl=r.url)
  if raw.startswith(b'%PDF'):
   reader=PdfReader(BytesIO(raw)); txt='\n\n'.join('PAGE '+str(n+1)+'\n'+p.extract_text() for n,p in enumerate(reader.pages));meta['title']=str(reader.metadata.title or key);meta['pages']=len(reader.pages)
   p=D/'captures'/f'{key}.pdf';p.write_bytes(raw);meta.update(file=str(p),sha256=hashlib.sha256(raw).hexdigest())
  else:
   tree=html.fromstring(raw)
   meta['title']=' '.join(tree.xpath('//title/text()')).strip() or key
   for tag in ['script','style','noscript','iframe','input']:
    nodes=tree.xpath('//'+tag);meta['redactions'].append({'action':'removed_elements','element':tag,'count':len(nodes),'reason':'Exclude runtime code, session, cookie, challenge, CSRF and client-secret data; retained visible public factual text and links'})
    for n in nodes:n.drop_tree()
   txt=tree.text_content();txt='\n'.join(x.strip() for x in txt.splitlines() if x.strip())
   links=[]
   for a in tree.xpath('//a[@href]'):
    u=a.get('href');label=' '.join(a.text_content().split())
    if u and not re.search(r'(?i)(token|secret|session|csrf|challenge|srsltid|gclid)=',u):links.append(label+' '+u)
   txt+='\n\nPUBLIC LINKS\n'+'\n'.join(links)
  # Redact runtime secrets if any appeared as text; never persist cookies or response headers.
  txt,n=re.subn(r'(?i)((?:csrf[_-]?token|client[_-]?secret|session[_-]?(?:id|token)|access[_-]?token|refresh[_-]?token)\s*[=:]\s*)[^\s<]+',r'\1[REDACTED]',txt)
  if n:meta['redactions'].append({'action':'redacted_runtime_values','count':n})
  p=D/'captures'/f'{key}.txt';p.write_text(txt);meta.update(textFile=str(p),textSha256=hashlib.sha256(txt.encode()).hexdigest());meta.setdefault('file',str(p));meta.setdefault('sha256',meta['textSha256'])
 except Exception as e:meta['error']=str(e)
 return meta
if __name__=='__main__':
 tasks=json.load(open(sys.argv[1])); out=list(concurrent.futures.ThreadPoolExecutor(max_workers=8).map(fetch,tasks))
 target=D/'sources.json';existing=json.load(open(target)) if target.exists() else [];ids={t['key'] for t in out};existing=[x for x in existing if x['key'] not in ids];target.write_text(json.dumps(existing+out,indent=2));print(json.dumps(out,indent=2))
