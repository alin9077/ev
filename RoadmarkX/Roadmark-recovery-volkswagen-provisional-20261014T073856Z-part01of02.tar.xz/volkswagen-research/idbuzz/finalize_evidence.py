import json,hashlib,re
from pathlib import Path
D=Path('/tmp/volkswagen-research/idbuzz');p=D/'evidence.json';x=json.load(open(p));raw=json.load(open(D/'sources.json'))
for key in ['townsville_lwb25','townsville_new_stock','carsales_gtx25']:
 s=next(s for s in raw if s['key']==key); x['sources']=[t for t in x['sources'] if t['key']!=key]+[s]
# Search-cache evidence is retained as such, not relabelled a direct live capture.
txt='''Checked 2026-10-14. Search-result finding, not a fresh direct dealer-page capture.
https://townsvillevolkswagen.com.au/544552-1859529-volkswagen-idbuzz-2025/
Indexed dealer title: New 2025 Volkswagen ID. Buzz Pro BEV560, stock 544552.
Indexed structured fields: Model Year 25; 7 seats; VIN WV2ZZZEB5SH008841; 47 km; build 10/2024; compliance 12/2025; indexed price A$94,571 driveaway. Dealer text calls it brand-new. Title says 2025 while About this Vehicle says 2024; model-year field resolves the requested MY25 cohort, but does not establish current supply.
https://townsvillevolkswagen.com.au/new-models/?models=ID.+Buzz
Indexed dealer stock list labels same stock 544552 New with 47 km.
Direct public HTTP retrieval of both exact dealer URLs returned 403 Forbidden on 2026-10-14. No CAPTCHA solved or restriction bypassed. Search cache crawl dates were last month. Current surviving New supply remains unverified.
Additional cached SWB lead: Autotrader Mascot MY25 Pro SWB, New, 25 km, A$82,888 driveaway; indexed pages crawled three months ago. No live exact dealer identity established. Not admitted as proof of current New inventory.
'''
f=D/'captures'/'residual_late_search_notes.txt';f.write_text(txt);h=hashlib.sha256(f.read_bytes()).hexdigest()
x['sources'].append({'key':'residual_late_search_notes','url':'https://townsvillevolkswagen.com.au/544552-1859529-volkswagen-idbuzz-2025/','title':'Late residual dealer search reconciliation','publisher':'Research reconciliation of public dealer/search output','source_type':'research_note','checkedOn':'2026-10-14','file':str(f),'textFile':str(f),'sha256':h,'textSha256':h,'retrieval':'Search-cache factual observations plus recorded direct HTTP failures','redactions':[{'action':'factual_summary_only','reason':'No response headers, cookies, scripts or runtime state retained'}]})
comp={'driveaway':'Driveaway','before_on_road':'Before on-road costs','wltp_combined':'WLTP combined','battery_usable_kwh':'Usable capacity','battery_gross_kwh':'Gross capacity','dc_peak_kw':'Peak DC charging','dc_10_80_percent':'DC 10–80%','ac_peak_kw':'Maximum AC charging','seats':'Seats','manufacturer_unspecified_all_seats_up_l':'Manufacturer litres, all seats up; method unspecified','zero_to_100_s':'0–100 km/h','power_kw':'Maximum combined power','drive':'Driven wheels','body_length_mm':'Length','body_width_mm':'Width, maker mirror scope unspecified','body_height_mm':'Height','braked_towing_kg':'Maximum braked towing'}
def feat(criterion,value,sources,grade='reported',reason='Exact Australian MY27 launch equipment report',condition=None):
 d={'criterion':criterion,'value':value,'grade':grade,'sourceKeys':sources,'reason':reason,'date':'2026-10-14'}
 if condition:d['condition']=condition
 return d
for v in x['variants']:
 y=v['modelYear']; swb='SWB' in v['trim'];plus='+'in v['trim'];gtx='GTX'in v['trim'];a=v['availability']
 v['modelId']=f'volkswagen_id_buzz_my{str(y)[2:]}'
 a['state']='announced_provisional' if y==2027 else 'outgoing' if y==2025 and gtx else 'current_or_order_listed'
 if y==2027:
  a['stockStatus']='unverified';a['orderStatus']='reported_order_open';a['censusEligible']=True;a['officialCensusClosure']=False
 elif y==2025 and not gtx:
  a.update(detailedState='current_named_manufacturer_campaign',stockStatus='unverified',orderStatus='listed_unconfirmed',censusEligible=True,sourceKeys=['vw_buzz_page','residual_search_log','residual_late_search_notes'],reason='Current Australian maker campaign explicitly advertises the named MY25 Pro body for new and demo purchases from 1 October to 31 December 2026. This establishes current official advertised offering; a surviving exact New unit is separately unverified.',qualifications=['Campaign covers both New and Demo and is while stocks last','No clean live exact New dealer unit was established; cached or conflicting ads do not prove remaining inventory','Do not describe this as confirmed residual-New stock'])
 elif y==2025:
  a['stockStatus']='new_stock_listed';a['orderStatus']='residual_new_advertised'
 else:
  a['stockStatus']='new_stock_listed' if not gtx else 'unverified';a['orderStatus']='current_manufacturer_configurator'
 for fact in v['facts']:
  fact['comparison']=comp.get(fact.get('comparison'),fact.get('comparison',''))
  if fact['key']=='price_aud' and 'campaign'in fact['basis'].lower():
   fact['validUntil']='2026-12-31';fact['validFrom']='2026-10-01';fact['condition']=f'Private buyers; new or demo MY{str(y)[2:]}; purchased from 1 October and delivered by 31 December 2026; while stocks last; options and metallic paint extra; government, fleet, rental and other offers excluded'
  if fact['key']=='price_aud' and y==2025 and gtx:
   fact.update(sourceKeys=['carsales_gtx25'],reason='Exact Australian GTX LWB MY25 Carsales/RedBook guide gives A$104,990 price when new including GST and LCT, excluding on-road costs. This is rung 5 secondary list price; the live dealer A$116,827 driveaway is a different price basis, retained separately.')
  if fact['key']=='price_aud' and y==2027 and v['trim']=='Pro LWB':
   fact['qualifications']=['Exact guide price A$80,990 selected; Carsales 29 July launch article has A$79,990. Both secondary. Unresolved maker price and no ranking admission.']
 # Finish equipment distinctions important to buyers.
 if y==2027:
  for z in v['features']:
   if z['criterion']=='driver_alerts':z['value']='Updated driver attention monitoring, front cross-traffic assist, predictive speed limiter, drive-mode selection and dynamic road-sign display'
  if plus:
   v['features'] += [feat('front_power_seats','Powered comfort front seats with massage',['goauto_my27_launch','carsales_my27_launch']),feat('rear_heated_seats','Heated second-row seats standard',['goauto_my27_launch','carsales_my27_launch']),feat('wheels','20-inch Stockton Silver alloy wheels',['carsales_my27_launch']),feat('parking_assist','Park Assist with memory standard',['goauto_my27_launch','carsales_my27_launch']),feat('cargo_flexibility','Luggage platform, net partition and storage boxes standard',['carsales_my27_launch']),feat('interior_trim','30-colour ambient lighting and upgraded seat upholstery',['carsales_my27_launch'])]
  elif gtx:v['features'].append(feat('parking_assist','Park Assist with memory standard',['carsales_my27_launch']))
  v['features'].append(feat('camping_package','Goodnight Package: folding bed, blinds, camping table and chairs; reported A$4,390 option',['carsales_my27_launch'],condition='Optional package, not included in base grade price; reported arrival, availability to confirm'))
 # Own-row summaries avoid unstated cross-cohort rankings.
 if swb:
  strength='Five seats and 1,121 L behind the second row'
  sk=['seats','boot_l']; trade='The Australian SWB has five seats, with 422 km published WLTP range';tk=['seats','range_km']
 elif gtx:
  strength='Seven-seat AWD with 250 kW and 1,600 kg maximum braked towing with the required towbar';sk=['seats','drive','power_kw','towing_braked_kg'];trade='Only 306 L of luggage space remains behind all seven seats';tk=['boot_l','seats']
 else:
  strength='Seven seats and a published 26-minute DC 10–80% recharge';sk=['seats','dc_charge_time_min'];trade='Only 306 L remains behind all seven seats; maximum braked towing is 1,000 kg';tk=['boot_l','seats','towing_braked_kg']
 v['summary']={'strengths':[{'label':'Practicality' if not gtx else 'Performance and utility','text':strength,'keys':sk}],'tradeOffs':[{'label':'Capacity trade-off','text':trade,'keys':tk}],'reason':'Original buyer summary grounded in this exact row; MY27 underlying fields are Reported'}
x['reportedOrderOpenVersions']=x.pop('currentNamedVersionList')
x['manufacturerCurrentOffering']=['MY25 Pro SWB','MY25 Pro LWB','MY26 Pro SWB','MY26 Pro LWB','MY26 GTX LWB']
x['residualReconciliation']={'confirmedLiveNew':['MY25 GTX LWB'], 'currentOfficialCampaignInventoryUnverified':['MY25 Pro SWB','MY25 Pro LWB'],'candidateSourceKeys':['brighton_swb25','wakeling_swb25','alto_lwb25','alto_lwb_26265754','alto_lwb_26198029','slaven_lwb25','townsville_lwb25','townsville_new_stock','residual_late_search_notes'],'decision':'Campaign-based inclusion is current named maker offering, not assertion of physical residual New stock. MY25 GTX separately has a clean live exact New dealer advertisement.'}
x['deferredSharedCoreFields']=['warranty','battery_warranty']
x['coreCoverage']='15 of 17 shared core fields supplied per row; warranty and battery warranty delegated to shared terms worker. Gross and usable battery helpers supplied in addition.'
x['standingNotes']=['Published laboratory range and charging figures are comparison ratings, not guaranteed real-world outcomes. Generic temperature, route, battery and driving variation does not itself earn Check.','Current linked maker technical material applies only to matching Australian named body/grade; documented MY27 equipment changes are not inherited as Confirmed.','Exact MY26 retained captures keep their actual 10 October date. Regrading them on 14 October does not imply a new capture.','Dealer advertisements establish advertised New status, not physical inspection, purchase acceptance or immediate delivery.','Width is preserved with maker table scope unspecified; boot figures have no inferred VDA/SAE or load-height method.']
# Tidy known presentation strings only, preserving keys, identifiers, URLs and original captured text.
repls={'V2 L':'V2L','Mode2':'Mode 2','Mode3':'Mode 3','Type2':'Type 2','Harman Kardon13':'Harman Kardon 13','charging11':'charging 11','from11':'from 11','May2025':'May 2025','SWB5seat':'SWB five-seat','LWB7seat':'LWB seven-seat','brief5.2':'brief 5.2','SWB1121':'SWB 1121','LWB306':'LWB 306','boot1121':'boot 1121','tablep19':'table p19','pages4/6':'pages 4/6','display32.8':'display 32.8','says32.8':'says 32.8','26-minute10':'26-minute 10','around30':'around 30','exact26':'exact 26','min10':'min 10','30.48cm':'30.48 cm'}
for v in x['variants']:
 for o in v['facts']+v['features']:
  for k in ('value','reason','condition','basis'):
   if isinstance(o.get(k),str):
    for old,new in repls.items():o[k]=o[k].replace(old,new)
p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
# Complete source index used by this packet; sources.json remains raw download-attempt history.
(D/'source-index.json').write_text(json.dumps(x['sources'],indent=2,ensure_ascii=False)+'\n')
log={'checkedOn':'2026-10-14','policy':'Only visible public factual text/public vehicle IDs saved. HTML scripts/styles/noscript/iframes/inputs removed before serialization. No cookies or response headers persisted. Runtime secret-like text scrubbed. PDF retained as public manufacturer publication.','sources':[{'key':s['key'],'redactions':s.get('redactions',[]),'retrieval':s.get('retrieval','retained existing source' if 'existingSource'in s else None)} for s in x['sources']]}
(D/'redaction-log.json').write_text(json.dumps(log,indent=2)+'\n')
refs={s['key'] for s in x['sources']};errors=[]
for v in x['variants']:
 for f in v['facts']+v['features']+[v['availability']]:
  for k in f.get('sourceKeys',[]):
   if k not in refs:errors.append((v['id'],k))
assert not errors, errors
assert len(set(v['id'] for v in x['variants']))==len(x['variants'])
print('Finalized',len(x['variants']),'records,',len(x['sources']),'source entries; cross-references valid')
