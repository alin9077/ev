import json,pathlib
R=pathlib.Path('/tmp/volkswagen-research');D='2026-10-14';PID='m1-volkswagen-'+D
load=lambda p:json.loads((R/p).read_text());p=load('volkswagen-2026-10-14.json');e=load('normalized-evidence.json');src={s['key']:s for s in e['sources']};old={v['id']:v for v in load('volkswagen-live-before.json')}
def urls(keys):return list(dict.fromkeys(src[k]['existingSource']['url'] if src[k].get('existingSource') else src[k]['url'] for k in keys))
def with_urls(o):
 if isinstance(o,list):return [with_urls(x) for x in o]
 if isinstance(o,dict):
  x={k:with_urls(v) for k,v in o.items()}
  if o.get('sourceKeys'):x['sourceUrls']=urls(o['sourceKeys'])
  return x
 return o
notes=[
'Volkswagen-only Australian Tier 1 BEV research. Current named passenger offerings are ID.4, ID.5 and passenger ID. Buzz; Cargo and e-Transporter remain outside this pass. Brand-only CarExpert and CarsGuide directories are not whole-market C1 lists.',
'Five MY27 ID. Buzz named versions are supported by Australian order-open launch reports but remain announced/provisional because no current exact maker configuration list was recovered. Reported orders-open does not become an accepted factory order or verified September arrival. Their older-current-maker-page mismatch remains unresolved, not an exclusion.',
'Current official October–December 2026 MY25 ID. Buzz Pro SWB/LWB campaigns establish current advertised exact versions. They remain stock-unverified; failed or inaccessible dealer leads do not establish either physical stock or that new supply has ceased.',
'The latest maker ID.4 MY27 and ID.5 MY26 grades are separately established. Genuine dated dealer New advertisements establish ID.4 Pro MY26, ID.5 Pro MY25.5 and ID.5 GTX MY25. ID.5 Pro ads labelled only MY25 do not establish an additional distinct MY25.0 identity.',
'An indexed New ID.4 GTX MY26 lead (stock 213730) has an inaccessible current origin and no usable exact live dealer counterpart. Its residual identity remains unresolved. The known MY26 Pro is included in buyer data, but a complete MY26 residual current-version review is withheld until that cohort is settled.',
'Current named-version maker technical figures and current linked ID. Buzz brochure scopes are reviewed directly. Generic model-year/lab caveats do not lower grades; actual options, measurement gaps, publication conflicts and sibling-only MY27 carryover remain explicit.',
'Original source data and registered packets remain unchanged. No physical stock, completed order, dealer contact, live publication or overall C1–C6 completion is asserted.'
]
r=dict(schemaVersion=1,checkedAt=D,notes=notes,publishedLists=[],currentVersionReviews=[],listResolutions=[],catalogueOnlyDifferences=[],inventoryResolutions=[])
groups={}
for v in e['variants']:
 if v['availability']['state']=='announced_provisional':continue
 if v['model']=='ID.4' and v.get('modelYear')==2026:continue
 groups.setdefault(v['modelId'],[]).append(v)
for mid,vs in groups.items():
 model=vs[0]['model'];keys=['terms_vw_ev_range','terms_vw_models']+list(dict.fromkeys(k for v in vs for k in v['availability']['sourceKeys']));keys=[k for k in keys if k in src and not src[k].get('access_limitation')]
 review=dict(id=PID+'-'+mid.replace('_','-'),brand='Volkswagen',model=model,bodyStyle='People mover' if model=='ID. Buzz' else 'SUV',vehicleClass='passenger',modelId=mid,checkedAt=D,officialSourceUrls=urls(keys),reason='Exact named Australian versions for this established model-year/body cohort, supported by current maker specifications, current national campaigns and/or exact live New advertisements as stated individually. Physical inventory and accepted orders remain unverified. Other model-year census gaps remain explicitly unresolved rather than inferred absent.',versions=[])
 for v in vs:
  before=old.get(v['id'],{});md=v.get('metadata',{});review['versions'].append(dict(carId=v['id'],model=model,trim=md.get('trim',before.get('trim',v['trim'])),modelYear=md.get('year',before.get('year',v.get('modelYear')))))
 r['currentVersionReviews'].append(review)
 if model=='ID.5' and mid=='volkswagen_id_5_my26':r['inventoryResolutions'].append(dict(kind='record',inventoryId='volkswagen-id-5',outcome='included',modelReviewId=review['id'],reviewedAt=D,reason='Latest maker MY26 Pro/GTX plus separately reviewed exact outgoing New Pro MY25.5 and GTX MY25; generic MY25 Pro advertisements establish no extra distinct sub-year identity. Failed stock pages are retained as limitations, not sold claims.',sourceUrls=list(dict.fromkeys(urls(keys)+urls(['id45_dealer_id5_pro255','id45_stock_id5_gtx25'])))))
for inv,keys,reason in [
 ('volkswagen-id-4',['id45_vw_id4','id45_vw_id4_my27','id45_carsales_id4_gtx26_new','id45_dealer_id4_gtx26'],'Latest MY27 Pro/GTX and exact New MY26 Pro are established. The indexed MY26 GTX New stock 213730 lead remains unresolved because its current source is blocked and dealer candidates failed or redirected; no absence or sold claim is made. Complete residual-model-year membership is not yet proved.'),
 ('volkswagen-id-buzz',['idbuzz_vw_buzz_page','idbuzz_vw_buzz_configurator','idbuzz_carsales_my27_launch','idbuzz_goauto_my27_launch'],'Current MY26 maker configurations, current maker MY25 Pro campaigns and exact MY25 GTX New advertisement are established. Five MY27 versions have explicit July Australian order-open reports but no retrieved current exact official configuration list or clean live New counterpart. Keep their order/arrival evidence provisional and the full-current-list reconciliation unresolved.')]:
 r['inventoryResolutions'].append(dict(kind='record',inventoryId=inv,outcome='unresolved',reviewedAt=D,reason=reason,sourceUrls=urls([k for k in keys if k in src])))
(R/'volkswagen-reconciliation-2026-10-14.json').write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
rec=dict(checkedAt=D,scope='Full Volkswagen brand model/body/version reconciliation, not whole-market C1 closure',notes=notes,termsAndDirectories=with_urls(e['familyNotes']['terms']),familyReconciliations={k:with_urls(v) for k,v in e['familyNotes'].items() if k!='terms'},currentVersionReviews=r['currentVersionReviews'],inventoryResolutions=r['inventoryResolutions'])
(R/'brand-model-list-reconciliation.json').write_text(json.dumps(rec,indent=2,ensure_ascii=False)+'\n')
print(len(r['currentVersionReviews']),'complete cohort reviews;',len(r['inventoryResolutions']),'inventory resolutions; unresolved ID.4 and ID. Buzz explicit')
