# Volkswagen Australian M1 research review

Checked 14 October 2026. This is a guarded integration candidate, not a registered packet or a claim that M1 is complete. Original source data and registered brand packets remain immutable. The bounded public research pass is exhausted; the precise unresolved census questions stay open while the useful labelled data is delivered.

## Current and provisional scope

Eighteen exact versions are retained in the candidate, eleven newly added. Thirteen meet the on-sale report denominator:

- ID.4 Pro and GTX MY27, plus an outgoing advertised-New Pro MY26
- ID.5 Pro and GTX MY26, plus advertised-New Pro MY25.5 and GTX MY25
- ID. Buzz Pro SWB, Pro LWB and GTX LWB MY26
- ID. Buzz Pro SWB and Pro LWB MY25 under current official October–December campaigns, plus an advertised-New GTX LWB MY25

Five additional MY27 ID. Buzz versions, Pro SWB/LWB, Pro+ SWB/LWB and GTX LWB, are retained as announced/provisional with reported advertised order opening. Australian launch reporting on 29 July says orders opened then, with September expected arrivals; CarsGuide reported Q4. Actual arrival and a current exact maker configuration list remain unverified. The buyer label is Order open or arriving, without a stock or accepted-order promise. These five are excluded from the on-sale coverage denominator.

Current official MY25 ID. Buzz Pro campaigns are evidence of current advertised sale, even though their New-or-Demo, while-stocks-last conditions do not establish a surviving exact New VIN. Their stock status remains unverified. MY25 GTX has a live Macgregor New advertisement. ID.4 Pro MY26 has a live Southern Volkswagen New advertisement; ID.5 Pro MY25.5 and GTX MY25 have live Autosports and Wakeling New advertisements. None has been physically inspected, reserved or ordered.

Two census issues remain explicit in the typed reconciliation:

1. The five MY27 ID. Buzz order-open reports have no retrieved current exact official manufacturer list. Current maker configuration and campaigns still expose MY25/MY26
2. An indexed New MY26 ID.4 GTX lead, stock 213730, has a blocked current origin; alternate exact dealer candidates failed or redirected. It is unresolved, not described as sold or unavailable. A complete MY26 residual cohort review is withheld, including the known Pro's C1 membership, rather than declaring that cohort closed

Both full independent brand directories are transcribed and reconciled: CarExpert has 15 current and four discontinued entries; CarsGuide has 17 current and 30 older entries. All 66 entries have source-bound dispositions. They reconcile to ID.4, ID.5 and passenger ID. Buzz as current Tier 1 BEV families. These mixed-powertrain Volkswagen-only lists do not count as the two complete Australian-market C1 lists. ID. Buzz Cargo and e-Transporter remain Tier 2 and are unchanged. No overseas ID.3/ID.7/e-Golf/e-up or prospective electric Amarok is inferred into the current Australian catalogue.

## Facts and prices

All 306 core cells across the eighteen records have earned reviews: 169 Confirmed, eight Check, 123 Reported and six Not published. For the thirteen on-sale versions, all 221 core cells are reviewed: 159 Confirmed, eight Check, 48 Reported and six Not published. The six genuine gaps are exact 10–80% charging durations for both latest ID.4s, both latest ID.5s and both outgoing ID.5s. The outgoing ID.4 Pro MY26 has an explicit 28-minute 10–80% figure from an Australian review, graded Reported.

The price ladder selects the current national maker campaigns ahead of reported list prices. ID.4 Pro MY26, Pro MY27 and GTX MY27 are A$64,990, A$65,990 and A$75,990 driveaway from, respectively. ID. Buzz MY25 Pro SWB/LWB are A$77,990/A$84,990 and MY26 Pro SWB/LWB A$79,990/A$84,990 driveaway from. All preserve private-buyer, exact model-year, stock, paint/options and delivery-by-31-December conditions. The MY26 Buzz GTX uses the explicitly retained A$117,216 NSW-postcode-2000 manufacturer configurator quote, checked 10 October, with its location/build condition. Neither the user's location nor a freshly fetched quote is implied.

Remaining ID.5 and MY25 Buzz GTX prices are secondary reported before-on-road-costs figures. The five MY27 Buzz prices remain Reported. MY27 Pro LWB uses the exact current guide's A$80,990 while retaining the Carsales launch article's A$79,990 discrepancy; no vote across publications is used to erase that conflict. MY27 ID.4 reported list prices A$60,990/A$70,990 stay as alternative source observations because a current maker national campaign is a higher ladder rung.

Important technical distinctions remain visible:

- Current ID.4 MY27 Pro/GTX usable batteries are 79/77 kWh; ID.5 MY26 Pro/GTX are 77/79 kWh. Technical PDF columns were visually checked
- An older maker ID.4 Pro 22-minute charging claim is paired with an 82 kWh/544 km specification. It is not transferred to the changed MY27 battery
- ID.5 MY26 braked towing is Reported at the exact Carsales table's 1,200/1,400 kg, with CarsGuide's 1,000/1,800 kg alternative retained. No hill-gradient explanation is invented
- Exact maker occupied-seat luggage figures are Confirmed, while unidentified methods/load boundaries remain unranked. Buzz SWB is 1,121 L with the second row up; LWB is 306 L with the third row up. Folded-row values are not sold as seven-seat boot capacity
- Nominal maker braked capacities are Confirmed with genuine-towbar and vehicle-mass qualifications. This does not claim the towbar is fitted
- Buzz brochure display-size and folded-cargo discrepancies stay in source notes. The literal 207/211/212 values under a kWh/100 km heading are not silently converted or normalized
- MY27 bidirectional charging is reported as pending Australian testing. No working V2L capability is claimed

## Ownership and equipment

Three inherited maker terms cover all eighteen reviewed Tier 1 records: five-year/unlimited-kilometre vehicle cover, eight-year/160,000 km battery cover with a below-70% usable-capacity trigger, and two years of included roadside. Taxi/ride-share/hire-car mileage limits, warranty commencement, maintenance/exclusions and conditional roadside service renewals remain disclosed. The higher battery restoration levels are not mislabelled as separate claim thresholds. The current EV-specific roadside policy takes precedence over generic one-year FAQ copy; the policy's March applicability heading and January slug/footer discrepancy are preserved.

The packet contains 675 guarded fact edits, three shared terms, 370 guarded equipment replacements and eighteen supported strength/trade-off pairs. Optional HUD/roof/camping packages keep optional fitment separately from source grade. Additional reported Pro+ wheel, trim, power-seat, parking and cargo-equipment claims are retained as canonical facts when no existing matching buyer feature row exists; the packet does not invent new feature criteria.

MY26 retained evidence is dated honestly. Original complete browser captures could not be recovered. Eight clearly labelled derived files and a 43-assertion map preserve inspectable excerpts from the immutable admitted fact ledger, including the GTX quote and exact wireless integration, nine-speaker, heating, camera and door assertions. Original capture hashes remain archived metadata and are not claimed to have been locally reverified. Pro optional-HUD/Harman/roof and GTX HUD claims additionally cite the current maker-linked brochure's actual option/grade columns. A no-option equipment list is not treated as proof of optional availability.

Historical populated per-configuration facts that were not rewritten remain at their original dates/scopes. The audit lists them explicitly. In particular, the earlier selected-paint/configuration equipment booleans are not relabelled as fresh base-grade findings.

## Validation and completion limits

The initial staging harness accidentally compared all Volkswagen records, including two unchanged Cargo versions, against the seven Tier 1 before records and exited 137 without a usable diagnostic. The corrected harness filters Tier 1 and separately asserts other brands and Tier 2 unchanged. Subsequent imports validate normally. One later ordinary validation rejected an invalid researcher status string on reported pending-V2L rows; those rows were normalized to the valid conditional status while preserving the pending-functionality statement. No guard was weakened.

Final self-staging runs with a 3,072 MB Node heap cap and explicit reuse of the existing research/catalogue snapshot in report loading. It checks all before states, sources, identity changes, facts, feature dependencies, actual detail-pack replay, citable source/grade parity, included roadside, portable equality, unchanged inputs and unchanged other brands/Tier 2. A full production build or clean aggregate test suite is not claimed by this research pass; root integration checks are separate.

Research completion deliberately remains false because of the two census issues. Strict criteria are C1 false, C2 false, C3 true, C4 true, C5 false and C6 true. There are no unreviewed on-sale core cells, unsupported summary pairs or aged/invalid claims in the staged report. Price/seat/source grades and unidentified cargo methods keep ranking coverage honest. A completed bounded source pass is distinct from strict current-list and coverage closure.

## Artifacts

The dated packet and typed reconciliation are accompanied by core-matrix.json, full brand-model-list-reconciliation.json, source-index.json, source-hash-manifest.json, artifact-hash-manifest.json, retained-ledger proof, redaction-audit.json, evidence-completeness-audit.json, staged reports/packs and integration-readiness.json. Saved factual captures exclude cookies, headers, script/session/challenge/CSRF/client-secret state; public facts, URLs and relevant product/stock identifiers are retained.
