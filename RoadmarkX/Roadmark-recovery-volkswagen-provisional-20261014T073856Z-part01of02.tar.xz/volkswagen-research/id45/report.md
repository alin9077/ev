# Volkswagen ID.4 / ID.5 Australian evidence, 14 October 2026

## Result

Seven identities are supported for integration: four latest exact maker versions, plus three outgoing identities with freshly retrieved, clean New advertisements. The initial live Roadmark snapshot contains the four latest versions only.

| Version | Selected price | Rung / grade | WLTP km | Usable kWh | DC / AC kW |
|---|---:|---|---:|---:|---:|
| ID.4 Pro MY27 | A$65,990 driveaway from | 2 / Check | 546 | 79 | 175 / 11 |
| ID.4 GTX MY27 | A$75,990 driveaway from | 2 / Check | 522 | 77 | 175 / 11 |
| ID.5 Pro MY26 | A$62,990 before on-road costs | 5 / Reported by carsales | 544 | 77 | 175 / 11 |
| ID.5 GTX MY26 | A$72,990 before on-road costs | 5 / Reported by carsales | 526 | 79 | 175 / 11 |
| ID.4 Pro MY26 residual | A$64,990 driveaway from | 2 / Check | 547 Reported* | 77 Reported | 175 / 11 Reported |
| ID.5 Pro MY25.5 residual | A$62,990 before on-road costs | 5 / Reported by CarExpert | 543 Reported | 77 Reported | 175 / 11 Reported |
| ID.5 GTX MY25 residual | A$72,990 before on-road costs | 5 / Reported by CarExpert | 522 | 79 | 175 / 11 |

Unqualified technical values above are Confirmed from the corresponding AU maker brochure. Generic lab/build notes do not reduce those grades. ID.4 campaign restrictions: private buyers, white vehicles, purchase from 1 October 2026 and delivery by 31 December, while stocks last, options/metallic paint extra, not combined with other offers. *Carsales MY26 structured row says 547 km, while its March review and older launch material say 544 km; this is retained as a Reported conflict.

GoAuto's 9 October report confirms MY27 ID.4 reported list prices A$60,990 / A$70,990, up A$1,000. These are stored as alternative price evidence only: maker national driveaway at rung 2 outranks secondary list pricing at rung 5. No primary exact before-ORC RRP was recovered. ID.5 July–September offers are expired and are not selected.

## New residual stock reconciliation

- ID.4 Pro MY26: Southern Volkswagen stock 204474, VIN WVGZZZE22TE026680, 20 km, New, A$65,890 driveaway; maker's current MY26 A$64,990 campaign is selected instead
- ID.5 Pro MY25.5: Autosports stock F516066, VIN WVGZZZE29SP516066, 25 km, New, A$66,880 driveaway; dealer explicitly says MY25.5 and July 2025 build/compliance
- ID.5 GTX MY25: Wakeling stock 415723, VIN WVGZZZE20SP512021, New, now A$73,990 driveaway (prior 10 October snapshot A$76,990)
- ID.5 Pro generic MY25: Kevin Dennis stock V516334, VIN WVGZZZE28SP516334, remains advertised New at A$68,032. This does not distinguish MY25.0 from MY25.5. No additional distinct identity is established; it is not dismissed as sold or unavailable
- ID.4 Pro MY25/MY25.5: Alto OAG-AD-26295090 has New category but comments simultaneously say MY25.5, MY26 and Demonstrator; exclude that specimen from clean New proof. Sime MY25 vehicle URL now redirects to generic stock
- ID.4 GTX MY25/MY25.5: former Alto North Shore New URL now returns generic stock; Castle Hill MY25.5 lead explicitly describes a demo
- ID.4 GTX MY26: carsales indexed stock 213730 is advertised New with 15 km, but direct retrieval is 403; Osborne Park candidate is 404 and Alto candidate redirects to generic stock. Retain as a search-only new-stock lead, not fresh direct stock proof. This does not establish that no new MY26 GTX supply exists
- ID.5 GTX MY25.5: expired offers and a used/demo MY25.5-versus-MY26 conflicting ad are insufficient for a new distinct residual identity
- ID.5 GTX MY26: maker current listing verified. Rex Gorell indexed New stock 215464 URL again redirects to generic stock on live retrieval

All stock statements describe advertisements. No physical inventory, dealer contact or order acceptance was verified.

## Core facts and gaps

All 17 requested core keys exist on each of the seven normalized records. Seats are 5 at Reported because the AU technical brochures do not explicitly state total seat count; exact Australian secondary/dealer tables do. Vehicle and battery warranty are Confirmed maker brand terms: 5 years/unlimited km; 8 years/160,000 km battery with 70% retained-capacity threshold. Staged warranty remedies remain in the saved terms source.

Only ID.4 Pro MY26 has an admitted explicit 10–80% duration: approximately 28 minutes, Reported by carsales' Australian review. The other six exact time fields remain Not published after the maker brochure/model page plus Australian source check. Do not turn the maker's generic “to 80% in 30 minutes” sentence into 10–80%. The maker walkthrough explicitly says approximately 22 minutes for the older ID.4 Pro paired with an 82 kWh/544 km specification; it must not be carried to the MY27 Pro's changed 84/79 kWh battery. It describes ID.5 GTX as sharing fast-charging capabilities but does not independently time that car. Foreign-market charging curves, station powers and estimates were not imported.

ID.4 MY27 braked towing is Reported at Pro 1,000 kg / GTX 1,800 kg from exact RedBook indexed rows (direct origin 403). ID.5 MY26 is Reported at carsales' exact 1,200 / 1,400 kg. CarsGuide 2026 disagrees at 1,000 / 1,800 kg. Both are retained, with a dealer checklist item. No gradient explanation is inferred.

Cargo values are maker Confirmed with rear seats upright/folded, but the measurement method is unstated. Never relabel as VDA. Maker width likewise does not expressly state mirror inclusion. ID.4 MY27's 2,139 / 2,311 kg tare figures are explicitly worldwide heaviest-equipment figures; not normalized into delivered AU kerb weight.

## Equipment and meaningful year changes

Current Pro and GTX have adaptive dampers, matrix headlights, front-seat heating/memory/massage, fixed panoramic roof, wireless smartphone charging, wired/wireless CarPlay and Android Auto, power tailgate, Mode 2 + Mode 3 cables, and 360-degree cameras. GTX adds AWD, 250 kW, 20-inch Ystad alloys, sport seats and Harman Kardon audio; Pro is 210 kW RWD with 19-inch Hamar alloys and seven-speaker audio.

MY27 ID.4 adds Innovision satellite navigation, revised steering wheel with regenerative-braking paddles, Driving Experience “Atmospheres”, dynamic traffic-sign display, front cross-traffic assistance and predictive speed limiter. Physical steering-wheel buttons are separately reported by GoAuto. Original MY25 brochure lists wired App-Connect; the MY25.5/26 sheets explicitly add wireless projection. Current ID.5 MY26 still uses Ready2Discover and touch steering controls. Do not transfer overseas V2L, app remote control or battery preconditioning features without AU evidence.

MY27 Pro's usable battery rises to 79 kWh; current GTX is 77 kWh. Older ID.4 MY25.5 booklet is 77/77. Current ID.5 MY26 is 77/79. Those columns were visually checked in rendered PDF pages.

## Files, source handling and limitations

- evidence.json: normalized variants, per-fact sources, conflicts, stock dispositions, equipment and omissions
- source-index.json: URLs, retrieval status, capture paths and SHA-256 hashes
- captures/: public PDF originals, full visible factual webpage text and rendered PDF verification images
- redactions.json: exclusion log; scripts/styles/noscript, HTML attributes, HTTP headers/cookies and form state were never persisted
- validation.json: required key and source/file-reference checks

No repository writes, account activity, CAPTCHA solving, dealer outreach, publishing, registration or computer tasks occurred. This completes the source-bound ID.4/ID.5 research pass; it is not a claim of complete Australian dealer inventory or global C1 closure. Cached-only leads remain open and clearly distinct from freshly retrieved New advertisements.
