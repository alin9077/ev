import urllib.request,json,hashlib,pathlib,subprocess,datetime,concurrent.futures,re
from html.parser import HTMLParser
ROOT=pathlib.Path('/tmp/volkswagen-research/id45');ROOT.mkdir(exist_ok=True,parents=True)
class Text(HTMLParser):
 def __init__(self):super().__init__();self.skip=0;self.t=[];self.dropped=0
 def handle_starttag(self,tag,attrs):
  if tag in ('script','style','noscript'): self.skip+=1;self.dropped+=1
  if tag in ('p','div','br','tr','li','h1','h2','h3','h4','section'):self.t.append('\n')
 def handle_endtag(self,tag):
  if tag in ('script','style','noscript') and self.skip:self.skip-=1
 def handle_data(self,data):
  if not self.skip:self.t.append(data)
def fetch(s):
 try:
  r=urllib.request.urlopen(urllib.request.Request(s['url'],headers={'User-Agent':'Mozilla/5.0'}),timeout=45);d=r.read();s.update(status=r.status,final_url=r.url,checked_on='2026-10-14')
  if 'application/pdf' in r.headers.get('Content-Type','') or d[:4]==b'%PDF':
   p=ROOT/'captures'/f"{s['key']}.pdf";p.write_bytes(d);t=p.with_suffix('.txt');subprocess.run(['pdftotext','-layout',str(p),str(t)],check=True);s.update(file=str(p),textFile=str(t),sha256=hashlib.sha256(d).hexdigest(),redactions='None: public static PDF')
  else:
   h=Text();h.feed(d.decode('utf-8',errors='replace'));text=re.sub(r'\n[ \t]*\n(?:[ \t]*\n)+','\n\n',''.join(h.t));p=ROOT/'captures'/f"{s['key']}.txt";p.write_text(text);s.update(file=str(p),textFile=str(p),sha256=hashlib.sha256(text.encode()).hexdigest(),redactions=f'{h.dropped} script/style/noscript blocks excluded; all HTML attributes, HTTP headers and cookies excluded. Visible factual text preserved. Original HTML never persisted.')
 except Exception as e:s.update(error=str(e),checked_on='2026-10-14')
 return s
if __name__=='__main__':
 import sys
 ss=json.load(open(sys.argv[1]));out=list(concurrent.futures.ThreadPoolExecutor(max_workers=5).map(fetch,ss));json.dump(out,open(sys.argv[2],'w'),indent=2);print([(s['key'],s.get('status'),s.get('error')) for s in out])
