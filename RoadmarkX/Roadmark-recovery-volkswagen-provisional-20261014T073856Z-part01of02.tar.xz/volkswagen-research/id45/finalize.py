import json,pathlib,hashlib
P=pathlib.Path('/tmp/volkswagen-research/id45');x=json.load(open(P/'evidence.json'))
for i,v in enumerate(x['variants']):
 v['facts']=[f for f in v['facts'] if f['key']!='dc_test_station_kw']
 for f in v['facts']:
  if f['key'] in ['boot_l','max_total_cargo_l','width_mm']:f['comparison']=''
  if v['modelYearLabel'] if 'modelYearLabel' in v else False:
   if v.get('modelYearLabel')=='MY25.5' and f['key']=='dc_charge_time_min':f['sourceKeys']=['dealer_id5_pro255','vw_id5_my26'];f['reason']='Exact MY25.5 10–80% duration absent in inspected exact dealer listing and current related maker sheet; no time inherited from sibling.'
  if f['key']=='price_aud' and f['grade']=='check':f['reason']='Current Australian maker national campaign for this named model year; specific buyer, paint, purchase/delivery and stock restrictions apply.'
 if i<4:
  v['availability']['state']='current_or_order_listed';v['availability']['stockStatus']='new_stock_listed' if i<2 else 'unverified'
 else:v['availability']['state']='outgoing';v['availability']['stockStatus']='new_stock_listed'
 v['availability']['orderStatus']='listed_unconfirmed'
 fs={f['key']:f for f in v['facts']};get=lambda k:fs[k]['value']
 if v['trim']=='GTX':
  v['summary']={'strength':{'label':'Strong AWD performance','text':f"{get('power_kw')} kW AWD and {get('zero_to_100_s')}-second 0–100 km/h acceleration",'keys':['power_kw','drive_type','zero_to_100_s']},'tradeoff':{'label':'Five-seat limit','text':'Five seats means this version cannot carry a larger household in three rows','keys':['seats']}}
 else:
  v['summary']={'strength':{'label':'Range and usable space','text':f"{get('range_km')} km WLTP range and a {get('boot_l')}-litre rear boot with seats upright",'keys':['range_km','boot_l']},'tradeoff':{'label':'Rear-wheel drive only','text':'This rear-wheel-drive version will not meet an all-wheel-drive requirement','keys':['drive_type']}}
for s in x['sources']:
 if s.get('textFile'):
  p=pathlib.Path(s['textFile']);s['textSha256']=hashlib.sha256(p.read_bytes()).hexdigest()
 if s.get('file'):
  p=pathlib.Path(s['file']);s['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
x['visualVerification']['note']='Visually checked ID.4 MY27 page9, ID.5 MY26 page8 and ID.4/ID.5 MY25 page9 technical tables, and both current equipment page5 grids. Battery usable columns: MY27 ID.4 Pro79/GTX77; MY26 ID.5 Pro77/GTX79; MY25 ID.4 Pro77/ID.5 GTX79. All named rows175kWDC and11kWAC. No column reversal.'
x['visualVerification']['captures']=[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in P.glob('captures/*.png') if p.name!='id45_my25_technical_page8.png']
x['limitations'].append('Unspecified luggage measurement methods and width mirror inclusion have empty comparison basis so they are not assigned invented like-for-like ranking groups.')
(P/'normalized-evidence.json').write_text(json.dumps(x,indent=2,ensure_ascii=False));(P/'evidence.json').write_text(json.dumps(x,indent=2,ensure_ascii=False));(P/'source-index.json').write_text(json.dumps(x['sources'],indent=2,ensure_ascii=False));print('Finalized',len(x['variants']),'variants;',sum(len(v['facts']) for v in x['variants']),'facts')
