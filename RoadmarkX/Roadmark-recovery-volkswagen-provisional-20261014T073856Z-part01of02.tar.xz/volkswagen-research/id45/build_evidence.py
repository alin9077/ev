import json, pathlib, hashlib, re, copy
P=pathlib.Path('/tmp/volkswagen-research/id45'); DATE='2026-10-14'
old=json.load(open('/workspace/scratch/586427eef9f2/roadmark-104/data/vw-skoda-cupra-evidence-2026-10-10.json'))
sources=[]
for p in sorted(P.glob('sources[0-9]*.json')):sources+=json.load(open(p))
for s in sources:
 s['publisher']='Volkswagen Australia' if 'www.volkswagen.com.au' in s['url'] else ('carsales' if 'carsales.com.au' in s['url'] else ('RedBook' if 'redbook.com.au' in s['url'] else ('CarsGuide' if 'carsguide.com.au' in s['url'] else s['url'].split('/')[2])))
 s['source_type']='manufacturer' if s['publisher']=='Volkswagen Australia' else ('secondary' if s['publisher'] in ['carsales','RedBook','CarsGuide'] or s['key'].startswith(('goauto','carexpert','autotrader')) else 'dealer')
cache=P/'captures/redbook_search_cache.json'; txt=json.load(open(cache));tf=cache.with_suffix('.txt');tf.write_text(txt)
sources.append(dict(key='redbook_id4_my27_cached',url='https://www.redbook.com.au/cars/details/2026-volkswagen-id-4-pro-e2-auto-my27/SPOT-ITM-699391?Cr=2',title='RedBook exact MY27 Pro and GTX public search excerpts',publisher='RedBook',source_type='secondary_search_cache',file=str(cache),textFile=str(tf),checked_on=DATE,sha256=hashlib.sha256(cache.read_bytes()).hexdigest(),retrieval_method='Public web indexed text; direct origin HTTP 403, not represented as a successful fresh origin fetch',redactions='None: public text only'))
S={s['key']:s for s in sources}

def fact(key,value,source,grade='confirmed',basis='',comparison='',reason='',condition=None,**kw):
 d=dict(key=key,value=value,grade=grade,sourceKeys=source if isinstance(source,list) else [source],basis=basis,comparison=comparison,reason=reason or ('Current Australian maker material names this version; generic test/build caveats are standing notes.' if grade=='confirmed' else 'Published secondary evidence; not a manufacturer-confirmed figure.'),checkedAt=DATE)
 if condition:d['condition']=condition
 d.update(kw);return d

def warranty():return [fact('warranty','5 years / unlimited kilometres','vw_warranty_terms',basis='Manufacturer Australian new-vehicle warranty',comparison='Vehicle warranty'),fact('battery_warranty','8 years / 160,000 km; 70% capacity threshold','vw_warranty_terms',basis='Manufacturer Australian BEV battery warranty',comparison='BEV battery warranty'),fact('warranty_years',5,'vw_warranty_terms'),fact('warranty_km','Unlimited','vw_warranty_terms'),fact('battery_warranty_years',8,'vw_warranty_terms'),fact('battery_warranty_km',160000,'vw_warranty_terms'),fact('battery_retention_pct',70,'vw_warranty_terms')]

def equip(source,gtx=False,my27=False,grade='confirmed'):
 data={
 'passive_unlock':'Keyless Access keyless entry and starting system',
 'front_heated_seats':'Heated, electrically adjustable front seats with memory, thigh support and lumbar massage',
 'heated_steering_wheel':'Heated steering wheel',
 'folding_mirrors':'Electrically adjustable, heated and folding exterior mirrors',
 'phone_contacts':'Bluetooth phone connectivity with contacts display',
 'voice_assistant':'IDA voice assistance',
 'parking_cameras':'Area View front, rear and side cameras for 360-degree view',
 'adas_standard':'Adaptive cruise control with stop/go, Travel Assist, Lane Assist, Front Assist, Side Assist, Rear Traffic Alert, Emergency Assist and Safe Exit Warning',
 'carplay_android_auto':'Wired and wireless Apple CarPlay and Android Auto',
 'app_connectivity':'GoConnect: technical status, vehicle location, recent trips, warnings and dealer communication; five-year complimentary subscription',
 'charging_cable':'Mode 2 domestic three-pin cable and Mode 3 Type 2 cable included',
 'charge_port_operation':'Charging flap remote lock/unlock, push to open',
 'child_seats':'ISOFIX on outer rear seats; three rear top-tether anchors',
 'spare_tyre':'Tyre sealant and 12-volt compressor mobility set',
 'screens_hud':'5.3-inch Digital Cockpit and 12.9-inch infotainment screen; HUD not listed',
 'audio_system':'Harman Kardon: eight speakers plus centre speaker, subwoofer, 480 W and 12-channel amplifier' if gtx else 'Six front/rear speakers plus centre speaker',
 'glass_roof':'Fixed panoramic glass roof with sunblind',
 'power_tailgate':'Electric tailgate with Easy Open and Easy Close',
 'wireless_charging':'Inductive wireless smartphone charging, up to 15 W' if my27 else 'Inductive wireless smartphone charging',
 'storage':'Rear split/fold seat, load-through hatch, variable centre console and rear centre armrest',
 'home_charging':'11 kW maximum AC acceptance; Type 2 inlet',
 'battery_chemistry':'Lithium-ion; specific cathode chemistry not published in AU sheet',
 }
 if my27:
  data['navigation_route_planner']='Integrated satellite navigation in Innovision; charging-stop route planning is not specified'
  data['driver_alerts']='Dynamic road-sign display, front cross-traffic assistance and predictive speed limiter'
 else:data['driver_alerts']='Advanced driver-attention/drowsiness monitor and front/rear seat-belt warnings'
 return [dict(criterion=k,value=v,grade=grade,sourceKeys=[source],reason='Exact Australian equipment-grid entry' if grade=='confirmed' else 'Explicit sibling-year carry from Australian maker sheet; exact outgoing-year equipment must be checked') for k,v in data.items()]

variants=[]
for i,r in enumerate(old['records'][:4]):
 sp=r['specifications'];v4=r['family']=='ID.4';gtx=r['grade']=='GTX';src='vw_id4_my27' if v4 else 'vw_id5_my26';year=2027 if v4 else 2026
 v=dict(id=f"volkswagen_id_{'4_my27' if v4 else '5_my26'}__{'gtx' if gtx else 'pro'}__20261010",modelId=f"volkswagen_id_{'4_my27' if v4 else '5_my26'}",model=r['family'],trim=r['grade'],modelYear=year,generation=f'MY{year%100} Australian specification',drive='AWD' if gtx else 'RWD',vehicleClass='passenger',role='latest_manufacturer_specification',facts=[],features=equip(src,gtx,v4))
 f=v['facts'];f.extend(warranty())
 mp={'range_km':('range_wltp_km','WLTP combined','WLTP combined'),'battery_kwh':('battery_usable_kwh','Usable battery capacity','Usable battery capacity'),'battery_gross_kwh':('battery_gross_kwh','Gross battery capacity','Gross battery capacity'),'dc_peak_kw':('dc_charge_peak_kw','Maximum vehicle DC acceptance','Maximum vehicle DC acceptance'),'ac_kw':('ac_charge_max_kw','Maximum onboard AC acceptance','Maximum onboard AC acceptance'),'zero_to_100_s':('zero_to_100_s','0–100 km/h','0–100 km/h'),'power_kw':('power_kw','Maximum system power','Maximum system power')}
 for k,(sk,b,c) in mp.items():f.append(fact(k,sp[sk]['value'],src,basis=b,comparison=c))
 for k in ['length','width','height','wheelbase','ground_clearance']:f.append(fact(k+'_mm',sp['dimensions_mm']['value'][k],src,basis='Maker dimensions; width mirror inclusion unspecified' if k=='width' else 'Maker dimension',comparison='Maker width; mirror basis unspecified' if k=='width' else k.title()))
 f.append(fact('boot_l',sp['rear_cargo_l']['value'][0],src,basis='Rear seats upright; measurement method not stated',comparison='Rear seats upright; maker method unspecified'))
 f.append(fact('max_total_cargo_l',sp['rear_cargo_l']['value'][1],src,basis='Rear seats folded; measurement method not stated',comparison='Rear seats folded; maker method unspecified'))
 f.append(fact('drive_type',v['drive'],src,basis='Driven wheels',comparison='Driven wheels'))
 f.append(fact('dc_charge_time_min',None,[src,'vw_id4_gtx' if v4 and gtx else ('vw_id4' if v4 else ('vw_id5_gtx' if gtx else 'vw_id5'))],grade='not_published',basis='Exact 10–80% state-of-charge interval',reason='Exact AU brochure omits a 10–80% time; live model page says to 80% without a start level. Older 22-minute/82 kWh ID.4 claim and overseas times are not transferred.'))
 f.append(fact('dc_test_station_kw',None,src,grade='not_published',reason='No exact timed 10–80% test-station rating published; vehicle maximum is not a station rating.'))
 ssrc='redbook_id4_my27_cached' if v4 else ('carsales_id5_gtx26' if gtx else 'carsales_id5_pro26')
 f.append(fact('seats',5,ssrc,grade='reported',basis='Seating capacity',comparison='Seating capacity'))
 tow=(1800 if gtx else 1000) if v4 else (1400 if gtx else 1200)
 f.append(fact('towing_braked_kg',tow,ssrc,grade='reported',basis='Published braked capacity',comparison='Braked towing',reason='Exact Australian MY27 RedBook structured row; direct origin blocked, indexed public excerpt retained.' if v4 else 'Exact carsales MY26 structured row selected; CarsGuide gives a conflicting figure.',condition=None if v4 else f"CarsGuide 2026 table instead lists {1800 if gtx else 1000} kg. Ask dealer for the exact vehicle rating and compatible towbar; no gradient basis inferred."))
 if v4:
  f.append(fact('price_aud',75990 if gtx else 65990,'vw_id4_gtx' if gtx else 'vw_id4',grade='check',basis='Maker’s national driveaway from',comparison='Driveaway',priceRung=2,validUntil='2026-12-31',reason='Highest available ladder rung: maker national campaign outranks reported list price.',condition='New MY27 vehicles in white, private buyers, purchased 1 October–31 December 2026 and delivered by 31 December; options/metallic paint extra, stock-limited, excludes other offers.'))
  v['alternativePrices']=[dict(value=70990 if gtx else 60990,basis='Before on-road costs, reported by GoAuto',grade='reported',priceRung=5,sourceKeys=['goauto_id4_my27'],selected=False)]
 else:
  f.append(fact('price_aud',72990 if gtx else 62990,ssrc,grade='reported',basis='Reported by carsales; price when new before on-road costs',comparison='Before on-road costs',priceRung=5,reason='No current exact maker list/configurator price or unexpired ID.5 national offer found; July–September campaign has expired.'))
 v['availability']=dict(state='on_sale_now',sourceKeys=[src,'vw_ev_range']+(['stock_id4_gtx27' if gtx else 'id4_pro27_epping'] if v4 else []),reason='Current Australian maker range and named specification; exact new advertised stock also recovered for ID.4.',qualifications=['Public order/stock listing evidence only; no physical inspection or completed order.'])
 v['summary']=dict(strength=('250 kW AWD and 5.4-second acceleration, with adaptive dampers and Harman Kardon audio' if gtx else f"{sp['range_wltp_km']['value']} km WLTP range with adaptive dampers, a panoramic roof and massaging front seats"),tradeoff=(f"{sp['range_wltp_km']['value']} km WLTP range is lower than the Pro, and the GTX costs more" if gtx else 'Rear-wheel drive and 6.7-second acceleration trade outright pace for the lower price'))
 variants.append(v)

# Outgoing stock supported by fresh public NEW advertisements. Generic MY25 Pro ad is not an additional distinct subyear.
def residual_base(model,trim,year,subyear,source):
 slug=f"volkswagen_id_{model[-1]}_my{str(subyear).replace('.','_')}";v=dict(id=slug+'__'+trim.lower()+'__20261014',modelId=slug,model=model,trim=trim,modelYear=year,modelYearLabel='MY'+str(subyear),generation='Outgoing Australian '+str(subyear)+' specification',drive='AWD' if trim=='GTX' else 'RWD',vehicleClass='passenger',role='advertised_new_residual',facts=warranty(),features=[],availability=dict(state='on_sale_now',sourceKeys=[source],reason='Fresh direct dealer advertisement explicitly marked New with public VIN and stock ID.',qualifications=['Advertised New, not physically verified. Availability and remaining warranty need dealer confirmation.']))
 return v
v=residual_base('ID.4','Pro',2026,26,'dealer_id4_pro26');src='carsales_id4_pro26';f=v['facts'];f.append(fact('price_aud',64990,'vw_id4',grade='check',basis='Maker’s national driveaway from',comparison='Driveaway',priceRung=2,validUntil='2026-12-31',condition='New MY26 Pro in white; private buyers; purchased 1 October and delivered by 31 December 2026; options/metallic paint extra, stock-limited, excludes other offers.'))
vals={'range_km':547,'battery_kwh':77,'battery_gross_kwh':82,'dc_peak_kw':175,'dc_charge_time_min':28,'ac_kw':11,'seats':5,'boot_l':543,'max_total_cargo_l':1575,'zero_to_100_s':6.7,'power_kw':210,'drive_type':'RWD','length_mm':4585,'width_mm':1852,'height_mm':1640,'wheelbase_mm':2766,'towing_braked_kg':1000}
for k,val in vals.items():
 ss='carsales_id4_pro_review26' if k in ['battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw'] else src
 b={'range_km':'WLTP combined','battery_kwh':'Usable battery capacity','battery_gross_kwh':'Gross battery capacity','dc_charge_time_min':'10–80% state of charge, approximately','boot_l':'Rear seats upright; measurement method unstated','max_total_cargo_l':'Rear seats folded; measurement method unstated','towing_braked_kg':'Braked towing','width_mm':'Width; mirror basis unspecified'}.get(k,'Published specification')
 f.append(fact(k,val,ss,'reported',b,b,condition='Exact MY26 structured table says 547 km; March 2026 carsales review and older launch material say 544 km.' if k=='range_km' else None))
v['features']=equip('vw_id4_my255',False,False,'reported');v['summary']=dict(strength='A lower-priced outgoing ID.4 with 77 kWh usable battery and a 543-litre rear boot',tradeoff='Older infotainment and touch steering controls; MY27 adds integrated navigation and additional driver assistance');v['stock']={'sourceKey':'dealer_id4_pro26','stockId':'204474','VIN':'WVGZZZE22TE026680','odometerKm':20,'advertisedPrice':65890,'priceBasis':'Driveaway'};variants.append(v)

v=residual_base('ID.5','Pro',2025,25.5,'dealer_id5_pro255');f=v['facts'];f.append(fact('price_aud',62990,'carexpert_id5_review26','reported','Reported Australian list price before on-road costs','Before on-road costs',priceRung=5,reason='CarExpert 2026 review explicitly prices 2025 ID.5 Pro at $62,990 before on-road costs; higher ladder rung than a dealer ad.'))
vals={'range_km':543,'battery_kwh':77,'battery_gross_kwh':82,'dc_peak_kw':175,'dc_charge_time_min':None,'ac_kw':11,'seats':5,'boot_l':549,'max_total_cargo_l':1561,'zero_to_100_s':6.7,'power_kw':210,'drive_type':'RWD','length_mm':4599,'width_mm':1852,'height_mm':1621,'wheelbase_mm':2766,'towing_braked_kg':1200}
for k,val in vals.items():
 ss='dealer_id5_pro255' if k in ['seats','zero_to_100_s','power_kw','drive_type','length_mm','width_mm','height_mm','wheelbase_mm','towing_braked_kg'] else ('vw_id5_my26' if k=='battery_gross_kwh' else 'carexpert_id5_review26')
 f.append(fact(k,val,ss,'not_published' if val is None else 'reported',{'range_km':'WLTP combined','battery_kwh':'Usable capacity','battery_gross_kwh':'Gross capacity; MY26 sibling carry','boot_l':'Rear seats upright; method unspecified','max_total_cargo_l':'Rear seats folded; method unspecified','towing_braked_kg':'Braked towing','dc_charge_time_min':'Exact 10–80% interval'}.get(k,'Published specification'),reason='Exact MY25.5 10–80% duration not found in dealer listing or maker sheet; no time inferred.' if val is None else ('MY26 sibling maker gross capacity carried at Reported; exact residual battery check required.' if k=='battery_gross_kwh' else 'Public dealer specification or Australian model review; exact MY25.5 maker sheet not recovered.')))
v['features']=equip('vw_id5_my26',False,False,'reported');v['stock']={'sourceKey':'dealer_id5_pro255','stockId':'F516066','VIN':'WVGZZZE29SP516066','odometerKm':25,'advertisedPrice':66880,'priceBasis':'Driveaway','buildDate':'2025-07','complianceDate':'2025-07'};v['summary']=dict(strength='543 km reported WLTP range with a coupe-style body and 549-litre boot',tradeoff='No MY27 infotainment update; exact outgoing equipment and charging time need checking');variants.append(v)

v=residual_base('ID.5','GTX',2025,25,'stock_id5_gtx25');f=v['facts'];src='vw_id45_my25';f.append(fact('price_aud',72990,'carexpert_id5_review26','reported','Reported Australian list price before on-road costs','Before on-road costs',priceRung=5,reason='2026 CarExpert review gives 2025 ID.5 GTX price before on-road costs; expired maker campaign is not applied.'))
vals={'range_km':522,'battery_kwh':79,'battery_gross_kwh':84,'dc_peak_kw':175,'ac_kw':11,'boot_l':549,'max_total_cargo_l':1561,'zero_to_100_s':5.4,'power_kw':250,'drive_type':'AWD','length_mm':4584,'width_mm':1852,'height_mm':1607,'wheelbase_mm':2769}
for k,val in vals.items():f.append(fact(k,val,src,basis={'range_km':'WLTP combined','battery_kwh':'Usable capacity','battery_gross_kwh':'Gross capacity','boot_l':'Rear seats upright; measurement method unstated','max_total_cargo_l':'Rear seats folded; measurement method unstated'}.get(k,'Maker specification'),comparison={'range_km':'WLTP combined','boot_l':'Rear seats upright; maker method unspecified'}.get(k,''),reason='Official AU MY25 brochure explicitly names ID.5 GTX; generic build/laboratory notes do not lower grade.'))
f.append(fact('seats',5,'stock_id5_gtx25','reported','Seats','Seating capacity'));f.append(fact('towing_braked_kg',1400,'stock_id5_gtx25','reported','Braked towing','Braked towing',condition='Dealer structured specification; confirm exact vehicle/towbar rating.'))
f.append(fact('dc_charge_time_min',None,[src,'vw_id45_walkthrough'],'not_published','Exact 10–80% interval',reason='MY25 brochure omits duration. Maker walkthrough explicitly times ID.4 Pro, while only describing ID.5 GTX as sharing fast-charging capabilities; no exact ID.5 time inferred.'))
v['features']=equip(src,True,False)
for a in v['features']:
 if a['criterion']=='carplay_android_auto':a['value']='USB-C App-Connect for Apple CarPlay and Android Auto; MY25 brochure does not list wireless projection'
v['stock']={'sourceKey':'stock_id5_gtx25','stockId':'415723','VIN':'WVGZZZE20SP512021','advertisedPrice':73990,'priceBasis':'Driveaway'};v['summary']=dict(strength='250 kW AWD, 5.4-second acceleration and Harman Kardon audio in an advertised-new outgoing model',tradeoff='522 km WLTP range and older infotainment; wireless phone projection depends on the specific build');variants.append(v)

conflicts=[
 {'key':'id4_battery_years','claim':'MY27 Pro 84/79 and GTX 82/77; MY25.5 Pro/GTX 82/77; MY26 GTX ads/secondary show84 gross. Do not share rows across MY.','sourceKeys':['vw_id4_my27','vw_id4_my255','carsales_id4_gtx26_new']},
 {'key':'id5_range_live_vs_pdf','claim':'MY26 PDF Pro544/GTX526 controls. Unversioned live Pro page repeats543 and522; older MY25 GTX522 is separate.','sourceKeys':['vw_id5_my26','vw_id5','vw_id5_gtx','vw_id45_my25']},
 {'key':'id5_brochure_publication_code','claim':'Current linked ID5 file is explicitly planned September2025 for MY2026 despite stale VWPID5MY25.5 footer code. Applicability statement controls.','sourceKeys':['vw_id5_my26']},
 {'key':'id5_towing','claim':'carsales exactMY26 structured rows Pro1200/GTX1400 versus CarsGuide2026 Pro1000/GTX1800. Maker AU brochures omit towing. Keep Reported, do not infer gradient-based reconciliation.','sourceKeys':['carsales_id5_pro26','carsales_id5_gtx26','carsguide_id5_towing26']},
 {'key':'id4_my26_range','claim':'Exact MY26 carsales/RedBook structured claim547; Australian March2026 carsales review544. Selected547 Reported, conflict retained.','sourceKeys':['carsales_id4_pro26','carsales_id4_pro_review26']},
 {'key':'roadside','claim':'Specific current roadside page says24months for BEVs other than eTransporter; generic warranty page and FAQ sayone year. Parent brand terms research should select specific current scope and retain conflict.','sourceKeys':['vw_roadside','vw_warranty']},
 {'key':'id4_my27_tare','claim':'Maker2139/2311kg explicitly heaviest model worldwide, all possible equipment. Not Australian delivered kerb weights.','sourceKeys':['vw_id4_my27']},
 {'key':'cargo_method','claim':'Maker defines rear-seat upright/folded loading but does not nameVDA/ISO. Confirmed values must remain in maker-method-unspecified ranking group.','sourceKeys':['vw_id4_my27','vw_id5_my26','vw_id45_my25']},
 {'key':'id4_gtx27_colour','claim':'Alto structured colourMoonstone Grey/Black Roof conflicts with GLACIER WHITE comments; exactMY27/GTX identity stays, colour not normalized.','sourceKeys':['stock_id4_gtx27']},
]
residual=[
 dict(identity='ID.4 Pro MY26',decision='admit',sourceKeys=['vw_id4','dealer_id4_pro26'],reason='Current maker MY26 campaign and clean dealer NEW VIN.'),
 dict(identity='ID.5 Pro MY25.5',decision='admit',sourceKeys=['dealer_id5_pro255'],reason='Dealer explicitly MY25.5, NEW, VIN and stockID.'),
 dict(identity='ID.5 Pro MY25, subyear unspecified',decision='no_additional_distinct_identity_established',sourceKeys=['stock_id5_pro25'],reason='Live NEW ad V516334/WVGZZZE28SP516334; MY25 could encompass MY25.5. Do not invent an additional MY25.0 record or say new supply is absent.'),
 dict(identity='ID.5 GTX MY25',decision='admit',sourceKeys=['stock_id5_gtx25','vw_id45_my25'],reason='Live NEW ad and exact manufacturer MY25 specification. MY25.5 not inferred from low km or calendar date.'),
 dict(identity='ID.4 Pro MY25/MY25.5',decision='not_confirmed',sourceKeys=['dealer_id4_pro25','dealer_id4_pro25_sime'],reason='Alto NEW category conflicts with comments MY25.5/MY26 and Demonstrator; Sime vehicle URL redirects to generic stock. No clean fresh exact residual identity recovered from these leads.'),
 dict(identity='ID.4 GTX MY25/MY25.5',decision='not_confirmed',sourceKeys=['dealer_id4_gtx25'],reason='Previously indexed NEW dealer URL now returns generic inventory. Other search lead CastleHill explicitly demo; no new MY25.5 identity admitted.'),
 dict(identity='ID.4 GTX MY26',decision='not_confirmed_search_only_new_lead',sourceKeys=['carsales_id4_gtx26_new','dealer_id4_gtx26','dealer_id4_gtx26_alto'],reason='Indexed carsales NEW stock213730/15km but direct source blocked403; OsbornePark vehicle404 and Alto candidate redirects. Do not claim fresh verified dealer NEW listing or infer absence from failed retrieval.'),
 dict(identity='ID.5 GTX MY25.5',decision='not_confirmed',sourceKeys=['vw_id5_gtx'],reason='Former July–September offers do not prove current stock; recovered example was Demo/Used with MY26-vsMY25.5 conflict. No distinct clean NEW identity recovered.'),
 dict(identity='ID.5 GTX MY26 dealer-stock continuation',decision='current_maker_listing_only',sourceKeys=['id5_gtx26_gorell','vw_id5_my26'],reason='RexGorell source is still indexed asNEW but live URL redirects to generic stock. Maker range establishes current version, not physical stock.'),
]
changes=[
 'ID.4 MY27 adds Innovision satellite navigation, revised steering wheel with regenerative-braking paddles, Driving Experience Atmospheres, traffic-sign display, front cross-traffic assistance and predictive speed limiter. Physical steering-wheel buttons specifically reported by GoAuto; brochure shows revised3-spoke controls.',
 'ID.4 MY27 Pro battery84/79 versus older82/77; MY27 rear boot533/1565 versus older543/1575. No cargo-method explanation inferred.',
 'ID.5 MY26 remains older Ready2Discover infotainment, wireless phone projection, touch steering wheel; MY25 original brochure lists wired App-Connect only.',
 'Both current grades have adaptive dampers, matrix headlights, front-seat heating/memory/massage, panoramic fixed roof and360degree cameras. GTX adds AWD,250kW,20inchYstad wheels, sport seats andHarmanKardon; Pro210kW RWD with19inchHamar and7speaker audio.'
]
obj=dict(schema='roadmark_m1_research_v1',asOf=DATE,scope='Australian Volkswagen ID.4/ID.5; four latest exact versions plus three verified residual identities',sources=sources,variants=variants,sourceConflicts=conflicts,residualReconciliation=residual,equipmentChanges=changes,limitations=['No dealer contact, ordering, physical stock check or registration; public read-only research.','No Australian exactMY27 10–80% duration recovered after maker brochure/model page and Australian reporting checks.','ID.5 MY26/25.5 andMY25 GTX exact10–80% times remain unfilled rather than converting partial windows or importing overseas/sibling charge curves.','Current manufacturer exact price search did not recover primary RRP; currentID4 national campaigns selected over reported list prices.','Sources retain factual public text/PDFs only; scripts,HTML attributes,cookies,headers and form state never persisted.'])
(P/'evidence.json').write_text(json.dumps(obj,indent=2,ensure_ascii=False));(P/'source-index.json').write_text(json.dumps(sources,indent=2,ensure_ascii=False));(P/'redactions.json').write_text(json.dumps([{k:s.get(k) for k in ['key','file','redactions','error']} for s in sources],indent=2))
print('Wrote',len(variants),'variants;',len(sources),'sources;',sum(len(v['facts']) for v in variants),'facts')
