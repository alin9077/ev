"""Normalize family evidence into one candidate; fail on ambiguous keys or duplicate edits."""
import json,pathlib,copy
R=pathlib.Path('/tmp/volkswagen-research');D='2026-10-14'
load=lambda p:json.loads((R/p).read_text())
pe={'checkedAt':D,'sources':[],'variants':[],'familyNotes':{}}
gradeMap={'Confirmed':'confirmed','Check':'check','Reported':'reported','Not published':'not_published'}
def norm(o,prefix):
 if isinstance(o,list):return [norm(v,prefix) for v in o]
 if isinstance(o,dict):
  r={k:norm(v,prefix) for k,v in o.items()}
  if 'sourceKeys' in r:r['sourceKeys']=[prefix+x for x in r['sourceKeys']]
  if 'grade' in r:r['grade']=gradeMap.get(r['grade'],r['grade'])
  return r
 return o
for family in ['id45','idbuzz']:
 path=family+'/normalized-evidence.json';orig=load(path);a=norm(orig,family+'_')
 for s in a['sources']:
  s['key']=family+'_'+s['key']
  s.setdefault('title',s.get('url',s['key']))
  if 'maker_my26_' in s['key'] and s['key'].endswith('_prior'):
   s['retrieval']='Derived excerpts from the immutable 10 October admitted fact ledger; not a new fetch or a complete original browser capture.'
   s['derivation']={'ledger':'data/catalogue-additions-2026-10-10.json','sourceIds':s.get('priorSourceIds',[]),'evidenceDate':'2026-10-10','note':'Original complete browser-capture bytes unavailable; exact previously admitted source excerpts remain inspectable in the immutable ledger.'}
  if s.get('error'):
   s['access_limitation']=s['error'];s['supports']='Failed retrieval recorded for audit only; this source establishes no vehicle fact or absence.'
  for key in ['file','textFile']:
   if s.get(key):
    p=pathlib.Path(s[key]);s[key]=str(p if p.is_absolute() else R/family/p)
 pe['sources']+=a['sources'];pe['variants']+=a['variants'];pe['familyNotes'][family]={k:v for k,v in a.items() if k not in ['sources','variants']}
t=norm(load('terms/terms-normalized.json'),'terms_')
for s in t['sources']:
 s['key']='terms_'+s['key']
 for key in ['file','textFile']:
  if s.get(key):
   p=pathlib.Path(s[key]);s[key]=str(p if p.is_absolute() else R/'terms'/p)
pe['sources']+=t['sources'];pe['familyNotes']['terms']=t.get('reconciliation',t.get('notes',[]))
terms=t['terms']
for item in terms.values():
 if item.get('comparison') is None:item['comparison']=''
terms['roadside_assistance']['value']='2 years included'
(R/'terms-normalized.json').write_text(json.dumps(terms,indent=2,ensure_ascii=False)+'\n')
old={c['id']:c for c in load('volkswagen-live-before.json')}
allowedCriteria={f['criterion'] for f in load('volkswagen-feature-before.json')}
for v in pe['variants']:
 if 'variantId' in v:v['id']=v.pop('variantId')
 if 'model_year' in v:v['modelYear']=v.pop('model_year')
 if v['id'] in old:
  b=old[v['id']]
  v['modelId']=b['modelId']
  for k in ['modelId','model','trim','generation','vehicleClass']:
   v.setdefault(k,b.get(k,'passenger' if k=='vehicleClass' else None))
  v.setdefault('modelYear',b['year']);v.setdefault('drive',b['drive'])
  if v['drive']!=b['drive']:v.setdefault('metadata',{})['drive']=v['drive'];v.setdefault('metadataReason','Current exact Australian specification establishes the drivetrain; it replaces a historical unknown without altering model, year or grade.')
 av=v['availability']
 if av['state']=='announced_provisional' and v['model']=='ID. Buzz':
  av['qualifications'].append('First deliveries expected September 2026; reported by Carsales on 29 July 2026, actual arrival still unverified at 14 October 2026. CarsGuide reported Q4; no current maker exact-version list was recovered.')
 if av.get('orderStatus') in ['current_manufacturer_configurator','residual_new_advertised']:av['orderStatus']='listed_unconfirmed'
 facts=v.setdefault('facts',[]);features=v.setdefault('features',[])
 facts[:]=[f for f in facts if f['key'] not in ['warranty','battery_warranty','roadside_assistance']]
 for f in facts:
  if f['key']=='drive_type':f['key']='drive'
  f['grade']=gradeMap.get(f.get('grade','confirmed'),f.get('grade','confirmed'))
  if 'comparison' in f and f['comparison'] is None:f['comparison']=''
  if f['key']=='price_aud' and f['value'] is not None:
   f['comparison']='Driveaway' if 'driveaway' in (str(f.get('comparison',''))+' '+f.get('basis','')).lower() else 'Before on-road costs'
  if f['key']=='range_km' and 'wltp' in str(f.get('basis','')).lower():f['comparison']='WLTP combined'
  if f['key'] in ['boot_l','width_mm'] and any(x in str(f.get('basis','')).lower() for x in ['unspecified','not stated','not specified']):f['comparison']=''
  if f['key']=='seats':f['comparison']='Seats'
  if v['model']=='ID. Buzz' and v.get('modelYear') in [2025,2026] and f['key']=='boot_l':
   if f.get('condition'):f.setdefault('qualifications',[]).append(f.pop('condition'))
   f['grade']='confirmed';f['comparison']='';f['reason']='Current Australian maker brochure explicitly states this occupied-seat luggage figure for the named Pro SWB, Pro LWB or GTX LWB body. The specified seating position defines the figure; an unidentified test/load boundary prevents like-for-like ranking but does not downgrade the maker-published number.'
  if v['model']=='ID. Buzz' and v.get('modelYear') in [2025,2026] and f['key']=='towing_braked_kg':
   if f.get('condition'):f.setdefault('qualifications',[]).append(f.pop('condition'))
   f['grade']='confirmed';f['comparison']='Maximum braked towing';f['basis']='Maximum braked towing with specified genuine towbar; towbar fitment not implied';f['reason']='The named Australian maker technical column publishes the maximum braked trailer rating. Required approved towing equipment and mass/load limits are retained; no documented option changes the stated rating and no fitted-towbar claim is made.'
  if v['model']=='ID. Buzz' and v.get('modelYear')==2025 and f['grade'] in ['confirmed','check'] and f['key'] not in ['price_aud','boot_l']:
   f['reason']='Exact MY25 Australian Volkswagen brochure identifies this figure in the named '+v['trim']+' column; actual policy/fitment conditions remain disclosed where applicable.'

 existing={f['key']:f for f in facts};assert len(existing)==len(facts),v['id']
 used=set()
 summary=v.get('summary',{})
 if 'strengths' in summary:v['summary']={'strength':summary['strengths'][0],'tradeoff':summary['tradeOffs'][0]}
 for clause in v.get('summary',{}).values():
  if isinstance(clause,dict):clause['keys']=['drive' if k=='drive_type' else k for k in clause.get('keys',[])]
 for fr in features:
  if fr['criterion']=='camping_package':fr['criterion']='camp_utility_mode'
  if v['model']=='ID. Buzz' and v.get('modelYear')==2026:
   if fr['criterion'] in ['screens_hud','glass_roof','audio_system']:
    fr['sourceKeys']=list(dict.fromkeys(fr['sourceKeys']+['idbuzz_vw_buzz_page','idbuzz_vw_buzz_my25_pdf']));fr['date']=D
    fr['reason']='The retained 10 October exact configuration establishes admitted standard equipment; current maker-linked brochure named-grade option/HUD columns supply the additional explicitly stated fitment. No absent no-option build row is used as proof of optional availability.'
    if fr['criterion']=='screens_hud' and v['trim'].startswith('Pro'):
     fr['value']='Head-up display with Harman Kardon sound system is an extra-cost option';fr['condition']='Optional Head-up display with Harman Kardon sound system package; not included in the base Pro price'
   if fr['criterion']=='parking_cameras':fr['value']='Area View and front/rear parking sensors'

  if 'keys' in fr:fr['keys']=['drive' if k=='drive_type' else k for k in fr['keys']]
  criterion=fr['criterion'];assert criterion not in used,(v['id'],criterion);used.add(criterion)
  if criterion in ['driveaway_price','roadside_assistance']:continue
  if 'keys' not in fr:
   key='feature_'+criterion;f=dict(key=key,value=None if fr.get('grade')=='not_published' else fr['value'],grade=fr.get('grade','confirmed'),sourceKeys=fr['sourceKeys'],basis='Australian exact-version '+criterion.replace('_',' ')+' evidence',comparison='',reason=fr.get('reason','Reviewed Australian manufacturer equipment evidence identifies this feature for the stated exact version.'),qualifications=fr.get('qualifications',[]))
   if fr.get('date'):f['date']=fr['date']
   if fr.get('condition') or fr.get('conditions'):f['condition']=fr.get('condition',fr.get('conditions'))
   if fr.get('evidenceScope'):f['evidenceScope']=fr['evidenceScope']
   assert key not in existing,(v['id'],key)
   facts.append(f);existing[key]=f;fr['keys']=[key]
  if fr.get('grade')=='not_published':fr['value']='Not published'
  if fr.get('grade') in ['check','reported'] and fr.get('status') in ['standard','unverified','not_verified']:fr['status']='conditional'
 v['additionalFactOnlyCriteria']=[f['criterion'] for f in features if f['criterion'] not in allowedCriteria]
 features[:]=[f for f in features if f['criterion'] not in ['driveaway_price','roadside_assistance'] and f['criterion'] in allowedCriteria]
 def add(criterion,value,keys,**kw):
  if criterion not in used:features.append(dict(criterion=criterion,value=value,keys=keys,**kw));used.add(criterion)
 for criterion,key,suffix in [('storage','boot_l','L rear luggage'),('home_charging','ac_kw','kW maximum AC input'),('performance_rear_motor','power_kw','kW motor output'),('energy_use','energy_use_wh_km','Wh/km published consumption')]:
  f=existing.get(key)
  if f and f['value'] is not None:add(criterion,str(f['value'])+' '+suffix+'; '+f.get('basis',''),[key],conditions=f.get('condition',''))
 if 'warranty_service' not in used:add('warranty_service',terms['warranty']['value'],['warranty'],grade=terms['warranty'].get('grade','confirmed'),conditions=' '.join(terms['warranty'].get('qualifications',[])),evidenceScope='brand_au_terms')
 assert len(set(f['key'] for f in facts))==len(facts),v['id']
assert len({v['id'] for v in pe['variants']})==len(pe['variants'])
assert len({s['key'] for s in pe['sources']})==len(pe['sources'])
(R/'normalized-evidence.json').write_text(json.dumps(pe,indent=2,ensure_ascii=False)+'\n')
print('Merged',len(pe['variants']),'versions,',len(pe['sources']),'sources')
