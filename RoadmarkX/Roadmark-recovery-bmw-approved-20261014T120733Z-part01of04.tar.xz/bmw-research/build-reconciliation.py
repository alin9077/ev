#!/usr/bin/env python3
"""Build draft BMW-only M1 reconciliation without importing or replaying the catalogue.
Inputs are captured research packages and the inherited market inventory. Outputs stay
under /tmp/bmw-research. Brand directories are never promoted to whole-market lists.
"""
import copy
import hashlib
import json
import pathlib
import re
from collections import OrderedDict

ROOT = pathlib.Path('/tmp/bmw-research')
REPO = pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104')
DATE = '2026-10-14'

def read(path):
    return json.loads(path.read_text())

def write(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

packages = {family: read(ROOT / family / 'normalized-evidence.json')
            for family in ['ix', 'compact', 'sedans', 'census']}
census = read(ROOT / 'census/new-families-and-census.json')
inventory = read(REPO / 'data/market-inventory-2026-10-10.json')
before = read(ROOT / 'bmw-live-before.json')
canonical = read(ROOT / 'normalized-evidence.json')
variants = canonical['variants']
assert len(variants) == 15, 'Recheck the expected membership before changing the current reviews'
assert len({v['id'] for v in variants}) == 15
sources = {}
for p in packages.values():
    values = p['sources'].values() if isinstance(p['sources'], dict) else p['sources']
    for s in values:
        sources[s.get('key', s.get('id'))] = s
for s in canonical['sources']:
    sources[s['key']] = s
for s in census['sources']:
    sources.setdefault(s['id'], s)

def urls(*keys):
    result = []
    for key in keys:
        assert key in sources, key
        url = sources[key]['url']
        assert re.match(r'^https?://[^/\s]+(?:/|$)', url), (key, url)
        if url not in result:
            result.append(url)
    return result

# Cohorts are deliberately exact-generation/code/body scopes, never the full residual family.
cohorts = OrderedDict([
 ('bmw_ix_current', dict(body='SUV', keys=['ix_spec', 'ix_config', 'ix_tech'],
   scope='Current Australian I20 xDrive45 M Sport 42CF maker-guide/configurator cohort',
   reason='The current June 2026 Australian guide and exact 42CF configurator establish xDrive45 M Sport for this code-bound cohort. This review does not certify the broader iX family census: older xDrive40/xDrive50/M60 and xDrive60/M70 leads remain unresolved separately.')),
 ('bmw_ix1_current', dict(body='SUV', keys=['ix1-current', 'config-price-22HM', 'sport-collection'],
   scope='Current U11 22HM regular M Sport and separately named Sport Collection offer',
   reason='The June 2026 Australian guide lists regular xDrive30 M Sport 22HM; the current maker offer separately names xDrive30 Sport Collection. Both named current configurations are transcribed. Sport Collection has no verified exact model code and is not equated with 22HM or counted as a separate drivetrain. Earlier eDrive20 and older xDrive30 code cohorts remain open residual-new leads.')),
 ('bmw_ix2_current', dict(body='SUV', keys=['ix2-current', 'config-price-82GN'],
   scope='Current U10 June 2026 Australian 82GN running-update cohort',
   reason='The June 2026 maker guide and exact Australian configurator list xDrive30 M Sport 82GN for this current running-update cohort. Older eDrive20 52GM and xDrive30 72GM residual-new membership remains unresolved; this current-code review does not close those older cohorts.')),
 ('bmw_ix3_na5', dict(body='SUV', keys=['ix3-current', 'config-price-12HR', 'config-price-32HR'],
   scope='NA5 Neue Klasse current Australian 12HR/32HR launch range',
   reason='The current Australian NA5 guide and exact live configurations establish 40 M Sport Package 12HR and 50 xDrive M Sport Package 32HR. M Sport Pro is an optional equipment package, not an extra drivetrain. This complete source-bound NA5 launch list excludes the explicitly future M60 and makes no closure claim for outgoing G08 M Sport/M Sport Pro residual-new stock.')),
 ('bmw_i4_current', dict(body='Liftback', keys=['sedan_bmw_i4_spec', 'sedan_config_52hd_price'],
   scope='Current G26 LCI Australian 52HD eDrive35-only maker range',
   reason='The current Australian maker guide and exact 52HD configurator establish eDrive35 M Sport Package as the current named G26 range. The October 2025 Australian range cull does not prove residual new vehicles are exhausted: older eDrive40/M50 and prior-code eDrive35 leads remain unresolved outside this current guide/code scope.')),
 ('bmw_i5_sedan_current', dict(body='Sedan', keys=['sedan_bmw_i5_spec', 'sedan_bmw_i5_page', 'sedan_i5_technical_metadata'],
   scope='G60 sedan, June 2026 guide applicable from July 2026 production, 62HG/42HG',
   reason='The June 2026 Australian 5 Series Sedan guide applicable from July 2026 production names i5 eDrive40 62HG and M60 xDrive 42HG. This review is restricted to that sedan production cohort. Earlier production/code cohorts and Touring are not silently merged; earlier residual-new availability remains open and current Touring is reviewed separately.')),
 ('bmw_i7_lci', dict(body='Sedan', keys=['sedan_bmw_i7_spec', 'sedan_bmw_i7_page'],
   scope='Arriving G70 LCI Australian 72HY 60 xDrive range, Q4 2026',
   reason='The current Australian facelift guide/model page names 60 xDrive M Sport 72HY for the Q4 2026 arriving cohort. Announced arrival and current listing are not accepted orders or verified physical stock. Outgoing 52EJ xDrive60 and 82EH M70 have a separate unresolved residual-new census and are not covered by this LCI list.')),
 ('bmw_i5_touring_current', dict(body='Wagon', keys=['sedan_config_32hh_tech', 'sedan_config_32hh_standard', 'sedan_config_32hh_price'],
   scope='Current Australian G61 M60 xDrive Touring 32HH',
   reason='The exact live Australian 32HH configurator establishes M60 xDrive Touring as the current named wagon configuration, with a current price and technical/standard-equipment views. Sedan and overseas eDrive40/xDrive40 Touring scopes are separate. This is the source-bound Australian 32HH wagon list, not evidence that all prior-production residual-new units have ceased.')),
 ('bmw_ix4_na7', dict(body='SUV', keys=['bmw-ix4', 'bmw-ix4-tech'],
   scope='Arriving NA7 Australian 40 xDrive/50 xDrive launch range',
   reason='Current Australian maker model/technical content establishes NA7 40 xDrive and 50 xDrive as the named arriving launch range; Australian launch reporting gives Q1 2027. Exact factory-order acceptance and physical new stock are unverified. M60 is explicitly available to order in 2027 and remains a separate future performance scope.')),
 ('bmw_i3_sedan_na0', dict(body='Sedan', keys=['bmw-i3', 'bmw-i3-tech','sedan_i3_32jb_price','sedan_i3_52jb_price'],
   scope='Arriving NA0 Australian i3 Sedan 40 xDrive/50 xDrive launch range',
   reason='Current Australian maker sedan/model technical content establishes NA0 40 xDrive M Sport 32JB and 50 xDrive M Sport 52JB as the named arriving launch range; Australian launch reporting gives Q1 2027. The reused i3 name is explicitly the NA0 sedan, not the historical I01 hatch. Accepted orders and physical stock remain unverified; M60 is a separate orders-in-2027 scope.')),
])
assert set(cohorts) == {v['modelId'] for v in variants}
reviews = []
body_requirements = []
for model_id, c in cohorts.items():
    group = [v for v in variants if v['modelId'] == model_id]
    assert len({v['model'] for v in group}) == 1
    review = dict(id='m1-bmw-2026-10-14-' + model_id.replace('_', '-'), brand='BMW',
                  model=group[0]['model'], bodyStyle=c['body'], vehicleClass='passenger',
                  modelId=model_id, checkedAt=DATE, officialSourceUrls=urls(*c['keys']),
                  reason=c['reason'], versions=[dict(carId=v['id'], model=v['model'], trim=v['trim'],
                                                      modelYear=v.get('modelYear')) for v in group])
    if model_id == 'bmw_i3_sedan_na0':
        review['publishedModelAliases'] = [dict(name='i3', reason='BMW Australia uses i3 for this NA0 sedan. The body/generation scope excludes the historic I01 hatch.', sourceUrls=urls('bmw-i3', 'bmw-i3-tech'))]
    if model_id in ['bmw_i5_sedan_current', 'bmw_i5_touring_current']:
        review['publishedModelAliases'] = [dict(name='i5', reason='The i5 family name is narrowed here to this exact ' + c['body'].lower() + ' body; it does not merge Sedan and Touring.', sourceUrls=urls(*c['keys']))]
    reviews.append(review)
    for v in group:
        existing = next((f['value'] for f in v['facts'] if f['key'] in ['body_style', 'body_type']), None)
        body_requirements.append(dict(carId=v['id'], modelId=model_id, requiredBodyStyle=c['body'],
                                      normalizedBodyStyle=existing, officialSourceUrls=urls(*c['keys']),
                                      status='matches' if existing == c['body'] else 'missing' if existing is None else 'mismatch'))
review_by_model = {r['modelId']: r for r in reviews}

residuals = []
for r in packages['compact']['census']['unresolved']:
    residuals.append(dict(name=r['name'], outcome='unresolved', reason=r['reason'], sourceUrls=urls(*r['sourceKeys'])))
residuals.extend([
 dict(name='i4 earlier eDrive35 codes, eDrive40 M Sport and M50', outcome='unresolved',
      reason='Current factory range was reduced to 52HD eDrive35, but a finite search finding used/demo units and old selectors is insufficient to establish that all prior-grade or prior-code residual new stock is absent.',
      sourceUrls=urls('sedan_bmw_i4_spec', 'sedan_i4_goauto_cull', 'sedan_i4_m50_census')),
 dict(name='i5 Sedan pre-July-2026 production/code cohorts', outcome='unresolved',
      reason='The refreshed 62HG/42HG guide applies from July 2026 production. Retained earlier-code technical components and advertisements have not been reconciled to exact unsold new build cohorts; the current revision does not exhaust prior stock.',
      sourceUrls=urls('sedan_bmw_i5_spec', 'sedan_i5_technical_metadata')),
 dict(name='i5 Touring earlier production cohorts', outcome='unresolved',
      reason='The current live Australian 32HH M60 Touring configuration is established, but it does not prove there are no materially distinct prior-production new vehicles.',
      sourceUrls=urls('sedan_config_32hh_tech', 'sedan_bmw_i5_touring_page')),
 dict(name='i7 outgoing xDrive60 M Sport 52EJ and M70 xDrive 82EH', outcome='unresolved',
      reason='Outgoing maker tables and historical prices remain available; no current exact New outgoing unit has been verified. The 82EH configurator route redirects to an unavailable/different model. These observations neither establish current orderability nor prove nationwide new-stock exhaustion.',
      sourceUrls=urls('sedan_bmw-i7-sedan-technical-data', 'sedan_i7_census', 'sedan_config_82eh_unavailable')),
 dict(name='iX xDrive40, xDrive50, M60, xDrive60 and M70', outcome='unresolved',
      reason='The current captured Australian 42CF guide/configurator list is separate. Older 40/50/M60 price-guide entries and 60/M70 selector, approval or overseas leads do not establish current Australian ordering or a verified exact New seller advertisement. Supplementary residual research remains attached without closing these scopes.',
      sourceUrls=urls('ix_spec', 'ix_tech', 'carsguide-iseries-price-2026')),
])

# Supplement can be supplied by the separate census worker. Its original schema is
# retained in the brand artifact; it does not silently alter the admitted cohort.
supplement_paths = sorted(set(ROOT.glob('census/*ix*residual*.json')) | set(ROOT.glob('census/*residual*ix*.json')) | ({ROOT / 'ix/residual-census.json'} if (ROOT / 'ix/residual-census.json').exists() else set()))
supplements = [dict(file=str(p.relative_to(ROOT)), sha256=hashlib.sha256(p.read_bytes()).hexdigest(), evidence=read(p)) for p in supplement_paths]
ix_extra_urls = []
for supplement in supplements:
    evidence = supplement['evidence']
    if supplement['file'] == 'ix/residual-census.json':
        residuals = [r for r in residuals if r['name'] != 'iX xDrive40, xDrive50, M60, xDrive60 and M70']
        for lead in evidence['variants']:
            if lead['disposition'] == 'included_current_exact_variant':
                continue
            lead_urls = list(dict.fromkeys(e['url'] for e in lead['evidence']))
            residuals.append(dict(name='iX ' + lead['trim'], outcome='unresolved',
                                  reason=lead['reason'], sourceUrls=lead_urls,
                                  unresolvedQuestion=lead['unresolvedQuestion'],
                                  supplementLeadId=lead['leadId']))
            if lead['trim'] in ['xDrive60', 'M70']:
                ix_extra_urls.extend(u for u in lead_urls if 'vesr.gov.au/' in u or 'bmw.com.au/' in u)


notes = [
 'BMW-only Australian Tier 1 passenger BEV reconciliation. Fifteen named configurations across ten exact model/body cohorts are reviewed, including seven new catalogue rows. Brand directories are not complete independently published whole-market BEV lists, so publishedLists remains empty and overall C1 closure is not claimed.',
 'Every currentVersionReview is restricted to its stated maker generation, production revision, code or arriving launch cohort. It is not a whole-family certificate that outgoing/residual-new variants have been exhausted.',
 'The inherited broad iX, iX1, iX2, iX3, i4, i5 and i7 records/leads remain unresolved where earlier codes, outgoing grades, additional performance scopes or residual new stock are not settled. A retained selector, price guide, approval listing or failed dealer page is not a current New advertisement.',
 'Current iX1 Sport Collection is a separately named marketing configuration with unknown exact code; it does not inherit 22HM identity or count as a fifth compact-SUV drivetrain grade.',
 'i5 Sedan and i5 Touring are separate bodies. NA0 i3 Sedan is separate from the historical I01 hatch. No generic family name joins these identities.',
 'NA5 iX3 40 and i7 LCI have arriving Q4 2026 scopes; NA0 i3 Sedan and NA7 iX4 have reported Q1 2027 Australian arrival windows. Current maker listing or Build & Price does not establish an accepted order, actual delivery or physical unsold stock.',
 'iX5 60 xDrive and i3/iX3/iX4 M60 orders-in-2027 material remains future-only. These future configurations are outside the fifteen admitted rows and are not silently added to current reviews.',
 'Formal manufacturer model year is unverified for these exact Australian current cohorts and remains null. Calendar year, guide publication month and advertisement year do not populate it.',
 'This dated reconciliation accompanies the staged, unregistered BMW packet. Original source data and registered packets are preserved; no physical stock, accepted factory order or whole-market C1 closure is asserted.',
]
# Complete inherited BMW rows, with exactly one disposition each and no synthetic orphan inventory rows.
inv = []
record_reasons = {
 'bmw-i4': ('Current 52HD eDrive35 M Sport is reviewed; older eDrive35 codes, eDrive40 and M50 residual-new cohorts remain unresolved. Current range discontinuation is not evidence that all unsold new stock is gone.', ['sedan_bmw_i4_spec', 'sedan_i4_goauto_cull', 'sedan_i4_m50_census']),
 'bmw-i5': ('Current July-2026-production sedan eDrive40/M60 and current 32HH M60 Touring are separately reviewed. The broad inherited i5 record spans bodies and does not settle earlier production/code residual-new cohorts.', ['sedan_bmw_i5_spec', 'sedan_config_32hh_tech', 'sedan_i5_technical_metadata']),
 'bmw-ix': ('Current 42CF xDrive45 M Sport is reviewed. Older xDrive40/xDrive50/M60 plus xDrive60/M70 leads remain an open Australian current-order/residual-new census, so the broad inherited iX record is unresolved.', ['ix_spec', 'ix_tech', 'carsguide-iseries-price-2026']),
 'bmw-ix1': ('Current 22HM M Sport and the separately named Sport Collection offer are reviewed. eDrive20 and older xDrive30 code cohorts remain unresolved for genuine residual new availability.', ['ix1-current', 'sport-collection', 'running-changes', 'ix1-edrive-template']),
 'bmw-ix2': ('Current 82GN M Sport is reviewed. The indexed eDrive20 52GM New lead is blocked and another lead has inconsistent model text; older 72GM xDrive30 residual-new stock is also unverified.', ['ix2-current', 'residual-ix2-ad', 'ix2-tech']),
 'bmw-ix3': ('Current NA5 12HR/32HR launch versions are reviewed. Outgoing G08 M Sport/M Sport Pro residual-new membership remains open. The separate M60 is explicitly orders-in-2027 future material.', ['ix3-current', 'ix3-g08-official', 'ix3-m60-future']),
 'bmw-i7': ('Arriving LCI 72HY 60 xDrive M Sport is reviewed. Outgoing 52EJ xDrive60 and 82EH M70 retain unresolved current-order/residual-new status; neither legacy pages nor a failed configurator route establish inventory absence.', ['sedan_bmw_i7_spec', 'sedan_bmw-i7-sedan-technical-data', 'sedan_i7_census']),
 'bmw-additional-performance-and-body-variants': ('Current i5 M60 Touring 32HH and NA5 iX3 40 are resolved as named current configurations, but this broad inherited lead remains open because outgoing i7 and iX performance/residual scopes are unsettled. i3/iX3/iX4 M60 and iX5 are retained separately as explicitly future orders-in-2027 scopes.', ['sedan_config_32hh_tech', 'ix3-current', 'sedan_bmw_i7_m70_page', 'bmw-i3-m60', 'bmw-ix4-m60', 'bmw-ix5']),
}
for kind, field in [('record', 'records'), ('lead', 'unverifiedLeads')]:
    for r in inventory[field]:
        if r.get('brand') != 'BMW' or r.get('vehicleClass', 'passenger') not in ['passenger', 'ute']:
            continue
        iid = r.get('id') or r.get('familyId') or f"{r['brand']}-{r['model']}"
        row = dict(kind=kind, inventoryId=iid, reviewedAt=DATE)
        if iid in ['bmw-i3', 'bmw-ix4']:
            mid = 'bmw_i3_sedan_na0' if iid == 'bmw-i3' else 'bmw_ix4_na7'
            review = review_by_model[mid]
            row.update(outcome='included', modelReviewId=review['id'], sourceUrls=review['officialSourceUrls'],
                       reason='The inherited current marketing lead is now resolved to the exact Australian arriving 40 xDrive and 50 xDrive launch cohort. This disposition establishes model/body/version membership only, not accepted orders, deliveries or physical stock. The separate M60 remains explicitly future; no historical same-name body is merged.')
        else:
            assert iid in record_reasons, ('Unaccounted inherited BMW inventory row', iid)
            reason, keys = record_reasons[iid]
            row.update(outcome='unresolved', reason=reason, sourceUrls=urls(*keys))
        if iid == 'bmw-ix' and ix_extra_urls:
            row['sourceUrls'] = list(dict.fromkeys(row['sourceUrls'] + ix_extra_urls))
            row['reason'] += ' xDrive60 has an explicit BMW Australia FAQ mention and both xDrive60/M70 have local VESR records; they are not dismissed as overseas-only. Administrative records and generic marketing do not establish retail new supply.'
        inv.append(row)

registry = dict(schemaVersion=1, checkedAt=DATE, notes=notes, publishedLists=[],
                currentVersionReviews=reviews, listResolutions=[], catalogueOnlyDifferences=[], inventoryResolutions=inv)

# Full transcribed directories with sourced dispositions remain inspectable, not reduced
# to a BEV-only shortlist, and remain explicitly brand-only.
directory_rows = []
for original in census['census']['rows']:
    row = copy.deepcopy(original)
    row['sourceUrls'] = urls(*row['sourceIds'])
    row['checkedAt'] = DATE
    if row.get('listedName') == 'i3' and row.get('directory') == 'CarExpert':
        row['reason'] = 'The discontinued directory badge and historical hatch index are distinct from the live linked NA0 sedan page. The NA0 40/50 xDrive arriving cohort is reviewed separately. The historical I01 hatch is not admitted on this old label alone; this is not a nationwide residual-stock absence claim.'
    directory_rows.append(row)
differences = []
for original in census['census']['differences']:
    row = copy.deepcopy(original);row['sourceUrls'] = urls(*row['sourceIds'])
    if row['model'] == 'i5 Touring':
        row.update(disposition='included_current_exact_body_cohort', reason='Exact live Australian 32HH M60 Touring configurator now establishes the current named wagon despite omission from the all-models directory. Earlier production and non-Australian grades remain separate.', sourceUrls=urls('sedan_config_32hh_tech', 'sedan_config_32hh_price', *row['sourceIds']))
    differences.append(row)
future = []
for f in census['future']:
    keys = f['sourceIds']
    if f['model'] == 'iX3':
        keys = ['ix3-m60-future']
    future.append(dict(model=f['model'], trim=f['trim'], generation=f.get('generation'),
                       disposition='future_not_currently_orderable', reason=f['evidence'] if f['model'] != 'iX3' else 'BMW Australia explicitly says iX3 M60 xDrive is available to order in 2027.', sourceUrls=urls(*keys)))
independent = []
for r in census['census']['independentDirectories']:
    independent.append(dict(publisher=r['publisher'], independenceKey=r['directory'], url=sources[r['directory']]['url'],
                            publisherEvidenceUrl=sources[r['publisherEvidence']]['url'], independenceReason=r['distinctness'],
                            scope='BMW brand model directory, all powertrains, not whole-market C1',
                            entries=[x for x in directory_rows if x['directory'] == ('CarExpert' if 'carexpert' in r['directory'] else 'CarsGuide')]))
brand = dict(checkedAt=DATE, scope='BMW Australian brand model/body/version reconciliation; current source-bound cohorts plus open residual census',
             wholeMarketClosureEstablished=False, fullBrandResidualVersionClosureEstablished=False,
             notes=notes, official=dict(sourceUrls=urls('bmw-models', 'bmw-electric'),
                                        listedElectricFamilies=census['census']['manufacturerElectricFamilies'],
                                        futureOnlyFamilies=['iX5']),
             independentDirectories=independent, familyDifferences=differences,
             currentVersionReviews=reviews, inventoryResolutions=inv, unresolvedResidualCohorts=residuals,
             futureConfigurations=future, residualResearchSupplements=supplements,
             bodyStyleIntegrationRequirements=body_requirements,
             counts=dict(expectedVersions=15, currentModelBodyCohorts=10,
                         existingCatalogueRows=sum(v['id'] in {b['id'] for b in before} for v in variants),
                         newCatalogueRows=sum(v['id'] not in {b['id'] for b in before} for v in variants),
                         inheritedInventoryRows=len(inv), directoryRows=len(directory_rows)),
             limitations=['Current-version review does not close outgoing or residual-new cohorts.',
                          'Brand-only directories are never inserted into publishedLists.',
                          'Normalized packages currently omit body_style where the requirements show missing; integration must add matching facts before claiming final exact-body guard completion.',
                          'No heavy catalogue, report replay or repository mutation is performed here.'])

errors = []
reviewed = [v['carId'] for r in reviews for v in r['versions']]
if set(reviewed) != {v['id'] for v in variants} or len(reviewed) != len(set(reviewed)):
    errors.append('Review membership does not cover each normalized row exactly once')
expected_inv = [(kind, r.get('id') or r.get('familyId') or f"{r['brand']}-{r['model']}")
                for kind, field in [('record','records'), ('lead','unverifiedLeads')]
                for r in inventory[field] if r.get('brand')=='BMW' and r.get('vehicleClass','passenger') in ['passenger','ute']]
if sorted(expected_inv) != sorted((r['kind'],r['inventoryId']) for r in inv):
    errors.append('Inherited inventory dispositions are missing, duplicated or orphaned')
if any(x['status']=='mismatch' for x in body_requirements):
    errors.append('A normalized body-style fact conflicts with its exact review')
if brand['counts']['newCatalogueRows'] != 7:
    errors.append('Expected seven new catalogue rows')
for r in reviews:
    assert r['officialSourceUrls'] and all(re.match(r'^https?://',u) for u in r['officialSourceUrls'])
assert not errors, errors
write('bmw-reconciliation-2026-10-14.json', registry)
write('brand-model-list-reconciliation.json', brand)
validation = dict(checkedAt=DATE, draftOnly=False, structuralValidationErrors=errors,
                  versionCount=len(reviewed), modelBodyCohorts=len(reviews), inventoryRows=len(inv),
                  includedInventoryRows=sum(r['outcome']=='included' for r in inv),
                  unresolvedInventoryRows=sum(r['outcome']=='unresolved' for r in inv),
                  missingBodyStyleFacts=[x['carId'] for x in body_requirements if x['status']=='missing'],
                  supplementFiles=[s['file'] for s in supplements],
                  heavyCatalogueOrReplayRun=False,
                  inputHashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in [ROOT/f/'normalized-evidence.json' for f in packages] + [ROOT/'census/new-families-and-census.json']})
write('reconciliation-draft-validation.json', validation)
print(json.dumps({k: v for k,v in validation.items() if k not in ['inputHashes','missingBodyStyleFacts']}, indent=2))
print('Body-style facts requiring integration:', len(validation['missingBodyStyleFacts']))
