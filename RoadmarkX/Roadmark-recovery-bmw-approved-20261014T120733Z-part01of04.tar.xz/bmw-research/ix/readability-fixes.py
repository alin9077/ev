# Applied only to this supplement's authored prose, never to captured source text.
def make_readable(O):
 S=O['sources'];E=O['variants']
 notes={
 'ix-current-guide':'The guide specifies xDrive45 M Sport, model code 42CF. Its model scope is not proof that all older stock has sold.',
 'ix-current-new-ad':'Parent capture of an exact advertised new xDrive45. Advertisement existence is not independent physical-stock or delivery confirmation.',
 'ix-cg2026':'Lists xDrive40 Sport, xDrive45 M Sport, xDrive50 Sport and M60 together. Directory presence is not stock or order acceptance.',
 'ix-goauto2025':'Historical launch scope, not an October 2026 nationwide stock audit.',
 'ix-ce2025':'Says other iX variant details will follow later. Does not establish a definite current Australian xDrive60 or M70 launch date.',
 'ix-generic-range':'Explicit iX xDrive60 701km WLTP lead. The FAQ also mixes i4 eDrive40 and future i3 mentions. No exact local order or price proof.',
 'ix-compare-selector':'xDrive50 appears as an engine-selector choice while the loaded technical table is xDrive45. No xDrive50 order availability is inferred.',
 'ix-global-new':'Global publication; final page explicitly scopes variants and specifications to Germany. Names xDrive45, xDrive60 and M70. No Australian retail inference.',
 'ix-hunter40-used':'Fresh body labels this under Used Cars and reports 34,231km. New Arrival means newly added stock, not a new vehicle.',
 'ix-old50-index':'Index was crawled 1.3 years ago. Live verification was blocked; the residual lead stays open.',
 }
 for s in S:
  if s['key'] in notes:s['notes']=notes[s['key']]
 titles={'ix-global-new':'The new BMW iX: highlights, January 2025','ix-hunter40-used':'2023 BMW iX xDrive40 Sport, stock 291406'}
 for s in S:
  if s['key'] in titles:s['title']=titles[s['key']]
 updates=[
 ('Exact Australian model/specification sources and a parent-captured new-car advertisement support this existing included variant.',None,[
 'Exact xDrive45 M Sport specification guide, model code 42CF.',
 'Current model page presents xDrive45.',
 'Exact advertised new 2026 xDrive45. No independent physical-stock or delivery verification.',
 '2026 price directory includes xDrive45 M Sport alongside older leads.']),
 ('A historical Australian grade remains visible in launch reporting and secondary used listings. Replacement of the factory range does not rule out unsold new units.',
 'Does any Australian dealer still have an exact xDrive40 base vehicle as genuinely new, unregistered stock?',[
 'Names outgoing xDrive40 among grades not listed as renewed at the 2025 launch.',
 'xDrive40 base appears in secondary used searches, rather than exact new-stock evidence.',
 'Current guide covers xDrive45. This alone cannot exclude older new stock.']),
 ('CarsGuide’s 2026 directory retains xDrive40 Sport. A fresh independent dealer read concerns a used vehicle. Residual new supply remains unclosed.',
 'Does any Australian dealer hold a genuinely new, unregistered xDrive40 Sport unit as of the checked date?',[
 'Lists xDrive40 Sport at AUD136,900 in the 2026 directory. This is not an order or stock statement.',
 'Reports xDrive45 M Sport replacing xDrive40 Sport as the local refreshed launch grade.',
 'Exact stock 291406 is under Used Cars with 34,231km. New Arrival wording does not mean a new vehicle.']),
 ('Current price-directory and BMW comparison-selector leads coexist with an old indexed dealer-new advertisement that could not be freshly verified.',
 'Is old advertisement OAG-AD-24355524 still live and new, or is another exact xDrive50 Sport new unit available? Is the selector entry active or residual?',[
 'Lists xDrive50 Sport at AUD185,400 in the 2026 directory.',
 'BMW Australia’s engine selector includes xDrive50, but the active technical table is xDrive45.',
 'Old indexed dealer-new 2024 advertisement OAG-AD-24355524. Its current page could not be verified.',
 'A separate Westside BMW-hosted 2022 advertisement is explicitly Used.',
 'Reports that xDrive50 Sport was not listed as renewed at the 2025 launch.']),
 ('The 2026 directory and dealer-model marketing preserve this lead. Recovered exact advertisements concern used vehicles. These results do not establish new supply.',
 'Is there a genuinely new, unregistered M60 unit or current Australian order acceptance?',[
 'Lists M60 at AUD233,400 in the 2026 directory.',
 'Reports that M60 was not listed as renewed at the 2025 launch.',
 'Exact 2025 advertisement OAG-AD-26322759 is explicitly Dealer Used with 7,810km.',
 'Static dealer M60 model page remains indexed; the current direct read returned HTTP404.',
 'A cached used M60 card was not reproduced after the live page redirected to general stock.']),
 ('Cannot safely be classified as overseas-only or not sold: BMW Australia’s generic FAQ explicitly names it, and a local government database has an exact record. Neither establishes current Australian retail supply.',
 'Has BMW Australia opened xDrive60 retail orders or supplied new stock, or are the FAQ/database entries preparatory or carried-over template content?',[
 'Explicit xDrive60 mention with 701km WLTP in the longest-range FAQ.',
 'Exact 2025–2026 xDrive60 government database record.',
 'Global press material lists xDrive60; the specifications are scoped to Germany.',
 'Other iX variants were promised later details. The overseas xDrive60 was named, without a firm current Australian launch.',
 'Current exact Australian specification guide covers xDrive45 only. No negative conclusion follows.']),
 ('An exact Australian government record plus the global production model warrants an explicit census lead. Local sale and order status remain unverified.',
 'Has the M70 been locally released, priced, opened for orders or supplied new through an Australian dealer?',[
 'Exact 2025–2026 M70 xDrive government database record.',
 'Global press material includes M70, with specifications scoped to Germany.',
 'Other iX variants were to receive details later; M70 was described as an overseas variant.',
 'Current Australian exact specification guide covers xDrive45. It does not prove that M70 cannot be sold.'])]
 for e,(reason,q,obs) in zip(E,updates):
  e['reason']=reason;e['unresolvedQuestion']=q
  assert len(e['evidence'])==len(obs)
  for f,v in zip(e['evidence'],obs):f['observation']=v
 O['newSupplyCensusStatus']='OPEN: six residual/newer leads remain unresolved. Only xDrive45 M Sport has an exact current new-car advertisement plus current Australian specification evidence here.'
 O['freshSearchAudit']['outcome']='No freshly verified exact new xDrive40, xDrive40 Sport, xDrive50 Sport, M60, xDrive60 or M70 advertisement was recovered in this limited targeted search. An old indexed dealer-new xDrive50 Sport advertisement remains unverified. This is not a no-sale exclusion or an exhaustive nationwide inventory audit.'
 O['freshSearchAudit']['queries'][0]='BMW iX xDrive40 Sport new Australia 2026 dealer'
 O['freshSearchAudit']['queries'][1]='BMW iX xDrive50 Sport new Australia dealer 2026'
 O['integrationRules']=[
 'Keep BMW Australia’s generic xDrive60 range mention visible as a local primary lead; do not translate it into retail availability.',
 'Do not classify xDrive60 or M70 as overseas-only when Australian government records exist. Those records do not prove retail availability.',
 'Historical reporting that only xDrive45 launched, or absence from an exact current configurator list, cannot prove all older new stock has sold.',
 'Do not count used, demo or near-new advertisements as new stock.',
 'Do not use CarsGuide’s 2026 directory prices as primary current prices.',
 'Do not equate the administrative 2025–2026 database label with local launch, model year or order status.',
 'Current xDrive45 facts and all normalized files remain unchanged.'
 ]
 O['transformations']=[
 'HTML captures retain public text only, without headers, cookies or authentication/session values.',
 'Public SVG-loader residue was removed from VESR text and its metadata SHA256 was updated.',
 'PDF text was derived using pdftotext -layout. German-market scope remains explicit.',
 'Cached advertisement extracts are minimal transcriptions and marked as not live. A tracking query was removed from the canonical M60 URL.',
 'BMW Australia’s range and CarsGuide captures duplicate reviewer content. They are not counted as extra independent sources.'
 ]
