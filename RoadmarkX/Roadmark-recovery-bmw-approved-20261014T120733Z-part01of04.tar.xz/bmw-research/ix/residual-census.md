# BMW iX residual and newer-variant census supplement

Checked: 14 October 2026.

## Result

Seven named iX leads are visible and source-bound. Only the xDrive45 M Sport has exact current Australian new-supply evidence in this supplement. Six other leads remain **unresolved for new supply**. No failure to find an ad has been converted into a “not sold” exclusion. This does not close the whole-market C1 census.

## Important newer-variant leads

- **xDrive60:** BMW Australia’s generic range FAQ explicitly advertises 701km WLTP. Its current exact iX model/specification materials centre on xDrive45. The FAQ mention must be retained as a local primary template lead, with retail status unverified.
- **xDrive60 and M70 xDrive:** both have exact 2025–2026 entries in the Australian VESR government database. These administrative records are additional local leads; they do not prove new stock, accepted orders or deliveries. Neither variant should be silently dismissed as overseas-only.
- BMW’s January 2025 global press material names xDrive45, xDrive60 and M70, but explicitly scopes specifications to Germany. CarExpert’s February 2025 Australian launch story says other iX variant details were to follow later, without establishing today’s status.

## Dispositions

### xDrive45 M Sport

included_current_exact_variant

Exact Australian model/specification sources and a parent-captured new-car advertisement support this existing included variant.

- [BMW iX Australian specification guide](https://media.adtorqueedge.com/new-cars/bmw-aus/brochures/BMW%20iX.pdf): Exact xDrive45 M Sport specification guide, model code 42CF.
- [BMW iX current Australian model page](https://www.bmw.com.au/en/models/bmw-i/ix/bmw-ix.html): Current model page presents xDrive45.
- [2026 BMW iX xDrive45 new advertisement](https://virtual.bmw.com.au/details/OAG-AD-WBY42CF090CY37329/2026-bmw-ix-xdrive45-new): Exact advertised new 2026 xDrive45. No independent physical-stock or delivery verification.
- [2026 BMW iX prices and specifications](https://www.carsguide.com.au/bmw/i-series/ix/price/2026): 2026 price directory includes xDrive45 M Sport alongside older leads.

### xDrive40

unresolved_historical_residual_new_supply

A historical Australian grade remains visible in launch reporting and secondary used listings. Replacement of the factory range does not rule out unsold new units.

- [BMW confirms iX local price and spec](https://www.goauto.com.au/new-models/bmw/ix/bmw-confirms-ix-local-price-and-spec/2025-02-20/95735.html): Names outgoing xDrive40 among grades not listed as renewed at the 2025 launch.
- [Targeted new-iX search and indexed listing results](https://www.carsales.com.au/cars/new/bmw/ix/?sort=~Price): xDrive40 base appears in secondary used searches, rather than exact new-stock evidence.
- [BMW iX Australian specification guide](https://media.adtorqueedge.com/new-cars/bmw-aus/brochures/BMW%20iX.pdf): Current guide covers xDrive45. This alone cannot exclude older new stock.

Open: Does any Australian dealer still have an exact xDrive40 base vehicle as genuinely new, unregistered stock?

### xDrive40 Sport

unresolved_historical_residual_new_supply

CarsGuide’s 2026 directory retains xDrive40 Sport. A fresh independent dealer read concerns a used vehicle. Residual new supply remains unclosed.

- [2026 BMW iX prices and specifications](https://www.carsguide.com.au/bmw/i-series/ix/price/2026): Lists xDrive40 Sport at AUD136,900 in the 2026 directory. This is not an order or stock statement.
- [BMW confirms iX local price and spec](https://www.goauto.com.au/new-models/bmw/ix/bmw-confirms-ix-local-price-and-spec/2025-02-20/95735.html): Reports xDrive45 M Sport replacing xDrive40 Sport as the local refreshed launch grade.
- [2023 BMW iX xDrive40 Sport, stock 291406](https://www.huntermotive.com.au/cars/used-black-2023-bmw-ix-291406): Exact stock 291406 is under Used Cars with 34,231km. New Arrival wording does not mean a new vehicle.

Open: Does any Australian dealer hold a genuinely new, unregistered xDrive40 Sport unit as of the checked date?

### xDrive50 Sport

unresolved_historical_residual_new_supply

Current price-directory and BMW comparison-selector leads coexist with an old indexed dealer-new advertisement that could not be freshly verified.

- [2026 BMW iX prices and specifications](https://www.carsguide.com.au/bmw/i-series/ix/price/2026): Lists xDrive50 Sport at AUD185,400 in the 2026 directory.
- [BMW AU model comparison selector](https://www.bmw.com.au/en/compare-bmw-models.html/i/I20/42CF/A/content.q): BMW Australia’s engine selector includes xDrive50, but the active technical table is xDrive45.
- [Old indexed dealer-new xDrive50 Sport advertisement](https://www.carsales.com.au/cars/details/2024-bmw-ix-xdrive50-sport-i20-auto-awd/OAG-AD-24355524/): Old indexed dealer-new 2024 advertisement OAG-AD-24355524. Its current page could not be verified.
- [2022 BMW iX xDrive50 Sport used advertisement](https://usedcars.bmw.com.au/details/OAG-AD-26250151/2022-bmw-ix-used): A separate Westside BMW-hosted 2022 advertisement is explicitly Used.
- [BMW confirms iX local price and spec](https://www.goauto.com.au/new-models/bmw/ix/bmw-confirms-ix-local-price-and-spec/2025-02-20/95735.html): Reports that xDrive50 Sport was not listed as renewed at the 2025 launch.

Open: Is old advertisement OAG-AD-24355524 still live and new, or is another exact xDrive50 Sport new unit available? Is the selector entry active or residual?

### M60

unresolved_historical_residual_new_supply

The 2026 directory and dealer-model marketing preserve this lead. Recovered exact advertisements concern used vehicles. These results do not establish new supply.

- [2026 BMW iX prices and specifications](https://www.carsguide.com.au/bmw/i-series/ix/price/2026): Lists M60 at AUD233,400 in the 2026 directory.
- [BMW confirms iX local price and spec](https://www.goauto.com.au/new-models/bmw/ix/bmw-confirms-ix-local-price-and-spec/2025-02-20/95735.html): Reports that M60 was not listed as renewed at the 2025 launch.
- [2025 BMW iX M60 dealer-used advertisement](https://www.carsales.com.au/cars/details/2025-bmw-ix-m60-i20-auto-awd/OAG-AD-26322759/): Exact 2025 advertisement OAG-AD-26322759 is explicitly Dealer Used with 7,810km.
- [BMW iX M60 dealer model-page lead](https://www.klosters.com.au/models/ix-m60): Static dealer M60 model page remains indexed; the current direct read returned HTTP404.
- [Sime Motors dealer stock redirect from search lead](https://simemotors.com.au/stock/details/OAG-AD-25476127/2021-volkswagen-tiguan-used): A cached used M60 card was not reproduced after the live page redirected to general stock.

Open: Is there a genuinely new, unregistered M60 unit or current Australian order acceptance?

### xDrive60

unresolved_au_template_and_administrative_lead

Cannot safely be classified as overseas-only or not sold: BMW Australia’s generic FAQ explicitly names it, and a local government database has an exact record. Neither establishes current Australian retail supply.

- [BMW electric-car range FAQ](https://www.bmw.com.au/en/electric-cars/electric-car-range.html): Explicit xDrive60 mention with 701km WLTP in the longest-range FAQ.
- [BMW iX xDrive60 Wagon Auto (2025–2026)](https://vesr.gov.au/vehicle/bmw-ix-xdrive60-wagon-auto-2025-2026): Exact 2025–2026 xDrive60 government database record.
- [The new BMW iX: highlights, January 2025](https://www.press.bmwgroup.com/global/article/attachment/T0447642EN/630681): Global press material lists xDrive60; the specifications are scoped to Germany.
- [2025 BMW iX price and specs](https://www.carexpert.com.au/car-news/2025-bmw-ix-price-and-specs): Other iX variants were promised later details. The overseas xDrive60 was named, without a firm current Australian launch.
- [BMW iX Australian specification guide](https://media.adtorqueedge.com/new-cars/bmw-aus/brochures/BMW%20iX.pdf): Current exact Australian specification guide covers xDrive45 only. No negative conclusion follows.

Open: Has BMW Australia opened xDrive60 retail orders or supplied new stock, or are the FAQ/database entries preparatory or carried-over template content?

### M70 xDrive

unresolved_au_administrative_and_overseas_lead

An exact Australian government record plus the global production model warrants an explicit census lead. Local sale and order status remain unverified.

- [BMW iX M70 xDrive Wagon Auto (2025–2026)](https://vesr.gov.au/vehicle/bmw-ix-m70-xdrive-wagon-auto-2025-2026): Exact 2025–2026 M70 xDrive government database record.
- [The new BMW iX: highlights, January 2025](https://www.press.bmwgroup.com/global/article/attachment/T0447642EN/630681): Global press material includes M70, with specifications scoped to Germany.
- [2025 BMW iX price and specs](https://www.carexpert.com.au/car-news/2025-bmw-ix-price-and-specs): Other iX variants were to receive details later; M70 was described as an overseas variant.
- [BMW iX Australian specification guide](https://media.adtorqueedge.com/new-cars/bmw-aus/brochures/BMW%20iX.pdf): Current Australian exact specification guide covers xDrive45. It does not prove that M70 cannot be sold.

Open: Has the M70 been locally released, priced, opened for orders or supplied new through an Australian dealer?

## What the targeted ad checks establish

CarsGuide’s 2026 iX directory simultaneously lists xDrive40 Sport, xDrive45 M Sport, xDrive50 Sport and M60. This is a census lead, not an inventory audit. BMW Australia’s comparison selector also still exposes xDrive50, while its loaded technical table is xDrive45.

A current independent Huntermotive read identifies the 40 Sport example as a used vehicle with 34,231km. Its “New Arrival” label does not mean a new vehicle. Other recovered 50/M60 ads are explicitly used or are cached. An old indexed 2024 xDrive50 Sport advertisement was labelled dealer-new; direct access failed, so it remains an unverified residual lead.

The Sime Motors search lead redirected to a general stock page. The captured page did not reproduce the old M60 card; that says nothing about all inventory. A Klosters static M60 model page returned 404, likewise not a nationwide exclusion.

No freshly verified exact new 40, 40 Sport, 50 Sport, M60, 60 or M70 listing was recovered in this limited targeted pass. Residual new supply remains open. A seller-confirmed new/unregistered unit or an exact current Australian order source is needed to close any of those leads.

## Evidence handling

The JSON records every public URL, publisher, capture method, source market, checked date, SHA256 and limitation. Global specifications retain German scope. HTML captures omit headers and authentication/session information. Search-cache extracts are clearly marked as cached. The supplementary manifest includes the source captures, derivative text and this report; existing normalized evidence is unchanged.
