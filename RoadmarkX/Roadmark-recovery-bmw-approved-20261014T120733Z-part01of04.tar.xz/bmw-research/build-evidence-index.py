import json,pathlib,hashlib,re
R=pathlib.Path('/tmp/bmw-research');p=json.loads((R/'bmw-2026-10-14.json').read_text());out=[]
for s in p['sources']:
 row={k:s[k]for k in ['id','title','url','publisher','source_type','accessed_date']}
 for loc,h in [('capture_locator','capture_sha256'),('capture_text_locator','capture_text_sha256')]:
  if loc in s:
   f=R/s[loc];actual=hashlib.sha256(f.read_bytes()).hexdigest();assert actual==s[h],f;row[loc]=s[loc];row[h]=actual
 row['originMarket']=s.get('sourceOriginMarket','AU');out.append(row)
(R/'source-index.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
# Source captures have been transformed at retrieval; this final scan checks for surviving credential-shaped values.
patterns=[r'(?i)(?:set-cookie|authorization)\s*[:=]\s*(?!\[REDACTED\])\S+',r'(?i)(?:access_token|refresh_token|client_secret|clientSecret|csrfToken|JSESSIONID|ak_bmsc|bm_sz|_abck)\s*["\x27]?\s*[:=]\s*["\x27]?(?!\[REDACTED\]|\[omitted\]|null|false|true)[A-Za-z0-9_./+%-]{10,}']
findings=[];scanned=[]
for f in R.rglob('*'):
 if not f.is_file()or f.suffix not in ['.html','.txt','.json']:continue
 if f.name in ['replay-snapshot.json','bmw-live-before.json','bmw-source-before.json','bmw-feature-before.json','new-feature-before.json','privacy-review.json']:continue
 t=f.read_text(errors='replace');scanned.append(str(f.relative_to(R)))
 for pat in patterns:
  if re.search(pat,t):findings.append({'file':str(f.relative_to(R)),'rule':patterns.index(pat),'result':'possible token-shaped value; manual review required'})
(R/'privacy-review.json').write_text(json.dumps({'checkedAt':'2026-10-14','captureFilesScanned':scanned,'findings':findings,'transforms':['Public HTTP captures omit response/request headers. Compact HTML removes non-JSON-LD scripts and redacts credential-like assignments; text derivatives retain public specifications and source URLs.','Other HTTP captures preserve PDF bodies or stripped public text, without script runtime state. Public Car JSON-LD preserves vehicle facts but excludes tracking graph/image query data.','Browser captures contain rendered public accessibility/DOM text, no headers/cookies/session objects. Generated configuration share-link values are omitted where not needed; public model/option codes and source URLs remain.','Local PDF page renders are labelled as such. No unrequested browser screenshot is included or Library-uploaded.'],'noSecretsExpected':not findings},indent=2)+'\n')
print('Evidence source rows',len(out),'privacy possible matches',len(findings))
