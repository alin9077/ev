# BMW new families and census — checked 14 October 2026

## Result
Four Australian launch versions identified: i3 Sedan 40/50 xDrive and iX4 40/50 xDrive. Australian reports place arrivals in Q1 2027. Order acceptance and physical stock remain unverified. iX5 60 xDrive, i3 M60 and iX4 M60 are explicitly not available to order until 2027.

## New-version facts
The JSON carries every value, basis, grade recommendation, condition, source and unresolved issue. Parent supplies primary prices and brand-wide warranty terms.

### iX4 40 xDrive
- Reported price: A$103,900 before ORC (CarExpert)
- Range: up to 638 km WLTP; preserve configuration qualification
- Battery: 82.6 kWh; AU page does not label net/gross
- Charging: 300 kW DC peak; 21 minutes 10–80%; up to 22 kW AC
- Seats: 5, Reported; boot 490 L, method unspecified
- 275 kW AWD; 0–100 km/h 5.6 s
- 4782 × 1895 × 1595 mm (body width)
- Strength: A claimed 21-minute 10–80% stop and all-wheel drive suit long-distance trips in a coupe-shaped SUV
- Trade-off: The rear boot holds 490 litres with the seats up; the sleeker body gives up 30 litres against the iX3

### iX4 50 xDrive
- Reported price: A$119,900 before ORC (CarExpert)
- Range: up to 828 km WLTP; preserve configuration qualification
- Battery: 108.7 kWh; AU page does not label net/gross
- Charging: 400 kW DC peak; 21 minutes 10–80%; up to 22 kW AC
- Seats: 5, Reported; boot 490 L, method unspecified
- 345 kW AWD; 0–100 km/h 4.9 s
- 4782 × 1895 × 1595 mm (body width)
- Strength: A claimed 21-minute 10–80% stop and all-wheel drive suit long-distance trips in a coupe-shaped SUV
- Trade-off: The rear boot holds 490 litres with the seats up; the sleeker body gives up 30 litres against the iX3

### i3 40 xDrive Sedan
- Reported price: A$96,900 before ORC (CarExpert)
- Range: up to 710 km WLTP; preserve configuration qualification
- Battery: 83.8 kWh; AU page does not label net/gross
- Charging: 300 kW DC peak; 21 minutes 10–80%; up to 22 kW AC
- Seats: 5, Reported; boot 420 L, method unspecified
- 275 kW AWD; 0–100 km/h 5.4 s
- 4760 × 1865 × 1480 mm (body width)
- Strength: BMW advertises up to 710 km WLTP and a 21-minute 10–80% charge, giving this sedan a long-trip focus
- Trade-off: The rear boot is 420 litres, with only a separate 31-litre front compartment for smaller items

### i3 50 xDrive Sedan
- Reported price: A$112,900 before ORC (CarExpert)
- Range: up to 912 km WLTP; preserve configuration qualification
- Battery: 108.7 kWh; AU page does not label net/gross
- Charging: 400 kW DC peak; 21 minutes 10–80%; up to 22 kW AC
- Seats: 5, Reported; boot 420 L, method unspecified
- 345 kW AWD; 0–100 km/h 4.7 s
- 4760 × 1865 × 1480 mm (body width)
- Strength: BMW advertises up to 912 km WLTP and a 21-minute 10–80% charge, giving this sedan a long-trip focus
- Trade-off: The rear boot is 420 litres, with only a separate 31-litre front compartment for smaller items

## Important safeguards
- BMW AU i3 40 battery says 83.8 kWh; CarExpert/carsales say 82.8. Do not silently reconcile
- iX4 AU towing is not published; 2000 kg is European and not an Australian rating
- iX4 AC 22 kW is called optional by BMW AU. Do not declare standard from max-capability table alone
- i3 towing 1800 kg is conditional on optional towing equipment
- V2L/Home Backup requires optional hardware/accessories expected Q4 2027
- iX5 future 141 kWh / 460 kW DC / 23 min figures and 845 km max are provisional and excluded from current-sale coverage
- All boot figures keep unspecified method; front storage is specifically liquid volume and separate

## Census
CarExpert and CarsGuide are distinct Australian publications/operators, with publisher evidence saved. Their lists have different grouping and stale-label issues. These are BMW brand-level reconciliation inputs, not whole-market C1 proof.

| Directory | Listed name | Disposition | Reason |
|---|---|---|---|
| CarExpert | 1 Series | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | 2 Series | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | 3 Series | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | 4 Series | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | 5 Series | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | 7 Series | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | i4 | included_current_family | Present in BMW AU electric directory; exact current version list handled in parent/parallel family packet. |
| CarExpert | i5 | included_current_family | Present in BMW AU electric directory; exact current version list handled in parent/parallel family packet. |
| CarExpert | i7 | included_current_family | Present in BMW AU electric directory; exact current version list handled in parent/parallel family packet. |
| CarExpert | iX | included_current_family | Present in BMW AU electric directory; exact current version list handled in parent/parallel family packet. |
| CarExpert | iX1 | included_current_family | Present in BMW AU electric directory; exact current version list handled in parent/parallel family packet. |
| CarExpert | iX2 | included_current_family | Present in BMW AU electric directory; exact current version list handled in parent/parallel family packet. |
| CarExpert | iX3 | included_current_family | Present in BMW AU electric directory; exact current version list handled in parent/parallel family packet. |
| CarExpert | M2 | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | M3 | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | M4 | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | M5 | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | X1 | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | X2 | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | X3 | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | X4 | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | X5 | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | X6 | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | X7 | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | XM | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | Z4 | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | 6 Series | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | 8 Series | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarExpert | i3 | included_arriving_separate_identity | Directory discontinued badge is stale/ambiguous after name reuse. Live linked i3 page now describes NA0 sedan, whereas web index still has historic hatch text. Include NA0 40/50 xDrive as arriving; exclude historical I01 hatch. |
| CarExpert | M8 | excluded_non_bev_or_historic | Combustion/PHEV line, or discontinued non-BEV nameplate. No additional battery-electric AU version in BMW current electric directory; i-prefixed electric siblings handled separately. |
| CarsGuide | 1 Series | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | 2 Series | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | 3 Series | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | 4 Series | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | 5 Series | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | 7 Series | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | 8 Series | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | i Series | expanded_aggregate | Expand to i4, iX and iX3 in the 2026 price page. Historic browse links I3 and I8 are not current-order evidence. i3 NA0 sedan handled separately; i8 is PHEV. |
| CarsGuide | I5 | included_current_family | Normalise label to i5; current BEV family. CarsGuide's wagon/body grouping does not prove i5 Touring order availability; parent sedan worker resolves Touring separately. |
| CarsGuide | I7 | included_current_family | Normalise label to i7; current BEV family. CarsGuide's wagon/body grouping does not prove i5 Touring order availability; parent sedan worker resolves Touring separately. |
| CarsGuide | IX1 | included_current_family | Normalise label to iX1; current BEV family. CarsGuide's wagon/body grouping does not prove i5 Touring order availability; parent sedan worker resolves Touring separately. |
| CarsGuide | IX2 | included_current_family | Normalise label to iX2; current BEV family. CarsGuide's wagon/body grouping does not prove i5 Touring order availability; parent sedan worker resolves Touring separately. |
| CarsGuide | M Models | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | X Models | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | XM | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | Z Models | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | 3.0 | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | 3.3 | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | 6 Series | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | 1600 | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | 1602 | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | 1800 | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | 2000 | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | 2002 | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | 2500 | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | 2800 | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |
| CarsGuide | iX4 | included_arriving_misclassified_directory | Live directory puts iX4 under older models, but current maker technical page and 8 Oct Australian launch evidence establish new NA7 40/50 xDrive arriving Q1 2027. |
| CarsGuide | M Models | excluded_non_bev_or_historic | Non-BEV/legacy category. X Models and M Models are combustion/PHEV groupings; separately named electric i families are accounted for. Old-model labels do not establish new-order availability. |

## Residual exact-version closure
The parent/family packets must resolve CarsGuide’s older iX3, iX and i4 entries and i5 Touring. No factory-order exclusion is inferred solely from omission.

## Captures and reproducibility
Source metadata and SHA256 manifest accompany sanitized text/PDF captures. Live direct captures differ from cached web rendering for CarsGuide iX4 classification and CarExpert i3 copy; live captures are the reconciliation basis. No user computer, CAPTCHA, account changes or publishing occurred.

## Public source URLs
- [Discover all BMW models](https://www.bmw.com.au/en/all-models.html)
- [BMW Electric Cars](https://www.bmw.com.au/en/electric-cars.html)
- [BMW iX4 NA7 model page](https://www.bmw.com.au/en/models/x-series/suv/bmw-ix4.html)
- [BMW iX4 NA7 technical data](https://www.bmw.com.au/en/models/x-series/suv/bmw-ix4-technical-data.html)
- [BMW i3 NA0 sedan model page](https://www.bmw.com.au/en/models/3-series/sedan/bmw-i3-sedan.html)
- [BMW i3 NA0 sedan technical data](https://www.bmw.com.au/en/models/3-series/sedan/bmw-i3-sedan-technical-data.html)
- [BMW iX5 G65 model page](https://www.bmw.com.au/en/models/x-series/suv/bmw-ix5.html)
- [BMW iX5 G65 technical data](https://www.bmw.com.au/en/models/x-series/suv/bmw-ix5-technical-data.html)
- [BMW 3 Series M models](https://www.bmw.com.au/en/models/m-series/sedan/bmw-3-series-sedan-m-models.html)
- [BMW iX4 M60 xDrive](https://www.bmw.com.au/en/models/m-series/suv/bmw-ix4-m-models.html)
- [BMW model directory](https://www.carexpert.com.au/bmw)
- [BMW model directory](https://www.carsguide.com.au/bmw)
- [BMW i Series directory](https://www.carsguide.com.au/bmw/i-series)
- [2026 BMW i Series price guide](https://www.carsguide.com.au/bmw/i-series/price/2026)
- [2026 BMW iX3 price guide](https://www.carsguide.com.au/bmw/i-series/ix3/price/2026)
- [BMW i3 model directory: live page now describes NA0 sedan](https://www.carexpert.com.au/bmw/i3)
- [2027 BMW iX4 price and specs](https://www.carexpert.com.au/car-news/2027-bmw-ix4-price-and-specs)
- [2027 BMW i3: Australian price and specifications](https://www.carexpert.com.au/car-news/2027-bmw-i3-electric-3-series-to-deliver-solid-performance-and-driving-range)
- [BMW i3 40 xDrive NA0 specifications](https://www.carsales.com.au/research/bmw/i3/2026/40-xdrive/0938cc04-8a01-4743-881c-b141e61cd702/)
- [BMW i3 50 xDrive NA0 specifications](https://www.carsales.com.au/research/bmw/i3/2026/50-xdrive/71fe8bcc-86e9-4534-9639-e71b9381af72/)
- [BMW iX4 revealed: Australian launch details and European towing distinction](https://evcentral.com.au/bmw-ix4-revealed-neue-klasse-electric-coupe-suv-confirmed-for-australia-from-103900-with-up-to-828km-range/)
- [The new BMW iX4 global press kit](https://www.press.bmwgroup.com/global/article/detail/T0461402EN/the-new-bmw-ix4)
- [BMW iX4 UK technical data](https://www.bmw.co.uk/en/all-models/x-models/suv/bmw-ix4-technical-data.html)
- [CarExpert terms: publisher identity](https://www.carexpert.com.au/terms-and-conditions)
- [CarsGuide cookie policy: publisher identity](https://www.carsguide.com.au/cookie-policy)
- [BMW iX4 technical specifications](https://www.press.bmwgroup.com/global/article/attachment/T0461402EN/656880)
- [The new BMW iX4 full media information](https://www.press.bmwgroup.com/global/article/attachment/T0461402EN/656879)
