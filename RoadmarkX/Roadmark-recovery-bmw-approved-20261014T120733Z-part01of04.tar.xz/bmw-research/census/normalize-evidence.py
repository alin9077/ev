from pathlib import Path
import json, hashlib
R=Path('/tmp/bmw-research/census'); D='2026-10-14'
d=json.loads((R/'new-families-and-census.json').read_text()); canonical={'dc_charge_kw':'dc_peak_kw','dc_10_80_minutes':'dc_charge_time_min','ac_charge_kw':'ac_kw','acceleration_0_100_s':'zero_to_100_s','braked_towing_kg':'towing_braked_kg','front_storage_l':'frunk_l','boot_seats_down_l':'max_total_cargo_l'}
ss={s['id']:s for s in d['sources']}; out={'checkedAt':D,'sources':[],'variants':[],'notes':['Standalone census and captures unchanged. This builder-compatible derivative contains four arriving launch versions only. Future M60/iX5 records remain in standalone census.','Foreign-source origin retained explicitly; foreign facts always Reported, never AU Confirmed.','Parent may replace rung-5 prices with exact primary pricing and supplies shared brand terms.']}
for s in d['sources']:
 origin='AU' if s['market']=='AU' else 'UK' if s['market']=='UK' else 'DE' if s['id']=='global-ix4-tech' else 'GLOBAL'
 typ='manufacturer_au_specification' if s['type']=='manufacturer' and origin=='AU' else 'manufacturer_global_specification' if s['type']=='manufacturer' else 'reputable_au_motoring_publication'
 cap=s.get('textCapture',s['capture']); row={'key':s['id'],'file':'census/'+cap,'textFile':'census/'+cap,'url':s['url'],'title':s['title'],'publisher':s['publisher'],'source_type':typ,'sourceOriginMarket':origin,'market':origin,'published_date':s.get('published_date'),'accessed_date':D,'supports':s['title'],'source_capture_note':'Sanitized public source text; scripts, styles, response headers and HTML attributes omitted. PDFs locally extracted, without response metadata.'}
 if origin!='AU': row['notes']='Foreign maker source, '+origin+' scope. Used only as Reported overseas/same-body evidence; not Australian fitment or homologation.'
 if s['id']=='global-ix4-tech':row.update(visualReview='PDF pages 1 and 3 rendered and inspected for the named iX4 50/40 xDrive tables; all specifications explicitly refer to Germany.',published_month='2026-09')
 out['sources'].append(row)

def add(facts,key,value,src,basis,grade='confirmed',comparison='',reason='',condition=None,**kwargs):
 x={'key':key,'value':value,'grade':grade,'sourceKeys':src if isinstance(src,list) else [src],'basis':basis,'comparison':comparison,'reason':reason or ('Australian motoring publication reports the specified equipment for both local launch versions.' if grade=='reported' else 'Current BMW Australian material establishes the named-version or explicit range fact.'),**kwargs}
 if condition:x['condition']=condition
 if grade=='reported':x['evidenceScope']='secondary_or_sibling'
 elif grade=='not_published':x['evidenceScope']='searched_not_found'
 facts.append(x);return x

def feat(features,criterion,value,keys,**extra):features.append({'criterion':criterion,'value':value,'keys':keys,**extra})
for v in d['variants']:
 isx=v['model']=='iX4';num=v['trim'].split()[0];family='ix4' if isx else 'i3_sedan';code='na7' if isx else 'na0';tech='bmw-ix4-tech' if isx else 'bmw-i3-tech';page='bmw-ix4' if isx else 'bmw-i3';launch='carexpert-ix4-specs' if isx else 'carexpert-i3-launch';carsales='carsales-i3-'+num
 row={'id':f'bmw_{family}_{num}_xdrive_{code}_au__20261014','modelId':f'bmw_{family}_{code}','familyId':'bmw-ix4' if isx else 'bmw-i3-sedan','model':v['model'],'trim':v['trim'],'generation':code.upper()+'; current Australian launch specification; formal manufacturer model year not declared','drive':'AWD','modelYear':None,'vehicleClass':'passenger','rangeCycle':'WLTP','notes':['New Australian '+v['model']+' '+v['trim']+'; distinct from historic I01 i3 hatchback.' if not isx else 'New NA7 SUV coupe family.','Australian arrival announced for Q1 2027. Listing/configuration evidence does not establish accepted orders, allocation or physical stock.'],'facts':[],'features':[]}
 fs=row['facts'];features=row['features']
 for k,f in v['facts'].items():
  if k in ['warranty','battery_warranty','sibling_ix3_boot_l']:continue
  key=canonical.get(k,k);sources=f['sourceIds'];grade=f['suggestedBuyerGrade'];comparison=f.get('comparisonBasis','')
  if key=='range_km':comparison='WLTP'
  if key=='dc_charge_time_min':comparison='10–80%'
  if key=='battery_kwh':comparison='Battery capacity; gross/usable unspecified'
  if key=='width_mm':comparison='Body width; excludes mirrors'
  if key=='boot_l':comparison='Rear boot; seats up; method unspecified'
  if key=='max_total_cargo_l':comparison='Rear luggage; seats folded; method unspecified'
  if key=='frunk_l':comparison='Front storage; liquid volume'
  if key=='towing_braked_kg':comparison='Maximum braked towing' if f['value'] is not None else ''
  reason=f.get('gapReason') or ('Maker global German-market technical table explicitly states 5 seats for the matching NA7 body; this is Reported overseas evidence, not Australian-maker confirmation.' if key=='seats' and isx else 'carsales Australian exact NA0 grade page, sourced from RedBook, reports five seating positions.' if key=='seats' else 'Current BMW Australian technical table names the exact local version; general test/overseas-image disclaimers are not standalone grade conditions.')
  if key=='price_aud':reason='CarExpert Australian launch report gives this named-version price before on-road costs. Primary configurator review is pending with parent.';comparison='Before on-road costs'
  quals=[]
  for prop in ['method','transform','fitmentReview']:
   if f.get(prop):quals.append(f[prop])
  if key=='range_km':quals.append('Published configuration range: '+str(f['publishedRangeKm'])+' km. German-market optional-equipment basis is stated in the AU page footnote; exact AU configured range needs confirmation.')
  if f.get('unresolvedConflict'):quals.append('Unresolved source discrepancy: BMW AU lists 83.8 kWh; CarExpert and carsales/RedBook list 82.8 kWh. No typo correction or gross/net reconciliation is assumed.')
  if key=='seats' and isx:quals+=['Global PDF pages 1 and 3 refer to German-market specifications, with all figures marked provisional.']
  x=add(fs,key,f['value'],sources,f['basis'],grade,comparison,reason,f.get('condition'),unit=f.get('unit') or '',qualifications=quals)
  if key=='price_aud':x.update(priceRung=5,basisTag='Reported by CarExpert',originalBasis='Price before on-road costs',rankingEligible=False,sourcePointer=ss[launch]['url'])
  if key=='ac_kw' and isx:x['sourceKeys']=[tech,page]
 if isx:
  add(fs,'battery_usable_kwh',v['facts']['battery_kwh']['value'],launch,'Net battery capacity reported by CarExpert','reported','Usable/net battery capacity')
  add(fs,'battery_chemistry','NMC',launch,'Nickel manganese cobalt battery chemistry reported for both Australian launch grades','reported','Battery chemistry')
  add(fs,'towing_braked_overseas_kg',2000,['global-ix4-tech','evcentral-ix4'],'European/German same-version braked towing at 12% gradient; not an Australian towing rating','reported','','Australian official technical page omits towing. EV Central explicitly identifies 2000 kg as European only; retain as unranked reference.',qualifications=['Optional towbar required; Australian towing approval remains unpublished.'],unit='kg')
 else:
  add(fs,'ac_standard_fitment',None,[tech,page],'Standard Australian AC charger fitment','not_published','','BMW AU technical page publishes maximum 22 kW; neither that page nor model page explicitly establishes standard local onboard AC charger fitment.')
  if num=='40':add(fs,'battery_secondary_reported_kwh',82.8,['carexpert-i3-launch',carsales],'Australian secondary reported battery capacity; conflicts with 83.8 kWh on BMW AU page','reported','Battery capacity; gross/usable unspecified','CarExpert and carsales/RedBook agree on 82.8 kWh, but this does not resolve the current BMW AU 83.8 kWh value. Both observations are preserved.',unit='kWh')
 # Explicit primary range-wide equipment only where maker describes standard fitment.
 add(fs,'equipment_m_sport_package',True,page if isx else launch,'Standard Australian M Sport package','confirmed' if isx else 'reported','Standard equipment',evidenceScope='explicit_au_range' if isx else 'secondary_or_sibling',label='M Sport package')
 add(fs,'equipment_panoramic_roof',True,page if isx else launch,'Standard Australian panoramic glass roof','confirmed' if isx else 'reported','Standard equipment',evidenceScope='explicit_au_range' if isx else 'secondary_or_sibling',label='Panoramic glass roof',qualifications=[] if isx else ['BMW AU showcase prose calls the roof optional; local Australian launch reporting lists it standard. Retain Reported local fitment rather than globally promoting standard equipment.'])
 add(fs,'equipment_panoramic_vision',True,page,'BMW Panoramic Vision cabin display in current Australian model description','confirmed','Equipment presence',evidenceScope='explicit_au_range',label='Panoramic Vision')
 add(fs,'wheel_size_in',20 if isx else 19,launch,'Australian launch-standard M wheel diameter','reported','Wheel diameter',unit='in')
 for key,label in [('equipment_front_heated_seats','Heated front seats'),('equipment_rear_heated_seats','Heated rear seats'),('equipment_heated_steering_wheel','Heated steering wheel'),('equipment_3d_head_up_display','3D head-up display')]:add(fs,key,True,launch,'Reported Australian standard '+label.lower(),'reported','Standard equipment',label=label)
 if isx:
  for key,label in [('equipment_harman_kardon_audio','Harman Kardon audio'),('equipment_wireless_carplay','Wireless Apple CarPlay'),('equipment_wireless_android_auto','Wireless Android Auto'),('equipment_wireless_phone_charging','Wireless phone charging'),('equipment_power_tailgate','Powered tailgate'),('equipment_tyre_repair_kit','Tyre repair kit'),('equipment_mode3_cable','Mode 3 charging cable')]:add(fs,key,True,launch,'Reported Australian standard '+label.lower(),'reported','Standard equipment',label=label)
 else:
  # Exact Australian carsales specification supplies these items, independent of launch article omissions.
  for key,label in [('equipment_wireless_carplay','Wireless Apple CarPlay'),('equipment_wireless_android_auto','Wireless Android Auto'),('equipment_wireless_phone_charging','Wireless phone charging'),('equipment_power_tailgate','Powered boot lid'),('equipment_tyre_repair_kit','Tyre repair kit')]:add(fs,key,True,carsales,'Reported Australian standard '+label.lower(),'reported','Standard equipment','Exact NA0 Australian carsales/RedBook page lists this item for the named grade.',label=label)
  add(fs,'equipment_adaptive_m_suspension',True,launch,'Adaptive M suspension reported standard for both Australian launch versions','reported','Standard equipment',label='Adaptive M suspension')
 v2cond='Requires optional AC Charging Professional (SA4U6) and matching BMW adapters; those accessories are expected from Q4 2027. This is not available-now standard fitment.'
 add(fs,'v2l','Optional future capability',page,'V2L / Home Backup accessory-dependent future capability','check','','BMW AU footnote explicitly ties V2L and Home Backup to optional SA4U6 and corresponding BMW adapters expected Q4 2027.',v2cond,fitment='optional',label='Vehicle-to-load')
 add(fs,'v2l_required_equipment','AC Charging Professional (SA4U6) and matching BMW adapters',page,'Required optional V2L / Home Backup equipment','confirmed','Required accessories',label='V2L required equipment')
 add(fs,'v2l_accessory_expected_date','Q4 2027',page,'Expected availability of matching BMW V2L / Home Backup adapters','confirmed','Expected accessory availability',label='V2L accessory timing')
 feat(features,'glass_roof','A panoramic glass roof is '+('listed as standard by BMW Australia.' if isx else 'reported as standard for Australian launch cars; BMW’s showcase page also depicts optional equipment.'),['equipment_panoramic_roof'],grade='confirmed' if isx else 'reported')
 feat(features,'style_refinement',f'M Sport package and {20 if isx else 19}-inch M wheels are listed for Australian launch cars.',['equipment_m_sport_package','wheel_size_in'],grade='reported')
 feat(features,'front_heated_seats','Heated front seats are reported as standard.',['equipment_front_heated_seats'],grade='reported')
 feat(features,'rear_heated_seats','Heated rear seats are reported as standard.',['equipment_rear_heated_seats'],grade='reported')
 feat(features,'heated_steering_wheel','A heated steering wheel is reported as standard.',['equipment_heated_steering_wheel'],grade='reported')
 feat(features,'screens_hud','BMW Panoramic Vision is described by the maker; a 3D head-up display is reported as standard locally.',['equipment_panoramic_vision','equipment_3d_head_up_display'],grade='reported')
 feat(features,'carplay_android_auto','Wireless Apple CarPlay and Android Auto are reported for the Australian launch specification.',['equipment_wireless_carplay','equipment_wireless_android_auto'],grade='reported')
 feat(features,'wireless_charging','Wireless phone charging is reported as standard.',['equipment_wireless_phone_charging'],grade='reported')
 feat(features,'power_tailgate',('A powered tailgate' if isx else 'A powered boot lid')+' is reported as standard.',['equipment_power_tailgate'],grade='reported')
 feat(features,'spare_tyre','A tyre repair kit is listed in the Australian reported specification.',['equipment_tyre_repair_kit'],grade='reported')
 if isx:
  feat(features,'audio_system','Harman Kardon audio is reported as standard.',['equipment_harman_kardon_audio'],grade='reported')
  feat(features,'charging_cable','A Mode 3 charging cable is reported in the standard equipment list.',['equipment_mode3_cable'],grade='reported')
  feat(features,'home_charging','BMW lists up to 22 kW AC charging, requiring the optional charger equipment.',['ac_kw'],grade='check',conditions='BMW AU describes 22 kW AC as optional; confirm the selected charger equipment.')
  feat(features,'storage','Rear boot: 490 L with seats up, or 1600 L folded; rear-volume method unspecified. Separate front storage: 58 L, measured as liquid volume.',['boot_l','max_total_cargo_l','frunk_l'])
  feat(features,'battery_chemistry',f"BMW AU publishes {v['facts']['battery_kwh']['value']} kWh; CarExpert describes that as net capacity and reports NMC chemistry.",['battery_kwh','battery_usable_kwh','battery_chemistry'],grade='reported')
 else:
  feat(features,'home_charging','Maximum AC capability is listed as 22 kW; standard local onboard-charger fitment is not established in the checked maker pages.',['ac_kw','ac_standard_fitment'],grade='check',conditions='22 kW is a maximum capability figure; verify the fitted onboard charger before choosing home charging equipment.')
  feat(features,'storage','Rear boot: 420 L, method unspecified. Separate front compartment: 31 L, measured as liquid volume.',['boot_l','frunk_l'])
  if num=='40':feat(features,'battery_chemistry','BMW AU lists 83.8 kWh while CarExpert and carsales report 82.8 kWh. The discrepancy and gross/usable basis remain unresolved.',['battery_kwh','battery_secondary_reported_kwh'],grade='reported')
  else:feat(features,'battery_chemistry','BMW AU publishes 108.7 kWh capacity without labelling gross or usable.',['battery_kwh'])
 feat(features,'v2l','V2L and Home Backup require optional AC Charging Professional (SA4U6) and matching adapters, expected from Q4 2027.',['v2l','v2l_required_equipment','v2l_accessory_expected_date'],grade='check',status='optional',conditions=v2cond)
 row['availability']={'state':'announced_provisional','sourceKeys':[tech,page,launch],'orderStatus':'listed_unconfirmed','stockStatus':'unverified','qualifications':['Australian arrival announced for Q1 2027 (January–March).','Current manufacturer model/configurator listing is present, but Build & Price alone does not establish order acceptance.','Physical stock, allocation and any individual delivery date are unverified.','Formal manufacturer model year not established; Australian publications use a 2027 launch heading.'],'reason':'Current BMW AU named-version technical and model pages plus dated Australian launch reporting identify these arriving versions. No factory-order acceptance inferred.'}
 row['summary']={'strength':{'label':'Long-trip charging' if isx else 'Long-trip range','text':'A claimed 21-minute 10–80% charge and all-wheel drive give this SUV a long-trip focus.' if isx else f"BMW advertises up to {v['facts']['range_km']['value']} km WLTP and a claimed 21-minute 10–80% charge; range varies with configuration.",'keys':['dc_charge_time_min','drive'] if isx else ['range_km','dc_charge_time_min']},'tradeoff':{'label':'Check luggage space','text':'The rear boot is limited to 490 litres with the seats up; its measurement method is not stated.' if isx else 'The rear boot is 420 litres, with a separate 31-litre front compartment for smaller items.','keys':['boot_l'] if isx else ['boot_l','frunk_l']}}
 row['summaryConditions']=[] if isx else ['WLTP maximum is configuration-dependent; published AU table footnote includes German-market optional equipment.']
 out['variants'].append(row)
# Trim source set to actual citations; no unrelated future/model-directory records in import derivative.
used=set()
for v in out['variants']:
 for f in v['facts']:used.update(f['sourceKeys'])
 used.update(v['availability']['sourceKeys'])
out['sources']=[s for s in out['sources'] if s['key'] in used]
(R/'normalized-evidence.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
errs=[];smap={s['key']:s for s in out['sources']}
for v in out['variants']:
 fm={f['key']:f for f in v['facts']}
 if len(fm)!=len(v['facts']):errs.append('duplicate fact '+v['id'])
 for f in v['facts']:
  for s in f['sourceKeys']:
   if s not in smap:errs.append('unknown source '+s)
   elif smap[s]['sourceOriginMarket']!='AU' and f['grade']!='reported':errs.append('foreign nonreported '+f['key'])
  if f['grade']=='check' and not f.get('condition'):errs.append('check lacks condition '+f['key'])
  if f['grade']=='not_published' and (f['value'] is not None or len({smap[k]['url'] for k in f['sourceKeys']})<2):errs.append('invalid notpublished '+f['key'])
 for fr in v['features']:
  for k in fr['keys']:
   if k not in fm:errs.append('missing feature dep '+k)
 for cl in v['summary'].values():
  for k in cl['keys']:
   if k not in fm:errs.append('missing summary dep '+k)
for s in out['sources']:
 if not (R.parent/s['file']).is_file():errs.append('missing capture '+s['file'])
validation={'checkedAt':D,'variants':len(out['variants']),'sources':len(out['sources']),'facts':sum(len(x['facts']) for x in out['variants']),'features':sum(len(x['features']) for x in out['variants']),'errors':errs,'normalizedSha256':hashlib.sha256((R/'normalized-evidence.json').read_bytes()).hexdigest(),'standaloneCensusSha256':hashlib.sha256((R/'new-families-and-census.json').read_bytes()).hexdigest(),'operations':'Local derivative/source/dependency checks only; no catalogue load, repository edits or heavy tests.'};(R/'normalized-validation.json').write_text(json.dumps(validation,indent=2));print(json.dumps(validation,indent=2));assert not errs
# Separate new derivative manifest: leave standalone capture manifest and deliverable unchanged.
files=['normalize-evidence.py','normalized-evidence.json','normalized-validation.json'];(R/'normalized-SHA256SUMS').write_text(''.join(hashlib.sha256((R/f).read_bytes()).hexdigest()+'  '+f+'\n' for f in files))
