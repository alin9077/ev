import json,pathlib,copy
R=pathlib.Path('/tmp/bmw-research');p=json.loads((R/'normalized-evidence.json').read_text());supp=json.loads((R/'census/browser-updates-sedans.json').read_text());byid={v['id']:v for v in p['variants']}
for s in supp['sources']:
 if s['status']!='retrieved':continue
 p['sources'].append(dict(key=s['key'],url=s['url'],title='BMW Australia exact i3 '+s['key'].split('_')[-2].upper()+' '+s['key'].split('_')[-1]+' configurator capture',publisher='BMW Australia',source_type='manufacturer_au_configurator',file=s['capturePath'],accessed_date='2026-10-14',finalUrl=s.get('fullConfiguredUrl'),notes='Public rendered cloud-browser text. Exact model and configured option scope retained; no accepted order, physical stock or inferred gross/net label.'))
for upd in supp['variantUpdates']:
 v=byid[upd['id']];v['trim']=upd['trim']+' M Sport';facts={f['key']:f for f in v['facts']};oldprice=copy.deepcopy(facts['price_aud']);oldprice['key']='reported_list_price_aud';facts[oldprice['key']]=oldprice
 code=upd['modelCode'].lower();tech='sedan_i3_'+code+'_tech';price='sedan_i3_'+code+'_price'
 for f0 in upd['factUpdates']:
  f=copy.deepcopy(f0);k=f['key'];old=facts.get(k,{});f={**{x:old[x]for x in ['unit','label']if x in old},**f};f['reason']='Current exact Australian '+upd['modelCode']+' '+v['trim']+' configurator technical/price panel explicitly publishes this source-scoped claim.'
  if k=='kerb_weight_kg':f['key']=k='unladen_ec_weight_kg';f['basis']='European unladen mass including driver; not Australian kerb/tare';f['comparison']='EC unladen mass'
  if k=='battery_configurator_kwh':f['grade']='confirmed';f['comparison']='Battery capacity; gross/usable unspecified'
  if k=='ac_configurator_kw'and code=='52jb':f['condition']='Exact configured panel lists 11 kW; Australian model page lists 22 kW maximum capability. Included AC Charging Professional fitment was not recovered.'
  if k=='ac_0_100_min'and code=='52jb':f['condition']='This is the configurator 0–100% duration at its displayed 11 kW AC setting; the 22 kW maximum-capability page does not establish this configuration’s included charger.'
  if k=='price_aud':f['state']='VIC';f['rankingEligible']=True;f['comparison']='Driveaway'
  if k=='towball_kg':f['grade']='check';f['condition']='Requires approved towbar and compliant vehicle/trailer loading.'
  if k=='width_mm':f['basis']='Body width excluding mirrors';f['comparison']='Body width excluding mirrors'
  if k=='width_with_mirrors_mm':f['basis']='Width including mirrors';f['comparison']='Width including mirrors'
  facts[k]=f
 if code=='32jb':
  facts['battery_kwh'].update(grade='check',sourceKeys=['bmw-i3-tech',tech],condition='BMW AU model technical page lists 83.8 kWh, while the exact 32JB configurator lists 82.8 kWh. Neither labels usable versus gross. Confirm the quoted configuration; no silent numerical correction is made.',reason='Two current Australian manufacturer publications disagree numerically. Both source-scoped capacities remain visible.')
  facts['ac_kw'].update(sourceKeys=[tech],reason='Exact selected Australian 32JB configuration publishes 22 kW maximum AC capability.',qualifications=['Maximum vehicle AC input; this does not separately certify the option-package label.'])
 else:
  alt=copy.deepcopy(facts['ac_kw']);alt.update(key='ac_maximum_advertised_kw',grade='check',condition='BMW AU page lists 22 kW maximum capability; exact 52JB selected technical panel lists 11 kW and included optional charger fitment was not recovered.',reason='Keep advertised maximum capability separate from the exact configured technical panel.')
  facts[alt['key']]=alt
  facts['ac_kw'].update(value=11,grade='check',sourceKeys=[tech,'bmw-i3-tech'],basis='Exact configured maximum AC input; separate Australian advertised maximum is 22 kW',comparison='Maximum AC input',condition='Exact 52JB configurator lists 11 kW; Australian model page lists 22 kW maximum capability. AC Charging Professional selected status was not recovered, so standard 22 kW is not asserted.',reason='Prefer the exact configured panel for this selected configuration and retain the broader maker capability as a separate qualified fact.',qualifications=[])
 # Exact default price capture includes the selected M Sport variant, 19-inch wheel and wireless charger.
 for key,val in [('wheel_size_in',19),('equipment_m_sport_package',True),('equipment_wireless_phone_charging',True)]:
  facts[key].update(value=val,grade='confirmed',sourceKeys=[price],evidenceScope='exact_au_version',reason='The exact Australian zero-paid-option M Sport configuration visibly selects this equipment.',basis='Selected current Australian M Sport configuration')
 v['availability']['sourceKeys']+= [price,tech]
 for fr in v['features']:
  if fr['criterion']=='home_charging':
   fr['keys']=['ac_kw','ac_0_100_min','ac_standard_fitment'];fr['value']='Exact 32JB technical panel lists 22 kW AC and 4 h 15 min for 0–100%; check the fitted charger before selecting home infrastructure.'if code=='32jb'else'Exact 52JB technical panel lists 11 kW AC and 11 hours for 0–100%; a separate maker page advertises 22 kW maximum capability, so charger fitment needs checking.'
   fr['conditions']=facts['ac_kw'].get('condition','The maximum charging capability does not independently establish the included option-package label; suitable supply is required.')
  if fr['criterion']in ['style_refinement','wireless_charging']:
   fr['grade']='confirmed';fr['evidenceScope']='exact_au_version';fr['value']='M Sport and selected 19-inch M wheels are included in the current zero-paid-option configuration.'if fr['criterion']=='style_refinement'else'The selected Wireless charging tray Plus is included in this zero-paid-option configuration.'
 v['facts']=list(facts.values())
# Exact model/body identity gets a citable primary fact. Broader residual cohorts remain open in reconciliation.
for v in p['variants']:
 body='Wagon'if 'touring' in v['modelId']else'Liftback'if v['model']=='i4'else'SUV'if v['model'].startswith('iX')else'Sedan'
 primary=next(k for k in v['availability']['sourceKeys']if next(s for s in p['sources']if s['key']==k)['publisher']=='BMW Australia')
 v['facts'].append(dict(key='body_style',value=body,grade='confirmed',sourceKeys=[primary],basis='Exact current model/body identity',comparison='Body style',reason='The cited Australian maker body/model listing identifies this body; sedan, Touring wagon, liftback and SUV cohorts are kept separate.'))
 # Capacity is not chemistry. Do not answer an LFP question using kWh alone.
 v['features']=[f for f in v['features']if f['criterion'] not in ['warranty_service','home_charging'] and (f['criterion']!='battery_chemistry' or any('chemistry' in k for k in f['keys']))]
 for f in v['facts']:
  f['qualifications']=[q for q in f.get('qualifications',[])if not q.startswith('Parent should')]
  if f['key']=='price_aud'and f.get('grade')=='reported':f['reason']=f.get('reason','').replace('Primary configurator review is pending with parent.','A usable exact primary price was not recovered in the dated configurator checks; the attributed reported price remains the eligible fallback.')
  if f.get('grade')=='check':assert f.get('condition'),(v['id'],f['key'])
 used={k for f in v['facts']for k in f['sourceKeys']};used.update(v['availability']['sourceKeys'])
 for fr in v['features']:
  assert set(fr['keys'])<=set(f['key']for f in v['facts'])|{'warranty','battery_warranty','roadside_assistance'},(v['id'],fr['criterion'])
used={k for v in p['variants']for f in v['facts']for k in f['sourceKeys']}|{k for v in p['variants']for k in v['availability']['sourceKeys']}|{k for f in json.loads((R/'terms-normalized.json').read_text()).values()for k in f['sourceKeys']}
p['sources']=[s for s in p['sources']if s['key']in used]
# Foreign maker evidence remains Reported under the established source taxonomy.
foreign=next(s for s in p['sources'] if s['key']=='global-ix4-tech')
assert foreign.get('sourceOriginMarket')=='DE'
foreign['source_type']='manufacturer_overseas_reported'
(R/'normalized-evidence.json').write_text(json.dumps(p,indent=2,ensure_ascii=False)+'\n')
print('Final normalized',len(p['variants']),len(p['sources']),sum(len(v['facts'])for v in p['variants']))
