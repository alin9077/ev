import json,pathlib
R=pathlib.Path('/tmp/bmw-research');p=json.loads((R/'normalized-evidence.json').read_text());valid={f['criterion']for f in json.loads((R/'bmw-feature-before.json').read_text())};removed=[]
for v in p['variants']:
 fs=v['features'];named={f['criterion']:f for f in fs}
 if 'apple_carplay'in named and 'android_auto'in named and 'carplay_android_auto'not in named:
  fs.append(dict(criterion='carplay_android_auto',value='Apple CarPlay and Android Auto are included.',keys=named['apple_carplay']['keys']+named['android_auto']['keys']))
 removed.extend({'variantId':v['id'],'criterion':f['criterion'],'retainedFactKeys':f['keys']}for f in fs if f['criterion']not in valid)
 v['features']=[f for f in fs if f['criterion']in valid]
(R/'normalized-evidence.json').write_text(json.dumps(p,indent=2,ensure_ascii=False)+'\n');(R/'feature-criterion-integration-audit.json').write_text(json.dumps({'checkedAt':'2026-10-14','actualCriterionCount':len(valid),'unsupportedProjectionNamesRemoved':removed,'factsAndSummaryDependenciesPreserved':True,'semanticRemovals':['automatic_seat_climate: cabin AC zones are not seat automation','performance_rear_motor: system output is not rear-motor hardware','navigation_route_planner: ordinary navigation is not charging itinerary','battery_chemistry: capacity is not chemistry','warranty_service: live criterion asks servicing interval/pricing','home_charging: live criterion asks a single-phase7kW duration, not maxAC']},indent=2)+'\n')
