import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {catalogue,research,effectiveFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/data.ts';
import {applyBrandUpdates,prepareBrandResearch} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-updates.ts';
const R='/tmp/bmw-research/';
const p=JSON.parse(fs.readFileSync(R+'bmw-2026-10-14.json','utf8'));
const canonical=JSON.stringify({...p,features:[]});
const canonicalHash=crypto.createHash('sha256').update(canonical).digest('hex');
console.log('Loading current catalogue for final canonical new-version baseline',canonicalHash);
const snapshotPath=R+'replay-snapshot-index.json';
function saveSnapshot(rd:any,before:any[]){
 const dir=R+'replay-snapshot';fs.mkdirSync(dir,{recursive:true});const index:any={research:{},cars:'replay-snapshot/cars.jsonl'};
 const writeRows=(file:string,rows:any[])=>{console.log('Snapshot',file,rows.length);const fd=fs.openSync(R+file,'w');try{for(let i=0;i<rows.length;i++){fs.writeSync(fd,JSON.stringify(rows[i])+'\n');if(i%50===0)global.gc?.();}}finally{fs.closeSync(fd);}};
 for(const [k,v]of Object.entries(rd)){const file='replay-snapshot/research-'+k+'.jsonl';if(Array.isArray(v)){writeRows(file,v);index.research[k]={file,array:true};}else{writeRows(file,[v]);index.research[k]={file,array:false};}}
 writeRows(index.cars,before);fs.writeFileSync(snapshotPath,JSON.stringify(index,null,2));
}
const rd=research(),before=catalogue();
saveSnapshot(rd,before);
assert.deepEqual(JSON.parse(JSON.stringify(before.filter(c=>c.brand==='BMW'))),JSON.parse(fs.readFileSync(R+'bmw-live-before.json','utf8')));
const data=prepareBrandResearch(rd,[p]),cars=applyBrandUpdates(before,data,[p]);
const newCars=cars.filter(c=>p.variants.some((v:any)=>v.id===c.id));
const fixture=newCars.flatMap(c=>effectiveFeatures(c,data));
fs.writeFileSync(R+'new-feature-before.json',JSON.stringify(fixture,null,2));
fs.writeFileSync(R+'canonical-baseline-meta.json',JSON.stringify({createdAt:new Date().toISOString(),canonicalHash,newIds:newCars.map(c=>c.id),featureRows:fixture.length,note:'Generated once only after final canonical facts, roadside and offers. Full row equality must be independently tested; never refreshed to mask a before-state mismatch.'},null,2));
// Reuse current read-only snapshot for the serial staged replay, avoiding a second heavy catalogue hydration.
// Streamed per-row snapshot above avoids one giant JSON allocation.
console.log('Captured',newCars.length,'new versions',fixture.length,'features');
