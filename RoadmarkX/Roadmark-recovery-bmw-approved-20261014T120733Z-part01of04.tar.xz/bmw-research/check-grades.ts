import fs from 'node:fs';
import {hasEarnedBuyerGrade} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/evidence-grading.ts';
import {priceCandidateRejection} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/price-ladder.ts';
const p=JSON.parse(fs.readFileSync('/tmp/bmw-research/bmw-2026-10-14.json','utf8'));let bad:any[]=[];
for(const row of p.facts){if(!hasEarnedBuyerGrade(row.after,p.sources,p.reviewedAt))bad.push([row.variantId,row.after.key,row.after.buyerGrade,row.after.gradeReview]);}
for(const row of p.features){if(!hasEarnedBuyerGrade(row.after,p.sources,p.reviewedAt))bad.push([row.variantId,row.criterion,row.after.buyerGrade,row.after.gradeReview]);}
console.log(JSON.stringify({bad},null,2));
