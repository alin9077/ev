import json,pathlib,copy,re
R=pathlib.Path('/tmp/bmw-research');old={x['id']:x for x in json.load(open(R/'bmw-live-before.json'))};D='2026-10-14'
out=dict(sources=[],variants=[]);keys=set()
for fam in ['ix','compact','sedans','census']:
 p=json.load(open(R/fam/'normalized-evidence.json'));sr=p['sources'];sr=list(sr.values())if isinstance(sr,dict)else sr
 for s in sr:
  s=copy.deepcopy(s);s.setdefault('key',s.get('id'));s.setdefault('title',s['key']);s.setdefault('publisher','BMW Australia');s.setdefault('source_type','manufacturer_au_specification'if s['publisher']=='BMW Australia'else'independent_automotive_publication')
  for fk in ['file','textFile']:
   if not s.get(fk):continue
   f=pathlib.Path(s[fk]);f=f if f.is_absolute()else(R/f if(R/f).exists()else R/fam/f);s[fk]=str(f)
  if not s.get('file'):
   s['access_limitation']=s.get('error',s.get('retrieval','Capture not recovered'));s.pop('file',None)
  if s['key'] in keys:
   assert next(x for x in out['sources']if x['key']==s['key'])==s,s['key']
  else:out['sources'].append(s);keys.add(s['key'])
 for v in p['variants']:
  v=copy.deepcopy(v);v.setdefault('familyId','bmw-'+v['model'].lower().replace(' ','-'));v.setdefault('drive',next((f['value']for f in v['facts']if f['key']=='drive'),'Unknown'))
  if 'availability'not in v or v['availability'].get('state') in ['On sale now','Order open or arriving']:
   av=v.get('availability',{});future=av.get('state')=='Order open or arriving'or v.get('recordState')in ['announced_future','announced_provisional'];src=av.get('sourceKeys')or list(dict.fromkeys(x for f in v['facts']for x in f['sourceKeys'] if 'bmw' in x or 'config' in x))[:3]
   quals=[av.get('detail')or v.get('availabilityReason')or'Current Australian maker named-version listing; physical stock, accepted factory order and delivery date are not verified.']
   if future:quals.insert(0,'First customer deliveries expected '+('Q4 2026'if v['model']in ['i7','iX3']else'Q1 2027')+'.')
   v['availability']=dict(state='announced_provisional'if future else'current_or_order_listed',orderStatus='listed_unconfirmed',stockStatus='new_stock_listed'if av.get('state')=='On sale now'and any('new'in k for k in src)else'unverified',sourceKeys=src,qualifications=quals+['Physical unsold stock and factory-order acceptance have not been verified.'],reason=av.get('detail')or v.get('availabilityReason')or'Current Australian maker lists this exact configuration.')
  if v['availability']['state']=='announced_provisional' and v['model'] in ['i3','i3 Sedan','iX4']:
   v['availability']['qualifications'].insert(0,'First deliveries expected Q1 2027; published Australian arrival window, not an individual delivery commitment.')
  if v['id']in old and v['drive']!=old[v['id']]['drive']:
   v['metadata']={'drive':v['drive']};v['metadataReason']='Current Australian named-version evidence establishes the drivetrain without changing its existing model/code identity.'
  if v['model']=='i7' and v.get('summary'):
   v['summary']['tradeoff']['text']='The reported list price is A$306,900 before on-road costs, and the body is 5.395 m long.'
  # Central shared terms own these three cells.
  v['facts']=[f for f in v['facts']if f['key']not in ['warranty','battery_warranty','roadside_assistance']]
  for f in v['facts']:
   if f.get('evidenceScope')=='explicit_au_body':f['evidenceScope']='explicit_au_range'
   if f.get('grade')=='reported':f['evidenceScope']='secondary_or_sibling'
   if f.get('grade')=='not_published':f['evidenceScope']='searched_not_found'
   if f['key']=='towing_kg':f['key']='towing_braked_kg'
   if f.get('priceRung')==4:f['state']='VIC'
   if f['key']=='max_total_cargo_l':f['label']='Expanded luggage volume'
   if f.get('unit')is None:f.pop('unit',None)
   if f.get('grade')=='check'and not f.get('reason'):f['reason']='Current Australian maker claim has this specific configuration or measurement condition: '+f['condition']
   if f.get('grade')=='reported'and not f.get('reason'):f['reason']='Attributed secondary or same-body figure; exact Australian maker confirmation has not been established for this claim.'
   # Preserve scope/alternative source provenance in the citable fact rather than dropping it.
   alternatives=f.get('alternatives',[])
   for a in alternatives:
    if a.get('sourceKey')and a['sourceKey']not in f['sourceKeys']:f['sourceKeys'].append(a['sourceKey'])
  # Prevent alias duplicates generated from canonical + legacy reconciliation.
  seen={}
  for f in v['facts']:
   if f['key']in seen:
    assert seen[f['key']]['value']==f['value'],(v['id'],f['key']);continue
   seen[f['key']]=f
  v['facts']=list(seen.values())
  assert not any(fr['criterion']=='automatic_seat_climate' for fr in v.get('features',[])), 'Cabin AC zones do not establish automatic seat climate'
  for fr in v.get('features',[]):
   fr['keys']=['towing_braked_kg'if k=='towing_kg'else k for k in fr['keys']]
   if fr.get('grade')=='reported':fr['evidenceScope']='secondary_or_sibling'
   if fr.get('evidenceScope')=='explicit_au_body':fr['evidenceScope']='explicit_au_range'
   conds=[seen[k].get('condition')for k in fr['keys']if k in seen and seen[k].get('condition')]
   if conds and not fr.get('conditions'):fr['conditions']=' '.join(dict.fromkeys(conds))
   if fr.get('status')=='standard'and any(seen.get(k,{}).get('grade')in ['reported','check']for k in fr['keys']):fr.pop('status')
  if 'summary'in v:
   conds=[]
   for clause in ['strength','tradeoff']:
    v['summary'][clause]['keys']=['towing_braked_kg'if k=='towing_kg'else k for k in v['summary'][clause]['keys']]
    for k in v['summary'][clause]['keys']:
     if seen.get(k,{}).get('condition'):conds.append(seen[k]['condition'])
   v['summaryConditions']=list(dict.fromkeys(v.get('summaryConditions',[])+conds))
  out['variants'].append(v)
used=set()
for v in out['variants']:
 used.update(v['availability']['sourceKeys'])
 for f in v['facts']:used.update(f['sourceKeys'])
for t in json.load(open(R/'terms-normalized.json')).values():used.update(t['sourceKeys'])
# Failed retrievals stay in research logs; only successful used observations enter the candidate packet.
missing=[k for k in used if k not in keys];assert not missing,missing
bad=[s['key']for s in out['sources']if s['key']in used and s.get('access_limitation')];assert not bad,bad
out['sources']=[s for s in out['sources']if s['key']in used]
(R/'normalized-evidence.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print('Combined',len(out['variants']),'versions',len(out['sources']),'sources',sum(len(v['facts'])for v in out['variants']),'facts')
