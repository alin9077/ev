import urllib.request,pathlib,json,re,html,sys,hashlib
R=pathlib.Path('/tmp/bmw-research')
def capture(key,url):
 p=R/key;p.parent.mkdir(parents=True,exist_ok=True)
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
  with urllib.request.urlopen(req,timeout=60) as r:b=r.read();final=r.url;status=r.status
  if p.suffix=='.pdf':p.write_bytes(b)
  else:
   # Save only public visible body text and non-secret structured vehicle facts.
   s=b.decode();s=re.sub(r'<(script|style)[\s\S]*?</\1>','',s,flags=re.I);s=re.sub('<[^>]+>','\n',s);s=html.unescape(s);s='\n'.join(x.strip() for x in s.splitlines() if x.strip());p.write_text(s)
  meta={'url':url,'finalUrl':final,'status':status,'checkedOn':'2026-10-14','captureFile':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'privacyTransformation':'Public response-body text only; scripts/style/HTML attributes and all response headers omitted' if p.suffix!='.pdf' else 'Public PDF body only; no response headers retained'};p.with_suffix(p.suffix+'.meta.json').write_text(json.dumps(meta,indent=2));print(meta,flush=True)
 except Exception as e:print(key,type(e).__name__,str(e),flush=True)
if __name__=='__main__':
 for key,url in json.loads(sys.argv[1]):capture(key,url)
