from pathlib import Path
import json, re, copy, hashlib
P=Path('/tmp/bmw-research/compact'); p=P/'normalized-evidence.json';d=json.loads(p.read_text())
source_key='config-price-12HR'; fn=source_key+'.txt';raw=(P/fn).read_text(); normalized_raw=raw.replace('\u00a0',' ')
assert 'State Victoria Base price $81,727 Selected options $0' in raw
assert 'Manufacturer’s Recommended Drive-away Price (MRDP)* $98,254' in raw
assert 'BMW iX3 40' in raw and 'Alpine White' in raw and '1048 M' in normalized_raw
url=re.search(r'URL: "([^"]+)"',raw).group(1)
d['sources'][source_key]={'key':source_key,'url':url,'title':'BMW Australia 12HR default M Sport configuration price overview','publisher':'BMW Australia','kind':'primary','checkedAt':'2026-10-14','file':fn,'retrieval':'Parent cloud-browser accessibility capture; Victoria price overview with postcode 3000 inherited from the selected browser location','retrievalStatus':'captured'}
v=next(v for v in d['variants'] if v['modelCode']=='12HR');q=next(f for f in v['facts'] if f['key']=='price_aud')
assert q['grade']=='reported' and q['value']==89900
reported=copy.deepcopy(q);reported['key']='reported_list_price_aud';v['facts'].append(reported)
q.clear();q.update(key='price_aud',value=98254,grade='check',sourceKeys=[source_key],priceRung=4,basis='Manufacturer recommended drive-away price, Victoria postcode 3000, Alpine White, standard 20-inch 1048 M wheels and no selected paid options',comparison='Driveaway',basisTag='Maker driveaway · VIC',rankingEligible=True,state='VIC',postcode='3000',condition='State-specific Victoria price, postcode 3000 inherited from the selected configurator location; Alpine White, standard 20-inch 1048 M wheels and no paid options. Charges vary by location.')
v['facts'].append(copy.deepcopy(dict(q,key='driveaway_price_aud')))
v['features'].append({'criterion':'driveaway_price','value':'A$98,254 manufacturer recommended drive-away, VIC 3000, Alpine White with standard 20-inch wheels and no paid options.','keys':['price_aud'],'status':'conditional'})
v['summary']['strength']['label']='21-minute DC charging'
removed=[]
for v in d['variants']:
 old=len(v['features']);v['features']=[f for f in v['features'] if f.get('criterion')!='navigation_route_planner']
 if len(v['features'])<old: removed.append(v['id'])
assert len(removed)==4
note='Ordinary navigation, BMW Maps and real-time traffic remain recorded as equipment facts. They do not establish an EV route planner with automatic charging stops, arrival state of charge or live charger availability, so no navigation_route_planner feature is mapped.'
if note not in d['conflictsAndUseNotes']:d['conflictsAndUseNotes'].append(note)
errors=[]
core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty_vehicle_private','battery_warranty_private']
for v in d['variants']:
 keys=[f['key'] for f in v['facts']]
 if len(keys)!=len(set(keys)):errors.append([v['id'],'duplicate facts'])
 for k in core:
  if k not in keys:errors.append([v['id'],'missing core',k])
 for row in v['features']+list(v['summary'].values()):
  for k in row['keys']:
   if k not in keys:errors.append([v['id'],'missing dependency',k])
 for f in v['facts']:
  if f.get('priceRung')==4 and f.get('state')!='VIC': errors.append([v['id'],'rung 4 missing state'])
  for sk in f['sourceKeys']:
   s=d['sources'].get(sk)
   if not s or s.get('retrievalStatus')=='failed' or not s.get('file') or not (P/s['file']).exists():errors.append([v['id'],f['key'],'source capture problem',sk])
assert not errors,errors
p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
md=(P/'FINDINGS.md').read_text().replace('A$89,900 before ORC, Reported fallback','A$98,254 maker VIC 3000 drive-away, no options').replace('The 32HR configurator price is captured; iX3 40 retains its Reported before-on-road fallback while the parent pursues its primary price.','All four regular versions now have captured primary configurator prices. The iX3 40 price is A$98,254 for Alpine White, standard 20-inch 1048 M wheels and no paid options; its A$89,900 Reported list price remains a separate fact, not the preferred price.')
anchor='- G08 Australian legacy trims are M Sport and M Sport Pro.'
md=md.replace(anchor,'- Ordinary navigation and BMW Maps equipment facts are retained, but none of the four regular versions is mapped positively to the EV route-planner criterion without evidence of charging stops, arrival state of charge or live charger availability\n'+anchor)
(P/'FINDINGS.md').write_text(md)
manifest=json.loads((P/'manifest-sha256.json').read_text()); files=[]
for f in sorted(P.iterdir()):
 if not f.is_file() or f.name=='manifest-sha256.json' or f.suffix=='.py': continue
 b=f.read_bytes();files.append({'file':f.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'kind':'local_pdf_render' if f.name.endswith('-local-pdf-render.png') else 'public_source_or_findings'})
manifest.update(files=files,validationErrors=errors,variantCount=len(d['variants']),coreFactsFilled=len(core)*len(d['variants']))
(P/'manifest-sha256.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'variants':len(d['variants']),'facts':sum(len(v['facts']) for v in d['variants']),'features':sum(len(v['features']) for v in d['variants']),'removedNavigationMappings':len(removed),'filesHashed':len(files),'coreFactsFilled':85,'validationErrors':errors},indent=2))
