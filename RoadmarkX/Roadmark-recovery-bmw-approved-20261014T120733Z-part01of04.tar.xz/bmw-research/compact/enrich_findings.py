import json,re,pathlib,copy
P=pathlib.Path('/tmp/bmw-research/compact');p=P/'normalized-evidence.json';x=json.load(open(p));before=json.load(open('/tmp/bmw-research/bmw-live-before.json'))
def fact(k,v,s,g='confirmed',**kw):return dict(key=k,value=v,sourceKeys=[s],grade=g,**kw)
for v in x['variants']:
 n=v['model'].lower();tech=n+'-tech';src=n+'-current';is3=n=='ix3';code=v['modelCode'];f=v['facts'];keys={i['key'] for i in f};old=next(o for o in before if o['id']==v['id'])
 # Preserve all previously populated verified non-core facts from rechecked same technical table.
 for k in ['unladen_ec_weight_kg','gvm_kg','payload_kg','manufacturer_model_code','width_mirrors_mm','ac_port','dc_port']:
  val=old['facts'].get(k,{}).get('value')
  if val is not None and k not in keys:f.append(fact(k,val,src if k in ['ac_port','dc_port','manufacturer_model_code'] else tech,basis='EC unladen includes 75 kg driver; not Australian kerb/tare' if k=='unladen_ec_weight_kg' else 'Current Australian maker publication'))
 for k,val in [('warranty_years',5),('battery_warranty_years',8),('battery_warranty_km',160000),('warranty','5 years / unlimited kilometres for private use'),('battery_warranty','8 years / 160,000 km'),('roadside_assistance',{'years':8,'unlimited_km':True})]:
  f.append(fact(k,val,'warranty',evidenceScope='brand_au_terms'))
 if is3:f.append(fact('frunk_l',58,tech,basis='Liquid volume',comparison='Liquid-volume frunk'))
 if code!='32HR': f.append(fact('towball_kg',75 if n=='ix1' else 80,tech,'check',condition='Requires appropriate towing equipment; NA5 local accessory availability needs confirmation' if is3 else 'Requires appropriate tow equipment; depends on vehicle options'))
 for q in f:
  if q['key'].startswith('equipment_') and q['value'] is False and q['grade']=='check':q['value']=True;q['standardFitment']=False
 # Canonical feature names used by site; source claim tied to an actual equipment fact.
 canonical={'parking_camera_360':'parking_cameras','premium_audio':'audio_system','panoramic_roof':'glass_roof','head_up_display':'screens_hud','driver_assistance':'adas_standard','driving_assistant_professional':'adas_standard','wireless_phone_charging':'wireless_charging'}
 for a in v['features']:a['criterion']=canonical.get(a['criterion'],a['criterion'])
 new=[('phone_key','BMW Digital Key Plus and NFC key card are included.','digital_key_plus'),('passive_unlock','Comfort Access includes automatic proximity unlocking.','comfort_access'),('walk_away_lock','Comfort Access includes automatic proximity locking.','proximity_lock'),('folding_mirrors','Exterior mirrors have electric fold-in operation.','folding_mirrors'),('carplay_android_auto','Apple CarPlay and Android Auto smartphone integration are included.','smartphone_integration'),('charging_cable','Mode 3 public-charging cable is included; '+('Multifunctional Charger is included.' if is3 else 'a Mode 2 Flexible Fast Charge cable is also included.'),'charging_cables'),('spare_tyre','A tyre repair kit is included.','tyre_repair_kit'),('voice_assistant','BMW Intelligent Personal Assistant is listed.' if not is3 else 'Voice operation through BMW Intelligent Personal Assistant is described on the current model page.','intelligent_personal_assistant')]
 if not is3:new += [('ota_capability_scope','Remote Software Update is listed.','remote_software_update'),('navigation_route_planner','Navigation guidance is included; the exact automatic charging-stop behaviour is not stated in the guide.','navigation_guidance'),('driver_profiles_local','Personal Profile is listed.','personal_profile'),('dashcam','Drive Recorder is included with Parking Assistant Plus.','drive_recorder')]
 else:new += [('screens_hud','BMW 3D Head-Up Display, Panoramic Vision and 17.9-inch central display are standard.','screens'),('navigation_route_planner','BMW Maps, Proactive Navigation and real-time traffic are included in the three-year BMW Digital Premium subscription.','navigation_digital_premium'),('dashcam','Drive Recorder is included in the three-year BMW Digital Premium subscription.','drive_recorder'),('sentry_parked_recording','Anti-Theft Recorder and Parking Collision Recorder are included in the three-year BMW Digital Premium subscription.','parked_recorders'),('driver_profiles_local','BMW ID can save customised settings to individual driver profiles.','driver_profiles')]
 seen={a['criterion'] for a in v['features']}
 for crit,txt,k in new:
  fk='equipment_'+k;ss=n+'-model' if is3 and crit=='voice_assistant' else src
  if fk not in {z['key'] for z in f}:f.append(fact(fk,True,ss,label=txt,basis='Current exact Australian named-grade equipment',**({'qualifications':['BMW Digital Premium duration is three years']} if k in ['navigation_digital_premium','parked_recorders'] or (is3 and k=='drive_recorder') else {})))
  if crit not in seen:v['features'].append({'criterion':crit,'value':txt,'keys':[fk],'status':'standard'});seen.add(crit)
 v['features'].append({'criterion':'roadside_assistance','value':'Eight years of roadside assistance with unlimited kilometres for a new BMW BEV.','keys':['roadside_assistance'],'status':'standard'})
 v['features'].append({'criterion':'storage','value':f"{next(a['value'] for a in f if a['key']=='boot_l')} L rear luggage volume; {next(a['value'] for a in f if a['key']=='max_total_cargo_l')} L expanded. Volume method is not specified."+(' Separate 58 L liquid-volume front storage.' if is3 else ''),'keys':['boot_l','max_total_cargo_l']+(['frunk_l'] if is3 else []),'status':'standard'})
 # Explicit battery-basis and frunk two-source gaps, rather than guessing a number.
 for key,reason in [('battery_gross_kwh','Current Australian guide and technical page do not establish gross battery capacity.'),('dc_test_station_kw','Current Australian guide and technical-page footnote do not publish a distinct charging-test station output; vehicle peak is not a station rating.'),('battery_retention_pct','Current warranty brochure and service portal do not state a numeric minimum retained-capacity percentage.')]:
  if key not in {a['key'] for a in f}:f.append(dict(key=key,value=None,grade='not_published',sourceKeys=['warranty','vehicle-warranty'] if key=='battery_retention_pct' else [src,tech],reason=reason,comparison=''))
 if not is3:f.append(dict(key='frunk_l',value=None,grade='not_published',sourceKeys=[tech,n+'-model'],reason='No numeric front-storage volume is published in the current technical data or model page; do not substitute zero.',comparison=''))
 # Parent-captured primary price ladder upgrade; preserved secondary before-road price separately.
 if code in ['22HM','82GN']:
  fn='config-price-22HM-full.txt' if code=='22HM' else 'config-price-82GN.txt';txt=(P/fn).read_text();url=re.search(r'URL: "([^"]+)"',txt).group(1);sk='config-price-'+code
  x['sources'][sk]={'key':sk,'title':'BMW Australia configurator price overview '+code,'url':url,'publisher':'BMW Australia','checkedAt':'2026-10-14','file':fn,'retrieval':'Parent cloud-browser accessibility text capture','kind':'primary'}
  q=next(a for a in f if a['key']=='price_aud');report=copy.deepcopy(q);report['key']='reported_list_price_aud';f.append(report)
  q.update(value=85362 if code=='22HM' else 87446,grade='check',sourceKeys=[sk],priceRung=4,basis='Manufacturer recommended drive-away price, Victoria postcode 3000, standard white, no selected paid options',comparison='Driveaway',basisTag='Maker driveaway · VIC',rankingEligible=True,condition='State-specific Victoria price, postcode 3000, standard Alpine White and no paid options; charges vary by location')
  f.append(copy.deepcopy(dict(q,key='driveaway_price_aud')))
  v['features'].append({'criterion':'driveaway_price','value':'A$'+format(q['value'],',')+' manufacturer recommended drive-away, VIC 3000, no paid options.','keys':['price_aud'],'status':'conditional'})

p.write_text(json.dumps(x,indent=2,ensure_ascii=False));print('Enriched',sum(len(v['facts']) for v in x['variants']),'facts',sum(len(v['features']) for v in x['variants']),'features')
