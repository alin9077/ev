import json,pathlib,re,copy,shutil,urllib.parse
P=pathlib.Path('/tmp/bmw-research/compact');p=P/'normalized-evidence.json';x=json.load(open(p))
def fact(k,v,s,g='confirmed',**kw):return dict(key=k,value=v,grade=g,sourceKeys=[s] if isinstance(s,str) else s,**kw)
# Correct publisher based on source host, not the BMW word in an article slug.
publishers={'evcentral.com.au':'EV Central','thedriven.io':'The Driven','carexpert.com.au':'CarExpert','cars24.com.au':'Cars24 Australia','goauto.com.au':'GoAuto','whichcar.com.au':'WhichCar','carsguide.com.au':'CarsGuide','carsales.com.au':'Carsales'}
for k,s in x['sources'].items():
 host=urllib.parse.urlparse(s['url']).hostname or ''
 match=next((pub for dom,pub in publishers.items() if host==dom or host.endswith('.'+dom)),None)
 if match:s['publisher']=match;s['kind']='secondary'
 elif host in ['bmw.com.au','www.bmw.com.au','www.bmw.com','configure.bmw.com.au','modules.bmw.com.au'] or host=='media.adtorqueedge.com':s['publisher']='BMW Australia';s['kind']='primary'
 elif host in ['virtual.bmw.com.au','usedcars.bmw.com.au']:s['publisher']='BMW Australia vehicle locator / named selling dealer';s['kind']='dealer'
 if s.get('error'):s['retrievalStatus']='failed';s['usableAsRetrievedEvidence']=False
 else:s['retrievalStatus']='captured'
for v in x['variants']:
 for f in v['facts']:
  if f.get('priceRung')==4:f['state']='VIC';f['postcode']='3000'
  if f['key']=='battery_kwh' and v['model'] in ['iX1','iX2']:
   f['sourceKeys']=[v['model'].lower()+'-current',v['model'].lower()+'-tech']
# Actual current exact-default iX1 equipment settles standard 22 kW AC.
shutil.copyfile('/tmp/bmw-research/review/config-options-22HM.txt',P/'config-options-22HM.txt')
s=(P/'config-options-22HM.txt').read_text();m=re.search(r'URL: "([^"]+)"',s);url=m.group(1) if m else x['sources']['config-price-22HM']['url']
x['sources']['config-options-22HM']={'key':'config-options-22HM','url':url,'title':'BMW Australia default 22HM configuration, included AC Charging Professional 22 kW','publisher':'BMW Australia','kind':'primary','checkedAt':'2026-10-14','file':'config-options-22HM.txt','retrieval':'Parent reviewer cloud-browser accessibility capture','retrievalStatus':'captured'}
ix1=next(v for v in x['variants'] if v['modelCode']=='22HM')
f=next(f for f in ix1['facts'] if f['key']=='ac_kw');f.update(grade='confirmed',sourceKeys=['config-options-22HM'],basis='Standard included AC Charging Professional onboard charger, selected/disabled in exact default Australian 22HM configuration',comparison='AC maximum',reason='Exact default 22HM with no Enhancement and no paid options shows AC Charging Professional (22kW) selected, checked/disabled, included for $0. The generic 11/22 technical table does not override this exact Australian equipment evidence.');f.pop('condition',None)
ix1['summary']['strength']['keys'].append('equipment_electric_front_seats')
ix1['features'].append({'criterion':'home_charging','value':'22 kW AC Charging Professional is included as standard; charging at that rate requires a compatible three-phase supply and charger.','keys':['ac_kw'],'status':'standard'})
ix2=next(v for v in x['variants'] if v['modelCode']=='82GN');ix2['summary']['tradeoff']={'label':'Allow around half an hour for fast charging','text':'The published 10–80% DC charge takes 29 minutes.','keys':['dc_charge_time_min']}
# New primary NA5 50 price from parent's exact default configurator capture.
fn='config-price-32HR.txt';s=(P/fn).read_text();url=re.search(r'URL: "([^"]+)"',s).group(1);sk='config-price-32HR'
x['sources'][sk]={'key':sk,'url':url,'title':'BMW Australia 32HR default configuration price overview','publisher':'BMW Australia','kind':'primary','checkedAt':'2026-10-14','file':fn,'retrieval':'Parent cloud-browser accessibility capture','retrievalStatus':'captured'}
v=next(v for v in x['variants'] if v['modelCode']=='32HR');q=next(f for f in v['facts'] if f['key']=='price_aud');reported=copy.deepcopy(q);reported['key']='reported_list_price_aud';v['facts'].append(reported)
q.update(value=122358,grade='check',sourceKeys=[sk],priceRung=4,basis='Manufacturer recommended drive-away price, Victoria postcode 3000, Alpine White and no selected paid options',comparison='Driveaway',basisTag='Maker driveaway · VIC',state='VIC',postcode='3000',rankingEligible=True,condition='State-specific Victoria price, postcode 3000; no selected paid options. Charges vary by location.')
v['facts'].append(copy.deepcopy(dict(q,key='driveaway_price_aud')));v['features'].append({'criterion':'driveaway_price','value':'A$122,358 maker recommended drive-away, VIC 3000, no paid options.','keys':['price_aud'],'status':'conditional'})
# Separate current marketing configuration. Do not equate it with 22HM.
sp={'id':'bmw_ix1_current__xdrive30_sport_collection__20261014','modelId':'bmw_ix1_current','model':'iX1','trim':'xDrive30 Sport Collection','modelCode':None,'modelYear':None,'drive':'AWD','generation':'U11; current Australian Sport Collection marketing configuration; exact model code unverified','recordKind':'marketing_configuration','facts':[],'features':[],'availability':{'state':'On sale now','detail':'Maker national promotional offer, with ordered production available, delivered by 31 March 2027','sourceKeys':['sport-collection'],'stockClaim':'Offer and ordered-production wording do not prove a particular unsold physical vehicle'},'standingNote':'This named promotional configuration is not equated with current code 22HM. Shared drivetrain figures are Reported until exact offer specification is established.'}
sf=sp['facts'];sf.append(fact('price_aud',79900,'sport-collection','check',priceRung=2,basis='Manufacturer recommended national drive-away promotional price',comparison='Driveaway',basisTag='Maker national driveaway offer',rankingEligible=True,validUntil='2027-03-31',condition='New iX1 xDrive30 Sport Collection in Alpine White, no Enhancement package or extras, delivered by 31 March 2027; participating dealers; excludes fleet, government and rental; no rainchecks; availability varies'))
sf.append(copy.deepcopy(dict(sf[-1],key='driveaway_price_aud')))
# Body dimensions/seats/cargo are published for the Australian iX1 body, so inherit Confirmed under the brief.
bodykeys=['seats','boot_l','max_total_cargo_l','length_mm','width_mm','height_mm','wheelbase_mm','width_including_mirrors_mm','width_mirrors_mm']
for k in bodykeys:
 f=copy.deepcopy(next(f for f in ix1['facts'] if f['key']==k));f.update(grade='confirmed',evidenceScope='explicit_au_range',reason='BMW Australian iX1 body dimensions/seating/luggage apply across the same U11 body; separate promotional drivetrain identity is not inferred.');sf.append(f)
# Bounded shared-drivetrain figures admitted as Reported, not current-code Confirmed.
for k in ['range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','zero_to_100_s','torque_nm','towing_braked_kg','towball_kg']:
 f=copy.deepcopy(next(f for f in ix1['facts'] if f['key']==k));f.update(grade='reported',rankingEligible=False,reason='Carried from the named Australian iX1 xDrive30 drivetrain. Exact Sport Collection model code/specification is not established; this is not a confirmed 22HM equivalence.');f.pop('condition',None)
 if k=='ac_kw':f.update(sourceKeys=['sport-specs'],basis='Sport Collection 22 kW maximum AC, reported by CarExpert',reason='CarExpert publishes 22 kW maximum AC for the named 2026 Sport Collection. No exact 22HM equivalence is assumed.');f.pop('qualifications',None)
 if k=='towing_braked_kg':f['condition']='Requires appropriate towing equipment; confirm Sport Collection homologated capacity and hitch fitment'
 if k=='battery_kwh':f['condition']='67 kWh guide and 64.8 kWh technical-table figures have unlabelled capacity bases; shared drivetrain evidence only'
 sf.append(f)
sf += [fact('power_kw',230,'sport-collection',basis='Maker-advertised peak output for the named offer'),fact('drive','AWD','sport-collection'),fact('drivetrain','AWD','sport-collection')]
for k in ['warranty_vehicle_private','battery_warranty_private','warranty_years','battery_warranty_years','battery_warranty_km','warranty','battery_warranty','roadside_assistance']:
 sf.append(copy.deepcopy(next(f for f in ix1['facts'] if f['key']==k)))
for k,val,label in [('m_sport',True,'M Sport Package'),('wheel_diameter_in',19,'19-inch M light-alloy double-spoke wheels'),('upholstery','Black Veganza','Black Veganza upholstery'),('front_heated_seats',True,'Heated driver and front-passenger seats'),('offer_paint','Alpine White','Headline-price paint'),('offer_excludes_enhancement',True,'Headline offer excludes Enhancement package and extras')]:
 sf.append(fact(k if k=='wheel_diameter_in' else 'equipment_'+k,val,'sport-collection',label=label,basis='Exact named Sport Collection offer'))
sp['features']=[{'criterion':'front_heated_seats','value':'Both front seats are heated.','keys':['equipment_front_heated_seats'],'status':'standard'},{'criterion':'style_refinement','value':'M Sport Package, 19-inch M double-spoke wheels and Black Veganza upholstery are included.','keys':['equipment_m_sport','wheel_diameter_in','equipment_upholstery'],'status':'standard'},{'criterion':'driveaway_price','value':'A$79,900 manufacturer national drive-away offer, Alpine White without Enhancement or extras, delivery by 31 March 2027.','keys':['price_aud'],'status':'conditional'},{'criterion':'home_charging','value':'22 kW AC charging is reported for the named Sport Collection.','keys':['ac_kw'],'grade':'reported','status':'reported'},{'criterion':'storage','value':'BMW publishes a 490 L boot and 1495 L expanded luggage volume for the iX1 body; method not stated.','keys':['boot_l','max_total_cargo_l'],'status':'standard'},{'criterion':'roadside_assistance','value':'Eight years of roadside assistance, unlimited kilometres.','keys':['roadside_assistance'],'status':'standard'},{'criterion':'warranty_service','value':'Five-year/unlimited-kilometre private-use vehicle warranty and eight-year/160,000 km high-voltage battery warranty.','keys':['warranty_vehicle_private','battery_warranty_private'],'status':'standard'}]
sp['summary']={'strength':{'label':'AWD at a national drive-away price','text':'Dual-motor AWD and heated front seats for an advertised A$79,900 drive-away.','keys':['drive','equipment_front_heated_seats','price_aud']},'tradeoff':{'label':'Headline price fixes the configuration','text':'The offer requires Alpine White and excludes Enhancement package and extras.','keys':['price_aud','equipment_offer_paint','equipment_offer_excludes_enhancement']}}
x['variants'].append(sp);x['offers'][0]['catalogueVariantId']=sp['id'];x['offers'][0]['existingCatalogueVariantId']=sp['id'];x['offers'][0]['scope']='Distinct current named maker promotional configuration, represented separately; exact model code unverified, never equated to 22HM';x['offers'][0]['validUntil']='2027-03-31'
x['census']['currentMarketingConfigurations']=['iX1 xDrive30 Sport Collection'];x['conflictsAndUseNotes'].append('Exact default 22HM configurator equipment now establishes standard AC Charging Professional 22 kW. Earlier 11/22 equipment ambiguity is resolved for current regular M Sport only, not silently for the Sport Collection.')
# Validate dependencies and source capture existence for every used source.
errs=[]
for v in x['variants']:
 keys=[f['key'] for f in v['facts']]
 if len(keys)!=len(set(keys)):errs.append((v['id'],'duplicate facts'))
 for row in v['features']+list(v['summary'].values()):
  for k in row['keys']:
   if k not in keys:errs.append((v['id'],'missing dependency',k))
 for f in v['facts']:
  for sk in f['sourceKeys']:
   s=x['sources'].get(sk)
   if not s or s.get('retrievalStatus')=='failed' or not s.get('file') or not (P/s['file']).exists():errs.append((v['id'],f['key'],'source capture problem',sk))
if errs:raise Exception(errs)
p.write_text(json.dumps(x,indent=2,ensure_ascii=False));print('Revised',len(x['variants']),'variants,',sum(len(v['facts']) for v in x['variants']),'facts; dependency/capture QA passed')
