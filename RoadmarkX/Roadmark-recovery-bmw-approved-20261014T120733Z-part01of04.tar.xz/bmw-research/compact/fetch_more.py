import runpy,json,pathlib,concurrent.futures
p='/tmp/bmw-research/compact/fetch_sources.py';s=open(p).read();s=s[:s.index('with concurrent.futures.ThreadPoolExecutor')];exec(s)
more={
'prices-compact-evcentral':'https://evcentral.com.au/bmw-chops-ev-pricing-ix1-and-ix2-are-now-cheaper-new-entry-level-ix1-added/',
'prices-compact-driven':'https://thedriven.io/2026/03/31/bmw-cuts-prices-of-fully-electric-ix1-and-ix2-models/',
'prices-ix3-carexpert':'https://www.carexpert.com.au/car-reviews/2026-bmw-ix3-review',
'ix3-40-arrival':'https://www.cars24.com.au/car-news/2026-bmw-ix3-40-price-specs-australia/',
'ix1-current-new':'https://virtual.bmw.com.au/details/OAG-AD-WBY22HM0105779888/2026-bmw-ix1-xdrive30-new',
'ix2-current-new':'https://virtual.bmw.com.au/details/OAG-AD-WBY82GN0405781119/2026-bmw-ix2-xdrive30-new',
'ix3-50-current-new':'https://virtual.bmw.com.au/details/OAG-AD-WBA32HR070DA28380/2026-bmw-ix3-50-xdrive-new',
'ix3-40-current-new':'https://usedcars.bmw.com.au/details/OAG-AD-WBA12HR000DA48655/2026-bmw-ix3-40-new',
'ix2-edrive-new-lead':'https://www.carsales.com.au/cars/details/2025-bmw-ix2-edrive20-m-sport-u10-auto/OAG-AD-25786993/',
'ix3-g08-official':'https://www.bmw.com/en-au/all-models/x-series/iX3/2021.html',
'ix3-m60-future':'https://www.bmw.com.au/en/models/m-series/suv/bmw-ix3-m-models.html',
'ix3-50-towing-secondary':'https://virtual.bmw.com.au/details/OAG-AD-26014710/2026-bmw-ix3-demo',
}
with concurrent.futures.ThreadPoolExecutor(max_workers=7) as ex:r=list(ex.map(lambda kv:f(*kv),more.items()))
x=json.load(open(P/'sources.json'));x.extend(r);(P/'sources.json').write_text(json.dumps(x,indent=2));print(json.dumps(r,indent=2))
