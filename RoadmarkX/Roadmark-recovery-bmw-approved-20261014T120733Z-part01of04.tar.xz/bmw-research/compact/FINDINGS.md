# BMW compact BEV research, 14 October 2026

## Result

Four current named powertrain/equipment versions are established: iX1 xDrive30 M Sport (22HM), iX2 xDrive30 M Sport (82GN), new-generation NA5 iX3 40 M Sport Package (12HR), and iX3 50 xDrive M Sport Package (32HR). The named iX1 xDrive30 Sport Collection is a separate current maker promotional configuration, not a fifth powertrain grade. It is now represented as a fifth, separately scoped marketing-configuration catalogue row, with unknown exact model code. No additional residual-new version has been admitted without a fresh verified seller-specific advertisement.

The normalized file retains the four existing catalogue IDs plus the new Sport Collection row, covers all 17 core fields on all five rows, refreshes related previously populated values, and adds source-backed equipment. No repository files were changed and no catalogue/test commands ran.

## Buyer numbers

| Version | Preferred captured price | Range | Battery basis | DC peak / 10–80% | AC | Seats / boot | 0–100 / power / drive |
|---|---|---|---|---|---|---|---|
| iX1 xDrive30 M Sport | A$85,362 maker VIC 3000 drive-away, no options | 410 km ADR81/02 | 67 kWh unlabelled; technical table separately says 64.8 | 130 kW / 29 min | 22 kW standard, exact default configuration verified | 5 / 490 L | 5.6 s / 230 kW temporary / AWD |
| iX2 xDrive30 M Sport | A$87,446 maker VIC 3000 drive-away, no options | 410 km WLTP; 410 ADR separately | 67 kWh unlabelled; table separately says 64.8 | 130 kW / 29 min | 22 kW standard | 5 / 525 L | 5.6 s / 230 kW temporary / AWD |
| iX3 40 M Sport Package | A$98,254 maker VIC 3000 drive-away, no options | 635 km expected ADR81/02; WLTP 635 Reported | 82.6 kWh net | 300 kW / 21 min | 22 kW | 5 / 520 L | 5.9 s / 235 kW / RWD |
| iX3 50 xDrive M Sport Package | A$122,358 maker VIC 3000 drive-away, no options | 678–805 km WLTP, wheels/options affect result | 108.7 kWh net | 400 kW / 21 min | 22 kW | 5 / 520 L | 4.9 s / 345 kW / AWD |

Primary configurator pricing was captured centrally by the parent and is source-linked in the normalized file. The numeric base-price field is exclusive of GST; no derived MRLP is substituted. All four regular versions now have captured primary configurator prices. The iX3 40 price is A$98,254 for Alpine White, standard 20-inch 1048 M wheels and no paid options; its A$89,900 Reported list price remains a separate fact, not the preferred price.

Dimensions (length/body width/height): iX1 4500/1845/1616 mm; iX2 4554/1845/1560 mm; both NA5 versions 4782/1895/1635 mm. Manufacturer body dimensions, seats and cargo apply to the corresponding body and remain Confirmed. Cargo measurement method is unlabelled; it belongs in a separate like-for-like comparison group, not invented VDA. Both NA5 versions also have a separately labelled 58 L liquid-volume frunk.

Braked towing: iX1/iX2 1200 kg; iX3 40 2000 kg primary, iX3 50 2000 kg primary. The new iX3 has a material Australian equipment condition: current guide p9 says option 3AC is preparation only, excluding tongue kit and power cable, with later availability and capacity/towball details TBC. Do not imply it is ready to tow.

Private-use vehicle warranty is 5 years/unlimited km; high-voltage battery 8 years/160,000 km. Brand terms are Confirmed. The checked warranty text does not state a numerical battery-retention floor. Roadside assistance is 8 years/unlimited km. Parent will reconcile shared terms centrally.

## Version and equipment distinctions

- Current June 2026 iX1/iX2 guides list only xDrive30 M Sport. February 2026 CarExpert reporting explicitly discontinues local eDrive20 and describes the SiC inverter running update. This is a running update, not evidence for a formal MY field or a new body generation
- iX1/iX2 include heated electric front seats, Driving Assistant Professional, Parking Assistant Plus, adaptive M suspension and 19-inch wheels. Sunroof, heated steering wheel and Harman Kardon audio are Enhancement-package options. The iX1 guide omits explicit AC equipment and its generic technical table shows 11/22 kW. The exact default 22HM configurator now resolves this: AC Charging Professional 22 kW is selected/disabled and included for $0, without Enhancement or paid options
- New NA5 iX3 standard equipment includes 20-inch wheels, panoramic roof, heated front seats/steering wheel, 3-zone climate, 3D HUD/Panoramic Vision, 17.9-inch display, Parking Assistant Plus, Driving Assistant Plus and Harman Kardon 13-speaker/365 W audio. The 50 explicitly adds to the 40 in the same guide, so shared equipment is Confirmed
- Current Sport Collection offer is A$79,900 manufacturer recommended drive-away, Alpine White/no Enhancement/extras, delivery by 31 March 2027, participating dealers, private eligibility exclusions, no rainchecks. The page explicitly says ordered production is available. Confirmed offer equipment: M Sport, 19-inch wheels, Black Veganza, heated front seats, dual-motor AWD and 230 kW. Its exact model code remains unestablished. The separate catalogue row carries stable same-body seats/dimensions/cargo as Confirmed; range, battery, charging/performance and towing shared from the named xDrive30 drivetrain as Reported. The offer-specific 230 kW, dual motors, AWD, wheels, trim and heated seats are Confirmed
- Ordinary navigation and BMW Maps equipment facts are retained, but none of the four regular versions is mapped positively to the EV route-planner criterion without evidence of charging stops, arrival state of charge or live charger availability
- G08 Australian legacy trims are M Sport and M Sport Pro. The older evidence's Inspiring/Impressive labels should not be used as Australian catalogue grade names
- iX3 M60 official AU page says available to order in 2027. Exclude from the current on-sale cohort

## Availability and census gaps

Current exact New-labelled ads rechecked: iX1 22HM North Shore, 0 km, A$90,814; iX2 82GN North Shore, 0 km, A$92,668; NA5 50 32HR Geelong, 0 km, A$136,900. These are optioned advertisements, never a physical-stock guarantee. iX3 40 remains Order open or arriving, Q4 2026; an exact ad endpoint hit a redirect loop.

Unresolved residual-new leads remain explicitly listed in normalized-evidence.json:

1. iX1 eDrive20 xLine: current-order discontinuation supported by two local reports; Carsales still has a generic new-to-order template. No fresh seller-specific New ad verified
2. Older iX1 xDrive30 xLine/M Sport codes: current official selector remnants and price guides alone do not establish residual new availability
3. iX2 eDrive20 M Sport: Carsales OAG-AD-25786993 indexed as NSW Dealer new, 5 km, but direct detail blocked. Newcastle aggregator eDrive20 lead has xDrive30 seller text, so identity is unresolved
4. Older iX2 xDrive30 72GM: retained selector, no fresh exact New advertisement verified
5. Outgoing iX3 G08 M Sport/M Sport Pro: legacy primary page and independent model lists retain them, but no current New-labelled seller detail recovered. This does not prove all stock is exhausted

Two-source gaps are not silently closed. No national full-brand census closure is claimed from this subtask.

## Files and verification

- normalized-evidence.json: integration-shaped findings, source keys, grades, reasons, conditions, summaries and census leads
- source-equipment-inventory.json: full current standard/option page text, page numbers and source keys; original current PDFs and text extracts retained
- Sources are downloadable BMW Australia guides, live Australian technical pages, official current offers, exact new advertisements, and independent Australian reports. All public URLs are in normalized source records
- *-p2-local-pdf-render.png: three local PDF renders, visually checked against current codes/range/battery rows; these are not browser screenshots
- manifest-sha256.json: file bytes and hashes. Capture dates use the canonical session date; host filesystem timestamps are not used as evidence

Failures: several direct secondary-site HTTP reads returned 403; public web text was captured instead. One NA5 40 dealer route returned a redirect loop. No challenge, CAPTCHA, login, dealer contact or user-computer action was taken.
