import urllib.request, pathlib, json, concurrent.futures, re
import html
P=pathlib.Path('/tmp/bmw-research/compact')
urls={
'ix1-current':'https://media.adtorqueedge.com/new-cars/bmw-aus/brochures/BMW%20iX1.pdf',
'ix2-current':'https://media.adtorqueedge.com/new-cars/bmw-aus/brochures/BMW%20iX2.pdf',
'ix3-current':'https://media.adtorqueedge.com/new-cars/bmw-aus/brochures/BMW%20iX3.pdf',
'ix1-tech':'https://www.bmw.com.au/en/models/bmw-i/ix1/bmw-ix1-technical-data.html',
'ix2-tech':'https://www.bmw.com.au/en/models/bmw-i/bmw-ix2-technical-data.html',
'ix3-tech':'https://www.bmw.com.au/en/models/x-series/ix3/bmw-ix3-technical-data.html',
'ix1-model':'https://www.bmw.com.au/en/models/bmw-i/ix1/bmw-ix1.html',
'ix2-model':'https://www.bmw.com.au/en/models/bmw-i/bmw-ix2.html',
'ix3-model':'https://www.bmw.com.au/en/models/x-series/ix3/bmw-ix3.html',
'sport-collection':'https://www.bmw.com.au/en/offers-and-services/promotions/sport-collection.html',
'brochure-module':'https://modules.bmw.com.au/download-brochure',
'vehicle-warranty':'https://www.bmw.com.au/en/service-portal.html',
'all-models':'https://www.bmw.com.au/en/all-models.html',
}
def f(k,u):
 try:
  b=urllib.request.urlopen(u,timeout=60).read();pdf=b.startswith(b'%PDF');p=P/(k+('.pdf' if pdf else '.html'))
  if not pdf:
   s=b.decode('utf8','replace');s=re.sub(r'(?i)((?:csrf|clientsecret|client_secret|sessionid|session_id|token)[\w-]*[\s"\x27]*[:=][\s"\x27]*)([^\s"\x27<>;&]+)',r'\1[REDACTED]',s)
   s=re.sub(r'<script(?![^>]*application/ld\+json)[^>]*>.*?</script>|<style[^>]*>.*?</style>', '', s, flags=re.S|re.I)
   p.write_text(s);(P/(k+'.txt')).write_text(html.unescape(re.sub(r'<[^>]+>', ' ', s)))
  else:p.write_bytes(b)
  return {'id':k,'url':u,'checked_on':'2026-10-14','file':str(p),'retrieval':'HTTP read, not browser screenshot','status':200}
 except Exception as e:return {'id':k,'url':u,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=7) as ex:r=list(ex.map(lambda kv:f(*kv),urls.items()))
(P/'sources.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
