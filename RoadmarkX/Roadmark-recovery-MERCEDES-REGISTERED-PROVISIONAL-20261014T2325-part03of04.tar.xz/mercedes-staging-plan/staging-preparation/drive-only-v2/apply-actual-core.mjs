/** Actual complete baseline-plus-candidate core application. Caller supplies independently reviewed, pinned proof. */
import path from 'node:path';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readJson, locate, pin, digestRows, assertResearchUnchanged } from '/tmp/xpeng-staging-plan/baseline-io.mjs';
import { readCompleteBaseline } from './read-complete-storage.mjs';
import { composeBrandResearch, fieldDigests, assertFieldDigests } from './compose-brand-research.mjs';

const tier1 = car => !car.vehicleClass || ['passenger', 'ute'].includes(car.vehicleClass);
export async function applyActualCore(proof, packetRef) {
  const m = proof.manifest, e = m.expected;
  assert.equal(proof.manifest.schemaVersion, 1); assert.equal(proof.manifest.mode, 'reviewed-brand-staging-v1');
  assert.equal(process.cwd(), proof.anchors.repo); assert.equal(typeof global.gc, 'function');
  assert.equal(proof.manifest.phase === 'canonical' || proof.manifest.phase === 'final-core', true);
  proof.verify(); proof.assertPinned(packetRef); pin(proof.anchors, packetRef);
  const packet = readJson(locate(proof.anchors, packetRef)), packetDigest = digestRows([packet]);
  const normalized = readJson(locate(proof.anchors, m.normalizedEvidence));
  assert.equal(packet.id, proof.manifest.packetId); assert.equal(packet.brand, m.brand);
  assert.equal(proof.manifest.newIds.length, e.newCars); assert.equal(new Set(proof.manifest.newIds).size, e.newCars);
  assert.deepEqual(packet.variants.map(row => row.id), proof.manifest.newIds);
  assert.equal(packet.features.length, 0, 'No equipment mutations authorized');
  for (const key of ['brandTerms', 'configurationUpdates']) assert.equal((packet[key] ?? []).length, 0);
  assert.equal(packet.versionUpdates.length, e.authorizedDriveOnlyVersionUpdates);
  assert.deepEqual(packet.versionUpdates.map(row => row.variantId), m.existingIds);
  if (proof.manifest.phase === 'canonical') { assert(Array.isArray(packet.features)); assert.equal(packet.features.length, 0, 'Input must already be feature-free, never silently edited by the harness'); }
  const baseline = await readCompleteBaseline(proof), before = baseline.cars, beforeData = baseline.data;
  const beforeCarDigests = before.map(car => ({ id: car.id, brand: car.brand, ...digestRows([car]) }));
  const beforeResearchDigests = fieldDigests(beforeData), beforeById = new Map(beforeCarDigests.map(row => [row.id, row]));
  const beforeSelected = before.filter(car => car.brand === m.brand && tier1(car)); assert.equal(beforeSelected.length, e.existingCars);
  assert.deepEqual(beforeSelected.map(car => car.id), proof.manifest.existingIds);
  proof.assertPinned(proof.manifest.selectedBeforeCars);
  assert.deepEqual(beforeSelected, readJson(locate(proof.anchors, proof.manifest.selectedBeforeCars)), 'Exact actual-before extraction full cars');
  for (const id of proof.manifest.newIds) assert(!beforeById.has(id), 'Every genuinely new identity');
  const require = createRequire(path.join(proof.anchors.repo, 'package.json'));
  const { prepareBrandResearch, applyBrandUpdates, brandVersionSnapshot } = require('./src/lib/brand-updates.ts');
  const { brandUpdatePackets } = require('./src/lib/brand-update-registry.ts');
  assert.equal(brandUpdatePackets.length, e.registeredPackets); assert.deepEqual(brandUpdatePackets, proof.registeredPackets);
  for (const name of m.forbiddenImports) assert(!require.cache[path.join(proof.anchors.repo, name)], 'Forbidden catalogue/hydration import: ' + name);
  const acceptedGuards = readJson(locate(proof.anchors, m.existingBeforeVersionGuards));
  assert.deepEqual(packet.versionGuards, acceptedGuards, 'Every full original guard retained exactly');
  const guardsById = new Map(acceptedGuards.map(row => [row.variantId, row.before]));
  const normalizedById = new Map(normalized.variants.map(row => [row.id, row]));
  const originalRawById = new Map(beforeData.variants.map(row => [row.id, row]));
  for (const [ordinal, edit] of packet.versionUpdates.entries()) {
    const original = guardsById.get(edit.variantId); assert(original);
    assert.deepEqual(edit.before, original, 'Full accepted metadata before guard, without reauthoring');
    assert.deepEqual(brandVersionSnapshot(beforeSelected[ordinal]), original);
    assert.equal(original.drive, 'Unknown');
    const normalizedDrive = normalizedById.get(edit.variantId).facts.find(row => row.key === 'drive'); assert(normalizedDrive);
    assert.equal(m.driveMetadataProjection.rows[ordinal].variantId, edit.variantId);
    assert.deepEqual(normalizedDrive, m.driveMetadataProjection.rows[ordinal].expectedNormalizedFact, 'Exact sourced normalized drive fact, including cohort and unranked scope');
    const reviewedDrive = packet.facts.find(row => row.variantId === edit.variantId && row.after.key === 'drive')?.after;
    assert(reviewedDrive); assert(['FWD', 'RWD', 'AWD'].includes(reviewedDrive.value));
    assert.equal(reviewedDrive.value, normalizedDrive.value); assert.equal(reviewedDrive.buyerGrade, 'reported');
    assert.equal(reviewedDrive.comparisonBasis, '');
    assert.deepEqual(reviewedDrive.sourceIds, normalizedDrive.sourceKeys.map(key => packet.id + '-' + key));
    assert.equal(normalizedDrive.rankingEligible, false);
    const expectedAfter = { ...original, drive: reviewedDrive.value };
    assert.deepEqual(edit.after, expectedAfter, 'Exactly drive changes; no identity, year, model, body, generation or other metadata change');
    assert.deepEqual(Object.keys(edit.after), Object.keys(original), 'No extra or missing snapshot keys');
    assert.deepEqual(digestRows([edit.after]), digestRows([expectedAfter]), 'Exact metadata order and values');
  }
  global.gc();
  const raw = prepareBrandResearch(beforeData, [packet]);
  for (const edit of packet.versionUpdates) {
    const original = originalRawById.get(edit.variantId), after = raw.variants.find(row => row.id === edit.variantId);
    assert(original && after);
    for (const key of ['brand_update_model', 'brand_update_generation']) assert(!Object.hasOwn(original, key), 'Declared derived key absent from accepted original raw row');
    assert.equal(after.brand_update_model, edit.before.model);
    assert.equal(after.brand_update_generation, edit.before.generation);
    assert.equal(after.drive, edit.after.drive);
    const availability = packet.availability.find(row => row.variantId === edit.variantId); assert(availability);
    const expectedRawAfterMetadata = { ...original, drive: edit.after.drive,
      brand_update_model: edit.before.model, brand_update_generation: edit.before.generation };
    const expectedRawAfterAvailability = { ...expectedRawAfterMetadata,
      record_state: availability.after.availability, availability_evidence: structuredClone(availability.after.evidence) };
    assert.deepEqual(after, expectedRawAfterAvailability, 'No raw Variant changes beyond seven drive/derived-marker changes and separately guarded availability');
    assert.deepEqual(digestRows([after]), digestRows([expectedRawAfterAvailability]), 'Full actual raw Variant key order and bytes');

    for (const [rawKey, snapshotKey] of [['brand', 'brand'], ['model', 'model'], ['trim', 'trim'], ['model_year', 'year'], ['vehicle_class', 'vehicleClass']]) {
      assert.equal(after[rawKey], original[rawKey], 'Unchanged raw identity metadata: ' + rawKey);
      assert.equal(after[rawKey], edit.before[snapshotKey]);
    }
  }

  const existingIdSet = new Set(m.existingIds);
  for (const original of beforeData.variants) if (!existingIdSet.has(original.id)) {
    const after = raw.variants.find(row => row.id === original.id); assert(after);
    assert.deepEqual(after, original, 'Every unselected complete raw Variant unchanged');
    assert.deepEqual(digestRows([after]), digestRows([original]));
  }
  const composed = composeBrandResearch(beforeData, packet, raw, brandUpdatePackets, m);
  const data = composed.data, cars = applyBrandUpdates(before, data, [packet]);
  assert.equal(cars.length, e.afterCars); assert.equal(new Set(cars.map(car => car.id)).size, e.afterCars);
  assert.deepEqual(cars.map(car => car.id), [...before.map(car => car.id), ...proof.manifest.newIds]);
  const selected = cars.filter(car => car.brand === m.brand && tier1(car)); assert.equal(selected.length, e.selectedCars);
  assert.deepEqual(selected.map(car => car.id), [...proof.manifest.existingIds, ...proof.manifest.newIds]);
  const beforeSelectedById = new Map(beforeSelected.map(car => [car.id, car]));
  const selectedById = new Map(selected.map(car => [car.id, car]));
  for (const edit of packet.versionUpdates) assert.deepEqual(brandVersionSnapshot(selectedById.get(edit.variantId)), edit.after, 'Actual snapshot equals exact drive-only after');
  for (const car of selected) {
    const drive = car.facts.drive; assert(drive); assert(['FWD', 'RWD', 'AWD'].includes(drive.value));
    assert.equal(car.drive, drive.value, 'Raw categorical drive agrees with the graded fact for all eleven');
    const rawVariant = raw.variants.find(row => row.id === car.id); assert(rawVariant); assert.equal(rawVariant.drive, drive.value);
    const normalizedDrive = normalizedById.get(car.id).facts.find(row => row.key === 'drive'); assert(normalizedDrive);
    assert.equal(drive.buyerGrade, normalizedDrive.grade, 'Metadata projection never promotes fact grades');
  }

  for (const id of m.existingIds) for (const key of m.preservedExistingFactKeys) {
    assert(Object.hasOwn(beforeSelectedById.get(id).facts, key)); assert(Object.hasOwn(selectedById.get(id).facts, key));
    const original = beforeSelectedById.get(id).facts[key], after = selectedById.get(id).facts[key];
    assert.deepEqual(after, original, 'Exact complete historical fact retained: ' + id + '/' + key);
    assert.deepEqual(digestRows([after]), digestRows([original]), 'Historical fact bytes/order retained');
  }
  for (const edit of packet.facts) {
    assert(!Object.hasOwn(edit.after, 'gradeReviewStatus'), 'No authored stale review marker to silently remove');
    const actualFact = selectedById.get(edit.variantId).facts[edit.after.key];
    assert.deepEqual(actualFact, edit.after, 'Exact full guarded after fact');
    assert.deepEqual(digestRows([actualFact]), digestRows([edit.after]));
  }
  assert.equal(packet.availability.length, e.selectedCars);
  for (const row of normalized.variants) {
    const edit = packet.availability.find(value => value.variantId === row.id); assert(edit);
    const actualAvailability = selectedById.get(row.id).availabilityEvidence;
    assert.deepEqual(actualAvailability, edit.after.evidence, 'All authored availability evidence survives actual Car');
    assert.equal(actualAvailability.qualifications.filter(value => value === row.availability.reason).length, 1,
      'Exact source conflict and scope reason stays buyer-visible once');
    for (const qualification of row.availability.qualifications) assert(actualAvailability.qualifications.includes(qualification));
    assert.equal(selectedById.get(row.id).availability, row.availability.state);
  }
  assert.equal(packet.summaries.length, e.selectedCars);
  for (const row of packet.summaries) {
    const summary = selectedById.get(row.variantId).buyerSummary; assert(summary);
    assert.deepEqual(summary.conditions, row.conditions ?? [], 'No inherited summary condition merge');
    for (const key of ['strength', 'tradeoff']) {
      assert.equal(summary[key]?.label, row[key].label); assert.equal(summary[key]?.text, row[key].text);
    }
  }
  const carHashes = [];
  for (const car of cars) {
    const digest = digestRows([car]), prior = beforeById.get(car.id);
    if (car.brand !== m.brand || !tier1(car)) {
      assert(prior); assert.equal(digest.sha256, prior.sha256, 'Every complete unselected/lower-tier car unchanged'); assert.equal(digest.bytes, prior.bytes);
    }
    carHashes.push({ id: car.id, brand: car.brand, beforeSha256: prior?.sha256 ?? null, afterSha256: digest.sha256, bytes: digest.bytes });
  }
  assert.equal(cars.filter(car => car.brand !== m.brand || !tier1(car)).length, e.unselectedCars);
  function verifyUnchanged() {
    assert.equal(cars.length, carHashes.length, 'Complete actual output-car count unchanged');
    assert.equal(cars.length, e.afterCars); assert.equal(new Set(cars.map(car => car.id)).size, e.afterCars);
    for (const [i, car] of cars.entries()) {
      const expected = carHashes[i], digest = digestRows([car]);
      assert.equal(car.id, expected.id, 'Every actual output car remains in captured order');
      assert.equal(car.brand, expected.brand, 'Complete actual output-car brand unchanged');
      assert.equal(digest.sha256, expected.afterSha256, 'Every complete actual output car unchanged after consumers/serialization: ' + car.id);
      assert.equal(digest.bytes, expected.bytes);
    }
    assert.equal(before.length, beforeCarDigests.length);
    for (const [i, car] of before.entries()) assert.deepEqual({ id: car.id, brand: car.brand, ...digestRows([car]) }, beforeCarDigests[i], 'Every complete original input car unchanged');
    assertFieldDigests(beforeData, beforeResearchDigests, 'Every original full Research field unchanged');
    assertResearchUnchanged(beforeData, baseline.index);
    assertFieldDigests(raw, composed.rawFieldDigests, 'Every raw output field preserved');
    assertFieldDigests(data, composed.composedFieldDigests, 'Every composed output field preserved');
    assert.deepEqual(digestRows([packet]), packetDigest); assert.deepEqual(brandUpdatePackets, proof.registeredPackets);
    for (const name of m.forbiddenImports) assert(!require.cache[path.join(proof.anchors.repo, name)], 'Forbidden catalogue/hydration import: ' + name);
    pin(proof.anchors, packetRef); proof.verify();
  }
  verifyUnchanged();
  return { baseline, packet, packetRef, packetDigest, raw, data, cars, selected, carHashes, composed, verifyUnchanged };
}

/** Final phase reuses exact original empty-feature packet; canonical originals never reset. */
export function assertFinalMatchesCanonical(proof, actual, canonical) {
  const e = proof.manifest.expected;
  assert.equal(proof.manifest.phase, 'final-core');
  assert.deepEqual(actual.packetRef, proof.manifest.featureFreePacket, 'Reuse original unchanged empty-feature packet');
  assert.equal(actual.packet.features.length, 0);
  assert.equal(canonical.meta.captureGenerationCount, 1);
  assert.equal(canonical.meta.generationCount, 1); assert.equal(canonical.meta.baselineGenerationCount, 1);
  assert(Array.isArray(actual.packet.features));
  const withoutFeatures = structuredClone(actual.packet); withoutFeatures.features = [];
  assert.deepEqual(withoutFeatures, canonical.packet);
  assert.deepEqual(digestRows([withoutFeatures]), canonical.meta.featureFreePacketDigest, 'Exact original feature-free packet including property order');
  assert.deepEqual(actual.selected, canonical.selectedCars, 'Every complete canonical selected car');
  assert.deepEqual(digestRows(actual.selected), canonical.meta.selectedCarsDigest);
  assertFieldDigests(actual.raw, canonical.meta.rawFieldDigests, 'All fourteen original canonical raw fields');
  assertFieldDigests(actual.data, canonical.meta.composedFieldDigests, 'All fourteen original canonical composed fields');
  assert.deepEqual(actual.composed.transition.rawMetadata, canonical.meta.rawMetadata);
  assert.deepEqual(actual.composed.transition.composedMetadata, canonical.meta.composedMetadata);
  assert.equal(canonical.newFeatures.length, e.newFeatureRows);
  const beforeExisting = new Map(canonical.existingFeatures.map(row => [row.variant_id + '\0' + row.criterion, row]));
  const beforeNew = new Map(canonical.newFeatures.map(row => [row.variant_id + '\0' + row.criterion, row]));
  assert.equal(beforeExisting.size, e.existingFeatureRows); assert.equal(beforeNew.size, e.newFeatureRows);
  for (const edit of actual.packet.features) {
    const key = edit.variantId + '\0' + edit.criterion;
    const expected = beforeNew.get(key) ?? beforeExisting.get(key); assert(expected);
    assert.deepEqual(edit.before, expected, 'Full guarded feature before-row must be the original actual row');
  }
  actual.verifyUnchanged();
}
