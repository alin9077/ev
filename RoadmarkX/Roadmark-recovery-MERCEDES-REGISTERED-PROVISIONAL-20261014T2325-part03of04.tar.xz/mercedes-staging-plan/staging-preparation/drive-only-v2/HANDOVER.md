# Drive-only static revision

Supersedes the first prepared module cut only for root-approved seven-drive metadata handling and its exact production-derived raw markers. The original 16-file cut, handover-v1 and every before artifact stay unchanged. No module import/execution, payload or source-capture scan, tests, compile, source edit, assembly or canonical generation occurred.

The new scripts permit exactly seven existing full BrandVersionSnapshot updates: only Unknown drive becomes FWD/RWD/AWD/RWD/AWD/RWD/AWD in accepted guard order. Full guard objects and all other snapshot keys/order remain exact. The full normalized source Fact is pinned by assembly v7's driveMetadataProjection. All eleven raw Car/Variant drive values must match the sourced fact values; grades, comparison basis, dates, source IDs and cohort conditions remain unchanged.

The pinned producer adds brand_update_model and brand_update_generation, equal to the unchanged accepted model/generation. Root explicitly approved those two new raw keys on the seven rows only. The full actual raw after Variant must equal the original with precisely drive, these two markers and the separately guarded availability effect. Every unselected original raw Variant remains exact. Actual raw/composed fields are retained without normalization.

The original staging anchor and fixed logical canonical capture-claim path are unchanged, so versioning does not create a second capture identity. Canonical JSON audit code is byte-identical to the first static handover and retains the separate four-new-ID scope with no assumed omission count.

Current assembly reference: assembly-feature-free-v7.json, SHA256 f73d5c03399b3444175046e4e6ca5d7345927e0d080a1e60c967914049a04201; adapter v5 SHA256 a7eac647a6f2672e660faf1110e4cd412a4a0c641dfa4cf6d8ffe9e321c04d3a. It remains unexecuted. Packet/receipt/acceptance/composition/canonical pins are still null, not invented. Phase manifests and commands remain blocked templates.

Review the exact six scripts, drive-only-amendment.patch, STAGING-DESIGN.md, CONSUMER-ACCEPTANCE.md and canonical/final-core-manifest-template-v3.json. An exact static receipt can accept this preparation but cannot approve the future phase invocation until real outputs are pinned and root grants the exclusive measured slot. All resource and remaining consumer/report gates from the first handover still apply.
