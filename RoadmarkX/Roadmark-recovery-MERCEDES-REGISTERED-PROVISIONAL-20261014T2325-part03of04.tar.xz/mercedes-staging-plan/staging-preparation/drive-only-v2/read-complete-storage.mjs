/** Reuses the accepted recursive reader unchanged; never calls its old 399-car wrapper. */
import assert from 'node:assert/strict';
import { readCompleteCars } from '/tmp/xpeng-staging-plan/staging-v1/read-complete-storage.mjs';
import { pin, readResearch } from '/tmp/xpeng-staging-plan/baseline-io.mjs';
export { readCompleteCars };
export async function readCompleteBaseline(proof) {
  const result = await readCompleteCars(proof, proof.manifest.baselineStorageIndex);
  assert.equal(result.cars.length, proof.manifest.expected.beforeCars);
  assert.equal(result.index.asOf, proof.manifest.asOf);
  for (const ref of Object.values(result.index.research)) { proof.assertPinned(ref); pin(proof.anchors, ref); }
  const data = await readResearch(proof.anchors, result.index, proof.manifest.researchFields);
  assert.equal(Object.keys(data).length, 14); assert.equal(data.variants.length, proof.manifest.expected.beforeCars);
  assert.deepEqual(data.variants.map(row => row.id), result.cars.map(car => car.id));
  return { ...result, data };
}
