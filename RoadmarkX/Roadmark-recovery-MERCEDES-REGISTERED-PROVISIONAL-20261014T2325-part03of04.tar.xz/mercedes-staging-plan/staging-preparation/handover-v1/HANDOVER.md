# Static staging handover

The six-module adaptation and complete proof design are ready for independent static review. No module has been executed, imported into Node, syntax-checked, compiled or tested. No production payload or retained-capture scan, assembly, canonical capture, source edit or registration occurred.

Original prepared cut: the 16 files listed, with exact bytes and hashes, in original-static-preparation-index-v1.json. Keep them unchanged. The handover-v1 addendum and v2 templates bind the now-accepted v6 evidence and capture manifest without changing that original cut. Research/content approval is not execution approval.

## Review now

- open-stage-inputs.mjs: exact accepted baseline, source inventory, raw/composed metadata and source-capture boundary
- read-complete-storage.mjs: direct reuse of the accepted recursive reader, never the old 399-car wrapper
- compose-brand-research.mjs: only metadata.brand_update_packet_ids is composed; complete actual raw output is retained
- apply-actual-core.mjs: 405-car baseline plus four new identities; all full original inputs, 398 unselected cars, historical model-code/roadside facts, exact fact-after objects, availability qualifiers/reasons and complete new summaries preserved
- canonical-feature-values.mjs: four new original 69-row sets plus exact narrow new-ID JSON-shape audit. The seven existing accepted omissions remain separate and immutable
- run-core-stage.mjs: one exclusive original capture claim, complete raw/composed field storage, full-car descriptors, retained original packet/features/audit and later exact final replay of the identical empty-feature packet
- STAGING-DESIGN.md, CONSUMER-ACCEPTANCE.md, adaptations.patch and reuse-provenance.json: lineage, minimal reuse, required final consumers and resource limits

The accepted v6 pin addendum supersedes only the original design's statement that final content was pending. It does not silently revise code, policy or packet pins. The original command template still intentionally points to future frozen phase manifests; it must not be run against a blocked preparation template.

## Still blocked

1. Feature-free packet assembly has not run. Its exact frozen manifest is assembly-feature-free-v6.json (15701 bytes; SHA256 4ee5234793b3c90aa7ecbc057ce1949fc95c130a49cc2b968fb6e9c8bc8f9473). Exact independent review and root grant are still needed
2. Actual packet, assembly receipt, effective-facts/provenance output and independent output acceptance are absent. Their pins stay null
3. Composition approval must bind the accepted 19-packet baseline and the actual packet bytes. Its template is not approval
4. Canonical phase needs a newly frozen exact input manifest, independent exact code/manifest review (including the separate four-ID JSON policy), and a root sole-slot grant. Static policy agreement in principle is insufficient
5. Canonical originals and their independent acceptance do not yet exist. No final-core or consumer manifest can be frozen until those actual pins are known
6. Consumer code is not adapted in this package. CONSUMER-ACCEPTANCE.md specifies the next minimal XPENG consumer adaptation: original snapshot replay, actual pack/citation/portable checks, isolated negative guards, complete 409-car/28221-feature serial ranges and full report equality

## Required review/receipt interface

The new open-stage-inputs boundary proposes exact status/binding fields for assembly output acceptance, composition review, phase review and canonical acceptance. These are intentionally pending contracts, not invented approvals. The independent reviewer should confirm this interface before authoring receipts, or request a versioned adapter correction. An actual valid receipt must never be weakened or relabelled merely to satisfy the adapter.

## Resource handling

Only the parent's common measured-command.py is used. Every future invocation is individually reviewed and root-granted, serial and exclusive, with 180 seconds, 448 MiB old heap, 1 MiB semi space and no NODE_OPTIONS. Preserve failures/partials; no automatic retries. Root's backup currently owns the heavy slot. Preparation never grants itself a slot.

## Stopping point

This task delivers static source, exact local preparation pins, transparent reuse diffs, blocked input/review/command templates and the complete downstream acceptance design. It claims no runtime or integration result. The next authorized work is independent static review and, separately, root-controlled packet assembly.
