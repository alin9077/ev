# Mercedes canonical and complete-storage staging adaptation

## Status and boundaries

Static preparation only. None of these six modules has been imported, parsed by Node, compiled, executed, tested, or used to hydrate production data. No assembly, canonical generation, repository/source edit, registration, report generation or full source scan was performed here. Preparation writes are confined to this directory. A separate independent review and explicit root sole-heavy-slot grant are required for each invocation, including capture scans and bounded consumer stages.

The exact current source remains the accepted registered XPENG source inventory. This is the accepted derived 397-car JSONL → 399-car Subaru storage → 405-car XPENG storage lineage, not a newly successful full-value loader export. All original before objects remain immutable: seven selected complete cars, 483 features, 245 facts and seven guards. The extraction acceptance is baseline-v2-output-acceptance.json, SHA256 feb366eb9b3f35f99a07000c5e05c3fcbf406b15aee2330aa00f31a3bfe3e7a8.

Research is being finalized after v5 provenance corrections; the packet worker reports v6 is now pending exact content acceptance. The blocked templates deliberately leave normalized evidence, content review, capture map and assembly pins unset until the final accepted revision is known. The expected scope remains 258 facts, 39 direct support sources and 60 retained normalized source records. Prior revisions remain historical inputs, not silently selected candidates. No packet/canonical output hashes exist yet, and none is fabricated.

## Reuse, not a new brand framework

- open-stage-inputs.mjs adapts XPENG's exact pin/review boundary to the generic accepted Mercedes baseline schema and the two exact retained capture roots
- read-complete-storage.mjs imports the original XPENG readCompleteCars function unchanged. It never calls that file's obsolete 399-car readCompleteBaseline wrapper or baseline-io's hardcoded Subaru selectVerifiedCars helper
- compose-brand-research.mjs is the XPENG composition body with expected brand, IDs and counts supplied by the reviewed manifest
- apply-actual-core.mjs is the XPENG actual one-packet core body with manifest counts plus exact historical-code/roadside, fact-after, availability-provenance and full-summary replacement assertions
- canonical-feature-values.mjs is the XPENG original-new-feature capture body with four-new-ID counts and separately scoped strict JSON shape audit, copied from the independently accepted baseline audit semantics
- run-core-stage.mjs preserves XPENG's exclusive once-only capture claim, complete field storage and full-car descriptors. It adds the original new-feature JSON audit artifact

baseline-io.mjs is imported unchanged from the accepted XPENG path. Its stale Subaru-specific helper is present but never invoked. No new scanner, loader, schema normalizer, registry replacement, brand-specific feature importer or duplicate measurement wrapper is introduced. Exact old/new pins and textual diffs are in reuse-provenance.json and adaptations.patch. Those are provenance evidence, not execution approval.

## Expected exact scope

- Baseline: 405 complete cars, 27,945 complete feature rows, 14 complete Research fields, 19 actual registered packets
- Selected before: seven Mercedes Tier 1 cars; 483 features, 245 complete Fact objects, seven complete version guards
- Candidate: 11 Mercedes Tier 1 cars, consisting of the original seven plus four appended identities, 258 fact edits, 11 summaries, zero authored equipment feature edits, zero brandTerms, zero versionUpdates and zero configurationUpdates
- Hypothetical after: 409 complete cars, 28,221 complete feature rows, 20 packet IDs only in explicit hypothetical metadata composition
- Preserve all 398 unselected complete car and feature sets, including the existing Tier 2 cargo eVito and every Model Y
- New canonical originals: all 69 source/effective rows for each of the four new variants, 276 rows total. Existing 483 originals remain their original accepted snapshot; together these are 759 selected original rows, not an assertion that every post-overlay feature must equal its earlier before snapshot

The baseline metadata already carries the complete accepted 19-packet prefix. prepareBrandResearch(base, [candidate]) intentionally reports invocation-scoped metadata with [candidate.id]. Preserve that raw output intact. The explicit composition changes only metadata.brand_update_packet_ids to the verified prefix plus candidate ID; retain every other metadata property/order and all 13 other full fields unchanged from raw. Full raw and composed streams/descriptors must remain available. Never silently label the raw one-packet result as a fully registered loader result.

## Frozen sequence

1. The packet worker completes separately reviewed feature-free assembly against exact accepted baseline and final approved research, then independent output review accepts the actual files. Its static manifest, receipt and accepted packet pins are required inputs; no expected output hash is guessed
2. Freeze a new canonical manifest from the blocked template, add the actual assembly/evidence/composition acceptance refs, all precise pins and the exact review. Independent static review must explicitly approve the four-new-ID JSON policy. Root grants one invocation using the common measured runner
3. Actual core reads the full accepted 405-car baseline and all 14 fields, then calls only prepareBrandResearch(beforeData, [packet]), the explicit metadata composition and applyBrandUpdates(beforeCars, data, [packet]). Never rerun old fills, price ladder, fact regrading or prior brand overlays
4. The once-only original claim is exclusive and remains fixed for this packet identity. Capture all four new original feature sets with the unchanged registered 19-packet consumer and explicit immutable snapshot. The Mercedes packet has no feature mutations; omitting an empty candidate feature packet does not synthesize features, and final consumers still prove the exact 20-packet pipeline
5. Preserve original canonical packet bytes, selected cars, all raw/composed fields and metadata, 276 complete features, strict serialization audit and source implementation pins. Independently accept the measured terminal and actual originals
6. Reuse the exact same empty-feature packet as the final packet. Do not reassemble a cosmetic second copy, add features just to exercise the harness, or regenerate canonical originals. A separately reviewed final-core replay verifies exact original packet, all selected cars and all 14 raw/composed field digests; it never recaptures originals
7. Run separately reviewed selected actual consumers, isolated negative guards, complete serial feature ranges and full report comparison. Consumer adaptations remain a next separately reviewed deliverable; the existing XPENG consumer scripts are references and cannot be run unchanged for Mercedes
8. Any later registration and fresh unchanged normal coverage CLI parity are separate root-authorized steps. This package does not authorize source edits or registration

Root may instead approve a separately reviewed memory-bounded split before first capture. Do not weaken proofs or invent a new capture claim after failure. Any partial or failed invocation is retained, including claim and output bytes; no automatic retry or silent path reset. Root and reviewer decide how an interrupted original claim is handled.

## Strict JSON serialization scope

Existing seven omissions are the independently observed own enumerable novated_fbt.confirmation_needed properties with undefined values. Their original audit and policy remain byte-pinned and separate. They authorize only JSON comparison on clones; they do not permit stripping fields from live rows or general undefined cleanup.

Static source inspection predicts the same property can occur on the four new variants, because auditedFeature's novated_fbt patch assigns it and the new source rows have unverified state. This is a hypothesis, not a claim of four observations. The separate proposed canonical policy names only the four exact new IDs, novated_fbt, own enumerable confirmation_needed and undefined. Runtime records every actual occurrence, has no expected omission count and rejects all other undefined, proxy/accessor, cyclic, nonplain, symbol, sparse-array, extra-array-property, non-finite or negative-zero shapes. It retains original live rows, removes only allowed omissions from a comparison clone, compares full serialized arrays and JSONL digests, then compares the parsed original output file to that full clone. The two policies cannot be merged or expanded without a new exact review.

## Source and output integrity

Input pins carry the accepted complete source inventory and inherited recursive-storage pins. Static pins are copied from accepted receipts or computed from these prepared harness files; they are not claims that current production bytes or retained source captures have been re-scanned. Runtime verifies input pins before and after production work and checks the inventory path set. Installed dependency bytes are outside the accepted inventory and remain an explicit limit.

Packet source captures resolve by the source-capture manifest's exact (sourceKey, locator) pair to the exact pinned path. Only /tmp/mercedes-research and /tmp/mercedes-review/warranty may supply source captures. Retained locator prefixes differ and must not be interpreted as one XPENG-style research root. No historical raw capture is reconstructed, no missing source is copied or synthesized, and no broad /tmp lookup is allowed. All 39 support captures must be consumed once; the 21 audit-only normalized records remain retained research, not production citations.

Each output directory is newly created exclusively. The logical original capture claim cannot change between attempts. Default sourceResearch/research/catalogue callbacks throw. Core/canonical modules reject imports of the normal data loader, reporting loader and test compilation helper. Later consumers may need the existing explicitly pinned compiled-source test helper to bind a hypothetical registry, but only under their own exact review. No full default loader is an allowed fallback.

## Required consumer proofs

See CONSUMER-ACCEPTANCE.md for the complete stage plan and buyer checks. No consumer pass is claimed by this preparation.

## Resource and authorization contract

Use only /tmp/mercedes-staging-plan/measured-command.py, 1696 bytes, SHA256 a2c4a8dffacfc8eeec29062f5b1a8e18176cd7d6949c5075f221112984bf511b. Root owns the exclusive heavy slot. Every individual stage has a 180-second timeout, 448 MiB old heap, 1 MiB semi space, --expose-gc and --import tsx. NODE_OPTIONS must be absent. No /usr/bin/time, retry loop or overlapping hydration/test/compiler/build/compression/report workload. The Python runner records stdout, stderr, exact command, elapsed time and kernel child RSS only after termination. Do not equate signal 9 or timeout with a diagnosed cause.

The templates stay blocked until actual inputs exist and reviewers accept exact files. They contain no root execution grant and do not self-authorize one.
