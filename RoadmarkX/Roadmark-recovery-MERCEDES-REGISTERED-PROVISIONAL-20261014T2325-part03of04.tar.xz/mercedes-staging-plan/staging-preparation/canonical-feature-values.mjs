/** New-version feature values only. The reviewed driver owns the exclusive once-only capture claim. */
import path from 'node:path';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { types as utilTypes } from 'node:util';
import { digestRows } from '/tmp/xpeng-staging-plan/baseline-io.mjs';

const pointerPart = value => String(value).replaceAll('~', '~0').replaceAll('/', '~1');
// Read-only shape guard, not a normalizer. JSON must not silently drop or convert
// anything except the exact manifest-declared own-undefined location checked below.
function assertDeclaredJson(value, pointer, permittedUndefined, active = new Set()) {
  if (value === undefined) { assert(permittedUndefined.has(pointer), 'Unapproved undefined: ' + pointer); return; }
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return;
  if (typeof value === 'number') {
    assert(Number.isFinite(value) && !Object.is(value, -0), 'Non-JSON-safe number: ' + pointer); return;
  }
  assert.equal(typeof value, 'object', 'Unsupported JSON value: ' + pointer);
  assert(!utilTypes.isProxy(value), 'Proxy cannot establish plain JSON parity');
  const array = Array.isArray(value);
  assert.equal(Object.getPrototypeOf(value), array ? Array.prototype : Object.prototype, 'Non-plain JSON value: ' + pointer);
  assert(!active.has(value), 'Cyclic JSON value: ' + pointer); active.add(value);
  try {
    const keys = Reflect.ownKeys(value); assert(keys.every(key => typeof key === 'string'), 'Symbol-keyed property: ' + pointer);
    if (array) {
      assert.equal(keys.length, value.length + 1, 'Sparse array or extra array property: ' + pointer);
      for (let i = 0; i < value.length; i++) assert(Object.hasOwn(value, String(i)), 'Array hole: ' + pointer);
    }
    for (const key of keys) {
      if (array && key === 'length') continue;
      if (array) assert(/^(0|[1-9][0-9]*)$/.test(key) && Number(key) < value.length, 'Extra array property: ' + pointer);
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      assert(Object.hasOwn(descriptor, 'value') && descriptor.enumerable, 'Accessor or non-enumerable property: ' + pointer);
      assertDeclaredJson(descriptor.value, pointer + '/' + pointerPart(key), permittedUndefined, active);
    }
  } finally { active.delete(value); }
}

export function captureNewFeatureValues(proof, actual) {
  const e = proof.manifest.expected;
  assert.equal(proof.manifest.phase, 'canonical');
  assert.equal(proof.canonicalCaptureClaim.generationCount, 1);
  assert.equal(proof.canonicalCaptureClaim.manifestSha256, proof.manifestSha256);
  assert.equal(proof.canonicalCaptureClaim.featureFreePacketSha256, actual.packetRef.sha256);
  assert.equal(actual.packet.features.length, 0);
  const require = createRequire(path.join(proof.anchors.repo, 'package.json'));
  const { createEvidenceConsumers } = require('./src/lib/evidence-consumers.ts');
  const { brandUpdatePackets } = require('./src/lib/brand-update-registry.ts');
  assert.deepEqual(brandUpdatePackets, proof.registeredPackets, 'Exactly the registered packet prefix; no candidate shim');
  let defaultCalls = 0;
  const forbidden = () => { defaultCalls++; throw new Error('Canonical candidate features require explicit immutable full baseline'); };
  const consumers = createEvidenceConsumers({ sourceResearch: forbidden, research: forbidden, catalogue: forbidden });
  const snapshot = { data: actual.data, cars: actual.cars }, ids = new Set(proof.manifest.newIds);
  const newCars = actual.selected.filter(car => ids.has(car.id)); assert.equal(newCars.length, e.newCars);
  assert.deepEqual(newCars.map(car => car.id), proof.manifest.newIds);
  const selectedBefore = actual.selected.map(car => digestRows([car])), features = [], comparisonFeatures = [], liveOriginalFeatures = [], perCar = [], serializationAudit = [];
  for (const car of newCars) {
    const pack = consumers.pack(car.id, snapshot);
    assert.deepEqual(pack.car, car); assert.equal(pack.features.length, e.criteria);
    assert.equal(new Set(pack.features.map(row => row.criterion)).size, e.criteria);
    assert(pack.features.every(row => row.variant_id === car.id));
    assert.deepEqual(pack.features.map(row => row.criterion).sort(), actual.data.criteria.map(row => row.key).sort());
    const allowance = proof.manifest.canonicalJsonParity.allowedOmission;
    const permittedUndefined = new Set(), omissions = [], liveOriginal = structuredClone(pack.features);
    for (const [rowIndex, row] of pack.features.entries()) {
      const descriptor = Object.getOwnPropertyDescriptor(row, allowance.property);
      if (!descriptor || !Object.hasOwn(descriptor, 'value') || descriptor.value !== undefined) continue;
      assert(descriptor.enumerable); assert.equal(row.variant_id, car.id);
      assert(allowance.variantIds.includes(car.id)); assert.equal(row.criterion, allowance.criterion);
      const pointer = '/features/' + rowIndex + '/' + pointerPart(allowance.property);
      permittedUndefined.add(pointer);
      omissions.push({ variantId: car.id, criterion: row.criterion, rowIndex, pointer, property: allowance.property,
        own: true, enumerable: true, actualValueType: 'undefined', serializedPropertyPresent: false });
    }
    assertDeclaredJson(pack.features, '/features', permittedUndefined);
    const comparison = structuredClone(pack.features);
    for (const omission of omissions) delete comparison[omission.rowIndex][omission.property];
    const serialized = JSON.parse(JSON.stringify(pack.features));
    assert.deepEqual(serialized, comparison, 'No other dropped, converted, missing or extra JSON fields');
    assert.equal(JSON.stringify(comparison), JSON.stringify(pack.features));
    assert.deepEqual(digestRows(comparison), digestRows(pack.features));
    assert.deepEqual(pack.features, liveOriginal, 'Original live rows, including own undefined properties, unchanged');
    comparisonFeatures.push(...comparison); liveOriginalFeatures.push(...liveOriginal);
    serializationAudit.push({ variantId: car.id, featureRows: pack.features.length, omissions,
      fullComparisonCloneEqual: true, fullSerializedArrayEqual: true, fullJsonlDigestEqual: true, liveRowsUnchanged: true });
    features.push(...pack.features); perCar.push({ id: car.id, ...digestRows(pack.features) }); global.gc?.();
  }
  assert.deepEqual(features, liveOriginalFeatures, 'Every original live feature row unchanged after all captures');
  for (const name of proof.manifest.forbiddenImports) assert(!require.cache[path.join(proof.anchors.repo, name)], 'Forbidden catalogue/hydration import: ' + name);
  assert.equal(features.length, e.newFeatureRows); assert.equal(defaultCalls, 0);
  for (const [i, car] of actual.selected.entries()) assert.deepEqual(digestRows([car]), selectedBefore[i]);
  actual.verifyUnchanged();
  return { features, comparisonFeatures, serializationAudit, perCar, defaultCalls, selectedCarsDigest: digestRows(actual.selected) };
}
