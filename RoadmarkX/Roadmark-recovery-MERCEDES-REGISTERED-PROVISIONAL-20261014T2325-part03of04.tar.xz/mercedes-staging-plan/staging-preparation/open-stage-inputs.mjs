/** Manifest adaptation of the XPENG proof boundary. Prepared only; execution requires exact review and root slot. */
import assert from 'node:assert/strict';
import {
  argumentsFor, readJson, fileHash, locate, referenceFor, pin, verifyPins, sourceNames,
} from '/tmp/xpeng-staging-plan/baseline-io.mjs';

export function openStageInputs() {
  const args = argumentsFor(['--manifest', '--manifest-sha256', '--review', '--review-sha256']);
  assert.equal(fileHash(args['--manifest']), args['--manifest-sha256']);
  assert.equal(fileHash(args['--review']), args['--review-sha256']);
  const manifest = readJson(args['--manifest']), review = readJson(args['--review']);
  const { anchors, expected: e } = manifest;
  assert.equal(manifest.schemaVersion, 1); assert.equal(manifest.mode, 'reviewed-brand-staging-v1');
  assert.equal(manifest.status, 'frozen_pending_independent_review_and_explicit_root_grant', 'Blocked templates cannot run');
  assert(['canonical', 'final-core'].includes(manifest.phase));
  assert.equal(process.cwd(), anchors.repo); assert.equal(process.version, manifest.nodeVersion);
  assert.equal(typeof global.gc, 'function'); assert.equal(process.env.NODE_OPTIONS, undefined);
  assert.deepEqual(process.execArgv, manifest.execution.execArgv);
  assert.equal(manifest.execution.timeoutSeconds, 180);
  assert.equal(manifest.execution.requiresSeparateRootHeavySlotGrant, true);
  assert.equal(manifest.execution.automaticRetry, false);
  assert.equal(review.status, 'approved_for_' + manifest.phase.replace('-', '_') + '_brand_staging_v1');
  assert.equal(review.phase, manifest.phase); assert.equal(review.manifestSha256, args['--manifest-sha256']);
  assert.equal(review.evidenceReviewed, true); assert.equal(review.compositionReviewed, true);
  assert.equal(review.canonicalCaptureAuthorized, manifest.phase === 'canonical');
  assert.equal(review.productionRegistrationAuthorized, false);
  assert.equal(review.separateRootExecutionGrantRequired, true);
  assert.deepEqual(review.harnessPins, manifest.harnessPins);
  assert.deepEqual(review.anchorExtension, manifest.anchorExtension);
  assert.deepEqual(review.canonicalJsonParity, manifest.canonicalJsonParity);
  assert.equal(e.afterCars, e.beforeCars + e.newCars);
  assert.equal(e.selectedCars, e.existingCars + e.newCars);
  assert.equal(e.unselectedCars, e.beforeCars - e.existingCars);
  assert.equal(e.existingFeatureRows, e.existingCars * e.criteria);
  assert.equal(e.newFeatureRows, e.newCars * e.criteria);
  assert.equal(e.afterFeatureRows, e.afterCars * e.criteria);
  assert.equal(e.authorizedFeatureMutations, 0);
  locate(anchors, referenceFor(anchors, args['--manifest'])); locate(anchors, referenceFor(anchors, args['--review']));
  const pins = new Map(manifest.inputPins.map(ref => [locate(anchors, ref), ref]));
  assert.equal(pins.size, manifest.inputPins.length, 'No duplicated or ambiguous reviewed input paths');
  function assertPinned(ref) {
    const accepted = pins.get(locate(anchors, ref)); assert(accepted, 'Missing reviewed input pin');
    assert.equal(ref.sha256, accepted.sha256); assert.equal(ref.bytes, accepted.bytes);
  }
  function read(ref) { assertPinned(ref); pin(anchors, ref); return readJson(locate(anchors, ref)); }
  function absolutePin(ref) { return { path: locate(anchors, ref), sha256: ref.sha256, bytes: ref.bytes }; }
  for (const ref of manifest.harnessPins) assertPinned(ref);
  for (const file of ['read-complete-storage.mjs', 'compose-brand-research.mjs', 'apply-actual-core.mjs', 'canonical-feature-values.mjs', 'open-stage-inputs.mjs', 'run-core-stage.mjs', 'STAGING-DESIGN.md']) {
    assert(manifest.harnessPins.some(ref => ref.anchor === 'staging' && ref.file === file), 'Missing reviewed adaptation');
  }
  for (const ref of Object.values(manifest.dependencies)) assertPinned(ref);
  assert.equal(locate(anchors, manifest.dependencies.io), '/tmp/xpeng-staging-plan/baseline-io.mjs');
  assert.equal(locate(anchors, manifest.dependencies.storageReader), '/tmp/xpeng-staging-plan/staging-v1/read-complete-storage.mjs');
  assert.equal(locate(anchors, manifest.dependencies.measuredRunner), '/tmp/mercedes-staging-plan/measured-command.py');
  for (const key of ['baselineManifest', 'baselineAcceptance', 'baselineExtractionReceipt', 'baselineStorageIndex', 'baselineFeatureIndex', 'currentSourceInventory', 'selectedBeforeCars', 'existingBeforeFeatures', 'beforeFeatureParityAudit', 'assemblerManifest', 'assemblyReceipt', 'assemblyAcceptance', 'featureFreePacket', 'packet', 'evidenceReview', 'compositionReview', 'normalizedEvidence', 'sourceCaptureManifest']) assertPinned(manifest[key]);
  const baseline = read(manifest.baselineManifest), receipt = read(manifest.baselineExtractionReceipt), acceptance = read(manifest.baselineAcceptance);
  assert.deepEqual(anchors, { ...baseline.anchors, ...manifest.anchorExtension }, 'Inherited anchors unchanged; no undeclared broad /tmp anchor');
  assert.deepEqual(manifest.anchorExtension, {
    staging: '/tmp/mercedes-staging-plan/staging-preparation',
    packetPreparation: '/tmp/mercedes-staging-plan/packet-preparation',
    mercedesResearch: '/tmp/mercedes-research',
    mercedesWarranty: '/tmp/mercedes-review/warranty',
    mercedesReview: '/tmp/mercedes-review',
    mercedesPlan: '/tmp/mercedes-staging-plan',
  });
  for (const ref of baseline.inputPins) assertPinned(ref);
  assert.deepEqual(manifest.baselineStorageIndex, baseline.accepted.storageIndex);
  assert.deepEqual(manifest.baselineFeatureIndex, baseline.accepted.featureIndex);
  assert.deepEqual(manifest.currentSourceInventory, baseline.accepted.registeredSourceInventory);
  assert.deepEqual(manifest.registeredPackets, baseline.registeredPackets);
  assert.deepEqual(manifest.researchFields, baseline.expected.researchFields);
  assert.deepEqual(manifest.existingIds, baseline.expected.selectedIds);
  assert.equal(e.beforeCars, baseline.expected.cars); assert.equal(e.beforeFeatureRows, baseline.expected.featureRows);
  assert.equal(e.criteria, baseline.expected.criteria); assert.equal(e.registeredPackets, baseline.expected.registeredPackets);
  assert.equal(receipt.status, 'passed_read_only_reviewed_derived_baseline_extraction');
  assert.equal(acceptance.status, 'accepted_exact_read_only_derived_baseline_extraction');
  assert.deepEqual(acceptance.extractionReceipt, absolutePin(manifest.baselineExtractionReceipt));
  assert.deepEqual(acceptance.manifest, absolutePin(manifest.baselineManifest));
  assert.equal(receipt.manifestSha256, manifest.baselineManifest.sha256);
  assert.equal(receipt.completeCarsVerified, e.beforeCars); assert.equal(receipt.completeFeatureRowsVerified, e.beforeFeatureRows);
  assert.equal(receipt.actualFeatureRows, e.existingFeatureRows); assert.equal(receipt.defaultLoaderCalls, 0);
  assert.deepEqual(receipt.selectedIds, manifest.existingIds);
  assert.deepEqual(receipt.featureParityPolicy, manifest.existingFeatureParity);
  assert.deepEqual(baseline.featureParity, manifest.existingFeatureParity);
  for (const [key, name] of [['selectedBeforeCars', 'selected-complete-before-cars.json'], ['existingBeforeFeatures', 'actual-before-features.json'], ['beforeFeatureParityAudit', 'before-feature-json-parity-audit.json']]) {
    assert.deepEqual(receipt.artifacts[name], absolutePin(manifest[key]));
    assert.deepEqual(acceptance.artifacts[name], absolutePin(manifest[key]));
  }
  const composition = read(manifest.compositionReview);
  assert.equal(composition.status, 'approved_exact_registered_prefix_plus_candidate_composition');
  assert.equal(composition.baselineStorageIndexSha256, manifest.baselineStorageIndex.sha256);
  assert.equal(composition.packetSha256, manifest.packet.sha256);
  assert.deepEqual(composition.contract, manifest.compositionContract);
  assert.equal(review.compositionReviewSha256, manifest.compositionReview.sha256);
  assert.equal(review.evidenceReviewSha256, manifest.evidenceReview.sha256);
  const assembler = read(manifest.assemblerManifest), assembly = read(manifest.assemblyReceipt), acceptedAssembly = read(manifest.assemblyAcceptance);
  assert.equal(assembler.mode, 'reviewed-brand-packet-assembly'); assert.equal(assembler.phase, 'feature-free');
  assert.equal(assembly.status, 'assembled_pending_actual_function_validation');
  assert.equal(assembly.manifestSha256, manifest.assemblerManifest.sha256);
  assert.equal(assembly.normalizedEvidenceSha256, manifest.normalizedEvidence.sha256);
  assert.equal(assembly.baselineReceiptSha256, manifest.baselineExtractionReceipt.sha256);
  assert.deepEqual(assembly.outputs.packet, absolutePin(manifest.featureFreePacket));
  assert.equal(assembly.productionFunctionsExecuted, false); assert.equal(assembly.canonicalCapturePerformed, false);
  assert.equal(acceptedAssembly.status, 'accepted_exact_feature_free_assembly_output');
  assert.equal(acceptedAssembly.assemblyReceiptSha256, manifest.assemblyReceipt.sha256);
  assert.equal(acceptedAssembly.packetSha256, manifest.featureFreePacket.sha256);
  assert.equal(acceptedAssembly.normalizedEvidenceSha256, manifest.normalizedEvidence.sha256);
  assert.deepEqual(assembler.newIds, manifest.newIds); assert.deepEqual(assembly.newIds, manifest.newIds);
  assert.equal(manifest.newIds.length, e.newCars); assert.equal(new Set(manifest.newIds).size, e.newCars);
  assert.equal(manifest.existingIds.length, e.existingCars);
  const registeredPackets = manifest.registeredPackets.map(row => { const packet = read(row.input); assert.equal(packet.id, row.id); return packet; });
  assert.equal(registeredPackets.length, e.registeredPackets);
  const packet = read(manifest.packet), normalized = read(manifest.normalizedEvidence);
  assert.deepEqual(manifest.packet, manifest.featureFreePacket, 'Canonical and final reuse identical feature-free bytes');
  assert.equal(packet.id, manifest.packetId); assert.equal(packet.brand, manifest.brand); assert.equal(packet.reviewedAt, manifest.asOf);
  assert.deepEqual(packet.variants.map(row => row.id), manifest.newIds);
  assert.equal(packet.features.length, 0); assert(normalized.variants.every(row => Array.isArray(row.features) && row.features.length === 0));
  assert.equal(packet.facts.length, e.facts); assert.equal(packet.summaries.length, e.selectedCars);
  assert.equal(packet.sources.length, e.directSources); assert.equal(normalized.sources.length, e.retainedSourceRecords);
  assert.deepEqual(normalized.currentVersionReviews, [], 'Current version census remains open');
  for (const key of ['brandTerms', 'versionUpdates', 'configurationUpdates']) assert.equal((packet[key] ?? []).length, 0);
  const evidence = read(manifest.evidenceReview);
  assert.equal(evidence.status, 'accepted_research_content_for_packet_drafting_only');
  // The normalization reviewer binds the frozen source in its own exact receipt.
  assert.deepEqual(evidence.artifact, absolutePin(manifest.normalizedEvidence));
  const captures = read(manifest.sourceCaptureManifest);
  assert.equal(captures.schemaVersion, 1); assert.equal(captures.normalizedEvidenceSha256, manifest.normalizedEvidence.sha256);
  assert.equal(captures.captures.length, e.supportCaptures);
  assert.deepEqual(manifest.packetSourceKeys, assembler.packetSourceKeys);
  const normalizedKeys = normalized.sources.filter(row => manifest.packetSourceKeys.includes(row.key)).map(row => row.key);
  assert.deepEqual(packet.sources.map(row => row.id), normalizedKeys.map(key => manifest.packetId + '-' + key));
  const captureMap = new Map();
  for (const row of captures.captures) {
    const ref = referenceFor(anchors, row.path);
    assert(['mercedesResearch', 'mercedesWarranty'].includes(ref.anchor), 'Only exact retained source roots');
    assert.equal(row.originalPath, row.path, 'No reconstructed or relocated captures in this version');
    const input = { ...ref, sha256: row.sha256, bytes: row.bytes }; assertPinned(input); pin(anchors, input);
    const key = JSON.stringify([row.sourceKey, row.locator]); assert(!captureMap.has(key)); captureMap.set(key, row);
  }
  const seen = new Set();
  for (const source of packet.sources) {
    const key = source.id.slice(manifest.packetId.length + 1);
    assert(source.retainedCaptures.length > 0);
    assert.equal(source.capture_locator, source.retainedCaptures[0].locator);
    assert.equal(source.capture_sha256, source.retainedCaptures[0].sha256);
    for (const capture of source.retainedCaptures) {
      const identity = JSON.stringify([key, capture.locator]), expected = captureMap.get(identity);
      assert(expected, 'Every locator resolves through exact reviewed source/capture map'); assert(!seen.has(identity));
      assert.equal(capture.sha256, expected.sha256); assert.equal(capture.bytes, expected.bytes); seen.add(identity);
    }
  }
  assert.deepEqual([...seen].sort(), [...captureMap.keys()].sort(), 'Every reviewed support capture retained exactly once');
  assert.deepEqual(manifest.canonicalJsonParity.allowedOmission.variantIds, manifest.newIds);
  assert.equal(manifest.canonicalJsonParity.allowedOmission.criterion, 'novated_fbt');
  assert.equal(manifest.canonicalJsonParity.allowedOmission.property, 'confirmation_needed');
  assert.equal(manifest.canonicalJsonParity.allowedOmission.valueType, 'undefined');
  for (const key of ['comparisonCloneOnly', 'liveRowsMustRemainUnchanged', 'allOtherUndefinedRejected', 'nonJsonValuesRejected', 'fullSerializedArrayEqualityRequired', 'fullJsonlDigestEqualityRequired', 'runtimeObservationsRequired']) assert.equal(manifest.canonicalJsonParity[key], true);
  assert.equal(manifest.canonicalJsonParity.observedOmissionCount, null, 'No predicted count presented as observed');
  if (manifest.phase === 'final-core') {
    for (const key of ['canonicalMeta', 'canonicalPacket', 'canonicalSelectedCars', 'canonicalNewFeatures', 'canonicalJsonAudit', 'canonicalAcceptance']) assertPinned(manifest[key]);
    const canonical = read(manifest.canonicalAcceptance);
    assert.equal(canonical.status, 'accepted_original_brand_canonical_baseline');
    assert.equal(canonical.canonicalMetaSha256, manifest.canonicalMeta.sha256);
    assert.equal(canonical.captureGenerationCount, 1); assert.equal(canonical.newFeatureRows, e.newFeatureRows);
    assert.equal(canonical.exactOriginalPacketAndSelectedCarsVerified, true);
    assert.equal(canonical.all14RawAndComposedFieldsVerified, true);
    assert.equal(canonical.allOriginalNewFeatureRowsVerified, true);
    assert.equal(canonical.serializationAuditSha256, manifest.canonicalJsonAudit.sha256);
  }
  const inventory = read(manifest.currentSourceInventory);
  for (const row of inventory.files) assertPinned({ anchor: 'repo', ...row });
  function verify() {
    assert.equal(fileHash(args['--manifest']), args['--manifest-sha256']); assert.equal(fileHash(args['--review']), args['--review-sha256']);
    assert.deepEqual(sourceNames(anchors.repo), inventory.files.map(row => row.file).sort());
    verifyPins(anchors, manifest.inputPins);
  }
  verify();
  return { anchors, manifest, manifestSha256: args['--manifest-sha256'], reviewSha256: args['--review-sha256'], registeredPackets, assertPinned, verify };
}
