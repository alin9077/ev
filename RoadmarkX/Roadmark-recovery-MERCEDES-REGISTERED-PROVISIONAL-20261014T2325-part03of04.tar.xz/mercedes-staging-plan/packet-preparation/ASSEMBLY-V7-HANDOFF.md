# Frozen Mercedes feature-free assembly V7

This supersedes the V4 handoff and V6 command plan. Earlier frozen files remain unchanged. No assembler, capture drift scan, production import, hydration, canonical capture, test or compiler was run during this preparation.

## Exact static cut

- Adapter: `assemble-reviewed-packet-v5.py`, 38,889 bytes, SHA256 `a7eac647a6f2672e660faf1110e4cd412a4a0c641dfa4cf6d8ffe9e321c04d3a`
- Manifest: `assembly-feature-free-v7.json`, 20,165 bytes, SHA256 `f73d5c03399b3444175046e4e6ca5d7345927e0d080a1e60c967914049a04201`
- Capture map: `source-capture-manifest-v6.json`, 18,041 bytes, SHA256 `3e18f87b18dd36a39a64dfdc3394cd46e84297ea00edd257ae07cbc105e86300`
- Command plan: `command-plan-v7.json`, 4,043 bytes, SHA256 `33b23ffd4c7250a779924e245e6646d98124642c976eb4424be1349fcf5f22b9`

The manifest binds exact accepted normalized V6, its content review and auxiliary audit, the accepted 405-car baseline, seven complete before cars and guards, 483 actual before feature rows, and the independently verified complete 180-model field. All four proposed model IDs are absent from that complete field. All four new formal model years remain null.

There are 258 fact replacements/additions, 39 direct support sources, 11 whole-summary replacements, four new versions/models, zero feature mutations and zero shared brand terms. All 245 existing facts are accounted for in the retained exact-hash audit. Availability reasons are copied verbatim exactly once into buyer-visible qualifications. Fact qualifications, source types, cohort limits, unranked grades and charging/price basis distinctions remain unchanged.

## Narrow drive metadata projection

V7 adds exactly seven versionUpdates in accepted existing-ID order. Each before is the full accepted nine-field version snapshot. Each after changes only drive from Unknown: EQA FWD; CLA200 RWD; CLA350 AWD; GLB250 RWD; GLB350 AWD; EQS400 RWD; G580 AWD. The manifest pins each full normalized drive fact, and the adapter binds the projection to that exact Fact and its source IDs. All seven facts remain Reported and unranked.

The unchanged production prepareBrandResearch function also materializes raw Variant.brand_update_model and brand_update_generation. Root explicitly allowed these only on the seven updated rows, equal to their unchanged accepted model and generation. Both markers are absent in the accepted raw before rows. The manifest's driveMetadataProjection.rawVariantProjection declares this exact boundary; no other metadata changes are permitted. The provenance audit retains raw before rows and expected rows immediately after metadata, before the independently guarded availability projection. The staging adapter must compose the availability change afterward and compare the full actual result, without deleting the derived markers.

## Capture and output contracts

The 39 named capture pins declare 29,842,473 bytes and remain metadata expectations until an authorized execution checks the exact files. No capture scan was performed here. Resolve retainedCaptures locators through the exact capture map under `/tmp/mercedes-research` and `/tmp/mercedes-review/warranty`. Keep the 21 audit-only source records outside packet grade support; do not reconstruct missing older captures.

Proposed exclusive output directory remains `outputs/feature-free-v1`, containing `mercedes-benz-feature-free-2026-10-15.json`, `effective-facts-feature-free.json`, `research-provenance-audit.json`, and `assembly-receipt.json`. No output hashes exist yet. Success status would be `assembled_pending_actual_function_validation`.

## Review and execution gates

The proposed review is `/tmp/mercedes-review/packet-assembly-v7-review.json`, with status `approved_for_reviewed_brand_packet_assembly`, binding manifestSha256, assemblerSha256 and sourceCaptureManifestSha256. Its eventual exact hash is the only unresolved command argument. Do not insert a fake hash or edit the frozen manifest to mark it approved.

The unchanged common measured runner uses exclusive `/tmp/mercedes-staging-plan/runs/packet-assembly-v1` logs and a 180-second limit. Root must grant this specific run separately after exact static review; a backup or other heavy task may not overlap it. The command plan preserves the exact argv and cwd.

Actual production functions, one-time canonical capture, complete unchanged-peer/raw-field equality and consumer/report checks remain separate gates. If those consumers accept the empty feature-mutation set, reuse the original feature-free packet bytes as final. Do not cosmetically reassemble. C1, unresolved editions, source registration and publication remain open.
