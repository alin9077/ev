# Current frozen assembly handoff

This handoff supersedes preparation-era status and interface descriptions in the earlier design/templates where they differ. Earlier drafts and both earlier adapter files remain intact. No assembly driver has been executed, imported, compiled or tested.

## Frozen inputs and adapter

- Adapter V3: `assemble-reviewed-packet-v3.py`, 33,905 bytes, SHA256 `d09fbf9bfe28b435e76e5f53b94e0074bef27bc432ddad8c6d2a100d25528eff`
- Final manifest: `assembly-feature-free-v4.json`, 15,700 bytes, SHA256 `df111689fd4a6c0c5f8dfa980ff6548e5de9123030c0cb7938cd332544cc8afe`
- Source-capture manifest: `source-capture-manifest-v4.json`, 18,041 bytes, SHA256 `625ba61f8d21f4ef2391591f277aa1075aa4ef07b952ce9a3e2f23add9afd271`
- Research V4: `/tmp/mercedes-research/normalized-evidence-v4.json`, 348,221 bytes, SHA256 `e41bc682267120bd9043554356c16c63325d7e69bbc28061f7e1a8b750304118`
- Exact research review: `/tmp/mercedes-review/normalized-evidence-v4-review.json`, 5,129 bytes, SHA256 `c543337629b98ea5be16494923b6e49e5ad6d2a0e0073a3848b69af117799fa8`
- Complete auxiliary consistency audit: `/tmp/mercedes-research/current-auxiliary-consistency-audit-v4.json`, 167,663 bytes, SHA256 `633b94d3e4aef935abfa58c1a4cc06586414f4fd5d2131cddc98b08b1c2c22af`
- Accepted baseline output review: `/tmp/mercedes-staging-plan/baseline-preparation/reviews/baseline-v2-output-acceptance.json`, 7,707 bytes, SHA256 `feb366eb9b3f35f99a07000c5e05c3fcbf406b15aee2330aa00f31a3bfe3e7a8`

Every manifest input pin now refers to actual accepted artifacts or explicitly frozen expected capture provenance. The independent assembly review remains external, so its later hash does not create a circular manifest dependency. The manifest is frozen with status `frozen_pending_independent_review_and_explicit_root_grant`; do not change this status after review.

## What was checked during preparation

The 32,305-byte complete models JSONL was read and its exact SHA256 matched the successful independently accepted 14-field verification. It has 180 unique model IDs. All four proposed Mercedes model IDs are absent, so the manifest's exact new-model list/count is now supported. This was a bounded field read, not catalogue hydration.

The accepted actual seven-car before file, selected metadata and small receipts were read for schema/auxiliary decisions. The driver preserves every full original before Fact and version guard, all original dates and the exact declared before-feature JSON parity audit. It does not remove undefined fields, rewrite the accepted baseline or pretend raw own-property equality.

The V4 audit accounts for all 245 existing facts: 158 explicit guarded current overlays, 80 unchanged dated unresolved facts, and seven unchanged historical identity facts. The new adapter verifies their exact audited hashes, values, dates and source IDs against the accepted before cars. It requires retained rows to be untargeted and binds all seven original summary hashes to the reviewed whole-summary replacements. The audit is retained in the separate provenance output.

Current research proposes 258 facts, no feature mutations, no brandTerms, no versionUpdates and no configurationUpdates. It retains 11 identities and 39 actual support sources. The two new attributed charging keys and five warranty auxiliary keys have explicit metadata; normalized units and labels override defaults, including `Unlimited`, SOCE and SOHC. No kilometres, warranty caps, model years, charging windows or comparison groups are inferred.

## Capture policy

No source capture drift scan was performed. The 39 expected capture pins, with 29,842,473 declared bytes, are copied unchanged from reviewed research provenance. The future authorized adapter checks those exact named files twice. It does not scan all 60 source files or traverse the research tree.

The 21 audit-only source records stay outside packet.sources and grade support. All normalized research, alternatives, locators, provenance, excluded candidates and review caveats are retained separately. Historical manufacturer codes and unresolved roadside rows retain their original facts and dates; they are not newly verified.

Every packet source retainedCapture has a stable locator. Resolve `mercedes-research/...` and `mercedes-review/warranty/...` through the exact reviewed locator-to-path map in the capture manifest and the two allowed roots. The next staging adaptation must not prepend XPENG's single research anchor, widen access to arbitrary `/tmp`, or reconstruct missing raw originals.

## Run and review contract

`command-plan-v4.json` records the exact common measured-runner command, repo cwd, exclusive `/tmp/mercedes-staging-plan/runs/packet-assembly-v1` logs and 180-second timeout. The runner is `/tmp/mercedes-staging-plan/measured-command.py`, 1,696 bytes, SHA256 `a2c4a8dffacfc8eeec29062f5b1a8e18176cd7d6949c5075f221112984bf511b`. No extra wrapper was created.

Proposed independent review path: `/tmp/mercedes-review/packet-assembly-v4-review.json`. Its accepted status must be `approved_for_reviewed_brand_packet_assembly`. It must bind the exact `manifestSha256`, `assemblerSha256` and `sourceCaptureManifestSha256` above. The review may record additional checks and exact command-plan/runner pins. A review cannot pin its own future hash; root supplies the independently verified review hash as the sole unresolved command argument after that file exists.

Root must separately grant the run. Static acceptance never grants execution. No output files or hashes exist yet. A successful receipt says only `assembled_pending_actual_function_validation`; it is not canonical, consumer, coverage, full-report, registration, compiler/build/test/mobile or publication acceptance.

## Downstream handoff

Outputs are proposed under `outputs/feature-free-v1/`: `mercedes-benz-feature-free-2026-10-15.json`, `effective-facts-feature-free.json`, `research-provenance-audit.json`, then `assembly-receipt.json`. Writes are exclusive, and each attempt requires an absent output directory.

The staging worker has the exact schema/path contract and `PROJECTION-ORDER-GUARDS.md`. It must retain the current guarded fact/feature ordering and compare every complete unchanged peer. C1, editions, Tier 2 work and release gates remain open.

Because all reviewed feature mutation lists are empty, the same original feature-free packet bytes should be final if actual canonical/final consumers accept them. Do not run a cosmetic final assembly or create a semantically equivalent replacement packet. Keep the original canonical fixture immutable.
