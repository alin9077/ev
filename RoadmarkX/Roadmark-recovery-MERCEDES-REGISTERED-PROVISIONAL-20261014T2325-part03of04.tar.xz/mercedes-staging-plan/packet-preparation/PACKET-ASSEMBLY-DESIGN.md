# Reusable packet assembly preparation

Status: static preparation only. The adapted driver has not been run, imported, compiled or tested. No packet, canonical fixture, before-value output, report or repository edit was produced here.

## Reuse boundary

`assemble-reviewed-packet.py` adapts the existing XPENG `assemble-packet.py` (16,609 bytes; SHA256 `6857eb4fc24b13b5d721b22ad433b054789de26c8907f22bdd02fac673e3460e`). It retains the same assembly stages:

1. Read an externally pinned manifest, accepted research and actual baseline artifacts
2. Retain exact source snapshots and capture pins
3. Add only genuinely new model/version identities
4. Construct reviewed facts using the complete original fact as `before`, or actual null for a new fact
5. Construct availability from the complete original evidence snapshot
6. Construct summaries with full post-packet Fact objects as dependencies
7. For an explicitly reviewed final phase, preserve the original feature-free canonical packet and bind exact original/canonical feature rows and complete post-packet dependencies
8. Recheck all inputs and captures, write exclusive outputs, then write a receipt

This is an adaptation of that interface, not another consumer, proof library, production loader, canonical generator or per-brand testing framework. Python formatting expands the original dense script. Brand, packet ID, review status, source selection, root containment, expected populations, metadata labels and artifact pins are manifest data. It does not edit the original XPENG driver.

The driver uses explicit `require` checks instead of Python assertions so `python -O` cannot erase its gates. Its receipt deliberately says `assembled_pending_actual_function_validation`.

## Accepted research and remaining gates

Use only `/tmp/mercedes-research/normalized-evidence-v2.json`, 260,500 bytes, SHA256 `3ab4076acb02eb2a02fe33af06ddb934640b6f69ff8b757652afb2572c9a453d`.

The independent content review is `/tmp/mercedes-review/normalized-evidence-v2-review.json`, 4,314 bytes, SHA256 `b71a75182426cad7ed349816d8d82007dbb3f52573311c016f01c5570e86f66e`. Its actual status is `accepted_research_content_for_packet_drafting_only`. It is not the XPENG review status, capture-drift verification, runtime acceptance or execution permission. The adapter checks its exact `artifact` object, without manufacturing a review schema field absent from this receipt.

V1 contained four summary clauses with null dependencies, which the unchanged production `clauseFor` rejects. This was reported to the parent. Reviewed V2 changes those clauses to non-null supporting facts; no fact or source was silently changed by this adapter. The adapter still fails closed if a future normalized summary contains null dependency values.

Baseline-v2 now passed at `/tmp/mercedes-staging-plan/baseline-preparation/extractions/baseline-v2`; its 13,087-byte receipt is SHA256 `db98036235d515ed01c0bc740066b05864d072dcb92755895c0aaeb82b4e9a81`. Independent output acceptance is pending. The current `assembly-manifest-template-v2.json` copies actual artifact pins from that receipt, without claiming acceptance or reading the full before context. Output-review, capture-review and complete-model inputs remain unresolved. The earlier template-v1 is retained as preparation history, not the current interface. Failed baseline-v1 must never supply before values.

Baseline-v2 expressly proves complete JSON parity while allowing only the declared optional own `confirmation_needed: undefined` property on each selected `novated_fbt` row to be absent in JSON. It does not claim raw in-memory own-property equality. The adapter preserves the exact parity policy and observed audit, binds them to the pinned baseline manifest/receipt, and does not apply any omission, trimming or transformation itself. Before feature objects are copied as the exact accepted persisted JSON. An independent reviewer must accept that precise boundary before assembly.

## Population and exact-before semantics

The template identifies the seven existing passenger IDs in baseline order and the four prospective new identities in research order. The expected input population is 405 complete cars, 27,945 complete feature rows and 483 actual selected feature rows. The research has 11 identities, 196 fact updates, no authored feature replacements, no brandTerms and 11 summaries. Those are reviewed content expectations, not claimed output measurements.

The packet copies `versionGuards` directly from the accepted extraction output. Existing fact `before` values are deep copies of the entire actual `car.facts[key]`, including fields the adapter does not interpret. Existing availability `before` contains the entire actual availability evidence object. No field is trimmed, regenerated, corrected or replaced with a canonical default. Existing identity metadata is retained; the adapter emits no versionUpdates or configurationUpdates.

New records alone have empty prior facts. Their initial availability before projection is the same narrow unchanged `newVariantCar` projection used by XPENG. This is expressly not a captured actual-before baseline. Unchanged production application must confirm that default before the separately authorized one-time canonical capture. Never regenerate the original canonical capture to accommodate a failure.

All four prospective new normalized records have `modelYear: null`. The adapter copies that actual null directly to `model_year`. Production `Variant.model_year` explicitly accepts number, string or null, and the identity admission checks do not require a numeric model year. No snapshot date or configuration code becomes a model year. This is a static schema finding, not a claim of runtime validation.

Cargo eVito `mercedes_benz_evito_current__112_lwb_panel_van__20261010` is an explicit excluded invariant. Its row and features, and all 398 unselected pre-existing cars, remain the responsibility of the unchanged full candidate validation phase. Assembly makes no claim to have run that phase.

## Complete model membership, without widening the baseline extraction

The baseline convenience context includes only selected models. It cannot establish whether a prospective model already exists in the full Research object.

The future assembly therefore takes a separately pinned complete models JSONL input. Its rows, byte count and SHA256 must exactly match `models` in the successful extraction's `complete-research-field-verification.json`. It is read only after the baseline output review is accepted. That review must bind the exact `completeModelsPin`. The adapter derives genuinely new model IDs against this full field and compares them with independently frozen `newModelIds`; the expected new-model count remains null until that decision is supported.

The already accepted XPENG storage-index descriptor advertises `xpeng/staging-artifacts/final-core-v1/raw-research-models.jsonl`, 180 rows, 32,305 bytes, SHA256 `5552903519e10ae56426b094c51e3f73addf5048f9dbadd259c0585abecf1f6c`. The successful baseline-v2 field-verification artifact now records that same complete digest. These small metadata files were read; the model payload was not read here. Do not populate the runnable input until independent output acceptance establishes the linkage. No change to the narrow baseline extraction output is proposed.

## Evidence mapping that must survive assembly

- Reported and Check values keep empty `comparisonBasis` and remain unranked in this packet. Any conflicting normalized comparable basis causes a stop
- Explicit `comparison: ""` is preserved. No truthy/falsy fallback can replace it with a default
- Fact labels and units come from reviewable manifest metadata when normalized research omits them. Basis fallbacks are conservative descriptive field labels, never inferred measurement protocols. No prior fact label or basis is inherited to supply missing evidence
- All comparison bases must be explicit in normalized research. Missing comparison is empty, even for Confirmed values. This is intentionally conservative; Confirmed seats without an explicit comparison remain out of a comparable cohort until the research author reviews that basis. The assembly must not manufacture a ranking quota
- The generic DC label is `DC charging duration`. It is never the XPENG default `DC 10–80% charge time`. EQA/EQB City 35/32-minute values preserve their literal unestablished-window basis and empty comparison. No negated `10–80` phrase is inserted in the basis, because the unchanged coverage parser would match it
- Source prices that exclude government charges/options are not relabelled before-on-road. All selected secondary prices remain Reported with original exclusions and `rankingEligible: false`
- GLC retains `announced_provisional`, `listed_unconfirmed`, unverified stock and the exact qualifications. Actual availability/coverage consumers must verify Not confirmed and exclusion from the on-sale denominator
- Tourer battery remains 93 kWh Check with the 90 kWh usable conflict, not a gross/usable conversion. Its all-seats-up boot remains null Not published. Cargo eVito is never selected
- Warranty facts remain the already researched per-version facts. Passenger and vans warranty have different scope. No XPENG brandTerms, exceptions, importer programme or equipment answers are duplicated
- Extra `cargo_third_row_folded_l`, `frunk_l`, `optional_agility_comfort` and `offroad_manoeuvring` facts are preserved and can supply exact summary dependencies
- GLB's historical audit remains ancillary. Only actual `sourceKeys` enter grade support. Internal, government, historical, dealer and secondary source types are preserved literally; none is retyped as manufacturer authority
- `currentVersionReviews` remains empty. The adapter refuses incoming closure entries. Equipment-edition census, C1 and whole-market reconciliation stay open

No production Fact field exists for a general `rankingEligible` boolean. Empty `comparisonBasis` carries that exclusion here; only price has its own `priceEvidence.rankingEligible`. The original normalized research, including alternative values, exact locators, historical witnesses, conflicts, audit sources and all ranking annotations, is retained verbatim inside a separate provenance audit output. It is not added to grade support.

## Sources and capture scope

Only 39 directly referenced support sources are candidates for packet.sources. The remaining 21 source records, including failed retrievals and the historical GLB audit, remain in the normalized-provenance audit. The template source-capture inventory copies existing expected path/byte/hash metadata; it is not a scan or drift acceptance.

Both `/tmp/mercedes-research` and `/tmp/mercedes-review/warranty` are explicit allowed capture roots. This avoids moving or reconstructing warranty captures. Exact-byte copies are supported only with reviewed original and destination pins, identical bytes/hash and a declared `exact-byte-copy` provenance object. Both originals and copies must still verify. Missing historical originals cannot be reconstructed or substituted.

For every packet source, the manifest accounts for all normalized `file`, `factualStateFile`, `textFile` and supplementary captures. The adapter checks exact bytes and hash before assembly and again before writing. Unused reviewed captures, missing captures, silent additions and silent repinning fail. Audit-only raw files are not read or falsely claimed drift-verified by this assembly.

See `SOURCE-CAPTURE-PLAN.md` for the exact inventory/review contract.

## Deliberate limits

The final-phase branch retains XPENG's canonical equality and full dependency construction, with counts and names parameterized. It does not invent feature rows: current research has zero proposed replacements. Whole-row Not published feature updates require separately reviewed criterion-specific support; this adapter stops rather than guessing that schema. No feature-free artifact may be declared a final validated packet merely because the feature list is empty.

The generic brandTerms branch accepts only explicitly supplied terms and explicit exceptions; current Mercedes research supplies none. The template cannot run until independently reviewed actual pins and status strings replace every null and the manifest status is intentionally changed. That change still does not grant execution.

No typecheck, tests, runtime import, source capture scan, candidate intake, complete-car/feature comparison, negative fixture, full-report parity, registration, normal CLI, production build, mobile check, M1 completion or release result is claimed.
