# Exact projection ordering for the later staging review

Static inspection only. No production import, assembly, canonical capture or consumer execution was performed for this check.

## Fact application order

The unchanged normal catalogue entry point in `src/lib/data.ts` applies:

1. `buildSourceCatalogue` (historical overlays, corrections, refreshes and original summary construction)
2. `applyRetainedFactFills`
3. `applyPriceLadder`
4. `applyEvidenceRegrading`
5. `prepareResearch` / `applyBrandUpdates` with the ordered packet registry
6. Only the Tier 1 `buyerGradesRequired: true` marker map, then return

The Mercedes staging adaptation starts from the accepted complete 405-car effective state. It must reuse the existing XPENG core pattern: `prepareBrandResearch(beforeData, [packet])`, explicit reviewed metadata composition, then `applyBrandUpdates(before, composedData, [packet])`. Do not rerun historical fact fills, price selection, fact regrading or old packet application on this already effective baseline. Such a rerun would be a change of semantics, not a fallback.

The production BrandTerm schema supports only `warranty`, `battery_warranty` and `roadside_assistance`. `expandBrandTerms` expands explicitly supplied terms inside `applyBrandUpdates`, before that packet's guarded fact replacement loop. The current Mercedes packet is deliberately expected to have zero brandTerms. No inherited XPENG policy is copied.

Consequently, no shared warranty/fact projection after this new guarded packet can append the old GLB omission, old SoH unit or old May-2026 wording to the replaced facts. Full new fact objects replace their original complete objects; qualifications are not merged.

## Summary replacement

Every one of the 11 authored summaries has a new strength, trade-off and conditions array. The assembler copies only the normalized summary, with missing conditions explicitly becoming `[]`. It never reads the old buyerSummary.

`summaryFor` constructs a fresh complete summary. `applyBrandUpdates` assigns that new object to `buyerSummary`; it never merges the old object's strengths, trade-offs, conditions, source snapshots or freshness records. All seven actual accepted before cars lack configurationEvidence, so there is no old `requiredBuyerVisibleConditions` array requiring retention here. If that ever changes, the unchanged production guard fails rather than silently dropping required conditions.

## Equipment projection order

The unchanged evidence-consumer pipeline is:

1. `sourceEffectiveFeatures` / `effectiveFeaturesFromRows`, with original historical variant context
2. `applyFeatureRegrading`
3. `applyBrandFeatureUpdates` for a buyerGradesRequired car
4. `applyBrandTermFeatures`

The last helper projects exactly two equipment criteria: `driveaway_price` and `roadside_assistance`. It does not project `warranty`, `battery_warranty`, `warranty_years`, `warranty_km`, `battery_warranty_years`, `battery_warranty_km` or `battery_retention_pct`. It returns equipment rows; it does not rewrite `car.facts` or buyerSummary.

A roadside projection is admitted only when the current car's roadside fact has a gradeReview with `evidenceScope: brand_au_terms` and is not marked review_required. The seven retained actual null roadside facts do not have that newly reviewed status. The actual before `roadside_assistance` and `warranty_service` feature rows are all unverified, with generic exact-trim equipment-pending text; none carries a GLB warranty omission. `warranty_service` is servicing-only in the source criteria preparation, not a competing warranty-coverage field.

## Required guards in the later bounded staging manifest

Use the existing pinned recursive complete-car reader, actual core production functions, shared digestRows helper and complete-feature consumer approach. Do not introduce another per-brand proof implementation.

- Freeze the exact 19-packet registered prefix and accepted 405-car / 27,945-feature state. The candidate is the twentieth packet only in explicit hypothetical composition until registration is separately authorized
- Pin the current production entry points through the accepted source inventory, and keep normal/default catalogue loading callbacks throwing
- Bind each replacement Fact's complete before object to the accepted extraction, and require actual application to accept all original guards
- Assert zero Mercedes brandTerms, versionUpdates and configurationUpdates unless a later explicitly reviewed amendment adds them
- Preserve the exact existing seven manufacturer_model_code fact objects, including value, date, sourceIds, qualifications, full JSON bytes and digest. Retain them as historical research, not new exact-current capture proof
- Preserve the exact existing seven roadside_assistance fact objects, with full unchanged JSON bytes/digests and original dates. No fresh roadside research is implied
- Do not delete, trim or normalize retained fact objects. The auxiliary amendment replaces only its explicitly reviewed keys
- After actual application, compare all new warranty/core/charge auxiliary facts to the packet's exact `after` objects, including full qualifications, units, basis and grades
- Compare all 11 new summary clause labels/text and conditions with the authored packet, and rely on unchanged production complete Fact dependency validation. Old summary conditions must not be appended
- Recheck complete output cars after pack/feature/report consumers, using the existing full-car digests. Consumers must not mutate updated facts or summaries
- Preserve all 398 unselected complete cars/features, explicitly including cargo eVito, and add only the four reviewed new identities
- Resolve every retained capture through the reviewed source-capture manifest's exact locator-to-path mapping and allowed roots. XPENG's old single `xpengResearch` prefix cannot resolve the separately retained warranty root; do not widen to arbitrary `/tmp` or reconstruct/copy sources without reviewed provenance
- Keep the declared before-feature JSON omission policy/audit exactly. Never broaden it into generic removal of undefined values or fields
- Do not let final report rendering imply that retained dated model-code/roadside research was freshly verified, that City charge durations have a valid charge window, or that GLC is on sale

These are requirements for the next independently reviewed execution manifest, not a claim that any downstream guard has run or passed.

## Warranty representation check

Production Fact.value accepts strings as well as numbers. A reviewed `warranty_km` value `Unlimited` with unit `km`, private-use scope/qualifications and empty comparison displays as `Unlimited km`. It creates no numeric kilometre limit and is excluded by finite-numeric ranking requirements. Null would continue displaying Needs confirmation; zero and Infinity are not substitutes for unlimited.

The actual existing retention key is `battery_retention_pct`. Replacing only a nonexistent `battery_warranty_retention_pct` would leave the old displayed fact untouched. `Detail` renders all existing facts, so the old GLB null auxiliary fields and old `% SoH` units require explicit reviewed replacements if they conflict with the newly accepted current certificate. No automatic text-to-numeric synchronization exists.
