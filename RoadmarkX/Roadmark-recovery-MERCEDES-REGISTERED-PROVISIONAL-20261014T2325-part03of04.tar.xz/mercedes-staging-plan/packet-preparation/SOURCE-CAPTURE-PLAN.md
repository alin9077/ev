# Small source-capture manifest plan

Prepared only from frozen reviewed normalized V2 metadata. No public page was fetched, browser opened, source file scanned, capture copied or old missing original reconstructed.

The draft inventory is `source-capture-manifest-template-v1.json`. It has 39 support-capture rows with 29,842,473 declared bytes (metadata sum, not measured drift verification). The 21 audit-only keys are listed separately. All 60 original source records remain in the frozen normalized artifact and eventual separate provenance audit.

## Promotion requirements

1. Keep exact normalized V2 SHA256 `3ab4076acb02eb2a02fe33af06ddb934640b6f69ff8b757652afb2572c9a453d`
2. An independent assembly reviewer checks the 39-key support selection against every fact, availability row and any future explicit term. AncillarySourceKeys never enter this set automatically
3. Preserve each original source_type. Historical audit and retrieval_failure are forbidden packet support. Government and secondary sources may support Reported, never become maker sources
4. Review each capture identity `(sourceKey, normalizedField, originalPath)`, exact path, expected bytes/hash and stable locator. The template has one primary `file` per support source because that is the reviewed V2 shape; do not omit any future supplementary/text capture
5. Pin the frozen accepted capture manifest itself in the assembly manifest. The independent assembly review binds its hash. Existing content review does not claim a 60-source rehash
6. Root separately authorizes the bounded capture verification/assembly run. The proposed assembler checks these 39 exact named files, not a filesystem traversal or broad research scan. It checks them again before output
7. Any mismatch is a stop. Keep the failed attempt and old pins. A fresh capture requires a new normalization/capture manifest review. Do not update expected hashes to whatever bytes happen to be on disk

## Row contract

Each row contains `sourceKey`, `normalizedField`, `originalPath`, `path`, `sha256`, `bytes` and `locator`. `path` is the retained byte input. `originalPath` identifies the exact path recorded by normalized research. Locators use stable descriptive prefixes such as `mercedes-research/technical/...` or `mercedes-review/warranty/...`.

The accepted capture manifest is an object with `schemaVersion: 1`, exact `normalizedEvidenceSha256`, and `captures: [...]`. Its draft status is explicitly unreviewed metadata only. The source bytes/hash must also equal any normalized source-row hash/byte fields.

An exact-byte copy is unnecessary for current warranty files. If a later handover requires one, add `copyProvenance: {method: "exact-byte-copy", original: {path, sha256, bytes}}`; original and destination hashes/bytes must be identical and both paths must verify within allowed capture roots. Preserve the original capture and copy provenance. This is no route to reconstructing the unavailable 10 October raw snapshots.

## Current warranty inputs

- Passenger warranty PDF: `/tmp/mercedes-review/warranty/statement-2026-10-09.pdf`, declared 185,008 bytes, SHA256 `e11aa887249f9969deebaef60023363e8297fe7c3db9dda0a982f9d6db1088d3`
- Vans warranty HTML: `/tmp/mercedes-review/warranty/vans-warranty.html`, declared 385,019 bytes, SHA256 `0c13d8ac7dab8497f2987ad2ad384568a660a1984bf11579427250ba6830e9c5`

These are provenance supplied by the research candidate and content reviewer. This preparation did not independently hash those captures. The manifest allows their existing root explicitly.

## Audit retention

The historical GLB audit remains `historical_audit_record`; it is omitted from packet.sources and gradeReview.sourceIds. Its original metadata and ancillary references stay in the provenance audit. Failed captures, rejected price leads, EQV research, government evidence not cited directly, broker pages and unused campaign pages likewise remain auditable without claiming packet support.

The provenance audit says audit-only raw files were not rehashed by assembly. It contains the complete frozen normalized JSON and excluded source rows so no alternative value, source limitation, conflict, coverage gap or census caveat is silently discarded.
