# Mercedes consumer preparation v3

Static adaptation only. None of these modules has been imported, parsed by a runtime, executed, compiled or tested. No repository or frozen input was edited. Root owns the sole measured execution slot. This directory does not authorize a run.

## Reuse and the one original packet

The five retained XPENG consumer-v1 modules remain unchanged at /tmp/xpeng-staging-plan/consumer-v1. Their complete recursive car visitor, actual production pack/citation/portable calls, frozen isolated negative cases, full per-car feature descriptors, serial range terminal proofs, exact-byte concatenation and unchanged public report loader/builder are retained here. Brand, IDs, expected counts and reviewed input/output references are supplied by a manifest. The transparent original-to-adapter diff is adaptation.patch.

There is no second core invocation. Root's later instruction supersedes the earlier final-core prerequisite: consumers read the original canonical invocation, its accepted meta/storage/selected-car/new-feature/audit artifacts, and the same original empty-feature packet. The original canonical receipt truthfully retains captured_once_pending_independent_review and canonicalCompared=false. A separately pinned accepted_original_brand_canonical_baseline review is required. No fake final-core receipt or renamed packet is manufactured.

The canonical manifest is the actual shape-first-v3 invocation, SHA256 9b9b812ee78ec0abff67b41529b226e358b4dee00eba170928d0e64620596282. Its complete inherited input pin set is retained, including all source inventory pins and the accepted nested derived baseline. Storage is derived 405 -> 409 cars, not a fresh full-value default-loader export. The original packet SHA256 is a2b0859623539166e51fd1808e7cd4fbeb7314ae7dd91a11334cf66e057265f4. Accepted canonical output does not itself prove final selected packs, all features, negatives or reports.

## Expected scope

- Complete original baseline: 405 cars, 27,945 full feature rows and all fourteen Research fields
- Selected boundary: seven existing complete cars, 483 original features and 245 original Fact objects; four new exact identities and 276 separately captured original new features
- Candidate: eleven selected cars, 258 fact updates, 39 direct support sources, zero explicit equipment updates and seven full-before-guarded drive-only metadata updates
- Complete candidate: 409 cars, 28,221 features, 398 unselected complete car/feature sets exactly unchanged, including Tier 2 cargo eVito and all Tesla Model Y records
- All original research/source bytes and Model Y hero/nine-selling-point files remain protected by complete current source inventory pins

No missing output hash is predicted. A common manifest template contains actual retained input references and null future review/output pins. Per-phase frozen manifests must be standalone complete objects with every nested dependency pinned; the template is not an inheritance interpreter.

## Input boundary and serialization

open-consumer-inputs.mjs reuses the XPENG boundary structure and the original recursive visitor. It rejects a template status, verifies exact manifest/review hashes, checks independent review scope, and requires every reachable artifact to exist in the unique input pin map. It checks all full canonical raw/composed field descriptors, the 19-packet registered prefix, complete original/selected car equality, baseline acceptance and feature descriptors, source inventory membership and pins before and after.

feature-json-parity.mjs reuses the canonical JSON shape guard unchanged. Shape validation precedes structuredClone, matching the accepted shape-first-v3 correction. Its small comparison adapter permits only own enumerable undefined confirmation_needed at the selected novated_fbt row, on a comparison clone. It rejects proxies/accessors/symbols/sparse arrays/extra array properties/nonplain objects/nonfinite values/-0/cycles and every other undefined location. It compares the complete serialized array and JSONL digest and leaves live rows untouched.

Existing and new audits are separate. The existing-seven replay must match the original accepted per-car omission observations. The new-four replay must match the independently accepted canonical observations. The four observed new row-49 omissions are recorded by the actual canonical audit; they were never predicted by this preparation. The helper accommodates the two audits' named absent-property evidence fields without broadening allowed locations or changing live values.

## Selected actual consumers

Original existing features are replayed under the complete original 405-car/fourteen-field snapshot, then those fields are released. New original canonical features are replayed under the unchanged complete candidate snapshot. These are not interchangeable propositions.

For every selected car, the actual pack equals sourceEffectiveFeatures -> applyFeatureRegrading -> applyBrandFeatureUpdates with all 19 registered packets plus the candidate -> applyBrandTermFeatures. The empty feature packet cannot add replacements. Only driveaway_price and roadside_assistance may differ at the shared-term projection step. Every feature and reviewed fact citation is checked, source records resolve exactly, and complete portable store/hydrate equality is required.

All candidate Fact objects, auxiliary warranty/charging facts, sources, dates, bases, grades, conditions, cohort qualifications and exact summary dependencies remain equal to the packet. Summaries replace old conditions rather than merge them. Historical manufacturer_model_code and roadside_assistance Facts remain exact for all seven existing cars. Car/Variant drive matches its unchanged graded Fact; picker/filter projection is checked without upgrading that grade.

The selected receipt deliberately labels its 187 displayed Fact slots as non-coverage. Numeric presence is not strict 10–80 coverage. It never copies XPENG's 186-filled assertion or asserts Mercedes C3 passed.

## Negative guards and retained fixture semantics

Applicable actual-candidate cases preserve immutable positive controls, complete frozen original inputs, isolated copies, exact production error messages, no fallback loader and unchanged-input checks. They cover source/capture drift, missing/duplicate sources, full Fact before drift, version identity, metadata before drift, genuine secondary/foreign-source promotion, synthetic DE-origin promotion, an isolated opposite-basis insertion into an actual Reported blank-basis price, exact summary dependency/schema rejection, actual numeric summary-amount dependency drift, wrong brand/tier, invalid/future Fact dates and stale numeric ranking exclusion with the value retained.

All accepted prices are Reported and keep blank comparisonBasis. The negative proof does not manufacture comparable positive prices. No accepted summary depends on price; its actual numeric amount-dependency proof uses a real non-price dependency and records that price-specific coverage is absent. The actual Mercedes packet has zero features. Original feature before/dependency/schema/cardinality/duplicate/numeric-V2L fixture cases remain visibly preserved in the adapted file inside the empty-feature branch. They are not run or claimed as Mercedes candidate mutations. Their existing accepted XPENG output is pinned separately; seven relevant current guard/consumer/price source pins must equal those of that historical proof. If any implementation differs, this reuse fails closed and requires a new exact fixture decision. No fake equipment update is added merely to manufacture a candidate target. Candidate-only feature categories are explicitly inapplicable, with the reason recorded; missing applicable cases remain fatal unsupportedCategories. The actual candidate exercises only the basisTag contradiction branch; originalBasis branch coverage remains historical, with price-ladder.ts unchanged. Price and numeric-summary targets are explicit manifest selectors.

## Full feature ranges and aggregate

The proposed eight serial ranges are [0,52), [52,104), [104,156), [156,208), [208,260), [260,312), [312,364), [364,409). Each range verifies every complete 409-car descriptor in order and all fourteen fields, and invokes the actual production feature consumer for every car in its range. All 69 criteria, source membership, complete selected pack equality and unchanged unselected feature descriptors are checked.

Every range needs an exact frozen manifest/review plus measured stdout/stderr/terminal. Aggregation requires all successful terminals, exact commands, no signal/timeout, serial non-overlap, full unique ordinal/car/criterion coverage and matching complete descriptor lists. It rechecks every parsed row and concatenates the original bytes without reserialization. Only all 409 cars/28,221 rows together produce the complete-feature receipt. Partial or failed results are never promoted.

## Complete actual reporting

The unchanged actual report loader receives the complete explicit 409-car snapshot and fourteen Research fields; its feature callback supplies the already proved complete 28,221-row stream and rechecks every full car/feature descriptor. The unchanged public builder receives the complete loader input plus only the separately reviewed Mercedes reconciliation overlay at 2026-10-15. Every input field is digested before/after. Full JSON and detailed text are preserved without filtering, normalization, sorting or count-only comparisons.

Per-car public-builder diagnostics use unchanged actual cars. Provisional GLC stays outside the denominator; there is no availability override. Every aggregate brand field is compared with the actual on-sale per-car diagnostics. City 35/32-minute Reported durations remain visible; the strict core fields stay missing and absent from charging rankings. If the existing reporter calls that strict absent-window cell Unreviewed, its exact result is preserved and the limitation is recorded rather than relabelling the fact or changing reporter code.

Fresh normal registered CLI equality remains a later root-owned gate: entire original JSON and exact bytes must match, not just metrics. Current-version reviews stay empty, C1/research closure stay open, and no broader C1–C5 or M1 completion is invented.

## Execution boundary

The common measured runner is /tmp/mercedes-staging-plan/measured-command.py, SHA256 a2c4a8dffacfc8eeec29062f5b1a8e18176cd7d6949c5075f221112984bf511b. Each proposed command is 180 seconds with Node 448 MiB old heap, 1 MiB semi-space, expose-gc and tsx; NODE_OPTIONS must be absent. No /usr/bin/time, concurrent heavy work, automatic retry, changed compiler scope or default loader.

Root authorized one bounded serial batch only after exact independent acceptance. Each receipt-dependent manifest/review must be frozen within that approved scope. Stop on any failed or incomplete measured command, preserve its outputs and get a separately reviewed correction/retry grant. These static templates neither grant that slot nor attest execution.


## V2 correction record

V1 remained unexecuted after independent static review found three authoring defects: e.newCars9 instead of e.criteria at three positive-control assertions, a positive comparable-price assumption incompatible with the actual Reported blank-basis prices, and an assumed price-summary dependency absent from the accepted packet. V2 fixes only those proof defects, versioned harness/command paths and an obsolete literal in a diagnostic string. Original candidate/baseline/source bytes and all guard functions remain untouched. See V2-CORRECTIONS.md and parameter-audit-v2.json.


## V3 written portable transport check

V2 remains unchanged and unexecuted. V3 adds a read-back of the actual written portable-packs.json and staged-packs.json, verifies their output hashes, hydrates the written portable values through the unchanged production function and compares the complete result to the written expected packs. Every non-feature pack field is additionally compared directly with its live value after the same existing JSON shape guard rejects every undefined/non-JSON value outside features. Each live feature set is compared with the transported set under its already accepted existing-seven/new-four per-car omission audit. The allowed property set is unchanged. Complete live packs and input/source pins are checked again. The receipt separately states inMemoryPortableExact and serializedPortableExact and links serialized-portable-roundtrip-audit.json. Downstream negative/range gates now require serializedPortableExact. Only the shape guard export, selected proof, that selected-receipt gate, versioned self/aggregate paths and this documentation change; no normalization layer or broader omission policy is introduced.
# V4 exact availability-label source transition

This version retains the original accepted canonical capture and the held selected-v3 output. The only live-source changes admitted are src/lib/config.ts and tests/device-issue-drafts.test.ts, as independently accepted in availability-label-v1-output-acceptance.json. Historical canonical/source-inventory pins are unchanged and the two old files resolve only against their preserved, exact before witnesses. Current live files must match the two reviewed after pins. Every other inherited pin and the complete source path set remain exact. The extra availabilityLabelFix anchor is fixed to /tmp/roadmark-availability-label-fix. There is no general pin-remapping policy.

The boundary checks the actual one-string config change, original test-file prefix, accepted focused test/lint receipt, identical old/current source path sets and exact per-file inventory difference. Every phase review must independently bind this exact transition. Every new consumer receipt carries it, and dependent phases require the identical transition. Historical canonical metadata remains a dated observation rather than being relabelled as a fresh live-source capture.

The new selected proof replays unchanged complete cars, all14 research fields and original existing/new features. It compares actual written pack, feature, portable and original-feature-replay artifacts byte-for-byte to selected-v3. Ten actual current_or_order_listed observations may change only availabilityClaim.value from the exact old prefix Current manufacturer listing to Current listing, and the single matching value segment in availabilityClaim.sentence. All other fields, including sources, dates, availability states, qualifications and City caveats, remain exact. GLC is unchanged. The serialized-portable audit permits only its new output-file references; all audit values remain exact. The old output is explicitly content-held, never used as an accepted predecessor for negative/range/report phases.

V3 remains immutable. No second canonical capture, evidence/packet rewrite, broader source change or execution is authorized by these static files. New exact phase review and root grant remain required. The earlier design is inherited context; this section governs the precise two-file source transition and versioned output lineage.

## V5 observation persistence-boundary correction

V4 failed after writing its six comparison artifacts because a live citation object was compared directly with historical JSON: production citations deliberately retain own undefined checked/limitation fields that JSON omits. The failed attempt and all partial files remain immutable. V5 compares the exact hash-checked newly written buyer-observations.json to the historical written observations, retaining the same ten value/sentence label replacements and unchanged GLC. It separately compares each complete raw source record and the actual production factClaim source projection from retained byte-identical packs to the live claim sources, including all own undefined properties. A full live-observation clone proves this comparison does not mutate them. No live citation is JSON-normalized; no new allowed-undefined or source serialization policy is introduced. The source transition, four byte-exact artifacts, portable proof, original canonical and all other checks remain unchanged. This new static cut requires exact review and root grant before execution.
