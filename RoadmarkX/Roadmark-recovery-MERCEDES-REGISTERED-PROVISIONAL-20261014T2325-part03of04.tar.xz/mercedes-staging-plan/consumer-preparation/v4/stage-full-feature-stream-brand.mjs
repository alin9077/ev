/** Bounded serial ordinal ranges and exact raw-byte aggregate, adapted from Subaru ranges-v3. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {digestRows,fileHash,referenceFor,locate,streamRows} from '/tmp/xpeng-staging-plan/baseline-io.mjs';
import {openConsumerInputs,visitCompleteCars,actualConsumers} from './open-consumer-inputs.mjs';
import {compareFeatureSerialization} from './feature-json-parity.mjs';
const proof=openConsumerInputs('features'),{manifest,index,selected,e}=proof,out=proof.createOutput();
assert(['range','aggregate'].includes(manifest.featureMode));proof.assertPinned(manifest.measuredWrapper);assert.equal(manifest.measuredWrapper.anchor,'mercedesPlan');assert.equal(manifest.measuredWrapper.file,'measured-command.py');assert.deepEqual(process.execArgv,manifest.execution.execArgv);assert.equal(process.env.NODE_OPTIONS,undefined);
assert(Number.isSafeInteger(manifest.execution.timeoutSeconds)&&manifest.execution.timeoutSeconds>0);
const plan=manifest.rangePlan;assert(Array.isArray(plan)&&plan.length>0&&plan.length<=e.afterCars);let end=0;
for(const [ordinal,range]of plan.entries()){assert.deepEqual(Object.keys(range).sort(),['end','ordinal','start']);assert.equal(range.ordinal,ordinal);assert.equal(range.start,end);assert(Number.isSafeInteger(range.end)&&range.end>range.start&&range.end<=e.afterCars);end=range.end;}assert.equal(end,e.afterCars);
const selectedReceipt=proof.readPhaseReceipt(manifest.selectedConsumerReceipt,'passed_selected_brand_consumers_pending_remaining_gates');
for(const key of ['allCompleteCarsVerified','all14ResearchFieldsUnchanged','allSelectedCarsAndPacketUnchanged','actualPackPipelineMatches','actualPortableExact','serializedPortableExact','allOriginalCanonicalFeatureRowsEqual'])assert.equal(selectedReceipt[key],true);
const packs=proof.read(selectedReceipt.packFile);assert.deepEqual(Object.keys(packs),selected.map(car=>car.id));
const data=await proof.readData(),sourceIds=new Set(data.sources.map(row=>row.id));assert.equal(sourceIds.size,data.sources.length);
const criteria=[...data.criteria.map(row=>row.key)].sort();assert.equal(new Set(criteria).size,e.criteria);
const baseById=new Map(proof.baselineFeatureIndex.perCar.map(row=>[row.id,row]));assert.equal(baseById.size,e.beforeCars);
const inspectedCars=[];let api;
function verifyFeatures(id,features){
  assert.equal(features.length,e.criteria);assert.equal(new Set(features.map(row=>row.criterion)).size,e.criteria);assert(features.every(row=>row.variant_id===id));assert.deepEqual([...features.map(row=>row.criterion)].sort(),criteria);
  for(const feature of features)for(const sourceId of feature.source_ids)assert(sourceIds.has(sourceId),'Every full feature source exists');
  const digest=digestRows(features);
  if(Object.hasOwn(packs,id)){
    const existing=proof.coreManifest.existingIds.includes(id),policy=existing?proof.coreManifest.existingFeatureParity:proof.coreManifest.canonicalJsonParity,audit=existing?proof.beforeFeatureParityAudit:proof.canonicalJsonAudit;
    if(manifest.featureMode==='range')compareFeatureSerialization(features,packs[id].features,policy,id,audit.observed.find(row=>row.variantId===id));
    else assert.deepEqual(features,packs[id].features,'Full parsed aggregate rows equal the accepted complete pack rows');
  }
  else{const old=baseById.get(id);assert(old);assert.equal(digest.sha256,old.featureSha256,'Complete accepted-before other-brand feature equality: '+id);assert.equal(digest.bytes,old.featureBytes);assert.equal(digest.rows,old.featureRows);}
  return digest;
}
function inspect(car,ordinal){const d=digestRows([car]);assert.equal(ordinal,inspectedCars.length);inspectedCars.push({ordinal,id:car.id,carSha256:d.sha256,carBytes:d.bytes});if(Object.hasOwn(packs,car.id))assert.deepEqual(car,packs[car.id].car);return d;}
const output=path.join(out,'all-features.jsonl'),perCar=[];let count=0,bytes=0,matchedOther=0,matchedSelected=0,sha256;
function appendProof(row){assert.equal(row.ordinal,perCar.length+(manifest.featureMode==='range'?plan[manifest.rangeOrdinal].start:0));assert.equal(row.id,index.cars.carHashes[row.ordinal].id);perCar.push(row);if(Object.hasOwn(packs,row.id))matchedSelected++;else matchedOther++;}
let rangeEvidence=[];
if(manifest.featureMode==='range'){
  assert(Number.isSafeInteger(manifest.rangeOrdinal)&&manifest.rangeOrdinal>=0&&manifest.rangeOrdinal<plan.length);assert(!Object.hasOwn(manifest,'ranges'));
  const range=plan[manifest.rangeOrdinal];api=actualConsumers(proof);global.gc();
  const fd=fs.openSync(output,'wx'),aggregate=crypto.createHash('sha256');
  try{await visitCompleteCars(proof,(car,ordinal)=>{
    const before=inspect(car,ordinal);if(ordinal<range.start||ordinal>=range.end)return;
    // Never substitute pack/canonical rows for the actual function invocation.
    const features=api.staged.effectiveFeatures(car,data),digest=verifyFeatures(car.id,features);
    for(const feature of features){const row=Buffer.from(JSON.stringify(feature)+'\n','utf8');let offset=0;while(offset<row.length){const written=fs.writeSync(fd,row,offset,row.length-offset);assert(written>0);offset+=written;}aggregate.update(row);bytes+=row.length;count++;}
    assert.deepEqual(digestRows([car]),before);appendProof({ordinal,id:car.id,carSha256:before.sha256,carBytes:before.bytes,featureRows:digest.rows,featureBytes:digest.bytes,featureSha256:digest.sha256});
    if(perCar.length%25===0){global.gc();console.log('Complete actual brand-stage feature sets in range',range.ordinal,perCar.length,process.memoryUsage());}
  });}finally{fs.closeSync(fd);}
  assert.equal(inspectedCars.length,e.afterCars);assert.equal(perCar.length,range.end-range.start);assert.equal(count,perCar.length*e.criteria);assert.equal(matchedOther+matchedSelected,perCar.length);
  assert.deepEqual(perCar.map(row=>row.id),index.cars.carHashes.slice(range.start,range.end).map(row=>row.id));sha256=aggregate.digest('hex');
  assert.equal(fileHash(output),sha256);assert.equal(fs.statSync(output).size,bytes);api.verify();proof.verifyData(data);proof.verify();
  const features={...referenceFor(proof.anchors,output),rows:count,bytes,sha256};
  const rangeIndex=proof.write(out,'feature-range-index.json',{schemaVersion:1,...proof.receiptBase(),mode:'Fresh actual complete feature invocations for one immutable ordinal range',range,rangePlan:plan,features,cars:perCar.length,perCar,inspectedCars,selectedMatched:matchedSelected,otherCarsExactlyUnchanged:matchedOther,selectedConsumerReceipt:manifest.selectedConsumerReceipt,baselineFeatureIndex:proof.coreManifest.baselineFeatureIndex});
  proof.write(out,'feature-range-receipt.json',{...proof.receiptBase(),status:'passed_brand_feature_range_pending_measured_terminal_and_aggregate',range,rangePlan:plan,cars:perCar.length,featureRows:count,actualConsumerInvocations:perCar.length,allCompleteCarHashesVerified:true,all14ResearchFieldsUnchanged:true,packetAndSelectedCarsUnchanged:true,allProducedActualFeatureSetsCompared:true,strictCompleteOrderAndUniqueness:true,defaultLoaderCalls:api.loaderCalls(),index:rangeIndex,selectedConsumerReceiptSha256:manifest.selectedConsumerReceipt.sha256,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
  console.log('Actual brand feature range passed; measured terminal and complete aggregate remain pending',range.ordinal);
}else{
  assert(!Object.hasOwn(manifest,'rangeOrdinal'));assert.equal(manifest.ranges.length,plan.length);
  await visitCompleteCars(proof,(car,ordinal)=>{inspect(car,ordinal);});assert.equal(inspectedCars.length,e.afterCars);
  const seen=new Set(),allRangePins=new Set();let previousCompleted=-Infinity;
  for(const [ordinal,entry]of manifest.ranges.entries()){
    assert.equal(entry.ordinal,ordinal);const range=plan[ordinal];
    for(const key of ['manifest','review','receipt','terminal','stdout','stderr']){proof.assertPinned(entry[key]);const file=locate(proof.anchors,entry[key]);assert(!allRangePins.has(file),'No reused range evidence');allRangePins.add(file);}
    const rm=proof.read(entry.manifest),review=proof.read(entry.review),receipt=proof.readPhaseReceipt(entry.receipt,'passed_brand_feature_range_pending_measured_terminal_and_aggregate'),terminal=proof.read(entry.terminal);
    assert.equal(rm.mode,'reviewed-brand-consumers-v1');assert.equal(rm.phase,'features');assert.equal(rm.featureMode,'range');assert.equal(rm.rangeOrdinal,ordinal);assert.deepEqual(rm.rangePlan,plan);assert.deepEqual(rm.anchors,proof.anchors);
    assert.deepEqual(rm.measuredWrapper,manifest.measuredWrapper);assert.equal(rm.nodeVersion,manifest.nodeVersion);assert.equal(rm.asOf,manifest.asOf);assert.equal(rm.packetId,manifest.packetId);assert.deepEqual(rm.harnessPins,manifest.harnessPins);
    for(const key of ['coreManifest','coreReview','coreReceipt','selectedConsumerReceipt'])assert.deepEqual(rm[key],manifest[key]);for(const ref of rm.inputPins)proof.assertPinned(ref);
    assert.equal(review.status,'approved_for_features_brand_consumers_v1');assert.equal(review.phase,'features');assert.equal(review.featureMode,'range');assert.equal(review.manifestSha256,entry.manifest.sha256);assert.deepEqual(review.harnessPins,manifest.harnessPins);assert.equal(review.coreReceiptSha256,proof.receiptHash);assert.equal(review.canonicalCaptureAuthorized,false);assert.equal(review.productionRegistrationAuthorized,false);
    assert.equal(receipt.phaseManifestSha256,entry.manifest.sha256);assert.equal(receipt.phaseReviewSha256,entry.review.sha256);assert.deepEqual(receipt.fullInputPins,rm.inputPins);assert.deepEqual(receipt.range,range);assert.deepEqual(receipt.rangePlan,plan);assert.equal(receipt.cars,range.end-range.start);assert.equal(receipt.featureRows,receipt.cars*e.criteria);assert.equal(receipt.actualConsumerInvocations,receipt.cars);assert.equal(receipt.defaultLoaderCalls,0);
    for(const key of ['allCompleteCarHashesVerified','all14ResearchFieldsUnchanged','packetAndSelectedCarsUnchanged','allProducedActualFeatureSetsCompared','strictCompleteOrderAndUniqueness'])assert.equal(receipt[key],true);
    const script=path.join(proof.anchors.consumerPreparation,'v4/stage-full-feature-stream-brand.mjs');
    const expectedCommand=['/usr/bin/timeout','--signal=TERM','--kill-after=10s',String(rm.execution.timeoutSeconds)+'s','node',...rm.execution.execArgv,script,'--manifest',locate(proof.anchors,entry.manifest),'--manifest-sha256',entry.manifest.sha256,'--review',locate(proof.anchors,entry.review),'--review-sha256',entry.review.sha256];
    assert.equal(terminal.returncode,0);assert.equal(terminal.signal,null);assert.equal(terminal.timeoutReported,false);assert.equal(terminal.receiptWrittenAfterExit,true);assert.equal(terminal.newProcessGroup,true);assert.equal(terminal.cwd,proof.anchors.repo);assert.equal(terminal.timeoutSeconds,rm.execution.timeoutSeconds);assert.deepEqual(terminal.command,expectedCommand);
    assert(Number.isFinite(terminal.elapsedSeconds)&&terminal.elapsedSeconds>=0);assert(Number.isFinite(terminal.maxRssKiB)&&terminal.maxRssKiB>0);const started=Date.parse(terminal.startedAt),completed=Date.parse(terminal.completedAt);assert(Number.isFinite(started)&&Number.isFinite(completed)&&completed>=started);assert(started>=previousCompleted,'Ranges must have completed serially in exact plan order');previousCompleted=completed;
    const terminalDirectory=path.dirname(locate(proof.anchors,entry.terminal));assert.equal(locate(proof.anchors,entry.stdout),path.join(terminalDirectory,'stdout.log'));assert.equal(locate(proof.anchors,entry.stderr),path.join(terminalDirectory,'stderr.log'));
    for(const ref of [receipt.index]){const file=locate(proof.anchors,ref);assert(!allRangePins.has(file));allRangePins.add(file);}
    const ri=proof.read(receipt.index);assert.equal(ri.schemaVersion,1);assert.deepEqual(ri.range,range);assert.deepEqual(ri.rangePlan,plan);assert.deepEqual(ri.inspectedCars,inspectedCars);assert.equal(ri.phaseManifestSha256,entry.manifest.sha256);assert.equal(ri.phaseReviewSha256,entry.review.sha256);assert.equal(ri.packetSha256,proof.coreManifest.packet.sha256);assert.equal(ri.coreReceiptSha256,proof.receiptHash);assert.deepEqual(ri.fullInputPins,rm.inputPins);assert.equal(ri.cars,range.end-range.start);assert.equal(ri.perCar.length,ri.cars);assert.equal(ri.features.rows,ri.cars*e.criteria);proof.assertPinned(ri.features);const rangeOutput=locate(proof.anchors,ri.features);assert(!allRangePins.has(rangeOutput));allRangePins.add(rangeOutput);
    assert.deepEqual(ri.perCar.map(row=>row.id),index.cars.carHashes.slice(range.start,range.end).map(row=>row.id));assert.deepEqual(ri.perCar.map(row=>row.ordinal),Array.from({length:ri.cars},(_,i)=>range.start+i));
    let rows=[],localCars=0,localSelected=0,localOther=0;
    await streamRows(proof.anchors,ri.features,(feature,rowOrdinal)=>{
      const expected=ri.perCar[Math.floor(rowOrdinal/e.criteria)];assert(expected);assert.equal(feature.variant_id,expected.id);rows.push(feature);
      if(rows.length===e.criteria){assert.equal(expected.ordinal,range.start+localCars);assert(!seen.has(expected.id));seen.add(expected.id);const car=inspectedCars[expected.ordinal];assert.equal(expected.id,car.id);assert.equal(expected.carSha256,car.carSha256);assert.equal(expected.carBytes,car.carBytes);
        const digest=verifyFeatures(expected.id,rows);assert.deepEqual(digest,{rows:expected.featureRows,bytes:expected.featureBytes,sha256:expected.featureSha256});appendProof(expected);if(Object.hasOwn(packs,expected.id))localSelected++;else localOther++;rows=[];localCars++;}
    });
    assert.equal(rows.length,0);assert.equal(localCars,ri.cars);assert.equal(localSelected,ri.selectedMatched);assert.equal(localOther,ri.otherCarsExactlyUnchanged);count+=ri.features.rows;bytes+=ri.features.bytes;rangeEvidence.push({...entry,range,index:receipt.index,features:ri.features});global.gc();
  }
  assert.equal(perCar.length,e.afterCars);assert.equal(seen.size,e.afterCars);assert.equal(count,e.afterFeatureRows);assert.equal(matchedSelected,e.selectedCars);assert.equal(matchedOther,e.unselectedCars);assert.deepEqual(perCar.map(row=>row.id),index.cars.carHashes.map(row=>row.id));
  const fd=fs.openSync(output,'wx'),aggregate=crypto.createHash('sha256');let copied=0;
  try{for(const entry of rangeEvidence)for await(const row of fs.createReadStream(locate(proof.anchors,entry.features))){let offset=0;while(offset<row.length){const written=fs.writeSync(fd,row,offset,row.length-offset);assert(written>0);offset+=written;}aggregate.update(row);copied+=row.length;}}finally{fs.closeSync(fd);}
  sha256=aggregate.digest('hex');assert.equal(copied,bytes);assert.equal(fileHash(output),sha256);assert.equal(fs.statSync(output).size,bytes);proof.verifyData(data);proof.verify();
  const features={...referenceFor(proof.anchors,output),rows:count,bytes,sha256};
  const featureIndex=proof.write(out,'all-feature-index.json',{schemaVersion:1,...proof.receiptBase(),mode:'Complete raw-byte aggregate of separately measured actual brand feature ranges',cars:e.afterCars,features,perCar,inspectedCars,selectedMatched:e.selectedCars,otherCarsExactlyUnchanged:e.unselectedCars,baselineFeatureIndex:proof.coreManifest.baselineFeatureIndex,selectedConsumerReceipt:manifest.selectedConsumerReceipt,rangePlan:plan,rangeEvidence});
  proof.write(out,'all-feature-receipt.json',{...proof.receiptBase(),status:'passed_complete_brand_features_pending_report_and_review',cars:e.afterCars,featureRows:e.afterFeatureRows,actualConsumerInvocations:e.afterCars,allCompleteCarHashesVerified:true,all14ResearchFieldsUnchanged:true,packetAndSelectedCarsUnchanged:true,allActualPackFeaturesExactlyEqual:true,allUnselectedCarFeatureSetsExactlyUnchanged:true,strictCompleteOrderAndUniqueness:true,allMeasuredRangesExitZeroNoSignal:true,rawByteConcatenationVerified:true,defaultLoaderCalls:0,index:featureIndex,rangePlan:plan,rangeEvidence,selectedConsumerReceiptSha256:manifest.selectedConsumerReceipt.sha256,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
  console.log('Complete measured brand complete-car/full-feature raw-byte aggregate passed; report and independent acceptance remain open');
}


