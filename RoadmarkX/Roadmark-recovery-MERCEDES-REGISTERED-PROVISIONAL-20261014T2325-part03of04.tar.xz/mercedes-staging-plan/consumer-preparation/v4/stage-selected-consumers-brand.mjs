/** Actual final 11-pack/citation/portable proof, adapted from the accepted Subaru proof. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {digestRows,readResearch,assertResearchUnchanged,fileHash,locate} from '/tmp/xpeng-staging-plan/baseline-io.mjs';
import {openConsumerInputs,visitCompleteCars,actualConsumers} from './open-consumer-inputs.mjs';
import {compareFeatureSerialization,assertDeclaredJson} from './feature-json-parity.mjs';
const proof=openConsumerInputs('selected'),{packet,selected,index,e}=proof,out=proof.createOutput();
const priorDiagnostic=proof.manifest.priorSelectedDiagnostic,priorReceipt=proof.read(priorDiagnostic.receipt),priorReview=proof.read(priorDiagnostic.heldReview);
assert.equal(priorReceipt.status,'passed_selected_brand_consumers_pending_remaining_gates');assert.equal(priorReceipt.packetSha256,proof.coreManifest.packet.sha256);assert.equal(priorReceipt.coreReceiptSha256,proof.manifest.coreReceipt.sha256);assert.equal(priorReceipt.coreManifestSha256,proof.manifest.coreManifest.sha256);
assert.equal(priorReview.status,'mechanical_checks_passed_buyer_content_held_for_provenance_label_correction');
assert.equal(priorReview.dependentPhaseAcceptanceIssued,false,'The original selected output is retained as a held diagnostic, never promoted to accepted');
assert.deepEqual(priorReview.producerReceipt,{path:locate(proof.anchors,priorDiagnostic.receipt),bytes:priorDiagnostic.receipt.bytes,sha256:priorDiagnostic.receipt.sha256});
assert.equal(priorReceipt.phaseManifestSha256,priorDiagnostic.manifest.sha256);assert.equal(priorReceipt.phaseReviewSha256,priorDiagnostic.phaseReview.sha256);
assert.equal(priorReceipt.serializedPortableExact,true);assert.equal(priorReceipt.completeCarCount,e.afterCars);
const checks=proof.manifest.buyerChecks,serializationReplay=[];
let verifiedCars=0;await visitCompleteCars(proof,()=>{verifiedCars++;});assert.equal(verifiedCars,e.afterCars);
const api=actualConsumers(proof),{require}=api;
const {applyBrandFeatureUpdates,applyBrandTermFeatures}=require('./src/lib/brand-updates.ts');
const {applyFeatureRegrading}=require('./src/lib/evidence-regrading.ts');
const {storePortablePacks,hydratePortablePacks}=require('./src/lib/portable-packs.ts');
const {factClaim,featureClaim}=require('./src/lib/citable.ts');
const {coreFacts,hasValue,existingGrade,isOnSale}=require('./scripts/reporting/reports.ts');
const {buyerAvailabilityText}=require('./src/lib/buyer-availability.ts');
const {availabilityReportClaim}=require('./src/lib/availability-corrections.ts');
const {comparisonPickerCars}=require('./src/lib/picker-car.ts');
const {catalogueFilterOptions,driveFilterKey}=require('./src/lib/search.ts');
const {rankAttribute,exclusionReason}=require('./src/lib/discovery.ts');
// Replay the existing original full feature sets under the accepted complete baseline,
// then release those fields before reading the final candidate's complete Research.
const originalIndex=proof.read(proof.coreManifest.baselineStorageIndex);
for(const ref of Object.values(originalIndex.research))proof.assertPinned(ref);
let originalData=await readResearch(proof.anchors,originalIndex,proof.coreManifest.researchFields);
assert.equal(originalData.variants.length,e.beforeCars);assert.deepEqual(originalData.metadata.brand_update_packet_ids,api.brandUpdatePackets.map(row=>row.id));
for(const car of proof.before){const originalFeatures=api.base.effectiveFeatures(car,originalData);serializationReplay.push(compareFeatureSerialization(originalFeatures,proof.beforeFeatures.filter(row=>row.variant_id===car.id),proof.coreManifest.existingFeatureParity,car.id,proof.beforeFeatureParityAudit.observed.find(row=>row.variantId===car.id)));}
assertResearchUnchanged(originalData,originalIndex);originalData=null;global.gc();
const data=await proof.readData(),sourceById=new Map(data.sources.map(row=>[row.id,row]));
assert.equal(sourceById.size,data.sources.length);const packs={},policy={asOf:proof.manifest.asOf};
let citableFacts=0,citableFeatures=0,allCitableFeatureRows=0,coreCells=0,filledCoreCells=0;const gaps=[];
for(const car of selected){
  const before=digestRows([car]);
  // Existing and new originals have separate accepted snapshot and JSON-omission audits.
  if(proof.coreManifest.newIds.includes(car.id))serializationReplay.push(compareFeatureSerialization(api.base.effectiveFeatures(car,data),proof.beforeFeatures.filter(row=>row.variant_id===car.id),proof.coreManifest.canonicalJsonParity,car.id,proof.canonicalJsonAudit.observed.find(row=>row.variantId===car.id)));
  const baseFeatures=applyFeatureRegrading(car,api.base.sourceEffectiveFeatures(car,data),data.sources);
  const updatedFeatures=applyBrandFeatureUpdates(car,baseFeatures,data,[...api.brandUpdatePackets,packet]);
  assert.deepEqual(updatedFeatures,baseFeatures,'The empty equipment packet cannot introduce feature replacements');
  const expectedFeatures=applyBrandTermFeatures(car,updatedFeatures);
  for(const [ordinal,feature]of expectedFeatures.entries())if(!['driveaway_price','roadside_assistance'].includes(feature.criterion))assert.deepEqual(feature,updatedFeatures[ordinal],'Shared-term projection cannot rewrite unrelated features');
  const view=api.staged.pack(car.id,{data,cars:selected});assert.deepEqual(view.car,car);assert.deepEqual(view.features,expectedFeatures);assert.equal(view.features.length,e.criteria);assert.equal(new Set(view.features.map(row=>row.criterion)).size,e.criteria);assert(view.features.every(row=>row.variant_id===car.id));assert.deepEqual([...view.features.map(row=>row.criterion)].sort(),[...data.criteria.map(row=>row.key)].sort());packs[car.id]=view;
  for(const feature of view.features){const claim=featureClaim(view,feature.criterion,feature.criterion,proof.manifest.asOf);assert(claim);assert.deepEqual(claim.sources.map(row=>row.id),[...new Set(feature.source_ids)]);for(const citation of claim.sources){assert(sourceById.has(citation.id));assert.deepEqual(view.sources.find(row=>row.id===citation.id),sourceById.get(citation.id));}allCitableFeatureRows++;}
  for(const {key}of coreFacts){
    const fact=car.facts[key];assert(fact);assert.equal(fact.gradeReview?.overlayId,packet.id);coreCells++;
    // Displayed-fact inventory only. The actual report builder owns strict coverage semantics.
    const known=hasValue(fact.value);assert.notEqual(existingGrade(fact,known,data.sources,proof.manifest.asOf),'Unreviewed');
    if(known)filledCoreCells++;else gaps.push({carId:car.id,key,grade:fact.buyerGrade,value:fact.value});
  }
  for(const fact of Object.values(car.facts).filter(row=>row.gradeReview?.overlayId===packet.id)){
    const claim=factClaim(view,fact,proof.manifest.asOf);assert.equal(claim.buyerGrade,fact.buyerGrade);assert.deepEqual(claim.sources.map(row=>row.id),fact.sourceIds);
    for(const citation of claim.sources){const source=sourceById.get(citation.id);assert(source);for(const key of ['title','url','publisher','accessed_date','published_date','market'])assert.equal(citation[key],source[key]);assert.deepEqual(view.sources.find(row=>row.id===source.id),source);}citableFacts++;
  }
  for(const edit of packet.features.filter(row=>row.variantId===car.id)){
    const feature=view.features.find(row=>row.criterion===edit.criterion);assert.deepEqual(feature,edit.after);
    const claim=featureClaim(view,feature.criterion,feature.criterion,proof.manifest.asOf);assert(claim);assert.equal(claim.gradeReview?.overlayId,packet.id);assert.deepEqual(claim.sources.map(row=>row.id),feature.source_ids);for(const citation of claim.sources){const source=sourceById.get(citation.id);assert(source);for(const key of ['title','url','publisher','accessed_date','published_date','market'])assert.equal(citation[key],source[key]);assert.deepEqual(view.sources.find(row=>row.id===source.id),source);}citableFeatures++;
  }
  assert.equal(car.availabilityEvidence.physicalStockVerified,false);assert.equal(car.availabilityEvidence.factoryOrderAcceptanceVerified,false);assert(car.buyerSummary?.strength&&car.buyerSummary?.tradeoff);
  assert.deepEqual(digestRows([car]),before);global.gc();console.log('Exact actual brand pack',car.id);
}
assert.equal(coreCells,e.selectedCars*coreFacts.length);assert.equal(Object.keys(packs).length,e.selectedCars);
assert.equal(citableFeatures,e.authorizedFeatureMutations);assert.equal(citableFeatures,packet.features.length);assert.equal(allCitableFeatureRows,e.selectedFeatureRows);
assert.equal(serializationReplay.length,e.selectedCars);
const portable=storePortablePacks(packs);assert.deepEqual(hydratePortablePacks(portable,data.sources),packs,'Every complete portable pack roundtrips exactly');
assert.throws(()=>api.staged.pack('not-a-selected-brand-id',{data,cars:selected}),{message:'Unknown variant'});
const observations=[];
for(const car of selected){
  const view=packs[car.id],normalized=proof.normalized.variants.find(row=>row.id===car.id);assert(normalized);
  for(const edit of packet.facts.filter(row=>row.variantId===car.id)){
    assert.deepEqual(car.facts[edit.after.key],edit.after,'Full exact after Fact, including cohort/basis/grade/source/auxiliary fields');
    const claim=factClaim(view,car.facts[edit.after.key],proof.manifest.asOf);
    for(const qualification of edit.after.qualifications)assert(claim.qualifications.includes(qualification),'Buyer citation retains every qualification');
    if(['reported','check'].includes(edit.after.buyerGrade))assert.equal(claim.buyerGrade,edit.after.buyerGrade);
    if(['reported','check'].includes(edit.after.buyerGrade))assert(exclusionReason(car,edit.after,data.sources,policy),'Every candidate Reported/Check measurement keeps its reviewed ranking exclusion');
  }
  assert.equal(car.drive,car.facts.drive.value);assert.equal(data.variants.find(row=>row.id===car.id).drive,car.facts.drive.value);
  const summary=packet.summaries.find(row=>row.variantId===car.id);assert(summary);
  for(const key of ['strength','tradeoff']){assert.equal(car.buyerSummary[key].label,summary[key].label);assert.equal(car.buyerSummary[key].text,summary[key].text);for(const dep of summary[key].dependencies)assert.deepEqual(car.facts[dep.key],dep.expected);}
  assert.deepEqual(car.buyerSummary.conditions,summary.conditions??[],'No historical summary-condition merge');
  assert.equal(car.availabilityEvidence.qualifications.filter(value=>value===normalized.availability.reason).length,1);
  const availabilityClaim=factClaim(view,availabilityReportClaim(car),proof.manifest.asOf);
  assert.equal(availabilityClaim.qualifications.filter(value=>value===normalized.availability.reason).length,1,'Actual citable availability keeps the exact reason once');
  for(const condition of normalized.availability.qualifications??[])assert(car.availabilityEvidence.qualifications.includes(condition));
  for(const key of proof.coreManifest.preservedExistingFactKeys){
    const old=proof.before.find(row=>row.id===car.id);if(old)assert.deepEqual(car.facts[key],old.facts[key],'Historical complete Fact remains unchanged');
  }
  const beforeTerms=digestRows([car]),afterTerms=applyBrandTermFeatures(car,view.features);
  assert.deepEqual(afterTerms,view.features,'Repeated shared-term projection is stable');assert.deepEqual(digestRows([car]),beforeTerms);
  observations.push({id:car.id,drive:car.drive,driveGrade:car.facts.drive.buyerGrade,buyerAvailability:buyerAvailabilityText(car),availabilityQualifications:car.availabilityEvidence.qualifications,availabilityClaim});
}
const glc=packs[checks.glc].car;
assert.equal(glc.availability,'announced_provisional');assert.equal(buyerAvailabilityText(glc),'Not confirmed');assert.equal(isOnSale(glc),false);
assert(glc.availabilityEvidence.qualifications.some(value=>/Coming soon/i.test(value)));
for(const {id,duration}of checks.city){
  const car=packs[id].car,fact=car.facts.dc_charge_time_min;
  assert.equal(fact.value,duration);assert.equal(fact.buyerGrade,'reported');assert.equal(factClaim(packs[id],fact,proof.manifest.asOf).buyerGrade,'reported');
  const reason=proof.normalized.variants.find(row=>row.id===id).availability.reason;
  for(const token of ['undated','©2025','no identified vehicle','advertised availability only'])assert(reason.includes(token));
  assert.equal(car.availabilityEvidence.physicalStockVerified,false);assert.equal(car.availabilityEvidence.factoryOrderAcceptanceVerified,false);
  assert(exclusionReason(car,fact,data.sources,policy));
}
const eqa=packs[checks.eqa].car;assert.equal(eqa.facts.range_km.value,578);assert(/NEDC/i.test(eqa.facts.range_km.basis+' '+eqa.facts.range_km.comparisonBasis));assert(!/WLTP/i.test(eqa.facts.range_km.comparisonBasis));
for(const car of selected.filter(car=>car.id!==checks.tourer)){
  assert.equal(car.facts.warranty_km.value,'Unlimited');assert.equal(typeof car.facts.warranty_km.value,'string');
  assert(/Unlimited/i.test(factClaim(packs[car.id],car.facts.warranty_km,proof.manifest.asOf).value));
  assert(exclusionReason(car,car.facts.warranty_km,data.sources,policy));
}
for(const [ids,years,kilometres,metric]of [[checks.glb,8,160000,'SOCE'],[[checks.eqs],10,250000,'SOHC']])for(const id of ids){
  const car=packs[id].car;assert.equal(car.facts.battery_warranty_years.value,years);assert.equal(car.facts.battery_warranty_km.value,kilometres);assert.equal(car.facts.battery_retention_pct.value,70);assert(car.facts.battery_retention_pct.unit.includes(metric));
  assert(!/unknown|not published|needs confirmation/i.test(String(car.facts.battery_warranty.value)));
}
const tourer=packs[checks.tourer].car;
for(const [key,value]of Object.entries({warranty_years:5,warranty_km:250000,battery_warranty_years:8,battery_warranty_km:160000}))assert.equal(tourer.facts[key].value,value);
assert.equal(tourer.facts.battery_retention_pct.value,null);assert.equal(tourer.facts.battery_retention_pct.buyerGrade,'not_published');
assert(/commercial/i.test(JSON.stringify(packs[checks.g580].car.facts.battery_warranty.qualifications)));
const projected=comparisonPickerCars(selected),filters=catalogueFilterOptions(selected);
for(const [ordinal,car]of selected.entries()){assert.equal(projected[ordinal].drive,car.facts.drive.value);assert(filters.drive.includes(driveFilterKey(car.drive)));assert.equal(projected[ordinal].facts.price_aud.buyerGrade,car.facts.price_aud.buyerGrade);}
assert.equal(buyerAvailabilityText(projected.find(car=>car.id===checks.glc)),'Not confirmed');
api.verify();proof.verifyData(data);proof.verify();
const livePacksBeforeSerialization=structuredClone(packs);
const packFile=proof.write(out,'staged-packs.json',packs),features=proof.write(out,'features-after.json',Object.values(packs).flatMap(pack=>pack.features)),portableFile=proof.write(out,'portable-packs.json',portable),serializationAudit=proof.write(out,'original-feature-replay-audit.json',serializationReplay),buyerObservations=proof.write(out,'buyer-observations.json',observations);
const writtenPackPath=path.join(out,'staged-packs.json'),writtenPortablePath=path.join(out,'portable-packs.json');
assert.equal(fileHash(writtenPackPath),packFile.sha256);assert.equal(fileHash(writtenPortablePath),portableFile.sha256);
const parsedWrittenPacks=JSON.parse(fs.readFileSync(writtenPackPath,'utf8'));
const parsedWrittenPortable=JSON.parse(fs.readFileSync(writtenPortablePath,'utf8'));
const hydratedWrittenPortable=hydratePortablePacks(parsedWrittenPortable,data.sources);
assert.deepEqual(hydratedWrittenPortable,parsedWrittenPacks,'Every complete written portable pack hydrates to the complete written expected pack');
const portableSerializationAudit=[];
for(const car of selected){
  const live=packs[car.id],hydrated=hydratedWrittenPortable[car.id];assert(hydrated);
  const {features:liveFeatures,...liveOther}=live,{features:hydratedFeatures,...hydratedOther}=hydrated;
  assertDeclaredJson(liveOther,'/pack',new Set());
  assert.deepEqual(hydratedOther,liveOther,'Complete cars, sources and every non-feature pack field survive actual JSON transport without any omission');
  const existing=proof.coreManifest.existingIds.includes(car.id),policy=existing?proof.coreManifest.existingFeatureParity:proof.coreManifest.canonicalJsonParity,audit=existing?proof.beforeFeatureParityAudit:proof.canonicalJsonAudit;
  portableSerializationAudit.push(compareFeatureSerialization(liveFeatures,hydratedFeatures,policy,car.id,audit.observed.find(row=>row.variantId===car.id)));
}
assert.deepEqual(packs,livePacksBeforeSerialization,'Serialization read-back leaves every complete live pack and own feature property unchanged');
assert.equal(fileHash(writtenPackPath),packFile.sha256);assert.equal(fileHash(writtenPortablePath),portableFile.sha256);
api.verify();proof.verifyData(data);proof.verify();
const serializedPortableAudit=proof.write(out,'serialized-portable-roundtrip-audit.json',{writtenPacks:packFile,writtenPortable:portableFile,completeHydratedWrittenPacksEqual:true,allNonFeaturePackFieldsEqualLive:true,livePacksUnchanged:true,featureAudits:portableSerializationAudit});
// Compare the actual new artifacts to the held v3 artifacts. No payload is
// normalized: four outputs remain byte-exact, and the only display differences
// are the neutral prefix and its matching sentence segment on current listings.
for(const [name,current]of Object.entries({packFile,features,portableFile,serializationAudit})){
  const previous=priorReceipt[name];proof.assertPinned(previous);
  assert.equal(fileHash(locate(proof.anchors,previous)),previous.sha256);
  assert.equal(current.bytes,previous.bytes);assert.equal(current.sha256,previous.sha256,name+' must remain byte-exact across the display correction');
}
const previousObservations=proof.read(priorReceipt.buyerObservations),expectedObservations=structuredClone(previousObservations),labelChanges=[];
assert.deepEqual(previousObservations.map(row=>row.id),selected.map(car=>car.id));
for(const [ordinal,car]of selected.entries()){
  if(car.availability!=='current_or_order_listed')continue;
  const claim=expectedObservations[ordinal].availabilityClaim,oldValue=claim.value,oldPrefix='Current manufacturer listing;';
  assert(oldValue.startsWith(oldPrefix));const newValue='Current listing;'+oldValue.slice(oldPrefix.length);
  assert.equal(claim.sentence.split(oldValue).length,2,'Only one exact displayed availability value may occur in the sentence');
  claim.value=newValue;claim.sentence=claim.sentence.replace(oldValue,newValue);
  labelChanges.push({id:car.id,paths:['availabilityClaim.value','availabilityClaim.sentence'],beforeValue:oldValue,afterValue:newValue});
}
assert.equal(labelChanges.length,priorDiagnostic.expectedNeutralLabelChanges);
assert.deepEqual(observations,expectedObservations,'Every other buyer observation field, including sources, dates, qualifications and status, stays exact');
for(const {id}of checks.city){const row=observations.find(value=>value.id===id);assert(row.availabilityClaim.value.startsWith('Current listing;'));assert(!row.availabilityClaim.value.includes('manufacturer'));}
assert.deepEqual(observations.find(row=>row.id===checks.glc),previousObservations.find(row=>row.id===checks.glc));
const previousPortableAudit=proof.read(priorReceipt.serializedPortableAudit),expectedPortableAudit={...previousPortableAudit,writtenPacks:packFile,writtenPortable:portableFile};
assert.equal(fileHash(path.join(out,'serialized-portable-roundtrip-audit.json')),serializedPortableAudit.sha256);
assert.deepEqual(JSON.parse(fs.readFileSync(path.join(out,'serialized-portable-roundtrip-audit.json'),'utf8')),expectedPortableAudit);
api.verify();proof.verifyData(data);proof.verify();
const labelTransitionAudit=proof.write(out,'availability-label-transition-audit.json',{priorSelectedReceipt:priorDiagnostic.receipt,priorHeldReview:priorDiagnostic.heldReview,byteExactOutputs:['packFile','features','portableFile','serializationAudit'],labelChanges,allOtherBuyerObservationFieldsExact:true,glcObservationUnchanged:true,serializedPortableAuditOnlyOutputReferencesChanged:true,originalCanonicalUnchanged:true});
proof.write(out,'selected-consumer-receipt.json',{...proof.receiptBase(),status:'passed_selected_brand_consumers_pending_remaining_gates',versions:e.selectedCars,newVersions:e.newCars,allCompleteCarsVerified:true,completeCarCount:e.afterCars,all14ResearchFieldsUnchanged:true,allSelectedCarsAndPacketUnchanged:true,displayedCoreCells:coreCells,displayedFilledCoreCells:filledCoreCells,displayedCoreGaps:gaps,strictCoreCoverageProven:false,strictCoreCoverageOwner:'Complete actual report stage; displayed hasValue inventory is not strict coverage',citableFacts,citableFeatures,allCitableFeatureRows,actualPackPipelineMatches:true,actualPortableExact:true,inMemoryPortableExact:true,serializedPortableExact:true,serializedPortableAudit,availabilityLabelTransitionExact:true,labelTransitionAudit,allOriginalCanonicalFeatureRowsEqual:true,originalExistingRowsMatchAcceptedBeforeSnapshot:true,actualOriginalExistingRowsReplayedUnderOriginalSnapshot:true,allNewCanonicalFeatureRowsEqual:true,originalExistingFeatureRows:e.existingFeatureRows,originalNewFeatureRows:e.newFeatureRows,exactFactAndSummaryEquality:true,historicalFactsUnchanged:true,reportedRemainsUnranked:true,driveFilterAndPickerProjectionVerified:true,defaultLoaderCalls:api.loaderCalls(),packFile,features,portableFile,serializationAudit,buyerObservations,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log('Actual selected packs, citations, original snapshot replay and portable equality passed; strict coverage and remaining gates stay open');

