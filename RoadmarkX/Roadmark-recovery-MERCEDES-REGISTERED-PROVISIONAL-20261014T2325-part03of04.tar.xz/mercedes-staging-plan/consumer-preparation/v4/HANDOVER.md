# Mercedes consumer v4 handover

Status: frozen static preparation, awaiting exact selected-phase/batch review and explicit root execution grant. No v4 module has been imported, syntax-checked, tested or executed by this preparation task.

## Ready first phase

- selected-manifest-frozen-v4.json: 160185 bytes; SHA256 22385180759d65e65a14be0e52497136b1e793665554feb97bda5dad8cbf699d; 733 unique actual input pins and seven harness pins
- selected-command-template-v4.json: exact selected driver/manifest; actual independent phase-review hash remains unresolved
- Current source inventory has the same 522 paths as the accepted historical inventory. Only src/lib/config.ts and tests/device-issue-drafts.test.ts differ, using the exact accepted patch, archived witnesses and focused-test/lint receipt
- Original canonical storage, packet, full cars, 14 research fields and source captures remain unchanged. No second core capture or final packet rewrite is required

## Narrow delta and retained history

v3-to-v4.patch is the complete seven-file diff. feature-json-parity.mjs, stage-negative-guards-brand.mjs and stage-complete-report-brand.mjs remain byte-identical to v3. The feature range module changes only its exact versioned self-path. open-consumer-inputs adds the path-specific historical/current source boundary; selected proof adds the held-output comparison. The design documents those changes.

V1/V2 remain unexecuted historical cuts. V3 ran once and mechanically passed but its buyer content was held: Current manufacturer listing wrongly labelled retailer-only City evidence. Its exact original outputs and held review are pinned as diagnostics. They are never accepted predecessors for the negative/range/report phases. V4 must prove four written artifacts byte-exact and permit only the neutral prefix in the value/sentence fields of ten actual current listings; GLC is unchanged. Portable-audit contents remain exact apart from new output references.

The original retained XPENG consumer-v1 harness remains the source framework. V1 provenance/diffs and the complete parameter-replacement audit/corrections in v2 remain available in their immutable directories. No fresh proof framework or generic normalization/pin-remapping policy is introduced.

## Independent acceptance checklist

1. Verify all seven harness pins, v3-to-v4.patch,733 unique input pins and full exact selected command
2. Verify archived config/test witnesses equal historical canonical pins; current files equal accepted after pins; old/current source inventories differ at exactly those two paths with identical path set
3. Verify actual label patch acceptance and exact phase review bind the source transition; every future phase receipt must carry the identical transition
4. Require unchanged409 complete cars, all14 research fields, original483+276 feature replay, actual packs/citations and complete serialized portable round-trip
5. Require byte-identical packs/features/portable/original replay audit versus held-v3; exactly ten claim values and matching sentence segments change; every other buyer field and GLC remain exact
6. Keep all critical buyer checks and inherited REVIEWER-HANDOFF.md checklist from v3: City caveats/no physical stock or accepted order, NEDC/WLTP distinction, Reported/unranked measurements, exact warranties, unchanged model-code facts, no summary merge, protected cargo/ModelY and all398 peers
7. Require independent selected output acceptance before freezing negative manifest. Preserve candidate applicability and separate historical feature-fixture semantics
8. Run only bounded serial eight ranges and exact raw-byte aggregate, inspecting all409 descriptor lists and28221 feature rows without sampling
9. Bind independently accepted reconciliation content only into the exact report phase; all14 inherited dispositions and C1 remain open
10. Keep unchanged actual GLC outside on-sale coverage;187 displayed slots are not strict coverage. City35/32 durations retain a missing10–80 window; actual complete report is authoritative
11. Stop on any failure or drift; retain partial outputs. No automatic retry, output rewrite or broader undefined omission policy
12. Full staged report and subsequent root-owned entire registered-report JSON/byte parity remain separate gates. No publication, M2, current-version-list or whole-market closure

## Bounded batch

bounded-serial-batch-contract-v4.json declares selected, negative, eight contiguous feature ranges, aggregate and report. Each command uses the common measured runner,180 seconds,448MiB old heap/1MiB semi-space,expose-gc and absent NODE_OPTIONS in the repository cwd. Every future manifest must bind actual predecessor receipts/output acceptances and receive exact independent phase review. Future output hashes remain null. The separately accepted reconciliation content/review pair is recorded but does not itself approve report execution.

Root owns execution and the sole heavy slot. This preparation task writes only versioned static artifacts in consumer-preparation. To resume, obtain the exact v4 phase/batch reviews and root grant, then resolve only the real selected review path/bytes/hash into a new command artifact. Do not modify this frozen cut.
