/** Prepared only. Isolated real-candidate mutations adapted from the Subaru guard proof. */
import assert from 'node:assert/strict';
import path from 'node:path';
import {createRequire} from 'node:module';
import {digestRows} from '/tmp/xpeng-staging-plan/baseline-io.mjs';
import {openConsumerInputs,visitCompleteCars} from './open-consumer-inputs.mjs';
const stage=openConsumerInputs('negative'),{packet,index,selected,before,e}=stage,out=stage.createOutput();
let completeCars=0;await visitCompleteCars(stage,()=>{completeCars++;});assert.equal(completeCars,e.afterCars);
const selectedReceipt=stage.readPhaseReceipt(stage.manifest.selectedConsumerReceipt,'passed_selected_brand_consumers_pending_remaining_gates');
for(const key of ['allCompleteCarsVerified','all14ResearchFieldsUnchanged','allSelectedCarsAndPacketUnchanged','actualPackPipelineMatches','actualPortableExact','serializedPortableExact','allOriginalCanonicalFeatureRowsEqual'])assert.equal(selectedReceipt[key],true);
const expectedFeatures=stage.read(selectedReceipt.features);assert.equal(expectedFeatures.length,e.selectedFeatureRows);
const selectedPacks=stage.read(selectedReceipt.packFile);assert.equal(Object.keys(selectedPacks).length,e.selectedCars);
const require=createRequire(path.join(stage.anchors.repo,'package.json'));
const {brandUpdatePackets}=require('./src/lib/brand-update-registry.ts');assert.equal(brandUpdatePackets.length,e.registeredPackets);assert.deepEqual(brandUpdatePackets,stage.registeredPackets);assert(!brandUpdatePackets.some(row=>row.id===packet.id||row.brand===stage.manifest.brand));
assert(!require.cache[path.join(stage.anchors.repo,'src/lib/data.ts')]);
const {applyBrandUpdates,applyBrandFeatureUpdates,applyBrandTermFeatures}=require('./src/lib/brand-updates.ts');
const {applyFeatureRegrading}=require('./src/lib/evidence-regrading.ts');
const {sameReviewedState}=require('./src/lib/correction-guards.ts');
const {hasEarnedBuyerGrade}=require('./src/lib/evidence-grading.ts');
const {isRetainedAUMakerSource}=require('./src/lib/evidence-regrade-policy.ts');
const {priceCandidateRejection}=require('./src/lib/price-ladder.ts');
const {createEvidenceConsumers}=require('./src/lib/evidence-consumers.ts');
const {compiledSource}=require('./tests/helpers/compiled-source.ts');
const data=await stage.readData(),newIds=new Set(packet.variants.map(row=>row.id));assert.equal(newIds.size,e.newCars);
const registeredIds=brandUpdatePackets.map(row=>row.id),registeredDigests=brandUpdatePackets.map(row=>digestRows([row]));
assert.deepEqual(data.metadata.brand_update_packet_ids,[...registeredIds,packet.id]);
for(const car of before){const expected=index.cars.carHashes.find(row=>row.id===car.id);assert.equal(digestRows([car]).sha256,expected.beforeSha256);}
const packetDigest=digestRows([packet]),selectedDigests=selected.map(car=>digestRows([car])),beforeDigests=before.map(car=>digestRows([car])),expectedFeaturesDigest=digestRows(expectedFeatures);
function freeze(value){
  if(value&&typeof value==='object'&&!Object.isFrozen(value)){
    for(const part of Object.values(value))freeze(part);
    Object.freeze(value);
  }
  return value;
}
// Frozen complete original inputs also detect an attempted write which would
// otherwise happen to leave the final digest unchanged.
for(const value of [packet,selected,before,data,expectedFeatures,brandUpdatePackets])freeze(value);
let loaderCalls=0;
const forbidden=()=>{loaderCalls++;throw new Error('BRAND_NEGATIVE_GUARD_FORBIDDEN_LOADER');};
const defaults={sourceResearch:forbidden,research:forbidden,catalogue:forbidden};
const baseConsumer=createEvidenceConsumers(defaults);
// Only this module binding changes between isolated candidate mutations. The
// production function bodies and every registered predecessor remain intact.
const registryBinding={brandUpdatePackets:Object.freeze([...brandUpdatePackets,packet])};
const stagedConsumer=compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':registryBinding}).createEvidenceConsumers(defaults);
function withCandidate(candidate,fn){
  assert.equal(candidate.id,packet.id);
  const previous=registryBinding.brandUpdatePackets;
  registryBinding.brandUpdatePackets=Object.freeze([...brandUpdatePackets,candidate]);
  assert.deepEqual(registryBinding.brandUpdatePackets.slice(0,e.registeredPackets).map(row=>row.id),registeredIds);
  try{return fn();}finally{registryBinding.brandUpdatePackets=previous;}
}
function pack(carId,cars=selected,research=data,candidate=packet){
  assert.equal(cars.length,e.selectedCars,'Every consumer snapshot supplies all selected cars');
  assert.deepEqual(Object.keys(research).sort(),Object.keys(data).sort(),'Every consumer receives all 14 Research fields');
  return withCandidate(candidate,()=>stagedConsumer.pack(carId,{data:research,cars}));
}
const caseResults=[],unsupportedCategories=[];
function reject(name,category,expectedMessage,inputs,fn){
  assert(!caseResults.some(row=>row.name===name));
  freeze(inputs);
  const inputDigest=digestRows([inputs]);
  let caught;
  try{fn();}catch(error){caught=error;}
  assert(caught instanceof Error,name+': production accepted the mutation');
  assert.equal(caught.message,expectedMessage,name+': rejected by an unintended guard');
  assert.deepEqual(digestRows([inputs]),inputDigest,name+': complete isolated mutation inputs changed');
  assert.equal(loaderCalls,0,name+': fallback loader invoked');
  caseResults.push({name,category,expectedMessage,actualMessage:caught.message,inputDigest,isolatedInputsUnchanged:true});
  console.log('Rejected isolated brand mutation:',name);
  global.gc();
}
function mutateCandidate(edit){const changed=structuredClone(packet);edit(changed);return changed;}
function changeCar(cars,id,edit){
  assert.equal(cars.filter(car=>car.id===id).length,1);
  return cars.map(car=>{if(car.id!==id)return car;const changed=structuredClone(car);edit(changed);return changed;});
}
function changedSources(id,edit){
  assert.equal(data.sources.filter(source=>source.id===id).length,1);
  return data.sources.map(source=>{if(source.id!==id)return source;const changed=structuredClone(source);edit(changed);return changed;});
}
function coreReject(name,category,expectedMessage,candidate=packet,cars=before,research=data){
  reject(name,category,expectedMessage,{candidate,cars,sources:research.sources},()=>applyBrandUpdates(cars,research,[candidate]));
}
function corePacketReject(name,category,expectedMessage,edit){
  coreReject(name,category,expectedMessage,mutateCandidate(edit));
}
function consumerPacketReject(name,category,expectedMessage,carId,edit){
  const candidate=mutateCandidate(edit);
  reject(name,category,expectedMessage,{candidate},()=>pack(carId,selected,data,candidate));
}
function missingCategory(category,detail){
  unsupportedCategories.push({category,detail});
  console.log('UNSUPPORTED REAL-CANDIDATE CATEGORY:',category,detail);
}

// Positive controls run before mutation tests: otherwise an unrelated baseline
// failure could be mistaken for a successful negative guard.
{
  const actual=applyBrandUpdates(before,data,[packet]);
  assert.equal(actual.length,e.selectedCars);
  assert.deepEqual(actual.map(car=>digestRows([car])),selectedDigests,'Unmodified actual core replay equals every complete staged car');
}
const baseFeatures=new Map();
for(const car of selected){
  const initial=applyFeatureRegrading(car,baseConsumer.sourceEffectiveFeatures(car,data),data.sources);
  assert.equal(initial.length,e.criteria);assert.equal(new Set(initial.map(row=>row.criterion)).size,e.criteria);
  freeze(initial);baseFeatures.set(car.id,initial);
  for(const row of packet.features.filter(row=>row.variantId===car.id)){
    const matches=initial.filter(feature=>feature.criterion===row.criterion);
    assert.equal(matches.length,1);assert(sameReviewedState(matches[0],row.before),'Original complete feature before-value differs: '+car.id+'/'+row.criterion);
  }
  const view=pack(car.id);
  assert.equal(view.features.length,e.criteria);
  assert.deepEqual(digestRows(view.features),digestRows(expectedFeatures.filter(row=>row.variant_id===car.id)),'Unmodified actual consumer differs from verified selected feature output');
  assert.deepEqual(view.features,applyBrandTermFeatures(car,applyBrandFeatureUpdates(car,initial,data,[...brandUpdatePackets,packet])));
  assert.deepEqual(JSON.parse(JSON.stringify(view)),selectedPacks[car.id],'Every complete unmodified actual pack equals the selected proof output');
  global.gc();
}
assert.equal(loaderCalls,0);
assert.deepEqual(digestRows([packet]),packetDigest,'Positive actual functions changed the complete packet');

// Complete source-record equality includes capture provenance, not just URL/ID.
const source=packet.sources[0];assert(source);
for(const field of ['supports','capture_sha256']){
  const target=field==='supports'?source:packet.sources.find(row=>typeof row.capture_sha256==='string');
  assert(target,'Actual retained source capture hash is required');
  const sources=changedSources(target.id,row=>{row[field]=field==='supports'?row[field]+' [isolated source drift]':(row[field][0]==='0'?'1':'0')+row[field].slice(1);});
  coreReject('complete_source_record_drift_'+field,'source_record_drift','Brand update: source snapshot changed: '+target.id,packet,before,{...data,sources});
}
{
  const sources=data.sources.filter(row=>row.id!==source.id);
  coreReject('missing_packet_source','missing_source','Brand update: research is missing packet sources: '+packet.id,packet,before,{...data,sources});
}
{
  const sources=[...data.sources,structuredClone(source)];
  coreReject('duplicate_packet_source','duplicate_source','Brand update: source snapshot changed: '+source.id,packet,before,{...data,sources});
}

const firstFeature=packet.features[0],firstCar=firstFeature&&selected.find(car=>car.id===firstFeature.variantId);
const numericV2LClaims=[];
const inapplicableCategories=stage.manifest.featureOnlyCategories;
assert.deepEqual(inapplicableCategories,['feature_before_drift','feature_dependency_drift','feature_dependency_schema','v2l_numeric_dependency','duplicate_feature_target','canonical_feature_cardinality','consumer_feature_cardinality','feature_only_brand_tier_identity','feature_only_other_brand_targeting']);
assert.equal(packet.features.length,0,'This cut never fabricates candidate equipment updates');
const fixture=stage.manifest.retainedFeatureFixture,historical=stage.read(fixture.receipt),historicalAcceptance=stage.read(fixture.acceptance);
assert.equal(historical.status,'passed_xpeng_negative_guards_pending_remaining_gates');assert.deepEqual(historical.unsupportedCategories,[]);
assert.equal(historicalAcceptance.status,'accepted_xpeng_negative_guard_outputs');assert.equal(historicalAcceptance.receiptSha256,fixture.receipt.sha256);
assert.equal(historical.caseCount,historicalAcceptance.caseCount);
assert.deepEqual(fixture.guardSourceFiles,['src/lib/brand-updates.ts','src/lib/evidence-consumers.ts','src/lib/evidence-grading.ts','src/lib/correction-guards.ts','src/lib/evidence-regrading.ts','src/lib/price-ladder.ts','tests/helpers/compiled-source.ts']);
for(const file of fixture.guardSourceFiles){
  const previous=historical.fullInputPins.find(row=>row.anchor==='repo'&&row.file===file),current=stage.manifest.inputPins.find(row=>row.anchor==='repo'&&row.file===file);
  assert(previous&&current);assert.deepEqual(current,previous,'Retained fixture proof may not cover changed implementation bytes');
}
const historicalFixtureCoverage={receipt:fixture.receipt,acceptance:fixture.acceptance,caseCount:historical.caseCount,sourceFilesUnchanged:fixture.guardSourceFiles,rerunForMercedes:false,scope:'Retained separately accepted fixture proof only; candidate equipment is empty and actual candidate feature mutations are inapplicable'};

const beforeFactIndex=packet.facts.findIndex(row=>row.before!==null&&before.some(car=>car.id===row.variantId));
assert(beforeFactIndex>=0);
{
  const row=packet.facts[beforeFactIndex];
  const cars=changeCar(before,row.variantId,car=>{car.facts[row.after.key].qualifications.push('Isolated before-value drift');});
  coreReject('full_fact_before_value_drift','fact_before_drift','Brand update: fact before snapshot changed: '+row.variantId+'/'+row.after.key,packet,cars);
}
{
  const row=packet.versionGuards[0];assert(row);
  const cars=changeCar(before,row.variantId,car=>{car.trim+=' [isolated identity drift]';});
  coreReject('full_version_identity_drift','identity_drift','Brand update: reviewed version changed: '+row.variantId,packet,cars);
}

// Preserve all genuine source records, including sourceOriginMarket, while
// attempting to turn an actually Reported fact/feature into Confirmed.
const sourceById=new Map(packet.sources.map(row=>[row.id,row]));
const isForeign=source=>source&&typeof source.sourceOriginMarket==='string'&&!['AU','Australia','AU/NZ'].includes(source.sourceOriginMarket);
const candidateForeignSources=packet.sources.filter(isForeign);
const candidateForeignSourceCount=candidateForeignSources.length;
for(const retained of packet.sources){
  if(/overseas|foreign|non_au/i.test(retained.source_type))assert(isForeign(retained),'A foreign-labelled retained source needs explicit foreign origin metadata: '+retained.id);
  if(!isForeign(retained))continue;
  assert.equal(isRetainedAUMakerSource(retained),false,'A retained foreign origin must never be classified as an AU maker: '+retained.id);
  assert(!packet.facts.some(row=>['confirmed','check'].includes(row.after.buyerGrade)&&row.after.sourceIds.includes(retained.id)),'Foreign origin may not support Confirmed/Check candidate facts');
  assert(!packet.features.some(row=>['confirmed','check'].includes(row.after.buyerGrade)&&row.after.source_ids.includes(retained.id)),'Foreign origin may not support Confirmed/Check candidate features');
}
const secondarySourceCoverage=[];
function promotionCase(label,sourcePredicate,{requireFact=true,requireFeature=packet.features.length>0}={}){
  const factIndex=packet.facts.findIndex(row=>row.after.buyerGrade==='reported'&&row.after.sourceIds.some(id=>sourcePredicate(sourceById.get(id))));
  if(factIndex<0){if(requireFact)missingCategory(label+'_confirmed_fact_promotion','No actually Reported candidate fact cites this retained source; no source was invented or relabelled.');}
  else{
    const original=packet.facts[factIndex].after;
    assert.equal(hasEarnedBuyerGrade(original,data.sources,packet.reviewedAt),true);
    const candidate=mutateCandidate(value=>{
      const fact=value.facts[factIndex].after;
      fact.buyerGrade='confirmed';fact.status='standard';fact.gradeReview.evidenceScope='exact_au_version';
    });
    assert.deepEqual(candidate.sources,packet.sources,'Promotion may not rewrite a source or sourceOriginMarket');
    assert.equal(hasEarnedBuyerGrade(candidate.facts[factIndex].after,data.sources,packet.reviewedAt),false,'Actual source-authority guard must reject promotion independently');
    coreReject(label+'_confirmed_fact_promotion','secondary_or_foreign_confirmed_promotion','Brand update: invalid fact or unearned grade: '+original.key,candidate);
  }
  const featureIndex=packet.features.findIndex(row=>row.after.buyerGrade==='reported'&&row.after.source_ids.some(id=>sourcePredicate(sourceById.get(id))));
  if(featureIndex<0){if(requireFeature)missingCategory(label+'_confirmed_feature_promotion','No actually Reported candidate feature cites this retained source.');}
  else{
    const row=packet.features[featureIndex];
    assert.equal(hasEarnedBuyerGrade(row.after,data.sources,packet.reviewedAt),true);
    consumerPacketReject(label+'_confirmed_feature_promotion','secondary_or_foreign_confirmed_promotion','Brand update: invalid feature or unearned grade: '+row.variantId+'/'+row.criterion,row.variantId,value=>{
      const after=value.features[featureIndex].after;
      after.buyerGrade='confirmed';after.status='standard';after.gradeReview.evidenceScope='exact_au_version';
      assert.deepEqual(value.sources,packet.sources);
      assert.equal(hasEarnedBuyerGrade(after,data.sources,packet.reviewedAt),false);
    });
  }
  return{factIndex,featureIndex};
}
const secondarySources=packet.sources.filter(source=>!isForeign(source)&&!isRetainedAUMakerSource(source)&&(
  packet.facts.some(row=>row.after.buyerGrade==='reported'&&row.after.sourceIds.includes(source.id))||
  packet.features.some(row=>row.after.buyerGrade==='reported'&&row.after.source_ids.includes(source.id))
));
assert(secondarySources.length,'At least one genuine secondary candidate source is required');
for(const source of secondarySources){
  const result=promotionCase('secondary_source_'+source.id,row=>row?.id===source.id,{requireFact:false,requireFeature:false});
  assert(result.factIndex>=0||result.featureIndex>=0);
  secondarySourceCoverage.push({sourceId:source.id,sourceDigest:digestRows([source]),factIndex:result.factIndex,featureIndex:result.featureIndex,sourceMetadataPreserved:true});
}
const foreignPromotion=candidateForeignSourceCount?'actual retained foreign-source promotions tested':'not applicable: no foreign source in candidate';
for(const source of candidateForeignSources)promotionCase('foreign_source_origin_retained_'+source.id,row=>row?.id===source.id,{requireFact:false,requireFeature:false});

// Deliberately synthetic negative input, kept separate from actual candidate evidence.
// Keep the source's AU applicability and valid record shape; change its source
// authority and retained origin only. Update both isolated snapshots so source
// drift cannot mask the intended unearned-grade rejection.
let syntheticForeignPromotionRejected=false;
{
  const targetIndex=packet.facts.findIndex(row=>row.after.buyerGrade==='reported'&&row.after.sourceIds.some(id=>secondarySources.some(source=>source.id===id)));
  assert(targetIndex>=0);
  const target=packet.facts[targetIndex];
  const sourceId=target.after.sourceIds.find(id=>secondarySources.some(source=>source.id===id));
  const candidate=mutateCandidate(value=>{
    const source=value.sources.find(row=>row.id===sourceId);
    source.source_type='manufacturer_overseas_reported';source.sourceOriginMarket='DE';
    const fact=value.facts[targetIndex].after;
    fact.buyerGrade='confirmed';fact.status='standard';fact.gradeReview.evidenceScope='exact_au_version';
  });
  const syntheticSource=candidate.sources.find(row=>row.id===sourceId);
  const sources=changedSources(sourceId,source=>{source.source_type='manufacturer_overseas_reported';source.sourceOriginMarket='DE';});
  assert.deepEqual(sources.find(row=>row.id===sourceId),syntheticSource);
  assert.equal(syntheticSource.market,sourceById.get(sourceId).market);
  assert.equal(isRetainedAUMakerSource(syntheticSource),false);
  assert.equal(hasEarnedBuyerGrade(candidate.facts[targetIndex].after,sources,packet.reviewedAt),false);
  coreReject('synthetic_foreign_DE_confirmed_promotion','synthetic_foreign_confirmed_promotion','Brand update: invalid fact or unearned grade: '+target.after.key,candidate,before,{...data,sources});
  syntheticForeignPromotionRejected=true;
}

// The actual prices are Reported with blank comparisonBasis. Preserve that positive
// control. Corrupt only one isolated comparisonBasis against a retained explicit label;
// never manufacture a comparable positive candidate or rewrite source provenance.
const priceSelector=stage.manifest.negativeSelectors.priceBasis;
assert.equal(priceSelector.key,'price_aud');assert.equal(priceSelector.guardField,'basisTag');assert.equal(priceSelector.originalComparisonBasis,'');assert.equal(priceSelector.corruptComparisonBasis,'Driveaway');
const priceIndex=packet.facts.findIndex(row=>row.variantId===priceSelector.variantId&&row.after.key===priceSelector.key&&typeof row.after.value==='number'&&row.after.buyerGrade==='reported'&&row.after.comparisonBasis===priceSelector.originalComparisonBasis&&row.after.priceEvidence?.basisTag.toLowerCase().includes('before on-road costs'));
assert(priceIndex>=0,'An actual Reported price with explicit retained before-on-road label is required');
function priceCandidate(fact){return{variantId:'packet',value:fact.value,sourceIds:fact.sourceIds,date:fact.date,...fact.priceEvidence,comparisonBasis:fact.comparisonBasis,qualifications:fact.qualifications,validUntil:fact.validUntil};}
const originalPrice=packet.facts[priceIndex].after;
assert.equal(priceCandidateRejection(priceCandidate(originalPrice),'packet',data.sources,packet.reviewedAt),null);
assert.equal(originalPrice.priceEvidence.rankingEligible,false);
{
  const candidate=mutateCandidate(value=>{value.facts[priceIndex].after.comparisonBasis=priceSelector.corruptComparisonBasis;});
  const expected='Price comparison basis contradicts retained price provenance (basisTag)';
  assert.deepEqual(candidate.facts[priceIndex].after.priceEvidence,originalPrice.priceEvidence);
  assert.deepEqual(candidate.sources,packet.sources);
  assert.equal(hasEarnedBuyerGrade(candidate.facts[priceIndex].after,data.sources,packet.reviewedAt),true);
  assert.equal(priceCandidateRejection(priceCandidate(candidate.facts[priceIndex].after),'packet',data.sources,packet.reviewedAt),expected);
  coreReject('reported_price_illegal_opposite_basis_insertion','price_basis_contradiction','Brand update: '+expected,candidate);
}

// Retained original feature fixture cases; deliberately not exercised by an empty-feature candidate.
if(packet.features.length){
  assert(firstFeature&&firstCar);
consumerPacketReject('candidate_complete_before_feature_drift','feature_before_drift','Brand update: feature before snapshot changed: '+firstFeature.variantId+'/'+firstFeature.criterion,firstFeature.variantId,value=>{value.features[0].before.conditions+=' [isolated before-feature drift]';});
{
  const features=structuredClone(baseFeatures.get(firstCar.id));
  features.find(row=>row.criterion===firstFeature.criterion).conditions+=' [isolated effective-feature drift]';
  reject('actual_effective_before_feature_drift','feature_before_drift','Brand update: feature before snapshot changed: '+firstCar.id+'/'+firstFeature.criterion,{features},()=>applyBrandFeatureUpdates(firstCar,features,data,[packet]));
}
const featureDependency=firstFeature.dependencies[0];assert(featureDependency);
consumerPacketReject('feature_expected_fact_dependency_drift','feature_dependency_drift','Brand update: feature dependency changed: '+firstCar.id+'/'+firstFeature.criterion+'/'+featureDependency.key,firstCar.id,value=>{value.features[0].dependencies[0].expected.qualifications.push('Isolated expected-fact drift');});
for(const mode of ['missing','changed']){
  const cars=changeCar(selected,firstCar.id,car=>{if(mode==='missing')delete car.facts[featureDependency.key];else car.facts[featureDependency.key].qualifications.push('Isolated actual-fact drift');});
  reject('feature_actual_fact_'+mode,'feature_dependency_drift','Brand update: feature dependency changed: '+firstCar.id+'/'+firstFeature.criterion+'/'+featureDependency.key,{cars},()=>pack(firstCar.id,cars));
}
for(const mode of ['missing','empty','duplicate']){
  consumerPacketReject('feature_dependency_list_'+mode,'feature_dependency_schema','Brand update: invalid feature dependencies: '+firstCar.id+'/'+firstFeature.criterion,firstCar.id,value=>{
    const row=value.features[0];
    if(mode==='missing')delete row.dependencies;
    else if(mode==='empty')row.dependencies=[];
    else row.dependencies.push(structuredClone(row.dependencies[0]));
  });
}

// Numeric V2L output and voltage must remain exact live dependencies, rather
// than merely retaining a feature's prose or a broad V2L source citation.
for(const row of packet.features.filter(row=>row.criterion==='v2l')){
  const text=row.after.value+' '+row.after.conditions,requiredKeys=[];
  if(/\d[\d,.]*\s*(?:kW|W)\b/i.test(text))requiredKeys.push('v2l_output_kw');
  if(/\d[\d,.]*\s*V\b/i.test(text))requiredKeys.push('v2l_voltage_v');
  for(const key of requiredKeys){
    const dependencies=row.dependencies.filter(dep=>dep.key===key);
    assert.equal(dependencies.length,1,'Every numeric V2L claim must explicitly name its exact numeric fact: '+row.variantId+'/'+key);
    assert.equal(typeof dependencies[0].expected.value,'number');
    assert(sameReviewedState(dependencies[0].expected,selected.find(car=>car.id===row.variantId).facts[key]),'Numeric V2L evidence must equal the complete live fact');
  }
  if(requiredKeys.length)numericV2LClaims.push({variantId:row.variantId,criterion:row.criterion,requiredKeys});
}
assert(numericV2LClaims.length,'Real candidate numeric V2L claims are required');
const numericV2L=packet.features.flatMap((row,rowIndex)=>row.dependencies.filter(dep=>/^v2l_.*(?:kw|voltage_v)$/.test(dep.key)&&typeof dep.expected.value==='number').map(dep=>({row,rowIndex,dep})));
if(!numericV2L.length)missingCategory('v2l_numeric_dependency','No candidate feature has an actual numeric V2L output/voltage dependency.');
for(const key of [...new Set(numericV2L.map(({dep})=>dep.key))]){
  const {row,dep}=numericV2L.find(item=>item.dep.key===key);
  // Find the first real feature using this key: its exact rejection must win.
  const earliest=packet.features.find(feature=>feature.variantId===row.variantId&&feature.dependencies.some(dependency=>dependency.key===key));
  assert(earliest);assert.equal(typeof dep.expected.value,'number');
  for(const mode of ['missing','changed']){
    const cars=changeCar(selected,row.variantId,car=>{assert.equal(car.facts[key].value,dep.expected.value);if(mode==='missing')delete car.facts[key];else car.facts[key].value+=0.125;});
    reject('v2l_numeric_'+key+'_'+mode,'v2l_numeric_dependency','Brand update: feature dependency changed: '+row.variantId+'/'+earliest.criterion+'/'+key,{cars},()=>pack(row.variantId,cars));
  }
}

}

const summary=packet.summaries[0];assert(summary?.strength?.dependencies?.length);
const summaryDependency=summary.strength.dependencies[0];
corePacketReject('summary_expected_fact_dependency_drift','summary_dependency_drift','Brand update: summary dependency changed: '+summary.variantId+'/'+summaryDependency.key,value=>{value.summaries[0].strength.dependencies[0].expected.qualifications.push('Isolated summary dependency drift');});
for(const mode of ['missing','empty','duplicate']){
  corePacketReject('summary_dependency_list_'+mode,'summary_dependency_schema','Brand update: invalid summary clause for '+summary.variantId,value=>{
    const clause=value.summaries[0].strength;
    if(mode==='missing')delete clause.dependencies;
    else if(mode==='empty')clause.dependencies=[];
    else clause.dependencies.push(structuredClone(clause.dependencies[0]));
  });
}

if(packet.features.length){
  assert(firstFeature&&firstCar);
consumerPacketReject('duplicate_candidate_feature_target','duplicate_feature_target','Brand update: duplicate feature target in '+packet.id,firstCar.id,value=>{value.features.push(structuredClone(value.features[0]));});
// New-version rows cannot be masked by a historical approved correction.
const newFeature=packet.features.find(row=>newIds.has(row.variantId));assert(newFeature);
const newCar=selected.find(car=>car.id===newFeature.variantId);assert(newCar);
const rawMatches=data.feature_evidence.filter(row=>row.variant_id===newCar.id&&row.criterion===newFeature.criterion);assert.equal(rawMatches.length,1);
for(const mode of ['missing','duplicate']){
  const rows=mode==='missing'?data.feature_evidence.filter(row=>row!==rawMatches[0]):[...data.feature_evidence,structuredClone(rawMatches[0])];
  const research={...data,feature_evidence:rows};freeze(research);
  reject('canonical_feature_data_'+mode,'canonical_feature_cardinality','Brand update: invalid or canonical feature target: '+newCar.id+'/'+newFeature.criterion,{targetRows:rows.filter(row=>row.variant_id===newCar.id)},()=>applyBrandFeatureUpdates(newCar,baseFeatures.get(newCar.id),research,[packet]));
  reject('actual_consumer_feature_data_'+mode,'consumer_feature_cardinality','Brand update: feature before snapshot changed: '+newCar.id+'/'+newFeature.criterion,{targetRows:rows.filter(row=>row.variant_id===newCar.id)},()=>pack(newCar.id,selected,research));
}

const otherBrand=data.variants.find(row=>row.brand&&row.brand!==packet.brand)?.brand;assert(otherBrand);
for(const [name,edit,message]of [
  ['wrong_brand',car=>{car.brand=otherBrand;},'Brand update: wrong brand or unguarded feature version: '+firstCar.id],
  ['wrong_tier',car=>{car.vehicleClass='van';},'Brand update: feature version is outside Tier 1: '+firstCar.id],
  ['changed_final_identity',car=>{car.trim+=' [isolated final identity drift]';},'Brand update: reviewed feature version changed: '+firstCar.id],
]){
  const cars=changeCar(selected,firstCar.id,edit);
  reject(name,'brand_tier_identity',message,{cars},()=>pack(firstCar.id,cars));
}
consumerPacketReject('other_brand_packet_targeting_xpeng','other_brand_targeting','Brand update: wrong brand or unguarded feature version: '+firstCar.id,firstCar.id,value=>{value.brand=otherBrand;});

}

// Candidate core identity and metadata guards remain active even with no equipment mutations.
for(const [name,edit,message]of [
  ['wrong_brand',car=>{car.brand='Isolated other brand';},'Brand update: wrong brand, version or tier: '],
  ['wrong_tier',car=>{car.vehicleClass='van';},'Brand update: wrong brand, version or tier: '],
]){
  const id=before[0].id,cars=changeCar(before,id,edit);coreReject(name,'brand_tier_identity',message+id,packet,cars);
}
{
  const row=packet.versionUpdates[0];assert(row);
  corePacketReject('drive_full_metadata_before_drift','metadata_before_drift','Brand update: metadata before snapshot changed: '+row.variantId,value=>{value.versionUpdates[0].before.trim+=' [isolated drift]';});
}
for(const value of ['not-a-date','2999-01-01']){
  const row=packet.facts[0];
  corePacketReject('invalid_or_future_fact_date_'+value,'invalid_or_future_date','Brand update: invalid fact or unearned grade: '+row.after.key,candidate=>{candidate.facts[0].after.date=value;});
}
{
  // Use an actual numeric summary dependency. None of this packet's summaries
  // depends on price; no price-specific dependency coverage is invented.
  assert(!packet.summaries.some(row=>[row.strength,row.tradeoff].some(clause=>clause.dependencies.some(dep=>dep.key==='price_aud'))));
  const amountSelector=stage.manifest.negativeSelectors.numericSummary;
  const summary=packet.summaries.find(row=>row.variantId===amountSelector.variantId);
  assert(summary,'An actual numeric summary dependency is required');
  const dependency=[summary.strength,summary.tradeoff].flatMap(clause=>clause.dependencies).find(dep=>dep.key===amountSelector.key&&typeof dep.expected.value==='number');assert(dependency);
  const original=packet.facts.find(row=>row.variantId===summary.variantId&&row.after.key===dependency.key);assert(original);assert.deepEqual(original.after,dependency.expected);
  corePacketReject('summary_bound_numeric_amount_drift','amount_dependency_drift','Brand update: summary dependency changed: '+summary.variantId+'/'+dependency.key,candidate=>{candidate.facts.find(row=>row.variantId===summary.variantId&&row.after.key===dependency.key).after.value+=0.125;});
}
{
  const {exclusionReason}=require('./src/lib/discovery.ts');
  const target=selected.flatMap(car=>Object.values(car.facts).map(fact=>({car,fact}))).find(({car,fact})=>typeof fact.value==='number'&&!exclusionReason(car,fact,data.sources,{asOf:stage.manifest.asOf}));
  assert(target,'An eligible actual numeric fact is required for a positive ranking control');
  const changed=structuredClone(target.car);changed.facts[target.fact.key].date='2000-01-01';freeze(changed);
  const digest=digestRows([changed]),reason=exclusionReason(changed,changed.facts[target.fact.key],data.sources,{asOf:stage.manifest.asOf});
  assert(reason,'An aged value must stay visible but leave rankings');assert.equal(changed.facts[target.fact.key].value,target.fact.value);assert.deepEqual(digestRows([changed]),digest);
  caseResults.push({name:'stale_fact_ranking_exclusion',category:'stale_ranking_exclusion',actualReason:reason,inputDigest:digest,isolatedInputsUnchanged:true,valueRetained:true});
}

// Unexpected defaults, any altered complete original snapshot or incomplete category fail closed.
assert.equal(loaderCalls,0);
assert.deepEqual(registryBinding.brandUpdatePackets.map(row=>row.id),[...registeredIds,packet.id]);
assert.equal(registryBinding.brandUpdatePackets.at(-1),packet);
assert.deepEqual(digestRows([packet]),packetDigest);
assert.deepEqual(selected.map(car=>digestRows([car])),selectedDigests);
assert.deepEqual(before.map(car=>digestRows([car])),beforeDigests);
assert.deepEqual(digestRows(expectedFeatures),expectedFeaturesDigest);
assert.deepEqual(brandUpdatePackets.map(row=>digestRows([row])),registeredDigests);
stage.verifyData(data);stage.verify();
assert(!Object.hasOwn(require.cache,stage.anchors.repo+'/src/lib/data.ts'));
const receipt={...stage.receiptBase(),
  status:unsupportedCategories.length?'incomplete_brand_negative_guards':'passed_brand_negative_guards_pending_remaining_gates',
  mode:'Actual guarded core and consumer functions on immutable complete derived inputs; registered prefix plus candidate only',
  versions:e.selectedCars,newVersions:e.newCars,originalSelectedVersions:e.existingCars,researchFields:14,allCompleteCarsVerified:true,completeCarCount:e.afterCars,
  packetFacts:e.facts,packetBrandTerms:(packet.brandTerms??[]).length,packetFeatureReplacements:e.authorizedFeatureMutations,
  positiveCoreCompleteEquality:true,positiveActualSelectedConsumers:e.selectedCars,
  exactRegisteredPrefix:registeredIds,candidateId:packet.id,loaderCalls,
  categories:[...new Set(caseResults.map(row=>row.category))],caseCount:caseResults.length,cases:caseResults,unsupportedCategories,
  inapplicableCategories:inapplicableCategories.map(category=>({category,reason:'The original accepted candidate has exactly zero equipment mutations; no feature target or feature dependency exists to mutate'})),historicalFixtureCoverage,
  secondaryPromotionCoverage:'One actual fact and/or feature per distinct retained secondary source',
  secondarySourceCoverage,candidateForeignSourceCount,foreignPromotion,
  syntheticForeignPromotionRejected,syntheticForeignOrigin:'DE',syntheticForeignInputNeverPublished:true,
  priceBasisCoverage:'Actual Reported blank-basis price positive control; isolated Driveaway insertion contradicts unchanged before-on-road basisTag and is rejected',
  candidatePriceProvenanceBranchesTested:['basisTag'],originalBasisBranchCoverage:'Retained historical fixture proof only, with unchanged price-ladder.ts pin; not a fresh Mercedes branch claim',
  priceSpecificSummaryDependencyPresent:false,amountDependencyCoverage:'Actual numeric summary dependency only; no accepted price dependency exists',
  numericV2LClaims,numericV2LMutationCoverage:'Inapplicable to this empty-equipment candidate; original accepted fixture proof retained separately',
  allMutationInputsUnchanged:true,allOriginalSelectedCarsUnchanged:true,allOriginalBeforeCarsUnchanged:true,
  all14ResearchFieldsUnchanged:true,allOriginalRegisteredPacketsUnchanged:true,fullOriginalPacketUnchanged:true,
  selectedConsumerReceiptSha256:stage.manifest.selectedConsumerReceipt.sha256,
  resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage(),
};
stage.write(out,'negative-guards-receipt.json',receipt);
assert.equal(unsupportedCategories.length,0,'Retained receipt reports incomplete applicable actual candidate categories');
console.log('Applicable candidate negative guards passed; retained fixture proof and inapplicable equipment categories are explicitly separate');


