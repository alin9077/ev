/** Exact reuse of the canonical JSON shape guard, with a replay-only comparison adapter. */
import assert from 'node:assert/strict';
import {types as utilTypes} from 'node:util';
import {digestRows} from '/tmp/xpeng-staging-plan/baseline-io.mjs';
const pointerPart = value => String(value).replaceAll('~', '~0').replaceAll('/', '~1');
// Read-only shape guard, not a normalizer. JSON must not silently drop or convert
// anything except the exact manifest-declared own-undefined location checked below.
export function assertDeclaredJson(value, pointer, permittedUndefined, active = new Set()) {
  if (value === undefined) { assert(permittedUndefined.has(pointer), 'Unapproved undefined: ' + pointer); return; }
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return;
  if (typeof value === 'number') {
    assert(Number.isFinite(value) && !Object.is(value, -0), 'Non-JSON-safe number: ' + pointer); return;
  }
  assert.equal(typeof value, 'object', 'Unsupported JSON value: ' + pointer);
  assert(!utilTypes.isProxy(value), 'Proxy cannot establish plain JSON parity');
  const array = Array.isArray(value);
  assert.equal(Object.getPrototypeOf(value), array ? Array.prototype : Object.prototype, 'Non-plain JSON value: ' + pointer);
  assert(!active.has(value), 'Cyclic JSON value: ' + pointer); active.add(value);
  try {
    const keys = Reflect.ownKeys(value); assert(keys.every(key => typeof key === 'string'), 'Symbol-keyed property: ' + pointer);
    if (array) {
      assert.equal(keys.length, value.length + 1, 'Sparse array or extra array property: ' + pointer);
      for (let i = 0; i < value.length; i++) assert(Object.hasOwn(value, String(i)), 'Array hole: ' + pointer);
    }
    for (const key of keys) {
      if (array && key === 'length') continue;
      if (array) assert(/^(0|[1-9][0-9]*)$/.test(key) && Number(key) < value.length, 'Extra array property: ' + pointer);
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      assert(Object.hasOwn(descriptor, 'value') && descriptor.enumerable, 'Accessor or non-enumerable property: ' + pointer);
      assertDeclaredJson(descriptor.value, pointer + '/' + pointerPart(key), permittedUndefined, active);
    }
  } finally { active.delete(value); }
}


export function compareFeatureSerialization(features,accepted,policy,carId,expectedObservation) {
  const allowance=policy.allowedOmission,permittedUndefined=new Set(),omissions=[];
  assert(allowance.variantIds.includes(carId));assert.equal(allowance.criterion,'novated_fbt');assert.equal(allowance.property,'confirmation_needed');assert.equal(allowance.valueType,'undefined');
  for(const [rowIndex,row]of features.entries()){
    assert.equal(row.variant_id,carId);
    const descriptor=Object.getOwnPropertyDescriptor(row,allowance.property);
    if(!descriptor||!Object.hasOwn(descriptor,'value')||descriptor.value!==undefined)continue;
    assert(descriptor.enumerable);assert.equal(row.criterion,allowance.criterion);
    const pointer='/features/'+rowIndex+'/'+pointerPart(allowance.property);permittedUndefined.add(pointer);
    omissions.push({variantId:carId,criterion:row.criterion,rowIndex,pointer,property:allowance.property,own:true,enumerable:true,actualValueType:'undefined'});
  }
  assertDeclaredJson(features,'/features',permittedUndefined);
  const original=structuredClone(features);
  const comparison=structuredClone(features);
  for(const omission of omissions)delete comparison[omission.rowIndex][omission.property];
  const serialized=JSON.parse(JSON.stringify(features));
  assert.deepEqual(serialized,comparison);assert.deepEqual(comparison,accepted);
  assert.equal(JSON.stringify(comparison),JSON.stringify(features));assert.deepEqual(digestRows(comparison),digestRows(features));assert.deepEqual(features,original);
  assert(expectedObservation,'A prior separate accepted per-car observation is required');
  assert.equal(expectedObservation.variantId,carId);assert.equal(expectedObservation.featureRows,features.length);
  // Existing and new audits differ only in their named "absent in JSON" evidence field.
  const prior=expectedObservation.omissions.map(({acceptedPropertyPresent,serializedPropertyPresent,...row})=>{
    assert(acceptedPropertyPresent===false||serializedPropertyPresent===false);return row;
  });
  assert.deepEqual(omissions,prior,'Exact previously observed locations, with no guessed new-row count');
  for(const key of ['fullComparisonCloneEqual','fullSerializedArrayEqual','fullJsonlDigestEqual','liveRowsUnchanged'])assert.equal(expectedObservation[key],true);
  return {variantId:carId,featureRows:features.length,omissions,fullComparisonCloneEqual:true,fullSerializedArrayEqual:true,fullJsonlDigestEqual:true,liveRowsUnchanged:true};
}

