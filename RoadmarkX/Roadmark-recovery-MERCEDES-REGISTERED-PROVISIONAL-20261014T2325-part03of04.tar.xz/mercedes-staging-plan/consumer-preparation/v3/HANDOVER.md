# Mercedes static consumer handover v3

No prepared module has run. All work is confined to versioned static files under consumer-preparation. V1 and v2, all original inputs and repository files remain unchanged.

Read consumer-static-index-v3.json, v2-to-v3.patch, V3-CORRECTIONS.md, consumer-design.md and the inherited reviewer checklist. Original-to-v2 transparent diffs and the complete parameter audit remain in the preserved v2 directory. V3 changes only written portable transport verification, its downstream selected-receipt gate and versioned code paths.

First standalone selected manifest: selected-manifest-frozen-v3.json, 147,114 bytes, SHA256 30e04fb8c1afb59ceac15854be2988b25bf3285f2e3cff3130a5c7be75d1e255. It contains 691 real unique input pins and seven exact current harness/design pins.

The bounded serial contract has twelve commands: selected, applicable actual negatives, eight complete contiguous feature ranges covering 0–409, complete raw-byte aggregate and unchanged full report. Every command is proposed at 180 seconds with the common measured runner and Node 448 MiB old/1 MiB semi-space. Root owns the sole slot. No overlap or automatic retry; stop on any failure. Future receipts/output/review/terminal/log/reconciliation pins remain unresolved until actual results and exact review exist.

selected-command-template-v3.json fixes command arguments and the actual manifest hash, but its future phase review reference/hash remains blocked. Bind the real review in a new command artifact after issuance, then wait for root's independent batch-slot grant.

Consumers reuse the accepted original canonical invocation, unchanged empty-feature packet and complete 409-car/fourteen-field storage. No second core execution or recapture. Complete 28,221-row features and all 398 unchanged peers must be proved. Actual GLC remains provisional/excluded. City Reported 35/32-minute values stay visible while strict 10–80 coverage stays missing; any unchanged reporter Unreviewed limitation is retained. Displayed 187 Fact slots never substitute for on-sale coverage.

V3 reads the exact written portable JSON and complete written pack JSON, checks file hashes, hydrates through the actual function and compares all fields. Non-feature fields must be plain JSON with no permitted undefined values and equal their live originals. Feature rows use only the accepted separate seven-existing/four-new omission audits. Full live packs remain unchanged. Both in-memory and serialized portable equality are required.

Independent final phase review/root grant, runtime results and output reviews, actual reconciliation input, fresh registered normal CLI whole-JSON/byte parity and existing compiler/build/full aggregate/mobile/release/M1 gates remain pending.
