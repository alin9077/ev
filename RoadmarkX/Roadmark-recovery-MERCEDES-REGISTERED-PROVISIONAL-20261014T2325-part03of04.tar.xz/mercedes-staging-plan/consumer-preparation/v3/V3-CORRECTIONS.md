# V3 minimal transport delta

V2 code and inputs remain preserved and unexecuted.

- Read the exact written portable JSON and exact written full-pack JSON, checking their hashes before and after
- Hydrate the written portable file through the actual production hydratePortablePacks function and compare complete packs
- Compare cars, sources and all other non-feature fields directly with live originals. Reuse the existing shape guard with an empty allowed-undefined set for those fields
- Compare every transported feature set against its complete live original under the separate already accepted seven-existing/four-new omission audits. Permit no new location, property, value conversion or broad normalization
- Assert complete live packs unchanged; recheck every Research/source/input pin
- Preserve distinct in-memory and serialized portable assertions and an actual read-back audit artifact
- Require serializedPortableExact in downstream negative and full-feature selected-receipt gates
- Move only self-harness and aggregate-command paths to v3. All remaining proof and negative semantics are unchanged from corrected v2

No runtime, syntax check, import, test, compiler, payload hydration, source-capture hash sweep or compression was performed.
