import fs from 'node:fs';
import assert from 'node:assert/strict';
import {catalogue,research,effectiveFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/data.ts';
import {prepareBrandResearch,applyBrandUpdates,applyBrandFeatureUpdates,applyBrandTermFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-updates.ts';
import {loadReportInput} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/load.ts';
import {buildCoverageReport} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/reports.ts';
import {combineM1Reconciliations} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/m1-reconciliation.ts';
import {featureClaim} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/citable.ts';
import {hydratePortablePacks,storePortablePacks} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/portable-packs.ts';
const root='/tmp/mg-im-research/';
const packets=['mg','im'].map(b=>JSON.parse(fs.readFileSync(root+b+'-2026-10-14.json','utf8')));
const reconciliations=['mg','im'].map(b=>JSON.parse(fs.readFileSync(root+b+'-reconciliation-2026-10-14.json','utf8')));
const before=JSON.parse(JSON.stringify(catalogue())),rd=JSON.parse(JSON.stringify(research()));
const original=JSON.stringify({before,rd,packets});
assert.deepEqual(before.filter(c=>['MG','IM'].includes(c.brand)),JSON.parse(fs.readFileSync(root+'before.json','utf8')),'Frozen catalogue baseline must still match current');
assert.deepEqual(rd,JSON.parse(fs.readFileSync(root+'research-before.json','utf8')),'Full research baseline must remain unchanged before registration');
const data=prepareBrandResearch(rd,packets);const cars=applyBrandUpdates(before,data,packets);const beforeById=new Map(before.map(c=>[c.id,c]));
const features=cars.flatMap(car=>['MG','IM'].includes(car.brand)?applyBrandTermFeatures(car,applyBrandFeatureUpdates(car,effectiveFeatures(beforeById.get(car.id)||car,data),data,packets)):effectiveFeatures(car,data));
for(const car of cars.filter(c=>['MG','IM'].includes(c.brand))){
 const p=packets.find(x=>x.brand===car.brand)!;const rows=features.filter(f=>f.variant_id===car.id);const pack={car,features:rows,sources:data.sources,eligibility:data.update_eligibility.find(r=>r.variant_id===car.id),events:[],configuration:[]};
 const restored=hydratePortablePacks(storePortablePacks({[car.id]:pack}),data.sources)[car.id];assert.deepEqual(JSON.parse(JSON.stringify(restored)),JSON.parse(JSON.stringify(pack)));
 for(const row of p.features.filter((f:any)=>f.variantId===car.id)){
  assert.deepEqual(rows.find(f=>f.criterion===row.criterion),row.after);const claim=featureClaim(restored,row.criterion,row.criterion)!;assert.equal(claim.value,row.after.value);assert.equal(claim.gradeReview?.overlayId,p.id);assert.equal(claim.gradeReviewStatus,undefined);assert.deepEqual(claim.sources.map(s=>s.id),row.after.source_ids);
 }
 assert.equal(car.availabilityEvidence.physicalStockVerified,false);assert.equal(car.availabilityEvidence.factoryOrderAcceptanceVerified,false);assert.equal(car.facts.warranty.buyerGrade,'confirmed');assert.equal(car.facts.battery_warranty.buyerGrade,'confirmed');
 assert.equal(car.facts.warranty.value,car.brand==='MG'?'7 years / unlimited km':'5 years / unlimited km');
 assert.match(car.facts.battery_warranty.value,car.brand==='MG'?/7 years \/ 150,000/:/8 years \/ 160,000/);
 if(car.model==='MGS5 EV') assert.notEqual(car.facts.dc_charge_time_min.comparisonBasis,'DC 30–80%');
 if(car.model==='Cyberster'){assert.equal(car.year,null);assert.equal(car.facts.dc_charge_time_min.value,40);assert.equal(car.facts.dc_30_80_time_min.value,34);}
 if(p.variants.some((v:any)=>v.id===car.id)){assert.ok(Object.keys(car.facts).length<=25+p.facts.filter((f:any)=>f.variantId===car.id).length+3);assert.ok(!Object.keys(car.facts).some(k=>/^truck|hydrogen|solar_wing/.test(k)));}
}
for(const car of before.filter(c=>!['MG','IM'].includes(c.brand)))assert.deepEqual(cars.find(c=>c.id===car.id),car,'Other brand remains immutable: '+car.id);
const input=loadReportInput();input.cars=cars;input.sources=data.sources;input.features=features;input.m1Reconciliation=combineM1Reconciliations(input.m1Reconciliation!,...reconciliations);
const report=buildCoverageReport(input,'2026-10-14');fs.writeFileSync(root+'staged-report.json',JSON.stringify(report,null,2));fs.writeFileSync(root+'after.json',JSON.stringify(cars.filter(c=>['MG','IM'].includes(c.brand)),null,2));fs.writeFileSync(root+'features-after.json',JSON.stringify(features.filter(c=>cars.some(x=>['MG','IM'].includes(x.brand)&&x.id===c.variant_id)),null,2));assert.equal(JSON.stringify({before,rd,packets}),original,'Staging preserves original inputs');
for(const name of ['MG','IM']){
 const brand=report.brandProgress.find(x=>x.brand===name)!;
 console.log(JSON.stringify({brand:name,researchCompleted:brand.researchCompleted,researchRemaining:brand.researchRemaining,onSaleVersions:brand.onSaleVersions,core:brand.core.map(x=>({key:x.key,grades:x.grades})),currentBodies:brand.currentVersionReviews.map(x=>({model:x.model,versions:x.versions.length})),gaps:report.gaps.filter(x=>x.brand===name),closureIssues:brand.closureIssues,criteria:brand.criteria},null,2));
 assert.ok(brand.researchCompleted,JSON.stringify(brand.researchRemaining));assert.equal(brand.missingModels,0);assert.equal(brand.unresolvedLeads,0);assert.equal(brand.missingSummaries,0);assert.equal(brand.agedOrInvalidClaims,0);
}
console.log('PASS: current identity/fact/source guards, effective feature chains/dependencies, citable/portable propagation, immutable original inputs/other brands, staged research completion. Strict/global C1–C6 remain separate.');
