import fs from 'node:fs';
import {hasEarnedBuyerGrade} from '../roadmark-104/src/lib/evidence-grading.ts';
import {usableCorrectionSources} from '../roadmark-104/src/lib/correction-guards.ts';
const p=JSON.parse(fs.readFileSync('/tmp/toyota-research/toyota-2026-10-14.json','utf8'));
const bad=p.facts.filter((r:any)=>!hasEarnedBuyerGrade(r.after,p.sources,p.reviewedAt)||!usableCorrectionSources(r.after.sourceIds,p.sources,p.reviewedAt));console.log(JSON.stringify(bad.map((r:any)=>({variant:r.variantId,fact:r.after,sources:p.sources.filter((s:any)=>r.after.sourceIds.includes(s.id))})),null,2));
