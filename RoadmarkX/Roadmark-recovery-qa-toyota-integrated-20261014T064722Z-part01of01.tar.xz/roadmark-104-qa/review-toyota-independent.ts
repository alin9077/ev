import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {catalogue, research, effectiveFeatures, pack} from '../roadmark-104/src/lib/data.ts';
import {prepareBrandResearch, applyBrandUpdates, applyBrandFeatureUpdates, applyBrandTermFeatures, brandVersionSnapshot, type BrandUpdatePacket} from '../roadmark-104/src/lib/brand-updates.ts';
import {brandUpdatePackets} from '../roadmark-104/src/lib/brand-update-registry.ts';
import {compiledSource} from '../roadmark-104/tests/helpers/compiled-source.ts';
import {hasEarnedBuyerGrade} from '../roadmark-104/src/lib/evidence-grading.ts';
import {factClaim, featureClaim} from '../roadmark-104/src/lib/citable.ts';
import {storePortablePacks, hydratePortablePacks} from '../roadmark-104/src/lib/portable-packs.ts';
import {coreFacts} from '../roadmark-104/scripts/reporting/reports.ts';
import {rankAttribute} from '../roadmark-104/src/lib/discovery.ts';

const R='/tmp/toyota-research';
const read=(f:string)=>JSON.parse(fs.readFileSync(path.join(R,f),'utf8'));
const plain=<T>(v:T):T=>JSON.parse(JSON.stringify(v));
const sha=(f:string)=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const artifactNames=['toyota-2026-10-14.json','toyota-reconciliation-2026-10-14.json','brand-model-list-reconciliation.json','residual/residual-closure.json'];
const approvedHashes=Object.fromEntries(artifactNames.map(f=>[f,sha(path.join(R,f))]));
const p=read('toyota-2026-10-14.json') as BrandUpdatePacket;
assert(!brandUpdatePackets.some(q=>q.id===p.id),'Review must occur before registration');
const rd=research(),before=catalogue();
const immutableInputs=crypto.createHash('sha256').update(JSON.stringify({rd,before,p})).digest('hex');
const existing=new Map(before.map(c=>[c.id,c]));
const toyota=before.filter(c=>c.brand==='Toyota');
assert.deepEqual(plain(toyota),read('toyota-live-before.json'));
assert.deepEqual(plain(rd.sources),read('toyota-source-before.json'));
assert.equal(toyota.length,6);assert.equal(p.variants.length,0);assert.equal(p.models.length,0);
assert.equal(p.versionGuards.length,6);assert.equal(p.availability.length,6);assert.equal(p.summaries.length,6);
const sourcesById=new Map(p.sources.map(s=>[s.id,s]));
const captureFiles=new Set<string>();let captureReferences=0;
for(const s of p.sources){
  for(const [locator,hashKey] of [['capture_locator','capture_sha256'],['capture_text_locator','capture_text_sha256']]){
    const f=(s as any)[locator];if(!f)continue;
    const location=path.resolve(R,f);assert(location.startsWith(R+'/'));assert.equal(sha(location),(s as any)[hashKey],`${s.id} capture hash`);
    captureFiles.add(f);captureReferences++;
  }
  assert((s as any).capture_locator||(s as any).capture_text_locator,`${s.id} lacks capture`);
}
for(const guard of p.versionGuards)assert.deepEqual(guard.before,brandVersionSnapshot(existing.get(guard.variantId)!));
for(const row of p.facts){assert.deepEqual(row.before??null,plain(existing.get(row.variantId)!.facts[row.after.key]??null),`${row.variantId}/${row.after.key} before`);assert(row.after.sourceIds.every(id=>sourcesById.has(id)));}
for(const term of p.brandTerms!){assert.deepEqual([...term.applicableVariantIds].sort(),toyota.map(c=>c.id).sort());for(const id of term.applicableVariantIds)assert.deepEqual(term.before[id]??null,plain(existing.get(id)!.facts[term.key]??null));}
const baselineFeatures=new Map(toyota.map(c=>[c.id,effectiveFeatures(c,rd)]));
assert.deepEqual(plain([...baselineFeatures.values()].flat()),read('toyota-feature-before.json'));
for(const row of p.features!)assert.deepEqual(row.before,plain(baselineFeatures.get(row.variantId)!.find(f=>f.criterion===row.criterion)),`${row.variantId}/${row.criterion} feature before`);
for(const row of p.availability)assert.deepEqual(row.before,plain({availability:existing.get(row.variantId)!.availability,evidence:existing.get(row.variantId)!.availabilityEvidence}));
const data=prepareBrandResearch(rd,[p]);const cars=applyBrandUpdates(before,data,[p]);
assert.deepEqual(cars.filter(c=>c.brand!=='Toyota'),before.filter(c=>c.brand!=='Toyota'),'Other-brand cars changed');
assert.deepEqual(data.sources.filter(s=>!sourcesById.has(s.id)),rd.sources,'Prior source rows changed');
const actual=compiledSource('src/lib/data.ts',{'./brand-update-registry':{brandUpdatePackets:[...brandUpdatePackets,p]}}) as {pack:typeof pack};
const packs:Record<string,ReturnType<typeof pack>>={};let factsChecked=0,featuresChecked=0,dependenciesChecked=0;
for(const car of cars.filter(c=>c.brand==='Toyota')){
  for(const {key} of coreFacts)assert.equal(car.facts[key]?.gradeReview?.overlayId,p.id,`${car.id}/${key} unreviewed`);
  const features=applyBrandTermFeatures(car,applyBrandFeatureUpdates(car,baselineFeatures.get(car.id)!,data,[p]));
  const view=actual.pack(car.id,{data,cars});packs[car.id]=view;
  assert.deepEqual(view.car,car);assert.deepEqual(view.features,features,'Actual effective feature pipeline differs');
  for(const f of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===p.id)){
    assert(hasEarnedBuyerGrade(f,data.sources,'2026-10-14'),`${car.id}/${f.key} grade`);
    const c=factClaim(view,f);assert.equal(c.buyerGrade,f.buyerGrade);assert.deepEqual(c.sources.map(s=>s.id),f.sourceIds);assert.deepEqual(c.gradeReview,f.gradeReview);factsChecked++;
  }
  for(const row of p.features!.filter(f=>f.variantId===car.id)){
    const f=features.find(f=>f.criterion===row.criterion)!;assert.deepEqual(f,row.after);assert(hasEarnedBuyerGrade(f,data.sources,'2026-10-14'));
    const claim=featureClaim(view,f.criterion,f.criterion)!;assert.deepEqual(claim.sources.map(s=>s.id),f.source_ids);assert.equal(claim.buyerGrade,f.buyerGrade);featuresChecked++;
    for(const d of row.dependencies){assert.deepEqual(car.facts[d.key],d.expected);dependenciesChecked++;}
  }
  const roadside=features.find(f=>f.criterion==='roadside_assistance')!;assert.equal(roadside.status,'optional');assert.equal(roadside.buyerGrade,'confirmed');assert.equal(car.facts.roadside_assistance.roadsideFitment,'optional');assert.deepEqual(roadside.source_ids,car.facts.roadside_assistance.sourceIds);
  assert.equal(featureClaim(view,'roadside_assistance','Roadside')!.status,'optional');
  assert.equal(car.facts.price_aud.priceEvidence!.rung,1);assert.equal(car.facts.price_aud.comparisonBasis,'Before on-road costs');
  assert.equal(car.facts.battery_defect_warranty.buyerGrade,'check');
  assert.equal(car.facts.boot_l.comparisonBasis,'','Unspecified boot load method must not rank');
  if(car.model!=='HiLux BEV'){assert.equal(car.facts.dc_charge_time_min.buyerGrade,'check');assert.equal(car.facts.dc_charge_time_min.comparisonBasis,'');}
  assert.equal(car.availabilityEvidence.physicalStockVerified,false);assert.equal(car.availabilityEvidence.factoryOrderAcceptanceVerified,false);
  assert(car.buyerSummary?.strength&&car.buyerSummary?.tradeoff);
  const price=car.facts.promotional_driveaway_aud;
  if(price?.gradeReview?.overlayId===p.id){const f=features.find(f=>f.criterion==='driveaway_price')!;assert.equal(f.gradeReview?.overlayId,p.id);assert.deepEqual(f.source_ids,price.sourceIds);}
}
assert.deepEqual(hydratePortablePacks(storePortablePacks(packs),data.sources),packs,'Portable pack roundtrip changes fields');
const selected=cars.filter(c=>c.brand==='Toyota');
const rankCounts=Object.fromEntries((['price_aud','range_km','dc_charge_time_min','seats','boot_l','towing_braked_kg'] as const).map(key=>{const r=rankAttribute(selected,data.sources,key,{asOf:'2026-10-14'});return[key,{ranked:r.groups.flatMap(g=>g.entries).length,unranked:r.unranked.length,excluded:r.excluded.length}]}));
assert.equal(rankCounts.price_aud.ranked,6);assert.equal(rankCounts.range_km.ranked,6);assert.equal(rankCounts.dc_charge_time_min.ranked,3);assert.equal(rankCounts.boot_l.ranked,0);assert.equal(rankCounts.towing_braked_kg.ranked,5);
const guarded:string[]=[];
function reject(name:string,edit:(q:BrandUpdatePacket)=>void,featureReplay=false){const q=structuredClone(p);edit(q);assert.throws(()=>{const d=prepareBrandResearch(rd,[q]);const cs=applyBrandUpdates(before,d,[q]);if(featureReplay){const c=cs.find(c=>c.id===q.features![0].variantId)!;applyBrandFeatureUpdates(c,baselineFeatures.get(c.id)!,d,[q]);}},undefined,name);guarded.push(name);}
reject('version before snapshot',q=>q.versionGuards[0].before.trim+=' changed');
reject('fact before snapshot',q=>{const r=q.facts.find(f=>f.before)!;r.before!.value='changed';});
reject('brand term complete version scope',q=>q.brandTerms![0].applicableVariantIds.pop());
reject('feature before snapshot',q=>q.features![0].before.value='changed',true);
reject('feature post-fact dependency',q=>q.features![0].dependencies[0].expected.value='changed');
reject('summary dependency',q=>q.summaries[0].strength.dependencies[0].expected.value='changed');
reject('availability before snapshot',q=>q.availability[0].before.availability='outgoing');
reject('price ladder basis',q=>q.facts.find(f=>f.after.key==='price_aud')!.after.comparisonBasis='Driveaway');
reject('optional roadside invalid enum',q=>(q.brandTerms!.find(t=>t.key==='roadside_assistance')!.fact as any).roadsideFitment='included');
reject('optional roadside on unrelated fact',q=>(q.facts.find(f=>f.after.key==='range_km')!.after as any).roadsideFitment='optional');
const reconciliation=read('toyota-reconciliation-2026-10-14.json'),lists=read('brand-model-list-reconciliation.json');
assert.equal(reconciliation.publishedLists.length,0);assert.equal(lists.globalPublishedLists.length,0);assert.equal(reconciliation.currentVersionReviews.flatMap((r:any)=>r.versions).length,6);assert.equal(lists.brandPublishedLists.length,2);
assert.equal(lists.brandPublishedLists[0].entries.length,64);assert.equal(lists.brandPublishedLists[1].entries.length,24);
for(const f of read('immutable-data-before.json'))assert.equal(sha(path.join(process.cwd(),f.path)),f.sha256,`${f.path} drift`);
assert.equal(crypto.createHash('sha256').update(JSON.stringify({rd,before,p})).digest('hex'),immutableInputs,'Input mutation');
for(const [f,h] of Object.entries(approvedHashes))assert.equal(sha(path.join(R,f)),h,'Artifact changed during review');
const result={status:'passed',reviewedAt:'2026-10-14',approvedHashes,counts:{versions:6,newVersions:p.variants.length,sources:p.sources.length,captureReferences,uniqueCaptureFiles:captureFiles.size,factEdits:p.facts.length,brandTerms:p.brandTerms!.length,citableFacts:factsChecked,features:featuresChecked,dependencies:dependenciesChecked},rankCounts,negativeGuards:guarded,actualPackPipeline:true,portableExactRoundtrip:true,otherBrandsUnchanged:true,priorSourcesUnchanged:true,immutableDataUnchanged:true,globalC1NotClaimed:true};
fs.writeFileSync(path.join(R,'independent-review-replay.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
