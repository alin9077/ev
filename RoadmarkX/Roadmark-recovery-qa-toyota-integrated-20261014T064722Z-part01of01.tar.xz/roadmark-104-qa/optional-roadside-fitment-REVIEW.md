# Optional roadside fitment: narrow M1 correction

## Result and contract

Canonical `Fact.roadsideFitment?: "standard" | "optional"` records roadside membership inclusion independently from evidence quality. A paid optional membership can retain `Fact.status: "standard"` and `buyerGrade: "confirmed"`; its guarded projected feature receives `status: "optional"`. Toyota's researcher agreed to use `roadsideFitment: "optional"` in the candidate packet.

The metadata is runtime-validated only for `roadside_assistance`; malformed explicit values (including null, undefined, booleans, unsupported strings, arrays and objects) fail closed. A missing property preserves legacy projection behavior. Complete before snapshots automatically include this metadata, so a changed or removed value requires a new reviewed replacement. Canonical roadside feature edits remain prohibited.

Evidence grades, review/source IDs, checked dates, values and exact conditions remain intact. No wording is parsed to infer fitment. Warranty and battery-warranty inheritance, sources, registry packets, ranking and caching are untouched.

## Separate safety correction: reused projection withdrawal

A previously projected roadside row is identifiable by `verification_state: "reviewed_brand_au_terms"`. If its canonical review is withdrawn, removed or absent on reuse, it must not retain a stale Confirmed grade. The correction preserves factual content, fitment, conditions and source IDs; it clears buyerGrade/gradeReview and sets `gradeReviewStatus: "review_required"`. The UI shows Needs review. A valid canonical re-review restores the reviewed projection.

Untouched source-row fallback is still returned unchanged and retains its independently established provenance. Driveaway projection/fallback is unchanged. Additional broad grade/value filters were deliberately excluded: accepted brand terms already require Confirmed/Check and non-null earned facts, and Reported evidence cannot pass the brand-term scope checks.

## Verification

- 23/23 focused brand-update tests passed on final formatted files
- 56/56 adjacent regression tests passed across brand updates, brand feature updates, retained evidence fitment, and feature-offer validity
- Final TypeScript check passed with exit 0
- Final changed-file ESLint check passed with exit 0
- Eight new behavioral tests cover paid membership, included/legacy behavior, malformed metadata, complete-snapshot drift, source/review withdrawal, reused projection withdrawal and valid re-review, canonical manual-edit rejection, and portable/evidence/render consistency
- Existing packet/registry SHA-256 checks passed; no packet was edited by this work
- No full production build or aggregate all-tests run was performed for this narrow patch

## Files and recovery

Implementation: `src/lib/types.ts`, `src/lib/brand-updates.ts`

Tests: `tests/brand-updates.test.ts`

Before copies: `optional-roadside-fitment-before/`

Patch: `optional-roadside-fitment.patch`

Hashes and check details: `optional-roadside-fitment-QA.json`

Packet baseline and verification: `optional-roadside-fitment-packets-before.sha256`, `optional-roadside-fitment-packets-check.log`
