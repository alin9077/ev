import fs from 'node:fs';
import {research,catalogue,effectiveFeatures} from '../roadmark-104/src/lib/data.ts';
import {prepareBrandResearch,applyBrandUpdates,type BrandUpdatePacket} from '../roadmark-104/src/lib/brand-updates.ts';
const R='/tmp/toyota-research/';const p=JSON.parse(fs.readFileSync(R+'toyota-2026-10-14.json','utf8')) as BrandUpdatePacket;
p.features=[];const rd=prepareBrandResearch(research(),[p]);const cs=applyBrandUpdates(catalogue(),rd,[p]);const ids=new Set(p.variants.map(v=>v.id));fs.writeFileSync(R+'new-feature-before.json',JSON.stringify(cs.filter(c=>ids.has(c.id)).flatMap(c=>effectiveFeatures(c,rd)),null,2));console.log('Captured',ids.size,'new feature baselines');
