# Ford light handoff v1

Read identity-review.md first, then current-core-proposal.json, source-index.json and configuration-update-proposal.json. This is frozen source/identity evidence for independent review, not a production BrandUpdatePacket and not a validation pass.

Three retained current rows reproduce the accepted Nissan31 raw line digests. /tmp/ford-packet/baseline-proof-v2/proof.json records exact source path, whole-file hash and line hashes. The v1 failure is preserved: stripping line terminators mismatched the accepted raw-line hashes; v2 matched with terminators.

No broad catalogue hydration, live edit, compiler retry, server, browser, archive, or release was run. Parent controls the heavy slot, typed packet preparation, staged tests, release gates and recovery.

Open work before Ford closure:
1. Review current MY26.00 versus guide MY26.50 mapping; no duplicates on current evidence
2. Research exact older MY23.75 Select/Premium technical facts and admit source-labelled residual versions if accepted; resolve 2023GT suffix and New2025SelectQ3GN exact epoch
3. Resolve Lightning manufacturer/official-importer/current-new boundary or retain explicit unresolved coverage lead
4. Bind source snapshots and exact Fact before/after objects into a typed packet; earned issue-free non-null dependencies needed to release historical nulls or global ranking hold
5. Review GT price source difference, DC vehicle-rating interpretation, and inherited September battery-warranty evidence
6. Preserve cargo protocol, mirror-width basis, gross/chemistry, towing and battery-retention unknowns; never import foreign-market values

Current proposed coverage:17core fields for each of3currentrows, including explicit towingNotPublished after maker+Australian guide. Range and named-grade technical facts Confirmed; prices/acceleration Reported; compatible rankings can be enabled narrowly. completeVehicleCountEligible must remainfalse under the existing helper. No productwide count/brandcomplete claim is made.
