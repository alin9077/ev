# Ford light audit: identity review, 15 October 2026

Research proposal only. No live catalogue change, packet admission, compiler run, full hydration, build, archive or publication occurred.

## Findings that change scope

The current Ford Australia Tier 1 BEV range is Mustang Mach-E Select, Premium and GT. The live maker overview, named-grade pages, 2026MY price page and linked brochure establish these current named versions. Select and Premium carry limited-availability wording, which is not withdrawal or residual-only evidence. An enquiry form is not order acceptance. No physical-stock promise is made.

Keep the three retained IDs and official 2026.00MY technical mapping (brochure issued 5 August 2026):
- ford_mustang_mach_e_2026_select_rwd
- ford_mustang_mach_e_2026_premium_rwd
- ford_mustang_mach_e_2026_gt_awd

RedBook additionally observes MY26.50, August 2026 release, for the same three grade names. Its Select technical identity matches 73kWh/212kW/525Nm/470km. Carsales' explicitly MY26.00 guide already has the same A$98,405 GT price and 10mm higher heights that appeared to distinguish MY26.50. Those differences therefore do not demonstrate a new purchasable configuration. Preserve the secondary half-year observation, but do not create duplicate rows solely from it. The current official 2026.00MY brochure is still linked by the live maker overview. No official supersession or distinct MY26.50 technical set was established.

There are separately advertised new older-epoch cars:
- Select MY23.75: City Ford Rockdale FN37, VIN3FMTR1R44PMB04640, explicitly New and MY23.75, 35km, A$59,990 driveaway NSW dealer advertisement. https://www.cityfordrockdale.com.au/new-cars/for-sale/ford/mustang-mach-e/2023/select/my23.75/3721010/
- Premium MY23.75: Mackay City Ford515581, VIN3FMTR3R79PMB00461, explicitly New and MY23.75,16km, build11/2023, compliance04/2024,A$77,000 driveaway QLD dealer advertisement. https://mackaycityford.com.au/515581-1570956-ford-mustangmache-2023/
- GT2023: Q Ford DRX5/D593, explicitly New,0km,build2023,A$89,000 driveaway QLD advertisements. MY suffix not stated on these exact pages. https://www.qford.com.au/cars/new-blue-2023-ford-mustang-mach-e-drx5 and https://www.qford.com.au/cars/new-blue-2023-ford-mustang-mach-e-d593 . An independently indexed Carsales New MY23.75 GT advert exists, but its older crawl does not bind Q Ford VINs to that suffix. Keep exact-MY review open.
- Additional Byrne New2023Select/Premium ads corroborate residual leads, but September-sale/expired-finance wording prevents treating the offer as current finance. No new identity is derived from the same grade at another dealer.
- Range Ford lists New2025Select Q3GN at A$75,671 driveaway WA. The detail page failed twice. Build/title year alone is not a model-year designation. Keep this lead unresolved rather than merging into MY26 or creating MY25. https://www.rangeford.com.au/models/mustang-mach-e

Proposed identity decision for independent review: retain current three; prepare separate MY23.75 Select/Premium residual admissions after their exact technical fact set is researched; keep GT2023 exact-MY and Q3GN leads explicit until bound. A clean physical-stock inspection is not a prerequisite to source-labelled released-version visibility; dealer listings support advertised availability only.

## Lightning and scope exclusions

Lightning remains unresolved under the actual manufacturer-or-official-importer boundary; see lightning-v2/disposition.json. Factory support, legal import/compliance, importer eligibility and current new-order availability are distinct. AUSEV receivership and used residual ads do not prove every eligible new route is absent.
Ranger PHEV is outside BEV scope. E-Transit/E-Transit Custom/Transit City are unchanged Tier2; no new deep research.

## Material source differences

Current brochure: Select/Premium/GT usable73/88/91kWh, range470/615/515km WLTP combined, power212/212/434kW, DC10–80%32/36/36min. Older Premium91kWh/216kW/600km and GT358kW/490km are genuine older technical epochs, not values to overwrite the current grades with.
CarExpert's29Nov2025 refresh article has current motor/battery set but Premium600km; current maker615km supersedes that historical observation for current rows.
GT reported price A$98,490 beforeORC in the older article differs from Carsales/RedBook's current guide A$98,405. Prefer the explicitly labelled current guide if reviewer accepts; preserve the older reported price and do not invent an $85 change date or maker-price claim.
Carsales heights1637/1637/1619mm differ from current maker1627/1627/1609mm; current maker controls named-grade height. CarsalesGT DC45min conflicts with current maker36min and is not adopted. These guide inconsistencies do not establish new versions.
Mackay Premium's battery-chemistry widget says LiFePO4; do not adopt this without exact technical corroboration. No chemistry inference is needed for the identity lead.

## Coverage boundary

Current three-grade 17-core proposal is separate from unresolved older-new and Lightning leads. This is not Ford C1 closure or a claim that every new Ford version is now implemented. No total count change is proposed before identity review.
