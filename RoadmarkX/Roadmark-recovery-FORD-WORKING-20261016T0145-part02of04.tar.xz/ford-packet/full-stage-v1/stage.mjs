/** Ford32 bounded full-stage preparation: no broad effective-feature replay or normal report. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {fileHash,readJson,readResearch,digestRows,assertResearchUnchanged} from '/tmp/xpeng-staging-plan/baseline-io.mjs';
import {readCompleteCars} from '/tmp/mercedes-staging-plan/staging-preparation/shape-first-v3/read-complete-storage.mjs';
import {assertDeclaredJson} from '/tmp/mercedes-staging-plan/consumer-preparation/v5/feature-json-parity.mjs';
const args=process.argv.slice(2);assert.equal(args.length,4);assert.equal(args[0],'--manifest');assert.equal(args[2],'--manifest-sha256');assert.equal(fileHash(args[1]),args[3]);
const m=readJson(args[1]),repo=m.repo,out=m.output,pins=m.pins;
assert.equal(process.cwd(),repo);assert.equal(process.env.NODE_OPTIONS,undefined);assert.equal(typeof global.gc,'function');assert.equal(process.version,m.nodeVersion);assert.deepEqual(process.execArgv,m.execArgv);
assert.equal(m.mode,'derived-prefix20-through-Nissan31-then-Ford32-no-broad-features');assert.equal(m.productionRegistrationAuthorized,false);assert.equal(m.canonicalRecaptureAuthorized,false);assert.equal(m.normalFullReportInStage,false);
function checkPins(){for(const p of pins){assert.equal(fs.statSync(p.path).size,p.bytes);assert.equal(fileHash(p.path),p.sha256,p.path);}}
checkPins();assert(!fs.existsSync(out));fs.mkdirSync(out);
function write(name,obj){fs.writeFileSync(out+'/'+name+'.json',JSON.stringify(obj,null,2)+'\n',{flag:'wx'});}
function progress(phase){const fd=fs.openSync(path.join(m.runOutput,'progress.jsonl'),'a');try{fs.writeSync(fd,JSON.stringify({at:new Date().toISOString(),phase})+'\n');fs.fsyncSync(fd);}finally{fs.closeSync(fd);}console.log(phase);}
const fieldDigests=data=>Object.fromEntries(Object.entries(data).map(([key,value])=>[key,digestRows(Array.isArray(value)?value:[value])])),carDigests=cars=>cars.map(car=>({id:car.id,...digestRows([car])}));
function fullResearchExact(data,expected,label){assertDeclaredJson(data,'/'+label,new Set());assert.deepStrictEqual(fieldDigests(data),expected);}
function fullCarsExact(cars,expected,label){assertDeclaredJson(cars,'/'+label,new Set());assert.deepStrictEqual(carDigests(cars),expected);}
progress('Restoring accepted retained409/prefix20 once');
const accepted=readJson(m.acceptedManifest.path),anchors=accepted.anchors,inputPins=new Map(accepted.inputPins.map(row=>[row.anchor+'\0'+row.file,row]));
const storageClosure=readJson(m.storageClosure.path),storagePins=new Map(storageClosure.map(pin=>[pin.path,pin])),storageReads=new Set();
assert.equal(storagePins.size,21);
const proof={anchors,assertPinned(ref){
 const pin=inputPins.get(ref.anchor+'\0'+ref.file);assert(pin);assert.equal(ref.sha256,pin.sha256);assert.equal(ref.bytes,pin.bytes);
 const absolute=path.resolve(anchors[ref.anchor],ref.file),terminalPin=storagePins.get(absolute);assert(terminalPin,'Actual retained input missing terminal pin '+absolute);
 assert.equal(terminalPin.sha256,ref.sha256);assert.equal(terminalPin.bytes,ref.bytes);assert(pins.some(pin=>pin.path===absolute&&pin.sha256===ref.sha256&&pin.bytes===ref.bytes));storageReads.add(absolute);
}};
let restored=await readCompleteCars(proof,m.storageIndex),cars=restored.cars;const index=restored.index;restored=null;
assert.equal(cars.length,409);for(const ref of Object.values(index.research))proof.assertPinned(ref);
let data=await readResearch(anchors,index,Object.keys(index.research));assert.equal(Object.keys(data).length,14);assertDeclaredJson(data,'/initialResearch',new Set());assertDeclaredJson(cars,'/initialCars',new Set());assertResearchUnchanged(data,index);assert.deepStrictEqual(data.variants.map(row=>row.id),cars.map(car=>car.id));
assert.deepStrictEqual([...storageReads].sort(),[...storagePins.keys()].sort());
write('retained-storage-read-closure',{actualReadFiles:[...storageReads].sort(),all21FilesPinnedBeforeAndAfter:true,rootStorageIndex:m.storageIndex,acceptedManifest:m.acceptedManifest});
const require=createRequire(repo+'/package.json'),brand=require('./src/lib/brand-updates.ts');
const {prepareBrandResearch,applyBrandUpdates,brandVersionSnapshot,applyBrandFeatureUpdates,applyBrandTermFeatures}=brand;
const {brandUpdatePackets}=require('./src/lib/brand-update-registry.ts');assert.equal(brandUpdatePackets.length,31);assert.deepStrictEqual(brandUpdatePackets.map(p=>p.id),m.registeredPacketIds);assert.equal(brandUpdatePackets.at(-1).id,'m1-nissan-2026-10-15');assert.deepStrictEqual(data.metadata.brand_update_packet_ids,m.registeredPacketIds.slice(0,20));
const acceptedCarStages=readJson(m.acceptedNissanCars.path),acceptedFieldStages=readJson(m.acceptedNissanFields.path),carStages={baseline20:carDigests(cars)},fieldStages={baseline20:fieldDigests(data)},transitions=[];
fullResearchExact(data,acceptedFieldStages.baseline20,'baseline20Research');fullCarsExact(cars,acceptedCarStages.baseline20,'baseline20Cars');
function compose(base,p,ids){const raw=prepareBrandResearch(base,[p]);assert.deepStrictEqual(Object.keys(raw),Object.keys(base));assert.deepStrictEqual(raw.metadata.brand_update_packet_ids,[p.id]);const result={...raw,metadata:{...raw.metadata,brand_update_packet_ids:ids}};for(const key of Object.keys(raw))if(key!=='metadata')assert.equal(result[key],raw[key]);transitions.push({packetId:p.id,beforeMetadata:digestRows([base.metadata]),rawMetadata:structuredClone(raw.metadata),composedMetadata:structuredClone(result.metadata),onlyCompositionPath:'metadata.brand_update_packet_ids'});return result;}
for(const [offset,stage,count]of [[20,'corrected21',409],[21,'current22',413],[22,'current23',413],[23,'current24',417],[24,'candidate25',427],[25,'candidate26',427],[26,'candidate27',427],[27,'candidate28',427],[28,'candidate29',430],[29,'candidate30',430],[30,'candidate31',430]]){
 const packet=brandUpdatePackets[offset],priorData=data,priorCars=cars,priorFields=fieldDigests(data),priorDigests=carDigests(cars);
 data=compose(priorData,packet,m.registeredPacketIds.slice(0,offset+1));cars=applyBrandUpdates(priorCars,data,[packet]);assert.equal(cars.length,count);assert.equal(data.variants.length,count);assert.deepStrictEqual(data.variants.map(row=>row.id),cars.map(car=>car.id));
 fullResearchExact(priorData,priorFields,'priorResearch');fullCarsExact(priorCars,priorDigests,'priorCars');
 fullResearchExact(data,acceptedFieldStages[stage],stage+'Research');fullCarsExact(cars,acceptedCarStages[stage],stage+'Cars');
 carStages[stage]=carDigests(cars);fieldStages[stage]=fieldDigests(data);global.gc();progress('Accepted '+stage+' complete-car and all14-field digests reproduced');
}



const base=data,currentCars=cars,currentFields=fieldStages.candidate31,currentDigests=carStages.candidate31;
const packetPath=m.packet.path,packet=readJson(packetPath),packetSnapshot=structuredClone(packet),expected=readJson(m.expectedReview.path);
assert.equal(fileHash(packetPath),expected.packet.sha256);assert.equal(packet.id,'m1-ford-2026-10-15');
const selected=new Set(expected.existingIds),added=new Set(expected.addedIds),allIds=new Set([...selected,...added]),modelIds=new Set(packet.versionGuards.map(g=>g.before.modelId)),before=currentCars.filter(car=>selected.has(car.id)),beforeSnapshot=structuredClone(before);
assert.equal(selected.size,3);assert.equal(added.size,3);assert.deepStrictEqual([...selected],m.selectedIds);assert.deepStrictEqual([...added],m.addedIds);assert.equal(before.length,3);assert.deepStrictEqual(before,readJson(m.selectedBefore.path));for(const id of added)assert(!currentCars.some(car=>car.id===id));
for(const prior of brandUpdatePackets){assert.notEqual(prior.brand,'Ford');for(const row of [...prior.facts,...prior.variants,...prior.versionGuards,...prior.availability,...prior.summaries,...(prior.features??[]),...(prior.configurationUpdates??[])])assert(!allIds.has(row.variantId??row.id));for(const term of prior.brandTerms??[])assert(term.applicableVariantIds.every(id=>!allIds.has(id)));}
const peerCars=currentCars.filter(car=>!selected.has(car.id)),peerIds=new Set(peerCars.map(car=>car.id));assert.equal(peerCars.length,427);
const sourceIdsAdded=new Set(packet.sources.map(source=>source.id));assert.equal(sourceIdsAdded.size,27);assert.equal(packet.sources.length,27);assert.equal(packet.facts.length,121);assert.equal(packet.models.length,0);assert.equal(packet.variants.length,3);
const sourceReferenceProof=[];
function inspectSourceReferences(value,label,pointer=''){if(typeof value==='string'){assert(!sourceIdsAdded.has(value),'New source already referenced '+label+pointer);return;}if(!value||typeof value!=='object')return;for(const [key,item]of Object.entries(value)){assert(!sourceIdsAdded.has(key),'New source already a dictionary key '+label+pointer);inspectSourceReferences(item,label,pointer+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));}}
for(const [label,value]of [['accepted complete research',base],['accepted complete cars',currentCars],['accepted packets',brandUpdatePackets]]){inspectSourceReferences(value,label);sourceReferenceProof.push({input:label,newSourceReferences:0,nestedGradeReviewsAndKeysIncluded:true});}
for(const pin of m.rawOverlayInputs){inspectSourceReferences(require(pin.path),pin.path);sourceReferenceProof.push({input:pin.path,sha256:pin.sha256,newSourceReferences:0,nestedGradeReviewsAndKeysIncluded:true});}
write('source-reference-neutrality',{peerCars:427,helperChanges:false,sourceRowsAdded:27,inspections:sourceReferenceProof,broadFeatureReplay:false});
function retainFordResearch(input,ids){return {...input,models:input.models.filter(row=>modelIds.has(row.id)),variants:input.variants.filter(row=>ids.has(row.id)),feature_evidence_variant_context:input.feature_evidence_variant_context.filter(row=>ids.has(row.id)),feature_evidence:input.feature_evidence.filter(row=>ids.has(row.variant_id)),trim_equipment:input.trim_equipment.filter(row=>ids.has(row.variant_id)),update_eligibility:input.update_eligibility.filter(row=>ids.has(row.variant_id))};}
const selectedBase=retainFordResearch(base,selected),selectedBaseFields=fieldDigests(selectedBase);assert.equal(selectedBase.variants.length,3);assert.equal(selectedBase.feature_evidence.length,207);
const {compiledSource}=require('./tests/helpers/compiled-source.ts');
const actualAvailability=require('./src/lib/availability-corrections.ts');
// Observe the private real newVariantCar result at its actual pre-availability boundary.
// No reconstructed zero-fact Car and no guessed new-availability baseline may satisfy this proof.
let capturedBuilderCars=null,probeAvailabilityCalls=0;
const probeBrand=compiledSource('src/lib/brand-updates.ts',{'./availability-corrections':{...actualAvailability,applyAvailabilityCorrections(cars,edits,sources){probeAvailabilityCalls++;assert.equal(probeAvailabilityCalls,1);capturedBuilderCars=structuredClone(cars);for(const car of cars.filter(c=>added.has(c.id)))assert.deepStrictEqual(car.facts,{});return actualAvailability.applyAvailabilityCorrections(cars,edits,sources);}}});
const probePacket={...structuredClone(packet),facts:[],brandTerms:[],features:[],configurationUpdates:[],summaries:[]};
const probePacketSnapshot=structuredClone(probePacket);
const probeData=probeBrand.prepareBrandResearch(selectedBase,[probePacket]),probeDataSnapshot=structuredClone(probeData);
const probeAfter=probeBrand.applyBrandUpdates(before,probeData,[probePacket]);
assert.equal(probeAvailabilityCalls,1);assert(capturedBuilderCars);assert.equal(capturedBuilderCars.length,6);assert.equal(probeAfter.length,6);
const additionBuilderProof=[];
for(const id of added){const raw=capturedBuilderCars.find(c=>c.id===id),declared=packet.availability.find(a=>a.variantId===id).before;assert.deepStrictEqual(raw.facts,{});assert.deepStrictEqual({availability:raw.availability,evidence:raw.availabilityEvidence},declared);assert.deepStrictEqual(declared,expected.additionDeclaredAvailabilityBefore[id]);assert.deepStrictEqual(raw.configurationEvidence,packet.variants.find(v=>v.id===id).configuration_evidence);additionBuilderProof.push({variantId:id,actualProducer:'src/lib/brand-updates.ts private newVariantCar, intercepted at actual applyAvailabilityCorrections boundary before unknownFacts',facts:raw.facts,availabilityBefore:{availability:raw.availability,evidence:raw.availabilityEvidence},version:brandVersionSnapshot(raw),zeroFactsVerified:true,declaredAvailabilityGuardExact:true});}
fullResearchExact(base,currentFields,'baseResearch');fullResearchExact(selectedBase,selectedBaseFields,'selectedBaseResearch');assert.deepStrictEqual(before,beforeSnapshot);assert.deepStrictEqual(probePacket,probePacketSnapshot);assert.deepStrictEqual(probeData,probeDataSnapshot);
const guardCars=new Map(capturedBuilderCars.map(c=>[c.id,c]));

const selectedPrepared=prepareBrandResearch(selectedBase,[packet]),selectedPreparedFields=fieldDigests(selectedPrepared);
data=compose(base,packet,[...m.registeredPacketIds,packet.id]);cars=applyBrandUpdates(currentCars,data,[packet]);
assertDeclaredJson(data,'/candidateResearchBeforeDigest',new Set());assertDeclaredJson(cars,'/candidateCarsBeforeDigest',new Set());
const candidateFields=fieldDigests(data),candidateDigests=carDigests(cars),after=cars.filter(car=>allIds.has(car.id)),afterSnapshot=structuredClone(after);
assert.equal(cars.length,433);assert.equal(data.variants.length,433);assert.equal(after.length,6);assert.deepStrictEqual(after,readJson(m.selectedAfter.path));
fullResearchExact(base,currentFields,'baseResearch');fullCarsExact(currentCars,currentDigests,'currentCars');fullResearchExact(selectedPrepared,selectedPreparedFields,'selectedPreparedResearch');
assert.deepStrictEqual(data.sources.slice(0,base.sources.length),base.sources);assert.deepStrictEqual(data.sources.slice(base.sources.length),packet.sources);
const changedResearchFields=['metadata','sources','variants','feature_evidence_variant_context','feature_evidence','trim_equipment','update_eligibility'];
for(const key of Object.keys(base))if(!changedResearchFields.includes(key))assert.deepStrictEqual(data[key],base[key],key);
const expectedMetadata={...base.metadata,added_variant_count:Number(base.metadata.added_variant_count??0)+3,added_feature_row_count:Number(base.metadata.added_feature_row_count??0)+207,brand_update_packet_ids:[...m.registeredPacketIds,packet.id]};assert.deepStrictEqual(data.metadata,expectedMetadata);
assert.deepStrictEqual(data.variants.map(row=>row.id),[...base.variants.map(row=>row.id),...added]);
for(let i=0;i<base.variants.length;i++){
 const old=base.variants[i],availability=packet.availability.find(row=>row.variantId===old.id),configuration=packet.configurationUpdates.find(row=>row.variantId===old.id);
 const expectedVariant={...old,...(configuration?{configuration_evidence:configuration.after}:{}),...(availability?{record_state:availability.after.availability,availability_evidence:availability.after.evidence}:{})};assert.deepStrictEqual(data.variants[i],expectedVariant);
}
for(const key of ['variants','feature_evidence_variant_context','feature_evidence','trim_equipment','update_eligibility']){
 const count=key==='feature_evidence'?207:3,identifier=['variants','feature_evidence_variant_context'].includes(key)?'id':'variant_id';
 assert.equal(data[key].length,base[key].length+count);
 if(key!=='variants')assert.deepStrictEqual(data[key].slice(0,base[key].length),base[key]);
 assert.deepStrictEqual(data[key].slice(base[key].length),selectedPrepared[key].filter(row=>added.has(row[identifier])));
}
assert.deepStrictEqual(cars.map(car=>car.id),[...currentCars.map(car=>car.id),...added]);assert.deepStrictEqual(cars.filter(car=>peerIds.has(car.id)),peerCars);
assert.deepStrictEqual(candidateDigests.filter(row=>peerIds.has(row.id)),currentDigests.filter(row=>peerIds.has(row.id)));
const currentById=new Map(currentDigests.map(row=>[row.id,row])),changedIds=candidateDigests.filter(row=>currentById.has(row.id)&&row.sha256!==currentById.get(row.id).sha256).map(row=>row.id);assert.deepStrictEqual(new Set(changedIds),selected);assert.deepStrictEqual(candidateDigests.filter(row=>!currentById.has(row.id)).map(row=>row.id),[...added]);
const unchangedPeers=427,reads=Object.entries(currentFields).map(([field,ref])=>({field,inputRows:ref.rows,retainedRows:ref.rows,sha256:ref.sha256,scope:'Full accepted structural research composition; effective feature replay only for three refreshed and three added Ford cars'}));
assert.equal(packet.versionGuards.length,3);assert.equal(packet.brandTerms.reduce((n,t)=>n+t.applicableVariantIds.length,0),18);assert.equal(packet.availability.length,6);assert.equal(packet.summaries.length,6);
for(const guard of packet.versionGuards)assert.deepStrictEqual(brandVersionSnapshot(before.find(c=>c.id===guard.variantId)),guard.before);
for(const edit of packet.facts){assert.deepStrictEqual(guardCars.get(edit.variantId).facts[edit.after.key]??null,edit.before);assert.deepStrictEqual(after.find(c=>c.id===edit.variantId).facts[edit.after.key],edit.after);}
for(const term of packet.brandTerms)for(const id of term.applicableVariantIds){assert.deepStrictEqual(guardCars.get(id).facts[term.key]??null,term.before[id]);assert.deepStrictEqual(after.find(c=>c.id===id).facts[term.key],term.fact);}
const untouchedFactProof=[];
for(const car of after){const prior=before.find(c=>c.id===car.id);if(!prior)continue;const updatedKeys=new Set(packet.facts.filter(e=>e.variantId===car.id).map(e=>e.after.key));for(const t of packet.brandTerms)if(t.applicableVariantIds.includes(car.id))updatedKeys.add(t.key);const exactKeys=[...new Set([...Object.keys(prior.facts),...updatedKeys])].sort();assert.deepStrictEqual(Object.keys(car.facts).sort(),exactKeys);const untouched=Object.keys(prior.facts).filter(k=>!updatedKeys.has(k));for(const key of untouched)assert.deepStrictEqual(car.facts[key],prior.facts[key]);untouchedFactProof.push({variantId:car.id,untouchedKeys:untouched.sort(),fullKeySetExact:true,untouchedFactObjectsExact:true});assert.deepStrictEqual(brandVersionSnapshot(car),brandVersionSnapshot(prior));}
const mutable=new Set(['rankingEligible','projectionScope','sourceIds','requiredBuyerVisibleConditions','requiredNulls','countContribution','configurationReview']);
for(const edit of packet.configurationUpdates){const b=before.find(c=>c.id===edit.variantId),a=after.find(c=>c.id===edit.variantId);assert.deepStrictEqual(b.configurationEvidence,edit.before);assert.deepStrictEqual(a.configurationEvidence,edit.after);assert.deepStrictEqual(Object.fromEntries(Object.entries(edit.before).filter(([k])=>!mutable.has(k))),Object.fromEntries(Object.entries(edit.after).filter(([k])=>!mutable.has(k))));assert.equal(edit.before.rankingEligible,false);assert.equal(edit.after.rankingEligible,true);assert.equal(edit.after.completeVehicleCountEligible,false);assert.deepStrictEqual(Object.keys(edit.before.requiredNulls).filter(k=>!(k in edit.after.requiredNulls)).sort(),['dc_peak_kw','price_aud','zero_to_100_s']);for(const k of ['current_manufacturer_base_price_aud','current_manufacturer_driveaway_price_aud','current_national_price_aud'])assert.deepStrictEqual(edit.after.requiredNulls[k],edit.before.requiredNulls[k]);for(const d of edit.dependencies)assert.deepStrictEqual(a.facts[d.key],d.expected);}
for(const edit of packet.availability){const b=guardCars.get(edit.variantId),a=after.find(c=>c.id===edit.variantId);assert.deepStrictEqual({availability:b.availability,evidence:b.availabilityEvidence},edit.before);assert.deepStrictEqual({availability:a.availability,evidence:a.availabilityEvidence},edit.after);}
for(const edit of packet.summaries){const car=after.find(c=>c.id===edit.variantId);for(const side of ['strength','tradeoff']){assert.equal(car.buyerSummary[side].label,edit[side].label);assert.equal(car.buyerSummary[side].text,edit[side].text);for(const d of edit[side].dependencies){assert.deepStrictEqual(car.facts[d.key],d.expected);assert.notEqual(d.expected.value,null);assert.deepStrictEqual(d.expected.issues,[]);}const fresh=edit[side].dependencies.flatMap(({expected:f})=>[f.date,...f.sourceIds.map(id=>data.sources.find(s=>s.id===id).accessed_date)].map(checkedAt=>({checkedAt,key:f.key,...(f.modelYearChangedAt?{modelYearChangedAt:f.modelYearChangedAt}:{})})));assert.deepStrictEqual(car.buyerSummary[side].freshness,fresh);assert.deepStrictEqual(car.buyerSummary[side].sourceIds,[...new Set(edit[side].dependencies.flatMap(d=>d.expected.sourceIds))]);}const ids=[...new Set(['strength','tradeoff'].flatMap(side=>edit[side].dependencies.flatMap(d=>d.expected.sourceIds)))];assert.deepStrictEqual(car.buyerSummary.guardSourceIds,ids);assert.deepStrictEqual(car.buyerSummary.expectedSourceSnapshots,packet.sources.filter(s=>ids.includes(s.id)));assert.deepStrictEqual(car.buyerSummary.conditions,edit.conditions);assert.deepStrictEqual(car.configurationEvidence.requiredBuyerVisibleConditions,edit.conditions);}
const negativeResearch=retainFordResearch(data,allIds);assert.equal(negativeResearch.variants.length,6);assert.equal(negativeResearch.feature_evidence.length,414);
const negativeProof=[];
function rejectMutation(name,mutate,pattern){const input={cars:structuredClone(before),research:structuredClone(negativeResearch),packet:structuredClone(packet)};mutate(input);const snap=structuredClone(input);let error;try{applyBrandUpdates(input.cars,input.research,[input.packet]);}catch(e){error=e;}assert(error instanceof Error,name+' accepted');assert.match(error.message,pattern,name+' wrong rejection');assert.deepStrictEqual(input,snap);negativeProof.push({name,actualError:error.message,expectedErrorPattern:pattern.source,rejected:true,inputsUnchanged:true});global.gc();}
rejectMutation('exact identity',({packet:p})=>{p.versionGuards[0].before.trim+=' changed';},/Brand update: reviewed version changed:/);
rejectMutation('retained fact beforeguard',({packet:p})=>{p.facts[0].before.qualifications.push('changed');},/Brand update: fact before snapshot changed:.*\/price_aud$/);
rejectMutation('new fact zero baseline',({packet:p})=>{p.facts.find(f=>added.has(f.variantId)).before={...p.facts[0].after};},/Brand update: fact before snapshot changed:/);
rejectMutation('shared warranty beforeguard',({packet:p})=>{p.brandTerms[0].before[p.versionGuards[0].variantId].value='changed';},/Brand update: fact before snapshot changed:.*\/warranty$/);
rejectMutation('addition availability baseline',({packet:p})=>{p.availability.find(a=>added.has(a.variantId)).before.evidence.stockStatus='new_stock_listed';},/Availability correction conflict .*reviewed snapshot changed or variant missing/);
rejectMutation('summary exact dependency',({packet:p})=>{p.summaries[0].strength.dependencies[0].expected.value=999;},/Brand update: summary dependency changed:.*\/range_km$/);
rejectMutation('source exact snapshot',({packet:p})=>{p.sources[0].title+=' changed';},/Brand update: source snapshot changed:/);
rejectMutation('earned grade provenance',({packet:p})=>{p.facts.find(f=>f.after.key==='range_km').after.gradeReview.overlayId='wrong';},/Brand update: invalid fact or unearned grade: range_km/);
rejectMutation('configuration beforeguard',({packet:p})=>{p.configurationUpdates[0].before.projectionScope+=' changed';},/Brand update: configuration before snapshot changed:/);
rejectMutation('frozen complete count',({packet:p})=>{p.configurationUpdates[0].after.completeVehicleCountEligible=true;},/Brand update: configuration historical source\/build boundary changed:/);
rejectMutation('maker price hold cannot use guide alias',({packet:p})=>{const c=p.configurationUpdates[0];delete c.after.requiredNulls.current_manufacturer_base_price_aud;c.after.configurationReview.releasedNulls.push({key:'current_manufacturer_base_price_aud',factKeys:['price_aud']});},/Brand update: configuration null release proof has wrong measurement:/);
assert.equal(negativeProof.length,11);
let defaultCalls=0;const forbidden=()=>{defaultCalls++;throw new Error('FORBIDDEN_DEFAULT_CATALOGUE_LOADER');};
const defaults={sourceResearch:forbidden,research:forbidden,catalogue:forbidden};
const factory=packets=>compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets:packets}}).createEvidenceConsumers(defaults);
const initial=factory(brandUpdatePackets),final=factory([...brandUpdatePackets,packet]);
const {hasEarnedBuyerGrade}=require('./src/lib/evidence-grading.ts');
const {factClaim,featureClaim,makeReport,reportMarkdown}=require('./src/lib/citable.ts');
const {availabilityReportClaim}=actualAvailability;
const {buyerAvailabilityText}=require('./src/lib/buyer-availability.ts');
const {isOnSale,isCurrentListEligible,isTierOne,buildCoverageReport}=require('./scripts/reporting/reports.ts');
const {auditedFeature}=require('./src/lib/launch-evidence.ts');
const {applyFeatureRegrading}=require('./src/lib/evidence-regrading.ts');
const beforePacks={},afterPacks={},observations=[],claims=[],featureClaims=[],claimOmissions=[],producerProofs=[],frames=new Map();
for(const [phase,cars,consumer,research,packets]of [['before',before,initial,base,brandUpdatePackets],['after',after,final,data,[...brandUpdatePackets,packet]]])for(const car of cars){const input=consumer.sourceEffectiveFeatures(car,research),snap=structuredClone(input),regraded=applyFeatureRegrading(car,input,research.sources);assert.deepStrictEqual(input,snap);const branded=applyBrandFeatureUpdates(car,regraded,research,packets),projected=applyBrandTermFeatures(car,branded,research.sources);frames.set(phase+'\0'+car.id,{input,regraded,branded,projected,research});producerProofs.push({phase,variantId:car.id,producer:'Actual sourceEffectiveFeatures -> applyFeatureRegrading -> applyBrandFeatureUpdates -> applyBrandTermFeatures',inputRows:input.length,outputRows:projected.length,inputUnchanged:true});}
for(const id of added){const rows=data.feature_evidence.filter(f=>f.variant_id===id);assert.equal(rows.length,69);for(const row of rows)for(const key of ['buyerGrade','gradeReview','gradeReviewStatus','condition_label','confirmation_needed'])assert(!Object.hasOwn(row,key));const raw=rows.find(f=>f.criterion==='novated_fbt'),snap=structuredClone(raw),audited=auditedFeature(raw);assert.deepStrictEqual(raw,snap);const d=Object.getOwnPropertyDescriptor(audited,'confirmation_needed');assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);producerProofs.push({variantId:id,producer:'Actual prepareBrandResearch generated 69 rows and auditedFeature raw novated_fbt branch',generatedOptionalFieldsAbsent:true,rawNovatedRow:raw,auditedNovatedOwnUndefined:true});}
function observePack(car,pack,phase){
 const pointers=[];
 function visit(value,pointer){
  if(value===undefined){
   const match=pointer.match(/\/features\/(\d+)\/([^/]+)$/);assert(match,'Unexpected undefined outside feature: '+pointer);
   const rowIndex=Number(match[1]),property=match[2],feature=pack.features[rowIndex],descriptor=Object.getOwnPropertyDescriptor(feature,property);
   assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value')&&descriptor.value===undefined);
   const frame=frames.get(phase+'\0'+car.id),sourceRow=frame.input.find(f=>f.criterion===feature.criterion),regraded=frame.regraded.find(f=>f.criterion===feature.criterion),projected=frame.projected.find(f=>f.criterion===feature.criterion);
   assert(sourceRow&&regraded&&projected);assert.deepEqual(feature,projected);
   let producer;
   if(property==='gradeReviewStatus'){
    assert(feature.gradeReview);assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts earned retained-feature branch explicitly sets gradeReviewStatus undefined';
   }else if(property==='condition_label'){
    assert.equal(feature.buyerGrade,'check');assert(!Object.hasOwn(sourceRow,property)||sourceRow[property]===undefined);assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts Check branch retains source optional condition_label';
   }else if(property==='confirmation_needed'){
    assert.equal(feature.criterion,'novated_fbt');
    for(const row of [sourceRow,regraded]){const d=Object.getOwnPropertyDescriptor(row,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);}
    const raw=frame.research.feature_evidence.find(f=>f.variant_id===car.id&&f.criterion===feature.criterion);assert(raw);
    const snap=structuredClone(raw),audited=auditedFeature(raw);assert.deepEqual(raw,snap);
    const d=Object.getOwnPropertyDescriptor(audited,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);
    producer='launch-evidence.ts actual auditedFeature(raw exact novated_fbt row) creates confirmation_needed undefined';
   }else if(['buyerGrade','gradeReview'].includes(property)){
    assert.equal(feature.gradeReviewStatus,'review_required');assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts unmatched retained-feature branch withdraws optional review';
   }else assert.fail('Unclassified optional undefined: '+pointer);
   observations.push({phase,variantId:car.id,pointer,rowIndex,criterion:feature.criterion,property,ownUndefined:true,enumerable:true,producer,sourceProperty:{own:Object.hasOwn(sourceRow,property),valueKind:sourceRow[property]===undefined?'undefined':typeof sourceRow[property]},regradedProperty:{own:Object.hasOwn(regraded,property),valueKind:regraded[property]===undefined?'undefined':typeof regraded[property]},actualFinalProjectionMatched:true});
   pointers.push(pointer);return;
  }
  if(!value||typeof value!=='object')return;
  for(const key of Object.keys(value))visit(value[key],pointer+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));
 }
 visit(pack,'/packs/'+car.id);assertDeclaredJson(pack,'/packs/'+car.id,new Set(pointers));
}
function observeClaim(claim,pack,pointer,replay,record=true){
 assert.deepEqual(replay(),claim,'Actual citable producer replay must match');
 const clone=structuredClone(claim),pointers=[];
 function visit(value,path){
  if(value===undefined){
   const match=path.match(/\/sources\/(\d+)\/(limitation|checked)$/);assert(match,'Unclassified citable undefined: '+path);
   const i=Number(match[1]),key=match[2],citation=claim.sources[i],source=pack.sources.find(s=>s.id===citation.id);assert(source);
   const d=Object.getOwnPropertyDescriptor(citation,key);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);
   assert(!source[key==='limitation'?'access_limitation':'full_text_checked_date']);
   pointers.push(path);if(record)claimOmissions.push({pointer:path,sourceId:source.id,property:key,ownUndefined:true,enumerable:true,producer:'Actual citable.ts citations() falsey source-metadata branch; actual factClaim/featureClaim replay matches'});
   delete clone.sources[i][key];return;
  }
  if(!value||typeof value!=='object')return;
  for(const key of Object.keys(value))visit(value[key],path+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));
 }
 visit(claim,pointer);assertDeclaredJson(claim,pointer,new Set(pointers));assert.deepEqual(JSON.parse(JSON.stringify(claim)),clone);return clone;
}

for(const car of before){const pack=initial.pack(car.id,{data:base,cars:before});beforePacks[car.id]=pack;assert.equal(pack.features.length,69);observePack(car,pack,'before');}
let earnedCells=0,roadsideRefreshes=0,driveawayRefreshes=0;const gradeCounts={},availabilityClaims=[];
for(const car of after){
 const pack=final.pack(car.id,{data,cars:after});afterPacks[car.id]=pack;assert.equal(pack.features.length,69);assert.equal(new Set(pack.features.map(f=>f.criterion)).size,69);observePack(car,pack,'after');
 for(const feature of pack.features){
  if(feature.criterion==='roadside_assistance'){const f=car.facts.roadside_assistance;assert.equal(feature.value,String(f.value));assert.equal(feature.buyerGrade,'confirmed');assert.equal(feature.status,'standard');assert.equal(feature.verification_state,'reviewed_brand_au_terms');assert.deepStrictEqual(feature.source_ids,f.sourceIds);for(const q of f.qualifications)assert(feature.conditions.includes(q));roadsideRefreshes++;}
  else if(feature.criterion==='driveaway_price'&&added.has(car.id)&&car.facts.price_aud.value!==null){const f=car.facts.price_aud;assert.equal(f.comparisonBasis,'Driveaway');assert.equal(feature.value,`A$${Number(f.value).toLocaleString('en-AU')}`);assert.equal(feature.buyerGrade,'reported');assert.deepStrictEqual(feature.source_ids,f.sourceIds);assert.equal(feature.verification_state,'reviewed_canonical_driveaway_price');driveawayRefreshes++;}
  else if(selected.has(car.id))assert.deepStrictEqual(feature,beforePacks[car.id].features.find(f=>f.criterion===feature.criterion),'Unrelated retained feature changed: '+car.id+'/'+feature.criterion);
  else assert(['not_verified','not_applicable'].includes(feature.status),'Unreviewed new equipment was promoted: '+car.id+'/'+feature.criterion);
 }
 for(const f of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===packet.id)){assert(hasEarnedBuyerGrade(f,data.sources,packet.reviewedAt));const claim=factClaim(pack,f,packet.reviewedAt);assert.equal(claim.buyerGrade,f.buyerGrade);assert.deepStrictEqual(claim.sources.map(s=>s.id),f.sourceIds);if(f.buyerGrade==='not_published'){assert.equal(f.value,null);assert.equal(claim.value,'Not published');}observeClaim(claim,pack,'/claims/'+claims.length+'/claim',()=>factClaim(pack,f,packet.reviewedAt));claims.push({variantId:car.id,key:f.key,claim});earnedCells++;}
 for(const feature of pack.features){const claim=featureClaim(pack,feature.criterion,feature.criterion,packet.reviewedAt);assert.deepStrictEqual(claim.sources.map(s=>s.id),[...new Set(feature.source_ids)]);observeClaim(claim,pack,'/feature-claims/'+featureClaims.length+'/claim',()=>featureClaim(pack,feature.criterion,feature.criterion,packet.reviewedAt));featureClaims.push({variantId:car.id,criterion:feature.criterion,claim});}
 const residualGT=car.id===expected.residualGT;assert.equal(isOnSale(car),!residualGT);assert.equal(isCurrentListEligible(car,data.sources,packet.reviewedAt),!residualGT);assert.equal(buyerAvailabilityText(car),residualGT?'Not confirmed':'On sale now');
 assert.equal(car.availabilityEvidence.physicalStockVerified,false);assert.equal(car.availabilityEvidence.factoryOrderAcceptanceVerified,false);
 for(const key of expected.coreKeys){const f=car.facts[key];assert(hasEarnedBuyerGrade(f,data.sources,packet.reviewedAt));gradeCounts[f.buyerGrade]=(gradeCounts[f.buyerGrade]??0)+1;}
 const claim=factClaim(pack,availabilityReportClaim(car),packet.reviewedAt);observeClaim(claim,pack,'/availability-claims/'+availabilityClaims.length+'/claim',()=>factClaim(pack,availabilityReportClaim(car),packet.reviewedAt));availabilityClaims.push({variantId:car.id,claim});assert.deepStrictEqual(claim.sources.map(s=>s.id),car.availabilityEvidence.sourceIds);
 assert.equal(car.facts.boot_l.value,402);assert.equal(car.facts.boot_l.buyerGrade,'confirmed');assert.equal(car.facts.boot_l.comparisonBasis,'Behind second row to package tray; method not stated');assert.equal(car.facts.width_mm.buyerGrade,'confirmed');assert.equal(car.facts.width_mm.comparisonBasis,'Overall width; mirror basis unknown');
 if(selected.has(car.id)){assert.equal(car.configurationEvidence.rankingEligible,true);assert.equal(car.configurationEvidence.completeVehicleCountEligible,false);assert.equal(car.facts.price_aud.buyerGrade,'reported');assert.equal(car.facts.price_aud.priceEvidence.rankingEligible,false);}
}
assert.equal(earnedCells,139);assert.equal(featureClaims.length,414);assert.equal(roadsideRefreshes,6);assert.equal(driveawayRefreshes,2);assert.equal(after.filter(isOnSale).length,5);assert.equal(after.filter(isOnSale).length-before.filter(isOnSale).length,2);
const {exclusionReason,rankAttribute,attributes}=require('./src/lib/discovery.ts');const policy={asOf:packet.reviewedAt},rankingProof=[],rankCounts={};
for(const attribute of attributes){const ranks=rankAttribute(after,data.sources,attribute.key,policy),ranked=ranks.groups.flatMap(g=>g.entries.map(e=>e.car.id));assert.deepStrictEqual(new Set(ranked),new Set(expected.rankingIds[attribute.key]));assert.equal(ranks.excluded.length,6-ranked.length);for(const group of ranks.groups)for(const entry of group.entries){assert.equal(entry.fact.comparisonBasis,group.basis);assert.equal(entry.fact.unit,group.unit);}rankCounts[attribute.key]={ranked,excluded:ranks.excluded};}
for(const car of after){for(const key of ['boot_l','price_aud','towing_braked_kg']){const reason=exclusionReason(car,car.facts[key],data.sources,policy);assert(reason);if(key==='boot_l'&&car.id!==expected.residualGT)assert.equal(reason,'Cargo measurement method is not established');rankingProof.push({variantId:car.id,key,reason});}if(car.id!==expected.residualGT){assert.equal(exclusionReason(car,car.facts.range_km,data.sources,policy),null);assert.equal(exclusionReason(car,car.facts.dc_charge_time_min,data.sources,policy),null);}else for(const k of ['range_km','dc_charge_time_min','seats'])assert.equal(exclusionReason(car,car.facts[k],data.sources,policy),'Not current/order-listed or evidenced outgoing new stock');}
for(const o of observations.filter(x=>x.phase==='after'&&selected.has(x.variantId))){assert(!['roadside_assistance'].includes(o.criterion));const prior=observations.find(x=>x.phase==='before'&&x.pointer===o.pointer&&x.criterion===o.criterion&&x.property===o.property);assert(prior,'Retained omission lacks exact before witness');if(o.property==='gradeReviewStatus')assert.deepStrictEqual(afterPacks[o.variantId].features[o.rowIndex].gradeReview,beforePacks[o.variantId].features[o.rowIndex].gradeReview);}
const {compareFacts}=require('./src/lib/compare.ts');const comparisonProof=[];
function pairCheck(a,b,key,state){const left=a.facts[key],right=b.facts[key],result=compareFacts(left,right);assert.equal(result.state,state,a.id+'/'+b.id+'/'+key);if(state==='comparable'){assert.equal(result.delta,right.value-left.value);}else{assert(!Object.hasOwn(result,'delta'));assert.equal(result.delta,undefined);}comparisonProof.push({left:a.id,right:b.id,key,leftBasis:left.comparisonBasis,rightBasis:right.comparisonBasis,result});}
for(let i=0;i<after.length;i++)for(let j=i;j<after.length;j++){const a=after[i],b=after[j];for(const k of ['boot_l','width_mm'])pairCheck(a,b,k,'different_basis');for(const k of ['range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','power_kw','length_mm','height_mm'])pairCheck(a,b,k,'comparable');pairCheck(a,b,'towing_braked_kg','unknown');pairCheck(a,b,'seats',added.has(a.id)||added.has(b.id)?'conditional':'comparable');pairCheck(a,b,'price_aud',a.facts.price_aud.value===null||b.facts.price_aud.value===null?'unknown':'conditional');pairCheck(a,b,'zero_to_100_s','conditional');}
assert.equal(comparisonProof.length,294);
const crossBasisProof=[];
for(const car of after.filter(c=>added.has(c.id))){for(const k of ['frunk_l','cargo_behind_first_row_roof_l','cargo_behind_second_row_roof_l']){const result=compareFacts(car.facts[k],car.facts[k]);assert.equal(result.state,'different_basis');assert(!Object.hasOwn(result,'delta'));crossBasisProof.push({variantId:car.id,key:k,result});}}
assert.equal(crossBasisProof.length,9);
const reconciliation=readJson(m.reconciliation.path),allInventory=require('./src/lib/market-inventory-data.ts').default;
const inventory={...allInventory,records:allInventory.records.filter(r=>r.brand==='Ford'&&(!r.vehicleClass||['passenger','ute'].includes(r.vehicleClass))),unverifiedLeads:allInventory.unverifiedLeads.filter(r=>r.brand==='Ford'&&(!r.vehicleClass||['passenger','ute'].includes(r.vehicleClass)))};
const {buildMarketReconciliation,inventoryRecordId}=require('./scripts/reporting/m1-reconciliation.ts');
assert.deepStrictEqual(new Set(inventory.records.map(inventoryRecordId)),new Set(expected.inventoryIds));assert.equal(inventory.unverifiedLeads.length,0);
for(const review of reconciliation.currentVersionReviews)for(const v of review.versions){const c=after.find(c=>c.id===v.carId);assert(c);assert.equal(c.modelId,review.modelId);assert.equal(c.trim,v.trim);assert.equal(c.year,v.modelYear);}
const eligible=after.filter(c=>isCurrentListEligible(c,data.sources,packet.reviewedAt));assert.equal(eligible.length,5);
const c1=buildMarketReconciliation(reconciliation,eligible,inventory,packet.reviewedAt);assert.equal(c1.pass,false);assert.deepStrictEqual(c1.settledInventory,[]);assert.equal(c1.reviewedModels,1);assert.equal(c1.reviewedVersions,3);assert.deepStrictEqual(new Set(c1.reviewedVersionIds),selected);assert(!c1.issues.some(i=>i.code==='version_review'));assert.deepStrictEqual(new Set(c1.issues.filter(i=>i.code==='version_unreviewed').map(i=>i.reference)),new Set(expected.residualOnSaleIds));assert.equal(c1.issues.filter(i=>i.code==='inventory_unresolved').length,2);assert(c1.issues.some(i=>i.code==='independent_lists'));
const selectedCoverage=buildCoverageReport({cars:after,sources:data.sources,features:Object.values(afterPacks).flatMap(p=>p.features),inventory,m1Reconciliation:reconciliation},packet.reviewedAt);assert.equal(selectedCoverage.allCatalogueVersions,6);assert.equal(selectedCoverage.tierOneVersions,6);assert.equal(selectedCoverage.onSaleVersions,5);const selectedBrandProgress=selectedCoverage.brandProgress.find(b=>b.brand==='Ford');assert(selectedBrandProgress);assert.equal(selectedBrandProgress.unreviewedCoreGrades,0);assert.equal(selectedBrandProgress.missingSummaries,0);assert.equal(selectedBrandProgress.criteria.C1,false);
const {storePortablePacks,hydratePortablePacks}=require('./src/lib/portable-packs.ts');
const snapshot=structuredClone(afterPacks),writtenExpected=structuredClone(afterPacks);
const stored=storePortablePacks(afterPacks);
assert.deepStrictEqual(afterPacks,snapshot);
assert.deepEqual(hydratePortablePacks(stored,data.sources),afterPacks);
for(const o of observations.filter(x=>x.phase==='after')){const row=writtenExpected[o.variantId].features[o.rowIndex];assert(Object.hasOwn(row,o.property));assert.equal(row[o.property],undefined);delete row[o.property];}
assert.deepEqual(JSON.parse(JSON.stringify(afterPacks)),writtenExpected);
assert.deepEqual(hydratePortablePacks(JSON.parse(JSON.stringify(stored)),data.sources),writtenExpected);assert.deepEqual(afterPacks,snapshot);
for(const [name,obj]of Object.entries({'selected-after-cars':after,'selected-packs':afterPacks,portable:stored,claims,'feature-claims':featureClaims,'availability-claims':availabilityClaims,'undefined-witnesses':observations,'claim-undefined-witnesses':claimOmissions}))fs.writeFileSync(out+'/'+name+'.json',JSON.stringify(obj,null,2)+'\n',{flag:'wx'});
const writtenPacks=readJson(out+'/selected-packs.json'),hydrated=hydratePortablePacks(readJson(out+'/portable.json'),data.sources);
assert.deepEqual(writtenPacks,writtenExpected);assert.deepEqual(hydrated,writtenExpected);
// Actual citable producers must agree for live packs and serialized/re-hydrated packs.
for(const row of claims){const fact=after.find(c=>c.id===row.variantId).facts[row.key];assert.deepEqual(factClaim(hydrated[row.variantId],fact,packet.reviewedAt),row.claim);}
for(const row of featureClaims)assert.deepEqual(featureClaim(hydrated[row.variantId],row.criterion,row.criterion,packet.reviewedAt),row.claim);
for(const row of availabilityClaims)assert.deepEqual(factClaim(hydrated[row.variantId],availabilityReportClaim(after.find(c=>c.id===row.variantId)),packet.reviewedAt),row.claim);
for(const [name,rows]of [['claims',claims],['feature-claims',featureClaims],['availability-claims',availabilityClaims]]){
 const written=readJson(out+'/'+name+'.json');
 for(let i=0;i<rows.length;i++){
  const pack=afterPacks[rows[i].variantId],replay=()=>name==='claims'?factClaim(pack,after.find(c=>c.id===rows[i].variantId).facts[rows[i].key],packet.reviewedAt):name==='availability-claims'?factClaim(pack,availabilityReportClaim(after.find(c=>c.id===rows[i].variantId)),packet.reviewedAt):featureClaim(pack,rows[i].criterion,rows[i].criterion,packet.reviewedAt);
  const clone=observeClaim(rows[i].claim,pack,'/'+name+'/'+i+'/claim',replay,false);assert.deepEqual(written[i],{...rows[i],claim:clone});
 }
}
const reportProof=[];
for(const car of after){
 const pack=afterPacks[car.id],path='/cars/'+car.family+'/'+car.slug,report=makeReport([pack],path,packet.reviewedAt),markdown=reportMarkdown(report);
 assert.deepEqual(makeReport([hydrated[car.id]],path,packet.reviewedAt),report);assert.equal(reportMarkdown(makeReport([writtenPacks[car.id]],path,packet.reviewedAt)),markdown);
 fs.writeFileSync(out+'/'+car.id+'-report.md',markdown,{flag:'wx'});assert.equal(fs.readFileSync(out+'/'+car.id+'-report.md','utf8'),markdown);
 reportProof.push({variantId:car.id,path,markdownFile:out+'/'+car.id+'-report.md',actualLiveWrittenHydratedReportEqual:true});
}
assert.equal(defaultCalls,0);for(const f of ['src/lib/data.ts','src/lib/catalogue.ts','src/lib/research.ts'])assert(!require.cache[repo+'/'+f]);
fullResearchExact(base,currentFields,'baseResearch');assert.deepStrictEqual(before,beforeSnapshot);fullResearchExact(data,candidateFields,'candidateResearch');assert.deepStrictEqual(after,afterSnapshot);assert.deepStrictEqual(packet,packetSnapshot);assert.deepStrictEqual(afterPacks,snapshot);checkPins();

const result={status:'selected_actual_consumers_and_exact_serialization_witness_pass',packetSha256:fileHash(packetPath),beforeCars:3,afterCars:6,coreCells:102,coreGradeCounts:gradeCounts,earnedPacketCells:earnedCells,selectedFeatureClaims:featureClaims.length,roadsideRefreshes,driveawayRefreshes,additionBuilderProof,reportProof,otherRetainedFeaturesUnchanged:true,readInputs:reads,currentListProof:c1,selectedCoverage,rankingProof,rankCounts,untouchedFactProof,comparisonProof,crossBasisProof,negativeProof,producerProofs,optionalFeaturePaths:observations,optionalCitationPaths:claimOmissions,inMemoryPortableExact:true,writtenPortableExact:true,writtenClaimReadback:true,livePacksUnchanged:true,productionCatalogueHydration:false,defaultLoaderCalls:defaultCalls,sourceEdits:false,scopeTargetNeutrality:{selectedTierOneOnly:true,tierTwoTargets:0,nonFordTargets:0,fullCataloguePeerEquality:'NOT RUN; later full-stage gate'},expectedOnSaleDelta:2,fullProjectTypeScript:'UNPASSED; no compiler retry'};
assert.deepStrictEqual(buildMarketReconciliation(reconciliation,eligible,inventory,packet.reviewedAt),c1);assert.deepStrictEqual(selectedCoverage.reconciliation,c1);
const resultSnapshot=structuredClone(result),resultWritten=structuredClone(result),reportOmissions=[];
function reportShape(value,path,clone,parent){if(value===undefined){assert(/\/(brand|reference)$/.test(path),'Unexpected report undefined: '+path);const issue=c1.issues.find(i=>i.code==='independent_lists');assert(issue);assert.deepStrictEqual(parent,issue);assert.deepStrictEqual(Object.keys(issue).sort(),['brand','code','reason','reference']);const property=path.split('/').at(-1),d=Object.getOwnPropertyDescriptor(parent,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);reportOmissions.push({pointer:path,property,ownUndefined:true,enumerable:true,producer:'Actual buildMarketReconciliation independent_lists issue, exact replay; absent optional brand/reference'});return;}if(!value||typeof value!=='object')return;for(const key of Object.keys(value)){reportShape(value[key],path+'/'+key.replaceAll('~','~0').replaceAll('/','~1'),clone?.[key],value);if(value[key]===undefined)delete clone[key];}}
reportShape(result,'/result',resultWritten,null);assertDeclaredJson(result,'/result',new Set(reportOmissions.map(x=>x.pointer)));assert.deepStrictEqual(JSON.parse(JSON.stringify(result)),resultWritten);assert.deepStrictEqual(result,resultSnapshot);
fs.writeFileSync(out+'/report-undefined-witnesses.json',JSON.stringify(reportOmissions,null,2)+'\n',{flag:'wx'});fs.writeFileSync(out+'/addition-builder-proof.json',JSON.stringify(additionBuilderProof,null,2)+'\n',{flag:'wx'});fs.writeFileSync(out+'/result.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});assert.deepStrictEqual(readJson(out+'/result.json'),resultWritten);assert.deepStrictEqual(result,resultSnapshot);fullResearchExact(base,currentFields,'baseResearch');assert.deepStrictEqual(before,beforeSnapshot);fullResearchExact(data,candidateFields,'candidateResearch');assert.deepStrictEqual(after,afterSnapshot);assert.deepStrictEqual(packet,packetSnapshot);assert.deepStrictEqual(afterPacks,snapshot);checkPins();progress('Six selected packs,139 fact/term claims,414 feature claims,303 comparison cases and eleven guard rejections proved');
const acceptedSelected=readJson(m.selectedResult.path);assert.equal(acceptedSelected.status,'selected_actual_consumers_and_exact_serialization_witness_pass');assert.equal(acceptedSelected.packetSha256,m.packet.sha256);
for(const [name,pin]of Object.entries(m.selectedArtifacts))assert.equal(fileHash(out+'/'+name),pin.sha256,'Exact selected written artifact '+name);
const acceptedWrittenPacks=readJson(m.selectedArtifacts['selected-packs.json'].path);
const acceptedWrittenClaims=readJson(m.selectedArtifacts['claims.json'].path),acceptedWrittenFeatureClaims=readJson(m.selectedArtifacts['feature-claims.json'].path),acceptedAvailabilityClaims=readJson(m.selectedArtifacts['availability-claims.json'].path);
assert.deepEqual(claims,acceptedWrittenClaims.map(row=>({variantId:row.variantId,key:row.key,claim:factClaim(acceptedWrittenPacks[row.variantId],acceptedWrittenPacks[row.variantId].car.facts[row.key],m.asOf)})));
assert.deepEqual(featureClaims,acceptedWrittenFeatureClaims.map(row=>({variantId:row.variantId,criterion:row.criterion,claim:featureClaim(acceptedWrittenPacks[row.variantId],row.criterion,row.criterion,m.asOf)})));
assert.deepEqual(availabilityClaims,acceptedAvailabilityClaims.map(row=>({variantId:row.variantId,claim:factClaim(acceptedWrittenPacks[row.variantId],availabilityReportClaim(acceptedWrittenPacks[row.variantId].car),m.asOf)})));
assert.deepEqual(observations,acceptedSelected.optionalFeaturePaths);assert.deepEqual(claimOmissions,acceptedSelected.optionalCitationPaths);assert.deepEqual(readJson(out+'/result.json').selectedCoverage,acceptedSelected.selectedCoverage);assert.deepEqual(comparisonProof,acceptedSelected.comparisonProof);assert.deepEqual(negativeProof,acceptedSelected.negativeProof);assert.deepEqual(crossBasisProof,acceptedSelected.crossBasisProof);assert.deepEqual(additionBuilderProof,acceptedSelected.additionBuilderProof);assert.deepEqual(untouchedFactProof,acceptedSelected.untouchedFactProof);
// Full structural ranking comparison: peers stay exact inside compatible groups; whole groups may move.
const discoverySource=fs.readFileSync(repo+'/src/lib/discovery.ts','utf8');
const comparatorSource='(a, b) =>\n        b.entries.length - a.entries.length || a.basis.localeCompare(b.basis)';
assert.equal(discoverySource.split(comparatorSource).length,2,'Unique production group-sort expression');
const groupCompare=(a,b)=>b.entries.length-a.entries.length||a.basis.localeCompare(b.basis);
const groupKey=group=>JSON.stringify([group.vehicleClass,group.basis,group.unit]);
const alphabeticalSource='unranked.sort((a, b) =>\n    `${a.car.brand} ${a.car.model} ${a.car.trim}`.localeCompare(\n      `${b.car.brand} ${b.car.model} ${b.car.trim}`,\n    ),\n  );';
assert.equal(discoverySource.split(alphabeticalSource).length,2,'Unique production unranked alphabetical comparator');
const alphabetical=(a,b)=>`${a.car.brand} ${a.car.model} ${a.car.trim}`.localeCompare(`${b.car.brand} ${b.car.model} ${b.car.trim}`);
function rankingRecords(ranking,digests){
 const byId=new Map(digests.map(row=>[row.id,row]));
 function entryRecord(entry){const {car,...fields}=entry;const digest=byId.get(car.id);assert(digest);assert.deepEqual({id:car.id,...digestRows([car])},digest);return {carId:car.id,carDigest:{...digest},...fields};}
 return {groups:ranking.groups.map(group=>({...group,entries:group.entries.map(entryRecord)})),excluded:ranking.excluded.map(row=>{const digest=byId.get(row.carId);assert(digest);return {...row,carDigest:{...digest}};}),unranked:ranking.unranked.map(entryRecord)};
}
const globalRankProof=[];
function groupProof(ranking,inputCars,attribute){
 const byKey=new Map(ranking.groups.map(group=>[groupKey(group),group]));assert.equal(byKey.size,ranking.groups.length);
 const memberGroup=new Map();for(const group of ranking.groups)for(const entry of group.entries){assert(!memberGroup.has(entry.car.id));memberGroup.set(entry.car.id,groupKey(group));assert.deepStrictEqual(entry.fact,entry.car.facts[attribute.key]);}
 const insertionKeys=[];for(const car of inputCars){const key=memberGroup.get(car.id);if(key&&!insertionKeys.includes(key))insertionKeys.push(key);}
 assert.equal(insertionKeys.length,ranking.groups.length);
 const predicted=insertionKeys.map(key=>byKey.get(key)).sort(groupCompare);assert.deepStrictEqual(predicted.map(groupKey),ranking.groups.map(groupKey));
 for(const group of ranking.groups){
  const ordered=[...group.entries].sort((a,b)=>(Number(a.fact.value)-Number(b.fact.value))*(attribute.direction==='lower'?1:-1)||a.car.id.localeCompare(b.car.id));
  assert.deepStrictEqual(ordered.map(row=>row.car.id),group.entries.map(row=>row.car.id));
  for(const row of group.entries){const value=Number(row.fact.value);assert.equal(row.rank,group.entries.findIndex(entry=>Number(entry.fact.value)===value)+1);assert.equal(row.tied,group.entries.filter(entry=>Number(entry.fact.value)===value).length>1);}
 }
 return {insertionKeys,sortedKeys:ranking.groups.map(groupKey),groups:ranking.groups.map(group=>({key:groupKey(group),count:group.entries.length,ids:group.entries.map(row=>row.car.id),selectedIds:group.entries.filter(row=>allIds.has(row.car.id)).map(row=>row.car.id),peerIds:group.entries.filter(row=>peerIds.has(row.car.id)).map(row=>row.car.id)}))};
}
for(const attribute of attributes){
 const old=rankAttribute(currentCars,base.sources,attribute.key,policy),next=rankAttribute(cars,data.sources,attribute.key,policy),selectedRanking=rankAttribute(after,data.sources,attribute.key,policy);
 const buckets=new Map();
 for(const group of old.groups){const entries=group.entries.filter(row=>peerIds.has(row.car.id));if(entries.length)buckets.set(groupKey(group),{...group,entries});}
 for(const group of selectedRanking.groups){const key=groupKey(group),prior=buckets.get(key);if(prior)prior.entries.push(...group.entries);else buckets.set(key,{...group,entries:[...group.entries]});}
 const memberGroup=new Map();for(const [key,group]of buckets)for(const entry of group.entries){assert(!memberGroup.has(entry.car.id));memberGroup.set(entry.car.id,key);}
 const insertionKeys=[];for(const car of cars){const key=memberGroup.get(car.id);if(key&&!insertionKeys.includes(key))insertionKeys.push(key);}
 const expectedGroups=insertionKeys.map(key=>buckets.get(key));
 for(const group of expectedGroups){
  group.entries.sort((a,b)=>(Number(a.fact.value)-Number(b.fact.value))*(attribute.direction==='lower'?1:-1)||a.car.id.localeCompare(b.car.id));
  group.entries=group.entries.map(entry=>({...entry,rank:group.entries.findIndex(row=>Number(row.fact.value)===Number(entry.fact.value))+1,tied:group.entries.filter(row=>Number(row.fact.value)===Number(entry.fact.value)).length>1}));
 }
 expectedGroups.sort(groupCompare);assert.deepEqual(next.groups,expectedGroups,'Complete compatible groups equal unchanged peer entries plus exact selected entries');
 const exclusionById=new Map([...old.excluded.filter(row=>peerIds.has(row.carId)),...selectedRanking.excluded].map(row=>[row.carId,row]));
 const expectedExcluded=cars.filter(car=>exclusionById.has(car.id)).map(car=>exclusionById.get(car.id));assert.deepEqual(next.excluded,expectedExcluded,'Complete exclusions preserve actual catalogue traversal order');
 const expectedUnranked=[...old.unranked.filter(row=>peerIds.has(row.car.id)),...selectedRanking.unranked].sort(alphabetical);assert.deepEqual(next.unranked,expectedUnranked,'Complete unranked entries equal unchanged peers plus selected, in verified alphabetical order');
 const beforeRecords=rankingRecords(old,currentDigests),afterRecords=rankingRecords(next,candidateDigests),selectedRecords=rankingRecords(selectedRanking,candidateDigests);
 assertDeclaredJson(beforeRecords,'/beforeRankingRecords',new Set());assertDeclaredJson(afterRecords,'/afterRankingRecords',new Set());assertDeclaredJson(selectedRecords,'/selectedRankingRecords',new Set());
 const a=groupProof(old,currentCars,attribute),b=groupProof(next,cars,attribute),aBy=new Map(a.groups.map(group=>[group.key,group])),bBy=new Map(b.groups.map(group=>[group.key,group]));
 for(const key of new Set([...aBy.keys(),...bBy.keys()])){
  const oldGroup=aBy.get(key),newGroup=bBy.get(key),oldPeers=oldGroup?.peerIds??[],newPeers=newGroup?.peerIds??[];
  assert.deepEqual(newPeers,oldPeers,'Peer order within compatible group '+attribute.key+'/'+key);
  assert.equal(newGroup?.count??0,(oldGroup?.count??0)-(oldGroup?.selectedIds.length??0)+(newGroup?.selectedIds.length??0));
 }
 assert.deepEqual(next.excluded.filter(row=>peerIds.has(row.carId)),old.excluded.filter(row=>peerIds.has(row.carId)));
 assert.deepEqual(next.unranked.filter(row=>peerIds.has(row.car.id)),old.unranked.filter(row=>peerIds.has(row.car.id)));
 assert.deepEqual(new Set(b.groups.flatMap(group=>group.selectedIds)),new Set(expected.rankingIds[attribute.key]));
 globalRankProof.push({attribute:attribute.key,completeOrderedBefore:beforeRecords,completeOrderedAfter:afterRecords,completeSelectedRecords:selectedRecords,fullGroupsEqualUnchangedPeersPlusSelected:true,fullExcludedInCatalogueOrder:true,fullUnrankedEqualAlphabeticalPeersPlusSelected:true,productionAlphabeticalComparator:alphabeticalSource,fullCarDigestBindingsVerified:true,before:a,after:b,peerExclusions:next.excluded.filter(row=>peerIds.has(row.carId)),peerMembershipAndWithinGroupOrderExact:true,productionGroupComparator:comparatorSource,insertionTiesProvedFromActualInputOrder:true,selectedCountDeltasExact:true});
}
write('global-ranking-comparison',globalRankProof);
// Actual global C1 only: mirror current loader imports without running its full loader.
const actualPaths=[...fs.readFileSync(repo+'/scripts/reporting/load.ts','utf8').matchAll(/import \w+ from "(\.\.\/\.\.\/data\/m1-[^"]+\.json)";/g)].map(match=>path.resolve(repo+'/scripts/reporting',match[1]));assert.deepEqual(actualPaths,m.reconciliationInputs.map(pin=>pin.path));assert.equal(actualPaths.length,31);
const {combineM1Reconciliations}=require('./scripts/reporting/m1-reconciliation.ts');
const baseReconciliation=combineM1Reconciliations(...m.reconciliationInputs.map(pin=>require(pin.path)));
const baselineC1=buildMarketReconciliation(baseReconciliation,currentCars.filter(isTierOne).filter(car=>isCurrentListEligible(car,base.sources,m.asOf)),allInventory,m.asOf);
const acceptedStageGlobal=readJson(m.acceptedNissanC1.path).after,acceptedReport=readJson(m.acceptedNormalReport.path),normalTerminal=readJson(m.acceptedNormalTerminal.path);assert.equal(normalTerminal.exitCode,0);assert.equal(normalTerminal.stdoutSha256,m.acceptedNormalReport.sha256);
const fixtureRegistry={schemaVersion:1,checkedAt:m.asOf,publishedLists:[],currentVersionReviews:[],listResolutions:[],inventoryResolutions:[],catalogueOnlyDifferences:[]},fixtureInventory={records:[],unverifiedLeads:[]};
const fixture=buildMarketReconciliation(fixtureRegistry,[],fixtureInventory,m.asOf);assert.deepEqual(fixture.issues.map(issue=>issue.code),['independent_lists','empty_catalogue']);
const producedIssue=fixture.issues[0],issueOwnership=[];assert.deepEqual(Object.keys(producedIssue).sort(),['brand','code','reason','reference']);
for(const property of ['brand','reference']){const descriptor=Object.getOwnPropertyDescriptor(producedIssue,property);assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value'));assert.equal(descriptor.value,undefined);issueOwnership.push({property,ownUndefined:true,enumerable:true,producer:'Actual buildMarketReconciliation fixture add(code,reason)'});}
function c1Written(live,label){const snapshot=structuredClone(live),clone=structuredClone(live),indices=live.issues.map((issue,index)=>issue.code==='independent_lists'?index:-1).filter(index=>index>=0);assert.equal(indices.length,1);const index=indices[0],issue=live.issues[index];assert.deepEqual(issue,producedIssue);const allowed=new Set();for(const property of ['brand','reference']){assert.deepEqual(Object.getOwnPropertyDescriptor(issue,property),Object.getOwnPropertyDescriptor(producedIssue,property));allowed.add('/'+label+'/issues/'+index+'/'+property);delete clone.issues[index][property];}assertDeclaredJson(live,'/'+label,allowed);assert.deepEqual(JSON.parse(JSON.stringify(live)),clone);assert.deepEqual(live,snapshot);return clone;}
const baselineWritten=c1Written(baselineC1,'baselineC1');assert.deepEqual(baselineWritten,acceptedStageGlobal);assert.deepEqual(baselineWritten,acceptedReport.reconciliation);
const expectedLive=structuredClone(acceptedStageGlobal),independentIndex=expectedLive.issues.findIndex(issue=>issue.code==='independent_lists');expectedLive.issues[independentIndex]=producedIssue;assert.deepEqual(baselineC1,expectedLive);
const proposedReconciliation=combineM1Reconciliations(baseReconciliation,reconciliation),globalC1=buildMarketReconciliation(proposedReconciliation,cars.filter(isTierOne).filter(car=>isCurrentListEligible(car,data.sources,m.asOf)),allInventory,m.asOf);


assert.equal(baselineC1.reviewedModels,106);assert.equal(baselineC1.reviewedVersions,242);assert.equal(baselineC1.issues.length,187);assert.equal(baselineC1.settledInventory.length,65);assert.equal(globalC1.reviewedModels,107);assert.equal(globalC1.reviewedVersions,245);assert.equal(globalC1.registryValid,true);assert.equal(globalC1.pass,false);
const fordInventoryRefs=['record:ford-mustang-mach-e','record:ford-f-150-lightning'];
const nonFordIssue=issue=>issue.brand!=='Ford'&&!allIds.has(issue.reference)&&!fordInventoryRefs.includes(issue.reference);
assert.deepStrictEqual(globalC1.issues.filter(nonFordIssue),baselineC1.issues.filter(nonFordIssue));
assert.deepStrictEqual(baselineC1.issues.filter(issue=>!nonFordIssue(issue)).map(issue=>issue.reference),[...selected,...fordInventoryRefs]);
assert.deepStrictEqual(globalC1.issues.filter(issue=>!nonFordIssue(issue)).map(issue=>issue.reference),[...expected.residualOnSaleIds,...fordInventoryRefs]);
assert.equal(currentCars.length,430);assert.equal(currentCars.filter(isTierOne).length,353);assert.equal(currentCars.filter(isTierOne).filter(isOnSale).length,312);assert.equal(cars.length,433);assert.equal(cars.filter(isTierOne).length,356);assert.equal(cars.filter(isTierOne).filter(isOnSale).length,314);
const expectedGlobalEvidence=structuredClone(baselineWritten.evidence);assert.deepStrictEqual(Object.keys(expectedGlobalEvidence).sort(),Object.keys(reconciliation).sort());expectedGlobalEvidence.checkedAt=[baselineWritten.evidence.checkedAt,reconciliation.checkedAt].sort().at(-1);
for(const key of ['notes','publishedLists','currentVersionReviews','listResolutions','catalogueOnlyDifferences','inventoryResolutions'])expectedGlobalEvidence[key]=[...baselineWritten.evidence[key],...reconciliation[key]];
assert.deepStrictEqual(proposedReconciliation,expectedGlobalEvidence);
const expectedIssues=baselineWritten.issues.filter(issue=>!(issue.code==='version_unreviewed'&&selected.has(issue.reference))),residualIssues=c1.issues.filter(issue=>issue.code==='version_unreviewed');assert.deepStrictEqual(residualIssues.map(issue=>issue.reference),expected.residualOnSaleIds);
const lastVersionIndex=expectedIssues.map((issue,index)=>issue.code==='version_unreviewed'?index:-1).filter(index=>index>=0).at(-1);assert(Number.isInteger(lastVersionIndex));expectedIssues.splice(lastVersionIndex+1,0,...residualIssues);
const expectedGlobalWritten={...structuredClone(baselineWritten),registryCheckedAt:expectedGlobalEvidence.checkedAt,reviewedModels:107,reviewedVersions:245,reviewedVersionIds:[...baselineWritten.reviewedVersionIds,...m.selectedIds],validModelReviewIds:[...baselineWritten.validModelReviewIds,...reconciliation.currentVersionReviews.map(review=>review.id)],issues:expectedIssues,evidence:expectedGlobalEvidence};
assert.deepStrictEqual(expectedGlobalWritten.settledInventory,baselineWritten.settledInventory);assert.equal(expectedGlobalWritten.issues.length,186);
const globalWritten=c1Written(globalC1,'globalC1');assert.deepStrictEqual(globalWritten,expectedGlobalWritten,'Complete proposed C1 equality, all counters, exact issue order and evidence arrays');
assert.equal(reconciliation.currentVersionReviews.length,1);assert.deepStrictEqual(reconciliation.currentVersionReviews[0].versions.map(v=>v.carId),[...selected]);assert(reconciliation.inventoryResolutions.every(row=>row.outcome==='unresolved'));assert.deepStrictEqual(reconciliation.inventoryResolutions.map(row=>row.inventoryId),['ford-mustang-mach-e','ford-f-150-lightning']);assert(reconciliation.notes.some(note=>note.includes('Q3GN')||note.includes('2025 Select')));assert(reconciliation.notes.some(note=>note.includes('Lightning')&&note.includes('unresolved')));assert(!globalC1.reviewedVersionIds.includes(expected.residualGT));
const dispositions=readJson(m.dispositions.path);assert.equal(dispositions.currentIdentities.length,3);assert.equal(dispositions.newResidualCandidates.length,3);
write('baseline-global-c1',baselineC1);write('global-c1-comparison',{before:baselineWritten,after:globalWritten,expectedCompleteAfter:expectedGlobalWritten,completeExpectedWrittenEquality:true,baselineMatchesAcceptedNissanAndNormal:true,nonFordIssuesReviewsDispositionsExact:true,issueOwnership,normalFullReportRun:false,currentMakerGradesReviewed:3,residualOnSaleMembershipUnresolved:expected.residualOnSaleIds,residualGTVisibleUnconfirmed:expected.residualGT,unresolvedFordInventory:fordInventoryRefs,Q3GNUnresolved:true,LightningImporterAndAvailabilityUnresolved:true});
progress('Global compatible-group rankings and complete expected C1 gaps proved without broad features');
fullResearchExact(base,currentFields,'baseResearch');fullCarsExact(currentCars,currentDigests,'currentCars');fullResearchExact(data,candidateFields,'candidateResearch');fullCarsExact(cars,candidateDigests,'candidateCars');assert.deepStrictEqual(before,beforeSnapshot);assert.deepStrictEqual(after,afterSnapshot);assert.deepStrictEqual(packet,packetSnapshot);assert.deepStrictEqual(afterPacks,snapshot);assert.equal(defaultCalls,0);
for(const file of ['src/lib/data.ts','src/lib/catalogue.ts','src/lib/research.ts','scripts/reporting/load.ts'])assert(!require.cache[repo+'/'+file]);checkPins();
write('metadata-composition',transitions);write('car-digest-comparison',{...carStages,candidate32:candidateDigests});write('research-field-digests',{...fieldStages,candidate32:candidateFields});
write('stage-receipt',{status:'bounded_structural_selected_stage_pass_pending_independent_review',manifestSha256:args[3],packetSha256:m.packet.sha256,originalBaselineCars:409,acceptedCurrentCars:430,stagedCars:433,tierOneVersions:356,onSaleVersions:314,untouchedPeerCars:427,changedRetainedCars:3,newModels:0,newVersions:3,versionUpdates:0,configurationUpdates:3,manualFeatureUpdates:0,sourceRowsAdded:27,allAcceptedStagesThroughNissan31ExactlyReproduced:true,all14ResearchFieldsProved:true,strictJsonShapeBeforeDigest:true,all21RetainedStorageFilesPinnedBeforeAndAfter:true,completeGlobalC1ExpectedEquality:true,actualSelectedCars:6,actualFactAndTermClaims:earnedCells,actualFeatureClaims:featureClaims.length,roadsideCanonicalProjections:6,driveawayCanonicalProjections:2,pairComparisonCases:comparisonProof.length,crossBasisComparisonCases:crossBasisProof.length,untouchedFactCars:untouchedFactProof.length,intendedNegativeRejections:negativeProof.length,actualZeroFactAdditionGuardProof:true,actualOptionalWitnessesExact:true,inMemoryPortableExact:true,writtenPortableExact:true,writtenClaimReadback:true,selectedC1:c1Written(c1,'selectedC1'),globalC1Counts:{reviewedModels:globalC1.reviewedModels,reviewedVersions:globalC1.reviewedVersions,issues:globalC1.issues.length,settledInventory:globalC1.settledInventory.length,pass:globalC1.pass},sourceAdditionsDoNotReviveAcceptedReferences:true,allPeerDigestsAndIdentitiesExact:true,peerOrderExactWithinCompatibleRankingGroups:true,productionGroupSortingAndInsertionTieProvenance:true,broadFeatureReplay:false,normalFullReportRun:false,normalFullReportRequiredAfterGuardedIntegration:true,defaultLoaderCalls:defaultCalls,liveSourceEdits:false,productionRegistration:false,currentProjectTypeScript:'UNPASSED; no compiler retry',resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log(JSON.stringify({status:'passed',receipt:out+'/stage-receipt.json',sha256:fileHash(out+'/stage-receipt.json'),noBroadFeatureReplay:true}));
