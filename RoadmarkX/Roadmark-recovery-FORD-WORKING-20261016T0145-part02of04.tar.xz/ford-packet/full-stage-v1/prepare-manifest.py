from pathlib import Path
import json,hashlib,re,ast,shutil,sys
O=Path('/tmp/ford-packet/full-stage-v1');R=Path('/workspace/scratch/586427eef9f2/roadmark-104');S=Path('/tmp/ford-packet/selected-readiness-v1');M=Path('/tmp/ford-packet/candidate-v4');N=Path('/tmp/nissan-packet/full-stage-v1')
review=Path(sys.argv[1]);assert review.is_file()
def pin(path):
 path=Path(path);h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return dict(path=str(path),bytes=path.stat().st_size,sha256=h.hexdigest())
def write(name,value):
 with (O/name).open('x') as f:f.write(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
for p in O.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
syntax=json.loads((O/'syntax-only-check.json').read_text());assert syntax['exitCode']==0 and syntax['runtimeExecuted'] is False and syntax['typescriptCompilerAttempted'] is False;assert syntax['scriptSha256']==pin(O/'stage.mjs')['sha256']
old=json.loads((N/'manifest.json').read_text());registry=json.loads((R/'data/m1-brand-updates/registry.json').read_text());ids=['m1-'+name.removesuffix('.json') for name in registry['packets']];assert len(ids)==31 and ids[-1]=='m1-nissan-2026-10-15'
packet=json.loads((M/'ford-2026-10-15.json').read_text());result=json.loads((S/'result.json').read_text());assert result['status']=='selected_actual_consumers_and_exact_serialization_witness_pass'
selectedIds=[g['variantId'] for g in packet['versionGuards']];addedIds=[v['id'] for v in packet['variants']];assert len(set(selectedIds))==3 and len(set(addedIds))==3
files={Path(p['path']) for p in json.loads((S/'source-pins.json').read_text())}
files.update(Path(p['path']) for p in old['pins'] if p['path'].startswith(str(R)) or p['path'].startswith(('/tmp/mercedes-staging-plan/','/tmp/xpeng-staging-plan/')))
refs=dict(acceptedManifest=old['acceptedManifest'],storageClosure=pin(O/'storage-read-closure.json'),packet=pin(M/'ford-2026-10-15.json'),reconciliation=pin('/tmp/ford-packet/reconciliation-v1/m1-ford-market-reconciliation-2026-10-15.json'),dispositions=pin(M/'source-identity-review.json'),expectedReview=pin(S/'expected-review.json'),selectedBefore=pin('/tmp/ford-research/retained-before-cars-v1.json'),selectedAfter=pin(S/'selected-after-cars.json'),selectedResult=pin(S/'result.json'),selectedTerminal=pin(S/'run/terminal.json'),selectedReadiness=pin('/tmp/ford-review/selected-readiness-v1-review/manifest.json'),selectedOutputReview=pin(review),acceptedNissanCars=pin(N/'output/car-digest-comparison.json'),acceptedNissanFields=pin(N/'output/research-field-digests.json'),acceptedNissanC1=pin(N/'output/global-c1-comparison.json'),acceptedNissanReceipt=pin(N/'output/stage-receipt.json'),acceptedNissanTerminal=pin(N/'run/terminal.json'),acceptedNormalReport=pin('/tmp/nissan-packet/report-comparison-plan-v2/normal-coverage-asof-2026-10-15/stdout.log'),acceptedNormalTerminal=pin('/tmp/nissan-packet/report-comparison-plan-v2/normal-coverage-asof-2026-10-15/terminal.json'),script=pin(O/'stage.mjs'),wrapper=pin(O/'run.py'))
names=[n+'.json' for n in ['selected-after-cars','selected-packs','portable','claims','feature-claims','availability-claims','undefined-witnesses','claim-undefined-witnesses','report-undefined-witnesses','addition-builder-proof']]+[id+'-report.md' for id in selectedIds+addedIds]
artifacts={name:pin(S/name) for name in names}
reconciliationPaths=[(R/'scripts/reporting'/name).resolve() for name in re.findall(r'import \w+ from "(\.\./\.\./data/m1-[^"]+\.json)";',(R/'scripts/reporting/load.ts').read_text())];assert len(reconciliationPaths)==31
reconciliationInputs=[pin(p) for p in reconciliationPaths];rawInputs=[pin(p['path']) for p in old['rawOverlayInputs']]
files.update(Path(p['path']) for p in [*refs.values(),*artifacts.values(),*reconciliationInputs,*rawInputs]);files.update(p for p in O.glob('*') if p.is_file());files.update([R/'scripts/reporting/load.ts',S/'run/after-pins.json',S/'prepared-command.json',S/'source-pins.json',S/'output-manifest.json',N/'manifest.json',N/'full-stage-result-manifest-v1.json',N/'stage.mjs',N/'compose-stage.py',Path('/tmp/nissan-review/full-stage-v1-results-v1.json'),Path('/tmp/nissan-review/report-comparison-v2-results-v1.json')])
files.update(p for p in (S/'run').glob('*') if p.is_file());files.update(R/'data/m1-brand-updates'/name for name in registry['packets'])
files.update(Path(p['path']) for p in json.loads((S/'output-manifest.json').read_text())['files'])
# The selected reviewer bundle is retained as a named frozen acceptance input, including its members.
rj=json.loads(review.read_text())
for row in rj.get('files',[]):
 if isinstance(row,dict) and 'path' in row:files.add(Path(row['path']))
closure=json.loads((O/'storage-read-closure.json').read_text());assert len(closure)==21
accepted=json.loads(Path(old['acceptedManifest']['path']).read_text());acceptedPins={(str((Path(accepted['anchors'][row['anchor']])/row['file']).resolve()),row['bytes'],row['sha256']) for row in accepted['inputPins']}
for row in closure:
 assert pin(row['path'])==row;assert (row['path'],row['bytes'],row['sha256']) in acceptedPins;files.add(Path(row['path']))
queue=[p for p in files if p.suffix in ['.ts','.tsx','.mts','.mjs'] and (str(p).startswith(str(R)) or p.parent==O)];seen=set();edges=[];external=set()
while queue:
 p=queue.pop()
 if p in seen:continue
 seen.add(p)
 pattern=r'''(?:from\s*|import\s*\(?\s*|require\(\s*|compiledSource\(\s*)["']([^"']+)["']'''
 for spec in re.findall(pattern,p.read_text()):
  if spec.startswith('@/'):root=R/'src'/spec[2:]
  elif spec.startswith(('./src/','./tests/','./scripts/')) and p.parent==O:root=R/spec
  elif spec.startswith(('src/','tests/','scripts/')):root=R/spec
  elif spec.startswith('.'):root=(p.parent/spec).resolve()
  elif spec.startswith('/'):root=Path(spec)
  else:external.add(spec);continue
  hit=next((f for f in [root,Path(str(root)+'.ts'),Path(str(root)+'.tsx'),Path(str(root)+'.mjs'),Path(str(root)+'.json'),root/'index.ts'] if f.is_file()),None)
  assert hit,('Unresolved local import',str(p),spec)
  files.add(hit);edges.append(dict(importer=str(p),specifier=spec,resolved=pin(hit)))
  if hit.suffix in ['.ts','.tsx','.mts','.mjs']:queue.append(hit)
write('import-read-closure.json',dict(status='static_local_import_closure_pinned',roots=sorted(str(p) for p in seen),edges=sorted(edges,key=lambda x:(x['importer'],x['specifier'])),externalPackageOrNodeSpecifiers=sorted(external),dynamicInputs='Explicit registered packet JSON, 31 reconciliation inputs, retained 21 storage files, nine raw overlays, compiledSource brand-updates/evidence-consumers seeds, regrading data and selected artifact references are separately enumerated and pinned. Loader source inspected only; production catalogue loader execution forbidden.',packageScope='Local implementation/data imports pinned here; selected source pins retain installed TypeScript, tsx, esbuild and Linux esbuild binary inventories, Node/timeout/Python executables and package/lock/tsconfig. No runtime imports during preparation.',runtimePackageClosure=pin(S/'input-closure.json')))
files.add(O/'import-read-closure.json')
for p in [R/'package.json',R/'pnpm-lock.yaml',R/'tsconfig.json']:assert p.is_file();files.add(p)
m=dict(schemaVersion=1,status='frozen_pending_independent_command_review_and_root_execution_grant',mode='derived-prefix20-through-Nissan31-then-Ford32-no-broad-features',asOf='2026-10-15',repo=str(R),nodeVersion='v24.19.0',nodeExecutable=str(Path(shutil.which('node')).resolve()),execArgv=['--max-old-space-size=448','--max-semi-space-size=1','--expose-gc','--import','tsx'],timeoutSeconds=420,killAfterSeconds=10,automaticRetry=False,productionRegistrationAuthorized=False,canonicalRecaptureAuthorized=False,normalFullReportInStage=False,rootExecutionGrantRequired=True,exclusiveHeavySlotRequired=True,**refs,importClosure=pin(O/'import-read-closure.json'),selectedArtifacts=artifacts,storageIndex=old['storageIndex'],registeredPacketIds=ids,selectedIds=selectedIds,addedIds=addedIds,rawOverlayInputs=rawInputs,reconciliationInputs=reconciliationInputs,output=str(O/'output'),runOutput=str(O/'run'),expected=dict(beforeCatalogue=430,afterCatalogue=433,beforeTierOne=353,afterTierOne=356,beforeOnSale=312,afterOnSale=314,beforePackets=31,afterPackets=32,changedRetainedCars=3,unchangedPeers=427,newModels=0,newVersions=3,configurationUpdates=3,sourcesAdded=27,specificFacts=121,termCells=18,coreCells=102,earnedCells=139,selectedFeatureClaims=414,pairComparisons=294,crossBasisComparisons=9,totalComparisons=303,intendedNegativeRejections=11,currentOfficialListReviewsAdded=1,settledInventoryRecordsAdded=0,residualOfficialMembershipGaps=2,residualGTOnSale=False,globalReviewedModels=107,globalReviewedVersions=245,globalIssueCount=186,globalSettledInventoryCount=65,globalC1Complete=False),pins=[pin(p) for p in sorted(files)],scope='Restore retained409 prefix20 once; reproduce complete-car/all14-field digests through Nissan31. Refresh three Ford MY26 cars and append three genuine MY23.75 residuals with actual builder/zero-fact and availability guards. Exactly six selected packs,139 earned cells,414 feature claims,303 comparisons,11 negative guards; exact selected artifact/live/written/portable/citable parity. Complete global ranking and expected C1 structure,427 unchanged peers,actual totals433/356/314. Only three current maker identities reviewed; two on-sale residual membership gaps and both inventory/Lightning/Q3GN holds remain. No broad feature replay, normal report, default loader, live edit, registration, canonical recapture, compiler retry, server/browser/archive/publication or automatic retry.')
write('manifest.json',m);h=pin(O/'manifest.json')['sha256'];command=[m['nodeExecutable'],*m['execArgv'],m['script']['path'],'--manifest',str(O/'manifest.json'),'--manifest-sha256',h]
write('root-grant-template.json',dict(authorized=False,exclusiveHeavySlotGranted=False,action='run_single_bounded_ford_full_stage',preparedManifestSha256=h,command=command,automaticRetry=False,note='Template only; explicit root grant and exclusive heavy slot required.'))
print(json.dumps(dict(manifest=pin(O/'manifest.json'),script=refs['script'],wrapper=refs['wrapper'],pins=len(files),localImportEdges=len(edges),reconciliationInputs=len(reconciliationInputs),executed=False),indent=2))
