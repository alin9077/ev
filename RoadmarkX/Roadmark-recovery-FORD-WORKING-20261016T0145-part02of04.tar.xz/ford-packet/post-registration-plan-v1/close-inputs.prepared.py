"""Ford32 prepared-byte logical closure inspector. Never executes application imports.
Uses frozen four-file after payloads with exact live-before guards. This is not live-after evidence.
All writes must target a new scratch directory, never this retained plan or live source.
"""
from pathlib import Path
import json,re,hashlib

def build_closure(R,A,B):
 R=Path(R);A=Path(A);B=Path(B)
 writes=json.loads((A/'prepared-writes.json').read_text())
 assert [w['relativePath'] for w in writes]==['data/m1-brand-updates/registry.json','scripts/reporting/load.ts','data/m1-brand-updates/ford-2026-10-15.json','data/m1-ford-market-reconciliation-2026-10-15.json']
 assert json.loads((A/'manifest.json').read_text())['writes']==writes
 # Preparation-only logical closure from exact candidate bytes; live targets retain before-state.
 for w in writes:
  target=Path(w['target']);prepared=Path(w['after']['path'])
  assert target==R/w['relativePath'] and prepared.is_file()
  assert prepared.stat().st_size==w['after']['bytes'] and hashlib.sha256(prepared.read_bytes()).hexdigest()==w['after']['sha256']
  if w['before'] is None:assert not target.exists()
  else:assert target.stat().st_size==w['before']['bytes'] and hashlib.sha256(target.read_bytes()).hexdigest()==w['before']['sha256']
 replacement={Path(w['target']):Path(w['after']['path']) for w in writes}
 def physical(p):return replacement.get(Path(p),Path(p))
 def pin(p):
  p=Path(p);f=physical(p);b=f.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 def exists(p):return physical(p).is_file()
 roots=list(json.loads(Path('/tmp/nissan-packet/post-registration-checks-v1/test-inventory.json').read_text()))+['scripts/validate.ts','scripts/generate-market-view.mjs','scripts/reporting/load.ts','eslint.config.mjs','tests/fixtures/evidence-consumers/data-before.ts.txt']
 seen=set();edges=[];externals=set();fs_lines=[]
 def add(p,origin,spec,kind):
  p=Path(p).resolve();assert p.is_relative_to(R),(origin,spec,p);assert exists(p),(origin,spec,p)
  edges.append(dict(importer=str(origin),specifier=spec,kind=kind,resolved=pin(p)));visit(p)
 def local(p,spec,kind):
  if spec.startswith('@/'):base=R/'src'/spec[2:]
  elif spec.startswith('.'):base=((R/'src/lib' if p.name=='data-before.ts.txt' else p.parent)/spec).resolve()
  elif spec.startswith(('src/','scripts/','tests/','data/','qa/','media/','public/')) or spec=='au_ev_all_variants_2026-10-06.json':base=R/spec
  else:externals.add(spec);return
  hit=next((f for f in [base,*[Path(str(base)+x) for x in ['.ts','.tsx','.js','.mjs','.json']],*[base/('index'+x) for x in ['.ts','.tsx','.js','.mjs']]] if exists(f)),None)
  assert hit,('Unresolved local reference',str(p),spec,kind)
  add(hit,p,spec,kind)
 def visit(p):
  p=Path(p).resolve()
  if p in seen:return
  seen.add(p)
  if p.suffix not in ['.ts','.tsx','.js','.mjs','.mts'] and p.name!='data-before.ts.txt':return
  text=physical(p).read_text()
  for spec in re.findall(r'''(?:\bfrom\s*|\bimport\s*\(?\s*|\brequire\s*\(\s*|\bapplicationRequire\s*\(\s*)["']([^"']+)["']''',text):local(p,spec,'static-import-or-require')
  for spec in re.findall(r'''\bcompiledSource\s*\(\s*["']([^"']+)["']''',text):local(p,spec,'literal-compiled-source')
  for spec in re.findall(r'''new\s+URL\s*\(\s*["']([^"']+)["']\s*,\s*import\.meta\.url''',text):local(p,spec,'literal-module-url')
  for spec in re.findall(r'''\breadFileSync\s*\(\s*["']([^"']+)["']''',text):
   target=R/spec;add(target,p,spec,'literal-working-directory-read')
  # Also close declared filename lists passed indirectly to readFileSync/path.join.
  for spec in re.findall(r'''["']((?:data|src|scripts|tests|qa|media|public)/[A-Za-z0-9_./-]+\.(?:json|ts|tsx|js|mjs|txt))["']''',text):local(p,spec,'declared-local-path')
  for i,line in enumerate(text.splitlines(),1):
   if re.search(r'\b(readFileSync|existsSync|readdirSync|statSync|compiledSource|new URL)\b',line):fs_lines.append(dict(path=str(p),line=i,text=line.strip()))
 for rel in roots:visit(R/rel)
 registry=json.loads(physical(R/'data/m1-brand-updates/registry.json').read_text());assert len(registry['packets'])==32 and registry['packets'][-1]=='ford-2026-10-15.json'
 add(R/'data/m1-brand-updates/registry.json',R/'src/lib/brand-update-registry.ts','registry.json','dynamic-registry-index')
 for name in registry['packets']:add(R/'data/m1-brand-updates'/name,R/'src/lib/brand-update-registry.ts',name,'dynamic-registered-packet')
 pointerBindings=[];pointerFiles=set()
 for name in ['data/price-ladder-existing-candidates-2026-10-13.json','data/price-ladder-premium-candidates-2026-10-13.json']:
  source=R/name;add(source,R/'src/lib/price-ladder.ts',name,'price-pointer-source-overlay')
  overlay=json.loads(source.read_text())
  for index,row in enumerate(overlay['candidates']):
   filename,pointer=row['sourcePointer'].split('#',1);target=(R/filename).resolve();assert target.is_relative_to(R/'data')
   add(target,R/'tests/price-ladder.test.ts',row['sourcePointer'],'data-driven-price-source-pointer');pointerFiles.add(filename)
   pointerBindings.append(dict(overlay=pin(source),candidateIndex=index,variantId=row['variantId'],sourcePointer=row['sourcePointer'],resolved=pin(target)))
 assert len(pointerFiles)==7
 assets=json.loads((R/'media/approved-assets.json').read_text());assert assets==[]
 # Exact compiler source is used only by existing test helper transpileModule, not project tsc.
 for p in [R/'node_modules/typescript/lib/typescript.js',R/'package.json',R/'pnpm-lock.yaml',R/'tsconfig.json']:
  assert p.is_file();seen.add(p)
 value=dict(status='prepared_byte_logical_closure_with_exact_live_before_guards_no_runtime',roots=roots,files=[pin(p) for p in sorted(seen)],edges=sorted(edges,key=lambda x:(x['importer'],x['kind'],x['specifier'])),externalPackageOrNodeSpecifiers=sorted(externals),filesystemAndCompiledSourceCallSites=fs_lines,registeredPackets=registry['packets'],priceSourcePointerFilenames=sorted(pointerFiles),priceSourcePointerBindings=pointerBindings,approvedAssetDynamicReads=dict(index='media/approved-assets.json',entries=0,physicalPublicAssetReads=0),dynamicReadBindings=[dict(producer='tests/evidence-consumers.test.ts',binding='Retained data-before.ts.txt behavioural oracle is directly pinned and recursively traversed using its actual src/lib/data.ts compilation/import context'),dict(producer='src/lib/brand-update-registry.ts',binding='Exact post-registration registry and all 32 listed packet JSON files'),dict(producer='tests/brand-updates.test.ts',binding='All registered packet files cover the literal named packet loop; module-relative registry URL is pinned'),dict(producer='tests/price-ladder.test.ts',binding='The exact unique sourcePointer filename prefixes before the hash separator are derived from both pinned existing/premium candidate overlays; all seven files and each row binding are pinned'),dict(producer='tests/helpers/compiled-source.ts',binding='Every literal compiledSource target is recursively traversed; TypeScript transpileModule implementation is pinned'),dict(producer='scripts/generate-market-view.mjs',binding='Both module-relative source/target JSON URLs are pinned; --check forbids writes'),dict(producer='scripts/validate.ts',binding='Root and copied immutable research files plus empty asset index are pinned; its ordinary all-car pack pass is deliberately included')],plannedTransitions=[dict(logicalPath=str(p),preparedPath=str(q),pin=pin(p)) for p,q in replacement.items()],scope='Conservative local content closure, including stubbed import branches. Installed dependencies retain existing runtime/package content and stat guards. No project parser, test or compiler execution.')
 with (B/'static-input-closure.json').open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 return value['files']
