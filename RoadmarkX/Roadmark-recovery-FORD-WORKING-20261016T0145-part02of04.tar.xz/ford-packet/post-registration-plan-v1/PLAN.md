# Ford32 post-registration validation plan

Preparation only. The live repository remains Nissan31. There is no authority to register, import application code, run tests, validate, compile or execute a normal report in this plan.

The four-file Ford registration is separately frozen at /tmp/ford-packet/registration-v1/manifest.json, SHA256 6a7c6bfca208eb5940eba4cb6adfd52a2b55a97ca0802ef1f495c706feee58eb. It requires bundle review, explicit Nissan backup live-source-freeze release and exact root application grant. Independent live byte readback must precede final command preparation.

## Actual current evidence and prepared-byte closure

The read/hash-only current observation verified the accepted Nissan validation references, 266 content pins, 170 local closure files, 496 edges, 361 configured TypeScript root names and 360 unchanged root stats, five directory states and two runtime executable metadata records. No project parser or compiler was executed. The configured root inventory is only an input-integrity guard; full-project TypeScript remains UNPASSED.

The eleven unchanged test files contain exactly 151 distinct retained test names: 144 behavioural tests and seven live safety tests. All137 price-ladder sourcePointer records were resolved against the actual source JSON values and all seven target files, matching the accepted dynamic closure. The approved external asset index is empty.

The preparation-only logical closure reads the exact four frozen after payloads and requires live-before hashes for the two existing targets and absence for the two new targets. It resolves 172 actual local files and 498 edges, 32 registry packets, the same137 price-pointer bindings/seven files, all literal compiledSource targets, the retained data-before fixture in its actual src/lib import context, module-relative URLs, literal and declared file reads, the immutable research files and empty asset index. These logical after pins are not represented as live-after evidence.

After application and independent readback, prepare-final.py must derive the closure again from real live files and require exact equality to the prepared logical files, edges and sourcePointer bindings. It also must recheck every inherited source/runtime/configured-root guard and freeze actual target stat/content records. A live discrepancy aborts finalization rather than weakening a pin or silently adopting unrelated edits.

## Five separately supervised commands

All commands are sequential, require an exclusive heavy slot and a fresh root grant binding their final manifest hashes, and use a ten-second TERM-to-KILL grace plus a twenty-second watchdog margin. No automatic retry, parallel execution, runtime scope mutation or compiler is allowed.

1. market-view: Node128MiB/1MiB,60 seconds, scripts/generate-market-view.mjs --check. The check mode must perform no write.
2. changed-file-lint: Node256MiB/1MiB,180 seconds, accepted explicit flat config, no config lookup/cache/concurrency, zero warnings, JSON output, only scripts/reporting/load.ts.
3. behavioural-suites: Node512MiB/1MiB,600 seconds, tsx Node test runner, TAP, concurrency1, exact ten accepted files and144 test names.
4. live-brand-safety: Node512MiB/1MiB,600 seconds, same runner policy, exact one accepted file andseven test names. No expectation or fixture is changed to make Ford pass.
5. structural-validation: Node448MiB/1MiB,900 seconds, scripts/validate.ts. Its ordinary all-car structural/pack validation is explicitly included in this separate gate, unlike the selected-only full-stage run. Expected433 variants,171 families,194 generations,69 criteria,29877 evidence rows,current351/outgoing46/provisional36,3858 source references,15 publication issues,zero approved external assets. The immutable root research SHA256 remains010ded194b4d61cd7be606ce0cc332fa7e32906bba70abff2b5c38541e634657.

The actual accepted full-stage results support433 catalogue/356 Tier1/314 on-sale and427 exact peers. The three new residual rows add207 generated feature rows and27 source snapshots; no model, manual feature or helper additions occur. Structural record-state counts are distinct from eligibility/on-sale counts.

## Supervisory and result requirements

Retain the byte-identical accepted Nissan supervisor. Each command enforces exact source/runtime/configuration and registration-target content/stat guards before and after, preserves invocation, raw wait status, timeout/process-group facts, peak RSS, stdout/stderr, TAP names/summary or structured validation/lint output, and requires prerequisite results. On any failure stop the sequence; preserve receipts. Do not infer a SIGKILL cause or rerun automatically.

Future finalization requires the independent readback schema to state accepted, bind the registration manifest, affirm allFourLiveHashesAndBytesMatchAcceptedPayloads, and provide the exact applicationReceipt pin. The application root grant must prove the backup freeze release and exact four-target scope. This contract follows the accepted Nissan gate preparation; if review chooses a different schema, adapt it in a separately frozen successor instead of guessing.

A single actual normal coverage report and exhaustive expected-versus-actual comparator are separately prepared under /tmp/ford-packet/report-comparison-plan-v1. They are not part of these five commands and require accepted gate results, independent readiness and root grants. Current maker C1 remains three grades, the two on-sale residual membership gaps and both Ford inventory questions remain open, and residual GT remains visible/unconfirmed. Full-project TypeScript/release remain UNPASSED after two preserved unknown-cause KGM SIGKILLs; no retry is proposed.
