"""Future read/hash-only final Ford32 five-gate preparation.
Usage: python prepare-final.py REGISTRATION_READBACK APPLICATION_ROOT_GRANT
Do not invoke until backup freeze release, exact application and independent readback.
This script never starts Node, a compiler, tests, browsers, servers or gate wrappers.
It creates /tmp/ford-packet/post-registration-checks-v1 exactly once.
"""
from pathlib import Path
from datetime import datetime, timezone
import ast, hashlib, json, runpy, sys
R=Path('/workspace/scratch/586427eef9f2/roadmark-104')
P=Path('/tmp/ford-packet/post-registration-plan-v1')
B=Path('/tmp/ford-packet/post-registration-checks-v1')
A=Path('/tmp/ford-packet/registration-v1')
O=Path('/tmp/nissan-packet/post-registration-checks-v1')
T=Path('/tmp/kgm-packet/full-project-typescript-v1')
F=Path('/tmp/ford-review/full-stage-v1-result-review/review.json')
EXPECTED_REGISTRATION_SHA='6a7c6bfca208eb5940eba4cb6adfd52a2b55a97ca0802ef1f495c706feee58eb'
EXPECTED_PACKET_SHA='8d728412f21a36aac152357d04793fd38b5efc47438e5210af610f72e868ce00'
EXPECTED_WRAPPER_SHA='0669805bd8b514e510179aea3f93adb5b231b5e02e08ec6b5cde26b290f62828'
assert len(sys.argv)==3,'prepare-final.py REGISTRATION_READBACK APPLICATION_ROOT_GRANT'
V,G=map(Path,sys.argv[1:])
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while chunk:=f.read(1024*1024):h.update(chunk)
 return h.hexdigest()
def pin(p):p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def verify(p):
 a=pin(p['path']);assert a['sha256']==p['sha256'],p['path']
 if 'bytes' in p:assert a['bytes']==p['bytes'],p['path']
 if 'realpath' in p:assert str(Path(p['path']).resolve())==p['realpath']
 return a
def meta(p):
 p=Path(p)
 if not p.exists():return dict(path=str(p),exists=False)
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
def read(p):return json.loads(Path(p).read_text())
def write(p,x):
 with Path(p).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
assert not B.exists(),'Never overwrite any preparation or historical attempt'
assert sha(A/'manifest.json')==EXPECTED_REGISTRATION_SHA
reg=read(A/'manifest.json');writes=read(A/'prepared-writes.json');assert reg['writes']==writes
expected=['data/m1-brand-updates/registry.json','scripts/reporting/load.ts','data/m1-brand-updates/ford-2026-10-15.json','data/m1-ford-market-reconciliation-2026-10-15.json']
assert [w['relativePath'] for w in writes]==expected
fullstage=read(F)
assert fullstage['status']=='PASS_BOUNDED_FULL_STAGE_RESULT_REVIEW_ONLY'
assert sha(F)=='e6e355d2e2023aadc09ae754da4f8a6a3e94e4d1aa01b10b4c2b6a4473d5dd8e'
assert sha(fullstage['resultManifest'])==fullstage['resultManifestSha256']
assert sha(fullstage['definitiveStageReceipt'])==fullstage['stageReceiptSha256']
stageReceipt=read(fullstage['definitiveStageReceipt']);assert stageReceipt['packetSha256']==EXPECTED_PACKET_SHA
assert stageReceipt['stagedCars']==433 and stageReceipt['tierOneVersions']==356 and stageReceipt['onSaleVersions']==314
verification=read(V);applicationGrant=read(G)
assert verification['status']=='accepted' and verification['manifestSha256']==EXPECTED_REGISTRATION_SHA
assert verification['allFourLiveHashesAndBytesMatchAcceptedPayloads'] is True
verify(verification['applicationReceipt']);application=read(verification['applicationReceipt']['path'])
assert application['passed'] is True and application['manifestSha256']==EXPECTED_REGISTRATION_SHA
assert applicationGrant['status']=='root_application_granted' and applicationGrant['action']=='apply_exact_ford_registration'
assert applicationGrant['backupLiveSourceFreezeReleased'] is True
assert applicationGrant['automaticRetry'] is False and applicationGrant['heavyExecutionAuthorized'] is False
assert applicationGrant['manifest']==pin(A/'manifest.json') and application['grantSha256']==sha(G)
assert applicationGrant['allowedTargets']==[w['target'] for w in writes]
verify(applicationGrant['reviewerAcceptance'])
transitions=[];targetMetadata=[]
for w in writes:
 verify(w['after']);assert Path(w['target'])==R/w['relativePath']
 target=dict(path=w['target'],bytes=w['after']['bytes'],sha256=w['after']['sha256']);verify(target)
 targetmeta=meta(w['target']);assert targetmeta['realpath']==w['target'] and not targetmeta['isSymlink'] and not targetmeta['isDirectory']
 if w['beforeCopy'] is not None:verify(w['beforeCopy'])
 transitions.append(target);targetMetadata.append(targetmeta)
oldregistry=read(writes[0]['beforeCopy']['path']);newregistry=read(R/expected[0])
assert len(oldregistry['packets'])==31 and newregistry['packets']==oldregistry['packets']+['ford-2026-10-15.json']
for p in reg['unchangedHelperPins']:verify(p)
config=read(R/'tsconfig.json');oldts=read(T/'manifest.json');assert config==oldts['originalConfig']
scope=read(O/'project-root-metadata.json')
for v in scope['fileMetadata']+scope['directoryState']+oldts['runtimeMetadata']:assert meta(v['path'])==v,v['path']
rootpaths=sorted({str(p.resolve()) for pat in config['include'] for p in R.glob(pat) if p.is_file()})
assert rootpaths==scope['configuredRootFilePaths'] and len(rootpaths)==361 and len(scope['fileMetadata'])==360
load=str(R/'scripts/reporting/load.ts');assert not any(v['path']==load for v in scope['fileMetadata'])
# Validate prerequisite assets before creating final preparation output.
inventory=read(O/'test-inventory.json');names=[]
for row in inventory.values():verify(row['source']);assert row['count']==len(row['names']);names+=row['names']
assert len(names)==len(set(names))==151
behavior=read(O/'behavioural-suites.json')['testFiles'];live=['tests/brand-live-safety.test.ts']
assert sum(inventory[f]['count'] for f in behavior)==144 and inventory[live[0]]['count']==7
assert sha(P/'run.reference.py')==sha(O/'run.py')==EXPECTED_WRAPPER_SHA
for name in ['prepare-final.py','close-inputs.future.py','run.reference.py']:ast.parse((P/name).read_text())
previouspins=read(O/'source-pins.json');transitionmap={p['path']:p for p in transitions}
pins={}
for p in previouspins:
 actual=verify(transitionmap.get(p['path'],p));pins[actual['path']]=actual
B.mkdir()
for src,dst in [('prepare-final.py','prepare.py'),('close-inputs.future.py','close-inputs.py'),('run.reference.py','run.py')]:
 with (B/dst).open('xb') as f:f.write((P/src).read_bytes())
scope.update(status='post_registration_metadata_frozen_no_compiler_invocation',method='Accepted Nissan31/KGM configured names and all 360 unchanged root stats; actual Ford32 registration target bytes/stat observed only after accepted application/readback.',registrationStatTransitions=[dict(expectedAfter=next(p for p in transitions if p['path']==load),runtimeContract='Exact live post-registration bytes; capture then preserve every target stat within each command')],postRegistrationTargets=targetMetadata,note='361 configured roots are input-integrity guards, not a compiler run. All four registration targets receive per-command content/stat guards; current full-project TypeScript remains UNPASSED.')
write(B/'project-root-metadata.json',scope)
for p in transitions:pins[p['path']]=p
for w in writes:
 p=pin(w['after']['path']);pins[p['path']]=p
for path in [A/'manifest.json',A/'prepared-writes.json',B/'prepare.py',B/'close-inputs.py',P/'plan-manifest.json',P/'prepared-closure/static-input-closure.json',Path('/tmp/nissan-review/post-registration-v1-readiness-v1.json'),Path('/tmp/nissan-review/post-registration-v1-results-v1.json')]:
 p=pin(path);pins[p['path']]=p
# Runs only this stdlib Python filesystem scanner, never project JS or TypeScript.
closure=runpy.run_path(str(B/'close-inputs.py'))['build_closure'](R,A,B)
for p in closure:
 if p['path'] in pins:assert pins[p['path']]==p,p['path']
 pins[p['path']]=p
closuredata=read(B/'static-input-closure.json')
assert len(closure)==172 and len(closuredata['edges'])==498
assert len(closuredata['registeredPackets'])==32 and len(closuredata['priceSourcePointerBindings'])==137
assert len(closuredata['priceSourcePointerFilenames'])==7
preparedClosure=read(P/'prepared-closure/static-input-closure.json')
assert closuredata['files']==preparedClosure['files'] and closuredata['edges']==preparedClosure['edges']
assert closuredata['priceSourcePointerBindings']==preparedClosure['priceSourcePointerBindings']
p=pin(B/'static-input-closure.json');pins[p['path']]=p
write(B/'source-pins.json',[pins[k] for k in sorted(pins)])
write(B/'test-inventory.json',inventory)
write(B/'wrapper-syntax-check.json',dict(status='passed_python_ast_parse_only',wrapper=pin(B/'run.py'),byteIdenticalToAcceptedNissanV1=pin(O/'run.py'),wrapperExecuted=False,compilerRun=False))
extraPaths=[F,V,G,Path(verification['applicationReceipt']['path']),Path('/tmp/ford-packet/full-stage-v1/output/stage-receipt.json'),Path('/tmp/ford-packet/full-stage-v1/output/research-field-digests.json'),Path('/tmp/kgm-packet/full-project-typescript-v1/run/terminal.json'),Path('/tmp/kgm-packet/full-project-typescript-v2/run/terminal.json'),Path('/tmp/kgm-packet/report-comparison-v2/typescript-failure-provenance.json'),Path('/tmp/renault-packet/report-comparison-v4/retry-provenance.json')]
extra=[pin(p) for p in extraPaths]
common=dict(status='frozen_not_executed_requires_review_and_root_grant',repo=str(R),qaRoot=str(B/'run'),exclusiveLock=str(B/'.exclusive-heavy.lock'),killAfterSeconds=10,automaticRetry=False,parallelExecutionAllowed=False,sourceMutationsAuthorized=False,sourcePins=pin(B/'source-pins.json'),rootMetadata=pin(B/'project-root-metadata.json'),testInventory=pin(B/'test-inventory.json'),wrapper=pin(B/'run.py'),registrationManifest=pin(A/'manifest.json'),registrationTargets=transitions,originalConfig=config,runtimeMetadata=oldts['runtimeMetadata'],environmentRemovals=oldts['environmentRemovals'],environmentOverrides={'NODE_DISABLE_COMPILE_CACHE':'1','FORCE_COLOR':'0','ESLINT_USE_FLAT_CONFIG':'true'},currentProjectTypeScript='UNPASSED; two retained KGM SIGKILL failures of unknown cause; no compiler retry')
node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
def base(heap):return [node,'--max-old-space-size='+str(heap),'--max-semi-space-size=1']
configs=[dict(id='market-view',kind='market',command=base(128)+['scripts/generate-market-view.mjs','--check'],timeoutSeconds=60),dict(id='changed-file-lint',kind='lint',command=base(256)+[str((R/'node_modules/eslint/bin/eslint.js').resolve()),'--no-config-lookup','--config',str(R/'eslint.config.mjs'),'--no-ignore','--no-cache','--concurrency','off','--max-warnings','0','--format','json','--','scripts/reporting/load.ts'],timeoutSeconds=180,lintFiles=['scripts/reporting/load.ts']),dict(id='behavioural-suites',kind='tests',command=base(512)+['--import','tsx','--test','--test-reporter=tap','--test-concurrency=1',*behavior],timeoutSeconds=600,testFiles=behavior,expectedTests=144),dict(id='live-brand-safety',kind='tests',command=base(512)+['--import','tsx','--test','--test-reporter=tap','--test-concurrency=1',*live],timeoutSeconds=600,testFiles=live,expectedTests=7),dict(id='structural-validation',kind='structural',command=base(448)+['--import','tsx','scripts/validate.ts'],timeoutSeconds=900,expectedStructuralCounts={'variants':433,'families':171,'generations':194,'criteria':69,'evidence':29877,'current':351,'outgoing':46,'provisional':36},expectedSourceReferences=3858,expectedPublicationIssues=15,expectedApprovedExternalAssets=0,immutableResearchSha256='010ded194b4d61cd7be606ce0cc332fa7e32906bba70abff2b5c38541e634657')]
sequence=[];previous=None
for c in configs:
 m={**common,**c,'runOutput':str(B/'run'/c['id']),'prerequisites':[] if previous is None else [previous],'extraPins':extra}
 write(B/(c['id']+'.json'),m);p=pin(B/(c['id']+'.json'));sequence.append(p);previous=dict(manifest=p,resultPath=str(B/'run'/c['id']/'result.json'))
write(B/'sequence.json',dict(status='frozen_not_executed_requires_review_and_root_grant',sequence=sequence,sourcePins=common['sourcePins'],rootMetadata=common['rootMetadata'],qaRoot=str(B/'run'),registrationManifest=common['registrationManifest'],registrationTargets=transitions,preparation=[pin(B/'prepare.py'),pin(B/'wrapper-syntax-check.json')],currentProjectTypeScript=common['currentProjectTypeScript'],compilerIncluded=False,noAutomaticRetry=True,normalReportAndComparatorIncluded=False,executionAuthorized=False))
write(B/'root-grant-template.json',dict(status='NOT_GRANTED',heavySlotExclusive=False,automaticRetry=False,parallelExecutionAllowed=False,granted=[],sequence=pin(B/'sequence.json'),reviewerAcceptance=None,registrationVerification=pin(V)))
for p in pins.values():verify(p)
for v in scope['fileMetadata']+scope['directoryState']+oldts['runtimeMetadata']+targetMetadata:assert meta(v['path'])==v,v['path']
assert not (B/'run').exists()
write(B/'preparation-status.json',dict(status='prepared_not_executed',at=datetime.now(timezone.utc).isoformat(),sequence=pin(B/'sequence.json'),wrapper=pin(B/'run.py'),sourcePinCount=len(pins),localClosureFiles=172,localClosureEdges=498,configuredRootCount=361,unchangedRootStatCount=360,actualRegistrationTargetMetadata=targetMetadata,behavioralTests=144,liveSafetyTests=7,distinctTests=151,registrationManifest=pin(A/'manifest.json'),registrationVerification=pin(V),backupFreezeReleaseApplicationGrant=pin(G),projectParsersRun=False,testsRun=False,compilerRun=False,wrappersRun=False,sourceEdits=False))
print(json.dumps(dict(sequence=pin(B/'sequence.json'),sourcePinCount=len(pins),executed=False),indent=2))
