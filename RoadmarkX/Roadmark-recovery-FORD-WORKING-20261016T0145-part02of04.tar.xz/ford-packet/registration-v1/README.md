# Ford32 four-file registration preparation

No live write is authorized by this bundle. Apply only after independent full-stage result acceptance, separate bundle review, explicit release of the Nissan backup live-source freeze, and an exact root application grant.

The complete allowed change set is two new data files plus two existing integration files:
1. Append ford-2026-10-15.json after the exact first 31 registry entries
2. Add one Ford reconciliation import and one final combineM1Reconciliations argument in scripts/reporting/load.ts
3. Copy the byte-exact accepted candidate-v4 packet to data/m1-brand-updates/ford-2026-10-15.json
4. Copy the byte-exact reconciliation-v1 successor to data/m1-ford-market-reconciliation-2026-10-15.json

The packet refreshes three current MY26 rows and adds three actual MY23.75 residual rows. The source-specific older and newer technical epochs remain separate. Current named-grade ranking eligibility is released through three guarded configuration updates, while complete-count exclusions and unsupported manufacturer-price holds remain. Unknown cargo methods and mirror bases stay excluded from direct comparison; prices are Reported/unranked. Recalls retain exact-VIN and remedy uncertainty.

Expected full catalogue after application is 433 catalogue / 356 Tier 1 / 314 on-sale, with 427 unchanged peers. Current maker C1 lists exactly three MY26 grades. The advertised-New residual Select/Premium rows remain on-sale with official-list membership gaps; residual GT remains visible/unconfirmed and is not on-sale. Lightning importer/new-supply status and Q3GN exact epoch remain unresolved. Global C1 remains false at 107 reviewed models / 245 versions / 186 issues / 65 settled inventory.

There are no helper, test, hero, immutable snapshot, market-view or report implementation changes. Source capture files stay outside the repository. The guarded applicator writes only the four reviewed targets, retains per-file journals, uses exclusive create for new files, and checks exact before/after hashes. A failure stops with its partial journal; no automatic retry, deletion or rollback is authorized.

After accepted application and independent byte readback, prepare and separately review the five scoped validation commands: market-view check, changed-file lint, 144 behavioural tests, seven live safety tests and structural validation. One actual normal report and an exhaustive expected-versus-actual comparator are later separate commands. Full-project TypeScript/release remain UNPASSED; no compiler retry or broad heavy execution is included here.
