#!/usr/bin/env python3
"""Code-only synthetic support boundary tests; no configure, scanner, seed or archive."""
import argparse,ast,collections,copy,hashlib,json,pathlib,sys,types
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent
ADAPTER={'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_support_adapter_v2.py', 'bytes': 13790, 'sha256': '8b625a908871d5bfc971d7d3d22643f1b7409fa4560a83f29d6b3b395c42171a'}
UTILITY={'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_delivery_sealed_runtime_v2.py', 'bytes': 4506, 'sha256': '137c53c4d5e01a4c708aaa61ccd3c425ab3f53b7ef0bf8a8d153767f094b4d1f'}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['pure-tests']);ap.add_argument('--contract',required=True);ap.add_argument('--contract-sha256',required=True);ap.add_argument('--review',required=True);ap.add_argument('--review-sha256',required=True);args=ap.parse_args()
 # Bootstrap performs only the exact pinned neutral code read.
 p=P(UTILITY['path']);before=p.stat();raw=p.read_bytes();after=p.stat();assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns) and not any(q.is_symlink() for q in (p,*p.parents)) and {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}=={k:UTILITY[k] for k in ('bytes','sha256')}
 u=types.ModuleType('ford_support_test_runtime');u.__file__=str(p);exec(compile(raw,str(p),'exec'),u.__dict__)
 c,metadata,payload,outputs=u.runtime(args,__file__,'SUPPORT_PURE_TEST');u.ck(not payload and outputs=={c['testOutput']},'pure-test scope')
 u.ck(metadata[ADAPTER['path']]==ADAPTER,'exact support adapter');m=u.module(ast.parse(u.read_exact(ADAPTER)),ADAPTER['path'],'ford_support_test_subject');classifier=m.classifier_module(u)
 counts=collections.Counter()
 def passed(label,fn):fn();counts[label]+=1
 def reject(label,fn):
  try:fn()
  except (AssertionError,ValueError,KeyError,IndexError):counts[label]+=1
  else:raise AssertionError('mutation accepted: '+label)
 def fixture(role):
  if role=='inverse-key-absence-check':text="def inverse(raw):\n    return b'\"authorization\":' not in raw\n";func='inverse';operation='Compare'
  elif role=='inverse-key-once-replacement':text="def inverse(raw):\n    return raw.replace(b'\"approvalScope\":', b'\"authorization\":', 1)\n";func='inverse';operation='Call'
  else:text="def captures(reused_raw):\n    return reused_raw.replace(b'\"authorization\":', b'\"approvalScope\":', 1)\n";func='captures';operation='Call'
  data=text.encode();tree=ast.parse(data);node=next(n for n in ast.walk(tree) if isinstance(n,ast.Constant) and n.value==b'"authorization":');starts=[0]
  for line in data.splitlines(keepends=True):starts.append(starts[-1]+len(line))
  start,end=starts[node.lineno-1]+node.col_offset,starts[node.end_lineno-1]+node.end_col_offset;name='ford-recovery-support/synthetic-'+role+'.py';finding={'header':'authorization','kind':'synthetic-exact-code-header','valueLength':0};fp=u.bp(data)
  row={'member':name,'filePin':fp,'exactFinding':finding,'byteStart':start,'byteEndExclusive':end,'matchedSyntaxSHA256':hashlib.sha256(data[start:end]).hexdigest(),'keyLiteralByteStart':start,'keyLiteralByteEndExclusive':end,'keyLiteralSHA256':hashlib.sha256(data[start:end]).hexdigest(),'keyLiteralAstType':'Constant[bytes]','astFunction':func,'astOperation':operation,'astRole':role,'classification':'exact synthetic reversible key syntax'}
  record={'member':name,'filePin':fp,'finding':finding,'classification':row['classification']};doc={'exactSupportCodeClassifications':[row],'expectedClassifiedRecords':[record]};return data,name,finding,doc
 for role in ['inverse-key-absence-check','inverse-key-once-replacement','approved-copy-key-reconstruction']:
  data,name,finding,doc=fixture(role);out=classifier.classify_exact([finding],data,name,doc);u.ck(out==([],doc['expectedClassifiedRecords']),'synthetic baseline');counts['exact_ast_role']+=1
  for label,candidates in [('missing',[]),('duplicate',[finding,finding]),('changed_finding',[dict(finding,valueLength=1)])]:reject(label,lambda:classifier.classify_exact(candidates,data,name,doc))
  extra={'kind':'extra'};blocked,records=classifier.classify_exact([finding,extra],data,name,doc);u.ck(blocked==[extra] and records==doc['expectedClassifiedRecords'],'extra remains blocking');counts['extra_blocking']+=1
  u.ck(classifier.classify_exact([finding],data,'unlisted.py',doc)==([finding],[]),'unlisted stays blocking');counts['unlisted_blocking']+=1
  reject('file_change',lambda:classifier.classify_exact([finding],data+b' ',name,doc))
  for field,value in [('matchedSyntaxSHA256','0'*64),('keyLiteralSHA256','0'*64),('astFunction','other'),('astOperation','Assign'),('astRole','generic-string')]:
   altered=copy.deepcopy(doc);altered['exactSupportCodeClassifications'][0][field]=value;reject(field,lambda:classifier.classify_exact([finding],data,name,altered))
 # Use the last synthetic document for the unchanged prior output dispatcher.
 calls=[];members={name};seen=set();emitted=[];extras=[];report=C/'synthetic-support-report.json';seed={'bytes':1,'sha256':'0'*64};dispatch=classifier.dump_dispatch(lambda p,r:calls.append((p,r)),report,seed,members,seen,emitted,extras,doc)
 receipt={'completedAt':'synthetic','processId':123,'exactPinnedMembersReadAndVerified':200,'historicalArchives':21,'memberIdentityListPin':seed,'noExtractedValuesPersisted':True,'scope':'Targeted historical seed reconstruction only, not a full base privacy scan or restore'}
 dispatch(C/'seed-read-invocations/123-456.json',receipt);u.ck(len(calls)==1,'seed receipt precedes classification');counts['seed_receipt_shape_only']+=1
 final={'classifiedExactCodeHeaderCandidates':doc['expectedClassifiedRecords'],'status':'clean','primaryHeaderCandidates':[]};reject('incomplete_report',lambda:dispatch(report,final));reject('wrong_destination',lambda:dispatch(C/'unrelated.json',receipt))
 seen.add(name);emitted.extend(doc['expectedClassifiedRecords']);dispatch(report,final);counts['complete_report']+=1
 extras.append({'kind':'extra'});reject('extra_cannot_be_clean',lambda:dispatch(report,final))
 bad=dict(receipt,exactPinnedMembersReadAndVerified=199);reject('bad_seed_receipt_shape',lambda:dispatch(C/'seed-read-invocations/123-456.json',bad))
 # Finite path checks use synthetic metadata only, with no filesystem operation.
 row={'path':'ford-recovery-support/synthetic.py','payloadPath':str(C/'synthetic-stage/synthetic.py'),'bytes':1,'sha256':'0'*64};payload={row['payloadPath']:{'path':row['payloadPath'],**u.sh(row)}};m.selected(u,[row],payload);counts['finite_selection']+=1
 reject('duplicate_member',lambda:m.selected(u,[row,row],payload));reject('extra_payload',lambda:m.selected(u,[row],dict(payload,extra=payload[row['payloadPath']])));reject('unsafe_member',lambda:m.selected(u,[dict(row,path='../escape')],payload));reject('external_payload',lambda:m.selected(u,[dict(row,payloadPath='/synthetic-outside/file.py')],payload))
 # Compile exact shared engines and unchanged six classifier functions, never import/execute their phases.
 for key in ['package','patterns']:
  compile(u.assembly(m.PINS[key],{}),m.PINS[key]['path'],'exec');counts['exact_engine_ast_compile_only']+=1
 result={'result':'PASS_EXACT_FORD_SUPPORT_CODE_ONLY_TESTS','adapter':ADAPTER,'testScript':u.pin(__file__),'cases':dict(counts),'totalCases':sum(counts.values()),'scope':{'syntheticInMemoryOnly':True,'configureCalled':False,'seedLoading':False,'scannerRuns':False,'archiveReads':False,'packageRuns':False,'sourcePayloadReads':False,'filesystemFixtureWrites':False,'nativeByteReadbackVerified':False}}
 with P(c['testOutput']).open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({'result':result['result'],'output':u.pin(c['testOutput']),'cases':result['totalCases']}))
if __name__=='__main__':main()
