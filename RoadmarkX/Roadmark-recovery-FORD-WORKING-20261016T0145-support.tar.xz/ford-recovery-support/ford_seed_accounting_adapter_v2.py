#!/usr/bin/env python3
"""Current Ford actual invocation/stage accounting; Nissan remains separate."""
import ast, sys
from ford_capture_adapter_v1 import C, B, NISSAN, P, capture_module, load_reference, replace_constant, redirect_import

PIN = {'bytes': 3724, 'sha256': '0e8af54d0092c226a7f0d360ab39a2f7096c05a2a28504b0ac0f43b8633164fc'}
INHERITED_PIN = {'bytes': 23857, 'sha256': 'f92470e29c5e8e417d1115650ab9e34eab4d9fcf0399b5ed9e438dfd92013b33'}

def transform(tree):
    redirect_import(tree, 'nissan_capture_adapter_v2', 'ford_capture_adapter_v1')
    replace_constant(tree, 'inheritedRenaultAccounting', 'inheritedNissanAccounting')
    replace_constant(tree, 'SEED-READ-ACCOUNTING-after-active-v2.json', 'SEED-READ-ACCOUNTING-after-correction-v1.json')
    replace_constant(tree, 'Nissan invocation/stage files only. Inherited Renault is pinned, not added to current counts. Missing receipts do not prove zero reads.',
                     'Ford invocation/stage files only. Inherited Nissan and its older accounting remain separately pinned, not added to current counts. Missing receipts do not prove zero reads.')
    main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    paths = [n for n in main.body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'priorPath']
    assert len(paths) == 1 and isinstance(paths[0].value, ast.BinOp) and paths[0].value.left.id == 'B'
    paths[0].value.left.id = 'NISSAN'
    assertions = [n for n in main.body if isinstance(n, ast.Assert) and n.lineno == 19]
    assert len(assertions) == 1
    index = main.body.index(assertions[0])
    main.body[index] = ast.parse("assert prior['currentInvocationSummary'] == INHERITED_SUMMARY").body[0]
    assignments = [n for n in main.body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Attribute)
                   and n.targets[0].value.id == 'm' and n.targets[0].attr == 'INHERITED_RENAULT']
    assert len(assignments) == 1
    assignments[0].value = ast.parse("{'receipt': {'path': str(priorPath), **INHERITED_PIN}, 'currentInvocationSummary': prior['currentInvocationSummary'], 'olderInheritedAccounting': prior['inheritedRenaultAccounting'], 'originalCupraUnknownPreservedByExactReceipt': True, 'originalRenaultFactualReportUnknownPreservedSeparately': True}", mode='eval').body
    return tree

def main():
    from ford_phase_gateway_v1 import verified_core_contract
    verified_core_contract()
    m = load_reference('ford_nissan_accounting_reference', NISSAN / 'nissan_seed_accounting_adapter_v1.py', PIN, transform)
    m.NISSAN = NISSAN
    m.INHERITED_PIN = INHERITED_PIN
    m.INHERITED_SUMMARY = {'attempts': 7, 'successfulPasses': 7, 'nonzeroOrTimeout': 0,
                          'unknownTerminalOutcomes': 0, 'independentlyEstablishedKnownZeroFailures': 0,
                          'zeroFailuresQualification': 'No current phase is classified known-zero by this revision'}
    m.main()

if __name__ == '__main__':
    main()
