#!/usr/bin/env python3
"""Independent Ford delivery/document checker over pinned Nissan v7; no producer execution."""
import ast,hashlib,pathlib,stat,sys,types
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent;N=C.parent/'nissan-working-20261015T2220';RENAULT=C.parent/'renault-working-20261015T2040'
UTILITY={'path':str(C/'ford_delivery_sealed_runtime_v2.py'),'bytes':4506,'sha256':'137c53c4d5e01a4c708aaa61ccd3c425ab3f53b7ef0bf8a8d153767f094b4d1f'}
BASE={'path':str(N/'independent_nissan_delivery_v7.py'),'bytes':46199,'sha256':'ac1652f80f0aaf8113120a431c4eecbb392f6ceed68e7074be5f7914258ebd1a'}
REPLAY={'path':str(C/'independent_ford_recovery_v5.py'),'bytes':31932,'sha256':'2bc86c7f5bacb053c5568a68ed1593b431e189296d598b06c607320e5cdd6238'}
def utility():
 p=P(UTILITY['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in (p,*p.parents));b=p.read_bytes();t=p.lstat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns,t.st_ctime_ns) and {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}=={k:UTILITY[k] for k in ('bytes','sha256')};m=types.ModuleType('ford_independent_delivery_loader');m.__file__=str(p);exec(compile(b,str(p),'exec'),m.__dict__);return m
EDITS={'context': [['ACCEPTED_EXACT_NISSAN_DELIVERY_RUNTIME_CONTRACT', 'ACCEPTED_EXACT_FORD_DELIVERY_RUNTIME_CONTRACT', 1], ['ACCEPTED_EXACT_NISSAN_DELIVERY_ADAPTER', 'ACCEPTED_EXACT_FORD_DELIVERY_ADAPTER', 1]], 'normalized': [["r=get(C/f'library-{phase}-provider-results.json')", 'r=ford_response_view(phase)', 1], ['currentNissanMaterializationAttempts', 'currentFordMaterializationAttempts', 1]], 'recovery': [['PASS_INDEPENDENT_NISSAN_FRESH_RECOVERY', 'PASS_INDEPENDENT_FORD_FRESH_RECOVERY', 1], ['ACCEPTED_EXACT_NISSAN_VERIFIER_RUNTIME_CONTRACT', 'ACCEPTED_EXACT_FORD_VERIFIER_RUNTIME_CONTRACT', 1], ["r['acceptedFinalRetentionScope']=='accepted'", "r['acceptedFinalRetentionScope']=='accepted factual/metadata retention only'", 1], ['SAFETY-SAVE-PLAN-v3.json', 'SAFETY-SAVE-PLAN-v1.json', 1], ["p['nissanEvidence']['finalFreeze']", "p['fordEvidence']['inventory']", 3], ["p['nissanEvidence']['finalRetentionReview']", "p['fordEvidence']['finalRetentionAcceptance']", 1], ["accept['currentValidation']", "accept['factualState']", 1], ["p['currentNissanValidation']", "p['currentFordValidation']", 1], ["'fullProjectTypecheckPassed','releaseReady','currentCleanFullSuite'", "'fullProjectTypecheckPassed','releaseReady','researchCompleted','currentCleanFullSuite'", 1], ["ck(all(x['cause']=='unknown' and x['exitCode']==-9 and x['fullProjectTypecheckPassed'] is False for x in inv['retainedFailures']['compilerAttempts']),'compiler failures changed')", "ck(all(x['cause']=='unknown' and x['exitCode']==-9 and x['fullProjectTypecheckPassed'] is False for x in inv['retainedFailures']['compilerAttempts']),'compiler failures changed');ck(accept['liveSourceAndStatusPins']==inv['sourceAndStatusAfterPins']==s['authorRetention']['sourceAndStatusAfterPins'] and len(accept['liveSourceAndStatusPins'])==8,'Ford live pins');ck(len(inv['files'])==538 and len(s['files'])==545,'Ford exact author closure')", 1]], 'restore': [['deliverables/Roadmark-RECOVERY-MANIFEST-RENAULT-WORKING-20261015.json', 'deliverables/Roadmark-RECOVERY-MANIFEST-NISSAN-WORKING-20261015.json', 1], ['INDEPENDENT-NISSAN-REFERENCE-CLOSURE-v2.json', 'INDEPENDENT-FORD-REFERENCE-CLOSURE-v2.json', 2], ["len(src['files'])==703 and source['members']==704", "len(src['files'])==706 and source['members']==707", 1], ["po['inheritedPreparationLimitations']==base['currentPreparationLimitations'] and po['inheritedRecoveryMetadata']==base['inheritedRecoveryMetadata']", "po['inheritedBaseRecovery']==base['baseRecovery'] and po['inheritedNissanIndependentVerification']==base['independentVerification']", 1], ['len(baseby)==142', 'len(baseby)==145', 1], ['len(reused)==141', 'len(reused)==144', 1], ["'archiveCount':141+len(ars)", "'archiveCount':144+len(ars)", 1], ["'fullSourceFiles':703,'sourceArchiveMembers':704,'baseArchivesReused':141", "'fullSourceFiles':706,'sourceArchiveMembers':707,'baseArchivesReused':144", 1], ["supp=[b['supplementalDeliveryVerificationArtifact']['identity'],b['deliveryCorrection']['artifact']];ck(len(supp)==2", "supp=[x['identity'] for x in cfg['deliveryOnlySupplements']];ck(len(supp)==3", 1], ['len(suppmaps)==2', 'len(suppmaps)==3', 1]], 'accounting': [["old=get(B/'SEED-READ-ACCOUNTING-after-active-v2.json');expected={'receipt':ref(B/'SEED-READ-ACCOUNTING-after-active-v2.json'),'attempts':11,'successfulPasses':9,'knownZeroPreconditionFailures':2,'originalCupraUnknownPreservedByExactReceipt':True,'originalRenaultFactualReportUnknownPreservedSeparately':True}\n ck(ac['inheritedRenaultAccounting']==expected and len(old['phases'])==11 and sum(p['outcome']=='PASS' for p in old['phases'])==9 and sum(p['knownZeroSeedPreconditionFailure'] for p in old['phases'])==2,'inherited9/11/2 separate')", 'old=ford_inherited_accounting(ac)', 1]], 'docpaths': [['NISSAN-WORKING-', 'FORD-WORKING-', 3], ['Roadmark-NISSAN-M1-UPDATE-', 'Roadmark-FORD-M1-UPDATE-', 1]], 'documents': [['INDEPENDENT-NISSAN-RECOVERY-VERIFICATION-v1.json', 'INDEPENDENT-FORD-RECOVERY-VERIFICATION-v1.json', 1], ['INDEPENDENT-NISSAN-REFERENCE-CLOSURE-v2.json', 'INDEPENDENT-FORD-REFERENCE-CLOSURE-v2.json', 2], ['Roadmark Nissan31 working recovery', 'Roadmark Ford32 working recovery', 2], ["'label':'Renault30'", "'label':'Nissan31'", 1], ['The standalone Nissan source replaces the Renault source', 'The standalone Ford source replaces the Nissan source', 1], ['contains703 project files', 'contains706 project files', 1], ['The two historical delivery-only artifacts', 'The three historical delivery-only artifacts', 1], ['docs/NISSAN_M1_UPDATE.md', 'docs/FORD_M1_UPDATE.md', 1]], 'active': [['NISSAN-WORKING-', 'FORD-WORKING-', 2], ['INDEPENDENT-NISSAN-RECOVERY-VERIFICATION-v1.json', 'INDEPENDENT-FORD-RECOVERY-VERIFICATION-v1.json', 1], ['currentNissanNormalReportOutcome', 'currentFordNormalReportOutcome', 1], ['currentNissanSavedComparatorOutcome', 'currentFordSavedComparatorOutcome', 1], ["'archiveReuse':141", "'archiveReuse':p['baseArchivesReused']", 1]], 'final_receipt': [['NISSAN-WORKING-', 'FORD-WORKING-', 2], ['Roadmark-NISSAN-M1-UPDATE-', 'Roadmark-FORD-M1-UPDATE-', 1], ['INDEPENDENT-NISSAN-RECOVERY-VERIFICATION-v1.json', 'INDEPENDENT-FORD-RECOVERY-VERIFICATION-v1.json', 1], ['FINAL-NISSAN-UPLOAD-RECEIPTS.json', 'FINAL-FORD-UPLOAD-RECEIPTS.json', 1]], 'main': [['INDEPENDENT-NISSAN-REFERENCE-CLOSURE-v2.json', 'INDEPENDENT-FORD-REFERENCE-CLOSURE-v2.json', 1], ["'acceptedFinalRetentionScope':'accepted'", "'acceptedFinalRetentionScope':'accepted factual/metadata retention only'", 1]]}
FIXED_PINS={'baseFinal': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/FINAL-NISSAN-UPLOAD-RECEIPTS.json', 'bytes': 49261, 'sha256': 'e6356c5af77521fb3d4492fdbd43832662947ccea89e84d7dd25e894e935f740'}, 'baseTerminal': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/INDEPENDENT-NISSAN-TERMINAL-CLOSURE-v1.json', 'bytes': 142559, 'sha256': '59a043f3a71c62f22bc0ecac95fabdad96f9b0375c39c4a3cad9fb1c59b3fffc'}, 'normalizer': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/renault-working-20261015T2040/delivery_native_adapter_v3.py', 'bytes': 12641, 'sha256': 'f5bec06d762fca6b3d34ea13f7e7f17d2f5353dbbd379a5e1b13e967aabbc474'}, 'captureAdapter': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_capture_adapter_v1.py', 'bytes': 2202, 'sha256': '0fccf034025e1550b4d2150681584464ac14ac6cdda03333fc75e44d79d0c74c'}, 'recoveryChecker': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/independent_ford_recovery_v5.py', 'bytes': 31932, 'sha256': '2bc86c7f5bacb053c5568a68ed1593b431e189296d598b06c607320e5cdd6238'}, 'referenceBuilder': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_reference_adapter_v2.py', 'bytes': 8904, 'sha256': '9fab2f535a9b75e4b98cad8982b5f399d43031cd6f35c7e0b3af495857f34161'}, 'referenceConfig': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/FORD-REFERENCE-CONFIG-v1.json', 'bytes': 22175, 'sha256': '76b08173191c7f3561001eef73f4f54d223bc86b9215badc03879a3f1ce37071'}, 'responseAdapter': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_closing_adapter_v5.py', 'bytes': 6862, 'sha256': '88617fa569527d6fed90ee3132ed0de656435d32bd9923d3cb21c5893422cfcc'}, 'responsePrior': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/nissan_closing_adapter_v5.py', 'bytes': 36401, 'sha256': '8bc24997dfb2726c090c4a86538eaf8682ee6dd51a0639322fc7af48e4d245e0'}, 'assemblyUtility': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_delivery_sealed_runtime_v2.py', 'bytes': 4506, 'sha256': '137c53c4d5e01a4c708aaa61ccd3c425ab3f53b7ef0bf8a8d153767f094b4d1f'}, 'baseChecker': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/independent_nissan_delivery_v7.py', 'bytes': 46199, 'sha256': 'ac1652f80f0aaf8113120a431c4eecbb392f6ceed68e7074be5f7914258ebd1a'}}

FORD_SHARED_HELPER_PINS = {'supportArchiveIdentity': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_support_archive_identity_v1.py',
                            'bytes': 9872,
                            'sha256': 'fe254de9da8209ddf670b4f337d209f0b0674dc0dc887c4b3e6cbe60be847955'},
 'supportMixedAuthority': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_support_mixed_authority_v1.py',
                           'bytes': 5821,
                           'sha256': '4d83ca398f870ca704f95fbede159c0f7ae1780345ac2250206fda25777936ed'}}
FIXED_PINS.update(FORD_SHARED_HELPER_PINS)
EDITS.setdefault('context', []).extend([('CONTRACT=c;LAUNCH=',
  "ck(c['sharedHelperPins']==FORD_SHARED_HELPER_PINS,'exact shared identity and mixed authority "
  "helpers');CONTRACT=c;LAUNCH=",
  1)])
EDITS.setdefault('recovery', []).extend([("for q in r['inputPins']:ck(ref(q['path'])==core(q),'recovery input not identically sealed')",
  'for key in '
  "('supportClassification','supportClassificationGrant','supportClassificationReview','supportPatternReport','supportPatternSelection'):\n"
  "  ck(inp[key]==rc['inputs'][key],'delivery/replay exact mixed authority pin differs')\n"
  " ck(CONTRACT['syntaxClassifications']==rc['syntaxClassifications'] and "
  "CONTRACT['jsonProseClassifications']==rc['jsonProseClassifications'] and "
  "CONTRACT['sharedHelperPins']==rc['sharedHelperPins'],'delivery/replay mixed runtime expectations "
  "differ')\n"
  " ck(CONTRACT['archivePrivacy']==rc['privacyReports'],'delivery/replay actual final archive reports "
  "differ')\n"
  " for q in r['inputPins']:ck(ref(q['path'])==core(q),'recovery input not identically sealed')",
  1)])
EDITS.setdefault('restore', []).extend([("reuse=get(C/'SUPPORT-REUSE-MAPPING.json');suppby=",
  "reuse=get(C/'SUPPORT-REUSE-MAPPING.json');ck(ref(C/'SUPPORT-REUSE-MAPPING.json')==IDENTITY_MAPPING_PIN "
  'and '
  "ref(B/'deliverables/Roadmark-RECOVERY-MANIFEST-NISSAN-WORKING-20261015.json')==IDENTITY_BASE_MANIFEST_PIN,'exact "
  'fixed identity metadata byte '
  "pins');ford_archive_identity=ford_bind_support_reuse_identity(reuse,base,reused);suppby=",
  1),
 ("a==reusedby.get(a['filename'])", "ford_archive_identity(x,reusedby.get(a['filename']))", 1)])
EDITS.setdefault('privacy', []).extend([("out=[];seen=set();ar=index(ars,'filename')",
  "mixed=ford_support_mixed_authority(CONTRACT);classes=[];jsonclasses=[];out=[];seen=set();ar=index(ars,'filename')",
  1),
 ("out.append({'report':spec['report'],'archive':name,'archivePin':d['archivePin'],'terminal':spec['terminal'],'invocation':spec['invocation']})",
  "classes.extend(d['classifiedExactCodeHeaderCandidates']);jsonclasses.extend(d.get('classifiedExactJSONProseCandidates',[]));out.append({'report':spec['report'],'archive':name,'archivePin':d['archivePin'],'terminal':spec['terminal'],'invocation':spec['invocation']})",
  1),
 ("ck(seen==set(ar),'missing final archive privacy');out.sort",
  "ck(seen==set(ar),'missing final archive privacy');ck(len({canonical(x) for x in classes})==len(classes) "
  "and len({canonical(x) for x in jsonclasses})==len(jsonclasses),'duplicate mixed report "
  "classification');ck(FORD_MIXED_AUTHORITY['report_records']({'classifiedExactCodeHeaderCandidates':classes,'classifiedExactJSONProseCandidates':jsonclasses},mixed,CONTRACT['syntaxClassifications'],CONTRACT['jsonProseClassifications']),'exact "
  "separate mixed report classifications');out.sort",
  1)])

def ford_inherited():
 b=get(FIXED['baseFinal'][0]);t=get(FIXED['baseTerminal'][0]);p=get(C/'SAFETY-SAVE-PLAN-v1.json');rv=load(p['base']['terminalResultReview'])
 ck(t['result']=='PASS_INDEPENDENT_NISSAN_TERMINAL' and t['inputPins'].count(ref(FIXED['baseFinal'][0]))==1,'prior exact terminal input chain')
 ck(rv['result']=='ACCEPTED_EXACT_NISSAN_QUALIFIED_TERMINAL_CLOSURE' and rv['terminalClosure']==ref(FIXED['baseTerminal'][0]) and rv['finalReceipt']==ref(FIXED['baseFinal'][0]),'prior qualified independent result')
 ck(b['counts']['archiveCount']==t['counts']['archiveCount']==145 and b['nativeByteReadbackVerified'] is t['nativeByteReadbackVerified'] is False,'prior145 native boundary')
 e=b['blockedReadbackEvidence']['inheritedRenaultReadbackDenial'];request=load(e['request']);response=load(e['response']);ck(response['isError'] is True and response['structuredContent']['error_code']=='FORBIDDEN' and '403' in response['structuredContent']['error'] and 'scope_violation' in response['structuredContent']['error'],'inherited403 evidence')
 ck(e['retries']==e['alternateReadRoutes']==0 and b['blockedReadbackEvidence']['deniedRouteRetried'] is False,'denied route retries')
 denial={'inheritedRenaultReadbackDenial':e,'inheritedNissanFinalReceipt':ref(FIXED['baseFinal'][0]),'inheritedNissanReadbackQualification':b['blockedReadbackEvidence'],'scope':'The historical denial was for the five Renault archive identities in its exact request. No Ford identity is claimed individually attempted or denied.','currentFordMaterializationAttempts':0,'currentFordAlternateReadRoutes':0,'deniedRouteRetried':False}
 old=b['referencedPriorDeliveryArtifactsOutsideRecovery'];closing=b['deliveryOnlyClosingArtifact'];cfg=get(FIXED['referenceConfig'][0])
 ck(closing['outsideRecoveryArchiveSet'] is True and closing['unchangedRecoveryArchiveCount']==145 and closing['nativeByteReadbackVerified'] is False,'Nissan closing boundary')
 ck([x['identity'] for x in cfg['deliveryOnlySupplements']]==[old['verification']['identity'],old['correction'],closing['artifact']],'exact three supplemental identities')
 supp={'verification':old['verification'],'correction':old['correction'],'nissanClosing':closing,'exactConfiguration':ref(FIXED['referenceConfig'][0]),'outsideCurrentRecoveryArchiveSet':True,'notNewFordArchives':True,'nativeByteReadbackVerified':False}
 return b,t,denial,supp

def ford_supplement_members(spec):
 pkg,inv=load(spec['package']),load(spec['inventory']);pm,attribution=independent_replay_supplement_members(spec,pkg,inv)
 ck(pkg['filename']==spec['identity']['filename'] and sh(pkg)==sh(spec['identity']),'supplement exact native tuple')
 ck(inv['outsideRecoveryArchiveSet'] is True and inv['unchangedRecoveryArchiveCount']==spec['originalCoreArchiveCount'] and inv['nativeByteReadbackVerified'] is False,'supplement inventory boundary')
 ck(sum(r['bytes'] for r in pm.values())==pkg['uncompressedBytes'] and len(inv['files'])==inv['filesInInventory'] and sum(r['bytes'] for r in inv['files'])==inv['bytesInInventory'],'supplement exact declared totals')
 return pm

def build():
 u=utility();own=ast.parse(P(__file__).read_bytes());f={n.name:n for n in own.body if isinstance(n,ast.FunctionDef)}
 tree=u.assembly(BASE,EDITS,{'inherited':f['ford_inherited'],'supplement_members':f['ford_supplement_members']})
 rt=ast.parse(u.read_exact(REPLAY));rf={n.name:n for n in rt.body if isinstance(n,ast.FunctionDef)}
 s=rf['ford_supplement_members'];s.name='independent_replay_supplement_members';tree.body.extend([s,rf['ford_inherited_accounting'],rf['ford_support_mixed_authority']]);ast.fix_missing_locations(tree)
 m=u.module(tree,__file__,'ford_independent_delivery');m.B=N;m.DATE='20261016';m.FIXED={k:(P(r['path']),r['bytes'],r['sha256']) for k,r in FIXED_PINS.items()};m.RESULTS={mode:'PASS_INDEPENDENT_FORD_'+mode.upper() for mode in ('documents','active','persisted','terminal')};m.OUTPUTS={'documents':'INDEPENDENT-FORD-DOCUMENT-CHECK-v1.json','active':'INDEPENDENT-FORD-ACTIVE-CHECK-v1.json','persisted':'INDEPENDENT-FORD-PERSISTED-CHECK-v1.json','terminal':'INDEPENDENT-FORD-TERMINAL-CLOSURE-v1.json'}
 m.NOTE='Local recovery replay passed. Library persistence is confirmed by server create receipts and matching local hashes. Native byte-readback remains unpassed after the inherited Library selected-folder 403 access boundary; no Ford readback request or alternative read route was attempted.'
 m.sealed=m.get;m.rows=m.member_rows;m.safe=lambda name:m.ck(isinstance(name,str) and not P(name).is_absolute() and '..' not in P(name).parts,'unsafe member path')
 def response(phase):
  spec=m.CONTRACT['normalizations'][phase];req=m.ref(C/f'library-{phase}-host-create-request.json');res=m.ref(C/f'library-{phase}-provider-results.json')
  m.ck(spec['rawRequest']==req and spec['rawResponse']==res,'exact raw normalization authority')
  helper=FIXED_PINS['responseAdapter'];m.ck(m.ref(helper['path'])==helper,'exact response adapter metadata seal');raw=m.raw(helper);adapter=u.module(ast.parse(raw),helper['path'],'ford_independent_response_semantics')
  return adapter.response_view(spec,m.raw(req),m.raw(res))
 identity=u.module(ast.parse(u.read_exact(FORD_SHARED_HELPER_PINS['supportArchiveIdentity'])),FORD_SHARED_HELPER_PINS['supportArchiveIdentity']['path'],'ford_exact_archive_identity')
 mixed=u.module(ast.parse(u.read_exact(FORD_SHARED_HELPER_PINS['supportMixedAuthority'])),FORD_SHARED_HELPER_PINS['supportMixedAuthority']['path'],'ford_exact_mixed_authority')
 m.ford_bind_support_reuse_identity=identity.bind_support_reuse_identity;m.IDENTITY_MAPPING_PIN=identity.MAPPING_PIN;m.IDENTITY_BASE_MANIFEST_PIN=identity.BASE_MANIFEST_PIN;m.FORD_SHARED_HELPER_PINS=FORD_SHARED_HELPER_PINS;m.FORD_MIXED_AUTHORITY=mixed.__dict__
 m.ford_response_view=response
 original_acceptance=m.acceptance
 def acceptance(confirmation,wanted,evidence):
  d=original_acceptance(confirmation,wanted,evidence);res=m.load(evidence['response']);m.ck(res['isError'] is False,'accepted send envelope must be successful');actual=m.at(res,evidence['responseTimestampPath'])
  m.ck(isinstance(actual,str) and d['acceptedAt']==actual,'accepted timestamp must be exact raw provider string');return d
 m.acceptance=acceptance
 return m

def main():build().main()
if __name__=='__main__':main()
