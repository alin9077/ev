#!/usr/bin/env python3
"""Pure Ford replay AST assembly/compile only; no checker function is executed."""
import ast, hashlib, json, pathlib, sys
import independent_ford_recovery_v2 as adapter

P = pathlib.Path
C = P(__file__).resolve().parent

def main():
    assert len(sys.argv) == 2 and P(sys.argv[1]) == C / 'FORD-REPLAY-ADAPTER-AST-TEST-v1.json'
    tree = adapter.adapted_tree(adapter.reference_bytes())
    compile(tree, str(adapter.BASE), 'exec')
    functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
    assert {'context', 'captures', 'archive_replay', 'references', 'accounting', 'main', 'supplement_members', 'ford_inherited_accounting'} <= functions.keys()
    imports = [n.module for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)]
    assert not any(n and ('capture' in n or 'privacy' in n) for n in imports)
    assert not any(isinstance(n, ast.If) and ast.dump(n.test) == ast.dump(ast.parse("__name__=='__main__'", mode='eval').body) for n in tree.body)
    values = [n.value for n in ast.walk(functions['main']) if isinstance(n, ast.Constant)]
    assert 'PASS_INDEPENDENT_FORD_FRESH_RECOVERY' in values and 'PASS_INDEPENDENT_NISSAN_FRESH_RECOVERY' not in values
    assert 'eightLiveTargetsVerified' in values and 'all545OriginalsStableThroughFinalGate' in values
    code = (C / 'independent_ford_recovery_v2.py').read_bytes()
    record = {'result': 'PASS_PURE_ADAPTER_AST_ASSEMBLY_COMPILE', 'adapter': {'path': str(C / 'independent_ford_recovery_v2.py'), 'bytes': len(code), 'sha256': hashlib.sha256(code).hexdigest()},
              'baseReference': {'path': str(adapter.BASE), **adapter.BASE_PIN}, 'functionsChecked': sorted(functions),
              'checkerNamespaceExecuted': False, 'checkerFunctionsExecuted': False, 'payloadOrArchiveOrSeedReads': 0,
              'scope': 'Exact source substitutions and replacement functions assemble and compile; runtime and payload semantics still require independent review and actual execution'}
    with P(sys.argv[1]).open('x') as f:
        json.dump(record, f, indent=2); f.write('\n')
    print(json.dumps({'result': record['result']}))

if __name__ == '__main__':
    main()
