#!/usr/bin/env python3
"""One exact retained synthetic-fixture comparison; no detector or generic classifier change."""
import ast,hashlib,json
TARGET={'member': 'ford-recovery-support/test_ford_support_adapter_v1.py', 'filePin': {'bytes': 8021, 'sha256': 'd80f87017fd3b74a7a4343da5d57a41c01855d1eb4a7877d0edba1eb7f676ca5'}, 'keyLiteralByteStart': 2799, 'keyLiteralByteEndExclusive': 2818, 'keyLiteralSHA256': '9e7abdea779ca8a4130c73cbc1042b8b670de04b6b0e75b3ed70c553a10b28d8', 'keyLiteralAstType': 'Constant[bytes]', 'astFunction': 'fixture', 'astOperation': 'Compare', 'astRole': 'synthetic-fixture-exact-byte-comparison', 'comparisonAstSHA256': 'a84e3b004feea919a1f455e00f6749886c3fa4a4fdfcca47ed2c9d275c7dad9f', 'assignmentAstSHA256': '9a4ad24044158d8f5664b44d661506f70159b3c543feaa7eab1295530b99a210', 'fixtureFunctionAstSHA256': '57e3345dac4d1df82d33e7b1416dd60d64e9d22c842275a7154615ca2f72f0f6', 'classification': 'exact-in-memory-synthetic-fixture-key-comparison'}

def checked_context(data,row,tree,parents,starts):
 def ck(ok,why):
  if not ok:raise ValueError(why)
 ck({'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}==TARGET['filePin'],'fixture whole-file scope')
 ck(all(row.get(k)==v for k,v in TARGET.items()),'fixture exact member/pin/span/AST authority')
 ck(row['exactFinding'].get('header')=='authorization','fixture header differs')
 begin,end=row['keyLiteralByteStart'],row['keyLiteralByteEndExclusive']
 def span(node):return starts[node.lineno-1]+node.col_offset,starts[node.end_lineno-1]+node.end_col_offset
 nodes=[n for n in ast.walk(tree) if isinstance(n,ast.Constant) and isinstance(n.value,bytes) and span(n)==(begin,end)]
 ck(len(nodes)==1,'fixture exact bytes node absent');node=nodes[0]
 ck(node.value==json.dumps(row['exactFinding']['header']).encode()+b':' and hashlib.sha256(data[begin:end]).hexdigest()==row['keyLiteralSHA256'],'fixture exact bytes value/hash')
 parent=parents[node];ck(isinstance(parent,ast.Compare) and len(parent.ops)==len(parent.comparators)==1 and isinstance(parent.ops[0],ast.Eq) and parent.comparators[0] is node,'fixture exact equality comparator')
 ck(isinstance(parent.left,ast.Attribute) and parent.left.attr=='value' and isinstance(parent.left.value,ast.Name) and parent.left.value.id=='n','fixture exact AST value receiver')
 lineage=[];current=node
 while current in parents:current=parents[current];lineage.append(current)
 funcs=[n for n in lineage if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))];ck([n.name for n in funcs]==['fixture','main'],'fixture exact nesting')
 assignments=[n for n in lineage if isinstance(n,ast.Assign)];ck(bool(assignments),'fixture assignment absent');assignment=assignments[0]
 ck(len(assignment.targets)==1 and isinstance(assignment.targets[0],ast.Name) and assignment.targets[0].id=='node' and isinstance(assignment.value,ast.Call) and isinstance(assignment.value.func,ast.Name) and assignment.value.func.id=='next','fixture exact next-node assignment')
 for node,key in ((parent,'comparisonAstSHA256'),(assignment,'assignmentAstSHA256'),(funcs[0],'fixtureFunctionAstSHA256')):
  ck(hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest()==row[key],'fixture exact enclosing AST hash')

def extend(module):
 original=module.ast_context
 def exact_or_prior(data,row,tree,parents,starts):
  if row.get('astRole')==TARGET['astRole']:return checked_context(data,row,tree,parents,starts)
  return original(data,row,tree,parents,starts)
 module.ast_context=exact_or_prior
 return module
