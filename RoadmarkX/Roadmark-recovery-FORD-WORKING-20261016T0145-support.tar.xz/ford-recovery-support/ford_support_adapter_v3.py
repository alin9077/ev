#!/usr/bin/env python3
"""Finite Ford support modes. Prior scanner/package/classifier code is pinned, never copied."""
import argparse,ast,collections,hashlib,json,pathlib,stat,sys,types
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent;R=C.parents[1]
PINS={'runtime': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_delivery_sealed_runtime_v2.py', 'bytes': 4506, 'sha256': '137c53c4d5e01a4c708aaa61ccd3c425ab3f53b7ef0bf8a8d153767f094b4d1f'}, 'capture': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_capture_adapter_v1.py', 'bytes': 2202, 'sha256': '0fccf034025e1550b4d2150681584464ac14ac6cdda03333fc75e44d79d0c74c'}, 'privacy': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_privacy_adapter_v1.py', 'bytes': 1608, 'sha256': '6ecbc232d448f863406b17d514e9ef5c9c05faac888937499752007440157003'}, 'classifier': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/nissan_support_privacy_adapter_v2.py', 'bytes': 9817, 'sha256': 'ad23291677e29b7d2646fd707edb584a2e27d1b36afe4f9f9e5e716135138eac'}, 'nissanPackage': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/package_nissan_support_v2.py', 'bytes': 1784, 'sha256': 'ee4d760cb78182fd5d439d2c6cda81f5f5085b14ae32094c6e3358b4ad20c85b'}, 'nissanGateway': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/nissan_phase_gateway_v2.py', 'bytes': 4385, 'sha256': '9320375725e900d042f6e5bbc7fc75f53564e16ec3a86af6e7fa9a07d82322df'}, 'package': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/renault-working-20261015T2040/package_v1.py', 'bytes': 3896, 'sha256': '7d05cd34ea0484cec3805dee49f1fe4afdccb7da2f6dd870470bbe748f9be8ac'}, 'patterns': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/renault-working-20261015T2040/preflight_patterns_v1.py', 'bytes': 939, 'sha256': '4a43afab5365a91c4a82233f912e503cf166cd0706f5706a9f22fa48e7be05d2'}, 'runner': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/renault-working-20261015T2040/run_bounded_v1.py', 'bytes': 2443, 'sha256': 'e0f7775ac03e02fb0cb746021b58a8bfdd71b3b315f1b9461482f2ba35fd8bce'}, 'fixtureExtension': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_support_fixture_context_v1.py', 'bytes': 3524, 'sha256': '7a2d89ca5916c5934e826d5bd725c93e322422a1b8a4333a8fbf299ee644fd51'}}
LABEL='FORD-WORKING-20261016T0145'
CLASSIFIER_FUNCTIONS=('require','digest','canon','ast_context','classify_exact','dump_dispatch')

def utility():
 r=PINS['runtime'];p=P(r['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in (p,*p.parents));b=p.read_bytes();t=p.lstat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns,t.st_ctime_ns) and {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}=={k:r[k] for k in ('bytes','sha256')};m=types.ModuleType('ford_support_runtime');m.__file__=str(p);exec(compile(b,str(p),'exec'),m.__dict__);return m

def classifier_module(u):
 tree=ast.parse(u.read_exact(PINS['classifier']),filename=PINS['classifier']['path'])
 nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in CLASSIFIER_FUNCTIONS]
 u.ck(tuple(n.name for n in nodes)==CLASSIFIER_FUNCTIONS,'exact classifier function set/order')
 m=types.ModuleType('ford_exact_support_classifier');m.__dict__.update(ast=ast,collections=collections,hashlib=hashlib,json=json,P=P,C=C)
 exec(compile(ast.Module(body=nodes,type_ignores=[]),PINS['classifier']['path'],'exec'),m.__dict__)
 p=PINS['fixtureExtension'];extension=u.module(ast.parse(u.read_exact(p)),p['path'],'ford_exact_fixture_context')
 return extension.extend(m)

def capture_module(u):
 p=PINS['capture'];m=u.module(ast.parse(u.read_exact(p)),p['path'],'ford_capture_adapter_v1');sys.modules['ford_capture_adapter_v1']=m
 return m,m.capture_module()

def privacy_module(u,seed_scope):
 capture,cap=capture_module(u);p=PINS['privacy'];m=u.module(ast.parse(u.read_exact(p)),p['path'],'ford_support_base_privacy')
 # False config still checks all exact engine/helper pins and never calls seed_sets.
 return capture,cap,m.configure(require_review=seed_scope)

def reference_module(u,key):
 # Nissan v2 routes to these exact Renault functions. Its code pins are provenance,
 # while the current finite runtime contract replaces Nissan's fixed filenames/counts.
 u.read_exact(PINS['nissanPackage' if key=='package' else 'nissanGateway'])
 p=PINS[key];return u.module(u.assembly(p,{}),p['path'],'ford_support_'+key+'_reference')

def metadata(u,table,r):
 u.ck(table.get(r['path'])==r,'unsealed metadata role');return u.json_exact(r)

def selected(u,rows,payload):
 u.ck(isinstance(rows,list) and bool(rows),'empty support selection')
 u.ck(len({r['path'] for r in rows})==len(rows) and len({r['payloadPath'] for r in rows})==len(rows),'duplicate support member/payload')
 for r in rows:
  p=P(r['path']);q=P(r['payloadPath']);u.ck(not p.is_absolute() and '..' not in p.parts and str(p)==r['path'] and '\\' not in r['path'],'unsafe member')
  u.ck(r['path'].startswith('ford-recovery-support/') and q.is_relative_to(C) and not q.is_relative_to(C/'deliverables'),'finite staged support only')
  u.ck(payload.get(str(q))=={'path':str(q),**u.sh(r)},'unsealed selected support payload')
 u.ck(set(payload)=={r['payloadPath'] for r in rows},'extra selected payload role')
 return rows

def raw_report(u,c,table):
 r=metadata(u,table,c['inputs']['patternReport']);s=metadata(u,table,c['inputs']['patternSelection'])
 u.ck(r['result'] in ('NO_PATTERN_CANDIDATES','REVIEW_REQUIRED') and r['seedReadsPerformed'] is False and r['selectionPin']==u.sh(c['inputs']['patternSelection']),'raw pattern authority')
 u.ck(r['filesInspected']==len(s['files']),'raw pattern completeness')
 inv=metadata(u,table,c['inputs']['patternInvocation']);terminal=metadata(u,table,c['inputs']['patternTerminal']);review=metadata(u,table,c['inputs']['patternReview'])
 u.ck(terminal['exitCode']==0 and terminal['timedOut'] is False and terminal['command']==inv['command'] and terminal['childPid']==inv['childPid'] and terminal['startedAt']==inv['startedAt'],'pattern terminal/invocation')
 u.ck(inv['addressSpaceLimitBytes']==terminal['addressSpaceLimitBytes']==268435456 and inv['wallLimitSeconds']==terminal['wallLimitSeconds']==600 and inv['processSerializationEstablished'] is True,'pattern bound/serialization')
 u.ck(review['result']=='ACCEPTED_EXACT_FORD_SUPPORT_PATTERN_REPORT' and review['report']==c['inputs']['patternReport'] and review['selection']==c['inputs']['patternSelection'] and review['terminal']==c['inputs']['patternTerminal'] and review['invocation']==c['inputs']['patternInvocation'],'pattern independent result review')
 return r,s

def classifications(u,c,table,member_rows):
 d=metadata(u,table,c['inputs']['classification']);g=metadata(u,table,c['inputs']['classificationGrant']);review=metadata(u,table,c['inputs']['classificationReview'])
 u.ck(d['result']=='ACCEPTED_EXACT_FORD_SUPPORT_CODE_SYNTAX_CLASSIFICATION' and d['rawPreflight']==c['inputs']['patternReport'],'classification exact raw authority')
 u.ck(review['result']=='ACCEPTED_EXACT_FORD_SUPPORT_CLASSIFICATION_AND_GRANT' and review['classification']==c['inputs']['classification'] and review['rootGrant']==c['inputs']['classificationGrant'],'classification independent review')
 u.ck(g['result']=='ROOT_APPROVED_EXACT_FORD_SUPPORT_SYNTAX' and g['classification']==c['inputs']['classification'] and g['additionalCandidatesApproved'] is False and g['sourceOrStagedEditsApproved'] is False,'classification grant scope')
 raw,selection=raw_report(u,c,table);files={r['member']:r for r in raw['candidateFiles']};rows=d['exactSupportCodeClassifications'];records=d['expectedClassifiedRecords']
 u.ck(len(files)==len(raw['candidateFiles']) and len(rows)==len(records),'classification unique files/count')
 u.ck(len(set(map(lambda x:json.dumps(x,sort_keys=True),rows)))==len(rows),'duplicate classification row')
 selected_rows={r['path']:r for r in selection['files']}
 for r in rows:
  n=r['member'];u.ck(n in files and n in selected_rows and r['filePin']==u.sh(selected_rows[n])==files[n]['filePin'],'classification exact member pin')
  u.ck(sum(x==r['exactFinding'] for x in files[n]['primary'])==1,'classification finding absent/duplicate in raw preflight')
  expected={'member':n,'filePin':r['filePin'],'finding':r['exactFinding'],'classification':r['classification']}
  u.ck(sum(x==expected for x in records)==1,'classification emitted record differs')
 # A global reviewed classification may span several sealed support parts. Only
 # exact members in this archive are consumed, without extending any classification.
 names={r['path'] for r in member_rows};subset=dict(d)
 subset['exactSupportCodeClassifications']=[r for r in rows if r['member'] in names]
 subset['expectedClassifiedRecords']=[r for r in records if r['member'] in names]
 return subset

def run_patterns(u,c,table,payload,outputs):
 selection=metadata(u,table,c['inputs']['selection']);rows=selected(u,selection['files'],payload)
 out=c['patternOutput'];u.ck(outputs=={out},'pattern exact output')
 capture,cap,privacy=privacy_module(u,False);m=reference_module(u,'patterns')
 sys.argv=[str(P(__file__).resolve()),c['inputs']['selection']['path'],out];m.main()
 result=u.json_exact(u.pin(out));u.ck(result['filesInspected']==len(rows) and result['seedReadsPerformed'] is False,'pattern completeness')

def run_package(u,c,table,payload,outputs):
 inv=metadata(u,table,c['inputs']['inventory']);rows=selected(u,inv['files'],payload)
 ap=P(c['archiveOutput']);op=c['packageOutput'];u.ck(outputs=={op} and ap.parent==R and ap.name.startswith('Roadmark-recovery-'+LABEL+'-support') and ap.name.endswith('.tar.xz') and not ap.exists(),'exact new support archive/output')
 u.ck(c['archiveOutputs']==[str(ap)],'archive outputs scope')
 raw,selection=raw_report(u,c,table);listed={r['path']:r for r in selection['files']}
 u.ck(all(listed.get(r['path'])==r for r in rows),'package rows absent from complete pattern selection')
 # Exact syntax authorization precedes package creation; it never waives
 # remaining header/runtime findings or later full current-known searches.
 classifications(u,c,table,rows)
 capture,cap=capture_module(u);m=reference_module(u,'package');m.LABEL=LABEL
 meta=c['embeddedMetadataMember'];cap.safe(meta);u.ck(meta.startswith('recovery-metadata/'+LABEL+'-support') and meta.endswith('.json') and meta not in {r['path'] for r in rows},'exact embedded inventory member')
 archive=m.pack(ap,rows,{meta:(json.dumps(inv,indent=2)+'\n').encode()})
 cap.dump(P(op),archive)


def run_privacy(u,c,table,payload,outputs):
 plan=metadata(u,table,c['inputs']['archivePlan']);archive=c['archive'];report=c['privacyOutput']
 matches=[r for r in plan['archives'] if r['file']==archive['path']];u.ck(len(matches)==1 and u.sh(matches[0])==u.sh(archive),'archive exact plan row');a=matches[0]
 u.ck(payload=={archive['path']:archive} and outputs=={report} and a['new'] is True and P(archive['path']).parent==R and a['filename']==P(archive['path']).name and a['filename'].startswith('Roadmark-recovery-'+LABEL+'-support'),'support-only payload scope')
 u.ck(a['allMembersVerified'] is True and a['members']==len(a['memberFiles']) and len({r['path'] for r in a['memberFiles']})==a['members'],'archive member scope')
 u.ck(c['inheritedSeedScope']==c['inputs']['inheritedSeedScope'] and metadata(u,table,c['inheritedSeedScope'])['inMemoryOnly'] is True,'exact inherited seed authority')
 scope=metadata(u,table,c['inheritedSeedScope']);u.ck(scope['actualRepeatedReadAccounting'] is True and scope['broadBaseScanOrClone'] is False and scope['rawExcludedPayloadReadRecoveryRefetch'] is False,'seed scope limits')
 d=classifications(u,c,table,a['memberFiles']);capture,cap,privacy=privacy_module(u,True);classifier=classifier_module(u)
 deepal=sys.modules['deepal_scan_additions_v2'];unchanged=deepal.code_context;members={r['member'] for r in d['exactSupportCodeClassifications']};seen=set();emitted=[];extra=[]
 def exact_context(candidates,data,name):
  remaining,inherited=unchanged(candidates,data,name);blocked,current=classifier.classify_exact(remaining,data,name,d)
  if name in members:
   u.ck(name not in seen,'approved support member repeated');seen.add(name);emitted.extend(current);extra.extend(blocked)
  return blocked,inherited+current
 deepal.code_context=exact_context
 privacy.dump=classifier.dump_dispatch(privacy.dump,P(report),cap.pin(C/'SEED-PROVENANCE.json'),members,seen,emitted,extra,d)
 # No scanner rewrite: source cache remains exact path+hash+rules only, and every
 # archive member still receives fresh integrity and current-known byte searches.
 sys.argv=[str(P(__file__).resolve()),archive['path'],report,c['inputs']['archivePlan']['path']];privacy.main()

def main():
 ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['patterns','package','privacy']);ap.add_argument('--contract',required=True);ap.add_argument('--contract-sha256',required=True);ap.add_argument('--review',required=True);ap.add_argument('--review-sha256',required=True);args=ap.parse_args()
 u=utility();c,table,payload,outputs=u.runtime(args,__file__,'SUPPORT')
 for r in PINS.values():u.ck(table.get(r['path'])==r,'support code pin missing from runtime metadata')
 u.ck(c['scope']['noLiveTreeTraversal'] is True and c['scope']['sourcePayloadReads'] is False and c['scope']['nativeReadback'] is False,'support scope')
 if args.mode!='privacy':u.ck(c['scope']['seedReads'] is False,'nonprivacy seed scope')
 else:u.ck(c['scope']['seedReads']=='exact-inherited-in-memory-only','privacy seed scope')
 {'patterns':run_patterns,'package':run_package,'privacy':run_privacy}[args.mode](u,c,table,payload,outputs)
if __name__=='__main__':main()
