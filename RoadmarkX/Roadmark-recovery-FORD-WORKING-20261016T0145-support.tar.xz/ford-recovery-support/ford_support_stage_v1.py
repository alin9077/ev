#!/usr/bin/env python3
"""Pinned support staging with exact logical-member schema adaptation only."""
import ast
import pathlib
from ford_capture_adapter_v1 import C, NISSAN, capture_module, load_reference, redirect_import, replace_constant

PIN = {'bytes': 4597, 'sha256': '01125100eae2435561bd6d72093b45bfcc19c8630a18669358a9de75a6f876fd'}


def package_rows(document, schema):
    assert schema in ('core-memberFiles', 'logical-path-originalPath', 'absolute-path-logical-member')
    if schema == 'core-memberFiles':
        rows = document['memberFiles']
    elif schema == 'logical-path-originalPath':
        rows = document['members']
    else:
        rows = []
        for row in document['members']:
            assert pathlib.Path(row['path']).is_absolute()
            assert not pathlib.Path(row['member']).is_absolute() and '..' not in pathlib.Path(row['member']).parts
            rows.append({'path': row['member'], 'bytes': row['bytes'], 'sha256': row['sha256'],
                         'originalPath': row['path']})
    assert isinstance(rows, list)
    assert len(rows) == len({r['path'] for r in rows})
    return rows


def transform(tree):
    redirect_import(tree, 'nissan_capture_adapter_v2', 'ford_capture_adapter_v1')
    replace_constant(tree, 'INDEPENDENTLY_ACCEPTED_EXACT_NISSAN_SUPPORT_SELECTION',
                     'INDEPENDENTLY_ACCEPTED_EXACT_FORD_SUPPORT_SELECTION', function='main')
    replace_constant(tree, 'EXPLICIT_UNIQUE_NISSAN_SUPPORT_SELECTION',
                     'EXPLICIT_UNIQUE_FORD_SUPPORT_SELECTION', function='main')
    # There are exactly two member-prefix occurrences in the pinned producer.
    hits = [n for n in ast.walk(tree) if isinstance(n, ast.Constant) and n.value == 'nissan-recovery-support/']
    assert len(hits) == 2
    for n in hits:
        n.value = 'ford-recovery-support/'
    expected_iter = ast.dump(ast.parse("package['members']", mode='eval').body)
    expected_rows = ast.dump(ast.parse("rows = d.get('memberFiles',d.get('members'))").body[0])
    changes = {'outsideRows': 0, 'mappingRows': 0}

    class Schemas(ast.NodeTransformer):
        def visit_For(self, node):
            if ast.dump(node.iter) == expected_iter:
                changes['outsideRows'] += 1
                node.iter = ast.parse("FORD_PACKAGE_ROWS(package, item['rowSchema'])", mode='eval').body
            return self.generic_visit(node)

        def visit_Assign(self, node):
            if ast.dump(node) == expected_rows:
                changes['mappingRows'] += 1
                return ast.copy_location(ast.parse("rows = FORD_PACKAGE_ROWS(d, r['archiveMappingSchema'])").body[0], node)
            return self.generic_visit(node)

    tree = Schemas().visit(tree)
    assert changes == {'outsideRows': 1, 'mappingRows': 1}
    return tree


if __name__ == '__main__':
    from ford_phase_gateway_v1 import verified_core_contract
    verified_core_contract()
    module = load_reference('ford_exact_support_stage', NISSAN / 'prepare_nissan_support_v1.py', PIN, transform)
    module.FORD_PACKAGE_ROWS = package_rows
    module.main()
