#!/usr/bin/env python3
"""Ford exact-reference adapter; imports perform no capture or seed operation."""
import ast, hashlib, pathlib, stat, sys, types
sys.dont_write_bytecode = True
P = pathlib.Path
C = P(__file__).resolve().parent
NISSAN = C.parent / 'nissan-working-20261015T2220'
B = C.parent / 'renault-working-20261015T2040'
R = C.parents[1]
UTILITY_PIN = {'bytes': 2488, 'sha256': '7d9f820e0af9a076e97f1d9b53524c1b9c6081cd5223f22d0630b87be919e14f'}

def utility():
    p = NISSAN / 'nissan_capture_adapter_v2.py'
    z = p.lstat()
    assert stat.S_ISREG(z.st_mode) and not any(q.is_symlink() for q in p.parents)
    before = (z.st_size, z.st_mtime_ns, z.st_ctime_ns, z.st_ino, z.st_dev)
    data = p.read_bytes()
    z = p.lstat()
    assert before == (z.st_size, z.st_mtime_ns, z.st_ctime_ns, z.st_ino, z.st_dev)
    assert {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} == UTILITY_PIN
    m = types.ModuleType('_ford_exact_nissan_utility')
    m.__file__ = str(p)
    sys.modules[m.__name__] = m
    exec(compile(ast.parse(data, filename=str(p)), str(p), 'exec'), m.__dict__)
    return m

_utility = utility()
exact_bytes = _utility.exact_bytes
load_reference = _utility.load_reference
replace_constant = _utility.replace_constant

def redirect_import(tree, old, new, expected=1):
    nodes = [n for n in ast.walk(tree) if isinstance(n, ast.ImportFrom) and n.module == old]
    assert len(nodes) == expected, (old, len(nodes), expected)
    for n in nodes:
        n.module = new
    return tree

def capture_transform(tree):
    # Edit original final count before original base count, preventing collisions.
    replace_constant(tree, 700, 706, function='source')
    replace_constant(tree, 697, 703, function='source')
    # Original changed-source count is already seven; preserve it.
    replace_constant(tree, 'deliverables/Roadmark-RECOVERY-MANIFEST-CUPRA-WORKING-20261015.json',
                     'deliverables/Roadmark-RECOVERY-MANIFEST-NISSAN-WORKING-20261015.json', function='proof')
    return tree

def capture_module():
    _utility.C = C
    _utility.capture_transform = capture_transform
    m = _utility.capture_module()
    m.BASE = NISSAN
    return m
