#!/usr/bin/env python3
"""Prepared-only synthetic identity regression suite: exact code/public metadata only.
Run only after separate approval. Never opens archives, source, staged or seed bytes.
"""
import copy
import hashlib
import json
import pathlib
import stat
import types
import unittest

C = pathlib.Path(__file__).resolve().parent
HELPER = {'path': str(C / 'ford_support_archive_identity_v1.py'), 'bytes': 9872, 'sha256': 'fe254de9da8209ddf670b4f337d209f0b0674dc0dc887c4b3e6cbe60be847955'}


def exact_bytes(pin):
    path = pathlib.Path(pin['path'])
    assert path.suffix in ('.py', '.json') and path.is_absolute()
    assert not any(item.is_symlink() for item in (path, *path.parents))
    before = path.stat()
    assert stat.S_ISREG(before.st_mode)
    raw = path.read_bytes()
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    assert {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()} == {key: pin[key] for key in ('bytes', 'sha256')}
    return raw


class ExactFordArchiveIdentity(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        module = types.ModuleType('approved_identity_test_target')
        module.__file__ = HELPER['path']
        exec(compile(exact_bytes(HELPER), HELPER['path'], 'exec'), module.__dict__)
        cls.module = module
        cls.original_mapping = json.loads(exact_bytes(module.MAPPING_PIN))
        cls.original_base = json.loads(exact_bytes(module.BASE_MANIFEST_PIN))

    def setUp(self):
        self.mapping = copy.deepcopy(self.original_mapping)
        self.base = copy.deepcopy(self.original_base)
        self.reused = [row for row in self.base['archivesInRestoreOrder'] if row['filename'] != self.base['source']['filename']]

    def bind(self):
        return self.module.bind_support_reuse_identity(self.mapping, self.base, self.reused)

    def test_exact_ten_and_ordinary48_accept_and_outside11_reject(self):
        predicate = self.bind()
        current = {row['filename']: row for row in self.reused}
        changed = ordinary = outside = 0
        for row in self.mapping['files']:
            historical = row['retainedArchive']
            if row['outsideRecoveryArchiveSet']:
                outside += 1
                self.assertFalse(predicate(row, historical))
            else:
                actual = current[historical['filename']]
                self.assertTrue(predicate(row, actual))
                if historical != actual:
                    changed += 1
                    self.assertFalse(predicate(row, historical))
                else:
                    ordinary += 1
        self.assertEqual((changed, ordinary, outside), (10, 48, 11))
        self.assertEqual(self.mapping, self.original_mapping)
        self.assertEqual(self.base, self.original_base)

    def test_each_native_identity_field_mutation_rejected_at_bind_and_predicate(self):
        original_predicate = self.bind()
        original_row = self.mapping['files'][38]
        current = next(row for row in self.reused if row['filename'] == original_row['retainedArchive']['filename'])
        for field in self.module.IDENTITY_FIELDS:
            with self.subTest(field=field):
                changed = copy.deepcopy(original_row)
                value = changed['retainedArchive'][field]
                changed['retainedArchive'][field] = value + 1 if type(value) is int else value + '-changed'
                self.assertFalse(original_predicate(changed, current))
                candidate = copy.deepcopy(self.mapping)
                candidate['files'][38] = changed
                with self.assertRaises(AssertionError):
                    self.module.bind_support_reuse_identity(candidate, self.base, self.reused)
                changed_current = copy.deepcopy(current)
                value = changed_current[field]
                changed_current[field] = value + 1 if type(value) is int else value + '-changed'
                self.assertFalse(original_predicate(original_row, changed_current))

    def test_missing_duplicate_reordered_and_extra_mapping_reject(self):
        variants = []
        for operation in ('missing', 'duplicate', 'reordered', 'extra'):
            mapping = copy.deepcopy(self.mapping)
            if operation == 'missing': mapping['files'].pop()
            if operation == 'duplicate': mapping['files'][0] = copy.deepcopy(mapping['files'][1])
            if operation == 'reordered': mapping['files'][0], mapping['files'][1] = mapping['files'][1], mapping['files'][0]
            if operation == 'extra': mapping['files'].append(copy.deepcopy(mapping['files'][0]))
            variants.append((operation, mapping))
        for operation, mapping in variants:
            with self.subTest(operation=operation), self.assertRaises(AssertionError):
                self.module.bind_support_reuse_identity(mapping, self.base, self.reused)

    def test_unexpected_field_value_and_eleventh_qualification_reject(self):
        for index, field, value in ((38, 'unexpected', True), (38, 'members', 132), (38, 'file', '/changed'), (0, 'new', True), (0, 'restoreOrder', 999), (38, 'new', False), (38, 'restoreOrder', 140)):
            with self.subTest(index=index, field=field):
                mapping = copy.deepcopy(self.mapping)
                mapping['files'][index]['retainedArchive'][field] = value
                with self.assertRaises(AssertionError):
                    self.module.bind_support_reuse_identity(mapping, self.base, self.reused)

    def test_changed_current_base_and_reused_order_reject(self):
        base = copy.deepcopy(self.base)
        base['archivesInRestoreOrder'][139]['restoreOrder'] = 141
        with self.assertRaises(AssertionError): self.module.bind_support_reuse_identity(self.mapping, base, self.reused)
        reordered = copy.deepcopy(self.reused)
        reordered[0], reordered[1] = reordered[1], reordered[0]
        with self.assertRaises(AssertionError): self.module.bind_support_reuse_identity(self.mapping, self.base, reordered)
        for rows in (self.reused[:-1], [*self.reused, self.reused[0]]):
            with self.assertRaises(AssertionError): self.module.bind_support_reuse_identity(self.mapping, self.base, rows)

    def test_boolean_integer_substitution_and_unrelated_metadata_change_reject(self):
        mapping = copy.deepcopy(self.mapping)
        mapping['files'][38]['retainedArchive']['new'] = 1
        with self.assertRaises(AssertionError): self.module.bind_support_reuse_identity(mapping, self.base, self.reused)
        mapping = copy.deepcopy(self.mapping)
        mapping['noExecutableSourceTextEmbedded'] = not mapping['noExecutableSourceTextEmbedded']
        with self.assertRaises(AssertionError): self.module.bind_support_reuse_identity(mapping, self.base, self.reused)
        base = copy.deepcopy(self.base)
        base['title'] += ' changed'
        with self.assertRaises(AssertionError): self.module.bind_support_reuse_identity(self.mapping, base, self.reused)

    def test_bound_predicate_does_not_expand_after_input_mutation(self):
        predicate = self.bind()
        row = self.mapping['files'][38]
        current = next(archive for archive in self.reused if archive['filename'] == row['retainedArchive']['filename'])
        row['retainedArchive']['members'] += 1
        current['members'] += 1
        self.assertFalse(predicate(row, current))
        self.assertFalse(predicate(None, None))


if __name__ == '__main__':
    unittest.main()
