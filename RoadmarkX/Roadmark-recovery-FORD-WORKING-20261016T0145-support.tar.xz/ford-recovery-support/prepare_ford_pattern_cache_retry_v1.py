#!/usr/bin/env python3
"""Derive exact prior-pattern credit and current retry selection, without payload reads."""
import hashlib
import json
from pathlib import Path
from ford_phase_gateway_v1 import verified_core_contract
from ford_privacy_adapter_v1 import configure

C = Path(__file__).resolve().parent
SELECTION_PIN = {'bytes': 960791, 'sha256': '700730fa314fdd6b26b7c06b3f500b3d345431ff57f8e6b018368d475934df65'}
FAILURE_PIN = {'bytes': 3969, 'sha256': 'cb921068905f63341cd699477f41cfd24ed077b25b87b13dc136463b66fca72e'}


def core(row):
    return {k: row[k] for k in ('path', 'bytes', 'sha256')}


def partition(rows, cache):
    assert len(rows) == len({r['path'] for r in rows})
    assert all(core(r) == r for r in cache.values())
    assert all(path == row['path'] for path, row in cache.items())
    cached, current = [], []
    for index, row in enumerate(rows):
        if cache.get(row['path']) == core(row):
            cached.append({'originalSelectionIndex': index, **core(row)})
        else:
            current.append(row)
    assert len(cached) + len(current) == len(rows)
    assert {r['path'] for r in cached}.isdisjoint(r['path'] for r in current)
    assert {r['path'] for r in cached + current} == {r['path'] for r in rows}
    return cached, current


def main():
    cap = verified_core_contract()
    original = C / 'FRESH-PATTERN-SELECTION-v1.json'
    failure = C / 'PATTERN-PREFLIGHT-FAILURE-v1.json'
    cap.check(original, SELECTION_PIN)
    cap.check(failure, FAILURE_PIN)
    rows = cap.load(original)['files']
    # This is the unchanged full archive scanner's exact prior source/rule authority.
    # configure(False) checks imported engine/helper identities, but never calls seed_sets.
    privacy = configure(require_review=False)
    cache, provenance = privacy.source_cache()
    assert len(cache) == 656
    cached, current = partition(rows, cache)
    assert (len(rows), len(cached), len(current)) == (1244, 636, 608)
    assert sum(r['bytes'] for r in cached) == 275536313
    assert sum(r['bytes'] for r in current) == 73333498
    assert max(r['bytes'] for r in current) == 11912272
    def ref(p):
        return {'path': str(p), **cap.pin(p)}
    def new(name, value):
        p = C / name
        raw = (json.dumps(value, indent=2) + '\n').encode()
        with p.open('xb') as f:
            f.write(raw)
        return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    selection = new('FRESH-PATTERN-SELECTION-v2.json', {
        'status': 'EXACT_NONCACHED_ROWS_REQUIRE_FULL_CURRENT_PATTERNS',
        'files': current, 'originalSelection': ref(original),
        'currentPatternRows': len(current), 'cachedPatternRows': len(cached),
        'noPayloadReadByThisPreparation': True})
    credit = new('SOURCE-PATTERN-CACHE-CREDIT-v1.json', {
        'status': 'EXACT_PRIOR_SOURCE_AND_RULE_PATTERN_CREDIT_ONLY',
        'originalSelection': ref(original), 'currentSelection': selection,
        'sourceCacheAuthority': provenance, 'priorCacheRows': len(cache),
        'creditedRows': cached, 'creditedRowCount': len(cached),
        'creditedBytes': sum(r['bytes'] for r in cached),
        'freshCurrentPatternRows': len(current),
        'freshCurrentPatternBytes': sum(r['bytes'] for r in current),
        'originalFailedPreflight': ref(failure),
        'originalFailedCompletedMemberCount': 'UNKNOWN',
        'originalFailedMemberIdentity': 'UNKNOWN',
        'cachedRowsAreNewPatternExecution': False,
        'currentKnownValueSearchForEveryArchiveMemberStillRequired': True,
        'noDetectorRuleDecoderOrClassificationChange': True,
        'sourceOrResearchOrArchivePayloadReadsByPreparation': 0,
        'seedValueReadsByPreparation': 0})
    command = ['python', str(C.parent / 'renault-working-20261015T2040' / 'run_bounded_v1.py'),
               str(C / 'preflight-patterns-v2.resources.json'), '--sole-heavy-slot',
               'python', str(C / 'ford_phase_gateway_v1.py'), 'preflight-patterns',
               selection['path'], str(C / 'FRESH-PATTERN-CANDIDATES-v2.json')]
    new('FRESH-PATTERN-RETRY-INVOCATION-v1.json', {
        'status': 'PREPARED_NOT_EXECUTED_REQUIRES_EXACT_RESULT_REVIEW',
        'selection': selection, 'cacheCredit': credit, 'preparer': ref(Path(__file__)),
        'command': command, 'currentPatternRows': 608, 'cachedPriorPatternRows': 636,
        'seedReadsPerformedByRetry': False,
        'fullArchiveScansRemainHeldForResultClassification': True})
    print(json.dumps({'result': 'EXACT_CACHE_BOUND_RETRY_PREPARED', 'cachedPriorPatternRows': len(cached),
                      'fullCurrentPatternRows': len(current), 'payloadReads': 0, 'seedValueReads': 0}))


if __name__ == '__main__':
    main()
