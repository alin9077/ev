#!/usr/bin/env python3
"""Derive finite support mappings from sealed metadata; never open archive payloads."""
import hashlib
import json
import pathlib
import sys

F = pathlib.Path(__file__).resolve().parent
assert F.name == 'ford-working-20261016T0145'


def identity(p):
    s = p.stat()
    return (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_mode)


def read(pin):
    p = pathlib.Path(pin['path'])
    assert p.is_absolute() and p.is_file() and not p.is_symlink()
    before = identity(p)
    b = p.read_bytes()
    assert identity(p) == before
    assert len(b) == pin['bytes'] and hashlib.sha256(b).hexdigest() == pin['sha256']
    return b


def core(x):
    return {k: x[k] for k in ('bytes', 'sha256')}


def rows(document, schema):
    assert schema in ('core-memberFiles', 'logical-path-originalPath', 'absolute-path-logical-member')
    if schema == 'core-memberFiles':
        result = document['memberFiles']
    elif schema == 'logical-path-originalPath':
        result = document['members']
    else:
        result = []
        for r in document['members']:
            assert pathlib.Path(r['path']).is_absolute()
            result.append({'path': r['member'], 'originalPath': r['path'], **core(r)})
    assert len(result) == len({r['path'] for r in result})
    for r in result:
        assert not pathlib.Path(r['path']).is_absolute() and '..' not in pathlib.Path(r['path']).parts
    return result


def main():
    assert len(sys.argv) == 3
    cp = pathlib.Path(sys.argv[1])
    assert cp.parent == F and cp.name == 'FORD-EXTERNAL-SUPPORT-INPUTS-v1.json'
    b = cp.read_bytes()
    assert hashlib.sha256(b).hexdigest() == sys.argv[2]
    c = json.loads(b)
    assert c['status'] == 'SEALED_FINITE_PUBLIC_SUPPORT_MAPPING_INPUTS'
    private = {x['path'] for x in c['localOnlyPrivateSeedInputPins']}
    assert len(private) == 10
    candidates = c['candidates']
    assert len(candidates) == len({x['expected']['path'] for x in candidates})
    assert not private.intersection(x['expected']['path'] for x in candidates)
    loaded = {}
    def load(pin):
        assert pin['path'] not in private
        key = (pin['path'], pin['bytes'], pin['sha256'])
        if key not in loaded:
            loaded[key] = json.loads(read(pin))
        return loaded[key]
    base = load(c['baseManifest'])
    oldsource = base['source']['filename']
    archives = {a['filename']: a for a in base['archivesInRestoreOrder'] if a['filename'] != oldsource}
    members = {r['path']: r for r in base['files'] if not r['path'].startswith('roadmark/')}
    index = {}
    def add(original, member, a, auth, schema, outside):
        d = load(auth)
        assert d['filename'] == a['filename'] and core(d) == core(a)
        aa = archives[a['filename']]
        assert all(aa.get(k) == a.get(k) for k in ('filename', 'bytes', 'sha256', 'library_file_id', 'file_id', 'version') if k in a)
        matching = [r for r in rows(d, schema) if r['path'] == member]
        assert len(matching) == 1 and member in members and core(matching[0]) == core(members[member])
        v = {'retainedMember': member, 'retainedArchive': a, 'archiveMappingAuthority': auth,
             'archiveMappingSchema': schema, 'outsideRecoveryArchiveSet': outside}
        key = (original, matching[0]['bytes'], matching[0]['sha256'])
        index.setdefault(key, []).append(v)
    outside = c['outsideRecoveryArtifacts']
    assert len(outside) == 3
    for item in outside:
        a = item['archive']
        assert a['filename'] not in archives
        archives[a['filename']] = a
        for m in rows(load(item['package']), item['rowSchema']):
            assert m['path'] not in members
            members[m['path']] = m
        inv = load(item['inventory'])
        for r in inv['files']:
            if item['rowSchema'] == 'absolute-path-logical-member':
                original, member = r['path'], r['member']
            else:
                original, member = r['originalPath'], r['path']
            add(original, member, a, item['package'], item['rowSchema'], True)
    package = load(c['corePackage'])
    a = archives[package['filename']]
    for r in load(c['coreInventory'])['files']:
        add(r['originalPath'], r['path'], a, c['corePackage'], 'core-memberFiles', False)
    for r in load(c['priorReuse'])['files']:
        auth = r['archiveMappingAuthority']
        d = load(auth)
        schema = 'core-memberFiles' if 'memberFiles' in d else 'logical-path-originalPath'
        if 'members' in d and isinstance(d['members'], list) and d['members'] and 'member' in d['members'][0]:
            schema = 'absolute-path-logical-member'
        add(r['originalPath'], r['retainedMember'], r['retainedArchive'], auth, schema, bool(r.get('outsideRecoveryArchiveSet')))
    result = []
    for item in candidates:
        pin = item['expected']
        read(pin)
        rel = item['localRelativePath']
        assert not pathlib.Path(rel).is_absolute() and '..' not in pathlib.Path(rel).parts
        r = {'originalPath': pin['path'], 'localRelativePath': rel, **core(pin),
             'externalOriginalExplicitlySelected': True, 'selectionReason': item['reason']}
        matches = index.get((pin['path'], pin['bytes'], pin['sha256']), [])
        unique = {(x['retainedArchive']['filename'], x['retainedMember']): x for x in matches}
        if unique:
            assert item['requiredDisposition'] != 'fresh'
            # If a path has historical exact duplicates, choose the explicitly ordered core/old mapping deterministically.
            chosen = sorted(unique.values(), key=lambda x: (x['outsideRecoveryArchiveSet'], x['retainedArchive']['filename'], x['retainedMember']))[0]
            r.update(chosen)
            r['action'] = 'reuse'
        else:
            assert item['requiredDisposition'] != 'reuse'
            assert pathlib.Path(pin['path']).suffix in ('.json', '.txt', '.log', '.md', '.patch')
            r['action'] = 'fresh'
            r['priorExactMemberMappingFound'] = False
            r['retentionDisclosure'] = 'Fresh public metadata retained now; no exact prior member was found in the finite declared authorities. No earlier byte retention is claimed.'
        result.append(r)
    assert len(result) == len({r['localRelativePath'] for r in result})
    out = {'status': 'PROPOSED_FINITE_EXACT_FORD_EXTERNAL_SUPPORT', 'baseManifest': c['baseManifest'],
           'outsideRecoveryArtifacts': outside, 'files': result,
           'localOnlyPrivateSeedInputPins': c['localOnlyPrivateSeedInputPins'],
           'privateSeedInputPayloadsSelected': False, 'privateSeedInputPayloadsRead': False,
           'metadataAuthoritiesRead': [{'path': k[0], 'bytes': k[1], 'sha256': k[2]} for k in sorted(loaded)],
           'inputContract': {'path': str(cp), 'bytes': len(b), 'sha256': sys.argv[2]},
           'archivePayloadsRead': False, 'sourceResearchPayloadsRead': False,
           'priorByteRetentionNotInferredFromBasenames': True,
           'newExecutableBytesSelected': False,
           'counts': {'selected': len(result), 'fresh': sum(r['action'] == 'fresh' for r in result),
                      'reused': sum(r['action'] == 'reuse' for r in result)}}
    op = F / 'FORD-EXTERNAL-SUPPORT-PROPOSAL-v1.json'
    with op.open('x') as f:
        json.dump(out, f, indent=2)
        f.write('\n')
    print(json.dumps({'output': str(op), **out['counts']}))


if __name__ == '__main__':
    main()
