#!/usr/bin/env python3
"""Exact public-metadata/code-only Ford mixed tests. No scanner, seed or payload phase."""
import argparse,ast,collections,contextlib,copy,hashlib,io,json,pathlib,stat,sys,types
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent
PINS={'runtime': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_delivery_sealed_runtime_v2.py', 'bytes': 4506, 'sha256': '137c53c4d5e01a4c708aaa61ccd3c425ab3f53b7ef0bf8a8d153767f094b4d1f'}, 'authority': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_support_mixed_authority_v1.py', 'bytes': 5821, 'sha256': '4d83ca398f870ca704f95fbede159c0f7ae1780345ac2250206fda25777936ed'}, 'jsonContext': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_support_json_prose_context_v1.py', 'bytes': 2340, 'sha256': 'db97cec5332801962a12164c1b8b4f9804997e8d77ca56d9c6459c0fedfcb5e7'}, 'support': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_support_adapter_v5.py', 'bytes': 8329, 'sha256': 'ffa370250138af1a0389110badd64634eaa0d4efa8224839b00fe0f1eb80e267'}, 'append': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_support_append_adapter_v2.py', 'bytes': 6852, 'sha256': 'a7e1c904c2c84233f522559b63f2f5d28e6b186fad9a362d638ea1789b990f66'}, 'fixtureExtension': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_support_fixture_context_v1.py', 'bytes': 3524, 'sha256': '7a2d89ca5916c5934e826d5bd725c93e322422a1b8a4333a8fbf299ee644fd51'}, 'fixtureSource': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/test_ford_support_adapter_v1.py', 'bytes': 8021, 'sha256': 'd80f87017fd3b74a7a4343da5d57a41c01855d1eb4a7877d0edba1eb7f676ca5'}, 'priorClassifier': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/nissan_support_privacy_adapter_v2.py', 'bytes': 9817, 'sha256': 'ad23291677e29b7d2646fd707edb584a2e27d1b36afe4f9f9e5e716135138eac'}}

def utility():
 r=PINS['runtime'];p=P(r['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in (p,*p.parents));b=p.read_bytes();t=p.lstat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns,t.st_ctime_ns) and {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}=={k:r[k] for k in ('bytes','sha256')};m=types.ModuleType('ford_mixed_test_loader');m.__file__=str(p);exec(compile(b,str(p),'exec'),m.__dict__);return m

def main():
 ap=argparse.ArgumentParser(allow_abbrev=False);ap.add_argument('mode',choices=['selftest']);ap.add_argument('--contract',required=True);ap.add_argument('--contract-sha256',required=True);ap.add_argument('--review',required=True);ap.add_argument('--review-sha256',required=True);args=ap.parse_args();u=utility();c,table,payload,outputs=u.runtime(args,__file__,'SUPPORT_MIXED_TEST')
 u.ck(payload=={} and outputs=={c['reportOutput']} and c['scope']=={'seedReads':False,'sourcePayloadReads':False,'archivePayloadReads':False,'researchPayloadReads':False,'nativeReadback':False,'noLiveTreeTraversal':True},'pure exact test scope')
 for r in PINS.values():u.ck(table.get(r['path'])==r,'test helper pin')
 def module(key):
  r=PINS[key];return u.module(ast.parse(u.read_exact(r)),r['path'],'ford_test_'+key)
 authority=module('authority');context=module('jsonContext');support=module('support');append=module('append');extension=module('fixtureExtension')
 proposal=u.json_exact(authority.FIXED_PINS['approvedProposal']);grant0=u.json_exact(authority.FIXED_PINS['initialClassificationGrant']);raw0=u.json_exact(authority.FIXED_PINS['initialPatternReport']);selection=u.json_exact(c['inputs']['initialSelection'])
 for r in authority.FIXED_PINS.values():u.ck(table.get(r['path'])==r,'test semantic metadata sealed')
 code_rows,prose=authority.expected(proposal,grant0,raw0);cases=[]
 def test(name,fn,reject=False):
  try:
   with contextlib.redirect_stderr(io.StringIO()):fn()
  except (ValueError,AssertionError,KeyError,TypeError,SystemExit,json.JSONDecodeError):
   if not reject:raise
  else:u.ck(not reject,'negative accepted: '+name)
  cases.append({'case':name,'result':'PASS'})
 def mutate(v,fn):
  out=copy.deepcopy(v);fn(out);return out
 for row in prose:
  r={'path':row['originalPath'],**row['filePin']};u.ck(table.get(r['path'])==r,'public review fixture exact pin');data=u.read_exact(r);candidates=[row['exactFinding']]
  test('json-accept-'+P(r['path']).name,lambda:context.classify_exact(candidates,data,row['member'],prose))
  for label,change in [('missing',lambda x:x.clear()),('duplicate',lambda x:x.append(copy.deepcopy(x[0]))),('added',lambda x:x.append({'kind':'unexpected'})),('changed',lambda x:x[0].update(valueLength=x[0]['valueLength']+1))]:
   test('json-finding-'+label+'-'+P(r['path']).name,lambda change=change:context.classify_exact(mutate(candidates,change),data,row['member'],prose),True)
  test('json-changed-file-'+P(r['path']).name,lambda:context.classify_exact(candidates,data+b' ',row['member'],prose),True)
  index=prose.index(row)
  for key,value in [('member',row['member']+'-other'),('filePin',{'bytes':row['filePin']['bytes']+1,'sha256':row['filePin']['sha256']}),('jsonPointer','/nested/'+row['exactFinding']['header']),('keyTokenByteStart',row['keyTokenByteStart']+1),('valueTokenByteEndExclusive',row['valueTokenByteEndExclusive']-1),('expectedDecodedReviewScopeProse',row['expectedDecodedReviewScopeProse']+' changed')]:
   test('json-row-'+key+'-'+str(index),lambda key=key,value=value,index=index:context.classify_exact(candidates,data,row['member'],mutate(prose,lambda x:x[index].update({key:value}))),True)
 key=prose[0]['exactFinding']['header']
 test('json-duplicate-top-key',lambda:json.loads(json.dumps({key:1})[:-1]+','+json.dumps(key)+':2}',object_pairs_hook=context.unique_object),True)
 test('json-duplicate-nested-key',lambda:json.loads('{"nested":'+json.dumps({key:1})[:-1]+','+json.dumps(key)+':2}}',object_pairs_hook=context.unique_object),True)
 test('json-unknown-member-remains-unclassified',lambda:u.ck(context.classify_exact([{'kind':'unlisted'}],b'{}','unlisted.json',prose)==([{'kind':'unlisted'}],[]),'unknown swallowed'))
 roles={**authority.FIXED_PINS,'classification':{'path':str(C/'synthetic-classification.json'),'bytes':1,'sha256':'1'*64},'classificationGrant':{'path':str(C/'synthetic-grant.json'),'bytes':1,'sha256':'2'*64},'classificationReview':{'path':str(C/'synthetic-review.json'),'bytes':1,'sha256':'3'*64},'patternReport':{'path':str(C/'synthetic-final-report.json'),'bytes':1,'sha256':'4'*64},'patternSelection':c['inputs']['initialSelection']}
 d={'schemaVersion':1,'result':authority.RESULT,'rawPreflight':roles['patternReport'],'initialRawPreflight':roles['initialPatternReport'],'approvedProposal':roles['approvedProposal'],'initialRootGrant':roles['initialClassificationGrant'],'exactSupportCodeClassifications':code_rows,'expectedClassifiedRecords':[authority.emitted(x) for x in code_rows],'exactSupportJSONProseClassifications':prose,'expectedJSONProseRecords':[authority.emitted(x) for x in prose]}
 g={'result':authority.GRANT_RESULT,'classification':roles['classification'],'approvedProposal':roles['approvedProposal'],'additionalCandidatesApproved':False,'sourceOrStagedEditsApproved':False};review={'result':'ACCEPTED_EXACT_FORD_SUPPORT_CLASSIFICATION_AND_GRANT','classification':roles['classification'],'rootGrant':roles['classificationGrant']}
 def validate(dd=d,gg=g,rr=raw0,ss=selection):return authority.validate(dd,gg,review,rr,ss,proposal,grant0,raw0,roles)
 test('mixed-final-authority-accept',validate)
 for field in ('exactSupportCodeClassifications','expectedClassifiedRecords','exactSupportJSONProseClassifications','expectedJSONProseRecords'):
  for label,change in [('missing',lambda x:x.pop()),('duplicate',lambda x:x.append(copy.deepcopy(x[0]))),('extra',lambda x:x.append({'unexpected':True}))]:
   test('mixed-'+field+'-'+label,lambda field=field,change=change:validate(mutate(d,lambda x:change(x[field]))),True)
 test('mixed-final-raw-rebind-rejected',lambda:validate(mutate(d,lambda x:x.update(rawPreflight=roles['initialPatternReport']))),True)
 test('mixed-old-root-grant-rejected',lambda:validate(d,grant0),True)
 test('mixed-grant-different-classification',lambda:validate(d,mutate(g,lambda x:x.update(classification=roles['patternReport']))),True)
 test('mixed-grant-additional-candidates',lambda:validate(d,mutate(g,lambda x:x.update(additionalCandidatesApproved=True))),True)
 for label,change in [('missing',lambda x:x['candidateFiles'].pop()),('duplicate',lambda x:x['candidateFiles'].append(copy.deepcopy(x['candidateFiles'][0]))),('runtime',lambda x:x['candidateFiles'][0]['runtime'].append({'field':'unexpected'}))]:
  test('raw-final-'+label,lambda change=change:validate(d,g,mutate(raw0,change)),True)
 test('selection-duplicate-file',lambda:validate(d,g,raw0,mutate(selection,lambda x:x['files'].append(copy.deepcopy(x['files'][0])))),True)
 report={'classifiedExactCodeHeaderCandidates':d['expectedClassifiedRecords'],'classifiedExactJSONProseCandidates':d['expectedJSONProseRecords']}
 test('separate-report-records-accept',lambda:authority.report_records(report,d,d['expectedClassifiedRecords'],d['expectedJSONProseRecords']))
 for field in report:
  for label,change in [('missing',lambda x:x.pop()),('duplicate',lambda x:x.append(copy.deepcopy(x[0]))),('changed',lambda x:x[0].update(classification='unapproved'))]:
   test('report-'+field+'-'+label,lambda field=field,change=change:authority.report_records(mutate(report,lambda x:change(x[field])),d,d['expectedClassifiedRecords'],d['expectedJSONProseRecords']),True)
 prior=ast.parse(u.read_exact(PINS['priorClassifier']));names=('require','digest','canon','ast_context','classify_exact','dump_dispatch');nodes=[n for n in prior.body if isinstance(n,ast.FunctionDef) and n.name in names];u.ck(tuple(n.name for n in nodes)==names,'prior classifier extraction');m=types.ModuleType('ford_test_unchanged_generic');m.__dict__.update(ast=ast,collections=collections,hashlib=hashlib,json=json,P=P,C=C);exec(compile(ast.Module(body=nodes,type_ignores=[]),PINS['priorClassifier']['path'],'exec'),m.__dict__);extension.extend(m)
 fixture=u.read_exact(PINS['fixtureSource']);f=code_rows[0]
 test('existing-fixture-accept',lambda:m.classify_exact([f['exactFinding']],fixture,f['member'],d))
 test('existing-fixture-changed-source',lambda:m.classify_exact([f['exactFinding']],fixture+b' ',f['member'],d),True)
 test('existing-fixture-changed-ast-pin',lambda:m.classify_exact([f['exactFinding']],fixture,f['member'],mutate(d,lambda x:x['exactSupportCodeClassifications'][0].update(comparisonAstSHA256='0'*64))),True)
 baseargs=['--contract','/synthetic/contract.json','--contract-sha256','1'*64,'--review','/synthetic/review.json','--review-sha256','2'*64];cli_contract={'archive':{'path':'/synthetic/archive.tar.xz'},'privacyOutput':'/synthetic/report.json'}
 correct=['privacy',*baseargs,'--archive',cli_contract['archive']['path'],'--report',cli_contract['privacyOutput']]
 test('privacy-cli-accept',lambda:support.check_cli(support.parse_cli(correct),cli_contract))
 for label,tokens in [('wrong-archive',correct[:-3]+['/wrong',*correct[-2:]]),('wrong-report',correct[:-1]+['/wrong']),('missing-paths',['privacy',*baseargs]),('extra-option',correct+['--unexpected','x']),('duplicate-option',correct+['--archive',cli_contract['archive']['path']]),('abbreviated', ['privacy',*baseargs,'--arch',cli_contract['archive']['path'],'--report',cli_contract['privacyOutput']]),('nonprivacy',['package',*baseargs,'--archive',cli_contract['archive']['path']])]:
  test('privacy-cli-'+label,lambda tokens=tokens:support.check_cli(support.parse_cli(tokens),cli_contract),True)
 code_roles=c['appendCodeRoles'];selected={'codeRoles':code_roles,'additionalCodePins':[],'copyPins':list(code_roles.values())};rv=copy.deepcopy(selected);table2={r['path']:r for r in selected['copyPins']}
 fake=types.SimpleNamespace(ck=u.ck,pin=lambda p:PINS['append'])
 test('append-finite-code-selection-accept',lambda:append.exact_additions(fake,selected,rv,table2))
 for label,change in [('missing',lambda x:x['copyPins'].pop()),('duplicate',lambda x:x['copyPins'].append(copy.deepcopy(x['copyPins'][0]))),('extra',lambda x:x['copyPins'].append({'path':str(C/'unlisted.py'),'bytes':0,'sha256':'0'*64})),('wrong-pin',lambda x:x['copyPins'][0].update(sha256='0'*64)),('wrong-role',lambda x:x['codeRoles'].update(unlisted=x['codeRoles']['supportAdapter']))]:
  test('append-scope-'+label,lambda change=change:append.exact_additions(fake,mutate(selected,change),rv,table2),True)
 for count in (349,351):
  s={'baseInventory':append.FIXED['baseInventory']};cc={'inputs':{'selection':{},'selectionReview':{},'baseInventory':append.FIXED['baseInventory']},'baseMemberCount':count}
  test('append-base-count-'+str(count),lambda s=s,cc=cc:append.finite_authority_check(fake,s,{}, {},{},cc,{}),True)
 result={'result':'PASS_EXACT_FORD_MIXED_CODE_AND_PUBLIC_METADATA_TESTS','cases':cases,'caseCount':len(cases),'failed':0,'seedReads':False,'sourceArchiveResearchPayloadReads':False,'scannersExecuted':False,'fixtureReads':'Exact four public review metadata receipts and exact retained generic test code only','nativeByteReadbackVerified':False}
 with P(c['reportOutput']).open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({'result':result['result'],'caseCount':len(cases)}))
if __name__=='__main__':main()
