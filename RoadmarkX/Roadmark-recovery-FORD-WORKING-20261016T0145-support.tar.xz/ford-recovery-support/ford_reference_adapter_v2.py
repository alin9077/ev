#!/usr/bin/env python3
"""Exact Ford scope adapter over the pinned Nissan metadata closure implementation."""
import argparse
import ast
import collections
import hashlib
import pathlib
import stat

P = pathlib.Path
C = P(__file__).resolve().parent
BASE = C.parent / 'nissan-working-20261015T2220/build_nissan_reference_restore_v7.py'
BASE_BYTES = 31549
BASE_SHA = 'd51bb903a52f01477864ab60bfeb36c8095eea8919ce4059b061e7c32b786b08'


def supplement_map(ns, conf, allowed_archives):
    """Two explicitly pinned historical metadata schemas; no inferred fields."""
    need, read_json, key, core = (ns[k] for k in ('need', 'read_json', 'key', 'core'))
    supplemental = {}
    specs = conf['deliveryOnlySupplements']
    need(len(specs) == 3 and len({s['identity']['filename'] for s in specs}) == 3,
         'Require the exact three distinct outside-chain artifacts')
    for s in specs:
        pkg, inv = read_json(s['package']), read_json(s['inventory'])
        need(key(pkg) == key(s['identity']) and pkg['filename'] == s['identity']['filename'],
             'Supplement package identity mismatch')
        need(pkg['outsideRecoveryArchiveSet'] is True
             and pkg['unchangedRecoveryArchiveCount'] == s['originalCoreArchiveCount'],
             'Wrong original outside-chain declaration')
        need(pkg['filename'] not in allowed_archives, 'Supplement entered recovery chain')
        schema = s['rowSchema']
        need(schema in ('logical-path-originalPath', 'absolute-path-logical-member'),
             'Unreviewed supplement row schema')

        def normalize(row):
            if schema == 'logical-path-originalPath':
                original, member = row['originalPath'], row['path']
            else:
                original, member = row['path'], row['member']
            need(P(original).is_absolute() and '..' not in P(original).parts,
                 'Unsafe supplement original path')
            need(not P(member).is_absolute() and '..' not in P(member).parts,
                 'Unsafe supplement member')
            out = {'path': member, 'originalPath': original,
                   'bytes': row['bytes'], 'sha256': row['sha256']}
            need(ns['valid_pin'](out), 'Malformed supplement member pin')
            return out

        package_rows = [normalize(r) for r in pkg['members']]
        inventory_rows = [normalize(r) for r in inv['files']]
        pm = {r['path']: core(r) for r in package_rows}
        im = {r['path']: core(r) for r in inventory_rows}
        need(len(pm) == len(package_rows) == pkg['memberCount'], 'Duplicate package member')
        need(len(im) == len(inventory_rows), 'Duplicate inventory member')
        inventory_members = [r for r in package_rows if r['originalPath'] == s['inventory']['path']]
        need(len(inventory_members) == 1, 'Exactly one inventory member required')
        inventory_member = inventory_members[0]
        need(key(inventory_member) == key(s['inventory']) and inventory_member['path'] not in im,
             'Inventory member pin mismatch')
        im[inventory_member['path']] = core(inventory_member)
        need(pm == im, 'Package differs from inventory plus exact inventory member')
        inventory_by = {r['path']: r for r in inventory_rows + [inventory_member]}
        need(all(inventory_by[r['path']]['originalPath'] == r['originalPath'] for r in package_rows),
             'Original path attribution differs across supplement metadata')
        for r in inventory_rows + [inventory_member]:
            supplemental.setdefault((r['originalPath'], r['bytes'], r['sha256']), []).append(
                {'member': core(r), 'archive': s['identity'],
                 'package': s['package'], 'inventory': s['inventory']})
    return supplemental


def load(config_sha):
    for p in (BASE, *BASE.parents):
        if stat.S_ISLNK(p.lstat().st_mode):
            raise ValueError('Symlink base helper')
    raw = BASE.read_bytes()
    if len(raw) != BASE_BYTES or hashlib.sha256(raw).hexdigest() != BASE_SHA:
        raise ValueError('Pinned base helper changed')
    tree = ast.parse(raw, filename=str(BASE))
    expected = collections.Counter({
        'supplement_loop': 1, 'prior_member_schema': 1, 'source_archive_view': 2,
        'base_archive_count': 2, 'base_reuse_count': 1, 'input_prefix': 1,
        'closure_name': 4, 'final_receipt_name': 1, 'terminal_receipt_name': 1,
        'inherited_rename_classification': 1, 'sanitation_pointer_list': 1,
    })
    seen = collections.Counter()
    source_expr = ast.dump(ast.parse("plan['base']['sourceArchive']", mode='eval').body)
    member_assign = ast.dump(ast.parse("n = r.get('member')").body[0])
    supplement_iter = ast.dump(ast.parse("conf['deliveryOnlySupplements']", mode='eval').body)
    sanitation_pointers = ast.dump(ast.parse("['/copyOnlySanitation', '/inheritedRecoveryMetadata', '/inheritedBoundaries']", mode='eval').body)
    replacements = {
        'NISSAN-REFERENCE-INPUTS-': ('FORD-REFERENCE-INPUTS-', 'input_prefix'),
        'INDEPENDENT-NISSAN-REFERENCE-CLOSURE-v2.json': ('INDEPENDENT-FORD-REFERENCE-CLOSURE-v2.json', 'closure_name'),
        'FINAL-RENAULT-UPLOAD-RECEIPTS.json': ('FINAL-NISSAN-UPLOAD-RECEIPTS.json', 'final_receipt_name'),
        'INDEPENDENT-RENAULT-TERMINAL-CLOSURE-v1.json': ('INDEPENDENT-NISSAN-TERMINAL-CLOSURE-v1.json', 'terminal_receipt_name'),
        'ordinary-noncredential-approval-prose': ('EXACT_HISTORICAL_ACTION_APPROVAL_PROSE_NOT_HTTP_AUTHENTICATION', 'inherited_rename_classification'),
    }

    class Adapt(ast.NodeTransformer):
        def visit_List(self, node):
            if ast.dump(node) == sanitation_pointers:
                seen['sanitation_pointer_list'] += 1
                return ast.copy_location(ast.parse("['/copyOnlySanitation', '/inheritedBoundaries']", mode='eval').body, node)
            return self.generic_visit(node)

        def visit_For(self, node):
            if isinstance(node.target, ast.Name) and node.target.id == 's' and ast.dump(node.iter) == supplement_iter:
                seen['supplement_loop'] += 1
                return ast.copy_location(ast.parse('supplemental = FORD_SUPPLEMENTS(conf, allowed_archives)').body[0], node)
            return self.generic_visit(node)

        def visit_Assign(self, node):
            if ast.dump(node) == member_assign:
                seen['prior_member_schema'] += 1
                return ast.copy_location(ast.parse("n = r['member']['path'] if isinstance(r.get('member'), dict) else r.get('member')").body[0], node)
            return self.generic_visit(node)

        def visit_Subscript(self, node):
            if ast.dump(node) == source_expr:
                seen['source_archive_view'] += 1
                return ast.copy_location(ast.parse("base['source']", mode='eval').body, node)
            return self.generic_visit(node)

        def visit_Constant(self, node):
            if type(node.value) is int and node.value in (142, 141):
                name = 'base_archive_count' if node.value == 142 else 'base_reuse_count'
                seen[name] += 1
                return ast.copy_location(ast.Constant(value=145 if node.value == 142 else 144), node)
            if isinstance(node.value, str) and node.value in replacements:
                value, name = replacements[node.value]
                seen[name] += 1
                return ast.copy_location(ast.Constant(value=value), node)
            return node

    tree = Adapt().visit(tree)
    if seen != expected:
        raise ValueError('Exact AST adaptation count mismatch: ' + repr(dict(seen)))
    # Define reviewed functions without triggering the original CLI.
    mains = [n for n in tree.body if isinstance(n, ast.If)
             and ast.dump(n.test) == ast.dump(ast.parse("__name__ == '__main__'", mode='eval').body)]
    if len(mains) != 1:
        raise ValueError('Wrong base main guard count')
    tree.body.remove(mains[0])
    ast.fix_missing_locations(tree)
    ns = {'__file__': str(BASE), '__name__': 'ford_reference_pinned_base'}
    exec(compile(tree, str(BASE), 'exec'), ns)
    ns['C'] = C
    conf = C / 'FORD-REFERENCE-CONFIG-v1.json'
    ns['CONFIG'] = {'path': str(conf), 'bytes': conf.stat().st_size, 'sha256': config_sha}
    ns['FORD_SUPPLEMENTS'] = lambda cfg, allowed: supplement_map(ns, cfg, allowed)
    return ns


if __name__ == '__main__':
    # Strip only the adapter's required exact config pin; base CLI retains its strict mode/input parser.
    import sys
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--config-sha256', required=True)
    args, remaining = parser.parse_known_args()
    if len(args.config_sha256) != 64 or any(c not in '0123456789abcdef' for c in args.config_sha256):
        raise ValueError('Invalid exact configuration digest')
    sys.argv = [sys.argv[0], *remaining]
    load(args.config_sha256)['main']()
