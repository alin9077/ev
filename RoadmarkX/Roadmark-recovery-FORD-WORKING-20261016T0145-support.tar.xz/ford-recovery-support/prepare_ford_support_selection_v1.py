#!/usr/bin/env python3
"""Seal the finite current Ford support set, excluding captured payload trees."""
import collections
import hashlib
import json
import pathlib
import sys

F = pathlib.Path(__file__).resolve().parent
assert F.name == 'ford-working-20261016T0145'
B = F.parent / 'renault-working-20261015T2040'


def pin(p):
    assert p.is_file() and not p.is_symlink()
    s = p.stat()
    before = (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_mode)
    h = hashlib.sha256()
    size = 0
    with p.open('rb') as f:
        for b in iter(lambda: f.read(65536), b''):
            h.update(b)
            size += len(b)
    s = p.stat()
    assert before == (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_mode)
    return {'path': str(p), 'bytes': size, 'sha256': h.hexdigest()}


def main():
    assert len(sys.argv) == 3
    ep = pathlib.Path(sys.argv[1])
    assert ep == F / 'FORD-EXTERNAL-SUPPORT-PROPOSAL-v1.json'
    assert pin(ep)['sha256'] == sys.argv[2]
    e = json.loads(ep.read_text())
    assert e['status'] == 'PROPOSED_FINITE_EXACT_FORD_EXTERNAL_SUPPORT'
    paths = sorted(p for p in F.iterdir() if p.is_file())
    for dirname in ('seed-read-invocations', 'audi-seed-read-invocations', 'deepal-seed-read-invocations'):
        for p in sorted((F / dirname).iterdir()):
            assert p.is_file() and not p.is_symlink() and p.suffix == '.json'
            paths.append(p)
    reserved = {'SUPPORT-SELECTION-v1.json', 'SUPPORT-REUSE-MAPPING.json',
                'SUPPORT-SELECTION-PROPOSAL-v1.json', 'SUPPORT-MEMBER-INVENTORY.json',
                'SUPPORT-PATTERN-SELECTION-v1.json', 'support-selection-proposal-v1.resources.json'}
    assert all(p.name not in reserved and not p.is_symlink() for p in paths)
    assert all(p.suffix in ('.json', '.py', '.log', '.txt', '.patch', '.md') for p in paths)
    rows = list(e['files'])
    for p in paths:
        z = pin(p)
        r = {'originalPath': str(p), 'localRelativePath': str(p.relative_to(F)),
             'bytes': z['bytes'], 'sha256': z['sha256'], 'action': 'fresh'}
        if p.name in ('SEED-PROVENANCE.json', 'INHERITED-LOCAL-SEED-READ-SCOPE.json', 'TARGETED-SEED-READ-DEPENDENCY.json'):
            matches = [x for x in e['files'] if x['originalPath'] == str(B / p.name)]
            assert len(matches) == 1 and matches[0]['action'] == 'reuse'
            old = matches[0]
            assert all(old[k] == r[k] for k in ('bytes', 'sha256'))
            r.update({k: old[k] for k in ('retainedMember', 'retainedArchive', 'archiveMappingAuthority',
                                         'archiveMappingSchema', 'outsideRecoveryArchiveSet')})
            r['action'] = 'reuse'
            r['exactMetadataAliasOf'] = old['originalPath']
        rows.append(r)
    assert len(rows) == len({r['originalPath'] for r in rows})
    assert len(rows) == len({r['localRelativePath'] for r in rows})
    private = {x['path'] for x in e['localOnlyPrivateSeedInputPins']}
    assert not private.intersection(r['originalPath'] for r in rows)
    code = collections.defaultdict(list)
    for r in rows:
        if r['action'] == 'fresh' and pathlib.Path(r['originalPath']).suffix == '.py':
            code[(r['bytes'], r['sha256'])].append(r['originalPath'])
    duplicates = [v for v in code.values() if len(v) > 1]
    assert not duplicates
    out = {'status': 'PROPOSED_EXACT_FORD_SUPPORT_SELECTION', 'baseManifest': e['baseManifest'],
           'outsideRecoveryArtifacts': e['outsideRecoveryArtifacts'], 'files': rows,
           'externalProposal': pin(ep), 'localOnlyPrivateSeedInputPins': e['localOnlyPrivateSeedInputPins'],
           'privateSeedInputPayloadsSelected': False, 'newExecutableDuplicateGroups': duplicates,
           'excludedTrees': ['selected-proof-sanitized-v1', 'selected-source-changes'],
           'reservedNamesExcluded': sorted(reserved),
           'finalizationRule': 'Preserve these exact rows. Add only this proposal, its independent acceptance receipt, and the completed support-selection-proposal-v1.resources.json terminal as three exact fresh metadata rows. The final selection review field pins that independent acceptance receipt. No source, archive, helper, or prior selected bytes may change.'}
    op = F / 'SUPPORT-SELECTION-PROPOSAL-v1.json'
    with op.open('x') as f:
        json.dump(out, f, indent=2)
        f.write('\n')
    print(json.dumps({'proposal': pin(op), 'selectedRows': len(rows),
                      'freshRows': sum(r['action'] == 'fresh' for r in rows),
                      'reuseRows': sum(r['action'] == 'reuse' for r in rows),
                      'freshBytes': sum(r['bytes'] for r in rows if r['action'] == 'fresh')}))


if __name__ == '__main__':
    main()
