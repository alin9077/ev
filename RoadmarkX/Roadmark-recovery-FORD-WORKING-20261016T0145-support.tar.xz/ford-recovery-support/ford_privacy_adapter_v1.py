#!/usr/bin/env python3
"""Ford namespace adapter over exact unchanged Nissan/Renault privacy engines."""
import ast
from ford_capture_adapter_v1 import C, B, NISSAN, P, capture_module, load_reference, replace_constant, redirect_import

PIN = {'bytes': 2498, 'sha256': 'a1907a57fc251cc34cd440229f444a110325a30ec31c8e4ef364aa19559283b0'}

def transform(tree):
    redirect_import(tree, 'nissan_capture_adapter_v2', 'ford_capture_adapter_v1')
    for old, new in (
        ('NISSAN-PRIVACY-ADAPTER-CONTRACT-v1.json', 'FORD-PRIVACY-ADAPTER-CONTRACT-v1.json'),
        ('INDEPENDENTLY_ACCEPTED_NISSAN_PRIVACY_ADAPTER', 'INDEPENDENTLY_ACCEPTED_FORD_PRIVACY_ADAPTER'),
        ('NISSAN-ADAPTER-PREPARATION-v2.json', 'FORD-ADAPTER-PREPARATION-v1.json')):
        replace_constant(tree, old, new)
    replace_constant(tree, 'NISSAN-INHERITED-ADAPTER-PINS-v1.json', 'FORD-INHERITED-ADAPTER-PINS-v1.json', expected=2)
    nodes = [n for n in ast.walk(tree) if isinstance(n, ast.Compare)
             and isinstance(n.left, ast.Attribute) and isinstance(n.left.value, ast.Name)
             and n.left.value.id == 'privacy' and n.left.attr == 'BASE']
    assert len(nodes) == 1
    assert len(nodes[0].comparators) == 1 and isinstance(nodes[0].comparators[0], ast.Name)
    assert nodes[0].comparators[0].id == 'B'
    nodes[0].comparators[0].id = 'NISSAN'
    return tree

def configure(require_review=True):
    capture_module()
    m = load_reference('ford_nissan_privacy_reference', NISSAN / 'nissan_privacy_adapter_v2.py', PIN, transform)
    m.NISSAN = NISSAN
    return m.configure(require_review=require_review)
