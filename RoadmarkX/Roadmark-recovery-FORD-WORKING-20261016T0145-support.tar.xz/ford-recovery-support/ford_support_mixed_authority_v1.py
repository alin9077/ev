#!/usr/bin/env python3
"""Pure exact Ford mixed-classification metadata authority; no payload or I/O."""
import hashlib,json
FIXED_PINS = {'approvedProposal': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/INDEPENDENT-FORD-SUPPORT-FIVE-FINDING-PROPOSAL-v1.json', 'bytes': 13603, 'sha256': 'a5b22887af4d1bb24151dc7b2d3b2e3d406af59e664f6673f344619dac4c6123'}, 'initialClassificationGrant': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ROOT-SUPPORT-FIVE-FINDING-GRANT-v1.json', 'bytes': 1539, 'sha256': '2e750c0da338f47a4f29402499ec468bff8dbb5ad7cfedbfee20046cedf5861c'}, 'initialPatternReport': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/SUPPORT-PATTERN-CANDIDATES-v1.json', 'bytes': 4235, 'sha256': 'cb73b0e71ed8748e76f69356312ef201255be0a68db52a3e70de4e3d2069e61b'}}
FIXED_CANONICAL = {'approvedProposal': 'baff4b8348ec59f8a571dbe2a1e89e45d39258f7ca63f5f7212b04b661160376', 'initialClassificationGrant': '63119ad436d1e34773f74e5322c1edfebe2ccd18f57f5531ab7b7562b1eee0e2', 'initialPatternReport': '9a604ff5bbf03f1020f293c221168043494b8ef1ece58e8df988c9cce9dd1008'}
RESULT='ACCEPTED_EXACT_FORD_SUPPORT_MIXED_CLASSIFICATION'
GRANT_RESULT='ROOT_APPROVED_EXACT_FORD_SUPPORT_MIXED_CLASSIFICATION'

def ck(ok,why):
 if not ok:raise ValueError(why)
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'))
def digest(x):return hashlib.sha256(canon(x).encode()).hexdigest()
def sh(x):return {k:x[k] for k in ('bytes','sha256')}
def emitted(row):return {'member':row['member'],'filePin':row['filePin'],'finding':row['exactFinding'],'classification':row['classification']}
def expected(proposal,initial_grant,initial_raw):
 for key,value in zip(('approvedProposal','initialClassificationGrant','initialPatternReport'),(proposal,initial_grant,initial_raw)):
  ck(digest(value)==FIXED_CANONICAL[key],'fixed semantic metadata differs: '+key)
 ck(initial_grant['approvedProposal']==FIXED_PINS['approvedProposal'] and initial_grant['result']=='ROOT_APPROVED_EXACT_FORD_SUPPORT_FIVE_CLASSIFICATIONS','initial semantic root scope')
 ck(initial_grant['additionalCandidatesApproved'] is False and initial_grant['sourceOrStagedEditsApproved'] is False and initial_grant['newRuntimeImplementationApproved'] is False,'initial grant qualification')
 prose=proposal['jsonProseCandidates'];fixture={k:v for k,v in proposal['fixtureCandidate'].items() if k!='classificationStatus'}
 ck(len(prose)==4 and len(initial_raw['candidateFiles'])==5,'exact four prose plus one fixture')
 return [fixture],prose

def validate(d,g,review,raw,selection,proposal,initial_grant,initial_raw,roles):
 for key,p in FIXED_PINS.items():ck(roles[key]==p,'fixed semantic authority pin differs: '+key)
 code,prose=expected(proposal,initial_grant,initial_raw)
 ck(set(d)=={'schemaVersion','result','rawPreflight','initialRawPreflight','approvedProposal','initialRootGrant','exactSupportCodeClassifications','expectedClassifiedRecords','exactSupportJSONProseClassifications','expectedJSONProseRecords'},'mixed classification fields')
 ck(d['schemaVersion']==1 and d['result']==RESULT and d['rawPreflight']==roles['patternReport'],'mixed final report binding')
 ck(d['initialRawPreflight']==roles['initialPatternReport'] and d['approvedProposal']==roles['approvedProposal'] and d['initialRootGrant']==roles['initialClassificationGrant'],'initial semantic bindings')
 ck(d['exactSupportCodeClassifications']==code and d['exactSupportJSONProseClassifications']==prose,'exact mixed rows changed/missing/extra/duplicate')
 ck(d['expectedClassifiedRecords']==[emitted(x) for x in code] and d['expectedJSONProseRecords']==[emitted(x) for x in prose],'exact mixed emitted records')
 ck(g['result']==GRANT_RESULT and g['classification']==roles['classification'] and g['approvedProposal']==roles['approvedProposal'],'second exact final classification grant')
 ck(g['additionalCandidatesApproved'] is False and g['sourceOrStagedEditsApproved'] is False,'final mixed grant boundary')
 ck(review['result']=='ACCEPTED_EXACT_FORD_SUPPORT_CLASSIFICATION_AND_GRANT' and review['classification']==roles['classification'] and review['rootGrant']==roles['classificationGrant'],'final independent mixed authority')
 ck(raw['result']=='REVIEW_REQUIRED' and raw['seedReadsPerformed'] is False and raw['selectionPin']==sh(roles['patternSelection']),'actual complete raw report')
 ck(raw['candidateFiles']==initial_raw['candidateFiles'],'final candidate set differs from exact initial five')
 rows=selection['files'];by={x['path']:x for x in rows};ck(len(by)==len(rows)==raw['filesInspected'],'final pattern selection count/duplicates')
 ck(len({x['payloadPath'] for x in rows})==len(rows),'duplicate final payload path')
 for item in raw['candidateFiles']:
  row=by[item['member']];ck(item['filePin']==sh(row) and item['payloadPath']==row['payloadPath'] and item['runtime']==[] and len(item['primary'])==1,'raw exact candidate selection/context')
  matches=[r for r in code+prose if r['member']==item['member']]
  ck(len(matches)==1 and matches[0]['exactFinding']==item['primary'][0] and matches[0]['filePin']==item['filePin'],'raw exact mixed finding')
 return d

def report_records(report,d,expected_code,expected_json):
 code=report['classifiedExactCodeHeaderCandidates'];prose=report['classifiedExactJSONProseCandidates']
 ck(sorted(map(canon,code))==sorted(map(canon,expected_code)) and len(set(map(canon,code)))==len(code),'exact complete code report records')
 ck(prose==d['expectedJSONProseRecords'] and prose==expected_json,'exact separate JSON prose report records')
 for r in d['expectedClassifiedRecords']:ck(code.count(r)==1,'fixture exact record missing/duplicate')
 return True
