#!/usr/bin/env python3
"""Metadata-only finite fresh-archive plan after accepted capture and packaging."""
import sys
from ford_capture_adapter_v1 import C, B, R, P
from ford_phase_gateway_v1 import verified_core_contract

def main():
    assert len(sys.argv) == 1
    cap = verified_core_contract()
    source_path = C / 'source-package.json'
    proof_path = C / 'proof-packages-v1.json'
    source = cap.load(source_path)
    proof = cap.load(proof_path)
    label = 'FORD-WORKING-20261016T0145'
    assert source['filename'] == 'Roadmark-recovery-source-' + label + '.tar.xz'
    assert source['file'] == str(R / source['filename'])
    assert source['members'] == 707 and source['bytes'] < 15000000 and source['allMembersVerified'] is True
    archives = [source] + proof['archives']
    assert len({a['file'] for a in archives}) == len(archives)
    assert len({a['filename'] for a in archives}) == len(archives)
    for index, a in enumerate(proof['archives'], 1):
        assert a['filename'] == f'Roadmark-recovery-{label}-part{index:02d}of{len(proof["archives"]):02d}.tar.xz'
        assert a['file'] == str(R / a['filename']) and a['allMembersVerified'] is True
    for a in archives:
        assert a['new'] is True and a['members'] == len(a['memberFiles'])
        names = [row['path'] for row in a['memberFiles']]
        assert len(names) == len(set(names))
        for n in names:
            cap.safe(n)
    plan_path = C / 'ARCHIVE-PLAN-initial.json'
    cap.dump(plan_path, {'status': 'EXACT_FRESH_SOURCE_AND_PROOF_ONLY_NO_BASE_PAYLOAD_READ',
                         'archives': archives,
                         'baseArchiveReusePlan': {'path': str(C / 'BASE-ARCHIVE-REUSE-PLAN-v1.json'), **cap.pin(C / 'BASE-ARCHIVE-REUSE-PLAN-v1.json')},
                         'sourcePackage': {'path': str(source_path), **cap.pin(source_path)},
                         'proofPackages': {'path': str(proof_path), **cap.pin(proof_path)},
                         'supportArchivesPendingSeparateFiniteSelection': True,
                         'inheritedArchivePayloadRead': False,
                         'nativeByteReadbackVerified': False})
    captures = [cap.load(C / 'source-capture.json'), cap.load(C / 'proof-capture-v1.json')]
    selected = [{**r, 'path': 'roadmark/' + r['path']} for r in captures[0]['files']]
    selected += captures[1]['changedFiles']
    assert len({r['path'] for r in selected}) == len(selected)
    selection_path = C / 'FRESH-PATTERN-SELECTION-v1.json'
    cap.dump(selection_path, {'status': 'EXACT_CAPTURED_SOURCE_AND_FRESH_PROOF', 'files': selected,
                              'noPayloadReadByThisPreparation': True})
    commands = []
    for index, a in enumerate(archives, 1):
        report = C / f'scan-fresh-{index:02d}.json'
        resource = C / f'scan-fresh-{index:02d}.resources.json'
        commands.append({'archive': a['file'], 'archivePin': {k: a[k] for k in ('bytes', 'sha256')},
                         'report': str(report),
                         'argv': ['python', str(B / 'run_bounded_v1.py'), str(resource), '--sole-heavy-slot',
                                  'python', str(C / 'ford_phase_gateway_v1.py'), 'scan-archive',
                                  a['file'], str(report), str(plan_path)]})
    cap.dump(C / 'FRESH-PHASE-INVOCATIONS-v1.json', {
        'status': 'PREPARED_ONLY_REQUIRES_EXACT_INDEPENDENT_INVOCATION_REVIEW',
        'archivePlan': {'path': str(plan_path), **cap.pin(plan_path)},
        'patternSelection': {'path': str(selection_path), **cap.pin(selection_path)},
        'patternPreflightArgv': ['python', str(B / 'run_bounded_v1.py'), str(C / 'preflight-patterns-v1.resources.json'),
                                '--sole-heavy-slot', 'python', str(C / 'ford_phase_gateway_v1.py'),
                                'preflight-patterns', str(selection_path), str(C / 'FRESH-PATTERN-CANDIDATES-v1.json')],
        'scanCommands': commands,
        'serialOnly': True, 'terminalBeforeNextPhase': True,
        'rootMustConfirmSoleHeavySlotForEveryInvocation': True,
        'fullByteSearchEveryMember': True,
        'newChangedMembersFullCurrentPatterns': True,
        'unchangedSourcePatternCacheRequiresExactPriorFileAndRuleHashes': True,
        'unclassifiedPatternFindingsRequireIndependentExactReview': True,
        'supportAndDeliveryPhasesRequireSeparateFiniteReviewedSelections': True})
    print('Prepared exact fresh source/proof metadata and held scan commands; no archive or seed payload read')

if __name__ == '__main__':
    main()
