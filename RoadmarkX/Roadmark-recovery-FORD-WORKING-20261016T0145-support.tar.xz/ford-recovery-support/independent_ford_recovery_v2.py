#!/usr/bin/env python3
"""Independent Ford fresh replay adapter. No producer/privacy imports or seed reads.

The pinned Nissan v9 verifier retains the byte hashing, streaming tar/XZ replay,
exact reference resolution, stage accounting and immutable output implementation.
Only the explicitly enumerated Ford schema boundaries below are adapted.
"""
import ast, hashlib, pathlib, stat, sys

P = pathlib.Path
C = P(__file__).resolve().parent
BASE = C.parent / 'nissan-working-20261015T2220/independent_nissan_recovery_v9.py'
BASE_PIN = {'bytes': 47463, 'sha256': 'ebc2706bcf08c0865248792cce0f608524ca1ed550e5c8262f096f2c1ad29930'}
FIXED_PINS = {
    'plan': {'path': str(C / 'SAFETY-SAVE-PLAN-v1.json'), 'bytes': 58537, 'sha256': 'c176aa528567d9500857d749b93019b90c2d614bc8218ccbae85288638a6dbac'},
    'planReview': {'path': str(C / 'INDEPENDENT-FORD-SAFETY-SAVE-PLAN-v1-REVIEW-v1.json'), 'bytes': 178204, 'sha256': 'f3e505779e0d25e8d8702afafab68727c7b2f08b5245c37c1c16ab5b8d4d0644'},
    'scope': {'path': str(C / 'FROZEN-CAPTURE-SCOPE.json'), 'bytes': 292185, 'sha256': '17f9bea18d36fa08ebbb89d082aefcad0744a8f79712d60d76fc8fe7452d7b76'},
}
REFERENCE_CONFIG_PIN = {'path': str(C / 'FORD-REFERENCE-CONFIG-v1.json'), 'bytes': 22175, 'sha256': '76b08173191c7f3561001eef73f4f54d223bc86b9215badc03879a3f1ce37071'}


def ford_context(args):
    cp, rp = P(args.contract), P(args.review)
    ck(cp.parent == rp.parent == C and cp.suffix == rp.suffix == '.json', 'contract/review outside Ford checkpoint')
    cr = {'path': str(cp), 'bytes': ident(cp)[0], 'sha256': args.contract_sha256}
    rr = {'path': str(rp), 'bytes': ident(rp)[0], 'sha256': args.review_sha256}
    add(cr); add(rr)
    contract, review, own = load(cr), load(rr), pin(__file__)
    ck(contract['schemaVersion'] == 1 and contract['mode'] == 'fresh-only' and contract['checkpoint'] == str(C), 'Ford runtime scope')
    ck(contract['verifier'] == own and review['verifier'] == own and review['contract'] == cr
       and review['mode'] == 'fresh-only' and review['result'] == 'ACCEPTED_EXACT_FORD_VERIFIER_RUNTIME_CONTRACT', 'Ford exact runtime acceptance')
    for r in FIXED.values(): add(r)
    for r in contract['inputs'].values(): add(r)
    for r in contract['additionalMetadata']: add(r)
    for x in contract['supportParts']:
        add(x['package']); add(x['inventory'])
    for x in contract['privacyReports']:
        for k in ('report', 'invocation', 'terminal'): add(x[k])
    for x in contract['phaseHistory']:
        add(x['invocation'])
        if x['terminal']: add(x['terminal'])
    plan, scope, pr = load(FIXED['plan']), load(FIXED['scope']), load(FIXED['planReview'])
    ck(pr['plan'] == FIXED['plan'] and pr['result'] == 'ACCEPTED_EXACT_FORD_METADATA_PLAN_ONLY', 'Ford factual plan review')
    evidence = plan['fordEvidence']
    for r in (evidence['inventory'], evidence['finalRetentionAcceptance'],
              plan['sourcePolicy']['priorSourceCapture'], plan['sourcePolicy']['priorSourcePackage']): add(r)
    inv, accept = load(evidence['inventory']), load(evidence['finalRetentionAcceptance'])
    ck(accept['status'] == 'accepted' and accept['inventory'] == evidence['inventory']
       and accept['preparer'] == inv['preparer'] == evidence['preparer'], 'Ford exact factual retention')
    ck(accept['liveSourceAndStatusPins'] == inv['sourceAndStatusAfterPins'] == scope['authorRetention']['sourceAndStatusAfterPins'], 'eight Ford live bindings')
    ck(len(inv['files']) == inv['totalFiles'] == 538 and sum(r['bytes'] for r in inv['files']) == inv['regularFileBytes'] == 66896242, '538 author rows and exact bytes')
    ck(len(scope['files']) == len({r['path'] for r in scope['files']}) == 545, '545 frozen rows')
    extras = evidence['noncircularExtras']
    retained = accept['separateRetentionRequired']
    expected_extras = [retained['finalInventory'], retained['finalPreparer'], retained['finalReviewBundle'],
                       *retained['finalReviewBundleMembers'], evidence['finalRetentionAcceptance']]
    ck(extras == expected_extras and len(extras) == len({r['path'] for r in extras}) == 7, 'seven exact noncircular extras')
    ck({r['path'] for r in scope['files']} == {r['path'] for r in inv['files']} | {r['path'] for r in extras}, '538 plus7 scope')
    frozen = {r['path']: r for r in scope['files']}
    for r in inv['files']:
        ck(all(frozen[r['path']].get(k) == v for k, v in r.items()), 'Ford original frozen metadata changed')
    for r in extras: ck(sh(frozen[r['path']]) == sh(r), 'Ford separate exact pin differs')
    ck(accept['factualState'] == inv['currentValidation'] == scope['currentValidation'] == plan['currentFordValidation'], 'Ford factual state differs')
    for k in ('fullProjectTypecheckPassed', 'releaseReady', 'researchCompleted', 'currentCleanFullSuite', 'productionBuildVerified', 'phoneMobileVerified', 'publicationAuthorized'):
        ck(inv['currentValidation'][k] is False, 'Ford unpassed qualification changed')
    ck(plan['base']['nativeByteReadbackVerified'] is False and plan['nativeFlow']['nativeByteReadbackVerified'] is False
       and accept['limits']['nativeCreateOrRemoteReadbackClaim'] is False, 'Ford native qualification')
    ck(contract['inputs']['referenceConfiguration'] == REFERENCE_CONFIG_PIN, 'exact Ford reference configuration')
    method = load(contract['inputs']['sourceMethodAmendment'])
    method_review = load(contract['inputs']['sourceMethodReview'])
    reuse = load(contract['inputs']['sourceReusePayloadMap'])
    ck(method['originalPlan'] == FIXED['plan'] and method['exactReusedPayloadMap'] == contract['inputs']['sourceReusePayloadMap'], 'source method exact bindings')
    ck(method_review['result'] == 'ACCEPTED_EXACT_FORD_SOURCE_METHOD_AMENDMENT_METADATA_AND_STATIC_CODE_ONLY', 'source method review status')
    ck(method_review['amendment'] == contract['inputs']['sourceMethodAmendment'] and method_review['payloadMap'] == contract['inputs']['sourceReusePayloadMap'] and method_review['originalPlan'] == FIXED['plan'], 'source method review exact pins')
    ck(reuse['sourceCaptureAuthority'] == plan['sourcePolicy']['priorSourceCapture'] and reuse['priorSourcePackageAuthority'] == plan['sourcePolicy']['priorSourcePackage'] and reuse['reusedFiles'] == len(reuse['files']) == 699, 'source reuse authority/count')
    prior_source = load(plan['sourcePolicy']['priorSourceCapture'])
    prior_rows = {r['path']: r for r in prior_source['files']}
    changed = set(plan['sourcePolicy']['sourceChangedPaths'])
    ck(len({r['sourcePath'] for r in reuse['files']}) == 699 and {r['sourcePath'] for r in reuse['files']} == set(prior_rows) - changed, 'exact source reuse map path set')
    for r in reuse['files']:
        q = prior_rows[r['sourcePath']]
        ck(r['payloadPath'] == q['payloadPath'] and sh(r) == sh(q) and r['priorArchiveMember'] == 'roadmark/' + r['sourcePath'], 'exact source reuse map row')
    ck(method['expectedReusedPriorSourceFiles'] == 699 and method['expectedChangedSourceFiles'] == 7
       and method['expectedSourceFiles'] == 706 and method['expectedSourceArchiveMembers'] == 707, 'source method counts')
    return contract, cr, rr, own, plan, scope, inv, accept


def ford_supplement_members(spec, pkg, inventory):
    ck(spec['rowSchema'] in ('logical-path-originalPath', 'absolute-path-logical-member'), 'unknown supplement row schema')
    ck(pkg['unchangedRecoveryArchiveCount'] == spec['originalCoreArchiveCount']
       and pkg['outsideRecoveryArchiveSet'] is True and pkg['nativeByteReadbackVerified'] is False, 'supplement original boundary')
    identity = spec['identity']
    ck('nativeByteReadbackVerified' not in identity or identity['nativeByteReadbackVerified'] is False, 'supplement readback upgraded')
    expected_boundaries = {
        'Roadmark-RENAULT-delivery-verification-supplement-20261015.tar.xz': (142, 'logical-path-originalPath'),
        'Roadmark-RENAULT-delivery-correction-20261015.tar.xz': (142, 'logical-path-originalPath'),
        'Roadmark-NISSAN-delivery-single-create-correction-20261016.tar.xz': (145, 'absolute-path-logical-member'),
    }
    ck(expected_boundaries[pkg['filename']] == (spec['originalCoreArchiveCount'], spec['rowSchema']), 'supplement known history/schema')

    def normalize(r):
        original, member = (r['originalPath'], r['path']) if spec['rowSchema'] == 'logical-path-originalPath' else (r['path'], r['member'])
        ck(P(original).is_absolute() and '..' not in P(original).parts, 'invalid supplement original path')
        safe(member)
        out = {'path': member, 'originalPath': original, 'bytes': r['bytes'], 'sha256': r['sha256']}
        ck(valid(out), 'invalid supplement row pin')
        return out

    package_rows, inventory_rows = [normalize(r) for r in pkg['members']], [normalize(r) for r in inventory['files']]
    pm, im = rows(package_rows), rows(inventory_rows)
    ck(len(pm) == pkg['memberCount'], 'supplement member count')
    own = [r for r in package_rows if r['originalPath'] == spec['inventory']['path']]
    ck(len(own) == 1 and own[0]['path'] not in im and sh(own[0]) == sh(spec['inventory']), 'supplement self inventory exact pin')
    im[own[0]['path']] = core(own[0])
    ck(pm == im, 'supplement package/inventory complete bijection')
    by = {r['path']: r for r in inventory_rows + own}
    ck(all(by[r['path']]['originalPath'] == r['originalPath'] for r in package_rows), 'supplement original attribution differs')
    return pm, inventory_rows + own


def ford_inherited_accounting(ac):
    prior_path = B / 'SEED-READ-ACCOUNTING-after-correction-v1.json'
    current_prior = sealed(prior_path)
    expected_summary = {'attempts': 7, 'successfulPasses': 7, 'nonzeroOrTimeout': 0, 'unknownTerminalOutcomes': 0,
                        'independentlyEstablishedKnownZeroFailures': 0, 'zeroFailuresQualification': 'No current phase is classified known-zero by this revision'}
    ck(current_prior['currentInvocationSummary'] == expected_summary, 'exact inherited Nissan7/7 summary')
    expected = {'receipt': ALLOWED[str(prior_path)], 'currentInvocationSummary': expected_summary,
                'olderInheritedAccounting': current_prior['inheritedRenaultAccounting'],
                'originalCupraUnknownPreservedByExactReceipt': True, 'originalRenaultFactualReportUnknownPreservedSeparately': True}
    ck(ac['inheritedNissanAccounting'] == expected, 'current Ford must separately preserve Nissan accounting')
    older = current_prior['inheritedRenaultAccounting']
    prior = load(older['receipt'])
    ck(older['attempts'] == len(prior['phases']) == 11 and older['successfulPasses'] == sum(p['outcome'] == 'PASS' for p in prior['phases']) == 9
       and older['knownZeroPreconditionFailures'] == sum(p['knownZeroSeedPreconditionFailure'] for p in prior['phases']) == 2, 'historical Renault11/9/2')
    return prior


def reference_bytes():
    for q in (BASE, *BASE.parents):
        if stat.S_ISLNK(q.lstat().st_mode): raise AssertionError('symlink verifier reference')
    z = BASE.lstat()
    assert stat.S_ISREG(z.st_mode)
    before = (z.st_size, z.st_mtime_ns, z.st_ctime_ns, z.st_ino, z.st_dev)
    raw = BASE.read_bytes()
    z = BASE.lstat()
    assert before == (z.st_size, z.st_mtime_ns, z.st_ctime_ns, z.st_ino, z.st_dev)
    assert {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()} == BASE_PIN
    return raw


def adapted_tree(raw):
    text = raw.decode()
    tree = ast.parse(text, filename=str(BASE))
    functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}

    def change(name, edits):
        node = functions[name]
        source = ast.get_source_segment(text, node)
        for old, new, expected in edits:
            assert source.count(old) == expected, (name, old, source.count(old), expected)
            source = source.replace(old, new)
        replacement = ast.parse(source).body[0]
        tree.body[tree.body.index(node)] = replacement

    change('captures', [
        ("INDEPENDENTLY_ACCEPTED_EXACT_NISSAN_COPY_MAPPING", "INDEPENDENTLY_ACCEPTED_EXACT_FORD_COPY_MAPPING", 1),
        ("sum(P(r['path']).suffix=='.json' for r in scope['files'])", "sum(P(r['path']).suffix=='.json' or P(r['path']).suffix.lower()=='.headers' for r in scope['files'])", 1),
        ("len(cr)==495", "len(cr)==545", 1),
        ("changed={r['sourceRelativePath']:r for r in plan['exactPlannedLiveTargets'] if r['sourceRelativePath'] is not None}", "changed={P(r['path']).relative_to(W/'roadmark-104').as_posix():{'frozenPin':r} for r in plan['fordEvidence']['sourceAndStatusAfterPins'] if P(r['path']).is_relative_to(W/'roadmark-104')}", 1),
        ("len(changed)==6 and len(plan['exactPlannedLiveTargets'])==7", "len(changed)==7 and len(plan['fordEvidence']['sourceAndStatusAfterPins'])==8", 1),
        ("len(oldrows)==700 and len(sr)==703", "len(oldrows)==703 and len(sr)==706", 1),
        ("plan['sourcePolicy']['provisionalAddedSourcePaths']", "plan['sourcePolicy']['sourceAdditions']", 1),
        ("deliverables/Roadmark-RECOVERY-MANIFEST-RENAULT-WORKING-20261015.json", "deliverables/Roadmark-RECOVERY-MANIFEST-NISSAN-WORKING-20261015.json", 1),
    ])
    change('archive_replay', [
        ("sp['members']==len(sp['memberFiles'])==704", "sp['members']==len(sp['memberFiles'])==707", 1),
        ("nissan-safety-support/COPY-SANITATION-MAPPING.json", "ford-safety-support/COPY-SANITATION-MAPPING.json", 3),
        ("Roadmark-recovery-source-NISSAN-WORKING-20261015T2220", "Roadmark-recovery-source-FORD-WORKING-20261016T0145", 1),
        ("Roadmark-recovery-NISSAN-WORKING-20261015T2220", "Roadmark-recovery-FORD-WORKING-20261016T0145", 1),
    ])
    change('references', [
        ("{'bytes':16143,'sha256':'62d4b02318ae71df2236b889582875c981ebb42c13d4df25bcb8bdd6878d2e22'}", "sh(REFERENCE_CONFIG_PIN)", 1),
        ("len(basears)==142 and len(prior_restore['archivesInRestoreOrder'])==142", "len(basears)==145 and len(prior_restore['archivesInRestoreOrder'])==145", 1),
        ("plan['base']['sourceArchive']", "base['source']", 2),
        ("len(reused)==141 and len({a['filename'] for a in reused})==141", "len(reused)==144 and len({a['filename'] for a in reused})==144", 1),
        ("len(allby)==141+len(archives)", "len(allby)==144+len(archives)", 1),
        ("len(supplements)==2", "len(supplements)==3", 1),
        ("identity['nativeByteReadbackVerified'] is False", "('nativeByteReadbackVerified' not in identity or identity['nativeByteReadbackVerified'] is False)", 1),
        ("pkg['unchangedRecoveryArchiveCount']==142", "pkg['unchangedRecoveryArchiveCount']==s['originalCoreArchiveCount']", 2),
        ("ordinary-noncredential-approval-prose", "EXACT_HISTORICAL_ACTION_APPROVAL_PROSE_NOT_HTTP_AUTHENTICATION", 1),
        ("nissan-recovery-support/base-renault/", "ford-recovery-support/base-nissan/", 1),
        ("for name in ('FINAL-RENAULT-UPLOAD-RECEIPTS.json','INDEPENDENT-RENAULT-TERMINAL-CLOSURE-v1.json'):\n  hits=[r for r in pending if P(r['expected']['path'])==B/name];ck(len(hits)==1 and hits[0]['mandatory'] is True,'mandatory late Renault support')", "for required in conf['pendingSupportCandidates']:\n  if required['mandatory']:\n   hits=[r for r in pending if r==required];ck(len(hits)==1,'mandatory exact late Nissan support')", 1),
        ("'baseArchivesReused':141,'archiveCount':141+len(archives)", "'baseArchivesReused':144,'archiveCount':144+len(archives)", 1),
        ("'fullSourceFiles':703,'sourceArchiveMembers':704", "'fullSourceFiles':706,'sourceArchiveMembers':707", 1),
        ("a['nativeByteReadbackVerified'] is False", "('nativeByteReadbackVerified' not in a or a['nativeByteReadbackVerified'] is False)", 1),
    ])
    prior_block = "prior=sealed(B/'SEED-READ-ACCOUNTING-after-active-v2.json');old=ac['inheritedRenaultAccounting'];expectedold={'receipt':ALLOWED[str(B/'SEED-READ-ACCOUNTING-after-active-v2.json')],'attempts':11,'successfulPasses':9,'knownZeroPreconditionFailures':2,'originalCupraUnknownPreservedByExactReceipt':True,'originalRenaultFactualReportUnknownPreservedSeparately':True}\n ck(old==expectedold and len(prior['phases'])==11 and sum(p['outcome']=='PASS' for p in prior['phases'])==9 and sum(p['knownZeroSeedPreconditionFailure'] for p in prior['phases'])==2,'inherited Renault9/11/2')"
    change('accounting', [(prior_block, "prior=ford_inherited_accounting(ac)", 1),
                          ("INDEPENDENTLY_ACCEPTED_NISSAN_PRIVACY_ADAPTER", "INDEPENDENTLY_ACCEPTED_FORD_PRIVACY_ADAPTER", 1)])
    change('main', [
        ("INDEPENDENT-NISSAN-RECOVERY-VERIFICATION-v1.json", "INDEPENDENT-FORD-RECOVERY-VERIFICATION-v1.json", 1),
        ("plan['nissanEvidence']['finalFreeze']", "plan['fordEvidence']['inventory']", 1),
        ("plan['nissanEvidence']['finalRetentionReview']", "plan['fordEvidence']['finalRetentionAcceptance']", 1),
        ("len([r for r in originals if r['liveTarget']])==7", "len([r for r in originals if r['liveTarget']])==8", 1),
        ("for p in inv['retainedFailures']['preparationFailurePaths']:ck(logical(p) in rows(restore['files']),'Nissan preparation failure omitted')\n for p in inv['retainedFailures']['reviewerDiagnosticPaths']:ck(logical(p) in rows(restore['files']),'Nissan diagnostic omitted')", "for p in inv['retainedFailures']['failureAndDiagnosticPaths']:ck(logical(p) in rows(restore['files']),'Ford failure or diagnostic omitted')", 1),
        ("'inheritedPreparationLimitations':base['currentPreparationLimitations']", "'inheritedBaseRecovery':base['baseRecovery']", 1),
        ("'inheritedRecoveryMetadata':base['inheritedRecoveryMetadata']", "'inheritedNissanIndependentVerification':base['independentVerification']", 1),
        ("'inheritedRenaultAccounting':ac['inheritedRenaultAccounting']", "'inheritedNissanAccounting':ac['inheritedNissanAccounting']", 1),
        ("PASS_INDEPENDENT_NISSAN_FRESH_RECOVERY", "PASS_INDEPENDENT_FORD_FRESH_RECOVERY", 1),
        ("'sourceProjectFiles':703", "'sourceProjectFiles':706", 2),
        ("'sourceArchiveMembers':704", "'sourceArchiveMembers':707", 1),
        ("'authorInventoryFiles':492,'separateFreezeExtras':3,'capturedOriginalsRehashed':495", "'authorInventoryFiles':538,'separateFreezeExtras':7,'capturedOriginalsRehashed':545", 1),
        ("'acceptedFinalRetentionScope':'accepted'", "'acceptedFinalRetentionScope':'accepted factual/metadata retention only'", 1),
        ("'sevenLiveTargetsVerified'", "'eightLiveTargetsVerified'", 1),
        ("'all495OriginalsStableThroughFinalGate'", "'all545OriginalsStableThroughFinalGate'", 1),
        ("'freshOriginalPayloadReadsOnly':495", "'freshOriginalPayloadReadsOnly':545", 1),
        ("'scopeOriginalFiles':495", "'scopeOriginalFiles':545", 1),
        ("'originalFiles':495", "'originalFiles':545", 1),
    ])
    own_tree = ast.parse(P(__file__).read_bytes(), filename=__file__)
    own_functions = {n.name: n for n in own_tree.body if isinstance(n, ast.FunctionDef)}
    for new_name, old_name in [('ford_context', 'context'), ('ford_supplement_members', 'supplement_members')]:
        replacement = own_functions[new_name]
        replacement.name = old_name
        tree.body[tree.body.index(functions[old_name])] = replacement
    tree.body.append(own_functions['ford_inherited_accounting'])
    mains = [n for n in tree.body if isinstance(n, ast.If) and ast.dump(n.test) == ast.dump(ast.parse("__name__=='__main__'", mode='eval').body)]
    assert len(mains) == 1
    tree.body.remove(mains[0])
    ast.fix_missing_locations(tree)
    return tree


def main():
    tree = adapted_tree(reference_bytes())
    namespace = {'__file__': str(P(__file__).resolve()), '__name__': 'ford_independent_pinned_checker'}
    exec(compile(tree, str(BASE), 'exec'), namespace)
    namespace['B'] = C.parent / 'nissan-working-20261015T2220'
    namespace['FIXED'] = FIXED_PINS
    namespace['REFERENCE_CONFIG_PIN'] = REFERENCE_CONFIG_PIN
    namespace['main']()


if __name__ == '__main__':
    main()
