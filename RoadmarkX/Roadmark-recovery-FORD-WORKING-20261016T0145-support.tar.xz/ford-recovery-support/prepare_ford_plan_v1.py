"""Metadata-only Ford recovery proposal. No payload, helper, archive or seed reads."""
import datetime
import hashlib
import json
from pathlib import Path

W = Path('/workspace/scratch/586427eef9f2')
R = W / 'roadmark-recovery-20261014'
C = R / 'checkpoints/nissan-working-20261015T2220'
F = R / 'checkpoints/ford-working-20261016T0145'
REPO = W / 'roadmark-104'
reads = {}


def metadata(path, expected=None):
    p = Path(path)
    assert p.suffix == '.json', p
    b = p.read_bytes()
    pin = {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
    if expected:
        assert pin['sha256'] == expected, pin
    reads[str(p)] = pin
    return json.loads(b), pin


def write_new(name, obj):
    p = F / name
    b = (json.dumps(obj, indent=2, ensure_ascii=False) + '\n').encode()
    with p.open('xb') as out:
        out.write(b)
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


inv, invpin = metadata('/tmp/ford-packet/final-freeze-v1/inventory.json', '24a828ef8c1d84081d36b0a4b602b20f3367d5963118fbe29b0365886088ca7e')
accept, acceptpin = metadata('/tmp/ford-review/final-retention-v1-accepted.json', 'fc873e67b9bc10e3378170b95b61bf1b3f083ef6ae05700a0de134cd29b47916')
bundle, bundlepin = metadata('/tmp/ford-final-retention-review-v1/manifest.json', '52f178f0dbb6084335840a587861cec6ba913101d6e2fa08769f01abc85121c5')
scope, scopepin = metadata(C / 'FROZEN-CAPTURE-SCOPE.json', '655decf522259c518bd291634c2dedcb54e04f063c6a1cb897a096bc42c486d1')
prior_plan, prior_plan_pin = metadata(C / 'SAFETY-SAVE-PLAN-v3.json', 'c92179241184ff825c2b494f2a78d93b30ecdcea31a52ecb45313fa23dade08b')
restore, restorepin = metadata(C / 'RESTORE-PLAN-v2.json', '8984ec9c38585498d105d0296a536773cc70cede7a66c0071358f1b6af445435')
archiveplan, archivepin = metadata(C / 'ARCHIVE-PLAN.json', '3efef28cdb354aa4af0f4a5a9ea48b4ac6b7c8e1b1a4a595fa76b2b9c27ffeae')
source_package, source_package_pin = metadata(C / 'source-package.json', '297014fb52d2bafeff13bffb65963dd8854e03849d827eb1f51e9c0453fa6cb9')
_, source_capture_pin = metadata(C / 'source-capture.json', 'bb915ea6091229b284090fb4c972623bcb0e6282ca7e01a763c2e70909d2c1f0')
final, finalpin = metadata(C / 'FINAL-NISSAN-UPLOAD-RECEIPTS.json', 'e6356c5af77521fb3d4492fdbd43832662947ccea89e84d7dd25e894e935f740')
terminal, terminalpin = metadata(C / 'INDEPENDENT-NISSAN-TERMINAL-CLOSURE-v1.json', '59a043f3a71c62f22bc0ecac95fabdad96f9b0375c39c4a3cad9fb1c59b3fffc')
_, terminal_review_pin = metadata(C / 'INDEPENDENT-NISSAN-TERMINAL-RESULT-REVIEW-v1.json', '02018761df31a03164a8277b0ff03d0e855f96a019cb8fc039cf677fa3ff76b1')
closing, closingpin = metadata(C / 'NISSAN-CLOSING-ADAPTER-CONTRACT-v1.json', 'c8801d51345ccb34c523aefd69f5118c54e9adf84079f4d298166a24452ee16e')
_, inheritedpin = metadata(C / 'NISSAN-INHERITED-ADAPTER-PINS-v1.json')
retention, retentionpin = metadata(C / 'NISSAN-CLOSING-RETENTION-v1.json', '13716f4cb8c0f92918ae072891ca4fd53695df027c33f64a8b1e3970a78d7fd7')
accounting, accountingpin = metadata(C / 'SEED-READ-ACCOUNTING-after-correction-v1.json', 'f92470e29c5e8e417d1115650ab9e34eab4d9fcf0399b5ed9e438dfd92013b33')
_, supportinventorypin = metadata(C / 'SUPPORT-MEMBER-INVENTORY-v2.json', '62bd4d89488072f0113353589414e33caa424ff3e9cbd026f663011a82a44a92')
_, supportreusepin = metadata(C / 'SUPPORT-REUSE-MAPPING.json', '0b4b805f4f6777ac2b8e95407f4b05daf64d6679c37080154f2084c390dc30de')
_, correction_inventory_pin = metadata(C / 'DELIVERY-SINGLE-CREATE-CORRECTION-MEMBER-INVENTORY-v1.json', '1cace278fdcf42dbec6944f9ef966513169e2b6bd8ad5bf4d6ac3762875ac1d1')

assert accept['status'] == 'accepted'
assert accept['inventory'] == invpin
assert inv['totalFiles'] == 538 and inv['regularFileBytes'] == 66896242
paths = [x['path'] for x in inv['files']]
assert len(paths) == len(set(paths)) == 538
assert sum(x['bytes'] for x in inv['files']) == 66896242
extra = accept['separateRetentionRequired']
extras = [extra['finalInventory'], extra['finalPreparer'], extra['finalReviewBundle'], *extra['finalReviewBundleMembers'], acceptpin]
assert inv['preparer'] == extra['finalPreparer']
assert extra['finalInventory'] == invpin and extra['finalReviewBundle'] == bundlepin
assert bundle['files'] == extra['finalReviewBundleMembers']
assert len(extras) == len({x['path'] for x in extras}) == 7
assert not set(paths) & {x['path'] for x in extras}
assert sum(x['bytes'] for x in extras) == 409054

live = inv['sourceAndStatusAfterPins']
assert len(live) == 8
source_delta = [x for x in live if x['path'].startswith(str(REPO) + '/')]
overlay = [x for x in live if x not in source_delta]
assert len(source_delta) == 7 and len(overlay) == 1
oldpaths = scope['expectedSourcePaths']
assert len(oldpaths) == len(set(oldpaths)) == 703
delta_paths = [str(Path(x['path']).relative_to(REPO)) for x in source_delta]
additions = sorted(set(delta_paths) - set(oldpaths))
replacements = sorted(set(delta_paths) & set(oldpaths))
assert additions == ['data/m1-brand-updates/ford-2026-10-15.json', 'data/m1-ford-market-reconciliation-2026-10-15.json', 'docs/FORD_M1_UPDATE.md']
assert len(replacements) == 4
expected_paths = sorted(set(oldpaths) | set(delta_paths))
assert len(expected_paths) == 706
source_name = source_package['filename']
assert source_package['members'] == 704
assert len(restore['archivesInRestoreOrder']) == 145
reused = [x for x in restore['archivesInRestoreOrder'] if x['filename'] != source_name]
assert len(reused) == 144
assert len({x['filename'] for x in reused}) == 144
assert final['counts']['archiveCount'] == 145
assert final['nativeByteReadbackVerified'] is False
assert terminal['nativeByteReadbackVerified'] is False
assert final['status'] == 'LOCAL_RECOVERY_VERIFIED_SERVER_CREATE_CONFIRMED_NATIVE_READBACK_UNPASSED_RELEASE_UNPASSED'
uploaded = {x['filename']: x for x in final['files']}
reuse_entries = []
for row in reused:
    item = {k: row[k] for k in ['filename', 'bytes', 'sha256', 'restoreOrder']}
    if row['filename'] in uploaded:
        u = uploaded[row['filename']]
        assert (u['bytes'], u['sha256']) == (row['bytes'], row['sha256'])
        item['nativeIdentity'] = {k: u[k] for k in ['library_file_id', 'file_id', 'version']}
        item['identityAuthority'] = finalpin
        item['nativeByteReadbackVerified'] = u['nativeByteReadbackVerified']
    else:
        item['nativeIdentity'] = {k: row[k] for k in ['library_file_id', 'file_id', 'version']}
        item['identityAuthority'] = restorepin
        item['nativeByteReadbackStatus'] = 'INHERITED_EXACT_PRIOR_RECEIPT_SCOPE; not upgraded by this plan'
    reuse_entries.append(item)

late_names = [
    'CORRECTION-CREATE-CONTRACT-PREPARATION-FAILURE-v1.json',
    'NISSAN-CORRECTION-CREATE-CONTRACT-v1.json',
    'CLOSING-RETENTION-REVIEW-PREPARATION-ORDER-ASSERTION-v1.json',
    'ACTIVE-DELIVERY-CONFIRMATION-PREPARATION-FAILURE-v1.json',
    'ACTIVE-DELIVERY-CONFIRMATION-RETRY-PREPARATION-v1.json',
    'INDEPENDENT-NISSAN-ACTIVE-DELIVERY-CONFIRMATION-RETRY-REVIEW-v1.json',
    'ACTIVE-DELIVERY-CONFIRMATION-RETRY-RESULT-v1.json',
    'ACTIVE-DELIVERY-CONFIRMATION-v1.json',
    'OWNER-ACTIVE-DELIVERY-REQUEST-v1.json',
    'OWNER-ACTIVE-DELIVERY-RESPONSE-v1.json',
]
# Only existing named JSON metadata, never executable/seed/archive contents.
late = []
for name in late_names:
    _, pin = metadata(C / name)
    late.append(pin)

reuse_pin = write_new('BASE-ARCHIVE-REUSE-PLAN-v1.json', {
    'status': 'METADATA_ONLY_EXACT_PRIOR_NON_SOURCE_ARCHIVE_REUSE',
    'authority': restorepin, 'currentNativeIdentityAuthority': finalpin,
    'excludedSourceArchive': {k: source_package[k] for k in ['filename', 'bytes', 'sha256', 'members']},
    'reusedArchiveCount': 144, 'archives': reuse_entries,
    'restoreOrderRule': 'Preserve this sequence. Reindex contiguously only in the future combined restore plan; inherited restoreOrder values are provenance, not new output order.',
    'archivePayloadReadsPerformed': False,
})
source_set_pin = write_new('EXPECTED-SOURCE-PATHS-v1.json', {
    'status': 'METADATA_EXPECTATION_NOT_CAPTURED', 'baseScope': scopepin,
    'baseProjectFiles': 703, 'approvedLivePins': source_delta,
    'additions': additions, 'replacements': replacements,
    'expectedSourcePaths': expected_paths, 'expectedProjectFiles': 706,
    'expectedArchiveMembersIncludingManifest': 707,
    'externalQaOverlay': overlay, 'currentPayloadReadOrHashPerformed': False,
})

plan = {
    'schemaVersion': 1,
    'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'METADATA_ONLY_PLAN_AWAITING_INDEPENDENT_REVIEW_AND_ROOT_CAPTURE_GRANT',
    'checkpoint': str(F), 'baseCheckpoint': str(C), 'repo': str(REPO),
    'approvalScope': 'Planning only. Existing Nissan grants are not Ford grants. Exact frozen Ford capture, inherited in-memory seed reads, scans, compression, replay and persistence remain held for separate root approval and reviewed immutable execution adapters.',
    'base': {
        'finalReceipt': finalpin, 'terminalReceipt': terminalpin, 'terminalResultReview': terminal_review_pin,
        'qualification': final['status'], 'nativeByteReadbackVerified': False,
        'sourceLibraryFileId': final['sourceLibraryFileId'],
        'activeReceiptLibraryFileId': final['activeReceiptLibraryFileId'],
        'counts': final['counts'], 'archivePlan': archivepin, 'restorePlan': restorepin,
        'localRecoveryPassed': True, 'nativePersistence': 'create-confirmed',
        'noDeniedMaterializationRetryOrAlternateReadRoute': True,
    },
    'fordEvidence': {
        'inventory': invpin, 'preparer': inv['preparer'],
        'finalRetentionAcceptance': acceptpin, 'acceptedStatusExact': accept['status'],
        'acceptanceScope': 'Factual and metadata retention only; no privacy, capture, runtime or native delivery acceptance inferred.',
        'finalReviewBundle': bundlepin, 'noncircularExtras': extras,
        'frozenPaths': 538, 'frozenRegularBytes': 66896242,
        'separateExtraPaths': 7, 'separateExtraBytes': 409054,
        'exactAuthorClosurePaths': 545, 'exactAuthorClosureRegularBytes': 67305296,
        'sourceAllowance': inv['sourceAllowlist'],
        'sourceAllowanceAcceptance': inv['sourceRetentionAcceptance'],
        'sourceAllowlistedResearchFiles': 78,
        'factualReportAcceptance': inv['factualReportAcceptance'],
        'scopedAcceptance': inv['scopedAcceptance'],
        'independentDocsReadback': inv['independentDocsReadback'],
        'sourceAndStatusAfterPins': live,
        'retainedStorageReadClosure': inv['retainedStorageReadClosure'],
        'storageReadClosureShape': 'List-shaped metadata; use its actual schema, not an assumed object schema.',
        'publicImageProvenance': inv['publicImageProvenance'],
        'rawRuntimeExclusion': inv['rawRuntimeExclusion'],
        'exclusions': inv['excluded'],
        'snapshotDate': inv['researchReportAsOf'], 'validationCompletedOn': inv['validationCompletedOn'],
    },
    'sourcePolicy': {
        'sourceExclusionBasis': prior_plan['sourcePolicy']['sourceExclusionBasis'],
        'currentBaseSourceScope': scopepin, 'priorSourceCapture': source_capture_pin,
        'priorSourcePackage': source_package_pin, 'exactExpectedPathSet': source_set_pin,
        'baseSourceFiles': 703, 'sourceChangedPaths': delta_paths,
        'sourceAdditions': additions, 'sourceReplacements': replacements,
        'expectedSourceFiles': 706, 'expectedArchiveMembersIncludingManifest': 707,
        'capturedCountsFinal': False, 'externalQaOverlay': overlay,
        'maximumCompressedSourceBytesExclusive': 15000000,
        'method': 'Stream the exact prior pinned source archive members and seven approved source replacements/additions into one standalone archive; retain original member identities for unchanged source. Read no unchanged live source and create no full base clone. Verify every final member and full archive size/hash after approved capture.',
        'sourceFullCloneAllowed': False, 'broadBaseScanAllowed': False,
        'unchangedLiveSourceReadAllowed': False, 'liveSourceMutationAllowed': False,
        'sourceFreezeReleaseOnlyAfterIndependentCapturedIntegrityPass': True,
    },
    'retention': {
        'authorClosure': 'Exactly inventory.files plus the seven noncircular extras; preserve all original logical paths, held versions, empty logs and failures. The new reviewed recovery plan/preparer/review and actual recovery phase receipts are an additional finite support selection, not part of the author closure count.',
        'stableIdentityFields': ['device', 'inode', 'size', 'mtime_ns', 'ctime_ns', 'mode'],
        'atimeExcluded': True, 'noSymlinkTraversal': True, 'noDeletion': True,
        'rawExcludedRefetchAllowed': False, 'seedValuesOrValueDigestsPersisted': False,
        'allDeliveredFreshMembersRequireFullPrivacyScan': True,
        'failureHistory': inv['retainedFailures'], 'otherAttemptHistory': inv['otherAttemptHistory'],
        'lateNissanMetadata': late,
        'lateNissanMetadataRetentionRule': 'Keep exact referenced terminal/final receipts and the local-only preparation histories; bind a finite new support selection if needed. Do not claim late metadata was included in the earlier sealed correction artifact, mutate that artifact, or reconstruct missing bytes.',
        'lateNissanExactCommandProvenance': retention['localOnlyPreparationProvenance'],
        'noExecutableSourceTextEmbeddedInJson': True,
    },
    'recoveryReuse': {
        'exactPriorArchiveReuse': reuse_pin, 'priorNonSourceArchivesReused': 144,
        'priorSourceArchiveReplacedOnlyInNewRestorePlan': source_name,
        'oldArchivesRemainImmutable': True,
        'compactSupport': 'Retain each new unique helper once. Use exact member/size/hash pointers for existing retained helpers. Matched prior members must reuse exact identities; unmatched non-code metadata, including empty logs, may be a fresh exact member. Unmatched code requires independent finite selection review before capture.',
        'sourceAndProofFreshArchiveCount': 'Determined only by approved frozen capture and packaging; no estimated total presented as final.',
        'supportMemberInventoryAuthority': supportinventorypin, 'supportReuseAuthority': supportreusepin,
        'referenceClosure': 'Resolve the finite exact references consumed by current helpers against the current restore plan and named delivery-only correction inventory. Do not sweep unrelated dependencies. External runtime paths need exact independently classified path/hash/size mapping and explicit non-retention; no prefix exemptions or runtime-retention claim.',
    },
    'deliveryOnlySupplementsOutsideRecovery': {
        'renault': prior_plan['deliveryOnlySupplementsOutsideRecovery'],
        'nissan': final['deliveryOnlyClosingArtifact'],
        'nissanClosingRetention': retentionpin, 'nissanCorrectionInventory': correction_inventory_pin,
        'countedInCore145OrFutureCoreChain': False,
        'reuseExactPointersDoNotRepackage': True,
    },
    'reviewedPriorHelpers': {
        'inheritedPins': inheritedpin,
        'closingContract': closingpin,
        'acceptedSingleAndBatchResponseAdapter': closing['adapter'],
        'closingAdapterReview': closing['review'],
        'closingAdapterTests': closing['tests'],
        'closingAdapterTestScript': closing['testScript'],
        'baseProducer': closing['producer'], 'baseChecker': closing['checker'],
        'baseNormalizer': closing['normalizer'],
        'scope': 'References only. No prior helper executable contents read or run during this metadata-only preparation. Future Ford-specific adapter/configuration must use these current exact identities, with independent exact-diff review; no execution of hardcoded Nissan modes for Ford.',
    },
    'adapterRules': {
        'allReviewedRevisionsNewImmutableFiles': True,
        'auditBeforeExecution': ['canonical checkpoint and every parent/path contract', 'actual final-retention accepted status and scope', 'current restore-plan field names and list/object shapes', 'current archive/source/fresh/support counts', 'every failed or held phase and zero/unknown read accounting', 'single and batch host-create return shapes', 'document, active, persisted and terminal consumers', 'provider-only version xattrs', 'outside-chain supplement counts', 'timestamp raw spelling versus parsed instant'],
        'nativeResponseRule': 'Preserve each provider request and response exactly. A separately bound in-memory view may normalize documented single or batch response shapes only after exact review; require one success per requested file, exact path/name/size/ID/version and no duplicates/extras/missing rows. Never synthesize a provider response or infer absent fields. Preserve the optional documented library_artifact_type request field.',
        'timestampRule': 'Copy the exact returned timestamp string. If semantic comparison is necessary, parse the instant; Z and +00:00 are equivalent.',
        'privacyFindingsRule': 'Retain raw findings/searches. Any copied-key change requires exact independent classification and root approval for current file/member/span with reversible mapping and unchanged outside bytes. Any syntax finding classification requires current whole-member/file/span/AST checks and strict extra/missing/duplicate rejection. No inherited blanket extension, syntax, field-name or prefix exemptions.',
    },
    'seedAccounting': {
        'currentFordReadsPerformed': 0,
        'futureFordSeedReadGrant': 'PENDING; exact inherited scope in memory only',
        'inheritedNissanAccounting': accountingpin,
        'inheritedNissanInvocationSummary': accounting['currentInvocationSummary'],
        'inheritedStageCompletedOperations': {k: v['totalCompletedOperations'] for k, v in accounting['stages'].items()},
        'inheritedLocalCompletedReads': {k: accounting['inheritedLocal'][k] for k in ['totalProvedValueReads', 'totalProvedIntegrityReads', 'accountingMethod']},
        'olderInheritedAccounting': accounting['inheritedRenaultAccounting'],
        'futureCounts': 'Account actual invocations, completed seed/member/integrity reads and terminals. Missing receipt or absent stage is not zero. Explicit UNKNOWN for unknown outcomes; exact zero only with independent evidence. Do not sum inherited attempts into current Ford counts.',
        'seedValuesPersisted': False,
        'cupraOriginalScanUnknownAndRenaultOriginalReportUnknownSeparate': True,
    },
    'nativeFlow': {
        'status': 'HELD_UNTIL_LOCAL_PRIVACY_REPLAY_AND_ROOT_PERSISTENCE_GRANT',
        'supportedRoute': 'Inspect current official Library contract; use create_library_file absolute local host paths for exact verified files. Preserve exact requests, responses and provider-returned xattrs; verify local hash/size and returned native identities without claiming remote-byte verification.',
        'nativeByteReadbackVerified': False,
        'nativePersistenceLabel': 'create-confirmed only after an actual successful server create',
        'deniedReadbackRetryAllowed': False, 'alternateDeniedScopeReadRouteAllowed': False,
        'uncertainCreateRetryAllowed': False,
        'fiveDeliveryFiles': ['standalone source archive', 'buyer update', 'backup index', 'recovery manifest', 'local verification and native limitation report'],
        'laterActiveReceipt': 'Prepare only after the exact accepted five-file delivery response. Preserve actual response shape and timestamp; parent handles delivery.',
        'savingAnnouncement': {'messageId': 'Sentinel_f55ca22aceb4819195571ff4c6a600d8', 'timestamp': '2026-10-16T00:54:21.017252Z'},
    },
    'boundedPhases': {
        'maximumAddressSpaceBytes': 268435456, 'phaseWallLimitSeconds': 600,
        'higherMemoryExceptionGranted': False, 'oneHeavyProcessAtATime': True,
        'terminalBeforeDependentPhase': True, 'rootHeavySlotCoordinationRequired': True,
        'phasesAfterSeparateGrant': ['exact JSON preflight and classification', 'frozen changed-source and exact proof capture', 'all fresh member privacy scans with actual in-memory seed accounting', 'source/proof packaging and finite compact support closure', 'independent full fresh archive member replay', 'five delivery documents privacy and independent checks', 'official host create and local/provider identity binding', 'accepted delivery, active receipt and qualified persisted/terminal closure'],
    },
    'historicalLimitations': prior_plan['historicalLimitations'] + [
        'Ford current TypeScript/release/full suite/build/phone/research completion are unpassed; 151 scoped tests and the normal report/comparator are passed.',
        'Ford provider outage preceded the last-two validator processes; preserve separate pre-execution and same-VM/pin provenance, not an invented runtime failure.',
        'Nissan single-result closing correction and late zero-write metadata preparation failures remain retained with their actual status. The sealed 80-member correction artifact excludes later local-only entries.',
        'Exact unavailable superseded Renault and mutable CUPRA preparation bytes remain unavailable; retain existing disclosures, never reconstruct or imply full draft-byte retention.',
    ],
    'currentFordValidation': inv['currentValidation'],
    'openFactualLimits': inv['openFactualLimits'],
    'gatesBeforeAnyCapture': ['independent acceptance of this exact plan and bindings', 'root exact Ford capture/in-memory seed grant and heavy slot', 'independent review of immutable Ford adapters and canonical invocations'],
    'executionPerformed': {'metadataReadsOnly': True, 'metadataPreparationScriptExecuted': True, 'capture': False, 'privacyScan': False, 'seedRead': False, 'archivePayloadRead': False, 'recoveryHelperExecution': False, 'compression': False, 'upload': False, 'sourceMutation': False},
    'metadataReadPins': list(reads.values()),
}
plan_pin = write_new('SAFETY-SAVE-PLAN-v1.json', plan)
print(json.dumps({'plan': plan_pin, 'sourcePathSet': source_set_pin, 'archiveReuse': reuse_pin, 'metadataFilesRead': len(reads), 'authorClosurePaths': 545, 'authorClosureBytes': 67305296}, indent=2))
