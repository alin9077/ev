#!/usr/bin/env python3
"""Pure pinned AST adapter checks; no capture, seed, scanner, or payload calls."""
import ast, hashlib, json, pathlib, sys
import ford_capture_adapter_v1 as capture
import ford_phase_gateway_v1 as gateway
import ford_privacy_adapter_v1 as privacy
import ford_seed_accounting_adapter_v2 as accounting

P = pathlib.Path
C = P(__file__).resolve().parent
tests = []

def check(label, condition):
    assert condition, label
    tests.append(label)

def syntax(path, transform, expected_pin):
    raw = capture.exact_bytes(path, expected_pin)
    tree = transform(ast.parse(raw, filename=str(path)))
    ast.fix_missing_locations(tree)
    compile(tree, str(path), 'exec')
    return tree

def constants(tree):
    return [n.value for n in ast.walk(tree) if isinstance(n, ast.Constant)]

def main():
    assert len(sys.argv) == 2 and P(sys.argv[1]) == C / 'FORD-ADAPTER-PURE-TEST-RESULT-v1.json'
    tree = syntax(capture.B / 'capture_v1.py', capture.capture_transform, capture._utility.CAPTURE_PIN)
    source = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'source')
    values = constants(source)
    check('source result706/base703/change7 without old697/700', all(x in values for x in [706, 703, 7]) and 697 not in values and 700 not in values)
    check('proof predecessor manifest is exact Nissan', constants(tree).count('deliverables/Roadmark-RECOVERY-MANIFEST-NISSAN-WORKING-20261015.json') == 1)
    tree = syntax(capture.NISSAN / 'nissan_phase_gateway_v2.py', gateway.transform, gateway.PIN)
    check('gateway imports exact Ford capture', sum(isinstance(n, ast.ImportFrom) and n.module == 'ford_capture_adapter_v1' for n in ast.walk(tree)) == 1)
    check('gateway imports exact Ford privacy in all three modes', sum(isinstance(n, ast.ImportFrom) and n.module == 'ford_privacy_adapter_v1' for n in ast.walk(tree)) == 3)
    check('gateway label and capture gate are Ford', 'FORD-WORKING-20261016T0145' in constants(tree) and 'FORD-CAPTURE-CANDIDATE-APPROVAL-v1.json' in constants(tree))
    check('gateway restores144 predecessors and explicitly keeps three supplements outside', gateway.NEW_RESTORE in constants(tree))
    tree = syntax(capture.NISSAN / 'nissan_privacy_adapter_v2.py', privacy.transform, privacy.PIN)
    check('privacy exact Ford contract', 'FORD-PRIVACY-ADAPTER-CONTRACT-v1.json' in constants(tree))
    check('privacy exact Ford preparation', 'FORD-ADAPTER-PREPARATION-v1.json' in constants(tree))
    comparisons = [n for n in ast.walk(tree) if isinstance(n, ast.Compare) and isinstance(n.left, ast.Attribute)
                   and isinstance(n.left.value, ast.Name) and n.left.value.id == 'privacy' and n.left.attr == 'BASE']
    check('privacy expected capture predecessor is Nissan', len(comparisons) == 1 and comparisons[0].comparators[0].id == 'NISSAN')
    tree = syntax(capture.NISSAN / 'nissan_seed_accounting_adapter_v1.py', accounting.transform, accounting.PIN)
    check('accounting uses exact current Nissan prior receipt', 'SEED-READ-ACCOUNTING-after-correction-v1.json' in constants(tree))
    check('accounting output key distinguishes inherited Nissan', 'inheritedNissanAccounting' in constants(tree))
    main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    paths = [n for n in main.body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'priorPath']
    check('accounting prior path is Nissan while counter stays Renault', len(paths) == 1 and paths[0].value.left.id == 'NISSAN'
          and any(isinstance(n, ast.BinOp) and isinstance(n.left, ast.Name) and n.left.id == 'B'
                  and isinstance(n.right, ast.Constant) and n.right.value == 'build_seed_accounting_v1.py' for n in ast.walk(main)))
    check('accounting prior summary independently pinned rather than hardcoded Renault attempt assert',
          any(isinstance(n, ast.Name) and n.id == 'INHERITED_SUMMARY' for n in ast.walk(main)))
    for label, transform, path, pin in [('capture', capture.capture_transform, capture.B / 'capture_v1.py', capture._utility.CAPTURE_PIN),
                                      ('gateway', gateway.transform, capture.NISSAN / 'nissan_phase_gateway_v2.py', gateway.PIN),
                                      ('privacy', privacy.transform, capture.NISSAN / 'nissan_privacy_adapter_v2.py', privacy.PIN),
                                      ('accounting', accounting.transform, capture.NISSAN / 'nissan_seed_accounting_adapter_v1.py', accounting.PIN)]:
        tree = transform(ast.parse(capture.exact_bytes(path, pin)))
        rejected = False
        try:
            transform(tree)
        except AssertionError:
            rejected = True
        check(label + ' rejects already transformed input', rejected)
    record = {'status': 'PASS', 'tests': tests, 'testCount': len(tests),
              'method': 'Compile transformed pinned source AST only; never execute transformed modules or phase functions',
              'captureOrPackageCalls': 0, 'seedOrPrivacyCalls': 0, 'payloadReads': 0}
    with P(sys.argv[1]).open('x') as f:
        json.dump(record, f, indent=2)
        f.write('\n')
    print(json.dumps({'status': 'PASS', 'tests': len(tests)}))

if __name__ == '__main__':
    main()
