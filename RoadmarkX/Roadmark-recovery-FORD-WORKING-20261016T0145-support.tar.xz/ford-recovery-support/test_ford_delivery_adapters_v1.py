#!/usr/bin/env python3
"""Separately gated pure synthetic protocol/AST tests. Never performs a delivery phase."""
import argparse,ast,copy,hashlib,json,os,pathlib,stat,sys,types
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent
UTILITY={'path':str(C/'ford_delivery_sealed_runtime_v2.py'),'bytes':4506,'sha256':'137c53c4d5e01a4c708aaa61ccd3c425ab3f53b7ef0bf8a8d153767f094b4d1f'}
PINS={'utility': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_delivery_sealed_runtime_v2.py', 'bytes': 4506, 'sha256': '137c53c4d5e01a4c708aaa61ccd3c425ab3f53b7ef0bf8a8d153767f094b4d1f'}, 'producer': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_delivery_adapter_v5.py', 'bytes': 10765, 'sha256': '6982e483aa400a0895123f7195cef23f01bf4b1fac326097d15ca3298b912c99'}, 'checker': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/independent_ford_delivery_v5.py', 'bytes': 15212, 'sha256': 'd8d203d70167bee9d60c5f622c469a9ce3db6b2ded06b5c78479bfdb65a58c37'}, 'closing': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_closing_adapter_v5.py', 'bytes': 6862, 'sha256': '88617fa569527d6fed90ee3132ed0de656435d32bd9923d3cb21c5893422cfcc'}, 'replay': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/independent_ford_recovery_v4.py', 'bytes': 26654, 'sha256': '289c8555ea27cc380ed2f3d67e58541a0747f0cfe4547f4ed21c4cbee38502fa'}, 'priorProducer': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/nissan_delivery_v3.py', 'bytes': 16490, 'sha256': 'e65fd17136f06032dced858053d61ad7365fca47acd5a969b351e37e6196857f'}, 'priorChecker': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/independent_nissan_delivery_v7.py', 'bytes': 46199, 'sha256': 'ac1652f80f0aaf8113120a431c4eecbb392f6ceed68e7074be5f7914258ebd1a'}, 'priorClosing': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/nissan_closing_adapter_v5.py', 'bytes': 36401, 'sha256': '8bc24997dfb2726c090c4a86538eaf8682ee6dd51a0639322fc7af48e4d245e0'}}
def utility():
 p=P(UTILITY['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in (p,*p.parents));b=p.read_bytes();t=p.lstat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns,t.st_ctime_ns) and {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}=={k:UTILITY[k] for k in ('bytes','sha256')};m=types.ModuleType('ford_delivery_test_loader');m.__file__=str(p);exec(compile(b,str(p),'exec'),m.__dict__);return m

def main():
 a=argparse.ArgumentParser();a.add_argument('mode',choices=['pure-tests']);a.add_argument('--contract',required=True);a.add_argument('--contract-sha256',required=True);a.add_argument('--review',required=True);a.add_argument('--review-sha256',required=True);args=a.parse_args();u=utility();authority,metadata,payload,outputs=u.runtime(args,__file__,'DELIVERY_PURE_TEST')
 assert not payload and outputs=={str(C/'FORD-DELIVERY-ADAPTER-PURE-TEST-RESULT-v1.json')}
 for r in PINS.values():assert metadata[r['path']]==r
 adapter=u.module(ast.parse(u.read_exact(PINS['closing'])),PINS['closing']['path'],'ford_pure_response_adapter');tests=[]
 def run(label,call,accepted):
  try:call()
  except (AssertionError,ValueError,KeyError,TypeError) as e:
   assert not accepted,(label,'unexpected rejection',str(e));tests.append({'case':label,'expected':'reject','observed':'reject'})
  else:
   assert accepted,(label,'unexpected acceptance');tests.append({'case':label,'expected':'accept','observed':'accept'})
 def objects(shape='direct-single',n=1,extra=False):
  files=[{'path':f'/synthetic-ford-fixtures/file-{i}.json','bytes':100+i,'sha256':str(i+1)*64} for i in range(n)]
  rows=[]
  for i,f in enumerate(files):
   row={'operation':'create_library_file','status':'succeeded','path':'/'+P(f['path']).name,'file_id':'file_synthetic_'+str(i),'library_file_id':'libfile_synthetic_'+str(i),'file_name':P(f['path']).name,'current_version_number':i,'restored_from_version_number':None,'xattrs':[{'name':'user.library-file-version','value':str(i)}],'directory_id':'libdir_synthetic','mime_type':'application/json','library_artifact_type':'report','file_size_bytes':f['bytes']}
   if extra:row['artifact_type']='report'
   if shape=='direct-single':row['external_connectors_accessed']=False
   rows.append(row)
  request={'file':files[0]['path'],'library_artifact_type':'report'} if n==1 else {'files':[f['path'] for f in files],'library_artifact_type':'report'}
  body=rows[0] if shape=='direct-single' else {'results':rows,'warnings':[],'external_connectors_accessed':False}
  response={'content':[{'type':'text','text':'Action completed.'}],'structuredContent':body,'isError':False}
  return request,response,files
 def check(shape,objects,edit=None):
  request,response,files=copy.deepcopy(objects)
  if edit:edit(request,response,files)
  body=response['structuredContent'];rows=[body] if shape=='direct-single' else body['results']
  qr=(json.dumps(request,sort_keys=True)+'\n').encode();rr=(json.dumps(response,sort_keys=True)+'\n').encode()
  spec={'rawRequest':{'path':'/synthetic/request.json',**u.bp(qr)},'rawResponse':{'path':'/synthetic/response.json',**u.bp(rr)},'shape':shape,'expectedRequest':copy.deepcopy(request),'expectedResults':copy.deepcopy(rows),'files':files}
  before=(copy.deepcopy(request),copy.deepcopy(response),qr,rr);view=adapter.response_view(spec,qr,rr)
  assert (request,response,qr,rr)==before and view['structuredContent']['results']==rows
  return view
 for label,shape,n,extra in [('direct-single','direct-single',1,False),('direct optional artifact_type coexistence','direct-single',1,True),('batch singleton','batch',1,False),('multirow batch','batch',3,False),('multirow batch optional artifact_type coexistence','batch',3,True)]:run(label,lambda shape=shape,n=n,extra=extra:check(shape,objects(shape,n,extra)),True)
 direct=objects();batch=objects('batch',2)
 def rowedit(key,value):return lambda q,d,f:d['structuredContent'].__setitem__(key,value)
 for label,edit in [
  ('wrong returned xattr',rowedit('xattrs',[{'name':'user.library-file-id','value':'invented'}])),
  ('wrong version attribute',rowedit('xattrs',[{'name':'user.library-file-version','value':'19'}])),
  ('wrong filename',rowedit('file_name','other.json')),
  ('wrong provider absolute name',rowedit('path','/other.json')),
  ('wrong bytes',rowedit('file_size_bytes',101)),
  ('failed row',rowedit('status','failed')),
  ('boolean version',rowedit('current_version_number',True)),
  ('unreviewed extra field',rowedit('unexpected','value')),
  ('missing row field',lambda q,d,f:d['structuredContent'].pop('mime_type')),
  ('isError true',lambda q,d,f:d.__setitem__('isError',True)),
  ('direct external connector true',rowedit('external_connectors_accessed',True)),
  ('ambiguous request',lambda q,d,f:q.__setitem__('files',[q['file']])),
  ('artifact_type is not official request argument',lambda q,d,f:q.__setitem__('artifact_type','report')),
 ]:run(label,lambda edit=edit:check('direct-single',direct,edit),False)
 for label,edit in [
  ('duplicate library IDs',lambda q,d,f:d['structuredContent']['results'][1].__setitem__('library_file_id',d['structuredContent']['results'][0]['library_file_id'])),
  ('duplicate file IDs',lambda q,d,f:d['structuredContent']['results'][1].__setitem__('file_id',d['structuredContent']['results'][0]['file_id'])),
  ('partial success',lambda q,d,f:d['structuredContent']['results'][1].__setitem__('status','failed')),
  ('missing row',lambda q,d,f:d['structuredContent']['results'].pop()),
  ('extra row',lambda q,d,f:d['structuredContent']['results'].append(copy.deepcopy(d['structuredContent']['results'][0]))),
  ('batch warnings',lambda q,d,f:d['structuredContent'].__setitem__('warnings',['partial'])),
  ('duplicate requested path',lambda q,d,f:q['files'].__setitem__(1,q['files'][0])),
 ]:run(label,lambda edit=edit:check('batch',batch,edit),False)
 # Exact per-function AST assembly and compile only; producer/checker phase namespaces are never executed.
 for ownkey,basekey,replacements,root_edits in [('producer','priorProducer',{'base':'ford_base','denied':'ford_denied','supplements':'ford_supplements'},[("from nissan_capture_adapter_v2 import C,B,R,capture_module,load_reference","from ford_capture_adapter_v1 import C,B,R,capture_module,load_reference",1)]),('checker','priorChecker',{'inherited':'ford_inherited','supplement_members':'ford_supplement_members'},[])]:
  own=ast.parse(u.read_exact(PINS[ownkey]));functions={n.name:n for n in own.body if isinstance(n,ast.FunctionDef)};assign={n.targets[0].id:n.value for n in own.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
  tree=u.assembly(PINS[basekey],ast.literal_eval(assign['EDITS']),{k:functions[v] for k,v in replacements.items()},root_edits)
  if ownkey=='checker':
   rfunctions={n.name:n for n in ast.parse(u.read_exact(PINS['replay'])).body if isinstance(n,ast.FunctionDef)};rfunctions['ford_supplement_members'].name='independent_replay_supplement_members';tree.body.extend([rfunctions['ford_supplement_members'],rfunctions['ford_inherited_accounting']]);ast.fix_missing_locations(tree)
  run(ownkey+' exact anchored AST compiles without execution',lambda tree=tree:compile(tree,PINS[basekey]['path'],'exec'),True)
 # Extract the actual nested independent acceptance wrapper; mock only prior full checks and sealed response access.
 checker=ast.parse(u.read_exact(PINS['checker']));build=next(n for n in checker.body if isinstance(n,ast.FunctionDef) and n.name=='build');acceptance=next(n for n in build.body if isinstance(n,ast.FunctionDef) and n.name=='acceptance')
 ts='2026-10-16T00:33:48.848016+00:00';response={'isError':False,'structuredContent':{'created_at':ts}};current={'acceptedAt':ts}
 def at(obj,keys):
  for key in keys:obj=obj[key]
  return obj
 m=types.SimpleNamespace(ck=u.ck,load=lambda _:copy.deepcopy(response),at=at);ns={'m':m,'original_acceptance':lambda *args:copy.deepcopy(current)};exec(compile(ast.fix_missing_locations(ast.Module(body=[acceptance],type_ignores=[])),PINS['checker']['path'],'exec'),ns)
 evidence={'response':{},'responseTimestampPath':['structuredContent','created_at']}
 run('verbatim accepted timestamp',lambda:ns['acceptance']({},[],evidence),True)
 current['acceptedAt']=ts.replace('+00:00','Z');run('equivalent Z timestamp respelling rejected',lambda:ns['acceptance']({},[],evidence),False)
 current['acceptedAt']='2026-10-16T00:33:48.8480160+00:00';run('equivalent fractional timestamp respelling rejected',lambda:ns['acceptance']({},[],evidence),False)
 current['acceptedAt']=ts;response['isError']=True;run('error send envelope rejected',lambda:ns['acceptance']({},[],evidence),False)
 result={'schemaVersion':1,'result':'PASS_FORD_DELIVERY_ADAPTER_PURE_TESTS','testScript':u.pin(__file__),'contract':u.pin(args.contract),'review':u.pin(args.review),'codePins':PINS,'cases':tests,'caseCount':len(tests),'producerOrCheckerPhaseExecuted':False,'archiveSourceResearchSeedPayloadReads':0,'nativeOperations':0,'xattrsReadOrWritten':0,'syntheticFixtureFilesCreated':0,'nativeByteReadbackVerified':False}
 target=P(next(iter(outputs)));raw=(json.dumps(result,indent=2)+'\n').encode();fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o444)
 with os.fdopen(fd,'wb') as f:f.write(raw)
 print(json.dumps({'result':result['result'],'cases':len(tests),'output':u.pin(target)}))
if __name__=='__main__':main()
