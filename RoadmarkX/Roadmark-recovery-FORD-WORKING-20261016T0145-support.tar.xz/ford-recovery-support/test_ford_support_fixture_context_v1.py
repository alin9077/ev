#!/usr/bin/env python3
"""Focused exact fixture context tests using only pinned existing code bytes; no new literal."""
import argparse,ast,collections,copy,hashlib,json,pathlib,sys,types
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent
ADAPTER={'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_support_adapter_v3.py', 'bytes': 14182, 'sha256': '63b551dd2a72982cea874134b349a233f5f32c5900f734fd718a857dbd45f180'}
UTILITY={'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_delivery_sealed_runtime_v2.py', 'bytes': 4506, 'sha256': '137c53c4d5e01a4c708aaa61ccd3c425ab3f53b7ef0bf8a8d153767f094b4d1f'}
EXTENSION={'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_support_fixture_context_v1.py', 'bytes': 3524, 'sha256': '7a2d89ca5916c5934e826d5bd725c93e322422a1b8a4333a8fbf299ee644fd51'}
FIXTURE={'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/test_ford_support_adapter_v1.py', 'bytes': 8021, 'sha256': 'd80f87017fd3b74a7a4343da5d57a41c01855d1eb4a7877d0edba1eb7f676ca5'}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['pure-tests']);ap.add_argument('--contract',required=True);ap.add_argument('--contract-sha256',required=True);ap.add_argument('--review',required=True);ap.add_argument('--review-sha256',required=True);args=ap.parse_args()
 p=P(UTILITY['path']);before=p.stat();raw=p.read_bytes();after=p.stat();assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns) and not any(q.is_symlink() for q in (p,*p.parents)) and {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}=={k:UTILITY[k] for k in ('bytes','sha256')};u=types.ModuleType('ford_fixture_test_runtime');u.__file__=str(p);exec(compile(raw,str(p),'exec'),u.__dict__)
 c,metadata,payload,outputs=u.runtime(args,__file__,'SUPPORT_FIXTURE_PURE_TEST');u.ck(not payload and outputs=={c['testOutput']},'code-only exact test scope')
 for r in (ADAPTER,EXTENSION,FIXTURE,UTILITY):u.ck(metadata[r['path']]==r,'code-only input pin')
 m=u.module(ast.parse(u.read_exact(ADAPTER)),ADAPTER['path'],'ford_fixture_test_subject');classifier=m.classifier_module(u);extension=u.module(ast.parse(u.read_exact(EXTENSION)),EXTENSION['path'],'ford_fixture_test_context');data=u.read_exact(FIXTURE);target=extension.TARGET
 tree=ast.parse(data);node=next(n for n in ast.walk(tree) if isinstance(n,ast.Constant) and isinstance(n.value,bytes) and n.lineno==26 and n.col_offset==121)
 finding={'header':json.loads(node.value[:-1]),'kind':'synthetic-code-only-finding','valueLength':0};row={**copy.deepcopy(target),'exactFinding':finding,'byteStart':target['keyLiteralByteStart'],'byteEndExclusive':target['keyLiteralByteEndExclusive'],'matchedSyntaxSHA256':target['keyLiteralSHA256']};name=row['member']
 record={'member':name,'filePin':row['filePin'],'finding':finding,'classification':row['classification']};doc={'exactSupportCodeClassifications':[row],'expectedClassifiedRecords':[record]};counts=collections.Counter()
 def run(candidates=None,bytes_value=data,member=name,d=doc):return classifier.classify_exact([finding] if candidates is None else candidates,bytes_value,member,d)
 u.ck(run()==([], [record]),'exact existing fixture accepted');counts['exact_existing_fixture']+=1
 def reject(label,fn):
  try:fn()
  except (AssertionError,ValueError,KeyError,IndexError):counts[label]+=1
  else:raise AssertionError('mutation accepted: '+label)
 reject('missing_finding',lambda:run([]));reject('duplicate_finding',lambda:run([finding,finding]));reject('changed_finding',lambda:run([dict(finding,valueLength=1)]));reject('changed_bytes',lambda:run(bytes_value=data+b' '))
 extra={'kind':'unreviewed-extra'};u.ck(run([finding,extra])==([extra],[record]),'extra remains blocking');counts['extra_blocking']+=1
 u.ck(run(member='ford-recovery-support/another-test.py')==([finding],[]),'unlisted member remains blocking');counts['unlisted_blocking']+=1
 for key in target:
  if key=='member':continue
  changed=copy.deepcopy(doc);value=changed['exactSupportCodeClassifications'][0][key]
  changed['exactSupportCodeClassifications'][0][key]=(value+1 if type(value) is int else dict(value,sha256='0'*64) if isinstance(value,dict) else value+'-changed')
  reject('changed_target_'+key,lambda:run(d=changed))
 changed=copy.deepcopy(doc);changed['exactSupportCodeClassifications'][0]['member']='ford-recovery-support/another-test.py';changed['expectedClassifiedRecords'][0]['member']='ford-recovery-support/another-test.py';reject('other_member_same_bytes',lambda:run(member='ford-recovery-support/another-test.py',d=changed))
 changed=copy.deepcopy(doc);newdata=data+b' ';fp=u.bp(newdata);changed['exactSupportCodeClassifications'][0]['filePin']=fp;changed['expectedClassifiedRecords'][0]['filePin']=fp;reject('repinned_changed_whole_file',lambda:run(bytes_value=newdata,d=changed))
 changed=copy.deepcopy(doc);changed['exactSupportCodeClassifications'][0]['matchedSyntaxSHA256']='0'*64;reject('changed_raw_finding_span',lambda:run(d=changed))
 changed=copy.deepcopy(doc);changed['expectedClassifiedRecords']*=2;reject('duplicate_expected_record',lambda:run(d=changed))
 changed=copy.deepcopy(doc);changed['expectedClassifiedRecords']=[];reject('missing_expected_record',lambda:run(d=changed))
 # Target metadata and code-only fixture are not an actual raw finding or grant.
 result={'result':'PASS_EXACT_FORD_SUPPORT_FIXTURE_CONTEXT_TESTS','adapter':ADAPTER,'extension':EXTENSION,'fixtureCode':FIXTURE,'testScript':u.pin(__file__),'cases':dict(counts),'totalCases':sum(counts.values()),'scope':{'existingCodeFixtureOnly':True,'actualPatternFindingInvented':False,'classificationOrRootGrantCreated':False,'configureCalled':False,'scannerRuns':False,'seedReads':False,'archiveReads':False,'sourcePayloadReads':False,'fixtureWrites':False,'nativeByteReadbackVerified':False}}
 with P(c['testOutput']).open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({'result':result['result'],'output':u.pin(c['testOutput']),'cases':result['totalCases']}))
if __name__=='__main__':main()
