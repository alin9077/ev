#!/usr/bin/env python3
"""Ford document producer, exact Nissan v3 reference with finite separately reviewed runtime inputs."""
import argparse,ast,hashlib,pathlib,stat,sys,types
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent;PREV=C.parent/'nissan-working-20261015T2220'
UTILITY={'path':str(C/'ford_delivery_sealed_runtime_v2.py'),'bytes':4506,'sha256':'137c53c4d5e01a4c708aaa61ccd3c425ab3f53b7ef0bf8a8d153767f094b4d1f'}
def utility():
 p=P(UTILITY['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in (p,*p.parents));b=p.read_bytes();t=p.lstat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns,t.st_ctime_ns) and {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}=={k:UTILITY[k] for k in ('bytes','sha256')};m=types.ModuleType('ford_delivery_sealed_runtime');m.__file__=str(p);exec(compile(b,str(p),'exec'),m.__dict__);return m
BASE={'path':str(PREV/'nissan_delivery_v3.py'),'bytes':16490,'sha256':'e65fd17136f06032dced858053d61ad7365fca47acd5a969b351e37e6196857f'}
EDITS={'qualify': [['NISSAN-DELIVERY-CONTRACT-v3.json', 'FORD-DELIVERY-ADAPTER-CONTRACT-v1.json', 1]], 'normalize': [['NISSAN-DELIVERY-CONTRACT-v3.json', 'FORD-DELIVERY-ADAPTER-CONTRACT-v1.json', 1], ['currentNissanMaterializationAttempts', 'currentFordMaterializationAttempts', 1]], 'docpaths': [['NISSAN-WORKING-', 'FORD-WORKING-', 3], ['Roadmark-NISSAN-M1-UPDATE-', 'Roadmark-FORD-M1-UPDATE-', 1]], 'docs': [['INDEPENDENT-NISSAN-RECOVERY-VERIFICATION-v1.json', 'INDEPENDENT-FORD-RECOVERY-VERIFICATION-v1.json', 2], ['INDEPENDENT-NISSAN-REFERENCE-CLOSURE-v2.json', 'INDEPENDENT-FORD-REFERENCE-CLOSURE-v2.json', 3], ['PASS_INDEPENDENT_NISSAN_FRESH_RECOVERY', 'PASS_INDEPENDENT_FORD_FRESH_RECOVERY', 1], ['Roadmark Nissan31 working recovery', 'Roadmark Ford32 working recovery', 2], ["'label':'Renault30'", "'label':'Nissan31'", 1], ['SAFETY-SAVE-PLAN-v3.json', 'SAFETY-SAVE-PLAN-v1.json', 1], ['The standalone Nissan source replaces the Renault source', 'The standalone Ford source replaces the Nissan source', 1], ['contains703 project files', 'contains706 project files', 1], ['The two historical delivery-only artifacts', 'The three historical delivery-only artifacts', 1], ['docs/NISSAN_M1_UPDATE.md', 'docs/FORD_M1_UPDATE.md', 1]], 'active': [['NISSAN-WORKING-', 'FORD-WORKING-', 1], ['INDEPENDENT-NISSAN-RECOVERY-VERIFICATION-v1.json', 'INDEPENDENT-FORD-RECOVERY-VERIFICATION-v1.json', 1], ['INDEPENDENT-NISSAN-DOCUMENT-CHECK-v1.json', 'INDEPENDENT-FORD-DOCUMENT-CHECK-v1.json', 1], ['PASS_INDEPENDENT_NISSAN_DOCUMENTS', 'PASS_INDEPENDENT_FORD_DOCUMENTS', 1], ['currentNissanNormalReportOutcome', 'currentFordNormalReportOutcome', 1], ['currentNissanSavedComparatorOutcome', 'currentFordSavedComparatorOutcome', 1], ["B/'FINAL-RENAULT-UPLOAD-RECEIPTS.json'", "PREV/'FINAL-NISSAN-UPLOAD-RECEIPTS.json'", 1], ["B/'INDEPENDENT-RENAULT-TERMINAL-CLOSURE-v1.json'", "PREV/'INDEPENDENT-NISSAN-TERMINAL-CLOSURE-v1.json'", 1], ["'archiveReuse':141", "'archiveReuse':p['baseArchivesReused']", 1]], 'final': [['NISSAN-WORKING-', 'FORD-WORKING-', 2], ['Roadmark-NISSAN-M1-UPDATE-', 'Roadmark-FORD-M1-UPDATE-', 1], ['INDEPENDENT-NISSAN-RECOVERY-VERIFICATION-v1.json', 'INDEPENDENT-FORD-RECOVERY-VERIFICATION-v1.json', 1], ['INDEPENDENT-NISSAN-DOCUMENT-CHECK-v1.json', 'INDEPENDENT-FORD-DOCUMENT-CHECK-v1.json', 1], ['INDEPENDENT-NISSAN-ACTIVE-CHECK-v1.json', 'INDEPENDENT-FORD-ACTIVE-CHECK-v1.json', 1], ['FINAL-NISSAN-UPLOAD-RECEIPTS.json', 'FINAL-FORD-UPLOAD-RECEIPTS.json', 1]]}

def ford_base():
    check(PREV/'FINAL-NISSAN-UPLOAD-RECEIPTS.json',BASE_FINAL);check(PREV/'INDEPENDENT-NISSAN-TERMINAL-CLOSURE-v1.json',BASE_TERMINAL)
    d=load(PREV/'FINAL-NISSAN-UPLOAD-RECEIPTS.json');t=load(PREV/'INDEPENDENT-NISSAN-TERMINAL-CLOSURE-v1.json');p=load(C/'SAFETY-SAVE-PLAN-v1.json');review=load(P(p['base']['terminalResultReview']['path']))
    assert d['nativeByteReadbackVerified'] is t['nativeByteReadbackVerified'] is False and d['counts']['archiveCount']==t['counts']['archiveCount']==145
    assert t['result']=='PASS_INDEPENDENT_NISSAN_TERMINAL' and t['inputPins'].count(ref(PREV/'FINAL-NISSAN-UPLOAD-RECEIPTS.json'))==1
    assert review['result']=='ACCEPTED_EXACT_NISSAN_QUALIFIED_TERMINAL_CLOSURE' and review['terminalClosure']==ref(PREV/'INDEPENDENT-NISSAN-TERMINAL-CLOSURE-v1.json') and review['finalReceipt']==ref(PREV/'FINAL-NISSAN-UPLOAD-RECEIPTS.json')
    return d

def ford_denied():
    d=base();e=d['blockedReadbackEvidence']['inheritedRenaultReadbackDenial'];check(P(e['request']['path']),e['request']);check(P(e['response']['path']),e['response']);raw=load(P(e['response']['path']))
    assert raw['isError'] is True and raw['structuredContent']['error_code']=='FORBIDDEN' and '403' in raw['structuredContent']['error'] and 'scope_violation' in raw['structuredContent']['error']
    assert e['retries']==e['alternateReadRoutes']==0 and d['blockedReadbackEvidence']['deniedRouteRetried'] is False
    return {'inheritedRenaultReadbackDenial':e,'inheritedNissanFinalReceipt':ref(PREV/'FINAL-NISSAN-UPLOAD-RECEIPTS.json'),'inheritedNissanReadbackQualification':d['blockedReadbackEvidence'],'scope':'The historical denial was for the five Renault archive identities in its exact request. No Ford identity is claimed individually attempted or denied.','currentFordMaterializationAttempts':0,'currentFordAlternateReadRoutes':0,'deniedRouteRetried':False}

def ford_supplements():
    d=base();cfg=load(C/'FORD-REFERENCE-CONFIG-v1.json');old=d['referencedPriorDeliveryArtifactsOutsideRecovery'];closing=d['deliveryOnlyClosingArtifact']
    assert closing['outsideRecoveryArchiveSet'] is True and closing['unchangedRecoveryArchiveCount']==145 and closing['nativeByteReadbackVerified'] is False
    assert [x['identity'] for x in cfg['deliveryOnlySupplements']]==[old['verification']['identity'],old['correction'],closing['artifact']]
    return {'verification':old['verification'],'correction':old['correction'],'nissanClosing':closing,'exactConfiguration':ref(C/'FORD-REFERENCE-CONFIG-v1.json'),'outsideCurrentRecoveryArchiveSet':True,'notNewFordArchives':True,'nativeByteReadbackVerified':False}

def build():
 u=utility();own=ast.parse(P(__file__).read_bytes());funcs={n.name:n for n in own.body if isinstance(n,ast.FunctionDef)}
 replacements={name:funcs['ford_'+name] for name in ('base','denied','supplements')}
 tree=u.assembly(BASE,EDITS,replacements,[("from nissan_capture_adapter_v2 import C,B,R,capture_module,load_reference","from ford_capture_adapter_v1 import C,B,R,capture_module,load_reference",1)])
 m=u.module(tree,__file__,'ford_exact_nissan_delivery');m.PREV=PREV;m.DATE='20261016'
 m.BASE_FINAL={'bytes':49261,'sha256':'e6356c5af77521fb3d4492fdbd43832662947ccea89e84d7dd25e894e935f740'}
 m.BASE_TERMINAL={'bytes':142559,'sha256':'59a043f3a71c62f22bc0ecac95fabdad96f9b0375c39c4a3cad9fb1c59b3fffc'}
 m.NOTE='Local recovery replay passed. Library persistence is confirmed by server create receipts and matching local hashes. Native byte-readback remains unpassed after the inherited Library selected-folder 403 access boundary; no Ford readback request or alternative read route was attempted.'
 return u,m

def execute(mode,c,metadata,payload,outputs,response_module=None):
 u,m=build();original_pin=m.pin;original_check=m.check;original_identity=m.identity;original_dump=m.dump
 allowed={**metadata,**payload};written=set()
 def admitted(p):
  p=str(P(p));u.ck(p in allowed or (p in outputs and P(p).is_file()),'unsealed producer read: '+p);return p
 def pin(p):
  p=admitted(p);got=original_pin(P(p))
  if p in allowed:u.ck(got==u.sh(allowed[p]),'producer input hash differs')
  return got
 def check(p,r):
  p=admitted(p)
  if p in allowed:u.ck(u.sh(r)==u.sh(allowed[p]),'producer check differs from sealed role')
  return original_check(P(p),r)
 def load(p):
  p=admitted(p)
  if p in metadata:return u.json_exact(metadata[p])
  u.ck(p in written,'JSON cannot be loaded from payload role');return m.cap.load(P(p))
 def dump(p,d):
  p=str(P(p));u.ck(p in outputs and p not in written,'unexpected/duplicate producer output');original_dump(P(p),d);written.add(p)
 def require():
  d=load(C/'FORD-DELIVERY-ADAPTER-CONTRACT-v1.json');u.ck(d['result']=='ACCEPTED_EXACT_FORD_DELIVERY_ADAPTER' and d['helper']==u.pin(P(__file__).resolve()),'producer static exact authority')
  review=load(P(d['independentReview']['path']));u.ck(review['helper']==d['helper'] and review['result']=='ACCEPTED_EXACT_FORD_DELIVERY_ADAPTER','producer exact static review')
  u.ck(d['nativeByteReadbackVerified'] is False and d['currentMaterializeAttempts']==0,'producer native boundary');return m.ref(C/'FORD-DELIVERY-ADAPTER-CONTRACT-v1.json')
 m.pin=pin;m.check=check;m.identity=lambda p:original_identity(P(admitted(p)));m.load=load;m.dump=dump;m.require_contract=require
 oldloader=m.load_reference
 def loader(name,path,pin_spec,*args):
  admitted(path);n=oldloader(name,path,pin_spec,*args);n.load=load;n.check=check;n.pin=pin;n.identity=m.identity;n.dump=dump
  if mode.startswith('normalize-'):
   phase=mode.split('-',1)[1];spec=c['normalization'];rawload=n.load
   def viewed(p):
    if str(P(p))==spec['rawResponse']['path']:
     return response_module.response_view(spec,u.read_exact(metadata[spec['rawRequest']['path']]),u.read_exact(metadata[spec['rawResponse']['path']]))
    return rawload(p)
   n.load=viewed
  return n
 m.load_reference=loader
 if mode.startswith('normalize-'):u.ck(response_module is not None,'closing response adapter required');m.normalize(mode.split('-',1)[1])
 else:{'docs':m.docs,'active':m.active,'final':m.final}[mode]()
 # Markdown/JSONL use the pinned producer's exclusive-open implementation.
 u.ck(all(P(p).is_file() for p in outputs),'missing declared output')
 return {'mode':mode,'outputs':[u.pin(p) for p in sorted(outputs)],'nativeByteReadbackVerified':False}

def main():
 a=argparse.ArgumentParser();a.add_argument('mode',choices=['docs','active']);a.add_argument('--contract',required=True);a.add_argument('--contract-sha256',required=True);a.add_argument('--review',required=True);a.add_argument('--review-sha256',required=True);args=a.parse_args();u=utility();c,metadata,payload,outputs=u.runtime(args,__file__,'DOCUMENT_PRODUCTION');print(execute(args.mode,c,metadata,payload,outputs))
if __name__=='__main__':main()
