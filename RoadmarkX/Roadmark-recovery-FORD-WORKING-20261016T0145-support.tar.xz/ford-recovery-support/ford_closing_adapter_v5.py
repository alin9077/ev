#!/usr/bin/env python3
"""Sealed Ford single/batch create response view and closing dispatch.
Raw provider evidence is never rewritten. The exact Nissan v5 tuple validator is
loaded by pin; no Nissan correction-package or failed-shape phase is recreated.
"""
import argparse,ast,copy,hashlib,json,pathlib,stat,sys,types
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent;N=C.parent/'nissan-working-20261015T2220'
UTILITY={'path':str(C/'ford_delivery_sealed_runtime_v2.py'),'bytes':4506,'sha256':'137c53c4d5e01a4c708aaa61ccd3c425ab3f53b7ef0bf8a8d153767f094b4d1f'}
PRIOR={'path':str(N/'nissan_closing_adapter_v5.py'),'bytes':36401,'sha256':'8bc24997dfb2726c090c4a86538eaf8682ee6dd51a0639322fc7af48e4d245e0'}
PRODUCER={'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_delivery_adapter_v5.py', 'bytes': 10765, 'sha256': '6982e483aa400a0895123f7195cef23f01bf4b1fac326097d15ca3298b912c99'}
def utility():
 p=P(UTILITY['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in (p,*p.parents));b=p.read_bytes();t=p.lstat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns,t.st_ctime_ns) and {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}=={k:UTILITY[k] for k in ('bytes','sha256')};m=types.ModuleType('ford_closing_sealed_runtime');m.__file__=str(p);exec(compile(b,str(p),'exec'),m.__dict__);return m

def response_view(spec,request_raw,response_raw):
 u=utility();u.ck(u.bp(request_raw)==u.sh(spec['rawRequest']) and u.bp(response_raw)==u.sh(spec['rawResponse']),'exact raw create pins differ')
 q=json.loads(request_raw);d=json.loads(response_raw)
 u.ck(q==spec['expectedRequest'] and set(q)<= {'file','files','library_artifact_type','directory_id'},'exact reviewed request differs')
 u.ck(('files' in q)^('file' in q),'ambiguous create target')
 paths=q['files'] if 'files' in q else [q['file']]
 u.ck(isinstance(paths,list) and paths and all(isinstance(p,str) and P(p).is_absolute() for p in paths) and len(paths)==len(set(paths)),'unique absolute create targets required')
 u.ck(set(d)=={'content','structuredContent','isError'} and d['isError'] is False,'exact successful create envelope required')
 body=d['structuredContent'];shape=spec['shape']
 if shape=='direct-single':
  u.ck(len(paths)==1 and isinstance(body,dict) and 'results' not in body and body['external_connectors_accessed'] is False,'exact direct singleton required');rows=[body]
 elif shape=='batch':
  u.ck(isinstance(body,dict) and set(body)=={'results','warnings','external_connectors_accessed'} and body['warnings']==[] and body['external_connectors_accessed'] is False,'exact batch envelope required');rows=body['results']
 else:raise AssertionError('unreviewed response shape')
 u.ck(rows==spec['expectedResults'] and len(rows)==len(paths)==len(spec['files']),'exact reviewed successful tuple set differs')
 tree=ast.parse(u.read_exact(PRIOR));functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
 selected=ast.fix_missing_locations(ast.Module(body=[functions['ck'],functions['create_tuple']],type_ignores=[]));ns={};exec(compile(selected,PRIOR['path'],'exec'),ns)
 mandatory={'operation','status','path','file_id','library_file_id','file_name','current_version_number','restored_from_version_number','xattrs','directory_id','mime_type','file_size_bytes'}
 optional={'library_artifact_type','artifact_type'}
 for path,row,want in zip(paths,rows,spec['files']):
  u.ck(path==want['path'] and P(path).name==row['file_name'],'reviewed file order/name differs')
  expected_fields=mandatory|({'external_connectors_accessed'} if shape=='direct-single' else set())
  u.ck(expected_fields<=set(row)<=expected_fields|optional,'undocumented tuple field differs')
  pkg={'file':path,'filename':P(path).name,'bytes':want['bytes']}
  ns['ACTIVE_ROW']=copy.deepcopy(row) if shape=='direct-single' else {**row,'external_connectors_accessed':False}
  # Exact pinned v5 tuple semantics, with a finite in-memory singleton for each batch row.
  envelope=d if shape=='direct-single' else {**d,'structuredContent':{**body,'results':[row]}}
  ns['create_tuple']({'file':path},envelope,pkg,'direct-single' if shape=='direct-single' else 'batch-single',row)
 u.ck(len({r['library_file_id'] for r in rows})==len({r['file_id'] for r in rows})==len(rows),'duplicate native identity')
 # Preserve every raw direct row field, including provider-returned optional type/version metadata.
 return copy.deepcopy(d) if shape=='batch' else {**copy.deepcopy(d),'structuredContent':{'results':[copy.deepcopy(body)]}}

def main():
 a=argparse.ArgumentParser();a.add_argument('mode',choices=['normalize-archives','normalize-documents','normalize-active','final']);a.add_argument('--contract',required=True);a.add_argument('--contract-sha256',required=True);a.add_argument('--review',required=True);a.add_argument('--review-sha256',required=True);args=a.parse_args();u=utility();c,metadata,payload,outputs=u.runtime(args,__file__,'CLOSING')
 u.ck(c['inputs']['producer']==PRODUCER and metadata[PRODUCER['path']]==PRODUCER and metadata[PRIOR['path']]==PRIOR,'exact producer/closing reuse pins')
 grant=c['inputs']['rootPersistenceGrant'];u.ck(metadata[grant['path']]==grant,'root persistence grant not sealed');u.json_exact(grant)
 if args.mode=='normalize-archives':name,result='INDEPENDENT-FORD-RECOVERY-VERIFICATION-v1.json','PASS_INDEPENDENT_FORD_FRESH_RECOVERY'
 elif args.mode=='normalize-documents':name,result='INDEPENDENT-FORD-DOCUMENT-CHECK-v1.json','PASS_INDEPENDENT_FORD_DOCUMENTS'
 else:name,result='INDEPENDENT-FORD-ACTIVE-CHECK-v1.json','PASS_INDEPENDENT_FORD_ACTIVE'
 prerequisite=u.json_exact(metadata[str(C/name)]);u.ck(prerequisite['result']==result and prerequisite['nativeByteReadbackVerified'] is False,'required prior independent gate differs')
 if args.mode in ('normalize-active','final'):
  gate=u.json_exact(c['inputs']['activePrivacy']);u.ck(gate['status']=='clean' and not gate['findings'] and not gate['errors'],'active privacy gate required')
  accounting=u.json_exact(c['inputs']['accounting']);u.ck(accounting['status']=='EXPLICIT_STAGE_AND_TERMINAL_ACCOUNTING' and accounting['noSeedValuesReadByThisAccounting'] is True,'actual final accounting required')
 m=u.module(ast.parse(u.read_exact(PRODUCER)),PRODUCER['path'],'ford_closing_exact_producer')
 if args.mode.startswith('normalize-'):
  spec=c['normalization'];u.ck(spec['rawRequest']==metadata[spec['rawRequest']['path']] and spec['rawResponse']==metadata[spec['rawResponse']['path']],'normalization evidence not sealed')
  response_view(spec,u.read_exact(spec['rawRequest']),u.read_exact(spec['rawResponse']))
 print(m.execute(args.mode,c,metadata,payload,outputs,response_module=sys.modules[__name__]))
if __name__=='__main__':main()
