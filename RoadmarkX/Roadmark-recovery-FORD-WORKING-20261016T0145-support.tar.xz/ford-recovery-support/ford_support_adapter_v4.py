#!/usr/bin/env python3
"""Exact mixed Ford support adapter over pinned v3; no raw detector changes."""
import argparse,ast,hashlib,pathlib,stat,sys,types
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent
NEW_PINS={'runtime': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_delivery_sealed_runtime_v2.py', 'bytes': 4506, 'sha256': '137c53c4d5e01a4c708aaa61ccd3c425ab3f53b7ef0bf8a8d153767f094b4d1f'}, 'priorSupport': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_support_adapter_v3.py', 'bytes': 14182, 'sha256': '63b551dd2a72982cea874134b349a233f5f32c5900f734fd718a857dbd45f180'}, 'mixedAuthority': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_support_mixed_authority_v1.py', 'bytes': 5821, 'sha256': '4d83ca398f870ca704f95fbede159c0f7ae1780345ac2250206fda25777936ed'}, 'jsonContext': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_support_json_prose_context_v1.py', 'bytes': 2340, 'sha256': 'db97cec5332801962a12164c1b8b4f9804997e8d77ca56d9c6459c0fedfcb5e7'}}
EDITS={'run_privacy': [["d=classifications(u,c,table,a['memberFiles']);capture,cap,privacy=privacy_module(u,True);classifier=classifier_module(u)", "d=classifications(u,c,table,a['memberFiles']);capture,cap,privacy=privacy_module(u,True);classifier=classifier_module(u);json_context=mixed_module(u,'jsonContext')", 1], ["deepal=sys.modules['deepal_scan_additions_v2'];unchanged=deepal.code_context;members={r['member'] for r in d['exactSupportCodeClassifications']};seen=set();emitted=[];extra=[]", "deepal=sys.modules['deepal_scan_additions_v2'];unchanged=deepal.code_context;members={r['member'] for r in d['exactSupportCodeClassifications']};seen=set();emitted=[];extra=[];json_members={r['member'] for r in d['exactSupportJSONProseClassifications']};json_seen=set();json_emitted=[]", 1], ["  return blocked,inherited+current\n deepal.code_context=exact_context\n privacy.dump=classifier.dump_dispatch(privacy.dump,P(report),cap.pin(C/'SEED-PROVENANCE.json'),members,seen,emitted,extra,d)", "  blocked,prose=json_context.classify_exact(blocked,data,name,d['exactSupportJSONProseClassifications'])\n  if name in json_members:\n   u.ck(name not in json_seen,'approved JSON member repeated');json_seen.add(name);json_emitted.extend(prose)\n  return blocked,inherited+current\n deepal.code_context=exact_context\n original_dispatch=classifier.dump_dispatch(privacy.dump,P(report),cap.pin(C/'SEED-PROVENANCE.json'),members,seen,emitted,extra,d)\n def separate_json_dump(path,record):\n  if P(path)==P(report):\n   u.ck(json_seen==json_members and json_emitted==d['expectedJSONProseRecords'],'complete separate exact JSON report records')\n   u.ck('classifiedExactJSONProseCandidates' not in record,'JSON report field already present')\n   record['classifiedExactJSONProseCandidates']=list(json_emitted)\n  return original_dispatch(path,record)\n privacy.dump=separate_json_dump", 1]]}

def utility():
 r=NEW_PINS['runtime'];p=P(r['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in (p,*p.parents));b=p.read_bytes();t=p.lstat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns,t.st_ctime_ns) and {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}=={k:r[k] for k in ('bytes','sha256')};m=types.ModuleType('ford_mixed_support_loader');m.__file__=str(p);exec(compile(b,str(p),'exec'),m.__dict__);return m

def mixed_module(u,key):
 p=PINS[key];return u.module(ast.parse(u.read_exact(p)),p['path'],'ford_support_'+key)

def mixed_classifications(u,c,table,member_rows):
 roles=c['inputs'];d=metadata(u,table,roles['classification']);g=metadata(u,table,roles['classificationGrant']);review=metadata(u,table,roles['classificationReview']);raw,selection=raw_report(u,c,table)
 proposal=metadata(u,table,roles['approvedProposal']);initial_grant=metadata(u,table,roles['initialClassificationGrant']);initial_raw=metadata(u,table,roles['initialPatternReport'])
 authority=mixed_module(u,'mixedAuthority');authority.validate(d,g,review,raw,selection,proposal,initial_grant,initial_raw,roles)
 approved=d['exactSupportCodeClassifications']+d['exactSupportJSONProseClassifications'];names={r['path'] for r in member_rows}
 u.ck(len(names)==len(member_rows) and {r['member'] for r in approved}<=names,'single support archive must contain all five exact contexts')
 return d

def parse_cli(argv=None):
 ap=argparse.ArgumentParser(allow_abbrev=False);ap.add_argument('mode',choices=['patterns','package','privacy']);ap.add_argument('--contract',required=True);ap.add_argument('--contract-sha256',required=True);ap.add_argument('--review',required=True);ap.add_argument('--review-sha256',required=True);ap.add_argument('--archive');ap.add_argument('--report');return ap.parse_args(argv)

def check_cli(args,c):
 if args.mode=='privacy':
  if args.archive!=c['archive']['path'] or args.report!=c['privacyOutput']:raise ValueError('privacy literal archive/report differs from contract')
 else:
  if args.archive is not None or args.report is not None:raise ValueError('archive/report allowed only for privacy')

def support_main():
 args=parse_cli();u=utility();c,table,payload,outputs=u.runtime(args,__file__,'SUPPORT');check_cli(args,c)
 for r in PINS.values():u.ck(table.get(r['path'])==r,'support code pin missing from runtime metadata')
 u.ck(c['scope']['noLiveTreeTraversal'] is True and c['scope']['sourcePayloadReads'] is False and c['scope']['nativeReadback'] is False,'support scope')
 if args.mode!='privacy':u.ck(c['scope']['seedReads'] is False,'nonprivacy seed extraction/search scope')
 else:u.ck(c['scope']['seedReads']=='exact-inherited-in-memory-only','privacy seed scope')
 if args.mode=='patterns':
  setup=c['integrityOnlySetup'];u.ck(setup['hashPasses']==1 and setup['pinnedFiles']==45 and setup['privateAuditInputFiles']==10 and setup['seedExtractionReconstructionSearch'] is False,'raw pattern inherited integrity read disclosure')
  u.ck(setup['qualification'] in c['metadata'] and len(setup['exactPinnedFiles'])==45 and len(setup['exactPrivateAuditInputs'])==10,'finite integrity setup pin sets')
  actual=metadata(u,table,c['inputs']['inheritedIntegrityPins'])['pins'];u.ck(actual==setup['exactPinnedFiles'],'exact inherited45 integrity inputs')
  u.ck(all(x in actual for x in setup['exactPrivateAuditInputs']) and len({x['path'] for x in setup['exactPrivateAuditInputs']})==10,'exact private10 subset')
 {'patterns':run_patterns,'package':run_package,'privacy':run_privacy}[args.mode](u,c,table,payload,outputs)

def build():
 u=utility();own=ast.parse(P(__file__).read_bytes());functions={n.name:n for n in own.body if isinstance(n,ast.FunctionDef)}
 tree=u.assembly(NEW_PINS['priorSupport'],EDITS,{'classifications':functions['mixed_classifications'],'main':functions['support_main']})
 tree.body.extend(functions[n] for n in ('mixed_module','parse_cli','check_cli'));ast.fix_missing_locations(tree)
 m=u.module(tree,__file__,'ford_mixed_support_adapter');m.PINS={**m.PINS,**NEW_PINS};return m

def main():build().main()
if __name__=='__main__':main()
