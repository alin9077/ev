#!/usr/bin/env python3
"""Pure append authority mutations and exact AST assembly. Never invokes append main."""
import argparse,ast,collections,copy,hashlib,json,pathlib,sys,types
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent
ADAPTER={'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_support_append_adapter_v1.py', 'bytes': 9469, 'sha256': '4c4946ccfe6716a18ed652cb45e8bcefc8bfaf065f71e27240289617494dca63'}
UTILITY={'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_delivery_sealed_runtime_v2.py', 'bytes': 4506, 'sha256': '137c53c4d5e01a4c708aaa61ccd3c425ab3f53b7ef0bf8a8d153767f094b4d1f'}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['pure-tests']);ap.add_argument('--contract',required=True);ap.add_argument('--contract-sha256',required=True);ap.add_argument('--review',required=True);ap.add_argument('--review-sha256',required=True);args=ap.parse_args()
 p=P(UTILITY['path']);before=p.stat();raw=p.read_bytes();after=p.stat();assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns) and not any(q.is_symlink() for q in (p,*p.parents)) and {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}=={k:UTILITY[k] for k in ('bytes','sha256')};u=types.ModuleType('ford_append_test_runtime');u.__file__=str(p);exec(compile(raw,str(p),'exec'),u.__dict__)
 c,metadata,payload,outputs=u.runtime(args,__file__,'SUPPORT_APPEND_PURE_TEST');u.ck(not payload and outputs=={c['testOutput']} and metadata[ADAPTER['path']]==ADAPTER,'code-only test scope')
 m=u.module(ast.parse(u.read_exact(ADAPTER)),ADAPTER['path'],'ford_append_test_subject');compile(m.assembly(u),m.BASE['path'],'exec');counts=collections.Counter(exact_13_anchor_assembly_compile_only=1)
 def ref(name):return {'path':str(C/('synthetic-'+name+'.json')),'bytes':1,'sha256':'0'*64}
 roles={k:ref(k) for k in m.MANDATORY_ROLES};sr,rr,base=ref('selection'),ref('selection-review'),ref('inventory');selected={'lateMetadataRoles':roles,'otherExplicitRetention':[],'baseInventory':base};review={'lateMetadataRoles':roles,'otherExplicitRetention':[]};cfg={'inputs':{'selection':sr,'selectionReview':rr}};table={r['path']:r for r in roles.values()}
 inv={'command':['synthetic-only'],'childPid':123,'startedAt':'synthetic','addressSpaceLimitBytes':268435456,'wallLimitSeconds':600,'processSerializationEstablished':True};terminal={**inv,'exitCode':0,'timedOut':False}
 docs={'stageInvocation':inv,'stageTerminal':terminal,'patternInvocation':copy.deepcopy(inv),'patternTerminal':copy.deepcopy(terminal),'stageReview':{'result':'ACCEPTED_EXACT_FORD_SUPPORT_STAGING_RESULT','inventory':base,'invocation':roles['stageInvocation'],'terminal':roles['stageTerminal']},'patternReport':{'result':'REVIEW_REQUIRED','seedReadsPerformed':False},'patternReview':{'result':'ACCEPTED_EXACT_FORD_SUPPORT_PATTERN_REPORT','report':roles['patternReport'],'invocation':roles['patternInvocation'],'terminal':roles['patternTerminal']},'classification':{'result':'ACCEPTED_EXACT_FORD_SUPPORT_CODE_SYNTAX_CLASSIFICATION','rawPreflight':roles['patternReport']},'classificationGrant':{'result':'ROOT_APPROVED_EXACT_FORD_SUPPORT_SYNTAX','classification':roles['classification'],'additionalCandidatesApproved':False,'sourceOrStagedEditsApproved':False},'classificationReview':{'result':'ACCEPTED_EXACT_FORD_SUPPORT_CLASSIFICATION_AND_GRANT','classification':roles['classification'],'rootGrant':roles['classificationGrant']}}
 def run(s=selected,r=review,d=docs,t=table):
  # Synthetic metadata is resolved entirely in memory; no fixture path is opened.
  fake=types.SimpleNamespace(ck=u.ck,read_exact=lambda ref:b'',json_exact=lambda ref:d[next(k for k,p in roles.items() if p==ref)])
  return m.authority_check(fake,s,r,sr,rr,cfg,t)
 u.ck(run()==list(roles.values()),'synthetic finite baseline');counts['exact_authority_baseline']+=1
 def reject(label,fn):
  try:fn()
  except (AssertionError,ValueError,KeyError,IndexError,StopIteration):counts[label]+=1
  else:raise AssertionError('mutation accepted '+label)
 for role,field,value,label in [('stageTerminal','exitCode',1,'failed_stage'),('patternTerminal','exitCode',1,'failed_pattern'),('stageTerminal','timedOut',True,'timeout'),('stageInvocation','processSerializationEstablished',False,'no_serialization'),('patternTerminal','addressSpaceLimitBytes',536870912,'wrong_limit'),('stageReview','inventory',ref('wrong'),'wrong_stage_inventory'),('patternReview','report',ref('wrong'),'wrong_pattern_report'),('classification','rawPreflight',ref('wrong'),'wrong_raw_classification'),('classificationGrant','additionalCandidatesApproved',True,'broader_candidates'),('classificationGrant','sourceOrStagedEditsApproved',True,'source_edit_grant'),('classificationReview','rootGrant',ref('wrong'),'wrong_grant')]:
  changed=copy.deepcopy(docs);changed[role][field]=value;reject(label,lambda:run(d=changed))
 bad=copy.deepcopy(selected);bad['lateMetadataRoles'].pop('stageTerminal');reject('missing_role',lambda:run(s=bad))
 bad=copy.deepcopy(selected);bad['otherExplicitRetention']=[roles['stageTerminal']];reject('duplicate_retention',lambda:run(s=bad))
 bad=dict(table);bad.pop(roles['stageTerminal']['path']);reject('unsealed_metadata',lambda:run(t=bad))
 result={'result':'PASS_EXACT_FORD_SUPPORT_APPEND_CODE_ONLY_TESTS','adapter':ADAPTER,'testScript':u.pin(__file__),'cases':dict(counts),'totalCases':sum(counts.values()),'scope':{'syntheticInMemoryOnly':True,'appendMainCalled':False,'captureModuleCalled':False,'payloadReads':False,'seedReads':False,'archiveReads':False,'fixtureWrites':False,'nativeByteReadbackVerified':False}}
 with P(c['testOutput']).open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({'result':result['result'],'output':u.pin(c['testOutput']),'cases':result['totalCases']}))
if __name__=='__main__':main()
