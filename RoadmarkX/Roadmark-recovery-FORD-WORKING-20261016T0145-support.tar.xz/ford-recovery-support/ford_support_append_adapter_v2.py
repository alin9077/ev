#!/usr/bin/env python3
"""Finite code-only amendment route over pinned append v1; unchanged copy loops."""
import ast,hashlib,pathlib,stat,sys,types
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent
NEW_PINS={'runtime': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_delivery_sealed_runtime_v2.py', 'bytes': 4506, 'sha256': '137c53c4d5e01a4c708aaa61ccd3c425ab3f53b7ef0bf8a8d153767f094b4d1f'}, 'priorAppend': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_support_append_adapter_v1.py', 'bytes': 9469, 'sha256': '4c4946ccfe6716a18ed652cb45e8bcefc8bfaf065f71e27240289617494dca63'}, 'mixedAuthority': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_support_mixed_authority_v1.py', 'bytes': 5821, 'sha256': '4d83ca398f870ca704f95fbede159c0f7ae1780345ac2250206fda25777936ed'}}
FIXED={'baseInventory': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/SUPPORT-MEMBER-INVENTORY.json', 'bytes': 192236, 'sha256': 'dccecc401b72a554a4add69e9b2c3692db1f7748eb8b378c9959d2b3ccbcb992'}, 'amendmentProposal': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/FORD-SUPPORT-AND-DOWNSTREAM-AMENDMENT-PROPOSAL-v1.json', 'bytes': 62928, 'sha256': 'be041466b8af134f057fa6cc44e8c3f4f82f0b23e04e2ca547ed4ce6e80c9f41'}, 'amendmentScopeReview': {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/INDEPENDENT-FORD-SUPPORT-AND-DOWNSTREAM-AMENDMENT-SCOPE-REVIEW-v1.json', 'bytes': 17855, 'sha256': 'efdc883437f29d01d225a32be5b0fb8feec54201fc93c82f424e2192f50fd8db'}}
ROLES=('stageInvocation','stageTerminal','stageReview','patternReport','patternInvocation','patternTerminal','patternReview','approvedProposal','initialClassificationGrant','amendmentProposal','amendmentScopeReview')
CODE_ROLES=('supportAdapter','appendAdapter','mixedAuthority','jsonContext','archiveIdentity','replay','deliveryChecker','mixedTest','identityTest')

def utility():
 r=NEW_PINS['runtime'];p=P(r['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in (p,*p.parents));b=p.read_bytes();t=p.lstat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns,t.st_ctime_ns) and {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}=={k:r[k] for k in ('bytes','sha256')};m=types.ModuleType('ford_finite_append_loader');m.__file__=str(p);exec(compile(b,str(p),'exec'),m.__dict__);return m

def exact_additions(u,selected,review,table):
 required=selected['copyPins'];code_roles=selected['codeRoles'];extra_code=selected['additionalCodePins']
 u.ck(set(code_roles)==set(CODE_ROLES),'exact finite mandatory executable roles')
 code=list(code_roles.values())+extra_code
 u.ck(len({r['path'] for r in code})==len(code) and len({r['path'] for r in required})==len(required),'duplicate executable/retention pin')
 u.ck(review['copyPins']==required and review['codeRoles']==code_roles and review['additionalCodePins']==extra_code,'reviewed exact additions differ')
 u.ck(code_roles['appendAdapter']==u.pin(__file__) and code_roles['mixedAuthority']==NEW_PINS['mixedAuthority'],'active append/authority must be retained exactly')
 u.ck([r for r in required if P(r['path']).suffix=='.py']==code,'complete ordered explicit executable allowlist')
 for r in required:
  p=P(r['path']);u.ck(table.get(str(p))==r and p.parent==C and p.suffix in ('.py','.json','.log','.txt'),'unsealed finite addition')
  u.ck(set(r)=={'path','bytes','sha256'},'exact addition pin shape')
 return required

def finite_authority_check(u,selected,review,sr,rr,c,table):
 u.ck(c['inputs']['selection']==sr and c['inputs']['selectionReview']==rr,'append exact selection authority')
 u.ck(selected['baseInventory']==c['inputs']['baseInventory']==FIXED['baseInventory'] and c['baseMemberCount']==350,'exact immutable350 base')
 for r in NEW_PINS.values():u.ck(table.get(r['path'])==r,'append helper dependency not sealed')
 roles=selected['prerequisiteRoles'];u.ck(set(roles)==set(ROLES) and review['prerequisiteRoles']==roles,'exact append prerequisite roles')
 for r in roles.values():u.ck(table.get(r['path'])==r and P(r['path']).parent==C and P(r['path']).suffix=='.json','finite prerequisite metadata')
 d={k:u.json_exact(r) for k,r in roles.items()}
 for key in ('amendmentProposal','amendmentScopeReview'):u.ck(roles[key]==FIXED[key],'exact accepted amendment scope pin')
 u.ck(d['amendmentScopeReview']['result']=='ACCEPTED_EXACT_FORD_SUPPORT_AND_DOWNSTREAM_AMENDMENT_SCOPE' and d['amendmentScopeReview']['proposal']==roles['amendmentProposal'],'independent amendment scope')
 bounded_pair(u,d['stageInvocation'],d['stageTerminal']);bounded_pair(u,d['patternInvocation'],d['patternTerminal'])
 u.ck(d['stageReview']['result']=='ACCEPTED_EXACT_FORD_SUPPORT_STAGING_RESULT' and d['stageReview']['inventory']==selected['baseInventory'] and d['stageReview']['invocation']==roles['stageInvocation'] and d['stageReview']['terminal']==roles['stageTerminal'],'actual original stage authority')
 u.ck(d['patternReview']['result']=='ACCEPTED_EXACT_FORD_SUPPORT_PATTERN_REPORT' and d['patternReview']['report']==roles['patternReport'] and d['patternReview']['invocation']==roles['patternInvocation'] and d['patternReview']['terminal']==roles['patternTerminal'],'actual original pattern authority')
 p=NEW_PINS['mixedAuthority'];authority=u.module(ast.parse(u.read_exact(p)),p['path'],'ford_append_initial_semantic_authority')
 for key in ('approvedProposal','initialClassificationGrant'):u.ck(roles[key]==authority.FIXED_PINS[key],'initial semantic pin')
 u.ck(roles['patternReport']==authority.FIXED_PINS['initialPatternReport'],'initial raw report pin')
 authority.expected(d['approvedProposal'],d['initialClassificationGrant'],d['patternReport'])
 u.ck(d['patternReport']['filesInspected']==350 and d['patternReport']['seedReadsPerformed'] is False,'initial350 raw scope')
 # Prerequisites authorize only the initial five semantic contexts. They are
 # not fabricated final classification records and need not be appended.
 return exact_additions(u,selected,review,table)

def build():
 u=utility();own=ast.parse(P(__file__).read_bytes());f={n.name:n for n in own.body if isinstance(n,ast.FunctionDef)}
 tree=u.assembly(NEW_PINS['priorAppend'],{}, {'authority_check':f['finite_authority_check']});tree.body.append(f['exact_additions']);ast.fix_missing_locations(tree)
 m=u.module(tree,__file__,'ford_finite_code_append');m.NEW_PINS=NEW_PINS;m.FIXED=FIXED;m.ROLES=ROLES;m.CODE_ROLES=CODE_ROLES;return m

def main():build().main()
if __name__=='__main__':main()
