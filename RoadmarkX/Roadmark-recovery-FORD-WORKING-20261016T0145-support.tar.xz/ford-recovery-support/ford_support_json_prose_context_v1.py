#!/usr/bin/env python3
"""Four exact JSON review-prose contexts only; raw detectors remain unchanged."""
import collections,hashlib,json
ROWS_CANONICAL_SHA256='7f1953ec8e14f743cdcbc3fc60fe9b097c9b196bf3256156cce77ab2682041a9'

def ck(ok,why):
 if not ok:raise ValueError(why)
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'))
def bp(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def unique_object(pairs):
 out={}
 for k,v in pairs:
  ck(k not in out,'duplicate JSON object key');out[k]=v
 return out

def classify_exact(candidates,data,name,rows):
 ck(hashlib.sha256(canon(rows).encode()).hexdigest()==ROWS_CANONICAL_SHA256,'exact four JSON context rows changed')
 matches=[r for r in rows if r['member']==name]
 if not matches:return candidates,[]
 ck(len(matches)==1,'duplicate approved JSON member');r=matches[0]
 ck(bp(data)==r['filePin'],'exact approved JSON whole file changed')
 doc=json.loads(data.decode('utf8'),object_pairs_hook=unique_object)
 ck(isinstance(doc,dict) and r['topLevelOnly'] is True and r['allObjectDuplicateKeysRejected'] is True,'top-level exact review JSON required')
 key=r['exactFinding']['header'];ck(r['jsonPointer']=='/'+key and r['exactFinding']['location']=={'pointer':r['jsonPointer']},'exact top-level JSON pointer')
 ck(type(doc.get(key)) is str and doc[key]==r['expectedDecodedReviewScopeProse'] and len(doc[key])==r['decodedValueLength'] and r['decodedValueType']=='str','exact decoded review prose')
 ck(hashlib.sha256(doc[key].encode()).hexdigest()==r['decodedValueUTF8SHA256'],'decoded prose identity')
 ks,ke,vs,ve=(r[k] for k in ('keyTokenByteStart','keyTokenByteEndExclusive','valueTokenByteStart','valueTokenByteEndExclusive'))
 ck(all(type(x) is int for x in (ks,ke,vs,ve)) and 0<=ks<ke<vs<ve<=len(data),'exact JSON spans')
 ck(hashlib.sha256(data[ks:ke]).hexdigest()==r['keyTokenSHA256'] and hashlib.sha256(data[vs:ve]).hexdigest()==r['valueTokenSHA256'],'exact JSON token identities')
 ck(json.loads(data[ks:ke])==key and json.loads(data[vs:ve])==doc[key] and data[ke:vs].strip()==b':','exact adjacent JSON key/value tokens')
 ck(candidates==[r['exactFinding']],'missing/duplicate/changed/additional JSON candidate')
 record={'member':name,'filePin':r['filePin'],'finding':r['exactFinding'],'classification':r['classification']}
 return [],[record]
