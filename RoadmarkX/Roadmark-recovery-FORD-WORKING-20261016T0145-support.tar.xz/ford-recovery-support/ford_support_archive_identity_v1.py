#!/usr/bin/env python3
"""Pure exact-ten Ford support archive identity qualification; no filesystem or payload I/O.

Callers must separately seal the byte pins below. Whole decoded metadata is bound
again here by canonical SHA-256, including list order and every otherwise unused
field. Only the exact approved new/restoreOrder pairs receive qualification.
This module never supplies restore ordering and never changes input objects.
"""
import hashlib
import json

MAPPING_PIN = {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/SUPPORT-REUSE-MAPPING.json',
 'bytes': 103980,
 'sha256': '1500cfbc2df143f1119c58295fe36893323b9bf568a91c9922116593729a7310'}

BASE_MANIFEST_PIN = {'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/deliverables/Roadmark-RECOVERY-MANIFEST-NISSAN-WORKING-20261015.json',
 'bytes': 3351451,
 'sha256': '1fbd562420216dce4191d836ebb6db0063051ba5fabe98f115a4429818de9f91'}

MAPPING_CANONICAL_SHA256 = 'b93eb38ffdd581680b9bc96a7eb59769c14b1452df43347d8e6f4ac07f86924e'

BASE_MANIFEST_CANONICAL_SHA256 = 'b5976a28ba2cc77ffcde6d745c667a7cca151c7cd9bda594dd22938e89c14598'

IDENTITY_FIELDS = ('filename', 'bytes', 'sha256', 'library_file_id', 'file_id', 'version')

EXACT_EXCEPTIONS = ({'reuseIndex': 38,
  'exactReuseRowCanonicalSHA256': 'a4206941d54596531f6a16aaf706760cd05dfcb255af4011b782f6d93a46e4da',
  'exactCurrentBaseArchiveCanonicalSHA256': 'e8d2bafad89d49e1267432093fd15053d255ffbd7114cee6c3fe5f1ca66f8f4f',
  'historicalAnnotations': {'new': True, 'restoreOrder': 141},
  'currentBaseAnnotations': {'new': False, 'restoreOrder': 140}},
 {'reuseIndex': 42,
  'exactReuseRowCanonicalSHA256': 'a192b687e86348e8936d14816b871703dce0ca1924e22b2214d0348454823b1c',
  'exactCurrentBaseArchiveCanonicalSHA256': 'e8d2bafad89d49e1267432093fd15053d255ffbd7114cee6c3fe5f1ca66f8f4f',
  'historicalAnnotations': {'new': True, 'restoreOrder': 141},
  'currentBaseAnnotations': {'new': False, 'restoreOrder': 140}},
 {'reuseIndex': 47,
  'exactReuseRowCanonicalSHA256': '8adb8e8d2ac1632cee2a3fe4d6a1ab6a581d80a0cc9787bf9c27df6605fae271',
  'exactCurrentBaseArchiveCanonicalSHA256': 'e65e85ca17b39fdd83d7c9a26994fcd55ec076ba2a7886ff9ae61ea9da40c52f',
  'historicalAnnotations': {'new': True, 'restoreOrder': 142},
  'currentBaseAnnotations': {'new': False, 'restoreOrder': 141}},
 {'reuseIndex': 48,
  'exactReuseRowCanonicalSHA256': 'eefda5cefd58b2a99fc8df9f6bc7f5c1be29a348768e531b553228b417ee1afd',
  'exactCurrentBaseArchiveCanonicalSHA256': 'e8d2bafad89d49e1267432093fd15053d255ffbd7114cee6c3fe5f1ca66f8f4f',
  'historicalAnnotations': {'new': True, 'restoreOrder': 141},
  'currentBaseAnnotations': {'new': False, 'restoreOrder': 140}},
 {'reuseIndex': 49,
  'exactReuseRowCanonicalSHA256': '2d62fdb086a1e98529bc5b2d5212832bc3e9c8ac879a46da94b1bc0eeb804ff0',
  'exactCurrentBaseArchiveCanonicalSHA256': 'e8d2bafad89d49e1267432093fd15053d255ffbd7114cee6c3fe5f1ca66f8f4f',
  'historicalAnnotations': {'new': True, 'restoreOrder': 141},
  'currentBaseAnnotations': {'new': False, 'restoreOrder': 140}},
 {'reuseIndex': 52,
  'exactReuseRowCanonicalSHA256': '62bb2c22cc8de268b1a64a5a5de9f1c62f1ba67da66499f0310070048cfdc74a',
  'exactCurrentBaseArchiveCanonicalSHA256': 'e65e85ca17b39fdd83d7c9a26994fcd55ec076ba2a7886ff9ae61ea9da40c52f',
  'historicalAnnotations': {'new': True, 'restoreOrder': 142},
  'currentBaseAnnotations': {'new': False, 'restoreOrder': 141}},
 {'reuseIndex': 55,
  'exactReuseRowCanonicalSHA256': '2c486a1a6171aba237cc33c7a01be6d6720cbf9180fd7e299cdb0d5c406b9992',
  'exactCurrentBaseArchiveCanonicalSHA256': 'e8d2bafad89d49e1267432093fd15053d255ffbd7114cee6c3fe5f1ca66f8f4f',
  'historicalAnnotations': {'new': True, 'restoreOrder': 141},
  'currentBaseAnnotations': {'new': False, 'restoreOrder': 140}},
 {'reuseIndex': 56,
  'exactReuseRowCanonicalSHA256': 'd9610f4471950dda7fab86c9984f84d301cd6d6e2019ec79e65acc6ea97916ca',
  'exactCurrentBaseArchiveCanonicalSHA256': 'e8d2bafad89d49e1267432093fd15053d255ffbd7114cee6c3fe5f1ca66f8f4f',
  'historicalAnnotations': {'new': True, 'restoreOrder': 141},
  'currentBaseAnnotations': {'new': False, 'restoreOrder': 140}},
 {'reuseIndex': 57,
  'exactReuseRowCanonicalSHA256': 'ee5a0fe7b970e5aafc6a04e1e9ef66723bf6599a744a2290f07ad0083d6d070f',
  'exactCurrentBaseArchiveCanonicalSHA256': 'e8d2bafad89d49e1267432093fd15053d255ffbd7114cee6c3fe5f1ca66f8f4f',
  'historicalAnnotations': {'new': True, 'restoreOrder': 141},
  'currentBaseAnnotations': {'new': False, 'restoreOrder': 140}},
 {'reuseIndex': 60,
  'exactReuseRowCanonicalSHA256': '104d87d704bd72277600ab6f9eee260e12275e1e46c93901cdef14ffb206f0d4',
  'exactCurrentBaseArchiveCanonicalSHA256': 'e8d2bafad89d49e1267432093fd15053d255ffbd7114cee6c3fe5f1ca66f8f4f',
  'historicalAnnotations': {'new': True, 'restoreOrder': 141},
  'currentBaseAnnotations': {'new': False, 'restoreOrder': 140}})

def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)


def _digest(value):
    return hashlib.sha256(_canonical(value).encode('utf8')).hexdigest()


def _require(condition, message):
    if not condition:
        raise AssertionError(message)


def bind_support_reuse_identity(mapping, base_manifest, current_reused):
    """Validate all 69 rows/base145, then return an exact in-chain row predicate.

    The predicate accepts (complete_reuse_row, current_base_archive). Outside11
    are never accepted by the predicate; their existing verifier checks remain
    mandatory. Captured canonical strings prevent post-validation mutation from
    expanding the allowed row or current archive set.
    """
    _require(type(mapping) is dict and type(base_manifest) is dict, 'identity metadata objects required')
    _require(_digest(mapping) == MAPPING_CANONICAL_SHA256, 'entire fixed69 mapping changed')
    _require(_digest(base_manifest) == BASE_MANIFEST_CANONICAL_SHA256, 'entire current Nissan base manifest changed')
    _require(mapping['baseManifest'] == BASE_MANIFEST_PIN, 'mapping base byte authority changed')
    rows, archives = mapping['files'], base_manifest['archivesInRestoreOrder']
    _require(type(rows) is list and len(rows) == 69, 'exact69 mapping required')
    _require(len({_canonical(row) for row in rows}) == len({row['originalPath'] for row in rows}) == len({row['localRelativePath'] for row in rows}) == 69, 'duplicate mapping row or original path')
    _require(type(archives) is list and len(archives) == 145, 'exact145 base archives required')
    by_name = {archive['filename']: archive for archive in archives}
    _require(len(by_name) == 145 and [archive['restoreOrder'] for archive in archives] == list(range(1, 146)), 'base archive duplicate/order changed')
    expected_reused = [archive for archive in archives if archive['filename'] != base_manifest['source']['filename']]
    _require(type(current_reused) is list and len(expected_reused) == len(current_reused) == 144 and _canonical(current_reused) == _canonical(expected_reused), 'current reused144 identity/order changed')
    current = {archive['filename']: archive for archive in current_reused}
    exceptions = {row['reuseIndex']: row for row in EXACT_EXCEPTIONS}
    _require(len(exceptions) == 10 and tuple(exceptions) == (38, 42, 47, 48, 49, 52, 55, 56, 57, 60), 'fixed exact-ten exception indices changed')
    outside_count = ordinary_count = 0
    qualified = []
    allowed = {}
    for index, row in enumerate(rows):
        outside = row['outsideRecoveryArchiveSet']
        _require(type(outside) is bool, 'outside scope flag must be bool')
        historical = row['retainedArchive']
        if outside:
            outside_count += 1
            _require(index not in exceptions and historical['filename'] not in by_name, 'outside archive entered base or qualification')
            continue
        actual = current.get(historical['filename'])
        _require(actual is not None, 'in-chain archive absent from current reuse')
        _require(all(field in historical and field in actual and _canonical(historical[field]) == _canonical(actual[field]) for field in IDENTITY_FIELDS), 'six-field native identity differs')
        _require(set(historical) == set(actual), 'archive field set differs')
        differing = {key for key in historical if _canonical(historical[key]) != _canonical(actual[key])}
        if index in exceptions:
            approved = exceptions[index]
            _require(_digest(row) == approved['exactReuseRowCanonicalSHA256'] and _digest(actual) == approved['exactCurrentBaseArchiveCanonicalSHA256'], 'exact historical/current exception metadata differs')
            _require(differing == {'new', 'restoreOrder'}, 'only exact annotation pair may differ')
            _require(_canonical({key: historical[key] for key in ('new', 'restoreOrder')}) == _canonical(approved['historicalAnnotations']), 'historical annotation pair differs')
            _require(_canonical({key: actual[key] for key in ('new', 'restoreOrder')}) == _canonical(approved['currentBaseAnnotations']), 'current annotation pair differs')
            qualified.append(index)
        else:
            _require(not differing and _canonical(historical) == _canonical(actual), 'ordinary archive requires complete equality')
            ordinary_count += 1
        allowed[_canonical(row)] = _canonical(actual)
    _require(outside_count == 11 and ordinary_count == 48 and qualified == list(exceptions) and len(allowed) == 58, 'exact69 partition or exception membership changed')

    def exact_in_chain_identity(row, current_archive):
        if type(row) is not dict or type(current_archive) is not dict:
            return False
        return allowed.get(_canonical(row)) == _canonical(current_archive)

    return exact_in_chain_identity
