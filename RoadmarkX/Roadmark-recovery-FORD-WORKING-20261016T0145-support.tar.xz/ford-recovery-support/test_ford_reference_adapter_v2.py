#!/usr/bin/env python3
"""Pure Ford reference-loader and supplement-schema tests; no payload or seed opens."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

C = Path(__file__).resolve().parent
ADAPTER = C / 'ford_reference_adapter_v2.py'
EXPECTED = '9fab2f535a9b75e4b98cad8982b5f399d43031cd6f35c7e0b3af495857f34161'
raw = ADAPTER.read_bytes()
assert len(raw) == 8904 and hashlib.sha256(raw).hexdigest() == EXPECTED
spec = importlib.util.spec_from_file_location('ford_reference_tested', ADAPTER)
adapter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(adapter)
ns = adapter.load('76b08173191c7f3561001eef73f4f54d223bc86b9215badc03879a3f1ce37071')
assert ns['C'] == C
assert ns['OPTIONAL'][-1] == 'INDEPENDENT-FORD-REFERENCE-CLOSURE-v2.json'
assert ns['CONFIG']['path'] == str(C / 'FORD-REFERENCE-CONFIG-v1.json')
assert 'main' in ns and callable(ns['closure']) and callable(ns['restore'])

data, specs = {}, []
for number, schema in enumerate(('logical-path-originalPath', 'logical-path-originalPath', 'absolute-path-logical-member')):
    root = '/synthetic/no-files-read/' + str(number)
    inventory_path, package_path = root + '/inventory.json', root + '/package.json'
    inventory_pin = {'path': inventory_path, 'bytes': 10 + number, 'sha256': str(number + 1) * 64}
    file_pin = {'path': root + '/file.json', 'bytes': 20 + number, 'sha256': str(number + 4) * 64}
    def row(pin, member):
        if schema == 'logical-path-originalPath':
            return {'path': member, 'originalPath': pin['path'], 'bytes': pin['bytes'], 'sha256': pin['sha256']}
        return {'path': pin['path'], 'member': member, 'bytes': pin['bytes'], 'sha256': pin['sha256']}
    content = row(file_pin, 'supplement' + str(number) + '/file.json')
    inventory_member = row(inventory_pin, 'supplement' + str(number) + '/inventory.json')
    identity = {'filename': 'synthetic-' + str(number) + '.tar.xz', 'bytes': 100 + number, 'sha256': 'a' * 64}
    data[inventory_path] = {'files': [copy.deepcopy(content)]}
    data[package_path] = {**identity, 'outsideRecoveryArchiveSet': True,
                          'unchangedRecoveryArchiveCount': 142 if number < 2 else 145,
                          'memberCount': 2, 'members': [content, inventory_member]}
    specs.append({'identity': identity, 'package': {'path': package_path}, 'inventory': inventory_pin,
                  'rowSchema': schema, 'originalCoreArchiveCount': 142 if number < 2 else 145})

def run(current_specs=None, current_data=None):
    local = dict(ns)
    values = data if current_data is None else current_data
    local['read_json'] = lambda ref: copy.deepcopy(values[ref['path']])
    return adapter.supplement_map(local, {'deliveryOnlySupplements': specs if current_specs is None else current_specs}, {})

result = run()
assert len(result) == 6 and all(len(v) == 1 for v in result.values())
tests = ['exact_ast_transform_counts', 'canonical_current_namespace', 'three_artifacts_two_actual_row_schemas']

def constants(value):
    if hasattr(value, 'co_consts'):
        yield from constants(value.co_consts)
    elif isinstance(value, tuple):
        for item in value:
            yield from constants(item)
    else:
        yield value

closure_constants = list(constants(ns['closure'].__code__))
assert '/inheritedRecoveryMetadata' not in closure_constants
assert '/copyOnlySanitation' in closure_constants and '/inheritedBoundaries' in closure_constants
tests.append('only_two_valid_current_base_sanitation_pointers')

def reject(name, mutate):
    s, d = copy.deepcopy(specs), copy.deepcopy(data)
    mutate(s, d)
    try:
        run(s, d)
    except (ValueError, KeyError, TypeError):
        tests.append(name)
    else:
        raise AssertionError('Accepted negative case: ' + name)

reject('missing_artifact', lambda s, d: s.pop())
reject('duplicate_artifact', lambda s, d: s[1].update(identity=s[0]['identity']))
reject('unreviewed_row_schema', lambda s, d: s[0].update(rowSchema='generic'))
reject('wrong_original_core_count', lambda s, d: d[s[2]['package']['path']].update(unchangedRecoveryArchiveCount=142))
reject('missing_package_member', lambda s, d: d[s[0]['package']['path']]['members'].pop())
reject('duplicate_package_member', lambda s, d: d[s[0]['package']['path']]['members'].append(d[s[0]['package']['path']]['members'][0]))
reject('missing_inventory_member', lambda s, d: d[s[1]['inventory']['path']]['files'].clear())
reject('changed_inventory_hash', lambda s, d: s[2]['inventory'].update(sha256='f' * 64))
reject('unsafe_member', lambda s, d: d[s[2]['package']['path']]['members'][0].update(member='../escape'))
reject('different_original_path_attribution', lambda s, d: d[s[0]['inventory']['path']]['files'][0].update(originalPath='/synthetic/different.json'))

output = {'result': 'PASS_PURE_FORD_REFERENCE_ADAPTER_TESTS', 'testsPassed': len(tests), 'tests': tests,
          'adapter': {'path': str(ADAPTER), 'bytes': len(raw), 'sha256': EXPECTED},
          'helperCodeOnlyLoaded': True, 'targetContextOrClosureOrRestoreInvoked': False,
          'archiveSourceResearchOrSeedPayloadReads': 0, 'syntheticDataOnly': True}
p = C / 'FORD-REFERENCE-ADAPTER-PURE-TEST-RESULT-v2.json'
with p.open('x') as f:
    json.dump(output, f, indent=2)
    f.write('\n')
print(json.dumps({'result': output['result'], 'testsPassed': len(tests), 'output': str(p)}))
