#!/usr/bin/env python3
"""Finite noncircular Ford support append using exact Nissan v2 copy/integrity loops."""
import argparse,ast,hashlib,json,pathlib,stat,sys,types
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent
UTILITY={'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_delivery_sealed_runtime_v2.py', 'bytes': 4506, 'sha256': '137c53c4d5e01a4c708aaa61ccd3c425ab3f53b7ef0bf8a8d153767f094b4d1f'}
BASE={'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/append_nissan_support_v2.py', 'bytes': 4933, 'sha256': '40e854050a0da667b9ae2a2eb5789f98c54c41fb46a262154e8b9a29c391c428'}
CAPTURE={'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/ford-working-20261016T0145/ford_capture_adapter_v1.py', 'bytes': 2202, 'sha256': '0fccf034025e1550b4d2150681584464ac14ac6cdda03333fc75e44d79d0c74c'}
EDITS=[['from nissan_capture_adapter_v2 import capture_module', 'from ford_capture_adapter_v1 import capture_module', 1], ["C/'SUPPORT-ADDITIONS-SELECTION-v1.json'", 'APPEND_SELECTION', 1], ['EXACT_FINITE_NISSAN_SUPPORT_APPEND_SELECTION', 'EXACT_FINITE_FORD_SUPPORT_APPEND_SELECTION', 1], ['ACCEPTED_EXACT_NISSAN_SUPPORT_APPEND_SELECTION', 'ACCEPTED_EXACT_FORD_SUPPORT_APPEND_SELECTION', 1], ["    contract_pin=selected['privacyContract'];assert P(contract_pin['path'])==C/'NISSAN-SUPPORT-PRIVACY-CONTRACT-v1.json'\n    cap.check(P(contract_pin['path']),contract_pin);contract=cap.load(contract_pin['path'])\n    assert contract['status']=='INDEPENDENTLY_ACCEPTED_EXACT_NISSAN_SUPPORT_PRIVACY_ADAPTER'\n    cap.check(P(contract['review']['path']),contract['review']);adapter_review=cap.load(contract['review']['path'])\n    assert adapter_review['result']=='ACCEPTED_EXACT_NISSAN_SUPPORT_APPEND_PRIVACY_PACKAGE_ADAPTERS'\n    own=ref(P(__file__).resolve());assert contract['appendAdapter']==adapter_review['appendAdapter']==own\n    retention=contract['additionalRetention'];assert retention==adapter_review['additionalRetention'] and isinstance(retention,list)\n    assert all(set(r)=={'path','bytes','sha256'} and type(r['bytes']) is int and r['bytes']>=0 and isinstance(r['sha256'],str) and len(r['sha256'])==64 for r in retention)\n    required=[contract[k] for k in ('privacyAdapter','appendAdapter','packageAdapter','testAdapter','classification','rootGrant','review','tests')]+[contract_pin]+retention\n", '    required=ford_authorities(selected,review,sr,rr)\n', 1], ['235', 'BASE_COUNT', 4], ["'nissan-recovery-support/'", "'ford-recovery-support/'", 2], ['[sp.name,rp.name]', '[p.name for p,r in CONTROL_COPIES]', 1], ["C/'support-additions-staging-v1'", 'APPEND_STAGING', 1], ["C/'SUPPORT-MEMBER-INVENTORY-v2.json'", 'AMENDED_INVENTORY', 1], ["C/'SUPPORT-PATTERN-SELECTION-v2.json'", 'AMENDED_PATTERNS', 1], ['for p,refpin in ((sp,sr),(rp,rr)):', 'for p,refpin in CONTROL_COPIES:', 1], ["C/'support-staging-v1'", 'BASE_STAGING', 1]]
MANDATORY_ROLES=('stageInvocation','stageTerminal','stageReview','patternReport','patternInvocation','patternTerminal','patternReview','classification','classificationGrant','classificationReview')

def utility():
 r=UTILITY;p=P(r['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in (p,*p.parents));b=p.read_bytes();t=p.lstat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns,t.st_ctime_ns) and {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}=={k:r[k] for k in ('bytes','sha256')};m=types.ModuleType('ford_append_runtime');m.__file__=str(p);exec(compile(b,str(p),'exec'),m.__dict__);return m

def assembly(u):return u.assembly(BASE,{'main':EDITS})

def bounded_pair(u,inv,terminal):
 u.ck(inv['command']==terminal['command'] and inv['childPid']==terminal['childPid'] and inv['startedAt']==terminal['startedAt'] and terminal['exitCode']==0 and terminal['timedOut'] is False,'successful exact prerequisite invocation/terminal')
 u.ck(inv['addressSpaceLimitBytes']==terminal['addressSpaceLimitBytes']==268435456 and inv['wallLimitSeconds']==terminal['wallLimitSeconds']==600 and inv['processSerializationEstablished'] is True,'prerequisite serialization/bounds')

def authority_check(u,selected,review,sr,rr,c,table):
 u.ck(c['inputs']['selection']==sr and c['inputs']['selectionReview']==rr,'append exact selection authority')
 roles=selected['lateMetadataRoles'];u.ck(set(roles)==set(MANDATORY_ROLES),'finite mandatory late metadata roles')
 required=list(roles.values())+selected['otherExplicitRetention'];u.ck(len({r['path'] for r in required})==len(required),'duplicate late metadata identity')
 for r in required:
  u.ck(table.get(r['path'])==r and P(r['path']).parent==C and P(r['path']).suffix in ('.json','.log','.txt'),'finite current metadata retention only')
  u.read_exact(r)
 u.ck(review['lateMetadataRoles']==roles and review['otherExplicitRetention']==selected['otherExplicitRetention'],'reviewed append exact late scope')
 d={k:u.json_exact(r) for k,r in roles.items()};bounded_pair(u,d['stageInvocation'],d['stageTerminal']);bounded_pair(u,d['patternInvocation'],d['patternTerminal'])
 u.ck(d['stageReview']['result']=='ACCEPTED_EXACT_FORD_SUPPORT_STAGING_RESULT' and d['stageReview']['inventory']==selected['baseInventory'] and d['stageReview']['invocation']==roles['stageInvocation'] and d['stageReview']['terminal']==roles['stageTerminal'],'stage result authority')
 u.ck(d['patternReport']['result'] in ('NO_PATTERN_CANDIDATES','REVIEW_REQUIRED') and d['patternReport']['seedReadsPerformed'] is False,'actual raw pattern report')
 u.ck(d['patternReview']['result']=='ACCEPTED_EXACT_FORD_SUPPORT_PATTERN_REPORT' and d['patternReview']['report']==roles['patternReport'] and d['patternReview']['invocation']==roles['patternInvocation'] and d['patternReview']['terminal']==roles['patternTerminal'],'pattern result authority')
 u.ck(d['classification']['result']=='ACCEPTED_EXACT_FORD_SUPPORT_CODE_SYNTAX_CLASSIFICATION' and d['classification']['rawPreflight']==roles['patternReport'],'classification authority')
 u.ck(d['classificationGrant']['result']=='ROOT_APPROVED_EXACT_FORD_SUPPORT_SYNTAX' and d['classificationGrant']['classification']==roles['classification'] and d['classificationGrant']['additionalCandidatesApproved'] is False and d['classificationGrant']['sourceOrStagedEditsApproved'] is False,'literal-only grant')
 u.ck(d['classificationReview']['result']=='ACCEPTED_EXACT_FORD_SUPPORT_CLASSIFICATION_AND_GRANT' and d['classificationReview']['classification']==roles['classification'] and d['classificationReview']['rootGrant']==roles['classificationGrant'],'classification review authority')
 return required

def main():
 ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['append']);ap.add_argument('--contract',required=True);ap.add_argument('--contract-sha256',required=True);ap.add_argument('--review',required=True);ap.add_argument('--review-sha256',required=True);args=ap.parse_args();u=utility();c,table,payload,outputs=u.runtime(args,__file__,'SUPPORT_APPEND')
 for r in (UTILITY,BASE,CAPTURE):u.ck(table.get(r['path'])==r,'append code pin not sealed')
 sr=c['inputs']['selection'];rr=c['inputs']['selectionReview'];base=c['inputs']['baseInventory']
 for r in (sr,rr,base):u.ck(table.get(r['path'])==r,'append metadata role not sealed')
 selected=u.json_exact(sr);u.ck(selected['baseInventory']==base,'append base inventory');old=u.json_exact(base)
 u.ck(len(old['files'])==c['baseMemberCount'] and len({r['path'] for r in old['files']})==c['baseMemberCount'],'actual original member count')
 u.ck(payload=={r['payloadPath']:{'path':r['payloadPath'],**u.sh(r)} for r in old['files']},'exact unchanged prior staged payloads')
 cp=P(args.contract);rp=P(args.review);controls=[(P(sr['path']),sr),(P(rr['path']),rr),(cp,{'path':str(cp),'bytes':u.identity(cp)[2],'sha256':args.contract_sha256}),(rp,{'path':str(rp),'bytes':u.identity(rp)[2],'sha256':args.review_sha256})]
 u.ck(len({str(p) for p,r in controls})==4 and c['controlCopyPaths']==[str(p) for p,r in controls],'four exact noncircular control copies')
 out=P(c['appendStaging']);inventory=P(c['amendedInventory']);patterns=P(c['amendedPatterns']);base_staging=P(c['baseStaging'])
 u.ck(out.parent==inventory.parent==patterns.parent==base_staging.parent==C and out!=base_staging and not out.exists(),'finite new staging/output paths')
 expected={str(out/r['localRelativePath']) for r in selected['files']}|{str(out/p.name) for p,r in controls}|{str(inventory),str(patterns)}
 u.ck(outputs==expected and len(expected)==len(selected['files'])+6,'exact append outputs/collision')
 u.ck(c['scope']=={'sourcePayloadReads':False,'seedReads':False,'nativeReadback':False,'noLiveTreeTraversal':True,'appendOnly':True},'append scope')
 capture=u.module(ast.parse(u.read_exact(CAPTURE)),CAPTURE['path'],'ford_capture_adapter_v1');sys.modules['ford_capture_adapter_v1']=capture
 m=u.module(assembly(u),__file__,'ford_exact_nissan_append');m.BASE_INVENTORY=base;m.BASE_COUNT=c['baseMemberCount'];m.APPEND_SELECTION=P(sr['path']);m.APPEND_STAGING=out;m.AMENDED_INVENTORY=inventory;m.AMENDED_PATTERNS=patterns;m.BASE_STAGING=base_staging;m.CONTROL_COPIES=controls
 m.ford_authorities=lambda s,r,sr,rr:authority_check(u,s,r,sr,rr,c,table)
 sys.argv=[str(P(__file__).resolve()),sr['path'],sr['sha256'],rr['path'],rr['sha256']];m.main()
if __name__=='__main__':main()
