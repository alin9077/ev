#!/usr/bin/env python3
"""Canonical Ford core modes; exact Nissan implementation, independently gated."""
import sys
from ford_capture_adapter_v1 import C, B, NISSAN, P, capture_module, load_reference, replace_constant, redirect_import

PIN = {'bytes': 4385, 'sha256': '9320375725e900d042f6e5bbc7fc75f53564e16ec3a86af6e7fa9a07d82322df'}
OLD_RESTORE = 'Overlay after the exact 142-archive Renault chain, replacing only its standalone source archive with this full registered Nissan working source; reuse the other 141 exact archives. Original raw-capture expected hashes remain unchanged; exact copy-only changes are recorded in the retained sanitation mapping. Native byte readback remains unpassed.'
NEW_RESTORE = 'Overlay after the exact 145-archive Nissan chain, replacing only its standalone source archive with this full registered Ford working source; reuse the other 144 exact archives. Original raw-capture expected hashes remain unchanged; exact copy-only changes are recorded in the retained sanitation mapping. Three delivery-only artifacts remain outside the recovery chain. TypeScript, release and native byte readback remain unpassed.'

def transform(tree):
    redirect_import(tree, 'nissan_capture_adapter_v2', 'ford_capture_adapter_v1')
    redirect_import(tree, 'nissan_privacy_adapter_v2', 'ford_privacy_adapter_v1', expected=3)
    for old, new in (
        ('NISSAN-WORKING-20261015T2220', 'FORD-WORKING-20261016T0145'),
        (OLD_RESTORE, NEW_RESTORE),
        ('nissan-safety-support/COPY-SANITATION-MAPPING.json', 'ford-safety-support/COPY-SANITATION-MAPPING.json'),
        ('NISSAN-CAPTURE-CANDIDATE-APPROVAL-v1.json', 'FORD-CAPTURE-CANDIDATE-APPROVAL-v1.json'),
        ('INDEPENDENTLY_ACCEPTED_EXACT_NISSAN_COPY_MAPPING', 'INDEPENDENTLY_ACCEPTED_EXACT_FORD_COPY_MAPPING')):
        replace_constant(tree, old, new)
    replace_constant(tree, 'nissan_phase_gateway_v1.py', 'ford_phase_gateway_v1.py', expected=4)
    return tree

def verified_core_contract():
    cap = capture_module()
    contract = cap.load(C / 'FORD-CORE-ADAPTER-CONTRACT-v1.json')
    assert contract['status'] == 'INDEPENDENTLY_ACCEPTED_EXACT_FORD_CORE_ADAPTERS'
    assert P(contract['preparation']['path']) == C / 'FORD-ADAPTER-PREPARATION-v1.json'
    for key in ('preparation', 'review', 'rootGrant', 'sourceMethodAmendment', 'sourceReusePayloadMap', 'sourceMethodReview'):
        row = contract[key]
        cap.check(P(row['path']), row)
    prep = cap.load(contract['preparation']['path'])
    for row in prep['localPins'] + prep['priorPins']:
        cap.check(P(row['path']), row)
    assert contract['rootGrant'] == prep['rootGrant']
    assert contract['sourceMethodAmendment'] == prep['sourceMethodAmendment']
    assert contract['sourceReusePayloadMap'] == prep['sourceReusePayloadMap']
    assert cap.load(contract['review']['path'])['result'] == 'ACCEPTED_EXACT_FORD_CORE_ADAPTERS_AND_INVOCATIONS'
    assert contract['nativeByteReadbackVerified'] is False
    return cap

def main():
    verified_core_contract()
    m = load_reference('ford_nissan_gateway_reference', NISSAN / 'nissan_phase_gateway_v2.py', PIN, transform)
    m.main()

if __name__ == '__main__':
    main()
