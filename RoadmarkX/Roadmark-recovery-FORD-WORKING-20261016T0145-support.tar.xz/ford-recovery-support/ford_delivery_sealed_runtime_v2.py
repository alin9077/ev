#!/usr/bin/env python3
"""Neutral immutable AST loader and finite delivery runtime authority, no phase on import."""
import ast,hashlib,json,os,pathlib,stat,sys,types
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent

def ck(ok,why):
    if not ok:raise AssertionError(why)
def sh(r):return {k:r[k] for k in ('bytes','sha256')}
def bp(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def identity(p):
    p=P(p);ck(p.is_absolute() and '..' not in p.parts,'absolute canonical path required')
    for q in (p,*p.parents):ck(not stat.S_ISLNK(q.lstat().st_mode),'symlink rejected')
    s=p.lstat();ck(stat.S_ISREG(s.st_mode),'regular file required');return (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def read_exact(r):
    p=P(r['path']);ck(type(r['bytes']) is int and 0<=r['bytes']<=33554432 and p.suffix in ('.py','.json','.jsonl','.md','.txt','.log'),'bounded code/metadata only')
    before=identity(p)
    with p.open('rb') as f:raw=f.read(r['bytes']+1)
    ck(identity(p)==before and bp(raw)==sh(r),'stable exact pin differs: '+str(p));return raw
def pin(p):
    p=P(p);before=identity(p);raw=p.read_bytes();ck(identity(p)==before,'pin changed');return {'path':str(p),**bp(raw)}
def json_exact(r):return json.loads(read_exact(r))
def assembly(base,edits,replacements=None,root_edits=()):
    text=read_exact(base).decode()
    for old,new,n in root_edits:
        ck(text.count(old)==n,'root anchor count differs');text=text.replace(old,new)
    tree=ast.parse(text,filename=base['path']);functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
    for name,changes in edits.items():
        node=functions[name];source=ast.get_source_segment(text,node)
        for old,new,n in changes:
            ck(source.count(old)==n,(name,'anchor count differs',old));source=source.replace(old,new)
        tree.body[tree.body.index(node)]=ast.parse(source).body[0]
    for name,node in (replacements or {}).items():
        current=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
        node=ast.parse(ast.unparse(node)).body[0];node.name=name;tree.body[tree.body.index(current)]=node
    guards=[n for n in tree.body if isinstance(n,ast.If) and ast.dump(n.test)==ast.dump(ast.parse("__name__=='__main__'",mode='eval').body)]
    ck(len(guards)==1,'main guard differs');tree.body.remove(guards[0]);return ast.fix_missing_locations(tree)
def module(tree,filename,name):
    m=types.ModuleType(name);m.__file__=str(filename);exec(compile(tree,str(filename),'exec'),m.__dict__);return m

def runtime(args,own,role):
    cp,rp=P(args.contract),P(args.review);ck(cp.parent==rp.parent==C,'runtime authority location')
    cr={'path':str(cp),'bytes':identity(cp)[2],'sha256':args.contract_sha256};rr={'path':str(rp),'bytes':identity(rp)[2],'sha256':args.review_sha256}
    c,r=json_exact(cr),json_exact(rr);op=pin(own)
    ck(c['schemaVersion']==1 and c['checkpoint']==str(C) and c['mode']==r['mode']==args.mode,'runtime exact scope')
    ck(c['adapter']==r['adapter']==op and r['contract']==cr and r['result']=='ACCEPTED_EXACT_FORD_'+role+'_RUNTIME_CONTRACT','runtime exact review')
    ck(c['nativeByteReadbackVerified'] is False and c['currentMaterializeAttempts']==c['currentAlternateReadRoutes']==0,'native boundary')
    argv=[args.contract_sha256 if x=='@CONTRACT_SHA256@' else args.review_sha256 if x=='@REVIEW_SHA256@' else x for x in c['canonicalArgvTemplate']]
    ck(argv==[str(P(own).resolve()),*sys.argv[1:]],'runtime canonical argv differs')
    metadata={x['path']:x for x in c['metadata']};payload={x['path']:x for x in c['payloadInputs']}
    ck(len(metadata)==len(c['metadata']) and len(payload)==len(c['payloadInputs']) and not set(metadata)&set(payload),'duplicate runtime input')
    for x in metadata.values():read_exact(x)
    out=[P(x) for x in c['outputs']];ck(len(set(out))==len(out) and all(p.is_relative_to(C) and not p.exists() for p in out),'immutable exact outputs')
    invocation=P(c['currentInvocationPath']);ck(invocation.parent==C and invocation.name.endswith('.resources.invocation.json'),'bounded invocation location')
    i=json.loads(invocation.read_bytes());ck(i['command'][-len(argv):]==argv and i['addressSpaceLimitBytes']==268435456 and i['wallLimitSeconds']==600,'bounded canonical invocation')
    ck(not invocation.with_name(invocation.name.replace('.invocation.json','.json')).exists(),'premature terminal')
    return c,metadata,payload,{str(p) for p in out}
