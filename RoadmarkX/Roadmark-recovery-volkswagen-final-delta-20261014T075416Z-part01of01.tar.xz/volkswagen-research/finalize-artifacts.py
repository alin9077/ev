import json,pathlib,hashlib,re,collections
R=pathlib.Path('/tmp/volkswagen-research');D='2026-10-14';REPO=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104');load=lambda p:json.loads((R/p).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=load('volkswagen-2026-10-14.json');e=load('volkswagen-effective-facts.json');src={s['id']:s for s in p['sources']};norm=load('normalized-evidence.json');prior={c['id']:c for c in load('volkswagen-live-before.json')}
core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty','battery_warranty']
rows=[]
for c in norm['variants']:
 fs={}
 for k in core:
  f=e[c['id']][k];fs[k]={x:f.get(x) for x in ['value','unit','basis','comparisonBasis','status','buyerGrade','conditionExplanation','qualifications','date','validUntil']};fs[k].update(reviewReason=f['gradeReview']['reason'],sourceIds=f['sourceIds'],sourceUrls=[src[x]['url'] for x in f['sourceIds']])
 rows.append(dict(variantId=c['id'],model=c['model'],trim=c.get('metadata',{}).get('trim',c['trim']),modelYear=c.get('metadata',{}).get('year',c.get('modelYear')),availability=c['availability'],fields=fs))
(R/'core-matrix.json').write_text(json.dumps(dict(checkedAt=D,coreFieldCount=17,cells=len(rows)*17,rows=rows),indent=2,ensure_ascii=False)+'\n')
for s in p['sources']:
 for l,h in [('capture_locator','capture_sha256'),('capture_text_locator','capture_text_sha256')]:
  if s.get(l):assert sha(R/s[l])==s[h],s['id']
(R/'source-index.json').write_text(json.dumps(dict(checkedAt=D,scope='Volkswagen Australian Tier 1 BEV source observations; immutable old sources preserved. Companion brand directories are not global C1 lists.',sources=p['sources']),indent=2,ensure_ascii=False)+'\n')
captures=[];findings=[];pats=[r'(?im)^set-cookie\s*:',r'(?im)^cookie\s*:',r'(?i)(?:csrf[_-]?token|requestverificationtoken|client_secret|access_token|refresh_token)["\x27]?\s*[:=]\s*["\x27](?!\[REDACTED\])[^"\x27\n]+']
for d in ['id45','idbuzz','terms']:
 for f in sorted((R/d).rglob('*')):
  if not f.is_file() or '__pycache__' in f.parts:continue
  rel=str(f.relative_to(R));captures.append(dict(path=rel,bytes=f.stat().st_size,sha256=sha(f)))
  if f.suffix in ['.txt','.json','.html']:
   text=f.read_text(errors='replace');n=sum(len(re.findall(pat,text)) for pat in pats)
   if n:findings.append(dict(path=rel,matches=n))
assert not findings,findings
red=dict(checkedAt=D,policy='Durable evidence excludes authentication headers, cookies, runtime session/challenge/CSRF/client secrets. Facts, source URLs and public site IDs retained.',scannedFiles=len(captures),detectedSensitiveCaptureValues=0,notes=['No request or response headers are needed as factual evidence. Family capture redaction logs document any content-preserving changes. Search-index and failed-page access limitations remain explicit.'],familyRedactionLogs=[str(f.relative_to(R)) for f in R.rglob('*redact*') if f.is_file() and f.parent!=R])
(R/'redaction-audit.json').write_text(json.dumps(red,indent=2)+'\n')
(R/'source-hash-manifest.json').write_text(json.dumps(dict(checkedAt=D,files=captures),indent=2,ensure_ascii=False)+'\n')
retained=[]
for id,c in prior.items():
 for k,f in c['facts'].items():
  if f['value'] is not None and k not in e[id]:retained.append(dict(variantId=id,key=k,value=f['value'],date=f['date'],reason='Unchanged historical exact-configuration observation, not a fresh review; preserved original source date, qualifications and grade. Canonical core/updated equipment facts are reviewed in this packet.'))
allf=[f for x in e.values() for f in x.values()]
assert all(all(s in src for s in f['sourceIds']) for f in allf)
assert all(f['value'] is None and len(set(src[s]['url'].split('#')[0] for s in f['sourceIds']))>=2 for f in allf if f['buyerGrade']=='not_published')
old=load('immutable-data-before.json');assert isinstance(old,dict)
authorizedRegistration=[]
for file,h in old.items():
 if sha(REPO/file)==h:continue
 assert file=='data/m1-brand-updates/registry.json',file
 assert load('integration-readiness.json').get('packetApprovedForGuardedIntegration'), 'Registry changed before independent approval'
 reg=json.loads((REPO/file).read_text());assert reg['packets'][-1]=='volkswagen-2026-10-14.json'
 reg['packets'].pop();assert hashlib.sha256((json.dumps(reg,indent=2)+'\n').encode()).hexdigest()==h
 authorizedRegistration.append(dict(path=file,previousSha256=h,currentSha256=sha(REPO/file),reason='Root appended the independently approved Volkswagen packet; the research task did not edit the registry.'))

counts=dict(collections.Counter(v[k]['buyerGrade'] for v in e.values() for k in core))
checks=dict(checkedAt=D,originalDataFilesUnchanged=len(old)-len(authorizedRegistration),authorizedRootRegistrationChanges=authorizedRegistration,totalReviewedVersions=len(rows),onSaleVersions=sum(r['availability']['state']=='current_or_order_listed' or r['availability']['state']=='outgoing' and r['availability'].get('stockStatus')=='new_stock_listed' for r in rows),newVersions=len(p['variants']),coreCells=len(rows)*17,coreGradeCounts=counts,allReviewedFactCount=len(allf),guardedFactEdits=len(p['facts']),brandTerms=len(p['brandTerms']),guardedEquipmentRows=len(p['features']),guardedConfigurationReviews=len(p.get('configurationUpdates',[])),summaries=len(p['summaries']),retainedHistoricalObservations=retained,sourceSnapshots=len(p['sources']),captureFiles=len(captures),allLocallyCapturedSourceHashesMatch=True,archivedOriginalBrowserHashesLocallyReverified=False,retainedEvidenceAudit='idbuzz/retained/admitted-assertion-supplement.json',allNegativeFactsHaveTwoUsableUrls=True,registeredByResearchTask=False)
(R/'evidence-completeness-audit.json').write_text(json.dumps(checks,indent=2,ensure_ascii=False)+'\n')
files=[]
for f in sorted(R.iterdir()):
 if f.is_file() and f.name!='artifact-hash-manifest.json':files.append(dict(path=f.name,bytes=f.stat().st_size,sha256=sha(f)))
(R/'artifact-hash-manifest.json').write_text(json.dumps(dict(checkedAt=D,files=files),indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in checks.items() if k!='retainedHistoricalObservations'},indent=2))
