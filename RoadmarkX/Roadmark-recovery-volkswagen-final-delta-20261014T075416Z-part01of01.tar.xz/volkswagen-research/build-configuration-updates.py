import json,copy,pathlib
R=pathlib.Path('/tmp/volkswagen-research')
p=json.loads((R/'volkswagen-2026-10-14.json').read_text())
before={x['id']:x for x in json.loads((R/'volkswagen-live-before.json').read_text())}
e=json.loads((R/'volkswagen-effective-facts.json').read_text())
keys=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg']
release={'price_aud':['price_aud'],'battery_kwh':['battery_kwh'],'power_kw':['power_kw'],'zero_to_100_s':['zero_to_100_s'],'battery_usable_kwh':['battery_kwh'],'range_wltp_km':['range_km'],'range_cycle':['range_km'],'ac_charge_max_kw':['ac_kw'],'dc_charge_peak_kw':['dc_peak_kw'],'dc_10_80_min':['dc_charge_time_min'],'braked_tow_kg':['towing_braked_kg'],'rear_cargo_l':['boot_l']}
rows=[]
for id,c in before.items():
 if not id.startswith('volkswagen_idbuzz_my26_'):continue
 b=copy.deepcopy(c['configurationEvidence']);a=copy.deepcopy(b);fs=e[id]
 deps=[dict(key=k,expected=fs[k]) for k in keys]
 ids=list(dict.fromkeys(s for d in deps for s in d['expected']['sourceIds']))
 a.update(rankingEligible=True,completeVehicleCountEligible=False,sourceIds=ids)
 a['countContribution']['rankableRecords']=1
 a['projectionScope']='Australia MY26 ID. Buzz '+c['trim']+' named-grade technical facts reviewed on 14 October 2026. '+b['projectionScope']+' Each price, technical fact and equipment answer keeps its own source/build scope; ranking eligibility is assessed per fact. The preserved pricingBoundary, chargingBoundary and projectionContract describe the earlier capture only, superseded for reviewed canonical facts; unreleased source-field nulls remain unknown. This is still an incomplete technical record.'
 a['requiredNulls']={k:copy.deepcopy(v) for k,v in b['requiredNulls'].items() if k not in release}
 a['configurationReview']={'reviewedAt':'2026-10-14','overlayId':p['id'],'historicalBoundaryFields':['pricingBoundary','chargingBoundary','projectionContract'],'releasedNulls':[{'key':k,'factKeys':v} for k,v in release.items() if k in b['requiredNulls']]}
 rows.append(dict(variantId=id,before=b,after=a,reason='Remove the historical all-facts ranking hold now that this exact MY26 named grade has independently reviewed canonical facts. Preserve incomplete-record status, original source/build boundaries and every per-fact grade/comparability restriction.',sourceIds=ids,dependencies=deps))
assert len(rows)==3
p['configurationUpdates']=rows
(R/'volkswagen-2026-10-14.json').write_text(json.dumps(p,indent=2,ensure_ascii=False)+'\n')
(R/'configuration-updates.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n')
print(json.dumps([{'variantId':r['variantId'],'sourceIds':len(r['sourceIds']),'dependencies':len(r['dependencies']),'releasedNulls':r['after']['configurationReview']['releasedNulls'],'retainedNulls':len(r['after']['requiredNulls'])} for r in rows],indent=2))
