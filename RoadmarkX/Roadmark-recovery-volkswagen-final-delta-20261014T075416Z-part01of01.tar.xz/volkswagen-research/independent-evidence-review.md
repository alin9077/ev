# Volkswagen M1 independent evidence review

Reviewed 14 October 2026. **Approved for guarded integration** after the final independent evidence/runtime replay exited 0. This approval covers the exact packet and reconciliation hashes below and the shared-code hashes recorded in independent-review-replay.json. No registry, source data or application code was changed by this reviewer.

- Packet: `208581fcff2c9e0dcd8a54ca0d11faff9423db1cb635211156722815d9e61513`
- Reconciliation: `1f91c72014f4120cc907a62937da0fd9be3431e89f74d7088cef3ba12f218b33`

Both unregistered repository candidates exactly match the reviewed research files. The approval retains the unresolved census and all strict completion limits. It is not M1 release or publication approval.

## Evidence judgment

- Eighteen Tier 1 versions are represented: thirteen currently advertised or evidenced outgoing-New versions and five reported-order-open MY27 passenger ID. Buzz versions. Eleven identities are new. ID. Buzz Cargo and e-Transporter remain outside this review and unchanged.
- Current official October–December MY25 Pro SWB/LWB Buzz campaigns establish advertised buyer options without proving a surviving New VIN. These two were retained after review rather than excluded for a failed dealer-stock search. The five MY27 passenger variants remain reported order-open/arriving, with the July report and elapsed September expectation visible. No current official MY27 list, actual arrival or accepted factory order is claimed.
- Two genuine census questions remain: the current official MY27 Buzz version list, and an indexed MY26 ID.4 GTX New advertisement whose live origin/alternate dealer pages cannot establish fresh stock. They remain unresolved, never converted to a false absence. Two whole-market published lists are also still needed globally. The two complete Volkswagen brand directories account for 66 entries and are not submitted as global lists.
- Prices follow the authorized ladder. Current exact-year maker campaigns outrank secondary list figures. The retained MY26 GTX Buzz A$117,216 NSW-reference configurator price keeps its 10 October date and build/location qualifications. MY27 Buzz secondary prices preserve the A$79,990/A$80,990 Pro LWB disagreement. No price vote, wholesale carryover or expired offer promotion is used.
- I independently reopened official Australian model pages, warranty/roadside terms and both brand directories, and visually checked relevant ID.4, ID.5 and Buzz PDF tables. Current battery usable-capacity columns are not reversed. Vehicle DC peak is separate from station power; exact 10–80% gaps remain Not published after bounded checks.
- Maker occupied-seat cargo values and nominal braked tow ratings are Confirmed with their exact seating/towbar scope. Cargo remains unranked where method and loading boundary are not established. The Buzz 10/12-inch brochure conflict, multiple folded-SWB cargo values, and apparent printed consumption-unit error are preserved rather than silently corrected. MY27 bidirectional capability remains pending Australian verification.
- Included two-year EV roadside assistance is separate from conditional service renewal. Five-year private-use vehicle cover and eight-year/160,000-km battery terms retain named-use limits, capacity trigger and restoration distinction. Paid equipment/optional fitment does not change evidence quality automatically.
- Missing original browser snapshots are disclosed. Forty-three retained-proof mappings contain 59 exact fact/anchor references that independently match the immutable original admitted ledger. Eight derived source files passed their hashes. Original full-browser hashes are archived assertions, not locally reverified bytes. Optional Pro HUD/roof/Harman and GTX HUD claims were corrected to cite their actual maker brochure columns.

## Final independent execution

The independent harness passed 675 guarded fact edits plus three shared terms (729 citable reviewed facts), 370 equipment rows and their 370 exact dependencies, and three configuration updates with 45 exact fact dependencies. It checked 168 local capture references across 103 unique files and 174 manifest file hashes/byte lengths. Actual application packs equal explicit replay and roundtrip exactly through the portable representation, including the new configuration review metadata. Other brands, Volkswagen Tier 2, prior sources and all 88 pre-existing data files remain unchanged.

Twenty-six negative mutation categories failed closed. The original twelve cover version state, fact state, complete brand-term scope, feature before state, feature dependency, summary dependency, availability before state, price ladder basis, invalid roadside enum, unrelated roadside metadata, existing-source collision and new Tier 2 version injection. Fourteen additional categories were each checked independently at preparation and catalogue application: configuration full-before state, protected source identity, protected build options, historical price boundary, complete-record promotion, complete-count promotion, dependency drift, explicit sources, null scope erasure, missing null-release proof, wrong scalar alias, changed retained hold, duplicate target and unguarded target.

Twenty-one actual-record ranking checks confirm that each of the three newly eligible MY26 Buzz records still loses range ranking when a supporting source is withdrawn, held, inaccessible or stale, the fact needs review, its measurement basis is missing, or the evidence ages out. Reported AC power and unidentified cargo methods remain unranked. Buyer availability is thirteen On sale now plus five Order open or arriving, with historical arrival timing and explicit nonverification preserved.

Final rankable counts are price 8, range 11, exact-window charging time 6, seats 6, cargo 0 and braked towing 6. Five provisional versions remain excluded from on-sale ranking; secondary or method-limited facts also remain unranked.

## Configuration correction and shared-code review

The initial candidate passed evidence review but left the three MY26 passenger Buzz records behind an obsolete blanket configuration ranking gate. The revised packet corrects that historical scope boundary through explicit full-before-state overlays. Each releases twelve named null holds using exact current packet facts, preserving all unmatched nulls, selected-build options, original source/capture identity and the three opaque historical pricing/charging/projection boundary objects. Full technical-record eligibility remains false. The residual ID.5 Pro identity now preserves the exact MY25.5 string.

Removing only those three configuration updates and reverting only the MY25.5 string reproduces the initial reviewed packet hash exactly. This independently establishes that no facts, equipment claims or source snapshots drifted in the revision. The static proof is in configuration-revision-static-check.json.

The shared implementation was inspected against its saved before files. It requires existing Tier 1 bounded records, unique targets, identity guards, exact before state, current explicit citations and exact post-packet fact dependencies. Opaque fields are immutable, scope cannot be erased, count/full-record promotion is blocked, and retained null holds cannot be rewritten. Released aliases preserve the relevant usable-capacity, cycle and charging-window meaning. Historical source-feature warning context is retained rather than rebased to the new live scope. Active dependencies are checked again after later packets. Ordinary fact-level grade, basis, source, offer and freshness rules still control ranking.

The shared-code worker's inspected logs record 80/80 focused brand/configuration/feature regressions, one additional historical-feature-context test, full TypeScript no-emit checking and focused ESLint passing. This review does not claim a full aggregate suite or production build; those remain root integration checks.

## Completion limits and proof files

Strict C1/C2/C5 and brand research completion remain false. C3/C4/C6 pass in the final self-stage. The current official MY27 Buzz version list and the inaccessible MY26 ID.4 GTX New-stock lead remain explicit census blockers. Brand directories never stand in for complete whole-market C1 lists.

- Independent harness: `../review-volkswagen-independent.ts`
- Final runtime and exact approved artifact/code hashes: `independent-review-replay.json`, `.log`, `.exit`
- Retained-ledger proof: `retained-ledger-independent-check.json`
- Configuration revision proof: `configuration-revision-static-check.json`
- Initial approved evidence/replay reference: `initial-91d90cd4-replay.json`, `.log`
- Visual PDF checks: `id4-09.png`, `id4-10.png`, `idbuzz-14.png`, `idbuzz-15.png`
