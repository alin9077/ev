"""Measure one authorized command in an exclusive external directory.

GNU timeout owns a new process group and terminates that group on timeout.
The terminal receipt is written only after wait4 returns for the completed group
leader, preserving actual exit/signal and kernel-reported child resource usage.
"""
import datetime, json, os, pathlib, subprocess, sys, time
out=pathlib.Path(sys.argv[1]).resolve();seconds=int(sys.argv[2]);command=sys.argv[3:]
assert out.is_relative_to(pathlib.Path('/tmp/mercedes-staging-plan/runs'))
assert seconds>0 and command and not out.exists()
out.mkdir(parents=True,exist_ok=False)
actual=['/usr/bin/timeout','--signal=TERM','--kill-after=10s',str(seconds)+'s',*command]
start=time.monotonic();stamp=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
initial={'startedAt':stamp(),'cwd':os.getcwd(),'command':actual,'timeoutSeconds':seconds,'newProcessGroup':True}
(out/'invocation.json').write_text(json.dumps(initial,indent=2)+'\n')
with (out/'stdout.log').open('x') as stdout,(out/'stderr.log').open('x') as stderr:
    proc=subprocess.Popen(actual,stdout=stdout,stderr=stderr,start_new_session=True)
    _,status,usage=os.wait4(proc.pid,0)
    code=os.waitstatus_to_exitcode(status);proc.returncode=code
result={**initial,'completedAt':stamp(),'returncode':code,'signal':-code if code<0 else None,'timeoutReported':code in (124,137),'elapsedSeconds':time.monotonic()-start,'maxRssKiB':usage.ru_maxrss,'userSeconds':usage.ru_utime,'systemSeconds':usage.ru_stime,'receiptWrittenAfterExit':True}
with (out/'terminal.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2));sys.exit(0 if code==0 else 1)
