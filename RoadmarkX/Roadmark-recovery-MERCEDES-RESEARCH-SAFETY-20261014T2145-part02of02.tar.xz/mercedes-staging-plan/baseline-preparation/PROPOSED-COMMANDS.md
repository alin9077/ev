# Proposed commands, not executed

The only proposed payload execution in this preparation is the single read-only baseline extraction below. It requires both an independent approval of the exact manifest/adapter and a separate root grant of the sole heavy slot. Do not run this command during review.

## Exact input boundary

- Working directory: `/workspace/scratch/586427eef9f2/roadmark-104`
- Node version: `v24.19.0`
- Manifest: `/tmp/mercedes-staging-plan/baseline-preparation/baseline-manifest-v1.json`
- Manifest SHA256: `bdcedddcbac5e2090efe423fc640a97975dcd3746ab10db916244ea7d5b7230d`
- Manifest bytes: `136774`
- Adapter: `/tmp/mercedes-staging-plan/baseline-preparation/extract-reviewed-baseline.mjs`
- Adapter SHA256: `e5fe315476b0641a5eb963d5675063cdb8f4c37df379c111d2eb230e72b73712`
- Adapter bytes: `18371`
- Review: `/tmp/mercedes-staging-plan/baseline-preparation/reviews/baseline-v1.json`, not yet created
- `REVIEW_SHA256` below must be supplied by the independent reviewer for that exact approval file. It must not be invented or filled by hashing an unreviewed placeholder
- Output folder: `/tmp/mercedes-staging-plan/baseline-preparation/extractions/baseline-v1`, must not exist beforehand
- Measurement/log folder proposal: `/tmp/mercedes-staging-plan/baseline-preparation/runs/baseline-v1`, exclusive, created by root's existing measured command runner

## Extraction command

```sh
cd /workspace/scratch/586427eef9f2/roadmark-104
node --expose-gc --max-old-space-size=448 --max-semi-space-size=1 --import tsx \
  /tmp/mercedes-staging-plan/baseline-preparation/extract-reviewed-baseline.mjs \
  --manifest /tmp/mercedes-staging-plan/baseline-preparation/baseline-manifest-v1.json \
  --manifest-sha256 bdcedddcbac5e2090efe423fc640a97975dcd3746ab10db916244ea7d5b7230d \
  --review /tmp/mercedes-staging-plan/baseline-preparation/reviews/baseline-v1.json \
  --review-sha256 "${REVIEW_SHA256:?Independent reviewed approval SHA256 required}"
```

The command must be wrapped by root's already used measured-run mechanism so the exact argv, stdout, stderr, terminal exit code, actual signal, elapsed time and peak RSS are retained. The adapter also records process resource usage on success. Do not infer an OOM cause from exit 137 or signal 9 alone. Do not overlap backup/compression, catalogue hydration, tests, compiler, report or another heavy task.

Any preflight pin/membership failure stops the extraction. There is no automatic source-pin refresh, restoration, retry, canonical recapture, grade relaxation or alternate hydration route. Root may propose a separately reviewed source transition or revised resource ceiling, preserving this original attempt and all inputs. Reusing an occupied output path is rejected.

## Output acceptance

Only after a successful terminal result AND the final receipt exist should a reviewer inspect the exact nine artifacts and receipt. The receipt contains actual output SHA256/bytes. Do not create an expected-output hash in advance. Bind these actual reviewed output pins into later candidate inputs, retaining the 405-car derived-baseline lineage and both complete historical report files.

## Later complete registered parity command

This is a separate future action, not included in this extraction grant. It can run only after a reviewed Mercedes candidate, complete staged feature/report proof, and separately authorized root registration transition exist. Its date must equal the original candidate report date; the following exact command applies only if the candidate uses `2026-10-15`:

```sh
cd /workspace/scratch/586427eef9f2/roadmark-104
node --max-old-space-size=448 --max-semi-space-size=1 --import tsx \
  scripts/report-coverage.ts --as-of 2026-10-15 --json
```

Root captures stdout unchanged and pins it, then compares it to the complete original Mercedes staged report as both bytes and complete parsed JSON. Candidate report path/hash and final Mercedes source inventory/transition do not exist yet and must be supplied from real reviewed outputs. Their absence is a remaining gate, not permission to reuse the old XPENG expected report or derive invented canonical values.

No TypeScript, tests, build, compression, publishing or browser command is proposed or authorized by this baseline preparation.
