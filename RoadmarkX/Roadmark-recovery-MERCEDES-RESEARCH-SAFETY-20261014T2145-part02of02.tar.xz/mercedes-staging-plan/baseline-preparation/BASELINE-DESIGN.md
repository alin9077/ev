# Reviewed derived baseline for the next Tier 1 packet

Status: static preparation only. No script, syntax check, test, compiler, hydration, extraction, report generation, compression, browser or cloud task was run. The repository was not edited. A metadata-only shell command briefly failed before process creation with an exec transport disconnection; a bounded read confirmed recovery, and preparation continued. This is not a failed extraction.

## Recommendation

Use the accepted 405-car / 27,945-feature-row derived XPENG state as the Mercedes before baseline. Reuse `readCompleteCars` directly from the pinned existing `staging-v1/read-complete-storage.mjs`. Do not invoke its `readCompleteBaseline` wrapper, which hard-codes 399. Do not run `prepare-baseline-manifest.mjs`, `extract-xpeng-baseline.mjs`, or `selectVerifiedCars`; those assume the previous 397→399 Subaru storage shape and earlier packet boundary.

The single new `extract-reviewed-baseline.mjs` adapter is brand-independent: selected brand, exact IDs, allowed classes, source inventory, packet list, accepted statuses, inherited locators, dependencies, output directory and counts are manifest data. It calls the existing recursive reader and existing production consumers. It is not a new per-brand consumer, catalogue, proof library, default loader, registry override or canonical generator. Its code has been written but never executed; independent static review is still required.

## Accepted lineage and current source boundary

1. Original full 397-car JSONL: `qa/catalogue-snapshot-reuse/after448/cars.jsonl`, 65,021,562 bytes, SHA256 `33be5eb143c848b80bd9c243b7fdf21e52e1552b462fe467b32879ea6e94243d`
2. Derived 399-car Subaru storage: `stage/candidate/staged-storage-index.json`, 129,803 bytes, SHA256 `8df40869d4db9c599d2dafe6c80fa7bbf2af9fd3cec633aa8b8f3c9bbb75893e`. Its complete 11-car replacement input is pinned by that index; two identities were appended
3. Derived 405-car XPENG storage: `xpeng/staging-artifacts/final-core-v1/staged-storage-index.json`, 131,342 bytes, SHA256 `3073d6661c437220e820477e925890ca0a04897bf2589051163d6f9fd909084d`. Its baseline explicitly has `format: storage-index`; 11 complete replacements and six appended identities are retained
4. All 14 top-level Research fields are read in full from their accepted descriptors. Raw feature evidence is distinct from the final consumer feature stream. Neither can substitute for the other
5. The complete actual final feature stream is 27,945 rows / 15,680,656 bytes, SHA256 `0cdaabd04c0bf8b6b1911e01cef69397686a234c11c4c5f679deeb0737e7f093`; its reviewed index is SHA256 `02d602f5d85d93a3ccecac84a62e31310323a8df28c24575b0b15c1b45c11504`
6. Final post-registration gate SHA256 `25f9c6b5c9149f34bbe460ec0e0e040c80a6b637e879542be199456e8169a3b2` supersedes earlier pending registration/report statuses without changing those historical artifacts

The final registered source inventory is 522 files, SHA256 `88fcc8d8ff30ff3c674f9573e652279f9cd5d54f3a0f43d2d5dae2f7f2100307`, with 19 ordered packets. The independent exact transition review is SHA256 `f370be34987add3c555eee4a112177d8abef6f561243e6c098d9cddfe4b2df31`. The transition changes only the packet registry and `scripts/reporting/load.ts`, adds the XPENG packet and reconciliation, and preserves 518 other original files. The original 18-packet prefix and retained pre-registration registry/load bytes remain pinned separately.

The new manifest copies reviewed expected source pins. It does not capture current files and call the resulting hashes approval. Before and after the future extraction, every current scoped source must equal the accepted final inventory. Any drift, including a test-only delta, stops execution and requires an explicit separately reviewed transition. No silent pin refresh is allowed.

The bounded source scope is inherited unchanged: `src`, `scripts`, `tests`, `data`, `media`, `public` except the two generated public indexes, plus root code/JSON/YAML excluding the generated source manifest. No traversal of `node_modules`, `.next`, QA, `/tmp` or arbitrary home directories is proposed. Installed dependency bytes are not covered by this source inventory; package/lock pins and the recorded Node version are included, and no stronger reproducibility claim is made.

## Exact selected population

The seven existing passenger rows are accepted catalogue ordinals 134–140:

- `mercedes_benz_eqa_current__eqa_250_plus__20261010`
- `mercedes_benz_cla_electric_current__cla_200__20261010`
- `mercedes_benz_cla_electric_current__cla_350_4matic__20261010`
- `mercedes_benz_glb_electric_current__glb_250_plus__20261010`
- `mercedes_benz_glb_electric_current__glb_350_4matic__20261010`
- `mercedes_benz_eqs_current__eqs_400__20261010`
- `mercedes_benz_g_class_electric_current__g_580_with_eq_technology__20261010`

The manifest records their complete accepted car and feature digest metadata. The extraction verifies exactly 483 actual feature rows, 69 per selected car. IDs do not prove current Australian orderability, model year, full Mercedes market closure or research completion; research must establish those separately.

Cargo eVito, `mercedes_benz_evito_current__112_lwb_panel_van__20261010`, ordinal 82, is excluded from selected changes. Its complete one-row car digest is 27,281 bytes / SHA256 `3253f6bbcb7cc750073f64f75d36a9685d55028ab33a559d29dc67894dac3ece`; its 69 features are 30,624 bytes / SHA256 `24fb05acfd17a37a7b5f530e657366226733a63afbd24d902839ebd47a6a34d3`. Both are explicit invariants. All other cars are also checked, not merely eVito.

## Reusable dependency selection

- `readCompleteCars`: reuse unchanged, SHA256 `e1459c82c69371c0bdf5d8597190c56cc5eda444b357970bc6497223954e9787`. It verifies complete inherited before/after car values at each nested layer, identities, brands, bytes, exact order, replacements, appended rows and cycles
- `baseline-io.mjs`: reuse only generic IO, path containment, digest, stream, research, inventory comparison and exclusive-output exports, SHA256 `71122a46213f25c58a8c81ee4ae9472920981fc04f1464ad7223ba9a256da0fe`. Its Subaru-specific `selectVerifiedCars` is deliberately not imported or called
- `open-stage-inputs.mjs`: reviewed as the dependency/manifest pattern, not an executable dependency. It contains XPENG-only anchor, ID, capture, status and count predicates, and is not suitable unchanged
- `src/lib/evidence-consumers.ts`: unchanged actual `createEvidenceConsumers`; explicit complete `{data, cars}` only, with all default-loading callbacks throwing
- `src/lib/brand-updates.ts`: unchanged actual `brandVersionSnapshot` for selected identity guards
- `src/lib/brand-update-registry.ts`: unchanged actual 19-packet loader; exact complete loaded packet equality against pinned files and exact Research metadata packet order
- No import of `src/lib/data.ts`, reporting loader, `compiledSource`, legacy baseline wrappers, production hydration entry points or candidate registry shim during extraction

## Proposed future extraction sequence

1. Independent reviewer inspects the manifest, adapter, this design, source transition and accepted storage/feature/report chain. Reviewer does not execute anything. It binds the exact manifest, driver and dependency hashes in a separate approval file
2. Root decides whether to grant the sole heavy slot for one measured extraction. Static review alone is not execution authorization. No parallel backup, compression, hydration, report, test or compiler process may overlap
3. In one fresh Node process, check the exact approved manifest/review, anchored path containment, driver/dependency hashes and accepted source membership/pins before reading payloads
4. Verify the historical final registration source transition and the complete original staged-versus-registered report bytes/JSON. The stored normal-CLI run remains historical; the extractor does not call it fresh
5. Recursively read every full effective car through the existing reader. Retain exact 405 order and complete hashes. Select the manifest IDs only after verification; check the selected brand/classes and cargo exclusion
6. Read all 14 Research fields and verify every descriptor's rows, bytes and SHA256; check exact variant order, criteria uniqueness and the real 19-packet metadata order. No metadata repair
7. Stream the complete 27,945 actual feature rows, verifying each contiguous 69-row car block, criteria uniqueness, complete feature digest and corresponding full car digest. Retain only the seven selected feature blocks after verification
8. Produce actual packs for those seven cars with unchanged explicit-snapshot consumers. Compare every complete feature row directly with accepted stored rows. Copy complete cars, packs, all original facts and actual production version guards. No hand-constructed or imagined canonical before values
9. Recheck all complete cars, all 14 Research fields, actual registry objects, source/file pins, manifest and review. Write exclusive output files. Repeat preservation checks and write the successful receipt last

This design necessarily reads and hashes payloads and scoped sources during the future granted run. None of those runtime steps has happened during static preparation. The 448 MiB old-heap / 1 MiB young-generation proposal is a bounded starting configuration, not a promise of measured success or a change to the compiler scope. Root may approve a different ceiling before review is finalized.

## Outputs and pin policy

The exclusive proposed output is `baseline-preparation/extractions/baseline-v1/`. It contains:

- `selected-complete-before-cars.json`
- `actual-before-packs.json`
- `actual-before-features.json`
- `actual-before-facts.json`
- `actual-before-version-guards.json`
- `unchanged-original-research-context.json`
- `complete-car-verification.json`
- `complete-feature-verification.json`
- `complete-research-field-verification.json`
- `baseline-extraction-receipt.json`, written last

The context file retains exact selected original rows plus the complete source bag, criteria and metadata for authoring. It is explicitly a projected convenience artifact, not the complete 14-field baseline. Complete original fields remain the accepted indexed storage, all verified before and after.

Output hashes are deliberately null before execution. The writer records actual SHA256/bytes for each output in the final receipt; an independent output review binds those exact values before candidate assembly may use them. Artifact presence is not a passing receipt. Failed or interrupted attempts remain intact. An output-directory retry needs a new manifest and review, never overwriting a prior run or manufacturing a new before baseline.

## Full-report parity and final Mercedes transition

Accepted baseline report SHA256 is `4d9fe8be0107c236d9eb005757f293fd78f41b3481315fdb9c8cd719f61b19f4`, 1,627,583 bytes at `2026-10-15`. The final gate and independent parity review bind the complete normal CLI output to the complete staged report with no sorting, filtering, normalization, date replacement or selected-field comparison. This extraction rechecks those stored bytes; it is not a regenerated baseline report.

After Mercedes research and independently reviewed candidate assembly, reuse the same existing parameterized approach for complete candidate cars/features and actual production consumers. Keep all 398 unselected pre-existing cars and their complete features unchanged, including eVito; add only evidence-established new identities. If a scope amendment intentionally selects another existing record, review the exact amendment rather than weakening the invariant.

Any genuine new identity has no historical complete before car. Its first approved canonical fixture is a separate one-time phase, after evidence review and explicit authorization. Original canonical capture is immutable. It cannot be used to replace one of the seven established before baselines.

The candidate must generate its entire report through the unchanged reporting loader/builder with the same explicit-snapshot/complete-feature semantics already used by XPENG. In the unregistered phase, the candidate reconciliation is combined exactly once; after registration, the unchanged normal loader includes the new reconciliation exactly once. Do not accidentally re-add already registered XPENG reconciliation. Retain the original complete candidate report before final registration.

Only root performs the separately authorized production transition. Preserve the actual 19-packet before registry, before reporting loader and exact full before inventory; append the reviewed Mercedes packet and reconciliation with a reviewed loader entry. Any other source change requires explicit review. The eventual accepted transition must retain the entire original 19-packet prefix and every unrelated original source byte.

Then run the normal unchanged coverage CLI with the exact candidate `--as-of` date, under a fresh measured sole-slot grant, and compare the entire output JSON AND bytes against the original staged report. A changed Australian date gets a separate dated run; never normalize the original report. Fresh structural validation and the applicable current behavior checks are separate gates. TypeScript, production build, whole-project aggregate and mobile verification remain open until actually run successfully. Baseline extraction does not authorize or claim those checks, M2, market closure, publishing or release readiness.

## Restoration-free behavior

No command edits the repository, temporary registry, production loader, stored baseline, original canonical fixture, existing reports or prior expected pins. The consumer is invoked with explicit supplied inputs instead. All writes go into new manifest-selected folders under this preparation directory. The successful receipt is additive. There is nothing to restore on success or failure.
