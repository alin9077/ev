# Independent static review checklist

Do not run the adapter, `node --check`, imports, tests, compiler, catalogue, report or payload-hash scans while reviewing this draft. Root has not assigned the heavy slot.

- Read repository AGENTS.md, full DOT-BRIEF-103.md and the latest M1 progress. Stay in Tier 1 / M1 and preserve original snapshots and Model Y hero
- Confirm the final XPENG gate, not the historical pending handover alone, is the accepted 405-car registered baseline
- Confirm all seven selected exact IDs and both eVito invariant digests against the reviewed small index metadata
- Confirm 405 cars × 69 criteria = 27,945 complete feature rows, seven selected cars × 69 = 483 selected rows, 19 registered packets and 522 accepted source files
- Verify nested storage descriptor closure includes 405→399 storage-index recursion, 399→397 JSONL, both full replacement files, all top-level 14 Research descriptors and the full actual feature stream
- Confirm expected hashes come from accepted metadata, not newly captured source values; no original fixture or source expectation is reset
- Confirm the accepted 520→522 source transition has precisely two changed and two added paths; retained old registry/load bytes match old hashes and 518 other original source records match
- Confirm old source pins are retained as historical evidence only; current runtime source pins use the accepted final 19-packet inventory
- Confirm generic `readCompleteCars` is reused unchanged; never call the hard-coded 399-car wrapper, Subaru selector or old preparation/extraction entry points
- Confirm every input, selected brand, ID, count, output path, runtime consumer path and historical status predicate is manifest-driven; no copied brand-specific consumer or grading semantics
- Confirm root-relative paths cannot escape via absolute names, `..`, empty components, separators or symlink redirection; input aliases cannot duplicate different pins
- Confirm the full source membership check uses the inherited bounded scope and does not scan installed dependencies or unrelated workspaces
- Confirm accepted full staged and registered reports are compared as complete bytes and complete JSON; no normalization, filtering or regenerated expectation
- Confirm extraction does not call the normal report CLI and states that stored report parity is historical
- Confirm all complete before cars and all raw research fields are verified before calling production consumers
- Confirm all complete stored feature rows are verified, with exact per-car block order, IDs, criteria sets, bytes and hashes
- Confirm actual selected pack features are compared as whole rows with accepted storage, not synthesized canonical defaults
- Confirm unchanged actual production functions provide packs and version guards; default loaders throw, no hydration imports or registry monkey patch
- Confirm the all-car and all-Research preservation checks run after consumer use and after serialization; no weakening of hashes, source scope or old records
- Confirm output names, context projection label and receipt-last semantics; output hashes stay unknown until actual output exists
- Confirm repeated output directory use is rejected, interrupted attempts preserved, and path-only retry requires new review without baseline regeneration
- Confirm the review file binds exact manifest SHA256, driver pin, dependency pins, accepted source inventory SHA256, no production semantic changes and no canonical authorization
- Confirm no output review, candidate approval, execution grant, test/typecheck/build/mobile success, market closure or release claim is implied by static review
- Root must independently grant the heavy slot after approval; reviewer does not grant it

Required approval object (reviewer creates only after completing review):

    status: approved_for_read_only_reviewed_baseline_extraction
    manifestSha256: exact reviewed manifest SHA256
    sourceInventorySha256: accepted registered inventory SHA256
    driverPin: exact manifest.driverPin object
    dependencyPins: exact manifest.dependencies object
    noProductionSemanticChanges: true
    canonicalCaptureAuthorized: false

The approval is evidence of static review only. It must not report a script/test/compile/extraction pass because none has been run.
