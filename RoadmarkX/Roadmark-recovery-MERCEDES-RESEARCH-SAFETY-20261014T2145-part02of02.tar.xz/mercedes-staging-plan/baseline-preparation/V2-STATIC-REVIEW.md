# V2: narrow serialized-feature parity correction

Status: static proposal only. V2 has not been executed, imported, syntax-checked, tested, compiled or hydrated. No repository, production function, accepted baseline value, original V1 file, prior expected pin or measured-runner file was edited. Root must approve a separate retry after independent review.

## Preserved failure

The authorized V1 command ended with exit 1, no signal or timeout, after 12.321139867999591 seconds; recorded peak RSS was 429,216 KiB. It failed at the first selected feature comparison, adapter line 216. There is no V1 extraction output directory or successful extraction receipt. This is an observed assertion failure; no resource-failure cause is inferred.

The first 35 stderr lines show only this relevant difference on EQA's `novated_fbt` row: actual in-memory own `confirmation_needed: undefined`, while accepted JSON omits that property. That is the only actual consumer-row observation claimed here. Other selected consumer rows have not been inspected or assumed to contain it.

`v1-failure-lineage.json` pins the original manifest, adapter, approval, invocation, terminal, stdout, full stderr and retained 35-line prefix. Full stderr was retained and hashed without reading the assertion dump into context. V1 artifacts remain in place and unchanged.

## Exact allowed difference

The manifest declares one allowance:

- Top-level own enumerable data property `confirmation_needed`
- Actual value must be exactly JavaScript `undefined`
- Feature criterion must be exactly `novated_fbt`
- Variant must be one of the same seven explicitly selected manifest IDs
- The corresponding accepted JSON row must match the variant and criterion and have no own property of that name

There is no expected omission count and no assertion that the allowance occurs on all seven cars. Every occurrence must be discovered and separately audited during an authorized run. Absent occurrences are not fabricated.

## Smallest semantic change

The original raw deep equality was stronger than the accepted JSON persistence representation at this one optional-property boundary. V2 changes only that comparison and adds fail-closed guards/audit:

1. Inspect data-property descriptors without evaluating accessors. Determine the precise permitted pointer only when every allowance condition holds
2. Run a read-only JSON-shape guard before cloning or serializing. The guard is not a normalizer and makes no conversions
3. Make a comparison clone that still retains own-undefined values. Delete only each already verified allowed property from that clone
4. Require complete deep equality of the resulting clone and the entire accepted feature array. All other fields, nested values, missing/present properties, sources and row order must match
5. Separately require exact full `JSON.stringify` array equality and the existing `digestRows` JSONL equality: row count, serialized bytes and SHA256
6. Keep `pack.features` untouched, including each original own-undefined property. Compare it with a raw structured snapshot immediately and again in each existing preservation check

There is no `JSON.parse(JSON.stringify(...))` normalization, source rewrite, canonical replacement, default hydration, option-value inference, key sorting, source-ID filtering or expected-value regeneration. The same unmodified production consumer, accepted stored rows and recursive reader are used.

## Differences that still fail

The guard rejects undefined at any other property, nested path or array position; array holes and extra array properties; functions; symbols and symbol keys; bigint; NaN/infinities; negative zero; cycles; accessors; non-enumerable object properties; proxies; and non-plain object/array prototypes. These checks prevent JSON from silently dropping, coercing or converting an unreviewed value before comparison.

Null is not a substitute for undefined. Actual undefined against an accepted present/null field fails the allowance. Actual null against an accepted missing field fails complete equality. Legitimate JSON null values may pass only where the accepted row has the identical value. Changed numbers, strings, statuses, conditions, source IDs, missing fields or array/key order still fail the full clone and exact serialization checks.

A matching `confirmation_needed` property on another criterion fails. The same key on an unselected variant fails. Any non-undefined value of the allowed property is compared unchanged, so it cannot be dropped to make the row pass.

## Reviewable file delta

- New adapter: `extract-reviewed-baseline-v2.mjs`; original adapter untouched
- Static unified diff: `adapter-v1-to-v2.diff`
- New manifest: `baseline-manifest-v2.json`; all 559 V1 input pins are retained unchanged, with ten additional V2/lineage/runner pins
- New output: `extractions/baseline-v2/`; the additional `before-feature-json-parity-audit.json` records actual variant, criterion, row index, JSON pointer, property type/presence and parity results
- Successful V2 receipt qualifies feature equality as declared JSON parity and explicitly does not claim raw own-property equality with parsed JSON
- New measured run: `runs/baseline-v2/`
- Same reviewed measured runner: `measured-command.py`, SHA256 `47957eda44fa4c4023767a7767ffe3bc2005a7c3e151731a2aa593e3beb646f3`; no wrapper changes

Metadata-only comparison confirms identical accepted inputs, expected counts/IDs, dependencies, invariants, registry packets, nested-storage descriptors and runtime/source boundary. The original 405 cars, 27,945 features, 14 Research fields, 19 packets, seven selected cars, 483 selected rows and eVito invariants are unchanged. This is a static comparison of manifests, not a new execution result.

## Independent review before any retry

- Verify the V1 failure and retained old artifact pins; do not reinterpret it as a passing extraction
- Inspect the entire static adapter diff. The sole deletion must target the comparison clone, never the live row or stored expectation
- Confirm manifest allowance scope is exactly the five conditions above and that it contains no expected count
- Trace every unsupported JSON type and every extra/missing field through a failing guard or full comparison. Pay particular attention to undefined arrays, own symbol keys, sparse arrays, accessors and non-finite numbers
- Confirm complete deep equality follows only the narrow clone deletion, and exact whole-array plus JSONL serialization equality is still mandatory
- Confirm raw live feature snapshots retain own-undefined properties before and after all consumer calls and output serialization
- Confirm actual audit records are generated only at runtime; no unobserved selected-row claim is prefilled
- Confirm all V1 pins remain present, baseline/source inputs are unchanged, output/run folders are new and exclusive, and the measured wrapper hash is unchanged
- Confirm the source checks, complete nested storage checks, all-feature verification, 14-field preservation, report parity, cargo invariant, original registry/source-transition proofs and receipt-last logic were not weakened
- Do not run syntax checks, tests, imports, hydration or extraction while reviewing

The V2 approval uses the same status and fields as V1, and additionally must contain `featureParity` exactly equal to the new manifest object and `previousAttemptManifestSha256` equal to `bdcedddcbac5e2090efe423fc640a97975dcd3746ab10db916244ea7d5b7230d`. This binds the specific permission, not a broad normalization exception. Static approval does not grant the heavy slot.

## Exact proposed retry command

Manifest SHA256: `536815e286386fb3907056c4936d156e1eb232424c64485bfeff4a50648dbf06` (141,569 bytes)

Adapter SHA256: `fd20a9f77517856106114929c52e84e3cd99295f941975d9ef65de96b3f15271` (24,514 bytes)

The independent reviewer must create `reviews/baseline-v2.json` and supply its SHA256. It does not exist yet. With a new explicit root grant only:

```sh
cd /workspace/scratch/586427eef9f2/roadmark-104
python3 /tmp/mercedes-staging-plan/baseline-preparation/measured-command.py \
  /tmp/mercedes-staging-plan/baseline-preparation/runs/baseline-v2 180 \
  node --expose-gc --max-old-space-size=448 --max-semi-space-size=1 --import tsx \
  /tmp/mercedes-staging-plan/baseline-preparation/extract-reviewed-baseline-v2.mjs \
  --manifest /tmp/mercedes-staging-plan/baseline-preparation/baseline-manifest-v2.json \
  --manifest-sha256 536815e286386fb3907056c4936d156e1eb232424c64485bfeff4a50648dbf06 \
  --review /tmp/mercedes-staging-plan/baseline-preparation/reviews/baseline-v2.json \
  --review-sha256 "${REVIEW_V2_SHA256:?Independent V2 approval SHA256 required}"
```

No execution occurred while preparing this correction. A further difference must fail closed and be reported from the preserved attempt; it must not trigger automatic allowance expansion, source-pin refresh, wrapper change, canonical recapture or unapproved retry.
