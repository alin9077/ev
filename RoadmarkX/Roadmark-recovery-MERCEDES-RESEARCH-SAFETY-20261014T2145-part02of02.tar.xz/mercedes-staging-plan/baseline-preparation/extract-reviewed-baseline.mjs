/**
 * Generic, read-only adapter over the accepted recursive storage reader.
 * STATIC DRAFT: never executed. Separate independent review and root heavy-slot
 * authorization are required. All brand selection and input pins are manifest data.
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';

const argv = process.argv.slice(2), args = {};
const names = ['--manifest', '--manifest-sha256', '--review', '--review-sha256'];
assert.equal(argv.length, names.length * 2);
for (let i = 0; i < argv.length; i += 2) {
  assert(names.includes(argv[i]) && !Object.hasOwn(args, argv[i]));
  assert(argv[i + 1] && !argv[i + 1].startsWith('--'));
  args[argv[i]] = argv[i + 1];
}
for (const name of names) assert(Object.hasOwn(args, name));
const hash = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
for (const name of ['--manifest', '--review']) {
  assert.equal(path.resolve(args[name]), args[name]);
  assert.equal(fs.realpathSync(args[name]), args[name]);
  assert.equal(hash(args[name]), args[name + '-sha256']);
}
const manifest = JSON.parse(fs.readFileSync(args['--manifest'], 'utf8'));
const review = JSON.parse(fs.readFileSync(args['--review'], 'utf8'));
const { anchors, expected, dependencies } = manifest;
assert.equal(manifest.schemaVersion, 1);
assert.equal(manifest.mode, 'read-only-reviewed-derived-baseline');
assert.equal(review.status, 'approved_for_read_only_reviewed_baseline_extraction');
assert.equal(review.manifestSha256, args['--manifest-sha256']);
assert.equal(review.noProductionSemanticChanges, true);
assert.equal(review.canonicalCaptureAuthorized, false);
assert.equal(review.sourceInventorySha256, manifest.accepted.registeredSourceInventory.sha256);
assert.deepEqual(review.driverPin, manifest.driverPin);
assert.deepEqual(review.dependencyPins, dependencies);
assert.equal(manifest.execution.requiresSeparateRootHeavySlotGrant, true);
assert.equal(manifest.output.exclusiveCreation, true);
assert.equal(manifest.output.neverOverwriteOrDeletePriorAttempt, true);
assert(Object.hasOwn(anchors, manifest.output.anchor));
assert(!path.isAbsolute(manifest.output.directory) && !manifest.output.directory.includes('\\'));
assert(manifest.output.directory.split('/').every(part => part && part !== '.' && part !== '..'));
assert(!fs.existsSync(path.join(anchors[manifest.output.anchor], manifest.output.directory)), 'Prior output is never reused');
assert.equal(process.cwd(), anchors.repo);
assert.equal(process.version, manifest.runtime.nodeVersion);
assert.equal(typeof global.gc, 'function');

// Bootstrap only the explicitly pinned existing IO module. It has no top-level I/O.
function bootstrapPath(ref) {
  assert(Object.hasOwn(anchors, ref.anchor));
  const root = anchors[ref.anchor];
  assert.equal(path.resolve(root), root); assert.equal(fs.realpathSync(root), root);
  assert(!path.isAbsolute(ref.file) && !ref.file.includes('\\'));
  assert(ref.file.split('/').every(part => part && part !== '.' && part !== '..'));
  const file = path.resolve(root, ref.file);
  assert(file.startsWith(root + path.sep)); assert.equal(fs.realpathSync(file), file);
  assert(fs.statSync(file).isFile()); assert.equal(fs.statSync(file).size, ref.bytes);
  assert.equal(hash(file), ref.sha256); return file;
}
assert.equal(bootstrapPath(manifest.driverPin), fileURLToPath(import.meta.url));
const io = await import(pathToFileURL(bootstrapPath(dependencies.io)).href);
const {
  readJson, fileHash, locate, pin, verifyPins, digestRows, expectedDigest,
  streamRows, readResearch, assertResearchUnchanged, sourceNames,
  newDirectory, writeNewJson, inventoryChanges,
} = io;
const pins = new Map(manifest.inputPins.map(ref => [locate(anchors, ref), ref]));
assert.equal(pins.size, manifest.inputPins.length);
function assertPinned(ref) {
  const declared = pins.get(locate(anchors, ref)); assert(declared, 'Missing reviewed input pin');
  assert.equal(declared.sha256, ref.sha256); assert.equal(declared.bytes, ref.bytes);
}
for (const ref of [manifest.driverPin, ...Object.values(dependencies), ...Object.values(manifest.accepted)]) assertPinned(ref);
for (const row of manifest.retainedRegistrationBefore) assertPinned(row.input);
const inventory = readJson(locate(anchors, manifest.accepted.registeredSourceInventory));
assert.equal(inventory.files.length, expected.registeredSourceFiles);
assert.equal(new Set(inventory.files.map(row => row.file)).size, inventory.files.length);
for (const ref of inventory.files) assertPinned({ anchor: 'repo', ...ref });
function verify() {
  assert.equal(hash(args['--manifest']), args['--manifest-sha256']);
  assert.equal(hash(args['--review']), args['--review-sha256']);
  assert.deepEqual(sourceNames(anchors.repo), inventory.files.map(row => row.file).sort());
  verifyPins(anchors, manifest.inputPins);
}
verify();

const accepted = Object.fromEntries(Object.entries(manifest.accepted).map(([key, ref]) => [key, readJson(locate(anchors, ref))]));
const index = accepted.storageIndex, featureIndex = accepted.featureIndex, gate = accepted.finalGate;
assert.equal(index.asOf, manifest.asOf); assert.equal(index.cars.rows, expected.cars);
assert.equal(featureIndex.asOf, manifest.asOf); assert.equal(featureIndex.cars, expected.cars);
assert.equal(featureIndex.features.rows, expected.featureRows);
assert.equal(featureIndex.coreReceiptSha256, manifest.accepted.coreReceipt.sha256);
assert.equal(accepted.coreReceipt.storageIndex.sha256, manifest.accepted.storageIndex.sha256);
assert.equal(index.packetSha256, featureIndex.packetSha256);
assert.equal(gate.registeredPacket.sha256, index.packetSha256);
assert.equal(gate.status, manifest.acceptancePredicates.finalGateStatus);
assert.equal(gate.registered, true); assert.equal(gate.scope.catalogue, expected.cars);
assert.equal(gate.scope.registeredPackets, expected.registeredPackets);
assert.equal(gate.freshNormalCoverageEntireJsonAndBytesPassed, true);
assert.equal(accepted.registrationReview.registeredInventory.sha256, manifest.accepted.registeredSourceInventory.sha256);
assert.equal(accepted.registrationReview.rootTransition.sha256, manifest.accepted.registrationTransition.sha256);
assert.deepEqual(accepted.registrationReview.changes, manifest.expectedRegistrationChanges);
assert.deepEqual(inventoryChanges(accepted.preRegistrationSourceInventory, inventory), manifest.expectedRegistrationChanges);
assert.equal(accepted.registrationReview.preRegistrationInventory.sha256, manifest.accepted.preRegistrationSourceInventory.sha256);
const actualTransition = [
  ...accepted.registrationTransition.changed.map(row => ({ file: row.path, beforeSha256: row.beforeSha256, afterSha256: row.afterSha256 })),
  ...accepted.registrationTransition.newFiles.map(row => ({ file: row.path, beforeSha256: null, afterSha256: row.sha256 })),
].sort((a, b) => a.file.localeCompare(b.file));
assert.deepEqual(actualTransition, manifest.expectedRegistrationChanges);
for (const row of manifest.retainedRegistrationBefore) {
  const change = manifest.expectedRegistrationChanges.find(value => value.file === row.file); assert(change);
  assert.equal(row.input.sha256, change.beforeSha256); pin(anchors, row.input);
}
for (const key of manifest.acceptancePredicates.registrationReviewTrueFields) assert.equal(accepted.registrationReview[key], true);
assert.equal(accepted.registrationAddendum.registrationTransition.sha256, manifest.accepted.registrationTransition.sha256);
assert.equal(accepted.registrationAddendum.handover.sha256, manifest.accepted.handover.sha256);
assert.equal(accepted.registrationAddendum.currentRegisteredState, true);

// Historical full-report parity is rechecked byte-for-byte. This is not a new CLI run.
const parity = accepted.registeredReportParity;
assert.equal(parity.status, manifest.acceptancePredicates.reportParityStatus);
assert.equal(parity.wholeBytesExactlyEqual, true); assert.equal(parity.wholeJsonExactlyEqual, true);
assert.equal(parity.normalizationFilteringOrExpectedRegeneration, false);
assert.equal(parity.terminal.exitCode, 0); assert.equal(parity.terminal.signal, null);
assert.equal(parity.originalStagedReport.sha256, manifest.accepted.completeReport.sha256);
assert.equal(parity.actualNormalCoverageArtifacts['stdout.log'].sha256, manifest.accepted.registeredReport.sha256);
assert.equal(gate.registeredWholeReport.sha256, manifest.accepted.completeReport.sha256);
assert.equal(gate.registeredWholeReport.entireOriginalStagedBytesAndJsonExactlyEqual, true);
assert.equal(gate.registeredWholeReport.normalizationOrFiltering, false);
assert.deepEqual(fs.readFileSync(locate(anchors, manifest.accepted.completeReport)), fs.readFileSync(locate(anchors, manifest.accepted.registeredReport)));
assert.deepEqual(accepted.completeReport, accepted.registeredReport);
assert.equal(accepted.completeReport.asOf, manifest.asOf);
assert.equal(accepted.completeReport.allCatalogueVersions, expected.cars);

// Invoke only the generic export. The historical readCompleteBaseline wrapper is not used.
const { readCompleteCars } = await import(pathToFileURL(bootstrapPath(dependencies.storageReader)).href);
const proof = { anchors, manifest, assertPinned };
const { cars } = await readCompleteCars(proof, manifest.accepted.storageIndex);
assert.equal(cars.length, expected.cars);
const carDigests = cars.map(car => ({ id: car.id, brand: car.brand, ...digestRows([car]) }));
assert.deepEqual(cars.map(car => car.id), index.cars.carHashes.map(row => row.id));
const selectedIds = new Set(expected.selectedIds);
assert.equal(selectedIds.size, expected.selectedIds.length);
const selected = cars.filter(car => selectedIds.has(car.id));
assert.deepEqual(selected.map(car => car.id), expected.selectedIds);
assert(selected.every(car => car.brand === expected.brand && expected.allowedVehicleClasses.includes(car.vehicleClass ?? 'passenger')));
assert.deepEqual(cars.filter(car => car.brand === expected.brand && expected.allowedVehicleClasses.includes(car.vehicleClass ?? 'passenger')).map(car => car.id), expected.selectedIds);
for (const invariant of manifest.invariants) {
  assert(!selectedIds.has(invariant.id));
  const car = cars.find(row => row.id === invariant.id); assert(car);
  assert.equal(car.brand, invariant.brand);
  assert.deepEqual(digestRows([car]), invariant.carDigest);
}
for (const ref of Object.values(index.research)) assertPinned(ref);
const data = await readResearch(anchors, index, expected.researchFields);
assert.equal(Object.keys(data).length, expected.researchFields.length);
assert.equal(data.criteria.length, expected.criteria);
assert.equal(new Set(data.criteria.map(row => row.key)).size, expected.criteria);
assert.equal(data.variants.length, expected.cars);
assert.deepEqual(data.variants.map(row => row.id), cars.map(car => car.id));
assertResearchUnchanged(data, index);
const registry = readJson(locate(anchors, manifest.registry));
const beforeRegistry = readJson(locate(anchors, manifest.retainedRegistrationBefore.find(row => row.file === manifest.registry.file).input));
assert.deepEqual(registry.packets.slice(0, beforeRegistry.packets.length), beforeRegistry.packets);
assert.deepEqual(registry.packets, manifest.registeredPackets.map(row => row.name));
assert.equal(registry.packets.length, expected.registeredPackets);
const packets = manifest.registeredPackets.map(row => {
  assertPinned(row.input); const packet = readJson(locate(anchors, row.input));
  assert.equal(packet.id, row.id); return packet;
});
assert.deepEqual(data.metadata.brand_update_packet_ids, packets.map(packet => packet.id));

// Verify every accepted output feature row, without rebuilding a 405-car catalogue.
assertPinned(featureIndex.features);
assert.deepEqual(featureIndex.perCar.map(row => row.id), cars.map(car => car.id));
assert.equal(featureIndex.perCar.length, expected.cars);
const storedSelected = new Map(), allFeatureChecks = []; let block = [];
await streamRows(anchors, featureIndex.features, (feature, ordinal) => {
  const carOrdinal = Math.floor(ordinal / expected.criteria), car = cars[carOrdinal]; assert(car);
  assert.equal(feature.variant_id, car.id); block.push(feature);
  if (block.length !== expected.criteria) return;
  const row = featureIndex.perCar[carOrdinal], digest = digestRows(block);
  assert.equal(row.ordinal, carOrdinal); assert.equal(row.id, car.id);
  assert.equal(row.carSha256, carDigests[carOrdinal].sha256); assert.equal(row.carBytes, carDigests[carOrdinal].bytes);
  assert.deepEqual(digest, { rows: row.featureRows, bytes: row.featureBytes, sha256: row.featureSha256 });
  assert.equal(new Set(block.map(value => value.criterion)).size, expected.criteria);
  assert.deepEqual(block.map(value => value.criterion).sort(), data.criteria.map(value => value.key).sort());
  allFeatureChecks.push({ id: car.id, ordinal: carOrdinal, ...digest });
  if (selectedIds.has(car.id)) storedSelected.set(car.id, block);
  const invariant = manifest.invariants.find(value => value.id === car.id);
  if (invariant) assert.deepEqual(digest, invariant.featureDigest);
  block = [];
});
assert.equal(block.length, 0); assert.equal(allFeatureChecks.length, expected.cars);

// Production consumers receive explicit, proved inputs. No default loader or shim.
const require = createRequire(path.join(anchors.repo, 'package.json'));
function assertNoHydrator() {
  for (const name of manifest.runtime.forbiddenImports) assert(!require.cache[path.join(anchors.repo, name)], 'Forbidden import: ' + name);
}
assertNoHydrator();
const { createEvidenceConsumers } = require('./' + manifest.runtime.consumerEntryPoint);
const { brandVersionSnapshot } = require('./' + manifest.runtime.versionGuardEntryPoint);
const { brandUpdatePackets } = require('./' + manifest.runtime.registryEntryPoint);
assert.deepEqual(brandUpdatePackets, packets); assertNoHydrator();
let defaultCalls = 0;
const forbidden = () => { defaultCalls++; throw new Error('Explicit reviewed baseline required; default loading forbidden'); };
const consumers = createEvidenceConsumers({ sourceResearch: forbidden, research: forbidden, catalogue: forbidden });
const snapshot = { data, cars }, packs = {}, facts = [], guards = [], actualFeatures = [];
for (const car of selected) {
  const pack = consumers.pack(car.id, snapshot);
  assert.deepEqual(pack.car, car);
  assert.deepEqual(pack.features, storedSelected.get(car.id), 'All accepted before feature values, no canonical substitution');
  packs[car.id] = pack; actualFeatures.push(...pack.features);
  guards.push({ variantId: car.id, before: brandVersionSnapshot(car) });
  for (const fact of Object.values(car.facts)) facts.push({ variantId: car.id, before: structuredClone(fact) });
  global.gc();
}
assert.equal(actualFeatures.length, expected.selectedFeatureRows); assert.equal(defaultCalls, 0);
function unchanged() {
  assertResearchUnchanged(data, index);
  assert.deepEqual(cars.map(car => ({ id: car.id, brand: car.brand, ...digestRows([car]) })), carDigests);
  assert.deepEqual(brandUpdatePackets, packets); assertNoHydrator(); verify();
}
unchanged();

// Exact original rows for authoring convenience, not a replacement full baseline.
const modelIds = new Set(selected.map(car => car.modelId));
const context = {
  schema_version: data.schema_version, metadata: data.metadata, criteria: data.criteria,
  sources: data.sources,
  models: data.models.filter(row => modelIds.has(row.id)),
  variants: data.variants.filter(row => selectedIds.has(row.id)),
  feature_evidence_variant_context: data.feature_evidence_variant_context.filter(row => selectedIds.has(row.id)),
  feature_evidence: data.feature_evidence.filter(row => selectedIds.has(row.variant_id)),
  trim_equipment: data.trim_equipment.filter(row => selectedIds.has(row.variant_id)),
  update_eligibility: data.update_eligibility.filter(row => selectedIds.has(row.variant_id)),
};
assert.deepEqual(context.variants.map(row => row.id), expected.selectedIds);
assert.equal(context.feature_evidence.length, expected.selectedFeatureRows);
assert.equal(context.feature_evidence_variant_context.length, selected.length);
const out = newDirectory(anchors[manifest.output.anchor], manifest.output.directory);
const artifacts = {};
const outputs = {
  'selected-complete-before-cars.json': selected,
  'actual-before-packs.json': packs,
  'actual-before-features.json': actualFeatures,
  'actual-before-facts.json': facts,
  'actual-before-version-guards.json': guards,
  'unchanged-original-research-context.json': context,
  'complete-car-verification.json': carDigests,
  'complete-feature-verification.json': allFeatureChecks,
  'complete-research-field-verification.json': Object.fromEntries(Object.entries(index.research).map(([key, ref]) => [key, expectedDigest(ref)])),
};
assert.deepEqual(Object.keys(outputs), manifest.output.artifactNames);
for (const [name, value] of Object.entries(outputs)) artifacts[name] = writeNewJson(out, name, value);
unchanged();
writeNewJson(out, manifest.output.receiptName, {
  schemaVersion: 1, status: 'passed_read_only_reviewed_derived_baseline_extraction',
  asOf: manifest.asOf, brand: expected.brand, lineage: manifest.lineage,
  manifestSha256: args['--manifest-sha256'], reviewSha256: args['--review-sha256'],
  completeCarsVerified: cars.length, completeFeatureRowsVerified: expected.featureRows,
  completeResearchFieldsVerifiedBeforeAndAfter: expected.researchFields,
  selectedIds: expected.selectedIds, actualFeatureRows: actualFeatures.length,
  fullOriginalFeatureRowEquality: true, allOtherCarsUnchanged: true,
  invariants: manifest.invariants, defaultLoaderCalls: defaultCalls,
  registeredSourceInventory: manifest.accepted.registeredSourceInventory,
  acceptedFinalRegistrationGate: manifest.accepted.finalGate,
  acceptedWholeReportByteAndJsonParityReverified: true,
  freshNormalCoverageCliExecuted: false, freshFullValueLoaderExport: false,
  sourceEdited: false, candidateCreated: false, metadataRepaired: false,
  canonicalCapturePerformed: false, fullTypecheckClaimed: false,
  productionBuildClaimed: false, publicationAuthorized: false,
  artifacts, resourceUsage: process.resourceUsage(), memoryUsage: process.memoryUsage(),
});
console.log('Read-only reviewed baseline extraction complete; no candidate or source change');
