"""Static, unexecuted adaptation of /tmp/xpeng-staging-plan/assemble-packet.py.

Reuse its manifest -> reviewed research -> exact actual-before -> packet flow.
This does not load production, hydrate cars, capture canonical fixtures, register
a packet, close a market review, or authorize its own execution. A separate root
grant is mandatory. All input pins and this driver must pass independent review.
"""
import argparse
import copy
import hashlib
import json
import re
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pin_shape(pin):
    require(isinstance(pin, dict), "Missing input pin")
    require(isinstance(pin.get("path"), str) and Path(pin["path"]).is_absolute(), "Absolute pinned path required")
    require(isinstance(pin.get("sha256"), str) and re.fullmatch(r"[0-9a-f]{64}", pin["sha256"]), "Unresolved SHA256 pin")
    require(type(pin.get("bytes")) is int and pin["bytes"] >= 0, "Unresolved byte count")


def contained(path, roots):
    p = Path(path).resolve()
    require(any(p.is_relative_to(root) for root in roots), "Path outside reviewed roots: " + str(p))
    return p


def strings(values, label, allow_empty=False):
    require(isinstance(values, list) and (allow_empty or values), label)
    require(all(isinstance(x, str) and x.strip() for x in values), label)
    require(len(values) == len(set(values)), "Duplicate " + label)
    return values


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("manifest")
    ap.add_argument("--manifest-sha256", required=True)
    ap.add_argument("--review", required=True)
    ap.add_argument("--review-sha256", required=True)
    a = ap.parse_args()
    mp = Path(a.manifest).resolve()
    require(mp.is_file() and sha(mp) == a.manifest_sha256, "Externally accepted manifest hash")
    mh = a.manifest_sha256
    m = json.loads(mp.read_text())
    require(m["schemaVersion"] == 1 and m["mode"] == "reviewed-brand-packet-assembly", "Wrong manifest")
    require(m["status"] == "frozen_pending_independent_review_and_explicit_root_grant", "Template is blocked; freeze exact inputs for independent review")
    require(m["phase"] in ["feature-free", "final"], "Unknown phase")
    input_roots = [Path(x).resolve() for x in strings(m["allowedInputRoots"], "input roots")]
    output_roots = [Path(x).resolve() for x in strings(m["allowedOutputRoots"], "output roots")]
    capture_roots = [Path(x).resolve() for x in strings(m["allowedCaptureRoots"], "capture roots")]
    require(all(any(r.is_relative_to(i) for i in input_roots) for r in capture_roots), "Capture root must be an input root")
    contained(mp, input_roots)

    def pinned(pin, roots=input_roots):
        pin_shape(pin)
        p = contained(pin["path"], roots)
        require(p.is_file() and p.stat().st_size == pin["bytes"] and sha(p) == pin["sha256"], "Changed pin: " + str(p))
        return p

    def read(pin):
        p = pinned(pin)
        if pin.get("format") == "jsonl":
            rows = [json.loads(line) for line in p.read_text().splitlines()]
            require(len(rows) == pin["rows"], "Complete JSONL row count")
            return rows
        require(pin.get("format", "json") == "json", "Unsupported input format")
        return json.loads(p.read_text())

    driver = pinned(m["assembler"])
    require(driver == Path(__file__).resolve(), "Wrong assembly driver")
    rp = contained(a.review, input_roots)
    require(rp.is_file() and sha(rp) == a.review_sha256, "Changed assembly review")
    assembly_review = json.loads(rp.read_text())
    require(assembly_review["status"] == m["acceptedStatuses"]["assemblyReview"], "Independent assembly review not accepted")
    require(assembly_review["manifestSha256"] == mh and assembly_review["assemblerSha256"] == m["assembler"]["sha256"], "Review binds different assembly")
    inputs = m["inputs"]
    data = read(inputs["normalized"])
    review = read(inputs["normalizationReview"])
    require(review["status"] == m["acceptedStatuses"]["normalizationReview"], "Research review not accepted")
    require(review["artifact"] == inputs["normalized"], "Research review binds different bytes")
    require(review["auxiliaryAudit"] == inputs["auxiliaryConsistencyAudit"], "Research review binds different legacy consistency audit")
    require(review["baselineAcceptance"] == inputs["baselineOutputReview"], "Research review binds different accepted before baseline")
    require(assembly_review["sourceCaptureManifestSha256"] == inputs["sourceCaptureManifest"]["sha256"], "Capture review mismatch")
    require(data.get("currentVersionReviews", []) == [], "C1/version closure is outside this assembly scope")
    require(data.get("versionUpdates", []) == [] and data.get("configurationUpdates", []) == [], "Additional mutation scope needs separate adapter review")
    D, PID, BRAND, REVIEWER = m["asOf"], m["packetId"], m["brand"], m["reviewedBy"]
    require(D == data["asOf"] and all(isinstance(x, str) and x.strip() for x in [D, PID, BRAND, REVIEWER]), "Packet identity")
    expected = m["expected"]
    require(len(data["variants"]) == expected["versions"], "Version count")
    ids = strings([v["id"] for v in data["variants"]], "normalized version IDs")
    require(ids == m["versionIds"], "Normalized version order changed")
    existing_ids = strings(m["existingIds"], "existing IDs")
    new_ids = strings(m["newIds"], "new IDs", allow_empty=True)
    require(set(existing_ids).isdisjoint(new_ids) and set(ids) == set(existing_ids + new_ids), "Population partition")
    require(len(existing_ids) == expected["existingVersions"] and len(new_ids) == expected["newVersions"], "Population counts")
    require(set(ids).isdisjoint(m["invariantIds"]), "Invariant car targeted")

    # Same XPENG actual-before selection, now from the accepted generic receipt.
    receipt = read(inputs["baselineReceipt"])
    baseline_manifest = read(inputs["baselineManifest"])
    baseline_review = read(inputs["baselineOutputReview"])
    require(receipt["status"] == m["acceptedStatuses"]["baselineReceipt"], "Baseline receipt not passed")
    require(baseline_review["status"] == m["acceptedStatuses"]["baselineOutputReview"], "Baseline outputs not accepted")
    require(baseline_review["extractionReceipt"] == inputs["baselineReceipt"], "Baseline review binds different receipt bytes")
    require(baseline_review["manifest"] == inputs["baselineManifest"], "Baseline review binds different extraction manifest")
    require(receipt["manifestSha256"] == inputs["baselineManifest"]["sha256"], "Baseline manifest mismatch")
    require(receipt["asOf"] == D and receipt["brand"] == BRAND, "Baseline scope/date")
    require(receipt["completeCarsVerified"] == expected["baselineCars"], "Full baseline car count")
    require(receipt["completeFeatureRowsVerified"] == expected["baselineFeatureRows"], "Full baseline feature count")
    require(receipt["actualFeatureRows"] == expected["existingFeatureRows"], "Selected feature count")
    require(receipt["selectedIds"] == existing_ids, "Selected before order")
    for key in m["baselineReceiptTrueFields"]:
        require(receipt[key] is True, "Unproved baseline property: " + key)
    for key in m["baselineReceiptFalseFields"]:
        require(receipt[key] is False, "Unexpected baseline claim: " + key)
    require(receipt["defaultLoaderCalls"] == 0 and receipt["sourceEdited"] is False and receipt["canonicalCapturePerformed"] is False, "Unexpected baseline side effect")
    baseline = {}
    artifact_names = {
        "cars": "selected-complete-before-cars.json",
        "features": "actual-before-features.json",
        "guards": "actual-before-version-guards.json",
        "context": "unchanged-original-research-context.json",
        "researchFieldVerification": "complete-research-field-verification.json",
        "featureParityAudit": "before-feature-json-parity-audit.json",
    }
    for key, name in artifact_names.items():
        require(inputs[key] == receipt["artifacts"][name], "Input must be exact accepted receipt artifact: " + key)
        require(inputs[key] == baseline_review["artifacts"][name], "Baseline artifact not independently accepted: " + key)
        baseline[key] = read(inputs[key])
    cars = baseline["cars"]
    old = {c["id"]: c for c in cars}
    old_ids = set(old)
    require(len(old) == len(cars) == expected["existingVersions"], "Existing before population")
    require([c["id"] for c in cars] == existing_ids, "Existing before order")
    require(all(c["brand"] == BRAND and c.get("vehicleClass", "passenger") in m["allowedVehicleClasses"] for c in cars), "Wrong before brand/tier")
    require(len(baseline["features"]) == expected["existingFeatureRows"], "Actual before features")
    require([g["variantId"] for g in baseline["guards"]] == existing_ids, "Actual guard order")
    require(baseline["featureParityAudit"]["policy"] == receipt["featureParityPolicy"] == baseline_manifest["featureParity"], "Exact declared before-feature JSON parity policy changed")
    require(baseline["featureParityAudit"]["observed"] == receipt["featureParityAudit"], "Before-feature omission observations changed")
    # The projected convenience context is NOT a complete model census. Read
    # only the separately pinned complete models JSONL, after baseline acceptance.
    complete_models = read(inputs["completeModels"])
    models_pin = inputs["completeModels"]
    require({k: models_pin[k] for k in ["rows", "bytes", "sha256"]} == baseline["researchFieldVerification"]["models"], "Models differ from successful full-field verification")
    model_ids = {row["id"] for row in complete_models}
    require(len(model_ids) == len(complete_models), "Duplicate complete model IDs")
    new_model_ids = strings(m["newModelIds"], "reviewed new model IDs", allow_empty=True)
    proposed_new_models = list(dict.fromkeys(row["modelId"] for row in data["variants"] if row["id"] in new_ids and row["modelId"] not in model_ids))
    require(proposed_new_models == new_model_ids, "New model decisions disagree with complete accepted models field")
    require(baseline_review["checks"]["all14ResearchFieldDescriptorsEqualAcceptedStorageIndex"] is True, "Complete models descriptor was not independently accepted")

    packet = dict(schemaVersion=1, id=PID, brand=BRAND, reviewedAt=D, reviewedBy=REVIEWER,
                  sources=[], models=[], variants=[], versionGuards=copy.deepcopy(baseline["guards"]),
                  versionUpdates=[], facts=[], features=[], brandTerms=[], availability=[], summaries=[])
    terms = data.get("brandTerms", {})
    require(isinstance(terms, dict), "brandTerms must be an explicit keyed object when supplied")
    support_keys = set()
    for row in data["variants"]:
        support_keys.update(strings(row["availability"]["sourceKeys"], "availability source keys"))
        for fact in row["facts"]:
            support_keys.update(strings(fact["sourceKeys"], "fact source keys"))
    for term in terms.values():
        support_keys.update(strings(term["sourceKeys"], "term source keys"))
    source_rows = {s["key"]: s for s in data["sources"]}
    require(len(source_rows) == len(data["sources"]) and support_keys <= set(source_rows), "Unknown or duplicate source keys")
    require(support_keys == set(m["packetSourceKeys"]), "Reviewed packet source selection changed")
    require(set(source_rows) - support_keys == set(m["auditOnlySourceKeys"]), "Excluded provenance not accounted for")
    captures = read(inputs["sourceCaptureManifest"])
    require(captures["schemaVersion"] == 1 and captures["normalizedEvidenceSha256"] == inputs["normalized"]["sha256"], "Capture manifest binds different research")
    accepted_captures = captures["captures"]
    capture_map = {(c["sourceKey"], c["normalizedField"], c["originalPath"]): c for c in accepted_captures}
    require(len(capture_map) == len(accepted_captures), "Duplicate capture identity")
    seen_captures, capture_pins, sources = set(), [], {}

    def capture(key, field, original, purpose):
        original_path = str(Path(original).resolve())
        identity = (key, field, original_path)
        require(identity in capture_map, "Unreviewed source capture: " + repr(identity))
        pin = capture_map[identity]
        f = pinned(pin, capture_roots)
        if f != Path(original_path):
            # Copies may only be accepted when both exact-byte origins and
            # destination are retained. No reconstructed missing originals.
            require(pin.get("copyProvenance", {}).get("method") == "exact-byte-copy", "Unreviewed capture relocation")
            origin = pin["copyProvenance"]["original"]
            require(origin["path"] == original_path and origin["sha256"] == pin["sha256"] and origin["bytes"] == pin["bytes"], "Copy is not exact-byte provenance")
            pinned(origin, capture_roots)
        require(isinstance(pin.get("locator"), str) and pin["locator"].strip(), "Reviewed capture locator required")
        seen_captures.add(identity)
        capture_pins.append({k: pin[k] for k in ["path", "sha256", "bytes"]})
        return dict(locator=pin["locator"], sha256=pin["sha256"], bytes=pin["bytes"], purpose=purpose)

    for row in data["sources"]:
        key = row["key"]
        if key not in support_keys:
            continue
        require(row["source_type"] not in m["forbiddenPacketSourceTypes"], "Audit/failure source cannot be packet support: " + key)
        require(not row.get("access_limitation") and not row.get("publication_hold"), "Unusable source: " + key)
        s = dict(id=PID + "-" + key, url=row["url"], title=row["title"], publisher=row["publisher"],
                 source_type=row["source_type"], published_date=row.get("published_date"),
                 accessed_date=row.get("checkedOn", D), market=row.get("market", "AU"), supports=row.get("supports", row["title"]))
        for k in ["notes", "capture_section", "retrievalMethod", "retrievalLimitations", "sourceOriginMarket", "visualReview", "conflict", "access_limitation", "publication_hold"]:
            if k in row:
                s[k] = copy.deepcopy(row[k])
        retained = []
        for field, purpose in [("file", "Public source capture"), ("factualStateFile", "Whitelisted public exact-version configuration facts"), ("textFile", "Extracted public document text")]:
            if row.get(field):
                retained.append(capture(key, field, row[field], purpose))
        for i, cap in enumerate(row.get("supplementaryCaptures", [])):
            retained.append(capture(key, "supplementaryCaptures/" + str(i), cap["path"], cap["purpose"]))
        require(retained, "Source has no reviewed capture: " + key)
        main_capture = next((c for c in accepted_captures if c["sourceKey"] == key and c["normalizedField"] == "file"), None)
        if main_capture and "sha256" in row:
            require(row["sha256"] == main_capture["sha256"] and row["bytes"] == main_capture["bytes"], "Normalized capture pin changed: " + key)
        s["capture_locator"], s["capture_sha256"], s["retainedCaptures"] = retained[0]["locator"], retained[0]["sha256"], retained
        sources[key] = s
        packet["sources"].append(s)
    require(seen_captures == set(capture_map), "Every accepted support capture must be used exactly; no silent repinning")
    require(len(packet["sources"]) == expected["sources"], "Source count")

    added_models = set()
    for row in data["variants"]:
        if row["id"] in old_ids:
            continue
        mid, gen, av = row["modelId"], row["generation"], row["availability"]
        source_ids = [sources[k]["id"] for k in av["sourceKeys"]]
        if mid in new_model_ids and mid not in added_models:
            packet["models"].append(dict(id=mid, brand=BRAND, model=row["model"], generation=gen, family_id=row.get("familyId", mid.replace("_", "-"))))
            added_models.add(mid)
        require(row["vehicleClass"] in m["allowedVehicleClasses"], "New version outside allowed tier")
        v = dict(id=row["id"], model_id=mid, brand=BRAND, model=row["model"], trim=row["trim"], model_year=row["modelYear"],
                 record_state=av["state"], variant_review_date=D, source_ids=source_ids, notes=row.get("notes", []),
                 price_basis="", range_cycle="", price_aud=None, range_km=None, seats=None,
                 vehicle_class=row["vehicleClass"], drive=row["drive"], brand_update_generation=gen)
        packet["variants"].append(v)
        # Same narrow projection of unchanged production newVariantCar as XPENG.
        # This is NOT a captured actual-before fixture. Production application must
        # validate it before the separately granted one-time canonical capture.
        old[v["id"]] = dict(id=v["id"], modelId=mid, brand=BRAND, model=v["model"], trim=v["trim"], year=v["model_year"],
                            generation=gen, vehicleClass=v["vehicle_class"], drive=v["drive"], availability=v["record_state"],
                            availabilityEvidence=dict(checkedAt=D, orderStatus="unverified", stockStatus="unverified", sourceIds=source_ids,
                                                      qualifications=["Physical stock and factory-order acceptance have not been verified."]), facts={})
    require([v["id"] for v in packet["variants"]] == new_ids, "New ID order")
    require([v["id"] for v in data["variants"] if v["id"] in old_ids] == existing_ids, "Existing research order")
    require(added_models == set(new_model_ids) and len(packet["models"]) == expected["newModels"], "New model decisions")
    effective = {id: {} for id in ids}

    def make_fact(car, rf):
        k, grade = rf["key"], rf["grade"]
        require(grade in ["confirmed", "check", "reported", "not_published"], "Unknown grade")
        meta = m["factMetadata"][k]
        source_ids = [sources[x]["id"] for x in rf["sourceKeys"]]
        basis = rf.get("basis", meta["basis"])
        comparison = rf.get("comparison", "")
        require(isinstance(basis, str) and basis.strip() and isinstance(comparison, str), "Unresolved fact basis: " + car["id"] + "/" + k)
        if grade in m["unrankedGrades"]:
            require(comparison == "" and rf.get("rankingEligible", False) is False, "Unranked grade was made comparable")
        if rf.get("rankingEligible") is False:
            require(comparison == "", "Explicitly unranked value has a comparable basis")
        scope = rf.get("evidenceScope") or ("secondary_or_sibling" if grade == "reported" else "searched_not_found" if grade == "not_published" else "exact_au_version")
        reason = rf.get("reason", m["gradeReasons"][grade])
        require(isinstance(reason, str) and reason.strip(), "Review reason missing")
        f = dict(key=k, label=rf.get("label", meta["label"]), value=rf["value"], unit=rf.get("unit", meta["unit"]),
                 basis=basis, comparisonBasis=comparison, status={"confirmed": "standard", "check": "conditional", "reported": "conditional", "not_published": "not_verified"}[grade],
                 sourceIds=source_ids, date=D, market="AU", scope=rf.get("scope", BRAND + " " + car["model"] + " " + car["trim"]),
                 qualifications=copy.deepcopy(rf.get("qualifications", [])), issues=[], buyerGrade=grade,
                 gradeReview=dict(reviewedAt=D, overlayId=PID, reason=reason, evidenceScope=scope, sourceIds=source_ids,
                                  sourceLabel=" / ".join(dict.fromkeys(sources[x]["publisher"] for x in rf["sourceKeys"]))))
        if rf.get("condition"):
            f["conditionExplanation"] = rf["condition"]
        if grade == "check":
            require(bool(f.get("conditionExplanation")), "Check needs a concrete condition")
        if grade == "not_published":
            require(f["value"] is None, "Not published requires actual null")
            f["conditionExplanation"] = reason
        if grade == "reported":
            f["resolvedElsewhere"] = True
        for key in ["validUntil", "roadsideFitment", "modelYearChangedAt"]:
            if key in rf:
                f[key] = rf[key]
        if k == "price_aud" and f["value"] is not None:
            rung = rf["priceRung"]
            # No inference from "government charges excluded" to before-ORC.
            eligible = rf["rankingEligible"]
            require(type(eligible) is bool and (comparison or not eligible), "Price ranking basis")
            f["priceEvidence"] = dict(rung=rung, basisTag=rf["basisTag"], sourceKey=k, sourcePointer=sources[rf["sourceKeys"][0]]["url"],
                                      originalBasis=rf.get("originalBasis", basis), rankingEligible=eligible)
            if rung >= 5:
                require(grade == "reported", "Secondary price grade")
                f["priceEvidence"]["publisher"] = sources[rf["sourceKeys"][0]]["publisher"]
            if rung == 4:
                f["priceEvidence"]["state"] = rf["state"]
        return f

    # No brand programme, exceptions or feature answers are copied from XPENG.
    for key, term in terms.items():
        applicable = strings(term["applicableVariantIds"], "term IDs")
        exceptions = term["exceptions"]
        exception_ids = strings([x["variantId"] for x in exceptions], "term exception IDs", allow_empty=True)
        require(set(applicable).isdisjoint(exception_ids) and set(applicable + exception_ids) == set(ids), "Term must account for all selected brand versions")
        f = make_fact(old[applicable[0]], term)
        require(f["key"] == key and f["gradeReview"]["evidenceScope"] == "brand_au_terms", "Explicit reviewed term scope required")
        packet["brandTerms"].append(dict(key=key, fact=f, applicableVariantIds=applicable,
                                         before={id: copy.deepcopy(old[id]["facts"].get(key)) for id in applicable}, exceptions=copy.deepcopy(exceptions)))
        for id in applicable:
            effective[id][key] = f
    for row in data["variants"]:
        car = old[row["id"]]
        for rf in row["facts"]:
            key = rf["key"]
            require(key not in effective[car["id"]], "Duplicate per-version/shared fact")
            f = make_fact(car, rf)
            effective[car["id"]][key] = f
            packet["facts"].append(dict(variantId=car["id"], before=copy.deepcopy(car["facts"].get(key)), after=f))
        av = row["availability"]
        source_ids = [sources[k]["id"] for k in av["sourceKeys"]]
        require("availabilityEvidence" in car, "Actual availability before missing; do not manufacture it")
        packet["availability"].append(dict(id=PID + "-availability-" + car["id"], variantId=car["id"],
            before=dict(availability=car["availability"], evidence=copy.deepcopy(car["availabilityEvidence"])),
            after=dict(availability=av["state"], evidence=dict(checkedAt=D, orderStatus=av["orderStatus"], stockStatus=av["stockStatus"],
                sourceIds=source_ids, physicalStockVerified=False, factoryOrderAcceptanceVerified=False, qualifications=copy.deepcopy(av["qualifications"]))),
            status="approved", reviewedBy=REVIEWER, reviewedAt=D, evidenceDate=D, reason=av["reason"]))

        def clause(x):
            keys = strings(x["keys"], "summary dependency keys")
            dependencies = [dict(key=k, expected=copy.deepcopy(effective[car["id"]][k])) for k in keys]
            require(all(d["expected"]["value"] is not None for d in dependencies), "Normalized summary has null dependency; obtain reviewed correction: " + car["id"])
            return dict(label=x["label"], text=x["text"], dependencies=dependencies)

        packet["summaries"].append(dict(variantId=car["id"], conditions=copy.deepcopy(row["summary"].get("conditions", [])),
                                         strength=clause(row["summary"]["strength"]), tradeoff=clause(row["summary"]["tradeoff"])))

    if m["phase"] == "final":
        canonical = read(inputs["canonicalPacket"])
        canonical_receipt = read(inputs["canonicalReceipt"])
        new_features = read(inputs["canonicalFeatures"])
        canonical_review = read(inputs["canonicalAcceptance"])
        require(canonical_review["status"] == m["acceptedStatuses"]["canonicalAcceptance"], "Original canonical capture not accepted")
        require(canonical_review["canonicalMeta"] == inputs["canonicalReceipt"] and canonical_review["canonicalOriginalPacket"] == inputs["canonicalPacket"]
                and canonical_review["canonicalOriginalNewFeatures"] == inputs["canonicalFeatures"], "Canonical acceptance binds different original bytes")
        require(canonical_receipt["generationCount"] == 1 and canonical_receipt["baselineGenerationCount"] == 1, "One-time original canonical capture required")
        require(packet == canonical, "Never alter the original feature-free canonical packet to make features pass")
        prior = baseline["features"] + new_features
        index = {(f["variant_id"], f["criterion"]): f for f in prior}
        require(len(index) == len(prior) == expected["allSelectedFeatureRows"], "Exact before/canonical feature population")
        for row in data["variants"]:
            for rf in row["features"]:
                criterion = rf["criterion"]
                before = index[(row["id"], criterion)]
                deps = [effective[row["id"]][k] for k in strings(rf["keys"], "feature dependency keys")]
                source_ids = list(dict.fromkeys(id for f in deps for id in f["sourceIds"]))
                grade = rf.get("grade") or ("reported" if any(f["buyerGrade"] == "reported" for f in deps) else "check" if any(f["buyerGrade"] == "check" for f in deps) else "confirmed")
                require(grade in ["confirmed", "check", "reported"], "Whole-row Not published feature needs separately reviewed criterion-specific handling")
                conditions = " ".join(dict.fromkeys(x for x in [rf.get("conditions"), *[f.get("conditionExplanation") for f in deps if f["buyerGrade"] == "check"]] if x))
                after = copy.deepcopy(before)
                for k in ["gradeReviewStatus", "confirmation_needed"]:
                    after.pop(k, None)
                after.update(value=rf["value"], status=rf.get("fitmentStatus", "standard" if grade == "confirmed" else "conditional"),
                    conditions=conditions, condition_label="Specific source/fitment condition" if conditions else "", source_ids=source_ids,
                    evidence_scope="Reviewed Australian " + BRAND + " " + row["model"] + " " + row["trim"], last_evidence_date=D,
                    reviewed_date=D, verification_state=m["featureVerificationState"], buyerGrade=grade,
                    gradeReview=dict(reviewedAt=D, overlayId=PID, reason="Reviewed equipment answer follows its exact post-packet facts and cited source scope.",
                        evidenceScope="secondary_or_sibling" if grade == "reported" else "exact_au_version", sourceIds=source_ids,
                        sourceLabel=" / ".join(dict.fromkeys(s["publisher"] for s in packet["sources"] if s["id"] in source_ids))))
                packet["features"].append(dict(variantId=row["id"], criterion=criterion, before=copy.deepcopy(before), after=after,
                                                dependencies=[dict(key=f["key"], expected=copy.deepcopy(f)) for f in deps]))
    require(len(packet["facts"]) == expected["facts"] and len(packet["brandTerms"]) == expected["brandTerms"], "Fact/term count")
    require(len(packet["features"]) == expected["features"] and len(packet["summaries"]) == expected["summaries"], "Feature/summary count")
    # Preserve the reviewed audit of retained legacy rows. Hashing this exact
    # audit convention never substitutes for, or changes, the full before fact.
    auxiliary_audit = read(inputs["auxiliaryConsistencyAudit"])
    require(auxiliary_audit["normalized"] == inputs["normalized"] and auxiliary_audit["acceptedBeforeCars"] == inputs["cars"], "Auxiliary audit binds different research/before cars")
    require(auxiliary_audit["baselineOutputAcceptance"] == inputs["baselineOutputReview"], "Auxiliary audit binds different baseline acceptance")
    require(auxiliary_audit["everyAcceptedBeforeFactAccountedFor"] is True, "Incomplete legacy fact audit")
    require(auxiliary_audit["hashConvention"] == "SHA256 of UTF-8 JSON with sorted keys, compact separators and ensure_ascii=false; original file pin is also retained.", "Unknown auxiliary audit digest convention")
    actual_before_facts = {(car["id"], key): fact for car in cars for key, fact in car["facts"].items()}
    audited_before_facts = {(row["variantId"], row["key"]): row for row in auxiliary_audit["beforeFacts"]}
    require(len(audited_before_facts) == len(auxiliary_audit["beforeFacts"]) and set(actual_before_facts) == set(audited_before_facts), "Every complete original fact must be audited exactly once")
    targeted = {(row["variantId"], row["after"]["key"]) for row in packet["facts"]}
    targeted.update((id, term["key"]) for term in packet["brandTerms"] for id in term["applicableVariantIds"])
    for identity, fact in actual_before_facts.items():
        row = audited_before_facts[identity]
        digest = hashlib.sha256(json.dumps(fact, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")).hexdigest()
        require(digest == row["beforeObjectSha256"] and fact["value"] == row["originalValue"] and fact["date"] == row["originalDate"]
                and fact["sourceIds"] == row["originalSourceIds"], "Original audited fact changed: " + repr(identity))
        if row["disposition"] == "dated_guarded_current_overlay":
            require(identity in targeted and row["newFactKey"] == identity[1], "Audited current fact has no exact guarded overlay")
        else:
            require(row["disposition"] in ["retain_dated_unresolved_research_unchanged", "retain_historical_identity_unchanged"], "Unknown preservation disposition")
            require(identity not in targeted, "Historical/retained fact must remain untouched: " + repr(identity))
    audited_summaries = {row["variantId"]: row for row in auxiliary_audit["summaries"]}
    require(len(audited_summaries) == len(auxiliary_audit["summaries"]) and set(audited_summaries) == old_ids, "Every original summary must be accounted for")
    normalized_by_id = {row["id"]: row for row in data["variants"]}
    for car in cars:
        row = audited_summaries[car["id"]]
        digest = hashlib.sha256(json.dumps(car.get("buyerSummary"), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")).hexdigest()
        require(digest == row["beforeObjectSha256"] and row["action"] == "replace_whole_summary", "Original summary audit changed")
        require(row["newSummary"] == normalized_by_id[car["id"]]["summary"], "New summary differs from reviewed complete replacement")
    audit = dict(normalizedEvidenceSha256=inputs["normalized"]["sha256"],
                 explanation="Retained normalized provenance, excluded from packet sources and grade support. Audit-only raw files were not independently rehashed by assembly.",
                 normalizedResearch=copy.deepcopy(data), packetSourceKeys=list(sources),
                 auxiliaryConsistencyAudit=copy.deepcopy(auxiliary_audit),
                 excludedSources=[copy.deepcopy(s) for s in data["sources"] if s["key"] not in support_keys],
                 currentVersionReviews=[], marketClosureAsserted=False)

    # Same recheck-before-exclusive-write discipline; no output hashes are guesses.
    for pin in inputs.values():
        read(pin)
    for pin in capture_pins:
        pinned(pin, capture_roots)
    pinned(m["assembler"])
    require(sha(mp) == mh and sha(rp) == a.review_sha256, "Manifest/review changed")
    paths = {key: contained(value, output_roots) for key, value in m["outputs"].items()}
    require(set(paths) == {"packet", "effectiveFacts", "provenanceAudit", "receipt"}, "Output contract")
    require(len(set(paths.values())) == len(paths), "Duplicate output paths")
    require(all(not p.exists() for p in paths.values()), "Exclusive outputs already exist")
    parents = {p.parent for p in paths.values()}
    require(len(parents) == 1 and not next(iter(parents)).exists(), "Every attempt needs a new exclusive output directory")

    def write_new(path, value):
        path.parent.mkdir(parents=True, exist_ok=True)
        require(contained(path, output_roots) == path, "Output parent changed")
        with path.open("x") as f:
            json.dump(value, f, indent=2, ensure_ascii=False)
            f.write("\n")
        return dict(path=str(path), sha256=sha(path), bytes=path.stat().st_size)

    outputs = {key: write_new(paths[key], value) for key, value in [("packet", packet), ("effectiveFacts", effective), ("provenanceAudit", audit)]}
    write_new(paths["receipt"], dict(status="assembled_pending_actual_function_validation", phase=m["phase"],
        manifestSha256=mh, assemblyReviewSha256=a.review_sha256, normalizedEvidenceSha256=inputs["normalized"]["sha256"],
        baselineReceiptSha256=inputs["baselineReceipt"]["sha256"], originalBeforeValuesUnchanged=True, outputs=outputs,
        auxiliaryConsistencyAuditSha256=inputs["auxiliaryConsistencyAudit"]["sha256"],
        capturePins=capture_pins, newIds=new_ids, counts=dict(versions=len(ids), newVersions=len(new_ids), sources=len(packet["sources"]),
            facts=len(packet["facts"]), brandTerms=len(packet["brandTerms"]), features=len(packet["features"]), summaries=len(packet["summaries"])),
        productionFunctionsExecuted=False, canonicalCapturePerformed=False, candidateRegistered=False, marketClosureAsserted=False))
    print(json.dumps(outputs, indent=2))


if __name__ == "__main__":
    main()
