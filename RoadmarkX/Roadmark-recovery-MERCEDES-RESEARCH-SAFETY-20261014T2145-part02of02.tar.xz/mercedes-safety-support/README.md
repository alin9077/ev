# Mercedes research safety increment

This frozen cut is pre-assembly, pre-canonical and unregistered. Normalized research v6 and the corrected baseline v2 have independent acceptance. The original baseline v1 failure, actual before objects, all normalized revision history, public warranty evidence and frozen packet adapters/manifests are retained. Static assembly review was still pending at this cutoff; later fixes and execution outputs are outside this cut.

No application source was recaptured or changed. Restore this increment over the exact saved XPENG registered-working chain, or use the combined recovery manifest and existing Roadmark-VERIFY-SAFE-RECOVERY-20261014.py into a new empty directory. The source remains libfile_664dd42cadcc8191b19f977c66ec71c2, version 0. Complete TypeScript, full-project suite, build, mobile and release gates remain open.

Exactly 372 research/review/static files, the frozen allowlist itself and four QA/status files are retained. The current work-status.json is the only existing-path overlay and matches its recorded before/after transition. No whole-QA scan or source recapture was performed. Active staging preparation and mutable explanatory drafts were excluded explicitly; they had no execution proof output in this cut.

The 45 historical Mercedes raw-capture paths were unavailable in the checkout and retained prior recovery chain. Current public captures have their own timestamps, URLs, hashes and failure provenance. They do not reconstruct or replace those missing historical original bytes. Historical citations and original hash expectations remain historical.

Privacy review redacted 51 runtime-value occurrences across eight copied raw captures: form/WordPress nonces, anti-bot challenge identifiers and capabilities, and public-site API capabilities. All original working files remain untouched. The explicit sanitation report records original and sanitized file hashes, locations and categories, without raw values or token digests. The copied raw-capture hashes differ; do not claim byte-equivalent recovery for these eight files. Accepted normalized evidence v6, corrected baseline acceptance and factual vehicle content remain unchanged.

A generic authorization-key sanitizer initially matched a reviewer scope-limitation sentence. Independent review confirmed it was benign prose. That file is preserved byte-for-byte; the unchanged scanner’s raw candidate is retained and classified only by exact path, whole-file hash, pointer and value hash. No blanket authorization exception is used. The known-value/header/runtime scans and additional 20-value/128-form residual check are bounded checks, not a universal guarantee that every possible secret is absent.

There are no images or browser screenshots in this frozen cut. Public text/HTML/PDF evidence and source URLs are retained. Original backups and local originals remain; no deletion or replacement is performed.
