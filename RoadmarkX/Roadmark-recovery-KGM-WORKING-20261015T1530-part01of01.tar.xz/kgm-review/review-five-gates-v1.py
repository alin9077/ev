from pathlib import Path
import json,hashlib,re,datetime
P=Path('/tmp/kgm-packet/post-registration-checks-v1');R=Path('/tmp/kgm-review')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def meta(p):
 p=Path(p)
 if not p.exists():return {'path':str(p),'exists':False}
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
seq=read(P/'sequence.json');grant=read(P/'first-five-root-grant.json');gh=pin(P/'first-five-root-grant.json')['sha256'];assert gh=='b4ac522de9e2051660254ef4ab47f63c2f853d2dba6d1603183956bae143fe76';assert grant['status']=='root_execution_granted' and grant['heavySlotExclusive'] and not grant['automaticRetry']
assert grant['sequence']==pin(P/'sequence.json') and grant['reviewerAcceptance']==pin(R/'post-registration-v1-readiness-review.json') and grant['registrationVerification']==pin(R/'registration-v1-application-review.json')
for p in read(P/'source-pins.json'):assert pin(p['path'])==p
metadata=read(seq['rootMetadata']['path']);inv=read(P/'test-inventory.json');checks=[];previous=None
for manifestpin in seq['sequence'][:5]:
 assert pin(manifestpin['path'])==manifestpin;m=read(manifestpin['path']);O=Path(m['runOutput']);result=read(O/'result.json');t=read(O/'terminal.json');invocation=read(O/'invocation.json');scope=read(O/'scope-verification.json')
 assert result['passed'] and result['exitCode']==0 and result['pinsPassed'] and result['scopePassed'] and result['manifestSha256']==manifestpin['sha256'];assert t['exitCode']==t['rawWaitStatus']==0 and not t['watchdogFired'] and t['elapsedSeconds']<m['timeoutSeconds'];assert invocation['command']==m['command'] and invocation['manifestSha256']==manifestpin['sha256'] and invocation['grantSha256']==gh
 assert invocation['beforePinsPassed'] and not invocation['automaticRetry'] and not invocation['sourceMutationsAuthorized'];assert read(O/'after-pins.json')['passed'] and read(O/'after-pins.json')['count']==209;assert scope['passed'] and scope['sourceScopeUnchanged'] and scope['registrationTargetMetadataUnchanged']
 for k in ['stdout','stderr']:assert pin(O/(k+'.log'))['sha256']==t[k+'Sha256']
 assert (O/'stderr.log').stat().st_size==0
 if previous:assert datetime.datetime.fromisoformat(invocation['at'])>datetime.datetime.fromisoformat(previous)
 previous=t['at']
 for row in read(O/'registration-target-metadata-before.json'):assert meta(row['path'])==row
 stdout=(O/'stdout.log').read_text()
 if m['kind']=='market':assert stdout=='Market view verified without writing\n'
 elif m['kind']=='lint':
  x=json.loads(stdout);assert len(x)==1 and x[0]['filePath']==m['repo']+'/scripts/reporting/load.ts';assert not x[0]['messages'] and x[0]['errorCount']==x[0]['warningCount']==x[0]['fatalErrorCount']==0
 elif m['kind']=='tests':
  names=[n for f in m['testFiles'] for n in inv[f]['names']];assert len(names)==m['expectedTests'];assert sorted(re.findall(r'^# Subtest: (.*)$',stdout,re.M))==sorted(names)
  for key,val in [('tests',len(names)),('pass',len(names)),('fail',0),('cancelled',0),('skipped',0),('todo',0)]:assert re.search(r'^# '+key+' '+str(val)+r'$',stdout,re.M)
  assert not re.search(r'^not ok\b',stdout,re.M)
 elif m['kind']=='structural':
  x=json.loads(stdout);assert x['result']=='PASS' and x['counts']==m['expectedStructuralCounts'];assert x['sourceReferences']==3769 and x['publicationIssues']==15 and x['approvedExternalAssets']==0 and x['sha256']==m['immutableResearchSha256']
 for row in metadata['fileMetadata']+metadata['directoryState']+m['runtimeMetadata']:assert meta(row['path'])==row
 checks.append({'name':m['id'],'passed':True,'exitCode':0,'manifest':manifestpin,'result':pin(O/'result.json'),'terminal':pin(O/'terminal.json'),'elapsedSeconds':t['elapsedSeconds'],'maxRssKiB':t['maxRssKiB'],'expectedTests':m.get('expectedTests'),'evidence':[pin(O/name) for name in ['invocation.json','after-pins.json','scope-verification.json','registration-target-metadata-before.json','stdout.log','stderr.log']]})
receipt={'schemaVersion':1,'status':'accepted','reviewedAt':'2026-10-15','applicationManifestSha256':seq['registrationManifest']['sha256'],'applicationVerification':pin(R/'registration-v1-application-review.json'),'sequence':pin(P/'sequence.json'),'grant':pin(P/'first-five-root-grant.json'),'inputPinsReverified':201,'unchangedConfiguredRootStatsReverified':360,'completeRootScope':361,'checks':checks,'checksPerformed':'Independently verified exact grants/commands, sequential timestamps, log hashes, zero exit/stderr/watchdogs, every TAP name/count, changed-file lint output, market no-write output, complete structural fields, current source pins and target/root metadata. No command rerun.','limits':['Five exact post-registration gates accepted; no full-project TypeScript, normal report, comparator or Next build pass is inferred.']}
p=R/'post-registration-v1-output-review.json';assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(pin(p)))
