from pathlib import Path
import json,hashlib,copy,collections
O=Path('/tmp/kgm-packet/selected-preflight-v2'); R=Path('/tmp/kgm-review')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
m=read(O/'prepared-command.json');result=read(O/'result.json');terminal=read(O/'run/terminal.json');inv=read(O/'run/invocation.json');afterpins=read(O/'run/after-pins.json')
assert pin(O/'result.json')['sha256']=='4df1a7ee17b32810f818ad92eefc365fbcf12d5fb4fd146149923fc62b028176'
assert pin(O/'prepared-command.json')['sha256']==inv['manifestSha256']==afterpins['manifestSha256']=='3463f4360bc502d35dfa73bb92483f27e53c7cbb9cb8e2ce5d4fc1bd50793004'
assert terminal['exitCode']==terminal['rawWaitStatus']==0 and (O/'run/stderr.log').stat().st_size==0
for which in ['stdout','stderr']:assert pin(O/f'run/{which}.log')['sha256']==terminal[which+'Sha256']
assert inv['command']==m['command'];assert pin(O/'root-execution-grant.json')['sha256']==inv['grantSha256']
grant=read(O/'root-execution-grant.json');assert grant['authorized'] and grant['exclusiveHeavySlotGranted'] and not grant['automaticRetry']
pins=read(O/'source-pins.json');assert len(pins)==185
for p in pins:assert pin(p['path'])==p
for k in ['script','sourcePins','packet','reconciliation','expectedReview','wrapper']:assert pin(m[k]['path'])==m[k]
assert afterpins['passed'] and afterpins['count']==190
p=read(m['packet']['path']);before={c['id']:c for c in read('/tmp/kgm-research/retained-before-cars.json')};after={c['id']:c for c in read(O/'selected-after-cars.json')};packs=read(O/'selected-packs.json');stored=read(O/'portable.json');claims=read(O/'claims.json');features=read(O/'feature-claims.json');exp=read(O/'expected-review.json')
assert list(before)==list(after)==list(packs)==list(stored)==exp['currentListIds']
changes={(f['variantId'],f['after']['key']):f['after'] for f in p['facts']}
for term in p['brandTerms']:
 for id in term['applicableVariantIds']:changes[id,term['key']]=term['fact']
assert len(changes)==68
for id,car in after.items():
 expected=copy.deepcopy(before[id]['facts'])
 for (cid,key),f in changes.items():
  if cid==id:expected[key]=f
 assert car['facts']==expected
 allowed={'facts','buyerSummary','availabilityEvidence','availabilityRevision'}
 assert {k for k in set(car)|set(before[id]) if car.get(k)!=before[id].get(k)}==allowed
 av=next(a for a in p['availability'] if a['variantId']==id);assert car['availabilityEvidence']==av['after']['evidence'] and car['availabilityRevision']==av['id']
 assert packs[id]['car']==car
 ss={s['id']:s for s in packs[id]['sources']};assert len(ss)==len(packs[id]['sources'])
 for f in car['facts'].values():assert all(s in ss for s in f['sourceIds'])
 for f in packs[id]['features']:assert all(s in ss for s in f['source_ids'])
 # Independent expansion of the documented portable representation, no application imports.
 h=copy.deepcopy(stored[id]);sids=h.pop('sourceIds');h['sources']=[ss[s] for s in sids]
 for f in h['features']:
  f.setdefault('variant_id',id);f.setdefault('model_id',car['modelId'])
 assert h==packs[id]
 assert len(h['features'])==69 and len({f['criterion'] for f in h['features']})==69
 for criterion,key in [('driveaway_price','price_aud'),('roadside_assistance','roadside_assistance')]:
  f=next(f for f in h['features'] if f['criterion']==criterion);fact=car['facts'][key]
  assert f['source_ids']==fact['sourceIds'] and f['buyerGrade']==fact['buyerGrade'] and f['gradeReview']==fact['gradeReview']
  assert f['reviewed_date']==f['last_evidence_date']=='2026-10-15'
 summary=next(s for s in p['summaries'] if s['variantId']==id)
 for side in ['strength','tradeoff']:
  assert car['buyerSummary'][side]['text']==summary[side]['text']
  assert car['buyerSummary'][side]['sourceIds']==list(dict.fromkeys(s for d in summary[side]['dependencies'] for s in d['expected']['sourceIds']))
  for d in summary[side]['dependencies']:assert d['expected']==car['facts'][d['key']] and not d['expected']['issues']
assert len(claims)==68 and len(features)==207
assert {(r['variantId'],r['key']) for r in claims}==set(changes)
for row in claims:
 f=changes[row['variantId'],row['key']];c=row['claim'];assert c['buyerGrade']==f['buyerGrade'] and c['gradeReview']==f['gradeReview'];assert [s['id'] for s in c['sources']]==f['sourceIds']
 if f['value'] is None:assert c['value']=='Not published'
for row in features:
 f=next(f for f in packs[row['variantId']]['features'] if f['criterion']==row['criterion']);assert row['claim']['carId']==row['variantId'];assert [s['id'] for s in row['claim']['sources']]==list(dict.fromkeys(f['source_ids']))
assert len({(r['variantId'],r['criterion']) for r in features})==207
coverage=result['selectedCoverage'];progress=coverage['brandProgress'][0]
assert progress['criteria']=={'C1':False,'C2':False,'C3':True,'C4':True,'C5':False,'C6':True}
assert progress['researchCompleted'] and progress['coreGaps']==5 and progress['agedOrInvalidClaims']==progress['missingSummaries']==progress['unreviewedCoreGrades']==0
counts=collections.Counter()
for c in coverage['core']:counts.update(c['grades'])
assert counts=={'Confirmed':41,'Check':2,'Reported':3,'Not published':5,'Unreviewed':0}
assert sum(c['filled'] for c in coverage['core'])==46
for x in coverage['rankings']:
 assert x['rankedIds']==result['rankCounts'][x['key']]['ranked'];assert x['ranked']==len(exp['rankingIds'][x['key']]);assert set(x['rankedIds'])==set(exp['rankingIds'][x['key']])
assert result['rankCounts']['price_aud']['ranked']==[exp['currentListIds'][2],exp['currentListIds'][0],exp['currentListIds'][1]]
assert result['currentListProof']['reviewedModels']==2 and result['currentListProof']['reviewedVersions']==3
assert result['currentListProof']['settledInventory']==exp['expectedSettledInventory']
assert [i['code'] for i in result['currentListProof']['issues']]==['independent_lists']
ws=read(O/'undefined-witnesses.json');cw=read(O/'claim-undefined-witnesses.json');rw=read(O/'report-undefined-witnesses.json')
assert len(ws)==86 and len(cw)==324 and len(rw)==6
assert ws==result['optionalFeaturePaths'] and cw==result['optionalCitationPaths']
assert collections.Counter(w['phase'] for w in ws)=={'before':43,'after':43}
for w in ws:
 assert w['ownUndefined'] and w['enumerable'] and w['actualFinalProjectionMatched'];assert w['criterion'] not in ['roadside_assistance','driveaway_price']
 if w['phase']=='after':
  f=packs[w['variantId']]['features'][w['rowIndex']];assert f['criterion']==w['criterion'] and w['property'] not in f
  assert any(b['phase']=='before' and b['pointer']==w['pointer'] and b['criterion']==w['criterion'] and b['property']==w['property'] for b in ws)
for w in cw:
 assert w['ownUndefined'] and w['enumerable'];parts=w['pointer'].split('/');rows=claims if parts[1]=='claims' else features;c=rows[int(parts[2])]['claim']['sources'][int(parts[5])];assert c['id']==w['sourceId'] and parts[6] not in c
for w in rw:assert w['ownUndefined'] and w['enumerable'] and w['property'] in ['brand','reference']
assert all(result[k] for k in ['otherRetainedFeaturesUnchanged','inMemoryPortableExact','writtenPortableExact','writtenClaimReadback','livePacksUnchanged'])
assert not result['productionCatalogueHydration'] and not result['sourceEdits'] and result['defaultLoaderCalls']==0
outputs=[pin(O/f) for f in ['result.json','selected-after-cars.json','selected-packs.json','portable.json','claims.json','feature-claims.json','undefined-witnesses.json','claim-undefined-witnesses.json','report-undefined-witnesses.json','run/terminal.json','run/after-pins.json','run/invocation.json','run/stdout.log','run/stderr.log','root-execution-grant.json']]
receipt={'schemaVersion':1,'reviewedAt':'2026-10-15','status':'accepted_selected_v2_result','preparedManifestSha256':inv['manifestSha256'],'candidateSha256':m['packet']['sha256'],'resultSha256':pin(O/'result.json')['sha256'],'terminal':terminal,'inputPinsReverified':185,'wrapperPostPinChecks':190,'reviewedOutputPins':outputs,'checks':{'completeCars':3,'exactFactTermUpdates':68,'allOtherCarFieldsUnchanged':True,'uniqueFactClaims':68,'uniqueFeatureClaims':207,'independentSavedPortableExpansionExact':True,'canonicalPriceProjections':3,'canonicalRoadsideProjections':3,'exactSummaryDependencies':10,'sourceClosure':True,'coreGrades':dict(counts),'strictCoreFilled':46,'strictCoreGaps':5,'featureOmissionsBefore':43,'featureOmissionsAfter':43,'citationOmissions':324,'reportOmissions':6,'researchCompleted':True,'criteria':progress['criteria'],'rankings':{r['key']:r['ranked'] for r in coverage['rankings']},'currentModels':2,'currentVersions':3,'settledInventoryRecords':2},'limits':['Selected-only actual consumer result; not a complete catalogue stage, live registration, normal coverage, full suite, production build or visual result.','Review inspected exact approved executed script, terminal/output evidence and complete saved artifacts; independent verification used read-only JSON comparisons and documented portable expansion, without another catalogue/consumer execution.','Full live-producer optional-property ownership is established by the reviewed executed harness; saved JSON absence and all exact witness locations were independently checked.']}
out=R/'selected-preflight-v2-result-review.json';out.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(pin(out)))
