from pathlib import Path
import json, hashlib, copy, collections
O=Path('/tmp/kgm-packet/full-stage-v1'); Q=O/'output'; R=Path('/tmp/kgm-review')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def digest(v):
 b=(json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n').encode();return {'rows':1,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
m=read(O/'manifest.json');t=read(O/'run/terminal.json');i=read(O/'run/invocation.json');a=read(O/'run/after-pins.json');grant=read(O/'root-execution-grant.json');s=read(Q/'stage-receipt.json')
assert pin(O/'manifest.json')['sha256']==i['manifestSha256']==a['manifestSha256']=='4a4b21deefa4dc50ce8bee595f3d42ae26d17a0fe764ee76f4edb72be6cc4ac9'
assert pin(Q/'stage-receipt.json')['sha256']=='e5e26681adccb5a2cf3279c02065c9c039f7fecbebf09368d3ecf959acf9dd4e'
assert t['exitCode']==t['rawWaitStatus']==0 and t['elapsedSeconds']<420 and (O/'run/stderr.log').stat().st_size==0
for k in ['stdout','stderr']:assert pin(O/f'run/{k}.log')['sha256']==t[k+'Sha256']
assert pin(O/'root-execution-grant.json')['sha256']==i['grantSha256'];assert grant['authorized'] and grant['exclusiveHeavySlotGranted'] and not grant['automaticRetry'];assert grant['command']==i['command']==read(O/'root-grant-template.json')['command']
assert a['passed'] and a['count']==270
for p in m['pins']:assert pin(p['path'])==p
cars=read(Q/'car-digest-comparison.json');fields=read(Q/'research-field-digests.json');oldcars=read(m['acceptedMiniCars']['path']);oldfields=read(m['acceptedMiniFields']['path'])
assert list(cars)==list(fields)==list(oldcars)+['candidate28'];assert list(oldcars)==list(oldfields)
for key in oldcars:assert cars[key]==oldcars[key] and fields[key]==oldfields[key]
assert all(len(v)==14 for v in fields.values()); assert [len(cars[k]) for k in cars]==[409,409,413,413,417,427,427,427,427]
selected=set(m['selectedIds']); peers={c['id'] for c in cars['candidate27']}-selected;assert len(peers)==424
assert [r for r in cars['candidate27'] if r['id'] in peers]==[r for r in cars['candidate28'] if r['id'] in peers]
assert [r['id'] for r in cars['candidate27']]==[r['id'] for r in cars['candidate28']]
assert {a['id'] for a,b in zip(cars['candidate27'],cars['candidate28']) if a!=b}==selected
for car in read(Q/'selected-after-cars.json'):assert next(r for r in cars['candidate28'] if r['id']==car['id'])=={'id':car['id'],**digest(car)}
changedfields={k for k,v in fields['candidate28'].items() if v!=fields['candidate27'][k]};assert changedfields=={'metadata','variants','sources'}
assert fields['candidate28']['variants']['rows']==427 and fields['candidate28']['sources']['rows']==fields['candidate27']['sources']['rows']+16
trans=read(Q/'metadata-composition.json');assert len(trans)==8
stagekeys=list(fields)
for index,row in enumerate(trans):
 assert row['beforeMetadata']==fields[stagekeys[index]]['metadata']; assert digest(row['composedMetadata'])==fields[stagekeys[index+1]]['metadata']
 assert row['rawMetadata']['brand_update_packet_ids']==[row['packetId']]
 assert row['composedMetadata']['brand_update_packet_ids']==(m['registeredPacketIds']+[read(m['packet']['path'])['id']])[:index+21]
 assert {k:v for k,v in row['rawMetadata'].items() if k!='brand_update_packet_ids'}=={k:v for k,v in row['composedMetadata'].items() if k!='brand_update_packet_ids'}
for name,p in m['selectedArtifacts'].items():assert pin(Q/(name+'.json'))['sha256']==p['sha256']
actual=read(Q/'result.json');prior=read(m['selectedResult']['path']);assert {k:v for k,v in actual.items() if k!='readInputs'}=={k:v for k,v in prior.items() if k!='readInputs'}
assert len(actual['readInputs'])==14
for row in actual['readInputs']:
 f=fields['candidate27'][row['field']];assert row['inputRows']==row['retainedRows']==f['rows'] and row['sha256']==f['sha256']
closure=read(Q/'retained-storage-read-closure.json');assert closure['actualReadFiles']==sorted(p['path'] for p in read(m['storageClosure']['path']));assert len(closure['actualReadFiles'])==21
neutral=read(Q/'source-reference-neutrality.json');assert neutral['peerCars']==424 and neutral['sourceRowsAdded']==16 and len(neutral['inspections'])==12
assert all(x['newSourceReferences']==0 and x['nestedGradeReviewsAndKeysIncluded'] for x in neutral['inspections'])
# Verify each complete saved global ranking group and all peer movement/selection deltas.
ranks=read(Q/'global-ranking-comparison.json');expected=read(m['expectedReview']['path']);rankcounts={}
for row in ranks:
 groups=[]
 for phase in ['before','after']:
  r=row[phase];g={x['key']:x for x in r['groups']};assert len(g)==len(r['groups']) and set(g)==set(r['insertionKeys']);assert list(g)==r['sortedKeys'];allids=[]
  for x in g.values():
   assert len(x['ids'])==x['count']==len(set(x['ids'])); assert x['selectedIds']==[i for i in x['ids'] if i in selected];assert x['peerIds']==[i for i in x['ids'] if i in peers];allids+=x['ids']
  assert len(allids)==len(set(allids));groups.append(g)
 b,n=groups
 for key in set(b)|set(n):
  bg=b.get(key,{'peerIds':[],'selectedIds':[],'count':0});ng=n.get(key,{'peerIds':[],'selectedIds':[],'count':0});assert bg['peerIds']==ng['peerIds'];assert ng['count']==bg['count']-len(bg['selectedIds'])+len(ng['selectedIds'])
 found=[i for g in n.values() for i in g['selectedIds']];assert set(found)==set(expected['rankingIds'][row['attribute']]);rankcounts[row['attribute']]=len(found)
 assert row['peerMembershipAndWithinGroupOrderExact'] and row['insertionTiesProvedFromActualInputOrder'] and row['selectedCountDeltasExact']
 assert row['productionGroupComparator']=='(a, b) =>\n        b.entries.length - a.entries.length || a.basis.localeCompare(b.basis)'
# Independently construct the complete expected global C1 from the accepted baseline and exact packet.
c1=read(Q/'global-c1-comparison.json');b=c1['before'];n=c1['after'];rec=read(m['reconciliation']['path']);assert b==read(m['acceptedMiniC1']['path'])['after']==read(m['acceptedNormalReport']['path'])['reconciliation']==read(Q/'baseline-global-c1.json')
new=copy.deepcopy(b);new['registryCheckedAt']=max(b['registryCheckedAt'],rec['checkedAt']);new['reviewedModels']+=2;new['reviewedVersions']+=3;new['reviewedVersionIds'] += [v['carId'] for r in rec['currentVersionReviews'] for v in r['versions']];new['validModelReviewIds'] += [r['id'] for r in rec['currentVersionReviews']]
settlements=set(expected['expectedSettledInventory']);other=lambda x:x.get('brand','').upper()!='KGM' and x.get('reference') not in selected and x.get('reference') not in settlements
removed=[x for x in b['issues'] if not other(x)];assert collections.Counter(x['code'] for x in removed)=={'version_unreviewed':3,'inventory_unresolved':2};new['issues']=[x for x in b['issues'] if other(x)]
inv=read(Path(m['repo'])/'data/market-inventory-2026-10-10.json');order=[]
for key,prefix in [('records','record:'),('unverifiedLeads','lead:')]:
 for r in inv[key]:
  if not r.get('vehicleClass') or r['vehicleClass'] in ['passenger','ute']:order.append(prefix+(r.get('id') or r.get('familyId') or r['brand']+'-'+r['model']))
new['settledInventory']=[i for i in order if i in set(b['settledInventory'])|settlements];assert len(new['settledInventory'])==len(b['settledInventory'])+2
new['evidence']['checkedAt']=max(b['evidence']['checkedAt'],rec['checkedAt'])
for key in ['notes','publishedLists','currentVersionReviews','listResolutions','catalogueOnlyDifferences','inventoryResolutions']:new['evidence'][key]+=rec[key]
assert new==n==c1['expectedCompleteAfter'];assert (n['reviewedModels'],n['reviewedVersions'],n['pass'])==(103,234,False)
assert c1['completeExpectedWrittenEquality'] and c1['baselineMatchesAcceptedMiniAndNormal'] and c1['nonKgmIssuesReviewsDispositionsExact']
assert (s['stagedCars'],s['tierOneVersions'],s['onSaleVersions'])==(427,350,309);assert s['defaultLoaderCalls']==0 and not s['productionRegistration'] and not s['normalFullReportRun'] and not s['broadFeatureReplay']
outputs=[pin(f) for f in sorted(Q.iterdir()) if f.is_file()]+[pin(O/f) for f in ['run/terminal.json','run/invocation.json','run/after-pins.json','run/stdout.log','run/stderr.log','root-execution-grant.json']]
receipt={'schemaVersion':1,'status':'accepted_bounded_full_stage_v1_result','reviewedAt':'2026-10-15','manifestSha256':i['manifestSha256'],'stageReceiptSha256':pin(Q/'stage-receipt.json')['sha256'],'candidateSha256':m['packet']['sha256'],'terminal':t,'allInputPinsReverified':270,'checks':{'acceptedStagesBeforeKgm':8,'allPriorCompleteCarAnd14FieldDigestsExact':True,'selectedCompleteCarDigestsIndependentlyRecomputed':3,'changedCars':3,'unchangedCompletePeers':424,'fixedCatalogueTierOneOnSale':[427,350,309],'changedResearchFields':sorted(changedfields),'sourceRowsAdded':16,'cumulativeMetadataComposition':8,'selectedArtifactsByteIdenticalToAcceptedSelectedV2':8,'selectedResultOnlyReadScopeMetadataDiffers':True,'factAndTermClaims':68,'featureClaims':207,'runtimeStorageClosure':21,'sourceReferenceNeutralityInspections':12,'selectedRankCounts':rankcounts,'allSavedGlobalGroupPeerOrdersAndDeltasChecked':True,'actualNumericRanksAndLocaleComparatorEstablishedByReviewedExecutedHarness':True,'completeGlobalC1IndependentlyReconstructed':True,'reviewedModels':[101,103],'reviewedVersions':[231,234],'removedKgmIssueCounts':dict(collections.Counter(x['code'] for x in removed)),'inventorySettlements':2,'globalC1StillFalse':True},'outputs':outputs,'limits':['No duplicate catalogue hydration or consumer run was performed for review. Complete JSON output comparisons and immutable input pin verification independently check the executed harness evidence.','Exact live optional-property ownership and numeric ranking comparator semantics are supported by the frozen reviewed producer harness; all saved witness artifacts are byte-identical to independently accepted selected v2.','This accepts the bounded full-stage result only. Guarded live integration and a subsequent separately authorized normal report remain pending.']}
p=R/'full-stage-v1-output-review.json';assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(pin(p)))
