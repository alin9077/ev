from pathlib import Path
import json,hashlib,ast
from datetime import datetime,timezone
B=Path('/tmp/kgm-packet/docs-status-v1');mp=B/'manifest.json';m=json.loads(mp.read_text())
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def check(r):
 p=Path(r['path']);assert p.is_file() and not p.is_symlink(),p;assert pin(p)==r,r
assert pin(mp)['sha256']=='2e2000475013c954ced63b5b6be2653990f92db8bfd807e7415bff5967f841cf'
for r in m['proofs']+[m[k] for k in ['applicator','preparer','patch']]:check(r)
assert len(m['proofs'])==56
for w in m['writes']:
 check(w['after']);p=Path(w['target']);assert p.resolve()==p and not p.is_symlink()
 if w['before']:
  check(w['before']);check(w['beforeCopy'])
 else:assert not p.exists()
old=json.loads(Path(m['writes'][2]['beforeCopy']['path']).read_text());new=json.loads(Path(m['writes'][2]['after']['path']).read_text());hp=m['historyPreservation']
assert len(old)==74 and len(hp['unchangedHistoricalFields'])==57
for k in hp['unchangedHistoricalFields']:assert old[k]==new[k],k
assert new['workStatusHistory'][:-1]==old['workStatusHistory'] and len(new['workStatusHistory'])==9
assert new['workStatusHistory'][-1]['previous']=={k:old[k] for k in hp['exactSupersededCurrentFields']}
assert set(new)-set(old)=={'kgmWorking','kgmResearchStatus','kgmPendingRecovery'}
for k in old:
 if k not in hp['changedCurrentFields'] and k!='workStatusHistory':assert old[k]==new[k],k
assert Path(m['writes'][1]['after']['path']).read_bytes()==Path(m['writes'][1]['beforeCopy']['path']).read_bytes()+(B/'progress-append.md').read_bytes()
r=json.loads(Path(m['reportEvidence']['normalReport']['path']).read_text());core={c['key']:c for c in r['core']};buyer=Path(m['writes'][0]['after']['path']).read_text()
assert '{{' not in buyer
for k in ['price_aud','range_km','battery_kwh','dc_charge_time_min','seats','boot_l','warranty']:
 assert f"{core[k]['filledPercent']:.1f}% / {core[k]['confirmedPercent']:.1f}%" in buyer,k
assert f"{r['pairedOnSalePercent']:.1f}%" in buyer and f"{r['inAllRankingsPercent']:.1f}%" in buyer
kw=new['kgmWorking'];assert kw==new['latestWorkingBrandChecks']
assert kw['releaseReady'] is False and kw['fullProjectTypecheckPassed'] is False
assert kw['coverage']['catalogue']==r['allCatalogueVersions']==427 and kw['coverage']['tier1']==r['tierOneVersions']==350 and kw['coverage']['onSale']==r['onSaleVersions']==309
assert kw['coverage']['coreReviewed']==sum(c['reviewed'] for c in r['core'])==5036
assert kw['coverage']['coreDenominator']==sum(c['total'] for c in r['core'])==5253
assert kw['coverage']['criteria']==[{'id':c['id'],'pass':c['pass']} for c in r['criteria']]
assert kw['coverage']['rankings']=={x['key']:x['ranked'] for x in r['rankings']}
assert kw['coverage']['researchCompletedBrands']==len(r['brandsResearchCompleted'])==14 and kw['coverage']['researchRemainingBrands']==len(r['brandsResearchRemaining'])==42
assert kw['relevantTests']['distinctScopedTestsAcrossTheseRuns']==151 and kw['relevantTests']['singleFullProjectAggregate'] is False
assert kw['fullTypecheck']['passed'] is False and kw['fullTypecheck']['furtherRetryAuthorized'] is False
for a in kw['fullTypecheck']['attempts']:
 for k in ['manifest','result','terminal','afterPins','scopeVerification','failureReview']:check(a[k])
 t=json.loads(Path(a['terminal']['path']).read_text());assert a['exitCode']==t['exitCode']==-9 and a['rawWaitStatus']==t['rawWaitStatus']==9
 assert a['cause']=='unknown' and a['fullProjectTypecheckPassed'] is False and not Path(a['freshCachePath']).exists()
 assert a['elapsedSeconds']==t['elapsedSeconds'] and a['maxRssKiB']==t['maxRssKiB']
assert kw['reportComparison']['fullProjectTypecheckPassed'] is False and kw['reportComparison']['releaseAcceptanceClaim'] is False
assert kw['visualPreview']['attempted'] is False and kw['publicationAuthorized'] is False
assert m['scope']['applied'] is False and not (B/'application').exists()
ast.parse(Path(m['applicator']['path']).read_text())
out={
 'schemaVersion':1,'status':'accepted','reviewedAt':datetime.now(timezone.utc).isoformat(),
 'scope':'Independent documentary readiness review only; no live write, producer execution, compiler retry, release or safety-save acceptance',
 'manifest':pin(mp),'applicator':m['applicator'],'writes':m['writes'],
 'checks':{'all56ProofPinsVerified':True,'allBeforeAndAfterPayloadPinsVerified':True,'exactThreeTargetsOnly':True,'buyerUpdateRequiredFiveSectionsRead':True,'buyerCoverageTableExactlyMatchesSavedNormalReport':True,'progressOriginalPrefixAndExactAppendPreserved':True,'all57UntouchedHistoricalStatusFieldsExact':True,'allEightPriorHistoryEntriesExact':True,'all16SupersededCurrentFieldsArchivedExactly':True,'currentKgmCoverageAndScopeCorrect':True,'bothFailedTypecheckAttemptPinsExactAndFreshCachesStillAbsent':True,'unknownCauseAndHistoricalMiniPassDistinctionExplicit':True,'factualCoverageExceptionAndReleaseLimitExplicit':True,'currentGatesAndRecoveryPendingCorrect':True,'applicatorExactGrantCreateOnlyJournalAndNoRetryGuardsReviewed':True,'noApplicationExists':True},
 'validationNote':'A reviewer-only table-key lookup initially used warranty_years; corrected to actual report key warranty. No candidate, proof, runtime or live byte changed.',
 'rootGrantRequired':True,'automaticRetry':False,'heavyExecutionAuthorized':False,
 'currentTypeScriptGate':'UNPASSED: two unknown-cause SIGKILL attempts; no further retry authorized',
 'remaining':'Root exact documentary application grant, then independent three-target live readback and final recovery freeze acceptance'
}
p=Path('/tmp/kgm-review/docs-status-v1-readiness-review.json');assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(pin(p)))
