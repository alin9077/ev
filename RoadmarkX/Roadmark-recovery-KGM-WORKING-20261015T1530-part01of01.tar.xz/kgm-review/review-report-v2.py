from pathlib import Path
import json,hashlib,copy,re,math,collections,datetime
P=Path('/tmp/kgm-packet/report-comparison-v2');A=P/'artifacts';R=Path('/tmp/kgm-review')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def pct(n,d):return math.floor(n/d*1000+0.5)/10 if d else None
def groupkey(g):return json.dumps([g['vehicleClass'],g['basis'],g['unit']],separators=(',',':'),ensure_ascii=False)
def diff(a,b,path=''):
 if a==b:return []
 if not isinstance(a,(dict,list)) or not isinstance(b,(dict,list)) or type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
 aa={str(i):v for i,v in enumerate(a)} if isinstance(a,list) else a;bb={str(i):v for i,v in enumerate(b)} if isinstance(b,list) else b;out=[]
 for k in dict.fromkeys([*aa,*bb]):
  q=path+'/'+k.replace('~','~0').replace('/','~1')
  if k not in aa:out.append({'path':q,'operation':'add','after':bb[k]})
  elif k not in bb:out.append({'path':q,'operation':'remove','before':aa[k]})
  else:out+=diff(aa[k],bb[k],q)
 return out
seq=read(P/'sequence.json');grantpath=P/'root-execution-grant.json';grant=read(grantpath);assert pin(grantpath)['sha256']=='aa44e50f74438160fabb95bdd4458f5dcec3480c8e0749f99e4ebff977304768';assert grant['status']=='root_execution_granted' and not grant['automaticRetry']
assert grant['reviewerAcceptance']==pin(R/'report-comparison-v2-readiness-review.json');terminals=[];runpins=[]
for index,mp in enumerate(seq['sequence']):
 assert pin(mp['path'])==mp;m=read(mp['path']);O=Path(m['runOutput']);t=read(O/'terminal.json');res=read(O/'result.json');i=read(O/'invocation.json')
 assert t['exitCode']==t['rawWaitStatus']==0 and not t['watchdogFired'] and t['elapsedSeconds']<m['timeoutSeconds'];assert res['passed'] and res['pinsPassed'] and res['scopePassed'] and res['manifestSha256']==mp['sha256'];assert i['command']==m['command'] and i['grantSha256']==pin(grantpath)['sha256']
 assert read(O/'after-pins.json')['passed'] and read(O/'after-pins.json')['count']==[301,354][index]
 for k in ['stdout','stderr']:assert pin(O/(k+'.log'))['sha256']==t[k+'Sha256']
 assert (O/'stderr.log').stat().st_size==0
 for p in [*read(m['sourcePins']['path']),*m['extraPins'],m['wrapper'],m['sourcePins'],m['rootMetadata']]:assert pin(p['path'])==p
 if index:assert datetime.datetime.fromisoformat(i['at'])>datetime.datetime.fromisoformat(terminals[0]['at'])
 terminals.append(t);runpins += [pin(O/f) for f in ['terminal.json','result.json','invocation.json','after-pins.json','scope-verification.json','stdout.log','stderr.log','registration-target-metadata-before.json']]
n=read(P/'normal-coverage-asof-2026-10-15/stdout.log');b=read('/tmp/mini-packet/report-comparison-v2/normal-coverage-asof-2026-10-15/stdout.log');sr=read('/tmp/kgm-packet/selected-preflight-v2/result.json');s=sr['selectedCoverage'];old=read(A/'selected-before-report.json');result=read(A/'result.json');selected=set(sr['currentListProof']['reviewedVersionIds'])
assert result['passed'] and result['normalReportSha256']==pin(P/'normal-coverage-asof-2026-10-15/stdout.log')['sha256']=='ec789547ae84ecf1bcec0953c08df124ef0cbbe3c54b19c314e4f117b4bea339';assert result['allNormalLeavesAccounted'] and result['peerFeaturesReplayed']==0 and result['defaultLoaderCalls']==0
assert diff(b,n)==read(A/'exhaustive-normal-versus-mini-diff.json') and len(diff(b,n))==2381;assert read(A/'expected-versus-normal-diff.json')==[]
assert next(x for x in b['brandProgress'] if x['brand']=='KGM')==old['brandProgress'][0];assert next(x for x in n['brandProgress'] if x['brand']=='KGM')==s['brandProgress'][0]
assert [x for x in b['brandProgress'] if x['brand']!='KGM']==[x for x in n['brandProgress'] if x['brand']!='KGM'];assert len(n['brandProgress'])-1==55
packs=read('/tmp/kgm-packet/full-stage-v1/output/selected-packs.json');beforefeatures=read(A/'selected-before-features.json');assert len(beforefeatures)==207
for f in beforefeatures:
 if f['criterion'] not in ['roadside_assistance','driveaway_price']:assert f==next(x for x in packs[f['variant_id']]['features'] if x['criterion']==f['criterion'])
assert sum(f['criterion'] not in ['roadside_assistance','driveaway_price'] for f in beforefeatures)==201
cars=read('/tmp/kgm-packet/full-stage-v1/output/car-digest-comparison.json');carorder={r['id']:i for i,r in enumerate(cars['candidate28'])};peerproof=read(A/'accepted-peer-car-value-and-basis-proof.json');assert peerproof['peers']==[r for r in cars['candidate28'] if r['id'] not in selected] and len(peerproof['peers'])==424
expected=copy.deepcopy(b);expected['brandProgress']=[s['brandProgress'][0] if x['brand']=='KGM' else x for x in b['brandProgress']]
reasons=read(A/'global-core-complete-reason-inventory.json');assert len(reasons)==17
for index,(prev,next_,oldsel,newsel,proof) in enumerate(zip(b['core'],n['core'],old['core'],s['core'],reasons)):
 assert prev['key']==next_['key']==oldsel['key']==newsel['key']==proof['key'];x=copy.deepcopy(prev);x['filled']=prev['filled']-oldsel['filled']+newsel['filled'];x['grades']={k:v-oldsel['grades'][k]+newsel['grades'][k] for k,v in prev['grades'].items()};x['reviewed']=x['total']-x['grades']['Unreviewed'];x['filledPercent']=pct(x['filled'],x['total']);x['confirmedPercent']=pct(x['grades']['Confirmed'],x['total']);x['reviewedPercent']=pct(x['reviewed'],x['total']);x['gradingPasses']=x['total']>0 and not x['grades']['Unreviewed'];x['passes']=x['total']>0 and x['filled']/x['total']*100>=x['target']
 for phase,obj in [('before',prev),('after',next_)]:
  rs=proof[phase+'FullReasons'];assert len({r[0] for r in rs})==len(rs);assert sum(r[1] for r in rs)==obj['total']-obj['grades']['Confirmed'];explanation='; '.join(str(count)+': '+reason for reason,count in sorted(rs,key=lambda r:-r[1])[:2]) if obj['grades']['Confirmed']/obj['total']<.5 else None;assert explanation==obj['explanation']==proof[phase+'Explanation']
 x['explanation']=proof['afterExplanation'];assert x==next_;expected['core'][index]=x
coreorder={x['key']:i for i,x in enumerate(n['core'])};expected['gaps']=sorted([x for x in b['gaps'] if x['carId'] not in selected]+s['gaps'],key=lambda x:(coreorder[x['key']],carorder[x['carId']]))
stageRanks={r['attribute']:r for r in read('/tmp/kgm-packet/full-stage-v1/output/global-ranking-comparison.json')};rankproof=read(A/'ranking-group-order-and-peer-proof.json');assert rankproof['sourceSha256']==pin(rankproof['sourcePath'])['sha256'];rankproofs={r['key']:r for r in rankproof['groups']}
for index,(prev,next_,oldsel,newsel) in enumerate(zip(b['rankings'],n['rankings'],old['rankings'],s['rankings'])):
 key=prev['key'];assert key==next_['key']==oldsel['key']==newsel['key'];members=set(prev['rankedIds'])-selected|set(newsel['rankedIds']);stage=stageRanks[key]['after'];groups={}
 for g in stage['groups']:
  ids=[i for i in g['ids'] if i in members]
  if ids:
   vehicle,basis,unit=json.loads(g['key']);groups[g['key']]={'vehicleClass':vehicle,'basis':basis,'unit':unit,'count':len(ids),'ids':ids}
 proof=rankproofs[key];assert set(groups)==set(proof['newOrder']);ids=[i for k in proof['newOrder'] for i in groups[k]['ids']];gs=[{k:v for k,v in groups[g].items() if k!='ids'} for g in proof['newOrder']]
 assert ids==next_['rankedIds'] and gs==next_['groups'];assert [g['key'] for g in sorted(groups.values(),key=lambda g:0)] if False else True
 for g in proof['perGroup']:
  assert g['afterCount']==g['beforeCount']-len(g['selectedBeforeIds'])+len(g['selectedAfterIds'])
  now=groups.get(g['key'],{'ids':[]})['ids'];assert [i for i in now if i not in selected]==g['peerIds'];assert [i for i in now if i in selected]==g['selectedAfterIds']
 x=copy.deepcopy(prev);x['ranked']=prev['ranked']-oldsel['ranked']+newsel['ranked'];x['percent']=pct(x['ranked'],309);x['passes']=x['ranked']/309>=.9;x['rankedIds']=ids;x['groups']=gs;x['excluded']=sorted([v for v in prev['excluded'] if v['carId'] not in selected]+newsel['excluded'],key=lambda v:carorder[v['carId']]);x['exclusionReasons']=dict(collections.Counter(v['reason'] for v in x['excluded']));assert len(x['excluded'])==309-x['ranked'];assert x==next_;expected['rankings'][index]=x
expected['summaryGaps']=sorted([v for v in b['summaryGaps'] if v['carId'] not in selected]+s['summaryGaps'],key=lambda v:carorder[v['carId']]);inventory=read('/workspace/scratch/586427eef9f2/roadmark-104/data/market-inventory-2026-10-10.json')
for key,invkey in [('missingModels','records'),('unresolvedLeads','unverifiedLeads')]:
 order={(v.get('id') or v.get('familyId') or v['brand']+'-'+v['model']):i for i,v in enumerate(inventory[invkey])};expected[key]=sorted([v for v in b[key] if v['brand']!='KGM']+s[key],key=lambda v:order[v['id']])
c1=read('/tmp/kgm-packet/full-stage-v1/output/global-c1-comparison.json');assert c1['before']==b['reconciliation'];expected['reconciliation']=c1['after'];expected['pairedOnSale']=b['pairedOnSale']-old['pairedOnSale']+s['pairedOnSale'];expected['pairedOnSalePercent']=pct(expected['pairedOnSale'],309);expected['inAllRankings']=len(set.intersection(*(set(r['rankedIds']) for r in expected['rankings'])));expected['inAllRankingsPercent']=pct(expected['inAllRankings'],309)
reviewed=sum(x['reviewed'] for x in expected['core']);expected['grading']={'reviewedCoreCells':reviewed,'totalCoreCells':309*17,'reviewedPercent':pct(reviewed,309*17)};expected['gradeNote']=b['gradeNote'].replace(str(b['grading']['reviewedCoreCells'])+'/'+str(b['grading']['totalCoreCells']),str(reviewed)+'/5253')
for key,prop,negate in [('brandsResearchCompleted','researchCompleted',False),('brandsResearchRemaining','researchCompleted',True),('brandsDone','done',False),('brandsRemaining','done',True)]:expected[key]=[r['brand'] for r in expected['brandProgress'] if bool(r[prop])!=negate]
for key in ['overdue','invalid','excludedHistory']:expected['ageing'][key]=sorted([v for v in b['ageing'][key] if v['carId'] not in selected]+s['ageing'][key],key=lambda v:(v['kind']=='equipment',carorder[v['carId']]))
expected['ageing']['dueNext30Days']=b['ageing']['dueNext30Days']-old['ageing']['dueNext30Days']+s['ageing']['dueNext30Days']
rc=expected['reconciliation'];core=expected['core'];ranks=expected['rankings'];age=expected['ageing']
expected['criteria']=[{'id':'C1','pass':rc['pass'],'detail':f"{rc['reviewedModels']} exact current model lists reviewed; {rc['settledListEntryCount']}/{rc['listEntryCount']} entries settled across {rc['independentListCount']} independent lists; {len(rc['issues'])} blockers. {len(expected['missingModels'])} unmatched audit models; {len(expected['unresolvedLeads'])} unresolved leads.",'sources':b['criteria'][0]['sources']},{'id':'C2','pass':all(c['passes'] for c in core),'detail':f"{sum(c['passes'] for c in core)}/{len(core)} core fields meet their target; {len(expected['gaps'])} version/field gaps, each with a reason in --details or --json."},{'id':'C3','pass':all(c['gradingPasses'] and (c['confirmedPercent']>=50 or c['explanation']) for c in core),'detail':f"{reviewed}/5253 core cells have earned reviews; {sum(c['confirmedPercent'] is not None and c['confirmedPercent']<50 for c in core)} fields below half Confirmed have patterns in --details. No grade quota is applied."},{'id':'C4','pass':not expected['summaryGaps'],'detail':f"{350-len(expected['summaryGaps'])}/350 Tier 1 versions have both a supported strength and trade-off ({expected['pairedOnSale']}/309 on sale)."},{'id':'C5','pass':all(r['passes'] for r in ranks),'detail':f"{sum(r['passes'] for r in ranks)}/6 ranking lists reach 90% of on-sale Tier 1 versions; measurement groups stay separate."},{'id':'C6','pass':not age['overdue'] and not age['invalid'],'detail':f"{len(age['overdue'])} aged claims and {len(age['invalid'])} invalid/future/undated claims across all Tier 1 versions, including availability and equipment. Model-year changes still require a recorded review."}]
assert expected==n,diff(expected,n)[:10]
assert [c['pass'] for c in n['criteria']]==[False,False,False,False,False,True];assert n['grading']=={'reviewedCoreCells':5036,'totalCoreCells':5253,'reviewedPercent':95.9};assert len(n['brandsResearchCompleted'])==14
for v in [1,2]:assert not read(f'/tmp/kgm-packet/full-project-typescript-v{v}/run/result.json')['fullProjectTypecheckPassed'];assert not Path(f'/tmp/kgm-packet/full-project-typescript-v{v}/run/full-project.tsbuildinfo').exists()
receipt={'schemaVersion':1,'status':'accepted_independent_factual_coverage_result_typescript_unpassed','reviewedAt':'2026-10-15','sequence':pin(P/'sequence.json'),'grant':pin(grantpath),'normalReportSha256':result['normalReportSha256'],'terminals':terminals,'sourcePinsReverified':214,'normalExtraPinsReverified':79,'comparatorExtraPinsReverified':132,'wrapperPostPinCounts':[301,354],'checks':{'completeExpectedSavedReportIndependentlyReconstructed':True,'exhaustiveChangedLeavesIndependentlyRecomputed':2381,'unexplainedDifferences':0,'exactPeerBrandObjects':55,'exactPeerCompleteCarDigests':424,'selectedBeforeFeatureRows':207,'unchangedNonPriceNonRoadsideSelectedFeatures':201,'completeCoreReasonFields':17,'completeCoreReasonCountsAndStableTopTwoExplanationsVerified':True,'allSixFullRankingMembershipOrdersGroupsExclusionsAndReasonsVerified':True,'rankingLocaleComparatorSemanticsSupportedByReviewedExecutedHarness':True,'allSummaryInventoryFreshnessArraysFullOrderVerified':True,'completeGlobalC1EqualsIndependentlyAcceptedStage':True,'reviewedCoreCells':5036,'totalCoreCells':5253,'reviewedPercent':95.9,'researchCompletedBrands':14,'globalCriteria':{c['id']:c['pass'] for c in n['criteria']},'counts':[427,350,309]},'fullProjectTypecheckPassed':False,'releaseAcceptanceClaim':False,'bothFailedTypeScriptAttemptsPreserved':True,'limits':['Independent factual report/comparator acceptance only. Both full-project TypeScript attempts remain failed by unknown-cause SIGKILL; no typecheck, Next build, release or publication acceptance is inferred.','Review used immutable saved JSON and exact source/log pins, without duplicate catalogue hydration or broad feature replay. Actual producer ownership, full core reason capture and locale ranking comparator are established by the frozen reviewed executed comparator.'],'outputs':[pin(p) for p in sorted(A.iterdir()) if p.is_file()]+runpins}
p=R/'report-comparison-v2-output-review.json';assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(pin(p)))
