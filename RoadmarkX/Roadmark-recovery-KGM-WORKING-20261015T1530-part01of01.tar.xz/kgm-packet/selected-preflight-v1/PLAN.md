# KGM selected actual-consumer preflight: prepared only

The independently accepted candidate v2 and reconciliation v1 remain unchanged. This command is unexecuted and requires independent readiness review and a fresh explicit root grant of the exclusive heavy slot.

## Frozen command

Manifest: `/tmp/kgm-packet/selected-preflight-v1/prepared-command.json`

SHA256: `1ffa94816fd2935554223b4d383267e7cf8bdc53d733dd66ccf726ac16b1cf3c`

Once approved, root may invoke:

```sh
python /tmp/kgm-packet/selected-preflight-v1/run.py \
 /tmp/kgm-packet/selected-preflight-v1/prepared-command.json \
 1ffa94816fd2935554223b4d383267e7cf8bdc53d733dd66ccf726ac16b1cf3c \
 /tmp/kgm-packet/selected-preflight-v1/root-execution-grant.json
```

The child is Node with 448 MiB old-space and 1 MiB semi-space, loading installed tsx and executing only check.mjs. The wrapper supervises for 180 seconds plus 10-second termination grace, records wait4 resource evidence, and checks all pins before and after. Heap flags are not OS RSS limits. No automatic retry, concurrency or scope expansion is authorized. The supplied grant template is explicitly unauthorized.

## Exact scope and input proofs

- Three complete retained KGM rows match the accepted MINI27 digest index, including the exact JSONL serialization newline
- Retained research is streamed through the previously accepted baseline reader: three variants, three historic variant contexts, two models, and 207 feature rows containing 69 distinct criteria per version. Shared sources/criteria/context arrays remain source inputs. No production catalogue/research loader is called
- The live registry must contain exactly 27 accepted packets ending with MINI. Every prior packet is checked not to target a selected KGM row or shared term
- The candidate preserves all identities and MY26 years: Musso EV 2WD, Musso EV AWD and Torres EVX FWD
- Two full inherited inventory records and zero KGM unverified leads are frozen separately and compared to actual original inventory rows. The two current-version reviews cover all three exact rows. Black Edge remains the documented 2WD styling pack; no new version is created
- The 168 source pins include the independently accepted candidate/source review receipt, candidate and reconciliation, all retained source captures and factual payloads, input manifests, the current registered packets and static import closure of actual producer/helper modules

## Required actual checks

1. Existing prepareBrandResearch/applyBrandUpdates execute with three identity guards, 59 full before-fact guards, nine shared-term guards, three full availability guards and six summary clauses. Original research, selected before cars, packet and resulting research stay unchanged
2. All 51 core cells and all 68 effective updated fact/term cells earn their proposed grades. All ten summary dependencies are exact fresh issue-free facts; only claim-bound fact and source dates may drive freshness
3. Every selected pack contains all 69 criteria. Only three canonical driveaway-price projections and three roadside projections may change. Fresh prices/terms own their value, evidence, grade, conditions and deadlines. All unrelated retained feature rows remain equal
4. All 68 updated fact claims and 207 full feature claims retain source closure, earned grades, actual conditions, null Not published values and evidence dates
5. Source-reviewed expectations govern every numeric core field, every numeric supplemental field and all supported discovery attributes. Clean driveaway prices, exact WLTP ranges and compatible clean facts remain eligible. Three Reported DC peaks, gross/net-unstated battery values, mirror-unstated widths, five genuine core gaps, AWD towing/GCM/towball conflicts, full-AC-time conflict and the separately displayed metallic offer remain unranked. Only the two clean supplemental payload maxima are eligible
6. Current-list reconciliation must settle the two exact inherited records through two complete current reviews and three exact identities. C1 remains false because independent whole-market lists are absent. No national-best claim is made
7. Actual sourceEffectiveFeatures, applyFeatureRegrading, applyBrandFeatureUpdates and applyBrandTermFeatures producers supply the before/after feature rows. The existing compiledSource helper injects only the registry sequence into the real evidence-consumer module; no producer implementation is replaced
8. Live portable storage/hydration equals complete live packs. Written/readback and written portable hydration equal an independently cloned representation after only exact proven optional own-undefined paths are removed. Live objects remain unchanged
9. Each optional feature omission must have an exact row/index/criterion/property witness tied to same-run source/regraded/final output, plus actual auditedFeature(raw) proof where applicable. No guessed omission count or generalized normalization is permitted
10. Actual factClaim and featureClaim producers replay against written hydrated packs with exact equality. Serialized citation omissions must be own enumerable undefined limitation/checked fields tied to actual source metadata and producer replay
11. Written report equality permits only the exact independent_lists issue producer's own undefined brand/reference properties at three precise report paths. All other report values and the live result remain unchanged
12. Default catalogue/research loaders remain unused and absent from the require cache. All inputs are re-pinned and every relevant object is checked for nonmutation

## Outputs and stopping boundary

All consumer output is create-only within this preparation directory and its run subdirectory. It includes selected cars, complete packs, portable storage, fact/feature claims, exact feature/citation/report omission witnesses, ranking proofs, selected coverage/current-list proof and terminal/resource/pin evidence.

An unexpected omission, changed pin, invalid grade, source guard failure, producer mismatch, rank discrepancy or timeout stops the command. Preserve raw results and request a separately reviewed bounded correction. Do not normalize arbitrary fields, increase memory, automatically rerun or change a helper to force a pass.

## Preparation provenance

The harness is adapted from the accepted MINI selected-preflight-v4 actual-consumer path. Its serialization/witness protections and runtime envelope remain intact. KGM-specific changes are exact selected counts, MY26, the current MINI27 registry, canonical driveaway/roadside projections, conflict/basis ranking assertions, and two-model inventory/current-list scope. No helper change was assumed.

The initial tiny static pin-preparation script stopped because supportingArtifacts are path strings while sourceFiles are objects. The failed script and preparation-correction.json are retained; the unchanged expected-review file is asserted on the corrected preparation pass. No consumer/runtime/test/build/server/live-source command ran during preparation.
