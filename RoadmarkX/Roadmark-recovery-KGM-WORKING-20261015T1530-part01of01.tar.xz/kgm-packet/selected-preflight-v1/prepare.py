from pathlib import Path
import json,hashlib,re
O=Path('/tmp/kgm-packet/selected-preflight-v1');R=Path('/tmp/kgm-research');REPO=Path('/workspace/scratch/586427eef9f2/roadmark-104');P=Path('/tmp/kgm-packet')
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def write(p,x):
 with p.open('x') as f:f.write(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
packet=json.loads((P/'kgm-2026-10-15-candidate-v2.json').read_text());before=json.loads((R/'retained-before-cars.json').read_text());ids=[c['id'] for c in before];facts={(x['variantId'],x['after']['key']):x['after'] for x in packet['facts']}
core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','length_mm','width_mm','height_mm','towing_braked_kg','zero_to_100_s','power_kw','drive','warranty','battery_warranty']
policy=[]
for i in ids:
 for k in core:
  if k in ['drive','warranty','battery_warranty']:continue
  f=facts[i,k]
  eligible=k in ['price_aud','range_km','length_mm','height_mm','seats','power_kw','ac_kw','dc_charge_time_min'] or (k=='boot_l' and 'torres' in i) or (k=='towing_braked_kg' and 'awd' not in i)
  policy.append({'variantId':i,'key':k,'eligible':eligible,'value':f['value'],'buyerGrade':f['buyerGrade'],'comparisonBasis':f['comparisonBasis'],'reason':'Independently accepted maker AU value and compatible stated basis. Reported DC peaks, gross/net-unstated batteries, mirror-unstated widths, Not published gaps and AWD towing conflict remain excluded; clean exact prices/ranges/other facts remain eligible.'})
supplemental=[]
for row in packet['facts']:
 f=row['after']
 if f['key'] not in core and isinstance(f['value'],(int,float)):
  supplemental.append({'variantId':row['variantId'],'key':f['key'],'eligible':f['key']=='payload_kg','issues':f['issues'],'reason':'Only the two exact published payload maxima are eligible; AC-time, AWD towing/GCM/towball conflicts and the separately displayed metallic campaign remain visible with no compatible ranking basis.'})
expected={'packetSha256':pin(P/'kgm-2026-10-15-candidate-v2.json')['sha256'],'coreKeys':core,'currentListIds':ids,'bodyByModelId':{'kgm_musso_ev_current':'dual-cab ute','kgm_torres_evx_current':'SUV'},'normalizedRankPolicy':policy,'supplementalRankPolicy':supplemental,'rankingIds':{k:[x['variantId'] for x in policy if x['key']==k and x['eligible']] for k in ['length_mm','range_km','price_aud','dc_charge_time_min','towing_braked_kg','seats','boot_l']},'expectedSettledInventory':['record:kgm-torres-evx','record:kgm-musso-ev'],'factUpdates':59,'termCells':9,'coreCells':51,'allFeatureClaims':207,'roadsideCanonicalProjections':3,'driveawayCanonicalProjections':3,'expectedOnSaleDelta':0,'fullCatalogueHydration':False,'optionalPropertyCount':'Not guessed; exact same-run producer-owned paths required.'}
assert json.loads((O/'expected-review.json').read_text())==expected
files=set()
# Accepted prior isolated consumers supply the actual helper/import/input boundary.
for x in json.loads(Path('/tmp/mini-packet/selected-preflight-v4/source-pins.json').read_text()):
 f=Path(x['path'])
 if str(f).startswith(str(REPO)) or str(f).startswith(('/tmp/xpeng-staging-plan/','/tmp/mercedes-staging-plan/')):files.add(f)
for f in [P/'kgm-2026-10-15-candidate-v2.json',P/'kgm-market-reconciliation-v1.json',P/'candidate-manifest-v2.json',P/'candidate-v1-to-v2-provenance.json',P/'inventory-original-records-v1.json',R/'research-manifest-v2.json',R/'retained-before-cars.json',R/'retained-before-selection-receipt.json',Path('/tmp/mini-packet/full-stage-v2/output/car-digest-comparison.json'),O/'expected-review.json',O/'check.mjs',O/'run.py',O/'prepare.py',O/'adapt.py',O/'inventory-resolution-review.json',Path('/tmp/kgm-review/candidate-v2-source-static-review.json'),REPO/'package.json',REPO/'pnpm-lock.yaml']:files.add(f)
research=json.loads((R/'research-manifest-v2.json').read_text())
for x in research['sourceFiles']:files.add(Path(x['path']))
for x in research['supportingArtifacts']:files.add(Path(x))
files.update([O/'prepare-v1-failed.py',O/'preparation-correction.json'])
for s in packet['sources']:
 for k in ['capturePath','provenancePath','factualPayloadPath','payloadProvenancePath']:
  if s.get(k):files.add(Path(s[k]))
registry=json.loads((REPO/'data/m1-brand-updates/registry.json').read_text());assert len(registry['packets'])==27
for f in registry['packets']:files.add(REPO/'data/m1-brand-updates'/f)
# Static relative import closure only; no imports or consumers execute in preparation.
queue=[f for f in files if str(f).startswith(str(REPO)) and f.suffix in ['.ts','.tsx']];seen=set()
while queue:
 f=queue.pop()
 if f in seen:continue
 seen.add(f)
 for spec in re.findall(r'''(?:from\s*|import\s*\(?\s*|require\(\s*)["']([^"']+)["']''',f.read_text()):
  if not spec.startswith('.'):continue
  root=(f.parent/spec).resolve();choices=[root,Path(str(root)+'.ts'),Path(str(root)+'.tsx'),Path(str(root)+'.json'),root/'index.ts']
  hit=next((p for p in choices if p.is_file()),None)
  if hit:
   files.add(hit)
   if hit.suffix in ['.ts','.tsx']:queue.append(hit)
write(O/'source-pins.json',[pin(f) for f in sorted(files)])
m={'status':'prepared_not_executed','script':pin(O/'check.mjs'),'sourcePins':pin(O/'source-pins.json'),'packet':pin(P/'kgm-2026-10-15-candidate-v2.json'),'reconciliation':pin(P/'kgm-market-reconciliation-v1.json'),'expectedReview':pin(O/'expected-review.json'),'wrapper':pin(O/'run.py'),'command':['node','--max-old-space-size=448','--max-semi-space-size=1','--import','tsx',str(O/'check.mjs'),'--root-execution-granted'],'workdir':str(REPO),'timeoutSeconds':180,'killGraceSeconds':10,'automaticRetry':False,'rootExecutionGrantRequired':True,'exclusiveHeavySlotRequired':True,'scope':'Exactly three retained KGM before/after cars anchored to accepted MINI27 digests. Actual prepare/apply with 3 identities, 59 full before-fact guards and 9 shared-term guards; 51 core grades and 68 effective updated cells; 207 complete feature claims; 3 canonical roadside and 3 canonical driveaway projections; all other features unchanged. Exact source closure, 6 claim-only summary clauses with 10 dependency facts, 3 availability guards and 2 current model reviews plus exact 2 complete inherited inventory records. Actual compatible rankings and explicit conflict/Reported/basis/gap exclusions. Full live, portable, written and hydrated pack/citable equality with exact same-run producer-owned optional-property witnesses. No helper change, broad catalogue hydration, test/build/server, source edit, registration, archive, publication or automatic retry.'}
write(O/'prepared-command.json',m)
write(O/'root-grant-template.json',{'authorized':False,'exclusiveHeavySlotGranted':False,'action':'run_single_selected_kgm_preflight','preparedManifestSha256':pin(O/'prepared-command.json')['sha256'],'command':m['command'],'automaticRetry':False,'note':'Template only. Root must independently review and create an explicit grant after the exclusive heavy slot is available.'})
print(json.dumps({'preparedManifest':pin(O/'prepared-command.json'),'script':m['script'],'sourcePins':m['sourcePins'],'wrapper':m['wrapper'],'pinCount':len(files),'executed':False},indent=2))
