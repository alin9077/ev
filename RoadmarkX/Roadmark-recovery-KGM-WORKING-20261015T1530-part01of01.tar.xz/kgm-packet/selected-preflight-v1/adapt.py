from pathlib import Path
import json,hashlib
O=Path('/tmp/kgm-packet/selected-preflight-v1'); S=Path('/tmp/mini-packet/selected-preflight-v4')
s=(S/'check.mjs').read_text()
def sub(a,b):
 global s
 assert a in s,a
 s=s.replace(a,b)
sub('exactly ten retained MINI rows','exactly three retained KGM rows')
sub('/tmp/mini-packet/selected-preflight-v4',str(O))
sub('/tmp/mini-packet/mini-2026-10-15-candidate-v3.json','/tmp/kgm-packet/kgm-2026-10-15-candidate-v2.json')
sub('/tmp/mini-research/','/tmp/kgm-research/')
sub('.candidate26','.candidate27')
sub('before.length,10','before.length,3')
sub('base.variants.length,10','base.variants.length,3')
sub('base.feature_evidence.length,690','base.feature_evidence.length,207')
sub('base.feature_evidence_variant_context.length,10','base.feature_evidence_variant_context.length,3')
sub("brandUpdatePackets.length,26);assert.equal(brandUpdatePackets.at(-1).id,'m1-deepal-2026-10-15'", "brandUpdatePackets.length,27);assert.equal(brandUpdatePackets.at(-1).id,'m1-mini-2026-10-15'")
sub("prior.brand,'MINI'", "prior.brand,'KGM'")
sub('after.length,10','after.length,3')
sub('data.variants.length,10','data.variants.length,3')
sub('data.feature_evidence.length,690','data.feature_evidence.length,207')
sub('driveawayFallbacks','driveawayRefreshes')
a="""   assert.equal(feature.value,String(fact.value));assert.equal(feature.buyerGrade,'check');assert.equal(feature.verification_state,'reviewed_brand_au_terms');assert.deepEqual(feature.source_ids,fact.sourceIds);
   assert(feature.conditions.includes(fact.conditionExplanation));assert.match(feature.conditions,/eight years|8 years/i);assert.match(feature.conditions,/five years|5 years/i);roadsideRefreshes++;"""
b="""   assert.equal(feature.value,String(fact.value));assert.equal(feature.buyerGrade,'confirmed');assert.equal(feature.status,'standard');assert.equal(feature.verification_state,'reviewed_brand_au_terms');assert.deepEqual(feature.source_ids,fact.sourceIds);
   for(const condition of fact.qualifications)assert(feature.conditions.includes(condition));assert.match(feature.value,/5 years/);assert.match(feature.value,/1 July 2024/);roadsideRefreshes++;"""
sub(a,b)
a="""   const f=car.facts.price_aud;assert.notEqual(f.comparisonBasis,'Driveaway');assert(!car.facts.promotional_driveaway_aud);assert(!car.facts.published_driveaway_aud);
   const fallback=frames.get('after\\0'+car.id).regraded.find(f=>f.criterion==='driveaway_price');assert.deepEqual(feature,fallback);
   assert.notEqual(feature.verification_state,'reviewed_canonical_driveaway_price');assert.notEqual(feature.verification_state,'reviewed_published_driveaway_price');driveawayRefreshes++;"""
b="""   const fact=car.facts.price_aud;assert.equal(fact.comparisonBasis,'Driveaway');
   assert.equal(feature.value,'A$'+Number(fact.value).toLocaleString('en-AU'));assert.equal(feature.buyerGrade,fact.buyerGrade);assert.equal(feature.status,fact.status);assert.deepEqual(feature.gradeReview,fact.gradeReview);assert.deepEqual(feature.source_ids,fact.sourceIds);
   assert.equal(feature.verification_state,'reviewed_canonical_driveaway_price');assert.equal(feature.last_evidence_date,fact.date);assert.equal(feature.reviewed_date,packet.reviewedAt);
   for(const condition of [...fact.qualifications,...(fact.conditionExplanation?[fact.conditionExplanation]:[])])assert(feature.conditions.includes(condition));
   assert.equal(feature.confirmation_needed,'');assert.deepEqual(feature.usability_notes,[]);assert(!Object.hasOwn(feature,'gradeReviewStatus'));assert.equal(feature.validUntil,fact.validUntil);driveawayRefreshes++;"""
sub(a,b)
sub('assert.equal(car.year,null)','assert.equal(car.year,2026)')
sub('earnedCells,183','earnedCells,68')
sub('featureClaims.length,690','featureClaims.length,207')
sub('roadsideRefreshes,10','roadsideRefreshes,3')
sub('driveawayRefreshes,10','driveawayRefreshes,3')
sub('after.filter(isOnSale).length,10','after.filter(isOnSale).length,3')
sub('ranks.excluded.length,10-ranked.length','ranks.excluded.length,3-ranked.length')
sub("assert.notEqual(o.criterion,'roadside_assistance','Fresh canonical roadside projection must not inherit optional undefined fields');", "assert(!['roadside_assistance','driveaway_price'].includes(o.criterion),'Fresh canonical term/price projection must not inherit optional undefined fields');")
sub('/tmp/mini-packet/mini-market-reconciliation-v3.json','/tmp/kgm-packet/kgm-market-reconciliation-v1.json')
sub('isMini','isKgm')
sub("toUpperCase()==='MINI'","toUpperCase()==='KGM'")
sub('inventory.records.length,3','inventory.records.length,2')
sub('new Set(actualInventoryIds).size,3','new Set(actualInventoryIds).size,2')
sub('reconciliation.inventoryResolutions.length,3','reconciliation.inventoryResolutions.length,2')
a="""const countrymanReview=reconciliation.currentVersionReviews.find(review=>review.id===inventoryProof.countrymanReviewId);
assert(countrymanReview);assert.deepStrictEqual(countrymanReview.publishedModelAliases,[inventoryProof.countrymanAlias]);
assert.deepStrictEqual(countrymanReview.versions.map(version=>version.carId),inventoryProof.countrymanVersionIds);assert.equal(countrymanReview.versions.length,5);
"""
sub(a,'')
sub('c1.reviewedModels,3','c1.reviewedModels,2')
sub('c1.reviewedVersions,10','c1.reviewedVersions,3')
sub('selectedCoverage.allCatalogueVersions,10','selectedCoverage.allCatalogueVersions,3')
sub('selectedCoverage.tierOneVersions,10','selectedCoverage.tierOneVersions,3')
sub('selectedCoverage.onSaleVersions,10','selectedCoverage.onSaleVersions,3')
sub('progress.currentVersionReviews.length,3','progress.currentVersionReviews.length,2')
sub('beforeCars:10,afterCars:10,coreCells:170','beforeCars:3,afterCars:3,coreCells:51')
# Guard all reviewed numeric supplementals independently as well as 17 core fields.
needle="for(const attribute of attributes){"
insert="""for(const row of expected.supplementalRankPolicy){
 const car=after.find(c=>c.id===row.variantId),fact=car.facts[row.key],reason=exclusionReason(car,fact,data.sources,policy);
 assert.deepEqual(fact.issues,row.issues);assert.equal(reason===null,row.eligible,'Supplemental ranking mismatch '+car.id+'/'+row.key);
 rankingProof.push({variantId:car.id,key:row.key,eligible:reason===null,reason,supplemental:true});
}
"""
sub(needle,insert+needle)
# Capture reviewed current identities/core counts, not just claimed result totals.
sub("const data=prepareBrandResearch(base,[packet]);", "assert.equal(packet.versionGuards.length,3);assert.equal(packet.facts.length,59);assert.equal(packet.brandTerms.length,3);assert.equal(packet.brandTerms.reduce((n,t)=>n+t.applicableVariantIds.length,0),9);assert.equal(packet.summaries.length,3);assert.equal(packet.availability.length,3);\nconst data=prepareBrandResearch(base,[packet]);")
(O/'check.mjs').write_text(s)
r=(S/'run.py').read_text().replace('run_single_selected_mini_preflight','run_single_selected_kgm_preflight')
(O/'run.py').write_text(r)
orig=json.loads(Path('/tmp/kgm-packet/inventory-original-records-v1.json').read_text());rec=json.loads(Path('/tmp/kgm-packet/kgm-market-reconciliation-v1.json').read_text())
p=Path(orig['sourcePath']);proof={'checkedAt':'2026-10-15','originalInventory':{'path':str(p),'bytes':p.stat().st_size,'sha256':orig['sourceSha256']},'records':orig['records'],'unverifiedLeads':orig['unverifiedLeads'],'expectedSettlement':['record:'+x['inventoryId'] for x in rec['inventoryResolutions']],'currentVersionReviewIds':[x['id'] for x in rec['currentVersionReviews']],'scope':'Exact two complete inherited KGM records and zero KGM leads; original records retained, not normalized. Two complete current BEV model reviews cover exactly three existing MY26 versions; Black Edge remains the documented 2WD styling pack.'}
(O/'inventory-resolution-review.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False)+'\n')
print({'scriptBytes':(O/'check.mjs').stat().st_size,'executedConsumers':False})
