from pathlib import Path
import hashlib,json,difflib
R=Path('/workspace/scratch/586427eef9f2/roadmark-104');B=Path('/tmp/kgm-packet/registration-v1');B.mkdir(exist_ok=False)
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,b):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
apply=Path('/tmp/mini-packet/registration-v1/apply.py').read_text().replace('apply_exact_mini_registration','apply_exact_kgm_registration')
save(B/'apply.py',apply.encode())
changed={};r='data/m1-brand-updates/registry.json';old=(R/r).read_text();registry=json.loads(old)
assert len(registry['packets'])==27 and registry['packets'][-1]=='mini-2026-10-15.json'
needle='    "mini-2026-10-15.json"\n';assert old.count(needle)==1
changed[r]=old.replace(needle,'    "mini-2026-10-15.json",\n    "kgm-2026-10-15.json"\n').encode()
assert json.loads(changed[r])['packets'][:-1]==registry['packets']
r='scripts/reporting/load.ts';old=(R/r).read_text()
needle='import miniReconciliation from "../../data/m1-mini-market-reconciliation-2026-10-15.json";\n';assert old.count(needle)==1
new=old.replace(needle,needle+'import kgmReconciliation from "../../data/m1-kgm-market-reconciliation-2026-10-15.json";\n')
needle='      miniReconciliation as M1MarketReconciliation,\n';assert new.count(needle)==1
changed[r]=new.replace(needle,needle+'      kgmReconciliation as M1MarketReconciliation,\n').encode()
newfiles={'data/m1-brand-updates/kgm-2026-10-15.json':Path('/tmp/kgm-packet/kgm-2026-10-15-candidate-v2.json'),'data/m1-kgm-market-reconciliation-2026-10-15.json':Path('/tmp/kgm-packet/kgm-market-reconciliation-v1.json')}
rows=[];patch=[]
for rel,content in [*changed.items(),*((r,p.read_bytes()) for r,p in newfiles.items())]:
 target=R/rel;before=target.read_bytes() if target.exists() else None
 assert (before is None)==(rel in newfiles)
 if before is not None:save(B/'before'/rel,before)
 save(B/'after'/rel,content)
 rows.append(dict(relativePath=rel,target=str(target),operation='create' if before is None else 'replace',before=None if before is None else dict(bytes=len(before),sha256=hashlib.sha256(before).hexdigest()),after=pin(B/'after'/rel),beforeCopy=None if before is None else pin(B/'before'/rel)))
 patch.extend(difflib.unified_diff((before or b'').decode().splitlines(True),content.decode().splitlines(True),fromfile='/dev/null' if before is None else 'a/'+rel,tofile='b/'+rel))
save(B/'registration.patch',''.join(patch).encode())
save(B/'prepared-writes.json',(json.dumps(rows,indent=2)+'\n').encode())
save(B/'README.md',b'''# KGM minimal guarded registration\n\nPreparation only. Exactly four writes: two new JSON files, append-only registry position 28, and one import plus final reconciliation argument in the report loader. Candidate v2 and reconciliation v1 remain byte-identical. No helper or test changes.\n\nApplication requires independent full-stage result acceptance, bundle review and a separate exact root application grant. The applicator checks all before hashes and proposed bytes before writing, journals each write, and stops on any failure without automatic retry or rollback. Tests, compilers and normal reports are separately authorized gates.\n''')
print(json.dumps(dict(preparedWrites=pin(B/'prepared-writes.json'),after=[r['after'] for r in rows],status='awaiting_full_stage_output_review_to_freeze_manifest'),indent=2))
