from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,os,stat
B=Path('/tmp/kgm-packet/final-freeze-v1');W=Path('/workspace/scratch/586427eef9f2');R=W/'roadmark-104';REVIEW=Path('/tmp/kgm-review')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def row(p,category):
 p=Path(p);s=p.lstat();r=dict(path=str(p),category=category,bytes=s.st_size,mode=s.st_mode,mtimeNs=s.st_mtime_ns)
 if stat.S_ISLNK(s.st_mode):r.update(kind='symlink',target=os.readlink(p),targetFollowed=False)
 else:assert stat.S_ISREG(s.st_mode),str(p);r['kind']='file'
 return r
out=B/'inventory.json';assert not out.exists()
readback=REVIEW/'docs-status-v1-application-review.json';assert read(readback)['status']=='accepted'
final=REVIEW/'final-retention-v1-acceptance.json';assert not final.exists()
research_manifest=Path('/tmp/kgm-research/research-manifest-v2.json');rm=read(research_manifest)
source_allowlist={p['path']:p for p in rm['sourceFiles']};assert len(source_allowlist)==56
reg=read('/tmp/kgm-packet/registration-v1/manifest.json');docs=read('/tmp/kgm-packet/docs-status-v1/manifest.json')
roots=[('/tmp/kgm-research','sanitized_public_research_and_source_history'),('/tmp/kgm-packet','packet_commands_qa_and_all_attempt_history'),('/tmp/kgm-review','independent_reviews')]
rows=[];excluded=[];seen_sources=set()
for root,category in roots:
 for cur,dirs,files in os.walk(root,followlinks=False):
  dirs.sort();files.sort()
  if Path(cur)==B:dirs[:]=[];continue
  for name in list(dirs):
   p=Path(cur)/name
   if p.is_symlink():rows.append(row(p,category));dirs.remove(name)
  for name in files:
   p=Path(cur)/name;path=str(p)
   if path=='/tmp/kgm-packet/post-registration-checks-v1/.exclusive-heavy.lock':
    item=row(p,'excluded_reconstructible');assert item['bytes']==0
    excluded.append(dict(**item,reason='Empty exclusive lock left by terminal sequential gates; no reconstruction state needed',deletionAuthorized=False));continue
   if name.endswith('.pyc') or '__pycache__' in p.parts:
    excluded.append(dict(**row(p,'excluded_reconstructible'),reason='Reconstructible bytecode; source retained',deletionAuthorized=False));continue
   if p.is_relative_to('/tmp/kgm-research/sources'):
    if path not in source_allowlist:
     excluded.append(dict(**row(p,'excluded_not_in_canonical_source_allowlist'),reason='Not one of the 56 canonical sanitized source files; metadata only, payload must not be read/copied without separate review',deletionAuthorized=False));continue
    declared=source_allowlist[path];item=row(p,'canonical_sanitized_source_allowlist')
    assert item['bytes']==declared['bytes'];item['declaredSha256']=declared['sha256'];item['contentHashRecomputedAtFreeze']=False
    rows.append(item);seen_sources.add(path)
   else:rows.append(row(p,category))
assert seen_sources==set(source_allowlist)
assert not any(x['category']=='excluded_not_in_canonical_source_allowlist' for x in excluded),'Unexpected source path needs separate review'
live=[]
for item in reg['writes']+docs['writes']:
 p=pin(item['target']);assert p['bytes']==item['after']['bytes'] and p['sha256']==item['after']['sha256']
 live.append(p);rows.append(row(item['target'],'live_registered_docs_status_target'))
assert len(live)==7 and len({r['path'] for r in rows})==len(rows)
rows.sort(key=lambda r:r['path'])
failures=[]
for v in [1,2]:
 base=Path(f'/tmp/kgm-packet/full-project-typescript-v{v}');r=read(base/'run/result.json');t=read(base/'run/terminal.json');a=read(base/'run/after-pins.json')
 assert r['passed'] is False and r['fullProjectTypecheckPassed'] is False and r['pinsPassed'] is True
 assert t['exitCode']==-9 and t['rawWaitStatus']==9 and not t['watchdogFired'] and not t['timeoutExitCodeObserved']
 assert a['passed'] is True and a['inputPinCount']==201 and a['liveCacheUnchanged'] and a['configuredRootsUnchanged']
 assert not (base/'run/full-project.tsbuildinfo').exists()
 failures.append(dict(name=f'Cold full-project TypeScript v{v}',terminal=pin(base/'run/terminal.json'),result=pin(base/'run/result.json'),afterPins=pin(base/'run/after-pins.json'),scopeFailure=pin(base/'run/scope-verification.json'),independentFailureReview=pin(REVIEW/f'full-project-typescript-v{v}-failure-review.json'),cause='unknown',freshCacheAbsent=True,fullProjectTypecheckPassed=False,disposition='Preserved actual SIGKILL failure; no compiler retry authorized'))
state=read(W/'roadmark-104-qa/work-status.json');assert state['currentBrand']=='KGM' and state['kgmWorking']['fullProjectTypecheckPassed'] is False and state['kgmWorking']['releaseReady'] is False
x=dict(schemaVersion=1,status='author_frozen_metadata_exact_allowlist_pending_backup_capture_and_independent_final_receipt',frozenAt=datetime.now(timezone.utc).isoformat(),noFurtherPayloadEdits=True,metadataOnlyInventory=True,contentCaptureOrPrivacyScanPerformed=False,inventoryHashScope='Only seven exact live targets and named small receipts/provenance are hashed here. Payload walk records lstat metadata only; source declared hashes are copied from the accepted 56-file canonical manifest, not a fresh payload scan. Backup owns separately authorized capture/privacy scan.',payloadRoots=[root for root,_ in roots],files=rows,totalFiles=len(rows),regularFileBytes=sum(r['bytes'] for r in rows if r['kind']=='file'),symlinkCount=sum(r['kind']=='symlink' for r in rows),sourceAndStatusAfterPins=live,excluded=excluded+[dict(path=str(B),reason='Inventory and preparer pinned separately with reviewer acceptance to avoid circularity',deletionAuthorized=False)],sourceAllowlist=pin(research_manifest),canonicalSanitizedSourceFiles=56,rawRuntimeExclusion=dict(rawRuntimeHTMLOrConfigurationPersisted=False,rawResponseHeadersOrCookiesPersisted=False,credentialOrClientKeyPayloadPersisted=False,locallyPresentExcludedOriginalPaths=[],basis='Accepted research-manifest-v2 requestPolicy and no-value source provenance; raw runtime discarded before persistence; no raw originals were saved',readRefetchOrRecoveryAuthorized=False),publicImageProvenance=dict(imagesGeneratedOrCaptured=False,pdfPageRendersCreated=False,publishedManufacturerPdfDocuments=2,sourceImageOrConfigurationPayloadReconstructionAuthorized=False),knownSanitizedSupport=dict(officialHTML='Visible text and public links only; runtime scripts/styles discarded before persistence, adjacent no-value provenance retained',officialModelData='Two explicit factual field-allowlisted payloads, no authorization headers/cookies/client keys used or retained',PDFs='Two unchanged public manufacturer technical PDFs with text/provenance, included in canonical source allowlist',secondary='Bounded factual public-source evidence with attribution; no third-party prose used as buyer copy',classificationCautions='Credential-related field names and false/empty request flags are no-value provenance. Public source URLs, ordinary model/grade identifiers, source/file hashes, test identifiers and compiler paths are factual/proof material, not secrets.',knownSensitiveValuesRetained=False,privacyScanClaim=False),retainedFailures=failures,otherAttemptHistory=dict(candidateV1='Superseded preparation preserved; final source/static candidate v2 corrects uncontested towing grades, AWD sibling attribution and clean summary dependency',selectedV1='Held unexecuted preparation missing terminal storage pin closure; selected v2 adds all 14 descriptor files before sole accepted selected execution',selectedV2='Accepted selected actual consumers and all207 feature claims,68 effective fact/term claims,exact live/written optional semantics',fullStageV1='Sole accepted bounded full-stage run,exact MINI27 baseline and424 unchanged peer complete cars,all14field digests and21file closure',reportComparatorV1='Held unexecuted preparation requiring a successful TS result that does not exist',reportComparatorV2='Root-directed independently accepted factual-only exception: one actual normal report plus one exhaustive saved comparator; all2381 leaves explained; no TS/release claim',freshValidation='151 scoped behavioral/safety tests,market-view,changed-file lint and structural validation passed; full-project TypeScript unpassed after two unknown-cause SIGKILLs; no current full-suite/build/phone/mobile pass'),currentValidation=dict(fullProjectTypecheckPassed=False,releaseReady=False,compilerRetriesAuthorized=False,factualCoverageOnly=True,priorMiniTypeScriptPass='Historical MINI27 source only'),independentDocsReadback=pin(readback),factualReportAcceptance=pin(REVIEW/'report-comparison-v2-output-review.json'),factualException=pin('/tmp/kgm-packet/report-comparison-v2/typescript-failure-provenance.json'),currentPacket=pin('/tmp/kgm-packet/kgm-2026-10-15-candidate-v2.json'),currentReconciliation=pin('/tmp/kgm-packet/kgm-market-reconciliation-v1.json'),retainedStorageReadClosure=pin('/tmp/kgm-packet/full-stage-v1/storage-read-closure.json'),externalDependencies='Reuse the accepted terminal MINI27 recovery chain and exact referenced prefix20 retained storage, EQA21/Leap22/Mazda23/Skoda24/Audi25/Deepal26/MINI27 proofs/replacement cars and MINI baseline normal report. KGM manifests/21-file actual closure supply exact original logical paths/hashes; backup owns existing-chain mapping without broad recapture. No credentials/raw runtime recovery.',reconstructionNotes='No KGM payload symlinks expected. No node_modules, generated Next build caches, preview snapshot or broad catalogue recapture is added. Neither failed TypeScript attempt produced a fresh cache. Preserve original config/361 configured roots; a later compiler pass would require fresh separate authorization and cannot be inferred from this factual report. Keep exact live/written optional-property producer semantics.',finalReviewerReceiptPolicy=dict(path=str(final),state='future_separate_acceptance_after_inventory_review',includedInPayload=False,reason='Avoid recursive inventory pins; reviewer directory otherwise frozen after docs application review'),preparer=pin(__file__))
assert x['symlinkCount']==0
with out.open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False);f.write('\n')
print(json.dumps(dict(inventory=pin(out),files=x['totalFiles'],bytes=x['regularFileBytes'],symlinks=x['symlinkCount'],liveTargets=7,excludedFiles=len(excluded),fullProjectTypecheckPassed=False,releaseReady=False),indent=2))
