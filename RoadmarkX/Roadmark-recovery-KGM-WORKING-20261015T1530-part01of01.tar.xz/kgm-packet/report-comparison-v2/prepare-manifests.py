from pathlib import Path
import json,hashlib,difflib,copy
old=Path('/tmp/kgm-packet/report-comparison-v1')
new=Path('/tmp/kgm-packet/report-comparison-v2')
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def pin(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=digest(p))
def check(p):assert pin(p['path'])==p,p['path']
def read(p):return json.loads(Path(p).read_text())
def write(name,v):
 with (new/name).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def text(name,v):
 with (new/name).open('x') as f:f.write(v)
def uniq(pins):
 by={}
 for p in pins:
  if p['path'] in by:assert by[p['path']]==p
  by[p['path']]=p
 return [by[k] for k in sorted(by)]
# Pure static adaptation: no report, loader, compiler or comparator invocation.
for f in ['run.py','source-pins.json','static-import-closure.json']:
 with (new/f).open('xb') as out:out.write((old/f).read_bytes())
compare=(old/'compare-report.mjs').read_text()
assert compare.count(str(old))==2
newcompare=compare.replace(str(old),str(new))
text('compare-report.mjs',newcompare)
text('v1-to-v2-comparator.patch',''.join(difflib.unified_diff(compare.splitlines(True),newcompare.splitlines(True),fromfile=str(old/'compare-report.mjs'),tofile=str(new/'compare-report.mjs'))))
fivepin=pin('/tmp/kgm-review/post-registration-v1-output-review.json')
five=read(fivepin['path']);assert five['status']=='accepted'
assert [c['name'] for c in five['checks']]==['market-view','changed-file-lint','behavioural-suites','live-brand-safety','structural-validation']
proofpins=[fivepin,pin('/tmp/kgm-review/registration-v1-application-review.json'),pin('/tmp/kgm-packet/full-project-typescript-v1/provenance-erratum-v1.json')]
for c in five['checks']:
 assert c['passed'] is True and c['exitCode']==0
 proofpins += [c[k] for k in ['manifest','result','terminal']]+c['evidence']
 r=read(c['result']['path']);assert r['passed'] is True and r['exitCode']==0 and r['manifestSha256']==c['manifest']['sha256']
attempts=[]
for v,expected in [(1,'8b83d691018ac3c1f8820df59ea25f5e3af7548e92ba98551fa799b1b0fc8028'),(2,'58d4fe8c49556be75bdab0893bdb5d9d8992a28cc9c34eb6fc57334b25b91332')]:
 base=Path(f'/tmp/kgm-packet/full-project-typescript-v{v}')
 review=pin(f'/tmp/kgm-review/full-project-typescript-v{v}-failure-review.json');assert review['sha256']==expected
 files=['manifest.json','run.py','root-execution-grant.json']+[f'run/{n}' for n in ['invocation.json','registration-target-metadata-before.json','started.json','terminal.json','result.json','after-pins.json','scope-verification.json','stdout.log','stderr.log']]
 filespins=[pin(base/n) for n in files]+[review]
 m=read(base/'manifest.json');r=read(base/'run/result.json');t=read(base/'run/terminal.json');a=read(base/'run/after-pins.json')
 assert r['passed'] is False and r['fullProjectTypecheckPassed'] is False and r['pinsPassed'] is True and r['scopePassed'] is False
 assert r['manifestSha256']==pin(base/'manifest.json')['sha256']
 assert r['exitCode']==t['exitCode']==-9 and t['rawWaitStatus']==9
 assert t['watchdogFired'] is False and t['timeoutExitCodeObserved'] is False
 assert a['passed'] is True and a['inputPinCount']==201 and a['liveCacheUnchanged'] is True and a['configuredRootsUnchanged'] is True
 assert not (base/'run/full-project.tsbuildinfo').exists()
 assert m['command'][1:3]==['--max-old-space-size=768','--max-semi-space-size=1'] and m['timeoutSeconds']==900 and m['killAfterSeconds']==10
 filespins += [m['inputPins'],m['projectRootMetadata']]
 proofpins += filespins
 attempts.append(dict(version=v,manifest=pin(base/'manifest.json'),result=pin(base/'run/result.json'),terminal=pin(base/'run/terminal.json'),afterPins=pin(base/'run/after-pins.json'),scopeVerification=pin(base/'run/scope-verification.json'),failureReview=review,exitCode=-9,rawWaitStatus=9,elapsedSeconds=t['elapsedSeconds'],maxRssKiB=t['maxRssKiB'],cause='unknown',freshCachePath=str(base/'run/full-project.tsbuildinfo'),freshCacheAbsentAtPreparation=True,fullProjectTypecheckPassed=False))
proofpins=uniq(proofpins)
for p in proofpins:check(p)
status=dict(status='coverage_validation_preparation_with_full_project_typescript_unpassed',fullProjectTypecheckPassed=False,releaseAcceptanceClaim=False,compilerRetriesAuthorized=False,priorFailureCause='unknown',attempts=attempts,acceptedFiveGateReview=fivepin,acceptedRegistrationReview=pin('/tmp/kgm-review/registration-v1-application-review.json'),currentInputVerification='The unchanged generic wrapper rechecks all 214 source pins, original tsconfig, all 361 configured roots, 360 unchanged root stats, runtime/directory state and four exact registration targets before and after each independent coverage gate.',cacheAbsenceLimit='Both failed attempts generated no fresh cache. Absence was observed at preparation and independently reviewed; neither attempt supplies a successful 361-root compiler completion proof.',proofPins=proofpins)
write('typescript-failure-provenance.json',status)
proofpins += [pin(new/'typescript-failure-provenance.json')]
readme=(old/'README.md').read_text()
start=readme.index('## Exactly one ordinary production report')
readme=('# KGM28 independent coverage report and saved comparison, v2\n\n'
 'Prepared only. KGM full-project TypeScript remains unpassed after two unknown-cause SIGKILL failures. Both failed attempts, empty streams, absent fresh caches and unchanged-input receipts are preserved and pinned. No compiler retry is included. A successful coverage report/comparison would establish only its factual coverage assertions; it would not establish typecheck, build or release acceptance.\n\n'
 '## Explicit prerequisite exception\n\n'
 'Root requested independent coverage validation after stopping compiler retries. This version replaces the nonexistent successful-TypeScript prerequisite with the five exact accepted post-registration gates and accepted registration, plus pinned evidence for both failed TypeScript attempts. The generic wrapper remains byte-identical to v1, including all input/config/root/runtime/target guards. Every actual report and comparator assertion and resource limit is unchanged. Independent review and a fresh exact root grant are still required.\n\n'
 'The source pin list and static import closure are byte-identical to v1. All 21 descriptor-bound retained files remain in pre/post closure. Failure-provenance and all accepted gate receipts are also in both commands\' pre/post extra pins. The comparator differs only in its two output-directory literals. Version 1 is retained unchanged.\n\n'+readme[start:])
readme=readme.replace(str(old),str(new)).replace('compare-report.mjs is byte-identical to the separately frozen compare-report-draft.mjs.','compare-report.mjs differs from the accepted v1 executable and separately frozen draft only in its two prep/qa directory literals, now pointing to v2. Every assertion is unchanged.')
text('README.md',readme)
normal=read(old/'normal-coverage-asof-2026-10-15.json');comparison=read(old/'report-comparison.json')
for m in [normal,comparison]:
 m['qaRoot']=str(new);m['runOutput']=str(new/m['id'])
 m['wrapper']=pin(new/'run.py');m['sourcePins']=pin(new/'source-pins.json')
 m['fullProjectTypecheckPassed']=False;m['releaseAcceptanceClaim']=False
 m['independentCoverageException']=pin(new/'typescript-failure-provenance.json')
 replaced=[]
 for p in m['extraPins']:
  if p['path'].startswith(str(old)+'/'):
   replaced.append(pin(new/Path(p['path']).name))
  else:replaced.append(p)
 m['extraPins']=uniq(replaced+proofpins+[pin(new/'README.md')])
normal['prerequisites']=[{'manifest':c['manifest'],'resultPath':c['result']['path']} for c in five['checks']]
write('normal-coverage-asof-2026-10-15.json',normal)
comparison['command'][-1]=str(new/'compare-report.mjs');comparison['comparisonResult']=str(new/'artifacts/result.json')
comparison['prerequisites']=[{'manifest':pin(new/'normal-coverage-asof-2026-10-15.json'),'resultPath':str(new/'normal-coverage-asof-2026-10-15/result.json')}]
write('report-comparison.json',comparison)
seq=read(old/'sequence.json')
seq['qaRoot']=str(new);seq['sourcePins']=pin(new/'source-pins.json')
seq['sequence']=[pin(new/n) for n in ['normal-coverage-asof-2026-10-15.json','report-comparison.json']]
seq['priorChecksAndFullProjectTypeScriptRequired']=False
seq['acceptedFiveChecksAndRegistrationRequired']=True
seq['fullProjectTypecheckPassed']=False;seq['releaseAcceptanceClaim']=False
seq['independentCoverageException']=pin(new/'typescript-failure-provenance.json')
seq['successfulTypeScriptPrerequisiteReplacedBy']='Explicitly preserved two failed attempts and unchanged input/config/root verification plus accepted five gates/registration; factual coverage validation only.'
write('sequence.json',seq)
g=read(old/'root-grant-template.json');g['granted']=seq['sequence'];g['sequence']=pin(new/'sequence.json')
g['fullProjectTypecheckPassed']=False;g['releaseAcceptanceClaim']=False;g['independentCoverageException']=pin(new/'typescript-failure-provenance.json')
write('root-grant-template.json',g)
assert (new/'run.py').read_bytes()==(old/'run.py').read_bytes()
assert newcompare.replace(str(new),str(old))==compare
assert normal['command']==read(old/'normal-coverage-asof-2026-10-15.json')['command']
assert normal['timeoutSeconds']==900 and comparison['timeoutSeconds']==180 and normal['killAfterSeconds']==comparison['killAfterSeconds']==10
assert normal['originalConfig']==comparison['originalConfig']==read(old/'normal-coverage-asof-2026-10-15.json')['originalConfig']
for m in [normal,comparison]:
 for p in json.loads(Path(m['sourcePins']['path']).read_text())+m['extraPins']+[m[k] for k in ['wrapper','sourcePins','rootMetadata','testInventory','registrationManifest']]:check(p)
write('static-same-scope-proof.json',dict(executed=False,oldSequence=pin(old/'sequence.json'),newSequence=pin(new/'sequence.json'),wrapperByteIdentical=True,normalCommandByteIdentical=True,comparatorOnlyTwoOutputDirectoryLiteralsChanged=True,allComparatorAssertionsUnchanged=True,all214SourcePinsByteIdentical=True,originalConfig361RootsAndRegistrationGuardsUnchanged=True,same448MiBOldSpace1MiBSemiSpace=True,normal900SecondComparator180SecondTimeoutsUnchanged=True,tenSecondGraceUnchanged=True,normalExtraPins=len(normal['extraPins']),comparisonExtraPins=len(comparison['extraPins']),bothFailedTypeScriptAttemptsPreserved=True,acceptedFivePrerequisites=True,fullProjectTypecheckPassed=False,releaseAcceptanceClaim=False))
print(json.dumps({'sequence':pin(new/'sequence.json'),'normal':pin(new/'normal-coverage-asof-2026-10-15.json'),'comparison':pin(new/'report-comparison.json'),'wrapper':pin(new/'run.py'),'staticProof':pin(new/'static-same-scope-proof.json')},indent=2))
