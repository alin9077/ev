# KGM28 bounded full-stage plan

Preparation only. Candidate v2 and reconciliation v1 are independently source/static accepted. Selected preflight v2 ran once under explicit root authority and passed; its actual outputs are independently accepted. This full-stage command requires its own independent readiness review and fresh root execution grant. No live edit, heavy command or normal production report is authorized by this plan.

## Fixed scope

- Accepted MINI27: 427 catalogue versions, 350 Tier 1, 309 on sale, 27 packets
- Proposed KGM28: the same 427 / 350 / 309, 28 packets; no models, versions, identity/MY, configuration or manual equipment additions
- Three existing MY26 KGM cars may change: Musso EV 2WD, Musso EV AWD and Torres EVX FWD. All 424 peer complete-car digests, values, sources, identities and order remain exact
- 59 specific fact updates plus nine shared-term applications; 51 core cells and 68 effective updated cells. Core grades: 41 Confirmed, two Check, three Reported and five Not published
- 207 complete selected feature claims: only three canonical driveaway and three roadside projections may change. All other complete feature rows remain exact
- Two complete current model reviews cover three exact identities; both complete inherited KGM inventory records settle. Black Edge remains the documented 2WD styling pack, with generic AWD payload linkage disclosed rather than used to invent a grade
- Global C1 remains false; no whole-market independent list or national-best claim is invented

## Retained baseline and exact transition chain

Restore retained409/prefix20 once through the existing accepted readCompleteCars/readResearch path. Compare each accepted ordered complete-car digest array and all 14 complete research-field digests against the accepted MINI full-stage outputs:

1. baseline20: 409 cars
2. corrected21 EQA: 409
3. current22 Leapmotor: 413
4. current23 Mazda: 413
5. current24 Skoda: 417
6. candidate25 Audi: 427
7. candidate26 Deepal: 427
8. candidate27 MINI: 427

The exact variant/car order and cumulative packet IDs must match every step. Do not replay packets 1–20, recapture canonical storage, create a whole-catalogue cache or invoke a production catalogue loader.

Current production helpers stay unchanged. Metadata composition owns only metadata.brand_update_packet_ids; every other prepare output field retains its returned reference and all original inputs remain unchanged. Strict whole-value plain-JSON validation precedes digests, rejecting own-undefined, accessor, symbol, nonfinite and sparse changes. Selected live objects retain pre-call structured clones.

The runtime storage closure is exactly three indexes, three replacement files, one original complete-car JSONL stream and 14 top-level research streams. All 21 exact files are pinned before and after; runtime-observed references must equal that closure and the accepted manifest descriptors. This is retained input verification, not recapture or a new cache.

## Apply only KGM28

The candidate applies after exact identity/fact/term/availability/summary guards. Preserve all old source rows; append exactly 16 KGM sources. No raw feature, historical context, model or peer variant change is allowed. Unaffected selected-car fields and facts stay exact; all 424 complete peers and their complete digest array remain exact.

Inspect complete accepted research/cars, all prior packets and the pinned raw overlay inputs for any pre-existing reference to the new source IDs, including nested grade reviews and dictionary keys. Such a reference is a blocker because newly appended evidence could otherwise revive a peer claim. Prior packets and terms must have disjoint targets. With unchanged helpers, raw rows, peer facts and old sources plus source-reference neutrality, perform no extra broad effective-feature replay.

The three staged cars must equal accepted selected-v2 output exactly. Run actual before/after packs only for those three cars through the unchanged evidence consumer with isolated registry injection and throwing default loaders. Reproduce 68 fact/term claims, 207 feature claims, six summary clauses with ten clean exact dependencies, full source closure, three availability guards, true rankings and the two-record inventory proof.

## Producer-owned serialization boundaries

Preserve the accepted selected producer checks. Live portable hydration equals complete live packs; written hydration and readback equal only a separately cloned representation with exact proven own-enumerable-undefined paths removed. No general undefined stripping or guessed count is allowed.

Every feature omission must be tied to the same-run source/regraded/final row, exact index/criterion/property and auditedFeature(raw) where applicable. Every citation omission must be the exact limitation/checked field owned by actual citable producer replay. Reconstruct accepted written claims through the actual factClaim/featureClaim producers before live comparison. Full selected artifact hashes must match the separately accepted selected run.

For selected/global C1, permit only independent_lists issue brand/reference own-undefined properties proven by actual buildMarketReconciliation fixture output. No other report property is silently normalized.

## Actual rankings and complete C1 expectations

Run real structural ranking/current-list consumers over the restored cars without all-car feature computation. Preserve full peer membership, facts, values, bases, units and relative order inside each exact vehicle-class/basis/unit group. Changes to selected membership can reorder whole groups by their size; verify actual production count-descending then basis.localeCompare ordering with independently established bucket-insertion tie order. Verify ranks/ties from numeric values and exact unchanged peer exclusions/unranked details.

For KGM: all three exact driveaway prices, WLTP ranges, DC 10–80% times, lengths and seat counts rank in their explicit compatible groups. Two clean tow ratings and Torres VDA boot rank. AWD towing conflict, Reported peaks, batteries without gross/net basis, widths without mirror convention, five Not published gaps, supplemental AC/tow/GCM/towball conflicts and metallic offer remain unranked. Only the two exact supplemental payload maxima are eligible.

Reproduce the baseline C1 object against both accepted MINI stage output and its successful saved ordinary normal report before adding KGM. Proposed C1 is independently constructed from every frozen baseline field plus the exact KGM evidence arrays:

- Reviewed models: 101 to 103
- Reviewed versions: 231 to 234
- Exactly three KGM version-unreviewed and two inventory-unresolved issues removed; every other issue unchanged
- Exactly two KGM inventory records settled in original inventory traversal order
- Every prior review, disposition, list counter, evidence array and other field unchanged, except explicitly appended KGM evidence and recomputed registry date
- Complete written C1 equality required; global pass remains false
- Catalogue/Tier 1/on-sale denominators remain 427 / 350 / 309

## Separate later gates

Only after independent full-stage acceptance and separate root authority may the exact candidate/reconciliation be copied and registered, with bounded documentation changes. No helper change is proposed.

One later ordinary production coverage report, in a separately granted exclusive slot, supplies its inherent exhaustive feature/reporting pass. Do not duplicate it here. Compare saved output to accepted MINI27 report: exact non-KGM brand objects, peer gaps/summary/freshness, inventories/leads, complete source/grade explanations, compatible-group memberships/order/exclusions and explicitly derived aggregate KGM deltas. Preserve failed comparator evidence; do not rerun the normal report merely to fix a comparator.

## Envelope and stopping boundary

One Node process: 448 MiB old-space / 1 MiB semi-space, explicit GC, 420 seconds plus 10-second termination grace. Record wait4 terminal/resource evidence, stdout/stderr hashes and before/after input pins. Heap flags are not OS RSS limits. Fresh explicit root grant and exclusive heavy slot are required; no automatic retry.

Create-only outputs remain within this full-stage directory: cumulative transition metadata, complete-car and all-14-field digest receipts, observed 21-file closure, source-reference proof, three selected cars/packs/portable/claims/witnesses, real global compatible-group ranking proof, baseline/proposed complete C1, and final structural receipt. No full-catalogue/all-feature cache, production edit, registration, archive, server, browser or publication.

A changed input, undeclared mutation, novel optional property, producer mismatch, unaccounted C1/rank difference, source-reference reuse or timeout stops the run and preserves raw evidence. Do not raise memory, weaken guards or retry without separate review and root authority.
