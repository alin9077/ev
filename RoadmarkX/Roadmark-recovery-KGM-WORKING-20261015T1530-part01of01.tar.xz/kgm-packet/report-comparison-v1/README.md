# KGM28 normal-report and exhaustive saved-comparison plan

Prepared only. This is a later gate, separate from registration, five scoped validations and the genuine full-project TypeScript check. The comparator draft is saved for review; no production report, comparator, production loader, test or compiler has run during this preparation.

## Prerequisites and freeze boundary

Exact KGM28 registration/readback is now accepted. These executable manifests remain unexecuted and require all five fresh validation outcomes, fresh full-project TypeScript acceptance, independent readiness and exact root grants before running. Freeze the existing generic gate wrapper, current report import closure, exact 28 registry packets, four live registration hashes/stat records, unchanged configured-root/runtime metadata and accepted validation receipts. Pin the later independent registration-readback receipt rather than inventing it now.

The comparator must separately pin its exact draft-to-final bytes, source/static/full-stage/selected output receipts, accepted MINI baseline report/terminal/review, KGM full-stage artifacts, all replacement-car files, actual production helpers, and all 21 descriptor-derived retained storage files. Every runtime-consumed retained input must be in pre/post closure. Freeze a sequence for one normal report followed by one saved-output comparator. Independent readiness and fresh root exclusive-slot grants are mandatory.

## Exactly one ordinary production report

Working directory: /workspace/scratch/586427eef9f2/roadmark-104

Command uses pinned installed Node with 448 MiB old-space / 1 MiB semi-space, installed tsx, and the unchanged scripts/report-coverage.ts --as-of 2026-10-15 --json. Timeout 900 seconds plus 10-second TERM-to-KILL grace and 20-second supervisor margin. Use the accepted generic wrapper's resource/pin/config/root-stat checks and create-only output path /tmp/kgm-packet/report-comparison-v1/normal-coverage-asof-2026-10-15.

This actual report invokes normal loadReportInput and its inherent full effective-feature work. Do not substitute a selected/staged report, stub the loader, create a new all-car feature cache, or run another broad feature replay. Preserve exact stdout, stderr, terminal/resource evidence and before/after pins. Existing helpers and reporting source remain unchanged.

## Saved comparator

Planned command: pinned installed Node, 448/1 MiB, installed tsx, /tmp/kgm-packet/report-comparison-v1/compare-report.mjs. Timeout 180 seconds plus 10-second grace. This process reads the newly saved normal report; it never reruns the report.

compare-report.mjs is byte-identical to the separately frozen compare-report-draft.mjs. Any later correction requires a new independently reviewed version. Output artifacts are create-only under /tmp/kgm-packet/report-comparison-v1/artifacts. Baseline is accepted MINI27 normal report /tmp/mini-packet/report-comparison-v2/normal-coverage-asof-2026-10-15/stdout.log, SHA256 0cd717ad3b1db049e14559010770b9b5dfb1e9ed05718ca7635d82a6bbde4464.

## Required comparison proofs

1. Verify saved report terminal exit/hash and fixed 427 catalogue / 350 Tier 1 / 309 on-sale denominators, as of 2026-10-15
2. Preserve every non-KGM complete brandProgress object exactly. KGM's whole object must equal the independently accepted actual selected coverage, including C1/C2/C5 false, C3/C4/C6 true and researchCompleted true
3. Restore retained409/prefix20 and overlay only accepted written complete-car replacements through EQA21, Leap22, Mazda23, Skoda24, Audi25, Deepal26 and MINI27. Every ordered complete-car digest must match the independently accepted stage arrays. Replace only the three KGM cars to match candidate28; 424 peer complete-car digests remain exact
4. Stream only the three selected feature contexts/rows from the exact 14 retained research fields, preserve shared source arrays, and reconstruct complete baseline/proposed source registries to exact accepted all-field source digests. No peer features are computed
5. Recompute only the three old KGM feature packs (207 rows) with actual source/regrade/brand/term producers. Bind exact producer-owned optional fields to the accepted selected witnesses. All 201 non-price/non-roadside selected features remain exact. Actual selected-before coverage must reproduce the whole baseline KGM brand object
6. Reconstruct every global core field with actual production coreCoverage/coreFact/gradePattern over all digest-verified on-sale cars and complete source arrays. Preserve the original car traversal order. Compare all 17 complete baseline core objects/gaps, every proposed filled/reviewed/grade/rate value, and the full reason inventory, including reasons omitted from shortened display strings. No inference from a truncated top-reasons tail
7. Check selected before/after core deltas independently against complete global output. Record each field's full before/after reason counts and explanations. Confidence and ranking compatibility stay separate; no quotas or generic-caveat downgrades
8. Use accepted full-stage ranking groups and the exact production group comparator. Verify peer membership/value/basis/unit and relative order within compatible groups, selected numeric interleaving, complete-group ordering and stable bucket-insertion ties. Reconstruct every full rankedIds/groups/excluded array and reason count, not merely its set
9. Reconstruct full summaryGaps, missingModels, unresolvedLeads and ageing overdue/invalid/excludedHistory arrays in the actual producer's complete order: catalogue traversal for car rows, original inventory order for records/leads, and all fact/availability rows before the feature phase for ageing. No unexplained append order or sorted-set substitute
10. Global C1 must equal the independently accepted full-stage complete object: 103 model reviews, 234 reviewed versions, exactly five KGM blockers removed, two inventory records settled, all other evidence/dispositions/counters unchanged, global pass false
11. Account all remaining aggregate fields explicitly: paired summaries, all-rank intersection, 17-field reviewed totals/rates, grade note, completed/remaining brand lists, freshness counts and every C1–C6 summary/detail. Compare the entire final expected report object with the actual normal report, with zero ignored leaves
12. Preserve exact own-undefined C1 brand/reference semantics through a real producer fixture, and require nonmutation of complete cars/sources, selected before/after facts/packs/results, prior features and packet. Default catalogue loaders must stay unused in the comparator

## Outputs and failure handling

Preserve exhaustive baseline-versus-normal changed leaves, explicit expected-versus-normal diff, complete core-reason inventories, rank/group/order proofs, full-array order proof, selected old feature/report/freshness artifacts, formatted normal report and final comparison receipt. A pass requires zero unexplained differences and every actual producer/source/digest invariant.

No automatic retry or resource escalation. A failed normal report ends that grant. A failed comparator preserves the normal report and comparator evidence; fix only the comparator under a separately reviewed versioned command if justified. Never rerun the expensive normal report merely to repair comparison code. No live helper/test edit, publication, archive, browser/server or user-computer operation is included.
