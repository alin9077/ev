import json,pathlib,hashlib,copy,collections
R=pathlib.Path('/tmp/kgm-research');P=pathlib.Path('/tmp/kgm-packet');repo=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104');D='2026-10-15';PID='m1-kgm-2026-10-15';prefix='m1_kgm_20261015_'
def read(p):return json.loads(pathlib.Path(p).read_text())
def write(p,x):
 with pathlib.Path(p).open('x') as f:f.write(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
 return {'path':str(p),'bytes':pathlib.Path(p).stat().st_size,'sha256':hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()}
rows=read(R/'retained-before-cars.json');byid={c['id']:c for c in rows};manifest=read(R/'research-manifest-v1.json');observations=copy.deepcopy(read(R/'core-observations-v1.json')['facts']);sources=[]
for s in manifest['sourceIndex']:
 name=s['id'];file=R/'sources'/(name+('.pdf' if 'specs' in name else '.txt'));prov=R/'sources'/(name+'-provenance.json')
 source={'id':prefix+name.replace('-','_'),'url':s['url'],'title':f"{s['publisher']} — {name.replace('-',' ')}",'publisher':s['publisher'],'source_type':'manufacturer_au_publication' if s['publisher']=='KGM Australia' else 'independent_safety_authority' if s['publisher']=='ANCAP' else 'secondary_publication','published_date':None,'accessed_date':D,'market':'AU','supports':'Exact Australian current vehicle identity, specification, offer or ownership term as mapped in the bounded KGM source audit.','capturePath':str(file),'captureSha256':hashlib.sha256(file.read_bytes()).hexdigest(),'provenancePath':str(prov)}
 if name in ['model-musso','model-torres']:
  payload=R/'sources'/('musso-public-model-v2.json' if name=='model-musso' else 'torres-public-model-v2.json')
  source.update(factualPayloadPath=str(payload),factualPayloadSha256=hashlib.sha256(payload.read_bytes()).hexdigest(),payloadProvenancePath=str(payload.with_name(payload.stem+'-provenance.json')),supports='Visible current maker page plus explicitly allowlisted public modelData grades and exact-grade feature_sets.docs; no runtime credentials or undocumented endpoint used.')
 sources.append(source)
sourceMap={s['id']:s for s in sources}
sid=lambda ids:[prefix+x.replace('-','_') for x in ids]
labels={'price_aud':'Published driveaway price','range_km':'WLTP combined range','battery_kwh':'Declared battery capacity','dc_peak_kw':'Reported maximum vehicle DC charging','dc_charge_time_min':'DC 10–80% charging time','ac_kw':'Onboard AC charging power','seats':'Seats','boot_l':'Boot with seats up to seatback','zero_to_100_s':'0–100 km/h','power_kw':'Combined system power','drive':'Drive type','length_mm':'Length','width_mm':'Declared width','height_mm':'Height','towing_braked_kg':'Braked towing','warranty':'Vehicle warranty','battery_warranty':'Battery warranty'}
packet={'schemaVersion':1,'id':PID,'brand':'KGM','reviewedAt':D,'reviewedBy':'dot KGM source research; independent review pending','sources':sources,'models':[],'variants':[],'versionGuards':[],'versionUpdates':[],'facts':[],'features':[],'configurationUpdates':[],'brandTerms':[],'availability':[],'summaries':[]}
for c in rows:packet['versionGuards'].append({'variantId':c['id'],'before':{k:c.get(k) for k in ['id','modelId','brand','model','trim','year','generation','vehicleClass','drive']}})
def make(c,key,val,unit,basis,comparison,ids,grade='confirmed',qual=None,condition='',reason='',issues=None,label=None,scope=None,term=False):
 ids=sid(ids); gscope='brand_au_terms' if term else 'searched_not_found' if grade=='not_published' else 'secondary_or_sibling' if grade=='reported' else 'exact_au_version'
 return {'key':key,'label':label or labels.get(key,key.replace('_',' ').capitalize()),'value':val,'unit':unit,'basis':basis,'comparisonBasis':comparison,'status':'standard' if grade=='confirmed' else 'not_verified' if grade=='not_published' else 'conditional','sourceIds':ids,'date':D,'market':'AU','scope':scope or f"Australian MY26 KGM {c['model']} {c['trim']}; exact retained identity",'qualifications':qual or [],'issues':issues or [],'conditionExplanation':condition,'resolvedElsewhere':grade=='reported','buyerGrade':grade,'gradeReview':{'reviewedAt':D,'overlayId':PID,'reason':reason or 'Current Australian maker evidence for this exact published claim; generic laboratory/build caveats do not reduce confidence.','evidenceScope':gscope,'sourceIds':ids,'sourceLabel':'; '.join(dict.fromkeys(sourceMap[x]['publisher'] for x in ids))}}
def add(c,f):
 assert not any(e['variantId']==c['id'] and e['after']['key']==f['key'] for e in packet['facts']);packet['facts'].append({'variantId':c['id'],'before':copy.deepcopy(c['facts'].get(f['key'])),'after':f});return f
mussoModel='kgm_musso_ev_current'
def issue(name,title,ids,action='Retain both published maker observations, qualify the figure and exclude it from normalized comparisons until applicability is resolved.'):
 return {'issue_id':PID+'-'+name,'title':title,'priority':'important','model_ids':[mussoModel],'publication_action':action,'source_ids':sid(ids)}
towingIssue=issue('musso-awd-towing','Musso AWD braked-towing and GCM claims disagree',['musso-current-specs','model-musso','musso-launch'])
towballIssue=issue('musso-awd-towball','Musso AWD towball limit is 230 kg in PDF versus 180 kg in exact-grade webpage',['musso-current-specs','model-musso','musso-launch'])
acIssue=issue('musso-ac-time','Musso 0–100% AC time is 10 h 20 min in PDF versus approximately 10 h in grade webpage',['musso-current-specs','model-musso'])
amendments=[]
for o in observations:
 c=byid[o['carId']];k=o['key']
 if k in ['warranty','battery_warranty']:continue
 if k=='towing_braked_kg' and c['drive']!='AWD':
  old=copy.deepcopy(o);o['buyerGrade']='confirmed';o['reason']='Exact current maker braked rating is uncontested. Generic state, towbar and loading restrictions remain attached without downgrading its evidence grade.';amendments.append({'carId':c['id'],'key':k,'before':old,'after':copy.deepcopy(o)})
 comp=o['comparisonBasis'];unit=o['unit']
 if k=='price_aud':comp='Driveaway'
 elif k=='dc_charge_time_min':comp='10–80%';unit='min'
 elif k=='zero_to_100_s':unit='s'
 elif k=='boot_l' and o['value'] is not None:comp='VDA; all seats up; loaded to top of seatback'
 elif k=='seats':comp='Seats';unit=''
 elif k in ['length_mm','height_mm']:comp='Overall '+k.replace('_mm','')
 elif k=='ac_kw':comp='Onboard AC charger power'
 elif k=='power_kw':comp='Combined system output' if c['model']=='Musso EV' else 'Maximum motor output'
 cond=''
 if o['buyerGrade']=='check':cond=o['reason']+' '+(' '.join(o['qualifications']))
 if k=='dc_peak_kw':
  cond='Reported by CarsGuide; maker sources identify station ratings rather than vehicle peak acceptance.'
  if c['drive']=='AWD':cond='Carried from the CarsGuide Musso EV 2WD review/model-wide charging statement; exact AWD maximum is not independently established. This is secondary/sibling evidence, not an exact-AWD maker claim.'
 f=make(c,k,o['value'],unit,o['basis'],comp,o['sourceIds'],o['buyerGrade'],o['qualifications'],cond,o['reason'],[towingIssue] if k=='towing_braked_kg' and c['drive']=='AWD' else [])
 if k=='price_aud':f['priceEvidence']={'rung':2 if c['model']=='Musso EV' else 3,'basisTag':"Maker's national driveaway" if c['model']=='Musso EV' else "Maker's driveaway-from offer",'sourceKey':'recommended_driveaway_aud' if c['model']=='Musso EV' else 'maker_driveaway_offer_aud','sourcePointer':sourceMap[sid(['model-musso' if c['model']=='Musso EV' else 'model-torres'])[0]]['url']+'#/modelData/grades/'+('25/price' if c['drive']=='AWD' else '24/price' if c['model']=='Musso EV' else '23/price'),'publisher':'KGM Australia','originalBasis':'Recommended driveaway pricing for private buyers; Grand White; metallic paint extra' if c['model']=='Musso EV' else 'Driveaway from price for MY26 Torres EVX built in calendar 2025; factory bonus already included; Grand White','rankingEligible':True}
 add(c,f)
# Clean, freshly bound summary dependencies and visible supplemental disagreements.
for c in rows:
 if c['model']!='Musso EV':continue
 awd=c['drive']=='AWD'
 add(c,make(c,'payload_kg',805 if awd else 905,'kg','Maker published maximum payload','Published maximum payload',['musso-current-specs','model-musso'],qual=['Occupants, accessories, cargo and towball load consume payload; this is not a promise of simultaneous maximum towing and payload.'],label='Published maximum payload'))
 add(c,make(c,'rear_suspension','Multi-link with self-levelling shock absorbers','','Maker Australian rear-suspension specification','',['musso-current-specs'],label='Rear suspension'))
 accond='Current linked technical sheet states approximately 10 h 20 min; exact maker grade payload states approximately 10 hours, both 0–100% using an 11 kW station. The onboard AC charger rating remains 10.5 kW.'
 add(c,make(c,'ac_charge_time0to100',620,'min','Maker PDF: 0–100% on 11 kW AC station','',['musso-current-specs','model-musso'],'check',condition=accond,issues=[acIssue],label='Published full AC charging time'))
 add(c,make(c,'published_web_ac_charge_time_0_100_min',600,'min','Maker grade webpage: approximately 0–100% on 11 kW AC station','',['model-musso','musso-current-specs'],'check',condition=accond,issues=[acIssue],label='Webpage full AC charging observation'))
 if awd:
  towcond='PDF and current grade publish 2,300 kg braked towing; live launch copy publishes 1,800 kg. PDF GCM is 5,390 kg versus launch 4,890 kg. No applicable VIN, production cutoff or retroactive homologation scope is established.'
  add(c,make(c,'gcm_kg',5390,'kg','Current linked maker PDF gross combined mass','',['musso-current-specs','musso-launch'],'check',condition=towcond,issues=[towingIssue],label='Gross combination mass'))
  add(c,make(c,'published_launch_gcm_kg',4890,'kg','Still-live maker launch article gross combined mass','',['musso-launch','musso-current-specs'],'check',condition=towcond,issues=[towingIssue],label='Launch-article GCM observation'))
  add(c,make(c,'published_launch_towing_braked_kg',1800,'kg','Still-live maker launch article braked towing','',['musso-launch','musso-current-specs'],'check',condition=towcond,issues=[towingIssue],label='Launch-article towing observation'))
  ballcond='Current PDF specifies 230 kg maximum towball download; exact AWD public grade feature set and live launch article specify 180 kg. Confirm the applicable vehicle and towbar limits; no production cutoff is established.'
  add(c,make(c,'towball_download',230,'kg','Current linked maker PDF maximum towball download','',['musso-current-specs','model-musso','musso-launch'],'check',condition=ballcond,issues=[towballIssue],label='Published maximum towball download'))
  add(c,make(c,'published_web_towball_download_kg',180,'kg','Exact maker AWD grade maximum towball load','',['model-musso','musso-current-specs'],'check',condition=ballcond,issues=[towballIssue],label='Webpage towball observation'))
# Keep directly displayed metallic-paint offer separate; never derive a total.
t=next(c for c in rows if c['model']=='Torres EVX')
add(t,make(t,'published_metallic_driveaway_aud',53690,'AUD','Maker displayed driveaway price including metallic paint','',['model-torres','offers'],'check',qual=['MY26 EVX built in 2025; limited time and while stocks last; KGM EV accredited dealers.'],condition='Maker model-page price explicitly includes metallic paint. Base Grand White offer is separately published at A$52,990. The factory bonus is already included.',label='Metallic-paint driveaway offer'))
# Shared terms are a single reviewed source of truth with exact prior Fact guards.
for key in ['warranty','battery_warranty']:
 o=next(x for x in observations if x['key']==key);f=make(rows[0],key,o['value'],'',o['basis'],'',o['sourceIds'],'confirmed',o['qualifications'],reason=o['reason'],scope='All three reviewed Australian MY26 KGM BEV versions',term=True)
 packet['brandTerms'].append({'key':key,'fact':f,'applicableVariantIds':[c['id'] for c in rows],'before':{c['id']:copy.deepcopy(c['facts'].get(key)) for c in rows},'exceptions':[]})
f=make(rows[0],'roadside_assistance','5 years from first registration on or after 1 July 2024','','Australian brand roadside assistance program','',['roadside'],'confirmed',qual=['First registrations before 1 July 2024 retain seven-year roadside cover. Program terms and limits remain separate from vehicle/battery warranty.'],scope='All three reviewed Australian MY26 KGM BEV versions; registration-date policy boundary retained',term=True,label='Roadside assistance');f['roadsideFitment']='standard'
packet['brandTerms'].append({'key':'roadside_assistance','fact':f,'applicableVariantIds':[c['id'] for c in rows],'before':{c['id']:copy.deepcopy(c['facts'].get('roadside_assistance')) for c in rows},'exceptions':[]})
for i,c in enumerate(rows,1):
 ids=sid(['model-musso','musso-current-specs'] if c['model']=='Musso EV' else ['model-torres','torres-current-specs'])
 packet['availability'].append({'id':PID+'-availability-'+str(i),'variantId':c['id'],'before':{'availability':c['availability'],'evidence':copy.deepcopy(c['availabilityEvidence'])},'after':{'availability':c['availability'],'evidence':{'checkedAt':D,'orderStatus':'listed_unconfirmed','stockStatus':'unverified','physicalStockVerified':False,'factoryOrderAcceptanceVerified':False,'sourceIds':ids,'qualifications':['Current Australian maker model list and exact MY26 grade specification establish this named offering.','Manufacturer listing, public price and servicing campaign do not establish physical New stock, accepted factory order or delivery timing.','Earlier dealer-new observations retain their original 10 October date; they are not re-dated as fresh stock checks.']}},'status':'approved','reviewedBy':packet['reviewedBy'],'reviewedAt':D,'evidenceDate':D,'reason':'Refresh current exact manufacturer listing without inferring physical stock or accepted order.'})
 def deps(keys):return [{'key':k,'expected':copy.deepcopy(next(e['after'] for e in packet['facts'] if e['variantId']==c['id'] and e['after']['key']==k))} for k in keys]
 if c['model']=='Torres EVX':
  strength={'label':'Luggage and trailer use','text':'A 465 L VDA boot to the seatbacks and 1,500 kg published braked towing rating support luggage and trailer use.','dependencies':deps(['boot_l','towing_braked_kg'])}
  trade={'label':'Charging stops','text':'Published 10–80% charging takes about 37 minutes on a 300 kW charging station.','dependencies':deps(['dc_charge_time_min'])}
 elif c['drive']=='AWD':
  strength={'label':'AWD and useful payload','text':'Dual-motor AWD supplies a published 266 kW combined output with an 805 kg maximum payload.','dependencies':deps(['drive','power_kw','payload_kg'])}
  trade={'label':'Plan longer journeys','text':'Its 379 km WLTP combined range is a reason to plan charging stops for longer journeys.','dependencies':deps(['range_km'])}
 else:
  strength={'label':'Everyday load carrying','text':'A 905 kg published maximum payload and self-levelling rear suspension support bulky everyday loads.','dependencies':deps(['payload_kg','rear_suspension'])}
  trade={'label':'Towing limit','text':'Braked towing is limited to 1,800 kg, with state, towbar and loaded-combination restrictions.','dependencies':deps(['towing_braked_kg'])}
 packet['summaries'].append({'variantId':c['id'],'conditions':[],'strength':strength,'tradeoff':trade})
# Two exact current-body reviews, original inventory rows retained in separate proof.
reviews=[]
for model,mid,body,kind,ids in [('Musso EV','kgm_musso_ev_current','dual-cab ute','ute',['home','model-musso','musso-current-specs']),('Torres EVX','kgm_torres_evx_current','SUV','passenger',['home','model-torres','torres-current-specs'])]:
 reviews.append({'id':PID+'-'+('musso-ev' if kind=='ute' else 'torres-evx'),'modelId':mid,'brand':'KGM','model':model,'bodyStyle':body,'vehicleClass':kind,'checkedAt':D,'officialSourceUrls':[next(s['url'] for s in manifest['sourceIndex'] if s['id']==i) for i in ids],'reason':'Current full Australian maker model menu, exact grade payload and linked MY26 technical sheet establish the complete current BEV family list. Black Edge is a priced optional 2WD styling pack, not a third core grade.' if kind=='ute' else 'Combined Torres page has one Australian battery-electric grade, EVX FWD MY26. K30/K40 are hybrids and Ultimate is petrol; parent petrol MY25 metadata is not applied to EVX.','versions':[{'carId':c['id'],'model':c['model'],'trim':c['trim'],'modelYear':c['year']} for c in rows if c['modelId']==mid]})
inventory=read(repo/'data/market-inventory-2026-10-10.json');selectedInventory=[copy.deepcopy(x) for x in inventory['records'] if x.get('brand')=='KGM'];assert len(selectedInventory)==2
recon={'schemaVersion':1,'checkedAt':D,'notes':['Current KGM maker-list review only; two independent whole-market lists remain unprovided.','All exact existing identities and model years remain unchanged.','Listing does not establish physical New stock, factory-order acceptance, delivery timing or national stock exhaustion.','Black Edge remains separately visible as a 2WD styling package; generic embedded variant relationship does not authorize an AWD Black Edge addition.'],'publishedLists':[],'currentVersionReviews':reviews,'listResolutions':[],'catalogueOnlyDifferences':[],'inventoryResolutions':[{'kind':'record','inventoryId':r['id'],'reviewedAt':D,'outcome':'included','modelReviewId':next(v['id'] for v in reviews if v['model']==r['model']),'reason':'Entire inherited model-family record is covered by the complete current maker grade list; historical ads remain dated and optional package distinctions remain explicit.','sourceUrls':next(v['officialSourceUrls'] for v in reviews if v['model']==r['model'])} for r in selectedInventory]}
cp=write(P/'kgm-2026-10-15-candidate-v1.json',packet);rp=write(P/'kgm-market-reconciliation-v1.json',recon)
write(R/'grade-summary-amendment-v1.json',{'checkedAt':D,'sourceReview':'/root/review_kgm_source_evidence messages 15 October 2026','towingGradeAmendments':amendments,'summaryCorrection':{'carId':next(c['id'] for c in rows if c['drive']=='AWD'),'old':'Its 379 km WLTP combined range is 40 km below the 2WD’s published figure','new':'Its 379 km WLTP combined range is a reason to plan charging stops for longer journeys.','reason':'Remove cross-version comparison not supported by an explicit dependency in this summary schema.'},'additionalConflict':'Fresh exact AWD payload says maximum towball load 180 kg while linked PDF says 230 kg; both retained in candidate Check observations.'})
write(P/'inventory-original-records-v1.json',{'sourcePath':str(repo/'data/market-inventory-2026-10-10.json'),'sourceSha256':hashlib.sha256((repo/'data/market-inventory-2026-10-10.json').read_bytes()).hexdigest(),'records':selectedInventory,'unverifiedLeads':[x for x in inventory['unverifiedLeads'] if x.get('brand')=='KGM'],'reason':'Complete original inherited rows, not normalized or truncated; current review resolves these exact two family IDs.'})
claimcells=packet['facts']+[{'after':t['fact']} for t in packet['brandTerms'] for _ in t['applicableVariantIds']]
freeze={'schemaVersion':1,'brand':'KGM','checkedAt':D,'status':'Prepared candidate and reconciliation, awaiting independent source review; no consumer execution','candidate':cp,'reconciliation':rp,'currentModels':2,'retainedVersions':3,'additions':0,'specificFactUpdates':len(packet['facts']),'sharedTerms':3,'sharedTermApplications':9,'effectiveFactTermCells':len(claimcells),'gradeCounts':dict(collections.Counter(x['after']['buyerGrade'] for x in claimcells)),'coreGrades':dict(collections.Counter((next(e['after']['buyerGrade'] for e in packet['facts'] if e['variantId']==o['carId'] and e['after']['key']==o['key']) if o['key'] not in ['warranty','battery_warranty'] else 'confirmed') for o in observations)),'availabilityUpdates':3,'summaryClauses':6,'featureUpdates':0,'identityChanges':0,'inputArtifacts':[{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [R/'retained-before-cars.json',R/'retained-before-selection-receipt.json',R/'research-manifest-v1.json',R/'grade-summary-amendment-v1.json',P/'inventory-original-records-v1.json']],'existingHelpersOnly':True,'nextGate':'Independent source/candidate acceptance, then frozen bounded actual selected-consumer command; explicit root execution grant required before any heavy run.'}
write(P/'candidate-manifest-v1.json',freeze)
print(json.dumps(freeze,indent=2))
