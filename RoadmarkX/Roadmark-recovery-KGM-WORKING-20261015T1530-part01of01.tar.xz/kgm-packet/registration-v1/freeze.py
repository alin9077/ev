from pathlib import Path
import hashlib,json
R=Path('/workspace/scratch/586427eef9f2/roadmark-104');B=Path('/tmp/kgm-packet/registration-v1')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(n,x):
 with (B/n).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
rows=json.loads((B/'prepared-writes.json').read_text())
proofs=['/tmp/kgm-packet/full-stage-v1/manifest.json', '/tmp/kgm-packet/full-stage-v1/output/stage-receipt.json', '/tmp/kgm-packet/full-stage-v1/run/terminal.json', '/tmp/kgm-packet/full-stage-v1/run/after-pins.json', '/tmp/kgm-review/full-stage-v1-output-review.json', '/tmp/kgm-packet/selected-preflight-v2/result.json', '/tmp/kgm-review/selected-preflight-v2-result-review.json', '/tmp/kgm-packet/kgm-2026-10-15-candidate-v2.json', '/tmp/kgm-packet/kgm-market-reconciliation-v1.json', '/tmp/kgm-research/research-manifest-v2.json']
helper=['src/lib/brand-updates.ts','src/lib/brand-update-registry.ts','src/lib/evidence-consumers.ts','src/lib/discovery.ts','src/lib/data.ts','scripts/reporting/reports.ts','scripts/reporting/m1-reconciliation.ts','tests/brand-updates.test.ts']
m=dict(schemaVersion=1,status='frozen_preparation_only_requires_bundle_review_and_root_application_grant',repo=str(R),writes=rows,proofs=[pin(p) for p in proofs],unchangedHelperPins=[pin(R/p) for p in helper],patch=pin(B/'registration.patch'),applicator=pin(B/'apply.py'),expected=dict(catalogue=427,tierOne=350,onSale=309,packets=28,changedCars=3,unchangedPeers=424,newModels=0,newVersions=0,manualFeatureUpdates=0),scope=dict(existingFiles=2,newFiles=2,helperSemantics='Unchanged accepted live helpers; all helper pins checked before and after',packet='Exact accepted candidate v2',reconciliation='Exact accepted reconciliation v1',registry='Append only, preserve first 27 ordered entries',reportLoader='One import and one last combineM1Reconciliations argument',reportImplementationChanged=False,testsChanged=False,heroChanged=False,immutableSnapshotChanged=False,sourceCapturesAddedToRepository=False),automaticRetry=False,rootGrantRequired=True,heavyChecksAllowed=False,rollback='No automatic rollback or deletion; retain journal and exact before copies for separately authorised recovery')
write('manifest.json',m)
write('root-grant-template.json',dict(status='NOT_GRANTED',action='apply_exact_kgm_registration',manifest=pin(B/'manifest.json'),reviewerAcceptance=None,allowedTargets=[x['target'] for x in rows],automaticRetry=False,heavyExecutionAuthorized=False))
print(json.dumps(dict(manifest=pin(B/'manifest.json'),applicator=pin(B/'apply.py'),patch=pin(B/'registration.patch')),indent=2))
