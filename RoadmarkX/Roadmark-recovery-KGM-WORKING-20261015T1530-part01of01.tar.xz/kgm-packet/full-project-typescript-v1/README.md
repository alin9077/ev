# KGM genuine full-project TypeScript v1: command-only preparation

This is an unexecuted plan for one cold installed-TypeScript attempt against the original repository tsconfig. No compiler, parser, test, wrapper, installation, generated-type refresh or source edit ran during preparation.

## Exact command semantics

Run from `/workspace/scratch/586427eef9f2/roadmark-104` using the pinned installed Node and TypeScript:

`node --max-old-space-size=768 --max-semi-space-size=1 node_modules/typescript/bin/tsc --noEmit --tsBuildInfoFile /tmp/kgm-packet/full-project-typescript-v1/run/full-project.tsbuildinfo`

The original package command is `tsc --noEmit`. Only the cache-output destination changes beyond that command. The original implicit project selection, includes, excludes, `incremental`, `skipLibCheck`, all checking options, path aliases, installed compiler and transitive resolution remain unchanged. No explicit file list, temporary tsconfig, narrowed project, stub, generated-type refresh, incremental disabling or seed cache is used. Therefore this is a full-project check, but not the literal package script and not a Next build.

Fresh tsbuildinfo root IDs must resolve to exactly the 361 unchanged configured roots. This inventory is evidence and never an input to the compiler. Both generated type paths remain as-is; four existing `.next/types` roots are retained and `.next/dev/types` is absent. No type generation is authorized.

## One bounded attempt

Reuse the accepted MINI v2 768 MiB old-space / 1 MiB semi-space envelope: the prior successful full-project run took 29.029 seconds with 876,332 KiB wait4 maximum RSS. That is precedent, not a KGM result, memory reservation or guarantee. V8 limits are not an OS RSS cap. Timeout is 900 seconds, TERM-to-KILL grace 10 seconds, watchdog 920 seconds. Core dumps and Node compile cache are disabled. Root must grant the exclusive heavy slot; the shared nonblocking lock prevents overlap with the five preceding gates. No retry or escalation is authorized.

Only `run/**` and the shared lock in the sibling validation directory are writable. The fresh output/cache must not exist. No live tsconfig.tsbuildinfo alteration is allowed; its content hash remains pinned before and after. Logs, process status, wait4 measurements, content pins and root-scope proof are retained.

## Prerequisites, exact acceptance, and no blanket metadata relaxation

Before running, require:
1. An independent reviewer receipt with `status: "accepted"`, exact `manifest: {path, sha256}` and `wrapper: {path, sha256}`
2. Accepted four-file KGM application readback using the exact shared contract in the sibling README: accepted status, registration manifest hash, `allFourLiveHashesAndBytesMatchAcceptedPayloads: true`, and pinned successful applicationReceipt
3. An independent preceding-check receipt with `status: "accepted"`, matching `applicationManifestSha256`, and exactly market-view, changed-file-lint, behavioural-suites, live-brand-safety, structural-validation in order. Each has `name`, `passed: true`, `exitCode: 0`, and exact content pins for manifest, result and terminal. Manifest pins must equal this manifest's precedingCheckManifests. Every result must be passed/exit0 and match its manifest hash; every terminal exit must be zero. The behavioral manifest must declare 144 tests
4. A separate root_execution_granted receipt matching this exact manifest and wrapper, accepting the above prerequisites, explicit fresh cache relocation, one attempt, no retry/parallel run, and exclusive heavy slot

The grant template is deliberately not executable authorization. Preparation of any receipt is not acceptance.

The 361 root names and every unchanged root stat remain exact. Only `scripts/reporting/load.ts` receives an explicit registration stat transition; its exact proposed after bytes and hash remain mandatory. All four live registration targets are separately content-pinned, their actual post-application stats are captured before the compiler and must remain identical afterward. This is not a general metadata refresh.

For the later authorized attempt only:
`python run.py MANIFEST_PATH MANIFEST_SHA256 ROOT_GRANT_PATH ROOT_GRANT_SHA256`

A pass requires compiler exit zero, unchanged pinned inputs and stats, exact full-project scope from fresh tsbuildinfo and no watchdog intervention. A missing cache or scope mismatch fails; no fallback or narrower success claim is allowed. Previous failures and Deepal passes remain history and are not relabelled as KGM results.

The wrapper is adapted from accepted MINI full-project v2; exact patch retained. KGM needs no new fixture correction, so Deepal's historical focused-correction gate is removed from KGM's new prerequisite contract while its corrected test content and accepted 144-test aggregate remain pinned. Compiler invocation, original scope, resource envelope, timeout, cache proof and terminal/result behavior retain the accepted implementation.
