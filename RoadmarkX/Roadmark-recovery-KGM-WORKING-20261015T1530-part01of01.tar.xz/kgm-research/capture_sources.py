import pathlib,json,hashlib,re,sys,urllib.request
from html.parser import HTMLParser
from urllib.parse import urljoin,urlsplit,urlunsplit,parse_qsl,urlencode
ROOT=pathlib.Path('/tmp/kgm-research/sources');ROOT.mkdir(exist_ok=True,parents=True)
def cleanurl(u):
 p=urlsplit(u)
 if p.scheme not in ['http','https']:return None
 q=[(k,v) for k,v in parse_qsl(p.query) if not re.search('key|token|auth|secret|session|jwt|signature|sig$',k,re.I)]
 return urlunsplit((p.scheme,p.netloc,p.path,urlencode(q),p.fragment))
class P(HTMLParser):
 def __init__(self,url):super().__init__();self.url=url;self.skip=0;self.parts=[];self.links=[];self.current=None;self.scripts=0
 def handle_starttag(self,tag,attrs):
  if tag in ['script','style','noscript','svg','iframe']:
   self.skip+=1;self.scripts+=tag=='script';return
  if self.skip:return
  if tag=='a':
   u=cleanurl(urljoin(self.url,dict(attrs).get('href','')));self.current={'text':'','url':u} if u else None
  if tag in ['div','p','section','h1','h2','h3','h4','li','tr','td','br']:self.parts.append('\n')
 def handle_endtag(self,tag):
  if tag in ['script','style','noscript','svg','iframe'] and self.skip:self.skip-=1;return
  if self.skip:return
  if tag=='a' and self.current:self.links.append(self.current);self.current=None
  if tag in ['div','p','section','h1','h2','h3','h4','li','tr','td']:self.parts.append('\n')
 def handle_data(self,d):
  if not self.skip:
   self.parts.append(d)
   if self.current:self.current['text']+=d

def capture(name,url):
 with urllib.request.urlopen(url,timeout=35) as r:b=r.read();typ=r.headers.get('Content-Type','');final=r.url;status=r.status
 meta={'name':name,'url':cleanurl(url),'final_url':cleanurl(final),'checkedAt':'2026-10-15','status':status,'response_type':typ,'no_credentials_used':True,'no_headers_retained':True}
 if b.startswith(b'%PDF'):
  p=ROOT/(name+'.pdf');p.write_bytes(b);meta['transformation']='Unmodified publicly linked PDF; no runtime HTML or credentials captured'
 else:
  parser=P(final);parser.feed(b.decode('utf-8',errors='replace'))
  text='\n'.join(x.strip() for x in ''.join(parser.parts).splitlines() if x.strip())
  text=re.sub(r'\beyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b','[REDACTED runtime credential]',text)
  p=ROOT/(name+'.txt');p.write_text(text);lp=ROOT/(name+'-links.json');lp.write_text(json.dumps(parser.links,indent=2))
  meta['transformation']='Sanitized visible document text and public links only; discarded all scripts, styles, noscript, SVG, iframe and HTML attributes in memory before any write. All credential-like URL parameters excluded. No credential values, response headers, cookies or raw HTML retained.'
  meta['discarded_script_elements']=parser.scripts
 meta['path']=str(p);meta['bytes']=p.stat().st_size;meta['sha256']=hashlib.sha256(p.read_bytes()).hexdigest();(ROOT/(name+'-provenance.json')).write_text(json.dumps(meta,indent=2)); print(name,meta['bytes'])
if __name__=='__main__':capture(sys.argv[1],sys.argv[2])
