import json,hashlib,pathlib
root=pathlib.Path('/tmp/kgm-research')
src=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104-qa/catalogue-snapshot-reuse/after448/cars.jsonl')
ix=pathlib.Path('/tmp/mini-packet/full-stage-v2/output/car-digest-comparison.json')
expected={x['id']:x for x in json.loads(ix.read_text())['candidate27'] if x['id'].startswith('kgm_')}
rows=[];pins=[]
with src.open('rb') as f:
 for raw in f:
  if b'"brand":"KGM"' not in raw:continue
  b=raw;r=json.loads(b)
  if r['id'] not in expected:continue
  h=hashlib.sha256(b).hexdigest();e=expected[r['id']]
  assert h==e['sha256'] and len(b)==e['bytes'],(r['id'],h,e)
  rows.append(r);pins.append({'id':r['id'],'sha256':h,'bytes':len(b)})
assert {r['id'] for r in rows}==set(expected)
(root/'retained-before-cars.json').write_text(json.dumps(rows,indent=2))
receipt={'source':str(src),'acceptedIndex':str(ix),'indexSha256':hashlib.sha256(ix.read_bytes()).hexdigest(),'stage':'candidate27','selectedDigests':pins,'newCatalogueLoad':False,'newWholeCatalogueCapture':False,'notes':'Streaming selection from retained accepted JSONL; selected complete KGM rows equal accepted MINI27 digests. No catalogue hydration or replay.'}
(root/'retained-before-selection-receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(pins,indent=2))
for r in rows:
 print(r['id'],list(r));print('fact keys',list(r.get('facts',{})))
