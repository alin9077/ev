import urllib.request,re,json,sys
url=sys.argv[1]
with urllib.request.urlopen(url,timeout=35) as r:s=r.read().decode()
pieces=[]
for m in re.finditer(r'self\.__next_f\.push\(\[\d+,("(?:\\.|[^"\\])*")\]\)',s):
 try:pieces.append(json.loads(m.group(1)))
 except:pass
stream=''.join(pieces)
print('Decoded public page chunks',len(pieces),'bytes',len(stream))
for label in ['modelData','grades','featureSets','models','vehicles']:
 print('Key occurrence',label,len(list(re.finditer('"'+label+'"',stream))))
 for m in list(re.finditer('"'+label+'":',stream))[:2]:
  try:
   obj,end=json.JSONDecoder().raw_decode(stream[m.end():]);
   print('Shape',type(obj).__name__,list(obj)[:35] if isinstance(obj,dict) else ['list length',len(obj)] if isinstance(obj,list) else '[scalar omitted]')
   if isinstance(obj,list):
    for x in obj[:8]:print('Entry key names',list(x) if isinstance(x,dict) else type(x).__name__)
  except Exception as e:print(type(e).__name__)
