import urllib.request,re,json,sys,pathlib,hashlib
url,name=sys.argv[1:3]
with urllib.request.urlopen(url,timeout=35) as r: raw=r.read(); s=raw.decode();status=r.status
parts=[json.loads(m.group(1)) for m in re.finditer(r'self\.__next_f\.push\(\[\d+,("(?:\\.|[^"\\])*")\]\)',s)]
stream=''.join(parts);m=re.search('"modelData":',stream);assert m
obj,end=json.JSONDecoder().raw_decode(stream[m.end():])
# Explicit field-name allowlist retains public vehicle identities, prices, options and equipment only.
allowed={'id','name','title','slug','price','model_year','public','grades','power_source','variants','colours','color','colour','colour_name','colour_type','year_discount','discountLabel','discountPopupTitle','discountPopupText','feature_sets','features','label','value','description','items','base_feature_set','universal_feature_sets','updatedAt','createdAt','display','variant','grade','heading','feature','specifications','key','group','unit','type','amount','is_standard','docs','year'}
def keep(x):
 if isinstance(x,list):return [keep(v) for v in x]
 if isinstance(x,dict):return {k:keep(v) for k,v in x.items() if k in allowed}
 return x
out=keep(obj);p=pathlib.Path('/tmp/kgm-research/sources')/(name+'-public-model-v2.json');p.write_text(json.dumps(out,indent=2))
meta={'url':url,'checkedAt':'2026-10-15','status':status,'method':'Unauthenticated public GET of maker model page; decode publicly embedded modelData only','transformation':'In-memory explicit public vehicle-field allowlist; all other runtime fields, scripts, headers and cookies discarded before write. No credential values used, printed or saved.','allowedFieldNames':sorted(allowed),'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
p.with_name(name+'-public-model-v2-provenance.json').write_text(json.dumps(meta,indent=2))
print(name,'grades',[(g.get('name'),g.get('price'),[(v.get('name'),v.get('price')) for v in g.get('variants',[])]) for g in out.get('grades',[])])
for g in obj.get('grades',[]):
 print(g.get('name'),'feature_set keys',list(g.get('feature_sets',{})))
 for v in g.get('variants',[]):print('variant key names',list(v))
print('allowed bytes',p.stat().st_size)
