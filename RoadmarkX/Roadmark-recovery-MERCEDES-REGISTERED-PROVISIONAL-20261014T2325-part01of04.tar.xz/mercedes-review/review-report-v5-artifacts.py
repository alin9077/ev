import json, hashlib, re
from pathlib import Path
from datetime import datetime, timezone
plan=Path('/tmp/mercedes-staging-plan'); prep=plan/'consumer-preparation'; v=prep/'v5'; out=prep/'consumer-artifacts/report-v5'; runs=plan/'runs/consumer-report-v5'; reviews=Path('/tmp/mercedes-review')
def pin(p):
 p=Path(p); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p): return json.loads(Path(p).read_text())
def checkpin(p, sha, sz=None):
 x=pin(p); assert x['sha256']==sha,(p,x); assert sz is None or x['bytes']==sz; return x
mp=v/'manifests/report-v5.json'; m=read(mp); r=read(out/'complete-report-receipt.json'); report=read(out/'staged-report.json'); diag=read(out/'selected-core-diagnostics.json'); packs=read(prep/'consumer-artifacts/selected-v5/staged-packs.json'); t=read(runs/'terminal.json'); inv=read(runs/'invocation.json'); cmd=read(v/'commands/report-v5-review-bound.json'); pr=read(v/'reviews/report-v5.json')
controls=[checkpin(mp,'70564bf4cdc4e367d59d98fe49026af93727532937470111b26fa4fb3b3c5bde',206484),checkpin(v/'reviews/report-v5.json','1c1b61f887705fa778162f6be9c73ab4cc2c18df720e9b5e4f1edf150bfd829d',9957),pin(v/'commands/report-v5-review-bound.json')]
rp=checkpin(out/'complete-report-receipt.json','d83f24c961d147c2535c3de7384c270fa351b99e80573db720b4aeebe22df518',206244)
outputs=[]
for name in ['reportFile','reportText','diagnosticsFile']:
 ref=r[name]; outputs.append(checkpin(Path(m['anchors'][ref['anchor']])/ref['file'],ref['sha256'],ref['bytes']))
assert r['fullInputPins']==m['inputPins'] and len(m['inputPins'])==886
assert r['availabilityLabelTransition']==m['availabilityLabelTransition']==pr['availabilityLabelTransition']
assert r['phaseManifestSha256']==controls[0]['sha256'] and r['phaseReviewSha256']==controls[1]['sha256']
assert cmd['manifest']==controls[0] and cmd['review']==controls[1]
assert t['command']==['/usr/bin/timeout','--signal=TERM','--kill-after=10s','180s']+cmd['argv'][4:]==inv['command']
assert t['returncode']==0 and t['signal'] is None and t['timeoutReported'] is False and t['receiptWrittenAfterExit'] is True
assert t['cwd']==cmd['cwd']==inv['cwd'] and t['startedAt']==inv['startedAt'] and t['timeoutSeconds']==180
assert (runs/'stderr.log').read_bytes()==b''
assert (runs/'stdout.log').read_text().strip()=='Original complete staged report preserved; fresh registered full-JSON and byte parity remains explicitly unverified'
checkpin(runs/'terminal.json','77f49912d5ce25784bfe6de0d6d0bbd2b935bd912c209bb78b760bd99ab7ca05',1136)
fa=read(reviews/'feature-aggregate-v5-output-acceptance.json'); assert fa['reviewedAt']<t['startedAt']
for key in ['featureOutputAcceptance','reconciliationReview','reconciliation','negativeOutputAcceptance','selectedConsumerAcceptance','canonicalAcceptance']:
 ref=m[key]; checkpin(Path(m['anchors'][ref['anchor']])/ref['file'],ref['sha256'],ref['bytes'])
assert r['featureReceiptSha256']==m['featureReceipt']['sha256']==fa['featureReceiptSha256']
assert r['negativeReceiptSha256']==m['negativeReceipt']['sha256'] and r['reconciliation']==m['reconciliation']
assert r['cars']==report['allCatalogueVersions']==409 and report['tierOneVersions']==332 and report['onSaleVersions']==304
assert r['selectedCars']==len(diag)==len(packs)==11 and r['onSaleSelectedCars']==10 and r['features']==28221 and r['sources']==3537
for key in ['all14ResearchFieldsUnchanged','allCompleteCarsUnchanged','allReportInputFieldsUnchanged','actualReportLoaderUsed','actualCoverageBuilderUsed','actualFullFeatureStreamUsed']: assert r[key] is True
for key in ['candidateRegistered','freshFullValueLoaderExport','fullFreshRegisteredJsonParity','filteredOrNormalized']: assert r[key] is False
assert r['defaultLoaderCalls']==0
assert r['completeReportInputFieldDigests']['features']=={'rows':28221,'bytes':fa['featureStream']['bytes'],'sha256':fa['featureStream']['sha256']}
assert r['completeReportInputFieldDigests']['cars']['rows']==409 and r['completeReportInputFieldDigests']['sources']['rows']==3537
brand=next(x for x in report['brandProgress'] if x['brand']=='Mercedes-Benz'); assert brand==r['brand']
assert brand['criteria']=={'C1':False,'C2':False,'C3':False,'C4':True,'C5':False,'C6':True}
assert brand['done'] is False and brand['researchCompleted'] is False and brand['currentVersionReviews']==[]
assert brand['coreGaps']==15 and brand['unreviewedCoreGrades']==5 and brand['missingSummaries']==0
keys=[x['key'] for x in report['core']]; assert len(keys)==17 and [x['id'] for x in diag]==list(packs)
gaps=[]; causes=[]
for d in diag:
 car=packs[d['id']]['car']; on=car['availability']=='current_or_order_listed'
 assert d['actualAvailability']==car['availability'] and d['actualOnSale']==on and d['unchangedActualCar'] is True
 assert [x['key'] for x in d['core']]==keys
 for cell in d['core']:
  assert cell['total']==int(on) and sum(cell['grades'].values())==int(on)
  assert cell['reviewed']==cell['total']-cell['grades']['Unreviewed']
  if cell['grades']['Unreviewed']:
   fact=car['facts'][cell['key']]; assert fact['buyerGrade']=='reported' and fact['gradeReview']['reviewedAt']=='2026-10-15'
   causes.append({'carId':car['id'],'vehicle':car['brand']+' '+car['model']+' '+car['trim'],'key':cell['key'],'displayedValue':fact['value'],'unit':fact['unit'],'displayedBuyerGrade':fact['buyerGrade'],'basis':fact['basis'],'comparisonBasis':fact['comparisonBasis'],'sourceIds':fact['sourceIds'],'gradeReview':fact['gradeReview'],'strictCore':cell})
 gaps+=d['gaps']
 if not on:
  assert car['id']==m['buyerChecks']['glc'] and not d['gaps'] and all(not q['rankedIds'] for q in d['rankings'])
assert len(causes)==5 and len(gaps)==15
# Global report is field-first; one-car diagnostics are car-first. Compare complete records by unique identity/key without changing either output.
global_gaps=[g for g in report['gaps'] if g['carId'] in packs]
assert len(global_gaps)==15
assert {(g['carId'],g['key']):g for g in global_gaps}=={(g['carId'],g['key']):g for g in gaps}
assert r['onSaleCoreSlotsInspected']==sum(x['total'] for d in diag for x in d['core'])==170
for cell in brand['core']:
 peers=[next(x for x in d['core'] if x['key']==cell['key']) for d in diag if d['actualOnSale']]
 for k in ['filled','total','reviewed']: assert cell[k]==sum(x[k] for x in peers)
 for grade in cell['grades']: assert cell['grades'][grade]==sum(x['grades'][grade] for x in peers)
assert sum(x['filled'] for x in brand['core'])==155 and sum(x['reviewed'] for x in brand['core'])==165
for br in brand['rankings']:
 ids=[i for d in diag for q in d['rankings'] if q['key']==br['key'] for i in q['rankedIds']]
 assert br['ranked']==len(ids) and br['total']==10 and br['passes'] is False
 actual=next(q for q in report['rankings'] if q['key']==br['key']); filtered=[i for i in actual['rankedIds'] if i in packs]
 assert len(filtered)==len(ids)==len(set(ids)) and set(filtered)==set(ids)
 assert m['buyerChecks']['glc'] not in actual['rankedIds']
for c in r['cityStrictCore']:
 d=next(x for x in diag if x['id']==c['id']); cell=next(x for x in d['core'] if x['key']=='dc_charge_time_min'); fact=packs[c['id']]['car']['facts']['dc_charge_time_min']; assert c['strictCore']==cell
 assert fact['value']==c['visibleDuration'] and fact['buyerGrade']==c['visibleGrade']=='reported'
 assert cell['filled']==0 and cell['grades']['Unreviewed']==1 and not fact['comparisonBasis']
for u in causes:
 if u['key']=='dc_charge_time_min':
  u['causeType']='genuine_unestablished_10_80_window_plus_reporter_review_conflation'
  u['finding']='The reported minutes have an earned review but do not establish the strict 10–80% window. coreFact returns a null strict value, and existingGrade labels any non-Not-published grade on that unfilled cell Unreviewed.'
 elif 'city_edition' in u['carId']:
  assert u['basis']=='braked_trailer_mass' and not re.search(r'\bbraked\b',u['basis'],re.I)
  u['causeType']='source_backed_braked_basis_token_parser_mismatch_plus_reporter_review_conflation'
  u['finding']='The accepted exact-grade secondary fact identifies braked_trailer_mass. The current word-boundary regex does not recognize braked followed by an underscore. This is a representation/parser seam, not established absence of a braked source rating.'
 else:
  assert u['displayedValue']==0 and '0 kg braked' in u['gradeReview']['reason']
  u['causeType']='source_scope_omitted_from_machine_checked_basis_plus_reporter_review_conflation'
  u['finding']='The accepted review identifies the exact 2026 CarsGuide 0 kg braked table; its displayed basis says zero / no towing without braked. The helper reads basis/comparisonBasis, not gradeReview.reason. The zero comes from an explicit numeric source, not categorical No Towing.'
assert len(report['gaps'])==sum(x['total']-x['filled'] for x in report['core'])==431
assert report['grading']['totalCoreCells']==304*17==5168 and report['grading']['reviewedCoreCells']==sum(x['reviewed'] for x in report['core'])==4760
assert not report['ageing']['overdue'] and not report['ageing']['invalid']
text=(out/'staged-report.txt').read_text(); assert text.startswith('Tier 1 coverage as of 2026-10-15\n') and 'Scope: 332 Tier 1 versions; all 409 catalogue versions preserved.' in text and 'C3 OPEN: 4760/5168 core cells have earned reviews' in text
repo=Path(m['anchors']['repo']); code=[]
for f in ['scripts/reporting/reports.ts','src/lib/evidence-grading.ts']:
 ref=next(p for p in m['inputPins'] if p['anchor']=='repo' and p['file']==f); code.append(checkpin(repo/f,ref['sha256'],ref['bytes']))
receipt={'schemaVersion':1,'status':'accepted_exact_complete_brand_staged_report_pending_registered_parity','reviewedAt':datetime.now(timezone.utc).isoformat(),'manifest':controls[0],'phaseReview':controls[1],'command':controls[2],'reportReceipt':rp,'reportReceiptSha256':rp['sha256'],'reportFile':outputs[0],'reportSha256':outputs[0]['sha256'],'reportText':outputs[1],'diagnosticsFile':outputs[2],'measuredArtifacts':[pin(runs/f) for f in ['invocation.json','terminal.json','stdout.log','stderr.log']],'packetSha256':r['packetSha256'],'coreReceiptSha256':r['coreReceiptSha256'],'featureReceiptSha256':r['featureReceiptSha256'],'availabilityLabelTransition':r['availabilityLabelTransition'],'featureAggregateAcceptance':pin(reviews/'feature-aggregate-v5-output-acceptance.json'),'reconciliationContentReview':pin(reviews/'reconciliation-v1-content-review.json'),'checks':{'all886InputReferencesMatchReviewedManifest':True,'successfulExactReviewedCommandAndEmptyStderr':True,'allThreeWrittenReportArtifactsHashChecked':True,'completeUnfilteredReportPreserved':True,'reportBrandExactlyMatchesReceipt':True,'allElevenActualDiagnosticsMatchAcceptedSelectedCars':True,'allSeventeenBrandCoreCountsEqualActualDiagnosticSums':True,'allSelectedGapRecordsMatchCompleteReportExactlyByCarAndKey':True,'allSelectedRankedIdMembershipMatchesCompleteReportExactly':True,'provisionalGlcExcludedFromAllSeventeenCoreDenominatorsAndRankings':True,'bothCityDurationsVisibleReportedAndStrictWindowGapsUnranked':True,'allFiveUnreviewedCellsHaveRecordedReportedGradeReviews':True,'globalCoreAndGapTotalsReconciled':True,'allCatalogueVersions':409,'tierOneVersions':332,'onSaleVersions':304,'selectedCars':11,'selectedOnSaleCars':10,'selectedStrictCoreSlots':170,'selectedStrictFilledCells':155,'selectedStrictGaps':15,'selectedReporterReviewedCells':165,'selectedReporterUnreviewedCells':5,'featureRows':28221,'sources':3537,'productionImportsByReviewer':0,'defaultLoaderCallsByProducer':0},'mercedesCriteria':brand['criteria'],'mercedesC3Causes':causes,'reviewedReporterCodePins':code,'artifactCheckScript':pin(__file__),'reporterFollowUp':{'requiredBeforeClaimingC3Closure':True,'scope':'Separately review source-backed towing basis representation and the braked-token recognizer; separate evidence-review completion from strict measurement completeness in coverage grading. Add bounded behavioral tests for explicit braked values, underscore token handling, genuine unknown charge windows, unreviewed evidence, and categorical no-towing without inventing zero. Keep Reported facts unranked and genuine 10–80% gaps unfilled. Any approved change needs versioned proofs and new report parity, never alteration of this original report.','mutationAuthorizedByThisReceipt':False},'reviewScope':'Bounded read-only artifact verification, full JSON/diagnostic parsing, complete output hashes, terminal/control matching, all selected cell and ranking reconciliation, and static inspection of the two exact reporter functions. No new catalogue hydration or production execution. Runtime full-input unchanged assertions remain tied to the reviewed exact invocation and accepted canonical/feature proofs. An initial reviewer assertion incorrectly expected car-first diagnostics to have the global field-first gap order; this bounded check uses unique car/key full-record equality and ranked-ID membership without rewriting either artifact.','limits':['This is staged report acceptance, not Mercedes or whole-market C1–C6 completion.','Mercedes C1, C2, C3 and C5 remain false; C4 and C6 pass.','Three towing cells reflect basis representation/parser seams; two City charging windows genuinely remain unknown. All five displayed facts have Reported reviews; the unchanged reporter labels their strict cells Unreviewed.','Original report JSON/text, packet, evidence, failed attempts and canonical capture remain immutable.','Production registration, fresh whole unmodified normal-report JSON and byte parity, standard TypeScript/build/full aggregate/mobile gates remain open.'],'productionRegistrationAuthorized':False,'canonicalRecaptureAuthorized':False,'freshRegisteredParityVerified':False}
p=reviews/'report-v5-output-acceptance.json'
with p.open('x') as f: json.dump(receipt,f,indent=2,ensure_ascii=False); f.write('\n')
print(json.dumps({'acceptance':pin(p),'counts':receipt['checks']},indent=2))
