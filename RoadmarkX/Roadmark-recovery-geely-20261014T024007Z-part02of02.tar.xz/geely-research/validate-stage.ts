import fs from 'node:fs';
import assert from 'node:assert/strict';
import {catalogue,research,effectiveFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/data.ts';
import {prepareBrandResearch,applyBrandUpdates,applyBrandFeatureUpdates,applyBrandTermFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-updates.ts';
import {loadReportInput} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/load.ts';
import {buildCoverageReport} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/reports.ts';
import {combineM1Reconciliations} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/m1-reconciliation.ts';
import {featureClaim} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/citable.ts';
import {hydratePortablePacks,storePortablePacks} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/portable-packs.ts';
const root='/tmp/geely-research/';
const p=JSON.parse(fs.readFileSync(root+'geely-2026-10-14.json','utf8'));
const r=JSON.parse(fs.readFileSync(root+'geely-reconciliation-2026-10-14.json','utf8'));
const before=JSON.parse(JSON.stringify(catalogue())),rd=JSON.parse(JSON.stringify(research()));
const original=JSON.stringify({before,rd,p});
assert.deepEqual(before.filter(c=>c.brand==='Geely'),JSON.parse(fs.readFileSync(root+'before.json','utf8')),'before snapshot must still match current catalogue');
const data=prepareBrandResearch(rd,[p]);
const cars=applyBrandUpdates(before,data,[p]);
const beforeById=new Map(before.map(c=>[c.id,c]));
const features=cars.flatMap(car=>car.brand==='Geely'?applyBrandTermFeatures(car,applyBrandFeatureUpdates(car,effectiveFeatures(beforeById.get(car.id)!,rd),data,[p])):effectiveFeatures(car,data));
for(const car of cars.filter(c=>c.brand==='Geely')){
 const rows=features.filter(f=>f.variant_id===car.id);
 const pack={car,features:rows,sources:data.sources,eligibility:data.update_eligibility.find(r=>r.variant_id===car.id),events:[],configuration:[]};
 const restored=hydratePortablePacks(storePortablePacks({[car.id]:pack}),data.sources)[car.id];
 assert.deepEqual(JSON.parse(JSON.stringify(restored)),JSON.parse(JSON.stringify(pack)));
 for(const row of p.features.filter((f:any)=>f.variantId===car.id)){
  assert.deepEqual(rows.find(f=>f.criterion===row.criterion),row.after);
  const claim=featureClaim(restored,row.criterion,row.criterion)!;
  assert.equal(claim.value,row.after.value);
  assert.equal(claim.gradeReview?.overlayId,p.id);
  assert.equal(claim.gradeReviewStatus,undefined);
  assert.deepEqual(claim.sources.map(s=>s.id),row.after.source_ids);
 }
 const dc=car.facts.dc_charge_time_min;
 if(car.trim.includes('Extended Range')){assert.notEqual(dc.value,20);assert.equal(car.facts.dc_30_80_min.value,20);}
}
const input=loadReportInput();
input.cars=cars;input.sources=data.sources;input.features=features;input.m1Reconciliation=combineM1Reconciliations(input.m1Reconciliation!,r);
const report=buildCoverageReport(input,'2026-10-14');
fs.writeFileSync(root+'staged-report.json',JSON.stringify(report,null,2));
fs.writeFileSync(root+'after.json',JSON.stringify(cars.filter(c=>c.brand==='Geely'),null,2));
fs.writeFileSync(root+'features-after.json',JSON.stringify(features.filter(c=>c.variant_id.startsWith('geely_')),null,2));
assert.equal(JSON.stringify({before,rd,p}),original,'staging must preserve original inputs');
const geely=report.brandProgress.find(x=>x.brand==='Geely')!;
assert.ok(geely.researchCompleted,JSON.stringify(geely.researchRemaining));
assert.equal(geely.missingModels,0);assert.equal(geely.unresolvedLeads,0);assert.equal(geely.missingSummaries,0);assert.equal(geely.agedOrInvalidClaims,0);
assert.ok(!report.unresolvedLeads?.some((x:any)=>x.id==='geely-riddara-rd6-bev'));
console.log(JSON.stringify({researchCompleted:geely.researchCompleted,onSaleVersions:geely.onSaleVersions,core:geely.core.map(x=>({key:x.key,grades:x.grades})),currentBodies:geely.currentVersionReviews.map(x=>({model:x.model,versions:x.versions.length})),gaps:report.gaps.filter(x=>x.brand==='Geely'),closureIssues:geely.closureIssues,criteria:geely.criteria,features:p.features.length},null,2));
console.log('PASS: effective-current fact/version guards, feature chains/dependencies, citable/portable propagation, immutable inputs, staged report. Global C1-C6 remain separate.');
