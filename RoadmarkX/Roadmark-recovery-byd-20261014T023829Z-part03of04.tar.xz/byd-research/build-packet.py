import json, pathlib, hashlib
BASE=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104')
D='2026-10-14'; PID='m1-byd-2026-10-14'; REVIEWER='Roadmark BYD Australian source review'
cars=json.load(open('/tmp/byd-research/before.json'))
p={'schemaVersion':1,'id':PID,'brand':'BYD','reviewedAt':D,'reviewedBy':REVIEWER,'sources':[],'models':[],'variants':[],'versionGuards':[],'versionUpdates':[],'facts':[],'availability':[],'summaries':[]}
sources={}
def source(key,url,title,supports,typ='manufacturer_au_specification',publisher='BYD Australia',pdf=None,pub=None,**kwargs):
 s={'id':PID+'-'+key,'url':url,'title':title,'publisher':publisher,'source_type':typ,'published_date':pub,'accessed_date':D,'market':'AU','supports':supports,**kwargs}
 if pdf:
  fp=pathlib.Path('/tmp/byd-research')/(pdf+'.pdf')
  if fp.exists(): s['capture_sha256']=hashlib.sha256(fp.read_bytes()).hexdigest()
 p['sources'].append(s);sources[key]=s;return s['id']
def sid(*keys):return [sources[k]['id'] for k in keys]
families={
 'atto1':('atto-1','BYD-ATTO-1-2025.pdf?v=1','ATTO 1'),
 'atto2':('atto-2','BYD-ATTO-2-2025.pdf','ATTO 2'),
 'atto3evo':('atto-3-evo','BYD-ATTO-3-EVO.pdf?v=3','ATTO 3 EVO'),
 'atto3old':('atto-3-evo','BYD-ATTO-3-2026.pdf','ATTO 3'),
 'dolphin':('dolphin','BYD-DOLPHIN-2025.pdf','DOLPHIN'),
 'seal':('seal','BYD-SEAL-2026.pdf','SEAL'),
 'sealion7':('sealion-7','BYD-SEALION-7-2026.pdf','SEALION 7')}
for k,(slug,pdf,name) in families.items():
 source(k+'-spec','https://bydautomotive.com.au/brochures/'+pdf,name+' Australian specification brochure','Visually checked specification table on PDF page 2: exact Australian grades, battery, range, charging where stated, seating, boot, performance and body dimensions. No charging-window conversions.',pdf=k)
 if k!='atto3old':
  source(k+'-product','https://bydautomotive.com.au/'+slug,name+' Australian model and version list','Complete named Australian version list and order buttons; body scope and drivetrain. Plug-in hybrids are excluded.')
  url='https://bydautomotive.com.au/configurator/byd-'+slug
  source(k+'-config',url,name+' maker-linked Australian order configurator','Exact named version base selection prices; on-road costs calculated separately. Official BYD Australia entry point redirects to its EV Dealer Group order configurator; no order, stock or delivery guarantee inferred.',typ='official_configurator',redirected_url='https://evdealergroup-byd.com.au/configurator/byd-'+slug)
source('offers','https://bydautomotive.com.au/offers','BYD Australia October 2026 national offers','National driveaway: ATTO 1 Essential A$19,990 and DOLPHIN Essential A$28,888. Retail orders 15 September–15 December 2026; delivery by 31 December. Metallic paint extra; demonstrators, stacked promotions excluded; allocation and delivery conditions.',typ='manufacturer_au_offer')
source('warranty','https://bydautomotive.com.au/public/vehicle-warranty-2026.pdf','BYD Australia Warranty and Service Handbook','Sections 1.3 and 1.3.1: every new BYD vehicle 6 years/150,000 km; power battery and drive unit 8 years/160,000 km, whichever first; at least 70% battery capacity retention. Component limits and exclusions remain in handbook.',typ='primary_warranty',pdf='warranty2026')
source('service','https://bydautomotive.com.au/service-and-warranty','BYD Australia service and warranty','Brand-wide vehicle/battery warranty and 12-month complimentary roadside assistance from delivery for vehicles delivered on or after 22 July 2025.',typ='manufacturer_au_brand_terms')
for k,name in [('atto1','ATTO-1'),('atto2','ATTO-2'),('seal','SEAL'),('sealion7','SEALION-7')]:
 source(k+'-handbook','https://bydautomotive.com.au/brochures/BYD-'+name+'-Owners-Handbook-2025.pdf',name.replace('-',' ')+' Australian handbook',{'atto1':'Australian ATTO 1 handbook checked: no numeric braked trailer rating; warns not to tow other vehicles and excludes damage from trailer towing. No zero capacity inferred.','atto2':'Australian ATTO 2 handbook trailer section: maximum total towing 750 kg, brake classification unstated; towing function, approved kit and software required.','seal':'Australian SEAL handbook checked: no numeric braked trailer rating or exact 10–80% charging duration established. EPB trailer mode concerns moving the vehicle, not a rated trailer capacity.','sealion7':'Australian SEALION 7 handbook, towing table: braked 750 kg RWD and 1500 kg four-wheel drive; unbraked 750 kg.'}[k],typ='manufacturer_au_handbook',pdf=k+'-handbook')
source('atto3evo-whichcar','https://www.whichcar.com.au/reviews/byd-atto-3-evo-review-australia-premium-dynamic-2026-specs-price','WhichCar Australian ATTO 3 EVO launch review','AU Premium RWD 10–80% reported as 25 minutes. No Dynamic 10–80% time is supplied. This secondary claim does not relabel maker 0–80% times.',typ='secondary_au_motoring_review',publisher='WhichCar')
source('dolphin-evcentral','https://evcentral.com.au/cars/byd/dolphin/','EV Central BYD Dolphin Australian guide','Essential/Premium range listed; 7 kW AC and 0 kg braked towing at model-range level. 40–41 minute 10–80% range is not mapped to individual grades. Data labelled updated 9 October 2026.',typ='secondary_au_motoring_guide',publisher='EV Central',pub='2026-10-09')
source('sealion7-goauto','https://www.goauto.com.au/new-models/byd/sealion/7/byd-sealion-7-goes-on-sale/2025-02-12/95697.html','GoAuto Australian SEALION 7 launch specifications','Explicit Australian-specification grades: 10–80% DC charging approximately 32 minutes. Other values now use current maker sources.',typ='secondary_au_motoring_report',publisher='GoAuto',pub='2025-02-12')
source('atto3old-carexpert','https://www.carexpert.com.au/car-reviews/2025-byd-atto-3-review','CarExpert Australian 2025 ATTO 3 review','Names Essential Standard Range and Premium Extended Range; reports approximately 35 minutes 10–80% for either and 7 kW AC for Premium. Essential AC carried from sibling at Reported, not treated as maker confirmation. A$44,990 is historical outgoing Premium price.',typ='secondary_au_motoring_review',publisher='CarExpert')

def key_for(c):
 i=c['id']
 return 'atto3evo' if 'atto_3_evo' in i else 'atto3old' if 'atto_3_legacy' in i else 'atto1' if 'atto_1' in i else 'atto2' if 'atto_2' in i else 'sealion7' if 'sealion_7' in i else 'dolphin' if 'dolphin' in i else 'seal'
meta={
 'price_aud':('Published price','AUD','Before on-road costs'),
 'range_km':('Claimed range','km','WLTP combined'),
 'battery_kwh':('Battery capacity','kWh','Manufacturer published capacity; usable/gross not specified'),
 'dc_peak_kw':('Peak DC charging power','kW','Vehicle DC peak'),
 'dc_charge_time_min':('DC 10–80% charging time','min','10–80%'),
 'ac_kw':('AC charging power','kW','Vehicle AC maximum'),
 'seats':('Seats','','Seating positions'),
 'boot_l':('Boot capacity','L','Rear boot, seats up; maker method not stated'),
 'zero_to_100_s':('0–100 km/h','s','0–100 km/h'),
 'power_kw':('Motor power','kW','Maximum combined motor power'),
 'drive':('Drive type','','Driven wheels'),
 'length_mm':('Length','mm','Overall length'),
 'width_mm':('Width','mm','Overall body width'),
 'height_mm':('Height','mm','Overall height'),
 'towing_braked_kg':('Braked towing','kg','Maximum braked towing'),
 'warranty':('Vehicle warranty','','Australian new-vehicle warranty'),
 'battery_warranty':('Battery warranty','','Australian power-battery warranty'),
 'towing_limit_kg':('Published towing limit','kg','Brake basis not stated'),
 'dc_charge_0_80_min':('DC 0–80% charging time','min','0–80%'),
 'dc_charge_30_100_min':('DC 30–100% charging time as printed','min','30–100%'),
 'dc_charge_10_80_range_min':('Reported model-range DC 10–80% time','min','10–80%; exact grade mapping not stated'),
 'roadside_assistance':('Roadside assistance','','Australian new-vehicle roadside assistance'),
 'body_style':('Body style','','Body style')}
effective={}
shared={'atto1':[3990,1720,1590,4,308], 'atto2':[4310,1830,1675,5,380], 'atto3evo':[4455,1875,1615,5,None], 'atto3old':[4455,1875,1615,5,440], 'dolphin':[4290,1770,1570,5,345], 'seal':[4800,1875,1460,5,400], 'sealion7':[4830,1925,1620,5,500]}
# Values in current official Australian specification tables, page 2.
vals={
'byd_sealion_7__premium_rwd__1':[54990,482,82.56,150,32,11,6.7,230,'RWD',750],
'byd_sealion_7__performance_awd__2':[63990,456,82.56,150,32,11,4.5,390,'AWD',1500],
'byd_atto_2__dynamic__1':[31990,345,51.13,82,38.6,7,7.9,130,'FWD',None],
'byd_atto_2__premium__2':[35990,345,51.13,82,38.6,7,7.9,130,'FWD',None],
'byd_atto_3_evo__dynamic_fwd__1':[41990,420,60.48,110,None,7,7.3,150,'FWD',750],
'byd_atto_3_evo__premium_rwd__2':[46990,510,74.88,220,25,11,5.5,230,'RWD',1500],
'byd_atto_3_legacy__essential_fwd__1':[39990,345,49.92,70,35,7,7.9,150,'FWD',750],
'byd_atto_3_legacy__premium_fwd__2':[44990,420,60.48,88,35,7,7.3,150,'FWD',750],
'byd_seal__premium_rwd__20261010':[52990,570,82.56,150,None,7,5.9,230,'RWD',None],
'byd_seal__performance_awd__20261010':[61990,520,82.56,150,None,7,3.8,390,'AWD',None],
'byd_dolphin__essential_fwd__20261010':[28888,340,44.9,60,None,7,12.3,70,'FWD',0],
'byd_dolphin__premium_fwd__20261010':[36990,427,60.48,80,None,7,7.0,150,'FWD',0],
'byd_atto_1__essential_fwd__20261010':[19990,220,30,65,30,11,11.1,65,'FWD',None],
'byd_atto_1__premium_fwd__20261010':[27990,310,43.2,85,30,11,9.1,115,'FWD',None]}
keys=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','zero_to_100_s','power_kw','drive','towing_braked_kg']

def fact(c,key,val,src,grade='confirmed',reason=None,scope='exact_au_version',condition='',basis=None,comparison=None,issues=None):
 label,unit,default=meta[key]; srcids=sid(*src)
 f={'key':key,'label':label,'value':val,'unit':unit,'basis':basis or default,'comparisonBasis':default if comparison is None else comparison,'status':{'confirmed':'standard','check':'conditional','reported':'conditional','not_published':'not_verified'}[grade],'sourceIds':srcids,'date':D,'market':'AU','scope':f"BYD {c['model']} {c['trim']}",'qualifications':[condition] if condition else [],'issues':issues or [],'buyerGrade':grade,'gradeReview':{'reviewedAt':D,'overlayId':PID,'reason':reason or f"Current Australian maker specification explicitly lists {label.lower()} for this grade.",'evidenceScope':scope,'sourceIds':srcids,'sourceLabel':' / '.join(dict.fromkeys(sources[x]['publisher'] for x in src))}}
 if condition:f['conditionExplanation']=condition
 if grade=='reported':f['resolvedElsewhere']=True
 p['facts'].append({'variantId':c['id'],'before':c['facts'].get(key),'after':f});effective.setdefault(c['id'],{})[key]=f
 return f

for c in cars:
 k=key_for(c);spec=k+'-spec'; premium='premium' in c['id'];out=c['availability']=='outgoing'
 ident={a:c[a] for a in ['id','modelId','brand','model','trim','year','generation','drive']};ident['vehicleClass']=c.get('vehicleClass','passenger')
 p['versionGuards'].append({'variantId':c['id'],'before':ident})
 values=dict(zip(keys,vals[c['id']]))
 values.update(dict(zip(['length_mm','width_mm','height_mm','seats','boot_l'],shared[k])))
 if k=='atto3evo':values['boot_l']=490 if premium else 434
 for key,val in values.items():
  src=[spec];grade='confirmed';scope='explicit_au_range' if key in ['length_mm','width_mm','height_mm','seats','boot_l'] and k!='atto3evo' else 'exact_au_version';reason=None;condition='';issues=[]
  if key=='price_aud':
   if out:
    src=['atto3old-carexpert'];grade='reported';scope='secondary_or_sibling';reason='CarExpert’s Australian 2025 review records A$44,990 before on-road costs for Premium Extended Range. This is a historical secondary price for the outgoing grade, not a current maker quote.';condition='Historical 2025 before-on-road price for the outgoing Premium; current factory orders are not listed.'
   elif val in [19990,28888]:
    src=['offers'];grade='check';condition='Retail customers: order 15 September–15 December 2026 and take delivery by 31 December 2026. Standard paint; metallic extra. Excludes demonstrators and stacked promotions. Allocation and delivery are not guaranteed.'
   else:src=[('atto3evo' if k=='atto3old' else k)+'-config'];reason='Exact named version base price is displayed in the maker-linked Australian configurator. On-road costs are separate, not a condition on this base figure.'
  elif key=='dc_charge_time_min':
   if k=='atto3evo':
    src=[spec,'atto3evo-whichcar']
    if premium:
     grade='reported';scope='secondary_or_sibling';reason='WhichCar Australian launch review explicitly reports 25 minutes for Premium 10–80%; maker brochure separately prints 30 minutes 0–80%.';condition='Reported by WhichCar for the Australian Premium; maker brochure publishes a different 0–80% window.'
    else:
     grade='not_published';scope='searched_not_found';reason='Maker brochure gives 41 minutes 0–80%; the Australian WhichCar review gives no Dynamic 10–80% time. No conversion was made after these two checks.'
   elif k=='sealion7':
    src=['sealion7-goauto'];grade='reported';scope='secondary_or_sibling';reason='GoAuto explicitly reports approximately 32 minutes 10–80% for Australian-specification SEALION 7 grades; current maker sheet does not publish a duration.';condition='Approximately 32 minutes, reported by GoAuto; not a measured owner result.'
   elif k=='atto3old':
    src=['atto3old-carexpert'];grade='reported';scope='secondary_or_sibling';reason='CarExpert explicitly gives approximately 35 minutes 10–80% for either named Australian Essential/Premium grade; maker sheet has no duration.';condition='Approximately 35 minutes, reported by CarExpert; Australian maker brochure does not publish a 10–80% time.'
   elif k=='seal':
    src=[spec,'seal-handbook'];grade='not_published';scope='searched_not_found';reason='The current Australian specification sheet and Australian handbook publish no exact 10–80% duration for Premium or Performance. No 30–80% or overseas result was substituted.'
   elif k=='dolphin':
    src=[spec,'dolphin-evcentral'];grade='not_published';scope='searched_not_found';reason='Maker sheet gives DC peak only; EV Central gives a 40–41 minute model-range span without mapping Essential/Premium. An exact-version 10–80% figure was not established after two sources.'
   elif k=='atto1':
    grade='check';reason='Australian brochure explicitly states 30 minutes 10–80% for both grades, alongside a conflicting faster 30–100% row; the stated windows are retained.';condition=f"Brochure also prints {22 if premium else 25} minutes for 30–100%; that inconsistent window is not corrected or used to infer a charging curve. Confirm timing with BYD."
    issues=[{'issue_id':PID+'-atto1-charge-window','title':'Conflicting charge-window timing in maker brochure','priority':'medium','model_ids':[c['modelId']],'publication_action':'Keep the explicit 10–80% figure visible with a Check note; exclude it from charging-time ranking until BYD clarifies the separate 30–100% row.','source_ids':sid(spec)}]
  elif key=='ac_kw' and k in ['dolphin','atto3old']:
   src=['dolphin-evcentral' if k=='dolphin' else 'atto3old-carexpert'];grade='reported';scope='secondary_or_sibling'
   reason='EV Central publishes 7 kW AC at the Australian DOLPHIN range level.' if k=='dolphin' else 'CarExpert publishes 7 kW AC for Premium; carried to Essential from its Australian sibling because the maker sheet does not state a power.' if not premium else 'CarExpert publishes 7 kW maximum AC for the Australian Premium.'
   condition='Reported Australian range figure; confirm the onboard AC rating.' if k=='dolphin' else 'Reported by CarExpert for Premium.' if premium else 'Carried from the Australian Premium sibling; Essential AC power needs confirmation.'
  elif key=='towing_braked_kg':
   if k=='sealion7':src=['sealion7-handbook'];reason='Australian handbook explicitly gives braked towing of 750 kg for RWD and 1500 kg for four-wheel drive.'
   elif k=='atto2':
    src=[spec,'atto2-handbook'];grade='not_published';scope='searched_not_found';reason='Brochure gives no braked rating; handbook gives 750 kg maximum total towing without distinguishing brakes. The separate towing-limit figure is retained, not relabelled braked.'
   elif k=='atto1':
    src=[spec,'atto1-handbook'];grade='not_published';scope='searched_not_found';reason='Australian brochure and handbook give no numeric braked trailer rating. Handbook says not to tow other vehicles and excludes trailer-towing damage; unknown is not recorded as zero.'
   elif k=='seal':
    src=[spec,'seal-handbook'];grade='not_published';scope='searched_not_found';reason='Current Australian brochure and handbook give no numeric braked trailer rating. A towbar accessory or EPB vehicle-towing mode does not establish trailer capacity.'
   elif k=='dolphin':
    src=['dolphin-evcentral'];grade='reported';scope='secondary_or_sibling';reason='EV Central explicitly publishes 0 kg braked towing for the Australian DOLPHIN range; maker brochure does not publish a numeric rating.';condition='0 kg is EV Central’s reported range figure, not an inferred maker-approved rating.'
  if grade=='not_published':condition=reason
  f=fact(c,key,val,src,grade,reason,scope,condition,issues=issues)
  if key=='price_aud':
   rung=5 if out else 2 if src==['offers'] else 3;cb='Driveaway' if rung==2 else 'Before on-road costs';tag='Reported by CarExpert · historical before on-road costs' if out else 'Maker’s national driveaway offer' if rung==2 else 'Maker’s configurator · before on-road costs'
   f.update(basis=tag,comparisonBasis=cb,priceEvidence={'rung':rung,'basisTag':tag,'sourceKey':'price_aud','sourcePointer':sources[src[0]]['url'],'originalBasis':'Historical 2025 Australian price before on-road costs' if out else 'Promotional national retail driveaway offer' if rung==2 else 'Exact version base selection price; on-road costs separately calculated','rankingEligible':not out})
   if rung==5:f['priceEvidence']['publisher']='CarExpert'
   if rung==2:f['validUntil']='2026-12-15'
 for key,val in [('warranty','6 years / 150,000 km'),('battery_warranty','8 years / 160,000 km; minimum 70% battery capacity retention')]:
  fact(c,key,val,['warranty'],'confirmed','Inherited from explicit brand-wide Australian new-vehicle terms in sections 1.3 and 1.3.1. Whichever time/distance limit occurs first; component limits and exclusions remain in the linked policy.','brand_au_terms')
 fact(c,'roadside_assistance','12 months from delivery',['service'],'confirmed','Brand-wide Australian roadside assistance terms for vehicles delivered on or after 22 July 2025.','brand_au_terms')
 body='Hatchback' if k in ['atto1','dolphin'] else 'Sedan' if k=='seal' else 'SUV'
 fact(c,'body_style',body,[(k if k!='atto3old' else 'atto3evo')+'-product'],'confirmed','The official Australian model page identifies this model’s body scope.','explicit_au_range')
 if k=='atto2':fact(c,'towing_limit_kg',750,['atto2-handbook'],'check','Handbook states a 750 kg maximum total trailer towing limit, without a brake classification.','explicit_au_range','750 kg total towing limit only; braked/unbraked basis not stated. Requires authorised towing kit and related software; not comparable with explicit braked ratings.')
 if k=='atto3evo':fact(c,'dc_charge_0_80_min',30 if premium else 41,[spec],reason='Maker Australian brochure explicitly labels this duration 0–80%; retained separately from the requested 10–80% field.')
 if k=='atto1':fact(c,'dc_charge_30_100_min',22 if premium else 25,[spec],'check','Exact printed 30–100% row is retained, without assuming a typographical correction.','exact_au_version','Maker brochure also prints 30 minutes 10–80%; the charge-window timing is internally inconsistent. Not used for a charging curve or ranking.',issues=[{'issue_id':PID+'-atto1-30-100-window','title':'Printed charge-window timing needs clarification','priority':'medium','model_ids':[c['modelId']],'publication_action':'Retain exact printed window and value; do not compare or convert.','source_ids':sid(spec)}])
 if k=='dolphin':fact(c,'dc_charge_10_80_range_min','40–41',['dolphin-evcentral'],'reported','Secondary range-level duration has no exact grade mapping, so it is displayed separately and does not fill the exact-version 10–80% core field.','secondary_or_sibling','EV Central model-range span; Essential/Premium mapping is not stated.')
 config=('atto3evo' if k=='atto3old' else k)+'-config'
 product=('atto3evo' if k=='atto3old' else k)+'-product'
 evidence={'checkedAt':D,'orderStatus':'not_accepting_orders' if out else 'accepting_order_requests_advertised','stockStatus':'no_new_stock_verified','sourceIds':sid(config,product),'physicalStockVerified':False,'factoryOrderAcceptanceVerified':False,'qualifications':['Outgoing Premium is absent from the current maker model comparison and order configurator; retained for historical context, without verified new stock.'] if out else ['Maker lists this exact version with an order request route. Allocation, accepted factory order, delivery timing and physical stock remain unverified.']}
 p['availability'].append({'id':PID+'-availability-'+c['id'],'variantId':c['id'],'before':{'availability':c['availability'],'evidence':c.get('availabilityEvidence',{'checkedAt':'','orderStatus':'unverified','stockStatus':'unverified','sourceIds':[]})},'after':{'availability':c['availability'],'evidence':evidence},'status':'approved','reviewedBy':REVIEWER,'reviewedAt':D,'evidenceDate':D,'reason':'Complete current maker Australian model comparison and configurator checked; exact version membership reconciled.'})

# Original buyer-use interpretation, with all numeric statements bound to the facts used.
summary={
'byd_sealion_7__premium_rwd__1':(('Family luggage space','Five seats and a 500 L rear boot suit family trips.',['seats','boot_l']),('Light-trailer limit','The 750 kg braked limit narrows the choice of trailers.',['towing_braked_kg'])),
'byd_sealion_7__performance_awd__2':(('Performance and towing','AWD, 4.5-second acceleration and 1500 kg braked towing add flexibility.',['drive','zero_to_100_s','towing_braked_kg']),('Wide body','The 1925 mm body needs room in tight parking spaces.',['width_mm'])),
'byd_atto_2__dynamic__1':(('Compact family fit','Five seats and a 380 L boot fit into a 4310 mm SUV body.',['seats','boot_l','length_mm','body_style']),('Long-trip charging','A 345 km WLTP claim and 38.6-minute 10–80% charge need planning on longer trips.',['range_km','dc_charge_time_min'])),
'byd_atto_2__premium__2':(('Everyday practicality','A 380 L boot and five seats make room for everyday family use.',['boot_l','seats']),('Range and stops','The 345 km WLTP range and 38.6-minute 10–80% time limit long-trip margin.',['range_km','dc_charge_time_min'])),
'byd_atto_3_evo__dynamic_fwd__1':(('Useful family footprint','A 434 L rear boot and 420 km WLTP range suit everyday family travel.',['boot_l','range_km']),('Light-trailer limit','The 750 kg braked rating limits heavier trailer plans.',['towing_braked_kg'])),
'byd_atto_3_evo__premium_rwd__2':(('Range and luggage','A 510 km WLTP claim and 490 L rear boot suit longer family trips.',['range_km','boot_l']),('Five-seat ceiling','There are five seats, so this cannot cover six-person trips.',['seats'])),
'byd_atto_3_legacy__essential_fwd__1':(('Everyday luggage room','Five seats and a 440 L rear boot make a useful everyday family layout.',['seats','boot_l']),('Shorter-trip focus','The 345 km WLTP claim and 70 kW DC peak leave less long-trip margin.',['range_km','dc_peak_kw'])),
'byd_atto_3_legacy__premium_fwd__2':(('Range and space','A 420 km WLTP claim and 440 L rear boot make this SUV practical.',['range_km','boot_l','body_style']),('Modest DC peak','An 88 kW DC peak limits fast-charge power on compatible high-power chargers.',['dc_peak_kw'])),
'byd_seal__premium_rwd__20261010':(('Long-range sedan','A 570 km WLTP claim gives this rear-drive sedan useful trip-planning margin.',['range_km','drive','body_style']),('Long body','The 4800 mm body needs a reasonably long parking space.',['length_mm'])),
'byd_seal__performance_awd__20261010':(('Quick all-wheel drive','AWD and a 3.8-second 0–100 km/h claim give brisk acceleration.',['drive','zero_to_100_s']),('Sedan luggage limit','The rear boot is 400 L, so check bulky luggage before choosing this sedan.',['boot_l','body_style'])),
'byd_dolphin__essential_fwd__20261010':(('Compact five-seater','Five seats and a 345 L boot fit into a 4290 mm hatchback.',['seats','boot_l','length_mm','body_style']),('Gentler acceleration','The 12.3-second 0–100 km/h claim makes this a measured rather than rapid choice.',['zero_to_100_s'])),
'byd_dolphin__premium_fwd__20261010':(('Range in a hatchback','The 427 km WLTP claim gives a compact hatchback useful driving range.',['range_km','body_style','length_mm']),('Charging ceiling','The 80 kW DC peak limits the benefit from higher-power charging stations.',['dc_peak_kw'])),
'byd_atto_1__essential_fwd__20261010':(('Small-car practicality','A 3990 mm body and 308 L boot suit everyday city errands.',['length_mm','boot_l']),('Passenger and range limits','Four seats and a 220 km WLTP claim favour smaller groups and shorter trips.',['seats','range_km'])),
'byd_atto_1__premium_fwd__20261010':(('Compact range upgrade','A 310 km WLTP claim fits into a city-sized 3990 mm body.',['range_km','length_mm']),('Only four seats','Four seats leave no place for a fifth passenger.',['seats']))}
for c in cars:
 clauses=[]
 for label,txt,deps in summary[c['id']]:clauses.append({'label':label,'text':txt,'dependencies':[{'key':key,'expected':effective[c['id']][key]} for key in deps]})
 p['summaries'].append({'variantId':c['id'],'conditions':[],'strength':clauses[0],'tradeoff':clauses[1]})
# Store shared brand terms once with exact per-version guards.
p['brandTerms']=[]
for key in ['warranty','battery_warranty','roadside_assistance']:
 rows=[r for r in p['facts'] if r['after']['key']==key]
 shared_fact=dict(rows[0]['after']);shared_fact['scope']='New BYD vehicles supplied in Australia; warranty commencement follows the linked policy'
 p['brandTerms'].append({'key':key,'fact':shared_fact,'applicableVariantIds':[r['variantId'] for r in rows],'before':{r['variantId']:r['before'] for r in rows},'exceptions':[]})
p['facts']=[r for r in p['facts'] if r['after']['key'] not in ['warranty','battery_warranty','roadside_assistance']]
# Stage outside the live registry during integration tests.
pathlib.Path('/tmp/byd-research/byd-2026-10-14.json').write_text(json.dumps(p,indent=2)+'\n')
# Official current-version membership is scoped by body/generation, not the shared marketing name.
r={'schemaVersion':1,'checkedAt':D,'notes':['BYD current Australian BEV version review only. Global independent-market-list reconciliation remains open.','Thirteen exact versions are order-request listed. Legacy ATTO 3 Premium is outgoing and absent from the complete current maker list; no new stock is verified.','Plug-in hybrids including ATTO 2 DM-i, M9, SEAL 6, SEALION 5/6/8 and SHARK 6 are outside BEV scope.'],'publishedLists':[],'currentVersionReviews':[],'listResolutions':[],'catalogueOnlyDifferences':[],'inventoryResolutions':[]}
for mid in dict.fromkeys(c['modelId'] for c in cars):
 cs=[c for c in cars if c['modelId']==mid and c['availability']!='outgoing'];c=cs[0];k=key_for(c);product=('atto3evo' if k=='atto3old' else k)
 r['currentVersionReviews'].append({'id':PID+'-current-'+mid,'brand':'BYD','model':c['model'],'bodyStyle':effective[c['id']]['body_style']['value'],'vehicleClass':'passenger','modelId':mid,'checkedAt':D,'officialSourceUrls':[sources[product+'-product']['url'],sources[product+'-config']['url']],'reason':'Complete current Australian maker comparison and configurator checked. '+('Essential is retained alongside the two EVO grades; the older Premium is absent and remains outgoing.' if k=='atto3old' else 'Only the exact listed BEV grades of this body are included; no overseas grade or plug-in hybrid is inherited.'),'versions':[{'carId':x['id'],'model':x['model'],'trim':x['trim'],'modelYear':x['year']} for x in cs]})
for review in r['currentVersionReviews']:
 if review['modelId']=='byd_atto_3_legacy':
  review['publishedModelAliases']=[{'name':'ATTO 3','reason':'The official maker page calls the continuing original-generation Essential ATTO 3, while the catalogue retains a legacy FWD suffix to keep it separate from ATTO 3 EVO.','sourceUrls':review['officialSourceUrls']}]
for inv,mid in [('byd-atto-1','byd_atto_1'),('byd-dolphin','byd_dolphin'),('byd-seal','byd_seal')]:
 rev=next(x for x in r['currentVersionReviews'] if x['modelId']==mid)
 r['inventoryResolutions'].append({'kind':'record','inventoryId':inv,'reviewedAt':D,'reason':'Inherited audit model is included with its complete current Australian BEV version list and exact catalogue identities.','sourceUrls':rev['officialSourceUrls'],'outcome':'included','modelReviewId':rev['id']})
pathlib.Path('/tmp/byd-research/byd-reconciliation-2026-10-14.json').write_text(json.dumps(r,indent=2)+'\n')
print('Built',len(p['facts']),'facts',len(p['sources']),'sources',len(p['summaries']),'summaries;',len(r['currentVersionReviews']),'reviews')
print('Core missing:',[(x['variantId'],x['after']['key']) for x in p['facts'] if x['after']['value'] is None])
