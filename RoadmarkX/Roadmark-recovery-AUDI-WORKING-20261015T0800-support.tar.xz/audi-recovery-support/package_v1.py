#!/usr/bin/env python3
"""Single-thread preset-6 XZ; file-object tar members and bounded verification."""
import pathlib,json,hashlib,tarfile,lzma,io,sys,datetime
from capture_v2 import C,R,pin,load,dump,check,identity,CHUNK,safe
LABEL='AUDI-WORKING-20261015T0800'
def add_file(t,name,p,rec):
 safe(name);check(p,rec);before=identity(p);info=tarfile.TarInfo(name);info.size=rec['bytes'];info.mode=0o644;info.mtime=0
 with p.open('rb') as f:t.addfile(info,f)
 assert identity(p)==before
 # Exact hash after the read prevents a changed payload from being promoted.
 check(p,rec)
def add_bytes(t,name,b):
 info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b));return {'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def verify(path,want):
 seen=set()
 with lzma.open(path,'rb') as stream:
  with tarfile.open(fileobj=stream,mode='r|') as t:
   for m in t:
    safe(m.name);assert m.isfile() and m.name not in seen and m.name in want;seen.add(m.name);h=hashlib.sha256();n=0
    with t.extractfile(m) as f:
     while b:=f.read(CHUNK):h.update(b);n+=len(b)
    assert (n,h.hexdigest())==(want[m.name]['bytes'],want[m.name]['sha256']),m.name
  while stream.read(CHUNK):pass
 assert seen==set(want)
 return {'file':str(path),'filename':path.name,**pin(path),'members':len(seen),'memberFiles':list(want.values()),'allMembersVerified':True}
def pack(path,rows,meta,source=False):
 assert not path.exists();want={}
 with tarfile.open(path,'w:xz',format=tarfile.PAX_FORMAT,preset=6) as t:
  for r in rows:
   n=('roadmark/' if source else '')+r['path'];add_file(t,n,pathlib.Path(r['payloadPath']),r);want[n]={'path':n,'bytes':r['bytes'],'sha256':r['sha256']}
  for n,b in meta.items():want[n]=add_bytes(t,n,b)
 if source:assert path.stat().st_size<15000000,'source exceeds strict 15,000,000 bytes'
 a=verify(path,want);a.update(group='source-'+LABEL if source else LABEL,new=True);return a
def main():
 if sys.argv[1]=='source':
  cap=load(C/'source-capture.json');manifest={'schemaVersion':1,'root':'roadmark','files':[{k:r[k] for k in ['path','bytes','sha256']} for r in cap['files']]};a=pack(R/f'Roadmark-recovery-source-{LABEL}.tar.xz',cap['files'],{'roadmark/SOURCE-FILE-MANIFEST.json':(json.dumps(manifest,indent=2)+'\n').encode()},True);dump(C/'source-package.json',a)
 elif sys.argv[1]=='support':
  inv=load(C/'SUPPORT-MEMBER-INVENTORY.json');rows=inv['files'];metadata={'recovery-metadata/'+LABEL+'-support.json':(json.dumps(inv,indent=2)+'\n').encode()};a=pack(R/f'Roadmark-recovery-{LABEL}-support.tar.xz',rows,metadata);dump(C/'support-package.json',a)
 else:
  assert sys.argv[1]=='proof'
  cap=load(C/'proof-capture-v1.json');rows=cap['changedFiles'];groups=[];cur=[];size=0
  for r in rows:
   if cur and size+r['bytes']>24000000:groups.append(cur);cur=[];size=0
   cur.append(r);size+=r['bytes']
  if cur:groups.append(cur)
  ars=[]
  for i,g in enumerate(groups,1):
   meta={'schemaVersion':1,'label':LABEL,'part':i,'parts':len(groups),'state':cap['state'],'files':[{k:r[k] for k in ['path','bytes','sha256','originalBytes','originalSHA256']} for r in g],'restore':'Overlay after the exact 119-archive Škoda chain, replacing its source archive with this full registered Audi working source. Original raw-capture expected hashes and sanitation mapping remain unchanged.'};metadata={f'recovery-metadata/{LABEL}-part{i:02d}.json':(json.dumps(meta,indent=2)+'\n').encode()};
   if i==1:metadata['audi-safety-support/COPY-SANITATION-MAPPING.json']=(C/'COPY-SANITATION-MAPPING.json').read_bytes()
   a=pack(R/f'Roadmark-recovery-{LABEL}-part{i:02d}of{len(groups):02d}.tar.xz',g,metadata);ars.append(a);print(json.dumps({'part':i,'members':a['members'],'bytes':a['bytes']}),flush=True)
  dump(C/'proof-packages.json',{'archives':ars})
if __name__=='__main__':main()
