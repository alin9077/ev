#!/usr/bin/env python3
"""Static seed-list contract; reads metadata only and never opens archives."""
import datetime
import hashlib
import json
import pathlib
import stat

C = pathlib.Path(__file__).resolve().parent
BASE = C.parent / 'skoda-working-20261015T0520'
CHUNK = 65536

def pin(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode)
    identity = (before.st_size, before.st_mtime_ns, before.st_ctime_ns, before.st_ino, before.st_dev)
    digest = hashlib.sha256()
    count = 0
    with path.open('rb') as stream:
        while block := stream.read(CHUNK):
            digest.update(block)
            count += len(block)
    after = path.lstat()
    assert identity == (after.st_size, after.st_mtime_ns, after.st_ctime_ns, after.st_ino, after.st_dev)
    assert count == identity[0]
    return {'bytes': count, 'sha256': digest.hexdigest()}

def load(path):
    return json.loads(path.read_text())

def main():
    source = C / 'SEED-PROVENANCE.json'
    assert pin(source) == pin(BASE / source.name)
    manifest_path = BASE / 'deliverables/Roadmark-RECOVERY-MANIFEST-SKODA-WORKING-20261015.json'
    assert pin(manifest_path) == {'bytes': 3749629, 'sha256': '744c41676bd8b8bbd4b97b78b06ffd3f94fb4e6d24bbb8d7580edc31b5cbc42c'}
    seeds = load(source)['historicalSeedMembers']
    assert len(seeds) == 200
    identities = {(row['archive'], row['member']): row for row in seeds}
    assert len(identities) == 200
    for row in seeds:
        assert row['bytes'] >= 0 and len(row['sha256']) == 64
        assert set(row['sha256']) <= set('0123456789abcdef')
    archive_names = sorted({row['archive'] for row in seeds})
    assert len(archive_names) == 21
    inherited_names = {row['filename'] for row in load(manifest_path)['archivesInRestoreOrder']}
    overlap = sorted(set(archive_names) & inherited_names)
    prior = load(C / 'INDEPENDENT-AUDI-STATIC-PREPARATION-v1.json')
    assert overlap == prior['seedReadBlocker']['overlap'] and len(overlap) == 9
    rows = [{key: row[key] for key in ('archive', 'member', 'bytes', 'sha256')} for row in seeds]
    canonical = json.dumps(rows, sort_keys=True, separators=(',', ':')).encode()
    result = {
        'result': 'PASS_STATIC_EXACT_SEED_METADATA_CONTRACT',
        'checkedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scriptPin': pin(pathlib.Path(__file__)),
        'priorStaticPreparation': pin(C / 'INDEPENDENT-AUDI-STATIC-PREPARATION-v1.json'),
        'provenancePin': pin(source),
        'baseManifestPin': pin(manifest_path),
        'seedMemberCount': 200,
        'seedArchiveCount': 21,
        'inheritedArchiveOverlapCount': 9,
        'archiveNames': archive_names,
        'inheritedArchiveOverlap': overlap,
        'canonicalOrderedMemberIdentityList': {'bytes': len(canonical), 'sha256': hashlib.sha256(canonical).hexdigest()},
        'targetedSeedReadException': {
            'status': 'ROOT_APPROVAL_RELAYED_BY_PARENT',
            'scope': 'Only the exact 200 pinned seed members in these 21 historical archives, including nine recommended-chain archives, to reconstruct unchanged known-value seeds',
            'noFullBaseScanOrClone': True,
            'requiredDuringEveryScannerInvocation': 'Verify every target member identity and exact target-set coverage; record actual targeted seed reads separately from fresh-member verification',
            'knownValuesNeverPersistedOrPrinted': True,
            'addressSpaceBytes': 268435456
        },
        'unifiedGateRefinement': {
            'order': ['Freeze reviewed code', 'Capture and package source/proof', 'Seal exact compact support inventory/archive', 'Derive one source+proof+support archive plan', 'Scan and independently replay every fresh archive', 'Persist and construct compact documents/active/closure'],
            'noSelfHashOrOwnResultsInsideSupportArchive': True,
            'postSealCompactReceiptsRemainExternal': True,
            'lateUniqueCodeRequiresAdditiveSupportAndVersionedAllFreshPlan': True
        },
        'originalSeedReadBlockerResolved': True,
        'finalFreezeStillRequired': True,
        'archivePayloadReadsPerformedByThisCheck': 0,
        'productionExecutionApprovedByThisReport': False
    }
    output = C / 'INDEPENDENT-AUDI-SEED-METADATA-CONTRACT-v1.json'
    with output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'result': result['result'], 'members': 200, 'archives': 21, 'overlap': 9, 'reportPin': pin(output)}))

if __name__ == '__main__':
    main()
