import collections,json,pathlib
from capture_v2 import C,BASE,load,pin,dump
bp=BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-SKODA-WORKING-20261015.json';b=load(bp)
assert pin(bp)=={'bytes':3749629,'sha256':'744c41676bd8b8bbd4b97b78b06ffd3f94fb4e6d24bbb8d7580edc31b5cbc42c'}
idx=collections.defaultdict(list)
for f in b['files']:idx[(f['bytes'],f['sha256'])].append({'member':f['path'],'origin':'verified-base-manifest'})
for n in ['source-capture.json','proof-capture-v1.json']:
 for f in load(C/n)['files']:idx[(f['bytes'],f['sha256'])].append({'member':('roadmark/' if n=='source-capture.json' else '')+f['path'],'origin':'current-capture-manifest'})
pc=load(C/'proof-capture-v1.json');r=next(r for r in pc['files'] if r['path']=='audi-packet/full-stage-v1/manifest.json');p=pathlib.Path(r['payloadPath']);assert pin(p)=={k:r[k] for k in ['bytes','sha256']};m=load(p)
rows=[]
for r in m['pins']:
 matches=idx[(r['bytes'],r['sha256'])];assert matches,r['path'];rows.append({'originalPath':r['path'],'bytes':r['bytes'],'sha256':r['sha256'],'retainedExactMembers':matches})
s=m['storageIndex'];matches=idx[(s['bytes'],s['sha256'])];assert matches
assert len(rows)==146
dump(C/'EXACT-BASELINE-DEPENDENCY-MAPPING.json',{'status':'PASS_METADATA_ONLY_EXACT_IDENTITY_MAPPING','scope':'All 146 direct full-stage manifest input pins plus its named storage index; inherited nested reconstruction metadata is retained, not newly replayed','manifestMember':'audi-packet/full-stage-v1/manifest.json','manifestPin':pin(p),'baseManifestPin':pin(bp),'directPins':rows,'storageIndex':{'originalReference':s,'retainedExactMembers':matches},'basePayloadsRead':0,'captureExpanded':False,'originalExpectedHashesUnchanged':True})
print(json.dumps({'directPins':len(rows),'missing':0,'basePayloadsRead':0}))
