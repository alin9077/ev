"""Same-request retained official prepared upload route; terminal/identity receipts."""
from pathlib import Path
import subprocess,json,time,resource,datetime,sys
c=Path(__file__).resolve().parent;h=c.parents[1]/'library-helper-20261014T1020/library_upload.py';phase=sys.argv[1]
assert phase in ['archives','documents','active']
def load(n):return json.loads((c/n).read_text())
if phase=='archives':assert load('PREUPLOAD-GATE.json')['result']=='PASS'
if phase=='documents':assert load('DELIVERABLE-PRIVACY-GATE.json')['result']==load('INDEPENDENT-DELIVERY-DOCUMENT-CHECK.json')['result']=='PASS'
if phase=='active':assert load('ACTIVE-PRIVACY-GATE.json')['result']==load('INDEPENDENT-ACTIVE-RECEIPT-CHECK.json')['result']=='PASS'
started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
with (c/f'library-{phase}-request.json').open('rb') as inp,(c/f'library-{phase}-results.json').open('xb') as out,(c/f'library-{phase}-results.err').open('xb') as err:
 r=subprocess.run(['python3',str(h)],stdin=inp,stdout=out,stderr=err)
with (c/f'upload-{phase}.resources.json').open('x') as f:json.dump({'startedAt':started,'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'wallSeconds':time.monotonic()-t,'maxRssKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'route':'Unchanged retained official prepared helper; authorized same request','localComputeCapAppliedToNetworkHelper':False,'uncertainRetry':False},f,indent=2);f.write('\n')
print('Official helper terminal exit',r.returncode,flush=True)
if r.returncode:raise SystemExit(r.returncode)
with (c/f'library-{phase}-verified.jsonl').open('x') as out:r=subprocess.run(['python3',str(c/'check_upload_phase.py'),phase],stdout=out)
print('Ordered identity verification exit',r.returncode,flush=True)
raise SystemExit(r.returncode)
