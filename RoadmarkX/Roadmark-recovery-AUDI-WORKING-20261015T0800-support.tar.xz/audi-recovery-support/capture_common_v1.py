#!/usr/bin/env python3
"""Explicit selected proof/QA + full source, exact hash reuse, no full source clone."""
import pathlib,json,hashlib,datetime,importlib.util,stat,sys,os
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent;R=C.parents[1];W=R.parent;OLD=C.parent/'xpeng-registered-working-20261014T2030';BASE=C.parent/'skoda-working-20261015T0520';SANBASE=C.parent/'mercedes-research-safety-20261014T2145';CHUNK=65536

def load(p):return json.loads(P(p).read_text())
def dump(p,d):
 with P(p).open('x') as f:json.dump(d,f,indent=2);f.write('\n')
def sha(b):return hashlib.sha256(b).hexdigest()
def identity(p):
 z=p.lstat();assert stat.S_ISREG(z.st_mode) and not any(q.is_symlink() for q in p.parents),str(p);return [z.st_size,z.st_mtime_ns,z.st_ctime_ns,z.st_ino,z.st_dev]
def pin(p):
 h=hashlib.sha256();n=0
 with P(p).open('rb') as f:
  while b:=f.read(CHUNK):h.update(b);n+=len(b)
 return {'bytes':n,'sha256':h.hexdigest()}
def check(p,expected):
 a=identity(p);got=pin(p);assert identity(p)==a and got['bytes']==a[0],str(p)
 for k in ('bytes','sha256'):
  if expected.get(k) is not None:assert got[k]==expected[k],str(p)+' '+k
 return got,a
def module(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
S=module('snapshot',R/'snapshot_recovery_v2.py')
def safe(n):
 p=P(n);assert n and not p.is_absolute() and '..' not in p.parts and str(p)==n and '\\' not in n;return n
def restpath(p):
 p=P(p)
 if p.is_relative_to('/tmp'):return safe(p.relative_to('/tmp').as_posix())
 if p.is_relative_to(W/'roadmark-104'):return 'roadmark/'+safe(p.relative_to(W/'roadmark-104').as_posix())
 if p.is_relative_to(W/'roadmark-104-qa'):return safe(p.relative_to(W).as_posix())
 raise ValueError('Unexpected selected root: '+str(p))

# Reviewed production implementation is capture_v2.py; this module exposes only unchanged common helpers.
