#!/usr/bin/env python3
"""Read accepted phase metadata and frozen identities; no payload or archive scan."""
import datetime
import hashlib
import json
import pathlib

C = pathlib.Path(__file__).resolve().parent
BASE = C.parent / 'skoda-working-20261015T0520'

def load(path):
    return json.loads(path.read_text())

def pin(path):
    payload = path.read_bytes()
    return {'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()}

def main():
    review = load(C / 'INDEPENDENT-AUDI-CAPTURE-FOUNDATION-REVIEW-v1.json')
    for row in review['reviewedScripts']:
        assert pin(pathlib.Path(row['path'])) == {key: row[key] for key in ('bytes', 'sha256')}
    inventory_review = load(C / 'INDEPENDENT-AUDI-CANDIDATE-INVENTORY-REVIEW-v1.json')
    row = inventory_review['script']
    assert pin(C / row['filename']) == {key: row[key] for key in ('bytes', 'sha256')}
    commands = {'freeze-scope': ['python3', str(C / 'freeze_scope_v1.py')], 'capture-source': ['python3', str(C / 'capture_v2.py'), 'source'], 'json-candidates': ['python3', str(C / 'inventory_json_sanitizer_candidates_v2.py')]}
    terminals = {}
    for name, command in commands.items():
        path = C / (name + '.resources.json')
        result = load(path)
        invocation = load(C / (name + '.resources.invocation.json'))
        assert result['command'] == invocation['command'] == command
        assert result['exitCode'] == 0 and not result['timedOut'] and result['maxRssKiB'] > 0
        assert result['addressSpaceLimitBytes'] == invocation['addressSpaceLimitBytes'] == 268435456
        assert result['childPid'] == invocation['childPid'] and result['wallLimitSeconds'] == invocation['wallLimitSeconds'] == 600
        terminals[name] = {'receipt': pin(path), 'result': result}
    scope = load(C / 'FROZEN-CAPTURE-SCOPE.json')
    identities = {row['path']: row['identity'] for row in load(C / 'INDEPENDENT-AUDI-FREEZE-IDENTITIES-v1.json')['files']}
    assert len(scope['files']) == len(identities) == 878
    for row in scope['files']:
        ident = identities[row['path']]
        assert row['bytes'] == ident[0] and row['mtimeNsAtFreeze'] == ident[1]
    current = load(C / 'source-capture.json')
    old = {row['path']: row for row in load(BASE / 'source-capture.json')['files']}
    source = {row['path']: row for row in current['files']}
    orig = lambda row: {key: row[key] for key in ('originalBytes', 'originalSHA256')}
    delta = {name for name, row in source.items() if name not in old or orig(row) != orig(old[name])}
    assert len(source) == len(current['files']) == scope['expectedSourceFiles'] == 685
    assert delta == set(scope['sourceChangedPaths']) and len(delta) == 16 and set(old) <= set(source)
    frozen = {row['path']: row for row in scope['files']}
    for name, row in source.items():
        if name in delta:
            expected = frozen[row['originalPath']]
            assert row['originalBytes'] == row['bytes'] == expected['bytes']
            assert row['originalSHA256'] == row['sha256'] == expected['sha256']
            assert row['sourceIdentity'] == identities[row['originalPath']]
        else:
            prior = old[name]
            for key in ('bytes', 'sha256', 'originalBytes', 'originalSHA256', 'redactedHeaderPaths', 'redactedPointers', 'redactedHTMLRanges'):
                assert row.get(key, []) == prior.get(key, [])
            assert row['payloadPath'] == prior['payloadPath']
    assert not current['sourceChangesDuringCapture'] and not current['fullSourceTreeCloned'] and current['chunkBytes'] == 65536
    candidates = load(C / 'JSON-SANITIZER-CANDIDATES-v1.json')
    assert candidates['result'] == 'NO_CANDIDATES' and candidates['jsonFilesChecked'] == sum(pathlib.Path(row['path']).suffix == '.json' for row in scope['files']) == 519
    assert candidates['candidateFiles'] == [] and candidates['candidateLocations'] == 0
    assert load(C / 'PROSE-KEY-RENAME-APPROVALS.json')['files'] == []
    result = {'result': 'PASS_CAPTURED_SOURCE_AND_NO_NEW_JSON_CANDIDATES', 'checkedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'script': pin(pathlib.Path(__file__)), 'sourceCapture': pin(C / 'source-capture.json'), 'frozenScope': pin(C / 'FROZEN-CAPTURE-SCOPE.json'), 'freezeIdentities': pin(C / 'INDEPENDENT-AUDI-FREEZE-IDENTITIES-v1.json'), 'candidateInventory': pin(C / 'JSON-SANITIZER-CANDIDATES-v1.json'), 'phaseTerminals': terminals, 'selectedFrozenFiles': 878, 'sourceFiles': 685, 'changedSourceFiles': 16, 'unchangedSourceReuse': 669, 'sourceOriginalAndSanitizedPinsExact': True, 'jsonFilesChecked': 519, 'candidateLocations': 0, 'sourceImmutableCutRecorded': True, 'proofCaptureAtReviewedVersionApprovedAfterSoleSlotRelease': True, 'proofCaptureStillFailsClosedOnAnyNewSensitiveField': True, 'fullArchivePrivacyAndIndependentReplayPending': True, 'noPayloadRehashOrArchiveReadByThisCheck': True}
    with (C / 'INDEPENDENT-AUDI-CAPTURE-READBACK-v1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'result': result['result'], 'sourceFiles': 685, 'changedSourceFiles': 16, 'jsonCandidateLocations': 0, 'reportPin': pin(C / 'INDEPENDENT-AUDI-CAPTURE-READBACK-v1.json')}))

if __name__ == '__main__':
    main()
