from capture_v2 import *
import os,datetime
retention=P('/tmp/audi-handoff/final-freeze.json');check(retention,{'bytes':10416,'sha256':'dab81635acb02717540474f19b8006b13414aab126b9162eb6307bf816a41d66'});d=load(retention);assert d['noFurtherLiveWritesAuthorized'] and not d['heavyProcessesActive'];inventory=P(d['retentionInventory']['path']);check(inventory,d['retentionInventory']);v=load(inventory);assert v['regularFileCount']==len(v['regularFiles'])==858 and not v['otherEntries'];assert sum(r['bytes'] for r in v['regularFiles'])==v['regularFileBytes']==81285268
files={};observed=set();links={}
for r in v['regularFiles']:
 p=P(r['path']);ident=identity(p);assert ident[0]==r['bytes'] and ident[1]==r['mtimeNs'];files[str(p)]={'path':str(p),'bytes':ident[0],'mtimeNsAtFreeze':ident[1]}
for root in v['roots']:
 assert not P(root).is_symlink()
 for current,dirs,names in os.walk(root,followlinks=False):
  for name in list(dirs)+names:
   p=P(current)/name
   if p.is_symlink():
    links[str(p)]=os.readlink(p)
    if name in dirs:dirs.remove(name)
   elif p.is_file():identity(p);observed.add(str(p))
assert observed==set(files);assert links=={r['path']:r['target'] for r in v['symlinks']}=={r['path']:r['target'] for r in d['metadataOnlyLinks']};assert len(links)==7
pins=d['sourceAndStatusFiles']+d['reviewerReceipts']+d['researchProvenance']+d['handoffArtifacts']
for r in pins:
 p=P(r['path']);got,ident=check(p,r)
 if str(p) in files:assert files[str(p)]['bytes']==got['bytes'] and files[str(p)]['mtimeNsAtFreeze']==ident[1]
 files[str(p)]={'path':str(p),**got,'mtimeNsAtFreeze':ident[1]}
for p in [retention,inventory]:
 got,ident=check(p,{});assert str(p) not in files;files[str(p)]={'path':str(p),**got,'mtimeNsAtFreeze':ident[1]}
changed=sorted(P(r['path']).relative_to(W/'roadmark-104').as_posix() for r in d['sourceAndStatusFiles'] if P(r['path']).is_relative_to(W/'roadmark-104'));assert len(changed)==16
pack=module('packager',W/'roadmark-104/scripts/package-source.py');sourceFiles=list(pack.source_files(W/'roadmark-104'));base=load(BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-SKODA-WORKING-20261015.json');old={r['path']:r for r in base['files']};overlay=sorted(restpath(P(p)) for p in files if restpath(P(p)) in old and not restpath(P(p)).startswith('roadmark/'));assert overlay==['roadmark-104-qa/work-status.json']
state='Registered Audi working cut; nine scoped fresh checks, exact complete normal/staged report parity, 190 targeted tests, and full-project cold TypeScript v2 with all 361 roots and only a fresh temporary cache override independently passed. Separate one-line test generic correction and 18 focused tests retained alongside the original TS2345 failure. Full aggregate suite, production build, mobile/device testing, strict M1 closure and release remain open.'
(C/'WORKING-STATE.txt').open('x').write(state+'\n')
q={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'freezeMetadata':{'path':str(retention),**pin(retention)},'authorRetention':d,'authorInventory':{'path':str(inventory),**pin(inventory)},'roots':v['roots'],'files':sorted(files.values(),key=lambda x:x['path']),'knownPinsVerified':len({r['path'] for r in pins})+2,'sourceChangedPaths':changed,'expectedSourceFiles':len(sourceFiles),'expectedNonSourceOverlay':overlay,'workingResult':state,'openGates':['M1 strict closure','Full-project aggregate suite','Production build','Real-device mobile/phone screenshots','Release/M2'],'scopeMethod':'Exact frozen regular-file inventory plus 17 source/docs/status pins and three handoff metadata files; no broad QA or /tmp capture','metadataOnlySymlinks':d['metadataOnlyLinks'],'noDeletion':True,'noSymlinkTraversal':True}
dump(C/'FROZEN-CAPTURE-SCOPE.json',q);print(json.dumps({'files':len(files),'bytes':sum(r['bytes'] for r in files.values()),'sourceFiles':len(sourceFiles),'sourceDeltaPaths':len(changed),'metadataOnlyLinks':len(links)}))
