from capture_v2 import *
# This explicit scope is written after final static code review and before sealing.
scope=load(C/'SUPPORT-SCOPE.json');names=scope['files'];assert len(names)==len(set(names));rows=[]
for n in names:
 safe(n);p=C/n;assert p.parent==C and p.is_file() and not p.is_symlink();assert p.suffix in ['.py','.json','.txt','.log','.err','.diff','.md'];assert not n.startswith('library-') and n not in ['SUPPORT-MEMBER-INVENTORY.json','support-package.json','ARCHIVE-PLAN.json','RESTORE-PLAN.json','FRESH-ONLY-RESTORE-MANIFEST.json'];got,ident=check(p,{});rows.append({'path':'audi-recovery-support/'+n,**got,'originalBytes':got['bytes'],'originalSHA256':got['sha256'],'payloadPath':str(p),'sourceIdentity':ident})
assert any(r['path'].endswith('/APPLICATION-ASSERTION-CONTRACT.json') for r in rows)
dump(C/'SUPPORT-MEMBER-INVENTORY.json',{'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SEALED_UNIQUE_SUPPORT_MEMBERS_BEFORE_ARCHIVE_PRIVACY_AND_REPLAY','files':rows,'scopePin':pin(C/'SUPPORT-SCOPE.json'),'noRecursiveExecutableEmbedding':True,'postSealReceiptsRetainedExternally':True,'newUniqueCodeRequiresAdditiveSupport':True,'originalArchiveOrSourcePayloadTreesExcluded':True});print(json.dumps({'supportFiles':len(rows),'supportBytes':sum(r['bytes'] for r in rows)}))
