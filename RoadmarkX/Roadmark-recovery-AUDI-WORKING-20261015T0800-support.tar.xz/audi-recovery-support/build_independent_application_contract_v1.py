#!/usr/bin/env python3
"""Bind frozen application result metadata; no product test or source/evidence body scan."""
import datetime
import hashlib
import json
import pathlib

P = pathlib.Path
C = P(__file__).resolve().parent
W = C.parents[2]

def load(path):
    return json.loads(P(path).read_text())

def rest(path):
    path = P(path)
    if path.is_relative_to('/tmp'):
        return path.relative_to('/tmp').as_posix()
    if path.is_relative_to(W / 'roadmark-104'):
        return 'roadmark/' + path.relative_to(W / 'roadmark-104').as_posix()
    assert path.is_relative_to(W / 'roadmark-104-qa')
    return path.relative_to(W).as_posix()

def pin(path):
    path = P(path)
    before = path.stat()
    payload = path.read_bytes()
    after = path.stat()
    fields = lambda row: (row.st_size, row.st_mtime_ns, row.st_ctime_ns, row.st_ino, row.st_dev)
    assert fields(before) == fields(after) and len(payload) == before.st_size
    return {'path': str(path), 'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()}

def main():
    freeze_path = P('/tmp/audi-handoff/final-freeze.json')
    assert pin(freeze_path)['sha256'] == 'dab81635acb02717540474f19b8006b13414aab126b9162eb6307bf816a41d66'
    freeze = load(freeze_path)
    inventory_path = P(freeze['retentionInventory']['path'])
    assert pin(inventory_path) == freeze['retentionInventory']
    selected = {row['path'] for row in load(inventory_path)['regularFiles']}
    selected.update(row['path'] for row in freeze['sourceAndStatusFiles'] + freeze['handoffArtifacts'])
    selected.update([str(freeze_path), str(inventory_path)])
    assertions, retained = [], {}
    def add_pin(row):
        assert row['path'] in selected, 'accepted artifact outside final freeze: ' + row['path']
        entry = {'path': rest(row['path']), 'bytes': row['bytes'], 'sha256': row['sha256']}
        if entry['path'] in retained:
            assert retained[entry['path']] == entry
        retained[entry['path']] = entry
    def refs(value):
        if isinstance(value, dict):
            if all(key in value for key in ('path', 'bytes', 'sha256')):
                add_pin(value)
            for child in value.values():
                refs(child)
        elif isinstance(value, list):
            for child in value:
                refs(child)
    def assertion(path, pointer, expected):
        assertions.append({'restorePath': rest(path), 'pointer': pointer, 'expected': expected})
    add_pin(pin(freeze_path))
    assertion(freeze_path, '/finalOutcomes', freeze['finalOutcomes'])
    assertion(freeze_path, '/includedFailures', freeze['includedFailures'])
    for row in freeze['sourceAndStatusFiles'] + freeze['reviewerReceipts'] + freeze['researchProvenance'] + freeze['handoffArtifacts']:
        add_pin(row)
    for row in freeze['reviewerReceipts']:
        assert pin(row['path']) == row
        value = load(row['path'])
        refs(value)
        assertion(row['path'], '/status', value['status'])
    nine_path = '/tmp/audi-review/post-registration-nine-results-acceptance.json'
    nine = load(nine_path)
    assert len(nine['steps']) == 9 and nine['targetedTests'] == {'installedSplit': 78, 'existingFixtureRegression': 105, 'isolatedLiveSafety': 7, 'total': 190}
    assertion(nine_path, '/targetedTests', nine['targetedTests'])
    assertion(nine_path, '/finalLiveSafetyCounts', nine['finalLiveSafetyCounts'])
    qa = W / 'roadmark-104-qa/audi-sequential-checks'
    for step in nine['steps']:
        root = qa / step['id']
        terminal_path = root / 'terminal.json'
        terminal = load(terminal_path)
        assert terminal == step['terminal'] and terminal['exitCode'] == 0
        add_pin(pin(terminal_path))
        assertion(terminal_path, '', terminal)
        result_path = root / 'result.json'
        result_pin = pin(result_path)
        assert result_pin['sha256'] == step['resultSha256']
        add_pin(result_pin)
        assertion(result_path, '/passed', True)
        assertion(result_path, '/exitCode', 0)
        for stream in ('stdout', 'stderr'):
            path = root / (stream + '.log')
            add_pin({'path': str(path), 'bytes': path.stat().st_size, 'sha256': terminal[stream + 'Sha256']})
    parity_path = qa / 'normal-report-staged-parity.json'
    parity = load(parity_path)
    assert parity['byteEquality'] and parity['exactDeepEquality'] and parity['ignoredPaths'] == []
    assert {key: parity['actual'][key] for key in ('bytes', 'sha256')} == {key: parity['expected'][key] for key in ('bytes', 'sha256')}
    add_pin(pin(parity_path))
    refs(parity)
    for field in ('status', 'exactDeepEquality', 'byteEquality', 'ignoredPaths', 'allCatalogueVersions', 'tierOneVersions', 'onSaleVersions', 'wholeMarketC1'):
        assertion(parity_path, '/' + field, parity[field])
    v2_path = '/tmp/audi-review/full-project-typescript-v2-result-acceptance.json'
    v2 = load(v2_path)
    for field in ('exitCode', 'actualFreshCacheRootsVerified', 'originalConfigIncludesExcludesPreserved', 'originalLiveCacheUnchanged', 'priorTs2345AttemptRetained', 'claims'):
        assertion(v2_path, '/' + field, v2[field])
    for field in ('terminal', 'result', 'scopeVerification'):
        path = v2[field]['path']
        assert pin(path) == v2[field]
        assertion(path, '', load(path))
    focused_path = '/tmp/audi-review/fixture-type-correction-focused-results-acceptance.json'
    focused = load(focused_path)
    for field in ('testsPassed', 'testsFailedSkippedCancelledTodo', 'lintFiles', 'lintErrorsWarningsSuppressed', 'rootConditionalGateSatisfied'):
        assertion(focused_path, '/' + field, focused[field])
    for check in focused['checks']:
        path = check['terminal']['path']
        assert pin(path) == check['terminal']
        assertion(path, '/exitCode', 0)
    for version, exit_code in [('v1', 2), ('v2', 0)]:
        path = P('/tmp/audi-packet/full-project-typescript-' + version + '/run/terminal.json')
        assert load(path)['exitCode'] == exit_code
        add_pin(pin(path))
        assertion(path, '/exitCode', exit_code)
    for suffix, exit_code in [('selected-preflight-v2', 1), ('selected-preflight-v3', 0), ('full-stage-v1', 0)]:
        path = P('/tmp/audi-packet') / suffix / 'run/terminal.json'
        terminal = load(path)
        assert terminal['exitCode'] == exit_code
        add_pin(pin(path))
        assertion(path, '/exitCode', exit_code)
        for stream in ('stdout', 'stderr'):
            log_path = path.parent / (stream + '.log')
            add_pin({'path': str(log_path), 'bytes': log_path.stat().st_size, 'sha256': terminal[stream + 'Sha256']})
    image_path = '/tmp/audi-research/recovery-provenance-metadata.json'
    image = load(image_path)
    assert len(image['images']) == 5 and image['gtQ8Images']['standaloneRasterFiles'] == []
    refs(image)
    assertion(image_path, '/images', image['images'])
    assertion(image_path, '/gtQ8Images', image['gtQ8Images'])
    browser_path = '/tmp/audi-research/browser-pre-navigation-failure.json'
    add_pin(pin(browser_path))
    result = {'result': 'APPROVED_EXACT_CAPTURED_APPLICATION_ASSERTIONS', 'preparedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'generator': pin(P(__file__)), 'finalFreeze': pin(freeze_path), 'assertions': assertions, 'retainedPins': sorted(retained.values(), key=lambda row: row['path']), 'scope': 'Exact frozen reviewer/application records only; assertions execute against captured payloads during fresh independent replay', 'noProductExecution': True, 'noSourceOrResearchBodyHashSweep': True, 'noReleaseOrAggregateSuiteClaim': True}
    with (C / 'APPLICATION-ASSERTION-CONTRACT.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'result': result['result'], 'assertions': len(assertions), 'retainedPins': len(retained), 'pin': pin(C / 'APPLICATION-ASSERTION-CONTRACT.json')}))

if __name__ == '__main__':
    main()
