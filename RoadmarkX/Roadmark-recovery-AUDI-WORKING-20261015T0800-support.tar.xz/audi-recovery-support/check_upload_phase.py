import pathlib,json,os,sys,hashlib
C=pathlib.Path(__file__).resolve().parent;phase=sys.argv[1]
def load(p):return json.loads(p.read_text())
def pin(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(65536):h.update(b);n+=len(b)
 return {'bytes':n,'sha256':h.hexdigest()}
req=load(C/f'library-{phase}-request.json')['uploads'];results=load(C/f'library-{phase}-results.json')['results'];assert len(req)==len(results)
for a,b in zip(req,results):
 p=pathlib.Path(a['local_path']);assert b['status']=='succeeded' and b['local_metadata_applied'];assert b['local_path']==str(p) and b['file_name']==p.name;assert os.getxattr(p,'user.library-file-id').decode()==b['library_file_id'];assert os.getxattr(p,'user.library-file-version').decode()==str(b['current_version_number']);print(json.dumps({'filename':p.name,'library_file_id':b['library_file_id'],'version':b['current_version_number'],**pin(p),'verified':True}))
