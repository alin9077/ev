#!/usr/bin/env python3
"""One measured child, fixed address-space ceiling, durable invocation/terminal receipts."""
import os,sys,time,json,resource,signal,datetime,pathlib
P=pathlib.Path
LIMIT=256*1024*1024

def write_new(p,d):
 with p.open('x') as f: json.dump(d,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def main():
 receipt=P(sys.argv[1]);cmd=sys.argv[2:];assert cmd and not receipt.exists()
 invocation=receipt.with_name(receipt.stem+'.invocation.json');started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic();readfd,writefd=os.pipe();pid=os.fork()
 if pid==0:
  os.close(writefd);os.setsid();resource.setrlimit(resource.RLIMIT_AS,(LIMIT,LIMIT));os.environ.update(PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1');grant=os.read(readfd,1);os.close(readfd)
  if grant!=b'1':os._exit(125)
  os.execvp(cmd[0],cmd)
 os.close(readfd)
 try: write_new(invocation,{'startedAt':started,'command':cmd,'childPid':pid,'processGroup':pid,'addressSpaceLimitBytes':LIMIT,'wallLimitSeconds':600,'unknownPriorValidationProcessMayOverlap':False,'processSerializationEstablished':True,'serializationBasis':'Parent explicitly released the heavy slot; this is not global process enumeration'})
 except BaseException:
  os.kill(pid,signal.SIGKILL);os.close(writefd);os.waitpid(pid,0);raise
 os.write(writefd,b'1');os.close(writefd);timedout=False;term_at=None
 while True:
  done,status,r=os.wait4(pid,os.WNOHANG)
  if done:break
  elapsed=time.monotonic()-t
  if elapsed>600 and term_at is None:
   timedout=True;term_at=time.monotonic()
   try:os.killpg(pid,signal.SIGTERM)
   except ProcessLookupError:pass
  if term_at is not None and time.monotonic()-term_at>5:
   try:os.killpg(pid,signal.SIGKILL)
   except ProcessLookupError:pass
  time.sleep(.1)
 code=os.waitstatus_to_exitcode(status);write_new(receipt,{'startedAt':started,'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'exitCode':code,'timedOut':timedout,'wallSeconds':round(time.monotonic()-t,3),'maxRssKiB':r.ru_maxrss,'addressSpaceLimitBytes':LIMIT,'wallLimitSeconds':600,'childPid':pid,'unknownPriorValidationProcessMayOverlap':False,'metricMethod':'POSIX wait4, Linux KiB','missingTerminalMeansOutcomeUnknown':True});sys.exit(code if code>=0 else 128-code)
if __name__=='__main__':main()
