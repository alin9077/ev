#!/usr/bin/env python3
"""Independent fresh-only streaming replay; never restores or opens base archives."""
import datetime
import hashlib
import json
import lzma
import os
import pathlib
import resource
import stat
import sys
import tarfile
import time
import traceback

sys.dont_write_bytecode = True
P = pathlib.Path
C = P(__file__).resolve().parent
R = C.parents[1]
W = R.parent
BASE = C.parent / 'skoda-working-20261015T0520'
CHUNK = 65536
LIMIT = 268435456
LABEL = 'AUDI-WORKING-20261015T0800'
OUT = C / 'INDEPENDENT-AUDI-RECOVERY-VERIFICATION-v1.json'
REPLAY = C / 'INDEPENDENT-NEW-MEMBER-REPLAY-MANIFEST-v1.json'
START = time.monotonic()
RESULT = {'result': 'IN_PROGRESS'}

def ck(value, message):
    if not value:
        raise AssertionError(message)

def load(path):
    return json.loads(P(path).read_text())

def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()

def dump(path, value):
    with P(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())

def identity(path):
    path = P(path)
    row = path.lstat()
    ck(stat.S_ISREG(row.st_mode) and not any(p.is_symlink() for p in path.parents), 'unsafe regular file ' + str(path))
    return [row.st_size, row.st_mtime_ns, row.st_ctime_ns, row.st_ino, row.st_dev]

def pin(path):
    before = identity(path)
    digest = hashlib.sha256()
    count = 0
    with P(path).open('rb') as stream:
        while block := stream.read(CHUNK):
            digest.update(block)
            count += len(block)
    ck(before == identity(path) and count == before[0], 'changed during read ' + str(path))
    return {'bytes': count, 'sha256': digest.hexdigest()}

def check(path, expected):
    actual = pin(path)
    ck(all(actual[key] == expected[key] for key in ('bytes', 'sha256') if expected.get(key) is not None), 'pin differs ' + str(path))
    return actual

def core(row):
    return {key: row[key] for key in ('path', 'bytes', 'sha256')}

def original(row):
    return {'bytes': row['originalBytes'], 'sha256': row['originalSHA256']}

def safe(name):
    path = pathlib.PurePosixPath(name)
    ck(bool(name) and not path.is_absolute() and '..' not in path.parts and '\\' not in name and str(path) == name, 'unsafe member ' + name)

def rows_map(rows):
    result = {}
    for row in rows:
        safe(row['path'])
        ck(row['path'] not in result, 'duplicate member ' + row['path'])
        result[row['path']] = core(row)
    return result

def restore_path(path):
    path = P(path)
    if path.is_relative_to('/tmp'):
        name = path.relative_to('/tmp').as_posix()
    elif path.is_relative_to(W / 'roadmark-104'):
        name = 'roadmark/' + path.relative_to(W / 'roadmark-104').as_posix()
    elif path.is_relative_to(W / 'roadmark-104-qa'):
        name = path.relative_to(W).as_posix()
    else:
        raise AssertionError('unexpected original path ' + str(path))
    safe(name)
    return name

def terminal(path, command, limit=LIMIT):
    path = P(path)
    invocation = path.with_name(path.stem + '.invocation.json')
    actual, started = load(path), load(invocation)
    ck(actual['command'] == started['command'] == command, 'terminal command differs ' + path.name)
    ck(actual['exitCode'] == 0 and not actual['timedOut'], 'terminal failed ' + path.name)
    ck(actual['addressSpaceLimitBytes'] == started['addressSpaceLimitBytes'] == limit, 'terminal memory differs ' + path.name)
    ck(actual['wallLimitSeconds'] == started['wallLimitSeconds'] == 600 and actual['childPid'] == started['childPid'], 'terminal bounds differ ' + path.name)
    ck(actual['maxRssKiB'] > 0, 'missing RSS ' + path.name)
    return {'receipt': pin(path), 'invocation': pin(invocation), 'command': command, 'exitCode': 0, 'addressSpaceLimitBytes': limit, 'maxRssKiB': actual['maxRssKiB'], 'wallSeconds': actual['wallSeconds']}

def pointer(value, path):
    if path == '':
        return value
    ck(path.startswith('/'), 'invalid JSON pointer')
    for key in path.split('/')[1:]:
        key = key.replace('~1', '/').replace('~0', '~')
        value = value[int(key)] if isinstance(value, list) else value[key]
    return value

def seed_invocations():
    provenance = pin(C / 'SEED-PROVENANCE.json')
    terminals = []
    for path in sorted(C.glob('*.resources.json')):
        value = load(path)
        command = value.get('command', [])
        if any(P(part).name in ('privacy_v2.py', 'scan_documents_v2.py') for part in command):
            terminals.append((path, value))
    result = []
    for path in sorted((C / 'seed-read-invocations').glob('*.json')):
        value = load(path)
        ck(value['exactPinnedMembersReadAndVerified'] == 200 and value['historicalArchives'] == 21 and value['noExtractedValuesPersisted'], 'seed invocation count/scope differs')
        ck(value['memberIdentityListPin'] == provenance, 'seed invocation identity-list pin differs')
        when = datetime.datetime.fromisoformat(value['completedAt'])
        matches = [(p, row) for p, row in terminals if row['childPid'] == value['processId'] and datetime.datetime.fromisoformat(row['startedAt']) <= when <= datetime.datetime.fromisoformat(row['endedAt'])]
        ck(len(matches) == 1, 'seed invocation lacks one matching actual terminal')
        result.append({'receipt': path.name, **pin(path), 'record': value, 'terminal': matches[0][0].name, 'terminalPin': pin(matches[0][0])})
    for path, row in terminals:
        if row['exitCode'] == 0:
            ck(sum(item['terminal'] == path.name for item in result) == 1, 'successful scanner has missing/duplicate actual seed receipt')
    return result

def main():
    ck('--sole-child-slot-authorized' in sys.argv, 'sole heavy slot release required')
    ck(resource.getrlimit(resource.RLIMIT_AS) == (LIMIT, LIMIT), '256 MiB process ceiling absent')
    ck(not OUT.exists() and not REPLAY.exists(), 'result already exists; preserve prior attempts')
    review = load(C / 'INDEPENDENT-AUDI-COMMAND-PLAN-REVIEW-v1.json')
    ck(review['result'] == 'PASS_FINAL_ARCHIVE_COMMAND_AND_POINTER_PLAN', 'final static review absent')
    command_path = P(review['commandPlan']['path'])
    ck(command_path.parent == C, 'command plan outside checkpoint')
    check(command_path, review['commandPlan'])
    command_plan = load(command_path)
    scanner_path = P(review['privacyScanner']['path'])
    check(scanner_path, review['privacyScanner'])
    for row in command_plan['scriptPins']:
        check(row['path'], row)
    check(__file__, review['independentVerifier'])
    scope = load(C / 'FROZEN-CAPTURE-SCOPE.json')
    check(C / 'FROZEN-CAPTURE-SCOPE.json', review['frozenScope'])
    frozen_identities = load(C / 'INDEPENDENT-AUDI-FREEZE-IDENTITIES-v1.json')
    ck(frozen_identities['result'] == 'PASS_STATIC_FROZEN_IDENTITY_BINDING', 'independent freeze identities absent')
    check(C / 'INDEPENDENT-AUDI-FREEZE-IDENTITIES-v1.json', review['freezeIdentities'])
    ids = {row['path']: row['identity'] for row in frozen_identities['files']}
    frozen = {restore_path(row['path']): row for row in scope['files']}
    ck(len(frozen) == len(scope['files']) == len(ids), 'duplicate or incomplete frozen identity scope')
    source_capture = load(C / 'source-capture.json')
    proof_capture = load(C / 'proof-capture-v1.json')
    support = load(C / 'SUPPORT-MEMBER-INVENTORY.json')
    plan = load(C / 'RESTORE-PLAN.json')
    archives = load(C / 'ARCHIVE-PLAN.json')['archives']
    state = (C / 'WORKING-STATE.txt').read_text()
    names = ['FROZEN-CAPTURE-SCOPE.json', 'INDEPENDENT-AUDI-FREEZE-IDENTITIES-v1.json', 'source-capture.json', 'proof-capture-v1.json', 'source-package.json', 'proof-packages.json', 'SUPPORT-MEMBER-INVENTORY.json', 'support-package.json', 'RESTORE-PLAN.json', 'ARCHIVE-PLAN.json', 'FRESH-ONLY-RESTORE-MANIFEST.json', 'ALL-ARCHIVE-PRIVACY-GATE.json', 'COPY-SANITATION-MAPPING.json', 'PROSE-KEY-RENAME-APPROVALS.json', 'APPLICATION-ASSERTION-CONTRACT.json', 'INDEPENDENT-AUDI-SEED-METADATA-CONTRACT-v1.json', 'SYMLINK-RECONSTRUCTION.json']
    input_pins = {name: pin(C / name) for name in names}
    phases = {row['phase']: terminal(row['terminal'], row['command']) for row in command_plan['phaseCommands']}
    ck(len(phases) == len(command_plan['phaseCommands']), 'duplicate phase names')
    base_path = BASE / 'deliverables/Roadmark-RECOVERY-MANIFEST-SKODA-WORKING-20261015.json'
    check(base_path, {'bytes': 3749629, 'sha256': '744c41676bd8b8bbd4b97b78b06ffd3f94fb4e6d24bbb8d7580edc31b5cbc42c'})
    check(BASE / 'FINAL-SKODA-UPLOAD-RECEIPTS.json', {'bytes': 83915, 'sha256': 'e076b33ab248a3e84fc3435118624fae9c7918e48e70b3cbdd0576aae3dcf9ca'})
    base = load(base_path)
    old = rows_map(base['files'])
    old_source = {row['path']: row for row in load(BASE / 'source-capture.json')['files']}
    current = {row['path']: row for row in source_capture['files']}
    captured = {row['path']: row for row in proof_capture['files']}
    delta = {row['path']: row for row in proof_capture['changedFiles']}
    ck(len(current) == len(source_capture['files']) == scope['expectedSourceFiles'], 'full source count differs')
    ck(set(old_source) <= set(current), 'inherited source deletion')
    changed = {name for name, row in current.items() if name not in old_source or original(row) != original(old_source[name])}
    ck(changed == set(scope['sourceChangedPaths']), 'source changed-path allowlist differs')
    ck(source_capture['chunkBytes'] == proof_capture['chunkBytes'] == CHUNK and not source_capture['fullSourceTreeCloned'] and proof_capture['noBroadQaTraversal'], 'capture resource contract differs')
    ck(not source_capture['sourceChangesDuringCapture'] and not proof_capture['sourceChangesDuringCapture'], 'capture stability failed')
    ck(source_capture['state'] == proof_capture['state'] == state == scope['workingResult'] + '\n', 'working state differs')
    reused_source = []
    for name, row in current.items():
        safe(name)
        ck(row['originalPath'] == str(W / 'roadmark-104' / name), 'source locator differs')
        if name in changed:
            expected = frozen['roadmark/' + name]
            ck(original(row)['bytes'] == expected['bytes'], 'changed source size differs')
            if expected.get('sha256') or expected.get('knownSha256'):
                ck(original(row)['sha256'] == (expected.get('sha256') or expected['knownSha256']), 'changed source frozen hash differs')
            ck(original(row) == {key: row[key] for key in ('bytes', 'sha256')}, 'unapproved new source transformation')
        else:
            prior = old_source[name]
            ck(all(row.get(key, []) == prior.get(key, []) for key in ('bytes', 'sha256', 'originalBytes', 'originalSHA256', 'redactedHeaderPaths', 'redactedPointers', 'redactedHTMLRanges')), 'source sanitation lineage differs ' + name)
            ck(row['payloadPath'] == prior['payloadPath'] and row['captureMethod'] == 'exact-original-and-prior-sanitized-hashes', 'source payload reuse differs')
            reused_source.append(name)
    ck(len(captured) == len(proof_capture['files']) == len(frozen) and proof_capture['scope'] == scope and len(delta) == len(proof_capture['changedFiles']), 'proof scope differs')
    covered, reused, renamed = [], [], []
    approvals = load(C / 'PROSE-KEY-RENAME-APPROVALS.json')
    approval_rows = approvals['files']
    for name, expected in frozen.items():
        row = captured[name]
        ck(row['originalPath'] == expected['path'] and row['sourceIdentity'] == ids[expected['path']], 'captured frozen identity differs ' + name)
        ck(original(row)['bytes'] == expected['bytes'], 'frozen original size differs')
        if expected.get('sha256') or expected.get('knownSha256'):
            ck(original(row)['sha256'] == (expected.get('sha256') or expected['knownSha256']), 'frozen original hash differs ' + name)
        if name.startswith('roadmark/'):
            source_row = current[name[9:]]
            ck(core(row) == {'path': name, 'bytes': source_row['bytes'], 'sha256': source_row['sha256']} and original(row) == original(source_row) and row['captureMethod'] == 'covered-by-full-source' and name not in delta, 'source-covered proof differs')
            covered.append(name)
        elif name in delta:
            ck(row == delta[name] and row['archiveAction'] == 'new-delta-member', 'new delta membership differs')
            if row.get('metadataKeyRename'):
                matches = [entry for entry in approval_rows if entry.get('restorePath', entry.get('path')) == name]
                ck(len(matches) == 1, 'unapproved key rename ' + name)
                check(row['payloadPath'], row)
                copied = P(row['payloadPath']).read_bytes()
                ck(copied.count(b'"approvalScope":') == 1 and b'"authorization":' not in copied, 'copied key shape differs')
                raw = copied.replace(b'"approvalScope":', b'"authorization":', 1)
                ck({'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()} == original(row), 'inverse rename does not reconstruct frozen bytes')
                before, after = json.loads(raw), json.loads(copied)
                value = before.pop('authorization')
                ck(after.pop('approvalScope') == value and before == after, 'rename changed value or non-key fields')
                ck(not row.get('redactedPointers') and not row.get('redactedHTMLRanges'), 'additional unapproved sanitation')
                renamed.append(name)
            else:
                ck({key: row[key] for key in ('bytes', 'sha256')} == original(row) and not row.get('redactedPointers') and not row.get('redactedHTMLRanges'), 'unapproved proof transformation ' + name)
        else:
            ck(core(row) == old[name] and row['archiveAction'] == 'reuse-exact-base-member', 'inherited proof pin differs')
            reused.append(name)
    ck(len(renamed) == len(approval_rows), 'approval rename coverage differs')
    source_package = load(C / 'source-package.json')
    proof_packages = load(C / 'proof-packages.json')['archives']
    support_package = load(C / 'support-package.json')
    package_rows = [source_package] + proof_packages + [support_package]
    ck(archives == plan['newArchives'] and [{key: value for key, value in row.items() if key != 'restoreOrder'} for row in archives] == package_rows, 'unified fresh archive order differs')
    source_metadata = {'schemaVersion': 1, 'root': 'roadmark', 'files': [core(row) for row in source_capture['files']]}
    generated = {'roadmark/SOURCE-FILE-MANIFEST.json': encoded(source_metadata), 'recovery-metadata/' + LABEL + '-support.json': encoded(support)}
    groups, group, group_bytes = [], [], 0
    for row in proof_capture['changedFiles']:
        if group and group_bytes + row['bytes'] > 24000000:
            groups.append(group)
            group, group_bytes = [], 0
        group.append(row)
        group_bytes += row['bytes']
    if group:
        groups.append(group)
    ck(len(groups) == len(proof_packages), 'proof archive grouping differs')
    for index, (group, archive) in enumerate(zip(groups, proof_packages), 1):
        name = f'recovery-metadata/{LABEL}-part{index:02d}.json'
        meta = {'schemaVersion': 1, 'label': LABEL, 'part': index, 'parts': len(groups), 'state': proof_capture['state'], 'files': [{key: row[key] for key in ('path', 'bytes', 'sha256', 'originalBytes', 'originalSHA256')} for row in group], 'restore': 'Overlay after the exact 119-archive Škoda chain, replacing its source archive with this full registered Audi working source. Original raw-capture expected hashes and sanitation mapping remain unchanged.'}
        generated[name] = encoded(meta)
        wanted_group = rows_map(group)
        wanted_group[name] = {'path': name, 'bytes': len(generated[name]), 'sha256': hashlib.sha256(generated[name]).hexdigest()}
        if index == 1:
            name = 'audi-safety-support/COPY-SANITATION-MAPPING.json'
            generated[name] = (C / 'COPY-SANITATION-MAPPING.json').read_bytes()
            wanted_group[name] = {'path': name, 'bytes': len(generated[name]), 'sha256': hashlib.sha256(generated[name]).hexdigest()}
        ck(rows_map(archive['memberFiles']) == wanted_group, 'proof member/metadata union differs')
        ck(archive['filename'] == f'Roadmark-recovery-{LABEL}-part{index:02d}of{len(groups):02d}.tar.xz', 'proof archive name differs')
    source_members = {'roadmark/' + name: {'path': 'roadmark/' + name, 'bytes': row['bytes'], 'sha256': row['sha256']} for name, row in current.items()}
    source_members['roadmark/SOURCE-FILE-MANIFEST.json'] = {'path': 'roadmark/SOURCE-FILE-MANIFEST.json', 'bytes': len(generated['roadmark/SOURCE-FILE-MANIFEST.json']), 'sha256': hashlib.sha256(generated['roadmark/SOURCE-FILE-MANIFEST.json']).hexdigest()}
    ck(rows_map(source_package['memberFiles']) == source_members and source_package['bytes'] < 15000000, 'full source membership or strict size limit differs')
    support_members = rows_map(support['files'])
    for row in support['files']:
        check(row['payloadPath'], row)
    scripts = [row for row in support['files'] if P(row['payloadPath']).suffix == '.py']
    ck(len({(row['bytes'], row['sha256']) for row in scripts}) == len(scripts), 'duplicate executable bytes in support instead of one exact retained copy')
    retained_paths = {str(P(row['payloadPath'])) for row in support['files']}
    for row in command_plan['scriptPins']:
        if P(row['path']).parent == C:
            ck(row['path'] in retained_paths, 'current unique script missing from support')
    support_meta = 'recovery-metadata/' + LABEL + '-support.json'
    support_members[support_meta] = {'path': support_meta, 'bytes': len(generated[support_meta]), 'sha256': hashlib.sha256(generated[support_meta]).hexdigest()}
    ck(rows_map(support_package['memberFiles']) == support_members, 'support membership differs')
    ck(any(P(row['payloadPath']) == P(__file__) for row in support['files']), 'independent verifier missing from support')
    seed_contract = load(C / 'INDEPENDENT-AUDI-SEED-METADATA-CONTRACT-v1.json')
    ck(seed_contract['result'] == 'PASS_STATIC_EXACT_SEED_METADATA_CONTRACT' and seed_contract['originalSeedReadBlockerResolved'], 'seed exception contract absent')
    check(C / 'SEED-PROVENANCE.json', seed_contract['provenancePin'])
    expected_counts = {key: value for key, value in load(BASE / 'scan-01.json').items() if key.endswith(('Values', 'Forms')) or key == 'originalSeedMembers'}
    prior_cache = load(BASE / 'scan-01.json')['patternCacheProvenance']
    cache_source = {row['path']: row for row in load(C.parent / 'xpeng-registered-working-20261014T2030/source-capture.json')['files']}
    fresh, verified_archives, scan_rows = {}, [], []
    for index, archive in enumerate(archives, 1):
        path = P(archive['file'])
        ck(path.parent == R and path.name == archive['filename'], 'fresh archive locator differs')
        check(path, archive)
        wanted = rows_map(archive['memberFiles'])
        actual = {}
        with lzma.open(path, 'rb') as stream:
            with tarfile.open(fileobj=stream, mode='r|') as tar:
                for member in tar:
                    safe(member.name)
                    ck(member.isfile() and member.name in wanted and member.name not in actual and member.name not in fresh, 'unsafe/unexpected/duplicate member ' + member.name)
                    digest, count = hashlib.sha256(), 0
                    parts = [] if member.name in generated else None
                    with tar.extractfile(member) as payload:
                        while block := payload.read(CHUNK):
                            digest.update(block)
                            count += len(block)
                            if parts is not None:
                                parts.append(block)
                    row = {'path': member.name, 'bytes': count, 'sha256': digest.hexdigest()}
                    ck(row == wanted[member.name] and count == member.size, 'fresh member hash differs ' + member.name)
                    actual[member.name] = row
                    fresh[member.name] = row
                    if parts is not None:
                        ck(b''.join(parts) == generated[member.name], 'generated metadata bytes differ')
            while stream.read(CHUNK):
                pass
        ck(actual == wanted and list(actual) == list(wanted) and len(actual) == archive['members'], 'member order/coverage differs')
        check(path, archive)
        scan_name = f'scan-{index:02d}'
        report_path = C / (scan_name + '.json')
        report = load(report_path)
        scan_terminal = terminal(C / (scan_name + '.resources.json'), ['python3', str(scanner_path), str(path), str(report_path)])
        ck(report['status'] == 'clean' and report['archivePin'] == {key: archive[key] for key in ('bytes', 'sha256')} and rows_map(report['members']) == actual, 'privacy coverage differs')
        ck(report['regularFilesScanned'] == len(actual) and report['bytesScanned'] == sum(row['bytes'] for row in actual.values()) and report['currentByteSearchForEveryMember'] and report['chunkBytes'] == CHUNK, 'privacy totals differ')
        ck(all(not report[key] for key in ('exactValueMatches', 'primaryHeaderCandidates', 'unclassifiedRuntimeCandidates', 'errors')), 'unresolved privacy findings')
        ck(all(report[key] == value for key, value in expected_counts.items()), 'known-value counts differ')
        ck(report['patternCacheProvenance'] == prior_cache and report['originalSeedMembers'] == seed_contract['seedMemberCount'], 'scanner cache or seed coverage differs')
        for row in report['members']:
            name = row['path']
            eligible = name.startswith('roadmark/') and name != 'roadmark/SOURCE-FILE-MANIFEST.json' and name[9:] in cache_source and core(row) == {'path': name, 'bytes': cache_source[name[9:]]['bytes'], 'sha256': cache_source[name[9:]]['sha256']}
            ck((row['patternVerdict'] == 'exact-prior-source-cache') == eligible, 'pattern cache eligibility differs')
            ck(eligible or row['patternVerdict'] == 'current-full-unchanged-scanner', 'unknown pattern verdict')
            ck(row['exactMatchesObserved'] == row['classifiedPublicLexicalCollisions'] + row['unresolvedExactMatches'] and row['unresolvedExactMatches'] == 0, 'exact-match accounting differs')
        ck(sum(row['classifiedPublicLexicalCollisions'] for row in report['members']) == report['classifiedPublicLexicalCollisions'], 'collision sum differs')
        scan_rows.append({'archive': path.name, 'report': pin(report_path), 'terminal': scan_terminal, 'members': len(actual), 'bytes': sum(row['bytes'] for row in actual.values()), 'classifiedPublicLexicalCollisions': report['classifiedPublicLexicalCollisions'], 'targetedHistoricalSeedMembersRead': report['originalSeedMembers'], 'targetedHistoricalSeedArchives': seed_contract['seedArchiveCount'], 'inheritedArchiveOverlap': seed_contract['inheritedArchiveOverlapCount']})
        verified_archives.append({'filename': path.name, **pin(path), 'members': len(actual), 'uncompressedBytes': sum(row['bytes'] for row in actual.values())})
        print(json.dumps({'stage': 'fresh-only-independent-replay', 'archive': index, 'members': len(actual), 'result': 'PASS'}), flush=True)
    ck(fresh == rows_map(plan['newFiles']) and len(fresh) == plan['freshFiles'] and sum(row['bytes'] for row in fresh.values()) == plan['freshBytes'], 'fresh union differs')
    merged = {name: row for name, row in old.items() if not name.startswith('roadmark/')}
    merged.update(fresh)
    ck(merged == rows_map(plan['files']) and len(merged) == plan['logicalFiles'] and sum(row['bytes'] for row in merged.values()) == plan['logicalBytes'], 'logical overlay differs')
    ck((set(old) & set(fresh)) - {name for name in old if name.startswith('roadmark/')} == set(scope['expectedNonSourceOverlay']), 'unexpected non-source overlay')
    expected_archives = [dict(source_package) if row['group'].startswith('source-') else {**row, 'new': False} for row in base['archivesInRestoreOrder']] + proof_packages + [support_package]
    for index, row in enumerate(expected_archives, 1):
        row['restoreOrder'] = index
    ck(sum(row['group'].startswith('source-') for row in base['archivesInRestoreOrder']) == 1, 'base source archive count differs')
    ck(expected_archives == plan['archivesInRestoreOrder'] and plan['baseArchivesReused'] == len(base['archivesInRestoreOrder']) - 1 and plan['archiveCount'] == len(expected_archives), 'inherited archive identity/order differs')
    ck(load(C / 'FRESH-ONLY-RESTORE-MANIFEST.json') == {'archivesInRestoreOrder': archives, 'files': list(fresh.values())}, 'fresh-only restore manifest differs')
    for row in proof_capture['files']:
        ck(merged[row['path']] == core(row), 'selected proof missing from final overlay')
    inherited_sanitized = []
    def inherited_mappings(value):
        if isinstance(value, dict):
            if 'sanitizedBytes' in value and 'sanitizedSHA256' in value and ('restorePath' in value or 'path' in value):
                name = value.get('restorePath') or value['path']
                ck(merged[name] == old[name] == {'path': name, 'bytes': value['sanitizedBytes'], 'sha256': value['sanitizedSHA256']}, 'inherited sanitation pin differs')
                inherited_sanitized.append(name)
            for child in value.values():
                inherited_mappings(child)
        elif isinstance(value, list):
            for child in value:
                inherited_mappings(child)
    for name in ('sourceSanitation', 'copyOnlySanitation', 'inheritedCopyOnlySanitation', 'originalRawCaptureReplayCompatibility'):
        inherited_mappings(base[name])
    for row in base['copyOnlySanitation'].get('files', []):
        if row.get('metadataKeyRename'):
            ck(merged[row['path']] == old[row['path']] == core(row), 'inherited prose-key copy changed')
    inherited_dependencies = base['inheritedDependencyReconstruction']['dependencies']
    for dependency in inherited_dependencies:
        for item in dependency['pins']:
            member = item['member']
            ck(merged[member['path']] == old[member['path']] == core(member), 'inherited dependency member changed')
            ck(member['sha256'] == item['expected']['sha256'] and (item['expected'].get('bytes') is None or member['bytes'] == item['expected']['bytes']), 'inherited original dependency expectation differs')
    links = load(C / 'SYMLINK-RECONSTRUCTION.json')
    ck(links['result'] == 'EXACT_METADATA_AND_MEMBER_MAPPING' and links['noTraversalOrDependencyCapture'] and len(links['links']) == len(scope['metadataOnlySymlinks']) == 7, 'link reconstruction scope differs')
    for row, expected in zip(links['links'], scope['metadataOnlySymlinks']):
        ck(all(row[key] == value for key, value in expected.items()), 'original link metadata differs')
        ck(row['restoreLinkPath'] == restore_path(row['path']), 'restore link location differs')
        if row.get('dependencyTreeExcluded'):
            ck(row['retainedMembers'] == [] and expected['resolvedTarget'] == str(W / 'roadmark-104/node_modules'), 'dependency link mapping differs')
        else:
            target = restore_path(expected['resolvedTarget'])
            ck(row['restoreTargetPath'] == target and row['retainedMembers'], 'link target mapping absent')
            for member in row['retainedMembers']:
                ck(member['path'] == target or member['path'].startswith(target + '/'), 'link member outside target')
                ck(merged[member['path']] == core(member), 'link target member hash differs')
    ck(sum(bool(row.get('dependencyTreeExcluded')) for row in links['links']) == 2, 'dependency link count differs')
    application = load(C / 'APPLICATION-ASSERTION-CONTRACT.json')
    ck(application['result'] == 'APPROVED_EXACT_CAPTURED_APPLICATION_ASSERTIONS', 'application assertion contract absent')
    checked_assertions = []
    for assertion in application['assertions']:
        name = assertion['restorePath']
        row = captured[name]
        check(row['payloadPath'], row)
        actual = pointer(load(row['payloadPath']), assertion['pointer'])
        ck(actual == assertion['expected'], 'application assertion differs ' + name + assertion['pointer'])
        checked_assertions.append({'restorePath': name, 'pointer': assertion['pointer'], 'passed': True})
    original_pin_transformations = []
    for expected in application['retainedPins']:
        if merged[expected['path']] != core(expected):
            row = captured[expected['path']]
            ck(expected['path'] in renamed and original(row) == {key: expected[key] for key in ('bytes', 'sha256')} and merged[expected['path']] == core(row), 'mandatory original application pin lacks exact approved copy mapping')
            original_pin_transformations.append(expected['path'])
    gate = load(C / 'ALL-ARCHIVE-PRIVACY-GATE.json')
    ck(gate['result'] == 'PASS' and gate['freshMembers'] == len(fresh) and gate['freshBytes'] == sum(row['bytes'] for row in fresh.values()) and len(gate['archives']) == len(archives), 'aggregate privacy union differs')
    ck(gate['classifiedPublicLexicalCollisions'] == sum(row['classifiedPublicLexicalCollisions'] for row in scan_rows) and gate['unclassifiedFindings'] == gate['errors'] == 0, 'aggregate privacy findings differ')
    for row, expected in zip(gate['archives'], scan_rows):
        ck(row['archive'] == expected['archive'] and row['reportPin'] == expected['report'] and row['members'] == expected['members'] and row['bytes'] == expected['bytes'], 'aggregate privacy report binding differs')
    actual_seed_reads = seed_invocations()
    ck(len(actual_seed_reads) == len(archives), 'unexpected seed invocation count before document stage')
    RESULT['targetedHistoricalSeedExecutions'] = {'completedInvocations': len(actual_seed_reads), 'targetedPinnedMemberReads': 200 * len(actual_seed_reads), 'uniquePinnedMembers': 200, 'uniqueHistoricalArchives': 21, 'receipts': actual_seed_reads, 'separateFromFreshMemberReplay': True}
    for name, expected in input_pins.items():
        check(C / name, expected)
    for row in command_plan['scriptPins']:
        check(row['path'], row)
    live = []
    seen = set()
    for row in source_capture['files'] + proof_capture['files']:
        if row['originalPath'] in seen:
            continue
        seen.add(row['originalPath'])
        try:
            current_identity = identity(row['originalPath'])
        except (FileNotFoundError, AssertionError):
            current_identity = None
        if current_identity != row['sourceIdentity']:
            live.append({'path': row['originalPath'], 'capturedIdentity': row['sourceIdentity'], 'currentIdentity': current_identity, 'classification': 'Later live-path identity differs from the immutable verified captured cut'})
    dump(REPLAY, {'result': 'PASS', 'method': 'Fresh source/proof/support only; non-materializing 64 KiB streaming SHA256/member-order verification to XZ EOF', 'archives': verified_archives, 'files': list(fresh.values()), 'fileCount': len(fresh), 'bytes': sum(row['bytes'] for row in fresh.values()), 'noExtractedTree': True})
    RESULT.update(result='PASS', verificationScope='All fresh source/proof/support members streamed and exact logical overlay verified. No inherited archive replay or restore clone; scanner targeted historical seed reads are separately accounted.', source={'files': len(current), 'changedPaths': sorted(changed), 'exactPriorReuse': len(reused_source), 'captureCutoff': source_capture['captureCutoff'], 'strictCompressedUnder15000000': True}, proof={'selectedOriginalFiles': len(captured), 'sourceCovered': len(covered), 'reusedBaseMembers': len(reused), 'newDeltaFiles': len(delta), 'exactProseKeyRenames': renamed, 'captureCutoff': proof_capture['captureCutoff']}, support={'inventory': pin(C / 'SUPPORT-MEMBER-INVENTORY.json'), 'archive': verified_archives[-1], 'uniquePinnedMembers': len(support['files']), 'noRecursiveExecutableText': True}, newArchives=verified_archives, phaseTerminals=phases, privacy={'result': 'PASS', 'reports': scan_rows, 'seedCounts': expected_counts, 'targetedSeedReadContract': pin(C / 'INDEPENDENT-AUDI-SEED-METADATA-CONTRACT-v1.json'), 'knownValuesPersistedOrPrinted': False, 'blockingOrUnclassifiedFindings': 0, 'limitations': ['No decryption', 'No recursive arbitrary embedded format decoding', 'Standalone base64 does not cover arbitrary wrapping/alignment', 'No universal secret-free claim']}, replay={'manifest': pin(REPLAY), 'noDiskExtractedTree': True}, overlay={'baseArchiveCount': len(base['archivesInRestoreOrder']), 'unchangedBaseArchivesReused': len(base['archivesInRestoreOrder']) - 1, 'combinedArchiveCount': len(expected_archives), 'combinedLogicalFiles': len(merged), 'combinedLogicalBytes': sum(row['bytes'] for row in merged.values()), 'freshFiles': len(fresh), 'freshBytes': sum(row['bytes'] for row in fresh.values()), 'inheritedPayloadReadsByIndependentVerifier': 0}, inheritedSanitation={'exactPreservedMembers': len(set(inherited_sanitized)), 'allOriginalAndSanitizedPinsUnchanged': True}, application={'contract': pin(C / 'APPLICATION-ASSERTION-CONTRACT.json'), 'assertions': checked_assertions, 'mandatoryRetainedPins': len(application['retainedPins']), 'workingState': state, 'openGates': scope['openGates']}, postCaptureLiveChanges=live, inputPins=input_pins, verifierScript=pin(__file__), noUploadsOrDeletion=True)

if __name__ == '__main__':
    code = 0
    try:
        main()
    except BaseException as error:
        code = 1
        RESULT.update(result='BLOCKED', blocker={'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()})
    RESULT['completedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    RESULT['resources'] = {'wallSeconds': round(time.monotonic() - START, 3), 'maxRssKiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss, 'addressSpaceLimitBytes': resource.getrlimit(resource.RLIMIT_AS)[0], 'chunkBytes': CHUNK, 'noRestoreClone': True}
    dump(OUT, RESULT)
    print(json.dumps({'result': RESULT['result'], 'resources': RESULT['resources'], 'blocker': RESULT.get('blocker')}), flush=True)
    sys.exit(code)
