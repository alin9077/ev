#!/usr/bin/env python3
"""Static first-phase review and lstat-only frozen identities; no production imports."""
import ast
import datetime
import hashlib
import json
import pathlib
import stat

P = pathlib.Path
C = P(__file__).resolve().parent

def load(path):
    return json.loads(path.read_text())

def identity(path):
    row = path.lstat()
    assert stat.S_ISREG(row.st_mode) and not any(p.is_symlink() for p in path.parents)
    return [row.st_size, row.st_mtime_ns, row.st_ctime_ns, row.st_ino, row.st_dev]

def pin(path):
    before = identity(path)
    payload = path.read_bytes()
    assert identity(path) == before and len(payload) == before[0]
    return {'path': str(path), 'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()}

def dump(name, value):
    with (C / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def main():
    retention = P('/tmp/audi-handoff/final-freeze.json')
    assert {k: v for k, v in pin(retention).items() if k != 'path'} == {'bytes': 10416, 'sha256': 'dab81635acb02717540474f19b8006b13414aab126b9162eb6307bf816a41d66'}
    freeze = load(retention)
    inventory = P(freeze['retentionInventory']['path'])
    assert pin(inventory) == freeze['retentionInventory']
    rows = load(inventory)
    assert len(rows['regularFiles']) == rows['regularFileCount'] == 858
    assert sum(row['bytes'] for row in rows['regularFiles']) == rows['regularFileBytes'] == 81285268
    assert len(rows['symlinks']) == 7 and not rows['otherEntries']
    selected = {}
    for row in rows['regularFiles']:
        path = P(row['path'])
        ident = identity(path)
        assert ident[0] == row['bytes'] and ident[1] == row['mtimeNs']
        selected[str(path)] = {'path': str(path), 'identity': ident}
    for row in freeze['sourceAndStatusFiles'] + freeze['reviewerReceipts'] + freeze['researchProvenance'] + freeze['handoffArtifacts']:
        path = P(row['path'])
        ident = identity(path)
        assert ident[0] == row['bytes']
        if str(path) in selected:
            assert ident == selected[str(path)]['identity']
        selected[str(path)] = {'path': str(path), 'identity': ident}
    for path in (retention, inventory):
        assert str(path) not in selected
        selected[str(path)] = {'path': str(path), 'identity': identity(path)}
    for row in rows['symlinks']:
        assert P(row['path']).is_symlink() and str(P(row['path']).readlink()) == row['target']
    scripts = ['freeze_scope_v1.py', 'capture_v2.py', 'run_bounded_v1.py', 'finish_capture_metadata_v1.py']
    pins = []
    for name in scripts:
        path = C / name
        ast.parse(path.read_text())
        pins.append(pin(path))
    assert load(C / 'PROSE-KEY-RENAME-APPROVALS.json')['files'] == []
    identities = {'result': 'PASS_STATIC_FROZEN_IDENTITY_BINDING', 'checkedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'retention': pin(retention), 'inventory': pin(inventory), 'files': sorted(selected.values(), key=lambda row: row['path']), 'identityFields': ['size', 'mtimeNs', 'ctimeNs', 'inode', 'device'], 'sourceAndEvidencePayloadsRead': False, 'noAtimeAssertion': True, 'noSymlinkTraversal': True}
    dump('INDEPENDENT-AUDI-FREEZE-IDENTITIES-v1.json', identities)
    report = {'result': 'PASS_STATIC_FREEZE_AND_SOURCE_CAPTURE_ONLY', 'checkedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'reviewedScripts': pins, 'reviewerScript': pin(P(__file__)), 'frozenIdentities': pin(C / 'INDEPENDENT-AUDI-FREEZE-IDENTITIES-v1.json'), 'retention': pin(retention), 'inventory': pin(inventory), 'emptySourceProseApproval': pin(C / 'PROSE-KEY-RENAME-APPROVALS.json'), 'selectedOriginalFiles': len(selected), 'approvedAfterSoleSlotRelease': [['python3', str(C / 'freeze_scope_v1.py')], ['python3', str(C / 'capture_v2.py'), 'source']], 'candidateInventoryStatus': 'Original v1 requires exclusive receipt creation and frozen identity/hash/mtime checking before approval', 'proofCaptureStatus': 'Not approved by this receipt; exact candidate classification required first', 'checks': {'explicitFreezeAndInventoryPins': True, 'boundedExactRootsOnly': True, 'sevenLinksMetadataOnly': True, 'allSixteenSourceDeltaPathsAndQaStatus': True, 'productionIdentityTupleExcludesAtime': True, 'inheritedOriginalAndSanitizedSourceReuse': True, 'newSensitiveClassFailsClosed': True, 'sourceCaptureEnumeratesBeforeAndAfter': True, 'sourceCaptureChecksEveryFinalIdentity': True, 'noNewHeaderRedactionOrBroadExemption': True}, 'bounds': {'addressSpaceBytes': 268435456, 'chunkBytes': 65536, 'singleHeavyChild': True, 'wallSeconds': 600}, 'noProductionExecutionByThisReview': True, 'noPayloadScanArchiveReadTestCaptureOrUpload': True}
    dump('INDEPENDENT-AUDI-CAPTURE-FOUNDATION-REVIEW-v1.json', report)
    print(json.dumps({'result': report['result'], 'files': len(selected), 'report': pin(C / 'INDEPENDENT-AUDI-CAPTURE-FOUNDATION-REVIEW-v1.json')}))

if __name__ == '__main__':
    main()
