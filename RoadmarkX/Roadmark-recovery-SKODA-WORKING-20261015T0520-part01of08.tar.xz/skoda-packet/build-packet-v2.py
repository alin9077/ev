from pathlib import Path
import json,hashlib,copy
R=Path('/tmp/skoda-research');O=Path('/tmp/skoda-packet/v2');ID='m1-skoda-2026-10-15';DATE='2026-10-15';REVIEWER='Roadmark Škoda M1 proposal pending independent review'
N=json.load(open(R/'normalized-review-v3.json'));I=json.load(open(R/'source-index-review-v2.json'))['sources'];B={v['id']:v for v in json.load(open(R/'retained-before-cars.json'))};C=json.load(open(R/'census-review-v2.json'))
assert hashlib.sha256((R/'normalized-review-v3.json').read_bytes()).hexdigest()=='eecae751b1f46dafef99ad4ae40350776167bcd91ef0615ede8f0c221d7bb428'
P=dict(schemaVersion=1,id=ID,brand='Škoda',reviewedAt=DATE,reviewedBy=REVIEWER,sources=[],models=[],variants=[],versionGuards=[],versionUpdates=[],facts=[],features=[],configurationUpdates=[],brandTerms=[],availability=[],summaries=[])
sourcekeys=set(C['censusSourceKeys'])
for v in N['variants']:
 for f in [*v['coreFacts'].values(),*v['extraFacts'].values()]:sourcekeys.update(f['sourceKeys'])
 sourcekeys.update(v['availability']['sourceKeys'])
def sid(key):return ID+'-'+key
for key in sorted(sourcekeys):
 s=I[key];url=s['url'];maker='skoda.com.au' in url
 publisher='Škoda Australia' if maker else 'CarExpert' if 'carexpert' in url else 'CarsGuide' if 'carsguide' in url else 'Essendon Škoda' if 'essendonskoda' in url else 'Kevin Dennis Škoda' if 'kdskoda' in url else 'Alto Škoda'
 title={'au-elroq-my27':'Australian Elroq MY27 specification, July 2026 production scope','au-elroq-my26-full':'Australian Elroq MY26 specification, January 2026 production scope','au-enyaq-my26':'Australian Enyaq MY26 specification, January 2026 production scope','enyaq_my27_specs':'Australian Enyaq MY27 specification, July 2026 production scope','au-warranty':'Škoda Australia current new-vehicle warranty','au-ev-warranty':'Škoda Australia BEV battery warranty benefits','au-warranty-pdf':'Škoda Australia warranty terms and BEV capacity-remedy table','au-elroq-sportline':'Elroq Sportline85 Australian future order-opening page','au_faq':'Škoda Australia FAQ: exact Enyaq grades, seating and future EV limits'}.get(key,key.replace('-',' ').replace('_',' ').title())
 raw=Path(s['rawPath']);captures=[dict(locator=str(raw.relative_to('/tmp')),sha256=s['rawSha256'],bytes=s['rawBytes'],purpose='Retained public source body')]
 if s.get('textPath'):
  tp=Path(s['textPath']);captures.append(dict(locator=str(tp.relative_to('/tmp')),sha256=s['textSha256'],bytes=tp.stat().st_size,purpose='Extracted source text'))
 P['sources'].append(dict(id=sid(key),url=url,title=title,publisher=publisher,source_type='manufacturer_au_publication' if maker else 'dealer_advertisement' if key.startswith('dealer-') else 'secondary_australian_motoring_publication',published_date=None,accessed_date=DATE,market='AU',supports=title,retrievalMethod='Fresh read-only public body capture; exact PDF technical tables and warranty pages visually checked as recorded in research dossier',capture_locator=captures[0]['locator'],capture_sha256=s['rawSha256'],retainedCaptures=captures))
S={s['id']:s for s in P['sources']}
labels=dict(price_aud='Listed price',range_km='Claimed WLTP range',battery_kwh='Usable battery capacity',dc_peak_kw='Peak vehicle DC acceptance',dc_charge_time_min='Published DC charging duration',ac_kw='On-board AC maximum',seats='Seats',boot_l='Published rear storage',zero_to_100_s='0–100 km/h',power_kw='Motor power',drive='Drive type',length_mm='Length',width_mm='Width',height_mm='Height',towing_braked_kg='Braked towing',warranty='Vehicle warranty',battery_warranty='Battery warranty',battery_gross_kwh='Gross battery capacity',source_brochure_price_aud='MY27 brochure driveaway-from price',source_web_dc_peak_kw='RS webpage DC maximum',source_web_dc_10_80_min='RS webpage DC 10–80% duration')
def makefact(n,v,shared=False):
 k=n['key'];ids=[sid(x) for x in n['sourceKeys']];g=n['buyerGrade']
 reason={'confirmed':'Exact Australian manufacturer source supports the stated labelled value and version or applicable body-wide scope. ','check':'Australian manufacturer source supports the labelled value with the specific offer condition, towing requirement or unresolved source conflict. ','reported':'Exact Australian secondary observation remains labelled and unranked. ','not_published':'Two distinct source checks did not establish the exact requested value. '}[g]+n['locator']
 if shared:reason='Current Australian maker warranty terms apply to the named new Australian BEV versions. Commercial-use limits, demonstrator balance, capacity trigger and remedy levels are kept explicit.'
 if k=='width_mm':reason='Exact maker-labelled width is confirmed; mirror inclusion is unstated, so no mirror basis is inferred and comparison basis remains blank.'
 f=dict(key=k,label=labels[k],value=n['value'],unit=n['unit'],basis=n['basis'],comparisonBasis=n['comparisonBasis'],status=n['status'],sourceIds=ids,date=DATE,market='AU',scope='Škoda Australia current new-vehicle / BEV high-voltage battery warranty terms' if shared else v['scope'],qualifications=[n['locator'],*n['qualifications']],issues=[],buyerGrade=g,gradeReview=dict(reviewedAt=DATE,overlayId=ID,reason=reason,evidenceScope='brand_au_terms' if shared else n['evidenceScope'],sourceIds=ids,sourceLabel=' / '.join(dict.fromkeys(S[x]['publisher'] for x in ids))),resolvedElsewhere=g=='reported')
 if g=='check':f['conditionExplanation']=' '.join(n['qualifications'])
 if n.get('validUntil'):f['validUntil']=n['validUntil']
 if n.get('conflictId'):
  f['issues']=[dict(issue_id=ID+'-'+n['conflictId'],title=n['conflictId'].replace('_',' ').capitalize(),priority='field_hold',model_ids=[v['modelId']],publication_action='Keep both source-labelled observations visible; exclude the unresolved claim from attribute rankings.',source_ids=ids)]
 if k=='price_aud':
  pe=copy.deepcopy(n['priceEvidence']);pe.pop('comparisonBasis',None);pe['sourceKey']=k;pe['sourcePointer']=I[n['sourceKeys'][0]]['url']+' | '+n['locator'];f['priceEvidence']=pe
 return f
modelids=set(B[v]['modelId'] for v in B);normalizedfacts={}
for v in N['variants']:
 vid=v['id'];old=B.get(vid);mid=v['modelId'];generation=old['generation'] if old else 'MY26 Australian technical specification · January 2026 production scope; separately advertised residual new version'
 if mid not in modelids:
  P['models'].append(dict(id=mid,brand='Škoda',model=v['model'],generation=generation,family_id='skoda-'+v['model'].lower().replace(' ','-')));modelids.add(mid)
 if old:P['versionGuards'].append(dict(variantId=vid,before={k:old.get(k) for k in ['id','modelId','brand','model','trim','year','generation','vehicleClass','drive']}))
 else:P['variants'].append(dict(id=vid,model_id=mid,brand='Škoda',model=v['model'],trim=v['trim'],model_year=v['formalModelYear'],record_state=v['availability']['recordState'],variant_review_date=DATE,source_ids=[sid(k) for k in v['availability']['sourceKeys']],notes=[],price_basis='',range_cycle='',price_aud=None,range_km=None,seats=None,vehicle_class='passenger',drive=v['coreFacts']['drive']['value'],brand_update_generation=generation))
 nf={k:makefact(f,v) for k,f in {**v['coreFacts'],**v['extraFacts']}.items()};normalizedfacts[vid]=nf
 for k,f in nf.items():
  if k not in ['warranty','battery_warranty']:P['facts'].append(dict(variantId=vid,before=copy.deepcopy(old['facts'].get(k)) if old else None,after=f))
 a=v['availability'];e=dict(checkedAt=DATE,orderStatus=a['orderStatus'],stockStatus=a['stockStatus'],sourceIds=[sid(k) for k in a['sourceKeys']],physicalStockVerified=False,factoryOrderAcceptanceVerified=False,factoryBuildSpecificationVerified=False,deliveryToBuyerVerified=False,qualifications=a['qualifications'],configuration=v['scope'])
 before=dict(availability=old['availability'],evidence=copy.deepcopy(old['availabilityEvidence'])) if old else dict(availability=a['recordState'],evidence=dict(checkedAt=DATE,orderStatus='unverified',stockStatus='unverified',sourceIds=[sid(k) for k in a['sourceKeys']],qualifications=['Physical stock and factory-order acceptance have not been verified.']))
 P['availability'].append(dict(id=ID+'-availability-'+vid,variantId=vid,before=before,after=dict(availability=a['recordState'],evidence=e),status='approved',reviewedBy=REVIEWER,reviewedAt=DATE,evidenceDate=DATE,reason='Fresh exact Australian current maker listing or separately scoped residual MY26 new advertisement/offer; no physical-stock or accepted-factory-order inference.'))
 summary=dict(variantId=vid,conditions=[])
 for name,clause in v['summary'].items():summary[name]=dict(label=clause['label'],text=clause['text'],dependencies=[dict(key=k,expected=copy.deepcopy(nf[k])) for k in clause['dependencies']])
 P['summaries'].append(summary)
for k in ['warranty','battery_warranty']:
 P['brandTerms'].append(dict(key=k,fact=makefact(N['variants'][0]['coreFacts'][k],N['variants'][0],True),applicableVariantIds=[v['id'] for v in N['variants']],before={v['id']:copy.deepcopy(B[v['id']]['facts'].get(k)) if v['id'] in B else None for v in N['variants']},exceptions=[]))
assert len(P['facts'])==183 and len(P['variants'])==4 and len(P['models'])==3 and len(P['versionGuards'])==7
assert not P['features'] and not P['configurationUpdates'] and not P['versionUpdates']
p=O/'skoda-2026-10-15.json';p.write_text(json.dumps(P,indent=2,ensure_ascii=False)+'\n')
receipt=dict(status='proposal_assembled_pending_independent_review_and_selected_actual_function_preflight',packetPath=str(p),packetSha256=hashlib.sha256(p.read_bytes()).hexdigest(),packetBytes=p.stat().st_size,normalizedPath=str(R/'normalized-review-v3.json'),normalizedSha256=hashlib.sha256((R/'normalized-review-v3.json').read_bytes()).hexdigest(),sources=len(P['sources']),models=3,newVariants=4,existingGuards=7,specificFactUpdates=183,sharedBrandTerms=2,effectiveTermCells=22,availability=11,summaries=11,configurationUpdates=0,equipmentUpdates=0,versionUpdates=0,expectedCatalogueDelta=4,expectedTier1Delta=4,expectedOnSaleDelta=4,baselineStatus='Seven unchanged selected cars from accepted derived retained409 chain; not a fresh full export. Exact before guards await selected actual-function preflight.',productionSourceEdits=False,productionCatalogueHydration=False)
(O/'assembly-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
