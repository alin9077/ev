# Škoda M1 update — 15 October 2026

Draft: the numbers below are from the independently accepted full stage. Fresh registered checks are in progress; this draft is not a completion receipt.

## 1. What changed for a buyer
- Eleven exact versions now have all 17 core figures and supported strengths/trade-offs: seven refreshed MY27 versions, plus four separately advertised-new MY26 versions. No equipment research was added. Advertisements do not confirm physical stock or accepted factory orders.
- Current MY27 maker driveaway-from figures are A$49,990/59,990 for Elroq Select 60/85; A$55,990/64,990/79,990 for Enyaq SUV Select 60/Sportline 85/RS; and A$70,990/80,990 for Enyaq Coupe Sportline 85/RS. These are named-version “from” offers, not before-on-road list prices. Three Enyaq page/brochure price disagreements remain explicit and unranked.
- The four MY26 additions are Elroq Select 60 and 130 Years Edition, Enyaq SUV Select 60, and Enyaq Coupe Sportline 85. Their specifications and offer terms stay separate from MY27. Other residual-new leads remain unresolved where exact fresh target evidence is missing or contradictory.
- Both MY27 RS versions retain conflicting maker charging observations. Towing preserves the genuine-towbar requirement and warning that Škoda does not endorse electronic trailer-brake fitment or use. Published widths are Confirmed, but mirror inclusion is unspecified and width comparisons remain unranked. Battery warranty distinguishes the below-70% trigger from the staged 78%/74%/70% remedy levels.
- Elroq Sportline 85 remains a future lead because its page says orders open in early 2027. Epiq and Peaq do not gain invented Australian order eligibility.

## 2. Coverage report

| Tier 1 on-sale versions | Price | Range | Battery | DC time | Seats | Boot | Warranty | Strength + trade-off | In rankings |
|---|---|---|---|---|---|---|---|---|---|
| 307 | 85.7% / 33.2% | 89.6% / 62.5% | 98.4% / 78.8% | 78.8% / 42.3% | 94.8% / 72.0% | 86.3% / 70.0% | 100.0% / 95.8% | 100.0% | 8.8% |

Figures are filled / Confirmed. Warranty means vehicle warranty; “In rankings” means eligible in all six required lists. The catalogue contains 417 versions, including 340 Tier 1 versions. All 187 Škoda core cells are filled and reviewed: 161 Confirmed and 26 Check. The 18 supplemental observations preserve gross batteries and source-specific price/charging differences.

Three complete current maker-body lists cover all seven MY27 grades. Four admitted residual MY26 versions still lack complete current-list membership reviews, so Škoda is not research-complete. C2/C3/C4/C6 pass for the brand; C1/C5 remain open. These maker lists are not the two independent whole-market lists required to close C1.

Overall, 8/17 core fields meet their fill target and 4,902/5,219 on-sale core cells have earned reviews, with 372 strict gaps. The existing eleven research-complete brands are unchanged; 45 remain. None meets all C1–C6. Global C1–C5 remain open and freshness passes. Two independent market lists, 22 unmatched audit models and 27 unresolved leads remain outstanding; full lists accompany the structured report.

## 3. Phone screenshots
No new phone screenshots were captured. The original Model Y hero, heading, artwork and nine selling points are unchanged.

## 4. What did not work
The first selected-consumer run rejected two RS trade-offs because they depended on conflicted charging facts. Those summaries were replaced with the source-supported towing/trailer-brake constraint; the charging conflicts were retained. The next attempt stopped on a null brand in an unrelated motorcycle lead; a one-line null-safe test-harness filter fixed that. Both failures remain preserved. The final selected run and independent full stage passed, including 406 unchanged peers, eleven actual packs and exact portable serialization witnesses.

The first fresh-check wrapper stopped before Node launched because its empty QA parent directory was missing. The directory was created under renewed approval and the unchanged market preflight passed. Fresh validation, report parity, scoped tests and lint are still pending in this draft. Full standard TypeScript, the full-project test aggregate, production build and real-device verification remain open; no repeat compiler run was attempted.

## 5. Decisions needed
None for this update. M1 remains in progress; checkpoint 103 remains the delivered milestone. M2 and publishing have not started.
