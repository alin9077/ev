# Škoda M1 candidate, checked 15 October 2026

Seven current MY27 versions plus four separately evidenced residual MY26 versions are proposed. This is a frozen candidate, not an integrated catalogue update.

- Current list: Elroq Select60/Select85; Enyaq SUV Select60/Sportline85/RS; Enyaq Coupe Sportline85/RS
- Residual additions: MY26 Elroq Select60 and130 Years Edition; MY26 Enyaq SUV Select60 andCoupe Sportline85
-187 core cells:161 Confirmed and26 Check. No equipment expansion
- Three current Enyaq page/PDF price conflicts and two RS charging conflicts stay visible and unranked; source-specific supplemental observations retained
- All maker-labelled dimensions and applicable warranties Confirmed. Width mirror inclusion remains unstated and unranked
- Elroq Sportline85 orders open early2027; it is a future lead, not currently orderable
- Residual MY25 Elroq New related cards and other earlier grades remain explicitly unresolved; no nationwide stock-absence claim
- Global C1 remains open: two independent whole-market lists are still missing

Final packet: skoda-2026-10-15.json
Final reconciliation: m1-skoda-market-reconciliation-2026-10-15.json
Source research and frozen artifact hashes: freeze-receipt.json

The single selected actual-consumer preflight is prepared in ../selected-preflight-v2, but requires the root heavy-slot execution grant. No full catalogue recapture, live edit, test run, upload or publication has occurred in this work.

Integration must preserve the accepted retained409 → EQA21 → Leapmotor22 → Mazda23 → Škoda24 chain. Before applying Škoda, reproduce the accepted Mazda full field and car digests from /tmp/mazda-staging/full-v2/output. Do not replay earlier added-version packets.
