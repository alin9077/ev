from pathlib import Path
import sys,json,subprocess,os,time,hashlib
from datetime import datetime,timezone
m=Path(sys.argv[1]);h=sys.argv[2];assert hashlib.sha256(m.read_bytes()).hexdigest()==h
x=json.loads(m.read_text());assert x['timeoutSeconds']==420 and x['killAfterSeconds']==10 and x['automaticRetry'] is False
assert x['execArgv']==['--max-old-space-size=448','--max-semi-space-size=1','--expose-gc','--import','tsx']
assert x['productionRegistrationAuthorized'] is False and x['canonicalRecaptureAuthorized'] is False
assert os.environ.get('NODE_OPTIONS') is None

def now():return datetime.now(timezone.utc).isoformat()
def checkpins():
 assert hashlib.sha256(m.read_bytes()).hexdigest()==h
 for p in x['pins']:
  b=Path(p['path']).read_bytes();assert len(b)==p['bytes'];assert hashlib.sha256(b).hexdigest()==p['sha256'],p['path']
checkpins();out=Path(x['runOutput']);out.mkdir(exist_ok=False)
def write(name,obj):
 with (out/name).open('x') as f:json.dump(obj,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
cmd=['node',*x['execArgv'],x['script']['path'],'--manifest',str(m),'--manifest-sha256',h]
wrapped=['/usr/bin/timeout','--signal=TERM','--kill-after=10s','420s',*cmd]
write('invocation.json',dict(at=now(),cwd=x['repo'],command=cmd,supervisedCommand=wrapped,manifestSha256=h,wrapperSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),beforePinsPassed=True,automaticRetry=False,sourceMutationsAuthorized=False))
start=time.monotonic()
with (out/'stdout.log').open('x') as so,(out/'stderr.log').open('x') as se:
 p=subprocess.Popen(wrapped,cwd=x['repo'],stdout=so,stderr=se,start_new_session=True);write('started.json',dict(at=now(),pid=p.pid,processGroup=os.getpgid(p.pid)))
 _,status,usage=os.wait4(p.pid,0);code=os.waitstatus_to_exitcode(status);p.returncode=code;so.flush();se.flush();os.fsync(so.fileno());os.fsync(se.fileno())
terminal=dict(at=now(),exitCode=code,rawWaitStatus=status,elapsedSeconds=time.monotonic()-start,maxRssKiB=usage.ru_maxrss,stdoutSha256=hashlib.sha256((out/'stdout.log').read_bytes()).hexdigest(),stderrSha256=hashlib.sha256((out/'stderr.log').read_bytes()).hexdigest(),timeoutInterpretation='Raw wait status retained; no cause inferred',automaticRetry=False)
write('terminal.json',terminal)
try:checkpins();write('after-pins.json',dict(at=now(),passed=True,count=len(x['pins']),manifestSha256=h))
except Exception as e:write('after-pins.json',dict(at=now(),passed=False,error=repr(e)));raise
print(json.dumps(terminal));print((out/'stdout.log').read_text()[-3500:]);print((out/'stderr.log').read_text()[-4500:]);sys.exit(0 if code==0 else 1)
