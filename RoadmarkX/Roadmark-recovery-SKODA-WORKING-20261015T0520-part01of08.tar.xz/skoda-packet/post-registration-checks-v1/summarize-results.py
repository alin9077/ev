from pathlib import Path
import json,hashlib,re
from datetime import datetime,timezone
base=Path('/workspace/scratch/586427eef9f2/roadmark-104-qa/skoda-sequential-checks');plan=Path('/tmp/skoda-packet/post-registration-checks-v1');s=json.loads((plan/'scoped-grant.json').read_text())
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
rows=[]
for item in s['granted']:
 m=Path(item['path']);assert pin(m)==item;x=json.loads(m.read_text());out=Path(x['runOutput']);terminal=json.loads((out/'terminal.json').read_text());after=json.loads((out/'after-pins.json').read_text());assert terminal['exitCode']==0 and after['passed'] and after['count']==125
 stdout=(out/'stdout.log').read_text();stderr=(out/'stderr.log').read_bytes();assert not stderr
 row={'manifest':pin(m),'terminal':pin(out/'terminal.json'),'afterPins':pin(out/'after-pins.json'),'stdout':pin(out/'stdout.log'),'stderr':pin(out/'stderr.log'),'exitCode':0,'elapsedSeconds':terminal['elapsedSeconds'],'maxRssKiB':terminal['maxRssKiB'],'pinsUnchanged':125}
 if '--test' in x['command']:
  counts={k:int(re.search(r'^# '+k+r' (\d+)$',stdout,re.M)[1]) for k in ['tests','pass','fail','cancelled','skipped','todo']};assert counts['tests']==counts['pass'] and not any(counts[k] for k in ['fail','cancelled','skipped','todo']);row['tests']=counts
 rows.append(row)
for item in s['notRun']:
 x=json.loads(Path(item['manifest']['path']).read_text());assert not Path(x['runOutput']).exists()
p=base/'final-scoped-check-receipt.json';x={'status':'eight_authorized_steps_pass_pending_independent_final_review','at':datetime.now(timezone.utc).isoformat(),'runs':rows,'notRun':s['notRun'],'scope':'105 seven-file behavioral tests, six isolated changed-search tests, seven isolated live-safety tests; separate runs, not a full-project aggregate. Unchanged historical sourceCatalogue and added-detail tests were omitted by root. No tsc, production build or real-device test in this cycle.','exactNormalStagedReportParity':pin(base/'normal-report-staged-parity.json'),'beforeLaunchSetupFailure':pin(plan/'market-preflight-setup-failure.json'),'setupFailureDidNotLaunchNodeOrTests':True,'allSourcePinsUnchangedEachRun':True,'sourceEditsDuringRuns':False,'automaticRetry':False,'rootApprovedBeforeLaunchPreparationRetry':True};assert [r['tests']['tests'] for r in rows if 'tests' in r]==[105,6,7]
with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
print(json.dumps(pin(p)));print(json.dumps({'status':x['status'],'steps':len(rows),'testRuns':[r['tests'] for r in rows if 'tests' in r]},indent=2))
