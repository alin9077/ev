from pathlib import Path
import json,hashlib
from datetime import datetime,timezone
base=Path('/workspace/scratch/586427eef9f2/roadmark-104-qa/skoda-sequential-checks')
a=base/'normal-coverage-asof-2026-10-15/stdout.log';e=Path('/tmp/skoda-packet/full-stage-v1/output/staged-report.json');t=base/'normal-coverage-asof-2026-10-15/terminal.json'
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert json.loads(t.read_text())['exitCode']==0
assert hashlib.sha256(e.read_bytes()).hexdigest()=='50009a459a4f51f0b6b5fb443d8dc5e990b8579addc42593978927c89f7f6313'
x=json.loads(a.read_text());y=json.loads(e.read_text());assert x==y;assert a.read_bytes()==e.read_bytes();assert [x[k] for k in ['allCatalogueVersions','tierOneVersions','onSaleVersions']]==[417,340,307]
b=next(b for b in x['brandProgress'] if b['brand']=='Škoda');assert b['onSaleVersions']==11 and len(b['currentVersionReviews'])==3 and b['unreviewedCoreGrades']==b['missingSummaries']==0
receipt={'status':'normal_full_report_exact_staged_deep_parity_pass','at':datetime.now(timezone.utc).isoformat(),'actual':pin(a),'expected':pin(e),'terminal':pin(t),'exactDeepEquality':True,'byteEquality':True,'ignoredPaths':[],'allCatalogueVersions':417,'tierOneVersions':340,'onSaleVersions':307,'skodaOnSaleVersions':11,'skodaMakerLists':3,'skodaCurrentVersions':7,'skodaResidualMembershipGaps':4,'wholeMarketC1':False}
with (base/'normal-report-staged-parity.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt,indent=2))
