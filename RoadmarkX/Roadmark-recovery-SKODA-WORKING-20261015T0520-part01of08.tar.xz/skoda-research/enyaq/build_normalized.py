import json,pathlib,collections,copy,hashlib
P=pathlib.Path('/tmp/skoda-research/enyaq');date='2026-10-15'
keys=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty','battery_warranty']
rows=[('suv','Select 60','select_60','enyaq_select'),('suv','Sportline 85','sportline_85','enyaq_suv_sportline'),('coupe','Sportline 85','sportline_85','enyaq_coupe_sportline'),('suv','RS','rs','enyaq_suv_rs'),('coupe','RS','rs','enyaq_coupe_rs')]
prices=[55990,64990,70990,79990,80990];pdfprices=[54990,63990,68990,79990,80990];reported=[51990,60990,66990,76590,77590]
conflicts=[]
def fact(key,value,unit,basis,comparison,source,locator,grade='confirmed',qual=None,rank=True,scope='exact_au_version'):
 return dict(key=key,value=value,unit=unit,buyerGrade=grade,status='standard' if grade=='confirmed' else 'conditional',basis=basis,comparisonBasis=comparison,sourceKeys=source if isinstance(source,list) else [source],locator=locator,evidenceScope=scope,qualifications=qual or [],rankingEligible=rank,date=date,market='AU')
def make(year):
 vals={2027:dict(ranges=[431,551,565,546,557],net=[58,77,77,77,77],gross=[61,82,82,82,82],dc=[105,165,165,165,165],minutes=[26,29,29,29,29],power=[140,210,210,250,250],accel=[8.6,6.6,6.6,5.4,5.4],tow=[1000,2000,2000,2200,2200],boot=[585,585,570,585,570],folded=[1710,1710,1610,1710,1610]),2026:dict(ranges=[410,547,561,523,534],net=[59,77,77,79,79],gross=[63,82,82,84,84],dc=[165,135,135,185,185],minutes=[24,28,28,26,26],power=[150,210,210,250,250],accel=[8.1,6.7,6.7,5.4,5.4],tow=[1000,1000,1000,1800,1800],boot=[585,585,570,570,570],folded=[1710,1710,1610,1610,1610])}[year]
 spec='enyaq_my27_specs' if year==2027 else 'au-enyaq-my26';out=[]
 for i,(body,trim,slug,landing) in enumerate(rows):
  mid=f'skoda_enyaq_{body}_my{str(year)[2:]}'
  v=dict(id=f'{mid}__{slug}__20261010' if year==2027 else f'{mid}__{slug}__20261015',brand='Škoda',model='Enyaq SUV' if body=='suv' else 'Enyaq Coupé',modelId=mid,trim=trim,vehicleClass='passenger',powertrain='BEV',formalModelYear=year,action='refresh' if year==2027 else 'potential_residual_add_pending_exact_new_ad',sourceCheckedAt=date,primarySourceKey=spec,scope=f'Australian Škoda Enyaq {body.upper() if body=="suv" else "Coupé"} {trim}; MY{str(year)[2:]}; '+('July 2026' if year==2027 else 'January 2026')+' production specification',sharedFactInheritanceRequired=['warranty','battery_warranty'])
  cf={}
  price=prices[i] if year==2027 else pdfprices[i]
  price_src=landing if year==2027 else spec
  pq=['Manufacturer recommended driveaway FROM price for new vehicles sold and delivered by 31 December 2026, while stocks last; no physical stock or individual quote verified.','Includes recommended retail price, 12 months private registration and CTP, estimated dealer delivery, stamp duty and applicable statutory charges/LCT; location/dealer and individual circumstances may alter price.','No explicit national applicability statement found; do not label as national driveaway.']
  cid=None
  if year==2027 and i<3:
   cid=f'ENYAQ_MY27_{body.upper()}_{slug.upper()}_PRICE_CONFLICT'
   pq.append(f'Live exact-version page says A${price:,}; linked July MY27 PDF says A${pdfprices[i]:,}. Current named-version page selected; both observations preserved and neither claimed a final quote.')
   conflicts.append(dict(id=cid,variantId=v['id'],factKeys=['price_aud'],chosenSourceKey=landing,observations=[dict(sourceKey=landing,value=price,basis='Maker driveaway from'),dict(sourceKey=spec,value=pdfprices[i],basis='Maker driveaway from')],resolution='Current live named-version amount selected for display with Check; PDF disagreement unresolved.'))
  cf['price_aud']=fact('price_aud',price,'AUD','Maker driveaway from','Driveaway',[price_src,spec] if cid else [price_src],'Named-version page headline + disclaimer 1' if year==2027 else 'PDF physical p2 / printed p1 model-price grid','check',pq,rank=not bool(cid))
  cf['price_aud']['validUntil']='2026-12-31'
  cf['price_aud']['priceEvidence']=dict(rung=3,basisTag='Maker driveaway from',comparisonBasis='Driveaway',sourceKey='price_aud',sourcePointer=price_src,originalBasis='Manufacturer recommended driveaway price / From; national applicability not explicit',rankingEligible=not bool(cid))
  if cid:cf['price_aud']['conflictId']=cid
  cf['range_km']=fact('range_km',vals['ranges'][i],'km','WLTP combined','WLTP combined',spec,'PDF physical p3 / printed p2: Energy Consumption (WLTP), Range - Combined, exact column')
  cf['battery_kwh']=fact('battery_kwh',vals['net'][i],'kWh','Usable battery capacity (maker Nett)','Usable battery capacity',spec,'PDF physical p3 / printed p2: High Voltage Battery Capacity (Gross / Nett), second figure')
  cf['dc_peak_kw']=fact('dc_peak_kw',vals['dc'][i],'kW','Maximum DC charging capacity','DC peak kW',spec,'PDF physical p3 / printed p2: Maximum charging capacity (AC / DC), DC figure')
  cf['dc_charge_time_min']=fact('dc_charge_time_min',vals['minutes'][i],'min','Approximate DC charging time, 10–80%','DC 10–80%',spec,f'PDF physical p4 / printed p3: Charging Time @{vals["dc"][i]}kW DC 10% - 80%, exact column',qual=[f'Approximately {vals["minutes"][i]} minutes at the published {vals["dc"][i]} kW DC station rating; peak input is not a session average.'])
  if year==2027 and i>=3:
   cid=f'ENYAQ_MY27_{body.upper()}_RS_DC_CONFLICT'
   cq='Exact MY27 PDF specifies 165 kW maximum DC and approximately 29 minutes for 10–80%; current RS landing-page charging prose specifies 185 kW and 26 minutes. Chosen MY27 sheet is exact-year technical evidence; discrepancy is unresolved and requires build confirmation.'
   for k in ['dc_peak_kw','dc_charge_time_min']:
    cf[k].update(buyerGrade='check',status='conditional',rankingEligible=False,conflictId=cid);cf[k]['sourceKeys'].append(landing);cf[k]['qualifications'].append(cq)
   conflicts.append(dict(id=cid,variantId=v['id'],factKeys=['dc_peak_kw','dc_charge_time_min'],chosenSourceKey=spec,observations=[dict(sourceKey=spec,dc_peak_kw=165,dc_charge_time_min=29,window='10–80%'),dict(sourceKey=landing,dc_peak_kw=185,dc_charge_time_min=26,window='10–80%')],resolution='Exact MY27 PDF selected, Check and unranked until contradictory current marketing prose is resolved; MY26 PDF separately matches the marketing values, but this does not prove the marketing copy is MY26.'))
  cf['ac_kw']=fact('ac_kw',11,'kW','Maximum AC charging capacity','AC maximum kW',spec,'PDF physical p3 / printed p2: Maximum charging capacity (AC / DC), AC figure')
  cf['seats']=fact('seats',5,'','Seats','Seats','au_faq','Explore the Škoda Enyaq / Is the Enyaq practical for families? says seats five; introductory Enyaq answer names all five versions',scope='body_range')
  if year==2026:cf['seats']['qualifications']=['Current maker Enyaq range-wide seat count inherited; not inferred from the MY27 battery or drivetrain changes.']
  cf['boot_l']=fact('boot_l',vals['boot'][i],'L','VDA; rear seats up','VDA; rear seats up',spec,'PDF physical p5 / printed p4: Luggage capacity, rear seats up (L) (VDA), exact column')
  if year==2026 and body=='suv' and trim=='RS':
   cid='ENYAQ_MY26_SUV_RS_BOOT_CONFLICT'
   cf['boot_l'].update(buyerGrade='check',status='conditional',rankingEligible=False,conflictId=cid)
   cf['boot_l']['sourceKeys'].append('enyaq_select')
   cf['boot_l']['qualifications']=['The exact MY26 SUV RS table publishes 570 L, with 1,610 L folded, but current maker SUV-family page publishes 585 / 1,710 L. Preserve 570 L as exact-year claim; do not silently correct it to the family figure or MY27 SUV RS.']
   conflicts.append(dict(id=cid,variantId=v['id'],factKeys=['boot_l'],chosenSourceKey=spec,observations=[dict(sourceKey=spec,boot_l=570,folded_l=1610,scope='MY26 SUV RS exact column'),dict(sourceKey='enyaq_select',boot_l=585,folded_l=1710,scope='Current SUV body-range page')],resolution='Exact MY26 figure retained as Check and unranked; body-range discrepancy requires confirmation.'))
  cf['zero_to_100_s']=fact('zero_to_100_s',vals['accel'][i],'s','0–100 km/h','0–100 km/h',spec,'PDF physical p3 / printed p2: Performance 0–100 km/h, exact column')
  cf['power_kw']=fact('power_kw',vals['power'][i],'kW','Maximum electric motor power','Maximum motor power kW',spec,'PDF physical p3 / printed p2: Max. Power of Electromotor (kW), exact column')
  cf['drive']=fact('drive','RWD' if i<3 else 'AWD','','Rear-wheel drive' if i<3 else 'Four-wheel drive','Drive type',spec,'PDF physical p3 / printed p2: Drivetrain standard dots, visually verified')
  cf['length_mm']=fact('length_mm',4658 if i<3 else 4653,'mm','Exterior length','Exterior length',spec,'PDF physical p5 / printed p4: Dimensions / Exterior / Length')
  cf['width_mm']=fact('width_mm',1879,'mm','Manufacturer exterior width; mirror inclusion unspecified','',spec,'PDF physical p5 / printed p4: Dimensions / Exterior / Width','check',['Current exact-year Australian specification and maker body landing/FAQ checked; no explicit mirror inclusion basis for the 1,879 mm figure found. Do not relabel as including or excluding mirrors.'],False)
  cf['height_mm']=fact('height_mm',[1622,1622,1623,1615,1618][i],'mm','Exterior height','Exterior height',spec,'PDF physical p5 / printed p4: Dimensions / Exterior / Height')
  cf['towing_braked_kg']=fact('towing_braked_kg',vals['tow'][i],'kg','Braked towing with Škoda Genuine Tow Bar','Braked towing',spec,'PDF physical p5 / printed p4: Towing capacity / Braked and genuine towbar footnote','check',['Only when fitted with Škoda Genuine Tow Bar; maximum depends on laden vehicle mass, conditions and accessories. Maker does not endorse or accept liability for electronic trailer-brake fitment/use.'])
  v['coreFacts']=cf
  v['extraFacts']={'battery_gross_kwh':fact('battery_gross_kwh',vals['gross'][i],'kWh','Gross battery capacity','Gross battery capacity',spec,'PDF physical p3 / printed p2: battery Gross / Nett first figure')}
  v['reviewFlags']=[f['conflictId'] for f in cf.values() if f.get('conflictId')]+['WIDTH_MIRROR_BASIS_UNSPECIFIED']
  v['reviewFlags']=list(dict.fromkeys(v['reviewFlags']))
  v['priceLadderReview']=dict(selectedRung=3,reason='Named-version manufacturer driveaway-from is explicit; national applicability and maker before-on-road-cost basis are not published in the checked maker material.',rung1Search=dict(checkedSourceKeys=[price_src,spec],searchQueries=['site.skoda.com.au Enyaq MY27 "$51,990" before','site.skoda.com.au Enyaq "recommended retail" "$" 2027','site.skoda.com.au Enyaq "MSRP"','site.skoda.com.au Enyaq "before on-road" "2027"','site.skoda.com.au Enyaq "51,990" "60,990"'],outcome='No explicit maker before-ORC price found. Current official page and exact-MY PDF give MRDP/from. Secondary before-ORC prices do not outrank maker rung3.'),candidates=[dict(rung=3,value=price,sourceKey=price_src,comparisonBasis='Driveaway',accepted=True,reason='Selected named-version maker From amount with explicit driveaway disclaimer.')])
  if year==2027:
   v['priceLadderReview']['candidates'].append(dict(rung=3,value=pdfprices[i],sourceKey=spec,comparisonBasis='Driveaway',accepted=True,selected=False,reason='Exact MY27 PDF price retained; live named page selected where amounts disagree.'))
   v['priceLadderReview']['candidates'].append(dict(rung=5,value=reported[i],sourceKey='carexpert_my27_update',comparisonBasis='Before on-road costs',accepted=True,selected=False,rankingEligible=False,reason='CarExpert explicitly labels before on-road costs; secondary and lower rung than maker from.'))
  v['availability']=dict(recordState='current_or_order_listed' if year==2027 else 'pending_residual_ad_verification',buyerState='On sale now' if year==2027 else 'Not confirmed',orderStatus='listed_unconfirmed',stockStatus='unverified',physicalStockVerified=False,factoryOrderAcceptanceVerified=False,factoryBuildSpecificationVerified=False,deliveryToBuyerVerified=False,sourceKeys=['current_range','au_faq',landing] if year==2027 else [spec],qualifications=['Current Australian exact-version catalogue and MY27 spec sheet establish the five maker versions; no dealer inventory or order acceptance inferred.'] if year==2027 else ['Reachable MY26 maker specification is technical evidence only; parent must link an exact advertised-new identity before admitting a residual version.'])
  if i==0:st=('Family luggage space',f'The five-seat SUV has a {vals["boot"][i]} L VDA boot with the rear seats up.',['seats','boot_l']);tr=('Shorter-trip bias',f'{vals["ranges"][i]} km WLTP combined range and a {vals["tow"][i]:,} kg braked towing limit constrain longer trips and heavier trailers.',['range_km','towing_braked_kg'])
  elif i==1:st=('Range and luggage',f'{vals["ranges"][i]} km WLTP combined range pairs with a {vals["boot"][i]} L VDA boot.',['range_km','boot_l']);tr=('Rear-wheel drive','This version is rear-wheel drive; the RS versions are the all-wheel-drive choices.',['drive'])
  elif i==2:st=('Range and acceleration',f'The maker quotes {vals["ranges"][i]} km WLTP combined and {vals["accel"][i]} seconds from 0–100 km/h.',['range_km','zero_to_100_s']);tr=('Less luggage room','Its 570 L VDA boot is 15 L smaller than the Sportline SUV’s 585 L boot.',['boot_l'])
  elif i==3:st=('All-wheel-drive performance','250 kW, all-wheel drive and a 5.4-second 0–100 km/h claim support brisk acceleration.',['power_kw','drive','zero_to_100_s']);tr=('Range trade-off',f'{vals["ranges"][i]} km WLTP combined is below the Sportline SUV’s {vals["ranges"][1]} km.',['range_km'])
  else:st=('All-wheel-drive performance','250 kW, all-wheel drive and a 5.4-second 0–100 km/h claim support brisk acceleration.',['power_kw','drive','zero_to_100_s']);tr=('Range trade-off',f'{vals["ranges"][i]} km WLTP combined is below the rear-drive Coupé Sportline’s {vals["ranges"][2]} km.',['range_km','drive'])
  v['summary']={k:dict(label=z[0],text=z[1],dependencies=z[2]) for k,z in [('strength',st),('tradeoff',tr)]}
  out.append(v)
 return out
current=make(2027);residual=make(2026)
for name,vs in [('normalized-current-my27.json',current),('normalized-residual-my26-potential.json',residual)]:
 grades=collections.Counter(f['buyerGrade'] for v in vs for f in v['coreFacts'].values())
 doc=dict(schema='skoda-enyaq-normalized-research-v1',status='proposed_for_parent_review_not_registered',checkedAt=date,coreKeys=keys,sharedFactInheritanceRequired=['warranty','battery_warranty'],variants=vs,gradeCounts=dict(grades),sourceIndexPath=str(P/'source-index.json'),conflictsPath=str(P/'conflicts.json'),censusPath=str(P/'census-current.json'),reviewNotes=['No equipment expansion; only M1 core facts and separate gross battery capacity.','Warranty and battery warranty are centrally captured and inherited by parent.','Current 5 MY27 versions and potential residual MY26 versions remain separate.','Conflicted prices/DC and width without mirror basis are visible but conservatively unranked pending review.'])
 (P/name).write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
(P/'conflicts.json').write_text(json.dumps(conflicts,ensure_ascii=False,indent=2)+'\n')
registry=[]
for p in P.glob('*.metadata.json'):
 s=json.loads(p.read_text());s['sourceKey']=s.pop('source_id');s['capture_kind']='full_response_body' if 'body_path' in s else 'failed_http_fetch';s['auth_headers_retained']=False
 if s['sourceKey']=='carexpert_my27_update':
  s.update(capture_kind='full_web_parsed_body_238_lines',web_extract_path=str(P/'carexpert_my27_update.web-extract.json'),web_read_success=True,checked_at='2026-10-15',note='Direct HTTP body fetch returned403; independent web tool returned complete parsed page lines0–237. Do not claim original HTML body captured.')
 if s['sourceKey']=='carexpert_my27_dimensions':s['used_for_claims']=False
 registry.append(s)
registry.append(dict(sourceKey='au-enyaq-my26',url='https://www.skoda.com.au/_doc/6dcc0cf3-bd57-4df2-b81f-acdb994a6b7d',checked_at=date,body_path='/tmp/skoda-research/sources/au-enyaq-my26.pdf',text_path='/tmp/skoda-research/sources/au-enyaq-my26.txt',metadata_path='/tmp/skoda-research/sources/au-enyaq-my26-receipt.json',capture_kind='full_response_body_captured_by_parent',auth_headers_retained=False))
(P/'source-index.json').write_text(json.dumps(registry,ensure_ascii=False,indent=2)+'\n')
census=dict(checkedAt=date,scope='Manufacturer current Australian Enyaq SUV and Coupé version lists',currentVersionCount=5,currentVersions=[dict(id=v['id'],model=v['model'],trim=v['trim'],formalModelYear=2027) for v in current],makerListSourceKeys=['current_range','au_faq','enyaq_my27_specs'],independentPublishedListSourceKeys=['carexpert_my27_update'],reconciliation=dict(makerCount=5,independentCount=5,missingFromRetained=[],missingFromCurrentMaker=[],differences=[]),closedForCurrentMakerList=True,residualLeadsSeparate=dict(path=str(P/'normalized-residual-my26-potential.json'),count=5,admission='None admitted by this worker. Parent supplies verified exact advertised-new MY26 identities; reachable technical sheet alone is not stock evidence.'),futureLeads=[],notes=['Official range, FAQ and exact MY27 PDF agree on all five current versions.','Published secondary MY27 price table independently enumerates the same five.','Global 85x, Selection variants and old MY25 are not promoted into the current Australian list.'])
(P/'census-current.json').write_text(json.dumps(census,ensure_ascii=False,indent=2)+'\n')
print('Wrote current5 and residual5; current facts',sum(len(v['coreFacts']) for v in current),'residual facts',sum(len(v['coreFacts']) for v in residual),'conflicts',len(conflicts))
