#!/usr/bin/env python3
"""Pinned unchanged privacy modules, canonical Nissan ledgers, no broad exemptions."""
import json,sys,types
from nissan_capture_adapter_v2 import C,B,P,exact_bytes,load_reference,capture_module
PINS={'privacy_v1.py': {'bytes': 15310, 'sha256': '5c8981f69d021b1ca18a69f95036b7cb25e26e35cf455c513d8ed7c3ad5ea601'}, 'audi_scan_additions_v3.py': {'bytes': 3201, 'sha256': '58bab303871e8c4fe48ed0b78327464da42ca3b98efaa0d3710befa4877f5e13'}, 'deepal_scan_additions_v2.py': {'bytes': 4049, 'sha256': '59894d2f1e04fe0162c8de4529180412df66b2d76b5f19a96b9967e4fb4582fc'}}
def verified_contract():
 cap=sys.modules.get('capture_v1') or capture_module()
 contract=cap.load(C/'NISSAN-PRIVACY-ADAPTER-CONTRACT-v1.json')
 assert contract['status']=='INDEPENDENTLY_ACCEPTED_NISSAN_PRIVACY_ADAPTER'
 assert P(contract['preparation']['path'])==C/'NISSAN-ADAPTER-PREPARATION-v2.json'
 cap.check(P(contract['review']['path']),contract['review']);cap.check(P(contract['preparation']['path']),contract['preparation'])
 prep=cap.load(contract['preparation']['path'])
 for r in prep['localPins']:cap.check(P(r['path']),r)
 for r in cap.load(C/'NISSAN-INHERITED-ADAPTER-PINS-v1.json')['pins']:cap.check(P(r['path']),r)
 scope=cap.load(C/'APPROVED-INHERITED-SEED-SCOPE.json')
 assert (scope['historicalPinnedMembers'],scope['historicalArchives'],scope['localSelectors'],scope['audiPayloadReadOperations'],scope['deepalCopiedCaptureSources'])==(200,21,48,6,5)
 assert scope['inMemoryOnly'] and scope['actualRepeatedReadAccounting'] and not scope['broadBaseScanOrClone'] and not scope['rawExcludedPayloadReadRecoveryRefetch']
 return contract
def configure(require_review=True):
 cap=sys.modules.get('capture_v1') or capture_module()
 if require_review:verified_contract()
 else:
  # Pattern-only preflight still pins every imported engine/helper but never calls seed_sets.
  for r in cap.load(C/'NISSAN-INHERITED-ADAPTER-PINS-v1.json')['pins']:cap.check(P(r['path']),r)
 audi=load_reference('audi_scan_additions_v3',B/'audi_scan_additions_v3.py',PINS['audi_scan_additions_v3.py']);audi.C=C
 deepal=load_reference('deepal_scan_additions_v2',B/'deepal_scan_additions_v2.py',PINS['deepal_scan_additions_v2.py']);deepal.C=C
 privacy=load_reference('privacy_v1',B/'privacy_v1.py',PINS['privacy_v1.py']);assert privacy.C==C and privacy.BASE==B
 guard=types.ModuleType('require_privacy_contract_v1');guard.verified_contract=verified_contract;sys.modules['require_privacy_contract_v1']=guard
 return privacy
