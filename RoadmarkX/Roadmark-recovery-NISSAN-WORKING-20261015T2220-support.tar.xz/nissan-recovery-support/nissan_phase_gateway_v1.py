#!/usr/bin/env python3
"""Nissan canonical phase entry points using pinned prior implementations."""
import sys,json,pathlib,ast
from nissan_capture_adapter_v2 import C,B,P,capture_module,load_reference,replace_constant
PINS={'package_v1.py': {'bytes': 3896, 'sha256': '7d05cd34ea0484cec3805dee49f1fe4afdccb7da2f6dd870470bbe748f9be8ac'}, 'preflight_patterns_v1.py': {'bytes': 939, 'sha256': '4a43afab5365a91c4a82233f912e503cf166cd0706f5706a9f22fa48e7be05d2'}, 'scan_documents_v1.py': {'bytes': 1968, 'sha256': '29f7ef0a6b2567f39d196e9985b5c5e143a63d3f665b2746615f05f0549278ab'}}
LABEL='NISSAN-WORKING-20261015T2220'
OLD_RESTORE='Overlay after the exact 138-archive CUPRA chain, replacing its source archive with this full registered Renault working source. Original raw-capture expected hashes remain unchanged; exact copy-only changes are recorded in the retained sanitation mapping.'
NEW_RESTORE='Overlay after the exact 142-archive Renault chain, replacing only its standalone source archive with this full registered Nissan working source; reuse the other 141 exact archives. Original raw-capture expected hashes remain unchanged; exact copy-only changes are recorded in the retained sanitation mapping. Native byte readback remains unpassed.'
def package_transform(tree):
 replace_constant(tree,'RENAULT-WORKING-20261015T2040',LABEL)
 replace_constant(tree,OLD_RESTORE,NEW_RESTORE,function='main')
 replace_constant(tree,'renault-safety-support/COPY-SANITATION-MAPPING.json','nissan-safety-support/COPY-SANITATION-MAPPING.json',function='main')
 return tree
def capture_review(cap):
 receipt=cap.load(C/'NISSAN-CAPTURE-CANDIDATE-APPROVAL-v1.json')
 assert receipt['status']=='INDEPENDENTLY_ACCEPTED_EXACT_NISSAN_COPY_MAPPING'
 for key in ('preflight','renameMapping','sanitationMapping','review'):cap.check(P(receipt[key]['path']),receipt[key])
 assert P(receipt['preflight']['path'])==C/'JSON-SANITIZER-CANDIDATES-v1.json'
 assert P(receipt['renameMapping']['path'])==C/'PROSE-KEY-RENAME-APPROVALS.json'
 assert P(receipt['sanitationMapping']['path'])==C/'COPY-SANITATION-MAPPING.json'
 candidate=cap.load(receipt['preflight']['path']);mapping=cap.load(receipt['renameMapping']['path']);rows=candidate['candidateFiles']
 assert len({r['restorePath'] for r in rows})==len(rows)
 assert {r['restorePath'] for r in mapping['files']}=={r['restorePath'] for r in rows}
 assert len(mapping['files'])==len(rows)
 for row in mapping['files']:
  c=next(x for x in rows if x['restorePath']==row['restorePath']);assert row['originalSHA256']==c['sha256'] and row['originalBytes']==c['bytes']
  assert row['oldPointer']=='/authorization' and row['newPointer']=='/approvalScope'
  assert len(c['locations'])==1 and c['locations'][0]['pointer']=='/authorization'
 return receipt
def main():
 mode=sys.argv[1];args=sys.argv[2:];cap=capture_module()
 if mode in ('capture-source','capture-proof'):
  assert not args;capture_review(cap);getattr(cap,'source' if mode=='capture-source' else 'proof')()
 elif mode in ('package-source','package-proof','package-support'):
  assert not args;capture_review(cap);m=load_reference('nissan_package_reference',B/'package_v1.py',PINS['package_v1.py'],package_transform);sys.argv=[str(C/'nissan_phase_gateway_v1.py'),mode.removeprefix('package-')];m.main()
 elif mode=='preflight-patterns':
  assert len(args)==2 and all(P(p).parent.resolve()==C for p in args)
  from nissan_privacy_adapter_v1 import configure
  configure(require_review=False);m=load_reference('nissan_pattern_reference',B/'preflight_patterns_v1.py',PINS['preflight_patterns_v1.py']);sys.argv=[str(C/'nissan_phase_gateway_v1.py'),*args];m.main()
 elif mode=='scan-archive':
  assert len(args)==3 and P(args[1]).parent.resolve()==C and P(args[2]).parent.resolve()==C
  from nissan_privacy_adapter_v1 import configure
  m=configure();sys.argv=[str(C/'nissan_phase_gateway_v1.py'),*args];m.main()
 elif mode=='scan-documents':
  assert len(args)==2 and all(P(p).parent.resolve()==C for p in args)
  from nissan_privacy_adapter_v1 import configure
  configure();m=load_reference('nissan_documents_reference',B/'scan_documents_v1.py',PINS['scan_documents_v1.py']);sys.argv=[str(C/'nissan_phase_gateway_v1.py'),*args];m.main()
 else:raise ValueError('Unreviewed phase: '+mode)
if __name__=='__main__':main()
