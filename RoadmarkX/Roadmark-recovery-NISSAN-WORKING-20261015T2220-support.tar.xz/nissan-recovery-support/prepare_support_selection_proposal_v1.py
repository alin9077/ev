#!/usr/bin/env python3
"""Snapshot current Nissan task support metadata/code; never payload or private seed inputs."""
from pathlib import Path
import hashlib,json,collections
C=Path(__file__).resolve().parent
assert C.name=='nissan-working-20261015T2220'
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
p=C/'NISSAN-EXTERNAL-SUPPORT-PROPOSAL-v1.json';assert pin(p)['sha256']=='c2a82aba402465448e68444ef8b10c59ae92979f69832930fd630887194231d1';e=json.loads(p.read_text())
paths=sorted(p for p in C.iterdir() if p.is_file())
for dn in ('seed-read-invocations','audi-seed-read-invocations','deepal-seed-read-invocations'):
 for p in sorted((C/dn).iterdir()):
  assert p.is_file() and not p.is_symlink();paths.append(p)
reserved={'SUPPORT-SELECTION-v1.json','SUPPORT-REUSE-MAPPING.json','SUPPORT-SELECTION-PROPOSAL-v1.json','SUPPORT-MEMBER-INVENTORY.json','SUPPORT-PATTERN-SELECTION-v1.json'}
assert all(p.name not in reserved and not p.is_symlink() for p in paths)
rows=list(e['files'])
for p in paths:
 z=pin(p);r={'originalPath':str(p),'localRelativePath':str(p.relative_to(C)),'bytes':z['bytes'],'sha256':z['sha256'],'action':'fresh'}
 if p.name in ('SEED-PROVENANCE.json','INHERITED-LOCAL-SEED-READ-SCOPE.json','TARGETED-SEED-READ-DEPENDENCY.json'):
  m=[x for x in e['files'] if x['originalPath'].endswith('/renault-working-20261015T2040/'+p.name)];assert len(m)==1
  assert all(m[0][k]==r[k] for k in ('bytes','sha256'))
  r|={k:m[0][k] for k in ('retainedMember','retainedArchive','archiveMappingAuthority','outsideRecoveryArchiveSet')};r['action']='reuse'
 rows.append(r)
assert len({r['originalPath'] for r in rows})==len(rows)
assert len({r['localRelativePath'] for r in rows})==len(rows)
private={x['path'] for x in e['localOnlyPrivateSeedInputPins']};assert not private.intersection(r['originalPath'] for r in rows)
code=collections.defaultdict(list)
for r in rows:
 if r['action']=='fresh' and r['originalPath'].endswith('.py'):code[(r['bytes'],r['sha256'])].append(r['originalPath'])
duplicates=[v for v in code.values() if len(v)>1];assert not duplicates
out={'status':'PROPOSED_EXACT_NISSAN_SUPPORT_SELECTION','baseManifest':e['baseManifest'],'outsideRecoveryArtifacts':e['outsideRecoveryArtifacts'],'files':rows,'externalProposal':pin(p if False else C/'NISSAN-EXTERNAL-SUPPORT-PROPOSAL-v1.json'),'localOnlyPrivateSeedInputPins':e['localOnlyPrivateSeedInputPins'],'privateSeedInputPayloadsSelected':False,'newExecutableDuplicateGroups':duplicates,'excludedTrees':['selected-proof-sanitized-v1','selected-source-changes'],'reservedNamesExcluded':sorted(reserved),'finalizationRule':'Final selection preserves these rows exactly and adds only this proposal and the independent acceptance receipt as exact fresh metadata rows. Its review field points to that receipt. No code or archive bytes may change.'}
dump(C/'SUPPORT-SELECTION-PROPOSAL-v1.json',out)
print(json.dumps({'proposal':pin(C/'SUPPORT-SELECTION-PROPOSAL-v1.json'),'selectedRows':len(rows),'freshRows':sum(r['action']=='fresh' for r in rows),'reuseRows':sum(r['action']=='reuse' for r in rows),'freshBytes':sum(r['bytes'] for r in rows if r['action']=='fresh')}))
