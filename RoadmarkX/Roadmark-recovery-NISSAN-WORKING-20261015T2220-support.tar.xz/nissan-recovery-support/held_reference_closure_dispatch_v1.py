import pathlib,json,hashlib,subprocess
C=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220');p=C/'INDEPENDENT-NISSAN-REFERENCE-CLOSURE-V3-INVOCATION-REVIEW-v1.json';assert hashlib.sha256(p.read_bytes()).hexdigest()=='03caa0169be850131e8eb227c95714342fe4c8afba10f78ec6356098a0be782f';x=json.loads(p.read_text());assert not pathlib.Path(x['argv'][2]).exists()
with pathlib.Path(x['stdout']).open('xb') as out,pathlib.Path(x['stderr']).open('xb') as err:r=subprocess.run(x['argv'],stdout=out,stderr=err)
print(json.dumps({'exitCode':r.returncode,'terminal':json.loads(pathlib.Path(x['argv'][2]).read_text()),'stdout':pathlib.Path(x['stdout']).read_text(),'stderr':pathlib.Path(x['stderr']).read_text()}));raise SystemExit(r.returncode)
