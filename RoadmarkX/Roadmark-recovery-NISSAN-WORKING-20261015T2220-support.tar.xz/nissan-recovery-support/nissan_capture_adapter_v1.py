#!/usr/bin/env python3
"""Nissan immutable exact-reference loader; no capture is performed by import."""
import ast,hashlib,json,pathlib,sys,types,stat
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent;B=C.parent/'renault-working-20261015T2040';R=C.parents[1]
CAPTURE_PIN={'bytes': 8185, 'sha256': '60127a3b7ff24d9e5ed30b6a2980db55d93104810581cc07e771cb79c9bb676f'}
SNAPSHOT_PIN={'bytes': 10384, 'sha256': 'cf321c73428059b8b4c2d69b284392a5e9e4c1f6238475ef10ab75a46e5c20a7'}
def exact_bytes(path,want):
 p=P(path);z=p.lstat();assert stat.S_ISREG(z.st_mode) and not any(q.is_symlink() for q in p.parents);before=(z.st_size,z.st_mtime_ns,z.st_ctime_ns,z.st_ino,z.st_dev);b=p.read_bytes();z=p.lstat();assert before==(z.st_size,z.st_mtime_ns,z.st_ctime_ns,z.st_ino,z.st_dev);assert {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}==want;return b
def replace_constant(tree,old,new,expected=1,function=None):
 roots=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==function] if function else [tree]
 if function:assert len(roots)==1
 matches=[n for root in roots for n in ast.walk(root) if isinstance(n,ast.Constant) and type(n.value) is type(old) and n.value==old]
 assert len(matches)==expected,(old,len(matches),expected)
 for n in matches:n.value=new
 return tree
def load_reference(name,path,want,transform=None):
 tree=ast.parse(exact_bytes(path,want),filename=str(path));tree=transform(tree) if transform else tree;ast.fix_missing_locations(tree)
 m=types.ModuleType(name);m.__file__=str(path);sys.modules[name]=m;exec(compile(tree,str(path),'exec'),m.__dict__);return m
def capture_transform(tree):
 for old,new in ((7,6),(697,700),(700,703)):replace_constant(tree,old,new,function='source')
 replace_constant(tree,'deliverables/Roadmark-RECOVERY-MANIFEST-CUPRA-WORKING-20261015.json','deliverables/Roadmark-RECOVERY-MANIFEST-RENAULT-WORKING-20261015.json',function='proof')
 return tree
def capture_module():
 exact_bytes(R/'snapshot_recovery_v2.py',SNAPSHOT_PIN)
 m=load_reference('capture_v1',B/'capture_v1.py',CAPTURE_PIN,capture_transform);m.C=C;m.BASE=B
 scope=json.loads((C/'FROZEN-CAPTURE-SCOPE.json').read_text());frozen={r['path']:r for r in scope['files']};old_check=m.check
 def frozen_check(path,expected):
  p=P(path);r=frozen.get(str(p))
  if r:assert m.identity(p)==r['stableIdentityAtPreparation'] and p.lstat().st_mode==r['mode'],str(p)+' frozen identity'
  return old_check(p,expected)
 m.check=frozen_check
 return m
