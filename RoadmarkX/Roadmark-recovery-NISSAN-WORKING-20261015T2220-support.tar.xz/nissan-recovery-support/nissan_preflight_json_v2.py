#!/usr/bin/env python3
"""Exact Nissan JSON/header preflight; discovery only, no seed reads or sanitized copy."""
from nissan_capture_adapter_v2 import B,capture_module,load_reference
if __name__=='__main__':
 capture_module()
 load_reference('nissan_json_preflight_reference',B/'preflight_json_v1.py',{'bytes': 1157, 'sha256': 'db669840e3e4b7f56a9d8b14a9523b179d93a778fba9cb7fc10f90007f2ea4dd'}).main()
