"""Bounded-memory .lower().find() adapter for the scanner's ASCII needles.
No regex windows are split. Returned offsets are in the lowered string, as before.
"""
import bisect,collections
class ChunkedLower:
 def __init__(self,text,block_chars=262144):
  self.text=text;self.block_chars=block_chars;self.starts=[0];self.cache=collections.OrderedDict()
  for i in range(0,len(text),block_chars):self.starts.append(self.starts[-1]+len(text[i:i+block_chars].lower()))
 def block(self,i):
  if i not in self.cache:
   self.cache[i]=self.text[i*self.block_chars:(i+1)*self.block_chars].lower()
   while len(self.cache)>2:self.cache.popitem(last=False)
  self.cache.move_to_end(i);return self.cache[i]
 def __contains__(self,needle):
  return self.find(needle)>=0
 def find(self,needle,start=0):
  assert needle and needle.isascii() and needle==needle.lower() and len(needle)<self.block_chars
  n=self.starts[-1];start=max(0,start if start>=0 else n+start)
  if start>=n:return -1
  i=bisect.bisect_right(self.starts,start)-1
  while i<len(self.starts)-1:
   b=self.block(i);x=b+(self.block(i+1)[:len(needle)-1] if i+1<len(self.starts)-1 else '')
   pos=x.find(needle,max(0,start-self.starts[i]))
   if 0<=pos<len(b):return self.starts[i]+pos
   i+=1;start=self.starts[i]
  return -1
