#!/usr/bin/env python3
"""Read-only final residual audit. Values and token digests stay in process memory."""
import gc,ctypes
from chunked_lower_find import ChunkedLower
import argparse,base64,collections,datetime,hashlib,html,importlib.util,json,pathlib,re,tarfile,urllib.parse
OUT=pathlib.Path(__file__).resolve().parent

def load(name):return json.loads((OUT/name).read_text())
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def source_values():
 inv=load('inventory.json');prior=load('scan-report.json');extra=load('confirmed-extra-redactions.json');runtime=load('runtime-token-report.json')
 known={};benign=set();seed_members=0;errors=[]
 for a in inv:
  ps={f['member'] for f in prior['findings'] if f['archive']==a['filename']}
  es=[f for f in extra if f['archive']==a['filename']]
  rs=[f for f in runtime['candidates'] if f['archive']==a['filename'] and f['layer']=='plain']
  paths=ps|{f['member'] for f in es}|{f['member'] for f in rs}
  if not paths:continue
  with tarfile.open(a['path'],'r:xz') as t:
   for m in t:
    if not m.isfile() or m.name not in paths:continue
    seed_members+=1;b=t.extractfile(m).read();s=b.decode('utf8',errors='replace')
    def add(v,field):
     if not v or re.fullmatch(rb'\[REDACTED[^\]]*\]',v,re.I):return
     loc={'archive':a['filename'],'library_file_id':a['library_file_id'],'member':m.name,'field':field}
     if loc not in known.setdefault(v,[]):known[v].append(loc)
    if m.name in ps:
     for mt in re.finditer(rb'(?mi)^set-cookie:\s*([^=;\s]+)=([^;\r\n]*)',b):add(mt.group(2),'cookie.'+mt.group(1).decode('ascii',errors='replace'))
     for mt in re.finditer(rb'''\bdd\s*=\s*\{([^{}]+)\}''',b):
      for f in re.finditer(rb'''(?:^|,)\s*['"]?(cid|e|cookie)['"]?\s*:\s*(['"])(.*?)\2''',mt.group(1)):add(f.group(3),'dd.'+f.group(1).decode())
    for f in es:
     if f['member']==m.name:add(b[f['byteStart']:f['byteEndExclusive']],f['field'])
    for f in rs:
     if f['member']==m.name:benign.add(s[f['valueCharStart']:f['valueCharEnd']])
 for v in known:
  try:benign.discard(v.decode())
  except UnicodeDecodeError:pass
 return known,benign,seed_members,errors

def variants_for(known):
 out={}
 def add(b,label,src):
  if b not in out:out[b]={'encoding':label,'sourceFields':src}
 for v,src in known.items():
  add(v,'literal',src)
  add(urllib.parse.quote_from_bytes(v,safe='').encode(),'url-component',src)
  add(base64.b64encode(v),'base64-standalone-value',src)
  add(base64.urlsafe_b64encode(v),'base64url-standalone-value',src)
  add(base64.b64encode(v).rstrip(b'='),'base64-unpadded-standalone-value',src)
  add(base64.urlsafe_b64encode(v).rstrip(b'='),'base64url-unpadded-standalone-value',src)
  try:s=v.decode('utf8')
  except UnicodeDecodeError:continue
  add(s.encode('utf-16-le'),'utf16le',src);add(s.encode('utf-16-be'),'utf16be',src)
  add(json.dumps(s,ensure_ascii=True)[1:-1].encode(),'json-escaped',src)
  add(html.escape(s,quote=True).encode(),'html-entity-escaped',src)
  add(''.join('\\u%04x'%ord(c) for c in s).encode(),'unicode-escapes-lower',src)
  add(''.join('\\u%04X'%ord(c) for c in s).encode(),'unicode-escapes-upper',src)
 return out

def patterns():
 spec=importlib.util.spec_from_file_location('audit_primary',OUT/'audit_scan.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 mod.ChunkedLower=ChunkedLower
 primary_code=(OUT/'audit_scan.py').read_text()
 assert primary_code.count('low=s.lower()')==1
 primary_code=primary_code.replace('low=s.lower()','low=ChunkedLower(s)')
 exec(compile(primary_code,str(OUT/'audit_scan.py'),'exec'),mod.__dict__)
 scope={'__file__':str(OUT/'runtime_token_scan.py'),'__name__':'audit_runtime','ChunkedLower':ChunkedLower}
 code=(OUT/'runtime_token_scan.py').read_text().split('\nfor i,a in enumerate(inv,1):',1)[0]
 assert code.count('low=s.lower();ranges=[]')==1
 code=code.replace('low=s.lower();ranges=[]','low=ChunkedLower(s);ranges=[]')
 exec(compile(code,str(OUT/'runtime_token_scan.py'),'exec'),scope)
 return mod.scan_bytes,scope['scan']

def payloads(args):
 if args.tree:
  root=pathlib.Path(args.tree).resolve()
  for p in sorted(root.rglob('*')):
   if p.is_symlink():yield {'member':str(p.relative_to(root))},None,'symlink-not-followed'
   elif p.is_file():yield {'member':str(p.relative_to(root))},p.read_bytes(),None
 if args.replacements:
  r=json.loads(pathlib.Path(args.replacements).read_text())
  for a in r['replacements']:
   path=pathlib.Path(a['replacementPath'])
   with tarfile.open(path,'r:*') as t:
    for m in t:
     if not m.isfile():yield {'archive':path.name,'member':m.name},None,'non-regular-member';continue
     yield {'archive':path.name,'member':m.name},t.extractfile(m).read(),None
 for name in args.archive:
  path=pathlib.Path(name)
  with tarfile.open(path,'r:*') as t:
   for m in t:
    if m.isfile():yield {'archive':path.name,'member':m.name},t.extractfile(m).read(),None
    else:yield {'archive':path.name,'member':m.name},None,'non-regular-member'

def release_memory():
 gc.collect()
 try:ctypes.CDLL(None).malloc_trim(0)
 except (AttributeError,OSError):pass

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--tree');ap.add_argument('--replacements');ap.add_argument('--archive',action='append',default=[]);ap.add_argument('--report',required=True);ap.add_argument('--no-patterns',action='store_true');args=ap.parse_args()
 if not (args.tree or args.replacements or args.archive):ap.error('Specify --tree, --replacements, or --archive')
 if args.tree and not pathlib.Path(args.tree).is_dir():ap.error('--tree must be an existing directory')
 destination=pathlib.Path(args.report).resolve()
 if not destination.is_relative_to(OUT):ap.error('Report path must stay inside the audit directory')
 known,benign,seed_count,errors=source_values();variants=variants_for(known)
 primary,runtime=(None,None) if args.no_patterns else patterns();release_memory()
 report={'startedAt':now(),'knownDistinctCapturedValues':len(known),'testedDistinctByteVariants':len(variants),'originalSeedMembersRead':seed_count,'regularFilesScanned':0,'bytesScanned':0,'uniquePayloadsScanned':0,'exactValueMatches':[],'primaryHeaderCandidates':[],'unclassifiedRuntimeCandidates':[],'recognizedBenignRuntimeCandidateCount':0,'errors':errors,'coverage':{'byteSearch':'Every regular payload, regardless of extension','encodings':['literal','URL component','base64/base64url standalone value, padded and unpadded','UTF-16LE/BE','JSON string escaping','HTML entity escaping','full Unicode-escaped value in lower/upper hex'],'patternSearch':'Primary nested-JSON/raw-header scanner and runtime HTML meta/input/property scanner with entity decoding and up to three nested escape levels','limitations':['Does not decrypt encrypted content','Does not recursively unpack arbitrary compressed or proprietary content inside regular payloads','Standalone base64 matching is not a claim to inspect every possible base64 wrapping/alignment of a larger structure']}}
 cache={}
 for loc,b,error in payloads(args):
  print(json.dumps({'stage':'payload-start',**loc,'bytes':len(b) if b is not None else None}),flush=True)
  if error:report['errors'].append({**loc,'error':error});continue
  report['regularFilesScanned']+=1;report['bytesScanned']+=len(b);digest=hashlib.sha256(b).digest()
  if digest not in cache:
   xs=[];seen=set()
   for value,info in variants.items():
    start=0
    while True:
     start=b.find(value,start)
     if start<0:break
     key=(start,start+len(value))
     if key not in seen:
      seen.add(key);xs.append({'byteStart':start,'byteEndExclusive':start+len(value),'line':b.count(b'\n',0,start)+1,**info})
     start+=len(value)
   ps=[];us=[];benign_count=0
   if primary:
    ps,_,_=primary(b,loc['member']);release_memory()
    print(json.dumps({'stage':'primary-complete',**loc}),flush=True)
    if b.startswith((b'\xff\xfe',b'\xfe\xff')):s=b.decode('utf-16',errors='replace')
    elif b[:1024].count(b'\x00')>len(b[:1024])//5:s=None
    else:s=b.decode('utf8',errors='replace')
    if s is not None:
     runtime_candidates=runtime(s)
     for f in runtime_candidates:
      if f['layer']=='plain':
       v=s[f['valueCharStart']:f['valueCharEnd']]
       if v in benign:benign_count+=1;continue
      elif any(g['layer']=='plain' and g['field']==f['field'] for g in runtime_candidates):
       # Decoded duplicate candidates are reported only if they have no plain counterpart.
       continue
      us.append(f)
   cache[digest]=(xs,ps,us,benign_count)
  xs,ps,us,bcount=cache[digest]
  report['exactValueMatches'].extend({**loc,**x} for x in xs)
  report['primaryHeaderCandidates'].extend({**loc,**x} for x in ps)
  report['unclassifiedRuntimeCandidates'].extend({**loc,**x} for x in us)
  report['recognizedBenignRuntimeCandidateCount']+=bcount
  if 's' in locals():del s
  del b
  release_memory()
 report['uniquePayloadsScanned']=len(cache);report['completedAt']=now()
 if not report['regularFilesScanned']:report['errors'].append({'error':'no-regular-payloads-scanned'})
 report['status']='clean' if not any(report[k] for k in ['exactValueMatches','primaryHeaderCandidates','unclassifiedRuntimeCandidates','errors']) else 'review-required'
 destination.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:report[k] for k in ['status','regularFilesScanned','bytesScanned','uniquePayloadsScanned','knownDistinctCapturedValues','testedDistinctByteVariants']}|{'exactValueMatchCount':len(report['exactValueMatches']),'primaryHeaderCandidateCount':len(report['primaryHeaderCandidates']),'unclassifiedRuntimeCandidateCount':len(report['unclassifiedRuntimeCandidates']),'errorCount':len(report['errors']),'report':str(destination)}))
if __name__=='__main__':main()
