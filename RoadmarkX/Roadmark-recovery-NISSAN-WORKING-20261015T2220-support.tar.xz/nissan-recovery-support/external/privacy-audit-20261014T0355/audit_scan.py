#!/usr/bin/env python3
import json,re,tarfile,pathlib,hashlib,datetime,collections
BASE=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-recovery-20261014')
OUT=BASE/'privacy-audit-20261014T0355'
SENSITIVE={'x-datadome-cid','set-cookie','cookie','authorization','proxy-authorization','x-api-key','api-key','x-auth-token','x-access-token','access-token','x-csrf-token','x-xsrf-token','x-session-token','authentication-info','proxy-authentication-info'}
GENERIC={'access_token','refresh_token','id_token','auth_token','session_token','client_secret','api_key','apikey','password','token','cookies'}
KEYS='|'.join(re.escape(x) for x in sorted(SENSITIVE,key=len,reverse=True))
RAW=re.compile(r'(?mi)^(?P<prefix>[ \t]*(?:[<>][ \t]*)?)(?P<key>'+KEYS+r')(?P<sep>[ \t]*:[ \t]*)(?P<value>[^\r\n]*)')
QUOTED=re.compile(r'(?i)(["\'])('+KEYS+r')\1\s*:\s*("(?:[^"\\]|\\.)*"|\'(?:[^\'\\]|\\.)*\')')
TOKEN_MARKERS=re.compile(rb'(?i)(?:set-cookie|authorization|x-api-key|api[_-]key|access[_-]token|refresh[_-]token|client[_-]secret|x-csrf-token|x-xsrf-token|cookie\s*:)')
SAFE=re.compile(r'\[REDACTED[^\]]*\]',re.I)
PLACEHOLDER=re.compile(r'^(?:null|none|undefined|false|true|your[-_ ].*|example.*|test|dummy|token|secret|password|cookie|bearer|basic|\.\.\.|\$\{.*\}|\{\{.*\}\})$',re.I)
def sha(b):return hashlib.sha256(b).hexdigest()
def safe(v):return not v or bool(SAFE.fullmatch(v.strip()))
def valinfo(key,v):
 info={'header':key,'valueType':type(v).__name__}
 if isinstance(v,str):
  info['valueLength']=len(v)
  if key.lower() in {'set-cookie','cookie','cookies'}:
   names=[]
   for c in re.finditer(r'(?:^|[,;]\s*)([!#$%&\'*+.^_`|~0-9A-Za-z-]+)=',v):
    name=c.group(1)
    if name.lower() not in {'expires','max-age','domain','path','samesite','priority'} and name not in names:names.append(name)
   if names:info['cookieNames']=names
   domains=re.findall(r'(?i)(?:^|;)\s*domain=([.a-z0-9-]+)',v)
   if domains:info['cookieDomains']=sorted(set(domains))
   info['literalPlaceholder']=bool(PLACEHOLDER.fullmatch(v.strip()))
 return info
def pointer(k):return str(k).replace('~','~0').replace('/','~1')
def scan_bytes(data,name):
 out=[];parsed=False
 low=data.lower()
 if not any(k.encode() in low for k in SENSITIVE|GENERIC):return [],False,False
 try:text=data.decode('utf-8-sig')
 except UnicodeDecodeError:
  # Match headers in any bytes; decoding does not discard ASCII markers.
  text=data.decode('latin-1')
 def add(kind,key,v,loc,confidence='captured'):
  if isinstance(v,str) and safe(v):return
  if v in (None,[],{}):return
  if isinstance(v,(dict,list)):
   if not v:return
  inf={'kind':kind,'location':loc,'confidence':confidence,**valinfo(key,v)}
  out.append(inf)
 def scanstring(s,loc,depth=0):
  if depth>12:return
  low=s.lower()
  if not any(k in low for k in SENSITIVE|GENERIC):return
  stripped=s.lstrip()
  if stripped.startswith(('{','[')):
   try:
    o=json.loads(s)
    if isinstance(o,(dict,list)):walk(o,loc+'/$decoded',depth+1);return
   except (ValueError,TypeError):pass
  for m in RAW.finditer(s):
   v=m.group('value')
   if safe(v):continue
   add('raw-header',m.group('key'),v,{'pointer':loc,'line':s.count('\n',0,m.start())+1,'charStart':m.start('value'),'charEnd':m.end('value')})
  for m in QUOTED.finditer(s):
   try:v=json.loads(m.group(3)) if m.group(3).startswith('"') else m.group(3)[1:-1]
   except ValueError:v=m.group(3)[1:-1]
   if safe(v):continue
   add('quoted-header-literal',m.group(2),v,{'pointer':loc,'line':s.count('\n',0,m.start())+1,'charStart':m.start(3),'charEnd':m.end(3)},'needs-context')
 def walk(o,p='',depth=0):
  if depth>30:return
  if isinstance(o,dict):
   # HAR-style header name/value pairs.
   key=o.get('name')
   if isinstance(key,str) and key.lower() in SENSITIVE and 'value' in o:add('json-header-pair',key,o['value'],{'pointer':p+'/value'})
   for k,v in o.items():
    q=p+'/'+pointer(k)
    if k.lower() in SENSITIVE:
     if isinstance(v,list):
      for i,s in enumerate(v):add('json-header',k,s,{'pointer':q+'/'+str(i)})
     else:add('json-header',k,v,{'pointer':q})
    elif k.lower() in GENERIC and v not in (None,'',False,[],{}):
     add('json-sensitive-key',k,v,{'pointer':q},'needs-context')
    if isinstance(v,(dict,list)):walk(v,q,depth+1)
    elif isinstance(v,str):scanstring(v,q,depth+1)
  elif isinstance(o,list):
   for i,v in enumerate(o):walk(v,p+'/'+str(i),depth+1)
  elif isinstance(o,str):scanstring(o,p,depth+1)
 try:
  obj=json.loads(text);parsed=True;walk(obj)
 except (ValueError,TypeError,RecursionError):scanstring(text,'')
 return out,parsed, bool(TOKEN_MARKERS.search(data))
def inventory():
 d=json.loads((BASE/'RECOVERY-MANIFEST-provisional-hyundai-20261014T0316.json').read_text());a=d['archives'][:]
 new=json.loads((BASE/'hyundai-established-sanitized-delta-20261014T035107Z-snapshot.json').read_text())['archives']
 receipts=json.loads((BASE/'checkpoints/hyundai-integrated-closure-pending-20261014T0348/library-hyundai-results.json').read_text())['results']
 for r in new:
  rr=next(x for x in receipts if x['file_name']==r['filename']);a.append({**r,'library':rr})
 seen=set();out=[]
 for r in a:
  lid=r['library']['library_file_id']
  if lid in seen:continue
  seen.add(lid);out.append({'filename':r['filename'],'path':r.get('file',r.get('path')),'library_file_id':lid,'expectedSHA256':r['sha256'],'expectedBytes':r['bytes']})
 return out
if __name__=='__main__':
 inv=inventory();(OUT/'inventory.json').write_text(json.dumps(inv,indent=2)+'\n')
 report={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archiveCount':len(inv),'archives':[],'findings':[],'errors':[]}
 for i,r in enumerate(inv,1):
  b=pathlib.Path(r['path']).read_bytes();record={**r,'actualSHA256':sha(b),'actualBytes':len(b),'members':[],'candidateCount':0,'tokenMarkerMemberCount':0};record['archiveIdentityVerified']=record['actualSHA256']==r['expectedSHA256'] and len(b)==r['expectedBytes']
  with tarfile.open(r['path'],'r:xz') as t:
   for m in t:
    if not m.isfile():report['errors'].append({'archive':r['filename'],'member':m.name,'issue':'not regular file'});continue
    data=t.extractfile(m).read();fs,parsed,hasmarker=scan_bytes(data,m.name)
    record['members'].append({'path':m.name,'bytes':len(data),'sha256':sha(data),'jsonParsed':parsed,'tokenMarker':hasmarker,'candidateCount':len(fs)})
    record['tokenMarkerMemberCount']+=int(hasmarker);record['candidateCount']+=len(fs)
    for f in fs:report['findings'].append({'archive':r['filename'],'library_file_id':r['library_file_id'],'member':m.name,**f})
  report['archives'].append(record)
  (OUT/'scan-progress.json').write_text(json.dumps(report,indent=2)+'\n')
  print(json.dumps({'done':i,'total':len(inv),'archive':r['filename'],'members':len(record['members']),'candidates':record['candidateCount'],'identityVerified':record['archiveIdentityVerified']}),flush=True)
 report['completedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();(OUT/'scan-report.json').write_text(json.dumps(report,indent=2)+'\n')
 print('COMPLETE',len(report['findings']))
