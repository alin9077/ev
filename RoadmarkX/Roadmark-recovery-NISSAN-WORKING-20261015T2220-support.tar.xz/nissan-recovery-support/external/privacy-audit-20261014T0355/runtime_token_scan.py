import re,json,tarfile,pathlib,hashlib,datetime,collections,html
OUT=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/privacy-audit-20261014T0355');inv=json.loads((OUT/'inventory.json').read_text())
K=r'(?:_?token|_?csrf(?:[-_]?token)?|_?xsrf(?:[-_]?token)?|authenticity_token|__RequestVerificationToken|_?nonce|_wpnonce|_ajax_nonce|(?:access|refresh|id|auth)[-_]?token|client[-_]?secret|session(?:[-_]?(?:id|token|key))?|sessid|anonymous[-_]?id|visitor[-_]?id|client[-_]?id|api[-_]?key|PHPSESSID|JSESSIONID|ASP\.NET_SessionId|laravel_session|connect\.sid)'
KEY=re.compile(r'^(?:'+K+r')$',re.I)
PROP=re.compile(r'(?P<key>\b'+K+r'\b)["\']?\s*[:=]\s*(?P<q>["\'])(?P<val>(?:\\.|(?!(?P=q))[^\\]){0,8192}?)(?P=q)',re.I)
TAG=re.compile(r'<(?P<tag>meta|input)\b[^<>]{0,8192}>',re.I)
ATTR=re.compile(r'''(?P<key>[A-Za-z_:][A-Za-z0-9_:.-]*)\s*=\s*(?:"(?P<d>[^"<>]*)"|'(?P<s>[^'<>]*)'|(?P<u>[^\s>]+))''')
SAFE=re.compile(r'^(?:\[REDACTED[^\]]*\]|null|undefined|none|false|true|test|example.*|dummy.*|your.*|\$.*|\{\{.*|<.*|\s*)$',re.I)
markers=['token','secret','sess','nonce','cookie','datadome','authorization','apikey','api_key','api-key','csrf','xsrf','clientid','client_id','client-id','visitor','anonymous']
cache={};report={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archives':[],'candidates':[],'errors':[]}
def scan(s):
 result=[];seen=set();low=s.lower();ranges=[]
 for needle in markers:
  pos=0
  while True:
   pos=low.find(needle,pos)
   if pos<0:break
   ranges.append((max(0,pos-1024),min(len(s),pos+12288)));pos+=len(needle)
 # Fully escaped field names are also checked, even with no literal marker.
 for needle in ['\\u00','\\x','&#','eyJ']:
  if needle=='eyJ':continue
  pos=0
  while True:
   pos=s.find(needle,pos)
   if pos<0:break
   ranges.append((max(0,pos-1024),min(len(s),pos+12288)));pos+=len(needle)
 merged=[]
 for a,b in sorted(ranges):
  if merged and a<=merged[-1][1]:merged[-1]=(merged[-1][0],max(b,merged[-1][1]))
  else:merged.append((a,b))
 def add(kind,key,value,start,end,layer,offset):
  if SAFE.fullmatch(value.strip()) or len(value)<8:return
  loc=(kind,key,start,end,layer,offset)
  if loc in seen:return
  seen.add(loc)
  if layer=='plain':start+=offset;end+=offset;line=s.count('\n',0,start)+1
  else:line=None
  row={'kind':kind,'field':key,'valueLength':len(value),'layer':layer,'line':line,'valueCharStart':start,'valueCharEnd':end,'sourceWindowStart':offset,'valueIsAlphanumeric':value.isalnum(),'valueIsUUID':bool(re.fullmatch(r'[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}',value,re.I)),'hasTemplateSyntax':bool(re.search(r'\$\{|\{\{|<%|\s\+\s',value))}
  result.append(row)
 def run(x,layer,offset):
  for m in PROP.finditer(x):add('literal-runtime-property',m.group('key'),m.group('val'),m.start('val'),m.end('val'),layer,offset)
  for m in TAG.finditer(x):
   attrs={}
   for am in ATTR.finditer(m.group(0)):
    vn=next(k for k in ['d','s','u'] if am.group(k) is not None);attrs[am.group('key').lower()]=(am.group(vn),m.start()+am.start(vn),m.start()+am.end(vn))
   key=attrs.get('name',attrs.get('id',('',0,0)))[0]
   target='content' if m.group('tag').lower()=='meta' else 'value'
   if (KEY.fullmatch(key) or re.search('csrf|xsrf|token|nonce|session',key,re.I)) and target in attrs:
    value,start,end=attrs[target];add('html-'+m.group('tag').lower(),key,value,start,end,layer,offset)
 for start,end in merged:
  x=s[start:end];run(x,'plain',start)
  if '&quot;' in x or '&#' in x:run(html.unescape(x),'html-entities',start)
  for level in range(1,4):
   y=re.sub(r'\\u([0-9a-fA-F]{4})|\\x([0-9a-fA-F]{2})',lambda m:chr(int(m.group(1) or m.group(2),16)),x)
   y=y.replace('\\"','"').replace("\\'","'").replace('\\n','\n').replace('\\r','\r').replace('\\t','\t').replace('\\\\','\\')
   if y==x:break
   run(y,'escaped-level-'+str(level),start);x=y
 return result
for i,a in enumerate(inv,1):
 n=0
 try:
  with tarfile.open(a['path'],'r:xz') as t:
   for m in t:
    if not m.isfile():continue
    n+=1;b=t.extractfile(m).read();digest=hashlib.sha256(b).digest()
    if digest not in cache:
     if b.startswith((b'\xff\xfe',b'\xfe\xff')):s=b.decode('utf-16',errors='replace')
     elif b[:1024].count(b'\x00')>len(b[:1024])//5:cache[digest]=[];continue
     else:s=b.decode('utf-8',errors='replace')
     cache[digest]=scan(s)
    for f in cache[digest]:report['candidates'].append({'archive':a['filename'],'library_file_id':a['library_file_id'],'member':m.name,**f})
  report['archives'].append({'archive':a['filename'],'members':n})
 except Exception as e:report['errors'].append({'archive':a['filename'],'errorType':type(e).__name__})
 (OUT/'runtime-token-progress.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'done':i,'archive':a['filename'],'candidates':len(report['candidates'])}),flush=True)
report['completedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();report['uniquePayloadCount']=len(cache)
(OUT/'runtime-token-report.json').write_text(json.dumps(report,indent=2)+'\n');print('COMPLETE')
