#!/usr/bin/env python3
"""Nissan delivery metadata with exact prior normalizer reuse and explicit readback limitation."""
import datetime,json,pathlib,sys
from nissan_capture_adapter_v2 import C,B,R,capture_module,load_reference
cap=capture_module();P=pathlib.Path;load=cap.load;dump=cap.dump;pin=cap.pin;check=cap.check;identity=cap.identity
D=C/'deliverables';DATE='20261015';SCOPE='DOCUMENT_CONTENT_AND_SERVER_CREATE_IDENTITY_ONLY'
NORMALIZER_PIN={'bytes':12641,'sha256':'f5bec06d762fca6b3d34ea13f7e7f17d2f5353dbbd379a5e1b13e967aabbc474'}
BASE_FINAL={'bytes':195133,'sha256':'1548c59e11ab2f9d1970348a8cdff91e19500496ad50c06c41e3f43e881bb44c'}
BASE_TERMINAL={'bytes':16973,'sha256':'60afb83a27b9c14fe5b00b9e2a6d965a375f4eebfa0a9ac134f3ff84e2ee4ef2'}
NOTE='Local recovery replay passed. Library persistence is confirmed by server create receipts and matching local hashes. Native byte-readback remains unpassed after the inherited Library selected-folder 403 access boundary; no Nissan readback request or alternative read route was attempted.'
STATUS='LOCAL_RECOVERY_VERIFIED_SERVER_CREATE_CONFIRMED_NATIVE_READBACK_UNPASSED_RELEASE_UNPASSED'
def ref(p):return {'path':str(p),**pin(p)}
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def require_contract():
 p=C/'NISSAN-DELIVERY-CONTRACT-v3.json';d=load(p);assert d['result']=='ACCEPTED_EXACT_NISSAN_DELIVERY_ADAPTER'
 check(P(__file__).resolve(),d['helper']);check(P(d['independentReview']['path']),d['independentReview']);check(B/'delivery_native_adapter_v3.py',NORMALIZER_PIN)
 assert d['nativeByteReadbackVerified'] is False and d['currentMaterializeAttempts']==0
 return ref(p)
def base():
 check(B/'FINAL-RENAULT-UPLOAD-RECEIPTS.json',BASE_FINAL);check(B/'INDEPENDENT-RENAULT-TERMINAL-CLOSURE-v1.json',BASE_TERMINAL)
 d=load(B/'FINAL-RENAULT-UPLOAD-RECEIPTS.json');t=load(B/'INDEPENDENT-RENAULT-TERMINAL-CLOSURE-v1.json');assert d['nativeByteReadbackVerified'] is False and t['nativeByteReadbackVerified'] is False and d['counts']['archiveCount']==142
 return d

def denied():
 d=base();e=d['blockedReadbackEvidence'];check(P(e['request']['path']),e['request']);check(P(e['response']['path']),e['response']);raw=load(P(e['response']['path']))
 assert raw['isError'] is True and raw['structuredContent']['error_code']=='FORBIDDEN' and '403' in raw['structuredContent']['error'] and 'scope_violation' in raw['structuredContent']['error']
 return {'inheritedRenaultReadbackDenial':e,'inheritedFinalReceipt':ref(B/'FINAL-RENAULT-UPLOAD-RECEIPTS.json'),'scope':'The historical denial was for the five Renault archive identities in its exact request. No Nissan identity is claimed individually attempted or denied.','currentNissanMaterializationAttempts':0,'currentNissanAlternateReadRoutes':0,'deniedRouteRetried':False}
def supplements():
 d=base();return {'verification':d['supplementalDeliveryVerificationArtifact'],'correction':d['deliveryCorrection']['artifact'],'outsideCurrentRecoveryArchiveSet':True,'notNewNissanArchives':True,'nativeByteReadbackVerified':False}
def qualify(d):
 d.update({'nativePersistenceStatus':'CREATE_CONFIRMED_NATIVE_BYTE_READBACK_UNPASSED','nativeByteReadbackVerified':False,'deliveryVerificationAcceptanceScope':SCOPE,'nativePersistenceLimitation':NOTE,'blockedReadbackEvidence':denied(),'referencedPriorDeliveryArtifactsOutsideRecovery':supplements(),'deliveryAdapter':ref(P(__file__).resolve()),'deliveryContract':ref(C/'NISSAN-DELIVERY-CONTRACT-v3.json'),'priorNormalizer':{'path':str(B/'delivery_native_adapter_v3.py'),**NORMALIZER_PIN},'fullProjectTypeScriptPassed':False,'releaseReady':False})
 return d

def normalize(phase):
 require_contract();assert phase in ('archives','documents','active')
 m=load_reference('nissan_prior_native_normalizer',B/'delivery_native_adapter_v3.py',NORMALIZER_PIN)
 m.C=C;m.D=D;m.NOTE=NOTE;m.denied=denied
 original_dump=m.dump
 def truthful_dump(path,data):
  path=P(path)
  if path.name.endswith('-NATIVE-READBACK-v1.json'):
   data['status']='NOT_ATTEMPTED_INHERITED_DENIED_SCOPE_BOUNDARY';data['nativeMaterializationAttemptsForThisPhase']=0
  if isinstance(data,dict):
   data['currentNissanMaterializationAttempts']=0;data['nativeByteReadbackVerified']=False;data['currentDeliveryAdapter']=ref(P(__file__).resolve());data['currentDeliveryContract']=ref(C/'NISSAN-DELIVERY-CONTRACT-v3.json')
  original_dump(path,data)
 m.dump=truthful_dump;m.normalize(phase)

def identities(prefix):
 p=C/f'{prefix}-UPLOAD-IDENTITIES.json';d=load(p);assert d['nativeByteReadbackVerified'] is False and d['acceptanceScope']==SCOPE
 rows=d['files'];assert len({r['filename'] for r in rows})==len(rows)==len({r['library_file_id'] for r in rows})
 for r in rows:
  check(P(r['localPath']),r);assert r['nativeByteReadbackVerified'] is False and r['providerCreateConfirmed'] and r['localBytesVerified'] and r['verificationBasis']=='EXACT_SERVER_CREATE_TUPLE_AND_LOCAL_HASH'
 return rows

def scans():
 plan=load(C/'ARCHIVE-PLAN-v2.json');want={a['filename']:a for a in plan['archives']};out=[];seen=set()
 for p in sorted(C.glob('scan-fresh-*.json')):
  if '.resources.' in p.name:continue
  d=load(p)
  if 'regularFilesScanned' not in d:continue
  a=want[d['archive']];assert d['archive'] not in seen;seen.add(d['archive']);assert d['status']=='clean' and d['archivePin']=={k:a[k] for k in ('bytes','sha256')} and d['regularFilesScanned']==a['members']
  assert not any(d[k] for k in ('exactValueMatches','primaryHeaderCandidates','unclassifiedRuntimeCandidates','errors'))
  tp=p.with_name(p.stem+'.resources.json');ip=p.with_name(p.stem+'.resources.invocation.json');t=load(tp);i=load(ip)
  assert t['exitCode']==0 and not t['timedOut'] and t['command']==i['command'] and t['childPid']==i['childPid'] and t['startedAt']==i['startedAt']
  assert t['addressSpaceLimitBytes']==i['addressSpaceLimitBytes']==268435456 and t['wallLimitSeconds']==i['wallLimitSeconds']==600
  assert a['file'] in t['command'] and str(p) in t['command'];out.append({'report':ref(p),'archive':a['filename'],'archivePin':d['archivePin'],'terminal':ref(tp),'invocation':ref(ip)})
 assert seen==set(want);return out

def retained_records(selection):
 s=load(selection);rows=s['files'];assert len({r['localPath'] for r in rows})==len(rows);out=[]
 for r in rows:
  p=P(r['localPath']);assert p.suffix in ('.json','.jsonl','.txt','.log','.md') and p.is_relative_to(C),str(p)
  check(p,r);before=identity(p);b=p.read_bytes();assert identity(p)==before and {'bytes':len(b),'sha256':cap.sha(b)}=={k:r[k] for k in ('bytes','sha256')};out.append({'file':ref(p),'utf8':b.decode('utf8')})
 return out

def bound_plan():
 p=load(C/'RESTORE-PLAN-v2.json');ids={r['filename']:r for r in identities('ARCHIVE')};assert set(ids)=={a['filename'] for a in p['newArchives']}
 def bind(a):
  if a['filename'] not in ids:return dict(a)
  r=ids[a['filename']];assert (a['bytes'],a['sha256'])==(r['bytes'],r['sha256']);return {**a,**{k:r[k] for k in ('library_file_id','file_id','version')}}
 return {**p,'source':bind(p['source']),'newArchives':[bind(a) for a in p['newArchives']],'archivesInRestoreOrder':[bind(a) for a in p['archivesInRestoreOrder']]}
def counts(p):return {k:p[k] for k in ('archiveCount','logicalFiles','logicalBytes','freshFiles','freshBytes','fullSourceFiles','sourceArchiveMembers','baseArchivesReused')}
def docpaths():return [D/f'Roadmark-RECOVERY-MANIFEST-NISSAN-WORKING-{DATE}.json',D/f'Roadmark-RECOVERY-VERIFICATION-NISSAN-WORKING-{DATE}.json',D/f'Roadmark-RECOVERY-INDEX-NISSAN-WORKING-{DATE}.md',D/f'Roadmark-NISSAN-M1-UPDATE-{DATE}.md']
def docs():
 require_contract();targets=docpaths();assert not any(p.exists() for p in targets);D.mkdir(exist_ok=True)
 p=bound_plan();s=load(C/'FROZEN-CAPTURE-SCOPE.json');b=base();ind=load(C/'INDEPENDENT-NISSAN-RECOVERY-VERIFICATION-v1.json');assert ind['result']=='PASS_INDEPENDENT_NISSAN_FRESH_RECOVERY'
 privacy=scans();closure=load(C/'INDEPENDENT-NISSAN-REFERENCE-CLOSURE-v2.json');assert closure['result']=='PASS_EXACT_METADATA_ONLY_REFERENCE_CLOSURE'
 inherited=closure['inheritedDependencyProposal'];dep=inherited['dependencies']
 manifest=qualify({'schemaVersion':11,'createdAt':stamp(),'title':'Roadmark Nissan31 working recovery','status':STATUS,'workState':s['workingResult'],'source':{k:v for k,v in p['source'].items() if k!='memberFiles'},'baseRecovery':{'label':'Renault30','sourceLibraryFileId':b['sourceLibraryFileId'],'manifestLibraryFileId':b['manifestLibraryFileId'],'activeReceiptLibraryFileId':b['activeReceiptLibraryFileId'],'manifest':p['baseManifest'],'finalReceipt':p['baseFinalReceipt'],'terminalReceipt':p['baseTerminalReceipt'],'priorCounts':b['counts'],'nativeByteReadbackVerified':False},'archivesInRestoreOrder':p['archivesInRestoreOrder'],'newArchives':[{k:v for k,v in a.items() if k!='memberFiles'} for a in p['newArchives']],'files':p['files'],'counts':counts(p),'currentValidation':s['currentValidation'],'captureScope':ref(C/'FROZEN-CAPTURE-SCOPE.json'),'copyOnlySanitation':load(C/'COPY-SANITATION-MAPPING.json'),'independentVerification':ref(C/'INDEPENDENT-NISSAN-RECOVERY-VERIFICATION-v1.json'),'privacyVerification':privacy,'currentImageProvenance':load(C/'IMAGE-PROVENANCE.json'),'currentRawRuntimeExclusion':s['rawRuntimeExclusion'],'dependencyClosure':ref(C/'INDEPENDENT-NISSAN-REFERENCE-CLOSURE-v2.json'),'inheritedDependencyReconstruction':{'receipt':ref(C/'INDEPENDENT-NISSAN-REFERENCE-CLOSURE-v2.json'),'count':len(dep),'dependencies':dep,'dependenciesCanonicalSha256':inherited['canonicalSha256'],'originalExpectedPathsAndHashesUnchanged':True},'supportInventory':ref(C/'SUPPORT-MEMBER-INVENTORY-v2.json'),'supportReuse':ref(C/'SUPPORT-REUSE-MAPPING.json'),'nativeCreateEvidenceScope':'New recovery archives at document preparation; these documents own creates are bound later in the active and final receipts.','inheritedBoundaries':load(C/'SAFETY-SAVE-PLAN-v3.json')['historicalLimitations'],'restoreInstructions':['Fetch the exact recovery archives listed in restoreOrder and verify their size and SHA-256.','Extract in that order into a clean directory. The standalone Nissan source replaces the Renault source; unchanged prior proof archives are reused.','Verify every resulting regular file against files. Project root roadmark contains703 project files plus its embedded source manifest.','Use only the exact reversible copy-only mappings for original prose receipts; preserve original expected hashes separately from stored copied hashes.','The two historical delivery-only artifacts remain outside the recovery archive count and have their own exact identities/member mappings.','Historical dependencies and compatible toolchain setup require their recorded expected pins. This recovery replay does not run the application or grant a release pass.'],'noDeletionOrReplacement':True,'noPinnedSourceOrStatusMutation':True,'noExecutableSourceTextEmbedded':True})
 dump(targets[0],manifest)
 ver=qualify({'schemaVersion':11,'createdAt':stamp(),'status':STATUS,'counts':counts(p),'independent':ind,'privacyReports':privacy,'postSealEvidence':retained_records(C/'POST-SEAL-METADATA-SELECTION-v1.json'),'postSealSelection':ref(C/'POST-SEAL-METADATA-SELECTION-v1.json'),'currentValidation':s['currentValidation'],'limitations':manifest['inheritedBoundaries'],'scope':'Exact fresh-member replay and pinned prior metadata reuse; no broad historical payload rescan or clone','nativeCreateEvidenceScope':manifest['nativeCreateEvidenceScope']})
 dump(targets[1],ver)
 lines=['# Roadmark Nissan31 working recovery','',NOTE,'',s['workingResult'],'',f"Source: {p['source']['filename']} ({p['source']['bytes']:,} bytes; SHA-256 {p['source']['sha256']})",f"Restore set: {p['archiveCount']} archives, {p['logicalFiles']:,} logical files, {p['freshFiles']:,} fresh verified members; {p['baseArchivesReused']} prior archives reused.",'','## Restore','']+manifest['restoreInstructions']+['','## Boundaries','']+manifest['inheritedBoundaries']+['','## Archive order','']
 for a in p['archivesInRestoreOrder']:lines.append(f"{a['restoreOrder']}. {a['filename']} | {a['bytes']} bytes | SHA-256 {a['sha256']} | Library {a['library_file_id']}")
 with targets[2].open('x') as f:f.write('\n'.join(lines)+'\n')
 sr=next(r for r in load(C/'source-capture.json')['files'] if r['path']=='docs/NISSAN_M1_UPDATE.md');sp=P(sr['payloadPath']);check(sp,sr);before=identity(sp);raw=sp.read_bytes();assert identity(sp)==before and {'bytes':len(raw),'sha256':cap.sha(raw)}=={k:sr[k] for k in ('bytes','sha256')}
 with targets[3].open('x') as f:f.write(raw.decode('utf8')+'\n\n## Recovery note\n\n'+s['workingResult']+'\n\n'+NOTE+'\n')
 dump(C/'DOCUMENT-PRIVACY-SELECTION-v1.json',{'files':[{'localPath':str(x),**pin(x)} for x in targets]});print(json.dumps({'documents':4,'counts':counts(p),'nativeByteReadbackVerified':False}))

def active():
 require_contract();p=bound_plan();s=load(C/'FROZEN-CAPTURE-SCOPE.json');a=identities('ARCHIVE');d=identities('DOCUMENT');assert len(d)==4
 ic=C/'INDEPENDENT-NISSAN-DOCUMENT-CHECK-v1.json';assert load(ic)['result']=='PASS_INDEPENDENT_NISSAN_DOCUMENTS'
 out=qualify({'schemaVersion':11,'createdAt':stamp(),'status':STATUS,'sourceLibraryFileId':next(x['library_file_id'] for x in a if x['filename']==p['source']['filename']),'files':a+d,'counts':counts(p),'currentValidation':s['currentValidation'],'workingResult':s['workingResult'],'currentNissanNormalReportOutcome':'PASSED','currentNissanSavedComparatorOutcome':'PASSED','inheritedRenaultOriginalReportOutcome':'UNKNOWN','inheritedCupraInterruptedScanOutcome':'UNKNOWN','independentRecovery':ref(C/'INDEPENDENT-NISSAN-RECOVERY-VERIFICATION-v1.json'),'independentDocuments':ref(ic),'lateMetadata':retained_records(C/'ACTIVE-LATE-METADATA-SELECTION-v1.json'),'lateMetadataSelection':ref(C/'ACTIVE-LATE-METADATA-SELECTION-v1.json'),'seedReadAccountingAsOfActivePreparation':load(C/'SEED-READ-ACCOUNTING-after-docs-v1.json'),'baseContinuity':{'finalReceipt':ref(B/'FINAL-RENAULT-UPLOAD-RECEIPTS.json'),'terminalReceipt':ref(B/'INDEPENDENT-RENAULT-TERMINAL-CLOSURE-v1.json'),'archiveReuse':141,'historicalUnknownOutcomesAndUnavailableDraftDisclosuresPreserved':True},'deliveryConfirmation':ref(C/'DELIVERY-CONFIRMATION.json'),'delivery':'Exact five files accepted in the recorded parent native attachment send; active receipt is separate.','noDeletionOrReplacement':True,'noPinnedSourceOrStatusMutation':True,'noExecutableSourceTextEmbedded':True})
 target=D/f'Roadmark-RECOVERY-ACTIVE-STATE-NISSAN-WORKING-{DATE}.json';dump(target,out);dump(C/'ACTIVE-PRIVACY-SELECTION-v1.json',{'files':[{'localPath':str(target),**pin(target)}]});print(json.dumps({'activePrepared':True,'nativeByteReadbackVerified':False}))
def final():
 require_contract();p=bound_plan();a=identities('ARCHIVE');d=identities('DOCUMENT');active=identities('ACTIVE');assert len(d)==4 and len(active)==1;files=a+d+active;assert len({r['library_file_id'] for r in files})==len(files)
 by={x['filename']:x for x in files};doc=lambda kind:by[f'Roadmark-RECOVERY-{kind}-NISSAN-WORKING-{DATE}.json']['library_file_id'];delivery=load(C/'DELIVERY-CONFIRMATION.json')
 out=qualify({'schemaVersion':11,'createdAt':stamp(),'status':STATUS,'sourceLibraryFileId':by[p['source']['filename']]['library_file_id'],'archiveLibraryFileIds':[r['library_file_id'] for r in a],'indexLibraryFileId':by[f'Roadmark-RECOVERY-INDEX-NISSAN-WORKING-{DATE}.md']['library_file_id'],'manifestLibraryFileId':doc('MANIFEST'),'verificationLibraryFileId':doc('VERIFICATION'),'summaryLibraryFileId':by[f'Roadmark-NISSAN-M1-UPDATE-{DATE}.md']['library_file_id'],'activeReceiptLibraryFileId':active[0]['library_file_id'],'files':files,'counts':counts(p),'independentRecovery':ref(C/'INDEPENDENT-NISSAN-RECOVERY-VERIFICATION-v1.json'),'documentCheck':ref(C/'INDEPENDENT-NISSAN-DOCUMENT-CHECK-v1.json'),'activeCheck':ref(C/'INDEPENDENT-NISSAN-ACTIVE-CHECK-v1.json'),'seedReadAccounting':load(C/'SEED-READ-ACCOUNTING-after-active-v1.json'),'deliveryConfirmation':delivery,'deliveryConfirmationPin':ref(C/'DELIVERY-CONFIRMATION.json'),'activeSnapshotAccountingIsAsOfPreparation':True,'noDeletionOrReplacement':True,'noPinnedSourceOrStatusMutation':True,'noExecutableSourceTextEmbedded':True})
 dump(C/'FINAL-NISSAN-UPLOAD-RECEIPTS.json',out);print(json.dumps({'finalPrepared':True,'createConfirmedFiles':len(files),'nativeByteReadbackVerified':False}))
if __name__=='__main__':
 if sys.argv[1]=='normalize':normalize(sys.argv[2])
 else:{'docs':docs,'active':active,'final':final}[sys.argv[1]]()
