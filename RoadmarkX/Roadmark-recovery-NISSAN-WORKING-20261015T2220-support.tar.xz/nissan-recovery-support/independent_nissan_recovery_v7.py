#!/usr/bin/env python3
"""Independent Nissan fresh-only recovery replay. No capture/privacy imports or seed reads.
Run only with a separately reviewed exact SHA-sealed runtime-input contract while the
495 originals and seven live targets remain frozen. Preparation does not run this file.
"""
import argparse, collections, datetime, hashlib, json, lzma, os, pathlib, resource, stat, tarfile, time
P=pathlib.Path
C=P(__file__).resolve().parent
B=C.parent/'renault-working-20261015T2040'
W=C.parents[2]
LIMIT=256*1024*1024
CHUNK=65536
PIN_FIELDS=('path','bytes','sha256')
FIXED={
 'plan':{'path':str(C/'SAFETY-SAVE-PLAN-v3.json'),'bytes':91776,'sha256':'c92179241184ff825c2b494f2a78d93b30ecdcea31a52ecb45313fa23dade08b'},
 'planReview':{'path':str(C/'INDEPENDENT-NISSAN-SAFETY-SAVE-PLAN-v3-REVIEW-v1.json'),'bytes':9223,'sha256':'8f3bb2af1460ac4430f5e963aa9c487e80eea6bc6205da17173e8a7860c55596'},
 'scope':{'path':str(C/'FROZEN-CAPTURE-SCOPE.json'),'bytes':282372,'sha256':'655decf522259c518bd291634c2dedcb54e04f063c6a1cb897a096bc42c486d1'}}
ALLOWED={}
READ={}
CACHE={}

def ck(v,why):
 if not v:raise AssertionError(why)
def sh(r):return {k:r[k] for k in ('bytes','sha256')}
def core(r):return {k:r[k] for k in PIN_FIELDS}
def bp(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def canonical(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def valid(r):
 return isinstance(r,dict) and isinstance(r.get('path'),str) and type(r.get('bytes')) is int and r['bytes']>=0 and isinstance(r.get('sha256'),str) and len(r['sha256'])==64 and all(c in '0123456789abcdef' for c in r['sha256'])
def safe(n):
 p=P(n);ck(bool(n) and not p.is_absolute() and '..' not in p.parts and str(p)==n and '\\' not in n,'unsafe member '+n)
def ident(p):
 p=P(p);ck(p.is_absolute() and '..' not in p.parts,'noncanonical path')
 for q in (p,*p.parents):ck(not stat.S_ISLNK(q.lstat().st_mode),'symlink path '+str(q))
 s=p.lstat();ck(stat.S_ISREG(s.st_mode),'nonregular file '+str(p))
 return [s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev,s.st_mode]
def pin(p):
 p=P(p);before=ident(p);h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while q:=f.read(CHUNK):n+=len(q);h.update(q)
 ck(ident(p)==before and n==before[0],'unstable read '+str(p))
 return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
def check(p,r):
 got=pin(p);ck(sh(got)==sh(r),'pin differs '+str(p));return got
def add(r):
 ck(valid(r),'invalid JSON pin');p=P(r['path']);ck(p.is_absolute() and '..' not in p.parts and p.suffix=='.json','unapproved metadata path')
 if str(p) in ALLOWED:ck(ALLOWED[str(p)]==core(r),'conflicting sealed metadata pin')
 ALLOWED[str(p)]=core(r)
def load(r):
 ck(valid(r) and ALLOWED.get(r['path'])==core(r),'unsealed metadata read '+str(r.get('path')))
 if r['path'] in CACHE:return CACHE[r['path']]
 ck(r['bytes']<=32*1024*1024,'oversized metadata')
 p=P(r['path']);before=ident(p)
 with p.open('rb') as f:raw=f.read(r['bytes']+1)
 ck(ident(p)==before and bp(raw)==sh(r),'metadata changed or bad pin '+str(p))
 obj=json.loads(raw);CACHE[str(p)]=obj;READ[str(p)]=core(r);return obj
def sealed(p):
 p=str(p);ck(p in ALLOWED,'missing sealed input '+p);return load(ALLOWED[p])
def rows(rs):
 out={r['path']:core(r) for r in rs};ck(len(out)==len(rs),'duplicate member rows');return out
def walk(obj):
 stack=[(obj,0)];count=0
 while stack:
  v,depth=stack.pop();count+=1;ck(depth<=128 and count<=2000000,'JSON traversal limit')
  if isinstance(v,dict):yield v;stack.extend((x,depth+1) for x in v.values())
  elif isinstance(v,list):stack.extend((x,depth+1) for x in v)
def logical(path):
 p=P(path)
 if p.is_relative_to('/tmp'):return p.relative_to('/tmp').as_posix()
 if p.is_relative_to(W/'roadmark-104'):return 'roadmark/'+p.relative_to(W/'roadmark-104').as_posix()
 if p.is_relative_to(W):return p.relative_to(W).as_posix()
 raise AssertionError('unknown frozen path '+str(p))
def inverse(raw,a):
 ck(a['oldPointer']=='/authorization' and a['newPointer']=='/approvalScope' and a['classification']=='EXACT_HISTORICAL_ACTION_APPROVAL_PROSE_NOT_HTTP_AUTHENTICATION' and a['unchangedValueAndOtherBytes'] is True,'unapproved rename scope')
 ck(bp(raw)==sh(a) and raw.count(b'"approvalScope":')==1 and b'"authorization":' not in raw,'stored rename boundary')
 original=raw.replace(b'"approvalScope":',b'"authorization":',1)
 ck(bp(original)=={'bytes':a['originalBytes'],'sha256':a['originalSHA256']},'inverse original pin')
 old=json.loads(original);new=json.loads(raw);value=old.pop('authorization');ck(new.pop('approvalScope')==value and old==new,'inverse changed value or other fields')
 return bp(original)
def absolute(r):
 p=P(r['path']);return {**r,'path':str(p if p.is_absolute() else C/p)}
def bound(invref,termref=None,success=False):
 i=load(invref);ck(i['addressSpaceLimitBytes']==LIMIT and i['wallLimitSeconds']==600,'invocation resource envelope')
 t=load(termref) if termref else None
 if t:
  ck(all(t[k]==i[k] for k in ('command','childPid','startedAt','addressSpaceLimitBytes','wallLimitSeconds')),'invocation terminal mismatch')
  ck(t['endedAt']>=i['startedAt'],'terminal chronology')
 outcome=('PASS' if t['exitCode']==0 and not t['timedOut'] else 'NONZERO_OR_TIMEOUT') if t else 'UNKNOWN'
 if success:ck(outcome=='PASS','unsuccessful required phase')
 return i,t,outcome

def context(args):
 cp=P(args.contract);rp=P(args.review)
 ck(cp.parent==rp.parent==C and cp.suffix==rp.suffix=='.json','contract/review outside checkpoint')
 cr={'path':str(cp),'bytes':ident(cp)[0],'sha256':args.contract_sha256};rr={'path':str(rp),'bytes':ident(rp)[0],'sha256':args.review_sha256}
 add(cr);add(rr);contract=load(cr);review=load(rr);own=pin(__file__)
 ck(contract['schemaVersion']==1 and contract['mode']=='fresh-only' and contract['checkpoint']==str(C),'runtime contract scope')
 ck(contract['verifier']==own and review['verifier']==own and review['contract']==cr and review['mode']=='fresh-only' and review['result']=='ACCEPTED_EXACT_NISSAN_VERIFIER_RUNTIME_CONTRACT','runtime contract lacks exact independent acceptance')
 for r in FIXED.values():add(r)
 for r in contract['inputs'].values():add(r)
 for r in contract['additionalMetadata']:add(r)
 for x in contract['supportParts']:
  add(x['package']);add(x['inventory'])
 for x in contract['privacyReports']:
  for k in ('report','invocation','terminal'):add(x[k])
 for x in contract['phaseHistory']:
  add(x['invocation'])
  if x['terminal']:add(x['terminal'])
 plan=load(FIXED['plan']);scope=load(FIXED['scope']);pr=load(FIXED['planReview'])
 ck(pr['plan']==FIXED['plan'] and pr['result']=='PASS_FINAL_METADATA_PLAN_PENDING_EXACT_ADAPTER_REVIEW_AND_CAPTURE_VERIFICATION','plan review differs')
 for r in plan['base']['metadata']+list(plan['nissanEvidence'][k] for k in ('finalFreeze','finalRetentionReview')):add(r)
 inv=load(plan['nissanEvidence']['finalFreeze']);accept=load(plan['nissanEvidence']['finalRetentionReview'])
 ck(accept['status']=='accepted' and accept['inventory']==plan['nissanEvidence']['finalFreeze'] and accept['preparer']==inv['preparer']==plan['nissanEvidence']['freezePreparer'],'exact accepted final freeze')
 ck(accept['sourceAndStatusAfterPins']==inv['sourceAndStatusAfterPins']==scope['authorRetention']['sourceAndStatusAfterPins'],'seven target bindings')
 ck(len(inv['files'])==inv['totalFiles']==492 and sum(r['bytes'] for r in inv['files'])==inv['regularFileBytes']==43677295,'author inventory count/bytes')
 ck(len(scope['files'])==495 and len({r['path'] for r in scope['files']})==495,'495 frozen rows')
 extras={plan['nissanEvidence'][k]['path'] for k in ('finalFreeze','freezePreparer','finalRetentionReview')}
 ck({r['path'] for r in scope['files']}=={r['path'] for r in inv['files']}|extras,'492+3 exact scope')
 frozen={r['path']:r for r in scope['files']}
 for r in inv['files']:ck(all(frozen[r['path']].get(k)==v for k,v in r.items()),'author frozen metadata changed')
 for k in ('finalFreeze','freezePreparer','finalRetentionReview'):ck(sh(frozen[plan['nissanEvidence'][k]['path']])==sh(plan['nissanEvidence'][k]),'separate pin differs')
 ck(accept['currentValidation']==inv['currentValidation']==scope['currentValidation']==plan['currentNissanValidation'],'current validation differs')
 for k in ('fullProjectTypecheckPassed','releaseReady','currentCleanFullSuite','productionBuildVerified','phoneMobileVerified','publicationAuthorized'):ck(inv['currentValidation'][k] is False,'unpassed qualification changed')
 ck(plan['base']['nativeByteReadbackVerified'] is False and plan['nativeFlow']['nativeByteReadbackVerified'] is False and accept['previousNativeByteReadbackVerified'] is False,'native readback qualification')
 return contract,cr,rr,own,plan,scope,inv,accept

def captures(contract,plan,scope,inv):
 inp=contract['inputs'];src=load(inp['sourceCapture']);cap=load(inp['proofCapture']);maps=load(inp['sanitationMapping']);ap=load(inp['renameApprovals']);grant=load(inp['captureApproval'])
 ck(grant['status']=='INDEPENDENTLY_ACCEPTED_EXACT_NISSAN_COPY_MAPPING','capture grant status')
 ck(grant['renameMapping']==inp['renameApprovals'] and grant['sanitationMapping']==inp['sanitationMapping'] and grant['preflight']==inp['preflight'],'capture exact grant bindings');classification=load(grant['review']);preflight=load(inp['preflight']);root=load(grant['rootApproval']);proposal=load(grant['proposal'])
 ck(root['proposal']==grant['proposal'] and root['classification']==grant['review'] and root['originalsMayBeChanged'] is False and root['onlyExactListedCopies'] is True and proposal['files']==ap['files'],'root exact copy approval')
 ck(classification['candidateReport']==inp['preflight'],'candidate review binding');bound(classification['preflightInvocation'],classification['preflightTerminal'],True)
 ck(preflight['filesInspected']==sum(P(r['path']).suffix=='.json' for r in scope['files']),'preflight exact JSON scope')
 ck(preflight['originalsUnchanged'] is True and preflight['sanitizedPayloadPersisted'] is False and len(preflight['candidateFiles'])==len(ap['files']),'preflight candidate count/scope')
 candidates={r['restorePath']:r for r in preflight['candidateFiles']}
 for a in ap['files']:
  q=candidates[a['restorePath']];ck(q['originalPath']==a['originalPath'] and sh(q)=={'bytes':a['originalBytes'],'sha256':a['originalSHA256']} and q['locations']==['/authorization'],'exact candidate mapping')
 ck(maps['files']==ap['files'] and maps['originalExpectedPinsUnchanged'] and maps['originalsUnchanged'] and not maps['secretMaterialChanged'],'approved sanitation differs')
 rename={r['restorePath']:r for r in maps['files']};ck(len(rename)==len(maps['files']),'duplicate rename')
 ck(cap['scope']==scope and not cap['sourceChangesDuringCapture'] and not src['sourceChangesDuringCapture'] and src['fullSourceTreeCloned'] is False and src['unchangedLiveSourceRead'] is False,'capture scope/changes')
 cr={r['originalPath']:r for r in cap['files']};ck(len(cr)==495 and set(cr)=={r['path'] for r in scope['files']},'capture original coverage')
 changed={r['sourceRelativePath']:r for r in plan['exactPlannedLiveTargets'] if r['sourceRelativePath'] is not None}
 ck(len(changed)==6 and len(plan['exactPlannedLiveTargets'])==7 and set(changed)==set(scope['sourceChangedPaths']),'six source/seven live scope')
 old=sealed(B/'source-capture.json');oldrows={r['path']:r for r in old['files']};sr={r['path']:r for r in src['files']}
 prior_source=sealed(B/'source-package.json');prior_source_rows=rows(prior_source['memberFiles']);prior_source_rows.pop('roadmark/SOURCE-FILE-MANIFEST.json');ck(prior_source_rows=={'roadmark/'+n:{'path':'roadmark/'+n,**sh(r)} for n,r in oldrows.items()},'prior700 source capture/package differs')
 ck(len(oldrows)==700 and len(sr)==703 and set(sr)==set(scope['expectedSourcePaths'])==set(oldrows)|set(changed),'700 plus3 source paths')
 ck(set(changed)-set(oldrows)==set(plan['sourcePolicy']['provisionalAddedSourcePaths']) and len(set(changed)-set(oldrows))==3,'three additions')
 for n,r in sr.items():
  if n in changed:ck(sh(r)==sh(changed[n]['frozenPin']) and {'bytes':r['originalBytes'],'sha256':r['originalSHA256']}==sh(r),'changed source identities')
  else:
   ck(sh(r)==sh(oldrows[n]) and r['originalBytes']==oldrows[n]['originalBytes'] and r['originalSHA256']==oldrows[n]['originalSHA256'] and r['payloadPath']==oldrows[n]['payloadPath'] and r['captureMethod']=='exact-prior-source-payload-reused-no-live-read' and r['originalPath']==oldrows[n]['originalPath'] and 'sourceIdentity' not in r,'unchanged source not exact prior reuse')
 covered={r['path'] for r in cap['files'] if r['captureMethod']=='covered-by-full-source'}
 ck(covered=={'roadmark/'+n for n in changed},'six covered source rows')
 basefiles=rows(sealed(B/'deliverables/Roadmark-RECOVERY-MANIFEST-RENAULT-WORKING-20261015.json')['files'])
 delta={r['path'] for r in cap['files'] if r.get('archiveAction')=='new-delta-member'};reused={r['path'] for r in cap['files'] if r.get('archiveAction')=='reuse-exact-base-member'}
 ck(delta|reused=={r['path'] for r in cap['files']}-covered and not delta&reused and {r['path'] for r in cap['changedFiles']}==delta,'actual proof delta/reuse partition')
 for r in cap['files']:
  if r['path'] in reused:ck(basefiles.get(r['path'])==core(r),'reused selected member is not exact base bytes')
 ck(len(cap['changedFiles'])==len({r['path'] for r in cap['changedFiles']}),'duplicate proof delta')
 originals=[];inverses=[];reused_json={};live={r['path']:r for r in inv['sourceAndStatusAfterPins']}
 for f in scope['files']:
  p=f['path'];r=cr[p];n=logical(p);ck(r['path']==n,'capture restore path')
  ident0=ident(p);ck(ident0[:5]==f['stableIdentityAtPreparation'] and ident0[:5]==r['sourceIdentity'] and ident0[5]==f['mode'],'frozen stable identity '+p)
  expected={'bytes':r['originalBytes'],'sha256':r['originalSHA256']};check(p,expected)
  declared=f.get('sha256') or f.get('knownSha256') or f.get('declaredSha256')
  ck(expected['bytes']==f['bytes'] and (not declared or declared==expected['sha256']),'frozen declared identity')
  if p in live:ck(expected==sh(live[p]),'live pin differs')
  payload=P(r['payloadPath'])
  if payload.is_relative_to(C):check(payload,r)
  else:ck(n in reused and basefiles.get(n)==core(r),'selected payload outside checkpoint without exact base reuse')
  reused_raw=None
  if n in reused and P(p).suffix=='.json':
   ck(r['originalBytes']<=8*1024*1024,'reused selected JSON budget');reused_raw=P(p).read_bytes();ck(bp(reused_raw)==expected,'reused selected original changed')
   if n in rename:reused_raw=reused_raw.replace(b'"authorization":',b'"approvalScope":',1)
   ck(bp(reused_raw)==sh(r),'reused stored JSON does not reconstruct');reused_json[n]=reused_raw
  if n in rename:
   a=rename[n];ck(a['originalPath']==p and sh(a)==sh(r) and {'bytes':a['originalBytes'],'sha256':a['originalSHA256']}==expected,'rename row differs')
   ck(r['bytes']<=8*1024*1024,'rename budget');raw=reused_raw if reused_raw is not None else payload.read_bytes();ck(inverse(raw,a)==expected,'inverse copy differs');inverses.append({'member':n,'storedPin':sh(r),'originalPin':expected})
  else:ck(sh(r)==expected,'unapproved copy transformation '+n)
  ck(ident(p)==ident0,'original changed during capture verification')
  originals.append({'originalPath':p,'member':n,'originalPin':expected,'stableIdentity':ident0,'liveTarget':p in live})
 ck(len(inverses)==len(rename),'unused approved rename')
 return src,cap,rename,originals,inverses,reused_json

def archive_replay(contract,src,cap,rename,reused_json):
 inp=contract['inputs'];sp=load(inp['sourcePackage']);proof=load(inp['proofPackages'])['archives'];supports=[load(x['package']) for x in contract['supportParts']]
 archives=[sp]+proof+supports;ck(bool(supports),'first support missing');ap=load(inp['archivePlan']);ck(ap['archives']==archives,'actual archive plan/package order')
 ck(len({a['filename'] for a in archives})==len(archives),'duplicate fresh archives')
 ck(sp['bytes']<15000000 and sp['members']==len(sp['memberFiles'])==704,'source compressed limit/count')
 source={ 'roadmark/'+r['path']:{'path':'roadmark/'+r['path'],**sh(r)} for r in src['files']}
 sm=rows(sp['memberFiles']);ck(set(sm)==set(source)|{'roadmark/SOURCE-FILE-MANIFEST.json'} and all(sm[n]==r for n,r in source.items()),'source package exact703')
 keep={r['path'] for r in cap['files'] if P(r['originalPath']).suffix=='.json'}|set(rename)|{'roadmark/SOURCE-FILE-MANIFEST.json','nissan-safety-support/COPY-SANITATION-MAPPING.json'}
 seenall={};where={};saved=dict(reused_json);checks=[];savedbytes=sum(len(v) for v in saved.values())
 for a in archives:
  ck(a['new'] is True and a['filename'].startswith(('Roadmark-recovery-source-NISSAN-WORKING-20261015T2220','Roadmark-recovery-NISSAN-WORKING-20261015T2220')),'nonfresh archive forbidden before payload open')
  p=P(a['file']);ck(p.parent==C.parents[1] and p.name==a['filename'] and p.suffix=='.xz','fresh archive path');check(p,a)
  expected=rows(a['memberFiles']);ck(a['allMembersVerified'] is True and a['members']==len(expected),'package verification/count');seen={};before=ident(p)
  with lzma.open(p,'rb') as stream:
   with tarfile.open(fileobj=stream,mode='r|') as tar:
    for m in tar:
     safe(m.name);ck(m.isfile() and m.name in expected and m.name not in seen and m.name not in seenall,'unsafe/unlisted/duplicate fresh member')
     ck(m.size==expected[m.name]['bytes'],'tar header size');h=hashlib.sha256();n=0;pieces=[] if m.name in keep or m.name.startswith('recovery-metadata/') else None
     with tar.extractfile(m) as f:
      while q:=f.read(CHUNK):
       h.update(q);n+=len(q)
       if pieces is not None:
        savedbytes+=len(q);ck(savedbytes<=64*1024*1024,'retained JSON budget');pieces.append(q)
     r={'path':m.name,'bytes':n,'sha256':h.hexdigest()};ck(r==expected[m.name],'fresh member identity '+m.name);seen[m.name]=r;seenall[m.name]=r;where[m.name]=[a['filename']]
     if pieces is not None:saved[m.name]=b''.join(pieces)
    ck(not any(tar.fileobj.buf),'nonzero buffered bytes after tar EOF')
   while q:=stream.read(CHUNK):ck(not any(q),'nonzero bytes after tar EOF')
  ck(seen==expected and ident(p)==before,'archive incomplete/changed')
  checks.append({'archive':a['filename'],**sh(a),'members':len(seen),'memberBytes':sum(r['bytes'] for r in seen.values()),'tarAndXzEofVerified':True})
 embedded=json.loads(saved['roadmark/SOURCE-FILE-MANIFEST.json']);ck(embedded['root']=='roadmark' and rows([{'path':'roadmark/'+r['path'],**sh(r)} for r in embedded['files']])==source,'embedded source manifest')
 caprows=rows(cap['changedFiles'])
 for a in proof:
  ar=rows(a['memberFiles']);meta=[n for n in ar if n.startswith('recovery-metadata/')];ck(len(meta)==1,'proof embedded metadata count');obj=json.loads(saved[meta[0]])
  listed=rows(obj['files']);actual={n:r for n,r in ar.items() if n!=meta[0] and n!='nissan-safety-support/COPY-SANITATION-MAPPING.json'};ck(listed==actual and all(caprows[n]==r for n,r in listed.items()),'proof embedded exact members')
  for r in obj['files']:
   c=next(x for x in cap['changedFiles'] if x['path']==r['path']);ck((r['originalBytes'],r['originalSHA256'])==(c['originalBytes'],c['originalSHA256']),'embedded original pin')
 ck(bp(saved['nissan-safety-support/COPY-SANITATION-MAPPING.json'])==sh(inp['sanitationMapping']),'embedded sanitation mapping bytes')
 for r in cap['files']:
  if r.get('archiveAction')!='reuse-exact-base-member':ck(seenall.get(r['path'])==core(r),'fresh captured file absent from fresh archives')
  else:ck(r['path'] not in seenall,'exact-reused proof redundantly recopied')
 for n,a in rename.items():inverse(saved[n],a)
 supportrows=[]
 for spec,a in zip(contract['supportParts'],supports):
  inventory=load(spec['inventory']);listed=rows(inventory['files']);actual=rows(a['memberFiles']);meta=[n for n in actual if n.startswith('recovery-metadata/')];ck(len(meta)==1,'support metadata count');actual.pop(meta[0]);ck(actual==listed and json.loads(saved[meta[0]])==inventory,'exact support inventory');supportrows+=inventory['files']
 own=[r for r in supportrows if r.get('originalPath')==str(P(__file__).resolve())];ck(len(own)==1 and sh(own[0])==sh(pin(__file__)) and own[0]['path'] in rows(supports[0]['memberFiles']),'checker must be retained once in first support')
 return archives,seenall,where,saved,checks,supportrows

def authority_has(ref,member,archives,resolution):
 obj=load(ref)
 for d in walk(obj):
  if d.get('filename') in archives and isinstance(d.get('memberFiles'),list):
   if len(archives)==1 and member in [core(x) for x in d['memberFiles']]:return True
  if isinstance(d.get('member'),(str,dict)):
   m=d['member'];m=core(m) if isinstance(m,dict) and valid(m) else {'path':m,**sh(d['expected'])} if isinstance(m,str) and valid(d.get('expected')) else None
   mapping=d.get('mapping') if isinstance(d.get('mapping'),dict) else {};a=d.get('archives',mapping.get('archives'));r=d.get('partResolution',mapping.get('partResolution','Exact single archive'))
   if m==member and a==archives and r==resolution:return True
  if d.get('retainedMember')==member['path'] and d.get('retainedArchive',{}).get('filename') in archives and len(archives)==1 and sh(d)==sh(member):return True
 return False

def references(contract,plan,cap,rename,archives,fresh,where,saved):
 inp=contract['inputs'];conf=load(inp['referenceConfiguration']);closure=load(inp['referenceClosure']);restore=load(inp['restorePlan'])
 ck(sh(inp['referenceConfiguration'])=={'bytes':16143,'sha256':'62d4b02318ae71df2236b889582875c981ebb42c13d4df25bcb8bdd6878d2e22'},'reference configuration fixed pin')
 closure_inputs={r['path']:r for r in closure['inputPins']}
 for role in ('sourceCapture','proofCapture','sourcePackage','proofPackages','renameApprovals','sanitationMapping'):ck(closure_inputs.get(inp[role]['path'])==inp[role],'closure source/proof binding differs')
 ck(closure_inputs.get(FIXED['scope']['path'])==FIXED['scope'],'closure frozen scope binding')
 ck(closure['configuration']==inp['referenceConfiguration'] and closure['result']=='PASS_EXACT_METADATA_ONLY_REFERENCE_CLOSURE' and closure['supportRetentionStatus']=='PENDING_FRESH_SUPPORT' and closure['recoveryComplete'] is False and not closure['unresolvedReferences'],'closure metadata-only status')
 ck(closure['historicalLimitations']==restore['historicalLimitations']==plan['historicalLimitations'],'historical limitations changed')
 for obj in (closure,restore):
  for k in ('fullProjectTypeScriptPassed','releaseReady','nativeByteReadbackVerified'):ck(obj[k] is False,'closure/restore acceptance boundary')
 for r in conf['metadata'].values():
  ck(r['path'] in ALLOWED and ALLOWED[r['path']]==core(r),'configuration authority not sealed')
 base=load(conf['metadata']['baseManifest']);prior_restore=load(conf['metadata']['baseRestore']);basefiles=rows(base['files']);basears={a['filename']:a for a in base['archivesInRestoreOrder']}
 ck(len(basears)==142 and len(prior_restore['archivesInRestoreOrder'])==142,'base142 identity')
 oldsource=plan['base']['sourceArchive']['filename'];ck(sh(basears[oldsource])==sh(plan['base']['sourceArchive']),'replaced source identity')
 reused=[]
 for a in prior_restore['archivesInRestoreOrder']:
  ck(a['filename'] in basears and sh(a)==sh(basears[a['filename']]),'base restore identity')
  if a['filename']!=oldsource:reused.append(basears[a['filename']])
 ck(len(reused)==141 and len({a['filename'] for a in reused})==141,'141 reused prior archives')
 reusedby={a['filename']:a for a in reused};allby={**reusedby,**{a['filename']:a for a in archives}};ck(len(allby)==141+len(archives),'archive identity collision')
 reqs={};metas=[]
 for r in cap['files']:
  if P(r['originalPath']).suffix!='.json':continue
  n=r['path'];raw=saved[n];obj=json.loads(raw);origin=len(metas);metas.append({'originalPath':r['originalPath'],'storedMember':n,'storedPin':{'path':r['payloadPath'],**sh(r)}})
  for d in walk(obj):
   if isinstance(d.get('path'),str) and d['path'].startswith('/') and {'bytes','sha256'}<=d.keys():
    ck(valid(d),'malformed captured reference');key=(d['path'],d['bytes'],d['sha256']);reqs.setdefault(key,set()).add(origin)
 ck(closure['metadataSources']==metas,'reference nomination sources differ')
 actual={tuple(r['expected'][k] for k in PIN_FIELDS):r for r in closure['requirements']};ck(len(actual)==len(closure['requirements']) and set(actual)==set(reqs),'exact reference requirements set')
 pending_expected={tuple(r['expected'][k] for k in PIN_FIELDS):r for r in conf['pendingSupportCandidates']}
 chosen_pending={k:r for k,r in pending_expected.items() if r['mandatory']};outside={};supplements=conf['deliveryOnlySupplements'];ck(len(supplements)==2,'two outside-chain supplements')
 for s in supplements:
  identity=s['identity'];ck(identity['filename'] not in allby and identity['nativeByteReadbackVerified'] is False,'supplement improperly in chain or readback upgraded')
  pkg=load(s['package']);inventory=load(s['inventory']);ck(sh(pkg)==sh(identity) and pkg['filename']==identity['filename'] and pkg['outsideRecoveryArchiveSet'] is True and pkg['unchangedRecoveryArchiveCount']==142,'outside supplement package identity')
  pm=rows(pkg['members']);im=rows(inventory['files']);ck(pm==im and len(pm)==pkg['memberCount'],'outside supplement member inventory')
  for r in inventory['files']:
   outside.setdefault((r['originalPath'],r['bytes'],r['sha256']),[]).append({'member':core(r),'archive':identity,'package':s['package'],'inventory':s['inventory']})
 priorclosure=load(conf['metadata']['baseClosure']);runtime={tuple(r['expected'][k] for k in PIN_FIELDS):r for r in priorclosure['requirements'] if r['kind']=='reference-only-runtime-exclusion'}
 if 'runtimeExclusions' in inp:
  for r in load(inp['runtimeExclusions'])['files']:
   e=r['expected'];p=P(e['path']);kind=r['category'];root=W/'roadmark-104'
   ok=(kind=='external-system-binary' and str(p)=='/usr/bin/timeout') or (kind=='installed-package-toolchain' and p.is_relative_to(root/'node_modules')) or (kind=='generated-next-types' and p.is_relative_to(root/'.next')) or (kind=='reconstructible-compiler-cache' and p==root/'tsconfig.tsbuildinfo')
   ck(ok and r['independentlyReviewed'] is True and r['justification'].strip(),'unapproved runtime exclusion');load(r['reviewAuthority']);runtime[tuple(e[k] for k in PIN_FIELDS)]=r
 counts=collections.Counter()
 for key,r in actual.items():
  ck(r['nominatedBy']==sorted(reqs[key]),'reference nominations differ');e=r['expected'];kind=r['kind'];counts[kind]+=1
  if kind=='reference-only-runtime-exclusion':
   ck(key in runtime and r['category']==runtime[key]['category'],'reference runtime authority differs');continue
  if kind=='pending-fresh-support':
   ck(key in pending_expected and r['member']==pending_expected[key]['member'] and r['notRetainedByOldArchives'] is True,'pending support authority');chosen_pending[key]=pending_expected[key];continue
  if kind=='delivery-supplement-exact-outside-recovery':
   ck(any(all(r[k]==v[k] for k in ('member','archive','package','inventory')) for v in outside.get(key,[])),'exact outside supplement reference');continue
  ck(kind in ('fresh-exact','fresh-reversible-original','base-exact','base-reversible-original'),'unrecognized reference kind')
  m=r['member'];n=m['path'];ck(valid(m) and bool(r['archives']) and set(r['archives'])<=allby.keys(),'reference archive binding')
  if kind.startswith('fresh'):
   ck(fresh.get(n)==m and where[n]==r['archives'] and r['partResolution']=='Exact single archive','fresh member/part binding')
   if kind=='fresh-exact':ck(sh(e)==sh(m),'fresh expected pin')
   else:
    ck(n in rename and r['storedPin']==sh(m) and r['inverse']=={'replaceKeyOnce':{'from':'approvalScope','to':'authorization'},'valueAndOtherBytesUnchanged':True,'mapping':str(C/'COPY-SANITATION-MAPPING.json')},'fresh inverse contract')
    ck(inverse(saved[n],rename[n])==sh(e),'fresh original reconstruction')
  else:
   ck(basefiles.get(n)==m and set(r['archives'])<=reusedby.keys() and n not in fresh,'inherited exact retained member')
   ck(authority_has(r['mappingAuthority'],m,r['archives'],r['partResolution']),'inherited archive mapping authority')
   if kind=='base-exact':ck(sh(e)==sh(m),'base exact expected pin')
   else:
    iv=r['inverse'];ck(iv['replaceKeyOnce']=={'from':'approvalScope','to':'authorization'} and iv['valueAndOtherBytesUnchanged'] is True and r['storedPin']==sh(m),'inherited inverse contract')
    mapping=load(iv['mapping']);approval=load(iv['approvalAuthority']);ck(mapping['files']==approval['files'],'prior inverse approval differs')
    matches=[a for a in mapping['files'] if a['restorePath']==n and a['originalPath']==e['path'] and sh(a)==sh(m) and {'bytes':a['originalBytes'],'sha256':a['originalSHA256']}==sh(e)]
    ck(len(matches)==1 and matches[0]['oldPointer']=='/authorization' and matches[0]['newPointer']=='/approvalScope' and matches[0]['unchangedValueAndOtherBytes'] is True and matches[0]['classification']=='ordinary-noncredential-approval-prose','inherited inverse original binding')
 ck(dict(counts)==closure['summary'],'reference summary counts')
 pending=closure['pendingSupportMap'];ck(len(pending)==len(chosen_pending) and {tuple(r['expected'][k] for k in PIN_FIELDS):r for r in pending}==chosen_pending,'exact pending support map')
 for r in pending:
  n=r['member'];ck(n=='nissan-recovery-support/base-renault/'+P(r['expected']['path']).name and fresh.get(n)=={'path':n,**sh(r['expected'])},'pending support actual fresh bytes')
 for name in ('FINAL-RENAULT-UPLOAD-RECEIPTS.json','INDEPENDENT-RENAULT-TERMINAL-CLOSURE-v1.json'):
  hits=[r for r in pending if P(r['expected']['path'])==B/name];ck(len(hits)==1 and hits[0]['mandatory'] is True,'mandatory late Renault support')
 ck(closure['deliveryOnlySupplementsOutsideRecovery']==restore['deliveryOnlySupplementsOutsideRecovery']==supplements,'supplement identity set')
 dp=closure['inheritedDependencyProposal'];deps=dp['dependencies'];olddeps=base['inheritedDependencyReconstruction']['dependencies'];ck(dp['canonicalSha256']==canonical(deps) and dp['inheritedRecords']==len(olddeps) and dp['proposedRecords']==len(deps) and dp['newRecords']==len(deps)-len(olddeps),'dependency counts/hash')
 ck(len(deps)>=len(olddeps) and len({d['originalPath'] for d in deps})==len(deps),'duplicate dependency original')
 for d,o in zip(deps,olddeps):ck(d['originalPath']==o['originalPath'] and d['pins'][:len(o['pins'])]==o['pins'],'inherited dependency prefix changed')
 ck(dp['newPinVariants']==sum(len(d['pins']) for d in deps)-sum(len(d['pins']) for d in olddeps),'dependency variant count')
 final={n:r for n,r in basefiles.items() if not n.startswith('roadmark/')};final.update(fresh)
 for d in deps:
  for r in d['pins']:ck(final.get(r['member']['path'])==core(r['member']) and sh(r['expected'])==sh(r['member']),'dependency not exact final retained bytes')
 expectedars=[]
 for a,new in [(a,False) for a in reused]+[(a,True) for a in archives]:expectedars.append({**{k:v for k,v in a.items() if k not in ('restoreOrder','new','memberFiles')},'new':new,'restoreOrder':len(expectedars)+1})
 ck(restore['status']=='EXACT_NEW_ARCHIVES_PLUS_REUSED_PRIOR_CHAIN' and restore['archivesInRestoreOrder']==expectedars and restore['newArchives']==archives,'exact141+new restore ordering/identity')
 ck(rows(restore['files'])==final and rows(restore['newFiles'])==fresh and restore['source']==archives[0],'restore exact logical files')
 expectedcounts={'baseArchivesReused':141,'archiveCount':141+len(archives),'logicalFiles':len(final),'logicalBytes':sum(r['bytes'] for r in final.values()),'freshFiles':len(fresh),'freshBytes':sum(r['bytes'] for r in fresh.values()),'fullSourceFiles':703,'sourceArchiveMembers':704}
 ck(all(restore[k]==v for k,v in expectedcounts.items()),'restore dynamic counts')
 ck(restore['sourceFullCloneCreated'] is False and restore['referenceClosureSupportSatisfied'] is True and restore['pendingSupportResolved']==pending and restore['inheritedDependencyReconstruction']==dp,'restore resolved support/dependencies')
 if 'supportReuse' in inp:
  reuse=load(inp['supportReuse']);supplementby={s['identity']['filename']:s for s in supplements}
  declared=reuse['outsideRecoveryArtifacts'];ck(len(declared)==len(supplements) and len({d['archive']['filename'] for d in declared})==len(declared),'outside support artifact set')
  for d in declared:
   s=supplementby.get(d['archive']['filename']);ck(s is not None and d['archive']==s['identity'] and d['package']==s['package'],'outside support exact archive/package declaration')
   if 'inventory' in d:ck(d['inventory']==s['inventory'],'outside support inventory declaration')
  for r in reuse['files']:
   n=r['retainedMember'];a=r['retainedArchive'];authority=r['archiveMappingAuthority'];outside_chain=r['outsideRecoveryArchiveSet'];ck(type(outside_chain) is bool,'support reuse outside-chain flag')
   if outside_chain:
    s=supplementby.get(a['filename']);ck(s is not None and a==s['identity'] and authority==s['package'] and a['filename'] not in allby,'outside support exact identity/authority or recovery-count inflation')
    pkg=load(s['package']);inventory=load(s['inventory']);member={'path':n,**sh(r)}
    ck(rows(pkg['members']).get(n)==member and rows(inventory['files']).get(n)==member,'outside support exact package/inventory member')
    ck(pkg['filename']==a['filename'] and sh(pkg)==sh(a) and pkg['outsideRecoveryArchiveSet'] is True and pkg['unchangedRecoveryArchiveCount']==142 and a['nativeByteReadbackVerified'] is False,'outside support boundary')
   else:
    ck(n in final and n in basefiles and sh(r)==sh(final[n])==sh(basefiles[n]),'support reuse final member')
    ck(a==reusedby.get(a['filename']),'support reuse exact current native archive identity');ck(authority_has(authority,core(final[n]),[a['filename']],'Exact single archive'),'support reuse archive authority')
 return base,closure,restore,expectedcounts

def accounting(contract,archives):
 inp=contract['inputs'];ac=load(inp['accounting']);ck(ac['status']=='EXPLICIT_STAGE_AND_TERMINAL_ACCOUNTING' and ac['noSeedValuesReadByThisAccounting'] is True,'accounting status')
 prior=sealed(B/'SEED-READ-ACCOUNTING-after-active-v2.json');old=ac['inheritedRenaultAccounting'];expectedold={'receipt':ALLOWED[str(B/'SEED-READ-ACCOUNTING-after-active-v2.json')],'attempts':11,'successfulPasses':9,'knownZeroPreconditionFailures':2,'originalCupraUnknownPreservedByExactReceipt':True,'originalRenaultFactualReportUnknownPreservedSeparately':True}
 ck(old==expectedold and len(prior['phases'])==11 and sum(p['outcome']=='PASS' for p in prior['phases'])==9 and sum(p['knownZeroSeedPreconditionFailure'] for p in prior['phases'])==2,'inherited Renault9/11/2')
 phases=ac['phases'];by={p['invocation']['path']:p for p in phases};ck(len(by)==len(phases),'duplicate scan phase');found={p.relative_to(C).as_posix() for p in C.glob('scan-*.resources.invocation.json')};ck(set(by)==found,'omitted actual scan invocation')
 for p in phases:
  ir=absolute(p['invocation']);tr=absolute(p['terminal']) if p['terminal'] else None;i,t,outcome=bound(ir,tr)
  expected_terminal=P(ir['path']).with_name(P(ir['path']).name.replace('.invocation.json','.json'))
  ck(bool(tr)==expected_terminal.exists() and (not tr or tr['path']==str(expected_terminal)),'unknown/missing terminal misclassified')
  ck(p['start']==i['startedAt'] and p['pid']==i['childPid'] and p['end']==(t['endedAt'] if t else None) and p['outcome']==outcome and p['knownZeroSeedPreconditionFailure'] is False,'actual scan phase outcome')
 summary={'attempts':len(phases),'successfulPasses':sum(p['outcome']=='PASS' for p in phases),'nonzeroOrTimeout':sum(p['outcome']=='NONZERO_OR_TIMEOUT' for p in phases),'unknownTerminalOutcomes':sum(p['outcome']=='UNKNOWN' for p in phases),'independentlyEstablishedKnownZeroFailures':0,'zeroFailuresQualification':'No current phase is classified known-zero by this revision'}
 ck(ac['currentInvocationSummary']==summary,'actual current invocation summary')
 for key,folder,unit,countfield in [('historical','seed-read-invocations',200,'exactPinnedMembersReadAndVerified'),('audi','audi-seed-read-invocations',6,'payloadReadOperations'),('deepal','deepal-seed-read-invocations',5,'payloadReadOperations')]:
  stage=ac['stages'][key];records=stage['records'];actual={p.relative_to(C).as_posix() for p in (C/folder).glob('*.json')};ck({r['receipt']['path'] for r in records}==actual and len(records)==len(actual),'omitted/duplicate actual seed receipt')
  completed=[]
  for r in records:
   d=load(absolute(r['receipt']));hits=[p for p in phases if d['processId']==p['pid'] and d['completedAt']>=p['start'] and (p['end'] is None or d['completedAt']<=p['end'])];ck(len(hits)==1,'seed receipt ambiguous phase');p=hits[0]
   ck(d[countfield]==unit and (d['noExtractedValuesPersisted'] if key=='historical' else d['noValuesOrValueDigestsPersisted']) is True,'seed receipt operations/disclosure')
   if key=='historical':ck(d['historicalArchives']==21,'historical seed archive count')
   ck(r['phaseInvocation']==p['invocation'] and r['phaseTerminal']==p['terminal'] and r['scanOutcome']==p['outcome'] and r['completedAt']==d['completedAt'],'seed phase binding')
   completed.append(p['invocation']['path'])
  ck(len(completed)==len(set(completed)),'duplicate stage within scan phase')
  missing=[p['invocation'] for p in phases if p['invocation']['path'] not in completed]
  ck(stage['completedInvocations']==len(records) and stage['perCompletedInvocationOperations']==unit and stage['totalCompletedOperations']==unit*len(records) and stage['unknownPartialReadPhases']==missing and stage['completedOperationsAreLowerBoundWhenUnknownPartialsExist']==bool(missing),'stage operations/unknown partial accounting')
 local=ac['inheritedLocal'];audi=ac['stages']['audi'];count=audi['completedInvocations']
 ck(local['completedInvocationsProvedByAudiLedger']==count and local['valueReadsPerCompletedInvocation']==local['integrityReadsPerCompletedInvocation']==48 and local['totalProvedValueReads']==local['totalProvedIntegrityReads']==48*count and local['unknownPartialLocalReadsPossibleForPhasesWithoutAudiCompletion']==audi['unknownPartialReadPhases'],'local48 actual completed lower-bound accounting')
 ck(prior['inheritedCupraAccounting']['originalInterruptedScanOutcome']=='UNKNOWN' and 'UNKNOWN' in prior['renaultOriginalFactualReport'] and 'UNKNOWN' in ac['renaultOriginalFactualReport'],'historical UNKNOWN lost')
 archiveby={a['filename']:a for a in archives};seen=set();classes=[];templates=[];privacy=[]
 pact=load(inp['privacyAdapterContract']);ck(pact['status']=='INDEPENDENTLY_ACCEPTED_NISSAN_PRIVACY_ADAPTER','privacy adapter acceptance');load(pact['preparation']);load(pact['review'])
 for spec in contract['privacyReports']:
  report=load(spec['report']);i,t,outcome=bound(spec['invocation'],spec['terminal'],True);n=report['archive'];ck(n in archiveby and n not in seen,'duplicate/unrelated privacy final receipt');seen.add(n);a=archiveby[n]
  ck(report['currentByteSearchForEveryMember'] is True,'privacy did not search every current member')
  ck(report['status']=='clean' and all(not report[k] for k in ('exactValueMatches','primaryHeaderCandidates','unclassifiedRuntimeCandidates','errors')),'privacy not clean')
  ck(sh(report['archivePin'])==sh(a) and rows(report['members'])==rows(a['memberFiles']) and report['regularFilesScanned']==a['members'],'privacy exact archive/member coverage')
  ck(str(spec['report']['path']) in i['command'] and a['file'] in i['command'],'privacy actual command targets');ck(P(spec['invocation']['path']).relative_to(C).as_posix() in by,'privacy scan absent from accounting')
  classes.extend(report['classifiedExactCodeHeaderCandidates']);templates.extend(report['classifiedExactTemplateRuntimeCandidates']);privacy.append(spec)
  for stage in ac['stages'].values():ck(sum(r['phaseInvocation']['path']==P(spec['invocation']['path']).relative_to(C).as_posix() for r in stage['records'])==1,'successful final privacy scan missing completed seed stage')
 ck(seen==set(archiveby),'missing fresh clean privacy receipt')
 ck(sorted(canonical(x) for x in classes)==sorted(canonical(x) for x in contract['syntaxClassifications']),'unreviewed syntax classification')
 ck(sorted(canonical(x) for x in templates)==sorted(canonical(x) for x in contract['templateClassifications']),'unreviewed template classification')
 return ac,summary,privacy


def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('mode',choices=['fresh-only']);parser.add_argument('--contract',required=True);parser.add_argument('--contract-sha256',required=True);parser.add_argument('--review',required=True);parser.add_argument('--review-sha256',required=True);args=parser.parse_args()
 resource.setrlimit(resource.RLIMIT_AS,(LIMIT,LIMIT));started=time.monotonic();output=C/'INDEPENDENT-NISSAN-RECOVERY-VERIFICATION-v1.json';ck(not output.exists(),'immutable output already exists')
 contract,contractpin,reviewpin,own,plan,scope,inv,accept=context(args)
 src,cap,rename,originals,inverses,reused_json=captures(contract,plan,scope,inv)
 archives,fresh,where,saved,archivechecks,supportrows=archive_replay(contract,src,cap,rename,reused_json)
 ck(json.loads(saved[logical(plan['nissanEvidence']['finalFreeze']['path'])])==inv and json.loads(saved[logical(plan['nissanEvidence']['finalRetentionReview']['path'])])==accept,'archived exact acceptance/inventory differs')
 base,closure,restore,counts=references(contract,plan,cap,rename,archives,fresh,where,saved)
 ac,summary,privacy=accounting(contract,archives)
 history=[]
 for spec in contract['phaseHistory']:
  i,t,outcome=bound(spec['invocation'],spec['terminal']);history.append({'invocation':spec['invocation'],'terminal':spec['terminal'],'outcome':outcome})
 ck(len(history)==len({r['invocation']['path'] for r in history}),'duplicate preparation phase')
 known={r['invocation']['path'] for r in history}
 active=contract['currentVerifierInvocationPath'];ck(P(active).parent==C and active.endswith('.resources.invocation.json'),'active verifier invocation path')
 ck({str(p) for p in C.glob('*.resources.invocation.json')}==known|{active},'omitted actual preparation invocation')
 ck(not P(active.replace('.invocation.json','.json')).exists(),'active verifier already terminal')
 # Every original remains stable across the complete independent replay, up to this gate.
 for r in originals:ck(ident(r['originalPath'])==r['stableIdentity'],'original changed before freeze-release gate')
 ck(len([r for r in originals if r['liveTarget']])==7,'seven live checks missing')
 for p in inv['retainedFailures']['preparationFailurePaths']:ck(logical(p) in rows(restore['files']),'Nissan preparation failure omitted')
 for p in inv['retainedFailures']['reviewerDiagnosticPaths']:ck(logical(p) in rows(restore['files']),'Nissan diagnostic omitted')
 ck(all(a['cause']=='unknown' and a['exitCode']==-9 and a['fullProjectTypecheckPassed'] is False for a in inv['retainedFailures']['compilerAttempts']) and 'UNKNOWN' in inv['retainedFailures']['predecessorRenaultOriginalReportOutcome'],'compiler/Renault history changed')
 preserved={'historicalLimitations':plan['historicalLimitations'],'currentRetainedFailures':inv['retainedFailures'],'currentOtherAttemptHistory':inv['otherAttemptHistory'],'inheritedBoundaries':base['inheritedBoundaries'],'inheritedPreparationLimitations':base['currentPreparationLimitations'],'inheritedRecoveryMetadata':base['inheritedRecoveryMetadata'],'inheritedRenaultAccounting':ac['inheritedRenaultAccounting'],'originalCupraPrivacyScan':'UNKNOWN','originalRenaultReport':'UNKNOWN','fullProjectTypeScriptPassed':False,'releaseReady':False,'nativeByteReadbackVerified':False}
 out={'schemaVersion':1,'result':'PASS_INDEPENDENT_NISSAN_FRESH_RECOVERY','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verifierScript':own,'runtimeInputContract':contractpin,'runtimeInputContractReview':reviewpin,'inputPins':list(READ.values()),'archiveChecks':archivechecks,'freshArchiveCount':len(archives),'freshMembers':len(fresh),'freshBytes':sum(r['bytes'] for r in fresh.values()),'sourceProjectFiles':703,'sourceArchiveMembers':704,'sourceBytes':archives[0]['bytes'],'authorInventoryFiles':492,'separateFreezeExtras':3,'capturedOriginalsRehashed':495,'originalChecksCanonicalSha256':canonical(originals),'originalChecks':originals,'inverseMappings':inverses,'exactReferenceClosure':contract['inputs']['referenceClosure'],'referenceRequirements':len(closure['requirements']),'referenceCounts':closure['summary'],'restoreCounts':counts,'privacyVerification':privacy,'currentSeedAccounting':ac,'currentInvocationSummary':summary,'actualPreparationPhaseHistory':history,'preservedOutcomes':preserved,'acceptedFinalRetentionScope':'accepted','sourceFreezeReleaseGate':{'successfulCapturedIntegrity':True,'sevenLiveTargetsVerified':True,'all495OriginalsStableThroughFinalGate':True,'releaseAuthorizedByThisVerifier':False,'noClaimAboutChangesAfterGate':True},'nativeByteReadbackVerified':False,'fullProjectTypeScriptPassed':False,'releaseReady':False,'scope':{'freshArchivesReplayedThroughXZEOF':True,'priorChainReusedByExactMetadataAndTerminalReceipts':True,'inheritedArchivePayloadReads':0,'supplementArchivePayloadReads':0,'independentVerifierSeedReads':0,'freshOriginalPayloadReadsOnly':495,'noUnchangedLiveSourceRead':True,'noFullSourceClone':True,'noExcludedRawReadRefetchOrRecovery':True,'noProductCompilerBuildOrUiExecution':True,'noPublishOrUpload':True},'resources':{'addressSpaceLimitBytes':LIMIT,'chunkBytes':CHUNK,'wallSeconds':round(time.monotonic()-started,3),'maxRssKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
 replay=C/'INDEPENDENT-NEW-MEMBER-REPLAY-MANIFEST-v1.json';ck(not replay.exists(),'immutable replay manifest already exists')
 replay_raw=(json.dumps({'result':'PASS_FRESH_MEMBER_HASH_REPLAY','archives':archivechecks,'files':list(fresh.values()),'inverseMappings':inverses,'scopeOriginalFiles':495},indent=2)+'\n').encode()
 with replay.open('xb') as f:f.write(replay_raw)
 out['memberReplayManifest']={'path':str(replay),**bp(replay_raw)}
 raw=(json.dumps(out,indent=2)+'\n').encode()
 with output.open('xb') as f:f.write(raw)
 print(json.dumps({'result':out['result'],'output':{'path':str(output),**bp(raw)},'freshArchives':len(archives),'freshMembers':len(fresh),'originalFiles':495,'sourceProjectFiles':703,'nativeByteReadbackVerified':False}))
if __name__=='__main__':main()
