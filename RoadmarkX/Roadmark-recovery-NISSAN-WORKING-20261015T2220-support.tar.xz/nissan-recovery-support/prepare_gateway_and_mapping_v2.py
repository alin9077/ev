import pathlib,json,hashlib,datetime,ast
C=pathlib.Path(__file__).resolve().parent

def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(name,obj):
 p=C/name
 with p.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
 return pin(p)
def exact_replace(text,old,new,count):
 assert text.count(old)==count,(old,text.count(old),count)
 return text.replace(old,new)
g=C/'nissan_phase_gateway_v1.py';text=g.read_text()
changes=[("assert len(c['locations'])==1 and c['locations'][0]['pointer']=='/authorization'","assert c['locations']==['/authorization']",1),("assert len(mapping['files'])==len(rows)","assert len(mapping['files'])==len(rows)\n assert cap.load(receipt['sanitationMapping']['path'])['files']==mapping['files']",1),(";assert row['originalSHA256']==c['sha256']",";assert row['originalPath']==c['originalPath'];assert row['originalSHA256']==c['sha256']",1),('from nissan_privacy_adapter_v1 import configure','from nissan_privacy_adapter_v2 import configure',3)]
for old,new,count in changes:text=exact_replace(text,old,new,count)
ast.parse(text)
with (C/'nissan_phase_gateway_v2.py').open('x') as f:f.write(text)
p=C/'nissan_privacy_adapter_v1.py';text=exact_replace(p.read_text(),'NISSAN-ADAPTER-PREPARATION-v1.json','NISSAN-ADAPTER-PREPARATION-v2.json',1);ast.parse(text)
with (C/'nissan_privacy_adapter_v2.py').open('x') as f:f.write(text)
p=C/'NISSAN-ADAPTER-PREPARATION-v1.json';d=json.loads(p.read_text());d['preparedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['supersedesUnexecutedPreparation']=pin(p)
for row in d['localPins']:
 for old,new in [('nissan_phase_gateway_v1.py','nissan_phase_gateway_v2.py'),('nissan_privacy_adapter_v1.py','nissan_privacy_adapter_v2.py')]:
  if row['path']==str(C/old):row.update(pin(C/new))
for key,argv in d['preparedInvocations'].items():d['preparedInvocations'][key]=[x.replace('/nissan_phase_gateway_v1.py','/nissan_phase_gateway_v2.py') for x in argv]
d['gateSchemas']['privacy']['preparationPath']=str(C/'NISSAN-ADAPTER-PREPARATION-v2.json')
d['schemaCorrection']={'scope':'Actual locations string-list check, exact mapping.files equality, exact originalPath match, and pin the current gateway/privacy pair through preparationv2','gatewayBefore':pin(g),'gatewayAfter':pin(C/'nissan_phase_gateway_v2.py'),'privacyBefore':pin(C/'nissan_privacy_adapter_v1.py'),'privacyAfter':pin(C/'nissan_privacy_adapter_v2.py'),'actualPreflight':pin(C/'JSON-SANITIZER-CANDIDATES-v1.json'),'reviewedParentPreparationFailure':pin(C/'PARENT-GATEWAY-PREPARATION-FAILURE-v1.json'),'oldGatewayExecuted':False,'allRenaultSourcePrivacyCodeUnchanged':True,'selfArgv0LiteralsUnchangedAndUnusedByModes':True}
prep=write('NISSAN-ADAPTER-PREPARATION-v2.json',d)
proposal=C/'PROSE-KEY-RENAME-PROPOSAL-v1.json';classification=C/'INDEPENDENT-NISSAN-JSON-CANDIDATE-CLASSIFICATION-v1.json';assert pin(proposal)['sha256']=='d8708b395690b2ccfe1a5955b3bf39a978f480dd5b1ce8cf8eaeaf800de5953d';assert pin(classification)['sha256']=='9ee78da8c7db71ae6e0750868c604caa7970a982deabc4dbedf176140dd6ca9b'
grant=write('ROOT-COPY-KEY-RENAME-GRANT-v1.json',{'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'approvalScope':'Root approved only the12 exact copied /authorization to /approvalScope key renames in the pinned proposal under the pinned independent classification. Preserve values, every outside-key byte, originals/expected pins and exact inverse. No actual headers, credentials or blanket field renames; every delivered member remains subject to full privacy scans.','proposal':pin(proposal),'classification':pin(classification),'originalsMayBeChanged':False,'onlyExactListedCopies':True})
pr=json.loads(proposal.read_text());m={'schemaVersion':1,'status':'APPROVED_EXACT_COPY_ONLY_PROSE_KEY_MAPPING','files':pr['files'],'originalExpectedPinsUnchanged':True,'originalsUnchanged':True,'secretMaterialChanged':False,'valuesAndOtherBytesPreserved':True,'inverseOperation':pr['inverseOperation'],'rootApproval':grant,'classification':pin(classification),'proposal':pin(proposal),'mappingPreparedBeforeCapture':True}
a=write('PROSE-KEY-RENAME-APPROVALS.json',m);s=write('COPY-SANITATION-MAPPING.json',{**m,'purpose':'Exact inverse reconstruction for the12 approved copied ordinary-prose metadata key changes'})
gate=write('NISSAN-CAPTURE-CANDIDATE-APPROVAL-v1.json',{'status':'INDEPENDENTLY_ACCEPTED_EXACT_NISSAN_COPY_MAPPING','preflight':pr['candidateReport'],'renameMapping':a,'sanitationMapping':s,'review':pin(classification),'rootApproval':grant,'proposal':pin(proposal),'mappingCount':12,'independentClassificationAndRootApprovalBothRequired':True,'noBlanketFieldExemption':True,'captureHasNotYetRun':True})
print(json.dumps({'preparation':prep,'gateway':pin(C/'nissan_phase_gateway_v2.py'),'privacy':pin(C/'nissan_privacy_adapter_v2.py'),'mapping':a,'sanitation':s,'gate':gate}))
