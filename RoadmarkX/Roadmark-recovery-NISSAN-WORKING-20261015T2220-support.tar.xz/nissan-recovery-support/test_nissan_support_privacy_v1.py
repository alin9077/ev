#!/usr/bin/env python3
"""Pure bounded mutations of exact approved code fixtures; never configure or scan."""
import ast,collections,copy,hashlib,importlib.util,json,pathlib,resource
P=pathlib.Path;C=P(__file__).resolve().parent
ADAPTER={'path': '/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/nissan-working-20261015T2220/nissan_support_privacy_adapter_v1.py', 'bytes': 8424, 'sha256': 'd167b4f3e3416179f80bbfdab93c6c197eadb063cddbefe5438df8957f07bcdb'}
CLASSIFICATION={'path':str(C/'INDEPENDENT-NISSAN-SUPPORT-SYNTAX-CLASSIFICATION-v1.json'),'bytes':51429,'sha256':'af17f9506d6cf5b2e9b8bd47597370d5497882b23c3779f02b66c92309493bd4'}
def pin(p):
    b=P(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def checked(ref):
    assert pin(ref['path'])==ref;return P(ref['path']).read_bytes()
def main():
    resource.setrlimit(resource.RLIMIT_AS,(256*1024*1024,256*1024*1024))
    checked(ADAPTER);doc=json.loads(checked(CLASSIFICATION))
    spec=importlib.util.spec_from_file_location('exact_nissan_support_classifier',ADAPTER['path']);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    counts=collections.Counter();fixtures=[]
    def reject(label,fn):
        try:fn()
        except (ValueError,AssertionError,KeyError,IndexError):counts[label]+=1
        else:raise AssertionError('Mutation unexpectedly accepted: '+label)
    for f in doc['files']:
        p=P(f['originalPath']);assert p.parent==C and p.name.startswith('independent_nissan_recovery_v') and p.suffix=='.py'
        data=checked({'path':str(p),**f['filePin']});name=f['member'];rows=[r for r in doc['exactSupportCodeClassifications'] if r['member']==name]
        candidates=[copy.deepcopy(r['exactFinding']) for r in rows]
        blocked,result=module.classify_exact(candidates,data,name,doc)
        assert not blocked and result==[r for r in doc['expectedClassifiedRecords'] if r['member']==name];counts['exact_baseline']+=1
        for i in range(len(rows)):
            missing=candidates[:i]+candidates[i+1:];reject('missing',lambda:module.classify_exact(missing,data,name,doc))
            duplicate=candidates+[copy.deepcopy(candidates[i])];reject('duplicate',lambda:module.classify_exact(duplicate,data,name,doc))
            changed=copy.deepcopy(candidates);changed[i]['valueLength']+=1;reject('changed_finding',lambda:module.classify_exact(changed,data,name,doc))
        extra={'kind':'unreviewed-extra-candidate','location':{'line':1}}
        blocked,result=module.classify_exact(candidates+[extra],data,name,doc);assert blocked==[extra] and len(result)==len(rows);counts['extra_remains_blocking']+=1
        original=[extra];blocked,result=module.classify_exact(original,data,'unlisted-member.py',doc);assert blocked is original and not result;counts['unlisted_unchanged']+=1
        reject('changed_file',lambda:module.classify_exact(candidates,data+b' ',name,doc))
        for field,value,label in [('matchedSyntaxSHA256','0'*64,'changed_span'),('keyLiteralSHA256','0'*64,'changed_key_hash'),('astFunction','unapproved_function','changed_ast_function'),('astOperation','Assign','changed_ast_operation'),('astRole','unapproved_role','changed_ast_role')]:
            altered=copy.deepcopy(doc);target=next(r for r in altered['exactSupportCodeClassifications'] if r['member']==name);target[field]=value
            reject(label,lambda:module.classify_exact(candidates,data,name,altered))
        fixtures.append({'member':name,'originalCode':{'path':str(p),**f['filePin']}})
    assert len(fixtures)==9 and counts['exact_baseline']==9 and counts['missing']==counts['duplicate']==counts['changed_finding']==24
    result={'result':'PASS_EXACT_NISSAN_SUPPORT_CLASSIFIER_MUTATION_TESTS','adapter':ADAPTER,'classification':CLASSIFICATION,'testScript':pin(P(__file__).resolve()),'fixtures':fixtures,'cases':dict(counts),'scope':{'pureClassifierOnly':True,'configureCalled':False,'seedLoading':False,'archiveReads':False,'scannerRuns':False,'packaging':False,'sourceBytesChanged':False,'onlyNineExactApprovedCodeFixturesRead':True}}
    p=C/'NISSAN-SUPPORT-ADAPTER-TEST-RESULT-v1.json'
    with p.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({'result':result['result'],'output':pin(p),'cases':dict(counts)}))
if __name__=='__main__':main()
