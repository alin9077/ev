#!/usr/bin/env python3
"""Bounded Nissan31 metadata closure / restore plan. No archive or source payload reads.
Run only after independent review, with an exact SHA256-sealed input manifest.
"""
import argparse, collections, copy, datetime, hashlib, json, os, pathlib, resource, stat, time
P = pathlib.Path
C = P(__file__).resolve().parent
CONFIG = {'path': str(C / 'NISSAN-REFERENCE-CONFIG-v1.json'), 'bytes': 16143,
          'sha256': '62d4b02318ae71df2236b889582875c981ebb42c13d4df25bcb8bdd6878d2e22'}
REQUIRED = ('source-capture.json', 'proof-capture-v1.json', 'source-package.json',
            'proof-packages-v1.json', 'FROZEN-CAPTURE-SCOPE.json',
            'PROSE-KEY-RENAME-APPROVALS.json', 'COPY-SANITATION-MAPPING.json')
OPTIONAL = ('RUNTIME-REFERENCE-EXCLUSION-APPROVALS-v1.json', 'ARCHIVE-PLAN-v2.json',
            'INDEPENDENT-NISSAN-REFERENCE-CLOSURE-v1.json')
READ_PINS = {}
LIMIT = 256 * 1024 * 1024


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def core(row):
    return {k: row[k] for k in ('path', 'bytes', 'sha256')}


def key(row):
    return row['bytes'], row['sha256']


def valid_pin(row):
    return (isinstance(row, dict) and isinstance(row.get('path'), str)
            and type(row.get('bytes')) is int and row['bytes'] >= 0
            and isinstance(row.get('sha256'), str) and len(row['sha256']) == 64
            and all(c in '0123456789abcdef' for c in row['sha256']))


def regular_path(path):
    p = P(path)
    need(p.is_absolute() and '..' not in p.parts, 'Noncanonical metadata path: ' + str(p))
    for q in [p, *p.parents]:
        need(not stat.S_ISLNK(q.lstat().st_mode), 'Symlink metadata path: ' + str(q))
    need(stat.S_ISREG(p.lstat().st_mode), 'Not a regular metadata file: ' + str(p))
    return p


def read_json(ref):
    need(valid_pin(ref), 'Malformed metadata pin')
    need(ref['bytes'] <= 32 * 1024 * 1024, 'Metadata file exceeds bounded limit')
    p = regular_path(ref['path'])
    need(p.suffix == '.json', 'Only JSON metadata may be read')
    fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as f:
        before = os.fstat(f.fileno())
        raw = f.read(ref['bytes'] + 1)
        after = os.fstat(f.fileno())
    need((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
         == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
         'Metadata changed during read: ' + str(p))
    need(len(raw) == ref['bytes'] and hashlib.sha256(raw).hexdigest() == ref['sha256'],
         'Metadata pin mismatch: ' + str(p))
    READ_PINS[str(p)] = core(ref)
    return json.loads(raw)


def write_new(name, value):
    need(P(name).name == name and name.endswith('.json'), 'Output must be a checkpoint JSON basename')
    p = C / name
    raw = (json.dumps(value, indent=2) + '\n').encode()
    fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
    with os.fdopen(fd, 'wb') as f:
        f.write(raw)
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def field(obj, path):
    for part in path.split('.'):
        obj = obj[part]
    return obj


def archive_identity(a):
    return {k: a[k] for k in ('filename', 'bytes', 'sha256', 'library_file_id', 'file_id', 'version') if k in a}


def member_index(archives):
    out = {}
    for a in archives:
        need(a.get('allMembersVerified') is True, 'Fresh package is not verified: ' + a['filename'])
        need(a['members'] == len(a['memberFiles']), 'Archive member count mismatch')
        for r in a['memberFiles']:
            need(valid_pin(r) and not P(r['path']).is_absolute() and '..' not in P(r['path']).parts,
                 'Unsafe or malformed logical member')
            need(r['path'] not in out, 'Duplicate fresh member: ' + r['path'])
            out[r['path']] = {'member': core(r), 'archives': [a['filename']],
                              'partResolution': 'Exact single archive'}
    return out


def load_context(seal_path, seal_sha, mode):
    conf = read_json(CONFIG)
    need(str(C) == conf['checkpoint'], 'Wrong checkpoint')
    sp = regular_path(seal_path)
    need(sp.parent == C and sp.name.startswith('NISSAN-REFERENCE-INPUTS-') and sp.suffix == '.json',
         'Input seal must be an immutable named checkpoint input manifest')
    seal = read_json({'path': str(sp), 'bytes': sp.stat().st_size, 'sha256': seal_sha})
    need(seal.get('schemaVersion') == 1 and seal.get('mode') == mode, 'Wrong input seal schema/mode')
    refs = seal['inputs']
    names = [P(r['path']).name for r in refs]
    need(len(names) == len(set(names)) and set(REQUIRED) <= set(names), 'Missing/duplicate required input')
    need(set(names) <= set(REQUIRED + OPTIONAL), 'Unreviewed input basename')
    for r in refs:
        need(P(r['path']).parent == C, 'Current input outside checkpoint')
    current = {P(r['path']).name: read_json(r) for r in refs}
    fixed = {k: read_json(v) for k, v in conf['metadata'].items()}
    base = fixed['baseManifest']; bp = fixed['baseRestore']; plan = fixed['plan']
    need(len(base['files']) == conf['expected']['baseLogicalFiles'], 'Wrong base logical count')
    need(len(base['archivesInRestoreOrder']) == len(bp['archivesInRestoreOrder']) == 142,
         'Wrong base archive count')
    base_archives = {a['filename']: a for a in base['archivesInRestoreOrder']}
    order = bp['archivesInRestoreOrder']
    need(len(base_archives) == 142 and {a['filename'] for a in order} == set(base_archives),
         'Base restore-plan archive set differs')
    for a in order:
        need(key(a) == key(base_archives[a['filename']]), 'Base restore-plan identity differs')
    source_name = plan['base']['sourceArchive']['filename']
    need(source_name in base_archives and key(base_archives[source_name]) == key(plan['base']['sourceArchive']),
         'Wrong replaced standalone source')
    reused = [base_archives[a['filename']] for a in order if a['filename'] != source_name]
    need(len(reused) == 141, 'Wrong current non-source reuse count')
    scope = current['FROZEN-CAPTURE-SCOPE.json']; src = current['source-capture.json']; cap = current['proof-capture-v1.json']
    need(core(scope['freezeMetadata']) == core(conf['expected']['freeze']), 'Wrong final freeze')
    need(len(cap['files']) == conf['expected']['proofCaptureFiles'], 'Wrong proof capture count')
    need(len(src['files']) == conf['expected']['sourceFiles'], 'Wrong source capture count')
    need(len({r['originalPath'] for r in cap['files']}) == len(cap['files']), 'Duplicate proof original path')
    need({r['originalPath'] for r in cap['files']} == {r['path'] for r in scope['files']},
         'Proof capture differs from exact scope')
    need({r['path'] for r in src['files']} == set(scope['expectedSourcePaths']), 'Source paths differ from freeze')
    source = current['source-package.json']; proofs = current['proof-packages-v1.json']['archives']
    need(source['bytes'] < conf['expected']['maximumCompressedSourceBytesExclusive'], 'Source exceeds size cap')
    need(source['members'] == conf['expected']['sourceMembers'], 'Wrong source archive member count')
    fresh = member_index([source] + proofs)
    for r in src['files']:
        n = 'roadmark/' + r['path']
        need(n in fresh and key(r) == key(fresh[n]['member']), 'Source capture/package disagreement: ' + n)
    expected_source_members = {'roadmark/' + r['path'] for r in src['files']} | {'roadmark/SOURCE-FILE-MANIFEST.json'}
    need({r['path'] for r in source['memberFiles']} == expected_source_members, 'Unexpected source package members')
    need({n for n in fresh if n.startswith('roadmark/')} == expected_source_members, 'Unexpected source overlay members')
    for r in cap['files']:
        need(r['path'] in fresh and key(r) == key(fresh[r['path']]['member']),
             'Proof capture/package disagreement: ' + r['path'])
    return conf, current, fixed, reused, fresh


def logical(path, workspace):
    p = P(path); w = P(workspace)
    if p.is_relative_to('/tmp'):
        return p.relative_to('/tmp').as_posix()
    if p.is_relative_to(w / 'roadmark-104'):
        return 'roadmark/' + p.relative_to(w / 'roadmark-104').as_posix()
    if p.is_relative_to(w):
        return p.relative_to(w).as_posix()
    return None


def closure(conf, cur, fixed, reused, fresh):
    base = fixed['baseManifest']; prior = fixed['baseClosure']; old = {r['path']: r for r in base['files']}
    allowed_archives = {a['filename']: a for a in reused}
    mapping = {}; mapping_sources = []; requirements = {}; metadata = []; captured_bytes = 0
    # Exact bounded traversal of captured JSON only. Never follow discovered paths.
    for row in cur['proof-capture-v1.json']['files']:
        if P(row['originalPath']).suffix != '.json':
            continue
        p = P(row['payloadPath'])
        need(p.is_relative_to(C) and p.suffix == '.json', 'Captured JSON is outside checkpoint')
        ref = {'path': str(p), 'bytes': row['bytes'], 'sha256': row['sha256']}
        captured_bytes += ref['bytes']
        need(captured_bytes <= conf['limits']['maximumCapturedJsonBytes'], 'Captured JSON budget exceeded')
        obj = read_json(ref); origin = len(metadata)
        metadata.append({'originalPath': row['originalPath'], 'storedMember': row['path'], 'storedPin': ref})
        stack = [(obj, 0)]; visited = 0
        while stack:
            value, depth = stack.pop(); visited += 1
            need(depth <= conf['limits']['maximumJsonDepth'] and visited <= conf['limits']['maximumJsonNodes'],
                 'Captured JSON traversal limit exceeded')
            if isinstance(value, dict):
                if isinstance(value.get('path'), str) and value['path'].startswith('/') and {'bytes', 'sha256'} <= value.keys():
                    need(valid_pin(value), 'Malformed absolute reference pin in ' + row['path'])
                    requirements.setdefault((value['path'], value['bytes'], value['sha256']), set()).add(origin)
                stack.extend((v, depth + 1) for v in value.values())
            elif isinstance(value, list):
                stack.extend((v, depth + 1) for v in value)
    needed_keys = {(n, h) for _, n, h in requirements}
    needed_members = {n for n, r in old.items() if key(r) in needed_keys}

    def add(member, archives, resolution, authority):
        n = member['path']
        if n not in needed_members:
            return
        need(core(member) == core(old[n]), 'Mapping member differs from final prior logical bytes: ' + n)
        if not archives or not set(archives) <= set(allowed_archives):
            return  # Replaced source or an explicitly outside-chain artifact is not reused.
        mapping.setdefault(n, {'member': core(member), 'archives': archives,
                               'partResolution': resolution, 'mappingAuthority': authority})

    for r in prior['requirements']:
        n = r.get('member')
        if n in old and r['kind'] in ('fresh-exact', 'base-exact') and key(r['expected']) == key(old[n]):
            add(old[n], r['archives'], r.get('partResolution', 'Exact single archive'), conf['metadata']['baseClosure'])
    for a in fixed['baseArchivePlan']['archives']:
        for r in a['memberFiles']:
            if r['path'] in old and key(r) == key(old[r['path']]):
                add(r, [a['filename']], 'Exact single archive', conf['metadata']['baseArchivePlan'])
    for spec in conf['inheritedMappingAuthorities']:
        if needed_members <= mapping.keys():
            break
        obj = read_json(spec['pin']); mapping_sources.append(spec['pin'])
        if spec['kind'] in ('archive-list', 'single-package'):
            archives = field(obj, spec['field']) if spec['kind'] == 'archive-list' else [obj]
            for a in archives:
                for r in a['memberFiles']:
                    if r['path'] in old and key(r) == key(old[r['path']]):
                        add(r, [a['filename']], 'Exact single archive', spec['pin'])
        else:
            for r in field(obj, spec['field']):
                n = r['member']['path'] if isinstance(r['member'], dict) else r['member']
                if n in old and key(r['expected']) == key(old[n]):
                    add(old[n], r['mapping']['archives'], r['mapping']['partResolution'], spec['pin'])
    for r in fixed['baseReuse']['files']:
        n = r['retainedMember']
        if n in old and key(r) == key(old[n]):
            add(old[n], [r['retainedArchive']['filename']], 'Exact single archive', conf['metadata']['baseReuse'])
    supplemental = {}
    for s in conf['deliveryOnlySupplements']:
        pkg = read_json(s['package']); inv = read_json(s['inventory'])
        need(key(pkg) == key(s['identity']) and pkg['filename'] == s['identity']['filename'], 'Supplement package identity mismatch')
        need(pkg['outsideRecoveryArchiveSet'] is True and pkg['unchangedRecoveryArchiveCount'] == 142,
             'Supplement is not separately declared')
        pm = {r['path']: core(r) for r in pkg['members']}; im = {r['path']: core(r) for r in inv['files']}
        need(pm == im and len(pm) == pkg['memberCount'], 'Supplement inventory/package differs')
        need(pkg['filename'] not in allowed_archives, 'Supplement wrongly in recovery chain')
        for r in inv['files']:
            supplemental.setdefault((r['originalPath'], r['bytes'], r['sha256']), []).append(
                {'member': core(r), 'archive': s['identity'], 'package': s['package'], 'inventory': s['inventory']})
    renames = cur['PROSE-KEY-RENAME-APPROVALS.json']['files']; sanitation = cur['COPY-SANITATION-MAPPING.json']
    need(renames == sanitation['files'], 'Rename approvals/sanitation mappings differ')
    rename_by = {r['restorePath']: r for r in renames}
    need(len(rename_by) == len(renames), 'Duplicate rename member')
    originals = collections.defaultdict(list)
    cap_by = {r['path']: r for r in cur['proof-capture-v1.json']['files']}
    for n, r in cap_by.items():
        if key(r) != (r['originalBytes'], r['originalSHA256']):
            need(n in rename_by, 'Unreviewed capture transform: ' + n)
            a = rename_by[n]
            need(a['originalPath'] == r['originalPath'] and key(a) == key(r)
                 and (a['originalBytes'], a['originalSHA256']) == (r['originalBytes'], r['originalSHA256'])
                 and a['unchangedValueAndOtherBytes'] is True and a['classification'] == 'ordinary-noncredential-approval-prose'
                 and a['oldPointer'] == '/authorization' and a['newPointer'] == '/approvalScope',
                 'Rename is not an exact reviewed reversible prose key')
            originals[(r['originalBytes'], r['originalSHA256'])].append(n)
    need(set(rename_by) == {n for names in originals.values() for n in names}, 'Unused or unproved rename approval')
    # Prior approved prose transforms remain reversible; their original hashes are not stored hashes.
    inherited_inverse = {}
    prior_approval_pin = next(r for r in prior['inputPins'] if r['path'] == str(P(conf['baseCheckpoint']) / 'PROSE-KEY-RENAME-APPROVALS.json'))
    prior_sanitation_pin = next(r for r in prior['inputPins'] if r['path'] == str(P(conf['baseCheckpoint']) / 'COPY-SANITATION-MAPPING.json'))
    pa = read_json(prior_approval_pin)['files']; ps = read_json(prior_sanitation_pin)['files']
    need(pa == ps, 'Inherited approval/sanitation metadata differs')
    for a in pa:
        req = (a['originalPath'], a['originalBytes'], a['originalSHA256'])
        if req not in requirements:
            continue
        n = a['restorePath']
        need(n in old and key(old[n]) == key(a) and a['unchangedValueAndOtherBytes'] is True
             and a['classification'] == 'ordinary-noncredential-approval-prose'
             and a['oldPointer'] == '/authorization' and a['newPointer'] == '/approvalScope',
             'Inherited inverse is not exactly reviewed')
        archives = [ar['filename'] for ar in fixed['baseArchivePlan']['archives']
                    if ar['filename'] in allowed_archives
                    and any(core(m) == core(old[n]) for m in ar['memberFiles'])]
        need(len(archives) == 1, 'Inherited inverse lacks exact retained single-archive member')
        inherited_inverse[req] = {'member': core(old[n]), 'archives': archives,
            'partResolution': 'Exact single archive', 'storedPin': {z: a[z] for z in ('bytes', 'sha256')},
            'mappingAuthority': conf['metadata']['baseArchivePlan'],
            'inverse': {'replaceKeyOnce': {'from': 'approvalScope', 'to': 'authorization'},
                'valueAndOtherBytesUnchanged': True, 'mapping': prior_sanitation_pin,
                'approvalAuthority': prior_approval_pin}}
    runtime = {(r['expected']['path'], r['expected']['bytes'], r['expected']['sha256']):
               {'category': r['category'], 'basis': conf['metadata']['baseClosure'],
                'justification': r['reconstruction']} for r in prior['requirements']
               if r['kind'] == 'reference-only-runtime-exclusion'}
    extra_runtime = cur.get('RUNTIME-REFERENCE-EXCLUSION-APPROVALS-v1.json', {})
    for r in extra_runtime.get('files', []):
        e = r['expected']; p = P(e['path']); w = P(conf['workspace']) / 'roadmark-104'
        category = r['category']
        bounded = ((category == 'external-system-binary' and str(p) == '/usr/bin/timeout')
                   or (category == 'installed-package-toolchain' and p.is_relative_to(w / 'node_modules'))
                   or (category == 'generated-next-types' and p.is_relative_to(w / '.next'))
                   or (category == 'reconstructible-compiler-cache' and p == w / 'tsconfig.tsbuildinfo'))
        need(valid_pin(e) and bounded and r.get('independentlyReviewed') is True
             and isinstance(r.get('justification'), str) and r['justification'].strip(),
             'Runtime exclusion lacks exact bounded independent justification')
        need(valid_pin(r.get('reviewAuthority')), 'Runtime exclusion lacks exact review authority')
        runtime[(e['path'], e['bytes'], e['sha256'])] = {'category': category,
             'justification': r['justification'], 'reviewAuthority': r['reviewAuthority']}
    pending_by = {(r['expected']['path'], r['expected']['bytes'], r['expected']['sha256']): r
                  for r in conf['pendingSupportCandidates']}
    pending = {k: copy.deepcopy(r) for k, r in pending_by.items() if r['mandatory']}
    fresh_keys = collections.defaultdict(list); old_keys = collections.defaultdict(list)
    for n, r in fresh.items():
        fresh_keys[key(r['member'])].append(n)
    for n, r in mapping.items():
        old_keys[key(r['member'])].append(n)
    deps = copy.deepcopy(base['inheritedDependencyReconstruction']['dependencies'])
    dep_by = {d['originalPath']: d for d in deps}; new_records = new_variants = 0
    results = []; unresolved = []; counts = collections.Counter()
    def choose(names, path):
        direct = logical(path, conf['workspace'])
        return direct if direct in names else sorted(names)[0]
    for req, origins in sorted(requirements.items()):
        path, nbytes, digest = req; k = (nbytes, digest)
        result = {'expected': {'path': path, 'bytes': nbytes, 'sha256': digest}, 'nominatedBy': sorted(origins)}
        if fresh_keys[k]:
            n = choose(fresh_keys[k], path); result.update(kind='fresh-exact', **fresh[n])
        elif originals[k]:
            n = choose(originals[k], path); a = rename_by[n]
            result.update(kind='fresh-reversible-original', **fresh[n],
                storedPin={z: a[z] for z in ('bytes', 'sha256')},
                inverse={'replaceKeyOnce': {'from': 'approvalScope', 'to': 'authorization'},
                         'valueAndOtherBytesUnchanged': True, 'mapping': str(C / 'COPY-SANITATION-MAPPING.json')})
        elif old_keys[k]:
            n = choose(old_keys[k], path); result.update(kind='base-exact', **mapping[n])
            record = {'expected': result['expected'], 'reconstructFrom': 'exact inherited recommended-chain member',
                      'member': core(old[n])}
            if path not in dep_by:
                dep_by[path] = {'originalPath': path, 'pins': []}; deps.append(dep_by[path]); new_records += 1
            if not any(x['expected'] == record['expected'] and x['member'] == record['member'] for x in dep_by[path]['pins']):
                dep_by[path]['pins'].append(record); new_variants += 1
        elif req in inherited_inverse:
            result.update(kind='base-reversible-original', **inherited_inverse[req])
        elif req in supplemental:
            result.update(kind='delivery-supplement-exact-outside-recovery', **supplemental[req][0])
        elif req in pending_by:
            pending[req] = copy.deepcopy(pending_by[req]); result.update(kind='pending-fresh-support',
                member=pending_by[req]['member'], notRetainedByOldArchives=True)
        elif req in runtime:
            result.update(kind='reference-only-runtime-exclusion', **runtime[req],
                reconstruction='Not supplied by recovery; separately authorized runtime must verify the original expected pin. Generated bytes are not promised to reproduce exactly.')
        else:
            result.update(kind='UNRESOLVED_NONRUNTIME_OR_UNAPPROVED_RUNTIME',
                          reason='No exact retained member, reviewed reversible transform, pending support authority, or exact runtime exclusion. Never reconstruct unavailable mutable drafts.')
            unresolved.append(result)
        counts[result['kind']] += 1; results.append(result)
    # Preserve inherited reconstruction records verbatim; append only proven exact chain mappings.
    need(deps[:len(base['inheritedDependencyReconstruction']['dependencies'])] == base['inheritedDependencyReconstruction']['dependencies']
         or all(d['pins'][:len(o['pins'])] == o['pins'] and d['originalPath'] == o['originalPath']
                for d, o in zip(deps, base['inheritedDependencyReconstruction']['dependencies'])),
         'Inherited dependency records changed')
    for d in deps:
        for r in d['pins']:
            need(r['member']['path'] in old and core(old[r['member']['path']]) == core(r['member'])
                 and key(r['expected']) == key(r['member']), 'Inherited dependency identity mismatch')
    out = {'schemaVersion': 1, 'result': 'BLOCKED_UNRESOLVED_REFERENCES' if unresolved else 'EXACT_METADATA_CLOSURE_PENDING_FRESH_SUPPORT',
           'summary': dict(counts), 'metadataSources': metadata, 'requirements': results,
           'unresolvedReferences': unresolved, 'pendingSupportMap': list(pending.values()),
           'inheritedDependencyProposal': {'inheritedRecords': len(base['inheritedDependencyReconstruction']['dependencies']),
               'newRecords': new_records, 'newPinVariants': new_variants, 'proposedRecords': len(deps),
               'canonicalSha256': hashlib.sha256(json.dumps(deps, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
               'dependencies': deps},
           'deliveryOnlySupplementsOutsideRecovery': conf['deliveryOnlySupplements'],
           'originalExpectedPathsAndHashesUnchanged': True, 'transformedBytesNeverClaimOriginalHash': True,
           'exactCurrentSourceCounts': {'files': len(cur['source-capture.json']['files']), 'archiveMembers': cur['source-package.json']['members']},
           'historicalLimitations': fixed['plan']['historicalLimitations'],
           'inheritedSanitationAuthorities': {'baseManifest': conf['metadata']['baseManifest'],
               'jsonPointers': ['/copyOnlySanitation', '/inheritedRecoveryMetadata', '/inheritedBoundaries']},
           'scope': {'metadataOnly': True, 'externalPayloadReads': 0, 'archivePayloadReads': 0,
                     'seedValueReads': 0, 'liveWrites': 0, 'freshReplayStillRequired': True},
           'fullProjectTypeScriptPassed': False, 'releaseReady': False, 'nativeByteReadbackVerified': False}
    return out


def restore(conf, cur, fixed, reused, fresh):
    need('ARCHIVE-PLAN-v2.json' in cur and 'INDEPENDENT-NISSAN-REFERENCE-CLOSURE-v1.json' in cur,
         'Restore requires sealed actual archive plan and closure')
    closure_doc = cur['INDEPENDENT-NISSAN-REFERENCE-CLOSURE-v1.json']
    need(closure_doc['result'] == 'EXACT_METADATA_CLOSURE_PENDING_FRESH_SUPPORT'
         and not closure_doc['unresolvedReferences'], 'Reference closure is blocked')
    prior_inputs = {r['path']: r for r in closure_doc['inputPins']}
    for name in REQUIRED:
        path = str(C / name)
        need(prior_inputs.get(path) == READ_PINS[path], 'Closure/current input identity differs: ' + name)
    need(closure_doc.get('configuration') == CONFIG, 'Closure configuration differs')
    new = cur['ARCHIVE-PLAN-v2.json']['archives']; all_new = member_index(new)
    source = cur['source-package.json']; proof = cur['proof-packages-v1.json']['archives']
    need(len({a['filename'] for a in new}) == len(new), 'Duplicate new archive')
    expect = [source] + proof
    need(len(new) >= len(expect) and [a['filename'] for a in new[:len(expect)]] == [a['filename'] for a in expect],
         'Current source/proof order differs from exact packaging order')
    for a, b in zip(new, expect):
        need(key(a) == key(b) and a['memberFiles'] == b['memberFiles'], 'Current archive plan/package mismatch')
    for n, r in fresh.items():
        need(n in all_new and all_new[n] == r, 'Fresh source/proof mapping changed')
    for r in closure_doc['pendingSupportMap']:
        n = r['member']; need(n in all_new and key(all_new[n]['member']) == key(r['expected']),
                             'Pending support not packaged exactly: ' + n)
    ars = []
    for a in reused:
        ars.append({**{k: v for k, v in a.items() if k not in ('restoreOrder', 'new', 'memberFiles')}, 'new': False})
    for a in new:
        need(a['filename'] not in {x['filename'] for x in ars}, 'Archive duplicates inherited chain')
        ars.append({**{k: v for k, v in a.items() if k not in ('restoreOrder', 'new', 'memberFiles')}, 'new': True})
    for order, a in enumerate(ars, 1):
        a['restoreOrder'] = order
    files = {r['path']: core(r) for r in fixed['baseManifest']['files'] if not r['path'].startswith('roadmark/')}
    fresh_rows = [core(r) for a in new for r in a['memberFiles']]
    files.update({r['path']: r for r in fresh_rows})
    for d in closure_doc['inheritedDependencyProposal']['dependencies']:
        for r in d['pins']:
            need(files.get(r['member']['path']) == core(r['member']), 'Overlay invalidates inherited dependency')
    need({n for n in files if n.startswith('roadmark/')} == {r['path'] for r in source['memberFiles']}, 'Final source member set mismatch')
    supplements = {s['identity']['filename'] for s in conf['deliveryOnlySupplements']}
    need(not supplements & {a['filename'] for a in ars}, 'Delivery-only supplement inflated recovery count')
    return {'status': 'EXACT_NEW_ARCHIVES_PLUS_REUSED_PRIOR_CHAIN', 'archivesInRestoreOrder': ars,
            'files': list(files.values()), 'newFiles': fresh_rows, 'newArchives': new, 'source': source,
            'baseManifest': conf['metadata']['baseManifest'],
            'baseFinalReceipt': next(r['expected'] for r in conf['pendingSupportCandidates'] if P(r['expected']['path']).name == 'FINAL-RENAULT-UPLOAD-RECEIPTS.json'),
            'baseTerminalReceipt': next(r['expected'] for r in conf['pendingSupportCandidates'] if P(r['expected']['path']).name == 'INDEPENDENT-RENAULT-TERMINAL-CLOSURE-v1.json'),
            'fullSourceFiles': len(cur['source-capture.json']['files']), 'sourceArchiveMembers': source['members'],
            'sourceChangedPaths': cur['FROZEN-CAPTURE-SCOPE.json']['sourceChangedPaths'],
            'baseArchivesReused': len(reused), 'archiveCount': len(ars), 'logicalFiles': len(files),
            'logicalBytes': sum(r['bytes'] for r in files.values()), 'freshFiles': len(fresh_rows),
            'freshBytes': sum(r['bytes'] for r in fresh_rows), 'sourceFullCloneCreated': False,
            'referenceClosureSupportSatisfied': True, 'pendingSupportResolved': closure_doc['pendingSupportMap'],
            'deliveryOnlySupplementsOutsideRecovery': conf['deliveryOnlySupplements'],
            'inheritedDependencyReconstruction': closure_doc['inheritedDependencyProposal'],
            'historicalLimitations': fixed['plan']['historicalLimitations'],
            'fullProjectTypeScriptPassed': False, 'releaseReady': False, 'nativeByteReadbackVerified': False,
            'actualArchivePayloadReplayPerformedByThisHelper': False}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('mode', choices=('closure', 'restore'))
    ap.add_argument('--inputs', required=True)
    ap.add_argument('--input-sha256', required=True)
    args = ap.parse_args()
    resource.setrlimit(resource.RLIMIT_AS, (LIMIT, LIMIT)); started = time.monotonic()
    conf, cur, fixed, reused, fresh = load_context(args.inputs, args.input_sha256, args.mode)
    output = closure(conf, cur, fixed, reused, fresh) if args.mode == 'closure' else restore(conf, cur, fixed, reused, fresh)
    output.update(createdAt=datetime.datetime.now(datetime.timezone.utc).isoformat(), inputPins=list(READ_PINS.values()),
                  configuration=CONFIG, resources={'addressSpaceLimitBytes': LIMIT,
                  'wallSeconds': round(time.monotonic() - started, 3), 'maxRssKiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
    name = 'INDEPENDENT-NISSAN-REFERENCE-CLOSURE-v1.json' if args.mode == 'closure' else 'RESTORE-PLAN-v2.json'
    result = write_new(name, output)
    print(json.dumps({'output': result, 'status': output.get('result', output.get('status'))}))
    if output.get('unresolvedReferences'):
        raise SystemExit(2)


if __name__ == '__main__':
    main()
