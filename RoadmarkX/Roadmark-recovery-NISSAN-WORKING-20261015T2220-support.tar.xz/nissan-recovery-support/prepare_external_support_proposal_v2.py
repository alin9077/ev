#!/usr/bin/env python3
"""Metadata-only exact prior-member attribution and explicitly approved fresh support scope."""
import json,pathlib,hashlib
R=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-recovery-20261014');C=R/'checkpoints/nissan-working-20261015T2220';B=R/'checkpoints/renault-working-20261015T2040'
def load(p):return json.loads(p.read_text())
def pin(p):b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def key(x):return x['bytes'],x['sha256']
mp=B/'deliverables/Roadmark-RECOVERY-MANIFEST-RENAULT-WORKING-20261015.json';base=load(mp);ars={a['filename']:a for a in base['archivesInRestoreOrder'] if a['filename']!=base['source']['filename']};members={r['path']:r for r in base['files'] if not r['path'].startswith('roadmark/')};cfg=load(C/'NISSAN-REFERENCE-CONFIG-v1.json');outside=[];idx={};authorities=[]
def package(p,out=False,archive=None):
 d=load(p);a=archive or ars[d['filename']];assert key(a)==key(d);ref=pin(p);authorities.append(ref)
 for m in d.get('memberFiles',d.get('members')):
  assert out or key(members[m['path']])==key(m)
  idx.setdefault(key(m),[]).append((m['path'],a,ref,out))
for name in ['cupra-working-20261015T1745','kgm-working-20261015T1530','audi-working-20261015T0800','deepal-working-20261015T1110','renault-working-20261015T2040']:
 package(R/'checkpoints'/name/'support-package.json')
package(R/'checkpoints/audi-working-20261015T0800/support2-package-v2.json')
package(B/'support2-package.json')
for s in cfg['deliveryOnlySupplements']:
 outside.append({'archive':s['identity'],'package':s['package'],'inventory':s['inventory'],'outsideRecoveryArchiveSet':True});package(pathlib.Path(s['package']['path']),True,s['identity'])
# Exact older snapshot helper attribution uses its one-part snapshot and named member manifest.
sp=R/'support-WORKING-CONSUMER-20261014T172617Z-snapshot.json';sd=load(sp);assert len(sd['archives'])==1;ap=sd['archives'][0];a=ars[ap['filename']];assert key(a)==key(ap)
fm=pathlib.Path(sd['manifest']);fd=load(fm);row=next(r for r in fd['files'] if r['path']=='working-consumer-support/snapshot_recovery_v2.py');assert key(row)==key(members[row['path']])
auth=C/'SNAPSHOT-HELPER-REUSE-AUTHORITY-v1.json';put(auth,{'filename':a['filename'],'bytes':a['bytes'],'sha256':a['sha256'],'memberFiles':[{k:row[k] for k in ('path','bytes','sha256')}],'exactSinglePartSnapshot':pin(sp),'exactSnapshotMemberManifest':pin(fm),'baseManifest':pin(mp),'metadataOnly':True});idx.setdefault(key(row),[]).append((row['path'],a,pin(auth),False))
plan=load(C/'SAFETY-SAVE-PLAN-v3.json');rows={r['path']:r for r in load(C/'NISSAN-INHERITED-ADAPTER-PINS-v1.json')['pins']}
for r in plan['reviewedPriorHelpers']+plan['reviewedPriorContractMetadata']:rows[r['path']]=r
for r in cfg['pendingSupportCandidates']:rows[r['expected']['path']]=r['expected']
selected=[];local=[];fresh_scanners=[];unresolved=[]
for path,r in sorted(rows.items()):
 p=pathlib.Path(path);rel='external/'+p.relative_to(R).as_posix();out={'originalPath':path,'localRelativePath':rel,'bytes':r['bytes'],'sha256':r['sha256'],'externalOriginalExplicitlySelected':True}
 matches=idx.get(key(r),[])
 if matches:
  # Prefer exact basename, then chain retention over outside artifacts; every match has member authority.
  matches.sort(key=lambda m:(pathlib.Path(m[0]).name!=p.name,m[3],m[0]));m,a,authority,outer=matches[0];out.update(action='reuse',retainedMember=m,retainedArchive=a,archiveMappingAuthority=authority,outsideRecoveryArchiveSet=outer);selected.append(out)
 elif p.parent==R/'privacy-audit-20261014T0355' and p.suffix=='.py':
  out.update(action='fresh',firstTimeRetention=True,priorContainmentProven=False);fresh_scanners.append(out);selected.append(out)
 elif p.name in {'INDEPENDENT-CUPRA-TERMINAL-CLOSURE-v1.json'} or path in {z['expected']['path'] for z in cfg['pendingSupportCandidates']}:
  out['action']='fresh'
  if p.parent==B:out['localRelativePath']='base-renault/'+p.name
  selected.append(out)
 elif p.suffix=='.json':local.append({k:r[k] for k in ('path','bytes','sha256')})
 else:unresolved.append(out)
assert len(fresh_scanners)==4 and sum(r['bytes'] for r in fresh_scanners)==23083 and not unresolved
put(C/'ORIGINAL-SCANNER-FIRST-RETENTION-GRANT-v1.json',{'approvalScope':'Retain exactly the four pinned original scanner helper code files once as fresh support, subject to independent selection and privacy review. Keep private seed values and audit inputs local-only; no broader dependency sweep.','grantSource':'Root collaboration message 2026-10-15T22:53:54Z context','inheritedPins':pin(C/'NISSAN-INHERITED-ADAPTER-PINS-v1.json'),'independentAttribution':pin(C/'INDEPENDENT-NISSAN-ORIGINAL-SCANNER-ATTRIBUTION-v1.json'),'files':fresh_scanners,'priorContainmentProven':False})
put(C/'NISSAN-EXTERNAL-SUPPORT-PROPOSAL-v1.json',{'status':'PROPOSED_EXACT_EXTERNAL_SUPPORT_SCOPE_FOR_REVIEW','baseManifest':pin(mp),'outsideRecoveryArtifacts':outside,'files':selected,'localOnlyPrivateSeedInputPins':local,'privateSeedInputPayloadsSelected':False,'firstTimeScannerRetentionGrant':pin(C/'ORIGINAL-SCANNER-FIRST-RETENTION-GRANT-v1.json'),'unresolved':unresolved,'onlyMetadataRead':True,'notFinalSupportSelection':True})
print(json.dumps({'selected':len(selected),'reuse':sum(r['action']=='reuse' for r in selected),'fresh':sum(r['action']=='fresh' for r in selected),'privateLocalOnly':len(local),'proposal':pin(C/'NISSAN-EXTERNAL-SUPPORT-PROPOSAL-v1.json')}))
