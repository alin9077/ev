#!/usr/bin/env python3
"""Exact reviewed Nissan support syntax only, after unchanged inherited classifiers."""
import ast, collections, hashlib, json, pathlib, sys
P = pathlib.Path
C = P(__file__).resolve().parent
CLASSIFICATION = {'path':str(C/'INDEPENDENT-NISSAN-SUPPORT-SYNTAX-CLASSIFICATION-v1.json'),'bytes':51429,'sha256':'af17f9506d6cf5b2e9b8bd47597370d5497882b23c3779f02b66c92309493bd4'}
ROOT_GRANT = {'path':str(C/'ROOT-SUPPORT-SYNTAX-GRANT-v1.json'),'bytes':907,'sha256':'e8858457c8ffa6d41380a38a6a7be927880caec96db03ca6607916db7371bbbe'}
BASE_ADAPTER = {'bytes':2498,'sha256':'a1907a57fc251cc34cd440229f444a110325a30ec31c8e4ef364aa19559283b0'}

def require(ok, message):
    if not ok: raise ValueError(message)
def digest(data): return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def canon(value): return json.dumps(value,sort_keys=True,separators=(',',':'))
def ast_context(data, row, tree, parents, starts):
    def span(node):
        return starts[node.lineno-1]+node.col_offset, starts[node.end_lineno-1]+node.end_col_offset
    begin,end=row['keyLiteralByteStart'],row['keyLiteralByteEndExclusive']
    nodes=[n for n in ast.walk(tree) if isinstance(n,ast.Constant) and isinstance(n.value,bytes) and span(n)==(begin,end)]
    require(len(nodes)==1 and row['keyLiteralAstType']=='Constant[bytes]','Expected exact key literal AST span missing')
    node=nodes[0];old=json.dumps(row['exactFinding']['header']).encode()+b':'
    new=json.dumps('approvalScope').encode()+b':'
    require(node.value==old and hashlib.sha256(data[begin:end]).hexdigest()==row['keyLiteralSHA256'],'Exact key literal bytes differ')
    lineage=[];cur=node
    while cur in parents:
        cur=parents[cur];lineage.append(cur)
    funcs=[n for n in lineage if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
    require(funcs and funcs[0].name==row['astFunction'],'Exact enclosing function differs')
    parent=parents[node];role=row['astRole']
    require(type(parent).__name__==row['astOperation'],'Exact AST operation differs')
    if role=='inverse-key-absence-check':
        require(row['astFunction']=='inverse' and isinstance(parent,ast.Compare) and parent.left is node
            and len(parent.ops)==len(parent.comparators)==1 and isinstance(parent.ops[0],ast.NotIn)
            and isinstance(parent.comparators[0],ast.Name) and parent.comparators[0].id=='raw','Not exact inverse absence comparison')
    else:
        require(role in ('inverse-key-once-replacement','approved-copy-key-reconstruction')
            and isinstance(parent,ast.Call) and isinstance(parent.func,ast.Attribute)
            and parent.func.attr=='replace' and len(parent.args)==3 and not parent.keywords
            and all(isinstance(x,ast.Constant) for x in parent.args),'Not exact one-key replacement call')
        inverse=role=='inverse-key-once-replacement'
        require(row['astFunction']==('inverse' if inverse else 'captures')
            and isinstance(parent.func.value,ast.Name) and parent.func.value.id==('raw' if inverse else 'reused_raw')
            and [x.value for x in parent.args]==([new,old,1] if inverse else [old,new,1])
            and parent.args[1 if inverse else 0] is node,'Replacement direction/count/receiver differs')

def classify_exact(candidates, data, name, classification):
    rows=[r for r in classification['exactSupportCodeClassifications'] if r['member']==name]
    if not rows: return candidates,[]
    actual=digest(data);require(all(r['filePin']==actual for r in rows),'Exact approved member bytes changed')
    expected=[r['exactFinding'] for r in rows]
    require(len(expected)==len(set(map(canon,expected))),'Duplicate approved finding')
    require(all(sum(c==e for c in candidates)==1 for e in expected),'Expected finding missing, duplicate or changed')
    tree=ast.parse(data,filename=name);parents={child:node for node in ast.walk(tree) for child in ast.iter_child_nodes(node)}
    starts=[];offset=0
    for line in data.splitlines(keepends=True): starts.append(offset);offset+=len(line)
    classified=[]
    for row in rows:
        start,end=row['byteStart'],row['byteEndExclusive']
        require(type(start) is int and type(end) is int and 0<=start<end<=len(data)
            and hashlib.sha256(data[start:end]).hexdigest()==row['matchedSyntaxSHA256'],'Exact finding span changed')
        ast_context(data,row,tree,parents,starts)
        classified.append({'member':name,'filePin':actual,'finding':row['exactFinding'],'classification':row['classification']})
    approved=[r for r in classification['expectedClassifiedRecords'] if r['member']==name]
    require(collections.Counter(map(canon,classified))==collections.Counter(map(canon,approved)),'Exact emitted classification records differ')
    return [c for c in candidates if c not in expected],classified

def dump_dispatch(original_dump, report_path, seed_pin, members, seen, emitted, extra, classification):
    """Keep historical seed receipt writes independent of final report completeness."""
    def guarded_dump(path,record):
        path=P(path)
        if path==report_path:
            require(seen==members and collections.Counter(map(canon,emitted))==collections.Counter(map(canon,classification['expectedClassifiedRecords'])),'Incomplete exact24 support classification')
            report_records=record['classifiedExactCodeHeaderCandidates']
            require(all(sum(c==r for c in report_records)==1 for r in emitted),'Final report lost or duplicated exact classification')
            require(not extra or (record['status']!='clean' and record['primaryHeaderCandidates']),'Extra candidate cannot become clean')
        else:
            parts=path.stem.split('-')
            require(path.parent==C/'seed-read-invocations' and path.suffix=='.json' and len(parts)==2
                and all(p.isdecimal() for p in parts),'Unreviewed privacy dump destination')
            require(set(record)=={'completedAt','processId','exactPinnedMembersReadAndVerified','historicalArchives','memberIdentityListPin','noExtractedValuesPersisted','scope'}
                and type(record['processId']) is int and record['processId']>0 and int(parts[0])==record['processId']
                and int(parts[1])>0 and isinstance(record['completedAt'],str)
                and record['exactPinnedMembersReadAndVerified']==200 and record['historicalArchives']==21
                and record['memberIdentityListPin']==seed_pin and record['noExtractedValuesPersisted'] is True
                and record['scope']=='Targeted historical seed reconstruction only, not a full base privacy scan or restore','Historical seed receipt shape differs')
        return original_dump(path,record)
    return guarded_dump

def configure(contract_pin, require_review=True):
    from nissan_capture_adapter_v2 import capture_module, load_reference
    cap=capture_module();require(P(contract_pin['path'])==C/'NISSAN-SUPPORT-PRIVACY-CONTRACT-v1.json','Wrong support privacy contract')
    cap.check(P(contract_pin['path']),contract_pin);contract=cap.load(contract_pin['path'])
    require(contract['status']=='INDEPENDENTLY_ACCEPTED_EXACT_NISSAN_SUPPORT_PRIVACY_ADAPTER'
        and contract['classification']==CLASSIFICATION and contract['rootGrant']==ROOT_GRANT,'Support contract scope differs')
    own={'path':str(P(__file__).resolve()),**cap.pin(__file__)}
    require(contract['privacyAdapter']==own,'Support classifier implementation differs')
    for ref in (CLASSIFICATION,ROOT_GRANT,contract['review']): cap.check(P(ref['path']),ref)
    review=cap.load(contract['review']['path']);grant=cap.load(ROOT_GRANT['path'])
    require(review['result']=='ACCEPTED_EXACT_NISSAN_SUPPORT_APPEND_PRIVACY_PACKAGE_ADAPTERS'
        and review['privacyAdapter']==own and review['classification']==CLASSIFICATION
        and grant['approvedScope']==CLASSIFICATION and grant['existingStagedMembersRemainUnchanged']==235,'Missing exact adapter/root review')
    classification=cap.load(CLASSIFICATION['path']);rows=classification['exactSupportCodeClassifications']
    require(classification['result']=='ACCEPTED_EXACT_NISSAN_SUPPORT_CODE_SYNTAX_CLASSIFICATION'
        and len(rows)==24 and len(classification['expectedClassifiedRecords'])==24,'Wrong support classification')
    members={r['member'] for r in rows};require(len(members)==9,'Wrong approved member scope')
    base=load_reference('nissan_support_base_privacy',C/'nissan_privacy_adapter_v2.py',BASE_ADAPTER)
    privacy=base.configure(require_review=require_review)
    deepal=sys.modules['deepal_scan_additions_v2'];unchanged=deepal.code_context;seen=set();emitted=[];extra=[]
    def code_context(candidates,data,name):
        remaining,inherited=unchanged(candidates,data,name)
        blocked,current=classify_exact(remaining,data,name,classification)
        if name in members:
            require(name not in seen,'Approved member classified more than once');seen.add(name)
            emitted.extend(current);extra.extend(blocked)
        return blocked,inherited+current
    deepal.code_context=code_context
    privacy.dump=dump_dispatch(privacy.dump,C/'scan-fresh-04.json',cap.pin(C/'SEED-PROVENANCE.json'),members,seen,emitted,extra,classification)
    return privacy

def main():
    require(len(sys.argv)==6,'Expected archive, report, archive-plan, contract, contract SHA256')
    archive,report,plan,contract_path,contract_sha=sys.argv[1:]
    require(P(archive)==C.parents[1]/'Roadmark-recovery-NISSAN-WORKING-20261015T2220-support.tar.xz'
        and P(report)==C/'scan-fresh-04.json' and P(plan).parent==C,'Support-only scan paths')
    cp=P(contract_path);m=configure({'path':str(cp),'bytes':cp.stat().st_size,'sha256':contract_sha})
    sys.argv=[str(P(__file__).resolve()),archive,report,plan];m.main()
if __name__=='__main__':main()
