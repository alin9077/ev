#!/usr/bin/env python3
"""Independent Nissan delivery verifier; stdlib only, never imports producer code.
PREPARED ONLY. Each execution needs a separately accepted SHA-sealed mode contract.
Reads sealed metadata/code/current deliverable bytes, never archive, seed or live-source
payloads. No network, subprocess, xattr write, replacement, or publication operations.
"""
import argparse, datetime, hashlib, json, os, pathlib, resource, stat, time
P=pathlib.Path; C=P(__file__).resolve().parent; B=C.parent/'renault-working-20261015T2040'; D=C/'deliverables'
LIMIT=268435456; SCOPE='DOCUMENT_CONTENT_AND_SERVER_CREATE_IDENTITY_ONLY'; DATE='20261015'
STATUS='LOCAL_RECOVERY_VERIFIED_SERVER_CREATE_CONFIRMED_NATIVE_READBACK_UNPASSED_RELEASE_UNPASSED'
NOTE='Local recovery replay passed. Library persistence is confirmed by server create receipts and matching local hashes. Native byte-readback remains unpassed after the inherited Library selected-folder 403 access boundary; no Nissan readback request or alternative read route was attempted.'
RESULTS={m:'PASS_INDEPENDENT_NISSAN_'+m.upper() for m in ('documents','active','persisted','terminal')}
OUTPUTS={'documents':'INDEPENDENT-NISSAN-DOCUMENT-CHECK-v1.json','active':'INDEPENDENT-NISSAN-ACTIVE-CHECK-v1.json','persisted':'INDEPENDENT-NISSAN-PERSISTED-CHECK-v1.json','terminal':'INDEPENDENT-NISSAN-TERMINAL-CLOSURE-v1.json'}
FIXED={
 'baseFinal':(B/'FINAL-RENAULT-UPLOAD-RECEIPTS.json',195133,'1548c59e11ab2f9d1970348a8cdff91e19500496ad50c06c41e3f43e881bb44c'),
 'baseTerminal':(B/'INDEPENDENT-RENAULT-TERMINAL-CLOSURE-v1.json',16973,'60afb83a27b9c14fe5b00b9e2a6d965a375f4eebfa0a9ac134f3ff84e2ee4ef2'),
 'normalizer':(B/'delivery_native_adapter_v3.py',12641,'f5bec06d762fca6b3d34ea13f7e7f17d2f5353dbbd379a5e1b13e967aabbc474'),
 'captureAdapter':(C/'nissan_capture_adapter_v2.py',2488,'7d9f820e0af9a076e97f1d9b53524c1b9c6081cd5223f22d0630b87be919e14f'),
 'recoveryChecker':(C/'independent_nissan_recovery_v7.py',46471,'01666e71b9201cac776f45c1a8a8a17cada57ad2a54a37575adb314883a4ef90'),
 'referenceBuilder':(C/'build_nissan_reference_restore_v5.py',30370,'1999dbdd3efc07d426327d0b3cd18e93b45339c36b43efcb74bd0fc52442d483'),
 'referenceConfig':(C/'NISSAN-REFERENCE-CONFIG-v1.json',16143,'62d4b02318ae71df2236b889582875c981ebb42c13d4df25bcb8bdd6878d2e22')}
ALLOWED={}; READ={}; CACHE={}; CONTRACT={}; OWN=None; LAUNCH=[]

def ck(value,why):
 if not value:raise AssertionError(why)
def core(r):return {k:r[k] for k in ('path','bytes','sha256')}
def sh(r):return {k:r[k] for k in ('bytes','sha256')}
def bp(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def canonical(obj):return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def valid(r):return isinstance(r,dict) and isinstance(r.get('path'),str) and type(r.get('bytes')) is int and r['bytes']>=0 and isinstance(r.get('sha256'),str) and len(r['sha256'])==64 and all(x in '0123456789abcdef' for x in r['sha256'])
def identity(p):
 p=P(p);ck(p.is_absolute() and '..' not in p.parts and str(p)==str(p.absolute()),'noncanonical path')
 for q in (p,*p.parents):ck(not stat.S_ISLNK(q.lstat().st_mode),'symlink path')
 s=p.lstat();ck(stat.S_ISREG(s.st_mode),'nonregular file');return (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_mode)
def raw_exact(r):
 ck(valid(r) and r['bytes']<=32*1024*1024,'invalid/oversized sealed input');p=P(r['path']);before=identity(p)
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 with os.fdopen(fd,'rb') as f:
  s=os.fstat(f.fileno());ck((s.st_dev,s.st_ino)==before[:2],'path/fd mismatch');raw=f.read(r['bytes']+1)
 ck(identity(p)==before and bp(raw)==sh(r),'changed input or pin mismatch: '+str(p));return raw
def register(r):
 ck(valid(r),'invalid input pin');p=P(r['path']);ck(p.is_absolute() and '..' not in p.parts,'unscoped input')
 ck(p.suffix in ('.json','.jsonl','.md','.txt','.log','.py') and not any(x in p.parts for x in ('payload','payloads','source-payload','proof-payload','node_modules','.git')),'payload or unsupported input')
 if str(p) in ALLOWED:ck(ALLOWED[str(p)]==core(r),'conflicting input pins')
 ALLOWED[str(p)]=core(r)
def raw(r):
 ck(ALLOWED.get(r['path'])==core(r),'unsealed read: '+r['path'])
 if r['path'] not in CACHE:CACHE[r['path']]=raw_exact(r);READ[r['path']]=core(r)
 return CACHE[r['path']]
def load(r):return json.loads(raw(r))
def ref(p):
 p=str(p);ck(p in ALLOWED,'missing sealed input: '+p);return ALLOWED[p]
def get(p):return load(ref(p))
def absref(r):return {**core(r),'path':str(P(r['path']) if P(r['path']).is_absolute() else C/r['path'])}
def index(rs,key='path'):
 d={r[key]:r for r in rs};ck(len(d)==len(rs),'duplicate '+key);return d
def member_rows(rs):return {n:core(r) for n,r in index(rs).items()}
def tuple_id(r):return {k:r[k] for k in ('filename','bytes','sha256','library_file_id','file_id','version')}
def at(obj,path):
 for k in path:obj=obj[k]
 return obj
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def timestamps(s):ck(isinstance(s,str) and datetime.datetime.fromisoformat(s.replace('Z','+00:00')).tzinfo is not None,'invalid aware timestamp')
def bound(spec,success=False):
 i=load(spec['invocation']);t=load(spec['terminal']) if spec.get('terminal') else None
 ck(i['addressSpaceLimitBytes']==LIMIT and i['wallLimitSeconds']==600,'resource envelope')
 if t:ck(all(t[k]==i[k] for k in ('command','childPid','startedAt','addressSpaceLimitBytes','wallLimitSeconds')) and t['endedAt']>=i['startedAt'],'phase binding/chronology')
 outcome=('PASS' if t['exitCode']==0 and not t['timedOut'] else 'NONZERO_OR_TIMEOUT') if t else 'UNKNOWN'
 if success:ck(outcome=='PASS','unsuccessful required phase')
 return i,t,outcome

def context(args):
 global CONTRACT,OWN,LAUNCH
 cp=P(args.contract);rp=P(args.review);ck(cp.parent==rp.parent==C and cp.suffix==rp.suffix=='.json','contract location')
 cr={'path':str(cp),'bytes':identity(cp)[2],'sha256':args.contract_sha256};rr={'path':str(rp),'bytes':identity(rp)[2],'sha256':args.review_sha256}
 for r in (cr,rr):register(r)
 c=load(cr);review=load(rr);ownraw=P(__file__).read_bytes();OWN={'path':str(P(__file__).resolve()),**bp(ownraw)}
 ck(c['schemaVersion']==1 and c['mode']==args.mode and c['checkpoint']==str(C),'contract scope')
 ck(c['checker']==OWN and review['checker']==OWN and review['contract']==cr and review['mode']==args.mode and review['result']=='ACCEPTED_EXACT_NISSAN_DELIVERY_RUNTIME_CONTRACT','exact independent runtime approval')
 ck(c['acceptanceScope']==SCOPE and c['nativeByteReadbackVerified'] is False and c['currentMaterializeAttempts']==0 and c['currentAlternateReadRoutes']==0,'contract native boundary')
 for r in c['metadata']:register(r)
 register(OWN)
 for k,(p,n,h) in FIXED.items():
  r={'path':str(p),'bytes':n,'sha256':h};ck(c['inputs'][k]==r,'fixed pin: '+k);register(r);raw(r)
 for r in c['inputs'].values():ck(ref(r['path'])==core(r),'input not in exact allowlist')
 for key in ('deliveryHelper','deliveryContract'):
  raw(c['inputs'][key])
 dc=load(c['inputs']['deliveryContract']);ck(dc['result']=='ACCEPTED_EXACT_NISSAN_DELIVERY_ADAPTER' and dc['helper']==c['inputs']['deliveryHelper'],'delivery exact acceptance');load(dc['independentReview'])
 ck(dc['nativeByteReadbackVerified'] is False and dc['currentMaterializeAttempts']==0,'delivery contract native boundary')
 ck(not list(C.glob('*materialize*')),'unexpected current materialization evidence; separate review required')
 CONTRACT=c;LAUNCH=[OWN['path'],args.mode,'--contract',str(cp),'--contract-sha256',args.contract_sha256,'--review',str(rp),'--review-sha256',args.review_sha256];return cr,rr

def inherited():
 b=get(FIXED['baseFinal'][0]);t=get(FIXED['baseTerminal'][0]);ck(t['result']=='PASS_INDEPENDENT_RENAULT_TERMINAL' and t['finalReceipt']==ref(FIXED['baseFinal'][0]),'prior exact terminal chain')
 ck(b['counts']['archiveCount']==t['counts']['archiveCount']==142 and b['nativeByteReadbackVerified'] is t['nativeByteReadbackVerified'] is False,'prior scope')
 e=b['blockedReadbackEvidence'];request=load(e['request']);response=load(e['response']);ck(response['isError'] is True and response['structuredContent']['error_code']=='FORBIDDEN' and '403' in response['structuredContent']['error'] and 'scope_violation' in response['structuredContent']['error'],'inherited403 evidence')
 ck(e['retries']==e['alternateReadRoutes']==0,'denied route retries')
 denial={'inheritedRenaultReadbackDenial':e,'inheritedFinalReceipt':ref(FIXED['baseFinal'][0]),'scope':'The historical denial was for the five Renault archive identities in its exact request. No Nissan identity is claimed individually attempted or denied.','currentNissanMaterializationAttempts':0,'currentNissanAlternateReadRoutes':0,'deniedRouteRetried':False}
 supp={'verification':b['supplementalDeliveryVerificationArtifact'],'correction':b['deliveryCorrection']['artifact'],'outsideCurrentRecoveryArchiveSet':True,'notNewNissanArchives':True,'nativeByteReadbackVerified':False}
 ck(b['deliveryCorrection']['outsideRecoveryArchiveSet'] is True and b['deliveryCorrection']['unchangedRecoveryArchiveCount']==142,'historical correction scope')
 return b,t,denial,supp

def normalized(phase,want,denial):
 pre={'archives':'ARCHIVE','documents':'DOCUMENT','active':'ACTIVE'}[phase];q=get(C/f'library-{phase}-host-create-request.json');r=get(C/f'library-{phase}-provider-results.json');d=get(C/f'{pre}-UPLOAD-IDENTITIES.json');n=get(C/f'library-{phase}-results.json');rb=get(C/f'{pre}-NATIVE-READBACK-v1.json')
 paths=q['files'] if 'files' in q else [q['file']];server=r['structuredContent']['results'];ck(r['isError'] is False and len(paths)==len(server)==len(want) and len(set(paths))==len(paths),'exact create cardinality')
 files=[];results=[];witness=[];attrs_out=[]
 for path,s in zip(paths,server):
  p=P(path);name=p.name;ck(name in want and path==want[name]['localPath'],'create exact local path');w=want[name]
  ck(s['operation']=='create_library_file' and s['status']=='succeeded' and s['file_name']==name and s['path']=='/'+name and s['file_size_bytes']==w['bytes'],'server create tuple')
  ck(s['library_file_id'].startswith('libfile_') and s['file_id'].startswith('file_') and type(s['current_version_number']) is int and s['current_version_number']>=0,'provider identity shape')
  attrs=[{'name':'user.library-file-version','value':str(s['current_version_number'])}];ck(s['xattrs']==attrs,'unreviewed provider xattrs')
  # Metadata-only: inspect attributes, never reopen archive contents or set attributes.
  identity(p);ck('user.library-file-id' not in os.listxattr(p),'fabricated library identity xattr')
  ck(os.getxattr(p,'user.library-file-version').decode()==attrs[0]['value'],'provider version xattr not applied')
  if phase!='archives':ck(sh(ref(path))==sh(w),'current document sealed local hash');raw(ref(path))
  a={'filename':name,'localPath':path,**sh(w),'library_file_id':s['library_file_id'],'file_id':s['file_id'],'version':s['current_version_number'],'providerCreateConfirmed':True,'localBytesVerified':True,'createReceiptAndLocalIdentityVerified':True,'nativeByteReadbackVerified':False,'verificationBasis':'EXACT_SERVER_CREATE_TUPLE_AND_LOCAL_HASH'};files.append(a)
  results.append({'local_path':path,'purpose':'create_library_file','status':'succeeded','file_id':a['file_id'],'library_file_id':a['library_file_id'],'file_name':name,'local_metadata_applied':True,'current_version_number':a['version'],'returnedXattrsApplied':attrs,'nativeByteReadbackVerified':False})
  witness.append({k:v for k,v in a.items() if k!='localPath'});attrs_out.append({'filename':name,'returnedXattrs':attrs,'allReturnedXattrsApplied':True,'noUnreturnedIdentityXattrAdded':True})
 ck(len(index(files,'library_file_id'))==len(index(files,'file_id'))==len(files),'duplicate created identity')
 ck(d['files']==files and d['status']=='CREATE_CONFIRMED_NATIVE_BYTE_READBACK_UNPASSED' and d['acceptanceScope']==SCOPE and d['nativeByteReadbackVerified'] is False and d['blockedReadbackEvidence']==denial,'normalized identities')
 for x in (d,n,rb):
  ck(x['currentNissanMaterializationAttempts']==0 and x['nativeByteReadbackVerified'] is False and x['currentDeliveryAdapter']==CONTRACT['inputs']['deliveryHelper'] and x['currentDeliveryContract']==CONTRACT['inputs']['deliveryContract'],'normalized current qualification')
 ck(d['normalizer']==ref(FIXED['normalizer'][0]),'exact prior normalizer')
 for x in (d,n):ck(x['exactHostRequest']==ref(C/f'library-{phase}-host-create-request.json') and x['exactProviderResponse']==ref(C/f'library-{phase}-provider-results.json'),'normalized raw bindings')
 ck(n['route']=='OFFICIAL_ABSOLUTE_PATH_HOST_CREATE' and n['results']==results,'normalized result tuples')
 ck([json.loads(x) for x in raw(ref(C/f'library-{phase}-verified.jsonl')).decode().splitlines()]==witness,'normalized JSONL witness')
 ck(rb['status']=='NOT_ATTEMPTED_INHERITED_DENIED_SCOPE_BOUNDARY' and rb['nativeMaterializationAttemptsForThisPhase']==0 and rb['legacyFilenameDoesNotAssertReadback'] is True and rb['blockedReadbackEvidence']==denial and rb['returnedAttributes']==attrs_out and rb['createConfirmedIdentities']==ref(C/f'{pre}-UPLOAD-IDENTITIES.json') and rb['statement']==NOTE,'truthful readback marker')
 return files

def retained(selection):
 d=load(selection);rs=d['files'];index(rs,'localPath');out=[]
 for r in rs:
  p=P(r['localPath']);ck(p.is_relative_to(C) and p.suffix in ('.json','.jsonl','.txt','.log','.md'),'retained metadata scope')
  rr=ref(p);ck(sh(rr)==sh(r),'retained selection pin');out.append({'file':rr,'utf8':raw(rr).decode('utf8')})
 return out

def common(b,denial,supp):
 return {'nativePersistenceStatus':'CREATE_CONFIRMED_NATIVE_BYTE_READBACK_UNPASSED','nativeByteReadbackVerified':False,'deliveryVerificationAcceptanceScope':SCOPE,'nativePersistenceLimitation':NOTE,'blockedReadbackEvidence':denial,'referencedPriorDeliveryArtifactsOutsideRecovery':supp,'deliveryAdapter':CONTRACT['inputs']['deliveryHelper'],'deliveryContract':CONTRACT['inputs']['deliveryContract'],'priorNormalizer':ref(FIXED['normalizer'][0]),'fullProjectTypeScriptPassed':False,'releaseReady':False}

def recovery():
 inp=CONTRACT['inputs'];r=load(inp['recovery']);ck(r['result']=='PASS_INDEPENDENT_NISSAN_FRESH_RECOVERY' and r['verifierScript']==inp['recoveryChecker'],'actual fresh recovery verifier')
 rc=load(r['runtimeInputContract']);rv=load(r['runtimeInputContractReview']);ck(rc['verifier']==inp['recoveryChecker'] and rv['verifier']==inp['recoveryChecker'] and rv['contract']==r['runtimeInputContract'] and rv['result']=='ACCEPTED_EXACT_NISSAN_VERIFIER_RUNTIME_CONTRACT','fresh recovery exact runtime approval')
 for q in r['inputPins']:ck(ref(q['path'])==core(q),'recovery input not identically sealed')
 ck(r['acceptedFinalRetentionScope']=='accepted','accepted final freeze spelling')
 p=get(C/'SAFETY-SAVE-PLAN-v3.json');s=get(C/'FROZEN-CAPTURE-SCOPE.json');inv=load(p['nissanEvidence']['finalFreeze']);accept=load(p['nissanEvidence']['finalRetentionReview'])
 ck(accept['status']=='accepted' and accept['inventory']==p['nissanEvidence']['finalFreeze'] and s['freezeMetadata']==p['nissanEvidence']['finalFreeze'],'final freeze exact identity')
 ck(accept['currentValidation']==inv['currentValidation']==s['currentValidation']==p['currentNissanValidation'],'validation continuity')
 for k in ('fullProjectTypecheckPassed','releaseReady','currentCleanFullSuite','productionBuildVerified','phoneMobileVerified','publicationAuthorized'):ck(s['currentValidation'][k] is False,'unpassed validation raised')
 ck(r['nativeByteReadbackVerified'] is r['fullProjectTypeScriptPassed'] is r['releaseReady'] is False,'recovery scope flags')
 po=r['preservedOutcomes'];ck(po['historicalLimitations']==p['historicalLimitations'] and po['currentRetainedFailures']==inv['retainedFailures'] and po['currentOtherAttemptHistory']==inv['otherAttemptHistory'] and po['originalCupraPrivacyScan']==po['originalRenaultReport']=='UNKNOWN','failure/UNKNOWN preservation')
 ck(all(x['cause']=='unknown' and x['exitCode']==-9 and x['fullProjectTypecheckPassed'] is False for x in inv['retainedFailures']['compilerAttempts']),'compiler failures changed')
 scope=r['scope'];ck(scope['inheritedArchivePayloadReads']==scope['supplementArchivePayloadReads']==scope['independentVerifierSeedReads']==0 and scope['noUnchangedLiveSourceRead'] and scope['noFullSourceClone'],'fresh recovery scope')
 bound(CONTRACT['recoveryPhase'],True)
 return r,p,s

def restore(r,b):
 p=get(C/'RESTORE-PLAN-v2.json');ap=get(C/'ARCHIVE-PLAN-v2.json');source=get(C/'source-package.json');src=get(C/'source-capture.json');base=get(B/'deliverables/Roadmark-RECOVERY-MANIFEST-RENAULT-WORKING-20261015.json');br=get(B/'RESTORE-PLAN-v2.json');cl=get(C/'INDEPENDENT-NISSAN-REFERENCE-CLOSURE-v1.json')
 ck(cl['result']=='PASS_EXACT_METADATA_ONLY_REFERENCE_CLOSURE' and r['exactReferenceClosure']==ref(C/'INDEPENDENT-NISSAN-REFERENCE-CLOSURE-v1.json'),'reference closure binding')
 ars=ap['archives'];fresh={};checks=index(r['archiveChecks'],'archive');ck(set(checks)=={a['filename'] for a in ars} and len(ars)==r['freshArchiveCount'],'archive replay set')
 for a in ars:
  ck(a['new'] is True and a['allMembersVerified'] is True and a['members']==len(a['memberFiles']),'fresh archive package')
  x=checks[a['filename']];ck(sh(x)==sh(a) and x['members']==a['members'] and x['memberBytes']==sum(v['bytes'] for v in a['memberFiles']) and x['tarAndXzEofVerified'] is True,'archive exact replay hash')
  for n,v in member_rows(a['memberFiles']).items():ck(n not in fresh,'overlapping fresh archive member');fresh[n]=v
 ck(ars[0]==source==p['source'] and len(src['files'])==703 and source['members']==704 and source['bytes']<15000000,'source703/704/size')
 sm=member_rows(source['memberFiles']);ck(set(sm)=={'roadmark/'+x['path'] for x in src['files']}|{'roadmark/SOURCE-FILE-MANIFEST.json'},'source member coverage')
 for x in src['files']:ck(sh(sm['roadmark/'+x['path']])==sh(x),'source capture member hash')
 po=r['preservedOutcomes'];ck(po['inheritedBoundaries']==base['inheritedBoundaries'] and po['inheritedPreparationLimitations']==base['currentPreparationLimitations'] and po['inheritedRecoveryMetadata']==base['inheritedRecoveryMetadata'],'all inherited failures/unavailable draft disclosures');bm=member_rows(base['files']);files={n:v for n,v in bm.items() if not n.startswith('roadmark/')};files.update(fresh)
 oldsource=base['source']['filename'];baseby=index(base['archivesInRestoreOrder'],'filename');ck(len(baseby)==142,'base142');reused=[baseby[a['filename']] for a in br['archivesInRestoreOrder'] if a['filename']!=oldsource];ck(len(reused)==141,'reuse141')
 expected=[{**{k:v for k,v in a.items() if k not in ('restoreOrder','new','memberFiles')},'new':new,'restoreOrder':i+1} for i,(a,new) in enumerate([(a,False) for a in reused]+[(a,True) for a in ars])]
 ck(p['archivesInRestoreOrder']==expected and p['newArchives']==ars and member_rows(p['files'])==files and member_rows(p['newFiles'])==fresh,'exact ordered restore identities/files')
 counts={'archiveCount':141+len(ars),'logicalFiles':len(files),'logicalBytes':sum(x['bytes'] for x in files.values()),'freshFiles':len(fresh),'freshBytes':sum(x['bytes'] for x in fresh.values()),'fullSourceFiles':703,'sourceArchiveMembers':704,'baseArchivesReused':141}
 ck(all(p[k]==v for k,v in counts.items()) and r['restoreCounts']==counts and r['freshMembers']==len(fresh) and r['freshBytes']==counts['freshBytes'],'dynamic restore counts')
 ck(p['baseFinalReceipt']==ref(FIXED['baseFinal'][0]) and p['baseTerminalReceipt']==ref(FIXED['baseTerminal'][0]),'exact late base receipt pins')
 dep=cl['inheritedDependencyProposal'];ck(dep['canonicalSha256']==canonical(dep['dependencies']) and p['inheritedDependencyReconstruction']==dep,'exact dependency closure')
 for d in dep['dependencies']:
  for q in d['pins']:ck(files.get(q['member']['path'])==core(q['member']) and sh(q['expected'])==sh(q['member']),'dependency outside exact restore chain')
 cfg=get(FIXED['referenceConfig'][0]);ck(cl['deliveryOnlySupplementsOutsideRecovery']==p['deliveryOnlySupplementsOutsideRecovery']==cfg['deliveryOnlySupplements'],'two historical supplements identity set')
 supp=[b['supplementalDeliveryVerificationArtifact']['identity'],b['deliveryCorrection']['artifact']];ck(len(supp)==2 and all(a['filename'] not in {v['filename'] for v in p['archivesInRestoreOrder']} and a['filename'] not in baseby for a in supp),'historical supplement inside recovery count')
 reuse=get(C/'SUPPORT-REUSE-MAPPING.json');suppby={x['identity']['filename']:x for x in cfg['deliveryOnlySupplements']};reusedby=index(reused,'filename')
 for x in reuse['files']:
  a=x['retainedArchive'];n=x['retainedMember'];outside=x['outsideRecoveryArchiveSet'];ck(type(outside) is bool,'support reuse scope flag')
  if outside:
   ss=suppby.get(a['filename']);ck(ss is not None and a==ss['identity'] and x['archiveMappingAuthority']==ss['package'] and a['filename'] not in {v['filename'] for v in p['archivesInRestoreOrder']},'outside supplemental identity/authority')
   pkg=load(ss['package']);inventory=load(ss['inventory']);m={'path':n,**sh(x)};ck(member_rows(pkg['members']).get(n)==m and member_rows(inventory['files']).get(n)==m and sh(pkg)==sh(a) and pkg['outsideRecoveryArchiveSet'] is True and pkg['unchangedRecoveryArchiveCount']==142,'supplement exact metadata member mapping')
  else:ck(files.get(n)==bm.get(n) and sh(files[n])==sh(x) and a==reusedby.get(a['filename']),'in-chain support reuse exact identity/member')
 support=get(C/'SUPPORT-MEMBER-INVENTORY.json')['files'];own=[x for x in support if x.get('originalPath')==OWN['path']];ck(len(own)==1 and sh(own[0])==sh(OWN),'delivery checker retained exactly once')
 sp=[load(x['package']) for x in CONTRACT['supportParts']];ck(sp and core(own[0]) in [core(x) for x in sp[0]['memberFiles']],'delivery checker not in first support')
 for x in support:ck(files.get(x['path'])==core(x),'support inventory member missing')
 return p,counts,ars,cl

def accounting():
 ac=load(CONTRACT['inputs']['accounting']);ck(ac['status']=='EXPLICIT_STAGE_AND_TERMINAL_ACCOUNTING' and ac['noSeedValuesReadByThisAccounting'] is True,'accounting status')
 old=get(B/'SEED-READ-ACCOUNTING-after-active-v2.json');expected={'receipt':ref(B/'SEED-READ-ACCOUNTING-after-active-v2.json'),'attempts':11,'successfulPasses':9,'knownZeroPreconditionFailures':2,'originalCupraUnknownPreservedByExactReceipt':True,'originalRenaultFactualReportUnknownPreservedSeparately':True}
 ck(ac['inheritedRenaultAccounting']==expected and len(old['phases'])==11 and sum(p['outcome']=='PASS' for p in old['phases'])==9 and sum(p['knownZeroSeedPreconditionFailure'] for p in old['phases'])==2,'inherited9/11/2 separate')
 ck(old['inheritedCupraAccounting']['originalInterruptedScanOutcome']=='UNKNOWN' and 'UNKNOWN' in old['renaultOriginalFactualReport'] and 'UNKNOWN' in ac['renaultOriginalFactualReport'],'historical UNKNOWN')
 phases=ac['phases'];by={p['invocation']['path']:p for p in phases};ck(len(by)==len(phases),'duplicate invocation')
 ck(set(by)=={p.relative_to(C).as_posix() for p in C.glob('scan-*.resources.invocation.json')},'omitted actual scan invocation')
 for p in phases:
  ir=absref(p['invocation']);tr=absref(p['terminal']) if p['terminal'] else None;i,t,outcome=bound({'invocation':ir,'terminal':tr})
  terminal=P(ir['path'].replace('.invocation.json','.json'));ck(bool(tr)==terminal.exists() and (not tr or tr['path']==str(terminal)),'hidden terminal outcome')
  ck(p['outcome']==outcome and p['start']==i['startedAt'] and p['pid']==i['childPid'] and p['end']==(t['endedAt'] if t else None) and p['knownZeroSeedPreconditionFailure'] is False,'actual phase outcome; new known-zero claim requires checker revision')
 summary={'attempts':len(phases),'successfulPasses':sum(p['outcome']=='PASS' for p in phases),'nonzeroOrTimeout':sum(p['outcome']=='NONZERO_OR_TIMEOUT' for p in phases),'unknownTerminalOutcomes':sum(p['outcome']=='UNKNOWN' for p in phases),'independentlyEstablishedKnownZeroFailures':0,'zeroFailuresQualification':'No current phase is classified known-zero by this revision'};ck(ac['currentInvocationSummary']==summary,'current dynamic summary')
 for key,folder,unit,countfield in [('historical','seed-read-invocations',200,'exactPinnedMembersReadAndVerified'),('audi','audi-seed-read-invocations',6,'payloadReadOperations'),('deepal','deepal-seed-read-invocations',5,'payloadReadOperations')]:
  s=ac['stages'][key];records=s['records'];actual={p.relative_to(C).as_posix() for p in (C/folder).glob('*.json')};ck({x['receipt']['path'] for x in records}==actual and len(records)==len(actual),'actual stage ledger coverage');complete=[]
  for x in records:
   d=load(absref(x['receipt']));hits=[p for p in phases if d['processId']==p['pid'] and d['completedAt']>=p['start'] and (p['end'] is None or d['completedAt']<=p['end'])];ck(len(hits)==1,'ambiguous stage phase');p=hits[0]
   ck(d[countfield]==unit and (d['noExtractedValuesPersisted'] if key=='historical' else d['noValuesOrValueDigestsPersisted']) is True,'stage read-operation metadata')
   if key=='historical':ck(d['historicalArchives']==21,'historical stage21')
   ck(x['phaseInvocation']==p['invocation'] and x['phaseTerminal']==p['terminal'] and x['scanOutcome']==p['outcome'] and x['completedAt']==d['completedAt'],'stage phase binding');complete.append(p['invocation']['path'])
  ck(len(complete)==len(set(complete)),'duplicate stage completion');missing=[p['invocation'] for p in phases if p['invocation']['path'] not in complete]
  ck(s['completedInvocations']==len(records) and s['perCompletedInvocationOperations']==unit and s['totalCompletedOperations']==unit*len(records) and s['unknownPartialReadPhases']==missing and s['completedOperationsAreLowerBoundWhenUnknownPartialsExist']==bool(missing),'stage totals/unknown partials')
 local=ac['inheritedLocal'];a=ac['stages']['audi'];n=a['completedInvocations'];ck(local['completedInvocationsProvedByAudiLedger']==n and local['valueReadsPerCompletedInvocation']==local['integrityReadsPerCompletedInvocation']==48 and local['totalProvedValueReads']==local['totalProvedIntegrityReads']==48*n and local['unknownPartialLocalReadsPossibleForPhasesWithoutAudiCompletion']==a['unknownPartialReadPhases'],'actual local48 lower bounds')
 return ac,summary,by

def privacy(ars,by,ac):
 out=[];seen=set();ar=index(ars,'filename')
 for spec in CONTRACT['archivePrivacy']:
  d=load(spec['report']);i,t,_=bound(spec,True);name=d['archive'];ck(name in ar and name not in seen,'archive privacy scope');seen.add(name);a=ar[name]
  ck(d['currentByteSearchForEveryMember'] is True and d['status']=='clean' and not any(d[k] for k in ('exactValueMatches','primaryHeaderCandidates','unclassifiedRuntimeCandidates','errors')),'full archive privacy gate')
  ck(sh(d['archivePin'])==sh(a) and d['regularFilesScanned']==a['members'] and member_rows(d['members'])==member_rows(a['memberFiles']),'actual full member privacy hashes')
  ck(a['file'] in i['command'] and spec['report']['path'] in i['command'],'privacy command targets');phase=P(spec['invocation']['path']).relative_to(C).as_posix();ck(phase in by,'scan not accounted')
  for stage in ac['stages'].values():ck(sum(x['phaseInvocation']['path']==phase for x in stage['records'])==1,'successful privacy missing seed completion')
  out.append({'report':spec['report'],'archive':name,'archivePin':d['archivePin'],'terminal':spec['terminal'],'invocation':spec['invocation']})
 ck(seen==set(ar),'missing final archive privacy');out.sort(key=lambda x:P(x['report']['path']).name);return out

def document_gate(key,selection,by,ac):
 spec=CONTRACT[key];g=load(spec['report']);i,t,_=bound(spec,True);s=load(selection);want={r['localPath']:sh(r) for r in s['files']};ck(len(want)==len(s['files']),'selection duplicate')
 ck(g['status']=='clean' and not g['findings'] and not g['errors'] and g['selectionPin']==sh(selection),'document privacy status/selection')
 ck({r['path']:sh(r) for r in g['files']}==want and len(g['files'])==len(want),'document privacy exact file coverage')
 ck(selection['path'] in i['command'] and spec['report']['path'] in i['command'],'document privacy exact command')
 phase=P(spec['invocation']['path']).relative_to(C).as_posix();ck(phase in by,'document privacy absent from actual accounting')
 for s in ac['stages'].values():ck(sum(x['phaseInvocation']['path']==phase for x in s['records'])==1,'document privacy incomplete seed stage')
 return spec

def docpaths():return [D/f'Roadmark-RECOVERY-MANIFEST-NISSAN-WORKING-{DATE}.json',D/f'Roadmark-RECOVERY-VERIFICATION-NISSAN-WORKING-{DATE}.json',D/f'Roadmark-RECOVERY-INDEX-NISSAN-WORKING-{DATE}.md',D/f'Roadmark-NISSAN-M1-UPDATE-{DATE}.md']
def compare_json(p,expected):
 actual=get(p);timestamps(actual['createdAt']);ck(actual=={'schemaVersion':11,'createdAt':actual['createdAt'],**expected},'document exact fields/content differ: '+P(p).name);return actual

def documents(p,counts,ars,cl,rec,plan,s,b,denial,supp,priv,archiveids):
 ids=index(archiveids,'filename')
 def bind(a):return {**a,**{k:ids[a['filename']][k] for k in ('library_file_id','file_id','version')}} if a['filename'] in ids else dict(a)
 p={**p,'source':bind(p['source']),'newArchives':[bind(a) for a in p['newArchives']],'archivesInRestoreOrder':[bind(a) for a in p['archivesInRestoreOrder']]};q=common(b,denial,supp);dep=cl['inheritedDependencyProposal'];paths=docpaths()
 instructions=['Fetch the exact recovery archives listed in restoreOrder and verify their size and SHA-256.','Extract in that order into a clean directory. The standalone Nissan source replaces the Renault source; unchanged prior proof archives are reused.','Verify every resulting regular file against files. Project root roadmark contains703 project files plus its embedded source manifest.','Use only the exact reversible copy-only mappings for original prose receipts; preserve original expected hashes separately from stored copied hashes.','The two historical delivery-only artifacts remain outside the recovery archive count and have their own exact identities/member mappings.','Historical dependencies and compatible toolchain setup require their recorded expected pins. This recovery replay does not run the application or grant a release pass.']
 native='New recovery archives at document preparation; these documents own creates are bound later in the active and final receipts.'
 manifest=compare_json(paths[0],{'title':'Roadmark Nissan31 working recovery','status':STATUS,'workState':s['workingResult'],'source':{k:v for k,v in p['source'].items() if k!='memberFiles'},'baseRecovery':{'label':'Renault30','sourceLibraryFileId':b['sourceLibraryFileId'],'manifestLibraryFileId':b['manifestLibraryFileId'],'activeReceiptLibraryFileId':b['activeReceiptLibraryFileId'],'manifest':p['baseManifest'],'finalReceipt':p['baseFinalReceipt'],'terminalReceipt':p['baseTerminalReceipt'],'priorCounts':b['counts'],'nativeByteReadbackVerified':False},'archivesInRestoreOrder':p['archivesInRestoreOrder'],'newArchives':[{k:v for k,v in a.items() if k!='memberFiles'} for a in p['newArchives']],'files':p['files'],'counts':counts,'currentValidation':s['currentValidation'],'captureScope':ref(C/'FROZEN-CAPTURE-SCOPE.json'),'copyOnlySanitation':get(C/'COPY-SANITATION-MAPPING.json'),'independentVerification':ref(C/'INDEPENDENT-NISSAN-RECOVERY-VERIFICATION-v1.json'),'privacyVerification':priv,'currentImageProvenance':get(C/'IMAGE-PROVENANCE.json'),'currentRawRuntimeExclusion':s['rawRuntimeExclusion'],'dependencyClosure':ref(C/'INDEPENDENT-NISSAN-REFERENCE-CLOSURE-v1.json'),'inheritedDependencyReconstruction':{'receipt':ref(C/'INDEPENDENT-NISSAN-REFERENCE-CLOSURE-v1.json'),'count':len(dep['dependencies']),'dependencies':dep['dependencies'],'dependenciesCanonicalSha256':dep['canonicalSha256'],'originalExpectedPathsAndHashesUnchanged':True},'supportInventory':ref(C/'SUPPORT-MEMBER-INVENTORY.json'),'supportReuse':ref(C/'SUPPORT-REUSE-MAPPING.json'),'nativeCreateEvidenceScope':native,'inheritedBoundaries':plan['historicalLimitations'],'restoreInstructions':instructions,'noDeletionOrReplacement':True,'noPinnedSourceOrStatusMutation':True,'noExecutableSourceTextEmbedded':True,**q})
 compare_json(paths[1],{'status':STATUS,'counts':counts,'independent':rec,'privacyReports':priv,'postSealEvidence':retained(ref(C/'POST-SEAL-METADATA-SELECTION-v1.json')),'postSealSelection':ref(C/'POST-SEAL-METADATA-SELECTION-v1.json'),'currentValidation':s['currentValidation'],'limitations':manifest['inheritedBoundaries'],'scope':'Exact fresh-member replay and pinned prior metadata reuse; no broad historical payload rescan or clone','nativeCreateEvidenceScope':native,**q})
 lines=['# Roadmark Nissan31 working recovery','',NOTE,'',s['workingResult'],'',f"Source: {p['source']['filename']} ({p['source']['bytes']:,} bytes; SHA-256 {p['source']['sha256']})",f"Restore set: {p['archiveCount']} archives, {p['logicalFiles']:,} logical files, {p['freshFiles']:,} fresh verified members; {p['baseArchivesReused']} prior archives reused.",'','## Restore','']+instructions+['','## Boundaries','']+manifest['inheritedBoundaries']+['','## Archive order','']
 for a in p['archivesInRestoreOrder']:lines.append(f"{a['restoreOrder']}. {a['filename']} | {a['bytes']} bytes | SHA-256 {a['sha256']} | Library {a['library_file_id']}")
 ck(raw(ref(paths[2]))==('\n'.join(lines)+'\n').encode(),'index exact content')
 summary=next(r for r in get(C/'source-capture.json')['files'] if r['path']=='docs/NISSAN_M1_UPDATE.md');text=raw(ref(paths[3]));suffix=('\n\n## Recovery note\n\n'+s['workingResult']+'\n\n'+NOTE+'\n').encode();ck(text.endswith(suffix) and bp(text[:-len(suffix)])==sh(summary),'summary exact source hash plus truthful suffix')
 selection=get(C/'DOCUMENT-PRIVACY-SELECTION-v1.json');ck(selection['files']==[{'localPath':str(x),**sh(ref(x))} for x in paths],'four exact document selection')
 return p,[ref(x) for x in paths]

def acceptance(confirmation,wanted,evidence):
 d=load(confirmation);ck(d['status']=='accepted' and isinstance(d['message_id'],str) and d['message_id'] and len(d['library_file_ids'])==len(wanted)==len(set(wanted)) and set(d['library_file_ids'])==set(wanted),'exact attachment acceptance');timestamps(d['acceptedAt'])
 ck(d['nativeByteReadbackVerified'] is False and d['fullProjectTypeScriptPassed'] is False and d['releaseReady'] is False,'attachment scope qualification')
 req=load(evidence['request']);res=load(evidence['response']);ck(at(req,evidence['requestChannelPath'])=='chatgpt' and at(req,evidence['requestLibraryIdsPath'])==d['library_file_ids'],'exact native attachment request')
 ck(at(res,evidence['responseStatusPath'])=='accepted' and at(res,evidence['responseMessageIdPath'])==d['message_id'],'actual accepted send response')
 if evidence.get('responseLibraryIdsPath') is not None:ck(at(res,evidence['responseLibraryIdsPath'])==d['library_file_ids'],'response attachment identity set')
 return d

def previous(mode,counts,documents):
 d=get(C/OUTPUTS[mode]);ck(d['result']==RESULTS[mode] and d['checkerScript']==OWN and d['acceptanceScope']==SCOPE and d['nativeByteReadbackVerified'] is False and d['counts']==counts and d['documentPins']==documents,'prior exact independent check');load(d['runtimeInputContract']);load(d['runtimeInputContractReview']);return ref(C/OUTPUTS[mode])

def active(p,counts,s,b,denial,supp,a,d,docs):
 q=common(b,denial,supp);doccheck=previous('documents',counts,docs);confirmation=ref(C/'DELIVERY-CONFIRMATION.json');wanted=[next(x['library_file_id'] for x in a if x['filename']==p['source']['filename'])]+[next(x['library_file_id'] for x in d if x['filename']==P(r['path']).name) for r in docs]
 delivery=acceptance(confirmation,wanted,CONTRACT['deliveryEvidence']);ck(delivery['activeFinalClosureCompleteAtDelivery'] is False,'active closure premature at five-file send')
 x=compare_json(D/f'Roadmark-RECOVERY-ACTIVE-STATE-NISSAN-WORKING-{DATE}.json',{'status':STATUS,'sourceLibraryFileId':wanted[0],'files':a+d,'counts':counts,'currentValidation':s['currentValidation'],'workingResult':s['workingResult'],'currentNissanNormalReportOutcome':'PASSED','currentNissanSavedComparatorOutcome':'PASSED','inheritedRenaultOriginalReportOutcome':'UNKNOWN','inheritedCupraInterruptedScanOutcome':'UNKNOWN','independentRecovery':ref(C/'INDEPENDENT-NISSAN-RECOVERY-VERIFICATION-v1.json'),'independentDocuments':doccheck,'lateMetadata':retained(ref(C/'ACTIVE-LATE-METADATA-SELECTION-v1.json')),'lateMetadataSelection':ref(C/'ACTIVE-LATE-METADATA-SELECTION-v1.json'),'seedReadAccountingAsOfActivePreparation':get(C/'SEED-READ-ACCOUNTING-after-docs-v1.json'),'baseContinuity':{'finalReceipt':ref(FIXED['baseFinal'][0]),'terminalReceipt':ref(FIXED['baseTerminal'][0]),'archiveReuse':141,'historicalUnknownOutcomesAndUnavailableDraftDisclosuresPreserved':True},'deliveryConfirmation':confirmation,'delivery':'Exact five files accepted in the recorded parent native attachment send; active receipt is separate.','noDeletionOrReplacement':True,'noPinnedSourceOrStatusMutation':True,'noExecutableSourceTextEmbedded':True,**q})
 ar=ref(D/f'Roadmark-RECOVERY-ACTIVE-STATE-NISSAN-WORKING-{DATE}.json');ck(get(C/'ACTIVE-PRIVACY-SELECTION-v1.json')['files']==[{'localPath':ar['path'],**sh(ar)}],'active exact privacy selection')
 return ar,delivery

def final_receipt(p,counts,b,denial,supp,a,d,activeids,docs,delivery):
 files=a+d+activeids;index(files,'library_file_id');index(files,'file_id');by=index(files,'filename');doc=lambda k:by[f'Roadmark-RECOVERY-{k}-NISSAN-WORKING-{DATE}.json']['library_file_id']
 return compare_json(C/'FINAL-NISSAN-UPLOAD-RECEIPTS.json',{'status':STATUS,'sourceLibraryFileId':by[p['source']['filename']]['library_file_id'],'archiveLibraryFileIds':[r['library_file_id'] for r in a],'indexLibraryFileId':by[f'Roadmark-RECOVERY-INDEX-NISSAN-WORKING-{DATE}.md']['library_file_id'],'manifestLibraryFileId':doc('MANIFEST'),'verificationLibraryFileId':doc('VERIFICATION'),'summaryLibraryFileId':by[f'Roadmark-NISSAN-M1-UPDATE-{DATE}.md']['library_file_id'],'activeReceiptLibraryFileId':activeids[0]['library_file_id'],'files':files,'counts':counts,'independentRecovery':ref(C/'INDEPENDENT-NISSAN-RECOVERY-VERIFICATION-v1.json'),'documentCheck':previous('documents',counts,docs),'activeCheck':previous('active',counts,docs),'seedReadAccounting':get(C/'SEED-READ-ACCOUNTING-after-active-v1.json'),'deliveryConfirmation':delivery,'deliveryConfirmationPin':ref(C/'DELIVERY-CONFIRMATION.json'),'activeSnapshotAccountingIsAsOfPreparation':True,'noDeletionOrReplacement':True,'noPinnedSourceOrStatusMutation':True,'noExecutableSourceTextEmbedded':True,**common(b,denial,supp)})

def phase_history():
 rows=[]
 for spec in CONTRACT['phaseHistory']:
  i,t,outcome=bound(spec);rows.append({'invocation':spec['invocation'],'terminal':spec['terminal'],'outcome':outcome})
 known={x['invocation']['path'] for x in rows};ck(len(known)==len(rows),'duplicate preparation phase')
 p=P(CONTRACT['currentCheckerInvocationPath']);ck(p.parent==C and p.name.endswith('.resources.invocation.json') and identity(p)[2]<=65536,'live launch metadata scope');before=identity(p);data=p.read_bytes();ck(identity(p)==before,'launch metadata changed');current={'path':str(p),**bp(data)};register(current);i=load(current);ck(P(current['path']).parent==C and current['path'].endswith('.resources.invocation.json') and i['addressSpaceLimitBytes']==LIMIT and i['wallLimitSeconds']==600,'current checker bounded invocation')
 ck(isinstance(i['command'],list) and i['command'][-len(LAUNCH):]==LAUNCH,'current checker exact command including seals')
 ck({str(p) for p in C.glob('*.resources.invocation.json')}==known|{current['path']},'omitted actual preparation invocation')
 ck(not P(current['path'].replace('.invocation.json','.json')).exists(),'checker premature terminal')
 return rows

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('mode',choices=list(RESULTS));parser.add_argument('--contract',required=True);parser.add_argument('--contract-sha256',required=True);parser.add_argument('--review',required=True);parser.add_argument('--review-sha256',required=True);args=parser.parse_args()
 resource.setrlimit(resource.RLIMIT_AS,(LIMIT,LIMIT));started=time.monotonic();output=C/OUTPUTS[args.mode];ck(not output.exists(),'immutable output exists');cr,rr=context(args)
 b,t,denial,supp=inherited();rec,plan,s=recovery();p,counts,ars,cl=restore(rec,b);ac,summary,by=accounting();priv=privacy(ars,by,ac);ck(CONTRACT['archivePrivacy']==rec['privacyVerification'],'archive privacy differs from independently replayed gates')
 want={a['filename']:{'localPath':a['file'],**sh(a)} for a in ars};a=normalized('archives',want,denial);p,docs=documents(p,counts,ars,cl,rec,plan,s,b,denial,supp,priv,a);document_gate('documentPrivacy',ref(C/'DOCUMENT-PRIVACY-SELECTION-v1.json'),by,ac)
 history=phase_history();native=list(a);delivery=None;active_delivery=None;active_ref=None
 if args.mode!='documents':
  d=normalized('documents',{P(x['path']).name:{'localPath':x['path'],**sh(x)} for x in docs},denial);active_ref,delivery=active(p,counts,s,b,denial,supp,a,d,docs);native+=d
 if args.mode in ('persisted','terminal'):
  document_gate('activePrivacy',ref(C/'ACTIVE-PRIVACY-SELECTION-v1.json'),by,ac);ai=normalized('active',{P(active_ref['path']).name:{'localPath':active_ref['path'],**sh(active_ref)}},denial);native+=ai;f=final_receipt(p,counts,b,denial,supp,a,d,ai,docs,delivery)
  ck(f['seedReadAccounting']==ac,'final accounting is not current after-active actual accounting')
  if args.mode=='terminal':
   previous('persisted',counts,docs);active_delivery=acceptance(CONTRACT['inputs']['activeDeliveryConfirmation'],[ai[0]['library_file_id']],CONTRACT['activeDeliveryEvidence']);ck(active_delivery['message_id']!=delivery['message_id'],'active must have separate accepted send')
   ck(datetime.datetime.fromisoformat(active_delivery['acceptedAt'].replace('Z','+00:00'))>=datetime.datetime.fromisoformat(delivery['acceptedAt'].replace('Z','+00:00')),'active-send chronology')
 out={'schemaVersion':1,'result':RESULTS[args.mode],'checkedAt':stamp(),'checkerScript':OWN,'runtimeInputContract':cr,'runtimeInputContractReview':rr,'inputPins':list(READ.values()),'acceptanceScope':SCOPE,'nativePersistenceStatus':'CREATE_CONFIRMED_NATIVE_BYTE_READBACK_UNPASSED','nativeByteReadbackVerified':False,'currentMaterializeAttempts':0,'currentAlternateReadRoutes':0,'deniedRouteRetried':False,'blockedReadbackEvidence':denial,'counts':counts,'documentPins':docs,'nativeIdentityChecks':native,'freshRecovery':CONTRACT['inputs']['recovery'],'referenceClosure':ref(C/'INDEPENDENT-NISSAN-REFERENCE-CLOSURE-v1.json'),'historicalSupplementsOutsideRecovery':supp,'currentSeedAccounting':CONTRACT['inputs']['accounting'],'currentInvocationSummary':summary,'actualPreparationPhaseHistory':history,'deliveryConfirmation':ref(C/'DELIVERY-CONFIRMATION.json') if delivery else None,'activeReceipt':active_ref,'activeReceiptSeparateDeliveryConfirmation':CONTRACT['inputs'].get('activeDeliveryConfirmation') if active_delivery else None,'acceptedFinalRetentionScope':'accepted','preservedOutcomes':rec['preservedOutcomes'],'fullProjectTypeScriptPassed':False,'releaseReady':False,'scope':{'metadataAndCurrentDocumentBytesOnly':True,'archivePayloadReads':0,'seedPayloadReads':0,'liveSourcePayloadReads':0,'producerCodeExecuted':False,'xattrsWritten':False,'providerReturnedVersionXattrsInspected':True,'externalOperations':0,'noNativeByteReadbackClaim':True},'resources':{'addressSpaceLimitBytes':LIMIT,'wallSeconds':round(time.monotonic()-started,3),'maxRssKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
 data=(json.dumps(out,indent=2)+'\n').encode();fd=os.open(output,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o444)
 with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 print(json.dumps({'result':out['result'],'output':{'path':str(output),**bp(data)},'counts':counts,'nativeByteReadbackVerified':False}))
if __name__=='__main__':main()
