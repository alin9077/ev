#!/usr/bin/env python3
"""Copy one exact reviewed support selection; prior executable bytes remain referenced once."""
import hashlib,json,pathlib,sys,shutil
from nissan_capture_adapter_v2 import C,B,capture_module
cap=capture_module();P=pathlib.Path

def core(r):return {k:r[k] for k in ('bytes','sha256')}
def ref(p):return {'path':str(p),**cap.pin(p)}
def main():
 assert len(sys.argv)==3;sp=P(sys.argv[1]);assert sp.parent.resolve()==C and sp.name=='SUPPORT-SELECTION-v1.json';assert cap.pin(sp)['sha256']==sys.argv[2]
 s=cap.load(sp);assert s['status']=='INDEPENDENTLY_ACCEPTED_EXACT_NISSAN_SUPPORT_SELECTION';cap.check(P(s['review']['path']),s['review']);cap.check(P(s['baseManifest']['path']),s['baseManifest'])
 base=cap.load(s['baseManifest']['path']);oldsource=base['source']['filename'];archives={a['filename']:a for a in base['archivesInRestoreOrder'] if a['filename']!=oldsource};members={r['path']:r for r in base['files'] if not r['path'].startswith('roadmark/')}
 for item in s['outsideRecoveryArtifacts']:
  a=item['archive'];assert a['filename'] not in archives;archives[a['filename']]=a
  cap.check(P(item['package']['path']),item['package']);package=cap.load(item['package']['path']);assert core(package)==core(a)
  for m in package['members']:
   assert m['path'] not in members;members[m['path']]={k:m[k] for k in ('path','bytes','sha256')}
 selected=s['files'];assert len({r['originalPath'] for r in selected})==len(selected) and len({r['localRelativePath'] for r in selected})==len(selected)
 # Validate the complete selection and every reuse authority before the first copy.
 checked=[]
 for r in selected:
  p=P(r['originalPath']);cap.safe(r['localRelativePath']);got,identity=cap.check(p,r);assert p==C/r['localRelativePath'] or r.get('externalOriginalExplicitlySelected') is True
  assert r['action'] in ('fresh','reuse')
  if r['action']=='reuse':
   m=r['retainedMember'];a=r['retainedArchive'];assert m in members and core(members[m])==got;assert a['filename'] in archives
   assert all(archives[a['filename']].get(k)==a.get(k) for k in ('filename','bytes','sha256','library_file_id','file_id','version') if k in a)
   auth=r['archiveMappingAuthority'];cap.check(P(auth['path']),auth);d=cap.load(auth['path']);assert d['filename']==a['filename'] and core(d)==core(a)
   rows=d.get('memberFiles',d.get('members'));assert isinstance(rows,list);matching=[x for x in rows if x['path']==m];assert len(matching)==1 and core(matching[0])==got
  checked.append((r,p,got,identity))
 out=C/'support-staging-v1';out.mkdir(exist_ok=False);fresh=[];reused=[]
 for r,p,got,before in checked:
  assert cap.identity(p)==before
  if r['action']=='reuse':
   reused.append({k:r[k] for k in ('originalPath','localRelativePath','retainedMember','retainedArchive','archiveMappingAuthority','bytes','sha256')}|{'kind':'exact-prior-member-reuse','outsideRecoveryArchiveSet':bool(r.get('outsideRecoveryArchiveSet'))});continue
  dest=out/r['localRelativePath'];dest.parent.mkdir(parents=True,exist_ok=True)
  with p.open('rb') as src,dest.open('xb') as dst:shutil.copyfileobj(src,dst,65536)
  cap.check(dest,got);assert cap.identity(p)==before;fresh.append({'path':'nissan-recovery-support/'+r['localRelativePath'],'originalPath':str(p),'payloadPath':str(dest),**got})
 mp=C/'SUPPORT-REUSE-MAPPING.json';cap.dump(mp,{'result':'EXACT_PRIOR_MEMBER_REUSE','files':reused,'baseManifest':s['baseManifest'],'outsideRecoveryArtifacts':s['outsideRecoveryArtifacts'],'selection':ref(sp),'reconstruction':'Restore the exact archive or separately listed historical delivery-only artifact; verify retained member hash, then map its bytes to originalPath under the chosen relocated checkpoint root. These references do not add an archive to the recovery chain.','noExecutableSourceTextEmbedded':True})
 for p in (sp,mp):
  dest=out/p.name;assert p.name not in {r['localRelativePath'] for r in selected}
  with p.open('rb') as src,dest.open('xb') as dst:shutil.copyfileobj(src,dst,65536)
  cap.check(dest,cap.pin(p));fresh.append({'path':'nissan-recovery-support/'+p.name,'originalPath':str(p),'payloadPath':str(dest),**cap.pin(dest)})
 inv={'result':'EXPLICIT_UNIQUE_NISSAN_SUPPORT_SELECTION','files':fresh,'reusedFiles':len(reused),'selection':ref(sp),'sourceCodeEmbeddedInMetadata':False,'outsideRecoveryArtifactCountNotAdded':True}
 cap.dump(C/'SUPPORT-MEMBER-INVENTORY.json',inv);cap.dump(C/'SUPPORT-PATTERN-SELECTION-v1.json',{'files':fresh});print(json.dumps({'newSupportMembers':len(fresh),'reusedMembers':len(reused),'freshBytes':sum(r['bytes'] for r in fresh)}))
if __name__=='__main__':main()
