#!/usr/bin/env python3
"""Current Nissan seed receipts only; historical Renault accounting is an exact reference."""
import ast,sys
from nissan_capture_adapter_v2 import C,B,P,capture_module,load_reference
COUNTER_PIN={'bytes': 4019, 'sha256': 'a41688c728873fb4e40deba7cf4857020cf61b8aed688b6789b1f396d85bc73d'}
INHERITED_PIN={'bytes': 31300, 'sha256': 'fda3a42898fb6fbac1b018954afc56fb654b86edbba3c194ebc29431e6773e80'}
def transform(tree):
 main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main');assert len(main.body)==20
 removed=main.body[4:12];assert len(removed)==8 and all(12<=n.lineno<=17 for n in removed)
 assert isinstance(removed[0],ast.Assign) and removed[0].targets[0].id=='failureReview'
 main.body[4:12]=ast.parse("for phase in phases:\n phase['knownZeroSeedPreconditionFailure']=False\n phase['zeroReadStatus']='NOT_INDEPENDENTLY_ESTABLISHED; absent stages remain unknown partials'\n").body
 record=next(n for n in main.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='record')
 keys=record.value.keys;indices=[i for i,k in enumerate(keys) if isinstance(k,ast.Constant) and k.value=='inheritedCupraAccounting'];assert len(indices)==1;i=indices[0]
 keys[i].value='inheritedRenaultAccounting';record.value.values[i]=ast.Name(id='INHERITED_RENAULT',ctx=ast.Load())
 return tree
def main():
 assert len(sys.argv)==2 and P(sys.argv[1]).parent.resolve()==C
 cap=capture_module();priorPath=B/'SEED-READ-ACCOUNTING-after-active-v2.json';cap.check(priorPath,INHERITED_PIN);prior=cap.load(priorPath)
 assert len(prior['phases'])==11 and sum(p['outcome']=='PASS' for p in prior['phases'])==9 and sum(p['knownZeroSeedPreconditionFailure'] for p in prior['phases'])==2
 m=load_reference('nissan_accounting_reference',B/'build_seed_accounting_v1.py',COUNTER_PIN,transform)
 m.INHERITED_RENAULT={'receipt':{'path':str(priorPath),**INHERITED_PIN},'attempts':11,'successfulPasses':9,'knownZeroPreconditionFailures':2,'originalCupraUnknownPreservedByExactReceipt':True,'originalRenaultFactualReportUnknownPreservedSeparately':True}
 original_load=m.load;original_dump=m.dump
 def load(path):
  result=original_load(path);folder=P(path).parent.name
  if folder=='seed-read-invocations':assert result['exactPinnedMembersReadAndVerified']==200 and result['historicalArchives']==21 and result['noExtractedValuesPersisted']
  elif folder=='audi-seed-read-invocations':assert result['payloadReadOperations']==6 and result['noValuesOrValueDigestsPersisted']
  elif folder=='deepal-seed-read-invocations':assert result['payloadReadOperations']==5 and result['noValuesOrValueDigestsPersisted']
  return result
 def dump(path,record):
  phases=record['phases'];stages=record['stages']
  record['currentInvocationSummary']={'attempts':len(phases),'successfulPasses':sum(r['outcome']=='PASS' for r in phases),'nonzeroOrTimeout':sum(r['outcome']=='NONZERO_OR_TIMEOUT' for r in phases),'unknownTerminalOutcomes':sum(r['outcome']=='UNKNOWN' for r in phases),'independentlyEstablishedKnownZeroFailures':0,'zeroFailuresQualification':'No current phase is classified known-zero by this revision'}
  for stage in stages.values():
   completed={r['phaseInvocation']['path'] for r in stage['records']};stage['unknownPartialReadPhases']=[r['invocation'] for r in phases if r['invocation']['path'] not in completed]
   stage['completedOperationsAreLowerBoundWhenUnknownPartialsExist']=bool(stage['unknownPartialReadPhases'])
  record['scope']='Nissan invocation/stage files only. Inherited Renault is pinned, not added to current counts. Missing receipts do not prove zero reads.'
  original_dump(path,record)
 m.load=load;m.dump=dump;m.main()
if __name__=='__main__':main()
