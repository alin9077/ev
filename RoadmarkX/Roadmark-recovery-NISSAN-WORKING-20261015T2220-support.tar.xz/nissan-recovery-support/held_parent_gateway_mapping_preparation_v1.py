import pathlib,json,hashlib,datetime,ast
C=pathlib.Path('.')
def pin(p):
 p=p.resolve();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(n,d):
 p=C/n
 with p.open('x') as f:json.dump(d,f,indent=2);f.write('\n')
 return pin(p)
p=C/'nissan_phase_gateway_v1.py';b=p.read_text();old="assert len(c['locations'])==1 and c['locations'][0]['pointer']=='/authorization'";assert b.count(old)==1
new=b.replace(old,"assert c['locations']==['/authorization']");selfs=new.count('nissan_phase_gateway_v1.py');assert selfs==3;new=new.replace('nissan_phase_gateway_v1.py','nissan_phase_gateway_v2.py');ast.parse(new)
p2=C/'nissan_phase_gateway_v2.py'
with p2.open('x') as f:f.write(new)
p=C/'NISSAN-ADAPTER-PREPARATION-v1.json';d=json.loads(p.read_text());d['supersedesUnexecutedPreparation']=pin(p);d['preparedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['schemaCorrection']={'heldGateway':pin(C/'nissan_phase_gateway_v1.py'),'actualCandidateOutput':pin(C/'JSON-SANITIZER-CANDIDATES-v1.json'),'oldCheck':"c['locations'][0]['pointer']",'newCheck':"c['locations']==['/authorization']",'reason':'Actual inherited preflight locations are a list of strings. Detected by parent and independent reviewer before any capture/package execution.','oldGatewayExecuted':False,'selfArgvPathLiteralUpdates':selfs}
for r in d['localPins']:
 if r['path'].endswith('/nissan_phase_gateway_v1.py'):r.update(pin(p2))
for k,v in d['preparedInvocations'].items():d['preparedInvocations'][k]=[x.replace('/nissan_phase_gateway_v1.py','/nissan_phase_gateway_v2.py') for x in v]
print(json.dumps(write('NISSAN-ADAPTER-PREPARATION-v2.json',d)))
proposal=C/'PROSE-KEY-RENAME-PROPOSAL-v1.json';classification=C/'INDEPENDENT-NISSAN-JSON-CANDIDATE-CLASSIFICATION-v1.json'
assert pin(proposal)['sha256']=='d8708b395690b2ccfe1a5955b3bf39a978f480dd5b1ce8cf8eaeaf800de5953d';assert pin(classification)['sha256']=='9ee78da8c7db71ae6e0750868c604caa7970a982deabc4dbedf176140dd6ca9b'
grant=write('ROOT-COPY-KEY-RENAME-GRANT-v1.json',{'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'approvalScope':'Root approved only the12 exact copied /authorization to /approvalScope key renames in the pinned proposal under the pinned independent classification. Preserve values, every outside-key byte, originals/expected pins and exact inverse. No actual headers, credentials or blanket field renames; every delivered member remains subject to full privacy scans.','proposal':pin(proposal),'classification':pin(classification),'originalsMayBeChanged':False,'onlyExactListedCopies':True})
pr=json.loads(proposal.read_text());m={'schemaVersion':1,'status':'APPROVED_EXACT_COPY_ONLY_PROSE_KEY_MAPPING','files':pr['files'],'originalExpectedPinsUnchanged':True,'originalsUnchanged':True,'secretMaterialChanged':False,'valuesAndOtherBytesPreserved':True,'inverseOperation':pr['inverseOperation'],'rootApproval':grant,'classification':pin(classification),'proposal':pin(proposal),'mappingPreparedBeforeCapture':True}
a=write('PROSE-KEY-RENAME-APPROVALS.json',m);s=write('COPY-SANITATION-MAPPING.json',{**m,'purpose':'Exact inverse reconstruction for the12 approved copied ordinary-prose metadata key changes'})
g=write('NISSAN-CAPTURE-CANDIDATE-APPROVAL-v1.json',{'status':'INDEPENDENTLY_ACCEPTED_EXACT_NISSAN_COPY_MAPPING','preflight':pr['candidateReport'],'renameMapping':a,'sanitationMapping':s,'review':pin(classification),'rootApproval':grant,'proposal':pin(proposal),'mappingCount':12,'independentClassificationAndRootApprovalBothRequired':True,'noBlanketFieldExemption':True,'captureHasNotYetRun':True})
print(json.dumps({'gateway':pin(p2),'mapping':a,'sanitation':s,'captureGate':g}))
