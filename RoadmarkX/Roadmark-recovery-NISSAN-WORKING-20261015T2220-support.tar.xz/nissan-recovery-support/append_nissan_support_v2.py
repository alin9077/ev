#!/usr/bin/env python3
"""Append one finite reviewed support amendment without touching the original235 files."""
import json,pathlib,shutil,sys
P=pathlib.Path;C=P(__file__).resolve().parent
BASE_INVENTORY={'path':str(C/'SUPPORT-MEMBER-INVENTORY.json'),'bytes':128818,'sha256':'84cfb35b7c29e45811698212f2680ee51f5b25682356be4ee176bd67925e5c79'}
def main():
    assert len(sys.argv)==5
    from nissan_capture_adapter_v2 import capture_module
    cap=capture_module()
    def ref(p):return {'path':str(p),**cap.pin(p)}
    sp,rp=map(P,(sys.argv[1],sys.argv[3]))
    assert sp==C/'SUPPORT-ADDITIONS-SELECTION-v1.json' and rp.parent==C and rp.suffix=='.json'
    sr,rr=ref(sp),ref(rp);assert sr['sha256']==sys.argv[2] and rr['sha256']==sys.argv[4]
    selected=cap.load(sp);review=cap.load(rp)
    assert selected['status']=='EXACT_FINITE_NISSAN_SUPPORT_APPEND_SELECTION'
    assert review['result']=='ACCEPTED_EXACT_NISSAN_SUPPORT_APPEND_SELECTION' and review['selection']==sr and review['baseInventory']==BASE_INVENTORY
    assert selected['baseInventory']==BASE_INVENTORY
    cap.check(P(BASE_INVENTORY['path']),BASE_INVENTORY);old=cap.load(BASE_INVENTORY['path']);assert len(old['files'])==235
    contract_pin=selected['privacyContract'];assert P(contract_pin['path'])==C/'NISSAN-SUPPORT-PRIVACY-CONTRACT-v1.json'
    cap.check(P(contract_pin['path']),contract_pin);contract=cap.load(contract_pin['path'])
    assert contract['status']=='INDEPENDENTLY_ACCEPTED_EXACT_NISSAN_SUPPORT_PRIVACY_ADAPTER'
    cap.check(P(contract['review']['path']),contract['review']);adapter_review=cap.load(contract['review']['path'])
    assert adapter_review['result']=='ACCEPTED_EXACT_NISSAN_SUPPORT_APPEND_PRIVACY_PACKAGE_ADAPTERS'
    own=ref(P(__file__).resolve());assert contract['appendAdapter']==adapter_review['appendAdapter']==own
    retention=contract['additionalRetention'];assert retention==adapter_review['additionalRetention'] and isinstance(retention,list)
    assert all(set(r)=={'path','bytes','sha256'} and type(r['bytes']) is int and r['bytes']>=0 and isinstance(r['sha256'],str) and len(r['sha256'])==64 for r in retention)
    required=[contract[k] for k in ('privacyAdapter','appendAdapter','packageAdapter','testAdapter','classification','rootGrant','review','tests')]+[contract_pin]+retention
    expected={r['path']:r for r in required};assert len(expected)==len(required)
    additions=selected['files'];assert len(additions)==len(expected)
    assert {r['originalPath'] for r in additions}==set(expected)
    oldpaths={r['path'] for r in old['files']};assert len(oldpaths)==235
    names=[r['localRelativePath'] for r in additions]+[sp.name,rp.name]
    assert len(names)==len(set(names))
    reserved={'SUPPORT-MEMBER-INVENTORY.json','SUPPORT-MEMBER-INVENTORY-v2.json','SUPPORT-PATTERN-SELECTION-v1.json','SUPPORT-PATTERN-SELECTION-v2.json','SUPPORT-REUSE-MAPPING.json','SUPPORT-SELECTION-v1.json'}
    for name in names:
        cap.safe(name);assert P(name).name==name and name not in reserved
        assert 'nissan-recovery-support/'+name not in oldpaths
    out=C/'support-additions-staging-v1';inventory=C/'SUPPORT-MEMBER-INVENTORY-v2.json';patterns=C/'SUPPORT-PATTERN-SELECTION-v2.json'
    assert not out.exists() and not inventory.exists() and not patterns.exists()
    checked=[]
    for row in additions:
        p=P(row['originalPath']);assert p.parent==C and p.name==row['localRelativePath']
        assert {'path':str(p),'bytes':row['bytes'],'sha256':row['sha256']}==expected[str(p)]
        got,before=cap.check(p,row);checked.append((p,p.name,got,before))
    for p,refpin in ((sp,sr),(rp,rr)):
        got,before=cap.check(p,refpin);checked.append((p,p.name,got,before))
    prior=[]
    for row in old['files']:
        p=P(row['payloadPath']);assert p.is_relative_to(C/'support-staging-v1')
        got,before=cap.check(p,row);prior.append((p,before))
    # Every destination/reserved name and source pin is checked before the first copy.
    out.mkdir(exist_ok=False);fresh=[]
    for p,name,got,before in checked:
        assert cap.identity(p)==before;dest=out/name
        with p.open('rb') as source,dest.open('xb') as target:shutil.copyfileobj(source,target,65536)
        cap.check(dest,got);assert cap.identity(p)==before
        fresh.append({'path':'nissan-recovery-support/'+name,'originalPath':str(p),'payloadPath':str(dest),**got})
    for p,before in prior:assert cap.identity(p)==before
    amended={**old,'files':old['files']+fresh,'appendOnlyBaseInventory':BASE_INVENTORY,'appendSelection':sr,'appendReview':rr,'unchangedPriorMembers':235,'appendedMembers':len(fresh)}
    cap.dump(inventory,amended);cap.dump(patterns,{'files':amended['files'],'inventory':ref(inventory)})
    print(json.dumps({'inventory':ref(inventory),'patternSelection':ref(patterns),'unchangedPriorMembers':235,'appendedMembers':len(fresh),'totalMembers':len(amended['files'])}))
if __name__=='__main__':main()
