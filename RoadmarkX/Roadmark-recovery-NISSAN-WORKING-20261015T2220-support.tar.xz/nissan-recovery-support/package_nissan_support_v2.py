#!/usr/bin/env python3
"""Pinned Nissan package implementation, support-only inventory basename revision."""
import pathlib,sys
P=pathlib.Path;C=P(__file__).resolve().parent
GATEWAY={'bytes':4385,'sha256':'9320375725e900d042f6e5bbc7fc75f53564e16ec3a86af6e7fa9a07d82322df'}
def main():
    assert len(sys.argv)==4
    from nissan_capture_adapter_v2 import B,capture_module,load_reference,replace_constant
    cap=capture_module();inv=C/'SUPPORT-MEMBER-INVENTORY-v2.json'
    assert cap.pin(inv)['sha256']==sys.argv[1]
    cp=P(sys.argv[2]);assert cp==C/'NISSAN-SUPPORT-PRIVACY-CONTRACT-v1.json' and cap.pin(cp)['sha256']==sys.argv[3]
    contract=cap.load(cp);assert contract['status']=='INDEPENDENTLY_ACCEPTED_EXACT_NISSAN_SUPPORT_PRIVACY_ADAPTER'
    own={'path':str(P(__file__).resolve()),**cap.pin(__file__)};assert contract['packageAdapter']==own
    cap.check(P(contract['review']['path']),contract['review']);review=cap.load(contract['review']['path'])
    assert review['result']=='ACCEPTED_EXACT_NISSAN_SUPPORT_APPEND_PRIVACY_PACKAGE_ADAPTERS' and review['packageAdapter']==own
    assert not (C.parents[1]/'Roadmark-recovery-NISSAN-WORKING-20261015T2220-support.tar.xz').exists() and not (C/'support-package.json').exists()
    gateway=load_reference('nissan_support_package_gateway',C/'nissan_phase_gateway_v2.py',GATEWAY);gateway.capture_review(cap)
    def transform(tree):
        tree=gateway.package_transform(tree)
        replace_constant(tree,'SUPPORT-MEMBER-INVENTORY.json','SUPPORT-MEMBER-INVENTORY-v2.json',function='main')
        return tree
    package=load_reference('nissan_support_package_reference',B/'package_v1.py',gateway.PINS['package_v1.py'],transform)
    sys.argv=[str(P(__file__).resolve()),'support'];package.main()
if __name__=='__main__':main()
