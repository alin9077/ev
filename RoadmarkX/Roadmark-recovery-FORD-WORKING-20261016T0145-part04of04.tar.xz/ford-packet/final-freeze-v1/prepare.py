"""Seal the metadata-only Ford32 retention cut after exact documentary/source readback."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,stat,sys
B=Path('/tmp/ford-packet/final-freeze-v1');W=Path('/workspace/scratch/586427eef9f2');REV=Path('/tmp/ford-review')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def meta(p,category):
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink(),str(p)
 return dict(path=str(p),category=category,bytes=s.st_size,mode=s.st_mode,mtimeNs=s.st_mtime_ns,kind='file')
assert len(sys.argv)==3,'prepare.py DOCS_LIVE_REVIEW SHA256'
readback=Path(sys.argv[1]);assert pin(readback)['sha256']==sys.argv[2]
rb=read(readback);assert rb['status']=='accepted'
docsPath=Path('/tmp/ford-packet/docs-status-v2/manifest.json');docs=read(docsPath)
assert rb['manifest']==pin(docsPath),'Readback must bind exact documentary manifest'
assert read(docsPath.parent/'application/result.json')['passed'] is True
sourcePath=Path('/tmp/ford-packet/source-retention-v1/manifest.json');source=read(sourcePath)
sourceReview=REV/'source-retention-v1-review/review.json';assert pin(sourceReview)['sha256']=='5c97ecf748df9cabca81a58adb73f47446017bff60df5288e9444900f264cd13'
sr=read(sourceReview);assert sr['status']=='accepted' and sr['manifest']==pin(sourcePath)
assert source['allowlistedResearchFiles']==78 and source['priorDeclaredPins']==70 and source['firstExplicitHistoricalPins']==8
assert not source['payloadHashSweepPerformed'] and not source['privacyScanClaim']
sourcePins={p['path']:p for p in source['sourcePins']}
final=REV/'final-retention-v1-accepted.json';assert not final.exists() and not (B/'inventory.json').exists()
roots=[('/tmp/ford-research','sanitized_public_source_and_preparation_history'),('/tmp/ford-packet','packet_qa_and_all_attempt_history'),('/tmp/ford-review','independent_reviews')]
rows=[];excluded=[];seen=set()
for root,category in roots:
 for current,dirs,files in os.walk(root,followlinks=False):
  dirs.sort();files.sort()
  if Path(current)==B:dirs[:]=[];continue
  assert not any((Path(current)/n).is_symlink() for n in dirs)
  for name in files:
   p=Path(current)/name;reason=None
   if str(p)=='/tmp/ford-packet/post-registration-checks-v1/.exclusive-heavy.lock':
    assert p.lstat().st_size==0;reason='Empty terminal exclusive-slot lock; not reconstruction data'
   elif p.suffix=='.pyc' or '__pycache__' in p.parts:reason='Reconstructible Python bytecode; original source retained'
   if reason:excluded.append(dict(**meta(p,'excluded_reconstructible'),reason=reason,deletionAuthorized=False));continue
   row=meta(p,category)
   if p.is_relative_to('/tmp/ford-research'):
    assert str(p) in sourcePins,('Research outside exact allowance',str(p));declared=sourcePins[str(p)]
    assert all(row[k]==declared[k] for k in ['bytes','mode','mtimeNs'])
    row.update(declaredSha256=declared['sha256'],contentHashRecomputedAtFreeze=False);seen.add(str(p))
   rows.append(row)
assert seen==set(sourcePins)
for image in source['independentReviewImages']:
 row=meta(image['file']['path'],'independent_reviews')
 assert row['bytes']==image['file']['bytes'] and all(row[k]==image[k] for k in ['mode','mtimeNs'])
registrationPath=Path('/tmp/ford-packet/registration-v1/manifest.json');registration=read(registrationPath);live=[]
for row in registration['writes']+docs['writes']:
 current=pin(row['target']);assert current['bytes']==row['after']['bytes'] and current['sha256']==row['after']['sha256'];live.append(current);rows.append(meta(row['target'],'live_registered_documentary_target'))
assert len(live)==8 and len({x['path'] for x in rows})==len(rows)
rows.sort(key=lambda x:x['path'])
# A second lstat-only pass proves that the cut did not move during metadata collection.
for row in rows:assert meta(row['path'],row['category'])=={k:row[k] for k in ['path','category','bytes','mode','mtimeNs','kind']}
state=read(W/'roadmark-104-qa/work-status.json');assert state['currentBrand']=='Ford'
assert not state['fordWorking']['fullProjectTypecheckPassed'] and not state['fordWorking']['releaseReady'] and not state['fordResearchStatus']['researchCompleted']
assert state['fordWorking']['coverage']['catalogue']==433
report=read('/tmp/ford-packet/report-comparison-plan-v2/results-manifest-v1.json');reportReview=REV/'report-comparison-v2-results-v1/review.json';rr=read(reportReview)
assert rr['status']=='accepted' and rr['normalReportRuns']==1 and rr['comparatorRuns']==1 and rr['snapshotAsOf']=='2026-10-15'
assert rr['resultManifest']==pin('/tmp/ford-packet/report-comparison-plan-v2/results-manifest-v1.json')
assert read('/tmp/ford-packet/report-comparison-plan-v2/terminal-slot-release-v1.json')['heavySlotReleased']
failurePath=Path('/tmp/kgm-packet/report-comparison-v2/typescript-failure-provenance.json');failure=read(failurePath)
previousCut=Path('/tmp/nissan-packet/final-freeze-v1/inventory.json');previousReview=Path('/tmp/nissan-review/final-retention-v1-accepted.json');pr=read(previousReview)
assert pr['status']=='accepted' and pr['inventory']==pin(previousCut)
failures=[x['path'] for x in rows if any(t in Path(x['path']).name.lower() for t in ['failure','diagnostic'])]
result=dict(schemaVersion=1,status='author_frozen_metadata_exact_allowlist_pending_independent_final_acceptance_and_backup_capture',frozenAt=datetime.now(timezone.utc).isoformat(),researchReportAsOf='2026-10-15',validationCompletedOn='2026-10-16',noFurtherPayloadEdits=True,metadataOnlyInventory=True,contentCaptureOrPrivacyScanPerformed=False,inventoryHashScope='Only eight exact live targets and named receipts/provenance/predecessor-cut metadata are hashed. Other payload paths are lstat-only. All78 research hashes are reused from the independently accepted source allowance. Backup owns separately authorized content capture, hashing and privacy scan.',payloadRoots=[r for r,c in roots],files=rows,totalFiles=len(rows),regularFileBytes=sum(x['bytes'] for x in rows),symlinkCount=0,sourceAndStatusAfterPins=live,excluded=excluded+[dict(path=str(B),reason='Inventory and preparer pinned separately with future final review to avoid circularity',deletionAuthorized=False)],sourceAllowlist=pin(sourcePath),sourceAllowlistedResearchFiles=78,sourceRole=source['sourceRole'],rawRuntimeExclusion=source['rawRuntimeExclusion'],publicImageProvenance=dict(publicPdfDocuments=0,retainedPublicPdfFiles=0,existingPublicPdfPageRenders=[],independentDealerArtwork=source['independentReviewImages'],independentProvenanceNote=sr['independentImageProvenance'],retentionLinkCheckDate='2026-10-16',researchSnapshotDate='2026-10-15',freshRemoteImageByteMatch=False,newRenderAtFreeze=False,productBrowserOrPhoneScreenshots=0),privacyBoundary='Exact source-path allowance and implementation/provenance are not a content privacy scan or global absence proof. Raw runtime/configuration/header/cookie/credential/token/client-key payload classes remain excluded; no refetch or reconstruction authorized.',sourceRetentionAcceptance=pin(sourceReview),retainedFailures=dict(compilerProvenance=pin(failurePath),compilerAttempts=failure['attempts'],currentFullProjectTypeScript='UNPASSED',compilerRetryAuthorized=False,reportAttempts=dict(totalFordNormalInvocations=1,normalOutcome='PASSED',savedComparatorInvocations=1,comparatorOutcome='PASSED',automaticRetry=False),failureAndDiagnosticPaths=failures,predecessorRenaultOriginalReportOutcome='UNKNOWN, distinct from its later fresh pass; preserved through accepted predecessor chain',policy='Preserve all source/typed/selected/scoped/report/docs preparations, original attempts and failed/held/unknown histories. A later pass never replaces an earlier failure.'),otherAttemptHistory=dict(sourceAndTyped='Initial missing-requests preparer and unsuccessful direct public fetch receipts retained. Indexed old maker table and accepted retained warranty anchors keep their genuine provenance. Old Lightning exclusion is superseded by unresolved v2. All candidate versions and review refinements retained.',selectedAndStage='One accepted selected actual-consumer run and one accepted full stage; preparation/checker corrections are retained separately and are not runtime retries.',scoped='Five gates complete serially. Environment-provider outage occurred before any last-two process; same-VM recovery and exact unstarted/pin checks precede the one safety-to-structural chain. Static absent-path checker correction retained.',report='Exactly one actual ordinary report and one saved-output comparator passed; comparison preparation v1/v2 preserves exact acceptance-binding correction before runtime.',docs='Docs v1 retained untouched; v2 adds only a buyer warranty bullet, with other payload bytes exact. Applied once under exact root grant.',runtimeAutomaticRetries=False),currentValidation=dict(catalogue=433,tier1=356,onSale=314,packetCount=32,retainedRefreshes=3,additions=3,visibleFord=6,onSaleFord=5,unconfirmedResidualGt=1,unchangedPeers=427,reviewedCore=102,filledCore=95,confirmed=81,check=1,reported=13,notPublished=7,scopedTests=151,structuralPassed=True,normalReportAndExhaustiveComparisonPassed=True,fullProjectTypecheckPassed=False,releaseReady=False,researchCompleted=False,fordCriteria=state['fordWorking']['fordCoverage']['criteria'],currentCleanFullSuite=False,productionBuildVerified=False,phoneMobileVerified=False,publicationAuthorized=False),openFactualLimits=dict(currentMakerVersions=3,residualCurrentListMembershipGaps=2,residualGt='Visible, Not confirmed, not on sale; price Not published',currentGtGuideAlternative='A$98,405 Carsales versus A$98,490 CarExpert remains unresolved and Reported/unranked',q3gn='Exact MY suffix/technical epoch unresolved',lightning='Official-importer eligibility/current new supply unresolved; factory support/legal approval/current availability separated',towing='All six Not published',cargoMirror='Published figures retain confidence; unknown method/mirror inclusion excluded from comparable ranking groups',recalls='Exact VIN applicability and remedy completion unverified; no all-grade/fixed claim'),independentDocsReadback=pin(readback),factualReportAcceptance=pin(reportReview),scopedAcceptance=pin(REV/'post-registration-v1-results-v1/review.json'),registrationManifest=pin(registrationPath),docsManifest=pin(docsPath),currentPacket=pin('/tmp/ford-packet/candidate-v4/ford-2026-10-15.json'),currentReconciliation=pin('/tmp/ford-packet/reconciliation-v1/m1-ford-market-reconciliation-2026-10-15.json'),retainedStorageReadClosure=read('/tmp/ford-packet/full-stage-v1/manifest.json')['storageClosure'],externalDependencies='Reuse accepted retained prefix20/EQA21/Leap22/Mazda23/Skoda24/Audi25/Deepal26/MINI27/KGM28/CUPRA29/Renault30/Nissan31 chain. Ford binds exact all14 research-field and complete-car digests, all21 storage leaves and accepted replacement/proof paths. Both KGM compiler failures and Renault unknown original report remain prior-chain history; no broad earlier-source recapture or immutable-history rebuild.',previousFactualRetentionCut=pin(previousCut),previousFactualRetentionAcceptance=pin(previousReview),predecessorDeliveryQualification='The accepted Nissan31 metadata/factual cut is not itself a native delivery receipt. Predecessor archive/local replay/native create/remote byte-readback status must come from the backup owner\'s separately reviewed delivery receipts; no new native verification or Ford capture/delivery is claimed here.',reconstructionNotes='Retain original logical absolute paths through recovery mapping. No node_modules, generated Next caches, browser preview or canonical catalogue recapture. Preserve exact source and optional-property witnesses; do not regenerate substitute evidence.',finalReviewerReceiptPolicy=dict(path=str(final),state='future_separate_acceptance_after_inventory_review',includedInPayload=False,separateReviewDirectory='/tmp/ford-final-retention-review-v1',reason='Avoid recursive inventory pins; existing review root frozen apart from this future acceptance receipt; retain the separate review bundle explicitly after acceptance'),preparer=pin(__file__))
with (B/'inventory.json').open('x') as f:json.dump(result,f,indent=2,ensure_ascii=False);f.write('\n')
print(json.dumps(dict(inventory=pin(B/'inventory.json'),files=result['totalFiles'],bytes=result['regularFileBytes'],liveTargets=8,failureDiagnosticPaths=len(failures)),indent=2))
