import json,hashlib,ast,difflib,datetime
from pathlib import Path
D=Path('/tmp/ford-packet/registration-v1');O=Path('/tmp/ford-review/registration-v1-review');m=json.loads((D/'manifest.json').read_text());checks=[]
def ck(n,v):
 checks.append({'check':n,'passed':bool(v)})
 if not v:raise AssertionError(n)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
ck('manifest hash',sha(D/'manifest.json')=='6a7c6bfca208eb5940eba4cb6adfd52a2b55a97ca0802ef1f495c706feee58eb')
for label,ps in [('proofs',m['proofs']),('helpers',m['unchangedHelperPins']),('preparation',m['preparation']),('direct',[m['patch'],m['applicator']])]:
 for p in ps:ck(label+' bytes '+p['path'],Path(p['path']).stat().st_size==p['bytes']);ck(label+' hash '+p['path'],sha(p['path'])==p['sha256'])
ck('431proofs',len(m['proofs'])==431)
ck('four exact targets',[x['relativePath'] for x in m['writes']]==['data/m1-brand-updates/registry.json','scripts/reporting/load.ts','data/m1-brand-updates/ford-2026-10-15.json','data/m1-ford-market-reconciliation-2026-10-15.json'])
patch=''
for r in m['writes']:
 p=Path(r['target']);ck('target path '+r['relativePath'],p==Path(m['repo'])/r['relativePath']);ck('after hash '+r['relativePath'],sha(r['after']['path'])==r['after']['sha256'] and Path(r['after']['path']).stat().st_size==r['after']['bytes'])
 if r['before']:
  ck('exact live before '+r['relativePath'],p.is_file() and sha(p)==r['before']['sha256'] and p.stat().st_size==r['before']['bytes']);ck('before copy '+r['relativePath'],Path(r['beforeCopy']['path']).read_bytes()==p.read_bytes());b=p.read_bytes()
 else:ck('new path absent '+r['relativePath'],not p.exists());b=b''
 a=Path(r['after']['path']).read_bytes();patch+=''.join(difflib.unified_diff(b.decode().splitlines(True),a.decode().splitlines(True),fromfile='a/'+r['relativePath'] if r['before'] else '/dev/null',tofile='b/'+r['relativePath']))
ck('independent exact patch reconstruction',patch==(D/'registration.patch').read_text())
old=json.loads((D/'before/data/m1-brand-updates/registry.json').read_text());new=json.loads((D/'after/data/m1-brand-updates/registry.json').read_text());ck('exact registry append',new=={**old,'packets':old['packets']+['ford-2026-10-15.json']} and len(new['packets'])==32)
b=(D/'before/scripts/reporting/load.ts').read_text();a=(D/'after/scripts/reporting/load.ts').read_text();imp='import fordReconciliation from "../../data/m1-ford-market-reconciliation-2026-10-15.json";\n';arg='      fordReconciliation as M1MarketReconciliation,\n';ck('only loader import and argument',a.count(imp)==a.count(arg)==1 and a.replace(imp,'').replace(arg,'')==b)
ck('packet byte exact',sha(D/'after/data/m1-brand-updates/ford-2026-10-15.json')=='8d728412f21a36aac152357d04793fd38b5efc47438e5210af610f72e868ce00')
ck('reconciliation successor byte exact',sha(D/'after/data/m1-ford-market-reconciliation-2026-10-15.json')=='07531bcbe9d57c9b89647313ced205a60a899dc2aa6c4655db161fec1debdf39')
app=(D/'apply.py').read_text();ast.parse(app);ck('exact accepted applicator pattern',app==Path('/tmp/nissan-packet/registration-v1/apply.py').read_text().replace('apply_exact_nissan_registration','apply_exact_ford_registration'))
ck('execution not performed',not (D/'application').exists())
ck('permissions held',m['rootGrantRequired'] and m['backupFreezeReleaseRequired'] and not m['heavyChecksAllowed'] and not m['automaticRetry'])
res={'status':'PASS_STATIC_FOUR_FILE_BUNDLE','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passedChecks':len(checks),'failedChecks':0,'method':'Read-only byte/hash/diff/AST inspection only; applicator not invoked; no live edit or application runtime','checks':checks};(O/'checks.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({k:v for k,v in res.items() if k!='checks'}))
