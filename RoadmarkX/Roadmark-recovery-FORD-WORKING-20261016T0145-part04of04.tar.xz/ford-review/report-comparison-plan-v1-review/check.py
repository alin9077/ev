import json,hashlib,ast,difflib,datetime
from pathlib import Path
D=Path('/tmp/ford-packet/report-comparison-plan-v1');O=Path('/tmp/ford-review/report-comparison-plan-v1-review');m=json.loads((D/'preparation-manifest-v1.json').read_text());checks=[]
def ck(n,v):
 checks.append({'check':n,'passed':bool(v)})
 if not v:raise AssertionError(n)
def read(p):return json.loads(Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def pin(p):ck('bytes '+p['path'],Path(p['path']).stat().st_size==p['bytes']);ck('hash '+p['path'],sha(p['path'])==p['sha256'])
ck('manifest',sha(D/'preparation-manifest-v1.json')=='7650581628020fb25410994aef945b626bfb70e33764f09b9b6cebe2926e8593')
for p in m['files']:pin(p)
c=read(D/'preparation-input-closure.json');files={p['path']:p for p in c['files']};ck('808 current real files',len(files)==len(c['files'])==808)
for p in c['files']:pin(p)
for e in c['edges']:ck('edge pinned '+e['importer']+e['specifier'],files.get(e['resolved']['path'])==e['resolved'])
for p in c['retainedStorageFiles']:ck('storage pinned '+p['path'],files.get(p['path'])==p)
for p in [m[k] for k in ['acceptedComparator','acceptedNissanReportReview','acceptedNissanNormalReport','fordDefinitiveStageReceipt','fordStageOutputManifest','fordSelectedOutputReview']]:pin(p)
for p in D.glob('*.py'):ast.parse(p.read_text());ck('Python AST '+p.name,True)
ck('wrapper exact accepted',(D/'run.py').read_bytes()==Path('/tmp/nissan-packet/post-registration-checks-v1/run.py').read_bytes())
s=(D/'compare-report.mjs').read_text();prior=Path('/tmp/ford-packet/selected-readiness-v1/check.mjs').read_text();start='function observePack(';end='\nfor(const car of before)'
actual=s[s.index(start):s.index(end,s.index(start))].strip();ref=prior[prior.index(start):prior.index('function observeClaim(',prior.index(start))].strip();ck('producer witness exact selected',actual==ref)
syntax=read(D/'syntax-only-receipt.json');ck('syntax binds body unexecuted',syntax['scriptSha256']==sha(D/'compare-report.mjs') and syntax['exitCode']==0 and not syntax['runtimeExecuted'] and not syntax['importsExecuted'])
b=read(m['acceptedNissanNormalReport']['path']);sel=read('/tmp/ford-packet/selected-readiness-v1/result.json')['selectedCoverage'];e=read(D/'expected-deltas.json');bf=next(x for x in b['brandProgress'] if x['brand']=='Ford')
ck('planned totals',e['countsBefore']==[430,353,312] and e['countsAfter']==[433,356,314])
for i,row in enumerate(e['core']):
 old=b['core'][i];before=bf['core'][i];after=sel['core'][i];ck('core delta '+row['key'],row['filledAfter']==old['filled']-before['filled']+after['filled'] and row['totalAfter']==314 and row['selectedBefore']==before and row['selectedAfter']==after)
 for grade in old['grades']:ck('core grade '+row['key']+grade,row['gradesAfter'][grade]==old['grades'][grade]-before['grades'][grade]+after['grades'][grade])
for i,row in enumerate(e['rankings']):ck('rank delta '+row['key'],row['after']==b['rankings'][i]['ranked']-bf['rankings'][i]['ranked']+sel['rankings'][i]['ranked'] and row['denominatorAfter']==314)
ck('actual denominators code',"assert.equal(onSaleBefore.length,312);assert.equal(onSaleAfter.length,314)" in s and "after.filter(reports.isOnSale)" in s)
ck('complete core producer code',"assert.deepStrictEqual(completeBeforeCore.core,baseline.core)" in s and 'expected.core=completeAfterCore.core;expected.gaps=completeAfterCore.gaps' in s)
ck('exhaustive compare no ignored paths',"assert.deepEqual(normal,expected,'Every report leaf" in s)
ck('only207 old feature rows',"assert.equal(beforeFeatures.length,207)" in s and "assert.equal(unchangedRetainedFeatureRows,204)" in s)
ck('exact C1 stage code',"assert.deepEqual(baseline.reconciliation,c1.before)" in s and 'expected.reconciliation=c1.after' in s)
ck('no outputruntime yet',all(not (D/n).exists() for n in ['artifacts','normal-coverage-asof-2026-10-15','report-comparison','sequence.json']))
res={'status':'PASS_CONTENT_AND_CLOSURE_CHECKS_WITH_FINALIZATION_GUARD_HOLD','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passedChecks':len(checks),'failedChecks':0,'hold':'Deferred finalization must bind exact Ford full-stage acceptance and actual five-gate acceptance sequence/results; generic status-only checks are insufficient. Successor requested before acceptance.','method':'Static source/JSON comparisons, AST and streaming byte hashes; no application imports, report/comparator or compiler execution','checks':checks};(O/'checks.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({k:v for k,v in res.items() if k!='checks'}))
