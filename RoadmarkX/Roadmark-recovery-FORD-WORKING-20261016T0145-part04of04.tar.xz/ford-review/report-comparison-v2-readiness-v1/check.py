from pathlib import Path
import json,hashlib,datetime
D=Path('/tmp/ford-packet/report-comparison-plan-v2');P=Path('/tmp/ford-packet/post-registration-checks-v1');O=Path('/tmp/ford-review/report-comparison-v2-readiness-v1');checks=[]
def ck(n,v):
 checks.append(dict(check=n,passed=bool(v)))
 if not v:raise AssertionError(n)
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def check(p):ck('pin '+p['path'],pin(p['path'])==p)
def meta(p):
 p=Path(p)
 if not p.exists():return dict(path=str(p),exists=False)
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
def write(n,v):
 with (O/n).open('x')as f:json.dump(v,f,indent=2);f.write('\n')
s=read(D/'sequence.json');ck('exact sequence',pin(D/'sequence.json')['sha256']=='3cc2c2fe6966cd9540014dbe4d0c6c3be6ae2401a9346935b78da72f34c18805')
ck('exact two commands',[p['sha256']for p in s['sequence']]==['3c7903685b20b506179297939a71b03f2bfa5d28ca6bc9994cbc3e238cf8f5a1','325bfa7cf94598e692aa428fd2b2f173ab9e8c9962bf291b1aaf27a6821ec44f'])
prep=read(D/'preparation-manifest-v2.json');ck('same accepted prep',pin(D/'preparation-manifest-v2.json')['sha256']=='d6f80809e6827680e3d753817c98fc19bb1d821a0aead60599df934a79e56ac8')
for p in prep['files']:check(p)
normal,compare=[read(p['path'])for p in s['sequence']];base=read(P/'structural-validation.json');pins=read(D/'source-pins.json');files={p['path']:p for p in pins};extra={p['path']:p for p in normal['extraPins']};ck('823 unique source pins',len(files)==len(pins)==823);ck('199 unique proof pins',len(extra)==len(normal['extraPins'])==199 and normal['extraPins']==compare['extraPins'])
for p in pins+normal['extraPins']+s['sequence']:check(p)
closure=read(D/'comparator-input-closure.json');before=read(D/'preparation-input-closure.json');old={p['path']:p for p in before['files']};trans=read(D/'source-transition-provenance.json');writes=read('/tmp/ford-packet/registration-v1/manifest.json')['writes'];wm={w['target']:w for w in writes}
ck('closure actual final',closure['files']==pins and closure['phase']=='final' and closure['finalLiveAfterFreeze']is True and not closure['runtimeExecuted'] and closure['pending']==[])
ck('all prepared inputs retained',set(old)<=set(files))
ck('only historical changes',{p for p in old if old[p]!=files[p]}=={w['target']for w in writes if w['before']is not None})
for p in old:
 if p in wm:
  w=wm[p];ck('transition exact '+p,old[p]==dict(path=p,**w['before']) and files[p]==dict(path=p,bytes=w['after']['bytes'],sha256=w['after']['sha256']));check(w['beforeCopy'])
 else:ck('unchanged original '+p,old[p]==files[p])
ck('fifteen added source pins',len(set(files)-set(old))==15)
ck('32 registry packets',closure['registeredPackets']==before['registeredPackets']+['ford-2026-10-15.json'])
ck('137 price source pointers unchanged',len(closure['priceSourcePointerBindings'])==137 and closure['priceSourcePointerBindings']==before['priceSourcePointerBindings'] and closure['priceSourcePointerFilenames']==before['priceSourcePointerFilenames'])
ck('21 retained storage exact',len(closure['retainedStorageFiles'])==21 and closure['retainedStorageFiles']==before['retainedStorageFiles'])
for p in closure['retainedStorageFiles']:ck('storage content pinned '+p['path'],files[p['path']]==p)
ck('227 actual read edges',len(closure['edges'])==227)
for e in closure['edges']:ck('edge content pinned '+e['importer']+e['specifier'],files[e['resolved']['path']]==e['resolved'])
for p in read(P/'source-pins.json'):ck('all actual five-gate input pinned '+p['path'],files[p['path']]==p)
ck('two explicit historical transitions',len(trans['onlyHistoricalLiveInputTransitions'])==2 and trans['allOtherStagePinsUnchanged']is True)
for t in trans['onlyHistoricalLiveInputTransitions']:check(t['retainedBefore']);check(t['current']);ck('historical retained '+t['historical']['path'],old[t['historical']['path']]==t['historical'])
ck('two new targets exact',trans['newTargets']==s['registrationTargets'][2:])
for name,expect in [('full-stage-v1-result-review/review.json','e6e355d2e2023aadc09ae754da4f8a6a3e94e4d1aa01b10b4c2b6a4473d5dd8e'),('post-registration-v1-results-v1/review.json','a970ef230e424f012d8968e121fdb176284e3737bbfe872106d9443b3545990c'),('registration-v1-live-readback-v1/review.json','2e3dc9d8f8efac0ba4f18bb61e86185fa9b4a9823df8484acf113090f56fa468')]:
 p=Path('/tmp/ford-review')/name;ck('exact acceptance '+name,extra[str(p)]['sha256']==expect)
five=read('/tmp/ford-review/post-registration-v1-results-v1/review.json');out=read(five['resultManifest']['path']);ck('five exact reviewed complete outputs',len(out['files'])==53 and all(extra[p['path']]==p for p in out['files']))
for x in [five['resultManifest'],five['sequence'],five['registrationVerification'],five['terminalSlotRelease'],*five['rootGrants']]:ck('five receipt pinned '+x['path'],extra[x['path']]==x)
for i,gate in enumerate(five['gates']):
 ck('five prerequisite exact '+gate['id'],normal['prerequisites'][i]==dict(manifest=gate['manifest'],resultPath=gate['result']['path']))
 for k in ['manifest','result','terminal']:ck('gate proof pinned '+gate['id']+k,extra[gate[k]['path']]==gate[k])
node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node';prefix=[node,'--max-old-space-size=448','--max-semi-space-size=1','--import','tsx']
ck('exact one normal command',normal['command']==prefix+['scripts/report-coverage.ts','--as-of','2026-10-15','--json'] and normal['timeoutSeconds']==900 and normal['asOf']=='2026-10-15' and normal['expectedReportCounts']==[433,356,314])
ck('exact saved comparator',compare['command']==prefix+[str(D/'compare-report.mjs')] and compare['timeoutSeconds']==180 and compare['comparisonResult']==str(D/'artifacts/result.json'))
ck('comparison depends exact one normal',compare['prerequisites']==[dict(manifest=s['sequence'][0],resultPath=str(D/'normal-coverage-asof-2026-10-15/result.json'))])
for m in [normal,compare]:
 for k in ['repo','exclusiveLock','registrationManifest','registrationTargets','originalConfig','runtimeMetadata','environmentRemovals','environmentOverrides','rootMetadata','testInventory']:ck('accepted common '+m['id']+k,m[k]==base[k])
 for k in ['sourcePins','rootMetadata','registrationManifest','registrationTargets','independentCoverageException']:ck('sequence binding '+m['id']+k,m[k]==s[k])
 for p in [m['wrapper'],m['sourcePins'],m['rootMetadata'],m['testInventory'],m['registrationManifest'],m['independentCoverageException'],*m['registrationTargets']]:check(p)
 ck('supervisor exact '+m['id'],m['wrapper']['sha256']=='0669805bd8b514e510179aea3f93adb5b231b5e02e08ec6b5cde26b290f62828')
 ck('one exclusive bounded invocation '+m['id'],m['killAfterSeconds']==10 and not m['automaticRetry'] and not m['parallelExecutionAllowed'] and not m['sourceMutationsAuthorized'] and m['qaRoot']==str(D) and m['runOutput']==str(D/m['id']))
root=read(normal['rootMetadata']['path'])
for p in root['fileMetadata']+root['directoryState']+normal['runtimeMetadata']+root['postRegistrationTargets']:ck('actual metadata '+p['path'],meta(p['path'])==p)
R=Path(normal['repo']);ck('config and roots exact',read(R/'tsconfig.json')==normal['originalConfig'] and sorted({str(p.resolve())for pat in normal['originalConfig']['include']for p in R.glob(pat)if p.is_file()})==root['configuredRootFilePaths'])
ctx=read(s['independentCoverageException']['path']);ck('TS unpassed anchored',ctx['currentFiveGateAcceptance']==pin('/tmp/ford-review/post-registration-v1-results-v1/review.json') and len(ctx['attempts'])==2 and not ctx['compilerRetriesAuthorized'] and not ctx['releaseAcceptanceClaim'])
for a in ctx['attempts']:ck('both unknown SIGKILL retained '+str(a['version']),a['exitCode']==-9 and a['cause']=='unknown' and a['fullProjectTypecheckPassed']is False and not Path(a['freshCachePath']).exists())
ck('unpassed and no retry scope',s['normalReportRuns']==1 and not s['normalReportSubstitutionAllowed'] and not s['fullProjectTypecheckPassed'] and not s['releaseAcceptanceClaim'] and not s['compilerRetryIncluded'] and not s['extraBroadFeatureReplay'] and not s['executionAuthorized'] and s['noAutomaticRetry'])
g=read(D/'root-grant-template.json');ck('still ungranted',g['status']=='NOT_GRANTED' and g['heavySlotExclusive']is False and g['granted']==s['sequence'] and g['sequence']==pin(D/'sequence.json') and g['reviewerAcceptance']is None)
ck('no output runtime exists',all(not(D/n).exists()for n in ['normal-coverage-asof-2026-10-15','report-comparison','artifacts']))
write('checks.json',dict(status='PASS_FINAL_REPORT_COMPARATOR_READINESS',passedChecks=len(checks),failedChecks=0,checks=checks))
r=dict(status='accepted',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),sequence=pin(D/'sequence.json'),wrapper=normal['wrapper'],sourcePins=s['sourcePins'],inputClosure=pin(D/'comparator-input-closure.json'),rootMetadata=s['rootMetadata'],registrationVerification=five['registrationVerification'],fiveGateAcceptance=pin('/tmp/ford-review/post-registration-v1-results-v1/review.json'),fullStageAcceptance=pin('/tmp/ford-review/full-stage-v1-result-review/review.json'),preparationReview=pin('/tmp/ford-review/report-comparison-plan-v2-review/review.json'),reviewedCommands=[dict(id=m['id'],manifest=p,command=m['command'],timeoutSeconds=m['timeoutSeconds'],killGraceSeconds=10,watchdogMarginSeconds=20)for p,m in zip(s['sequence'],[normal,compare])],sourcePinCount=823,extraProofPins=199,actualReadEdges=227,staticChecks=len(checks),allCurrentPinsExact=True,allPrior808InputsRetainedExceptTwoAcceptedLiveTransitions=True,addedInputFiles=15,retainedStorageFiles=21,registeredPackets=32,pricePointerBindings=137,all53FiveGateOutputsBound=True,allStageAndSelectedOutputsBound=True,wrapperExactAcceptedNissan=True,sourceTransition=pin(D/'source-transition-provenance.json'),snapshotAsOf='2026-10-15',scope='Exactly one actual normal report then one saved-output comparator; complete report leaf parity with all427 peer cars and no peer effective-feature replay. No blanket optional-value normalization.',failureRule='Stop on any failure; preserve a successful normal report and all failed comparator artifacts. No automatic retry or normal-report substitution.',currentProjectTypeScript='UNPASSED; both unknown-cause KGM SIGKILL attempts preserved; no compiler retry',fullProjectTypecheckPassed=False,releaseAcceptanceClaim=False,executionAuthorized=False,noRuntimeExecutedByReviewer=True,limits='Readiness acceptance only. Root must separately grant exact manifests with an exclusive slot. Report results, C1-C6, milestone, release and publication remain unclaimed.')
write('review.json',r);write('manifest.json',dict(status='accepted',files=[pin(O/n)for n in ['check.py','checks.json','review.json']]))
print(json.dumps(dict(review=pin(O/'review.json'),manifest=pin(O/'manifest.json'),checks=len(checks)),indent=2))
