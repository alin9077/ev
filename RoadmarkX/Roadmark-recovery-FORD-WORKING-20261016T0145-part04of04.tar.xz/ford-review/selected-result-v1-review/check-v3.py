import json, hashlib, re, copy, datetime
from pathlib import Path
D=Path('/tmp/ford-packet/selected-readiness-v1'); O=Path('/tmp/ford-review/selected-result-v1-review')
checks=[]
def ck(name, ok):
 checks.append({'check':name,'passed':bool(ok)})
 if not ok: raise AssertionError(name)
def read(p):return json.loads(Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def pointer(root,p):
 for key in p.strip('/').split('/'):
  key=key.replace('~1','/').replace('~0','~')
  root=root[int(key)] if isinstance(root,list) else root[key]
 return root
r=read(D/'result.json'); packet=read('/tmp/ford-packet/candidate-v4/ford-2026-10-15.json'); before={c['id']:c for c in read('/tmp/ford-research/retained-before-cars-v1.json')}; after={c['id']:c for c in read(D/'selected-after-cars.json')}; packs=read(D/'selected-packs.json'); portable=read(D/'portable.json'); expected=read(D/'expected-review.json'); manifest=read(D/'output-manifest.json')
for group,rows in [('output',manifest['files']),('input',read(D/'source-pins.json'))]:
 for row in rows:
  ck(group+' bytes '+row['path'],Path(row['path']).stat().st_size==row['bytes']);ck(group+' sha '+row['path'],sha(row['path'])==row['sha256'])
ck('frozen output manifest',sha(D/'output-manifest.json')=='694f03460b9684ecd911ce8d23b3f76027e028a0b7495cd48dd7c5b7644c4639')
term=read(D/'run/terminal.json');inv=read(D/'run/invocation.json');cmd=read(D/'prepared-command.json');post=read(D/'run/after-pins.json')
ck('terminal success',term['exitCode']==0 and term['rawWaitStatus']==0 and term['elapsedSeconds']<180 and not term['automaticRetry'])
for stream in ['stdout','stderr']: ck(stream+' terminal binding',sha(D/f'run/{stream}.log')==term[stream+'Sha256'])
ck('stderr empty',(D/'run/stderr.log').stat().st_size==0)
stdout=read(D/'run/stdout.log');ck('stdout result binding',stdout['sha256']==sha(D/'result.json') and stdout['status']==r['status'])
ck('invocation manifest',inv['manifestSha256']==sha(D/'prepared-command.json')=='e4d21d7457a76dccc6d4c0b3d343cabefd5bfb83b5686e7e2bc802ef5f9b29bb')
ck('invocation wrapper',inv['wrapperSha256']==sha(D/'run.py'))
ck('grant binding',inv['grantSha256']==sha(D/'root-execution-grant.json'))
ck('post pins',post['passed'] and post['count']==257 and post['manifestSha256']==inv['manifestSha256'])
ck('six exact IDs',set(after)==set(packs)==set(portable)==set(expected['existingIds']+expected['addedIds']))
for e in packet['facts']:
 ck('fact after '+e['variantId']+'/'+e['after']['key'],after[e['variantId']]['facts'][e['after']['key']]==e['after'])
 ck('fact before '+e['variantId']+'/'+e['after']['key'],before.get(e['variantId'],{}).get('facts',{}).get(e['after']['key'])==e['before'])
for t in packet['brandTerms']:
 for id in t['applicableVariantIds']:
  ck('shared after '+id+'/'+t['key'],after[id]['facts'][t['key']]==t['fact']);ck('shared before '+id+'/'+t['key'],before.get(id,{}).get('facts',{}).get(t['key'])==t['before'][id])
for id,b in before.items():
 edited={e['after']['key'] for e in packet['facts'] if e['variantId']==id}|{t['key'] for t in packet['brandTerms'] if id in t['applicableVariantIds']}
 ck('full fact keyset '+id,set(after[id]['facts'])==set(b['facts'])|edited)
 for k in set(b['facts'])-edited:ck('untouched '+id+'/'+k,after[id]['facts'][k]==b['facts'][k])
for e in packet['configurationUpdates']:
 ck('configuration before '+e['variantId'],before[e['variantId']]['configurationEvidence']==e['before']);ck('configuration after '+e['variantId'],after[e['variantId']]['configurationEvidence']==e['after'])
 ck('complete hold '+e['variantId'],after[e['variantId']]['configurationEvidence']['completeVehicleCountEligible'] is False)
for e in packet['availability']:
 a=after[e['variantId']];ck('availability '+e['variantId'],{'availability':a['availability'],'evidence':a['availabilityEvidence']}==e['after'])
for e in packet['summaries']:
 a=after[e['variantId']]
 for side in ['strength','tradeoff']:
  for k in ['label','text']:ck('summary '+e['variantId']+'/'+side+'/'+k,a['buyerSummary'][side][k]==e[side][k])
  for dep in e[side]['dependencies']:ck('summary dependency '+e['variantId']+'/'+side+'/'+dep['key'],a['facts'][dep['key']]==dep['expected'])
 ck('summary conditions '+e['variantId'],a['buyerSummary']['conditions']==e['conditions']==a['configurationEvidence']['requiredBuyerVisibleConditions'])
sources={}
for id,p in packs.items():
 ck('pack car '+id,p['car']==after[id]);ck('feature count '+id,len(p['features'])==69 and len({f['criterion'] for f in p['features']})==69)
 for s in p['sources']:
  ck('source object consistency '+s['id'],s['id'] not in sources or sources[s['id']]==s);sources[s['id']]=s
 q=copy.deepcopy(p);q['sourceIds']=[s['id'] for s in q.pop('sources')]
 for f in q['features']:
  if f.get('variant_id')==id:f.pop('variant_id')
  if f.get('model_id')==p['car']['modelId']:f.pop('model_id')
 ck('independent written portable exact '+id,q==portable[id])
 for f in p['features']:ck('feature identity '+id+'/'+f['criterion'],f['variant_id']==id and f['model_id']==p['car']['modelId'])
for s in packet['sources']:
 if s['id'] in sources:ck('projected packet source retained '+s['id'],sources[s['id']]==s)
claims=read(D/'claims.json');features=read(D/'feature-claims.json');availability=read(D/'availability-claims.json')
ck('139 unique earned claims',len(claims)==len({(x['variantId'],x['key']) for x in claims})==139)
for row in claims:
 f=after[row['variantId']]['facts'][row['key']];c=row['claim'];ck('claim grade '+row['variantId']+'/'+row['key'],c['buyerGrade']==f['buyerGrade']);ck('claim source IDs '+row['variantId']+'/'+row['key'],[s['id'] for s in c['sources']]==f['sourceIds'])
 if f['value'] is None:ck('null claim display '+row['variantId']+'/'+row['key'],c['value']=='Not published')
ck('414 unique feature claims',len(features)==len({(x['variantId'],x['criterion']) for x in features})==414)
for row in features:
 f=next(x for x in packs[row['variantId']]['features'] if x['criterion']==row['criterion']);ck('feature claim source IDs '+row['variantId']+'/'+row['criterion'],[s['id'] for s in row['claim']['sources']]==list(dict.fromkeys(f['source_ids'])))
ck('6 availability claims',len(availability)==6)
for row in availability:ck('availability claim sources '+row['variantId'],[s['id'] for s in row['claim']['sources']]==after[row['variantId']]['availabilityEvidence']['sourceIds'])
# Independently enumerate every omitted falsey citation metadata branch from the actual written outputs.
omissions=[]
for group,rows in [('claims',claims),('feature-claims',features),('availability-claims',availability)]:
 for i,row in enumerate(rows):
  for j,s in enumerate(row['claim']['sources']):
   for key,sourcekey in [('limitation','access_limitation'),('checked','full_text_checked_date')]:
    if not sources[s['id']].get(sourcekey):
     ck('citation metadata absent '+group+str(i)+str(j)+key,key not in s);omissions.append((f'/{group}/{i}/claim/sources/{j}/{key}',s['id'],key))
actual=read(D/'claim-undefined-witnesses.json');ck('394 exact derived citation omissions',len(actual)==394 and sorted(omissions)==sorted((o['pointer'],o['sourceId'],o['property']) for o in actual))
ck('witness result equality',actual==r['optionalCitationPaths'])
for o in actual:ck('citation witness producer '+o['pointer'],o['ownUndefined'] and o['enumerable'] and 'Actual citable.ts citations()' in o['producer'])
obs=read(D/'undefined-witnesses.json');ck('9 feature witnesses',len(obs)==9 and obs==r['optionalFeaturePaths'])
ck('exact phase ID witness set',{(o['phase'],o['variantId']) for o in obs}=={('before',i) for i in before}|{('after',i) for i in after})
for o in obs:
 ck('feature witness '+o['phase']+o['variantId'],o['criterion']=='novated_fbt' and o['property']=='confirmation_needed' and o['rowIndex']==49 and o['ownUndefined'] and o['enumerable'] and o['actualFinalProjectionMatched'])
 if o['phase']=='after':ck('written feature absent '+o['variantId'],o['property'] not in packs[o['variantId']]['features'][o['rowIndex']] and packs[o['variantId']]['features'][o['rowIndex']]['criterion']==o['criterion'])
ros=read(D/'report-undefined-witnesses.json');ck('6 exact report witnesses',len(ros)==6)
for o in ros:
 parent=pointer({'result':r},o['pointer'].rsplit('/',1)[0]);ck('report omitted branch '+o['pointer'],parent['code']=='independent_lists' and o['property'] not in parent and o['property'] in ['brand','reference'] and o['ownUndefined'] and o['enumerable'])
ck('actual addition proof file',read(D/'addition-builder-proof.json')==r['additionBuilderProof'])
for p in r['additionBuilderProof']:
 e=next(x for x in packet['availability'] if x['variantId']==p['variantId']);ck('actual addition producer '+p['variantId'],p['facts']=={} and p['availabilityBefore']==e['before'] and p['declaredAvailabilityGuardExact'] and p['zeroFactsVerified'] and 'private newVariantCar' in p['actualProducer'])
ck('11 unique negatives',len(r['negativeProof'])==len({n['name'] for n in r['negativeProof']})==11)
for n in r['negativeProof']:ck('negative '+n['name'],n['rejected'] and n['inputsUnchanged'] and re.search(n['expectedErrorPattern'],n['actualError']) is not None)
ck('294 unique comparisons',len(r['comparisonProof'])==len({(c['left'],c['right'],c['key']) for c in r['comparisonProof']})==294)
for c in r['comparisonProof']:
 l=after[c['left']]['facts'][c['key']];right=after[c['right']]['facts'][c['key']];s=c['result']['state']
 ck('comparison basis '+str((c['left'],c['right'],c['key'])),c['leftBasis']==l['comparisonBasis'] and c['rightBasis']==right['comparisonBasis'])
 if s=='comparable':ck('comparison arithmetic '+str((c['left'],c['right'],c['key'])),c['result']['delta']==right['value']-l['value'])
 else:ck('comparison no delta '+str((c['left'],c['right'],c['key'])),'delta' not in c['result'])
 if c['key'] in ['boot_l','width_mm']:ck('unknown method exclusion '+str(c),s=='different_basis')
for c in r['crossBasisProof']:ck('supplement unknown method '+c['variantId']+'/'+c['key'],c['result']['state']=='different_basis' and 'delta' not in c['result'])
for k,v in r['rankCounts'].items():ck('rank identities '+k,set(v['ranked'])==set(expected['rankingIds'][k]) and len(v['ranked'])+len(v['excluded'])==6)
c1=r['currentListProof'];ck('C1 exact reviewed IDs',set(c1['reviewedVersionIds'])==set(before) and c1['reviewedModels']==1 and c1['reviewedVersions']==3 and c1['registryValid'] and not c1['pass'])
ck('C1 exact gaps',sorted((x['code'],x.get('reference')) for x in c1['issues'])==sorted([('independent_lists',None),*[("version_unreviewed",i) for i in expected['residualOnSaleIds']],*[("inventory_unresolved","record:"+i) for i in expected['inventoryIds']]]))
ck('selected counts',r['selectedCoverage']['allCatalogueVersions']==6 and r['selectedCoverage']['tierOneVersions']==6 and r['selectedCoverage']['onSaleVersions']==5)
ck('selected C1 parity',r['selectedCoverage']['reconciliation']==c1)
for p in r['reportProof']:
 text=Path(p['markdownFile']).read_text();id=p['variantId'];ck('report claim text '+id,all(x['claim']['sentence'] in text for x in claims if x['variantId']==id and x['key'] in ['price_aud','range_km','dc_charge_time_min','boot_l','towing_braked_kg','warranty']));ck('report availability '+id,next(x['claim']['sentence'] for x in availability if x['variantId']==id) in text)
ck('bounded successful scope',not r['productionCatalogueHydration'] and r['defaultLoaderCalls']==0 and not r['sourceEdits'] and r['scopeTargetNeutrality']['tierTwoTargets']==0 and r['scopeTargetNeutrality']['nonFordTargets']==0)
ck('project TS unpassed',r['fullProjectTypeScript'].startswith('UNPASSED'))
output={'status':'PASS_STATIC_OUTPUT_REVIEW','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passedChecks':len(checks),'failedChecks':0,'method':'Read and compare emitted JSON, manifest byte hashes and terminal receipts; no application imports, compiler or runtime rerun','checks':checks}
(O/'checks.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps({k:v for k,v in output.items() if k!='checks'}))
