import json,hashlib,ast,re,datetime
from pathlib import Path
D=Path('/tmp/ford-packet/post-registration-plan-v1');O=Path('/tmp/ford-review/post-registration-plan-v1-review');m=json.loads((D/'plan-manifest.json').read_text());checks=[]
def ck(n,v):
 checks.append({'check':n,'passed':bool(v)})
 if not v:raise AssertionError(n)
def read(p):return json.loads(Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def meta(p):
 p=Path(p)
 if not p.exists():return dict(path=str(p),exists=False)
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
def pinck(p,physical=None):
 f=Path(physical or p['path']);ck('bytes '+p['path'],f.stat().st_size==p['bytes']);ck('hash '+p['path'],sha(f)==p['sha256'])
ck('plan manifest',sha(D/'plan-manifest.json')=='bebed06fce121b4b8c4d56f2b417b82e3fd23a831e8962dfd5c999e4dc13b28f')
for p in [*m['files'],m['registrationManifest'],m['fullStageReview'],m['referenceReadiness'],m['referenceResults']]:pinck(p)
for p in D.glob('*.py'):ast.parse(p.read_text());ck('Python AST only '+p.name,True)
ck('supervisor exact accepted bytes',(D/'run.reference.py').read_bytes()==Path('/tmp/nissan-packet/post-registration-checks-v1/run.py').read_bytes())
writes=read('/tmp/ford-packet/registration-v1/prepared-writes.json');mapping={w['target']:w['after']['path'] for w in writes};c=read(D/'prepared-closure/static-input-closure.json');files={p['path']:p for p in c['files']}
ck('172files498edges',len(files)==172 and len(c['edges'])==498)
for p in c['files']:pinck(p,mapping.get(p['path']))
for e in c['edges']:ck('edge closed '+e['importer']+e['specifier'],e['resolved']==files[e['resolved']['path']])
for w in writes:
 p=Path(w['target'])
 ck('transition frozen '+w['target'],files[w['target']]['sha256']==w['after']['sha256'])
 if w['before']:ck('unchanged live before '+w['target'],sha(p)==w['before']['sha256'])
 else:ck('new live target absent '+w['target'],not p.exists())
old=read('/tmp/nissan-packet/post-registration-checks-v1/static-input-closure.json');ck('registry32logical',c['registeredPackets']==old['registeredPackets']+['ford-2026-10-15.json'])
ck('137 exact pointer bindings',len(c['priceSourcePointerBindings'])==137 and c['priceSourcePointerBindings']==old['priceSourcePointerBindings'])
ck('seven pointer filenames',len(c['priceSourcePointerFilenames'])==7 and c['priceSourcePointerFilenames']==old['priceSourcePointerFilenames'])
ck('old closure only four changes',{p['path'] for p in old['files'] if p!=files[p['path']]}=={w['target'] for w in writes if w['before']})
for p in read('/tmp/nissan-packet/post-registration-checks-v1/source-pins.json'):pinck(p)
roots=read('/tmp/nissan-packet/post-registration-checks-v1/project-root-metadata.json');ts=read('/tmp/kgm-packet/full-project-typescript-v1/manifest.json')
for p in roots['fileMetadata']+roots['directoryState']+ts['runtimeMetadata']:ck('metadata '+p['path'],meta(p['path'])==p)
R=Path('/workspace/scratch/586427eef9f2/roadmark-104');config=read(R/'tsconfig.json');ck('configured roots actual',sorted({str(p.resolve()) for pat in config['include'] for p in R.glob(pat) if p.is_file()})==roots['configuredRootFilePaths'] and config==ts['originalConfig'])
inv=read(D/'test-inventory.reference.json');names=[]
for rel,x in inv.items():
 pinck(x['source']);text=Path(x['source']['path']).read_text();actual=re.findall(r'\btest\(\s*"([^"\n]+)"',text);
 if rel=='tests/evidence-consumers.test.ts':
  match=re.search(r'for \(const stage of (\[.*?\])\)\s*test\(`moved consumers preserve the first \$\{stage\} failure`',text);ck('literal dynamic test loop',bool(match));actual += ['moved consumers preserve the first '+stage+' failure' for stage in json.loads(match.group(1))]
 ck('actual test names '+rel,actual==x['names']);names+=actual
ck('151unique tests',len(names)==len(set(names))==151)
commands=read(D/'commands.plan.json');ck('fivecommands exactids',[x['id'] for x in commands['commands']]==['market-view','changed-file-lint','behavioural-suites','live-brand-safety','structural-validation'])
ck('144plus7',commands['commands'][2]['expectedTests']==sum(inv[p]['count'] for p in commands['commands'][2]['testFiles'])==144 and commands['commands'][3]['expectedTests']==7)
ck('no runtime extras',not commands['compilerIncluded'] and not commands['normalReportIncluded'] and not commands['automaticRetry'] and not commands['parallelExecutionAllowed'])
ck('market check only',commands['commands'][0]['command'][-1]=='--check')
ck('lint only loader',commands['commands'][1]['lintFiles']==['scripts/reporting/load.ts'])
struct=commands['commands'][-1];oldstruct=read('/tmp/nissan-packet/post-registration-checks-v1/run/structural-validation/stdout.log');e=dict(oldstruct['counts']);e['variants']+=3;e['evidence']+=207;e['outgoing']+=3
ck('structural expected exact delta',struct['expectedStructuralCounts']==e and struct['expectedSourceReferences']==oldstruct['sourceReferences']+27 and struct['expectedPublicationIssues']==oldstruct['publicationIssues'] and struct['expectedApprovedExternalAssets']==oldstruct['approvedExternalAssets'] and struct['immutableResearchSha256']==oldstruct['sha256'])
future=(D/'prepare-final.py').read_text();ck('live reclosure assertions',"closuredata['files']==preparedClosure['files'] and closuredata['edges']==preparedClosure['edges']" in future and "closuredata['priceSourcePointerBindings']==preparedClosure['priceSourcePointerBindings']" in future)
ck('no finalized execution bundle',not Path('/tmp/ford-packet/post-registration-checks-v1').exists())
res={'status':'PASS_DEFERRED_FIVE_GATE_PLAN_STATIC_REVIEW','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passedChecks':len(checks),'failedChecks':0,'method':'Read/hash/stat/AST review only; no application imports, compiler, test or supervisor execution; future real-live reclosure still required','checks':checks};(O/'checks.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({k:v for k,v in res.items() if k!='checks'}))
