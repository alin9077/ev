from pathlib import Path
import json,hashlib,difflib,datetime
D=Path('/tmp/ford-packet/registration-v1');O=Path('/tmp/ford-review/registration-v1-live-readback-v1');checks=[]
def ck(n,v):
 checks.append(dict(check=n,passed=bool(v)))
 if not v:raise AssertionError(n)
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def check(p):ck('pin '+p['path'],pin(p['path'])==p)
def write(n,v):
 with (O/n).open('x')as f:json.dump(v,f,indent=2);f.write('\n')
m=read(D/'manifest.json');a=read(D/'application/result.json');g=read(D/'root-application-grant-v1.json');started=read(D/'application/started.json')
ck('reviewed manifest',pin(D/'manifest.json')['sha256']=='6a7c6bfca208eb5940eba4cb6adfd52a2b55a97ca0802ef1f495c706feee58eb')
ck('exact root grant',pin(D/'root-application-grant-v1.json')['sha256']=='5da010afe9700d14ea983df55b905539abd810d7dd73cc25c5bd1de5d86a7500')
check(g['manifest']);check(g['reviewerAcceptance']);ck('reviewed acceptance',g['reviewerAcceptance']['sha256']=='f0f68c9065870646d90c133ab19fde841ef313b02bafce26dab3602ebf0da6e6')
ck('backup freeze explicitly released',g['backupLiveSourceFreezeReleased']is True)
ck('root action',g['status']=='root_application_granted' and g['action']=='apply_exact_ford_registration' and g['grantor']=='/root')
ck('no heavy grant or retry',not g['heavyExecutionAuthorized'] and not g['automaticRetry'])
ck('application chain',a['passed'] is True and a['manifestSha256']==g['manifest']['sha256']==started['manifestSha256'] and a['grantSha256']==pin(D/'root-application-grant-v1.json')['sha256']==started['grantSha256'])
ck('terminal no heavy/retry',not a['heavyExecution'] and not a['automaticRetry'] and not started['heavyExecution'] and started['beforeGuardsPassed']is True)
ck('exact target order',g['allowedTargets']==[w['target']for w in m['writes']] and len(m['writes'])==4)
transitions={w['target']:w for w in m['writes'] if w['before'] is not None};live=[]
ck('two replacements two creates',[w['operation']for w in m['writes']]==['replace','replace','create','create'])
for i,w in enumerate(m['writes']):
 check(w['after']);t=Path(w['target']);ck('not symlink '+str(t),not t.is_symlink());x=pin(t);ck('actual live bytes '+str(t),t.read_bytes()==Path(w['after']['path']).read_bytes());ck('actual live hash '+str(t),{k:v for k,v in x.items()if k!='path'}=={k:v for k,v in w['after'].items()if k!='path'});live.append(x)
 expected=dict(target=str(t),sha256=x['sha256']);ck('application recorded write '+str(i),a['writes'][i]==expected);ck('journal write '+str(i),read(D/f'application/write-{i+1}.json')==expected)
 if w['before']:
  check(w['beforeCopy']);ck('before copy matches declared '+str(t),{k:v for k,v in w['beforeCopy'].items()if k!='path'}==w['before'])
ck('six exact application files',sorted(p.name for p in (D/'application').iterdir())==['result.json','started.json','write-1.json','write-2.json','write-3.json','write-4.json'])
changed=[];unchanged=0
for p in m['proofs']:
 if p['path']in transitions:
  w=transitions[p['path']];ck('historical pin before '+p['path'],{k:v for k,v in p.items()if k!='path'}==w['before']);changed.append(p['path'])
 else:check(p);unchanged+=1
ck('only two historical transitions',sorted(changed)==sorted(transitions))
for p in m['unchangedHelperPins']:check(p)
check(m['applicator']);check(m['patch'])
reg=read(live[0]['path']);oldreg=read(m['writes'][0]['beforeCopy']['path']);ck('registry append32',reg['packets']==oldreg['packets']+['ford-2026-10-15.json'] and len(reg['packets'])==32)
ck('registry unchanged other fields',{k:v for k,v in reg.items()if k!='packets'}=={k:v for k,v in oldreg.items()if k!='packets'})
load=Path(live[1]['path']).read_text();before=Path(m['writes'][1]['beforeCopy']['path']).read_text();added=[x[1:]for x in difflib.unified_diff(before.splitlines(),load.splitlines()) if x.startswith('+')and not x.startswith('+++')];removed=[x for x in difflib.unified_diff(before.splitlines(),load.splitlines())if x.startswith('-')and not x.startswith('---')]
ck('exact two loader additions',added==['import fordReconciliation from "../../data/m1-ford-market-reconciliation-2026-10-15.json";','      fordReconciliation as M1MarketReconciliation,'] and not removed)
ck('packet exact accepted',live[2]['sha256']=='8d728412f21a36aac152357d04793fd38b5efc47438e5210af610f72e868ce00');ck('corrected reconciliation exact',live[3]['sha256']=='07531bcbe9d57c9b89647313ced205a60a899dc2aa6c4655db161fec1debdf39')
c1=read(live[3]['path']);ck('three current maker members',[x['carId']for x in c1['currentVersionReviews'][0]['versions']]==['ford_mustang_mach_e_2026_select_rwd','ford_mustang_mach_e_2026_premium_rwd','ford_mustang_mach_e_2026_gt_awd'])
ck('no published list closure',c1['publishedLists']==[] and c1['listResolutions']==[]);ck('both inventory unresolved',len(c1['inventoryResolutions'])==2 and all(x['outcome']=='unresolved'for x in c1['inventoryResolutions']))
write('checks.json',dict(status='PASS_STATIC_LIVE_READBACK',count=len(checks),failed=0,checks=checks))
r=dict(status='accepted',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),manifestSha256=pin(D/'manifest.json')['sha256'],manifest=pin(D/'manifest.json'),applicationReceipt=pin(D/'application/result.json'),rootApplicationGrant=pin(D/'root-application-grant-v1.json'),backupLiveSourceFreezeReleaseExplicitInRootGrant=True,allFourLiveHashesAndBytesMatchAcceptedPayloads=True,liveTargets=live,applicationJournal=[pin(p)for p in sorted((D/'application').iterdir())],beforeAfterChainExact=True,proofPins=dict(total=len(m['proofs']),unchanged=unchanged,onlyReviewedTransitions=changed,allExact=True),unchangedHelperPins=dict(count=len(m['unchangedHelperPins']),allExact=True,pins=m['unchangedHelperPins']),registry=dict(packets=32,first31Unchanged=True,last='ford-2026-10-15.json'),loaderChanges=added,acceptedCandidateSha256=live[2]['sha256'],acceptedReconciliationSha256=live[3]['sha256'],correctedMakerMembershipCount=3,FordInventoryUnresolved=2,staticChecks=len(checks),runtimeExecutedByReviewer=False,scopedRuntimePassed=False,normalReportPassed=False,currentProjectTypeScript='UNPASSED; no compiler retry',limits='Registration readback only. Actual post-registration command freeze, independent readiness and exclusive root grant remain required for scoped gates.')
write('review.json',r);write('manifest.json',dict(status='accepted',files=[pin(O/n)for n in ['check.py','checks.json','review.json']]))
print(json.dumps(dict(review=pin(O/'review.json'),manifest=pin(O/'manifest.json'),checks=len(checks),unchangedProofs=unchanged),indent=2))
