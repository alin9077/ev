from pathlib import Path
import json,hashlib,re,datetime
D=Path('/tmp/ford-packet/post-registration-checks-v1');O=Path('/tmp/ford-review/post-registration-v1-first-three-results-v1');checks=[]
def ck(n,v):
 checks.append(dict(check=n,passed=bool(v)))
 if not v:raise AssertionError(n)
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def check(p):ck('pin '+p['path'],pin(p['path'])==p)
def meta(p):
 p=Path(p)
 if not p.exists():return dict(path=str(p),exists=False)
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
def write(n,v):
 with (O/n).open('x')as f:json.dump(v,f,indent=2);f.write('\n')
mp=D/'first-three-results-manifest-v1.json';m=read(mp);s=read(D/'sequence.json');g=read(D/'root-first-three-grant-v1.json');readiness=read(g['reviewerAcceptance']['path']);inventory=read(D/'test-inventory.json');release=read(D/'first-three-slot-release.json')
ck('frozen outputs',pin(mp)['sha256']=='211411cbc16d706020a0879f3b9b093c985f8709d05ce8b1b81d703db796199c')
ck('exact reviewed sequence',m['sequence']==pin(D/'sequence.json')==g['sequence']==readiness['sequence'] and m['sequence']['sha256']=='cec141a15e1eeda6acc2d55de1e4e9a8927ed0b4fdf5fa7b64ba067e28857f4a')
for p in m['outputs']+m['commands']+[g['sequence'],g['reviewerAcceptance'],g['registrationVerification']]:check(p)
ck('29 unique output bindings',len(m['outputs'])==len({p['path']for p in m['outputs']})==29)
ck('only first three granted',g['granted']==m['commands']==s['sequence'][:3] and g['status']=='root_execution_granted' and g['heavySlotExclusive']is True and not g['automaticRetry'] and not g['parallelExecutionAllowed'])
ck('same accepted readiness',g['reviewerAcceptance']['sha256']=='a408c17784fb763d016b333eead47d7d7946852c26899da7fc0de1081e7f26b3')
ck('same registration readback',g['registrationVerification']['sha256']=='2e3dc9d8f8efac0ba4f18bb61e86185fa9b4a9823df8484acf113090f56fa468')
pins=read(D/'source-pins.json');ck('281 source pins',len(pins)==281)
for p in pins:check(p)
root=read(D/'project-root-metadata.json');gates=[];previous=None
for i,p in enumerate(m['commands']):
 config=read(p['path']);d=D/'run'/config['id'];result=read(d/'result.json');terminal=read(d/'terminal.json');inv=read(d/'invocation.json');scope=read(d/'scope-verification.json');after=read(d/'after-pins.json');start=read(d/'started.json');stdout=(d/'stdout.log').read_text()
 ck('full pass '+config['id'],result['passed']is True and result['exitCode']==terminal['exitCode']==terminal['rawWaitStatus']==0 and result['pinsPassed']is True and result['scopePassed']is True and result['automaticRetry']is False and not terminal['watchdogFired'])
 ck('terminal logs '+config['id'],terminal['stdoutSha256']==pin(d/'stdout.log')['sha256'] and terminal['stderrSha256']==pin(d/'stderr.log')['sha256'] and pin(d/'stderr.log')['bytes']==0)
 ck('frozen invocation '+config['id'],inv['manifestSha256']==result['manifestSha256']==p['sha256'] and inv['grantSha256']==pin(D/'root-first-three-grant-v1.json')['sha256'] and inv['command']==config['command'] and inv['cwd']==config['repo'] and inv['beforePinsPassed']is True and not inv['automaticRetry'] and not inv['sourceMutationsAuthorized'])
 ck('exact timeout '+config['id'],inv['supervisedCommand']==['/usr/bin/timeout','--signal=TERM','--kill-after=10s',str(config['timeoutSeconds'])+'s',*config['command']])
 ck('exact environment '+config['id'],inv['environmentRemovals']==config['environmentRemovals'] and inv['environmentOverrides']==config['environmentOverrides'])
 ck('postchecks '+config['id'],after['passed']is True and after['count']==299 and scope['passed']is True and scope['sourceScopeUnchanged']is True and scope['registrationTargetMetadataUnchanged']is True and scope['kind']==config['kind'])
 ck('target stat stable '+config['id'],read(d/'registration-target-metadata-before.json')==root['postRegistrationTargets'])
 if previous:ck('serial invocation '+config['id'],datetime.datetime.fromisoformat(inv['at'])>datetime.datetime.fromisoformat(previous['at']))
 previous=result
 ck('process group recorded '+config['id'],release['groups'][i]==dict(id=config['id'],processGroup=start['processGroup'],members=[]))
 for x in config['extraPins']+[config['wrapper'],config['testInventory'],config['sourcePins'],config['rootMetadata'],config['registrationManifest'],*config['registrationTargets']]:check(x)
 if config['kind']=='market':ck('exact market check output',stdout=='Market view verified without writing\n')
 elif config['kind']=='lint':
  lint=json.loads(stdout);ck('only exact loader lint',len(lint)==1 and lint[0]['filePath']==str(Path(config['repo'])/'scripts/reporting/load.ts'));ck('zero lint issues',all(lint[0][k]==0 for k in ['errorCount','fatalErrorCount','warningCount']) and lint[0]['messages']==[])
 else:
  names=[n for f in config['testFiles']for n in inventory[f]['names']];ck('exact144testnames',len(names)==144 and sorted(re.findall(r'^# Subtest: (.*)$',stdout,re.M))==sorted(names))
  for label,n in [('tests',144),('pass',144),('fail',0),('cancelled',0),('skipped',0),('todo',0)]:ck('TAP '+label,bool(re.search(r'^# '+label+r' '+str(n)+r'$',stdout,re.M)))
  ck('no failure rows',not re.search(r'^not ok\b',stdout,re.M))
 gates.append(dict(id=config['id'],manifest=p,result=pin(d/'result.json'),terminal=pin(d/'terminal.json'),seconds=terminal['elapsedSeconds'],maxRssKiB=terminal['maxRssKiB'],tests=config.get('expectedTests'),afterPinCount=after['count'],emptyStderr=True,watchdog=False))
for x in root['fileMetadata']+root['directoryState']+config['runtimeMetadata']+root['postRegistrationTargets']:ck('actual metadata '+x['path'],meta(x['path'])==x)
R=Path(config['repo']);ck('config and configured roots',read(R/'tsconfig.json')==config['originalConfig'] and sorted({str(p.resolve())for pat in config['originalConfig']['include']for p in R.glob(pat)if p.is_file()})==root['configuredRootFilePaths'])
ck('remaining gates unrun',not (D/'run/live-brand-safety').exists() and not (D/'run/structural-validation').exists())
ck('slot explicitly released',release['heavySlotReleased']is True and release['remainingCommandsRun']is False)
write('checks.json',dict(status='PASS_FIRST_THREE_SCOPED_RESULTS',passedChecks=len(checks),failedChecks=0,checks=checks))
r=dict(status='accepted',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),resultManifest=pin(mp),sequence=m['sequence'],rootGrant=pin(D/'root-first-three-grant-v1.json'),readiness=g['reviewerAcceptance'],registrationVerification=g['registrationVerification'],gates=gates,allFirstThreeScopedGatesPassed=True,all29OutputPinsExact=True,all281SourcePinsExact=True,allConfiguredAndTargetMetadataExact=True,perGateAfterChecks=299,strictSerialInvocations=True,behavioralTests=144,failed=0,cancelled=0,skipped=0,todo=0,terminalSlotRelease=pin(D/'first-three-slot-release.json'),remainingProcesses=[],staticChecks=len(checks),noRuntimeExecutedByReviewer=True,remainingUnrun=['live-brand-safety','structural-validation','normal report','saved comparator','full-project TypeScript'],currentProjectTypeScript='UNPASSED; no compiler retry',limits='Accepts first three gates only. Remaining scoped gates need a separate root grant after backup window. No full-suite, C1-C6, milestone or release claim.')
write('review.json',r);write('manifest.json',dict(status='accepted',files=[pin(O/n)for n in ['check.py','checks.json','review.json']]))
print(json.dumps(dict(review=pin(O/'review.json'),manifest=pin(O/'manifest.json'),checks=len(checks)),indent=2))
