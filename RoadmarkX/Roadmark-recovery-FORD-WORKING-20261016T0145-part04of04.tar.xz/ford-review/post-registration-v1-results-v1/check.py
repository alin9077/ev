from pathlib import Path
import json,hashlib,re,datetime
D=Path('/tmp/ford-packet/post-registration-checks-v1');O=Path('/tmp/ford-review/post-registration-v1-results-v1');checks=[]
def ck(n,v):
 checks.append(dict(check=n,passed=bool(v)))
 if not v:raise AssertionError(n)
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def check(p):ck('pin '+p['path'],pin(p['path'])==p)
def meta(p):
 p=Path(p)
 if not p.exists():return dict(path=str(p),exists=False)
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
def write(n,v):
 with (O/n).open('x')as f:json.dump(v,f,indent=2);f.write('\n')
mp=D/'results-manifest-v1.json';m=read(mp);s=read(D/'sequence.json');g=read(D/'root-first-three-grant-v1.json');readiness=read(g['reviewerAcceptance']['path']);inventory=read(D/'test-inventory.json');release=read(D/'terminal-slot-release-v1.json');grants=[read(p['path']) for p in m['rootGrants']]
ck('frozen outputs',pin(mp)['sha256']=='4daea32336c85d7f1eecf95bf9fad85a068f8c00ab745a6de12461ae36f30db8')
ck('exact reviewed sequence',m['sequence']==pin(D/'sequence.json')==g['sequence']==readiness['sequence'] and m['sequence']['sha256']=='cec141a15e1eeda6acc2d55de1e4e9a8927ed0b4fdf5fa7b64ba067e28857f4a')
for p in m['files']+s['sequence']+[g['sequence'],g['reviewerAcceptance'],g['registrationVerification']]:check(p)
ck('53 unique output bindings',len(m['files'])==len({p['path']for p in m['files']})==53)
ck('two exact partitioned grants',grants[0]['granted']==s['sequence'][:3] and grants[1]['granted']==s['sequence'][3:])
for gp,gg in zip(m['rootGrants'],grants):
 check(gp);ck('grant same sequence '+gp['path'],gg['status']=='root_execution_granted' and gg['heavySlotExclusive']is True and not gg['automaticRetry'] and not gg['parallelExecutionAllowed'] and gg['sequence']==m['sequence'] and gg['reviewerAcceptance']==g['reviewerAcceptance'] and gg['registrationVerification']==g['registrationVerification'])
ck('same accepted readiness',g['reviewerAcceptance']['sha256']=='a408c17784fb763d016b333eead47d7d7946852c26899da7fc0de1081e7f26b3')
ck('same registration readback',g['registrationVerification']['sha256']=='2e3dc9d8f8efac0ba4f18bb61e86185fa9b4a9823df8484acf113090f56fa468')
pins=read(D/'source-pins.json');ck('281 source pins',len(pins)==281)
for p in pins:check(p)
root=read(D/'project-root-metadata.json');gates=[];previous=None
for i,p in enumerate(s['sequence']):
 config=read(p['path']);d=D/'run'/config['id'];result=read(d/'result.json');terminal=read(d/'terminal.json');inv=read(d/'invocation.json');scope=read(d/'scope-verification.json');after=read(d/'after-pins.json');start=read(d/'started.json');stdout=(d/'stdout.log').read_text()
 ck('full pass '+config['id'],result['passed']is True and result['exitCode']==terminal['exitCode']==terminal['rawWaitStatus']==0 and result['pinsPassed']is True and result['scopePassed']is True and result['automaticRetry']is False and not terminal['watchdogFired'])
 ck('terminal logs '+config['id'],terminal['stdoutSha256']==pin(d/'stdout.log')['sha256'] and terminal['stderrSha256']==pin(d/'stderr.log')['sha256'] and pin(d/'stderr.log')['bytes']==0)
 ck('frozen invocation '+config['id'],inv['manifestSha256']==result['manifestSha256']==p['sha256'] and inv['grantSha256']==m['rootGrants'][0 if i<3 else 1]['sha256'] and inv['command']==config['command'] and inv['cwd']==config['repo'] and inv['beforePinsPassed']is True and not inv['automaticRetry'] and not inv['sourceMutationsAuthorized'])
 ck('exact timeout '+config['id'],inv['supervisedCommand']==['/usr/bin/timeout','--signal=TERM','--kill-after=10s',str(config['timeoutSeconds'])+'s',*config['command']])
 ck('exact environment '+config['id'],inv['environmentRemovals']==config['environmentRemovals'] and inv['environmentOverrides']==config['environmentOverrides'])
 ck('postchecks '+config['id'],after['passed']is True and after['count']==299 and scope['passed']is True and scope['sourceScopeUnchanged']is True and scope['registrationTargetMetadataUnchanged']is True and scope['kind']==config['kind'])
 ck('target stat stable '+config['id'],read(d/'registration-target-metadata-before.json')==root['postRegistrationTargets'])
 if previous:ck('serial invocation '+config['id'],datetime.datetime.fromisoformat(inv['at'])>datetime.datetime.fromisoformat(previous['at']))
 previous=result
 ck('process group recorded '+config['id'],release['groups'][i]==dict(id=config['id'],processGroup=start['processGroup'],members=[]))
 for x in config['extraPins']+[config['wrapper'],config['testInventory'],config['sourcePins'],config['rootMetadata'],config['registrationManifest'],*config['registrationTargets']]:check(x)
 if config['kind']=='market':ck('exact market check output',stdout=='Market view verified without writing\n')
 elif config['kind']=='lint':
  lint=json.loads(stdout);ck('only exact loader lint',len(lint)==1 and lint[0]['filePath']==str(Path(config['repo'])/'scripts/reporting/load.ts'));ck('zero lint issues',all(lint[0][k]==0 for k in ['errorCount','fatalErrorCount','warningCount']) and lint[0]['messages']==[])
 elif config['kind']=='tests':
  names=[n for f in config['testFiles']for n in inventory[f]['names']];ck('exact scoped test names '+config['id'],len(names)==config['expectedTests'] and sorted(re.findall(r'^# Subtest: (.*)$',stdout,re.M))==sorted(names))
  for label,n in [('tests',config['expectedTests']),('pass',config['expectedTests']),('fail',0),('cancelled',0),('skipped',0),('todo',0)]:ck('TAP '+label,bool(re.search(r'^# '+label+r' '+str(n)+r'$',stdout,re.M)))
  ck('no failure rows',not re.search(r'^not ok\b',stdout,re.M))
 else:
  structural=json.loads(stdout);ck('structural PASS',structural['result']=='PASS' and structural['counts']==config['expectedStructuralCounts']);ck('structural exact other values',structural['sourceReferences']==config['expectedSourceReferences'] and structural['publicationIssues']==config['expectedPublicationIssues'] and structural['approvedExternalAssets']==config['expectedApprovedExternalAssets'] and structural['sha256']==config['immutableResearchSha256'])
 ck('complete manifest gate bindings '+config['id'],m['checks'][i]['name']==config['id'] and m['checks'][i]['manifest']==p and m['checks'][i]['result']==pin(d/'result.json') and m['checks'][i]['terminal']==pin(d/'terminal.json') and m['checks'][i]['passed']is True and m['checks'][i]['exitCode']==0)
 for name in ['result.json','terminal.json','after-pins.json','scope-verification.json','stdout.log','stderr.log','invocation.json','registration-target-metadata-before.json','started.json']:ck('output explicitly bound '+config['id']+name,pin(d/name) in m['files'])
 gates.append(dict(id=config['id'],manifest=p,result=pin(d/'result.json'),terminal=pin(d/'terminal.json'),seconds=terminal['elapsedSeconds'],maxRssKiB=terminal['maxRssKiB'],tests=config.get('expectedTests'),afterPinCount=after['count'],emptyStderr=True,watchdog=False))
for x in root['fileMetadata']+root['directoryState']+config['runtimeMetadata']+root['postRegistrationTargets']:ck('actual metadata '+x['path'],meta(x['path'])==x)
R=Path(config['repo']);ck('config and configured roots',read(R/'tsconfig.json')==config['originalConfig'] and sorted({str(p.resolve())for pat in config['originalConfig']['include']for p in R.glob(pat)if p.is_file()})==root['configuredRootFilePaths'])
ck('exact five run directories',sorted(p.name for p in (D/'run').iterdir())==sorted(x['id']for x in gates))
ck('slot explicitly released',release['heavySlotReleased']is True and release['allFiveProcessesTerminal']is True)

for k in ['firstThreeAcceptance','preExecutionFailure','resumeReadiness']:check(grants[1][k])
resume=read(grants[1]['resumeReadiness']['path']);outage=read(grants[1]['preExecutionFailure']['path'])
ck('outage before any gate',outage['gateProcessesStarted']is False and outage['testFailureClaimed']is False and outage['alternateEnvironmentUsed']is False and outage['escalationUsed']is False and outage['sourceEdits']is False)
ck('resume checks exact and unstarted',resume['sequenceSha256']==m['sequence']['sha256'] and resume['sourcePinsExact']==281 and resume['allFiveManifestPinsExact']is True and resume['metadataExact']is True and resume['lastTwoNeverStarted']is True and resume['gateExecutionStarted']is False)
ck('first three receipt unchanged',grants[1]['firstThreeAcceptance']['sha256']=='0b5248b1f99284470f2c92b4f6eb04cb1e27fc117c1baca755d13b7f2570646d')
write('checks.json',dict(status='PASS_ALL_FIVE_SCOPED_RESULTS',passedChecks=len(checks),failedChecks=0,checks=checks))
r=dict(status='accepted',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),resultManifest=pin(mp),sequence=m['sequence'],rootGrants=m['rootGrants'],readiness=g['reviewerAcceptance'],registrationVerification=g['registrationVerification'],partialReview=grants[1]['firstThreeAcceptance'],gates=gates,allFiveScopedGatesPassed=True,all53OutputPinsExact=True,all281SourcePinsExact=True,allConfiguredAndTargetMetadataExact=True,perGateAfterChecks=299,strictSerialInvocations=True,behavioralTests=144,liveSafetyTests=7,distinctScopedTests=151,failed=0,cancelled=0,skipped=0,todo=0,structural=read(D/'run/structural-validation/stdout.log'),terminalSlotRelease=pin(D/'terminal-slot-release-v1.json'),remainingProcesses=[],staticChecks=len(checks),noRuntimeExecutedByReviewer=True,snapshotAsOf='2026-10-15',preProcessOutage=dict(receipt=grants[1]['preExecutionFailure'],resumeReadiness=grants[1]['resumeReadiness'],checkerCorrection=pin(D/'last-two-resume-checker-failure-v1.json'),interpretation='Same-environment transport failure before grant-file or gate process creation, followed by explicit same-VM recovery/pin checks. Ad hoc expected-absent-directory checker corrected before gate start; no test failure, duplicate wrapper execution, source drift or automatic retry.'),currentProjectTypeScript='UNPASSED; both unknown-cause KGM SIGKILL attempts retained; no compiler retry',normalReportPassed=False,comparatorPassed=False,limits='Accepted five scoped gates only, not full suite or C1-C6/milestone/release pass. Final actual-live report/comparator source freeze, independent command readiness and exact parent-exclusive grant remain required.')
write('review.json',r);write('manifest.json',dict(status='accepted',files=[pin(O/n)for n in ['check.py','checks.json','review.json']]))
print(json.dumps(dict(review=pin(O/'review.json'),manifest=pin(O/'manifest.json'),checks=len(checks)),indent=2))
