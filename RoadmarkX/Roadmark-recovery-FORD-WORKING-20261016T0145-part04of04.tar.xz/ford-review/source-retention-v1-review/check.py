from pathlib import Path
from datetime import datetime, timezone
import ast, hashlib, json, os, stat
B=Path('/tmp/ford-review/source-retention-v1-review'); M=Path('/tmp/ford-packet/source-retention-v1/manifest.json')
checks=[]
def ck(ok,label):
 assert ok,label
 checks.append(label)
def pin(path):
 p=Path(path); b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def verify(p,label):
 actual=pin(p['path']);ck(all(actual[k]==p[k] for k in ('path','bytes','sha256')),label);return actual
mp=pin(M);ck(mp['sha256']=='e8b6fd6c4f4478191f8e65ba64737b1ae0342d6a8432818ea9929405f09d481d','Exact frozen allowance')
m=json.loads(M.read_text());root=Path(m['sourceRoot']);ck(str(root)=='/tmp/ford-research','Exact source root')
origins={}
for p in m['authoritativeManifests']:
 verify(p,'Authoritative manifest '+p['path']);x=json.loads(Path(p['path']).read_text()); rows=x if isinstance(x,list) else x['files']
 origins[p['path']]={r['path']:r for r in rows}
rows=m['sourcePins'];ck(len(rows)==78==m['allowlistedResearchFiles'],'78 source files')
ck(len({p['path'] for p in rows})==78,'Unique named paths')
first=[];prior=[]
for r in rows:
 p=Path(r['path']);s=p.lstat()
 ck(p.is_relative_to(root) and p.resolve()==p,'Bounded source path '+str(p))
 ck(stat.S_ISREG(s.st_mode) and not p.is_symlink(),'Regular file '+str(p))
 ck((s.st_size,s.st_mode,s.st_mtime_ns)==(r['bytes'],r['mode'],r['mtimeNs']),'Exact metadata '+str(p))
 ck(p.suffix in ['.txt','.json','.py'],'Source/preparation extension '+str(p))
 if r['contentHashRecomputedAtThisPreparation']:
  first.append(r);verify(r,'Bounded historical hash '+str(p));ck(r['role'].startswith('Superseded'),'Historical role '+str(p))
 else:
  prior.append(r);ck(bool(r['pinOrigins']),'Declared prior origin '+str(p))
  for o in r['pinOrigins']:
   ck(o in origins and str(p) in origins[o],'Origin membership '+str(p)+' '+o)
   old=origins[o][str(p)];ck(all(old[k]==r[k] for k in ['path','bytes','sha256']),'Exact prior pin '+str(p)+' '+o)
actual=set()
for current, dirs, files in os.walk(root,followlinks=False):
 for n in dirs:ck(not (Path(current)/n).is_symlink(),'No directory symlink '+str(Path(current)/n))
 actual.update(str(Path(current)/n) for n in files)
ck(actual=={p['path'] for p in rows},'Metadata inventory exactly equals allowance')
ck(len(first)==8==m['firstExplicitHistoricalPins'] and sum(p['bytes'] for p in first)==77576==m['firstExplicitHistoricalBytes'],'Bounded eight first-time pins')
ck(len(prior)==70==m['priorDeclaredPins'],'70 reused source pins; no payload hash sweep')
for r in m['captureImplementations']:
 ck(r in first,'Capture implementation is explicitly bounded');ast.parse(Path(r['path']).read_text())
 ck('headers' not in [n.attr for n in ast.walk(ast.parse(Path(r['path']).read_text())) if isinstance(n,ast.Attribute)],'No response-header accessor in preserved capture implementation')
ck(Path(first[0]['path']).read_bytes()==Path(first[1]['path']).read_bytes(),'Identical unrun legacy source copy')
for k in ['preparationDiagnostic','imageProvenance','preparer']:verify(m[k],'Allowance member '+k)
ast.parse(Path(m['preparer']['path']).read_text())
ck(len(m['independentReviewImages'])==1 and m['sourceImages']==[],'One independent artwork; no source images')
i=m['independentReviewImages'][0];verify(i['file'],'Existing dealer artwork hash');s=Path(i['file']['path']).lstat();ck((s.st_mode,s.st_mtime_ns)==(i['mode'],i['mtimeNs']),'Artwork metadata')
pro=json.loads(Path(m['imageProvenance']['path']).read_text());ck(pro==i['provenance'],'Image provenance embedded exactly')
ind=pin('/tmp/ford-review/tait-gt-offer-provenance-v1.json');ck(ind['sha256']=='d1a16b980710bd12f7e315c4b867f7af60889f0d5cc6c3fe9619e8b9f94853ee','Independent artwork provenance pin');ip=json.loads(Path(ind['path']).read_text())
ck(pro['imageUrl']==ip['linkedImageUrl'] and pro['sourcePage']==ip['sourcePage'],'Public link provenance agrees')
ck(pro['freshRemoteImageByteMatchClaimed'] is False and ip['exactCurrentLinkToRetainedByteIdentityVerified'] is False,'No fresh/current remote byte identity claim')
ck(pro['researchSnapshotAsOf']=='2026-10-15' and pro['retentionLinkProvenanceVerifiedOn']=='2026-10-16','Dates distinguish research from retention check')
ck(not pro['applicationBrowserOrPhoneScreenshot'] and not pro['newRenderingPerformed'],'Dealer artwork is not product visual acceptance')
ck(all(not m[k] for k in ['payloadHashSweepPerformed','payloadCopyOrCompressionPerformed','privacyScanClaim','newSourceCaptureAuthorized']),'Narrow metadata-only preparation limitations')
ck(m['rawRuntimeExclusion']['readRefetchOrRecoveryAuthorized'] is False and all(x['deletionAuthorized'] is False for x in m['excludedPathsOrClasses']),'No prohibited recovery or deletion authority')
ck(m['retainedPublicPdfFiles']==0 and m['publicPdfDocuments']==0,'No locally retained PDF binary')
result={'status':'passed','checkedAt':datetime.now(timezone.utc).isoformat(),'manifest':mp,'checksPassed':len(checks),'checks':checks,'sourceFiles':78,'reusedPriorSourceHashes':70,'targetedHistoricalHashes':8,'targetedHistoricalBytes':77576,'independentImageProvenance':ind,'payloadHashSweepPerformed':False,'payloadCopiesOrCompression':False,'privacyScanClaim':False,'sourceFilesMutated':False,'projectModulesImported':False}
with (B/'checks.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
