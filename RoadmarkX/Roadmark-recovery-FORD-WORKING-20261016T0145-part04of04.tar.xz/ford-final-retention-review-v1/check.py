from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,os,stat
B=Path('/tmp/ford-final-retention-review-v1');P=Path('/tmp/ford-packet/final-freeze-v1/inventory.json');FINAL=Path('/tmp/ford-review/final-retention-v1-accepted.json')
checks=[]
def ck(v,n):
 assert v,n
 checks.append(n)
def pin(p):
 p=Path(p);d=p.read_bytes();return {'path':str(p),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
def verify(p,n):
 a=pin(p['path']);ck(all(a[k]==p[k] for k in ['path','bytes','sha256']),n);return a
def read(p):return json.loads(Path(p).read_text())
mp=pin(P);ck(mp['sha256']=='24a828ef8c1d84081d36b0a4b602b20f3367d5963118fbe29b0365886088ca7e','Exact author metadata cut')
m=read(P);rows=m['files'];paths={r['path'] for r in rows};by={r['path']:r for r in rows}
ck(len(rows)==len(paths)==538==m['totalFiles'],'538 unique paths')
ck(sum(r['bytes'] for r in rows)==66896242==m['regularFileBytes'],'66,896,242 declared payload bytes')
ck(m['payloadRoots']==['/tmp/ford-research','/tmp/ford-packet','/tmp/ford-review'],'Exact three Ford roots')
ck(not FINAL.exists() and str(FINAL) not in paths,'Future acceptance outside original cut')
ck(m['finalReviewerReceiptPolicy']['path']==str(FINAL) and m['finalReviewerReceiptPolicy']['separateReviewDirectory']==str(B) and m['finalReviewerReceiptPolicy']['includedInPayload'] is False,'Non-circular final receipt policy')
for r in rows:
 p=Path(r['path']);s=p.lstat();ck(p.resolve()==p and stat.S_ISREG(s.st_mode) and not p.is_symlink(),'Regular exact path '+str(p))
 ck((s.st_size,s.st_mode,s.st_mtime_ns)==(r['bytes'],r['mode'],r['mtimeNs']),'Exact metadata '+str(p))
 ck(r['kind']=='file','File kind '+str(p))
actual=set();ex={e['path']:e for e in m['excluded']};freeze=Path('/tmp/ford-packet/final-freeze-v1')
ck(set(ex)=={str(freeze),'/tmp/ford-packet/post-registration-checks-v1/.exclusive-heavy.lock'},'Only explicit two exclusions')
for root in m['payloadRoots']:
 for current,dirs,files in os.walk(root,followlinks=False):
  for d in dirs:ck(not (Path(current)/d).is_symlink(),'No directory symlink '+str(Path(current)/d))
  if Path(current)==freeze:dirs[:]=[];continue
  for n in files:
   p=Path(current)/n
   if str(p) in ex:
    e=ex[str(p)];s=p.lstat();ck((s.st_size,s.st_mode,s.st_mtime_ns)==(e['bytes'],e['mode'],e['mtimeNs']) and s.st_size==0,'Empty terminal lock metadata');continue
   actual.add(str(p))
live=m['sourceAndStatusAfterPins'];ck(len(live)==8,'Eight live targets')
actual.update(p['path'] for p in live);ck(actual==paths,'Exact existing inventory membership')
for e in m['excluded']:ck(e['deletionAuthorized'] is False,'No exclusion deletion authority '+e['path'])
for p in live:verify(p,'Exact live target '+p['path']);ck(by[p['path']]['category']=='live_registered_documentary_target','Live category '+p['path'])
for k in ['sourceAllowlist','sourceRetentionAcceptance','independentDocsReadback','factualReportAcceptance','scopedAcceptance','registrationManifest','docsManifest','currentPacket','currentReconciliation','retainedStorageReadClosure','previousFactualRetentionCut','previousFactualRetentionAcceptance','preparer']:
 verify(m[k],'Named pin '+k)
 if k not in ['previousFactualRetentionCut','previousFactualRetentionAcceptance','preparer']:ck(m[k]['path'] in paths,'Pinned artifact retained '+k)
ast.parse(Path(m['preparer']['path']).read_text())
source=read(m['sourceAllowlist']['path']);sr=read(m['sourceRetentionAcceptance']['path']);ck(sr['status']=='accepted' and sr['manifest']==m['sourceAllowlist'],'Exact accepted source allowance')
ck(sr['checksPassed']==816,'Source review scope retained')
research=[r for r in rows if r['path'].startswith('/tmp/ford-research/')];ck(len(research)==78==m['sourceAllowlistedResearchFiles'],'78 exact research declarations')
sm={p['path']:p for p in source['sourcePins']};ck(set(sm)=={r['path'] for r in research},'Allowance set equals research cut')
for r in research:
 s=sm[r['path']];ck(all(r[k]==s[k] for k in ['bytes','mode','mtimeNs']) and r['declaredSha256']==s['sha256'] and r['contentHashRecomputedAtFreeze'] is False,'Reused source declaration '+r['path'])
ck(m['rawRuntimeExclusion']==source['rawRuntimeExclusion'],'Raw-data boundary unchanged')
ip=m['publicImageProvenance'];ck(ip['independentDealerArtwork']==source['independentReviewImages'],'Same artwork provenance');verify(ip['independentProvenanceNote'],'Independent artwork provenance note')
ck(ip['independentProvenanceNote']==sr['independentImageProvenance'],'Image note bound to source acceptance')
ck(ip['freshRemoteImageByteMatch'] is False and ip['productBrowserOrPhoneScreenshots']==0 and ip['retentionLinkCheckDate']=='2026-10-16' and ip['researchSnapshotDate']=='2026-10-15','Artwork limits and dates preserved')
ck([r['path'] for r in rows if Path(r['path']).suffix.lower() in ['.png','.jpg','.jpeg','.pdf']]==['/tmp/ford-review/tait-gt-offer-v1.png'],'Only existing dealer artwork in cut; no PDF or product images')
reg=read(m['registrationManifest']['path']);doc=read(m['docsManifest']['path']);ck([w['target'] for w in reg['writes']+doc['writes']]==[p['path'] for p in live],'Live set exactly registration plus documentary targets')
for w,p in zip(reg['writes']+doc['writes'],live):ck((w['after']['bytes'],w['after']['sha256'])==(p['bytes'],p['sha256']),'Live expected after binding '+p['path'])
rb=read(m['independentDocsReadback']['path']);ck(rb['status']=='accepted' and rb['manifest']==m['docsManifest'] and rb['allFourLiveHashesAndBytesMatchAcceptedPayloads'] is True,'Independent documentary readback binding')
rr=read(m['factualReportAcceptance']['path']);sc=read(m['scopedAcceptance']['path']);ck(rr['status']==sc['status']=='accepted','Scoped and report receipts accepted');ck(rr['snapshotAsOf']=='2026-10-15' and rr['normalReportRuns']==rr['comparatorRuns']==1,'Exactly one snapshot report and comparator')
ck(rr['allNormalLeavesAccounted'] and rr['unchangedCompletePeerCars']==427 and rr['exhaustiveDifferences']==2154,'Accepted exhaustive factual comparison preserved')
ck(sc['allFiveScopedGatesPassed'] and sc['distinctScopedTests']==151 and sc['remainingProcesses']==[] and rr['remainingProcesses']==[],'Scoped tests and terminal release retained')
v=m['currentValidation'];expected={'catalogue':433,'tier1':356,'onSale':314,'packetCount':32,'retainedRefreshes':3,'additions':3,'visibleFord':6,'onSaleFord':5,'unconfirmedResidualGt':1,'unchangedPeers':427,'reviewedCore':102,'filledCore':95,'confirmed':81,'check':1,'reported':13,'notPublished':7,'scopedTests':151}
for k,n in expected.items():ck(v[k]==n,'Expected accepted validation '+k)
ck(v['fordCriteria']==rr['FordCriteria'],'Ford criteria agree with actual report')
for k in ['fullProjectTypecheckPassed','releaseReady','researchCompleted','currentCleanFullSuite','productionBuildVerified','phoneMobileVerified','publicationAuthorized']:ck(v[k] is False,'Unpassed/ungranted boundary '+k)
f=m['retainedFailures'];verify(f['compilerProvenance'],'Prior compiler provenance');cp=read(f['compilerProvenance']['path']);ck(f['compilerAttempts']==cp['attempts'] and len(cp['attempts'])==2,'Both original KGM attempts retained exactly')
ck(all(x['exitCode']==-9 and x['cause']=='unknown' and x['fullProjectTypecheckPassed'] is False for x in cp['attempts']),'Unknown SIGKILL remains unknown and unpassed')
ck(f['currentFullProjectTypeScript']=='UNPASSED' and f['compilerRetryAuthorized'] is False,'No compiler promotion or retry')
found=[r['path'] for r in rows if any(t in Path(r['path']).name.lower() for t in ['failure','diagnostic'])];ck(found==f['failureAndDiagnosticPaths'] and len(found)==10,'Ten exact Ford diagnostic/failure paths retained')
for d in ['candidate-v1','candidate-v2','candidate-v3','candidate-v4','docs-status-v1','docs-status-v2','report-comparison-plan-v1','report-comparison-plan-v2']:
 ck(any(p.startswith('/tmp/ford-packet/'+d+'/') for p in paths),'Immutable predecessor retained '+d)
previous=read(m['previousFactualRetentionAcceptance']['path']);ck(previous['status']=='accepted' and previous['inventory']==m['previousFactualRetentionCut'],'Exact accepted Nissan factual predecessor')
storage=read(m['retainedStorageReadClosure']['path']);ck(isinstance(storage,list) and len(storage)==21,'Exact 21-file retained storage closure schema')
ck('not itself a native delivery receipt' in m['predecessorDeliveryQualification'],'Predecessor factual and delivery qualifications separate')
ck(m['metadataOnlyInventory'] and not m['contentCaptureOrPrivacyScanPerformed'] and m['noFurtherPayloadEdits'],'Metadata-only frozen scope')
for r in rows:
 s=Path(r['path']).lstat();ck((s.st_size,s.st_mode,s.st_mtime_ns)==(r['bytes'],r['mode'],r['mtimeNs']),'Final stable metadata '+r['path'])
result=dict(status='passed',checkedAt=datetime.now(timezone.utc).isoformat(),inventory=mp,checksPassed=len(checks),checks=checks,totalFiles=538,totalBytes=66896242,liveTargetCount=8,sourceAllowanceCount=78,diagnosticHistoryCount=10,payloadContentHashSweep=False,payloadCopyOrCompression=False,privacyScanClaim=False,sourceOrLiveWrites=False,projectRuntimeOrCompiler=False,ownDiagnostic=pin(B/'schema-inspection-diagnostic-v1.json'))
with (B/'checks.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
