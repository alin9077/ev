"""Prepare a complete immutable independent replay manifest only after all staged phases pass."""
import pathlib,json,hashlib,datetime
R=pathlib.Path('/tmp/subaru-staging-review'); S=pathlib.Path('/tmp/subaru-staging-plan'); C=S/'candidate'; V=pathlib.Path('/tmp/subaru-staging-continuation-v2'); G=pathlib.Path('/tmp/subaru-feature-ranges-v3/runs/attempt1'); P=pathlib.Path('/tmp/subaru-derived-proof-plan'); REPO=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104'); Q=REPO.parent/'roadmark-104-qa'; T=Q/'subaru-derived-staging-checks'
roots={'stage':S,'proof':P,'research':pathlib.Path('/tmp/subaru-research'),'polestar':pathlib.Path('/tmp/polestar-research'),'qa':Q,'repo':REPO}
def read(p):return json.loads(pathlib.Path(p).read_text())
def pin(p):
 p=pathlib.Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(262144),b''):h.update(b)
 return {'path':str(p),'sha256':h.hexdigest(),'bytes':p.stat().st_size}
allpins={}
def add(p,sha=None,size=None):
 row=pin(p)
 if sha is not None:assert row['sha256']==sha,(str(p),'expected hash')
 if size is not None:assert row['bytes']==size,(str(p),'expected bytes')
 if row['path'] in allpins:assert allpins[row['path']]==row
 allpins[row['path']]=row;return row
def declared(row):return add(row.get('path',row.get('file')),row['sha256'],row.get('bytes'))
def locate(row):
 assert row['anchor'] in roots and not row['file'].startswith('/') and '..' not in pathlib.PurePath(row['file']).parts
 return roots[row['anchor']]/row['file']
# Retain all historical expectations. No hash replacement or omitted transition is permitted.
add(S/'stage-inputs.json','0244f1e320dd6f5a0d52b4365e20c3e27e4905caaca4c7cfd2eec5ebb22844be')
for row in read(S/'stage-inputs.json')['executionInputs']:declared(row)
add(V/'continuation-manifest.json','99fae0e573de27661ab6a36031afffb68590a1c8b2ec1e062439e9dd42adad1a')
cm=read(V/'continuation-manifest.json');declared(cm['contract']);declared(cm['amendmentReview'])
for row in read(V/'continuation-contract.json')['executionInputs']:declared(row)
add(G/'range-contract.json','3a59b75b973a281b18ead7372ecf5c65b942405ff0850466efdc64b0dc6af0ce')
gc=read(G/'range-contract.json')
for row in gc['executionInputs']:declared(row)
gm=read(G/'run-manifest.json');add(G/'run-manifest.json','97710735a04be1e808c34c1df6ae1ec4f2b5398e3ee95efaf22bdeaadd05fb3e');assert gm['status']=='approved_for_execution';assert gm['plan']==gc['plan'];declared(gm['contract']);declared(gm['independentReview']);assert gm['contract']['sha256']=='3a59b75b973a281b18ead7372ecf5c65b942405ff0850466efdc64b0dc6af0ce'
add(R/'independent-actual-replay.mjs','965a575741b782e4fbcc7768900baf8c2fa2b0bbc643b762203ab0836cad23bd');add(R/'verify-stored-values.mjs','1dabfc2e08f0daf77cab6616bebd437bab42856e0ccc32b55bc1fa6da2d2e9b5');add(R/'independent-replay-static-review.json','5e753526d5aed4b45096bb4acf09ab46307051ff29d0a4c03904d86e193a7e3d');add(__file__)
assert read(R/'independent-replay-static-review.json')['status']=='approved_for_pinned_independent_derived_only_execution_after_all_owner_phases_pass'
node=['node','--max-old-space-size=320','--max-semi-space-size=1','--expose-gc','--import','tsx']
def terminal(file,command):
 row=add(file);t=read(file);assert t['returncode']==0 and t['signal'] is None;assert t['command']==command;assert t['inheritedNodeOptions'] is None
 for name in ['stdout.log','stderr.log']:add(pathlib.Path(file).parent/name)
 return row
terminals={}
for key,run,script in [('core','core-feature-status-v2-attempt1','stage-core-subaru.mjs'),('selectedConsumers','selected-feature-status-v2-attempt1','stage-selected-consumers-subaru.mjs'),('negativeGuards','negatives-feature-status-v2-attempt1','stage-negative-guards-subaru.mjs'),('completeReport','report-feature-status-v2-attempt1','stage-complete-report-subaru.mjs')]:terminals[key]=terminal(T/run/'terminal.json',node+[str(V/script)])
rangeTerminals=[]
for phase in gc['plan']['ranges']:
 rangeTerminals.append(terminal(phase['terminal'],phase['command']));ri=read(phase['index']);rr=read(phase['receipt']);add(phase['index']);add(phase['receipt']);declared(rr['index']);declared(ri['features']);assert ri['range']==phase;assert rr['status']=='passed_range_pending_measured_terminal_and_aggregate';assert ri['inputProof']['rangeRunManifestSha256']==pin(G/'run-manifest.json')['sha256']
assert len(rangeTerminals)==len({r['path'] for r in rangeTerminals})==8
ap=gc['plan']['aggregate'];terminals['fullFeatures']=terminal(ap['terminal'],ap['command']);ar=read(ap['receipt']);add(ap['receipt']);assert ar['allEightMeasuredTerminalsExitZeroNoSignal'];assert ar['exactOriginalFailedPrefix']['matched'];assert ar['cars']==399 and ar['featureRows']==27531
for name in ['canonical-baseline-meta.json','canonical-selected-cars.json','canonical-packet-original.json','new-feature-before.json','staged-after.json','staged-core-receipt.json','staged-storage-index.json','staged-selected-consumer-receipt.json','staged-packs.json','staged-negative-guards-receipt.json','staged-all-feature-index.json','staged-all-feature-receipt.json','staged-complete-report-receipt.json','staged-report.json']:add(C/name)
core=read(C/'staged-core-receipt.json');assert core['packetSha256']=='6a21431aacaee96d10924ec854773c855d64b59d19ab313fa20e2a22f0f39b9c';assert pin(C/'staged-core-receipt.json')['sha256']=='7af97f5d8f0f143edd75e36614456d97367eea31a4748897d7c8d235fc6f9537';declared(core['storageIndex']);declared(core['selectedCars'])
for row in core['generatedPins']:declared(row)
declared(core['compositionTransition'])
selected=read(C/'staged-selected-consumer-receipt.json');declared(selected['packFile']);declared(selected['features'])
idx=read(C/'staged-storage-index.json')
for row in [idx['cars']['baseline'],*idx['research'].values()]:add(locate(row),row['sha256'],row.get('bytes'))
fr=read(C/'staged-all-feature-receipt.json');fi=read(C/'staged-all-feature-index.json');declared(fr['index']);declared(fi['features']);declared(fi['aggregateEvidence']);assert fi['features']['file']==ap['output'];assert fi['rangeRunManifestSha256']==pin(G/'run-manifest.json')['sha256']
rp=read(C/'staged-complete-report-receipt.json');assert rp['status']=='passed_pending_independent_candidate_review';assert rp['featureReceiptSha256']==pin(C/'staged-all-feature-receipt.json')['sha256'];declared(rp['reportFile'])
for name in ['accepted-derived-index.json','core-oracle-receipt.json']:add(P/name)
a=read(P/'accepted-derived-index.json');f=a['fullActualFeatureIndex'];add(P/f['file'],f['sha256'])
add('/tmp/subaru-research/capture-attempt640-original/subaru-live-before.json');add(S/'run-stage-measured.py')
# Recheck the entire combined input set before exclusive publication.
for p in allpins.values():assert pin(p['path'])==p
manifest={'status':'pinned_for_independent_actual_replay','asOf':'2026-10-15','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'coreReceiptSha256':pin(C/'staged-core-receipt.json')['sha256'],'correctedPacketSha256':core['packetSha256'],'continuationManifestSha256':pin(V/'continuation-manifest.json')['sha256'],'rangeRunManifestSha256':pin(G/'run-manifest.json')['sha256'],'inputs':sorted(allpins.values(),key=lambda r:r['path']),'terminals':terminals,'featureRangeTerminals':rangeTerminals,'historicalExpectedHashesNotReset':True,'freshLoaderValidation':False,'currentFullTypecheckVerified':False,'candidateRegistered':False}
out=R/'independent-replay-inputs.json'
with out.open('x') as f:json.dump(manifest,f,indent=2);f.write('\n')
print(json.dumps({'manifest':pin(out),'inputs':len(allpins),'executionStarted':False},indent=2))
