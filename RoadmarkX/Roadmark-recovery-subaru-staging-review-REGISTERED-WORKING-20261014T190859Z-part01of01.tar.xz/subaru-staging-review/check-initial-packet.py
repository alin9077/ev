from pathlib import Path
import json,hashlib,datetime,collections,re
S=Path('/tmp/subaru-staging-plan');R=Path('/tmp/subaru-research');O=R/'capture-attempt640-original';Q=Path('/workspace/scratch/586427eef9f2/roadmark-104-qa/subaru-derived-staging-checks')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
f=S/'candidate/subaru-initial-2026-10-15.json';ph=h(f);assert ph=='1bc824ee2dba493106626a2a57ee7557979a746076d60df6198463b11f029184'
m=S/'stage-inputs.json';mh=h(m);assert mh=='0244f1e320dd6f5a0d52b4365e20c3e27e4905caaca4c7cfd2eec5ebb22844be'
p=read(f);n=read(R/'normalized-evidence.json');before={x['id']:x for x in read(O/'subaru-live-before.json')};oldfeatures={(x['variant_id'],x['criterion']):x for x in read(O/'subaru-feature-before.json')};oldSources={x['id']:x for x in read(O/'subaru-source-before.json')};pins={x['path']:x for x in read(m)['executionInputs']}
assert len(pins)==1072
for file in [R/'normalized-evidence.json',R/'terms-normalized.json',R/'subaru-reconciliation-2026-10-15.json',*O.glob('subaru-*.json')]:assert h(file)==pins[str(file)]['sha256']
assert p['id']=='m1-subaru-2026-10-15' and p['brand']=='Subaru' and p['reviewedAt']=='2026-10-15'
assert [len(p[k]) for k in ['sources','variants','facts','brandTerms','features','summaries','versionGuards','availability']]==[29,2,646,3,239,11,9,11]
ids=[v['id'] for v in n['variants']];assert len(ids)==len(set(ids))==11
new=[v['id'] for v in p['variants']];assert new==['subaru_solterra_my27__awd__20261015','subaru_solterra_my27__awd_touring__20261015'];assert set(ids)==set(before)|set(new)
for v in p['variants']:
 assert v['brand']=='Subaru' and v['vehicle_class']=='passenger' and v['model_year']==2027
 assert all(v[k] is None for k in ['price_aud','range_km','seats'])
assert not p['versionUpdates'];assert len(p['models'])==1 and p['models'][0]['id']=='subaru_solterra_my27'
for g in p['versionGuards']:assert g['before']=={k:before[g['variantId']][k] for k in ['id','modelId','brand','model','trim','year','generation','vehicleClass','drive']}
sources={s['id']:s for s in p['sources']};assert len(sources)==29
sourceCaptureChecks=0
for s in p['sources']:
 assert s['market']=='AU' and s['accessed_date']=='2026-10-15'
 assert not s.get('sourceOriginMarket')
 if s['id'] in oldSources:assert s==oldSources[s['id']]
 for locator,digest in [('capture_locator','capture_sha256'),('capture_text_locator','capture_text_sha256')]:
  if locator in s:
   target=R/s[locator];assert target.is_relative_to(R);assert h(target)==s[digest];sourceCaptureChecks+=1
facts={v:{} for v in ids}
for row in p['facts']:
 v=row['variantId'];a=row['after'];k=a['key'];assert k not in facts[v];facts[v][k]=a
 assert row['before']==before.get(v,{}).get('facts',{}).get(k)
 assert a['date']=='2026-10-15' and a['market']=='AU';assert a['sourceIds'] and all(s in sources for s in a['sourceIds'])
 assert a['gradeReview']['overlayId']==p['id'] and a['gradeReview']['reviewedAt']=='2026-10-15' and a['gradeReview']['sourceIds']==a['sourceIds']
 if a['buyerGrade']=='check':assert a.get('conditionExplanation')
 if a['buyerGrade']=='not_published':assert a['value'] is None
 for src in a['sourceIds']:
  if sources[src]['source_type'] in ['independent_au_specification','dealer_hosted_manufacturer_brochure_reported']:assert a['buyerGrade']=='reported',(v,k)
for t in p['brandTerms']:
 assert set(t['applicableVariantIds'])==set(ids) and not t['exceptions'] and set(t['before'])==set(ids)
 for v in ids:assert t['before'][v]==before.get(v,{}).get('facts',{}).get(t['key']);facts[v][t['key']]=t['fact']
core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty','battery_warranty']
assert sum(all(k in facts[v] for k in core) for v in ids)==11
prices={};forbiddenBasis=re.compile(r'\b(?:not|unknown|unconfirmed|unresolved|unclear|whether)\b',re.I)
for v in ids:
 a=facts[v];tour='touring' in v;sol='solterra' in v;trail='trailseeker' in v;unch='uncharted' in v
 price=(67990 if tour else 61990) if sol else (69990 if tour else 63990) if trail else (59990 if 'without_' in v else 61190)
 assert a['price_aud']['value']==price;prices[v]=price
 for k,val in {'battery_kwh':74.7,'dc_peak_kw':150,'dc_charge_time_min':30,'ac_kw':22,'seats':5,'towing_braked_kg':1500,'ac_single_phase_kw':7}.items():assert a[k]['value']==val,(v,k)
 expected=[517 if tour else 566,410 if tour else 421,5.1,252,4690,1860,1650] if sol else [488 if tour else 533,595 if tour else 609,4.5,280,4845,1860,1675] if trail else [522,403,5,252,4535,1870,1625]
 for k,val in zip(['range_km','boot_l','zero_to_100_s','power_kw','length_mm','width_mm','height_mm'],expected):assert a[k]['value']==val,(v,k)
 assert a['boot_l']['comparisonBasis']==a['battery_kwh']['comparisonBasis']==a['width_mm']['comparisonBasis']==''
 pe=a['price_aud']['priceEvidence'];assert a['price_aud']['comparisonBasis']=='Before on-road costs'
 assert 'before on-road costs' in pe['basisTag'].lower();assert not forbiddenBasis.search(pe['basisTag']+' '+pe['originalBasis'])
 assert pe['rung']==(5 if 'solterra_my26' in v else 1)
 if 'solterra_my26' in v:assert a['price_aud']['buyerGrade']=='reported' and pe['rankingEligible'] is False
 else:assert a['price_aud']['buyerGrade']=='confirmed' and pe['rankingEligible'] is True and 'manufacturersListPrice' in pe['sourcePointer']
 if sol:assert a['zero_to_100_s']['buyerGrade']=='reported'
 if unch:
  assert a['equipment_speaker_system']['buyerGrade']=='check';assert 'hands-free kick operation not established' in a['equipment_power_tailgate']['value']
  assert a['dc_charge_time_min']['buyerGrade']==('check' if 'my27' in v else 'confirmed')
 if trail:assert a['cargo_folded_l']['value']==(1216 if tour else 1230) and a['max_total_cargo_l']['value']==(1680 if tour else 1694)
 if unch:assert a['cargo_folded_l']['value']==1089 and a['max_total_cargo_l']['value']==(1323 if 'without_' in v else 1304)
 assert a['service_plan']['value']=='5-year/75,000 km capped-price servicing program'
for av in p['availability']:
 v=av['variantId'];assert av['after']['evidence']['checkedAt']=='2026-10-15'
 assert av['after']['evidence']['physicalStockVerified'] is av['after']['evidence']['factoryOrderAcceptanceVerified'] is False
 if v in before:assert av['before']=={'availability':before[v]['availability'],'evidence':before[v]['availabilityEvidence']}
 assert av['after']['availability']==('residual_new_stock' if '_my26__' in v else 'current_or_order_listed')
seen=set()
for e in p['features']:
 key=(e['variantId'],e['criterion']);assert key not in seen;seen.add(key);assert e['variantId'] in before;assert e['before']==oldfeatures[key]
 assert all(d['expected']==facts[e['variantId']][d['key']] for d in e['dependencies'])
 assert e['after']['reviewed_date']=='2026-10-15' and e['after']['gradeReview']['overlayId']==p['id']
 if e['criterion']=='warranty_service':assert [d['key'] for d in e['dependencies']]==['service_plan']
 if e['criterion']=='v2l' and '1,500' in e['after']['value']:assert {'v2l_output_kw','v2l_voltage_v'}<=set(d['key'] for d in e['dependencies'])
for s in p['summaries']:
 for kind in ['strength','tradeoff']:
  assert s[kind]['dependencies'] and all(d['expected']==facts[s['variantId']][d['key']] for d in s[kind]['dependencies'])
term={t['key']:t['fact'] for t in p['brandTerms']};assert '150,000' in term['warranty']['value'];assert 'defect' in term['battery_warranty']['value'];assert '12 months' in term['roadside_assistance']['value'];assert any('fewer than 5' in q for q in term['roadside_assistance']['qualifications'])
receipts={}
for name in ['prepare-inputs-attempt1','build-initial-attempt1']:
 file=Q/name/'terminal.json';r=read(file);assert r['returncode']==0 and r['signal'] is None;receipts[name]={'path':str(file),'sha256':h(file)}
assert not (S/'candidate/canonical-baseline-meta.json').exists();assert h(f)==ph and h(m)==mh
out=Path('/tmp/subaru-staging-review/initial-packet-review.json');assert not out.exists()
r={'status':'approved_for_once_only_canonical_capture','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'asOf':'2026-10-15','packetSha256':ph,'stageInputManifestSha256':mh,'scriptSha256':h(__file__),'initialVersions':11,'newIdentities':2,'sources':29,'sourceCaptureHashesVerified':sourceCaptureChecks,'specificFacts':646,'brandTerms':3,'coreCells':187,'existingFeatureReplacements':239,'newFeatureReplacementsPendingCanonical':54,'summaryPairs':11,'exactPriceByVersion':prices,'fullOriginalBeforeGuardsChecked':True,'currentAndResidualSourceScopesPreserved':True,'secondaryFactsRemainReported':True,'unchartedConflictsRemainCheck':True,'genericCargoAndBatteryMeasurementBasisUnranked':True,'explicitAvailabilityLimitsRetained':True,'allSourceAndDependencyClosureChecked':True,'terminalReceipts':receipts,'limitations':['Static packet/evidence review; actual production validation and complete 399-car/feature/report checks remain pending','Current full-loader/equality, normal top-level report and full TypeScript remain open','No registry or production source mutation authorized'],'candidateRegistered':False,'canonicalFixtureExists':False}
with out.open('x') as f:json.dump(r,f,indent=2);f.write('\n')
print(json.dumps({'status':r['status'],'receipt':str(out),'sha256':h(out),'sourceCaptureHashesVerified':sourceCaptureChecks}))
