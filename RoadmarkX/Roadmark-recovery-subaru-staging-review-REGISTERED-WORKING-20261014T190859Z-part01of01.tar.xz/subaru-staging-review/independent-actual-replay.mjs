/** Independent actual core/pack/portable replay of complete staged Subaru values. No data.ts import. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {roots,readJson,fileHash,digestRows} from '/tmp/subaru-derived-proof-plan/helpers.mjs';
import {openStagedCore,readStagedResearch,assertStagedResearchUnchanged} from '/tmp/subaru-staging-continuation-v2/staged-values.mjs';
const root='/tmp/subaru-staging-review',manifestFile=root+'/independent-replay-inputs.json',manifestSha256=fileHash(manifestFile),manifest=readJson(manifestFile);
assert.equal(process.env.SUBARU_INDEPENDENT_REPLAY_MANIFEST_SHA256,manifestSha256);
assert.equal(manifest.status,'pinned_for_independent_actual_replay');assert.equal(manifest.asOf,'2026-10-15');
assert.equal(process.cwd(),roots.repo);assert.equal(typeof global.gc,'function');
assert.equal(new Set(manifest.inputs.map(r=>r.path)).size,manifest.inputs.length);
const ownPins=new Map(manifest.inputs.map(r=>[r.path,r]));
for(const file of [root+'/independent-actual-replay.mjs',root+'/verify-stored-values.mjs','/tmp/subaru-staging-plan/candidate/staged-packs.json','/tmp/subaru-staging-plan/candidate/staged-negative-guards-receipt.json','/tmp/subaru-staging-plan/candidate/new-feature-before.json',roots.research+'/capture-attempt640-original/subaru-live-before.json','/tmp/subaru-staging-plan/run-stage-measured.py'])assert(ownPins.has(file),'Mandatory independent replay pin: '+file);
for(const row of Object.values(manifest.terminals))assert.equal(ownPins.get(row.path)?.sha256,row.sha256);
assert.equal(manifest.featureRangeTerminals.length,8);assert.equal(new Set(manifest.featureRangeTerminals.map(r=>r.path)).size,8,'Eight distinct successful range terminals');for(const row of manifest.featureRangeTerminals){assert.equal(ownPins.get(row.path)?.sha256,row.sha256);const t=readJson(row.path);assert.equal(t.returncode,0);assert.equal(t.signal,null)}
const verifyOwn=()=>{assert.equal(fileHash(manifestFile),manifestSha256);for(const row of manifest.inputs){assert.equal(fileHash(row.path),row.sha256,row.path);assert.equal(fs.statSync(row.path).size,row.bytes)}};
verifyOwn();
const stage=openStagedCore();assert.equal(stage.receiptHash,manifest.coreReceiptSha256);assert.equal(stage.receipt.packetSha256,manifest.correctedPacketSha256);
assert.equal(stage.continuation.manifestSha256,manifest.continuationManifestSha256);
const candidate='/tmp/subaru-staging-plan/candidate',expectedPacks=readJson(candidate+'/staged-packs.json'),ownerNegative=readJson(candidate+'/staged-negative-guards-receipt.json');
assert.equal(ownerNegative.status,'passed_pending_complete_reports_and_independent_review');assert.equal(ownerNegative.unsupportedCategories.length,0);assert(ownerNegative.syntheticForeignPromotionRejected);assert.equal(ownerNegative.candidateForeignSourceCount,0);
for(const key of ['core','selectedConsumers','negativeGuards','fullFeatures','completeReport']){
 const row=manifest.terminals[key];assert(row);const t=readJson(row.path);assert.equal(fileHash(row.path),row.sha256);assert.equal(t.returncode,0);assert.equal(t.signal,null);
}
const require=createRequire(roots.repo+'/package.json');
const {applyBrandUpdates}=require('./src/lib/brand-updates.ts');
const {createEvidenceConsumers}=require('./src/lib/evidence-consumers.ts');
const {brandUpdatePackets}=require('./src/lib/brand-update-registry.ts');
const {compiledSource}=require('./tests/helpers/compiled-source.ts');
const {factClaim,featureClaim}=require('./src/lib/citable.ts');
const {storePortablePacks,hydratePortablePacks}=require('./src/lib/portable-packs.ts');
const {priceCandidateRejection}=require('./src/lib/price-ladder.ts');
const forbidden=()=>{throw new Error('Independent replay forbids broad/default data hydration')};
const defaults={sourceResearch:forbidden,research:forbidden,catalogue:forbidden};
assert.equal(brandUpdatePackets.length,17);assert(!brandUpdatePackets.some(p=>p.id===stage.packet.id));
const originalPacketDigest=digestRows([stage.packet]),registeredDigests=brandUpdatePackets.map(p=>digestRows([p]));
const stagedFactory=compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets:[...brandUpdatePackets,stage.packet]}}).createEvidenceConsumers;
const actual=stagedFactory(defaults),base=createEvidenceConsumers(defaults);global.gc();
const data=await readStagedResearch(stage.index);assert.equal(Object.keys(data).length,14);global.gc();
const original=readJson(roots.research+'/capture-attempt640-original/subaru-live-before.json'),originalDigests=original.map(car=>digestRows([car]));assert.equal(original.length,9);
const cars=applyBrandUpdates(original,data,[stage.packet]);assert.equal(cars.length,11);assert.equal(JSON.stringify(cars),JSON.stringify(stage.selected),'Independent complete serialized core application equals every selected car');
const carDigests=cars.map(car=>digestRows([car])),canonicalFeatures=readJson(candidate+'/new-feature-before.json'),newIds=new Set(stage.packet.variants.map(v=>v.id));assert.equal(newIds.size,2);
const packs={};let factClaims=0,featureClaims=0,priceFacts=0;
for(const car of cars){
 if(newIds.has(car.id))assert.equal(JSON.stringify(base.effectiveFeatures(car,data)),JSON.stringify(canonicalFeatures.filter(f=>f.variant_id===car.id)),'Immutable complete serialized canonical features');
 const view=actual.pack(car.id,{data,cars});assert.equal(JSON.stringify(view),JSON.stringify(expectedPacks[car.id]),'Independent complete serialized actual pack equality '+car.id);assert.equal(view.features.length,69);assert.equal(new Set(view.features.map(f=>f.criterion)).size,69);
 for(const fact of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===stage.packet.id)){
  const claim=factClaim(view,fact);assert.equal(claim.buyerGrade,fact.buyerGrade);assert.deepEqual(claim.sources.map(s=>s.id),fact.sourceIds);factClaims++;
  if(fact.key==='price_aud'){
   const p={variantId:car.id,value:fact.value,sourceIds:fact.sourceIds,date:fact.date,...fact.priceEvidence,comparisonBasis:fact.comparisonBasis,qualifications:fact.qualifications,validUntil:fact.validUntil};
   assert.equal(priceCandidateRejection(p,car.id,data.sources,'2026-10-15'),null);priceFacts++;
  }
 }
 for(const edit of stage.packet.features.filter(f=>f.variantId===car.id)){
  const feature=view.features.find(f=>f.criterion===edit.criterion);assert.deepEqual(feature,edit.after);
  const claim=featureClaim(view,feature.criterion,feature.criterion);assert.deepEqual(claim.sources.map(s=>s.id),feature.source_ids);assert.equal(claim.gradeReview.overlayId,stage.packet.id);featureClaims++;
 }
 packs[car.id]=view;global.gc();console.log('Independent complete actual pack',car.id);
}
assert.equal(Object.keys(packs).length,11);assert.equal(factClaims,679);assert.equal(featureClaims,293);assert.equal(priceFacts,11);assert.equal(JSON.stringify(packs),JSON.stringify(expectedPacks));
assert.deepEqual(hydratePortablePacks(storePortablePacks(packs),data.sources),packs,'Independent complete portable equality');
assert.deepEqual(original.map(car=>digestRows([car])),originalDigests);assert.deepEqual(cars.map(car=>digestRows([car])),carDigests);assertStagedResearchUnchanged(data,stage.index);
assert.deepEqual(digestRows([stage.packet]),originalPacketDigest);assert.deepEqual(brandUpdatePackets.map(p=>digestRows([p])),registeredDigests);
assert(!Object.hasOwn(require.cache,roots.repo+'/src/lib/data.ts'));verifyOwn();stage.verify();
const receipt={status:'passed_independent_actual_subaru_replay',asOf:'2026-10-15',manifestSha256,correctedPacketSha256:stage.receipt.packetSha256,coreReceiptSha256:stage.receiptHash,continuationManifestSha256:stage.continuation.manifestSha256,completeCoreCars:11,completeActualPacks:11,completeFeatures:759,factClaims,featureClaims,priceFacts,fullOriginalCanonicalFeaturesEqual:true,fullPortableEqual:true,all14ResearchFieldsUnchanged:true,allOriginalAndSelectedCarsUnchanged:true,completePacketAnd17RegisteredPacketsUnchanged:true,fullOwnerPackValuesExactlyEqual:true,broadDataModuleImported:false,freshLoaderValidation:false,currentFullTypecheckVerified:false,candidateRegistered:false,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()};
const out=root+'/independent-actual-replay-receipt.json';assert(!fs.existsSync(out));fs.writeFileSync(out,JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));
