from pathlib import Path
import json,hashlib,datetime,copy,re
S=Path('/tmp/subaru-staging-plan');C=Path('/tmp/subaru-staging-continuation-v2');V=Path('/tmp/subaru-staging-review')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while chunk:=f.read(262144):h.update(chunk)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
def pin(row):
 p=Path(row['path']);assert p.is_absolute();assert sha(p)==row['sha256'],str(p)
 if 'bytes' in row:assert p.stat().st_size==row['bytes']
contractFile=C/'continuation-contract.json';contractHash=sha(contractFile);assert contractHash=='32bd7df13b5787f71d7261fb40882b0f18140242cf363857b9d5c0797bc9ff73';c=read(contractFile);m=read(S/'stage-inputs.json');assert sha(S/'stage-inputs.json')=='0244f1e320dd6f5a0d52b4365e20c3e27e4905caaca4c7cfd2eec5ebb22844be'
assert len(m['executionInputs'])==1072;assert len(c['executionInputs'])==48
for rows in [m['executionInputs'],c['executionInputs']]:
 assert len({r['path'] for r in rows})==len(rows)
 for row in rows:pin(row)
oldpins={r['path']:r for r in m['executionInputs']}
for r in c['originalScriptPins']:assert r==oldpins[r['path']]
assert len(c['newScriptPins'])==7 and len(c['scriptTransitions'])==6
# Verify each retained full unified diff reconstructs the entire current clone.
for tr in c['scriptTransitions']:
 old=Path(tr['original']['path']).read_text().splitlines(True);patch=Path(tr['diff']['path']).read_text().splitlines(True);i=2;pos=0;result=[]
 while i<len(patch):
  match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',patch[i]);assert match,patch[i];start=int(match[1])-1;assert start>=pos;result.extend(old[pos:start]);pos=start;i+=1
  while i<len(patch) and not patch[i].startswith('@@'):
   line=patch[i];assert line[:1] in [' ','-','+']
   if line[0] in [' ','-']:assert old[pos]==line[1:];pos+=1
   if line[0] in [' ','+']:result.append(line[1:])
   i+=1
 result.extend(old[pos:]);assert ''.join(result)==Path(tr['continuation']['path']).read_text()
b=read(c['beforePacket']['path']);a=read(c['correctedPacket']['path']);proposal=read(c['transitionProposal']['path']);expected=[f'features[{i}].after.status' for i in [26,29,33,35,39,145,226]]
def diff(x,y,path=''):
 assert type(x)==type(y)
 if isinstance(x,dict):assert list(x)==list(y);return [d for k in x for d in diff(x[k],y[k],path+'.'+k if path else k)]
 if isinstance(x,list):assert len(x)==len(y);return [d for i,(xx,yy) in enumerate(zip(x,y)) for d in diff(xx,yy,f'{path}[{i}]')]
 return [] if x==y else [path]
assert diff(b,a)==expected==c['changedPaths'];reconstructed=copy.deepcopy(b)
for r in proposal['changes']:
 assert b['features'][r['index']]==r['beforeRow'];assert a['features'][r['index']]==r['proposedAfterRow'];reconstructed['features'][r['index']]['after']['status']='conditional'
assert reconstructed==a
for p in [a,b]:x=copy.deepcopy(p);x['features']=[];assert x==read(c['canonicalPacket']['path'])
review={
 'status':'approved_for_pinned_subaru_feature_status_v2_continuation',
 'contractSha256':contractHash,'originalStageInputManifestSha256':sha(S/'stage-inputs.json'),
 'beforePacketSha256':c['beforePacket']['sha256'],'correctedPacketSha256':c['correctedPacket']['sha256'],
 'canonicalPacketSha256':c['canonicalPacket']['sha256'],'originalFeatureFixtureSha256':c['originalFeatureFixture']['sha256'],
 'changedPaths':expected,'scriptPins':c['newScriptPins'],'sourceDiffPins':[t['diff'] for t in c['scriptTransitions']]+[c['helperDiff']],
 'allOriginalAlgorithmsAssertionsAndCompleteComparisonsPreserved':True,'original1072PinsUnchanged':True,
 'exactCorrectedPacketInspected':True,'allOtherPacketValuesUnchanged':True,'featureFreeCanonicalExactlyEqual':True,
 'canonicalRecaptured':False,'historicalExpectationsReset':False,'candidateRegistered':False,
 'freshLoaderValidation':False,'currentFullTypecheckVerified':False,'registryEditsAuthorized':False,
 'reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'Independent Subaru evidence reviewer',
 'independentFilePinsVerified':{'original':1072,'continuation':48},'independentFullDiffsReconstructed':6,
 'verificationScriptSha256':sha(__file__),
 'findings':['All six clone diffs preserve original full loops, counts, order, serialized comparisons and negative expectations; changes are explicit import/packet bindings, own-script path and additional lineage checks.','New helper requires an externally pinned sealed manifest, independently reviewed fixed contract, every exact new/original script and full candidate transition. It verifies the seven changes and immutable canonical artifacts before and after phases.','The new packet is exactly the approved seven after.status changes. Both executed packet files, the original 1072-pin manifest, failed core receipts and once-only canonical fixture remain preserved.','The unchanged complete core expectations still require 399 cars, all 14 canonical fields, all non-Subaru/lower-tier equality and full input immutability. Later actual consumer/portable/negative/full-feature/report checks remain mandatory.'],
 'executionApproval':'Seal a new final manifest from the reviewed draft and run one measured core retry with the exact externally supplied manifest hash. Stop on mismatch or termination; retain every original expectation. No new facts or canonical generation.',
 'scopedLaterPhases':'After independent successful core terminal review, unchanged selected consumer, negative, full feature and complete report phases may proceed serially under the approved plan.'}
template=read(C/'independent-review-required-fields.json')['requiredApprovedFields']
for k,v in template.items():assert review[k]==v,k
assert sha(contractFile)==contractHash
out=V/'feature-status-v2-continuation-review.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps({'status':review['status'],'review':str(out),'sha256':sha(out),'contractSha256':contractHash}))
