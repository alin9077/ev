import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
const root='/workspace/scratch/586427eef9f2/roadmark-104',dir='/tmp/leapmotor-c1-scope/v2';
const req=createRequire(root+'/package.json'),ts=req('typescript');
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const pins=[
 [dir+'/reports.ts','e8514fdd9a3bcc6fd5a4351515a1b26a181ec2f8a69c1cee299347a833ffc88b'],
 ['/tmp/leapmotor-packet/reconciliation-v2/m1-leapmotor-market-reconciliation-2026-10-15.json','33a3e1d6c47d3b68b0baac3a3d701af2c28ef10450d1c1175db1156802a642db'],
 ['/tmp/leapmotor-staging/v4-timeout/output/staged-packs.json','903457138169fd0add1186cc3017ed23b95dd645f88bbfdce892683c91cf0191'],
 [root+'/scripts/reporting/reports.ts','3e3c6118a5d876f3dce7ddd6577b80e752dae5be3f9d6e4f4ffeec6157b16b4e']
];
for(const [p,h]of pins)assert.equal(hash(p),h,p);
function compile(p){const logical=root+'/scripts/reporting/reports.ts';const output=ts.transpileModule(fs.readFileSync(p,'utf8'),{fileName:logical,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,esModuleInterop:true}}).outputText;const module={exports:{}};vm.runInThisContext('(function(require,module,exports){'+output+'\n})',{filename:logical})(createRequire(logical),module,module.exports);return module.exports;}
const old=compile(root+'/scripts/reporting/reports.ts'),updated=compile(dir+'/reports.ts');
const packs=JSON.parse(fs.readFileSync('/tmp/leapmotor-staging/v4-timeout/output/staged-packs.json','utf8'));
const cars=Object.values(packs).map(p=>p.car),features=Object.values(packs).flatMap(p=>p.features);
const bySource=new Map();for(const p of Object.values(packs))for(const s of p.sources){if(bySource.has(s.id))assert.deepEqual(s,bySource.get(s.id));bySource.set(s.id,s);}
const sources=[...bySource.values()],rawInventory=JSON.parse(fs.readFileSync(root+'/data/market-inventory-2026-10-10.json','utf8'));
const inventory={records:rawInventory.records.filter(r=>r.brand==='Leapmotor'),unverifiedLeads:rawInventory.unverifiedLeads.filter(r=>r.brand==='Leapmotor')};assert.equal(cars.length,10);assert.equal(features.length,690);assert.equal(inventory.records.length,4);assert.equal(inventory.unverifiedLeads.length,0);
const reconciliation=JSON.parse(fs.readFileSync(pins[1][0],'utf8')),input={cars,sources,features,inventory,m1Reconciliation:reconciliation};const beforeInput=structuredClone(input);
const before=old.buildCoverageReport(input,'2026-10-15'),after=updated.buildCoverageReport(input,'2026-10-15');
for(const key of ['allCatalogueVersions','tierOneVersions','onSaleVersions','denominatorNote','gradeNote','core','gaps','rankings','summaryGaps','pairedOnSale','pairedOnSalePercent','inAllRankings','inAllRankingsPercent','grading','ageing'])assert.deepEqual(after[key],before[key],key);
assert.deepEqual(after.criteria.filter(c=>c.id!=='C1'),before.criteria.filter(c=>c.id!=='C1'));
assert.equal(after.reconciliation.reviewedModels,4);assert.equal(after.reconciliation.reviewedVersions,9);assert.equal(after.reconciliation.settledInventory.length,4);
assert.deepEqual(after.reconciliation.issues.map(i=>[i.code,i.reference??null]),[['independent_lists',null],['version_unreviewed','leapmotor_c10_my25__design_69_9kwh__20261015']]);
assert.equal(after.onSaleVersions,7);assert.equal(after.brandProgress[0].researchCompleted,false);assert.equal(after.brandProgress[0].coreGaps,7);assert.equal(after.brandProgress[0].unreviewedCoreGrades,0);
assert.deepEqual(input,beforeInput);for(const [p,h]of pins)assert.equal(hash(p),h,p);assert(!req.cache[root+'/src/lib/data.ts']);
const output=dir+'/selected-reconciliation-output';fs.mkdirSync(output);
for(const[name,value]of [['before.json',before],['after.json',after],['receipt.json',{status:'passed',scope:'Ten selected actual written detail packs,690 features,four inherited inventory rows; no catalogue hydration',pins:pins.map(([path,sha256])=>({path,sha256})),inputUnchanged:true,completeNonC1ReportMetricsUnchanged:true,onSaleVersions:7,currentMakerReviews:4,currentMakerVersions:9,inventorySettled:4,remainingC1:after.reconciliation.issues,defaultCatalogueLoaded:false}]])fs.writeFileSync(output+'/'+name,JSON.stringify(value,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:'passed',output,reviewedModels:4,reviewedVersions:9,settledInventory:4,remaining:after.reconciliation.issues,unchangedC2ThroughC6:true},null,2));
