import fs from 'node:fs';
import vm from 'node:vm';
import {createRequire} from 'node:module';
const root='/workspace/scratch/586427eef9f2/roadmark-104';
const req=createRequire(root+'/package.json'),ts=req('typescript');
function compile(file,logical,overrides={}){
 const source=fs.readFileSync(file,'utf8');
 const output=ts.transpileModule(source,{fileName:logical,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,esModuleInterop:true}}).outputText;
 const module={exports:{}},scoped=createRequire(logical);
 vm.runInThisContext('(function(require,module,exports){'+output+'\n})',{filename:logical})(id=>Object.hasOwn(overrides,id)?overrides[id]:scoped(id),module,module.exports);
 return module.exports;
}
const proposal=compile('/tmp/leapmotor-c1-scope/v1/reports.ts',root+'/scripts/reporting/reports.ts');
compile('/tmp/leapmotor-c1-scope/v1/c1-order-eligibility.test.ts',root+'/tests/c1-order-eligibility.test.ts',{'../scripts/reporting/reports':proposal});
if(req.cache[root+'/src/lib/data.ts'])throw new Error('Unexpected full-catalogue loader');
