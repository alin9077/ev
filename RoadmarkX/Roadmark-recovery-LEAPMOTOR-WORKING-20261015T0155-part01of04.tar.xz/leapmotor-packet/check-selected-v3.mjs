import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import readline from 'node:readline';
import { createRequire } from 'node:module';
const repo='/workspace/scratch/586427eef9f2/roadmark-104', out='/tmp/leapmotor-packet/v3';
const req=createRequire(repo+'/package.json');
const {prepareBrandResearch,applyBrandUpdates,brandVersionSnapshot}=req('./src/lib/brand-updates.ts');
const {hasEarnedBuyerGrade,isBrakedTowingBasisEstablished}=req('./src/lib/evidence-grading.ts');
const {buyerAvailabilityText}=req('./src/lib/buyer-availability.ts');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const packetBytes=fs.readFileSync(out+'/leapmotor-2026-10-15.json');assert.equal(sha(packetBytes),'ba6a8e7e89ea598e2cff75075e5893b1885974aa8a2ddde9acd946c9b459990c');const p=JSON.parse(packetBytes);
const before=JSON.parse(fs.readFileSync('/tmp/leapmotor-research/retained-before-cars.json')),beforeText=JSON.stringify(before),ids=new Set(before.map(v=>v.id));
const stem='/tmp/mercedes-staging-plan/staging-preparation/staging-artifacts/canonical-v1/';
const variants=[];for await(const l of readline.createInterface({input:fs.createReadStream(stem+'raw-research-variants.jsonl'),crlfDelay:Infinity})){if(!l.includes('Leapmotor'))continue;const v=JSON.parse(l);if(ids.has(v.id))variants.push(v)}
assert.equal(variants.length,6);
const models=fs.readFileSync(stem+'raw-research-models.jsonl','utf8').trim().split('\n').map(JSON.parse).filter(m=>variants.some(v=>v.model_id===m.id));
const sources=JSON.parse(fs.readFileSync('/tmp/leapmotor-research/retained-before-sources.json'));
// Deliberately bounded selected-core fixture. Empty feature/history arrays are NOT a full Research snapshot.
const base={schema_version:'selected-core-fixture',metadata:{record_count:6,feature_row_count:0,added_variant_count:0,added_feature_row_count:0},criteria:[],models,variants,sources,trim_equipment:[],feature_evidence:[],update_eligibility:[],update_events:[],configuration_history:[],publication_issues:[],prior_update_summary:[]};
const baseText=JSON.stringify(base);const data=prepareBrandResearch(base,[p]);const after=applyBrandUpdates(before,data,[p]);
assert.equal(after.length,10);assert.equal(data.variants.length,10);assert.equal(new Set(after.map(v=>v.id)).size,10);assert.equal(JSON.stringify(before),beforeText);assert.equal(JSON.stringify(base),baseText);
for(const g of p.versionGuards)assert.deepEqual(brandVersionSnapshot(before.find(v=>v.id===g.variantId)),g.before);
let facts=0;for(const v of after){for(const f of Object.values(v.facts)){if(f.gradeReview?.overlayId!==p.id)continue;facts++;assert(hasEarnedBuyerGrade(f,data.sources,p.reviewedAt));}assert(v.buyerSummary?.strength&&v.buyerSummary?.tradeoff);assert(isBrakedTowingBasisEstablished(v.facts.towing_braked_kg));assert.equal(v.facts.dc_10_80_min.value,null);assert.equal(v.facts.dc_10_80_min.buyerGrade,'not_published');}
assert.equal(facts,185);
for(const car of after){const expected=car.availability==='announced_provisional'?'Order open or arriving':'On sale now';assert.equal(buyerAvailabilityText(car),expected);if(car.model==='B03X'){assert(!Object.hasOwn(car.availabilityEvidence,'expectedDelivery'));assert(car.availabilityEvidence.qualifications.some(q=>q.includes('dealership arrival expected November 2026')));}}
for(const v of after.filter(v=>v.facts.maker_msrp_aud?.value)){assert.equal(v.facts.maker_msrp_aud.comparisonBasis,'');assert.equal(v.facts.maker_msrp_aud.buyerGrade,'confirmed');assert.equal(v.facts.price_aud.buyerGrade,'reported');assert.equal(v.facts.price_aud.priceEvidence.rung,5);assert.equal(v.facts.price_aud.priceEvidence.rankingEligible,false);}
const forbidden=['src/lib/data.ts','src/lib/catalogue.ts','src/lib/research.ts'];for(const f of forbidden)assert(!req.cache[repo+'/'+f],'No full catalogue or research loader import');
const result={status:'selected_core_actual_functions_pass',packetSha256:sha(packetBytes),beforeCars:6,afterCars:10,earnedPacketFactCells:facts,coreCells:170,published30to80Values:10,explicit10to80NotPublished:10,brakedSourceLabelsRecognized:10,sharedBrandTerms:2,originalSelectedInputsUnchanged:true,productionCatalogueHydration:false,fullResearchSnapshot:false,fullReportRun:false,limitations:'Selected-core fixture only; feature/history arrays deliberately empty. Full composed snapshot, report and consumer checks remain separate.',selectedAfterRows:after.map(v=>({id:v.id,availability:v.availability,price:v.facts.price_aud.value,priceGrade:v.facts.price_aud.buyerGrade,buyerAvailability:buyerAvailabilityText(v)}))};
fs.writeFileSync(out+'/selected-core-check-receipt.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
fs.writeFileSync(out+'/selected-core-after.json',JSON.stringify(after,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result,null,2));
