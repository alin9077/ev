import json,pathlib,hashlib
base=pathlib.Path('/tmp/leapmotor-research');out=pathlib.Path('/tmp/leapmotor-packet/reconciliation-v2')
census=json.load(open(base/'census-review-v2.json'));sources=json.load(open(base/'source-index-review-v2.json'))['sources'];cars=json.load(open('/tmp/leapmotor-staging/v4-timeout/output/selected-after-cars.json'))
def urls(*keys):return [sources[k]['url'] for k in keys]
notes=[
 'Leapmotor Australian Tier 1 BEV research checked 15 October 2026. Four complete current manufacturer model/body cohorts contain nine exact named versions: B05 MY26 Style and Design LR; B10 MY26 BEV Style and Design LR; current C10 Style, Design LR and AWD Sports+ Special Edition; B03X Style and Design LR. A separately evidenced MY25 C10 Design residual-new advertisement is the tenth catalogue identity, outside these current official cohorts.',
 'Current maker cohort reviews do not certify that older residual-new versions, unconfirmed global names or distinct future model leads have been exhausted. Formal MY26 applies only to the printed B05/B10 maker guides; C10 current/AWD and B03X keep null formal model years. BEVs remain distinct from range-extender hybrids.',
 census['independentListLimit'],
 'C1 includes three explicitly advertised pre-order versions: B03X Style, B03X Design LR and C10 AWD Sports+. They stay announced/provisional and outside the seven-version on-sale coverage/ranking denominator. The narrow reporter predicate requires an explicit order token, a current valid availability review and usable cited sources. Mere arrival timing does not create C1 eligibility.',
 'November 2026 is the advertised B03X dealership arrival, not a customer-delivery promise. Factory-order acceptance and physical stock remain unverified for all ten versions. MY25 C10 Design is a specific dealer-advertised New Car, not proof of physical possession or the complete residual-new range nationwide.',
 'Published 30–80% charging times remain source-scoped and do not fill strict 10–80% coverage; ten separate two-source searches retain 10–80% Not published facts. Maker B05/AWD MSRP with unknown on-road treatment remains supplemental; selected before-on-road secondary prices remain Reported and unranked. B05 towing preserves the Reported 750 kg braked value and CarsGuide 0 kg/no-towing conflict, with no inferred ATM/GTM basis.',
 *['Excluded candidate: '+x['candidate']+'. '+x['reason']+' Sources: '+', '.join(urls(*x['sourceKeys'])) for x in census['excluded']],
 *['Unresolved candidate: '+x['candidate']+'. '+x['reason']+' Sources: '+', '.join(urls(*x['sourceKeys'])) for x in census['unresolvedCandidates']],
 'MY25 C10 Design current-version-list membership remains unresolved: its exact new advertisement supports the residual catalogue identity but is not a complete current maker MY25 range list. MY24 residual and MY26 Design guide candidates are not silently merged, added or declared unavailable.',
 'This reconciliation leaves whole-market C1, residual membership and M1 completion open. It changes no approved packet fact, identity, availability, summary or ranking basis, and authorizes no M2 work or publication.'
]
configs=[
 ('leapmotor_b05_my26','Hatchback',['au-b05','au-b05-guide'],'Current Australian model-page trims and the printed MY26 guide enumerate exactly Style and Design LR. Both are transcribed. The separate B05 Ultra export-development candidate has no confirmed Australian sale version and is outside this current maker list. This current MY26 review does not certify nationwide residual stock.',None),
 ('leapmotor_b10_my26','SUV',['au-b10','au-b10-guide'],'Current Australian model-page trims and printed MY26 guide enumerate Style and Design LR in separate BEV columns. Hybrid EV range-extender columns are excluded. Both complete current BEV grades are transcribed; older MY25 residual-new eligibility remains a separate unresolved candidate.',('B10 BEV','The inherited B10 BEV label denotes the fully electric B10 columns, distinct from Hybrid EV range-extender columns.')),
 ('leapmotor_c10_current','SUV',['au-c10','au-c10-guide','au-c10-awd-guide','au-c10-awd-launch','au-offers'],'The current Australian model page and June guide enumerate regular BEV Style 69.9 kWh and Design LR 81.9 kWh. The separate maker AWD Sports+ Special Edition release/guide and active explicit pre-order offer establish the third current named BEV configuration. All three form the complete current maker cohort. Battery suffixes retain exact existing catalogue scope. MY25 Design residual stock, MY24 residual leads and the MY26 Design guide entry remain outside this current maker cohort and unresolved separately.',('C10 BEV','The inherited C10 BEV label denotes fully electric C10 versions, excluding the separately presented Hybrid EV range-extender configurations.')),
 ('leapmotor_b03x_current','SUV',['au-b03x','au-b03x-launch','au-offers'],'The Australian launch explicitly states two grades, Style and Design LR; the current Australian model page and active maker pre-order offer corroborate both. These are the complete advertised Australian B03X launch grades, retained as provisional but explicitly orderable for C1. The linked global LIFE/Pro/ProMax PDF is not the Australian list. The separately reported B03 hatchback is a distinct unresolved model.',None)
]
reviews=[]
for mid,body,keys,reason,alias in configs:
 cs=[c for c in cars if c['modelId']==mid]
 r=dict(id='m1-leapmotor-2026-10-15-'+mid.replace('_','-'),modelId=mid,brand='Leapmotor',model=cs[0]['model'],bodyStyle=body,vehicleClass='passenger',checkedAt='2026-10-15',officialSourceUrls=urls(*keys),reason=reason,versions=[dict(carId=c['id'],model=c['model'],trim=c['trim'],modelYear=c['year']) for c in cs])
 if alias:r['publishedModelAliases']=[dict(name=alias[0],reason=alias[1],sourceUrls=urls(*keys))]
 reviews.append(r)
ids=['leapmotor-b05','leapmotor-b10-bev','leapmotor-c10-bev','leapmotor-b03x']
resolutions=[dict(kind='record',inventoryId=id,reviewedAt='2026-10-15',outcome='included',modelReviewId=r['id'],reason='The inherited current BEV family is represented by this complete exact manufacturer cohort. '+r['reason'],sourceUrls=r['officialSourceUrls']) for id,r in zip(ids,reviews)]
r=dict(schemaVersion=1,checkedAt='2026-10-15',notes=notes,publishedLists=[],currentVersionReviews=reviews,listResolutions=[],catalogueOnlyDifferences=[],inventoryResolutions=resolutions)
p=out/'m1-leapmotor-market-reconciliation-2026-10-15.json'
with p.open('x') as f:json.dump(r,f,indent=2,ensure_ascii=False);f.write('\n')
print(str(p),p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
