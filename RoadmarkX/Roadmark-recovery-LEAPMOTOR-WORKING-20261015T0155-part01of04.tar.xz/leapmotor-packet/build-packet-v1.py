from pathlib import Path
import json,hashlib,copy
R=Path('/tmp/leapmotor-research');O=Path('/tmp/leapmotor-packet/v1');ID='m1-leapmotor-2026-10-15';DATE='2026-10-15';REVIEWER='Roadmark independently reviewed Australian Leapmotor research'
N=json.load(open(R/'normalized-review-v3.json'));I=json.load(open(R/'source-index-review-v2.json'))['sources'];B={v['id']:v for v in json.load(open(R/'retained-before-cars.json'))}
assert hashlib.sha256((R/'normalized-review-v3.json').read_bytes()).hexdigest()=='ab3a5e9b26873d07dedd7a9fb64932f68a099d0938cb3e6b3221878706115359'
P=dict(schemaVersion=1,id=ID,brand='Leapmotor',reviewedAt=DATE,reviewedBy=REVIEWER,sources=[],models=[],variants=[],versionGuards=[],versionUpdates=[],facts=[],features=[],brandTerms=[],availability=[],summaries=[])
sourcekeys=set()
for v in N['variants']:
 for f in [*v['coreFacts'].values(),*v['extraFacts'].values()]:sourcekeys.update(f['sourceKeys'])
 sourcekeys.update(v['availability']['sourceKeys'])
sourcekeys.add('current-c10-brochure-index')
sourcekeys=sorted(sourcekeys)
def sid(key):return ID+'-'+key
for key in sourcekeys:
 s=I[key];url=s['url'];maker=key.startswith('au-') or key=='residual-c10-guide'
 publisher='Leapmotor Australia' if maker else ('CarExpert' if 'carexpert.com.au' in url else 'Carsales' if 'carsales.com.au' in url else 'CarsGuide' if 'carsguide.com.au' in url else 'Artarmon Leapmotor' if 'artarmon' in url else 'Brighton Leapmotor')
 title={'au-b05-guide':'Australian MY26 B05 buyers guide, June 2026','au-b10-guide':'Australian MY26 B10 buyers guide, June 2026','au-c10-guide':'Australian current C10 buyers guide, June 2026','residual-c10-guide':'Australian printed MY25 C10 buyers guide, April 2026','au-c10-awd-guide':'Australian C10 AWD Sports+ technical sheet','au-b03x-launch':'Australian B03X launch and exact Style / Design LR pricing, 6 October 2026','au-b05-launch':'Australian B05 launch and exact MSRP table, 1 July 2026','au-c10-awd-launch':'Australian C10 AWD Sports+ launch and MSRP, 24 March 2026','au-warranty':'Leapmotor Australia vehicle and high-voltage battery warranty terms','current-c10-brochure-index':'Brighton Leapmotor current Australian brochure links'}.get(key,key.replace('-',' ').title())
 published={'au-b03x-launch':'2026-10-06','au-b05-launch':'2026-07-01','au-c10-awd-launch':'2026-03-24'}.get(key)
 row=dict(id=sid(key),url=url,title=title,publisher=publisher,source_type='manufacturer_au_publication' if maker else ('dealer_advertisement' if key.startswith('residual-c10-design') else 'dealer_brochure_index' if key=='current-c10-brochure-index' else 'secondary_australian_motoring_publication'),published_date=published,accessed_date=DATE,market='AU',supports=title,retrievalMethod='Fresh public read-only HTTP capture; retained raw response and extracted text',capture_locator='leapmotor-research/'+Path(s['rawPath']).name,capture_sha256=s['rawSha256'],retainedCaptures=[dict(locator='leapmotor-research/'+Path(s['rawPath']).name,sha256=s['rawSha256'],bytes=s['rawBytes'],purpose='Raw public source'),dict(locator='leapmotor-research/'+Path(s['textPath']).name,sha256=s['textSha256'],bytes=Path(s['textPath']).stat().st_size,purpose='Extracted source text')])
 if key=='au-c10-guide':row['authority_provenance']='Printed manufacturer Australian guide; exact URL linked from the freshly captured Brighton Leapmotor brochure index. Underscore c10_ebrochure.pdf is distinct from residual hyphen c10-ebrochure.pdf.'
 P['sources'].append(row)
S={s['id']:s for s in P['sources']}
labels=dict(price_aud='Listed price',range_km='Claimed WLTP range',battery_kwh='Published battery capacity',dc_peak_kw='Peak vehicle DC acceptance',dc_charge_time_min='Published DC charging duration',ac_kw='On-board AC maximum',seats='Seats',boot_l='Published rear storage',zero_to_100_s='0–100 km/h',power_kw='Motor power',drive='Drive type',length_mm='Length',width_mm='Width',height_mm='Height',towing_braked_kg='Braked towing',warranty='Vehicle warranty',battery_warranty='Battery warranty',dc_10_80_min='10–80% DC charging time',promotional_driveaway_aud='Current conditional driveaway offer',maker_msrp_aud='Maker MSRP · on-road treatment not stated')
def makefact(n,v,shared=False):
 k=n['key'];ids=[sid(x) for x in n['sourceKeys']];g=n['buyerGrade']
 reason=('Exact Australian manufacturer source establishes the named value and stated measurement window/basis. ' if g=='confirmed' else 'Exact Australian maker offer with the stated paint, buyer and delivery eligibility. ' if g=='check' else 'Exact Australian secondary report retained with source label and no ranking promotion. ' if g=='reported' else 'Two distinct sources searched; exact 10–80% duration not found while the different 30–80% window remains published. ')+n['locator']
 if shared:reason='Current Australian manufacturer brand warranty terms; exact-version guides/launch materials corroborate applicability to the ten named 2025-and-later configurations.'
 f=dict(key=k,label=labels[k],value=n['value'],unit=n['unit'],basis=n['basis'],comparisonBasis=n['comparisonBasis'],status=n['status'],sourceIds=ids,date=DATE,market='AU',scope='Leapmotor Australian vehicle / high-voltage battery warranty terms; explicitly reviewed named-version applicability' if shared else v['scope'],qualifications=[n['locator'],*n['qualifications']],issues=[],buyerGrade=g,gradeReview=dict(reviewedAt=DATE,overlayId=ID,reason=reason,evidenceScope=n['evidenceScope'],sourceIds=ids,sourceLabel=' / '.join(dict.fromkeys(S[x]['publisher'] for x in ids))),resolvedElsewhere=g=='reported')
 if g=='check':f['conditionExplanation']=n['conditionExplanation']
 if k in ['price_aud','promotional_driveaway_aud']:
  pe=copy.deepcopy(n['priceEvidence']);key=pe['sourceKey'];pe['sourceKey']=k;pe['sourcePointer']=I[key]['url']+' | '+pe['sourcePointer']
  pe['basisTag']=('Maker’s list price · before on-road costs' if pe['rung']==1 else 'Maker’s national driveaway offer' if pe['rung']==2 else 'Dealer ad · NSW driveaway' if pe['rung']==6 else 'Reported by '+S[sid(key)]['publisher']+' · before on-road costs')
  if pe['rung']>=5:pe['publisher']=S[sid(key)]['publisher']
  if 'offerEnd' in pe:f['validUntil']=pe.pop('offerEnd')
  if 'offerStart' in pe:f['qualifications'].append('Offer starts '+pe.pop('offerStart'))
  f['priceEvidence']=pe
 return f
models=[json.loads(l) for l in Path('/tmp/mercedes-staging-plan/staging-preparation/staging-artifacts/canonical-v1/raw-research-models.jsonl').read_text().splitlines() if l]
modelids={x['id'] for x in models};normalizedfacts={}
for v in N['variants']:
 vid=v['id'];old=B.get(vid);new=not old;modelid=old['modelId'] if old else 'leapmotor_b03x_current' if v['model']=='B03X' else 'leapmotor_c10_my25' if v['formalModelYear']==2025 else 'leapmotor_c10_current'
 generation=old['generation'] if old else 'Australian B03X Style / Design LR launch, October 2026; formal model year not stated' if v['model']=='B03X' else 'Printed MY25 Australian C10 guide; exact MY25 dealer-linked residual new listing' if v['formalModelYear']==2025 else 'Australian C10 AWD Sports+ Special Edition; formal model year not printed'
 if modelid not in modelids:
  P['models'].append(dict(id=modelid,brand='Leapmotor',model=v['model'],generation=generation,family_id='leapmotor-'+v['model'].lower()));modelids.add(modelid)
 if old:P['versionGuards'].append(dict(variantId=vid,before={k:old.get(k) for k in ['id','modelId','brand','model','trim','year','generation','vehicleClass','drive']}))
 else:
  P['variants'].append(dict(id=vid,model_id=modelid,brand='Leapmotor',model=v['model'],trim=v['trim'],model_year=v['formalModelYear'],record_state=v['availability']['recordState'],variant_review_date=DATE,source_ids=[sid(k) for k in v['availability']['sourceKeys']],notes=[],price_basis='',range_cycle='',price_aud=None,range_km=None,seats=None,vehicle_class='passenger',drive=v['coreFacts']['drive']['value'],brand_update_generation=generation))
 nf={k:makefact(f,v) for k,f in {**v['coreFacts'],**v['extraFacts']}.items()};normalizedfacts[vid]=nf
 for k,f in nf.items():
  if k in ['warranty','battery_warranty']:continue
  P['facts'].append(dict(variantId=vid,before=copy.deepcopy(old['facts'].get(k)) if old else None,after=f))
 a=v['availability'];e=dict(checkedAt=DATE,orderStatus=a['orderStatus'],stockStatus=a['stockStatus'],sourceIds=[sid(k) for k in a['sourceKeys']],physicalStockVerified=False,factoryOrderAcceptanceVerified=False,qualifications=a['qualifications'],configuration=v['scope'])
 if a.get('expectedDelivery'):e['expectedDelivery']=a['expectedDelivery']
 before=dict(availability=old['availability'],evidence=copy.deepcopy(old['availabilityEvidence'])) if old else dict(availability=a['recordState'],evidence=dict(checkedAt=DATE,orderStatus='unverified',stockStatus='unverified',sourceIds=[sid(k) for k in a['sourceKeys']],qualifications=['Physical stock and factory-order acceptance have not been verified.']))
 P['availability'].append(dict(id=ID+'-availability-'+vid,variantId=vid,before=before,after=dict(availability=a['recordState'],evidence=e),status='approved',reviewedBy=REVIEWER,reviewedAt=DATE,evidenceDate=DATE,reason='Fresh exact Australian maker listing, pre-order offer or explicitly scoped dealer-new advertisement; evidence states are preserved without a physical-stock inference.'))
 summary=dict(variantId=vid,conditions=[])
 for name,clause in v['summary'].items():summary[name]=dict(label=clause['label'],text=clause['text'],dependencies=[dict(key=k,expected=copy.deepcopy(nf[k])) for k in clause['dependencies']])
 P['summaries'].append(summary)
for k in ['warranty','battery_warranty']:
 shared=makefact(N['variants'][0]['coreFacts'][k],N['variants'][0],True)
 P['brandTerms'].append(dict(key=k,fact=shared,applicableVariantIds=[v['id'] for v in N['variants']],before={v['id']:copy.deepcopy(B[v['id']]['facts'].get(k)) if v['id'] in B else None for v in N['variants']},exceptions=[]))
assert len(P['versionGuards'])==6 and len(P['variants'])==4 and len(P['facts'])==165 and len(P['brandTerms'])==2
for name,obj in [('leapmotor-2026-10-15.json',P)]:
 b=(json.dumps(obj,indent=2,ensure_ascii=False)+'\n').encode();(O/name).write_bytes(b);print(name,len(b),hashlib.sha256(b).hexdigest())
receipt=dict(status='bounded_packet_assembled_pending_actual_function_validation',normalizedPath=str(R/'normalized-review-v3.json'),normalizedSha256=hashlib.sha256((R/'normalized-review-v3.json').read_bytes()).hexdigest(),packetPath=str(O/'leapmotor-2026-10-15.json'),packetSha256=hashlib.sha256((O/'leapmotor-2026-10-15.json').read_bytes()).hexdigest(),sources=len(P['sources']),models=len(P['models']),newVariants=len(P['variants']),existingGuards=len(P['versionGuards']),specificFactUpdates=len(P['facts']),sharedBrandTerms=2,effectiveTermCells=20,availability=10,summaries=10,equipmentUpdates=0,versionUpdates=0,baselineStatus='Selected six unchanged cars reused from accepted derived canonical chain; not fresh production capture.',productionSourceEdits=False,productionCatalogueHydration=False,priorSourceRecordsChanged=False)
(O/'assembly-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
