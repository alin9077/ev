# Leapmotor M1 update - draft pending test/lint terminals and phone screenshots

## What changed for a buyer
- Ten exact Australian Leapmotor versions now have sourced facts and a useful strength and trade-off. The review adds B03X Style and Design LR, C10 AWD Sports+ and a separately advertised residual MY25 C10 Design.
- B03X and AWD Sports+ show “Order open or arriving”. B03X’s November timing is the maker’s expected dealership arrival; physical stock and customer delivery remain unconfirmed.
- Prices keep their published on-road bases. Unknown-basis maker MSRP remains visible separately; reported prices and unresolved towing comparisons do not gain ranking eligibility.
- Published 30–80% charging times remain useful and labelled. All ten exact 10–80% times remain Not published after two-source searches; older and global candidates remain explicit open questions.

## Coverage report
From the fresh registered normal coverage CLI, checked 15 October 2026:

| Tier 1 on-sale versions | Price | Range | Battery | DC time | Seats | Boot | Warranty | Strength + trade-off | In rankings |
|---|---|---|---|---|---|---|---|---|---|
| 305 | 84.9% / 33.4% | 89.5% / 61.0% | 98.4% / 78.0% | 78.7% / 41.3% | 91.8% / 68.9% | 84.9% / 69.2% | 100.0% / 95.7% | 99.7% | 6.9% |

Cells are filled / earned Confirmed. Strict core gaps: 401. Reviewed on-sale core cells: 4,832/5,185. C1 now records 84 exact current model-list reviews, including four Leapmotor cohorts with nine current versions. Global independent-list closure and the residual MY25 C10 membership remain open. The report retains 245 C1 blockers; it now also exposes ten supported preorder versions in other brands rather than omitting them from C1 checks. No brand is yet coverage-qualified across all six criteria. Research-completed brands remain BYD, GAC, Geely, IM, Jaecoo, Kia, MG, Tesla, Toyota and Zeekr; 46 remain, including Leapmotor. The current report has 23 unmatched audit models and 27 unresolved leads; retain the detailed normal report as the attachment.

## Three phone screenshots
Pending. Suggested views: B03X preorder detail and arrival qualification; B05 selected price plus supplemental maker MSRP; MY25 C10 residual-new availability and exact source. Do not describe screenshots or mobile checks as passed until captured from the registered source.

## What did not work
The first staged verification stopped on existing optional undefined feature fields during JSON transport checking. A selected diagnostic established the exact 54 affected paths; strict checks remain elsewhere. The next attempt reached the full report but exceeded its 180-second limit. With the reviewed bounded timeout, the unchanged full stage passed in 174.53 seconds. Ten narrow C1 eligibility tests subsequently passed. Fresh registered structural validation and the complete normal coverage run passed, with all 500 scoped inputs unchanged in each run. The 11-file relevant test command reached 264 passing tests, but the brand-added-detail child was SIGKILLed with no completed subtest results or assertion-error details. Its cause is unestablished, and the aggregate command is not a pass. The exact file is being rerun alone without source changes; that result and lint remain pending. A full suite, build, TypeScript and mobile pass are not claimed.

## Decisions needed
None for the approved M1 work. M2 remains paused for the user’s go-ahead. Whole-market independent-list closure and the remaining residual-version questions stay open.
