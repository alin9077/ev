# Leapmotor M1 research — 15 October 2026

## Result

Ten exact Australian BEV versions are ready for the staged packet: six retained versions refreshed and four additions. The ten versions have 170 reviewed canonical core cells: 139 Confirmed and 31 Reported. Ten separate 10–80% charging-time facts are genuinely Not published after two-source checks; the maker's different 30–80% durations remain visible. This is research and selected-function validation, not registration or a completed milestone report.

| Version | Selected price | Price source / basis | Availability evidence |
|---|---:|---|---|
| B03X Style | $26,990 | Maker list, before on-road costs | Maker advertises pre-order; dealerships expected November 2026 |
| B03X Design LR | $30,990 | Maker list, before on-road costs | Maker advertises pre-order; dealerships expected November 2026 |
| B05 Style MY26 | $35,888 | Reported by CarExpert, before on-road costs | Current maker listing |
| B05 Design LR MY26 | $39,888 | Reported by CarExpert, before on-road costs | Current maker listing |
| B10 Style MY26 BEV | $37,888 | Reported by CarExpert, before on-road costs | Current maker listing |
| B10 Design LR MY26 BEV | $40,888 | Reported by CarExpert, before on-road costs | Current maker listing |
| C10 Style 69.9 kWh | $45,888 | Reported by CarExpert, before on-road costs | Current maker listing |
| C10 Design LR 81.9 kWh | $49,888 | Reported by CarExpert, before on-road costs | Current maker listing |
| C10 AWD Sports+ | $53,888 | Reported by CarExpert, before on-road costs | Maker advertises pre-order; no current delivery date established |
| C10 Design 69.9 kWh MY25 | $46,888 | Reported Artarmon NSW dealer driveaway example | Exact new-car advertisement; physical stock and factory ordering unverified |

Reported prices remain unranked. The B05 and AWD maker MSRP observations remain separate Confirmed figures with their unknown on-road treatment stated, also unranked. B03X has separately retained conditional national driveaway offers of $29,990/$33,990 through 31 December, with paint, buyer and delivery eligibility. No expired B05 Design LR campaign is extended and no $0-on-roads offer is converted into an invented total.

## Important distinctions

- B10/C10 Hybrid EV columns are range-extender versions and are excluded from the BEV packet
- B03X's linked global PDF uses different trim names and conflicting drivetrain/cargo information; exact Australian launch/model sources control the Australian rows
- B05 towing is Reported 750 kg braked from exact CarExpert records, with CarsGuide's 0 kg conflict explicitly retained; no towing recommendation or ranking promotion follows
- C10 AWD body/cargo/towing facts come from the exact Sports+ Carsales record at Reported grade, not inherited RWD maker data
- Residual MY25 identity is bound by a dealer card explicitly naming MY25 and linking the exact live stock 4L114074, corroborated by the printed MY25 maker guide
- Formal MY remains unset for B03X and current C10/AWD; filenames and secondary headline years are insufficient
- Boot protocols and gross/usable battery distinctions are not invented. Labelled values remain visible with no comparable basis where unspecified
- Seats are Reported for all ten versions because examined maker material does not provide an explicit seat-count row. All seven proposed on-sale prices are Reported; this explains the low Confirmed share for those core fields rather than chasing a grade quota

## Still open

Whole-market C1 reconciliation remains open. Residual B10 MY25, C10 MY24 and C10 MY26 Design entries are not closed from historic guides alone. B03 hatchback certification, B05 Ultra, B01, D19, T03 and C16 are retained as unresolved/local-unconfirmed candidates where appropriate, without inventing exact sale versions or national absence claims.

## Verification boundary

Final normalized research: `normalized-review-v5.json`; census and captured-source index: `census-review-v2.json`, `source-index-review-v2.json`. Earlier versions remain immutable, with explicit amendment ledgers. Packet v3 has 35 new dated sources, four added versions, six identity guards, 165 specific fact writes, two shared warranty terms, ten availability updates and ten two-clause summaries. No equipment expansion, existing identity change, validator change or UI change is included.

The selected actual prepare/apply fixture passes on six retained cars plus four additions, including all 185 earned packet fact cells and the real seven On sale now / three Order open or arriving buyer labels. Complete composed staging, original full report, real detail/citation/portable outputs, root registration and fresh registered validation remain separately gated.
