from pathlib import Path
import json,hashlib,copy
from collections import Counter
P=Path('/tmp/leapmotor-research')
r=json.load(open(P/'normalized-review-v1.json'));c=json.load(open(P/'census-review-v1.json'));s=json.load(open(P/'source-index-review-v1.json'))
r['schema']='leapmotor-normalized-research-review-v2';r['previousVersion']='normalized-review-v1.json';r['censusPath']=str(P/'census-review-v2.json');r['sourceIndexPath']=str(P/'source-index-review-v2.json')
for v in r['variants']:
 if v['availability']['recordState']=='announced_or_provisional':v['availability']['recordState']='announced_provisional'
 if v['model']=='B05' or v['trim']=='AWD Sports+ Special Edition':
  f=v['coreFacts']['price_aud'];maker=copy.deepcopy(f);maker['key']='maker_msrp_aud';maker['basis']='Manufacturer MSRP; on-road treatment not stated';maker.pop('priceEvidence');v['extraFacts']['maker_msrp_aud']=maker
  key=('secondary-b05-style' if v['trim']=='Style' else 'secondary-b05-lr-carexpert') if v['model']=='B05' else 'secondary-c10-sports'
  f.update(buyerGrade='reported',status='conditional',basis='Reported by CarExpert; before on-road costs',comparisonBasis='Before on-road costs',sourceKeys=[key],locator='Exact-version introductory price sentence explicitly says before on-road costs',evidenceScope='secondary_or_sibling',qualifications=['Exact-version Australian secondary price. Separate maker MSRP remains visible without an invented on-road basis. No current exact-version maker driveaway/configurator/state amount established in the checked maker material.'],rankingEligible=False)
  f['priceEvidence']=dict(rung=5,basisTag='Reported by CarExpert · before on-road costs',originalBasis='Prices starting at the stated amount before on-road costs',sourceKey=key,sourcePointer='Exact-version introductory price sentence',publisher='CarExpert',rankingEligible=False)
 if v['model']=='B05':
  v['coreFacts']['towing_braked_kg']['sourceKeys'].append('secondary-b05-carsguide')
  v['summary']['tradeoff']['label']='Luggage fit'
 if v['model']=='B10':
  v['summary']['tradeoff']=dict(label='Charging window',text='The quoted 20-minute DC stop covers 30–80%; an exact 10–80% time is not published in the checked sources.',dependencies=['dc_charge_time_min','dc_10_80_min'])
 if v['model']=='C10' and v['trim']=='Design LR 81.9kWh':
  v['summary']['tradeoff']['text']='At 4,739 mm long, check the fit of your garage and parking space.'
r['reviewNotes'][2]='B05 and AWD maker MSRP observations remain separate visible Confirmed maker_msrp_aud facts with empty comparison basis. Exact-version CarExpert before-on-road prices become canonical Reported rung5 amounts. No validator relaxation or false rung1 classification.'
r['gradeCounts']=dict(Counter(f['buyerGrade'] for v in r['variants'] for f in v['coreFacts'].values()))
c['independentListLimit']='CarsGuide lists four current model families: B03X, B05, B10 and C10. Its older-model section lists D19. CarExpert lists B03X/B05/B10/C10 plus D19/T03 and warns that global or future names are not necessarily Australian on-sale vehicles. These two brand-level pages do not close separate whole-market C1 reconciliation.'
for x in c['unresolvedCandidates']:
 if x['candidate']=='T03 / C16 global models':
  x.update(candidate='T03 / C16 global models',reason='T03 appears in the CarExpert brand index, which explicitly warns against treating global/future nameplates as current AU on-sale models. The T03 model page has no exact current AU price/version offer. C16 is absent from inspected AU maker range and these brand indexes; no final national absence claim.',sourceKeys=['maker-home','secondary-brand-carexpert','secondary-brand-carsguide','candidate-t03'])
c['unresolvedCandidates'].append(dict(candidate='B03 hatchback',status='AU certification reported; exact sale versions unresolved',reason='CarExpert 27 September reports Australian type approval but says local pricing/specifications were not confirmed. It is distinct from B03X. No current maker AU sale listing or exact named versions established; do not import estimated prices or European sibling battery/range.',sourceKeys=['candidate-b03','maker-home']))
c['scopeBoundary']='No M2, Tier 2, Tier 3, equipment expansion, repository registration or catalogue hydration performed. B03/T03 follow-up only resolves census ambiguity from an already-inspected independent brand index.'
for k in ['candidate-b03','candidate-t03']:s['sources'][k]=json.load(open(P/(k+'-receipt.json')))
notes=dict(previousVersionHashes={n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in ['normalized-review-v1.json','census-review-v1.json','source-index-review-v1.json']},changes=['Correct three unknown-basis maker MSRP ladder selections: canonical exact-version Reported rung5 plus separate visible maker MSRP facts.','Replace B10 generic lab caveat summaries with specific 30–80% charging-window trade-offs.','Correct independent index descriptions; retain T03 and newly noticed B03 candidate honestly unresolved.','Use repository announced_provisional availability token.','Include conflicting CarsGuide B05 towing source alongside selected CarExpert report.','Make B05 luggage and C10 parking copy fact-specific without loose comparisons.'],productionSourceEdits=False)
for name,obj in [('normalized-review-v2.json',r),('census-review-v2.json',c),('source-index-review-v2.json',s),('review-v2-amendments.json',notes)]:
 data=(json.dumps(obj,indent=2,ensure_ascii=False)+'\n').encode();(P/name).write_bytes(data);print(name,len(data),hashlib.sha256(data).hexdigest())
