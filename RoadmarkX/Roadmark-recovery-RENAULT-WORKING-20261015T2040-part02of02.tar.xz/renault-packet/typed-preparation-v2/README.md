Renault typed preparation v2

Four existing retained Tier 1 rows only. Source review v2 and its independent review receipt are pinned; source amendments are explicit and no reviewed artifact is rewritten. Exact beforeguards cover 92 fact changes, twelve brand-term applications and four availability snapshots. Eight summary clauses use only clean exact after-facts.

Core split: 61 Confirmed, one Check, two Reported, four Not published. Sixty-eight core cells; all four actual 10–80% durations remain gaps. Published 15–80% claims remain separate, including the 30/35-minute Megane disagreement. Megane height remains Check with 1,505/1,500-mm alternatives. Width/cargo/battery basis limitations and Reported price remain separate from confidence.

Twenty-four inherited warranty/roadside component aliases and four drivetrain aliases receive narrow source-backed repairs so current display facts do not contradict the canonical terms/drive facts. Three canonical shared terms remain entered once and inherited only by these four versions. No equipment expansion.

Two current maker lists cover four rows. Scenic settles; inherited Megane remains unresolved for separate MY24 residual applicability. R5 Turbo 3E remains explicitly unresolved in the census/reconciliation notes, without a fabricated inherited ID, admission, stock claim or forced exclusion.

Preparation only. No actual helper/consumer, compiler, tests, full catalogue or runtime execution. Independent review and a separate root execution grant are required for the next selected-consumer stage.
