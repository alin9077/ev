from pathlib import Path
import json,hashlib,re
O=Path('/tmp/renault-packet/selected-preflight-v3');M=Path('/tmp/renault-packet/typed-preparation-v3');R=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def write(name,v):
 with (O/name).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
manifest=json.loads((M/'manifest.json').read_text());assert pin(M/'manifest.json')['sha256']=='06c9dc69640136eb9828d86c91d14392617b39d5c4c61ae951af49353adb1638'
files=set()
for p in manifest['pins']:assert pin(p['path'])==p;files.add(Path(p['path']))
files.add(M/'manifest.json')
review=Path('/tmp/renault-review/typed-preparation-v3-findings-v1.json');assert pin(review)['sha256']=='7066b047124d1699a7e5e04634135e734d73affb29a58ea280891ce4e01df501';files.add(review)
files.update(O.glob('*'));files.update(Path('/tmp/renault-packet/selected-preflight-v2').glob('*'));files.update(Path('/tmp/renault-research/selected-harness-draft-v1').glob('*'));files.update(Path('/tmp/renault-packet/selected-preflight-v1').glob('*'))
files.update(Path(p) for p in ['/tmp/xpeng-staging-plan/baseline-io.mjs','/tmp/mercedes-staging-plan/consumer-preparation/v5/feature-json-parity.mjs','/tmp/cupra-packet/full-stage-v2/output/car-digest-comparison.json','/tmp/renault-research/inherited-inventory-extract-v1.json'])
files.update(R/p for p in ['src/lib/evidence-consumers.ts','src/lib/evidence-regrading.ts','src/lib/launch-evidence.ts','src/lib/portable-packs.ts','src/lib/citable.ts','src/lib/compare.ts','src/lib/discovery.ts','src/lib/market-inventory-data.ts','scripts/reporting/reports.ts','scripts/reporting/m1-reconciliation.ts','tests/helpers/compiled-source.ts','src/lib/brand-update-registry.ts','tsconfig.json','data/m1-evidence-regrading-2026-10-13.json','package.json','pnpm-lock.yaml','data/m1-brand-updates/registry.json'])
registry=json.loads((R/'data/m1-brand-updates/registry.json').read_text());assert len(registry['packets'])==29;assert registry['packets'][-1]=='cupra-2026-10-15.json'
for name in registry['packets']:files.add(R/'data/m1-brand-updates'/name)
anchorsPath=Path('/tmp/mercedes-staging-plan/consumer-preparation/v5/manifests/report-v5.json');storagePath=Path('/tmp/mercedes-staging-plan/staging-preparation/staging-artifacts/canonical-v1/staged-storage-index.json')
files.update([anchorsPath,storagePath]);anchors=json.loads(anchorsPath.read_text())['anchors'];storage=json.loads(storagePath.read_text());assert len(storage['research'])==14
for ref in storage['research'].values():
 root=Path(anchors[ref['anchor']]);p=root/ref['file'];assert p.resolve()==p and p.is_file() and p.is_relative_to(root)
 actual=pin(p);assert actual['bytes']==ref['bytes'] and actual['sha256']==ref['sha256'];files.add(p)
queue=[p for p in files if p.suffix in ['.ts','.tsx','.mts','.mjs'] and (str(p).startswith(str(R)) or p.parent==O)];seen=set()
while queue:
 p=queue.pop()
 if p in seen:continue
 seen.add(p)
 for spec in re.findall(r'''(?:from\s*|import\s*\(?\s*|require\(\s*)["']([^"']+)["']''',p.read_text()):
  if spec.startswith('@/'):root=R/'src'/spec[2:]
  elif spec.startswith(('./src/','./tests/','./scripts/')) and p.parent==O:root=R/spec
  elif spec.startswith('.'):root=(p.parent/spec).resolve()
  elif spec.startswith('/'):root=Path(spec)
  else:continue
  choices=[root,Path(str(root)+'.ts'),Path(str(root)+'.tsx'),Path(str(root)+'.json'),root/'index.ts']
  hit=next((x for x in choices if x.is_file()),None)
  if hit:
   files.add(hit)
   if hit.suffix in ['.ts','.tsx','.mts','.mjs']:queue.append(hit)
write('source-pins.json',[pin(p) for p in sorted(files)])
m=dict(status='prepared_not_executed',script=pin(O/'check.mjs'),sourcePins=pin(O/'source-pins.json'),packet=manifest['candidate'],reconciliation=manifest['reconciliation'],expectedReview=pin(O/'expected-review.json'),wrapper=pin(O/'run.py'),command=['node','--max-old-space-size=448','--max-semi-space-size=1','--import','tsx',str(O/'check.mjs'),'--root-execution-granted'],workdir=str(R),timeoutSeconds=180,killGraceSeconds=10,automaticRetry=False,rootExecutionGrantRequired=True,exclusiveHeavySlotRequired=True,scope='Exactly four retained Renault Tier 1 rows bound to accepted CUPRA29 full-car digests. Actual prepare/apply and exact 4 identity, 92 fact, 12 shared-term and 4 availability guards. 276 complete effective feature claims, 104 earned cells, 68 core cells, four canonical roadside projections; other feature rows unchanged. All fourteen research fields streamed with only selected variant/feature/model rows retained and complete global evidence context. Seven actual intended-rejection/unchanged-input cases; actual C1/current-list and coverage consumers, 150 compareFacts self/pair cases, compatible rankings, four summary pairs, availability/citable and Markdown reports, live/portable/written/hydrated equality with exact producer-owned optional-property witnesses. Megane inventory and R5 Turbo 3E remain open; Tier 2/non-Renault target neutrality only; full-catalogue peer equality is a later gate. No full catalogue, project tsc, tests, live edits, registration, build, server, browser, archive or automatic retry.',currentProjectTypeScript='UNPASSED; no retry')
write('prepared-command.json',m)
write('root-grant-template.json',dict(authorized=False,exclusiveHeavySlotGranted=False,action='run_single_selected_renault_preflight',preparedManifestSha256=pin(O/'prepared-command.json')['sha256'],command=m['command'],automaticRetry=False,note='Template only. Independent readiness review and a separate root exclusive-slot grant are required.'))
print(json.dumps(dict(manifest=pin(O/'prepared-command.json'),sourcePinCount=len(files),executed=False),indent=2))
