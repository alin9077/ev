Renault typed preparation v3

Four retained Tier 1 versions; 92 specific updates plus 12 shared-term applications, 68 core cells (61 Confirmed, one Check, two Reported, four Not published). V2 remains immutable.

The independent review identified that matching empty measurement bases could permit false pair deltas. Explicit unknown basis labels now block battery, cargo and Megane width comparisons; narrow source-supported battery and Megane-width method holds also preserve direct ranking exclusions without disputing their published numbers. Clean dimensions, charge maxima, motor power, acceleration and drive facts now carry their stated bases. The four real 10–80 gaps stay unfilled. Separate 15–80 observations state their exact station/window bases; Megane 30/35-minute disagreement and height disagreement remain Check.

Scenic announcement publication date is retained as 11 March 2026. Exact summary dependencies are rebound to changed basis objects without rewriting prose. Existing beforeguards, identity/availability bounds, warranty terms and C1 open dispositions are unchanged.

Preparation only. Actual helpers/consumers and pair comparisons have not run. Independent typed review, frozen selected readiness and a separate root execution grant remain required.
