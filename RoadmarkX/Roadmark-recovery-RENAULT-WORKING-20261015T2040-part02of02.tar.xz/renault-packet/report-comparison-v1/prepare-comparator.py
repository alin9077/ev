from pathlib import Path
import difflib
B=Path('/tmp/renault-packet/report-comparison-v1')
old=Path('/tmp/kgm-packet/report-comparison-v2/compare-report.mjs').read_text();s=old
s=s.replace('One saved normal report versus accepted MINI27; exact core reasons and selected-only features.','One saved normal report versus accepted CUPRA29; exact core reasons and four selected prior Renault packs.')
s=s.replace("const prep='/tmp/kgm-packet/report-comparison-v2';","const prep='/tmp/renault-packet/report-comparison-v1';").replace("const qa='/tmp/kgm-packet/report-comparison-v2';","const qa='/tmp/renault-packet/report-comparison-v1';")
s=s.replace('/tmp/mini-packet/report-comparison-v2/normal-coverage-asof-2026-10-15/stdout.log','/tmp/cupra-packet/report-comparison-v1/normal-coverage-asof-2026-10-15/stdout.log').replace('0cd717ad3b1db049e14559010770b9b5dfb1e9ed05718ca7635d82a6bbde4464','66006b9e8b78d5078a98bee9418466630bf4962a9554e3e8e5bfeddebb6f1579').replace('exhaustive-normal-versus-mini-diff','exhaustive-normal-versus-cupra-diff')
s=s.replace('/tmp/kgm-packet/selected-preflight-v2/result.json','/tmp/renault-packet/selected-preflight-v5/result.json').replace('/tmp/kgm-research/retained-before-cars.json','/tmp/renault-research/retained-before-cars-v1.json').replace('/tmp/kgm-packet/full-stage-v1/','/tmp/renault-packet/full-stage-v1/')
s=s.replace("const acceptedMiniDigests=readJson('/tmp/mini-packet/full-stage-v2/output/car-digest-comparison.json');","const acceptedCupraDigests=readJson('/tmp/cupra-packet/full-stage-v2/output/car-digest-comparison.json');")
s=s.replace('acceptedMiniDigests','acceptedCupraDigests').replace('acceptedStageDigests.candidate28','acceptedStageDigests.candidate30').replace('acceptedStageDigests.candidate27','acceptedStageDigests.candidate29').replace('acceptedCupraDigests.candidate27','acceptedCupraDigests.candidate29')
s=s.replace("readJson('/tmp/mini-packet/full-stage-v2/output/research-field-digests.json').candidate27.sources","readJson('/tmp/cupra-packet/full-stage-v2/output/research-field-digests.json').candidate29.sources").replace("readJson('/tmp/renault-packet/full-stage-v1/output/research-field-digests.json').candidate28.sources","readJson('/tmp/renault-packet/full-stage-v1/output/research-field-digests.json').candidate30.sources")
s=s.replace('selectedIds.size,3','selectedIds.size,4').replace('base.variants.length,3','base.variants.length,4').replace('base.feature_evidence.length,207','base.feature_evidence.length,276').replace('beforeFeatures.length,207','beforeFeatures.length,276').replace('selectedOldFeatureProducers:207','selectedOldFeatureProducers:276')
s=s.replace('brandUpdatePackets.length,28','brandUpdatePackets.length,30').replace("brandUpdatePackets.at(-1).id,'m1-kgm-2026-10-15'","brandUpdatePackets.at(-1).id,'m1-renault-2026-10-15'").replace('brandUpdatePackets.slice(0,27)','brandUpdatePackets.slice(0,29)')
s=s.replace(" ['candidate27','/tmp/mini-packet/full-stage-v2/output/selected-after-cars.json'],"," ['candidate27','/tmp/mini-packet/full-stage-v2/output/selected-after-cars.json'],\n ['candidate28','/tmp/kgm-packet/full-stage-v1/output/selected-after-cars.json'],\n ['candidate29','/tmp/cupra-packet/full-stage-v2/output/selected-after-cars.json'],")
s=s.replace('length,424','length,426').replace('exactCompletePeerCars:424','exactCompletePeerCars:426').replace('peerCompleteCarDigestsExact:424','peerCompleteCarDigestsExact:426')
s=s.replace('length,427','length,430').replace('size,427','size,430').replace('[427,350,309]','[430,353,312]').replace('length,309','length,312').replace('catalogue:427,tierOne:350,onSale:309','catalogue:430,tierOne:353,onSale:312')
s=s.replace("'KGM'","'Renault'").replace('kgmInventory','renaultInventory').replace('oldKgm','oldRenault').replace('liveKgm','liveRenault').replace('expectedLiveKgm','expectedLiveRenault').replace('newKgm','newRenault').replace('peer and KGM identities','peer and Renault identities')
s=s.replace("!['roadside_assistance','driveaway_price'].includes(f.criterion)","f.criterion!=='roadside_assistance'")
a=s.index('const groupKey=g=>JSON.stringify');b=s.index("assert.deepStrictEqual(peer(normal.gaps)",a)
ranks=r'''const groupKey=g=>JSON.stringify([g.vehicleClass,g.basis,g.unit]);
const discoveryPath=repo+'/src/lib/discovery.ts',discoverySource=fs.readFileSync(discoveryPath,'utf8');
const comparatorText='(a, b) =>\n        b.entries.length - a.entries.length || a.basis.localeCompare(b.basis)';
assert.equal(discoverySource.split(comparatorText).length,2);
const groupOrder=vm.runInThisContext('('+comparatorText+')',{filename:discoveryPath+':actual-group-order-excerpt'});
const {attributes}=require('./src/lib/discovery.ts');
const stageRankings=readJson('/tmp/renault-packet/full-stage-v1/output/global-ranking-comparison.json');
const beforeCarMap=new Map(completeBefore.map(car=>[car.id,car])),afterCarMap=new Map(completeAfter.map(car=>[car.id,car]));
const beforeDigestMap=new Map(acceptedStageDigests.candidate29.map(row=>[row.id,row])),afterDigestMap=new Map(acceptedStageDigests.candidate30.map(row=>[row.id,row]));
const alphabeticalSource='unranked.sort((a, b) =>\n    `${a.car.brand} ${a.car.model} ${a.car.trim}`.localeCompare(\n      `${b.car.brand} ${b.car.model} ${b.car.trim}`,\n    ),\n  );';
assert.equal(discoverySource.split(alphabeticalSource).length,2);
const alphabetical=(a,b)=>{const ac=afterCarMap.get(a.carId),bc=afterCarMap.get(b.carId);return `${ac.brand} ${ac.model} ${ac.trim}`.localeCompare(`${bc.brand} ${bc.model} ${bc.trim}`);};
const rankingBindings=[];
for(const stage of stageRankings){
 const old=stage.completeOrderedBefore,next=stage.completeOrderedAfter,selected=stage.completeSelectedRecords;
 const attribute=attributes.find(row=>row.key===stage.attribute);assert(attribute);
 for(const [phase,records,carMap,digestMap]of [['before',old,beforeCarMap,beforeDigestMap],['after',next,afterCarMap,afterDigestMap],['selected',selected,afterCarMap,afterDigestMap]]){
  for(const row of [...records.groups.flatMap(g=>g.entries),...records.excluded,...records.unranked]){
   assert.deepEqual(row.carDigest,digestMap.get(row.carId));
   if(Object.hasOwn(row,'fact'))assert.deepEqual(row.fact,carMap.get(row.carId).facts[stage.attribute]);
  }
  for(const group of records.groups){
   assert.deepEqual([...group.entries].sort((a,b)=>(Number(a.fact.value)-Number(b.fact.value))*(attribute.direction==='lower'?1:-1)||a.carId.localeCompare(b.carId)),group.entries);
   for(const row of group.entries){
    assert.equal(row.rank,group.entries.findIndex(other=>Number(other.fact.value)===Number(row.fact.value))+1);
    assert.equal(row.tied,group.entries.filter(other=>Number(other.fact.value)===Number(row.fact.value)).length>1);
   }
  }
  rankingBindings.push({attribute:stage.attribute,phase,completeGroups:records.groups.length,completeEntries:records.groups.reduce((n,g)=>n+g.entries.length,0),completeExcluded:records.excluded.length,completeUnranked:records.unranked.length,allCarDigestsAndFactsExact:true,allRankAndTiedFieldsExact:true});
 }
 const buckets=new Map();
 for(const group of old.groups){const entries=group.entries.filter(row=>!selectedIds.has(row.carId));if(entries.length)buckets.set(groupKey(group),{...group,entries});}
 for(const group of selected.groups){const key=groupKey(group),existing=buckets.get(key);if(existing)existing.entries.push(...group.entries);else buckets.set(key,{...group,entries:[...group.entries]});}
 const memberGroup=new Map();for(const [key,group]of buckets)for(const row of group.entries){assert(!memberGroup.has(row.carId));memberGroup.set(row.carId,key);}
 const insertion=[];for(const car of completeAfter){const key=memberGroup.get(car.id);if(key&&!insertion.includes(key))insertion.push(key);}
 const expectedGroups=insertion.map(key=>buckets.get(key));
 for(const group of expectedGroups){group.entries.sort((a,b)=>(Number(a.fact.value)-Number(b.fact.value))*(attribute.direction==='lower'?1:-1)||a.carId.localeCompare(b.carId));group.entries=group.entries.map(row=>({...row,rank:group.entries.findIndex(other=>Number(other.fact.value)===Number(row.fact.value))+1,tied:group.entries.filter(other=>Number(other.fact.value)===Number(row.fact.value)).length>1}));}
 expectedGroups.sort(groupOrder);assert.deepEqual(next.groups,expectedGroups);
 const excludedById=new Map([...old.excluded.filter(row=>!selectedIds.has(row.carId)),...selected.excluded].map(row=>[row.carId,row]));
 assert.deepEqual(next.excluded,completeAfter.filter(car=>excludedById.has(car.id)).map(car=>excludedById.get(car.id)));
 assert.deepEqual(next.unranked,[...old.unranked.filter(row=>!selectedIds.has(row.carId)),...selected.unranked].sort(alphabetical));
 for(const group of old.groups){const nextGroup=next.groups.find(row=>groupKey(row)===groupKey(group));assert.deepEqual(nextGroup?.entries.filter(row=>!selectedIds.has(row.carId)).map(row=>row.carId)??[],group.entries.filter(row=>!selectedIds.has(row.carId)).map(row=>row.carId));}
 assert.deepEqual(next.excluded.filter(row=>!selectedIds.has(row.carId)),old.excluded.filter(row=>!selectedIds.has(row.carId)));
 assert.deepEqual(next.unranked.filter(row=>!selectedIds.has(row.carId)),old.unranked.filter(row=>!selectedIds.has(row.carId)));
}
function projectRecords(records,inputCars){
 const ids=new Set(inputCars.map(car=>car.id)),index=new Map(inputCars.map((car,i)=>[car.id,i]));
 const groups=records.groups.map(g=>({...g,entries:g.entries.filter(row=>ids.has(row.carId))})).filter(g=>g.entries.length);
 groups.sort((a,b)=>Math.min(...a.entries.map(row=>index.get(row.carId)))-Math.min(...b.entries.map(row=>index.get(row.carId))));
 const insertionKeys=groups.map(groupKey);groups.sort(groupOrder);
 return {groups:groups.map(g=>({vehicleClass:g.vehicleClass,basis:g.basis,unit:g.unit,count:g.entries.length})),rankedIds:groups.flatMap(g=>g.entries.map(row=>row.carId)),excluded:records.excluded.filter(row=>ids.has(row.carId)).map(({carDigest,...row})=>row),insertionKeys};
}
const rankingGroupProof=[];
expected.rankings=baseline.rankings.map((old,i)=>{
 const actual=normal.rankings[i],beforeSelected=selectedBefore.rankings[i],afterSelected=selectedAfter.rankings[i],stage=stageRankings.find(row=>row.attribute===old.key);assert(stage);
 assert.equal(actual.key,old.key);assert.equal(beforeSelected.key,old.key);assert.equal(afterSelected.key,old.key);
 const b=projectRecords(stage.completeOrderedBefore,onSaleBefore),a=projectRecords(stage.completeOrderedAfter,onSaleAfter),selectedProjection=projectRecords(stage.completeSelectedRecords,after);
 assert.deepEqual(b.groups,old.groups);assert.deepEqual(b.rankedIds,old.rankedIds);assert.deepEqual(b.excluded,old.excluded);
 assert.deepEqual(selectedProjection.groups,afterSelected.groups);assert.deepEqual(selectedProjection.rankedIds,afterSelected.rankedIds);assert.deepEqual(selectedProjection.excluded,afterSelected.excluded);
 assert.deepEqual(a.excluded,orderedRows([...peer(b.excluded),...afterSelected.excluded],catalogueOrder));
 assert.equal(a.rankedIds.length,old.ranked-beforeSelected.ranked+afterSelected.ranked);
 assert.equal(a.rankedIds.length+a.excluded.length,312);
 const exclusionReasons={};for(const row of a.excluded)exclusionReasons[row.reason]=(exclusionReasons[row.reason]||0)+1;
 fullArrayOrderProof.push({path:'rankings/'+old.key+'/excluded',producer:'Full digest-bound stage exclusions filtered in actual input catalogue order',beforeRows:b.excluded.length,afterRows:a.excluded.length,completeEquality:true});
 rankingGroupProof.push({key:old.key,unchangedPeerMembershipAndRelativeGroupOrder:true,selectedBeforeRanked:beforeSelected.ranked,selectedAfterRanked:afterSelected.ranked,beforeInsertionKeys:b.insertionKeys,afterInsertionKeys:a.insertionKeys,actualProductionGroupComparator:true,completeBeforeAndAfterRecordBindings:true});
 return {...old,ranked:a.rankedIds.length,percent:pct(a.rankedIds.length,312),rankedIds:a.rankedIds,passes:a.rankedIds.length/312>=0.9,groups:a.groups,excluded:a.excluded,exclusionReasons};
});
write('ranking-group-order-and-peer-proof',{sourcePath:discoveryPath,sourceSha256:fileHash(discoveryPath),exactComparatorText:comparatorText,fullStageRecordPath:'/tmp/renault-packet/full-stage-v1/output/global-ranking-comparison.json',fullStageRecordSha256:fileHash('/tmp/renault-packet/full-stage-v1/output/global-ranking-comparison.json'),completeBindings:rankingBindings,groups:rankingGroupProof});
'''
s=s[:a]+ranks+s[b:]
# Current exact candidate and its corrected roadside representation remain bound to accepted selected output.
s=s.replace("assert.equal(selectedIds.size,4);assert.equal(selectedResult.otherRetainedFeaturesUnchanged,true);","assert.equal(selectedIds.size,4);assert.equal(selectedResult.otherRetainedFeaturesUnchanged,true);assert.equal(selectedResult.selectedFeatureClaims,276);assert.equal(selectedResult.packetSha256,'6f89f00f147c45c5e1afdff24f8597da3b980d6f5230cd1ba5fb663754464605');\nfor(const car of after){assert.equal(car.facts.roadside_assistance.value,'5 years');assert.equal(packs[car.id].features.find(row=>row.criterion==='roadside_assistance').value,'5 years');}")
with (B/'compare-report.mjs').open('x') as f:f.write(s)
with (B/'kgm-to-renault-comparator.patch').open('x') as f:f.write(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='/tmp/kgm-packet/report-comparison-v2/compare-report.mjs',tofile=str(B/'compare-report.mjs'))))
print('Prepared comparator only; no runtime executed.')
