"""Metadata-only source retention allowance; no source recapture or payload sweep."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,stat
B=Path('/tmp/renault-packet/source-retention-v1');R=Path('/tmp/renault-research')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
refs=[('/tmp/renault-packet/source-review-v1/manifest.json','pins'),('/tmp/renault-packet/source-review-v2/manifest.json','pins'),('/tmp/renault-packet/typed-preparation-v4/manifest.json','pins'),('/tmp/renault-packet/report-comparison-v4/source-pins.json',None)]
declared={};origins={}
for f,k in refs:
 d=read(f)
 for p in d if k is None else d[k]:
  if not Path(p['path']).is_relative_to(R):continue
  if p['path']in declared:assert declared[p['path']]==p,p['path']
  declared[p['path']]=p;origins.setdefault(p['path'],[]).append(f)
actual=[];excluded=[]
for p in sorted(R.rglob('*')):
 if p.is_dir():continue
 s=p.lstat();assert stat.S_ISREG(s.st_mode)and not p.is_symlink(),str(p)
 if '__pycache__'in p.parts or p.suffix=='.pyc':excluded.append(dict(path=str(p),bytes=s.st_size,mode=s.st_mode,mtimeNs=s.st_mtime_ns,reason='Reconstructible Python bytecode; original source retained',deletionAuthorized=False));continue
 assert str(p)in declared,str(p);x=declared[str(p)];assert x['bytes']==s.st_size;actual.append(dict(**x,mode=s.st_mode,mtimeNs=s.st_mtime_ns,pinOrigins=origins[str(p)],contentHashRecomputedAtThisPreparation=False))
assert len(actual)==75 and {p['path']for p in actual}==set(declared)
images=[]
for stem in ['megane','scenic']:
 base=R/'sources-v1';png=base/(stem+'-dimensions-page2.png');pdf=base/(stem+'-spec.pdf');prov=base/(stem+'-spec-provenance.json');txt=base/(stem+'-spec.txt');v=read(prov);assert v['pdfSha256']==declared[str(pdf)]['sha256']
 images.append(dict(file=declared[str(png)],sourcePdf=declared[str(pdf)],sourceUrl=v['url'],parentProvenance=declared[str(prov)],parentExtractedText=declared[str(txt)],pdfPageNumber=2,pdfZeroBasedPageIndex=1,visibleHeading='01. dimensions',printedPageNumber=None,kind='Existing local public maker PDF page render; not an application, browser or phone screenshot',mappingEvidence='Existing extracted text page 2 starts with 01. dimensions and matches the displayed boot declaration. Both existing image pixels were inspected on 2026-10-15; page numbering here is PDF order, not an invented printed page label.',newRenderingPerformed=False))
x=dict(schemaVersion=1,status='frozen_metadata_allowlist_pending_independent_review',preparedAt=datetime.now(timezone.utc).isoformat(),sourceRoot=str(R),sourcePins=actual,allowlistedResearchFiles=75,sourceReviewV2ResearchFiles=sum(Path(p['path']).is_relative_to(R)for p in read(refs[1][0])['pins']),additionalAcceptedPreparationFiles=8,sourceRole='Union of sanitized public source captures, original and corrected extracted facts, retained before-state, and accepted preparation scripts. Inclusion does not relabel held facts as current.',authoritativeManifests=[pin(f)for f,k in refs],sourceImages=images,publicPdfDocuments=2,rawRuntimeExclusion=dict(rawRuntimeHTMLOrConfigurationPersisted=False,rawResponseHeadersOrCookiesPersisted=False,credentialOrClientKeyPayloadPersisted=False,locallyPresentExcludedOriginalPaths=[],basis='Public capture source implementation and per-source no-value provenance declare that runtime scripts/config are discarded in memory before visible-text persistence. Raw response headers/cookies/client keys were not saved by that flow. This metadata preparation is not an independent privacy scan.',readRefetchOrRecoveryAuthorized=False),captureImplementation=declared[str(R/'capture-public-v1.py')],excludedPathsOrClasses=excluded+[dict(path='raw runtime HTML/configuration, response headers, cookies, credentials, tokens and client/API key payloads',reason='Excluded data classes; do not refetch, reconstruct or copy',deletionAuthorized=False)],metadataOnly=True,payloadHashSweepPerformed=False,payloadCopyOrCompressionPerformed=False,privacyScanClaim=False,productBrowserOrPhoneScreenshots=0,newSourceCaptureAuthorized=False,sourceFilesUnmodified=True,heldHistoryPolicy='Retain sources-v1 and sources-v2 plus all correction/preparation scripts and source/typed review history; none of the old reviewed bytes is overwritten by this allowance.',preparer=pin(__file__))
with(B/'manifest.json').open('x')as f:json.dump(x,f,indent=2,ensure_ascii=False);f.write('\n')
print(json.dumps(dict(manifest=pin(B/'manifest.json'),allowlistedFiles=75,sourceImages=2,excludedReconstructibleFiles=len(excluded)),indent=2))
