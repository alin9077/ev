# Renault light source/identity review v1

Four existing Tier 1 rows, no live edits or additions. Read candidate-facts.json, identity-review.json, brand-terms.json and conflicts-and-history.json. The exact retained four-car baseline is /tmp/renault-research/retained-before-cars-v1.json and its accepted-CUPRA29 digest proof is retained-selection-proof-v1.json.

Core source observations: 68 reviewed, 64 filled, four 10–80% gaps; proposed split 61 Confirmed, one Check, two Reported, four Not published. Actual production report outcomes are untested. Three Scenic maker prices are explicit before ORC. Megane uses Reported current-guide A$54,990 before-ORC fallback, not the expired A$49,990 driveaway campaign or MY24 seller price.

Width figures and declared minimum boot litres remain visible with precise unknown/folded-mirror/method scope; they must not acquire unsupported exclusion-of-mirrors or VDA/SAE ranking bases. Exact named-grade WLTP ranges remain Confirmed. The Megane currently linked PDF versus model-page 15–80% discrepancy is separate from true 10–80% gaps.

R5 Turbo3E's official reservation headline versus July fully-pre-sold report remains unresolved. The MY24 seller-specific New advertisement remains separate because its technical epoch applicability is unproven. No physical stock, order acceptance, final release, full-project TypeScript or M1 completion is claimed.

All files in this version must be immutable after review. Revisions go in new versioned paths. Public fetch failures and successful later web-tool factual extracts remain separately labelled. No runtime payload, credential, key, cookie or raw header was retained.
