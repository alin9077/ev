Renault typed preparation v4

Seven exact JSON pointer changes from independently reviewed v3: shared roadside assistance is written as “5 years” with empty unit so the existing canonical feature projection carries the unit; its repeated text-tool research narration is replaced by buyer-facing guidance in the shared term and four numeric roadside_years aliases. Those aliases retain value 5 and unit years. Duration, grades, conditions/limits, dates and sources are otherwise unchanged.

The prior selected actual-consumer v4 execution passed its technical checks and remains preserved, but independent output review withheld integration because that candidate showed roadside assistance as “5”. The corrected candidate needs independent static acceptance and a new frozen selected run. No live edit, helper change, runtime replay or compiler retry has occurred.
