"""Seal metadata-only Renault30 retention cut after exact documentary readback."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,os,stat
B=Path('/tmp/renault-packet/final-freeze-v1');W=Path('/workspace/scratch/586427eef9f2');REV=Path('/tmp/renault-review')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);assert p.is_file()and not p.is_symlink();h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def row(p,category):
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode)and not p.is_symlink(),str(p)
 return dict(path=str(p),category=category,bytes=s.st_size,mode=s.st_mode,mtimeNs=s.st_mtime_ns,kind='file')
out=B/'inventory.json';assert not out.exists()
readback=REV/'docs-status-v5-live-readback-v1.json';assert read(readback)['status']=='accepted'
final=REV/'final-retention-v1-accepted.json';assert not final.exists()
sourcePath=Path('/tmp/renault-packet/source-retention-v1/manifest.json');source=read(sourcePath);assert len(source['sourcePins'])==75
sourceAllowance=read(REV/'source-retention-v1-readiness-v1.json');assert sourceAllowance['status']=='accepted_metadata_allowlist_only'and sourceAllowance['manifest']==pin(sourcePath)
sourcePins={x['path']:x for x in source['sourcePins']};rows=[];excluded=[];seenSources=set()
roots=[('/tmp/renault-research','sanitized_public_source_and_preparation_history'),('/tmp/renault-packet','packet_qa_and_all_attempt_history'),('/tmp/renault-review','independent_reviews')]
for root,category in roots:
 for cur,dirs,files in os.walk(root,followlinks=False):
  dirs.sort();files.sort()
  if Path(cur)==B:dirs[:]=[];continue
  assert not any((Path(cur)/d).is_symlink()for d in dirs),'Unexpected directory symlink'
  for name in files:
   p=Path(cur)/name;reason=None
   if str(p)=='/tmp/renault-packet/post-registration-checks-v6/.exclusive-heavy.lock':assert p.lstat().st_size==0;reason='Empty terminal exclusive-slot lock; not reconstruction data'
   elif p.suffix=='.pyc'or'__pycache__'in p.parts:reason='Reconstructible Python bytecode; sources retained'
   if reason:excluded.append(dict(**row(p,'excluded_reconstructible'),reason=reason,deletionAuthorized=False));continue
   item=row(p,category)
   if p.is_relative_to('/tmp/renault-research'):
    assert str(p)in sourcePins,('Research path outside exact allowance',str(p));declared=sourcePins[str(p)]
    assert all(item[k]==declared[k]for k in ['bytes','mode','mtimeNs']);item['declaredSha256']=declared['sha256'];item['contentHashRecomputedAtFreeze']=False;seenSources.add(str(p))
   rows.append(item)
assert seenSources==set(sourcePins)
reg=read('/tmp/renault-packet/registration-v1/manifest.json');docs=read('/tmp/renault-packet/docs-status-v5/manifest.json');live=[]
for item in reg['writes']+docs['writes']:
 p=pin(item['target']);assert p['bytes']==item['after']['bytes']and p['sha256']==item['after']['sha256'];live.append(p);rows.append(row(item['target'],'live_registered_documentary_target'))
assert len(live)==8 and len({x['path']for x in rows})==len(rows);rows.sort(key=lambda x:x['path'])
state=read(W/'roadmark-104-qa/work-status.json');assert state['currentBrand']=='Renault'and not state['renaultWorking']['fullProjectTypecheckPassed']and not state['renaultWorking']['releaseReady']and not state['renaultResearchStatus']['researchCompleted']
assert state['renaultWorking']['coverage']['catalogue']==430
report=read('/tmp/renault-packet/report-comparison-v4/results-manifest-v1.json');assert report['reportAttemptAccounting']['totalKnownNormalReportInvocations']==2 and report['reportAttemptAccounting']['originalAttemptOutcome']=='UNKNOWN'
original=Path('/tmp/renault-packet/report-comparison-v2/normal-coverage-asof-2026-10-15')
assert not any((original/x).exists()for x in ['terminal.json','result.json','after-pins.json','scope-verification.json'])
assert (original/'stdout.log').stat().st_size==(original/'stderr.log').stat().st_size==0
failure=Path('/tmp/kgm-packet/report-comparison-v2/typescript-failure-provenance.json');fail=read(failure)
preparationFailures=[x['path']for x in rows if Path(x['path']).name in ['preparation-failure-v1.json','preparation-failure.json']]
x=dict(schemaVersion=1,status='author_frozen_metadata_exact_allowlist_pending_independent_final_acceptance_and_backup_capture',frozenAt=datetime.now(timezone.utc).isoformat(),noFurtherPayloadEdits=True,metadataOnlyInventory=True,contentCaptureOrPrivacyScanPerformed=False,inventoryHashScope='Only eight exact live targets and named small receipts/provenance are hashed. All other payload paths are lstat-only.75 research declared hashes come from independently accepted prior manifests. Backup owns separately authorized capture, hashing and privacy scan.',payloadRoots=[r for r,c in roots],files=rows,totalFiles=len(rows),regularFileBytes=sum(x['bytes']for x in rows),symlinkCount=0,sourceAndStatusAfterPins=live,excluded=excluded+[dict(path=str(B),reason='Inventory and preparer pinned separately with future final review to avoid circularity',deletionAuthorized=False)],sourceAllowlist=pin(sourcePath),sourceAllowlistedResearchFiles=75,sourceRole=source['sourceRole'],rawRuntimeExclusion=source['rawRuntimeExclusion'],publicImageProvenance=dict(publicPdfDocuments=2,existingPublicPdfPageRenders=source['sourceImages'],newRenderAtFreeze=False,productBrowserOrPhoneScreenshots=0),privacyBoundary='Source implementation/provenance and exact path allowance are not a content privacy scan or global absence proof. Raw runtime/configuration/header/cookie/credential/token/client-key payload classes remain excluded; no refetch or reconstruction authorized.',sourceRetentionAcceptance=pin(REV/'source-retention-v1-readiness-v1.json'),retainedFailures=dict(compilerProvenance=pin(failure),compilerAttempts=fail['attempts'],currentFullProjectTypeScript='UNPASSED',compilerRetryAuthorized=False,originalReportOutcome='UNKNOWN',originalReportCause='unknown',originalReportEvidence=pin('/tmp/renault-packet/report-comparison-v2-interruption-record-v2/record.json'),originalReportFirstObserverFailureAlsoRetained=True,reportAttempts=report['reportAttemptAccounting'],preparationFailurePaths=preparationFailures,policy='Preserve every source/typed/selected/scoped-gate/report/docs preparation and failed/held/unknown execution. Do not replace unknown terminal state with the successful fresh report.'),otherAttemptHistory=dict(selectedRoadside='Earlier selected v4 technical checks passed but independent review withheld integration for unitless5 display. Typed v4/selected v5 narrow correction accepted; original artifacts retained.',sourceAndTyped='Original source v1/v2 and all typed v1-v4 amendments remain retained, including original failures and held versions.',postRegistration='All preparation versions v1-v6 retained; only accepted exact v6 five-gate results establish current scoped success.',report='Original v2 actual invocation UNKNOWN; v3 light observer preparation failed; v4 separately granted normal report and comparator passed.',docs='v1 syntax and v2 stale-context-path preparation failures retained; v3/v4 unapplied reviewed revisions retained; v5 concise first-bullet-corrected documentary version applied only after independent acceptance.',runtimeAutomaticRetries=False),currentValidation=dict(catalogue=430,tier1=353,onSale=312,packetCount=30,retainedRefreshes=4,additions=0,unchangedPeers=426,reviewedCore=68,filledCore=64,confirmed=61,check=1,reported=2,notPublished=4,scopedTests=151,structuralPassed=True,normalReportAndExhaustiveComparisonPassed=True,reportAttempts=report['reportAttemptAccounting'],fullProjectTypecheckPassed=False,releaseReady=False,researchCompleted=False,currentCleanFullSuite=False,productionBuildVerified=False,phoneMobileVerified=False,publicationAuthorized=False),independentDocsReadback=pin(readback),docsRevisionFindings=pin(REV/'docs-status-v3-v4-findings-v1.json'),factualReportAcceptance=pin(REV/'report-comparison-v4-results-v1.json'),registrationManifest=pin('/tmp/renault-packet/registration-v1/manifest.json'),docsManifest=pin('/tmp/renault-packet/docs-status-v5/manifest.json'),currentPacket=pin('/tmp/renault-packet/typed-preparation-v4/renault-2026-10-15-candidate.json'),currentReconciliation=pin('/tmp/renault-packet/typed-preparation-v4/renault-market-reconciliation.json'),retainedStorageReadClosure=read('/tmp/renault-packet/full-stage-v1/manifest.json')['storageClosure'],externalDependencies='Reuse accepted terminal CUPRA29 recovery and earlier prefix20/EQA21/Leap22/Mazda23/Skoda24/Audi25/Deepal26/MINI27/KGM28 chain. Renault manifests bind all21 retained storage leaves and accepted replacement/proof paths. Both KGM compiler failures remain in that prior chain. Do not broadly recapture earlier source or rebuild immutable history.',reconstructionNotes='Retain original logical absolute paths via recovery mapping. No node_modules, generated Next caches, browser preview snapshot or new canonical catalogue capture added. Preserve exact source and optional-property witnesses; no regenerated substitute evidence.',finalReviewerReceiptPolicy=dict(path=str(final),state='future_separate_acceptance_after_inventory_review',includedInPayload=False,reason='Avoid recursive inventory pins; reviewer root otherwise frozen after documentary readback and source-retention review'),preparer=pin(__file__))
with out.open('x')as f:json.dump(x,f,indent=2,ensure_ascii=False);f.write('\n')
print(json.dumps(dict(inventory=pin(out),files=x['totalFiles'],bytes=x['regularFileBytes'],liveTargets=8,preparationFailures=len(preparationFailures),excludedFiles=len(excluded)),indent=2))
