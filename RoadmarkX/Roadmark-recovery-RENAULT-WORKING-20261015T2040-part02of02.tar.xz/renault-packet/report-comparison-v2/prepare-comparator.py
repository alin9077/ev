from pathlib import Path
import difflib
P=Path('/tmp/renault-packet/report-comparison-v1');B=Path('/tmp/renault-packet/report-comparison-v2')
old=(P/'compare-report.mjs').read_text();s=old.replace(str(P),str(B))
needle="const normalTerminal=readJson(qa+'/normal-coverage-asof-2026-10-15/terminal.json');assert.equal(normalTerminal.exitCode,0);assert.equal(normalTerminal.stdoutSha256,fileHash(normalPath));"
extra="""
const generatedNormalInputs=['stdout.log','terminal.json','result.json','after-pins.json','scope-verification.json','invocation.json'].map(name=>{const file=qa+'/normal-coverage-asof-2026-10-15/'+name;return {path:file,bytes:fs.statSync(file).size,sha256:fileHash(file)};});
const normalResult=readJson(qa+'/normal-coverage-asof-2026-10-15/result.json'),normalAfterPins=readJson(qa+'/normal-coverage-asof-2026-10-15/after-pins.json');
assert.equal(normalResult.passed,true);assert.equal(normalResult.exitCode,0);assert.equal(normalResult.manifestSha256,fileHash(qa+'/normal-coverage-asof-2026-10-15.json'));assert.equal(normalAfterPins.passed,true);
function checkNormalInputs(){for(const pin of generatedNormalInputs){assert.equal(fs.statSync(pin.path).size,pin.bytes);assert.equal(fileHash(pin.path),pin.sha256);}}
checkNormalInputs();write('generated-normal-input-closure',generatedNormalInputs);
"""
assert s.count(needle)==1;s=s.replace(needle,needle+extra)
s=s.replace("fs.writeFileSync(out+'/normal-coverage-formatted.txt'","checkNormalInputs();\nfs.writeFileSync(out+'/normal-coverage-formatted.txt'")
with (B/'compare-report.mjs').open('x') as f:f.write(s)
with (B/'v1-to-v2-comparator.patch').open('x') as f:f.write(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile=str(P/'compare-report.mjs'),tofile=str(B/'compare-report.mjs'))))
