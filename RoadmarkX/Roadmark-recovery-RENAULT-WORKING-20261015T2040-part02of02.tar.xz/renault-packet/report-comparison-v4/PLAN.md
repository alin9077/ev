# Renault30 normal report and exhaustive comparison plan

Preparation only. No command is authorized by this document. Full-project TypeScript and release remain UNPASSED after two preserved KGM SIGKILL attempts of unknown cause. No compiler retry, build, server, browser or publication is included.

## Separate gates and supervision

Require the exact four-file Renault30 registration, independent live readback and five accepted scoped gates: market-view check, loader-only lint, 144 behavioural tests, seven live-safety tests and structural validation. Bind the registration hashes/stat transitions, unchanged configured TypeScript roots and runtime metadata as integrity guards only; this is not a TypeScript run.

Then run one actual unchanged scripts/report-coverage.ts --as-of 2026-10-15 --json command with installed pinned Node, 448 MiB old space, 1 MiB semi-space and --import tsx. Freeze a 900-second timeout, 10-second TERM-to-KILL grace and 20-second supervisor margin. The planned normal structural validator calls the actual pack producer for every catalogue car and therefore performs its own broad feature work. The one independent normal report also includes its inherent full effective-feature work. These two deliberate normal checks are separate from the selected and derived-stage output; no additional broad replay is added to the comparator.

A separate bounded saved-output comparator reads that report without rerunning it. Use the accepted 448/1 MiB envelope, 180-second timeout and 10-second grace, with exact source/import/storage closure, create-only outputs and before/after integrity checks. Only the four selected prior Renault packs may be replayed if needed for prior freshness contributions; no peer feature replay. Freeze and independently review the composed comparator and syntax-only receipt before its runtime grant.

## Exact reconstruction and comparison obligations

Baseline is the accepted actual CUPRA29 normal report, not a selected report. Both baseline and Renault30 have 430 catalogue / 353 Tier 1 / 312 on-sale. Restore retained 409/prefix20 complete cars once, then compose accepted written replacements/additions through EQA21, Leap22, Mazda23, Skoda24, Audi25, Deepal26, MINI27, KGM28 and CUPRA29. Every ordered complete-car digest must equal the accepted stage chain. Replace only four Renault cars with accepted staged values; all 426 peers, ordering and identities remain exact.

Stream the 14 retained research descriptors with only four Renault variants and their 276 raw feature rows retained; keep complete global evidence/source controls. Close all 21 physical storage files. Compose source arrays from accepted packet additions through CUPRA29, then append the 24 Renault sources and verify both complete source-array digests. Use the saved selected actual-consumer outputs and exact optional-property witnesses. Replay only four prior Renault effective feature packs if needed to establish prior selected coverage/freshness with actual producer provenance.

The comparator must account for every normal-report leaf:

1. Exact date, terminal success and stdout hash; fixed denominators; unchanged reporting implementation
2. Whole non-Renault brandProgress objects unchanged; Renault's entire object equals accepted selected coverage, including honest criteria, completion and closure issues
3. Actual complete global coreCoverage/coreFact/gradePattern over all digest-verified on-sale cars and sources; baseline equality for all 17 core objects and gaps, then exact before-to-after selected contribution deltas
4. Every complete per-field reason count in catalogue insertion order, not only the shortened displayed explanation; confidence and compatible comparison bases stay distinct
5. Complete digest-bound stage ranking records, including every Fact, rank, tie and reason. Preserve peer group membership and relative order while allowing selected additions/removals and group-size sorting changes. Filter the actual on-sale subset, re-establish production bucket insertion order, then apply the actual group comparator. Compare every group, ordered ranked ID, exclusion, reason count, percentage and pass flag
6. Summary gaps in actual Tier 1 catalogue order; missing models and unresolved leads in inherited inventory traversal order; overdue/invalid/excluded-history rows in actual producer order, all cars' facts/availability before features. Replace only selected contributions
7. Entire C1 value equals accepted stage before/after: reviewed models 103 to 105, versions 234 to 238, issues 197 to 192, settled inventory 63 to 64. Scenic settles; Megane remains unresolved; R5 Turbo conflict stays explicitly held without a fabricated inventory identity; every non-Renault issue and evidence array remains exact; pass stays false
8. Reconstruct all remaining aggregates: paired summaries, all-rank intersection, 17-field grade totals/percentages/note, completed and remaining brands, freshness counts and every C1–C6 detail
9. Deep equality of the complete expected report and actual normal output, with zero ignored leaves; save exhaustive baseline/normal and expected/normal differences plus exact array-order and reason proofs
10. Exact nonmutation of cars, sources, packets, selected packs/results and implementation pins. Every omitted optional property requires the actual producer's ownership witness

Four true 10–80% duration gaps remain; no 15–80% conversion is allowed. Megane's reported before-ORC price, height/charge conflicts and unresolved MY24 technical applicability remain visible. Unknown battery/cargo/mirror measurement bases remain held. Roadside fact and feature text both remain “5 years”, with unchanged benefit limits and policy applicability conditions. No expired offer, ordinary Renault 5 admission or global whole-market closure is inferred.

## Stop and preserve

Every command needs independent readiness and an explicit root exclusive-slot grant. Run serially with no automatic retry or memory escalation. A failed normal report stops that grant and preserves terminal evidence. A comparator failure preserves the successful normal report for a separately reviewed comparator-only correction. Never rerun the report solely to repair comparison code. The deferred older-packet empty-basis audit remains a separate read-only backlog item, with no uninspected affected-packet claim.

## Explicit one-attempt retry after UNKNOWN interruption

The v2 report invocation at 2026-10-15T20:00:19.501118+00:00 has no retained terminal receipt and empty logs. Its result and cause remain UNKNOWN. The exact original directory and copied invocation/stat/log evidence are retained and pinned in report-comparison-v2-interruption-record-v2/record.json. This v4 is a distinct proposed retry, not an automatic continuation and not evidence that v2 passed or failed. It needs fresh independent readiness and an explicit new root grant.

Retain all original 545 source pins and 217 proof pins verbatim; add retry preparation and interruption evidence. The comparator changes only its two output-root constants; the supervisor is byte-identical. The normal command and 448/1 MiB, 900+10-second limits are unchanged. The comparator retains 448/1 MiB, 180+10-second limits, all assertions, complete-leaf equality and no peer feature replay. All new outputs are create-only. The first report's terminal absence is never repaired or filled by this attempt. Exactly one new normal invocation is proposed, followed by its comparator only if the new normal invocation is positively verified.
