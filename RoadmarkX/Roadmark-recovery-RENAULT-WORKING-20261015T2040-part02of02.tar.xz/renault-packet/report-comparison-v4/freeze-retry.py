from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,runpy
P=Path('/tmp/renault-packet/report-comparison-v2');B=Path('/tmp/renault-packet/report-comparison-v4');E=Path('/tmp/renault-packet/report-comparison-v2-interruption-record-v2');R=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def check(p):assert pin(p['path'])==p,p['path']
def read(p):return json.loads(Path(p).read_text())
def write(p,x):
 with Path(p).open('x')as f:json.dump(x,f,indent=2);f.write('\n')
for p in B.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
normal=read(P/'normal-coverage-asof-2026-10-15.json');comparison=read(P/'report-comparison.json');seq=read(P/'sequence.json')
assert normal['extraPins']==comparison['extraPins'] and len(normal['extraPins'])==217
originalSources=read(normal['sourcePins']['path']);assert len(originalSources)==545
for p in originalSources+normal['extraPins']:check(p)
record=read(E/'record.json')
for p in record['originalFiles']:check(p)
assert read(B/'syntax-only-receipt.json')['exitCode']==0
sourcePins={p['path']:p for p in originalSources}
for p in runpy.run_path(str(B/'close-comparator-inputs.py'))['collect'](R,B):
 check(p)
 if p['path']in sourcePins:assert sourcePins[p['path']]==p
 sourcePins[p['path']]=p
write(B/'source-pins.json',[sourcePins[k]for k in sorted(sourcePins)])
proofs={p['path']:p for p in normal['extraPins']}
for file in [*(Path(p['path'])for p in record['originalFiles']),*(p for p in E.rglob('*')if p.is_file()),*(p for p in B.iterdir()if p.is_file()),Path('/tmp/renault-packet/prepare-report-retry-v3.py'),Path('/tmp/renault-packet/prepare-report-retry-v4.py'),Path('/tmp/renault-packet/report-comparison-v3/preparation-failure-v1.json'),Path('/tmp/renault-packet/report-comparison-v2-interruption-record-v1/process-snapshot.txt')]:
 p=pin(file)
 if p['path']in proofs:assert proofs[p['path']]==p
 proofs[p['path']]=p
common=[proofs[k]for k in sorted(proofs)]
for m in [normal,comparison]:
 m.update(qaRoot=str(B),sourcePins=pin(B/'source-pins.json'),wrapper=pin(B/'run.py'),runOutput=str(B/m['id']),extraPins=common,retryProvenance=pin(B/'retry-provenance.json'),originalAttemptOutcome='UNKNOWN',minimumRetryStartUtc='2026-10-15T20:15:39.501118+00:00')
 if m['kind']=='comparison':
  m['command'][-1]=str(B/'compare-report.mjs');m['comparisonResult']=str(B/'artifacts/result.json');m['prerequisites']=[dict(manifest=pin(B/'normal-coverage-asof-2026-10-15.json'),resultPath=str(B/'normal-coverage-asof-2026-10-15/result.json'))]
 write(B/(m['id']+'.json'),m)
seq.update(sequence=[pin(B/(m['id']+'.json'))for m in [normal,comparison]],sourcePins=normal['sourcePins'],qaRoot=str(B),retryProvenance=pin(B/'retry-provenance.json'),originalAttemptOutcome='UNKNOWN',normalReportRunsInThisSequence=1,totalKnownPriorNormalReportInvocations=1,plannedTotalKnownNormalReportInvocationsIfGranted=2,minimumRetryStartUtc='2026-10-15T20:15:39.501118+00:00',freshRootGrantRequired=True)
seq.pop('normalReportRuns')
write(B/'sequence.json',seq)
g=read(P/'root-grant-template.json');g.update(sequence=pin(B/'sequence.json'),granted=seq['sequence'],reviewerAcceptance=None,retryProvenance=pin(B/'retry-provenance.json'),originalAttemptOutcome='UNKNOWN',minimumRetryStartUtc=seq['minimumRetryStartUtc']);write(B/'root-grant-template.json',g)
for m in [normal,comparison]:
 for p in [m['wrapper'],m['sourcePins'],m['rootMetadata'],m['testInventory'],m['registrationManifest'],*read(m['sourcePins']['path']),*m['extraPins']]:check(p)
for p in [B/'normal-coverage-asof-2026-10-15',B/'report-comparison',B/'artifacts',B/'root-execution-grant.json']:assert not p.exists()
for p in record['originalFiles']:check(p)
write(B/'static-verification.json',dict(status='prepared_not_executed',at=datetime.now(timezone.utc).isoformat(),sequence=pin(B/'sequence.json'),originalSourcePinsRetainedVerbatim=545,originalProofPinsRetainedVerbatim=217,sourcePinCount=len(sourcePins),extraProofPins=len(proofs),allOriginalAttemptFilesUnmodified=True,interruptedAttempt=pin(E/'record.json'),originalAttemptOutcome='UNKNOWN',originalAttemptCause='unknown',wrapperByteIdenticalToV2=pin(B/'run.py')['sha256']==pin(P/'run.py')['sha256'],comparatorOnlyTwoOutputRootConstantsChanged=(B/'compare-report.mjs').read_text()==(P/'compare-report.mjs').read_text().replace(str(P),str(B)),normalCommandExactlyUnchanged=normal['command']==read(P/'normal-coverage-asof-2026-10-15.json')['command'],normalLimits='448/1 MiB;900+10 seconds;20-second watchdog margin',comparatorLimits='448/1 MiB;180+10 seconds',currentProjectTypeScript='UNPASSED',releaseAcceptanceClaim=False,compilerRetriesIncluded=False,reportAttemptAccounting=dict(knownInterruptedActualInvocations=1,interruptedResult='UNKNOWN',plannedFreshActualInvocations=1,plannedTotalIfGranted=2,automaticRetry=False),executionAuthorized=False))
print(json.dumps(dict(sequence=pin(B/'sequence.json'),normal=pin(B/'normal-coverage-asof-2026-10-15.json'),comparison=pin(B/'report-comparison.json'),sourcePinCount=len(sourcePins),extraProofPins=len(proofs),interruptionRecord=pin(E/'record.json')),indent=2))
