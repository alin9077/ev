from pathlib import Path
import json,hashlib,subprocess,os,time,ast
from datetime import datetime,timezone
O=Path('/tmp/renault-packet/report-comparison-v4');stage=O/'compare-report.mjs'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p in O.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
cmd=['/usr/bin/timeout','--signal=TERM','--kill-after=2s','10s','/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','--max-old-space-size=64','--max-semi-space-size=1','--check',str(stage)]
beforeSha=sha(stage)
start=time.monotonic()
with (O/'syntax-only-stdout.log').open('x') as so,(O/'syntax-only-stderr.log').open('x') as se:
 p=subprocess.Popen(cmd,cwd='/workspace/scratch/586427eef9f2/roadmark-104',stdout=so,stderr=se,start_new_session=True)
 _,status,usage=os.wait4(p.pid,0);code=os.waitstatus_to_exitcode(status);p.returncode=code
receipt=dict(at=datetime.now(timezone.utc).isoformat(),command=cmd,exitCode=code,rawWaitStatus=status,elapsedSeconds=time.monotonic()-start,maxRssKiB=usage.ru_maxrss,scriptSha256=sha(stage),stdoutSha256=sha(O/'syntax-only-stdout.log'),stderrSha256=sha(O/'syntax-only-stderr.log'),runtimeExecuted=False,comparatorBodyExecuted=False,importsExecuted=False,beforeScriptSha256=beforeSha,scriptUnchanged=beforeSha==sha(stage),typescriptCompilerAttempted=False,pythonPreparationAstParsed=True,authorizedBy='/root',authorization='Root authorized Node 64/1 MiB, 10 seconds plus 2 seconds grace, --check only with no imports/runtime; same bounded preparation check covers versioned Renault harness fixes. Distinct from semantic validation and TypeScript.',currentProjectTypeScript='UNPASSED; syntax-only preparation is not a compiler pass')
with (O/'syntax-only-receipt.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt));assert code==0 and beforeSha==sha(stage)
