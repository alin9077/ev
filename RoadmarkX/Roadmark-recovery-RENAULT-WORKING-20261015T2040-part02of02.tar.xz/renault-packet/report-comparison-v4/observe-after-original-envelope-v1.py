from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,os
B=Path('/tmp/renault-packet/report-comparison-v4');P=Path('/tmp/renault-packet/report-comparison-v2');R=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def check(p):assert pin(p['path'])==p,p['path']
def meta(p):
 p=Path(p)
 if not p.exists():return dict(path=str(p),exists=False)
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
now=datetime.now(timezone.utc);assert now>=datetime(2026,10,15,20,15,40,tzinfo=timezone.utc),'Original timeout and watchdog envelope has not yet elapsed'
recordPin=read(B/'retry-provenance.json')['interruptedAttempt'];check(recordPin);record=read(recordPin['path'])
assert [pin(p)for p in sorted(P.rglob('*'))if p.is_file()]==record['originalFiles'],'Original file set or bytes changed'
for p in record['savedEvidence']:assert meta(p['original']['path'])==p['originalMetadata']
for p in record['directoryState']:assert meta(p['path'])==p
m=read(B/'normal-coverage-asof-2026-10-15.json');pins=[m['sourcePins'],m['wrapper'],m['rootMetadata'],m['testInventory'],m['registrationManifest'],*read(m['sourcePins']['path']),*m['extraPins']]
for p in pins:check(p)
md=read(m['rootMetadata']['path'])
for p in md['fileMetadata']+md['directoryState']+m['runtimeMetadata']:assert meta(p['path'])==p
config=read(R/'tsconfig.json');roots=sorted({str(p.resolve())for pattern in config['include']for p in R.glob(pattern)if p.is_file()})
assert config==m['originalConfig']and roots==md['configuredRootFilePaths']
for p in m['registrationTargets']:check(p)
p=subprocess.run(['ps','-eo','pid,ppid,pgid,stat,lstart,etime,args'],capture_output=True,text=True,check=True);active=[]
for line in p.stdout.splitlines()[1:]:
 fields=line.split(None,10)
 if len(fields)==11:
  args=fields[10];argv=args.split();exe=Path(argv[0]).name
  if exe in ['node','timeout']or(exe.startswith('python')and len(argv)>1 and argv[1]==str(P/'run.py')):active.append(line)
assert not active,active
for child in ['normal-coverage-asof-2026-10-15','report-comparison','artifacts','root-execution-grant.json']:assert not(B/child).exists(),child
with(B/'post-envelope-process-snapshot-v1.txt').open('x')as f:f.write(p.stdout);f.flush();os.fsync(f.fileno())
result=dict(status='post_original_envelope_readonly_checks_passed',observedAt=now.isoformat(),observer=pin(__file__),sequence=pin(B/'sequence.json'),originalAttemptEvidence=recordPin,originalAttemptOutcome='UNKNOWN',originalCause='unknown',originalExitCode=None,originalTerminalStillAbsent=True,originalLogsStillEmpty=True,allOriginalFileNamesBytesHashesAndInvocationStatsUnchanged=True,originalNormalInvocationAt=record['invocation']['at'],boundUsed='Original invocation + 920 seconds, rounded conservatively to 2026-10-15T20:15:40Z',matchingVisibleProcesses=active,processObservationScope='Current tool-visible process namespace only; absence is not global process proof and does not establish cause or terminal outcome',processSnapshot=pin(B/'post-envelope-process-snapshot-v1.txt'),sourcePinCount=546,extraProofPinCount=256,allCurrentPinsAndRootRuntimeMetadataPassed=True,configuredRootCount=len(roots),freshOutputPathsAbsent=True,executionAuthorized=False,currentProjectTypeScript='UNPASSED',releaseAcceptanceClaim=False)
with(B/'post-envelope-observation-v1.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(dict(observation=pin(B/'post-envelope-observation-v1.json')),indent=2))
