from pathlib import Path
import json,hashlib,copy
D=Path('/tmp/renault-packet/full-stage-v1');O=D/'output';R=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def read(p):return json.loads(Path(p).read_text())
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
def pin(p):p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p)}
def verify(p):assert pin(p['path'])==p,p['path']
m=read(D/'manifest.json');rm=read(D/'full-stage-result-manifest-v1.json')
assert digest(D/'manifest.json')=='c99fd21a54620d0b6129ecc60b5c510301e0146cfd2c7f9dc9105a72a644137b'
assert digest(D/'full-stage-result-manifest-v1.json')=='1437681f123d99337d79567062cce8f59682c2a528c0ce38ec2ea5b6ac68616f'
for p in m['pins']+rm['pins']:verify(p)
assert len(m['pins'])==407 and len({p['path'] for p in rm['pins']})==len(rm['pins'])
assert {str(p) for p in O.iterdir()}=={p['path'] for p in rm['pins'] if Path(p['path']).parent==O}
terminal=read(D/'run/terminal.json');assert terminal==rm['terminal'];assert terminal['exitCode']==0 and terminal['rawWaitStatus']==0 and terminal['elapsedSeconds']<420
assert terminal['stdoutSha256']==digest(D/'run/stdout.log');assert terminal['stderrSha256']==digest(D/'run/stderr.log');assert (D/'run/stderr.log').stat().st_size==0
assert read(D/'run/after-pins.json')==rm['afterPins'];assert rm['afterPins']['passed'] and rm['afterPins']['count']==407
invocation=read(D/'run/invocation.json');grant=read(D/'root-grant-v1.json');assert invocation['command']==grant['command'];assert grant['authorized'] and grant['exclusiveHeavySlotGranted'];assert invocation['grantSha256']==digest(D/'root-grant-v1.json');assert invocation['manifestSha256']==digest(D/'manifest.json')
oldcars=read(m['acceptedCupraCars']['path']);newcars=read(O/'car-digest-comparison.json');oldfields=read(m['acceptedCupraFields']['path']);newfields=read(O/'research-field-digests.json')
assert {k:newcars[k] for k in oldcars}==oldcars;assert {k:newfields[k] for k in oldfields}==oldfields
assert set(newcars)-set(oldcars)=={'candidate30'} and set(newfields)-set(oldfields)=={'candidate30'}
before={x['id']:x for x in newcars['candidate29']};after={x['id']:x for x in newcars['candidate30']};selected=set(m['selectedIds']);peers=set(before)-selected
assert len(peers)==426;assert list(before)==list(after);assert {i for i in before if before[i]!=after[i]}==selected
assert {k:v for k,v in newfields['candidate29'].items() if k not in ['metadata','sources','variants']}=={k:v for k,v in newfields['candidate30'].items() if k not in ['metadata','sources','variants']}
assert newfields['candidate30']['sources']['rows']==newfields['candidate29']['sources']['rows']+24
assert newfields['candidate30']['variants']['rows']==430
selectedCars=read(O/'selected-after-cars.json');carBy={c['id']:c for c in selectedCars}
for c in selectedCars:
 b=(json.dumps(c,ensure_ascii=False,separators=(',',':'))+'\n').encode();assert after[c['id']]=={'id':c['id'],'rows':1,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
for name,p in m['selectedArtifacts'].items():assert pin(O/name)['sha256']==p['sha256']
prior=read(m['selectedResult']['path']);result=read(O/'result.json');assert set(result)==set(prior)
assert [k for k in result if result[k]!=prior[k]]==['reportProof','readInputs']
for a,b in zip(result['reportProof'],prior['reportProof']):assert {k:v for k,v in a.items() if k!='markdownFile'}=={k:v for k,v in b.items() if k!='markdownFile'};assert Path(a['markdownFile']).name==Path(b['markdownFile']).name
assert len(result['readInputs'])==14
for row in result['readInputs']:assert row['sha256']==newfields['candidate29'][row['field']]['sha256'];assert row['inputRows']==row['retainedRows']==newfields['candidate29'][row['field']]['rows']
rankings=read(O/'global-ranking-comparison.json');assert len(rankings)==7;rankSummary=[]
def key(g):return (g['vehicleClass'],g['basis'],g['unit'])
def stripRank(e):return {k:v for k,v in e.items() if k not in ('rank','tied')}
for a in rankings:
 attr=a['attribute'];old=a['completeOrderedBefore'];new=a['completeOrderedAfter'];sel=a['completeSelectedRecords'];g0={key(g):g for g in old['groups']};g1={key(g):g for g in new['groups']};gs={key(g):g for g in sel['groups']}
 for label,r,d in [('before',old,before),('after',new,after),('selected',sel,after)]:
  eligible=[]
  for g in r['groups']:
   es=g['entries'];eligible += [e['carId'] for e in es]
   values=[e['fact']['value'] for e in es];assert values==sorted(values,reverse=attr not in ['length_mm','price_aud','dc_charge_time_min'])
   for e in es:
    assert e['carDigest']==d[e['carId']];assert e['fact']['comparisonBasis']==g['basis'] and e['fact']['unit']==g['unit'];assert e['rank']==values.index(e['fact']['value'])+1;assert e['tied']==(values.count(e['fact']['value'])>1)
    if label!='before' and e['carId'] in selected:assert e['fact']==carBy[e['carId']]['facts'][attr]
  excluded=[e['carId'] for e in r['excluded']];assert len(set(eligible+excluded))==len(eligible+excluded);assert set(eligible+excluded)==(selected if label=='selected' else set(before))
  for e in r['excluded']+r['unranked']:assert e['carDigest']==d[e['carId']]
  assert set(e['carId'] for e in r['unranked'])<=set(excluded)
  assert [e['carId'] for e in r['excluded']]==[i for i in d if i in set(excluded)]
 for k in set(g0)|set(g1)|set(gs):
  oldPeer=[e for e in g0.get(k,{}).get('entries',[]) if e['carId'] in peers];newPeer=[e for e in g1.get(k,{}).get('entries',[]) if e['carId'] in peers]
  assert [stripRank(e) for e in oldPeer]==[stripRank(e) for e in newPeer]
  gotSelected=[e for e in g1.get(k,{}).get('entries',[]) if e['carId'] in selected]
  assert [stripRank(e) for e in gotSelected]==[stripRank(e) for e in gs.get(k,{}).get('entries',[])]
  assert len(g1.get(k,{}).get('entries',[]))==len(oldPeer)+len(gotSelected)
 for field in ['excluded','unranked']:assert [e for e in new[field] if e['carId'] in peers]==[e for e in old[field] if e['carId'] in peers]
 groupSizes=[len(g['entries']) for g in new['groups']];assert groupSizes==sorted(groupSizes,reverse=True)
 for phase,r in [('before',old),('after',new)]:
  assert [x['key'] for x in a[phase]['groups']]==a[phase]['sortedKeys'];assert [x['ids'] for x in a[phase]['groups']]==[[e['carId'] for e in g['entries']] for g in r['groups']]
 rankSummary.append({'attribute':attr,'rankedBeforeAllCatalogue':sum(len(g['entries']) for g in old['groups']),'rankedAfterAllCatalogue':sum(len(g['entries']) for g in new['groups']),'selectedRanked':sum(len(g['entries']) for g in sel['groups']),'excludedAfterAllCatalogue':len(new['excluded']),'unrankedAfterAllCatalogue':len(new['unranked'])})
c1=read(O/'global-c1-comparison.json');b=c1['before'];a=c1['after'];assert b==read(m['acceptedCupraC1']['path'])['after']==read(m['acceptedNormalReport']['path'])['reconciliation']==read(O/'baseline-global-c1.json')
recon=read(m['reconciliation']['path']);expected=copy.deepcopy(b);expected['reviewedModels']+=2;expected['reviewedVersions']+=4;expected['reviewedVersionIds']+=m['selectedIds'];expected['validModelReviewIds'] += [x['id'] for x in recon['currentVersionReviews']]
expected['issues']=[x for x in b['issues'] if not (x['code']=='version_unreviewed' and x.get('reference') in selected) and not (x['code']=='inventory_unresolved' and x.get('reference')=='record:renault-scenic-e-tech')]
inventory=read(R/'data/market-inventory-2026-10-10.json');ids=[]
for kind,rows in [('record',inventory['records']),('lead',inventory['unverifiedLeads'])]:
 for row in rows:
  if not row.get('vehicleClass') or row['vehicleClass'] in ['passenger','ute']:ids.append(kind+':'+(row.get('id') or row.get('familyId') or str(row.get('brand'))+'-'+row['model']))
settled=set(b['settledInventory'])|{'record:renault-scenic-e-tech'};expected['settledInventory']=[i for i in ids if i in settled]
for k in ['notes','publishedLists','currentVersionReviews','listResolutions','catalogueOnlyDifferences','inventoryResolutions']:expected['evidence'][k]+=recon[k]
expected['evidence']['checkedAt']=max(expected['evidence']['checkedAt'],recon['checkedAt']);expected['registryCheckedAt']=expected['evidence']['checkedAt']
assert a==expected==c1['expectedCompleteAfter'];assert len(a['issues'])==192 and len(a['settledInventory'])==64 and a['reviewedModels']==105 and a['reviewedVersions']==238 and a['pass'] is False
assert [x['reference'] for x in a['issues'] if x.get('brand')=='Renault']==['record:renault-megane-e-tech']
meta=read(O/'metadata-composition.json');assert len(meta)==10
for i,t in enumerate(meta):
 raw=copy.deepcopy(t['rawMetadata']);raw['brand_update_packet_ids']=m['registeredPacketIds'][:21+i] if i<9 else m['registeredPacketIds']+['m1-renault-2026-10-15'];assert raw==t['composedMetadata'];assert t['rawMetadata']['brand_update_packet_ids']==[t['packetId']]
assert set(read(O/'retained-storage-read-closure.json')['actualReadFiles'])==set(x['path'] for x in read(m['storageClosure']['path']))
summary={'status':'independent_saved_output_verification_pass','inputPinsVerified':407,'outputAndProvenancePinsVerified':len(rm['pins']),'outputFiles':len(list(O.iterdir())),'allAcceptedPriorStageCarAndFieldDigestsExact':True,'completePeerDigestsExact':426,'changedSelectedDigests':4,'selectedArtifactHashesExact':len(m['selectedArtifacts']),'selectedResultDifferencesOnlyExpectedPathsAndFullResearchReadProof':True,'rankings':rankSummary,'independentlyReconstructedCompleteC1Matches':True,'globalC1':{'models':105,'versions':238,'issues':192,'settledInventory':64,'pass':False},'metadataOnlyOrderedIdComposition':True,'retainedStorageFiles':21,'runtimeReexecuted':False}
p=Path('/tmp/renault-review/full-stage-v1-output-verification-v1.json')
with p.open('x') as f:f.write(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2));print(json.dumps(pin(p),indent=2))
