"""Independent saved-JSON verification. Does not import or run product code."""
from pathlib import Path
from collections import Counter
from copy import deepcopy
from datetime import datetime,timezone
import json,hashlib,math,re
Q=Path('/tmp/renault-packet/report-comparison-v4');A=Q/'artifacts'
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def check(p):assert pin(p['path'])==p,p['path']
def write(n,v):
 with (Path('/tmp/renault-review')/n).open('x') as f:json.dump(v,f,indent=2,ensure_ascii=False);f.write('\n')
def pct(n,d):return math.floor(n/d*1000+.5)/10 if d else None
# Rehash every current manifest/output pin independently.
s=read(Q/'sequence.json');out=read(Q/'results-manifest-v1.json')
assert out['sequence']==pin(Q/'sequence.json')
for p in out['files']:check(p)
for p in read(s['sourcePins']['path']):check(p)
for p in s['sequence']:
 check(p);m=read(p['path'])
 for p2 in m['extraPins']:check(p2)
 d=Path(m['runOutput']);t=read(d/'terminal.json');r=read(d/'result.json');iv=read(d/'invocation.json')
 assert t['exitCode']==t['rawWaitStatus']==r['exitCode']==0
 assert not t['watchdogFired'] and r['passed'] and r['pinsPassed'] and r['scopePassed']
 assert t['stdoutSha256']==pin(d/'stdout.log')['sha256'] and t['stderrSha256']==pin(d/'stderr.log')['sha256']
 assert (d/'stderr.log').stat().st_size==0 and r['manifestSha256']==p['sha256']==iv['manifestSha256']
 assert read(d/'after-pins.json')['passed'] and read(d/'scope-verification.json')['passed']
 assert iv['command']==m['command'] and iv['automaticRetry'] is False and iv['sourceMutationsAuthorized'] is False
 assert iv['environmentOverrides']==m['environmentOverrides'] and iv['environmentRemovals']==m['environmentRemovals']
 assert iv['grantSha256']==pin(Q/'root-execution-grant.json')['sha256']
 assert t['elapsedSeconds']<=m['timeoutSeconds']+20
# Two actually invoked reports, original UNKNOWN retained separately.
interrupted=read(read(Q/'retry-provenance.json')['interruptedAttempt']['path'])
for p in interrupted['originalFiles']:check(p)
for n in ['terminal.json','result.json','after-pins.json','scope-verification.json']:assert not (Path('/tmp/renault-packet/report-comparison-v2/normal-coverage-asof-2026-10-15')/n).exists()
assert out['reportAttemptAccounting']['totalKnownNormalReportInvocations']==2
assert out['reportAttemptAccounting']['originalAttemptOutcome']=='UNKNOWN'
assert datetime.fromisoformat(read(Q/'normal-coverage-asof-2026-10-15/invocation.json')['at'])>=datetime.fromisoformat(s['minimumRetryStartUtc'])
assert datetime.fromisoformat(read(Q/'report-comparison/invocation.json')['at'])>=datetime.fromisoformat(read(Q/'normal-coverage-asof-2026-10-15/result.json')['at'])
N=read(Q/'normal-coverage-asof-2026-10-15/stdout.log');B=read('/tmp/cupra-packet/report-comparison-v1/normal-coverage-asof-2026-10-15/stdout.log')
old=read(A/'selected-before-report.json');new=read('/tmp/renault-packet/selected-preflight-v5/result.json')['selectedCoverage']
carsOld=read('/tmp/renault-research/retained-before-cars-v1.json');carsNew=read('/tmp/renault-packet/full-stage-v1/output/selected-after-cars.json')
selected={c['id'] for c in carsOld};D=read('/tmp/renault-packet/full-stage-v1/output/car-digest-comparison.json');order={c['id']:i for i,c in enumerate(D['candidate30'])}
assert len(order)==430 and len(selected)==4
assert [x for x in D['candidate29'] if x['id'] not in selected]==[x for x in D['candidate30'] if x['id'] not in selected]
assert len([x for x in D['candidate30'] if x['id'] not in selected])==426
onSale=set(B['rankings'][0]['rankedIds'])|{r['carId'] for r in B['rankings'][0]['excluded']};assert len(onSale)==312 and selected<=onSale
for r in B['rankings']:assert set(r['rankedIds'])|{x['carId'] for x in r['excluded']}==onSale
E=deepcopy(B)
assert [N[k] for k in ['allCatalogueVersions','tierOneVersions','onSaleVersions']]==[430,353,312]
E['brandProgress']=[new['brandProgress'][0] if r['brand']=='Renault' else r for r in B['brandProgress']]
assert [r for r in N['brandProgress'] if r['brand']!='Renault']==[r for r in B['brandProgress'] if r['brand']!='Renault']
assert len(E['brandProgress'])==56 and new['brandProgress'][0]['brand']=='Renault'
# Independently derive every selected per-fact reason and verify aggregate grades.
def present(v):
 if v is None:return False
 if isinstance(v,str):return bool(v.strip()) and not re.match(r'^(?:unknown|unverified|needs confirmation|not (?:published|stated|verified|available|applicable)|n/?a)(?:\b|$)',v.strip(),re.I)
 if isinstance(v,list):return any(map(present,v))
 if isinstance(v,dict):return any(map(present,v.values()))
 return True
def one(s):return ' '.join(s.split())
labels={'confirmed':'Confirmed','check':'Check','reported':'Reported','not_published':'Not published'}
def cell(car,key):
 aliases={'drive':['drive','drive_type','drivetrain'],'dc_charge_time_min':['dc_charge_time_min','dc_10_80_min','dc_charge_10_80_min']}
 facts=[car['facts'][k] for k in aliases.get(key,[key]) if k in car['facts']]
 issue=None
 if key=='dc_charge_time_min':
  good=[f for f in facts if present(f.get('value')) and (f['key']!=key or re.search(r'10\s*(?:%|per cent)?\s*(?:[–—-]|to)\s*(?:up to\s*)?80',str(f.get('basis',''))+' '+str(f.get('comparisonBasis',''))+' '+str(car['facts'].get('dc_charge_window',{}).get('value','')),re.I))]
  if good:return good[0],None,False
  other=next((f for f in facts if present(f.get('value'))),None)
  if other:return other,'Published charging duration uses a different or unestablished state-of-charge window: '+str(other.get('basis') or other.get('comparisonBasis')),False
 f=next((f for f in facts if present(f.get('value'))),facts[0] if facts else None)
 # For these exact selected rows, accepted before towing bases are held, and all after are explicit.
 if key=='towing_braked_kg' and f and present(f.get('value')):
  basis=(f.get('comparisonBasis') or '')+' '+(f.get('basis') or '')
  if not re.search(r'braked',basis,re.I):issue='Published towing limit does not establish a braked-towing measurement basis'
 return f,issue,key=='drive' and not f and present(car.get('drive'))
def reasons(cars,key):
 counts=Counter();grades=Counter()
 for car in cars:
  f,issue,ungraded=cell(car,key)
  g=labels.get(f.get('buyerGrade')) if f and f.get('gradeReview') else None
  if not g or (present(f.get('value')) if f else False)==(g=='Not published'):g='Unreviewed'
  grades[g]+=1
  if g=='Confirmed':continue
  if ungraded:r='Drive value exists without a per-fact grade'
  elif issue:r=one(issue)
  elif g=='Unreviewed':r=('Value missing; no valid completed two-source search recorded' if not f or not present(f.get('value')) else 'Recorded grade review has incomplete or invalid evidence' if f.get('gradeReview') else 'Published value has no auditable M1 grading review')
  elif f.get('gradeReview',{}).get('reason'):r=one(f['gradeReview']['reason'])
  elif not present(f.get('value')):r='Value missing; no completed two-source search recorded'
  else:r='Published value has no auditable M1 grading review'
  counts[r]+=1
 return counts,grades
reasonRows=read(A/'global-core-complete-reason-inventory.json');assert len(reasonRows)==17
for i,row in enumerate(E['core']):
 b=old['core'][i];a=new['core'][i];proof=reasonRows[i];assert row['key']==b['key']==a['key']==proof['key']
 rb,gb=reasons(carsOld,row['key']);ra,ga=reasons(carsNew,row['key'])
 assert dict(gb)=={k:v for k,v in b['grades'].items() if v},('before grades',row['key'],gb,b['grades'])
 assert dict(ga)=={k:v for k,v in a['grades'].items() if v},('after grades',row['key'],ga,a['grades'])
 beforeReasons=dict(proof['beforeFullReasons']);afterReasons=dict(proof['afterFullReasons'])
 assert len(beforeReasons)==len(proof['beforeFullReasons']) and len(afterReasons)==len(proof['afterFullReasons'])
 assert sum(beforeReasons.values())==row['total']-row['grades']['Confirmed']
 expectedReasons=Counter(beforeReasons);expectedReasons.subtract(rb);expectedReasons.update(ra)
 assert all(n>=0 for n in expectedReasons.values())
 assert {k:v for k,v in expectedReasons.items() if v}==afterReasons,('complete reason delta',row['key'])
 for key in ['filled','reviewed']:row[key]=row[key]-b[key]+a[key]
 row['grades']={k:row['grades'][k]-b['grades'][k]+a['grades'][k] for k in row['grades']}
 row['filledPercent']=pct(row['filled'],312);row['confirmedPercent']=pct(row['grades']['Confirmed'],312);row['reviewedPercent']=pct(row['reviewed'],312)
 row['gradingPasses']=row['grades']['Unreviewed']==0;row['passes']=row['filled']/312*100>=row['target']
 for phase,reportRow,reasonsArray in [('before',B['core'][i],proof['beforeFullReasons']),('after',row,proof['afterFullReasons'])]:
  explanation='; '.join(f'{n}: {reason}' for reason,n in sorted(reasonsArray,key=lambda x:-x[1])[:2]) if reportRow['grades']['Confirmed']/312<.5 else None
  assert proof[phase+'Explanation']==explanation
  if phase=='before':assert reportRow['explanation']==explanation
  else:reportRow['explanation']=explanation
 assert sum(afterReasons.values())==312-row['grades']['Confirmed']
coreOrder={r['key']:i for i,r in enumerate(E['core'])}
def selectedSwap(before,after,key='carId'):
 return [r for r in before if r[key] not in selected]+after
E['gaps']=sorted(selectedSwap(B['gaps'],new['gaps']),key=lambda r:(coreOrder[r['key']],order[r['carId']]))
# Reconstruct every ranking from complete stage records. The simple lexical collation is
# checked against the accepted baseline as well, so any mismatch is a hard review failure.
rankProofs=[]
for i,stage in enumerate(read('/tmp/renault-packet/full-stage-v1/output/global-ranking-comparison.json')):
 def groupkey(g):return (g['vehicleClass'],g['basis'],g['unit'])
 oldr=stage['completeOrderedBefore'];afterr=stage['completeOrderedAfter'];sel=stage['completeSelectedRecords']
 for phase,records,digests in [('before',oldr,D['candidate29']),('after',afterr,D['candidate30'])]:
  dm={r['id']:r for r in digests}
  for r in [r for g in records['groups'] for r in g['entries']]+records['excluded']+records['unranked']:assert r['carDigest']==dm[r['carId']]
  for g in records['groups']:
   vals=[r['fact']['value'] for r in g['entries']]
   direction=1 if stage['attribute'] in ['price_aud','dc_charge_time_min','length_mm'] else -1
   assert vals==sorted(vals,reverse=direction<0)
   for r in g['entries']:assert r['rank']==vals.index(r['fact']['value'])+1 and r['tied']==(vals.count(r['fact']['value'])>1)
 og={groupkey(g):g for g in oldr['groups']};ag={groupkey(g):g for g in afterr['groups']}
 for k,g in og.items():assert [r['carId'] for r in g['entries'] if r['carId'] not in selected]==[r['carId'] for r in ag.get(k,{'entries':[]})['entries'] if r['carId'] not in selected]
 for key in ['excluded','unranked']:assert [r for r in oldr[key] if r['carId'] not in selected]==[r for r in afterr[key] if r['carId'] not in selected]
 if stage['attribute']=='length_mm':continue
 def project(records):
  groups=[]
  for g in records['groups']:
   rows=[r for r in g['entries'] if r['carId'] in onSale]
   if rows:groups.append(dict(vehicleClass=g['vehicleClass'],basis=g['basis'],unit=g['unit'],rows=rows))
  groups.sort(key=lambda g:min(order[r['carId']] for r in g['rows']))
  groups.sort(key=lambda g:(-len(g['rows']),g['basis'].lower()))
  ranked=[r['carId'] for g in groups for r in g['rows']]
  excluded=[{k:v for k,v in r.items() if k!='carDigest'} for r in records['excluded'] if r['carId'] in onSale]
  return {'groups':[dict(vehicleClass=g['vehicleClass'],basis=g['basis'],unit=g['unit'],count=len(g['rows'])) for g in groups],'rankedIds':ranked,'excluded':excluded}
 ix=next(j for j,r in enumerate(B['rankings']) if r['key']==stage['attribute']);br=B['rankings'][ix]
 pb=project(oldr);pa=project(afterr)
 for key in pb:assert pb[key]==br[key],('baseline rank projection',stage['attribute'],key)
 er=E['rankings'][ix];er.update(pa);er['ranked']=len(pa['rankedIds']);er['percent']=pct(er['ranked'],312);er['passes']=er['ranked']/312>=.9;er['exclusionReasons']=dict(Counter(r['reason'] for r in pa['excluded']))
 assert len(set(pa['rankedIds']))==er['ranked'] and set(pa['rankedIds']).isdisjoint({r['carId'] for r in pa['excluded']}) and er['ranked']+len(pa['excluded'])==312
 assert er['ranked']==br['ranked']-old['rankings'][ix]['ranked']+new['rankings'][ix]['ranked']
 rankProofs.append(dict(key=er['key'],ranked=er['ranked'],excluded=len(pa['excluded']),allOrderedRowsAndReasons=True))
E['summaryGaps']=sorted(selectedSwap(B['summaryGaps'],new['summaryGaps']),key=lambda r:order[r['carId']])
# These selected changes do not change missing-model or lead records; assert that directly.
for key in ['missingModels','unresolvedLeads']:
 assert [r for r in B[key] if r['brand']=='Renault']==new[key]
 E[key]=deepcopy(B[key])
C=read('/tmp/renault-packet/full-stage-v1/output/global-c1-comparison.json');assert C['before']==B['reconciliation'];E['reconciliation']=C['after']
assert C['after']['pass'] is False and C['after']['reviewedModels']==105 and C['after']['reviewedVersions']==238 and len(C['after']['issues'])==192
E['pairedOnSale']=B['pairedOnSale']-old['pairedOnSale']+new['pairedOnSale'];E['pairedOnSalePercent']=pct(E['pairedOnSale'],312)
E['inAllRankings']=len(set.intersection(*(set(r['rankedIds']) for r in E['rankings'])));E['inAllRankingsPercent']=pct(E['inAllRankings'],312)
reviewed=sum(r['reviewed'] for r in E['core']);E['grading']=dict(reviewedCoreCells=reviewed,totalCoreCells=5304,reviewedPercent=pct(reviewed,5304))
E['gradeNote']=B['gradeNote'].replace(str(B['grading']['reviewedCoreCells'])+'/5304',str(reviewed)+'/5304')
for key,field,positive in [('brandsDone','done',True),('brandsRemaining','done',False),('brandsResearchCompleted','researchCompleted',True),('brandsResearchRemaining','researchCompleted',False)]:E[key]=[r['brand'] for r in E['brandProgress'] if bool(r[field])==positive]
for key in ['overdue','invalid','excludedHistory']:
 E['ageing'][key]=sorted(selectedSwap(B['ageing'][key],new['ageing'][key]),key=lambda r:(r['kind']=='equipment',order[r['carId']]))
E['ageing']['dueNext30Days']=B['ageing']['dueNext30Days']-old['ageing']['dueNext30Days']+new['ageing']['dueNext30Days']
c=E['core'];rc=E['reconciliation'];age=E['ageing'];rank=E['rankings']
E['criteria']=[
 {'id':'C1','pass':rc['pass'],'detail':f"{rc['reviewedModels']} exact current model lists reviewed; {rc['settledListEntryCount']}/{rc['listEntryCount']} entries settled across {rc['independentListCount']} independent lists; {len(rc['issues'])} blockers. {len(E['missingModels'])} unmatched audit models; {len(E['unresolvedLeads'])} unresolved leads.",'sources':B['criteria'][0]['sources']},
 {'id':'C2','pass':all(r['passes'] for r in c),'detail':f"{sum(r['passes'] for r in c)}/{len(c)} core fields meet their target; {len(E['gaps'])} version/field gaps, each with a reason in --details or --json."},
 {'id':'C3','pass':all(r['gradingPasses'] and (r['confirmedPercent']>=50 or bool(r['explanation'])) for r in c),'detail':f"{reviewed}/5304 core cells have earned reviews; {sum(r['confirmedPercent']<50 for r in c)} fields below half Confirmed have patterns in --details. No grade quota is applied."},
 {'id':'C4','pass':not E['summaryGaps'],'detail':f"{353-len(E['summaryGaps'])}/353 Tier 1 versions have both a supported strength and trade-off ({E['pairedOnSale']}/312 on sale)."},
 {'id':'C5','pass':all(r['passes'] for r in rank),'detail':f"{sum(r['passes'] for r in rank)}/6 ranking lists reach 90% of on-sale Tier 1 versions; measurement groups stay separate."},
 {'id':'C6','pass':not age['overdue'] and not age['invalid'],'detail':f"{len(age['overdue'])} aged claims and {len(age['invalid'])} invalid/future/undated claims across all Tier 1 versions, including availability and equipment. Model-year changes still require a recorded review."}]

def diff(a,b,path=''):
 if a==b and (type(a)==type(b) or (isinstance(a,(int,float)) and not isinstance(a,bool) and isinstance(b,(int,float)) and not isinstance(b,bool))):return []
 if not isinstance(a,(dict,list)) or not isinstance(b,type(a)):return [dict(path=path,before=a,after=b)]
 aa={str(i):v for i,v in enumerate(a)} if isinstance(a,list) else a;bb={str(i):v for i,v in enumerate(b)} if isinstance(b,list) else b
 out=[]
 for k in dict.fromkeys([*aa,*bb]):
  p=path+'/'+k.replace('~','~0').replace('/','~1')
  if k not in aa:out.append(dict(path=p,operation='add',after=bb[k]))
  elif k not in bb:out.append(dict(path=p,operation='remove',before=aa[k]))
  else:out.extend(diff(aa[k],bb[k],p))
 return out
actualDelta=diff(B,N);expectedDiff=diff(E,N)
assert not expectedDiff,expectedDiff[:10]
assert actualDelta==read(A/'exhaustive-normal-versus-cupra-diff.json')
assert read(A/'expected-versus-normal-diff.json')==[]
assert read(A/'result.json')['exhaustiveDifferences']==len(actualDelta)
for p in read(A/'generated-normal-input-closure.json'):check(p)
result=dict(status='independent_saved_output_verification_pass',checkedAt=datetime.now(timezone.utc).isoformat(),sequence=pin(Q/'sequence.json'),outputManifest=pin(Q/'results-manifest-v1.json'),verifier=pin(__file__),outputLeavesRehashed=len(out['files']),sourcePinsRehashed=len(read(s['sourcePins']['path'])),proofPinsPerCommand=len(read(s['sequence'][0]['path'])['extraPins']),completePeerCarDigests=426,peerBrandObjects=55,all17CoreObjectsIndependentDelta=True,all17CompleteReasonInventoriesConserved=True,orderedRankingsAndExclusions=rankProofs,allSummaryInventoryLeadFreshnessArraysExact=True,completeC1EqualsAcceptedStage=True,wholeExpectedReportEqualsActual=True,ignoredLeaves=0,exhaustiveChangedReportLeaves=len(actualDelta),reportAttemptAccounting=out['reportAttemptAccounting'],counts={k:N[k] for k in ['allCatalogueVersions','tierOneVersions','onSaleVersions']},globalGrading=N['grading'],strictGaps=len(N['gaps']),globalCriteria=N['criteria'],renaultBrand=N['brandProgress'][next(i for i,r in enumerate(N['brandProgress']) if r['brand']=='Renault')],fullProjectTypecheckPassed=False,compilerRetry=False,releaseAcceptanceClaim=False,productCodeExecuted=False)
write('report-comparison-v4-output-verification-v1.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ['renaultBrand','globalCriteria']},indent=2))
