import json,pathlib,hashlib,shutil
R=pathlib.Path('/tmp/renault-research');old=pathlib.Path('/tmp/renault-packet/source-review-v1');new=pathlib.Path('/tmp/renault-packet/source-review-v2');new.mkdir(exist_ok=False);s=R/'sources-v2';s.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
 with p.open('x')as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
p=R/'sources-v1/carexpert-scenic-review-facts.json';x=json.loads(p.read_text());assert x['facts']['published']=='2026-03-20';x['facts']['published']='2026-03-26';x['facts']['launchTiming']='Only Esprit Alpine available at March launch; Techno variants due late May/early June2026. This dated timing is not an October delivery promise.';put(s/p.name,x)
for p in old.iterdir():
 if p.is_file() and p.name not in ['manifest.json','source-index.json','README.md']:shutil.copyfile(p,new/p.name)
ix=json.loads((old/'source-index.json').read_text())
for row in ix:
 if row['sourceId']=='carexpert-scenic-review':
  row['files']=[({'path':str(s/'carexpert-scenic-review-facts.json'),'bytes':(s/'carexpert-scenic-review-facts.json').stat().st_size,'sha256':sha(s/'carexpert-scenic-review-facts.json')} if r['path'].endswith('carexpert-scenic-review-facts.json') else r)for r in row['files']]
put(new/'source-index.json',ix)
(new/'README.md').write_text((old/'README.md').read_text().replace('review v1','review v2')+'\nV2 corrects the CarExpert Scenic review date to 26 March2026 from the exact public page and adds its explicitly dated rollout context. Source-v1 and review-v1 remain unchanged and held for that date transcription error. Candidate facts and source grading are byte-identical.\n')
put(new/'v1-to-v2-provenance.json',{'reason':'Own pre-handoff check found wrong Scenic CarExpert review publication date in source-v1:20March; exact page says26March2026','oldManifest':str(old/'manifest.json'),'oldManifestSha256':sha(old/'manifest.json'),'changedFactualSource':str(s/'carexpert-scenic-review-facts.json'),'unchangedCandidateSha256':sha(new/'candidate-facts.json'),'sourceEvidence':'https://www.carexpert.com.au/car-reviews/2026-renault-scenic-e-tech-review-quick-drive; public heading date26Mar2026 5pm','oldFilesOverwritten':False})
files=sorted(p for p in R.rglob('*')if p.is_file())+sorted(p for p in old.rglob('*')if p.is_file())+sorted(p for p in new.rglob('*')if p.is_file())
put(new/'manifest.json',{'status':'prepared-light-source-review-v2','checkedAt':'2026-10-15','scope':'Four retained Renault Tier1 source/identity audit only','noLiveEdits':True,'noHeavyScripts':True,'noCompilerRetry':True,'sourceRows':len(ix),'pins':[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}for p in files]})
m=json.loads((new/'manifest.json').read_text());assert all(pathlib.Path(r['path']).stat().st_size==r['bytes'] and sha(pathlib.Path(r['path']))==r['sha256']for r in m['pins']);print({'manifest':str(new/'manifest.json'),'sha256':sha(new/'manifest.json'),'pins':len(files),'allPinsVerified':True})
