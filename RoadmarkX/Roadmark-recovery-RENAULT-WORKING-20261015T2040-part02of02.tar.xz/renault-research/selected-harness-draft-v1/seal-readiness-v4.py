from pathlib import Path
import json,hashlib
OLD=Path('/tmp/renault-packet/selected-preflight-v3');O=Path('/tmp/renault-packet/selected-preflight-v4');O.mkdir(exist_ok=False)
def pin(p):p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
receipt=Path('/tmp/renault-review/selected-preflight-v2-readiness-v1.json');assert pin(receipt)['sha256']=='0d521f0b160bd73fb25cf9088c4f2aec5488f7731e1d5ffaded9066933024301'
for name in ['check.mjs','run.py','expected-review.json']:
 with (O/name).open('x') as f:f.write((OLD/name).read_text().replace(str(OLD),str(O)))
with (O/'v3-to-v4-provenance.json').open('x') as f:json.dump({'priorManifest':pin(OLD/'prepared-command.json'),'priorScript':pin(OLD/'check.mjs'),'priorExecuted':False,'review':pin(receipt),'correction':'Seal the independent readiness-v2 receipt into the input closure. The seven guard-negative cases already added in unexecuted v3 remain unchanged; only the new output directory changes.'},f,indent=2);f.write('\n')
s=(OLD/'prepare-command.py').read_text().replace(str(OLD),str(O))
s=s.replace("files.update(O.glob('*'));", "files.update(O.glob('*'));files.update(Path('/tmp/renault-packet/selected-preflight-v3').glob('*'));files.add(Path('/tmp/renault-review/selected-preflight-v2-readiness-v1.json'));")
with (O/'prepare-command.py').open('x') as f:f.write(s)
