from pathlib import Path
import json,copy,hashlib
OLD=Path('/tmp/renault-packet/selected-preflight-v1');O=Path('/tmp/renault-packet/selected-preflight-v2');O.mkdir(exist_ok=False)
s=(OLD/'check.mjs').read_text().replace(str(OLD),str(O))
def change(a,b):
 global s
 assert a in s,a[:100];s=s.replace(a,b)
change("assert.equal(duration.comparisonBasis,'');", "assert.equal(duration.comparisonBasis,'15–80% state of charge at '+(car.model==='Megane E-Tech'?'130':'150')+' kW DC station');")
change("assert.equal(car.facts.battery_kwh.comparisonBasis,'');assert.equal(car.facts.boot_l.comparisonBasis,'');", "assert.equal(car.facts.battery_kwh.comparisonBasis,'Battery capacity basis not established');assert.equal(car.facts.battery_kwh.issues.length,1);assert.equal(car.facts.boot_l.comparisonBasis,'Cargo measurement method not stated');")
change("assert.equal(car.facts.width_mm.comparisonBasis,'');", "assert.equal(car.facts.width_mm.comparisonBasis,'Width measurement basis not established');assert.equal(car.facts.width_mm.issues.length,1);")
start=s.index("const reconciliation=readJson(expected.reconciliation.path);")
new='''const {compareFacts}=require('./src/lib/compare.ts');
const comparisonProof=[];
function pairCheck(a,b,key,state){
 const left=a.facts[key],right=b.facts[key],result=compareFacts(left,right);assert.equal(result.state,state,`${a.id}/${b.id}/${key}`);
 if(state==='comparable'){assert.equal(typeof left.value,'number');assert.equal(typeof right.value,'number');assert.equal(result.delta,right.value-left.value);}
 else{assert(!Object.hasOwn(result,'delta'));assert.equal(result.delta,undefined);}
 comparisonProof.push({left:a.id,right:b.id,key,leftBasis:left.comparisonBasis,rightBasis:right.comparisonBasis,result});
}
for(let i=0;i<after.length;i++)for(let j=i;j<after.length;j++){
 const a=after[i],b=after[j],hasMegane=a.model==='Megane E-Tech'||b.model==='Megane E-Tech';
 for(const key of ['battery_kwh','boot_l'])pairCheck(a,b,key,'different_basis');
 pairCheck(a,b,'width_mm',hasMegane?'different_basis':'comparable');
 pairCheck(a,b,'height_mm',hasMegane?'conditional':'comparable');
 pairCheck(a,b,'dc_charge_time_min','unknown');
 pairCheck(a,b,'dc_15_80_time_min',hasMegane?'conditional':'comparable');
 for(const key of ['length_mm','range_km','seats','ac_kw','dc_peak_kw','power_kw','zero_to_100_s','towing_braked_kg'])pairCheck(a,b,key,'comparable');
 pairCheck(a,b,'price_aud',hasMegane?'conditional':'comparable');
}
assert.equal(comparisonProof.length,150);
const cleanLengths=rankCounts.length_mm.ranked;assert.deepEqual(new Set(cleanLengths),selected);
for(const car of after){assert(exclusionReason(car,car.facts.battery_kwh,data.sources,policy));assert(exclusionReason(car,car.facts.boot_l,data.sources,policy));}
assert(exclusionReason(after[0],after[0].facts.width_mm,data.sources,policy));
''' 
s=s[:start]+new+s[start:]
change('rankingProof,rankCounts,producerProofs,','rankingProof,rankCounts,comparisonProof,producerProofs,')
# Retain the earlier not-executed draft; the new final script receives its own pins.
with (O/'check.mjs').open('x') as f:f.write(s)
with (O/'run.py').open('x') as f:f.write((OLD/'run.py').read_text())
P=Path('/tmp/renault-packet/typed-preparation-v3');packet=json.loads((P/'renault-2026-10-15-candidate.json').read_text());baseline=json.loads(Path('/tmp/renault-research/retained-before-cars-v1.json').read_text());ids=[c['id'] for c in baseline]
def pin(p):p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','length_mm','width_mm','height_mm','towing_braked_kg','zero_to_100_s','power_kw','drive','warranty','battery_warranty'];facts={(r['variantId'],r['after']['key']):r['after'] for r in packet['facts']}
policy=[]
for vid in ids:
 for key in core:
  if key in ['drive','warranty','battery_warranty']:continue
  f=facts[vid,key];megane=vid==ids[0]
  eligible=key in ['range_km','dc_peak_kw','ac_kw','seats','length_mm','towing_braked_kg','zero_to_100_s','power_kw'] or (key in ['price_aud','width_mm','height_mm'] and not megane)
  policy.append({'variantId':vid,'key':key,'eligible':eligible,'value':f['value'],'buyerGrade':f['buyerGrade'],'comparisonBasis':f['comparisonBasis'],'reason':'Actual published matching measurement basis required. Reported price, true 10–80 gaps, unknown battery/cargo/Megane-width bases and Megane height conflict remain excluded.'})
supplemental=[]
for row in packet['facts']:
 f=row['after'];key=f['key']
 if key not in core and isinstance(f['value'],(int,float)):
  eligible=key=='dc_15_80_time_min' and row['variantId']!=ids[0]
  supplemental.append({'variantId':row['variantId'],'key':key,'eligible':eligible,'issues':f['issues'],'reason':'Only clean Scenic published 15–80 durations share an explicit 150 kW station/window basis. Megane disagreement remains held; warranty component aliases carry the whole shared terms rather than numeric rankings.'})
expected={'packet':pin(P/'renault-2026-10-15-candidate.json'),'packetSha256':pin(P/'renault-2026-10-15-candidate.json')['sha256'],'reconciliation':pin(P/'renault-market-reconciliation.json'),'coreKeys':core,'currentListIds':ids,'bodyByModelId':{'renault_megane_current':'Hatchback','renault_scenic_current':'SUV'},'normalizedRankPolicy':policy,'supplementalRankPolicy':supplemental,'rankingIds':{k:[x['variantId'] for x in policy if x['key']==k and x['eligible']] for k in ['length_mm','range_km','price_aud','dc_charge_time_min','towing_braked_kg','seats','boot_l']},'factUpdates':92,'termCells':12,'coreCells':68,'allFeatureClaims':276,'roadsideCanonicalProjections':4,'expectedOnSaleDelta':0,'fullCatalogueHydration':False,'optionalPropertyCount':'Not guessed; exact same-run producer-owned paths required.','pairComparisonCases':150}
with (O/'expected-review.json').open('x') as f:json.dump(expected,f,indent=2,ensure_ascii=False);f.write('\n')
with (O/'draft-to-v2-provenance.json').open('x') as f:json.dump({'priorDraft':pin(OLD/'check.mjs'),'priorWrapper':pin(OLD/'run.py'),'draftExecuted':False,'correction':'Adopt independently reviewed typed v3 basis corrections and add 150 actual compareFacts self/pair cases plus preserved direct ranking holds. Draft v1 is retained; no execution outputs exist.'},f,indent=2);f.write('\n')
print(json.dumps({'script':pin(O/'check.mjs'),'expectedReview':pin(O/'expected-review.json'),'wrapper':pin(O/'run.py'),'executed':False},indent=2))
