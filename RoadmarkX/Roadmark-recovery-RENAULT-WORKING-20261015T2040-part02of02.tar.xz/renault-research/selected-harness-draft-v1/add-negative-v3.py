from pathlib import Path
import json,hashlib
OLD=Path('/tmp/renault-packet/selected-preflight-v2');O=Path('/tmp/renault-packet/selected-preflight-v3');O.mkdir(exist_ok=False)
s=(OLD/'check.mjs').read_text().replace(str(OLD),str(O))
marker="const {compiledSource}=require('./tests/helpers/compiled-source.ts');"
assert marker in s
negative='''// Each selected-only mutation must hit its intended guard and leave its supplied inputs untouched.
const negativeProof=[];
function rejectMutation(name,mutate,pattern){
 const input={cars:structuredClone(before),research:structuredClone(data),packet:structuredClone(packet)};
 mutate(input);const snapshot=structuredClone(input);let error;
 try{applyBrandUpdates(input.cars,input.research,[input.packet]);}catch(caught){error=caught;}
 assert(error instanceof Error,`${name}: intended invalid input was accepted`);assert.match(error.message,pattern,`${name}: wrong rejection path`);
 assert.deepEqual(input,snapshot,`${name}: rejection mutated supplied inputs`);
 negativeProof.push({name,actualError:error.message,expectedErrorPattern:pattern.source,rejected:true,inputsUnchanged:true});
}
rejectMutation('exact identity guard',({packet:p})=>{p.versionGuards[0].before.trim+=' changed';},/Brand update: reviewed version changed:/);
rejectMutation('specific fact beforeguard',({packet:p})=>{p.facts[0].before.qualifications.push('changed beforeguard');},/Brand update: fact before snapshot changed:.*\\/price_aud$/);
rejectMutation('shared warranty beforeguard',({packet:p})=>{p.brandTerms[0].before[p.versionGuards[0].variantId].value='changed beforeguard';},/Brand update: fact before snapshot changed:.*\\/warranty$/);
rejectMutation('availability beforeguard',({packet:p})=>{p.availability[0].before.evidence.qualifications.push('changed beforeguard');},/Availability correction conflict .*reviewed snapshot changed or variant missing/);
rejectMutation('summary exact dependency',({packet:p})=>{p.summaries[0].strength.dependencies[0].expected.value=999;},/Brand update: summary dependency changed:.*\\/range_km$/);
rejectMutation('source exact snapshot',({packet:p})=>{p.sources[0].title+=' changed';},/Brand update: source snapshot changed:/);
rejectMutation('earned grade provenance',({packet:p})=>{p.facts.find(row=>row.after.key==='range_km').after.gradeReview.overlayId='wrong-overlay';},/Brand update: invalid fact or unearned grade: range_km/);
assert.equal(negativeProof.length,7);assert.deepEqual(before,beforeSnapshot);assert.deepEqual(data,dataSnapshot);assert.deepEqual(packet,packetSnapshot);
'''
s=s.replace(marker,negative+marker).replace('rankingProof,rankCounts,comparisonProof,producerProofs,','rankingProof,rankCounts,comparisonProof,negativeProof,producerProofs,').replace("sourceEdits:false,expectedOnSaleDelta:0,", "sourceEdits:false,scopeTargetNeutrality:{selectedTierOneOnly:true,tierTwoTargets:0,nonRenaultTargets:0,fullCataloguePeerEquality:'NOT RUN; later full-stage gate'},expectedOnSaleDelta:0,")
with (O/'check.mjs').open('x') as f:f.write(s)
for name in ['run.py','expected-review.json']:
 with (O/name).open('xb') as f:f.write((OLD/name).read_bytes())
def pin(p):p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
with (O/'v2-to-v3-provenance.json').open('x') as f:json.dump({'priorManifest':pin(OLD/'prepared-command.json'),'priorScript':pin(OLD/'check.mjs'),'priorExecuted':False,'correction':'Added seven selected-only intended-rejection/immutability cases covering identity, specific beforefact, shared-term beforefact, availability, summary dependency, source snapshot and earned-grade provenance. Explicitly labelled peer/Tier 2 checks as scope/target neutrality; full catalogue peer equality remains unrun.'},f,indent=2);f.write('\n')
prep=(OLD/'prepare-command.py').read_text().replace(str(OLD),str(O))
prep=prep.replace("files.update(O.glob('*'));", "files.update(O.glob('*'));files.update(Path('/tmp/renault-packet/selected-preflight-v2').glob('*'));")
prep=prep.replace('Actual C1/current-list and coverage consumers, 150 compareFacts self/pair cases,','Seven actual intended-rejection/unchanged-input cases; actual C1/current-list and coverage consumers, 150 compareFacts self/pair cases,').replace('Tier 2 unchanged.', 'Tier 2/non-Renault target neutrality only; full-catalogue peer equality is a later gate.')
with (O/'prepare-command.py').open('x') as f:f.write(prep)
print('Added guarded negative readiness v3; no actual helper execution.')
