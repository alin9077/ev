from pathlib import Path
import re
O=Path('/tmp/renault-packet/selected-preflight-v1')
O.mkdir(exist_ok=False)
s=Path('/tmp/kgm-packet/selected-preflight-v2/check.mjs').read_text()
def change(a,b):
 global s
 assert a in s,a[:100]
 s=s.replace(a,b)
change('exactly three retained KGM rows','exactly four retained Renault Tier 1 rows')
change('/tmp/kgm-packet/selected-preflight-v2','/tmp/renault-packet/selected-preflight-v1')
change("const packetPath='/tmp/kgm-packet/kgm-2026-10-15-candidate-v2.json';","const packetPath=expected.packet.path;")
change("/tmp/kgm-research/retained-before-cars.json","/tmp/renault-research/retained-before-cars-v1.json")
change("/tmp/kgm-research/retained-before-selection-receipt.json","/tmp/renault-research/retained-selection-proof-v1.json")
change("readJson(receipt.acceptedIndex).candidate27","readJson(receipt.acceptedIndex)[receipt.stage]")
change("assert.equal(before.length,3);","assert.equal(before.length,4);assert.equal(acceptedDigests.length,430);assert.equal(receipt.stage,'candidate29');")
change("receipt.selectedDigests.find(x=>x.id===car.id)","receipt.checks.find(x=>x.found.id===car.id)?.found")
change('assert.equal(base.variants.length,3);assert.equal(base.feature_evidence.length,207);','assert.equal(base.variants.length,4);assert.equal(base.feature_evidence.length,276);')
change('assert.equal(base.feature_evidence_variant_context.length,3);','assert.equal(base.feature_evidence_variant_context.length,4);')
change("assert.equal(brandUpdatePackets.length,27);assert.equal(brandUpdatePackets.at(-1).id,'m1-mini-2026-10-15');","assert.equal(brandUpdatePackets.length,29);assert.equal(brandUpdatePackets.at(-1).id,'m1-cupra-2026-10-15');")
change("assert.notEqual(prior.brand,'KGM');","assert.notEqual(prior.brand,'Renault');")
change('assert.equal(packet.versionGuards.length,3);assert.equal(packet.facts.length,59);assert.equal(packet.brandTerms.length,3);assert.equal(packet.brandTerms.reduce((n,t)=>n+t.applicableVariantIds.length,0),9);assert.equal(packet.summaries.length,3);assert.equal(packet.availability.length,3);','assert.equal(packet.versionGuards.length,4);assert.equal(packet.facts.length,92);assert.equal(packet.brandTerms.length,3);assert.equal(packet.brandTerms.reduce((n,t)=>n+t.applicableVariantIds.length,0),12);assert.equal(packet.summaries.length,4);assert.equal(packet.availability.length,4);')
change('assert.equal(after.length,3);assert.equal(data.variants.length,3);assert.equal(data.feature_evidence.length,207);','assert.equal(after.length,4);assert.equal(data.variants.length,4);assert.equal(data.feature_evidence.length,276);')
change("const {factClaim,featureClaim}=require('./src/lib/citable.ts');","const {factClaim,featureClaim,makeReport,reportMarkdown}=require('./src/lib/citable.ts');\nconst {availabilityReportClaim}=require('./src/lib/availability-corrections.ts');")
change('let earnedCells=0,roadsideRefreshes=0,driveawayRefreshes=0;','let earnedCells=0,roadsideRefreshes=0;const gradeCounts={},availabilityClaims=[];')
change("for(const condition of fact.qualifications)assert(feature.conditions.includes(condition));assert.match(feature.value,/5 years/);assert.match(feature.value,/1 July 2024/);roadsideRefreshes++;","for(const condition of fact.qualifications)assert(feature.conditions.includes(condition));assert.equal(fact.value,5);assert.equal(fact.unit,'years');assert.equal(feature.value,'5');roadsideRefreshes++;")
a=s.index("  }else if(feature.criterion==='driveaway_price'){"); b=s.index("  }else assert.deepEqual(feature,beforePacks",a)
s=s[:a]+s[b:]
change("assert.equal(buyerAvailabilityText(car),'On sale now');assert(isOnSale(car));assert(isCurrentListEligible(car,data.sources,packet.reviewedAt));assert.equal(car.year,2026);","assert.equal(buyerAvailabilityText(car),'On sale now');assert(isOnSale(car));assert(isCurrentListEligible(car,data.sources,packet.reviewedAt));assert.equal(car.year,car.model==='Megane E-Tech'?null:2026);\n assert.equal(car.availabilityEvidence.orderStatus,car.model==='Megane E-Tech'?'listed_unconfirmed':'accepting_orders_advertised');")
change("for(const key of expected.coreKeys)assert(hasEarnedBuyerGrade(car.facts[key],data.sources,packet.reviewedAt));","for(const key of expected.coreKeys){const fact=car.facts[key];assert(hasEarnedBuyerGrade(fact,data.sources,packet.reviewedAt));gradeCounts[fact.buyerGrade]=(gradeCounts[fact.buyerGrade]??0)+1;}\n const availability=factClaim(pack,availabilityReportClaim(car),packet.reviewedAt);observeClaim(availability,pack,'/availability-claims/'+availabilityClaims.length+'/claim',()=>factClaim(pack,availabilityReportClaim(car),packet.reviewedAt));availabilityClaims.push({variantId:car.id,claim:availability});\n assert.deepEqual(availability.sources.map(source=>source.id),car.availabilityEvidence.sourceIds);\n const charge=car.facts.dc_charge_time_min;assert.equal(charge.value,null);assert.equal(charge.buyerGrade,'not_published');\n const duration=car.facts.dc_15_80_time_min;assert.equal(duration.comparisonBasis,'');assert(duration.qualifications.some(q=>q.includes('No interpolation to 10–80%')));\n assert.equal(car.facts.battery_kwh.comparisonBasis,'');assert.equal(car.facts.boot_l.comparisonBasis,'');\n if(car.model==='Megane E-Tech'){\n  assert.equal(car.facts.price_aud.value,54990);assert.equal(car.facts.price_aud.buyerGrade,'reported');assert.equal(car.facts.price_aud.priceEvidence.rankingEligible,false);\n  for(const [key,words]of [['height_mm',['1,505','1,500','CarsGuide']],['dc_15_80_time_min',['30','35','15–80%']]]){const fact=car.facts[key],claim=factClaim(pack,fact,packet.reviewedAt);assert.equal(fact.buyerGrade,'check');assert(fact.issues.length);const visible=[claim.sentence,...claim.qualifications].join(' ');for(const word of words)assert(visible.includes(word));}\n  assert.equal(car.facts.width_mm.comparisonBasis,'');assert.equal(car.facts.drive.buyerGrade,'reported');assert.equal(car.drive,'Unknown');\n }else{assert.equal(car.facts.price_aud.buyerGrade,'confirmed');assert.equal(car.facts.price_aud.comparisonBasis,'Before on-road costs');}\n")
change('assert.equal(earnedCells,68);assert.equal(featureClaims.length,207);assert.equal(roadsideRefreshes,3);assert.equal(driveawayRefreshes,3);','assert.equal(earnedCells,104);assert.equal(featureClaims.length,276);assert.equal(roadsideRefreshes,4);assert.deepEqual(gradeCounts,{reported:2,confirmed:61,not_published:4,check:1});')
change('assert.equal(after.filter(isOnSale).length,3);','assert.equal(after.filter(isOnSale).length,4);')
change('assert.equal(ranks.excluded.length,3-ranked.length);','assert.equal(ranks.excluded.length,4-ranked.length);')
change("assert(!['roadside_assistance','driveaway_price'].includes(o.criterion),'Fresh canonical term/price projection must not inherit optional undefined fields');","assert.notEqual(o.criterion,'roadside_assistance','Fresh canonical term projection must not inherit optional undefined fields');")
a=s.index("const reconciliation=readJson('/tmp/kgm-packet/kgm-market-reconciliation-v1.json');");b=s.index("const {storePortablePacks,hydratePortablePacks}",a)
s=s[:a]+'''const reconciliation=readJson(expected.reconciliation.path);
const allInventory=require('./src/lib/market-inventory-data.ts').default;
const isRenault=s=>s==='Renault';
const inventory={...allInventory,records:allInventory.records.filter(r=>isRenault(r.brand)),unverifiedLeads:allInventory.unverifiedLeads.filter(r=>isRenault(r.brand))};
const inherited=readJson('/tmp/renault-research/inherited-inventory-extract-v1.json').sections;
assert.deepEqual(inventory.records,inherited.records);assert.deepEqual(inventory.unverifiedLeads,inherited.unverifiedLeads);
assert.equal(inventory.records.length,4);assert.equal(inventory.records.filter(r=>r.vehicleClass==='van').length,2);assert.equal(inventory.unverifiedLeads.length,0);
const {inventoryRecordId,buildMarketReconciliation}=require('./scripts/reporting/m1-reconciliation.ts');
assert.deepEqual(inventory.records.filter(r=>r.vehicleClass==='passenger').map(inventoryRecordId),['renault-megane-e-tech','renault-scenic-e-tech']);
assert.deepEqual(reconciliation.inventoryResolutions.map(r=>[r.kind,r.inventoryId,r.outcome]),[['record','renault-megane-e-tech','unresolved'],['record','renault-scenic-e-tech','included']]);
for(const review of reconciliation.currentVersionReviews){
 assert.equal(review.bodyStyle,expected.bodyByModelId[review.modelId]);
 for(const version of review.versions){const car=after.find(c=>c.id===version.carId);assert(car);assert.equal(car.modelId,review.modelId);assert.equal(car.model,review.model);assert.equal(car.model,version.model);assert.equal(car.trim,version.trim);assert.equal(car.year,version.modelYear);}
}
const c1=buildMarketReconciliation(reconciliation,after,inventory,packet.reviewedAt);
assert.equal(c1.reviewedModels,2);assert.equal(c1.reviewedVersions,4);assert.deepEqual(new Set(c1.reviewedVersionIds),selected);
assert.deepEqual(c1.settledInventory,['record:renault-scenic-e-tech']);assert.equal(c1.pass,false);
assert.deepEqual(c1.issues.map(i=>i.code),['independent_lists','inventory_unresolved']);assert.equal(c1.issues[1].reference,'record:renault-megane-e-tech');
const selectedCoverage=buildCoverageReport({cars:after,sources:data.sources,features:Object.values(afterPacks).flatMap(p=>p.features),inventory,m1Reconciliation:reconciliation},packet.reviewedAt);
assert.equal(selectedCoverage.allCatalogueVersions,4);assert.equal(selectedCoverage.tierOneVersions,4);assert.equal(selectedCoverage.onSaleVersions,4);
const progress=selectedCoverage.brandProgress.find(b=>isRenault(b.brand));assert(progress);assert.equal(progress.currentVersionReviews.length,2);assert.equal(progress.unreviewedCoreGrades,0);assert.equal(progress.missingSummaries,0);assert.equal(progress.criteria.C1,false);
''' + s[b:]
change("portable:stored,claims,'feature-claims':featureClaims,","portable:stored,claims,'feature-claims':featureClaims,'availability-claims':availabilityClaims,")
change("for(const [name,rows]of [['claims',claims],['feature-claims',featureClaims]]){","for(const row of availabilityClaims)assert.deepEqual(factClaim(hydrated[row.variantId],availabilityReportClaim(after.find(c=>c.id===row.variantId)),packet.reviewedAt),row.claim);\nfor(const [name,rows]of [['claims',claims],['feature-claims',featureClaims],['availability-claims',availabilityClaims]]){")
change(":featureClaim(pack,rows[i].criterion,rows[i].criterion,packet.reviewedAt);",":name==='availability-claims'?factClaim(pack,availabilityReportClaim(after.find(c=>c.id===rows[i].variantId)),packet.reviewedAt):featureClaim(pack,rows[i].criterion,rows[i].criterion,packet.reviewedAt);")
change("assert.equal(defaultCalls,0);for(const f",'''const reportProof=[];
for(const car of after){
 const pack=afterPacks[car.id],path='/cars/'+car.family+'/'+car.slug,report=makeReport([pack],path,packet.reviewedAt),markdown=reportMarkdown(report);
 assert.deepEqual(makeReport([hydrated[car.id]],path,packet.reviewedAt),report);assert.equal(reportMarkdown(makeReport([writtenPacks[car.id]],path,packet.reviewedAt)),markdown);
 fs.writeFileSync(out+'/'+car.id+'-report.md',markdown,{flag:'wx'});assert.equal(fs.readFileSync(out+'/'+car.id+'-report.md','utf8'),markdown);
 reportProof.push({variantId:car.id,path,markdownFile:out+'/'+car.id+'-report.md',actualLiveWrittenHydratedReportEqual:true});
}
assert.equal(defaultCalls,0);for(const f''')
change("beforeCars:3,afterCars:3,coreCells:51,earnedPacketCells:earnedCells,selectedFeatureClaims:featureClaims.length,roadsideRefreshes,driveawayRefreshes,","beforeCars:4,afterCars:4,coreCells:68,coreGradeCounts:gradeCounts,earnedPacketCells:earnedCells,selectedFeatureClaims:featureClaims.length,roadsideRefreshes,reportProof,")
change("sourceEdits:false,expectedOnSaleDelta:0","sourceEdits:false,expectedOnSaleDelta:0,fullProjectTypeScript:'UNPASSED; no compiler retry'")
change("assert.equal(c1.issues.length,1);","assert.equal(c1.issues.length,2);")
# Only generic independent-list issue owns undefined properties; the unresolved Renault reference is fully populated.
change("assert(/^\\/result\\/(currentListProof\\/issues\\/0|selectedCoverage\\/reconciliation\\/issues\\/0|selectedCoverage\\/brandProgress\\/0\\/closureIssues\\/0)\\/(brand|reference)$/.test(path),'Unexpected report undefined: '+path);","assert(/\\/(brand|reference)$/.test(path),'Unexpected report undefined: '+path);")
assert 'kgm' not in s.lower()
with (O/'check.mjs').open('x') as f:f.write(s)
w=Path('/tmp/cupra-packet/selected-preflight-v1/run.py').read_text().replace('run_single_selected_cupra_preflight','run_single_selected_renault_preflight').replace("['script','sourcePins','packet','reconciliation','readinessReview']","['script','sourcePins','packet','reconciliation','expectedReview']")
with (O/'run.py').open('x') as f:f.write(w)
print('Draft-only files created. No Node, TypeScript helpers or runtime executed.')
