from pathlib import Path
import json,hashlib,copy
O=Path('/tmp/renault-packet/typed-preparation-v3');N=Path('/tmp/renault-packet/typed-preparation-v4');N.mkdir(exist_ok=False)
def read(p):return json.loads(Path(p).read_text())
def pin(p):p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(n,v):
 with (N/n).open('x') as f:json.dump(v,f,indent=2,ensure_ascii=False);f.write('\n')
m=read(O/'manifest.json');assert pin(O/'manifest.json')['sha256']=='06c9dc69640136eb9828d86c91d14392617b39d5c4c61ae951af49353adb1638'
for p in m['pins']:assert pin(p['path'])==p,p['path']
receipt=Path('/tmp/renault-review/selected-preflight-v4-results-v2.json');assert pin(receipt)['sha256']=='5a685af803520c8a2204e7d50f636d5fa4f851ca0340a0fcff507d7a50f763ab'
old=read(O/'renault-2026-10-15-candidate.json');p=copy.deepcopy(old)
oldq='Roadside page refers to exclusions and service-area details but no additional accessible linked terms were supplied by text tool'
newq='Check the full roadside-assistance terms for service-area coverage, exclusions and benefit limits.'
t=next(t for t in p['brandTerms'] if t['key']=='roadside_assistance');assert t['fact']['value']==5 and t['fact']['unit']=='years';t['fact']['value']='5 years';t['fact']['unit']=''
rows=[t['fact']]+[r['after'] for r in p['facts'] if r['after']['key']=='roadside_years'];assert len(rows)==5
for f in rows:
 assert f['qualifications'].count(oldq)==1;f['qualifications']=[newq if q==oldq else q for q in f['qualifications']]
# Produce and constrain the complete JSON pointer diff, rather than masking arbitrary paths.
def diff(a,b,path=''):
 if isinstance(a,dict) and isinstance(b,dict):
  assert a.keys()==b.keys()
  return [x for k in a for x in diff(a[k],b[k],path+'/'+k)]
 if isinstance(a,list) and isinstance(b,list):
  assert len(a)==len(b)
  return [x for i,(aa,bb) in enumerate(zip(a,b)) for x in diff(aa,bb,path+'/'+str(i))]
 return [] if a==b else [{'path':path,'before':a,'after':b}]
d=diff(old,p);assert len(d)==7
assert len([x for x in d if x['before']==oldq and x['after']==newq])==5
assert {x['path'] for x in d if x['before']!=oldq}=={'/brandTerms/2/fact/value','/brandTerms/2/fact/unit'}
write('renault-2026-10-15-candidate.json',p)
for name in ['core-review.json','renault-market-reconciliation.json','source-support-map.json','census-and-dispositions.json','source-amendment.json']:
 with (N/name).open('xb') as f:f.write((O/name).read_bytes())
a=read(O/'static-audit.json');a['roadsideDisplayCorrection']='Shared fact is an explicit 5 years string for canonical feature projection; numeric roadside_years aliases retained; seven exact JSON pointer changes only';write('static-audit.json',a)
write('v3-to-v4-provenance.json',{'priorManifest':pin(O/'manifest.json'),'priorCandidate':pin(O/'renault-2026-10-15-candidate.json'),'executedPriorCandidateResult':pin('/tmp/renault-packet/selected-preflight-v4/result.json'),'independentOutputReview':pin(receipt),'changes':d,'semanticScope':'Same five-year duration, benefit limits, dates, sources, grade, fitment and applicability. One shared value/unit presentation change, five buyer-wording substitutions. No other JSON pointer changed.','priorVersionsPreserved':True,'liveEdits':False,'actualHelpersExecuted':False})
with (N/'README.md').open('x') as f:f.write('Renault typed preparation v4\n\nSeven exact JSON pointer changes from independently reviewed v3: shared roadside assistance is written as “5 years” with empty unit so the existing canonical feature projection carries the unit; its repeated text-tool research narration is replaced by buyer-facing guidance in the shared term and four numeric roadside_years aliases. Those aliases retain value 5 and unit years. Duration, grades, conditions/limits, dates and sources are otherwise unchanged.\n\nThe prior selected actual-consumer v4 execution passed its technical checks and remains preserved, but independent output review withheld integration because that candidate showed roadside assistance as “5”. The corrected candidate needs independent static acceptance and a new frozen selected run. No live edit, helper change, runtime replay or compiler retry has occurred.\n')
files={x['path'] for x in m['pins']}|{str(O/'manifest.json'),str(receipt),'/tmp/renault-review/typed-preparation-v3-findings-v1.json','/tmp/renault-research/correct-roadside-typed-v4.py','/tmp/renault-packet/selected-preflight-v4/selected-result-manifest-v1.json'}
files.update(x['path'] for x in read('/tmp/renault-packet/selected-preflight-v4/selected-result-manifest-v1.json')['pins']);files.update(str(x) for x in N.iterdir() if x.is_file())
n={**m,'scope':'Four Renault Tier 1 retained rows; exact narrow roadside display correction from v3','candidate':pin(N/'renault-2026-10-15-candidate.json'),'reconciliation':pin(N/'renault-market-reconciliation.json'),'pins':[pin(x) for x in sorted(files)],'nextGate':'Independent typed correction acceptance, new frozen selected command, separate root/exclusive-slot replay grant'};write('manifest.json',n)
for x in m['pins']:assert pin(x['path'])==x
print(json.dumps({'manifest':pin(N/'manifest.json'),'candidate':n['candidate'],'pins':len(n['pins']),'exactChangedPointers':len(d)},indent=2))
