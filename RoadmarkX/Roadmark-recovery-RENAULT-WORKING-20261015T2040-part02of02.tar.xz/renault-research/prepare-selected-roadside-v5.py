from pathlib import Path
import json,hashlib
OLD=Path('/tmp/renault-packet/selected-preflight-v4');O=Path('/tmp/renault-packet/selected-preflight-v5');O.mkdir(exist_ok=False);M=Path('/tmp/renault-packet/typed-preparation-v4')
def pin(p):p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
s=(OLD/'check.mjs').read_text().replace(str(OLD),str(O));old="assert.equal(fact.value,5);assert.equal(fact.unit,'years');assert.equal(feature.value,'5');";assert s.count(old)==1;s=s.replace(old,"assert.equal(fact.value,'5 years');assert.equal(fact.unit,'');assert.equal(feature.value,'5 years');")
old="const claim=featureClaim(pack,feature.criterion,feature.criterion,packet.reviewedAt);assert(claim);assert.deepEqual(claim.sources.map(s=>s.id),[...new Set(feature.source_ids)]);";assert s.count(old)==1;s=s.replace(old,old+"if(feature.criterion==='roadside_assistance'){assert.equal(claim.value,'5 years');assert(!claim.qualifications.some(q=>q.includes('text tool')));}")
with (O/'check.mjs').open('x') as f:f.write(s)
with (O/'run.py').open('xb') as f:f.write((OLD/'run.py').read_bytes())
e=json.loads((OLD/'expected-review.json').read_text());e['packet']=pin(M/'renault-2026-10-15-candidate.json');e['packetSha256']=e['packet']['sha256'];e['reconciliation']=pin(M/'renault-market-reconciliation.json')
with (O/'expected-review.json').open('x') as f:json.dump(e,f,indent=2,ensure_ascii=False);f.write('\n')
with (O/'v4-to-v5-provenance.json').open('x') as f:json.dump({'priorManifest':pin(OLD/'prepared-command.json'),'priorPassedResult':pin(OLD/'result.json'),'priorOutputReview':pin('/tmp/renault-review/selected-preflight-v4-results-v2.json'),'candidateCorrection':pin(M/'v3-to-v4-provenance.json'),'changes':['Bind corrected typed-v4 packet and unchanged reconciliation','Assert roadside shared fact and actual canonical feature/claim say 5 years','Ensure affected roadside claim no longer contains text-tool research narration'],'remainingChecks':'Unchanged4cars/276features/104cells/150pairs/sevennegatives and strict portable/citable/optional-witness checks','priorOutputsPreserved':True,'runtimeExecuted':False},f,indent=2);f.write('\n')
print('Prepared corrected selected v5 script; manifest waits for independent typed-v4 receipt.')
