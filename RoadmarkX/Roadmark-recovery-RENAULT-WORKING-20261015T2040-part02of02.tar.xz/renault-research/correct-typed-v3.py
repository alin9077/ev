from pathlib import Path
import json,hashlib,copy
from collections import Counter
ROOT=Path('/tmp/renault-packet'); OLD=ROOT/'typed-preparation-v2'; NEW=ROOT/'typed-preparation-v3'; NEW.mkdir(exist_ok=False)
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(name,v):
 with (NEW/name).open('x') as f:json.dump(v,f,indent=2,ensure_ascii=False);f.write('\n')
receipt=Path('/tmp/renault-review/typed-preparation-v2-findings-v1.json');assert pin(receipt)['sha256']=='b454823548e89238d22a427f7c570cf067c7465a2de71f51ac9d005153bebbe1'
old_manifest=read(OLD/'manifest.json');assert pin(OLD/'manifest.json')['sha256']=='f712482a2750807e07b2d2e8269693f4f827ee3dba15a157aff7672553a7dbe7'
for p in old_manifest['pins']:assert pin(p['path'])==p,p['path']
old=read(OLD/'renault-2026-10-15-candidate.json');packet=copy.deepcopy(old);changes=[]
clean={'dc_peak_kw':'Peak DC charging power','ac_kw':'Maximum onboard AC charging power','zero_to_100_s':'0–100 km/h','power_kw':'Maximum motor power','drive':'Driven wheels','drivetrain':'Driven wheels','length_mm':'Overall length','height_mm':'Overall height'}
for row in packet['facts']:
 f=row['after'];key=f['key'];is_megane='megane' in row['variantId'];before=copy.deepcopy(f)
 if key in clean:f['comparisonBasis']=clean[key]
 if key=='battery_kwh':f['comparisonBasis']='Battery capacity basis not established'
 if key=='boot_l':f['comparisonBasis']='Cargo measurement method not stated'
 if key=='width_mm':f['comparisonBasis']='Width measurement basis not established' if is_megane else 'Width with mirrors folded'
 if key=='dc_15_80_time_min':f['comparisonBasis']='15–80% state of charge at '+('130' if is_megane else '150')+' kW DC station'
 if key=='battery_kwh' or (key=='width_mm' and is_megane):
  model='renault_megane_current' if is_megane else 'renault_scenic_current'
  label='Battery capacity gross/usable basis is not published' if key=='battery_kwh' else 'Megane width mirror state is not labelled'
  action='Keep the published numeric value Confirmed and visible; do not make direct measurement comparisons or ranks until its measurement basis is established. This is a measurement-basis hold, not a disagreement about the published number.'
  f['issues'].append({'issue_id':packet['id']+'-'+('megane' if is_megane else 'scenic')+'-'+key+'-basis','title':label,'priority':'important','model_ids':[model],'publication_action':action,'source_ids':copy.deepcopy(f['sourceIds'])})
 if f!=before:changes.append({'variantId':row['variantId'],'key':key,'beforeComparisonBasis':before['comparisonBasis'],'afterComparisonBasis':f['comparisonBasis'],'measurementHoldAdded':len(f['issues'])>len(before['issues']),'valueAndGradeUnchanged':f['value']==before['value'] and f['buyerGrade']==before['buyerGrade']})
news=next(s for s in packet['sources'] if s['id']=='m1_renault_20261015_scenic_order_news');assert news['published_date'] is None;news['published_date']='2026-03-11'
lookup={(r['variantId'],r['after']['key']):r['after'] for r in packet['facts']}
for t in packet['brandTerms']:
 for vid in t['applicableVariantIds']:lookup[(vid,t['key'])]=t['fact']
for summary in packet['summaries']:
 for side in ['strength','tradeoff']:
  for dep in summary[side]['dependencies']:dep['expected']=copy.deepcopy(lookup[(summary['variantId'],dep['key'])]);assert not dep['expected']['issues']
core=read(OLD/'core-review.json')
for car in core['versions']:
 for k in car['facts']:car['facts'][k]=copy.deepcopy(lookup[(car['variantId'],k)])
assert Counter(f['buyerGrade'] for c in core['versions'] for f in c['facts'].values())=={'confirmed':61,'check':1,'reported':2,'not_published':4}
assert len(lookup)==104 and len(packet['facts'])==92
# All existing identities, before snapshots, availability, factual values, grades and summary prose remain exact.
for key in ['versionGuards','versionUpdates','models','variants','features','configurationUpdates','brandTerms','availability']:assert packet[key]==old[key]
for a,b in zip(old['facts'],packet['facts']):
 assert a['variantId']==b['variantId'] and a['before']==b['before']
 for key in a['after']:
  if key not in ['comparisonBasis','issues']:assert a['after'][key]==b['after'][key],(a['variantId'],key)
for a,b in zip(old['summaries'],packet['summaries']):
 assert a['variantId']==b['variantId'] and a['conditions']==b['conditions']
 for side in ['strength','tradeoff']:
  for key in ['label','text']:assert a[side][key]==b[side][key]
write('renault-2026-10-15-candidate.json',packet)
write('core-review.json',core)
for name in ['renault-market-reconciliation.json','source-support-map.json','census-and-dispositions.json','source-amendment.json']:
 with (NEW/name).open('xb') as f:f.write((OLD/name).read_bytes())
audit=read(OLD/'static-audit.json');audit['comparisonBasisCorrection']='Explicit supported clean bases; unknown battery/cargo/Megane-width bases with narrow direct-rank holds; actual compareFacts not executed';write('static-audit.json',audit)
write('v2-to-v3-provenance.json',{'previousManifest':pin(OLD/'manifest.json'),'independentReview':pin(receipt),'changes':changes,'sourceMetadataChange':{'sourceId':news['id'],'field':'published_date','before':None,'after':'2026-03-11','evidence':pin('/tmp/renault-research/sources-v1/scenic-order-news-facts.json')},'summaryDependencies':'Rebound only changed exact fact objects; labels/text and dependency keys unchanged','unchanged':'V1/v2 source and typed preparations including failed v1 Python assertion remain immutable. No new requests, helper changes, compiler, consumers or live edits.'})
with (NEW/'README.md').open('x') as f:f.write('Renault typed preparation v3\n\nFour retained Tier 1 versions; 92 specific updates plus 12 shared-term applications, 68 core cells (61 Confirmed, one Check, two Reported, four Not published). V2 remains immutable.\n\nThe independent review identified that matching empty measurement bases could permit false pair deltas. Explicit unknown basis labels now block battery, cargo and Megane width comparisons; narrow source-supported battery and Megane-width method holds also preserve direct ranking exclusions without disputing their published numbers. Clean dimensions, charge maxima, motor power, acceleration and drive facts now carry their stated bases. The four real 10–80 gaps stay unfilled. Separate 15–80 observations state their exact station/window bases; Megane 30/35-minute disagreement and height disagreement remain Check.\n\nScenic announcement publication date is retained as 11 March 2026. Exact summary dependencies are rebound to changed basis objects without rewriting prose. Existing beforeguards, identity/availability bounds, warranty terms and C1 open dispositions are unchanged.\n\nPreparation only. Actual helpers/consumers and pair comparisons have not run. Independent typed review, frozen selected readiness and a separate root execution grant remain required.\n')
files={p['path'] for p in old_manifest['pins']}|{str(OLD/'manifest.json'),str(receipt),'/tmp/renault-research/correct-typed-v3.py','/tmp/renault-research/selected-harness-draft-v1/follow-on-audit.json'}
files.update(str(p) for p in NEW.iterdir() if p.is_file())
manifest={'schemaVersion':1,'status':'frozen_prepared_not_executed','asOf':'2026-10-15','scope':'Four retained Renault Tier 1 typed refresh; v3 comparison-basis and publication-date correction only','candidate':pin(NEW/'renault-2026-10-15-candidate.json'),'reconciliation':pin(NEW/'renault-market-reconciliation.json'),'baseline':old_manifest['baseline'],'beforeProof':old_manifest['beforeProof'],'sources':old_manifest['sources'],'pins':[pin(p) for p in sorted(files)],'currentFullProjectTypeScript':'UNPASSED; no retry','nextGate':'Independent typed review, bounded selected actual-consumer readiness, separate explicit root runtime grant'}
write('manifest.json',manifest)
for p in old_manifest['pins']:assert pin(p['path'])==p,p['path']
print(json.dumps({'manifest':pin(NEW/'manifest.json'),'candidate':manifest['candidate'],'pins':len(manifest['pins']),'changedBasisFacts':len(changes),'executedHelpers':False},indent=2))
