import sys,json,datetime,urllib.request,urllib.parse,hashlib,pathlib,subprocess
from lxml import html
base=pathlib.Path('/tmp/leapmotor-research')
name,url=sys.argv[1:3]
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt={'key':name,'url':url,'checkedAt':now}
try:
    req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
    r=urllib.request.urlopen(req,timeout=45); raw=r.read()
    ext='.pdf' if raw[:4]==b'%PDF' else '.html'
    path=base/(name+ext); path.write_bytes(raw)
    receipt.update(status=r.status,finalUrl=r.url,rawPath=str(path),rawBytes=len(raw),rawSha256=hashlib.sha256(raw).hexdigest(),headers=dict(r.headers))
    textpath=base/(name+'.txt')
    if ext=='.pdf':
        subprocess.run(['pdftotext','-layout',str(path),str(textpath)],check=True)
    else:
        tree=html.fromstring(raw)
        links=[{'text':' '.join(a.text_content().split()),'url':urllib.parse.urljoin(r.url,a.get('href'))} for a in tree.xpath('//a[@href]')]
        (base/(name+'-links.json')).write_text(json.dumps(links,indent=2))
        for el in tree.xpath('//script|//style|//noscript'): el.drop_tree()
        textpath.write_text('\n'.join(t.strip() for t in tree.xpath('//body//text()') if t.strip()))
    receipt.update(textPath=str(textpath),textSha256=hashlib.sha256(textpath.read_bytes()).hexdigest())
except Exception as e:
    receipt.update(error=type(e).__name__+': '+str(e))
(base/(name+'-receipt.json')).write_text(json.dumps(receipt,indent=2))
print(json.dumps({k:v for k,v in receipt.items() if k!='headers'}))
