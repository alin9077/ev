# Deepal M1 residual / expansion research

As observed 15 October 2026 UTC. Read-only; no catalogue edits, uploads, user-computer use, browser retry, test runs or dealer contact.

## Decision

No additional distinct Australian residual technical version was established. Live advertised-new examples map to the current S07 RWD, E07 RWD and E07 AWD Performance. Calendar-year headings and MY24/MY25 badges do not by themselves justify new version identities. The 20-inch S07 is a wheel option, not a fourth marketing grade.

The S05 Australian manufacturer page remains an interest form. Its Pre-Order checkbox asks whether the visitor is interested; it is not order acceptance or evidence of a named Australian grade. Current AU navigation enumerates S05, S07 and E07; no additional Australian BEV family was established.

## Live advertised-new examples

Exact URLs, receipt timestamps, condition, identifiers, qualifications and normalization are in normalized_census.json.

- Eastern: 2024 S07 MY24, stock 40033, and 2025 S07 MY24, stock 40031, each advertised New at $46,888 driveaway. Both have erroneous E07 boilerplate in comments. Use title/structured fields for identity only. Neither establishes wheel size
- Brisbane: 2025 S07 MY24 RWD W20, stock 23474, advertised New at $47,990 driveaway. Explicit optional 20-inch configuration. It does not establish a new trim
- Inchcape North Shore: 2025 E07 MY25 RWD, stock DE400344, advertised New at $70,137 driveaway
- Inchcape North Shore: 2025 E07 MY25 Performance AWD, stock DE500148, advertised New at $81,477 driveaway
- Brisbane: 2026 E07 MY25 Performance AWD, stock 24093, advertised New, price on application

Dealer template fields sometimes call the heading year Model Year while the description says MY24/MY25. Preserve each source label; do not infer manufacture year from VIN, turn 2026 headings into MY26, or manufacture a specification change. Physical stock and factory order acceptance remain unverified.

## Important exclusions and freshness issues

- Waverley D1071 (2025 E07 RWD): live HTML says SOLD / JUST SOLD even while web cache still says New and available for immediate delivery
- Inchcape 2024 S07 DE605278 detail: redirects to general stock; cached detail cannot support current availability
- Brisbane stock 23570 (S07 W20) and 23649 (E07 Performance): now Demo. Search-index copy still labels them New
- Perth generic All New S07 model page contains used stock. Model marketing language does not change listing condition
- Carsales explicitly labelled new-car-to-order entries are placeholders, not inventory/factory-acceptance proof
- Do not transfer the national 20-inch-only S07 driveaway campaign to a retained 19-inch configuration. An individual dealer offer is separate evidence and needs exact configuration support

## Overseas and broader leads

- UK: official S05 specifications close RWD Max and AWD Max, each 68.8 kWh LFP; 200 kW and 320 kW respectively. UK launch release is dated 26 February 2026, not a separate model-year declaration. No AU availability follows
- Thailand: current S05 product page distinguishes it from S05 REEV and mentions Max Long Range; 200 kW and 560 km are advertised. Current NEW S07 page advertises 190 kW and 485 km. Do not overwrite Australian S07 data with that market's configuration
- Thailand L07: official 29 November 2025 release describes a 100% electric 190 kW/66.8 kWh car. Current Thai navigation omits L07, so current sale/order status is unresolved
- China: indexed official navigation contains SL03, explicitly 2027-model L06, L07, S05, S07, S09 and G318. Global Changan's five-name summary is narrower and cannot be treated as an exhaustive world census
- China S07 official indexed specification table shows BEV 630Max+ and 630Ultra Huawei laser grades, 190 kW/77.94 kWh LFP/630 km CLTC, alongside separate EREV columns. This is a genuine overseas difference, not AU residual evidence
- China L07 official 2026-model launch release distinguishes BEV/EREV; exact current BEV grades remain unresolved. SL03 has historical official BEV proof, but current exact variants remain unresolved. L06 is a current manufacturer-enumerated lead; exact BEV grades were not closed in this pass
- G318, S09, Hunter K50, S05 REEV and S05 Ultra PHEV must not enter the AU BEV census from broad electric/NEV marketing. No Australian BEV grade proof was found for those leads

## Files / evidence discipline

- normalized_census.json: current-grade match decision, six exact live New listing samples, exclusions, global leads, limits
- source_index.json: URL, final URL, UTC retrieval, HTTP status and body SHA-256 for direct receipts
- Each direct source has a .json receipt containing extracted visible text and observed links, and a .txt text extract
- indexed_global_receipts.json: explicit source-method-qualified summaries for China/placeholder observations only available through indexed rendering

Direct receipts take precedence over stale search snippets. The source bodies were parsed without script/style content or form input values. No Cookie/Set-Cookie/auth headers were saved. Failed direct requests are documented, not bypassed. This is an evidence sample of configuration identities, not an exhaustive national count of physical cars.
