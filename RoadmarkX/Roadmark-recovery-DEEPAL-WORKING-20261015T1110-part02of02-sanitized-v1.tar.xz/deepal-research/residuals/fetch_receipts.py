import urllib.request, urllib.error, html.parser, json, hashlib, datetime, concurrent.futures, pathlib, re
BASE=pathlib.Path('/tmp/deepal-research/residuals')
class Parse(html.parser.HTMLParser):
 def __init__(self): super().__init__(); self.text=[]; self.links=[]; self.skip=0
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag in ('script','style'): self.skip+=1
  if tag=='a' and a.get('href') and not re.search(r'token|auth|session|password',a['href'],re.I): self.links.append(a['href'])
  if tag in ('p','div','h1','h2','h3','h4','li','tr','br','section'):self.text.append('\n')
 def handle_endtag(self,tag):
  if tag in ('script','style') and self.skip:self.skip-=1
  if tag in ('p','div','h1','h2','h3','h4','li','tr','section'): self.text.append('\n')
 def handle_data(self,data):
  if not self.skip:self.text.append(data)
def fetch(item):
 key,url=item
 out={'url':url,'retrieved_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  r=urllib.request.urlopen(url,timeout=40); raw=r.read();out.update(status=r.status,final_url=r.url,body_sha256=hashlib.sha256(raw).hexdigest(),byte_count=len(raw))
  p=Parse();p.feed(raw.decode('utf-8',errors='replace'));txt='\n'.join(' '.join(line.split()) for line in ''.join(p.text).splitlines() if line.strip());out['links']=list(dict.fromkeys(p.links));out['text']=txt
  (BASE/(key+'.txt')).write_text(txt)
 except Exception as e: out['error']=str(e)
 (BASE/(key+'.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2))
 return key,out.get('status'),len(out.get('text','')),out.get('error')
if __name__=='__main__':
 items=json.loads(pathlib.Path(__file__).with_name('fetch_urls.json').read_text())
 for result in concurrent.futures.ThreadPoolExecutor(max_workers=5).map(fetch,items.items()):print(result)
