# Deepal M1 independent evidence review

Reviewed 15 October 2026 UTC. Verdict: **accepted for bounded staging**, against the exact frozen files below. This accepts the evidence, three retained identities, proposed grades and guards. It does not claim live integration, actual consumer/portable equality, structural validation, coverage parity, a test-suite pass, TypeScript, build, mobile verification, C1 closure or M1 completion.

## Exact accepted inputs

- Candidate: `/tmp/deepal-packet/v5/deepal-2026-10-15.json`
  - SHA-256: `bde29788d6aa73cb6cb0f7119713d68c67f16cc9807bd11e38fb3bd34737fc24`
- Reconciliation: `/tmp/deepal-packet/reconciliation-v2/m1-deepal-market-reconciliation-2026-10-15.json`
  - SHA-256: `c35368191d6e31d82c85c67cadefaae0bbe11026c7b77c197d2b57ffc5196435`
- Frozen evidence manifest: `/tmp/deepal-packet/review-manifest-v4.json`
  - SHA-256: `f1f5e564e9164d1f0e077772ac84bd0003b629a1c19176478d282d39b7fc4ab2`
- All 58 explicitly listed manifest files match their frozen sizes and hashes; all 38 retained captures referenced by the 23 candidate sources match their sizes/hashes.

The superseded v2 remains retained. Review found a material omitted manufacturer AC-time disagreement in v2. New versions, rather than edits to frozen inputs, correct it and add supported publication dates. The final v5 also binds the AWD acceleration precision qualification to the webpage it describes.

## Result and scope

Three existing variants only: S07 RWD, E07 RWD and E07 AWD Performance. No models, versions, version metadata, equipment features or configuration updates are introduced. All three availability states remain current/order-listed with order acceptance and physical stock unverified. Expected on-sale delta is zero.

All 51 core cells have a supported labelled value: 46 Confirmed, two Check and three Reported. There are 64 specific fact updates and two shared warranty definitions applying to six variant cells. Three supported strength/trade-off pairs use 11 exact, clean dependencies. A 17-field review is not a claim that the brand or whole market meets every completion criterion.

## Evidence decisions

### Prices

- E07's current Australian model page explicitly defines MLP as GST-inclusive, before dealer delivery and government/statutory charges. The two HTML variant IDs bind respectively to RWD and AWD Performance. This supports rung 1 prices of A$64,900 and A$73,900, not a guessed meaning of the MLP acronym.
- Independent read-only calculator requests, supplying only Content-Type and the observed JSON payload, returned HTTP 200 and byte-identical bodies to the author's captures. No authentication, cookies, credentials, browser session, account, form, order or quote submission was involved. The NSW 2000 displayed driveaway totals are A$70,058 and A$79,508; these remain separate conditional observations. Raw totals differ fractionally from display rounding, so no components were independently rounded or summed into a new price.
- S07's current model page has 19-inch and 20-inch wheel selections but no active custom-price section, model ID input or MLP definition. Its linked specification identifies 19-inch standard and 20-inch optional. The retained car's standard-wheel fact is 19 inches and is unchanged. The A$47,990 campaign explicitly requires 20-inch wheels and excludes premium paint. It remains rung 3 / Check with the wheel, paint, purchaser, participating-retailer, location and availability conditions. It must never be described as a base 19-inch price. No applicable higher current maker rung was established; historic launch prices do not displace the current campaign.

Primary pages:
- https://www.deepal.com.au/vehicles/deepal/e07/
- https://www.deepal.com.au/vehicles/deepal/s07/
- https://www.deepal.com.au/special-offers/s07/

### Range, batteries and charging

- S07: 475 km retained as Check with a real method conflict. The current brochure table says WLTP but its footnote says ADR 81/02; the live page says WLTP combined. The candidate leaves comparison basis blank and preserves a field hold. This is not downgraded merely because of a generic laboratory disclaimer.
- E07: 550 km RWD / 510 km AWD use the current brochure's explicit WLTP combined method. Both are Confirmed.
- Published capacities are 79.97 kWh S07 and 89.98 kWh E07. The documents do not designate gross/usable capacity, so no designation or second quantity is invented. Candidate comparison bases stay blank.
- Published vehicle DC peaks are 92 kW S07 and 240 kW E07. AC maxima are 11 kW S07 and 7 kW E07. These are named vehicle limits, not charger ratings substituted for acceptance.
- Maker DC durations remain separate: S07 35 minutes and E07 15 minutes for 30–80%. No exact 10–80% duration is inferred from those windows.
- S07's approximately 50-minute 10–80% duration is independently supported in two Australian secondary reviews. E07's selected RWD 30-minute report is model-level EV Central material whose principal panel names RWD; AWD's approximately 20-minute figure is an exact AWD Performance Chasing Cars review. These are permitted Reported observations, not maker promises. E07's alternative 20/30-minute sibling/model-level observations and zecar's inconsistent 21/22-minute estimates remain visible and held. No charging-time ranking promotion is accepted.
- E07's brochure says 13 hours for 0–100% at 7 kW. The live page separately says a full charge takes about 16 hours at 7 kW without specifying starting SOC. Final v5 retains both as Check observations under a field hold. Neither is a summary dependency. The revised RWD trade-off relies only on the clean 7 kW AC limit.
- S07's maker 8-hour AC observation has no printed SOC window; the candidate does not import a secondary 0–100% window into it.

The current S07 and E07 specification page 2 captures were independently visually checked; column binding and the S07 method footnote were verified.

### Other core and supplementary facts

The current maker specification supports the named-version power, drive and acceleration values; body-wide dimensions, seats, rear/front storage and braked towing apply to both E07 grades. E07's detailed page and brochure both give 3.96 seconds for AWD; its headline's 3.9-second shorthand is disclosed without inventing a separate test or changing the precise specification.

- S07: 160 kW; RWD; 7.9 seconds; five seats; 445 L rear / 125 L front storage; 4750 × 1930 × 1625 mm; 1500 kg braked towing
- E07 RWD: 252 kW; RWD; 6.7 seconds
- E07 AWD Performance: 440 kW; AWD; 3.96 seconds
- Both E07 grades: five seats; 524 L rear / 131 L front storage; 5045 × 1996 × 1680 mm; 1500 kg braked towing

No cargo method or mirror inclusion is supplied; those comparison bases remain blank. No VDA/SAE, mirror-excluded width, battery usable/gross capacity, model year, stock promise or SOH guarantee is invented.

The shared warranty is Confirmed from the Australian brand page and both handbooks: private-use vehicle cover 7 years/160,000 km, and high-voltage battery cover 8 years/240,000 km, whichever comes first. The specific 1-year/120,000 km commercial vehicle period, commercial exclusion of the stated battery cover, maintenance/charging/health-check requirements and fair-wear degradation exclusion remain visible. No minimum retained-capacity percentage is asserted.

Warranty source: https://www.deepal.com.au/ownership/warranty/

### Safety and recall

The official notice was independently reopened. REC-006560 / DRT-001 was published 10 March 2026 and identifies 218 Deepal SC6501 vehicles in the 2025 year range, all variants within that affected set. The defect concerns a potentially absent rear-middle child-restraint anchorage. The notice tells affected owners to promptly arrange the free work with an authorised dealer; it does not state a stop-drive instruction.

The September brochure's three-anchor row and revised manual's three top-tether positions were visually checked. They do not prove an earlier individual vehicle was repaired. The exact-vehicle recall/rectification caution must remain. Existing retained child-anchor facts already include three anchors and VIN-specific qualifications, and are unchanged.

The linked official discrete VIN CSV was not available in the retained research retrievals. No continuous interval, manufacture cutoff, completed repair status, all-MY25 applicability, or all-stock rectification is inferred. CarExpert's 7 July 2026 delivery-resumption report stays secondary and separate; no official lifting date is claimed. Source publication dates now preserve 10 March and 7 July separately from the 15 October checked date.

Official notice: https://www.vehiclerecalls.gov.au/recalls/rec-006560

### Census and identity

Two complete current maker-body reviews enumerate all three retained named drivetrain grades. S07 wheel choices are options within one drivetrain grade. Exact catalogue model/trim/year identities match the retained rows, and SUV body scope is supported without conflicting retained body evidence.

Six live New advertisements were inspected in the retained dated receipts: two Eastern S07s, one Brisbane S07 W20, two Inchcape E07 grades and one Brisbane E07 Performance. None establishes an additional distinct technical version. Their calendar-year headings, MY24/MY25 labels, option wheels and colours do not create extra identities. Incorrect E07 comments on Eastern S07 ads are excluded from technical evidence. Sold, demo, redirect-only and new-to-order placeholder observations stay separate. These are listing observations, not a count of physically present cars.

S05 remains unresolved: the Australian page is registration/preorder interest, without named local grades or demonstrated open-order eligibility. Overseas S05 or other global Deepal leads do not establish Australian versions. CarExpert and CarsGuide brand-level cross-checks are not falsely recorded as complete independent whole-market lists. No research-complete or C1 closure claim is accepted.

S05 source: https://www.deepal.com.au/vehicles/deepal/s05/

## Guard and provenance checks

`frozen-v5-consistency.json` records the exact static comparison results:
- Three version beforeguards, all 64 fact beforeguards, six shared-term before cells and three availability beforeguards exactly match the retained selected cars
- All three selected complete-car JSONL digests independently match the accepted Audi candidate25 digest rows; see `independent-audi25-peer-parity.json`
- All 66 proposed fact/term source lists resolve to candidate sources; grade-review source lists match exactly. Every Confirmed proposed value cites Australian manufacturer material, and every Reported proposed value keeps secondary/sibling scope
- All 11 summary dependencies exactly equal the proposed facts and have no unresolved field issue
- All three current-list identities match their catalogue rows; the S05 inventory outcome stays unresolved
- All unknown battery quantities remain null, and S07 range/E07 AC/secondary DC holds remain explicit

The first independent digest diagnostic omitted the accepted JSONL trailing LF and therefore produced different hashes one byte shorter. It is retained as `independent-retained-car-digests.json`; the corrected format is explicitly documented and all three accepted comparisons pass. No catalogue recapture or serialization normalization was used.

## Security and remaining gates

The public API support script's credential-like literal was not used or repeated. I inspected only its safe redaction receipt, hashed the frozen sanitized files and independently demonstrated unauthenticated pricing. No original script was re-fetched. Original-hash/redaction provenance stays separate from factual source records; no authentication headers were recorded.

No repository source, original snapshot, hero or historical source record was edited by this review. No catalogue hydration, production loader, compiler, test framework, scan, compression, upload, browser retry, local computer or publication was used. The current brief and M1_PROGRESS were read in full; the parent's newer Audi state governs the staging base.

Remaining gates belong to integration: a bounded derived stage against accepted Audi25, actual consumer/citation/portable checks, unchanged peers, fresh structural and complete coverage parity, applicable behavioral checks and the parent-managed recovery process. The broader full-project TypeScript/build/full-suite/mobile limits remain open unless separately verified. No further source-review blocker remains for the frozen v5/reconciliation-v2 pair.
