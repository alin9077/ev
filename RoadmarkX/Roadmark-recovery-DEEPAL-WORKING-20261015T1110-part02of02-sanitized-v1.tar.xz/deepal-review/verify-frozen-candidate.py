import json,hashlib,sys,datetime
from pathlib import Path
from collections import Counter
packet=Path('/tmp/deepal-packet/v5/deepal-2026-10-15.json')
manifest=Path('/tmp/deepal-packet/review-manifest-v4.json')
reconciliation=Path('/tmp/deepal-packet/reconciliation-v2/m1-deepal-market-reconciliation-2026-10-15.json')
D=json.loads(packet.read_text()); M=json.loads(manifest.read_text()); R=json.loads(reconciliation.read_text())
C={c['id']:c for c in json.load(open('/tmp/deepal-research/retained-before-cars.json'))}
A=json.load(open('/tmp/audi-packet/full-stage-v1/output/car-digest-comparison.json'))
errors=[];checks=Counter(); digests=[]
def verify(ok,label,detail=None):
 checks[label]+=1
 if not ok:errors.append({'category':label,'detail':detail})
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for x in M['files']:
 p=Path(x['path']);verify(p.is_file() and p.stat().st_size==x['bytes'] and sha(p)==x['sha256'],'frozen_manifest_file',str(p))
for x in D['versionGuards']:
 verify(x['variantId'] in C and {k:C[x['variantId']].get(k) for k in x['before']}==x['before'],'exact_version_before',x['variantId'])
for x in D['facts']:
 verify(C[x['variantId']]['facts'].get(x['after']['key'])==x['before'],'exact_fact_before',[x['variantId'],x['after']['key']])
for x in D['brandTerms']:
 for vid,b in x['before'].items():verify(C[vid]['facts'].get(x['key'])==b,'exact_shared_term_before',[vid,x['key']])
for x in D['availability']:
 c=C[x['variantId']];verify(x['before']=={'availability':c['availability'],'evidence':c['availabilityEvidence']},'exact_availability_before',c['id'])
 verify(x['after']['availability']==c['availability'],'unchanged_availability_state',c['id'])
E={v:dict(c['facts']) for v,c in C.items()}
for x in D['facts']:E[x['variantId']][x['after']['key']]=x['after']
for x in D['brandTerms']:
 for vid in x['applicableVariantIds']:E[vid][x['key']]=x['fact']
S={s['id']:s for s in D['sources']};terms=[x['fact'] for x in D['brandTerms']]
for a in [x['after'] for x in D['facts']]+terms:
 verify(all(s in S for s in a['sourceIds']),'source_closure',a['key'])
 verify(a['gradeReview']['sourceIds']==a['sourceIds'],'grade_source_binding',a['key'])
 if a['buyerGrade']=='confirmed':verify(all(S[s]['source_type']=='manufacturer_au_publication' and S[s]['market']=='AU' for s in a['sourceIds']),'confirmed_maker_au_authority',a['key'])
 if a['buyerGrade']=='reported':verify(a['gradeReview']['evidenceScope']=='secondary_or_sibling','reported_scope',a['key'])
for s in D['sources']:
 for cap in s.get('retainedCaptures',[]):
  p=Path('/tmp')/cap['locator'];verify(p.stat().st_size==cap['bytes'] and sha(p)==cap['sha256'],'retained_capture_hash',str(p))
for s in D['summaries']:
 for side in ['strength','tradeoff']:
  for dep in s[side]['dependencies']:
   a=E[s['variantId']][dep['key']];verify(dep['expected']==a,'exact_summary_dependency',[s['variantId'],side,dep['key']]);verify(not a['issues'],'clean_summary_dependency',[s['variantId'],side,dep['key']])
for k in ['models','variants','versionUpdates','features','configurationUpdates']:verify(not D[k],'no_unrequested_mutations',k)
core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty','battery_warranty']
grades=Counter()
for vid,f in E.items():
 for k in core:
  verify(f[k]['value'] is not None,'core_filled',[vid,k]);grades[f[k]['buyerGrade']]+=1
 for k in ['battery_kwh','boot_l','width_mm']:verify(f[k]['comparisonBasis']=='','unknown_basis_unranked',[vid,k])
 verify(f['dc_charge_time_min']['buyerGrade']=='reported','dc_time_not_promoted',vid)
 for k in ['battery_usable_kwh','battery_gross_kwh','warranty_battery_retention_guarantee']:verify(f[k]['value'] is None,'unknown_quantity_not_invented',[vid,k])
 if 'e07' in vid:
  for k in ['ac_charge_time_hours','source_ac_web_time_hours']:verify(f[k]['buyerGrade']=='check' and any(i['priority']=='field_hold' for i in f[k]['issues']),'e07_ac_conflict_retained',[vid,k])
 else:verify(f['range_km']['buyerGrade']=='check' and f['range_km']['comparisonBasis']=='' and bool(f['range_km']['issues']),'s07_range_hold',vid)
for review in R['currentVersionReviews']:
 for v in review['versions']:
  c=C[v['carId']];verify(review['modelId']==c['modelId'] and review['brand']==c['brand'] and review['model']==c['model'] and review['vehicleClass']==c['vehicleClass'] and v['model']==c['model'] and v['trim']==c['trim'] and v['modelYear']==c['year'],'current_list_identity',v['carId'])
verify(len(R['currentVersionReviews'])==2 and sum(len(x['versions']) for x in R['currentVersionReviews'])==3,'complete_current_list_count')
verify(any(x['inventoryId']=='deepal-s05' and x['outcome']=='unresolved' for x in R['inventoryResolutions']),'s05_unresolved')
verify(not R['publishedLists'],'no_invented_whole_market_lists')
verify(grades==Counter({'confirmed':46,'check':2,'reported':3}),'earned_core_split',dict(grades))
out={'reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed_small_file_consistency_review' if not errors else 'failed','candidate':str(packet),'candidateSha256':sha(packet),'reconciliation':str(reconciliation),'reconciliationSha256':sha(reconciliation),'manifest':str(manifest),'manifestSha256':sha(manifest),'checks':dict(checks),'coreGrades':dict(grades),'errors':errors,'scopeLimits':['No catalogue loader, hydration, test framework, compiler, repository mutation, browser, compression or upload used.','This is static evidence and exact-guard review, not an integration/consumer/coverage/portable pass.']}
Path('/tmp/deepal-review/frozen-v5-consistency.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
