from pathlib import Path
import json,hashlib,collections
D=Path('/tmp/skoda-packet/full-stage-v1');O=D/'output';V=Path('/tmp/skoda-packet/selected-preflight-v7');MD=Path('/tmp/mazda-staging/full-v2/output')
load=lambda p:json.loads(Path(p).read_text())
def meta(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
m=load(D/'manifest.json');r=load(O/'stage-receipt.json');t=load(D/'run/terminal.json');assert t['exitCode']==0 and t['rawWaitStatus']==0 and (D/'run/stderr.log').read_bytes()==b'';assert load(D/'run/after-pins.json')['passed']
for a in r['artifacts']:assert meta(a['path'])==a
assert r['manifestSha256']==meta(D/'manifest.json')['sha256'] and r['packetSha256']==m['packet']['sha256']
cd=load(O/'car-digest-comparison.json');fd=load(O/'research-field-digests.json');ac=load(MD/'car-digest-comparison.json');af=load(MD/'research-field-digests.json')
for k,prior in [('baseline20','baseline20'),('corrected21','corrected21'),('current22','current22'),('current23','candidate23')]:assert cd[k]==ac[prior] and fd[k]==af[prior] and len(fd[k])==14
cur={x['id']:x for x in cd['current23']};aft={x['id']:x for x in cd['candidate24']};oldids=set(m['existingSelectedIds']);selected=set(m['selectedIds']);newids=selected-oldids
assert len(cur)==413 and len(aft)==417 and set(aft)-set(cur)==newids
peers={id for id in cur if id not in oldids};assert len(peers)==406 and all(cur[id]==aft[id] for id in peers)
assert all(cur[id]!=aft[id] for id in oldids)
for out,pre in [('selected-after-cars.json','selected-after-cars.json'),('staged-packs.json','selected-packs.json'),('portable-packs.json','portable.json')]:assert (O/out).read_bytes()==(V/pre).read_bytes()
claims=load(O/'selected-citations.json');factclaims={(x['carId'],x['key']):x['claim'] for x in claims if x['key']!='availability'};vclaims={(x['variantId'],x['key']):x['claim'] for x in load(V/'claims.json')};assert factclaims==vclaims and len(factclaims)==205 and len(claims)==216
w=load(V/'result.json');om=load(O/'portable-json-omissions.json');assert om['witnessSha256']==meta(V/'result.json')['sha256'];assert len(om['observations'])==36
for x in om['observations']:
 y=dict(x);assert y.pop('producerVerified');assert y in w['observations']
assert len(om['generatedProofs'])==4
for x in om['generatedProofs']:
 y=dict(x);assert y.pop('actualFullStageRawEqual') and y.pop('actualAuditedFeatureCalled');assert y in w['producerProofs']
assert all(om[k] for k in ['allOtherPackValuesPlainJson','livePacksUnchanged','inMemoryPortableExact','writtenPortableReadback'])
a=load(m['currentBaselineReport']['path']);b=load(O/'staged-report.json');assert (b['allCatalogueVersions'],b['tierOneVersions'],b['onSaleVersions'])==(417,340,307)
ab={x['brand']:x for x in a['brandProgress']};bb={x['brand']:x for x in b['brandProgress']};assert set(ab)==set(bb);assert all(ab[k]==bb[k] for k in ab if k!='Škoda')
assert [g for g in a['gaps'] if g['carId'] not in selected]==[g for g in b['gaps'] if g['carId'] not in selected]
assert len(a['gaps'])==380 and len(b['gaps'])==372 and all(g['carId'] not in selected for g in b['gaps'])
for x,y in zip(a['core'],b['core']):
 assert x['key']==y['key'];sa=next(q for q in ab['Škoda']['core'] if q['key']==x['key']);sb=next(q for q in bb['Škoda']['core'] if q['key']==x['key'])
 for k in ['total','filled','reviewed']:assert y[k]-x[k]==sb[k]-sa[k],(x['key'],k)
 for grade in x['grades']:assert y['grades'][grade]-x['grades'][grade]==sb['grades'][grade]-sa['grades'][grade],(x['key'],grade)
rankdeltas=[]
def groupRows(rank):
 pos=0;out={}
 for g in rank['groups']:
  ids=rank['rankedIds'][pos:pos+g['count']];assert len(ids)==g['count'];pos+=g['count'];key=(g['vehicleClass'],g['basis'],g['unit']);assert key not in out;out[key]=ids
 assert pos==len(rank['rankedIds']);return out
for x,y in zip(a['rankings'],b['rankings']):
 assert x['key']==y['key'];gx=groupRows(x);gy=groupRows(y)
 for key in gx.keys()|gy.keys():assert [id for id in gx.get(key,[]) if id not in selected]==[id for id in gy.get(key,[]) if id not in selected],(x['key'],key)
 assert [q for q in x['excluded'] if q['carId'] not in selected]==[q for q in y['excluded'] if q['carId'] not in selected]
 assert len(y['rankedIds'])==y['ranked']
 rankdeltas.append({'key':x['key'],'before':x['ranked'],'after':y['ranked'],'selectedBefore':len(set(x['rankedIds'])&selected),'selectedAfter':len(set(y['rankedIds'])&selected)})
ca=a['reconciliation'];cb=b['reconciliation'];assert cb['pass'] is False and cb['registryValid'] and cb['independentListCount']==0
assert set(cb['reviewedVersionIds'])-set(ca['reviewedVersionIds'])==oldids
assert len(cb['validModelReviewIds'])-len(ca['validModelReviewIds'])==3 and set(ca['validModelReviewIds'])<=set(cb['validModelReviewIds'])
assert set(cb['settledInventory'])-set(ca['settledInventory'])=={'record:skoda-elroq','record:skoda-enyaq-suv','record:skoda-enyaq-coupe'}
assert [x for x in ca['issues'] if x.get('brand')!='Škoda']==[x for x in cb['issues'] if x.get('brand')!='Škoda']
issues=[x for x in cb['issues'] if x.get('brand')=='Škoda'];assert len(issues)==4 and {x['reference'] for x in issues}==newids and all(x['code']=='version_unreviewed' for x in issues)
assert bb['Škoda']['criteria']=={'C1':False,'C2':True,'C3':True,'C4':True,'C5':False,'C6':True};assert bb['Škoda']['currentVersionReviews']==w['selectedCoverage']['brandProgress'][0]['currentVersionReviews']
assert b['grading']=={'reviewedCoreCells':4902,'totalCoreCells':5219,'reviewedPercent':93.9};assert sum(q['grades']['Confirmed'] for q in bb['Škoda']['core'])==161 and sum(q['grades']['Check'] for q in bb['Škoda']['core'])==26
unchanged=[k for k in a if a[k]==b[k]];changed=[k for k in a if a[k]!=b[k]]
assert all(a[k]==b[k] for k in ['asOf','denominatorNote','summaryGaps','pairedOnSalePercent','missingModels','unresolvedLeads','brandsResearchCompleted','brandsResearchRemaining','brandsDone','brandsRemaining','ageing'])
report={'status':'accepted_full_stage_v1_outputs','scope':'Independent bounded output/digest/report comparison. No reviewer catalogue hydration, consumer rerun, compiler or test execution.','artifacts':{k:meta(p) for k,p in {'manifest':D/'manifest.json','receipt':O/'stage-receipt.json','terminal':D/'run/terminal.json','report':O/'staged-report.json','carDigests':O/'car-digest-comparison.json','researchDigests':O/'research-field-digests.json','omissions':O/'portable-json-omissions.json'}.items()},'terminal':t,'checks':{'acceptedMazdaIntermediateCarAnd14FieldDigestsExact':True,'currentCars':413,'stagedCars':417,'tierOneVersions':340,'onSaleVersions':307,'unchangedPeerCarDigests':406,'retainedChangedCarDigests':7,'newCarDigests':4,'selected11CarPackPortableBytesEqualV7':True,'selectedFactClaimsEqualV7':205,'availabilityClaims':11,'beforeOmissions':16,'afterOmissions':20,'newActualProducerProofs':4,'otherBrandProgressExact':55,'nonSkodaGapRowsExact':True,'nonSkodaWithinBasisGroupRankOrderAndExclusionsExact':True,'coreCountAndGradeDeltasExactlySkodaContribution':True,'reconciliationNonSkodaIssuesExact':True,'currentMakerListsAdded':3,'currentMakerVersionsAdded':7,'residualMembershipGaps':4,'all134RuntimePinsUnchanged':True,'reportRankingGroupOrderChange':'Seats and towing flattened list order changes because existing discovery sorts basis groups by size; within each exact class/basis/unit group every non-Škoda member/order is unchanged.'},'coverage':{'reviewedCoreCells':4902,'totalCoreCells':5219,'strictGaps':372,'skodaCoreConfirmed':161,'skodaCoreCheck':26,'skodaCriteria':bb['Škoda']['criteria'],'globalCriteria':{x['id']:x['pass'] for x in b['criteria']},'rankDeltas':rankdeltas,'unchangedTopLevelFields':unchanged,'changedTopLevelFields':changed},'checkHistory':'Initial reviewer harness incorrectly required flattened rank order across changing basis-group sizes. It failed on seats/towing. Actual reporter and discovery source confirm group ordering by count; corrected harness reconstructs every exact class/basis/unit group, verifies complete non-Škoda member/order equality within each group, and retains all exclusion checks. Original harness preserved. No candidate or production change.', 'limitations':['Current source registration and fresh normal validation/report equality are not established by a staged pass.','No new canonical recapture or full feature-comparison replay; retained digest chain is explicitly derived.','All C1 membership gaps, broader residual census questions, whole-market independent-list closure, current TypeScript/build/full-test aggregate and real-device checks remain open.']}
p=Path('/tmp/skoda-review/full-stage-v1-result-acceptance.json');p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(meta(p)));print(json.dumps(report['checks']));print(json.dumps(report['coverage']))
