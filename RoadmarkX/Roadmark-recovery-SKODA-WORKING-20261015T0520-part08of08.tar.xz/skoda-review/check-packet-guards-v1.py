import json,hashlib
from pathlib import Path
P=Path('/tmp/skoda-packet/v2/skoda-2026-10-15.json');N=Path('/tmp/skoda-research/normalized-review-v3.json');B=Path('/tmp/skoda-research/retained-before-cars.json');I=Path('/tmp/skoda-research/source-index-review-v2.json');R=Path('/tmp/skoda-research/retained-before-selection-receipt.json')
p=json.loads(P.read_text());n={v['id']:v for v in json.loads(N.read_text())['variants']};b={v['id']:v for v in json.loads(B.read_text())};idx=json.loads(I.read_text())['sources'];receipt=json.loads(R.read_text());sid=lambda k:p['id']+'-'+k
issues=[];checks={};hashes=[]
for x in receipt['selectedCarDigests']:
 raw=json.dumps(b[x['id']],ensure_ascii=False,separators=(',',':')).encode();h=hashlib.sha256(raw).hexdigest()
 if h!=x['sha256']:issues.append('Retained digest differs '+x['id'])
 hashes.append({'id':x['id'],'sha256':h,'matchesAcceptedIndex':h==x['acceptedIndexRow']['afterSha256']})
for g in p['versionGuards']:
 exp={k:b[g['variantId']][k] for k in ['id','modelId','brand','model','trim','year','generation','vehicleClass','drive']}
 if g['before']!=exp:issues.append('Version guard differs '+g['variantId'])
checks['fullVersionGuards']=len(p['versionGuards'])
sources={x['id']:x for x in p['sources']};fmap={}
for f in p['facts']:
 vid=f['variantId'];a=f['after'];k=a['key'];original=b.get(vid,{}).get('facts',{}).get(k)
 if f['before']!=original:issues.append('Full fact before differs '+vid+'.'+k)
 exp=n[vid]['coreFacts'].get(k,n[vid]['extraFacts'].get(k))
 if exp is None:issues.append('Unexpected packet fact '+vid+'.'+k);continue
 for x in ['key','value','unit','basis','comparisonBasis','status','buyerGrade']:
  if a[x]!=exp[x]:issues.append('After/normalized mismatch '+vid+'.'+k+'.'+x)
 if a['sourceIds']!=[sid(s) for s in exp['sourceKeys']]:issues.append('Fact source mapping differs '+vid+'.'+k)
 if a['qualifications']!=[exp['locator'],*exp['qualifications']]:issues.append('Fact qualifications differ '+vid+'.'+k)
 if a['gradeReview']['sourceIds']!=a['sourceIds'] or a['gradeReview']['evidenceScope']!=exp['evidenceScope']:issues.append('Review binding differs '+vid+'.'+k)
 if a['date']!='2026-10-15' or a['market']!='AU':issues.append('Date/market mismatch '+vid+'.'+k)
 if exp.get('conflictId'):
  if not a['issues'] or any(i['priority']!='field_hold' for i in a['issues']):issues.append('Conflict hold missing '+vid+'.'+k)
 if k=='price_aud':
  if a['priceEvidence']['rung']!=3 or a['priceEvidence']['rankingEligible']!=exp['rankingEligible']:issues.append('Price provenance differs '+vid)
 fmap[(vid,k)]=a
checks['fullFactBeforeGuards']=len(p['facts'])
for t in p['brandTerms']:
 k=t['key'];a=t['fact'];exp=n[next(iter(n))]['coreFacts'][k]
 for x in ['key','value','unit','basis','comparisonBasis','status','buyerGrade']:
  if a[x]!=exp[x]:issues.append('Brand term normalized mismatch '+k+'.'+x)
 if set(t['applicableVariantIds'])!=set(n) or set(t['before'])!=set(n):issues.append('Term applicability mismatch '+k)
 for vid in t['applicableVariantIds']:
  if t['before'][vid]!=b.get(vid,{}).get('facts',{}).get(k):issues.append('Full brand term before differs '+vid+'.'+k)
  fmap[(vid,k)]=a
checks['fullTermBeforeGuards']=sum(len(t['before']) for t in p['brandTerms'])
for a in p['availability']:
 vid=a['variantId'];orig=b.get(vid)
 exp={'availability':orig['availability'],'evidence':orig['availabilityEvidence']} if orig else None
 if a['before']!=exp:issues.append('Full availability before differs '+vid)
 nv=n[vid]['availability'];after=a['after'];ev=after['evidence']
 if after['availability']!=nv['recordState'] or ev['sourceIds']!=[sid(x) for x in nv['sourceKeys']]:issues.append('Availability binding mismatch '+vid)
 for k in ['orderStatus','stockStatus','physicalStockVerified','factoryOrderAcceptanceVerified','factoryBuildSpecificationVerified','deliveryToBuyerVerified','qualifications']:
  if ev[k]!=nv[k]:issues.append('Availability exact mismatch '+vid+'.'+k)
checks['fullAvailabilityBeforeGuards']=len(p['availability'])
for s in p['summaries']:
 vid=s['variantId']
 for typ in ['strength','tradeoff']:
  cur=s[typ];exp=n[vid]['summary'][typ]
  if cur['label']!=exp['label'] or cur['text']!=exp['text'] or [d['key'] for d in cur['dependencies']]!=exp['dependencies']:issues.append('Summary mismatch '+vid+'.'+typ)
  for d in cur['dependencies']:
   if d['expected']!=fmap[(vid,d['key'])]:issues.append('Full summary expected differs '+vid+'.'+d['key'])
checks['supportedSummaries']=len(p['summaries']);checks['fullSummaryDependencies']=sum(len(s[t]['dependencies']) for s in p['summaries'] for t in ['strength','tradeoff'])
for id,s in sources.items():
 key=id.removeprefix(p['id']+'-');orig=idx.get(key)
 if not orig:issues.append('Missing source index '+id);continue
 if s['url']!=orig['url'] or s['capture_sha256']!=orig.get('rawSha256'):issues.append('Source capture binding differs '+id)
 if 'skoda.com.au/' in s['url'] and s['source_type']!='manufacturer_au_publication':issues.append('Wrong maker type '+id)
 if key.startswith('dealer-') and s['source_type']=='manufacturer_au_publication':issues.append('Dealer promoted '+id)
for f in fmap.values():
 if any(x not in sources for x in f['sourceIds']):issues.append('Unbound fact source')
checks['boundSources']=len(sources)
if p['features'] or p['configurationUpdates'] or p['versionUpdates']:issues.append('Unexpected changes outside evidence scope')
for v in p['variants']:
 nv=n[v['id']]
 for dest,src in [('model_id','modelId'),('brand','brand'),('model','model'),('trim','trim'),('model_year','formalModelYear'),('vehicle_class','vehicleClass')]:
  if v[dest]!=nv[src]:issues.append('New variant identity mismatch '+v['id']+'.'+dest)
 if v['drive']!=nv['coreFacts']['drive']['value']:issues.append('New variant drive mismatch')
 if v['price_aud'] is not None or v['range_km'] is not None or v['seats'] is not None:issues.append('Duplicate prehydrated core values')
checks['newVariantIdentityMappings']=len(p['variants']);checks['newModels']=len(p['models'])
r={'status':'pass' if not issues else 'fail','scope':'Independent small JSON checks against exact retained seven-car baseline and normalized source review. No production import/hydration or application guard execution. Canonical packet roundtrip, portable, rankings and unchanged-peer checks remain separate consumer work.','artifacts':[{'path':str(x),'sha256':hashlib.sha256(x.read_bytes()).hexdigest(),'bytes':x.stat().st_size} for x in [P,N,B,I,R]],'checks':checks,'retainedCarDigests':hashes,'issues':issues}
out=Path('/tmp/skoda-review/packet-v2-independent-guard-check.json');out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'status':r['status'],'checks':checks,'issues':issues},ensure_ascii=False))
