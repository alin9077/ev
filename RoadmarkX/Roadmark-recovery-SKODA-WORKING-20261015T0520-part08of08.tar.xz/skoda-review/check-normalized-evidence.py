import json,hashlib,sys
from pathlib import Path
from collections import Counter
p=Path(sys.argv[1]); data=json.loads(p.read_text()); idxp=Path('/tmp/skoda-research/source-index-review-v2.json');idx=json.loads(idxp.read_text())['sources']
# Independently transcribed from the four Australian MY-specific PDFs, current named-version price pages, body-wide seat statements and visually reviewed warranty PDF pages 1-4.
keys=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg']
expected={
'skoda_elroq_my27__select_60__20261010':[49990,406,58,105,26,11,5,470,8.5,140,'RWD',4488,1884,1625,1000],
'skoda_elroq_my27__select_85__20261010':[59990,521,77,165,29,11,5,470,6.6,210,'RWD',4488,1884,1625,1000],
'skoda_elroq_my26__select_60__20261015':[49990,395,59,165,24,11,5,470,8,150,'RWD',4488,1884,1625,1000],
'skoda_elroq_my26__130_years_edition__20261015':[69990,529,77,135,28,11,5,470,6.6,210,'RWD',4488,1884,1625,1000],
'skoda_enyaq_suv_my27__select_60__20261010':[55990,431,58,105,26,11,5,585,8.6,140,'RWD',4658,1879,1622,1000],
'skoda_enyaq_suv_my27__sportline_85__20261010':[64990,551,77,165,29,11,5,585,6.6,210,'RWD',4658,1879,1622,2000],
'skoda_enyaq_coupe_my27__sportline_85__20261010':[70990,565,77,165,29,11,5,570,6.6,210,'RWD',4658,1879,1623,2000],
'skoda_enyaq_suv_my27__rs__20261010':[79990,546,77,165,29,11,5,585,5.4,250,'AWD',4653,1879,1615,2200],
'skoda_enyaq_coupe_my27__rs__20261010':[80990,557,77,165,29,11,5,570,5.4,250,'AWD',4653,1879,1618,2200],
'skoda_enyaq_suv_my26__select_60__20261015':[54990,410,59,165,24,11,5,585,8.1,150,'RWD',4658,1879,1622,1000],
'skoda_enyaq_coupe_my26__sportline_85__20261015':[68990,561,77,135,28,11,5,570,6.7,210,'RWD',4658,1879,1623,1000],
}
assert set(expected)=={v['id'] for v in data['variants']}
issues=[]; grades=Counter();source_keys=set(); rows=[]
for v in data['variants']:
 id=v['id'];f=v['coreFacts']; count=0
 ex=dict(zip(keys,expected[id]));ex.update(warranty='7 years / unlimited km',battery_warranty='8 years / 160,000 km; below 70% capacity cover')
 for k,value in ex.items():
  if f[k]['value']!=value:issues.append(f'{id}.{k}: value {f[k]["value"]!r} != expected {value!r}')
  else: count+=1
  grades[f[k]['buyerGrade']]+=1
  source_keys.update(f[k]['sourceKeys'])
  want='check' if k in ['price_aud','towing_braked_kg'] or (id in ['skoda_enyaq_suv_my27__rs__20261010','skoda_enyaq_coupe_my27__rs__20261010'] and k in ['dc_peak_kw','dc_charge_time_min']) else 'confirmed'
  if f[k]['buyerGrade']!=want:issues.append(f'{id}.{k}: unexpected buyer grade')
  if f[k]['status']!=('standard' if want=='confirmed' else 'conditional'):issues.append(f'{id}.{k}: grade/status inconsistency')
  if f[k].get('conflictId') and f[k]['rankingEligible']:issues.append(f'{id}.{k}: conflict ranked')
 if f['width_mm']['comparisonBasis'] or f['width_mm']['rankingEligible']:issues.append(id+': width scope improperly assumed')
 for attr in ['physicalStockVerified','factoryOrderAcceptanceVerified','factoryBuildSpecificationVerified','deliveryToBuyerVerified']:
  if v['availability'][attr]:issues.append(id+': '+attr+' asserted')
 pe=f['price_aud']['priceEvidence']
 if pe['rung']!=3 or pe['comparisonBasis']!='Driveaway':issues.append(id+': wrong price basis')
 for summary in v['summary'].values():
  if any(k not in f for k in summary['dependencies']):issues.append(id+': missing summary dependency')
 rows.append({'id':id,'sourceValuesMatched':count,'coreCells':17})
source_texts=[]
for k in sorted(source_keys):
 if k not in idx:issues.append('Missing source '+k);continue
 s=idx[k]
 if not s['url'].startswith('https://www.skoda.com.au/'):issues.append('Non-AU maker core source '+k)
 if s.get('textPath'):
  q=Path(s['textPath']);h=hashlib.sha256(q.read_bytes()).hexdigest();source_texts.append({'key':k,'path':str(q),'sha256':h,'matchesIndexedText':h==s['textSha256']})
  if h!=s['textSha256']:issues.append('Source text hash mismatch '+k)
r={'status':'pass' if not issues else 'fail','scope':'Small independent data/source comparison only. No production application loader, hydration, compiler, test suite, large scan or full source capture. PDF binary hashes not freshly recomputed; original source index retained. Warranty and drivetrain visual checks manually completed. Census/packet/consumer acceptance remains separate.','normalized':{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()},'sourceIndex':{'path':str(idxp),'sha256':hashlib.sha256(idxp.read_bytes()).hexdigest()},'coreCells':187,'coreGrades':dict(grades),'rows':rows,'indexedSourceTextChecks':source_texts,'issues':issues}
out=Path('/tmp/skoda-review')/(p.stem+'-evidence-check.json');out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'status':r['status'],'coreCells':187,'coreGrades':dict(grades),'issues':issues}))
