import json,hashlib
from pathlib import Path
files={
'packet':'/tmp/skoda-packet/v3/skoda-2026-10-15.json',
'normalized':'/tmp/skoda-research/normalized-review-v3.json',
'sourceIndex':'/tmp/skoda-research/source-index-review-v2.json',
'census':'/tmp/skoda-research/census-review-v3.json',
'reconciliation':'/tmp/skoda-packet/v3/m1-skoda-market-reconciliation-2026-10-15.json',
'normalizedChecks':'/tmp/skoda-review/normalized-review-v3-evidence-check.json',
'packetChecks':'/tmp/skoda-review/packet-v3-independent-guard-check-corrected-harness.json',
'baselineReceipt':'/tmp/skoda-research/retained-before-selection-receipt.json'
}
artifacts={k:{'path':p,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest(),'bytes':Path(p).stat().st_size} for k,p in files.items()}
r={
'schemaVersion':1,'status':'accepted_evidence_packet_and_census_only','reviewedAt':'2026-10-15','reviewer':'Independent Škoda M1 evidence reviewer',
'artifacts':artifacts,
'outcome':'No remaining blocking evidence, identity, source authority, full retained beforeguard, or summary dependency findings in the exact frozen candidate. Actual application staging and consumer acceptance are separate and pending.',
'acceptedScope':{
 'existingMY27Refreshes':7,'separatelyEvidencedMY26ResidualAdditions':4,'coreCells':187,'confirmedCoreCells':161,'checkCoreCells':26,'supplementalGrossAndConflictObservations':18,'specificFactUpdates':183,'sharedTerms':2,'effectiveSharedTermCells':22,'newModels':3,'sources':27,'availabilityReviews':11,'summaries':11,'fullSummaryDependencies':45,
 'currentMakerVersionLists':'Three current MY27 cohorts comprising two Elroq, three Enyaq SUV and two Enyaq Coupe versions. Official MY-specific PDFs enumerate exact columns; current maker FAQ and named pages corroborate. Residual cohorts and future/global leads remain separate.',
 'residualEvidence':'Elroq MY26 Select60: Essendon New detail, exact NY MY26 and stock K10246; Elroq MY26 130 Years: Kevin Dennis New detail, exact NY MY26 and stock S162245; Enyaq MY26 Coupe Sportline85: Alto New detail, exact MY26 Coupe dealer description and stock A635147; Enyaq MY26 Select60: current maker finance campaign expressly includes new and demonstrator MY26 stock. No ad is treated as physical stock or factory acceptance.',
 'prices':'All selected prices are named-version maker driveaway-from offers at rung3. No explicit national coverage or before-on-road basis is invented. MY26 Elroq brochure prints no expiry; its price is labelled as such. Three current MY27 Enyaq page/PDF price conflicts are separately preserved and unranked.',
 'charging':'DC peak is taken from the maximum capacity row; the input station in a time row is not substituted for peak. All time windows explicitly say10–80%. Two MY27 RS web/PDF pairs remain Check, field-held and unranked. MY26 and MY27 batteries, power, range and charging remain separate.',
 'dimensions':'Exact maker widths1884mm Elroq and1879mm Enyaq are Confirmed; mirror scope stays unknown, comparison basis blank, ranking eligibility false. No missing mirror protocol is invented.',
 'warranty':'Australian warranty PDF pages1–4 visually inspected. Seven years unlimited km for standard use,7yr/150k commercial exceptions and demonstrator commencement remain explicit. BEV battery8yr/160k and below70% initial net capacity trigger verified.78/74/70% at3yr60k/5yr100k/8yr160k are remedy levels, not alternative claim triggers; new/reconditioned components and exclusions retained.',
 'guards':'All seven retained car hashes match the accepted derived storage receipt with JSON.stringify-plus-newline convention. Seven complete identity guards,183 entire fact before rows,22 warranty before rows and11 availability before rows exactly match retained objects or the inspected newVariantCar initializer. All45 complete summary expected-fact objects match their candidate after facts.',
 'authority':'All core factual sources are exact Australian manufacturer material. All three dealers are dealer_advertisement; both secondary brand cross-checks remain secondary. Capture references map to the source index. Selected source text hashes were recomputed; large PDF binaries were not freshly rehashed.',
 'protectedScope':'Packet contains zero equipment edits, configuration updates or version identity updates. Reviewer made no repository/source/live-site edits and invoked no production hydration, test suite, compiler or compression.'
},
'findingsResolved':[
 {'finding':'Both MY27 Enyaq Sportline85 summaries said1,000kg despite exact2,000kg core/source values.','resolution':'Normalizedv3 and final packet summaries now say2,000kg, with correct towing dependency.'},
 {'finding':'MY27 Coupe Sportline85 alternate brochure price was63,990 instead of68,990.','resolution':'Normalizedv3/censusv3/final packet preserve68,990 brochure versus70,990 page conflict.'},
 {'finding':'Earlier residual census omitted explicit New MY25 related-stock cards already visible in Essendon capture.','resolution':'Censusv3 explicitly retains the exact related-card leads as unresolved, without claiming a verified final listing or stock.'},
 {'finding':'Non-admitted MY26 SUV RS boot conflict wording implied an integrated Check fact.','resolution':'Censusv3 labels it non-admitted residual lead only with no live/candidate grade or ranking decision.'},
 {'finding':'Essendon and Kevin Dennis sources incorrectly had maker publisher/type.','resolution':'Final packetv3 changes exactly their two publishers and two source_type values; no other packet fields differ fromv2.'}
],
'knownOpenWork':[
 'Broader residual MY25/MY26 availability and manufacturer-MY matching remain unresolved; no nationwide absence claim is accepted.',
 'Elroq Sportline85 explicitly has orders opening early2027 and remains a future lead. Epiq, Peaq and ElroqRS leads do not become orderable versions.',
 'Two independent whole-market lists remain unreconciled. Brand cross-checks are not whole-market C1 closure.',
 'Source-conflicted values and unknown measurement scopes must remain excluded in actual ranking execution.',
 'Actual production guard replay, canonical configuration parity, actual citation/detail packs, portable roundtrip, full current derived peer/report equality and registered validation are not established by this evidence-only acceptance.',
 'Current full TypeScript, production build, full-project test aggregate and real-device verification remain open under the parent work record.'
],
'checkHistory':{
 'normalized':'Independent187-value/source/grade comparison passed on normalizedv3.',
 'initialPacketHarness':'Original small JSON harness and failed receipt are preserved. Reviewer corrected its own absent newline in accepted car-hash convention and modeled new-variant availability initializer rather than assuming null. Those harness issues were not candidate errors. The correctedv2 harness isolated only two real dealer authority errors.',
 'finalPacket':'Corrected harness passes finalpacketv3 with zero issues. These are read-only bounded JSON/evidence checks, not application test or consumer passes.'
}}
out=Path('/tmp/skoda-review/evidence-packet-census-v3-acceptance.json');out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'status':r['status'],'artifactHashes':{k:v['sha256'] for k,v in artifacts.items()}},ensure_ascii=False))
