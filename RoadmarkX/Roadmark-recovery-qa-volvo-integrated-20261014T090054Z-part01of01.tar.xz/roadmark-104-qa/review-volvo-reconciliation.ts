import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {catalogue,research,effectiveFeatures,pack} from '../roadmark-104/src/lib/data.ts';
import {prepareBrandResearch,applyBrandUpdates} from '../roadmark-104/src/lib/brand-updates.ts';
import {brandUpdatePackets} from '../roadmark-104/src/lib/brand-update-registry.ts';
import {compiledSource} from '../roadmark-104/tests/helpers/compiled-source.ts';
import {buildCoverageReport,isOnSale,isTierOne,type ReportInput} from '../roadmark-104/scripts/reporting/reports.ts';
import {combineM1Reconciliations,buildMarketReconciliation} from '../roadmark-104/scripts/reporting/m1-reconciliation.ts';
const R='/tmp/volvo-research/',Q='../roadmark-104-qa/volvo-independent-review/';
const read=(f:string)=>JSON.parse(fs.readFileSync(R+f,'utf8'));const sha=(f:string)=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');const plain=(x:any)=>JSON.parse(JSON.stringify(x));
const hashes=Object.fromEntries(['volvo-2026-10-14.json','volvo-reconciliation-2026-10-14.json','staged-report.json','staged-packs.json'].map(f=>[f,sha(R+f)]));
assert.equal(hashes['volvo-2026-10-14.json'],'f2dccd648ad2f8ebaa6637d6f76e9991dcffc4288704599e4a3482d6e1bfedd6');assert.equal(hashes['volvo-reconciliation-2026-10-14.json'],'667edab8cac2e588397f780ed4b4524c735fd7452162c8d2286fd7927dfefb8a');
const codeHashes=Object.fromEntries(['scripts/reporting/load.ts','scripts/reporting/m1-reconciliation.ts','scripts/reporting/reports.ts','data/m1-brand-updates/registry.json'].map(f=>[f,sha(f)]));
console.log('Loading independent reporting input');
const p=read('volvo-2026-10-14.json'),r=read('volvo-reconciliation-2026-10-14.json');assert(!brandUpdatePackets.some(x=>x.id===p.id));
const before=catalogue(),rd=research(),data=prepareBrandResearch(rd,[p]),cars=applyBrandUpdates(before,data,[p]);
const staged=compiledSource('src/lib/data.ts',{'./brand-update-registry':{brandUpdatePackets:[...brandUpdatePackets,p]}}) as {pack:typeof pack};
const selected=cars.filter(c=>c.brand==='Volvo'&&isTierOne(c)),packs=Object.fromEntries(selected.map(c=>[c.id,staged.pack(c.id,{cars,data})]));
assert.deepEqual(plain(packs),read('staged-packs.json'),'Owner staged packs must exactly equal independent actual runtime');
const loader=compiledSource('scripts/reporting/load.ts',{'../../src/lib/data':{research:()=>rd,catalogue:()=>before,effectiveFeatures}}) as {loadReportInput:()=>ReportInput};
const input=loader.loadReportInput();input.cars=cars;input.sources=data.sources;input.features=input.features.filter(f=>!packs[f.variant_id]).concat(Object.values(packs).flatMap(v=>v.features));input.m1Reconciliation=combineM1Reconciliations(input.m1Reconciliation!,r);
console.log('Building complete coverage and reconciliation');
const report=buildCoverageReport(input,'2026-10-14');assert.deepEqual(plain(report),read('staged-report.json'),'Complete independent report differs from staged report');
const volvo=report.brandProgress.find(b=>b.brand==='Volvo')!;assert.deepEqual(volvo.criteria,{C1:false,C2:true,C3:true,C4:true,C5:false,C6:true});assert.equal(volvo.done,false);assert.equal(volvo.researchCompleted,false);
assert.equal(report.reconciliation.independentListCount,0);assert.equal(report.criteria.find(c=>c.id==='C1')!.pass,false);
const onSale=cars.filter(c=>isTierOne(c)&&isOnSale(c));const guards:string[]=[];
for(const [name,mutate] of [
 ['missing exact current member',(x:any)=>x.currentVersionReviews.find((v:any)=>v.brand==='Volvo'&&v.modelId==='volvo_ex40_my27').versions.pop()],
 ['wrong exact model year',(x:any)=>x.currentVersionReviews.find((v:any)=>v.brand==='Volvo'&&v.modelId==='volvo_ex40_my27').versions[0].modelYear=2025],
 ['stale exact-model review',(x:any)=>x.currentVersionReviews.find((v:any)=>v.brand==='Volvo'&&v.modelId==='volvo_ex40_my27').checkedAt='2025-10-14']
] as const){const q=structuredClone(input.m1Reconciliation!);mutate(q);const changed=buildMarketReconciliation(q,onSale,input.inventory,'2026-10-14');assert.equal(changed.pass,false);assert(changed.issues.filter(x=>x.brand==='Volvo').length>report.reconciliation.issues.filter(x=>x.brand==='Volvo').length,name+' did not expose additional blocker');guards.push(name);}
for(const [f,h] of Object.entries(hashes))assert.equal(sha(R+f),h,'Artifact drift');for(const [f,h] of Object.entries(codeHashes))assert.equal(sha(f),h,'Code drift');
const out={status:'passed',checkedAt:'2026-10-14',hashes,codeHashes,actualPacksEqual:true,completeCoverageReportEqual:true,reconciliationActualComposition:true,reconciliationNegativeGuards:guards,brandCriteria:volvo.criteria,researchCompleted:volvo.researchCompleted,strictDone:volvo.done,closureIssues:volvo.closureIssues,rankings:volvo.rankings};fs.writeFileSync(Q+'independent-reconciliation-replay.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out,null,2));
