# Independent Volvo evidence and guarded-candidate review

Reviewed 14 October 2026. Verdict: **approve the exact candidate for guarded integration, with open census and ranking limitations**. This is not approval of Volvo research completion or global M1 C1–C6 closure. The reviewer did not register, publish, change the base data, or change the evidence-grading implementation. Root subsequently registered the exact approved candidate at 08:54 UTC; the registered full-coverage output subsequently matched the staged report exactly at the JSON object level. Root integration tests passed 82/82 and structural validation exited 0; TypeScript/lint and the final backup gate remain root-owned.

## Approved immutable candidate

- Packet `volvo-2026-10-14.json`: SHA-256 `f2dccd648ad2f8ebaa6637d6f76e9991dcffc4288704599e4a3482d6e1bfedd6`
- Reconciliation `volvo-reconciliation-2026-10-14.json`: SHA-256 `667edab8cac2e588397f780ed4b4524c735fd7452162c8d2286fd7927dfefb8a`
- Source manifest: `d6130d02f8898567b367765596d66d4022a58bfeae0e7f3a17366439b59c651f`
- Final artifact manifest: `f51170f55c5cf294bfcae34c1324b0cea4a571e483d522a49129b4f8d808dc9b`
- Independent full-baseline replay result: `dfb6ae946b35f4846fd46955ecbe33556d42b579aeb98826be9a2585d57f0c4f`

The manifests independently verify 327 source/support files and 42 root artifacts, 369 distinct files in total. Every candidate source locator/hash was checked, including 286 locator references resolving to 152 physical capture files. The replay reports 163 distinct locator strings before path normalization. All 143 source rows exactly match the source index. The two staged repository copies match the approved packet/reconciliation bytes.

## Scope and completion boundaries

The candidate covers 20 exact versions: nine existing MY2027 EX30/EX40/EX90/ES90 configurations, nine advertised-new MY2026 residual versions, and two provisional MY2027 EX60 Ultra P6/P10 configurations. It adds 11 versions, makes 647 guarded fact edits, supplies three complete-scope Australian terms, and updates 224 equipment answers and 20 fact-dependent strength/trade-off pairs.

All 340 core cells are reviewed: 170 Confirmed, 23 Check, 147 Reported. No missing value has been relabelled Not published to inflate completion. Where a secondary or clearly identified sibling supplies a value, it remains Reported. Applicable shared Australian body facts and brand terms retain earned Confirmed grades; generic laboratory/model-year caveats are not automatic downgrades.

The staged Volvo criteria are C1 false, C2 true, C3 true, C4 true, C5 false, C6 true. `researchCompleted` and strict `done` remain false. The six rankings have 7 price, 9 range, 13 DC-time, 0 seats, 0 boot, and 2 braked-towing entries among 18 on-sale versions. The two provisional EX60 versions remain outside that denominator. A confirmed number does not automatically establish an eligible comparison basis.

C1 remains open because:

- Two stale MY2025 EX30 New advertisements, Single stock 51658 and Twin stock 5711V, have not been resolved to fresh current origin inventory
- MY2026 EX30 Plus stock 13702716 has an advertised-year/VIN-code conflict; its condition is retained rather than silently corrected
- Full residual EX30 MY2026 membership is not closed, even though three individually evidenced versions are included
- EC40/C40 and older electric XC40 Recharge residual-new supply is not disproved by unavailable configurators or individual sold/demo listings
- EX60 current accepted orders and delivery availability remain unverified
- Brand-only CarExpert/CarsGuide directories are not substituted for the two independently published whole-market lists required by C1

The actual staged report retains seven Volvo C1 blockers: three exact-version membership blockers, three inherited record/lead dispositions, and the independent-list requirement.

## Material source checks and corrections

**Availability.** Dealer New headings were checked against body text. Berwick C40 stock 11048122 and EX30 stock 13702719 are sold and cannot establish live New availability. Doncaster EX30 MY2025 stock 11966122 is sold/demo and is excluded individually, not used as proof of model-family absence. Live Doncaster EX30 MY2026 Ultra stock 12974600 and Springwood/Cricks MY2026 Cross Country HL2495 supplied better exact-stock evidence. Listings and current maker configurations are not proof of physical stock or factory acceptance: both verification flags remain false across all 20 versions.

**EX60.** Current Australian maker wording is “Coming 2027”, superseding older secondary late-2026 delivery predictions. Historical explicit orders-open reporting is retained with its date and limitation. The versions stay provisional. The year-only arrival remains in qualifications/summary; the existing badge parser does not support year-only timing, so no invented month or quarter is supplied. Preliminary certification conditions remain explicit.

**Price.** Actual localized NSW 2000 breakdowns distinguish list price from on-road estimates. Five compact MY2027 prices ($49,990/$54,990/$62,990/$69,990/$74,990), ES90 Plus ($88,880), and EX60 P6 ($86,990) have rung-1 evidence. EX90 Plus/Ultra ($103,453/$124,991), ES90 Ultra ($104,222), and EX60 P10 ($99,606) retain the maker's unadjusted configuration amount because LCT is separately displayed: rung 3, Check, blank comparison basis, unranked. No tax-inclusive list or driveaway value is synthesized. Localized driveaway estimates remain separate qualified facts. The MY2026 EX30 Plus $55,990 campaign retains the named trim, offer period and order/delivery conditions; it is not automatically applied to the MY2027 P5 alias. Exact residual secondary prices remain rung 5 above individual dealer rung-6 alternatives.

**Charging and model year.** Current EX90 MY2027 is 800 V; outgoing specifications are not blindly transferred. Manufacturer station ratings remain distinct from vehicle DC peak, and every time retains its state-of-charge window and test context. Overseas technical sheets were visually checked by table column and are explicitly Reported with origin-market metadata. They cannot satisfy AU-primary authority. For example, the 300 kW Australian EX90/ES90 test station is not treated as a 300 kW vehicle peak. EX40 support/model time differences and EX60 Australian/global test differences are retained rather than averaged.

**Cargo, dimensions and towing.** Open/max storage, seat state, front storage and closed compartments remain separate. AU maker open-boot values can earn Confirmed without an invented VDA/SAE label; ranking comparison basis remains blank when the measurement boundary is not established. EX30 Cross Country-specific dimensions were checked rather than inherited from the normal EX30. Unqualified maker “trailer maximum” wording is not silently promoted to braked towing; the exact secondary braked claim remains Reported where appropriate.

**Terms.** Vehicle warranty retains private five-year/unlimited cover, the commercial/hire/taxi/paid-goods-or-people 150,000 km cap, and qualifying exclusions. The AU HV baseline is eight years/160,000 km with a below-70% trigger and qualified repair/reconditioned remedy, not a promise of 100% capacity. EX60 ten-year/240,000 km claims are separately Reported because exact AU extension terms were not recovered. Roadside retains the current five-year entitlement, taxi exclusion, under-3,500 kg towing condition and driver-plus-four travel-benefit limit; it is not assumed to cover every occupant of a seven-seat EX90. Older eight-year roadside wording is not transferred to current vehicles.

## Independent executable proof

`review-volvo-independent.ts` ran the actual application functions and actual buyer-pack module against the exact packet. Its final run exited 0 with:

- Complete original and generated-new feature baseline equality, including canonical driveaway and roadside projections
- Exact version/fact/feature before snapshots, 224 post-fact equipment dependencies, summary dependencies, full brand-term scope, source collision and availability guards
- Actual pack pipeline equality, 707 reviewed fact citations, all 224 equipment citations, earned grades and exact portable roundtrip
- Unchanged other-brand cars, Volvo Tier 2, prior sources and all 91 original data files before registration
- 12 negative mutation classes rejected, 27 overseas-source promotion checks rejected, and 63 ranking withdrawal/hold/access/freshness/basis/ageing checks rejected
- No configuration updates: zero configuration dependencies or configuration-mutation claims are asserted for this packet

After root registration, 90 original data files still match their initial hashes. For the sole changed original file, the registry, removing exactly the approved Volvo append restores the initial byte hash. The live report loader contains exactly one Volvo reconciliation import and one composition entry. The reviewer then compared root’s completed registered full-coverage JSON to the staged report, with complete object-level equality. The registered report hash is `ad9312ad2ca7668911a6423fa7dfa5cc35c00e3f8af0c9cb74b7366e7b34dad7`; its different raw byte hash reflects serialization, not content. This read-only comparison validates the composed outcome without a duplicate catalogue process.

The optional additional reconciliation replay correctly stopped before catalogue work when it detected that root had already registered the packet. It was not a candidate failure and did not duplicate application. Its diagnostic log is retained.

## Failure transparency and privacy

The first candidate failed a real price-basis enum check for ES90 Plus. The owner corrected that enum, producing the approved f2dccd64… packet. The next run exposed a stale generated helper fixture: it had been captured before supplemental driveaway facts. The owner regenerated it; the final run restored full equality, without excluding canonical rows or weakening the explicit feature guards. Both original failure logs are retained.

Saved capture hash references point to the final sanitized bytes. The independent value-oriented scan of all 147 directly referenced text captures found no JWT, bearer credential, runtime credential assignment, private-key block or Set-Cookie header. Public configuration/stock IDs and factual source links are retained. The separate immutable-backup privacy gate is still required; this bounded scan is not presented as an exhaustive security certification.

## Evidence files

- `volvo-independent-review/independent-review-replay.json` and `.log`: final full guarded replay
- `volvo-independent-review/final-artifact-verification.json`: all approved hashes, manifest verification, privacy scope and root registry append proof
- `volvo-independent-review/registered-report-comparison.json`: complete registered/staged report equality and root test exits
- `volvo-independent-review/early-source-checks.json`: exact captured anchors for material source findings
- `volvo-independent-review/*page*.png`: local public-PDF column verification renders, not browser screenshots
- `volvo-independent-review/initial-e84368a9-enum-failure.log`: preserved real enum failure
- `volvo-independent-review/f2dccd64-projection-baseline-harness.log`: preserved helper-fixture mismatch

Approval remains bound to the exact hashes above. Changes to evidence, candidate values/grades, guards or implementation require a fresh review of the affected scope.
