# Volvo M1 candidate, 14 October 2026

Status: independently approved and registered by root at 08:54 UTC; root integration validation is running. This is a Volvo-only evidence review, not a claim that C1–C6 are complete.

## Scope and evidence

- 20 exact candidate versions: nine current MY2027 maker configurations, nine advertised-new MY2026 residual versions, and two provisional MY2027 EX60 versions.
- All 340 core cells reviewed. 170 Confirmed, 23 Check and 147 Reported. No unsupported unknown has been converted to Not published.
- 647 guarded fact edits, three shared Australian terms, 224 guarded equipment answers, and 20 fact-dependent strength/trade-off pairs.
- 143 source snapshots; 90 original data files remain byte-identical; the only changed original file is the independently approved root-only registry append, verified by exact removal of that one entry. Existing version identities and every edited before-state are guarded.
- Full CarExpert/CarsGuide brand directory transcription and maker powertrain accounting are in brand-model-list-reconciliation.json. Those brand directories do not count as independent whole-market C1 lists.

## Material decisions

Current maker EX60 pages say “Coming 2027”. Historical secondary orders-open reports had late-2026 timing. Both are retained, the two versions stay provisional, and no delivery month or accepted factory order is invented. The current renderer keeps year-only timing in detailed qualifications rather than a parsed arrival badge.

The five compact MY2027 configurations, ES90 Plus and EX60 P6 have exact maker list-price evidence. EX90 Plus/Ultra, ES90 Ultra and EX60 P10 separately display LCT, so their unadjusted maker configuration amounts remain Check and unranked. Exact Sydney NSW 2000 driveaway estimates are supplemental facts with reference-location and owner assumptions; Roadmark does not reconstruct prices by summing tax components.

DC station power is separate from vehicle peak. Australian named-version times retain their exact state-of-charge windows and test-station ratings. Overseas technical sheets are explicitly Reported and cannot earn an AU-primary grade. Open/max luggage and seat/load states stay distinct, with no invented VDA/ISO measurement label or addition of front/closed storage.

AU vehicle cover is five years/unlimited kilometres for private use, with the commercial/hire/taxi/paid-goods-or-people 150,000 km cap. The battery baseline is eight years/160,000 km with a below-70% trigger and qualified repair/reconditioned remedy. EX60 ten-year claims remain a separate Reported extension without recovered AU terms. Current roadside is five years, retaining taxi, under-3,500 kg towing and driver-plus-four support limits.

## Open census scope

- Two stale MY2025 EX30 New leads lack verified current origins. The MY2026 Plus dealer model-year label also conflicts with its VIN-coded year. Specific offers remain visible with those limitations; full residual membership is not closed.
- EC40/C40 and older XC40 Recharge electric-name residual supply is not disproved by unavailable configurators or individual sold/demo advertisements.
- EX60 timing and accepted current order/delivery availability remain unresolved.

## Verification and preservation

The final self-stage and independent replay both exited 0. The independent run asserts the complete refreshed generated-feature baseline, actual buyer-pack feature projection, exact citations, portable roundtrip, core completeness, before-state/dependency guards, negative mutations and unchanged other brands. It approves only packet f2dccd648ad2f8ebaa6637d6f76e9991dcffc4288704599e4a3482d6e1bfedd6 and reconciliation 667edab8cac2e588397f780ed4b4524c735fd7452162c8d2286fd7927dfefb8a. Root registered the exact approved packet at 08:54 UTC after matching full hashes. C1 and C5 remain incomplete; researchCompleted remains false.

Saved evidence excludes HTTP headers/cookies, runtime configuration/quote tokens, anti-bot challenge scripts, JWTs and authentication secrets. final-redaction-transformations.json records final content-preserving changes. The only saved PNG is a local render of the public EX60 technical PDF, not a browser screenshot. The backup process performs its own final privacy gate.
