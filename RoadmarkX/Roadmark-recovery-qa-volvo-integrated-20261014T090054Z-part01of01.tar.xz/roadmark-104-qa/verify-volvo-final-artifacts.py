from pathlib import Path
import json, hashlib, re
R=Path('/tmp/volvo-research').resolve()
REPO=Path('/workspace/scratch/586427eef9f2/roadmark-104').resolve()
Q=Path('/workspace/scratch/586427eef9f2/roadmark-104-qa/volvo-independent-review')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected={'volvo-2026-10-14.json':'f2dccd648ad2f8ebaa6637d6f76e9991dcffc4288704599e4a3482d6e1bfedd6','volvo-reconciliation-2026-10-14.json':'667edab8cac2e588397f780ed4b4524c735fd7452162c8d2286fd7927dfefb8a'}
for f,h in expected.items():assert sha(R/f)==h,f
manifest_results={}
all_files=set()
for name in ['source-hash-manifest.json','artifact-hash-manifest.json']:
 rows=read(R/name)['files']; seen=set()
 for row in rows:
  f=(R/row['path']).resolve();assert f.is_relative_to(R),row['path'];assert f not in seen,'duplicate '+row['path'];seen.add(f)
  assert f.stat().st_size==row['bytes'],row['path']+' byte count';assert sha(f)==row['sha256'],row['path']+' digest';all_files.add(f)
 manifest_results[name]={'sha256':sha(R/name),'files':len(rows),'verified':True}
p=read(R/'volvo-2026-10-14.json');replay=read(Q/'independent-review-replay.json');assert replay['status']=='passed';assert (Q/'independent-review-replay.exit').read_text().strip()=='0'
for k,v in expected.items():assert replay['approvedHashes'][k]==v
assert replay['approvedHashes']['source-hash-manifest.json']==sha(R/'source-hash-manifest.json')
for f,h in replay['codeHashes'].items():assert sha(REPO/f)==h,'code drift '+f
immutable=read(R/'immutable-data-before.json')
registration_proof=[]
for f,h in immutable.items():
 if f=='data/m1-brand-updates/registry.json':
  raw=(REPO/f).read_bytes();needle=b',\n    \"volvo-2026-10-14.json\"';assert raw.count(needle)==1;assert hashlib.sha256(raw.replace(needle,b'')).hexdigest()==h,'Registry is not an exact approved append';registration_proof.append({'path':f,'beforeSha256':h,'afterSha256':sha(REPO/f),'exactAppendVerified':True})
 else:assert sha(REPO/f)==h,'immutable drift '+f
assert sha(REPO/'data/m1-brand-updates/volvo-2026-10-14.json')==expected['volvo-2026-10-14.json']
assert sha(REPO/'data/m1-volvo-market-reconciliation-2026-10-14.json')==expected['volvo-reconciliation-2026-10-14.json']
registry=read(REPO/'data/m1-brand-updates/registry.json');assert registry['packets'].count('volvo-2026-10-14.json')==1
loader=(REPO/'scripts/reporting/load.ts').read_text();assert loader.count('import volvoReconciliation from \"../../data/m1-volvo-market-reconciliation-2026-10-14.json\";')==1;assert loader.count('volvoReconciliation as M1MarketReconciliation')==1
index=read(R/'source-index.json')['sources'];assert index==p['sources'],'Source index differs from packet'
captures=set()
for s in index:
 for lk,hk in [('capture_locator','capture_sha256'),('capture_text_locator','capture_text_sha256')]:
  if s.get(lk):
   f=(R/s[lk]).resolve();assert f.is_relative_to(R);assert sha(f)==s[hk];captures.add(f)
# Value-oriented scan; findings contain only pattern labels and paths, never values.
patterns={
 'JWT value':re.compile(rb'eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}'),
 'Bearer credential':re.compile(rb'(?i)authorization\s*[:=]\s*["\x27]?bearer\s+[A-Za-z0-9_./+\-=]{16,}'),
 'Runtime credential assignment':re.compile(rb'(?i)(?:access[_-]?token|refresh[_-]?token|id[_-]?token|csrf[_-]?token|client[_-]?secret|data-cce-token)\s*["\x27]?\s*[:=]\s*["\x27][A-Za-z0-9_./+\-=]{12,}["\x27]'),
 'Private-key block':re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
 'Set-Cookie header':re.compile(rb'(?im)^set-cookie\s*:\s*[^\r\n;]+=')
}
findings=[];scanned=0
for f in captures:
 if f.suffix.lower() in ['.pdf','.png','.jpg','.jpeg','.webp']:continue
 b=f.read_bytes();scanned+=1
 for name,pattern in patterns.items():
  if pattern.search(b):findings.append({'path':str(f.relative_to(R)),'pattern':name})
assert not findings,findings
report=read(R/'staged-report.json');volvo=next(x for x in report['brandProgress'] if x['brand']=='Volvo')
assert volvo['criteria']=={'C1':False,'C2':True,'C3':True,'C4':True,'C5':False,'C6':True}
assert volvo['researchCompleted'] is False and volvo['done'] is False
assert read(R/'volvo-reconciliation-2026-10-14.json')['publishedLists']==[]
for x in volvo['rankings']:assert replay['rankCounts'][x['key']]['ranked']==x['ranked']
audit=read(R/'evidence-completeness-audit.json');assert audit['coreGradeCounts']=={'confirmed':170,'check':23,'reported':147};assert audit['coreCells']==340
out={'status':'passed','checkedAt':'2026-10-14','approvalScope':'Exact guarded Volvo candidate only; strict research completion/C1-C6 not achieved; root subsequently registered the exact candidate; reviewer did not register or publish','approvedPacketHashes':expected,'manifestVerification':manifest_results,'allManifestFilesVerified':len(all_files),'immutableDataFilesVerified':len(immutable)-len(registration_proof),'authorizedRootRegistrationProof':registration_proof,'packetSourceRows':len(index),'uniquePacketCaptureFilesVerified':len(captures),'privacyValueScan':{'files':scanned,'patterns':list(patterns),'findings':findings,'scope':'All text captures directly referenced by candidate source rows; separate backup privacy gate remains required'},'fullBaselineFixtureSha256':sha(R/'new-feature-before.json'),'independentReplaySha256':sha(Q/'independent-review-replay.json'),'independentHarnessSha256':sha(Q.parent/'review-volvo-independent.ts'),'independentReplayLogSha256':sha(Q/'independent-review-replay.log'),'criteria':volvo['criteria'],'researchCompleted':volvo['researchCompleted'],'rankings':volvo['rankings'],'closureIssues':volvo['closureIssues'],'sourceIndexSha256':sha(R/'source-index.json'),'coreMatrixSha256':sha(R/'core-matrix.json'),'evidenceCompletenessSha256':sha(R/'evidence-completeness-audit.json'),'stagedReportSha256':sha(R/'staged-report.json'),'readinessSha256':sha(R/'integration-readiness.json'),'registryUnchangedByReview':True,'stagedCopiesMatch':True}
(Q/'final-artifact-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
