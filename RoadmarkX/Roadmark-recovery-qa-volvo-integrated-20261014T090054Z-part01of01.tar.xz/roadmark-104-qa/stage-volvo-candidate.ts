import fs from 'node:fs';
import assert from 'node:assert/strict';
import {catalogue,research,effectiveFeatures,pack} from '../roadmark-104/src/lib/data.ts';
import {applyBrandUpdates,prepareBrandResearch,applyBrandFeatureUpdates,applyBrandTermFeatures,type BrandUpdatePacket} from '../roadmark-104/src/lib/brand-updates.ts';
import {brandUpdatePackets} from '../roadmark-104/src/lib/brand-update-registry.ts';
import {compiledSource} from '../roadmark-104/tests/helpers/compiled-source.ts';
import {loadReportInput} from '../roadmark-104/scripts/reporting/load.ts';
import {buildCoverageReport,coreFacts} from '../roadmark-104/scripts/reporting/reports.ts';
import {combineM1Reconciliations} from '../roadmark-104/scripts/reporting/m1-reconciliation.ts';
import {storePortablePacks,hydratePortablePacks} from '../roadmark-104/src/lib/portable-packs.ts';
import {factClaim,featureClaim} from '../roadmark-104/src/lib/citable.ts';
const R='/tmp/volvo-research/';const p=JSON.parse(fs.readFileSync(R+'volvo-2026-10-14.json','utf8')) as BrandUpdatePacket;
assert(!brandUpdatePackets.some(o=>o.id===p.id),'Candidate must remain unregistered');
const tier1=(c:{vehicleClass?:string})=>!c.vehicleClass||['passenger','ute'].includes(c.vehicleClass);
console.log('Loading effective catalogue');
const rd=research(),before=catalogue();
console.log('Loaded',before.length,'cars');
const prior=JSON.stringify({rd,before,p});
assert.deepEqual(JSON.parse(JSON.stringify(before.filter(c=>c.brand==='Volvo'&&tier1(c)))),JSON.parse(fs.readFileSync(R+'volvo-live-before.json','utf8')));
assert.deepEqual(JSON.parse(JSON.stringify(rd.sources)),JSON.parse(fs.readFileSync(R+'volvo-source-before.json','utf8')));
const data=prepareBrandResearch(rd,[p]);const cars=applyBrandUpdates(before,data,[p]);
console.log('Applied candidate');
const selected=cars.filter(c=>c.brand===p.brand&&tier1(c));const original=new Map(before.map(c=>[c.id,c]));
const staged=compiledSource('src/lib/data.ts',{'./brand-update-registry':{brandUpdatePackets:[...brandUpdatePackets,p]}}) as {pack:typeof pack};
const packs:Record<string,ReturnType<typeof pack>>={};let factCount=0,featureCount=0;
for(const car of selected){
 console.log('Checking',car.id);
 for(const {key} of coreFacts)assert.equal(car.facts[key]?.gradeReview?.overlayId,p.id,`${car.id} ${key}`);
 const start=effectiveFeatures(car,data);
 const features=applyBrandTermFeatures(car,applyBrandFeatureUpdates(car,start,data,[p]));
 const view=staged.pack(car.id,{data,cars});assert.deepEqual(view.features,features,`${car.id}: actual pack replay`);packs[car.id]=view;
 for(const f of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===p.id)){const claim=factClaim(view,f);assert.equal(claim.buyerGrade,f.buyerGrade);assert.deepEqual(claim.sources.map(s=>s.id),f.sourceIds);factCount++;}
 for(const row of p.features?.filter(f=>f.variantId===car.id)||[]){const f=features.find(f=>f.criterion===row.criterion)!;assert.deepEqual(f,row.after);const claim=featureClaim(view,f.criterion,f.criterion)!;assert.deepEqual(claim.sources.map(s=>s.id),f.source_ids);assert.equal(claim.gradeReview?.overlayId,p.id);featureCount++;}
 assert.equal(features.find(f=>f.criterion==='roadside_assistance')?.status,'standard','Included Volvo roadside must remain standard');
 assert.equal(car.availabilityEvidence.physicalStockVerified,false);assert.equal(car.availabilityEvidence.factoryOrderAcceptanceVerified,false);
}
assert.deepEqual(hydratePortablePacks(storePortablePacks(packs),data.sources),packs,'Portable exact equality');
assert.equal(JSON.stringify({rd,before,p}),prior,'Input objects unchanged');
assert.deepEqual(cars.filter(c=>c.brand!==p.brand||!tier1(c)),before.filter(c=>c.brand!==p.brand||!tier1(c)),'Other brands and Tier2 unchanged');
console.log('Actual pack and portable checks passed; building report');
const reportLoader=compiledSource('scripts/reporting/load.ts',{'../../src/lib/data':{research:()=>rd,catalogue:()=>before,effectiveFeatures}}) as {loadReportInput:typeof loadReportInput};
const input=reportLoader.loadReportInput();input.cars=cars;input.sources=data.sources;input.features=input.features.filter(f=>!packs[f.variant_id]).concat(Object.values(packs).flatMap(v=>v.features));
input.m1Reconciliation=combineM1Reconciliations(input.m1Reconciliation!,JSON.parse(fs.readFileSync(R+'volvo-reconciliation-2026-10-14.json','utf8')));
const report=buildCoverageReport(input,'2026-10-14');const brand=report.brandProgress.find(b=>b.brand==='Volvo')!;
fs.writeFileSync(R+'staged-report.json',JSON.stringify(report,null,2));fs.writeFileSync(R+'after.json',JSON.stringify(selected,null,2));fs.writeFileSync(R+'features-after.json',JSON.stringify(Object.values(packs).flatMap(v=>v.features),null,2));fs.writeFileSync(R+'staged-packs.json',JSON.stringify(packs,null,2));
assert.equal(brand.missingSummaries,0);assert.equal(brand.agedOrInvalidClaims,0);
assert(brand.core.every(row=>row.grades.Unreviewed===0),'No unreviewed core cells');
console.log(JSON.stringify({staged:true,registered:false,versions:selected.length,newVersions:p.variants.length,citableFacts:factCount,features:featureCount,portableExactRoundtrip:true,actualPackPipelineMatches:true,immutableInputs:true,otherBrandsUnchanged:true,brand},null,2));
