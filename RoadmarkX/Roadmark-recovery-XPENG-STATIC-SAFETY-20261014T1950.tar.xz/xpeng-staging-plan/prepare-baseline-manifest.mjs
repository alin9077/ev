/** Preparation tool for a later authorized serialized pinning phase. Does not import production code. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import {
  argumentsFor, readJson, fileHash, locate, referenceFor, pin, captureSourceInventory,
  inventoryChanges, newDirectory, writeNewJson,
} from './baseline-io.mjs';

const args = argumentsFor(['--contract', '--contract-sha256', '--manifest-directory', '--extraction-directory']);
const contractFile = args['--contract'];
assert.equal(path.resolve(contractFile), contractFile);
assert.equal(fileHash(contractFile), args['--contract-sha256'], 'Externally supplied contract hash');
const contract = readJson(contractFile), { anchors, expected } = contract;
assert.equal(contract.schemaVersion, 1); assert.equal(contract.mode, 'read-only-xpeng-baseline-preparation');
assert.equal(process.cwd(), anchors.repo); assert.equal(path.dirname(fileURLToPath(import.meta.url)), anchors.xpeng);
assert.equal(locate(anchors, { anchor: 'xpeng', file: 'baseline-contract.json' }), contractFile);
assert.equal(expected.cars, 399); assert.equal(expected.registeredPackets, 18);
const pins = new Map();
function add(ref) {
  const row = pin(anchors, ref), file = locate(anchors, row), prior = pins.get(file);
  if (prior) assert.deepEqual(row, prior, 'No contradictory duplicate input'); else pins.set(file, row);
  return row;
}
function addAbsolute(row) {
  return add({ ...referenceFor(anchors, row.path ?? row.file), sha256: row.sha256, ...(row.bytes === undefined ? {} : { bytes: row.bytes }) });
}
const contractPin = add(referenceFor(anchors, contractFile));
const approved = Object.fromEntries(Object.entries(contract.approved).map(([key, ref]) => [key, add(ref)]));
const storage = readJson(locate(anchors, approved.storageIndex)), core = readJson(locate(anchors, approved.coreReceipt));
const features = readJson(locate(anchors, approved.featureIndex)), parity = readJson(locate(anchors, approved.freshRegisteredParity));
const final = readJson(locate(anchors, approved.finalRegistrationAddendum));
assert.equal(storage.asOf, contract.asOf); assert.equal(storage.cars.rows, expected.cars);
assert.equal(core.storageIndex.sha256, approved.storageIndex.sha256); assert.equal(features.coreReceiptSha256, approved.coreReceipt.sha256);
assert.equal(features.cars, expected.cars); assert.equal(features.perCar.length, expected.cars);
assert.equal(parity.stagedReport.sha256, approved.report.sha256);
assert.equal(parity.normalCoverageCli.stdout.sha256, approved.report.sha256);
assert(parity.normalCoverageCli.fullJSONEqual && parity.normalCoverageCli.fullBytesEqual && !parity.normalCoverageCli.filteredOrNormalized);
assert.equal(final.normalReportParityReceipt.sha256, approved.freshRegisteredParity.sha256);

// Retain dated proof separately; never invoke its obsolete 17-packet source-pin routine.
const historicalRegisteredManifest = addAbsolute(parity.registeredInputManifest);
assert.equal(historicalRegisteredManifest.sha256, final.registeredInputManifest.sha256);
const registered = readJson(locate(anchors, historicalRegisteredManifest));
const registrationSourceInventory = addAbsolute(registered.sourceInventory);
const previousSourceInventory = addAbsolute(final.finalSourceInventory);
for (const row of [registered.registrationTransition, registered.independentStaticReview]) addAbsolute(row);
for (const row of registered.changedExistingPaths) addAbsolute(row.retainedBefore);
for (const key of ['before', 'after', 'manifest', 'independentReview']) addAbsolute(final.testOnlyTransition[key]);

// All full-value inputs are selected from approved indexes/receipts, not a directory glob.
add(storage.cars.baseline); add(storage.cars.replacements);
for (const row of Object.values(storage.research)) add(row);
for (const row of core.generatedPins) addAbsolute(row);
addAbsolute(core.compositionTransition); addAbsolute(core.selectedCars);
addAbsolute(features.features); addAbsolute(features.aggregateEvidence);
const harnessPins = contract.harnessFiles.map(file => add({ anchor: 'xpeng', file }));

const currentSourceInventory = captureSourceInventory(anchors);
for (const row of currentSourceInventory.files) add({ anchor: 'repo', ...row });
const changes = inventoryChanges(readJson(locate(anchors, previousSourceInventory)), currentSourceInventory);
assert(changes.every(row => row.file.startsWith('tests/')), 'Production/data drift requires a separate baseline review, not refreshed expectations');
const registry = add({ anchor: 'repo', file: 'data/m1-brand-updates/registry.json' });
const registryValue = readJson(locate(anchors, registry));
assert.equal(registryValue.schemaVersion, 1); assert.equal(registryValue.packets.length, expected.registeredPackets);
assert.equal(new Set(registryValue.packets).size, expected.registeredPackets);
const packets = registryValue.packets.map(name => {
  assert(/^[a-z0-9][a-z0-9-]*\.json$/.test(name) && name !== 'registry.json');
  const ref = add({ anchor: 'repo', file: 'data/m1-brand-updates/' + name });
  const packet = readJson(locate(anchors, ref));
  return { name, id: packet.id, reviewedAt: packet.reviewedAt, input: ref };
});
assert.equal(new Set(packets.map(packet => packet.id)).size, expected.registeredPackets);
assert.equal(packets.at(-1).id, 'm1-subaru-2026-10-15'); assert.equal(packets.at(-1).input.sha256, storage.packetSha256);
assert(!packets.some(packet => /^m1-xpeng-/i.test(packet.id)), 'XPENG must remain unregistered');
const extractionRelative = args['--extraction-directory'];
assert(/^extractions\/[a-z0-9][a-z0-9_-]*$/.test(extractionRelative), 'Explicit versioned extraction destination required');
assert(!fs.existsSync(path.join(anchors.xpeng, extractionRelative)), 'No reuse of an earlier extraction');
assert(/^manifests\/[a-z0-9][a-z0-9_-]*$/.test(args['--manifest-directory']));
const directory = newDirectory(anchors.xpeng, args['--manifest-directory']);
const inventoryOutput = writeNewJson(directory, 'current-source-inventory.json', currentSourceInventory);
const currentSourceInventoryPin = addAbsolute(inventoryOutput);
const transitionOutput = writeNewJson(directory, 'observed-source-transition.json', {
  status: 'observed_only_pending_independent_review',
  before: previousSourceInventory, after: currentSourceInventoryPin, changes,
  earlierRegistrationTransition: registered.registrationTransition,
  earlierTestOnlyTransition: final.testOnlyTransition,
  noHistoricalExpectationReset: true,
});
const observedTransition = addAbsolute(transitionOutput);
// Two complete source passes catch changes during pinning. No importer or hydration is used.
assert.deepEqual(captureSourceInventory(anchors), currentSourceInventory, 'Current source stayed unchanged while pinning');
for (const row of pins.values()) pin(anchors, row);
const manifest = {
  schemaVersion: 1, mode: 'read-only-xpeng-baseline-manifest', asOf: contract.asOf,
  lineage: contract.lineage, contract: contractPin, anchors, expected, approved,
  historicalRegisteredManifest, registrationSourceInventory, previousSourceInventory,
  currentSourceInventory: currentSourceInventoryPin, observedTransition,
  registry, packets, harnessPins, inputPins: [...pins.values()].sort((a, b) => locate(anchors, a).localeCompare(locate(anchors, b))),
  output: { anchor: 'xpeng', directory: extractionRelative },
  runtime: { nodeVersion: process.version, productionEntryPoint: 'src/lib/evidence-consumers.ts', defaultsMustThrow: true },
  candidateCreated: false, canonicalCapturePerformed: false, freshFullValueLoaderExport: false,
};
const result = writeNewJson(directory, 'baseline-manifest.json', manifest);
console.log(JSON.stringify({ status: 'manifest_prepared_not_execution_approval', manifest: result, sourceChanges: changes, independentReviewRequired: true }, null, 2));
