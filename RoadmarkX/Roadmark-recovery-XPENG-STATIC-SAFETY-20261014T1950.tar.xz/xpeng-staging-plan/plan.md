# XPENG derived-baseline staging plan

Preparation only. No catalogue hydration, source edit, registration, or test execution is authorized while the backup owns the serialized heavy slot.

The accepted baseline is the complete 399-car Subaru result at 15 October 2026, as explicitly approved by root. It is an independently accepted derived storage lineage, not a newly completed full-value loader export. The later normal registered coverage CLI was freshly reproduced and exactly matched the entire staged report. Full current TypeScript, current production build, clean aggregate regression and real-device testing remain unverified.

## Immutable approved anchors

- /tmp/subaru-staging-plan/candidate/staged-storage-index.json, SHA256 8df40869d4db9c599d2dafe6c80fa7bbf2af9fd3cec633aa8b8f3c9bbb75893e
- /tmp/subaru-staging-plan/candidate/staged-core-receipt.json, SHA256 7af97f5d8f0f143edd75e36614456d97367eea31a4748897d7c8d235fc6f9537
- /tmp/subaru-staging-plan/candidate/staged-all-feature-index.json, SHA256 5f52dec2f6c750554dd9dcfae5a8c07753d66690a80bd4e9042e8911cd7fdc50
- /tmp/subaru-staging-plan/candidate/staged-report.json, SHA256 9b6bb08935cc7f569d5d80e1184a547a48eff7f7a4da189b898dc83ca4e0b53d
- /tmp/subaru-post-registration-review/fresh-registered-parity-independent-review.json, SHA256 a5fc44d6441812a5a0799ca5b8a65d0c1356950b82afbe2077519fe59c912cda
- /tmp/subaru-post-registration-review/final-post-registration-gate-addendum.json, SHA256 95abbe0289f1ca8d4b0fe402e4722a6e965f93be31cdb191ce6b86e890590834

## Proposed phases

1. Pin the current source, all registered packets, approved index and every directly referenced full-value file. Preserve separately dated prior acceptance and source-transition receipts. Do not change old pins to match current source. Record new source inventory and the exact explained registered-Subaru/test-only transitions.
2. Stream and validate the full baseline-car file and complete Subaru replacement list, checking every effective full car against all 399 pinned car hashes and exact order. Retain the five current XPENG cars, full identity guards, original source/model/variant rows, and actual 345 feature rows from the unchanged production evidence consumer. Each complete feature result must match the accepted prior per-car hash.
3. Freeze the evidence/reconciliation inputs after independent review. Build a candidate with complete before facts and identities from phase 2. The candidate starts with no feature replacements. New announced/residual identities must be source-bound; no invented base drivetrain for a package.
4. Apply actual prepareBrandResearch and applyBrandUpdates to the approved explicit baseline. Preserve the raw one-packet output and use an independently reviewed registry-composition rule for metadata.brand_update_packet_ids only: the original 18 registered packet IDs followed by XPENG. Verify every other metadata property and all other 13 Research fields are unchanged by composition.
5. Capture the original canonical new-version 69-field feature baseline once, using the exact production evidence consumers with throwing defaults. Freeze the feature-free packet, full canonical selected cars, raw output and composition transition. Never regenerate the fixture to make a changed candidate pass.
6. Build final guarded feature replacements against the original actual rows. Use immutable manifest-selected packet and output paths for every phase and amendment. A correction receives a new manifest/candidate, not cloned scripts or overwritten expectations.
7. Verify all actual core cars and Research fields, exact other-brand car equality, all actual packs/citable claims/portable roundtrips, and source/price/identity/dependency negative mutations. Verify every field of complete coverage JSON.
8. Stream full effective features in pinned contiguous serial ranges if needed. Require exact full 399-plus-new coverage and order, no duplicate/missing cars or criteria, and complete per-car full-feature hashes against unchanged non-XPENG expectations. An interrupted stream is preserved and is not a pass.
9. Independent reviewer checks the complete candidate and receipts. Root alone registers and runs fresh current checks, sends user updates and saves recovery.

## Retention

Use an explicit bounded file allowlist. Retain public factual text, whitelisted public configurator facts, PDF documents and necessary PDF page renders. Failed raw HTTP captures that only render a global shell are failure evidence, not Australian specification sources. Do not retain browser runtime data, cookies, response headers, login capabilities or unrequested screenshots. No deletions.
