/** Run only after independent static review and root's separate serialized-execution authorization. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import {
  argumentsFor, readJson, fileHash, locate, pin, referenceFor, verifyPins, expectedDigest, digestRows,
  sourceNames, inventoryChanges, newDirectory, writeNewJson, selectVerifiedCars, readResearch, assertResearchUnchanged,
} from './baseline-io.mjs';

const args = argumentsFor(['--manifest', '--manifest-sha256', '--review', '--review-sha256']);
for (const name of ['--manifest', '--review']) assert.equal(path.resolve(args[name]), args[name]);
assert.equal(fileHash(args['--manifest']), args['--manifest-sha256']);
assert.equal(fileHash(args['--review']), args['--review-sha256']);
const manifest = readJson(args['--manifest']), review = readJson(args['--review']);
const { anchors, expected } = manifest;
assert.equal(manifest.schemaVersion, 1); assert.equal(manifest.mode, 'read-only-xpeng-baseline-manifest');
assert.equal(manifest.candidateCreated, false); assert.equal(manifest.canonicalCapturePerformed, false); assert.equal(manifest.freshFullValueLoaderExport, false);
assert.equal(process.cwd(), anchors.repo); assert.equal(path.dirname(fileURLToPath(import.meta.url)), anchors.xpeng);
assert.equal(process.version, manifest.runtime.nodeVersion); assert.equal(typeof global.gc, 'function');
assert.equal(manifest.runtime.productionEntryPoint, 'src/lib/evidence-consumers.ts'); assert.equal(manifest.runtime.defaultsMustThrow, true);
locate(anchors, referenceFor(anchors, args['--manifest'])); locate(anchors, referenceFor(anchors, args['--review']));
assert.equal(review.status, 'approved_for_read_only_xpeng_baseline_extraction');
assert.equal(review.manifestSha256, args['--manifest-sha256']);
assert.equal(review.contractSha256, manifest.contract.sha256);
assert.equal(review.noProductionSemanticChanges, true); assert.equal(review.canonicalCaptureAuthorized, false);
assert.deepEqual(review.harnessPins, manifest.harnessPins, 'Reviewer inspected these exact scripts and contract');

const pinMap = new Map(manifest.inputPins.map(row => [locate(anchors, row), row]));
assert.equal(pinMap.size, manifest.inputPins.length);
function requiredPin(row) {
  const file = locate(anchors, row), declared = pinMap.get(file);
  assert(declared, 'Missing mandatory manifest input: ' + file);
  assert.equal(declared.sha256, row.sha256);
  if (row.bytes !== undefined) assert.equal(declared.bytes, row.bytes);
  return declared;
}
requiredPin(manifest.contract);
const contract = readJson(locate(anchors, manifest.contract));
assert.deepEqual(manifest.anchors, contract.anchors); assert.deepEqual(manifest.expected, contract.expected);
assert.equal(manifest.lineage, contract.lineage); assert.equal(manifest.asOf, contract.asOf);
assert.equal(expected.cars, 399); assert.equal(expected.registeredPackets, 18); assert.equal(expected.criteria, 69);
assert.equal(expected.selectedIds.length, 5); assert.equal(expected.researchFields.length, 14);
for (const [key, ref] of Object.entries(contract.approved)) {
  assert.equal(manifest.approved[key].anchor, ref.anchor); assert.equal(manifest.approved[key].file, ref.file);
  assert.equal(manifest.approved[key].sha256, ref.sha256); requiredPin(manifest.approved[key]);
}
assert.deepEqual(manifest.harnessPins.map(row => row.file), contract.harnessFiles);
for (const row of manifest.harnessPins) { assert.equal(row.anchor, 'xpeng'); requiredPin(row); }
for (const key of ['historicalRegisteredManifest', 'registrationSourceInventory', 'previousSourceInventory', 'currentSourceInventory', 'observedTransition', 'registry']) requiredPin(manifest[key]);
const sourceInventory = readJson(locate(anchors, manifest.currentSourceInventory));
assert.equal(new Set(sourceInventory.files.map(row => row.file)).size, sourceInventory.files.length);
for (const row of sourceInventory.files) requiredPin({ anchor: 'repo', ...row });
const transition = readJson(locate(anchors, manifest.observedTransition));
assert.deepEqual(transition.before, manifest.previousSourceInventory); assert.deepEqual(transition.after, manifest.currentSourceInventory);
const changes = inventoryChanges(readJson(locate(anchors, manifest.previousSourceInventory)), sourceInventory);
assert.deepEqual(transition.changes, changes); assert.deepEqual(review.sourceChanges.map(({ file, beforeSha256, afterSha256 }) => ({ file, beforeSha256, afterSha256 })), changes);
assert(changes.every(row => row.file.startsWith('tests/')), 'Production changes cannot be accepted by source pin refresh');
for (const change of review.sourceChanges) {
  assert(typeof change.reason === 'string' && change.reason.trim());
  if (change.beforeSha256 === null) assert.equal(change.retainedBefore, null);
  else { assert(change.retainedBefore); assert.equal(change.retainedBefore.sha256, change.beforeSha256); pin(anchors, change.retainedBefore); }
}

const approved = Object.fromEntries(Object.entries(manifest.approved).map(([key, row]) => [key, readJson(locate(anchors, row))]));
const { storageIndex: index, coreReceipt: core, featureIndex, freshRegisteredParity: parity, finalRegistrationAddendum: final } = approved;
assert.equal(index.schemaVersion, 1); assert.equal(index.asOf, manifest.asOf); assert.equal(index.freshLoaderValidation, false);
assert.equal(core.status, 'passed_pending_actual_pack_and_complete_report_phases');
assert.equal(core.asOf, manifest.asOf); assert.equal(featureIndex.asOf, manifest.asOf);
assert.equal(core.storageIndex.sha256, manifest.approved.storageIndex.sha256);
assert.equal(core.storageIndex.file, locate(anchors, manifest.approved.storageIndex));
assert.equal(core.selectedCars.file, locate(anchors, index.cars.replacements));
assert.equal(core.selectedCars.sha256, index.cars.replacements.sha256);
assert.equal(core.selectedCars.bytes, index.cars.replacements.bytes);
assert.equal(core.afterCars, expected.cars); assert.equal(core.beforeCars, expected.baselineCars);
assert(core.allCompleteInputCarsAnd14ResearchFieldsUnchanged && core.allNonSubaruAndLowerTierCarsExactlyUnchanged && core.all14CanonicalResearchFieldsExactlyEqual && core.rawSinglePacketOutputPreserved);
assert.equal(featureIndex.coreReceiptSha256, manifest.approved.coreReceipt.sha256); assert.equal(featureIndex.cars, expected.cars);
assert.equal(featureIndex.packetSha256, index.packetSha256); assert.equal(core.packetSha256, index.packetSha256);
assert.equal(featureIndex.features.rows, expected.cars * expected.criteria);
assert.equal(featureIndex.perCar.length, expected.cars);
assert.deepEqual(featureIndex.perCar.map(row => row.id), index.cars.carHashes.map(row => row.id));
for (const [i, row] of featureIndex.perCar.entries()) {
  assert.equal(row.carSha256, index.cars.carHashes[i].afterSha256); assert.equal(row.carBytes, index.cars.carHashes[i].bytes); assert.equal(row.featureRows, expected.criteria);
}
assert.equal(parity.status, 'passed_independent_full_fresh_registered_report_parity_and_registration_pins');
assert.equal(parity.catalogueVersions, expected.cars);
assert(parity.normalCoverageCli.fullJSONEqual && parity.normalCoverageCli.fullBytesEqual && !parity.normalCoverageCli.filteredOrNormalized);
assert.equal(parity.stagedReport.sha256, manifest.approved.report.sha256); assert.equal(parity.normalCoverageCli.stdout.sha256, manifest.approved.report.sha256);
assert.equal(final.normalReportParityReceipt.sha256, manifest.approved.freshRegisteredParity.sha256);
assert.equal(final.finalSourceInventory.sha256, manifest.previousSourceInventory.sha256);
assert.equal(parity.registeredInputManifest.sha256, manifest.historicalRegisteredManifest.sha256);
assert.equal(final.registeredInputManifest.sha256, manifest.historicalRegisteredManifest.sha256);
const registered = readJson(locate(anchors, manifest.historicalRegisteredManifest));
assert.equal(registered.sourceInventory.sha256, manifest.registrationSourceInventory.sha256);
function requireAbsolute(row) { return requiredPin({ ...referenceFor(anchors, row.path ?? row.file), sha256: row.sha256, ...(row.bytes === undefined ? {} : { bytes: row.bytes }) }); }
for (const row of [index.cars.baseline, index.cars.replacements, ...Object.values(index.research)]) requiredPin(row);
for (const row of [...core.generatedPins, core.compositionTransition, core.selectedCars, featureIndex.features, featureIndex.aggregateEvidence, registered.registrationTransition, registered.independentStaticReview]) requireAbsolute(row);
for (const row of registered.changedExistingPaths) requireAbsolute(row.retainedBefore);
for (const key of ['before', 'after', 'manifest', 'independentReview']) requireAbsolute(final.testOnlyTransition[key]);

function verifyAllInputs() {
  assert.equal(fileHash(args['--manifest']), args['--manifest-sha256']); assert.equal(fileHash(args['--review']), args['--review-sha256']);
  assert.deepEqual(sourceNames(anchors.repo), sourceInventory.files.map(row => row.file).sort(), 'No new, missing, or unpinned source file');
  verifyPins(anchors, manifest.inputPins);
  for (const change of review.sourceChanges) if (change.retainedBefore) pin(anchors, change.retainedBefore);
}
verifyAllInputs();
const rawRegistry = readJson(locate(anchors, manifest.registry));
assert.equal(rawRegistry.schemaVersion, 1); assert.equal(rawRegistry.packets.length, expected.registeredPackets);
assert.deepEqual(rawRegistry.packets, manifest.packets.map(row => row.name));
assert.equal(new Set(rawRegistry.packets).size, expected.registeredPackets);
const pinnedPackets = manifest.packets.map(row => {
  assert.equal(row.input.anchor, 'repo'); assert.equal(row.input.file, 'data/m1-brand-updates/' + row.name);
  requiredPin(row.input); const value = readJson(locate(anchors, row.input));
  assert.equal(value.id, row.id); assert.equal(value.reviewedAt, row.reviewedAt); return value;
});
assert.equal(new Set(pinnedPackets.map(row => row.id)).size, expected.registeredPackets);
assert.equal(pinnedPackets.at(-1).id, 'm1-subaru-2026-10-15');
assert.equal(manifest.packets.at(-1).input.sha256, index.packetSha256);
assert(!pinnedPackets.some(packet => /^m1-xpeng-/i.test(packet.id)));

const { selected, completeCarDigests } = await selectVerifiedCars(anchors, index, expected);
const originalSelected = selected.map(car => digestRows([car]));
const data = await readResearch(anchors, index, expected.researchFields);
assert.equal(data.criteria.length, expected.criteria); assert.equal(new Set(data.criteria.map(row => row.key)).size, expected.criteria);
assert.equal(data.variants.length, expected.cars);
assert.deepEqual(data.variants.map(row => row.id), completeCarDigests.map(row => row.id));
assert.deepEqual(data.metadata.brand_update_packet_ids, pinnedPackets.map(row => row.id), 'Already approved complete registry metadata; never repair it');
assertResearchUnchanged(data, index);

// A fresh process imports only the unchanged production consumer. Never import data.ts,
// reporting/load.ts, compiledSource, old proof helpers, or any candidate registry shim.
const require = createRequire(path.join(anchors.repo, 'package.json'));
const forbiddenModulePaths = ['src/lib/data.ts', 'scripts/reporting/load.ts', 'tests/helpers/compiled-source.ts'].map(file => path.join(anchors.repo, file));
function assertNoHydrator() { for (const file of forbiddenModulePaths) assert(!require.cache[file], 'Forbidden loader/test shim present: ' + file); }
assertNoHydrator();
const { createEvidenceConsumers } = require('./src/lib/evidence-consumers.ts');
const { brandVersionSnapshot } = require('./src/lib/brand-updates.ts');
const { brandUpdatePackets } = require('./src/lib/brand-update-registry.ts');
assert.deepEqual(brandUpdatePackets, pinnedPackets, 'Actual unchanged production registry equals all pinned packets');
assertNoHydrator(); global.gc();
let defaultCalls = 0;
const forbidden = () => { defaultCalls++; throw new Error('XPENG baseline requires explicit proven Research and cars; default loading is forbidden'); };
const consumers = createEvidenceConsumers({ sourceResearch: forbidden, research: forbidden, catalogue: forbidden });
const snapshot = { data, cars: selected }, packs = {}, guards = [], facts = [], fullFeatures = [], selectedChecks = [];
for (const [ordinal, car] of selected.entries()) {
  const expectedFeatures = featureIndex.perCar.find(row => row.id === car.id); assert(expectedFeatures);
  const pack = consumers.pack(car.id, snapshot);
  assert.deepEqual(pack.car, car, 'Actual production pack contains complete before car');
  assert.equal(pack.features.length, expected.criteria); assert.equal(new Set(pack.features.map(row => row.criterion)).size, expected.criteria);
  assert(pack.features.every(row => row.variant_id === car.id));
  assert.deepEqual(pack.features.map(row => row.criterion).sort(), data.criteria.map(row => row.key).sort());
  const actual = digestRows(pack.features);
  assert.deepEqual(actual, { rows: expectedFeatures.featureRows, bytes: expectedFeatures.featureBytes, sha256: expectedFeatures.featureSha256 }, 'All 69 actual production feature rows equal accepted prior hash: ' + car.id);
  guards.push({ variantId: car.id, before: brandVersionSnapshot(car) });
  for (const fact of Object.values(pack.car.facts)) facts.push({ variantId: car.id, before: structuredClone(fact) });
  packs[car.id] = pack; fullFeatures.push(...pack.features);
  selectedChecks.push({ id: car.id, car: originalSelected[ordinal], features: actual, identityFromProductionFunction: true });
  assert.deepEqual(digestRows([car]), originalSelected[ordinal], 'Actual production consumer did not mutate complete car');
  global.gc(); console.log('Verified all 69 actual before features:', car.id);
}
assert.equal(defaultCalls, 0); assertNoHydrator();
assert.equal(fullFeatures.length, expected.selectedIds.length * expected.criteria);
assert.deepEqual(Object.keys(packs), expected.selectedIds);
for (const [i, car] of selected.entries()) assert.deepEqual(digestRows([car]), originalSelected[i]);
assertResearchUnchanged(data, index); assert.deepEqual(brandUpdatePackets, pinnedPackets);
verifyAllInputs();

const selectedIds = new Set(expected.selectedIds), modelIds = new Set(selected.map(car => car.modelId));
// Original rows below are copied unchanged from the fully verified explicit baseline.
// Keep every source row to avoid narrowing away evidence later packet authoring may need.
const context = {
  schema_version: data.schema_version, metadata: data.metadata, criteria: data.criteria,
  sources: data.sources,
  models: data.models.filter(row => modelIds.has(row.id)),
  variants: data.variants.filter(row => selectedIds.has(row.id)),
  feature_evidence_variant_context: data.feature_evidence_variant_context.filter(row => selectedIds.has(row.id)),
  feature_evidence: data.feature_evidence.filter(row => selectedIds.has(row.variant_id)),
  trim_equipment: data.trim_equipment.filter(row => selectedIds.has(row.variant_id)),
  update_eligibility: data.update_eligibility.filter(row => selectedIds.has(row.variant_id)),
};
assert.deepEqual(context.variants.map(row => row.id), expected.selectedIds);
assert.equal(context.feature_evidence.length, fullFeatures.length);
assert.equal(context.feature_evidence_variant_context.length, selected.length);
assert.equal(manifest.output.anchor, 'xpeng'); assert(/^extractions\/[a-z0-9][a-z0-9_-]*$/.test(manifest.output.directory));
const out = newDirectory(anchors.xpeng, manifest.output.directory);
const artifacts = {};
for (const [name, value] of Object.entries({
  'selected-complete-before-cars.json': selected,
  'actual-before-packs.json': packs,
  'actual-before-features.json': fullFeatures,
  'actual-before-facts.json': facts,
  'actual-before-version-guards.json': guards,
  'unchanged-original-research-context.json': context,
  'complete-399-car-verification.json': completeCarDigests,
})) artifacts[name] = writeNewJson(out, name, value);
// Verify again after serialization. A failure leaves artifacts, but no successful receipt.
assertResearchUnchanged(data, index); verifyAllInputs();
for (const [i, car] of selected.entries()) assert.deepEqual(digestRows([car]), originalSelected[i]);
const receipt = writeNewJson(out, 'baseline-extraction-receipt.json', {
  schemaVersion: 1, status: 'passed_read_only_derived_xpeng_baseline_extraction', asOf: manifest.asOf,
  lineage: manifest.lineage, manifestSha256: args['--manifest-sha256'], independentReviewSha256: args['--review-sha256'],
  completeCarsVerified: completeCarDigests.length, exactCompleteCarOrderVerified: true,
  completeResearchFieldsVerifiedBeforeAndAfter: expected.researchFields,
  selectedCars: selected.length, actualFeatureRows: fullFeatures.length, selectedChecks,
  actualProductionConsumer: manifest.runtime.productionEntryPoint,
  defaultLoaderCalls: defaultCalls, registryPackets: pinnedPackets.map(packet => packet.id),
  sourceAndFixturePinsRechecked: true, artifacts,
  sourceEdited: false, candidateCreated: false, registryEdited: false, metadataRepaired: false,
  canonicalCapturePerformed: false, freshFullValueLoaderExport: false,
  fullTypecheckClaimed: false, productionBuildClaimed: false, publicationAuthorized: false,
  resourceUsage: process.resourceUsage(), memoryUsage: process.memoryUsage(),
});
console.log(JSON.stringify({ status: 'passed_read_only_derived_xpeng_baseline_extraction', receipt }, null, 2));
