"""Manifest-selected XPENG packet assembly from independently reviewed research
and immutable actual production before values. Never imports or edits source.
"""
import argparse, copy, hashlib, json
from pathlib import Path

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(pin):
    p=Path(pin['path']).resolve();assert p.is_file() and sha(p)==pin['sha256'],str(p)
    if 'bytes' in pin:assert p.stat().st_size==pin['bytes'],str(p)
    return json.loads(p.read_text())
def write_new(path,value):
    p=Path(path).resolve();assert p.is_relative_to(Path('/tmp/xpeng-staging-plan')) and not p.exists()
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(value,f,indent=2,ensure_ascii=False);f.write('\n')
    return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}

ap=argparse.ArgumentParser();ap.add_argument('manifest');ap.add_argument('--manifest-sha256',required=True);a=ap.parse_args()
mp=Path(a.manifest).resolve();mh=sha(mp);assert mh==a.manifest_sha256,'Externally reviewed assembly manifest hash';m=json.loads(mp.read_text())
assert m['schemaVersion']==1 and m['mode']=='xpeng-packet-assembly'
assert m['phase'] in ['feature-free','final']
inputs=m['inputs'];data=read(inputs['normalized']);review=read(inputs['normalizationReview'])
assert review['normalizedEvidenceSha256']==inputs['normalized']['sha256']
assert review['status']=='approved_for_feature_free_xpeng_packet_construction'
assert review['sourceCaptureManifestSha256']==inputs['sourceCaptureManifest']['sha256']
acceptedCaptures=read(inputs['sourceCaptureManifest'])
acceptedCaptureMap={(c['sourceKey'],c['path']):c for c in acceptedCaptures}
assert len(acceptedCaptureMap)==len(acceptedCaptures)
seenCaptures=set()
def reviewed_capture(key,f):
    identity=(key,str(f));assert identity in acceptedCaptureMap,('Unreviewed capture',identity)
    c=acceptedCaptureMap[identity];assert f.stat().st_size==c['bytes'] and sha(f)==c['sha256'],('Changed reviewed source capture',identity)
    seenCaptures.add(identity);return c
receipt=read(inputs['baselineReceipt']);assert receipt['status']=='passed_read_only_derived_xpeng_baseline_extraction'
assert receipt['completeCarsVerified']==399 and receipt['actualFeatureRows']==345 and receipt['sourceAndFixturePinsRechecked']
baseline={}
for key,name in [('cars','selected-complete-before-cars.json'),('features','actual-before-features.json'),('guards','actual-before-version-guards.json'),('context','unchanged-original-research-context.json')]:
    assert inputs[key]==receipt['artifacts'][name],(key,'Input must be exact accepted receipt artifact')
    baseline[key]=read(inputs[key])
cars=baseline['cars'];old={c['id']:c for c in cars};old_ids=set(old)
assert len(old)==5 and all(c['brand']=='XPENG' for c in cars)
assert len(baseline['features'])==345
D=m['asOf'];PID=m['packetId'];BRAND='XPENG';REVIEWER='Roadmark independently reviewed Australian XPENG research'
assert D==data['asOf']=='2026-10-15' and PID=='m1-xpeng-'+D
packet=dict(schemaVersion=1,id=PID,brand=BRAND,reviewedAt=D,reviewedBy=REVIEWER,sources=[],models=[],variants=[],versionGuards=copy.deepcopy(baseline['guards']),versionUpdates=[],facts=[],features=[],brandTerms=[],availability=[],summaries=[])
sources={};effective={};originalModels=baseline['context']['models'];modelids={x['id'] for x in originalModels}
researchRoot=Path('/tmp/xpeng-research')
capturePins=[]
for row in data['sources']:
    key=row['key'];assert key not in sources
    s=dict(id=PID+'-'+key,url=row['url'],title=row['title'],publisher=row['publisher'],source_type=row['source_type'],published_date=row.get('published_date'),accessed_date=row.get('checkedOn',D),market='AU',supports=row.get('supports',row['title']))
    for k in ['notes','capture_section','retrievalMethod','retrievalLimitations','sourceOriginMarket','visualReview']:
        if k in row:s[k]=row[k]
    captures=[]
    for k,purpose in [('file','Public source capture'),('factualStateFile','Whitelisted public exact-version configuration facts'),('textFile','Extracted public document text')]:
        if row.get(k):
            f=Path(row[k]);f=(f if f.is_absolute() else researchRoot/f).resolve()
            assert f.is_relative_to(researchRoot) and f.is_file()
            accepted=reviewed_capture(key,f)
            cap=dict(locator=str(f.relative_to(researchRoot)),sha256=accepted['sha256'],bytes=accepted['bytes'],purpose=purpose)
            captures.append(cap);capturePins.append({'path':str(f),'sha256':cap['sha256'],'bytes':cap['bytes']})
    for cap in row.get('supplementaryCaptures',[]):
        f=Path(cap['path']).resolve();assert f.is_relative_to(researchRoot) and sha(f)==cap['sha256'];reviewed_capture(key,f)
        captures.append(dict(locator=str(f.relative_to(researchRoot)),sha256=cap['sha256'],bytes=f.stat().st_size,purpose=cap['purpose']))
        capturePins.append({'path':str(f),'sha256':cap['sha256'],'bytes':f.stat().st_size})
    assert captures,key;s['capture_locator']=captures[0]['locator'];s['capture_sha256']=captures[0]['sha256'];s['retainedCaptures']=captures
    sources[key]=s;packet['sources'].append(s)

assert seenCaptures==set(acceptedCaptureMap),'Every independently reviewed capture is required and no extra capture can be silently repinned'
for row in data['variants']:
    if row['id'] in old_ids:continue
    mid=row['modelId'];gen=row['generation'];av=row['availability'];ids=[sources[k]['id'] for k in av['sourceKeys']]
    if mid not in modelids:
        packet['models'].append(dict(id=mid,brand=BRAND,model=row['model'],generation=gen,family_id=row.get('familyId',mid.replace('_','-'))));modelids.add(mid)
    v=dict(id=row['id'],model_id=mid,brand=BRAND,model=row['model'],trim=row['trim'],model_year=row['modelYear'],record_state=av['state'],variant_review_date=D,source_ids=ids,notes=row.get('notes',[]),price_basis='',range_cycle='WLTP',price_aud=None,range_km=None,seats=None,vehicle_class='passenger',drive=row['drive'],brand_update_generation=gen)
    packet['variants'].append(v)
    # New records have no prior facts. Availability's before projection is the
    # documented unchanged newVariantCar default; actual application must verify
    # it before the sole canonical capture, rather than adjusting it to pass.
    old[v['id']]=dict(id=v['id'],modelId=mid,brand=BRAND,model=v['model'],trim=v['trim'],year=v['model_year'],generation=gen,vehicleClass='passenger',drive=v['drive'],availability=v['record_state'],availabilityEvidence=dict(checkedAt=D,orderStatus='unverified',stockStatus='unverified',sourceIds=ids,qualifications=['Physical stock and factory-order acceptance have not been verified.']),facts={})
assert [v['id'] for v in packet['variants']]==m['newIds'] and len(m['newIds'])==6
assert [v['id'] for v in data['variants'] if v['id'] in old_ids]==[c['id'] for c in cars]
for row in data['variants']:effective[row['id']]={}
meta={
 'price_aud':('Price','AUD',''), 'range_km':('Range','km','WLTP'), 'battery_kwh':('Battery capacity','kWh',''), 'dc_peak_kw':('Peak DC charging acceptance','kW','Peak DC input'), 'dc_charge_time_min':('DC 10–80% charge time','min','10–80%'), 'ac_kw':('AC charging power','kW','Maximum AC input'), 'seats':('Seats','','Seating positions'), 'boot_l':('Rear luggage volume','L',''), 'zero_to_100_s':('0–100 km/h','s','0–100 km/h'), 'power_kw':('Motor power','kW','Motor output'), 'drive':('Drive type','','Drivetrain'), 'length_mm':('Length','mm','Body length'), 'width_mm':('Width','mm','Width; mirror treatment unspecified'), 'height_mm':('Height','mm','Body height'), 'towing_braked_kg':('Braked towing','kg','Braked towing'), 'warranty':('Vehicle warranty','','Australian new-vehicle warranty'), 'battery_warranty':('Battery warranty','','Australian traction-battery warranty'), 'roadside_assistance':('Roadside assistance','','Australian roadside assistance'),
 'wheelbase_mm':('Wheelbase','mm','Wheelbase'), 'kerb_weight_kg':('Kerb mass','kg','Kerb mass'), 'gvm_kg':('Gross vehicle mass','kg','Gross vehicle mass'), 'payload_kg':('Payload','kg','Published payload'), 'wheel_size_in':('Wheel size','in','Wheel diameter'), 'cargo_folded_l':('Rear cargo seats folded','L','Rear seats folded'), 'frunk_l':('Front storage','L','Front storage'), 'v2l_output_kw':('Vehicle-to-load output','kW','V2L power'), 'speaker_count':('Speakers','','Speaker count'), 'airbags':('Airbags','','Airbag count'), 'screen_size_in':('Multimedia display','in','Screen diagonal'), 'instrument_display_in':('Instrument display','in','Screen diagonal'), 'turning_radius_m':('Turning radius','m','Turning radius'), 'price_when_new_aud':('Historical price when new','AUD',''), 'reported_list_price_aud':('Reported list price','AUD',''), 'black_edition_reported_total_aud':('Reported Black Edition total','AUD',''), 'range_20inch_km':('Range on optional 20-inch wheels','km','WLTP'), 'head_up_display_in':('Head-up display','in','Display diagonal'), 'boot_excluding_underfloor_l':('Reported rear cargo excluding underfloor','L',''), 'boot_including_underfloor_reported_l':('Reported rear cargo including underfloor','L','')}
def make_fact(car,rf):
    k=rf['key'];g=rf['grade'];prev=car['facts'].get(k,{})
    label,unit,default=meta.get(k,(prev.get('label',k.replace('_',' ').capitalize()),prev.get('unit',''),prev.get('basis',k.replace('_',' '))))
    ids=[sources[x]['id'] for x in rf['sourceKeys']]
    scope=rf.get('evidenceScope') or ('secondary_or_sibling' if g=='reported' else 'searched_not_found' if g=='not_published' else 'exact_au_version')
    f=dict(key=k,label=rf.get('label',label),value=rf['value'],unit=rf.get('unit',unit),basis=rf.get('basis',default),comparisonBasis=rf.get('comparison',default),status={'confirmed':'standard','check':'conditional','reported':'conditional','not_published':'not_verified'}[g],sourceIds=ids,date=D,market='AU',scope=rf.get('scope',BRAND+' '+car['model']+' '+car['trim']),qualifications=rf.get('qualifications',[]),issues=[],buyerGrade=g,gradeReview=dict(reviewedAt=D,overlayId=PID,reason=rf.get('reason',{'confirmed':'Current Australian maker material establishes this value within its cited scope.','check':'Current Australian maker evidence establishes the value with the stated specific measurement or fitment condition.','reported':'The cited Australian secondary, dealer or historical evidence reports this value; it is not promoted to current maker confirmation.','not_published':'The two cited sources were checked without establishing this narrowly scoped value.'}[g]),evidenceScope=scope,sourceIds=ids,sourceLabel=' / '.join(dict.fromkeys(sources[x]['publisher'] for x in rf['sourceKeys']))))
    if rf.get('condition'):f['conditionExplanation']=rf['condition']
    if g=='check':assert f.get('conditionExplanation')
    if g=='not_published':assert f['value'] is None;f['conditionExplanation']=f['gradeReview']['reason']
    if g=='reported':f['resolvedElsewhere']=True
    for key in ['validUntil','roadsideFitment']:
        if key in rf:f[key]=rf[key]
    if k=='price_aud' and f['value'] is not None:
        rung=rf['priceRung'];f['priceEvidence']=dict(rung=rung,basisTag=rf['basisTag'],sourceKey=k,sourcePointer=sources[rf['sourceKeys'][0]]['url'],originalBasis=rf.get('originalBasis',f['basis']),rankingEligible=rf.get('rankingEligible',g in ['confirmed','check']))
        if rung>=5:f['priceEvidence']['publisher']=sources[rf['sourceKeys'][0]]['publisher']
        if rung==4:f['priceEvidence']['state']=rf['state']
    return f
for key,t in data['brandTerms'].items():
    ids=t['applicableVariantIds'];assert ids and set(ids)<=set(old)
    f=make_fact(old[ids[0]],t)
    packet['brandTerms'].append(dict(key=key,fact=f,applicableVariantIds=ids,before={id:old[id]['facts'].get(key) for id in ids},exceptions=[]))
    for id in ids:effective[id][key]=f
for row in data['variants']:
    car=old[row['id']]
    for rf in row['facts']:
        k=rf['key'];assert k not in effective[car['id']]
        f=make_fact(car,rf);effective[car['id']][k]=f;packet['facts'].append(dict(variantId=car['id'],before=car['facts'].get(k),after=f))
    av=row['availability'];ids=[sources[k]['id'] for k in av['sourceKeys']]
    packet['availability'].append(dict(id=PID+'-availability-'+car['id'],variantId=car['id'],before=dict(availability=car['availability'],evidence=car['availabilityEvidence']),after=dict(availability=av['state'],evidence=dict(checkedAt=D,orderStatus=av['orderStatus'],stockStatus=av['stockStatus'],sourceIds=ids,physicalStockVerified=False,factoryOrderAcceptanceVerified=False,qualifications=av['qualifications'])),status='approved',reviewedBy=REVIEWER,reviewedAt=D,evidenceDate=D,reason=av['reason']))
    def clause(x):return dict(label=x['label'],text=x['text'],dependencies=[dict(key=k,expected=effective[car['id']][k]) for k in x['keys']])
    packet['summaries'].append(dict(variantId=car['id'],conditions=[],strength=clause(row['summary']['strength']),tradeoff=clause(row['summary']['tradeoff'])))

if m['phase']=='final':
    canonical=read(inputs['canonicalPacket']);meta_record=read(inputs['canonicalReceipt']);new_features=read(inputs['canonicalFeatures'])
    assert meta_record['generationCount']==1 and meta_record['baselineGenerationCount']==1
    assert packet==canonical,'Never change the original feature-free canonical packet to make new features pass'
    prior=baseline['features']+new_features
    index={(f['variant_id'],f['criterion']):f for f in prior};assert len(index)==len(prior)==759
    for row in data['variants']:
        for rf in row['features']:
            criterion=rf['criterion'];before=index[(row['id'],criterion)];deps=[effective[row['id']][k] for k in rf['keys']]
            ids=list(dict.fromkeys(id for f in deps for id in f['sourceIds']))
            grade=rf.get('grade') or ('reported' if any(f['buyerGrade']=='reported' for f in deps) else 'check' if any(f['buyerGrade']=='check' for f in deps) else 'confirmed')
            conditions=' '.join(dict.fromkeys(x for x in [rf.get('conditions'),*[f.get('conditionExplanation') for f in deps if f['buyerGrade']=='check']] if x))
            after=copy.deepcopy(before)
            for k in ['gradeReviewStatus','confirmation_needed']:after.pop(k,None)
            after.update(value=rf['value'],status='standard' if grade=='confirmed' else 'conditional',conditions=conditions,condition_label='Specific source/fitment condition' if conditions else '',source_ids=ids,evidence_scope='Reviewed Australian XPENG '+row['model']+' '+row['trim'],last_evidence_date=D,reviewed_date=D,verification_state='reviewed_m1_xpeng_2026_10_15',buyerGrade=grade,gradeReview=dict(reviewedAt=D,overlayId=PID,reason='Reviewed equipment answer follows its exact post-packet facts and cited source scope.',evidenceScope='secondary_or_sibling' if grade=='reported' else 'exact_au_version',sourceIds=ids,sourceLabel=' / '.join(dict.fromkeys(s['publisher'] for s in packet['sources'] if s['id'] in ids))))
            packet['features'].append(dict(variantId=row['id'],criterion=criterion,before=before,after=after,dependencies=[dict(key=f['key'],expected=f) for f in deps]))
for pin in inputs.values():read(pin)
for pin in capturePins:
    f=Path(pin['path']);assert sha(f)==pin['sha256'] and f.stat().st_size==pin['bytes']
assert sha(mp)==mh
out={key:write_new(path,value) for key,path,value in [('packet',m['outputs']['packet'],packet),('effectiveFacts',m['outputs']['effectiveFacts'],effective)]}
write_new(m['outputs']['receipt'],dict(status='assembled_pending_actual_function_validation',phase=m['phase'],manifestSha256=mh,normalizedEvidenceSha256=inputs['normalized']['sha256'],baselineReceiptSha256=inputs['baselineReceipt']['sha256'],originalBeforeValuesUnchanged=True,outputs=out,capturePins=capturePins,newIds=m['newIds'],counts={'versions':11,'newVersions':6,'sources':len(packet['sources']),'facts':len(packet['facts']),'brandTerms':len(packet['brandTerms']),'features':len(packet['features']),'summaries':len(packet['summaries'])},productionFunctionsExecuted=False,canonicalCapturePerformed=False,candidateRegistered=False))
print(json.dumps(out,indent=2))
