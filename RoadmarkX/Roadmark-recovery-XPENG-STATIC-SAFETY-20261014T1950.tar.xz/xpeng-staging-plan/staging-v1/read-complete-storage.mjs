/** Recursive full-value derived-storage reader. No production loader and no inferred path. */
import assert from 'node:assert/strict';
import { readJson, locate, pin, streamRows, digestRows, readResearch } from '../baseline-io.mjs';

/** proof.assertPinned(ref) must require an exact reviewed input pin, not capture a new expectation. */
export async function readCompleteCars(proof, indexRef, activeIndexes = new Set()) {
  proof.assertPinned(indexRef); pin(proof.anchors, indexRef);
  const file = locate(proof.anchors, indexRef);
  assert(!activeIndexes.has(file), 'Cyclic storage index'); activeIndexes.add(file);
  try {
    const index = readJson(file), descriptor = index.cars;
    assert.equal(descriptor.mode, 'baseline-with-complete-replacements-and-appended-identities');
    const expected = descriptor.carHashes, expectedIds = expected.map(row => row.id);
    assert.equal(expected.length, descriptor.rows); assert.equal(new Set(expectedIds).size, descriptor.rows);
    assert.equal(new Set(descriptor.newIds).size, descriptor.newIds.length);
    proof.assertPinned(descriptor.baseline); proof.assertPinned(descriptor.replacements);
    pin(proof.anchors, descriptor.baseline); pin(proof.anchors, descriptor.replacements);
    let baseline;
    if (descriptor.baseline.format === 'storage-index') {
      const child = await readCompleteCars(proof, descriptor.baseline, activeIndexes);
      baseline = child.cars;
      assert.equal(baseline.length, descriptor.baseline.rows);
    } else {
      assert(!descriptor.baseline.format || descriptor.baseline.format === 'jsonl');
      baseline = []; await streamRows(proof.anchors, descriptor.baseline, value => { baseline.push(value); });
    }
    assert.equal(descriptor.replacements.format, 'json');
    const replacements = readJson(locate(proof.anchors, descriptor.replacements));
    assert.equal(replacements.length, descriptor.replacements.rows);
    const replacementMap = new Map(replacements.map(car => [car.id, car])); assert.equal(replacementMap.size, replacements.length);
    assert.deepEqual(replacements.map(car => car.id), expected.filter(row => replacementMap.has(row.id)).map(row => row.id), 'Complete replacements in effective-car order');
    assert.equal(baseline.length + descriptor.newIds.length, descriptor.rows);
    assert.deepEqual(expectedIds, [...baseline.map(car => car.id), ...descriptor.newIds]);
    const consumed = new Set(), cars = [];
    function accept(car, row) {
      assert.equal(car.id, row.id); assert.equal(car.brand, row.brand);
      const digest = digestRows([car]); assert.equal(digest.sha256, row.afterSha256); assert.equal(digest.bytes, row.bytes);
      cars.push(car);
    }
    for (const [ordinal, original] of baseline.entries()) {
      const row = expected[ordinal]; assert.equal(original.id, row.id); assert.equal(original.brand, row.brand);
      assert.equal(digestRows([original]).sha256, row.beforeSha256, 'Every full inherited car at every storage layer');
      const replacement = replacementMap.get(original.id); if (replacement) consumed.add(original.id);
      accept(replacement ?? original, row);
    }
    for (const [offset, id] of descriptor.newIds.entries()) {
      const row = expected[baseline.length + offset]; assert.equal(row.beforeSha256, null);
      assert(!consumed.has(id)); const car = replacementMap.get(id); assert(car); consumed.add(id); accept(car, row);
    }
    assert.equal(consumed.size, replacements.length); assert.equal(new Set(cars.map(car => car.id)).size, descriptor.rows);
    assert.deepEqual(cars.map(car => car.id), expectedIds);
    pin(proof.anchors, indexRef); pin(proof.anchors, descriptor.baseline); pin(proof.anchors, descriptor.replacements);
    return { index, cars };
  } finally { activeIndexes.delete(file); }
}

export async function readCompleteBaseline(proof) {
  const result = await readCompleteCars(proof, proof.manifest.baselineStorageIndex);
  assert.equal(result.cars.length, 399); assert.equal(result.index.asOf, proof.manifest.asOf);
  for (const row of Object.values(result.index.research)) { proof.assertPinned(row); pin(proof.anchors, row); }
  const data = await readResearch(proof.anchors, result.index, proof.manifest.researchFields);
  assert.equal(Object.keys(data).length, 14); assert.equal(data.variants.length, 399);
  assert.deepEqual(data.variants.map(row => row.id), result.cars.map(car => car.id));
  return { ...result, data };
}
