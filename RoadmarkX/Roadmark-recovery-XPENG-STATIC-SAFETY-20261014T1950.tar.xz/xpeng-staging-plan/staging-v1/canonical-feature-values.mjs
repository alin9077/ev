/** New-version feature values only. The reviewed driver owns the exclusive once-only capture claim. */
import path from 'node:path';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { digestRows } from '../baseline-io.mjs';

export function captureNewFeatureValues(proof, actual) {
  assert.equal(proof.manifest.phase, 'canonical');
  assert.equal(proof.canonicalCaptureClaim.generationCount, 1);
  assert.equal(proof.canonicalCaptureClaim.manifestSha256, proof.manifestSha256);
  assert.equal(proof.canonicalCaptureClaim.featureFreePacketSha256, actual.packetRef.sha256);
  assert.equal(actual.packet.features.length, 0);
  const require = createRequire(path.join(proof.anchors.repo, 'package.json'));
  const { createEvidenceConsumers } = require('./src/lib/evidence-consumers.ts');
  const { brandUpdatePackets } = require('./src/lib/brand-update-registry.ts');
  assert.deepEqual(brandUpdatePackets, proof.registeredPackets, 'Exactly the registered eighteen packets; no XPENG shim');
  let defaultCalls = 0;
  const forbidden = () => { defaultCalls++; throw new Error('Canonical XPENG features require explicit immutable full baseline'); };
  const consumers = createEvidenceConsumers({ sourceResearch: forbidden, research: forbidden, catalogue: forbidden });
  const snapshot = { data: actual.data, cars: actual.cars }, ids = new Set(proof.manifest.newIds);
  const newCars = actual.selected.filter(car => ids.has(car.id)); assert.equal(newCars.length, 6);
  assert.deepEqual(newCars.map(car => car.id), proof.manifest.newIds);
  const selectedBefore = actual.selected.map(car => digestRows([car])), features = [], perCar = [];
  for (const car of newCars) {
    const pack = consumers.pack(car.id, snapshot);
    assert.deepEqual(pack.car, car); assert.equal(pack.features.length, 69);
    assert.equal(new Set(pack.features.map(row => row.criterion)).size, 69);
    assert(pack.features.every(row => row.variant_id === car.id));
    assert.deepEqual(pack.features.map(row => row.criterion).sort(), actual.data.criteria.map(row => row.key).sort());
    features.push(...pack.features); perCar.push({ id: car.id, ...digestRows(pack.features) }); global.gc?.();
  }
  assert.equal(features.length, 414); assert.equal(defaultCalls, 0);
  for (const [i, car] of actual.selected.entries()) assert.deepEqual(digestRows([car]), selectedBefore[i]);
  actual.verifyUnchanged();
  return { features, perCar, defaultCalls, selectedCarsDigest: digestRows(actual.selected) };
}
