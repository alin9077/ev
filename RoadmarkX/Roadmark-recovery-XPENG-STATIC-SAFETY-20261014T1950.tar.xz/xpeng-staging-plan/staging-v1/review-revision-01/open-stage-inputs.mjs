/** A new staging manifest binds completed baseline extraction, assembler output, and source pins. */
import path from 'node:path';
import assert from 'node:assert/strict';
import {
  argumentsFor, readJson, fileHash, locate, referenceFor, pin, verifyPins, sourceNames,
} from '../baseline-io.mjs';

export function openStageInputs() {
  const args = argumentsFor(['--manifest', '--manifest-sha256', '--review', '--review-sha256']);
  assert.equal(fileHash(args['--manifest']), args['--manifest-sha256']); assert.equal(fileHash(args['--review']), args['--review-sha256']);
  const manifest = readJson(args['--manifest']), review = readJson(args['--review']), { anchors } = manifest;
  assert.equal(manifest.schemaVersion, 1); assert.equal(manifest.mode, 'reviewed-xpeng-staging-v1');
  assert(['canonical', 'final-core'].includes(manifest.phase)); assert.equal(process.cwd(), anchors.repo);
  assert.equal(manifest.asOf, '2026-10-15'); assert.equal(manifest.packetId, 'm1-xpeng-2026-10-15');
  assert.equal(manifest.nodeVersion, process.version); assert.equal(typeof global.gc, 'function');
  locate(anchors, referenceFor(anchors, args['--manifest'])); locate(anchors, referenceFor(anchors, args['--review']));
  assert.equal(review.status, 'approved_for_' + manifest.phase.replace('-', '_') + '_xpeng_staging_v1');
  assert.equal(review.manifestSha256, args['--manifest-sha256']); assert.equal(review.phase, manifest.phase);
  assert.equal(review.evidenceReviewed, true); assert.equal(review.compositionReviewed, true);
  assert.equal(review.canonicalCaptureAuthorized, manifest.phase === 'canonical');
  assert.deepEqual(review.harnessPins, manifest.harnessPins);
  const pins = new Map(manifest.inputPins.map(row => [locate(anchors, row), row])); assert.equal(pins.size, manifest.inputPins.length);
  function assertPinned(row) {
    const expected = pins.get(locate(anchors, row)); assert(expected, 'Required reviewed pin absent');
    assert.equal(expected.sha256, row.sha256); if (row.bytes !== undefined) assert.equal(expected.bytes, row.bytes);
  }
  for (const row of manifest.harnessPins) assertPinned(row);
  const ownScripts = ['read-complete-storage.mjs', 'compose-xpeng-research.mjs', 'apply-actual-core.mjs', 'canonical-feature-values.mjs', 'open-stage-inputs.mjs', 'run-core-stage.mjs', 'staging-design.md'];
  for (const name of ownScripts) assert(manifest.harnessPins.some(row => row.anchor === 'xpeng' && row.file === 'staging-v1/' + name), 'Required reviewed staging script/plan omitted');
  for (const key of ['baselineManifest', 'baselineExtractionReceipt', 'baselineStorageIndex', 'currentSourceInventory', 'selectedBeforeCars', 'existingBeforeFeatures', 'assemblerManifest', 'featureFreePacket', 'packet', 'evidenceReview', 'compositionReview']) assertPinned(manifest[key]);
  assert.equal(review.evidenceReviewSha256, manifest.evidenceReview.sha256);
  assert.equal(review.compositionReviewSha256, manifest.compositionReview.sha256);
  const baselineManifest = readJson(locate(anchors, manifest.baselineManifest));
  assert.deepEqual(anchors, baselineManifest.anchors);
  assert.deepEqual(manifest.currentSourceInventory, baselineManifest.currentSourceInventory, 'No implicit source-pin transition in this staging design');
  assert.deepEqual(manifest.baselineStorageIndex, baselineManifest.approved.storageIndex);
  assert.deepEqual(manifest.researchFields, baselineManifest.expected.researchFields);
  assert.deepEqual(manifest.existingIds, baselineManifest.expected.selectedIds);
  for (const row of baselineManifest.inputPins) assertPinned(row);
  const receipt = readJson(locate(anchors, manifest.baselineExtractionReceipt));
  assert.equal(receipt.status, 'passed_read_only_derived_xpeng_baseline_extraction'); assert.equal(receipt.manifestSha256, manifest.baselineManifest.sha256);
  for (const [key, name] of [['selectedBeforeCars', 'selected-complete-before-cars.json'], ['existingBeforeFeatures', 'actual-before-features.json']]) {
    assert.equal(receipt.artifacts[name].path, locate(anchors, manifest[key])); assert.equal(receipt.artifacts[name].sha256, manifest[key].sha256);
  }
  assert.equal(receipt.completeCarsVerified, 399); assert.equal(receipt.actualFeatureRows, 345); assert.equal(receipt.defaultLoaderCalls, 0);
  const assembler = readJson(locate(anchors, manifest.assemblerManifest));
  assert.equal(assembler.schemaVersion, 1); assert.equal(assembler.mode, 'immutable-xpeng-feature-free-candidate');
  assert.deepEqual(assembler.featureFreePacket, manifest.featureFreePacket);
  assert.deepEqual(assembler.baselineExtractionReceipt, manifest.baselineExtractionReceipt);
  assert.deepEqual(assembler.newIds, manifest.newIds); assert.equal(manifest.newIds.length, 6);
  assert.equal(new Set(manifest.newIds).size, 6);
  assert.deepEqual(manifest.newIdRoles, ['l03_sr', 'l03_lr', 'l03_awd_ultra', 'gen1_my2024_sr', 'gen1_my2025_sr', 'gen1_my2025_lr']);
  assert.deepEqual(assembler.newIdRoles, manifest.newIdRoles);
  const sourceInventory = readJson(locate(anchors, manifest.currentSourceInventory));
  for (const row of sourceInventory.files) assertPinned({ anchor: 'repo', ...row });
  assert.deepEqual(manifest.registeredPackets, baselineManifest.packets);
  const registeredPackets = manifest.registeredPackets.map(row => { assertPinned(row.input); const packet = readJson(locate(anchors, row.input)); assert.equal(packet.id, row.id); return packet; });
  assert.equal(registeredPackets.length, 18);
  const packet = readJson(locate(anchors, manifest.packet)), featureFreePacket = readJson(locate(anchors, manifest.featureFreePacket));
  assert(Array.isArray(featureFreePacket.features)); assert.equal(featureFreePacket.features.length, 0);
  assert.equal(packet.id, manifest.packetId); assert.equal(featureFreePacket.id, manifest.packetId);
  assert.deepEqual(packet.variants.map(row => row.id), manifest.newIds);
  if (manifest.phase === 'canonical') assert.deepEqual(manifest.packet, manifest.featureFreePacket);
  else {
    for (const key of ['canonicalMeta', 'canonicalPacket', 'canonicalSelectedCars', 'canonicalNewFeatures', 'canonicalAcceptance']) assertPinned(manifest[key]);
    const acceptance = readJson(locate(anchors, manifest.canonicalAcceptance));
    assert.equal(acceptance.status, 'accepted_original_xpeng_canonical_baseline');
    assert.equal(acceptance.canonicalMetaSha256, manifest.canonicalMeta.sha256);
    assert.equal(acceptance.captureGenerationCount, 1);
    assert(acceptance.fullPacketAndSelectedCarsVerified && acceptance.all14RawAndComposedFieldsVerified && acceptance.all414OriginalFeatureRowsVerified);
  }
  function verify() {
    assert.equal(fileHash(args['--manifest']), args['--manifest-sha256']); assert.equal(fileHash(args['--review']), args['--review-sha256']);
    assert.deepEqual(sourceNames(anchors.repo), sourceInventory.files.map(row => row.file).sort());
    verifyPins(anchors, manifest.inputPins);
    for (const key of ['baselineManifest', 'baselineExtractionReceipt', 'assemblerManifest']) pin(anchors, manifest[key]);
  }
  verify();
  return { anchors, manifest, manifestSha256: args['--manifest-sha256'], reviewSha256: args['--review-sha256'], registeredPackets, assertPinned, verify };
}
