/** Separate canonical or final-core driver. Never run before phase-specific review and root allocation. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { readJson, locate, pin, referenceFor, fileHash, digestRows, newDirectory, writeNewJson } from '../baseline-io.mjs';
import { openStageInputs } from './open-stage-inputs.mjs';
import { applyActualCore, assertFinalMatchesCanonical } from './apply-actual-core.mjs';
import { captureNewFeatureValues } from './canonical-feature-values.mjs';

const proof = openStageInputs(), { manifest, anchors } = proof;
assert.equal(manifest.output.anchor, 'xpeng'); assert(/^staging-artifacts\/[a-z0-9][a-z0-9_-]*$/.test(manifest.output.directory));
const out = newDirectory(anchors.xpeng, manifest.output.directory);
function outputPin(result) { return { ...referenceFor(anchors, result.path), sha256: result.sha256, bytes: result.bytes }; }
function write(name, value) { return outputPin(writeNewJson(out, name, value)); }
function copy(name, input) {
  proof.assertPinned(input); pin(anchors, input);
  const target = path.join(out, name); assert.equal(path.basename(name), name);
  fs.copyFileSync(locate(anchors, input), target, fs.constants.COPYFILE_EXCL);
  assert.equal(fileHash(target), input.sha256);
  return { ...referenceFor(anchors, target), sha256: input.sha256, bytes: fs.statSync(target).size };
}
if (manifest.phase === 'canonical') {
  // This single logical capture claim cannot be moved for an amended candidate or retry.
  assert.equal(manifest.canonicalClaim.anchor, 'xpeng');
  assert.equal(manifest.canonicalClaim.file, 'staging-artifacts/xpeng-2026-10-15-original-capture-claim.json');
  const directory = path.join(anchors.xpeng, 'staging-artifacts'); assert.equal(fs.realpathSync(directory), directory);
  const claim = { generationCount: 1, manifestSha256: proof.manifestSha256, independentReviewSha256: proof.reviewSha256, featureFreePacketSha256: manifest.featureFreePacket.sha256, outputDirectory: manifest.output.directory };
  const claimFile = path.join(anchors.xpeng, manifest.canonicalClaim.file);
  fs.writeFileSync(claimFile, JSON.stringify(claim, null, 2) + '\n', { flag: 'wx' });
  proof.canonicalCaptureClaim = claim;
}
const actual = await applyActualCore(proof, manifest.packet);
let captured, canonical;
if (manifest.phase === 'canonical') captured = captureNewFeatureValues(proof, actual);
else {
  canonical = {
    meta: readJson(locate(anchors, manifest.canonicalMeta)),
    packet: readJson(locate(anchors, manifest.canonicalPacket)),
    selectedCars: readJson(locate(anchors, manifest.canonicalSelectedCars)),
    newFeatures: readJson(locate(anchors, manifest.canonicalNewFeatures)),
    existingFeatures: readJson(locate(anchors, manifest.existingBeforeFeatures)),
  };
  assert.equal(canonical.meta.featureFreePacket.sha256, manifest.featureFreePacket.sha256);
  assert.deepEqual(canonical.meta.featureFreePacket, manifest.canonicalPacket);
  assert.deepEqual(canonical.meta.selectedCars, manifest.canonicalSelectedCars);
  assert.deepEqual(canonical.meta.newFeatures, manifest.canonicalNewFeatures);
  assert.equal(canonical.meta.baselineStorageIndex.sha256, manifest.baselineStorageIndex.sha256);
  assert.equal(canonical.meta.baselineExtractionReceipt.sha256, manifest.baselineExtractionReceipt.sha256);
  assert.deepEqual(canonical.meta.existingBeforeFeatures, manifest.existingBeforeFeatures);
  for (const key of ['rawResearchIndex', 'storageIndex', 'transition', 'originalCaptureClaim', 'existingBeforeFeatures']) proof.assertPinned(canonical.meta[key]);
  for (const key of ['rawResearchIndex', 'storageIndex']) {
    const retainedIndex = readJson(locate(anchors, canonical.meta[key]));
    assert.equal(Object.keys(retainedIndex.research).length, 14);
    for (const row of Object.values(retainedIndex.research)) proof.assertPinned(row);
  }
  assertFinalMatchesCanonical(proof, actual, canonical);
}

function writeRows(name, values) {
  const file = path.join(out, name); assert.equal(path.basename(name), name);
  const fd = fs.openSync(file, 'wx');
  try {
    for (const value of values) {
      const row = Buffer.from(JSON.stringify(value) + '\n', 'utf8'); let offset = 0;
      while (offset < row.length) { const written = fs.writeSync(fd, row, offset, row.length - offset); assert(written > 0); offset += written; }
    }
  } finally { fs.closeSync(fd); }
  const digest = digestRows(values); assert.equal(fileHash(file), digest.sha256); assert.equal(fs.statSync(file).size, digest.bytes);
  return { ...referenceFor(anchors, file), ...digest };
}
function storeFields(data, beforeIndex, prefix) {
  const result = {};
  for (const [key, value] of Object.entries(data)) {
    const array = Array.isArray(value), rows = array ? value : [value], digest = digestRows(rows), prior = beforeIndex.research[key];
    result[key] = prior && digest.sha256 === prior.sha256 && digest.bytes === prior.bytes && digest.rows === prior.rows
      ? { ...prior }
      : { ...writeRows(prefix + '-' + key + '.jsonl', rows), array };
    global.gc?.();
  }
  assert.equal(Object.keys(result).length, 14); return result;
}
const rawResearch = storeFields(actual.raw, actual.baseline.index, 'raw-research');
const research = storeFields(actual.data, { research: rawResearch }, 'composed-research');
const rawResearchIndex = write('raw-research-index.json', { schemaVersion: 1, mode: 'preserved_exact_actual_single_packet_output', research: rawResearch });
const selectedCars = write('selected-complete-after-cars.json', actual.selected);
const transition = write('composition-transition.json', {
  ...actual.composed.transition, rawResearchIndex,
  registeredPacketPins: manifest.registeredPackets, actualProductionSource: manifest.inputPins.find(row => row.anchor === 'repo' && row.file === 'src/lib/brand-updates.ts'),
  inputManifestSha256: proof.manifestSha256, compositionReviewSha256: proof.reviewSha256,
});
const storageIndex = write('staged-storage-index.json', {
  schemaVersion: 1, mode: 'derived_only_xpeng_recursive_baseline_plus_complete_replacements', asOf: manifest.asOf,
  research, cars: {
    mode: 'baseline-with-complete-replacements-and-appended-identities',
    baseline: { ...manifest.baselineStorageIndex, format: 'storage-index', rows: 399 },
    replacements: { ...selectedCars, format: 'json', rows: 11 }, newIds: manifest.newIds, rows: 405, carHashes: actual.carHashes,
  },
  packetSha256: manifest.packet.sha256, inputManifestSha256: proof.manifestSha256,
  freshFullValueLoaderExport: false, candidateRegistered: false,
});
let canonicalMeta = null;
if (manifest.phase === 'canonical') {
  const featureFreePacket = copy('canonical-packet-original.json', manifest.featureFreePacket);
  const newFeatures = write('new-feature-before-original.json', captured.features);
  canonicalMeta = write('canonical-baseline-meta.json', {
    status: 'captured_once_pending_independent_review', captureGenerationCount: 1, generationCount: 1, baselineGenerationCount: 1,
    baselineStorageIndex: manifest.baselineStorageIndex, baselineExtractionReceipt: manifest.baselineExtractionReceipt,
    featureFreePacket, featureFreePacketDigest: actual.packetDigest,
    selectedCars, selectedCarsDigest: captured.selectedCarsDigest,
    newFeatures, newIds: manifest.newIds, newFeatureRows: 414, perCar: captured.perCar,
    existingBeforeFeatures: manifest.existingBeforeFeatures,
    rawFieldDigests: actual.composed.rawFieldDigests, composedFieldDigests: actual.composed.composedFieldDigests,
    rawMetadata: actual.raw.metadata, composedMetadata: actual.data.metadata,
    rawResearchIndex, storageIndex, transition,
    originalCaptureClaim: { ...manifest.canonicalClaim, sha256: fileHash(path.join(anchors.xpeng, manifest.canonicalClaim.file)) },
    inputManifestSha256: proof.manifestSha256, independentReviewSha256: proof.reviewSha256,
    defaultLoaderCalls: captured.defaultCalls, freshFullValueLoaderExport: false, candidateRegistered: false,
  });
}
actual.verifyUnchanged();
const receipt = write('core-phase-receipt.json', {
  status: manifest.phase === 'canonical' ? 'captured_once_pending_independent_review' : 'passed_actual_final_core_pending_consumers_mutations_and_report',
  phase: manifest.phase, asOf: manifest.asOf, beforeCars: 399, afterCars: 405, xpengCars: 11, newCars: 6,
  all399InputCarsAnd14ResearchFieldsUnchanged: true, all394NonXpengOrLowerTierCarsUnchanged: true,
  rawSinglePacketOutputPreserved: true, onlyCompositionPath: 'metadata.brand_update_packet_ids',
  canonicalCompared: manifest.phase === 'final-core', canonicalMeta, storageIndex, rawResearchIndex, selectedCars, transition,
  ...(manifest.phase === 'canonical' ? { generationCount: 1, baselineGenerationCount: 1 } : {}),
  inputManifestSha256: proof.manifestSha256, independentReviewSha256: proof.reviewSha256,
  packetSha256: manifest.packet.sha256, freshFullValueLoaderExport: false, registered: false,
  actualFinalPacksVerified: false, fullFeatureStreamVerified: false, negativeMutationsVerified: false, fullReportVerified: false,
  resourceUsage: process.resourceUsage(), memoryUsage: process.memoryUsage(),
});
console.log(JSON.stringify({ receipt }, null, 2));
