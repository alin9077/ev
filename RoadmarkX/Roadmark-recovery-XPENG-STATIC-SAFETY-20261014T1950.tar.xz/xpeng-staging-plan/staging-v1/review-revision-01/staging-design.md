# XPENG immutable staging design v1

Prepared only. No file in this directory has been executed, imported, syntax-checked, or tested. The earlier five baseline preparation files are unchanged. No candidate, canonical claim, fixture, source inventory, or phase output is created by preparing these modules.

## Scope and interfaces

The current accepted derived baseline is 399 cars and five XPENG versions. The assembler owns the immutable feature-free candidate and reconciliation. It adds exactly six identities in this source-reviewed order:

1. Arriving L03 Standard Range
2. Arriving L03 Long Range
3. Arriving L03 AWD Ultra
4. Residual Gen1 MY2024 Standard Range
5. Residual Gen1 MY2025 Standard Range
6. Residual Gen1 MY2025 Long Range

The actual resulting core must contain exactly 405 cars, 11 XPENG versions, and 394 unchanged other-brand/lower-tier cars. Do not invent drivetrain identities for package options. Exact IDs are supplied by the assembler and reviewed source reconciliation, never inferred by these modules.

The assembler emits a JSON manifest with:

- `schemaVersion: 1`
- `mode: "immutable-xpeng-feature-free-candidate"`
- `featureFreePacket`: exact `{anchor,file,sha256,bytes}` locator for the already feature-free packet JSON, with explicit `features: []`
- `baselineExtractionReceipt`: exact pinned successful existing-five-XPENG extraction receipt
- `newIds`: six source-reviewed IDs in the order above
- `newIdRoles`: `["l03_sr","l03_lr","l03_awd_ultra","gen1_my2024_sr","gen1_my2025_sr","gen1_my2025_lr"]`

This is an interchange contract for the assembler author. These files do not duplicate packet assembly, reconciliation, evidence research, or evidence review.

## Files

- `read-complete-storage.mjs` recursively reads the approved 399-car index over its original 397 rows and 11 complete Subaru replacements, and supports later 405-car indexes whose baseline is the pinned 399-car index. Every layer requires exact full-car before/after hashes, bytes, IDs, brand, order, no duplicates, and exactly consumed replacement/appended identities
- `compose-xpeng-research.mjs` defines the separately reviewed 18-to-19 metadata composition and full-field preservation assertions
- `apply-actual-core.mjs` loads every complete baseline car and all 14 Research fields, invokes actual unchanged production `prepareBrandResearch` and `applyBrandUpdates`, compares all input/output cars, and checks final output against original canonical values
- `canonical-feature-values.mjs` invokes the unchanged production `createEvidenceConsumers` with explicit full snapshot and throwing defaults to capture precisely the six new versions' 414 original actual feature rows
- `open-stage-inputs.mjs` admits only a phase-specific reviewed immutable manifest, successful prior baseline extraction, assembler pins, current source pins, all 18 exact registered packet values, and applicable evidence/composition/canonical reviews
- `run-core-stage.mjs` runs either separately authorized `canonical` or `final-core`, writes exclusive versioned raw/composed full-value storage, preserves the original once-only canonical fixture, and writes the phase receipt last

No production source, registry, old fixture or old expectation is changed. No catalogue hydration, compiled-source shim, source-loader fallback, test, build, report, or final feature-stream execution occurs in these core phases. Current registry imports remain the original 18 registered packets.

## Composition proof

Let P be the full pinned registered 18-packet list, Q the immutable unregistered XPENG packet, and F the actual unchanged `prepareBrandResearch` implementation. The accepted baseline is the independently accepted derived value after P. Call the real function once as `raw = F(base, [Q])`. Keep that raw object, full metadata, all 14 full-field digests, and reconstructible full values.

The current production function assigns `metadata.brand_update_packet_ids` from the packets in that invocation. Therefore the actual raw value is `[Q.id]`. A separately identified hypothetical composition creates a new top-level object and a new metadata object with this one path replaced by the exact pinned P IDs followed by Q ID. It is never written back into raw or used to hide unexpected metadata.

The module checks:

- Exact registered 18-ID prefix, Subaru last, no registered XPENG, chronological unique 19-ID hypothetical sequence
- Existing historical feature-variant context projection is byte-for-byte idempotent
- The actual variant delta is six and source feature-row delta is 414; safe-integer added counters telescope exactly
- All other 13 full Research fields retain their references and complete digests
- Every other metadata property, property order, and serialized value is identical to the raw actual value
- Raw all-14-field values and all original 14 baseline fields remain unchanged after core and consumer execution

This is hypothetical staged composition only. It is not a production metadata repair or proof of a fresh full-value loader export.

## Staging manifest and review

Generate an immutable versioned JSON manifest only after baseline extraction and assembler output exist. Do not fill unknown pins with placeholders or infer that new observed hashes are accepted. All input refs use the inherited precise baseline anchors and are included once in `inputPins`. Include recursive storage leaves and indexes, original fixture files, every baseline-manifest input, all source files, all 18 packets, assembler/candidate inputs, reviews, and this complete seven-file harness.

Required manifest fields:

- `schemaVersion: 1`, `mode: "reviewed-xpeng-staging-v1"`, `phase: "canonical"` or `"final-core"`, `asOf: "2026-10-15"`, `packetId: "m1-xpeng-2026-10-15"`, exact `nodeVersion`
- `anchors`: exact inherited baseline anchor map
- `baselineManifest`, `baselineExtractionReceipt`, `baselineStorageIndex`, `currentSourceInventory`, `selectedBeforeCars`, `existingBeforeFeatures`: pinned refs from the completed reviewed baseline extraction
- `researchFields`: exact 14-field baseline list; `existingIds`: exact five baseline IDs
- `assemblerManifest`, `featureFreePacket`, `packet`: pinned immutable files; canonical phase requires identical packet and feature-free refs
- `newIds` and `newIdRoles`: exact assembler arrays
- `registeredPackets`: exact full ordered packet descriptor array from the baseline manifest
- `evidenceReview`, `compositionReview`: pinned actual independent approval artifacts
- `harnessPins`: all seven files listed above, in explicit order; also retain the earlier baseline helper pins in `inputPins`
- `inputPins`: exhaustive immutable bounded input refs
- `output: {"anchor":"xpeng","directory":"staging-artifacts/<unique-phase-attempt>"}`
- Canonical only: `canonicalClaim: {"anchor":"xpeng","file":"staging-artifacts/xpeng-2026-10-15-original-capture-claim.json"}`
- Final-core only: `canonicalMeta`, `canonicalPacket`, `canonicalSelectedCars`, `canonicalNewFeatures`, `canonicalAcceptance`: pinned original files and review; include every canonical file referenced by metadata/indexes in `inputPins`

Current-source policy remains strict: `currentSourceInventory` must equal the successful baseline manifest's current inventory. All source names and bytes are checked before and after. A later UI-caption correction or other source edit is not silently accepted merely because it looks unrelated. It requires a separately reviewed source transition and a new design/contract amendment preserving this version and its historical inventory.

The independent phase review must contain:

- `status`: `approved_for_canonical_xpeng_staging_v1` or `approved_for_final_core_xpeng_staging_v1`
- exact `phase`, `manifestSha256`, and `harnessPins`
- `evidenceReviewed: true`, `compositionReviewed: true`, `evidenceReviewSha256`, `compositionReviewSha256`
- `canonicalCaptureAuthorized`: true only for the canonical phase, false for final-core

Root separately allocates the heavy slot and authorizes the exact measured command. Example argument shape only, not executed:

`node --expose-gc --import tsx /tmp/xpeng-staging-plan/staging-v1/run-core-stage.mjs --manifest <immutable-phase-manifest> --manifest-sha256 <sha256> --review <independent-phase-review> --review-sha256 <sha256>`

Use root's resource ceiling. Full 399-car and 14-field retention is required by this full-core proof, so the baseline source-pinning phase's 256 MiB budget is not an assumed runtime limit for these phases. Preserve terminal command, exit/signal, elapsed time, RSS, stdout and stderr separately. None of these phases is presently authorized or executed.

## Canonical phase: one original fixture

Before actual function evaluation, the driver exclusively creates the fixed logical XPENG capture claim. Its path is stable across manifests and amendments; a new output directory cannot evade it. It identifies the exact feature-free packet, phase manifest, independent review, and output directory. If an attempt fails, retain claim and partial files. This harness cannot regenerate the canonical fixture under another pathname or reset the claim. Recovery needs a separate explicit review of what was actually produced.

Apply the exact feature-free packet to full baseline data/cars. Reconstruct and hash all 405 cars, with complete other-brand equality. Capture the actual new six-car/414-row consumer result against the unchanged 18-packet registry. No feature rows are invented, normalized, copied from siblings, or hand-edited. Preserve the complete 11 selected after-cars and original candidate file bytes as well as full raw/composed research storage and digests.

An independent reviewer then creates `canonicalAcceptance` with:

- `status: "accepted_original_xpeng_canonical_baseline"`
- exact `canonicalMetaSha256`, `captureGenerationCount: 1`
- `fullPacketAndSelectedCarsVerified: true`
- `all14RawAndComposedFieldsVerified: true`
- `all414OriginalFeatureRowsVerified: true`

For the packet assembler's `canonicalReceipt` input, use the original `canonical-baseline-meta.json`. It carries `generationCount: 1` and `baselineGenerationCount: 1` as well as `captureGenerationCount: 1`. The canonical phase receipt also preserves the two assembler count fields. These are written only by the once-only capture path; final-core requires all three metadata counts to remain exactly one. The assembler's 124 guarded equipment replacements remain its own output, checked against the unchanged complete original fixture rows.

The existing five versions' 345 before rows remain the original accepted actual baseline extraction. The new six versions' 414 before rows remain the one original canonical capture. Neither set is changed to make the final packet pass.

## Final-core phase

The final packet may add only guarded feature replacements. Removing that `features` array must recover the full original feature-free packet by complete value and canonical row digest, including property order. Every feature replacement's complete before row must equal its original existing-five or new-six fixture row.

Run the actual full core again, preserving raw output and composition independently. Require exact original canonical full 11-car equality, selected-car digest equality, and all 14 original raw and all 14 original composed field digests. Check every remaining 394 complete car unchanged and all 399 original input cars/14 input fields unchanged. Any mismatch stops the phase; do not relax guards or recapture fixtures.

The output index references the immutable accepted 399-car index as `cars.baseline` with `format: "storage-index"`, plus complete 11-car replacements and the six appended identities. It retains all 405 per-car before/after digests and exact order. All changed research fields are stored as exact standard JSONL; identical fields reuse original immutable refs. Raw and composed metadata remain separate full-value artifacts.

The final-core receipt explicitly leaves actual final packs, complete effective features, mutations, complete report, fresh registered integration, current full TypeScript/build/aggregate/mobile gates, and publication unverified. Those later phases need their own reviewed manifest-selected inputs and authorization.

## Static-review focus

Check recursive storage cycle detection, all exact per-layer original/effective car hashes/order, complete source pin closure, direct imports and actual function signatures, full raw-output retention, the one-path metadata expression, strict assembler/new-ID ordering, complete feature-free equality, the stable exclusive canonical claim, every source/canonical/field pin, and pass receipts written last. No status should imply runtime validation of these currently unexecuted modules.
