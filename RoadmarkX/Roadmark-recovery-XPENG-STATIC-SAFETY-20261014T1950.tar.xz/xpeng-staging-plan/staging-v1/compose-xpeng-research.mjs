/** Explicit hypothetical 18-to-19 composition. No registry mutation or raw-output repair. */
import assert from 'node:assert/strict';
import { digestRows } from '../baseline-io.mjs';

export function fieldDigests(data) {
  return Object.fromEntries(Object.entries(data).map(([key, value]) => [key, digestRows(Array.isArray(value) ? value : [value])]));
}
export function assertFieldDigests(data, expected, message) {
  assert.deepEqual(Object.keys(data), Object.keys(expected), message + ': complete field names/order');
  for (const [key, value] of Object.entries(data)) assert.deepEqual(digestRows(Array.isArray(value) ? value : [value]), expected[key], message + ': ' + key);
}
export function composeXpengResearch(base, packet, raw, registeredPackets, expectedNewIds) {
  assert.equal(registeredPackets.length, 18); assert.equal(new Set(registeredPackets.map(row => row.id)).size, 18);
  assert.equal(registeredPackets.at(-1).id, 'm1-subaru-2026-10-15');
  assert(!registeredPackets.some(row => row.id === packet.id || row.brand === 'XPENG'));
  assert.equal(packet.brand, 'XPENG'); assert.equal(packet.id, 'm1-xpeng-2026-10-15'); assert.equal(packet.reviewedAt, '2026-10-15');
  assert.equal(packet.variants.length, 6); assert.deepEqual(packet.variants.map(row => row.id), expectedNewIds);
  const registeredIds = registeredPackets.map(row => row.id), hypotheticalIds = [...registeredIds, packet.id];
  assert.equal(new Set(hypotheticalIds).size, 19);
  let previous = '';
  for (const row of [...registeredPackets, packet]) {
    assert(/^\d{4}-\d{2}-\d{2}$/.test(row.reviewedAt)); assert.equal(new Date(row.reviewedAt + 'T00:00:00Z').toISOString().slice(0, 10), row.reviewedAt);
    assert(row.reviewedAt >= previous); previous = row.reviewedAt;
  }
  assert.deepEqual(base.metadata.brand_update_packet_ids, registeredIds, 'Full accepted registered prefix');
  assert.deepEqual(raw.metadata.brand_update_packet_ids, [packet.id], 'Preserve actual invocation-scoped production assignment');
  assert.equal(Object.keys(base).length, 14); assert.deepEqual(Object.keys(raw), Object.keys(base));
  const context = base.feature_evidence_variant_context; assert(Array.isArray(context));
  const projected = context.map(({ id, model_id, record_state, configuration_evidence }) => ({ id, model_id, record_state, ...(configuration_evidence ? { configuration_evidence: structuredClone(configuration_evidence) } : {}) }));
  assert.deepEqual(digestRows(context), digestRows(projected), 'Historical source-feature context projection is exactly idempotent');
  assert.equal(base.variants.length, 399); assert.equal(raw.variants.length, 405); assert.equal(base.criteria.length, 69);
  assert.equal(raw.feature_evidence.length - base.feature_evidence.length, 414);
  for (const key of ['added_variant_count', 'added_feature_row_count']) {
    assert(Number.isSafeInteger(base.metadata[key]) && base.metadata[key] >= 0);
    assert(Number.isSafeInteger(raw.metadata[key]) && raw.metadata[key] >= 0);
  }
  assert.equal(raw.metadata.added_variant_count, base.metadata.added_variant_count + 6);
  assert.equal(raw.metadata.added_feature_row_count, base.metadata.added_feature_row_count + 414);
  const rawFieldDigests = fieldDigests(raw);
  const data = { ...raw, metadata: { ...raw.metadata, brand_update_packet_ids: hypotheticalIds } };
  assert.deepEqual(Object.keys(data), Object.keys(raw)); assert.deepEqual(Object.keys(data.metadata), Object.keys(raw.metadata));
  for (const key of Object.keys(raw)) if (key !== 'metadata') {
    assert.equal(data[key], raw[key], 'No replacement of the other thirteen full Research fields');
    assert.deepEqual(digestRows(Array.isArray(data[key]) ? data[key] : [data[key]]), rawFieldDigests[key]);
  }
  for (const key of Object.keys(raw.metadata)) if (key !== 'brand_update_packet_ids') {
    assert.equal(JSON.stringify(data.metadata[key]), JSON.stringify(raw.metadata[key]), 'Every other metadata property/order unchanged');
  }
  assertFieldDigests(raw, rawFieldDigests, 'Raw actual one-packet output preserved');
  return {
    data, rawFieldDigests, composedFieldDigests: fieldDigests(data),
    transition: {
      mode: 'hypothetical_registered_18_plus_xpeng_only', onlyChangedPath: 'metadata.brand_update_packet_ids',
      registeredPacketIds: registeredIds, hypotheticalPacketIds: hypotheticalIds,
      rawMetadata: structuredClone(raw.metadata), composedMetadata: structuredClone(data.metadata),
      rawFieldDigests, freshFullValueLoaderExport: false, candidateRegistered: false,
    },
  };
}
