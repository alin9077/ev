/** Actual full 399-to-405 core application. Caller supplies independently reviewed, pinned proof. */
import path from 'node:path';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readJson, locate, pin, digestRows, assertResearchUnchanged } from '../baseline-io.mjs';
import { readCompleteBaseline } from './read-complete-storage.mjs';
import { composeXpengResearch, fieldDigests, assertFieldDigests } from './compose-xpeng-research.mjs';

const tier1 = car => !car.vehicleClass || ['passenger', 'ute'].includes(car.vehicleClass);
export async function applyActualCore(proof, packetRef) {
  assert.equal(proof.manifest.schemaVersion, 1); assert.equal(proof.manifest.mode, 'reviewed-xpeng-staging-v1');
  assert.equal(process.cwd(), proof.anchors.repo); assert.equal(typeof global.gc, 'function');
  assert.equal(proof.manifest.phase === 'canonical' || proof.manifest.phase === 'final-core', true);
  proof.verify(); proof.assertPinned(packetRef); pin(proof.anchors, packetRef);
  const packet = readJson(locate(proof.anchors, packetRef)), packetDigest = digestRows([packet]);
  assert.equal(packet.id, proof.manifest.packetId); assert.equal(packet.brand, 'XPENG');
  assert.equal(proof.manifest.newIds.length, 6); assert.equal(new Set(proof.manifest.newIds).size, 6);
  assert.deepEqual(packet.variants.map(row => row.id), proof.manifest.newIds);
  if (proof.manifest.phase === 'canonical') { assert(Array.isArray(packet.features)); assert.equal(packet.features.length, 0, 'Input must already be feature-free, never silently edited by the harness'); }
  const baseline = await readCompleteBaseline(proof), before = baseline.cars, beforeData = baseline.data;
  const beforeCarDigests = before.map(car => ({ id: car.id, brand: car.brand, ...digestRows([car]) }));
  const beforeResearchDigests = fieldDigests(beforeData), beforeById = new Map(beforeCarDigests.map(row => [row.id, row]));
  const beforeSelected = before.filter(car => car.brand === 'XPENG' && tier1(car)); assert.equal(beforeSelected.length, 5);
  assert.deepEqual(beforeSelected.map(car => car.id), proof.manifest.existingIds);
  proof.assertPinned(proof.manifest.selectedBeforeCars);
  assert.deepEqual(beforeSelected, readJson(locate(proof.anchors, proof.manifest.selectedBeforeCars)), 'Exact actual-before extraction full cars');
  for (const id of proof.manifest.newIds) assert(!beforeById.has(id), 'Six genuinely new identities');
  const require = createRequire(path.join(proof.anchors.repo, 'package.json'));
  const { prepareBrandResearch, applyBrandUpdates } = require('./src/lib/brand-updates.ts');
  const { brandUpdatePackets } = require('./src/lib/brand-update-registry.ts');
  assert.equal(brandUpdatePackets.length, 18); assert.deepEqual(brandUpdatePackets, proof.registeredPackets);
  assert(!require.cache[path.join(proof.anchors.repo, 'src/lib/data.ts')], 'No fallback catalogue loader');
  global.gc();
  const raw = prepareBrandResearch(beforeData, [packet]);
  const composed = composeXpengResearch(beforeData, packet, raw, brandUpdatePackets, proof.manifest.newIds);
  const data = composed.data, cars = applyBrandUpdates(before, data, [packet]);
  assert.equal(cars.length, 405); assert.equal(new Set(cars.map(car => car.id)).size, 405);
  assert.deepEqual(cars.map(car => car.id), [...before.map(car => car.id), ...proof.manifest.newIds]);
  const selected = cars.filter(car => car.brand === 'XPENG' && tier1(car)); assert.equal(selected.length, 11);
  assert.deepEqual(selected.map(car => car.id), [...proof.manifest.existingIds, ...proof.manifest.newIds]);
  const carHashes = [];
  for (const car of cars) {
    const digest = digestRows([car]), prior = beforeById.get(car.id);
    if (car.brand !== 'XPENG' || !tier1(car)) {
      assert(prior); assert.equal(digest.sha256, prior.sha256, 'Every complete non-XPENG/lower-tier car unchanged'); assert.equal(digest.bytes, prior.bytes);
    }
    carHashes.push({ id: car.id, brand: car.brand, beforeSha256: prior?.sha256 ?? null, afterSha256: digest.sha256, bytes: digest.bytes });
  }
  assert.equal(cars.filter(car => car.brand !== 'XPENG' || !tier1(car)).length, 394);
  function verifyUnchanged() {
    assert.equal(cars.length, carHashes.length, 'Complete actual output-car count unchanged');
    assert.equal(cars.length, 405); assert.equal(new Set(cars.map(car => car.id)).size, 405);
    for (const [i, car] of cars.entries()) {
      const expected = carHashes[i], digest = digestRows([car]);
      assert.equal(car.id, expected.id, 'Every actual output car remains in captured order');
      assert.equal(car.brand, expected.brand, 'Complete actual output-car brand unchanged');
      assert.equal(digest.sha256, expected.afterSha256, 'Every complete actual output car unchanged after consumers/serialization: ' + car.id);
      assert.equal(digest.bytes, expected.bytes);
    }
    assert.equal(before.length, beforeCarDigests.length);
    for (const [i, car] of before.entries()) assert.deepEqual({ id: car.id, brand: car.brand, ...digestRows([car]) }, beforeCarDigests[i], 'Every complete original input car unchanged');
    assertFieldDigests(beforeData, beforeResearchDigests, 'Every original full Research field unchanged');
    assertResearchUnchanged(beforeData, baseline.index);
    assertFieldDigests(raw, composed.rawFieldDigests, 'Every raw output field preserved');
    assertFieldDigests(data, composed.composedFieldDigests, 'Every composed output field preserved');
    assert.deepEqual(digestRows([packet]), packetDigest); assert.deepEqual(brandUpdatePackets, proof.registeredPackets);
    pin(proof.anchors, packetRef); proof.verify();
  }
  verifyUnchanged();
  return { baseline, packet, packetRef, packetDigest, raw, data, cars, selected, carHashes, composed, verifyUnchanged };
}

/** Final packet may add guarded feature updates only; the original canonical packet is never reset. */
export function assertFinalMatchesCanonical(proof, actual, canonical) {
  assert.equal(proof.manifest.phase, 'final-core');
  assert.equal(canonical.meta.captureGenerationCount, 1);
  assert.equal(canonical.meta.generationCount, 1); assert.equal(canonical.meta.baselineGenerationCount, 1);
  assert(Array.isArray(actual.packet.features));
  const withoutFeatures = structuredClone(actual.packet); withoutFeatures.features = [];
  assert.deepEqual(withoutFeatures, canonical.packet);
  assert.deepEqual(digestRows([withoutFeatures]), canonical.meta.featureFreePacketDigest, 'Exact original feature-free packet including property order');
  assert.deepEqual(actual.selected, canonical.selectedCars, 'All eleven complete canonical selected cars');
  assert.deepEqual(digestRows(actual.selected), canonical.meta.selectedCarsDigest);
  assertFieldDigests(actual.raw, canonical.meta.rawFieldDigests, 'All fourteen original canonical raw fields');
  assertFieldDigests(actual.data, canonical.meta.composedFieldDigests, 'All fourteen original canonical composed fields');
  assert.deepEqual(actual.composed.transition.rawMetadata, canonical.meta.rawMetadata);
  assert.deepEqual(actual.composed.transition.composedMetadata, canonical.meta.composedMetadata);
  assert.equal(canonical.newFeatures.length, 414);
  const beforeExisting = new Map(canonical.existingFeatures.map(row => [row.variant_id + '\0' + row.criterion, row]));
  const beforeNew = new Map(canonical.newFeatures.map(row => [row.variant_id + '\0' + row.criterion, row]));
  assert.equal(beforeExisting.size, 345); assert.equal(beforeNew.size, 414);
  for (const edit of actual.packet.features) {
    const key = edit.variantId + '\0' + edit.criterion;
    const expected = beforeNew.get(key) ?? beforeExisting.get(key); assert(expected);
    assert.deepEqual(edit.before, expected, 'Full guarded feature before-row must be the original actual row');
  }
  actual.verifyUnchanged();
}
