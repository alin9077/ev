/** Read-only, manifest-selected IO. No production imports or mutable global cache. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import readline from 'node:readline';
import assert from 'node:assert/strict';

export const readJson = file => JSON.parse(fs.readFileSync(file, 'utf8'));
export const sha256 = value => crypto.createHash('sha256').update(value).digest('hex');
export function fileHash(file) {
  const hash = crypto.createHash('sha256'), chunk = Buffer.alloc(262144);
  const fd = fs.openSync(file, 'r');
  try { let n; while ((n = fs.readSync(fd, chunk, 0, chunk.length, null)) > 0) hash.update(chunk.subarray(0, n)); }
  finally { fs.closeSync(fd); }
  return hash.digest('hex');
}
export function argumentsFor(names) {
  const result = {}, args = process.argv.slice(2);
  assert.equal(args.length, names.length * 2, 'Every argument must be explicit');
  for (let i = 0; i < args.length; i += 2) {
    assert(names.includes(args[i]) && !Object.hasOwn(result, args[i]), 'Unknown or duplicate argument');
    assert(args[i + 1] && !args[i + 1].startsWith('--'));
    result[args[i]] = args[i + 1];
  }
  for (const name of names) assert(Object.hasOwn(result, name));
  return result;
}
export function within(root, file) {
  const relative = path.relative(root, file);
  return relative !== '' && !relative.startsWith('..' + path.sep) && relative !== '..' && !path.isAbsolute(relative);
}
export function locate(anchors, row) {
  assert(row && Object.hasOwn(anchors, row.anchor), 'Unknown explicit anchor');
  const root = anchors[row.anchor];
  assert.equal(path.resolve(root), root, 'Absolute canonical anchor required');
  assert.equal(fs.realpathSync(root), root, 'Anchor must not be redirected by a symlink');
  assert(typeof row.file === 'string' && !row.file.includes('\\') && !path.isAbsolute(row.file));
  assert(row.file.split('/').every(part => part && part !== '.' && part !== '..'), 'No ambiguous locator segments');
  const file = path.resolve(root, row.file);
  assert(within(root, file), 'Locator escaped its precise anchor');
  assert.equal(fs.realpathSync(file), file, 'Input path must not be redirected by a symlink');
  assert(fs.statSync(file).isFile(), 'Input must be a regular file');
  return file;
}
export function referenceFor(anchors, absolute) {
  assert.equal(path.resolve(absolute), absolute, 'Canonical absolute input path required');
  const matches = Object.entries(anchors).filter(([, root]) => within(root, absolute)).sort((a, b) => b[1].length - a[1].length);
  assert(matches.length, 'No approved anchor for ' + absolute);
  const [anchor, root] = matches[0], ref = { anchor, file: path.relative(root, absolute).split(path.sep).join('/') };
  locate(anchors, ref);
  return ref;
}
export function pin(anchors, ref) {
  const file = locate(anchors, ref), row = { anchor: ref.anchor, file: ref.file, bytes: fs.statSync(file).size, sha256: fileHash(file) };
  if (ref.sha256 !== undefined) assert.equal(row.sha256, ref.sha256, 'Approved bytes changed: ' + file);
  if (ref.bytes !== undefined) assert.equal(row.bytes, ref.bytes, 'Approved length changed: ' + file);
  return row;
}
export function verifyPins(anchors, rows) {
  const paths = new Set();
  for (const row of rows) { const file = locate(anchors, row); assert(!paths.has(file), 'Duplicate input pin'); paths.add(file); pin(anchors, row); }
}
export function digestRows(rows) {
  const hash = crypto.createHash('sha256'); let bytes = 0, count = 0;
  for (const row of rows) { const data = Buffer.from(JSON.stringify(row) + '\n', 'utf8'); hash.update(data); bytes += data.length; count++; }
  return { rows: count, bytes, sha256: hash.digest('hex') };
}
export const expectedDigest = row => ({ rows: row.rows, bytes: row.bytes, sha256: row.sha256 });

/** Canonical row verification also detects missing final newline or CRLF alteration. */
export async function streamRows(anchors, descriptor, visit) {
  const file = locate(anchors, descriptor), hash = crypto.createHash('sha256');
  let rows = 0, bytes = 0;
  for await (const line of readline.createInterface({ input: fs.createReadStream(file), crlfDelay: Infinity })) {
    assert(line.length > 0, 'Blank rows are never omitted');
    const value = JSON.parse(line), canonical = JSON.stringify(value);
    assert.equal(canonical, line, 'Complete stored row must retain standard JSON serialization');
    const encoded = Buffer.from(canonical + '\n', 'utf8'); hash.update(encoded); bytes += encoded.length;
    await visit(value, rows++);
  }
  const digest = { rows, bytes, sha256: hash.digest('hex') };
  assert.deepEqual(digest, expectedDigest(descriptor), 'Exact complete stored stream: ' + file);
  assert.equal(fs.statSync(file).size, bytes);
  return digest;
}
export async function readResearch(anchors, index, fields) {
  assert.deepEqual(Object.keys(index.research).sort(), [...fields].sort(), 'All fourteen Research fields, with no projection');
  const data = {};
  for (const [key, row] of Object.entries(index.research)) {
    assert.equal(typeof row.array, 'boolean'); assert(!row.format || row.format === 'jsonl');
    const values = []; await streamRows(anchors, row, value => { values.push(value); });
    assert(row.array || values.length === 1);
    data[key] = row.array ? values : values[0];
    global.gc?.();
  }
  return data;
}
export function assertResearchUnchanged(data, index) {
  assert.deepEqual(Object.keys(data).sort(), Object.keys(index.research).sort());
  for (const [key, value] of Object.entries(data)) {
    assert.deepEqual(digestRows(Array.isArray(value) ? value : [value]), expectedDigest(index.research[key]), 'Complete Research field unchanged: ' + key);
    global.gc?.();
  }
}

/** Same bounded source scope as the accepted registration inventory. Never scans QA, node_modules, .next, or /tmp. */
export function sourceNames(repo) {
  const result = new Set(), excluded = new Set(['public/index.html', 'public/index-b.html']);
  function walk(relative) {
    for (const entry of fs.readdirSync(path.join(repo, relative), { withFileTypes: true })) {
      const name = relative + '/' + entry.name;
      assert(!entry.isSymbolicLink(), 'No source-tree symlink: ' + name);
      if (entry.isDirectory()) walk(name);
      else if (entry.isFile() && !excluded.has(name)) result.add(name);
    }
  }
  for (const directory of ['src', 'scripts', 'tests', 'data', 'media', 'public']) walk(directory);
  for (const entry of fs.readdirSync(repo, { withFileTypes: true })) {
    if (entry.isFile() && ['.ts', '.js', '.mjs', '.json', '.yaml', '.yml'].includes(path.extname(entry.name)) && entry.name !== 'SOURCE-FILE-MANIFEST.json') result.add(entry.name);
  }
  return [...result].sort();
}
export function captureSourceInventory(anchors) {
  return { scope: 'Same source/data/media/public and root code/json/yaml scope as approved registration inventory', files: sourceNames(anchors.repo).map(file => {
    const row = pin(anchors, { anchor: 'repo', file }); return { file, bytes: row.bytes, sha256: row.sha256 };
  }) };
}
export function inventoryChanges(before, after) {
  const a = new Map(before.files.map(row => [row.file, row])), b = new Map(after.files.map(row => [row.file, row]));
  assert.equal(a.size, before.files.length); assert.equal(b.size, after.files.length);
  return [...new Set([...a.keys(), ...b.keys()])].sort().filter(file => a.get(file)?.sha256 !== b.get(file)?.sha256 || a.get(file)?.bytes !== b.get(file)?.bytes)
    .map(file => ({ file, beforeSha256: a.get(file)?.sha256 ?? null, afterSha256: b.get(file)?.sha256 ?? null }));
}
export function newDirectory(root, relative) {
  assert.equal(fs.realpathSync(root), root);
  assert(relative && !path.isAbsolute(relative) && !relative.includes('\\'));
  assert(relative.split('/').every(part => part && part !== '.' && part !== '..'));
  const file = path.resolve(root, relative); assert(within(root, file));
  let current = root;
  for (const part of relative.split('/').slice(0, -1)) {
    current = path.join(current, part);
    if (!fs.existsSync(current)) fs.mkdirSync(current);
    assert.equal(fs.realpathSync(current), current); assert(fs.statSync(current).isDirectory());
  }
  fs.mkdirSync(file); // Exclusive. Interrupted outputs are retained, never reused or overwritten.
  return file;
}
export function writeNewJson(directory, name, value) {
  assert.equal(path.basename(name), name); assert.equal(fs.realpathSync(directory), directory);
  const file = path.join(directory, name);
  fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
  return { path: file, bytes: fs.statSync(file).size, sha256: fileHash(file) };
}

/** All effective cars verified in exact accepted order, only selected cars retained. */
export async function selectVerifiedCars(anchors, index, expected) {
  assert.equal(index.cars.mode, 'baseline-with-complete-replacements-and-appended-identities');
  assert.equal(index.cars.rows, expected.cars); assert.equal(index.cars.baseline.rows, expected.baselineCars);
  assert.equal(index.cars.replacements.rows, expected.replacementCars); assert.equal(index.cars.replacements.format, 'json');
  const hashes = index.cars.carHashes, ids = hashes.map(row => row.id);
  assert.equal(hashes.length, expected.cars); assert.equal(new Set(ids).size, expected.cars);
  assert.equal(index.cars.newIds.length, expected.appendedCars); assert.equal(new Set(index.cars.newIds).size, expected.appendedCars);
  assert.deepEqual(ids.slice(expected.baselineCars), index.cars.newIds);
  const replacements = readJson(locate(anchors, index.cars.replacements));
  assert.equal(replacements.length, expected.replacementCars);
  const replacementMap = new Map(replacements.map(car => [car.id, car])); assert.equal(replacementMap.size, replacements.length);
  assert.deepEqual(replacements.map(car => car.id), hashes.filter(row => row.brand === 'Subaru').map(row => row.id));
  const consumed = new Set(), selected = [], completeCarDigests = [];
  function accept(car, row) {
    assert.equal(car.id, row.id); assert.equal(car.brand, row.brand);
    const digest = digestRows([car]); assert.equal(digest.sha256, row.afterSha256); assert.equal(digest.bytes, row.bytes);
    completeCarDigests.push({ id: car.id, brand: car.brand, ...digest });
    if (car.brand === expected.brand && (!car.vehicleClass || ['passenger', 'ute'].includes(car.vehicleClass))) selected.push(car);
  }
  await streamRows(anchors, index.cars.baseline, (original, ordinal) => {
    const row = hashes[ordinal]; assert(row); assert.equal(original.id, row.id); assert.equal(original.brand, row.brand);
    assert.equal(digestRows([original]).sha256, row.beforeSha256, 'Every original full car verified: ' + original.id);
    const replacement = replacementMap.get(original.id); if (replacement) consumed.add(original.id);
    accept(replacement ?? original, row); if (ordinal % 25 === 0) global.gc?.();
  });
  for (const [offset, id] of index.cars.newIds.entries()) {
    const row = hashes[expected.baselineCars + offset], car = replacementMap.get(id);
    assert(car); assert.equal(row.beforeSha256, null); assert(!consumed.has(id)); consumed.add(id); accept(car, row);
  }
  assert.equal(consumed.size, replacementMap.size, 'Every complete replacement consumed exactly once');
  assert.deepEqual(completeCarDigests.map(row => row.id), ids);
  assert.deepEqual(selected.map(car => car.id), expected.selectedIds);
  return { selected, completeCarDigests };
}
