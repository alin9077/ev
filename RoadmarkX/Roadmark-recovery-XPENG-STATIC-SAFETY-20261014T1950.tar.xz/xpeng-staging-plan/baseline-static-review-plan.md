# XPENG baseline extraction: static review and later execution contract

## Present state and limits

Prepared only. None of these scripts has been executed, syntax-checked, imported, or tested. No current source inventory has been captured by this harness. No catalogue hydration, full scan, candidate, canonical new-version fixture, source edit, registry edit, metadata repair, or production build has been performed. Root owns the serialized heavy slot and must separately authorize any later execution.

The baseline is the explicitly approved, accepted **derived** 399-car storage lineage after Subaru. Independent fresh normal registered coverage output matched the complete staged report, without filtering or normalization. That does not establish fresh full-value loader equality or a completed TypeScript/build/release gate. Historical receipt flags, source pins, and before expectations remain untouched.

## Files to review

1. `baseline-contract.json`: immutable approved anchor paths and six baseline/provenance hashes, full 399/397/11/2 reconstruction expectations, all 14 Research field names, the five existing XPENG IDs, and 18 current registered packets
2. `baseline-io.mjs`: generic bounded, symlink-rejecting input resolution; exclusive output IO; canonical JSONL stream verification; complete Research reads/digests; full-car reconstruction/verification; bounded source inventory policy
3. `prepare-baseline-manifest.mjs`: later authorized read-only pin generation, with explicit contract/hash, versioned manifest destination, and versioned extraction destination
4. `extract-xpeng-baseline.mjs`: manifest-selected extraction only after an independent review attestation bound to the exact manifest and script hashes
5. This static plan

No old `openSubaruStageInputs`, `openConsumerPhaseInputs`, source loader, compiled-source helper, candidate registry shim, or mutable derived cache is imported. The old 17-packet proof is dated provenance only.

## Independent static review checklist

- Check the six approved contract hashes against root's approval. Preserve the distinction between staged-derived values and fresh registered report parity
- Check that every path is selected by the immutable contract/manifest and contained in its exact named anchor. No `..`, absolute-relative bypass, symlink redirection, broad `/tmp` discovery, or guessed fallback is allowed
- All direct full-value paths from the accepted storage index and core receipt must be pinned, including original 397-car storage, complete 11-car replacement file, all 14 Research files, original canonical Subaru fixture files, and full accepted feature storage. Original artifacts are never rewritten
- The prior registered manifest, prior source inventory, final source inventory, retained pre-registration bytes, registration transition, and later test-only transition remain separate artifacts. New current pins must not replace old expected hashes
- The source inventory scope exactly follows the existing accepted bounded policy: `src`, `scripts`, `tests`, `data`, `media`, `public` except two generated public indexes, plus root code/JSON/YAML, excluding the generated root source manifest. No `node_modules`, `.next`, QA, or `/tmp` full scan
- Any difference after the accepted final source inventory must be independently explained. This harness allows only test-file deltas. Existing changed/deleted test files require immutable retained-before bytes with the historical hash. Any production/data delta stops extraction and needs a separately approved baseline review
- Pin all current 18 registered packet files and the registry file in exact order. Verify real production imports equal those complete packet values, the final packet is the approved Subaru packet, and XPENG is absent
- Verify every one of the 397 input cars against its accepted prior hash and every effective car against the accepted 399-car after hash, bytes, identity, brand, and exact order. Require each complete Subaru replacement to be consumed exactly once, and require precisely the accepted two appended IDs
- Read and digest every row of every one of the 14 Research fields. Require exact record counts, standard serialized bytes, SHA256, complete field set, exact 399-variant order, and actual registry metadata. No hand repair is permitted
- Extract exactly the five accepted current XPENG IDs. Use unchanged production `createEvidenceConsumers` with explicit `{data, cars}` and throwing `sourceResearch`, `research`, and `catalogue` defaults. Every actual `pack` result must contain 69 unique correctly scoped criteria and match its complete accepted per-car feature hash and byte count
- Use unchanged production `brandVersionSnapshot` for identity guards; retain complete original facts from actual returned packs, complete actual features, complete cars/packs, original variants/models/context/features, and all original source rows
- Recheck all selected objects, all 14 Research fields, current registry objects, all source/fixture pins, exact source-file membership, review hash, and manifest hash after actual function calls and after output serialization
- Preserve exclusive outputs and interrupted attempts. No completed output or expectation is overwritten. Write the pass receipt last; artifact presence alone is not success
- The original canonical **new-version** XPENG baseline is a different future phase. This extractor cannot create it, compose metadata, create a candidate, register a packet, or change old before expectations

## Later pinning procedure (not authorized or run here)

1. Root confirms the heavy slot is free and authorizes this bounded pinning phase after static review
2. Read and externally record the contract SHA256. Execute the preparation script from the repository in a fresh process with explicit arguments. Example argument shapes only:

   `node /tmp/xpeng-staging-plan/prepare-baseline-manifest.mjs --contract /tmp/xpeng-staging-plan/baseline-contract.json --contract-sha256 <reviewed-contract-sha256> --manifest-directory manifests/baseline-v1 --extraction-directory extractions/baseline-v1`

3. The preparation script checks approved storage/provenance inputs, captures the current source inventory, records any observed test-only delta, pins every referenced full-value fixture, current registered packet and reviewed harness file, then rechecks source bytes. It creates only exclusive new pinning artifacts; it does not load production modules
4. Independently review the resulting manifest and observed transition. Record retained-before refs and reasons for any test-only deltas. Confirm no other source change. Do not infer that newly captured hashes are correct just because capture succeeded
5. Write a separately pinned independent-review JSON file inside the `xpeng` anchor. Required fields:

   - `status`: `approved_for_read_only_xpeng_baseline_extraction`
   - `manifestSha256`: exact manifest file SHA256
   - `contractSha256`: exact contract SHA256 in the manifest
   - `harnessPins`: the complete exact ordered manifest harness-pin array
   - `noProductionSemanticChanges`: `true`
   - `canonicalCaptureAuthorized`: `false`
   - `sourceChanges`: exact observed changes in order, each with `file`, `beforeSha256`, `afterSha256`, a nonempty `reason`, and `retainedBefore` containing a pinned `{anchor,file,sha256,bytes}` locator or `null` only for a genuinely new file

   With no new source differences, `sourceChanges` is an empty array. Do not invent an approval before review.

## Later extraction procedure (not authorized or run here)

1. Root authorizes one serialized measured extraction after the manifest review. Use a fresh process, the repository working directory, the installed `tsx` hook, `--expose-gc`, and root's approved resource ceiling
2. Provide exact immutable manifest and review paths/hashes. Example argument shapes only:

   `node --expose-gc --import tsx /tmp/xpeng-staging-plan/extract-xpeng-baseline.mjs --manifest /tmp/xpeng-staging-plan/manifests/baseline-v1/baseline-manifest.json --manifest-sha256 <reviewed-manifest-sha256> --review /tmp/xpeng-staging-plan/reviews/baseline-v1.json --review-sha256 <review-sha256>`

3. Keep stdout, stderr, command, terminal exit/signal, elapsed time and peak RSS in a separate exclusive measured-run folder. A terminal failure or interruption remains a failure. Do not rewrite or recycle that attempt
4. A successful receipt verifies only read-only derived baseline extraction. Review the complete artifacts before candidate preparation. It is not a candidate approval, canonical capture, fresh full-value export, full test pass, or release claim
5. A path-only retry requires a new immutable manifest and independent review because output paths are already pinned. Reuse the unchanged scripts; do not clone them with different global paths or relax an expectation

## Outputs of a successful later extraction

All output names are beneath the manifest-selected exclusive extraction directory:

- `selected-complete-before-cars.json`
- `actual-before-packs.json`
- `actual-before-features.json`
- `actual-before-facts.json`
- `actual-before-version-guards.json`
- `unchanged-original-research-context.json`
- `complete-399-car-verification.json`
- `baseline-extraction-receipt.json`, written last

No output has been produced by this preparation task. No reusable canonical XPENG new-version feature fixture is among these outputs.
