# Config inventory v2 and partition feasibility limits

Status: review-only, entirely unexecuted. No syntax check, config parse, compiler Program, graph, typecheck, application change or compiler-option change has run. Root must assign the slot after independent static approval. The original full standard TypeScript command remains unverified.

## Scope reduction and preserved lineage

The parent folder's audit.mjs, PLAN.md and proposal-manifest.json are preserved byte-for-byte as rejected v1. Their graph/shape implementation must not run. Independent review found five blockers: copied CompilerHost instrumentation missed closed-over reads; undefined serialization did not round-trip; explicitly rooting imported declarations could change classification/reprocessing/order; missing-reference/checker-free diagnostic coverage was incomplete; terminal input identity and physical output-boundary checks were incomplete.

Root approved replacing that unproven framework with this small **config-only** proposal. The v2 script has no createProgram, createCompilerHost, getTypeChecker, source diagnostic checking, partition construction, synthetic root, resolver override, graph-only JSON stub, incremental state or emit path. Removing those unsupported modes is deliberate, not evidence that their blockers have been solved by execution.

## What one bounded config-only run would establish

- Use the installed TypeScript5.9.3 getParsedCommandLineOfConfigFile API on the original tsconfig, original working directory and original options. Retain original checked-root order, configFilePath, option values, project references and all config parsing diagnostics. Read the non-enumerable options.configFile explicitly; include its parseDiagnostics as well as parsed.errors and unrecoverable diagnostics, without dropping duplicates. The configFile AST is represented by its filename/text hash, never passed through a generated config or used to build a partition.
- Record total/test/non-test root counts and whether the existing .next/types/validator.ts is included. Counts are scheduling context, not a compiler closure or a claim of semantic independence. A source file's ambient declarations and imported JSON inference cannot be inferred from its root name.
- Wrap the parse-host object in place. Record actual config reads, negative file/directory observations, directory enumerations and realpath results without changing resolver results. No CompilerHost exists in v2, so there is no getSourceFile closure to accidentally bypass instrumentation.
- Hash physical config bytes before/after each successful config read. Retain text hashes, physical paths, inode/device/size/mode/timestamps, compiler/API/CLI/package bytes and script bytes. Recheck all execution/config pins and recorded filesystem observations at termination, then re-pin after replay. These pins cover consumed configuration/tool inputs, not unparsed source bytes or the full semantic environment.
- Resolve the existing output parent physically before mkdir, reject both lexical and physical output locations inside the checkout, require a fresh output directory, and verify its physical identity before each artifact write. Compiler host write/create/delete functions throw. Artifacts stay outside source.
- Artifacts use a reversible canonical wire envelope; undefined and arbitrary reserved-shaped plugin option objects are preserved by escaping. Every write checks its own serialization round trip. This is a static design until reviewed/executed.

Outputs: config-inventory.json, execution-inputs.json, config-inputs.json, io-observations.json and terminal.json. Each has wireFormat=config-inventory-v2 and a payload. A normal result is CONFIG_INVENTORY_COMPLETE, never a typecheck pass. Config errors, drift and thrown errors fail the run. An external measured wrapper must preserve exit/signal/RSS; abrupt termination can prevent terminal.json, which is an incomplete attempt rather than an approval to retry automatically.

Use the established inspected Python resource.wait4 measurement wrapper for exit/signal/child maxRSS; /usr/bin/time is absent in this environment. The script's own resourceUsage receipt is additional evidence only when it reaches termination. Review and pin the wrapper/command before execution.

Example for root's later authorization, not executed:

```sh
node --max-old-space-size=<root-approved bound> --max-semi-space-size=1 config-inventory.mjs \
  --authorize-config-inventory \
  --project /workspace/scratch/586427eef9f2/roadmark-104/tsconfig.json \
  --out /workspace/scratch/586427eef9f2/roadmark-104-qa/ts-config-inventory-UNIQUE
```

No heap limit is claimed sufficient. One bounded run and its terminal evidence are the proposed next diagnostic, subject to reviewer/root approval. No production files or tsconfig options change.

## Unimplemented graph/partition feasibility plan

Only consider additional work if config inventory makes a useful reduction plausible. All steps below remain unimplemented, require new review, and are not authorized by the config-only switch.

1. Discover the **actual complete compiler graph** using the same installed compiler/options/root order and real source/JSON bytes. Instrument the actual CompilerHost object in place before Program construction. Pin all consumed source/declaration/package/compiler bytes and negative resolution observations before/after. Keep original configFilePath, libraries, strict/skipLibCheck behavior, module resolution, paths and generated Next roots unchanged.
2. Inventory every actual transitive module/type/triple-slash/library/automatic-type edge, missing root/reference and failed resolution. Collect checker-free configuration/options/syntactic/file-processing diagnostics, including missing triple-slash paths/libs and automatic types. The exact installed APIs and any internal diagnostics container must be independently reviewed; no partial graph or incomplete diagnostics collection may establish a planning gate.
3. Identify every nonmodule script, declaration file, JavaScript file, global/module augmentation and UMD declaration with compiler AST/API data. Known contributors include react-dom's React augmentation and global/UMD declarations, esbuild's global WebAssembly/URL declarations, and Next's generated ambient/global helpers. Never assume all external-module tests are isolated merely from their top-level imports. Preserve Next validator as a genuine checked source root.
4. Find **existing original roots that naturally reach the full shared ambient/declaration closure**, plus the original config-driven implicit library/type roots. Do not directly add imported .d.ts dependencies as new roots: that can change external-library classification, reprocessing and order, violating the structural gate. In installed TypeScript, skipLibCheck is gated on isDeclarationFile independently of external-library classification; no skipLibCheck toggle is asserted. Preserve original root-relative order. Any root-selection heuristic is only a scheduling proposal; require exact actual closure, identity, file order, classification, package/mode resolution, ambient merge order and common-source-directory comparison before considering semantic checking.
5. Stop if those required existing roots pull almost the full original graph or force large fixture inputs into every candidate. A negative feasibility result is useful; do not build a new synthetic-root/rewritten-declaration framework to hide it. The 8,236,430-byte kia-cadillac-staged-delta.json fixture can have its own candidate only if real reachability permits. It must retain every byte and the compiler's full inferred type.
6. If meaningful independence is actually demonstrated, a later separately reviewed checker would need every original root covered, all global contributors co-checked, every applicable diagnostic category retained and original semantic options intact. Preserve incremental=true only with distinct fresh external state per process, no reused/stale original build info. Keep serial execution and input immutability across the whole series. This checker is not implemented.

Even a future clean partition union would not be an observed full standard tsc pass. Separate Programs may differ in lazy checking, order effects, resource-limit diagnostics and project-wide behavior; the installed CLI also short-circuits some diagnostics differently from API collectors. Installed Next16.3.8's useTypeScriptCli guide specifies the full project-local CLI default, including tests/generated types selected by tsconfig. No replacement release gate, ignoreBuildErrors, alternate tsconfig, weaker flags, skipped roots, casts or inferred-fixture rewrites are proposed.

The optional graph-only JSON substitute remains unimplemented. It could never be used for semantic diagnostics; globally stubbing readFile would also corrupt package/config resolution. Do not pursue it without a separate justified domain and independent review.
