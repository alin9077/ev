/** REVIEW ONLY. Config inventory, never a Program, checker, graph, partition or emit. */
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const argv = process.argv.slice(2);
const permitted = new Set(['--authorize-config-inventory', '--project', '--out']);
const args = new Map();
for (let i = 0; i < argv.length; i++) {
  const name = argv[i];
  if (!permitted.has(name) || args.has(name)) throw new Error(`Unknown/duplicate argument: ${name}`);
  if (name === '--authorize-config-inventory') args.set(name, true);
  else {
    const value = argv[++i];
    if (!value || value.startsWith('--')) throw new Error(`Missing value: ${name}`);
    args.set(name, value);
  }
}
if (!args.get('--authorize-config-inventory')) throw new Error('Separate root approval and --authorize-config-inventory are required');
if (!args.has('--project') || !args.has('--out')) throw new Error('Explicit --project and new external --out are required');
const project = path.resolve(args.get('--project'));
const root = path.dirname(project);
const realRoot = fs.realpathSync(root);
const out = path.resolve(args.get('--out'));
const outParent = path.dirname(out);
const realOutParent = fs.realpathSync(outParent); // Parent must already exist; resolve symlinks before any write.
const realOut = path.join(realOutParent, path.basename(out));
const within = (child, parent) => child === parent || child.startsWith(parent + path.sep);
if (within(out, root) || within(realOut, realRoot)) throw new Error('Output must be physically outside the checkout');
fs.mkdirSync(out); // No reuse, recursive creation, or overwrite of an earlier/partial run.
const outputIdentity = { realPath: fs.realpathSync(out), dev: fs.statSync(out).dev, ino: fs.statSync(out).ino };
function assertOutputIdentity() {
  const stat = fs.statSync(out);
  if (fs.realpathSync(outParent) !== realOutParent || fs.realpathSync(out) !== realOut ||
      stat.dev !== outputIdentity.dev || stat.ino !== outputIdentity.ino || !stat.isDirectory()) {
    throw new Error('Output parent/directory physical identity changed');
  }
}
process.chdir(root);
const sha256 = (value) => createHash('sha256').update(value).digest('hex');
const identity = (stat) => ({ dev: stat.dev, ino: stat.ino, size: stat.size, mode: stat.mode, mtimeMs: stat.mtimeMs, ctimeMs: stat.ctimeMs });
function physicalFile(file) {
  const realPath = fs.realpathSync(file), link = identity(fs.lstatSync(file));
  const fd = fs.openSync(file, 'r'), digest = createHash('sha256'), buffer = Buffer.allocUnsafe(65536);
  let before, after, bytes = 0;
  try {
    before = identity(fs.fstatSync(fd));
    let count;
    while ((count = fs.readSync(fd, buffer, 0, buffer.length, null))) {
      digest.update(buffer.subarray(0, count)); bytes += count;
    }
    after = identity(fs.fstatSync(fd));
  } finally { fs.closeSync(fd); }
  if (JSON.stringify(before) !== JSON.stringify(after) || fs.realpathSync(file) !== realPath ||
      JSON.stringify(identity(fs.lstatSync(file))) !== JSON.stringify(link)) throw new Error(`Input changed while hashing: ${file}`);
  return { realPath, link, target: after, bytes, sha256: digest.digest('hex') };
}
// A reversible canonical wire format. Reserved-shaped user objects are escaped, so
// explicit undefined, absent properties, arrays and arbitrary plugin-option keys stay distinct.
const U = '$auditUndefined', E = '$auditEscapedObject';
function encode(value) {
  if (value === undefined) return { [U]: true };
  if (value === null || ['string', 'boolean'].includes(typeof value)) return value;
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (Array.isArray(value)) return value.map(encode);
  if (!value || typeof value !== 'object') throw new Error(`Unsupported artifact value: ${typeof value}`);
  const entries = Object.keys(value).sort().map((key) => [key, encode(value[key])]);
  return Object.hasOwn(value, U) || Object.hasOwn(value, E) ? { [E]: entries } : Object.fromEntries(entries);
}
function decode(value) {
  if (Array.isArray(value)) return value.map(decode);
  if (!value || typeof value !== 'object') return value;
  if (Object.hasOwn(value, U)) return undefined;
  if (Object.hasOwn(value, E)) return Object.fromEntries(value[E].map(([key, part]) => [key, decode(part)]));
  return Object.fromEntries(Object.entries(value).map(([key, part]) => [key, decode(part)]));
}
const canonical = (value) => JSON.stringify(encode(value));
const equal = (a, b) => canonical(a) === canonical(b);
function write(name, value) {
  assertOutputIdentity();
  const wire = JSON.stringify({ wireFormat: 'config-inventory-v2', payload: encode(value) }, null, 2) + '\n';
  if (!equal(decode(JSON.parse(wire).payload), value)) throw new Error('Artifact failed canonical round trip');
  fs.writeFileSync(path.join(out, name), wire, { flag: 'wx' });
}
const startedAt = new Date().toISOString();
const executionInputs = new Map(), configInputs = new Map(), observations = new Map();
let ts, inventory, failure, inventoryWritten = false;
function observe(method, callArgs, value) {
  const summary = method === 'readFile' && typeof value === 'string'
    ? { textSha256: sha256(value), utf8Bytes: Buffer.byteLength(value) } : value;
  const key = canonical([method, callArgs]), prior = observations.get(key);
  if (prior && !equal(prior.result, summary)) throw new Error(`Config input changed: ${method} ${callArgs[0]}`);
  if (!prior) observations.set(key, { method, args: callArgs, result: summary });
  return value;
}
function diagnostic(d) {
  return { code: d.code, category: d.category, file: d.file?.fileName, start: d.start, length: d.length,
    message: ts.flattenDiagnosticMessageText(d.messageText, '\n'), relatedInformation: d.relatedInformation?.map(diagnostic) };
}
function checkPins(pins) {
  const differences = [];
  for (const [file, expected] of pins) {
    let actual;
    try { actual = physicalFile(file); } catch (error) { actual = { error: error.message }; }
    if (!equal(actual, expected)) differences.push({ file, expected, actual });
  }
  return differences;
}
try {
  const require = createRequire(path.join(root, 'package.json'));
  const compilerPath = require.resolve('typescript');
  for (const file of [fileURLToPath(import.meta.url), compilerPath,
    path.join(path.dirname(compilerPath), '_tsc.js'), require.resolve('typescript/package.json'), path.join(root, 'package.json')]) {
    executionInputs.set(file, physicalFile(file));
  }
  ts = require('typescript');
  if (ts.version !== '5.9.3') throw new Error(`Unreviewed installed compiler version: ${ts.version}`);
  const unrecoverable = [];
  const host = { ...ts.sys, onUnRecoverableConfigFileDiagnostic: (d) => unrecoverable.push(d) };
  // Instrument the host object IN PLACE. No CompilerHost is created in this version.
  for (const method of ['readFile', 'fileExists', 'directoryExists', 'getDirectories', 'readDirectory', 'realpath']) {
    if (typeof host[method] !== 'function') continue;
    const original = host[method];
    host[method] = (...callArgs) => {
      let before;
      const file = method === 'readFile' ? path.resolve(callArgs[0]) : undefined;
      if (file && fs.existsSync(file)) before = physicalFile(file);
      const value = original.apply(host, callArgs);
      if (typeof value === 'string' && file) {
        const after = physicalFile(file);
        if (!before || !equal(before, after)) throw new Error(`Config bytes changed across readFile: ${file}`);
        if (configInputs.has(file) && !equal(configInputs.get(file), after)) throw new Error(`Config physical identity changed: ${file}`);
        configInputs.set(file, after);
      }
      return observe(method, callArgs, value);
    };
  }
  host.writeFile = host.createDirectory = host.deleteFile = () => { throw new Error('Compiler writes are forbidden'); };
  const parsed = ts.getParsedCommandLineOfConfigFile(project, undefined, host);
  const configDiagnostics = [...unrecoverable, ...(parsed?.errors ?? [])].map(diagnostic);
  const options = parsed && Object.fromEntries(Object.entries(parsed.options).map(([key, value]) => [key,
    key === 'configFile' ? { fileName: value?.fileName, textSha256: value ? sha256(value.text) : undefined } : value]));
  if (parsed && path.resolve(parsed.options.configFilePath) !== project) throw new Error('Original configFilePath changed');
  const roots = parsed?.fileNames ?? [];
  const testPrefix = path.join(root, 'tests') + path.sep;
  const validator = path.join(root, '.next', 'types', 'validator.ts');
  inventory = {
    project, root, realRoot, actualCurrentDirectory: process.cwd(), compilerVersion: ts.version, compilerPath,
    nodeVersion: process.version, nodeExecPath: process.execPath, execArgv: process.execArgv, nodeOptions: process.env.NODE_OPTIONS,
    originalRootNames: roots, originalOptions: options, projectReferences: parsed?.projectReferences ?? [], configDiagnostics,
    rootCounts: { total: roots.length, test: roots.filter((file) => file.startsWith(testPrefix)).length,
      nonTest: roots.filter((file) => !file.startsWith(testPrefix)).length },
    nextValidatorIncluded: roots.includes(validator),
    originalConfigFileAstNotSerialized: true,
    noProgramCreated: true, noCheckerInvoked: true, noGraphDiscovered: true, noPartitionsCreated: true,
    noIncrementalStateReadOrWritten: true, noEmitInvoked: true, standardTscPassed: false,
    note: 'Root counts are scheduling context only. This does not inspect source syntax, transitive imports, ambient effects, types, or diagnostics beyond config parsing.',
  };
  write('config-inventory.json', inventory);
  inventoryWritten = true;
  if (!parsed || configDiagnostics.length) failure = 'Original config parsing reported diagnostics';
} catch (error) {
  failure = { message: error.message, stack: error.stack };
} finally {
  const differences = [...checkPins(executionInputs), ...checkPins(configInputs)];
  if (ts) for (const record of observations.values()) {
    let actual;
    try {
      const value = ts.sys[record.method](...record.args);
      actual = record.method === 'readFile' && typeof value === 'string'
        ? { textSha256: sha256(value), utf8Bytes: Buffer.byteLength(value) } : value;
    } catch (error) { actual = { error: error.message }; }
    if (!equal(actual, record.result)) differences.push({ observation: record, actual });
  }
  // Re-pin again after replaying reads so terminal attestation follows the last input observation.
  differences.push(...checkPins(executionInputs), ...checkPins(configInputs));
  write('execution-inputs.json', [...executionInputs]);
  write('config-inputs.json', [...configInputs]);
  write('io-observations.json', [...observations.values()]);
  const terminal = { status: failure ? 'FAILED' : differences.length ? 'INPUT_DRIFT' : 'CONFIG_INVENTORY_COMPLETE',
    startedAt, finishedAt: new Date().toISOString(), failure, differences, outputIdentity,
    noProgramCreated: true, noTypecheckRun: true, standardTscPassed: false,
    configInventoryWritten: inventoryWritten, memory: process.memoryUsage(), resourceUsage: process.resourceUsage() };
  write('terminal.json', terminal);
  console.log(JSON.stringify({ status: terminal.status, noProgramCreated: true, standardTscPassed: false }));
  if (failure || differences.length) process.exitCode = 1;
}
