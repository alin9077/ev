# Final feasibility recommendation

**Stop partition exploration here. Meaningful, semantically safe partitioning has not been established. Keep the full standard TypeScript gate open.**

The approved config-only v2 run completed on 2026-10-14 at19:37UTC: exit0, 0.455seconds, 80,904KiB timeout-wrapper/reaped-descendant peakRSS; Node's own terminal reports80,776KiB. It found355 original roots (193 non-test,162 test), including the generated Next validator, with zero config diagnostics and zero input drift. All six wrapper/proposal input pins stayed unchanged. This establishes the original configuration inventory only. No compiler Program, dependency graph, semantic check or partition was constructed.

Root counts make a source/scripts versus test split look administratively possible, but do not establish compiler independence or a useful reduction. Known imported declaration/global/augmentation effects include react-dom, esbuild and generated Next types. Their complete original-root reachability, ambient merge order, source classification and diagnostic interactions remain unmeasured. The8,236,430-byte inferred JSON fixture must remain fully typed; assigning its importing test to a separate group does not itself prove safe separation or bounded completion.

The rejected v1 graph/shape implementation remains preserved at the parent level. It must not execute. Review found missed closed-over CompilerHost reads, a serialization round-trip defect, explicit dependency-root classification/order changes, incomplete missing-reference/checker-free diagnostic gates, and incomplete terminal/physical-boundary attestation. Do not claim that external-library classification alone toggles skipLibCheck: installed TypeScript gates that flag on isDeclarationFile.

The reduced v2 removes graph/shape execution entirely. Its first review version, amendments, frozen approved script/plan/manifest and the bounded run are preserved. The unimplemented feasibility plan requires shared ambient contributors to remain reachable through original roots, without directly rooting imported declarations. If that forces nearly the full original graph, partitioning offers no justified route. No further framework or compiler execution is recommended on the current evidence.

## Retained receipts

- Approved v2 script SHA256:d900664e8ac7442c777ed371a54cdd1be9ea713995858c0327011f15ab555331
- Approved v2 plan SHA256:58d0235d3765ae65d188e8edd84d848c57d5def9a8b49f44bdca3cd72e3ae494
- Approved v2 manifest SHA256:2662e17e9065297f7f418dae7249a9e08f5eca05e1deeb758fef4601f7dd2434
- Run directory:../ts-config-inventory-v2-20261014T1936/
- Exact command/starting pins:run-inputs-before.json
- Ending wrapper/proposal pins and summary:run-inputs-after.json
- Exit/signal/RSS/elapsed:config-only-measurement.json and config-only.exit
- Raw combined stdout/stderr:config-only.log
- Config options/root order:inventory/config-inventory.json
- Terminal config/tool/input attestation:inventory/terminal.json, execution-inputs.json, config-inputs.json and io-observations.json

The measurement wrapper uses os.wait4. The outer status belongs to GNU timeout, with60seconds followed by a5-second TERM grace; this successful run did not time out. The wrapper is copied into the new run directory with only its output constant and exclusive-file-creation changes. Historical capture directories were not written. No application, fixture, data or tsconfig edits were made by this audit work. No retry occurred. The heavy slot was released to root immediately after completion.
