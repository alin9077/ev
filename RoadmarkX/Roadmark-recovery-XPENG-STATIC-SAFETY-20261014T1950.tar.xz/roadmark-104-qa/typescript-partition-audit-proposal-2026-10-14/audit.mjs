/** REVIEW ONLY until separately authorized. No semantic check or emit is implemented here.
 * Modes: config (parse original config), graph (original full Program, no checker),
 * shape (one candidate Program, compare to graph). Run each in a fresh measured process.
 */
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const argv = process.argv.slice(2);
function argument(name, fallback) {
  const index = argv.indexOf(name);
  return index < 0 ? fallback : argv[index + 1];
}
if (!argv.includes('--authorize-compiler-audit')) {
  throw new Error('Not executed: requires separate root approval and --authorize-compiler-audit');
}
const mode = argument('--mode');
if (!['config', 'graph', 'shape'].includes(mode)) throw new Error('Mode must be config, graph, or shape');
const project = path.resolve(argument('--project', 'tsconfig.json'));
const root = path.dirname(project);
const outArg = argument('--out');
if (!outArg) throw new Error('A new external --out directory is required');
const out = path.resolve(outArg);
if (out === root || out.startsWith(root + path.sep)) throw new Error('Output must be outside the source checkout');
fs.mkdirSync(out, { recursive: false }); // Never merge a partial or earlier run.
process.chdir(root);
const require = createRequire(path.join(root, 'package.json'));
const compilerPath = require.resolve('typescript');
const ts = require('typescript');
if (ts.version !== '5.9.3') throw new Error(`Unreviewed compiler internals: ${ts.version}`);
const hash = (value) => createHash('sha256').update(value).digest('hex');
function physicalFile(file) {
  const digest = createHash('sha256'), buffer = Buffer.allocUnsafe(64 * 1024);
  const fd = fs.openSync(file, 'r');
  let bytes = 0;
  try {
    let count;
    while ((count = fs.readSync(fd, buffer, 0, buffer.length, null)) !== 0) {
      digest.update(buffer.subarray(0, count)); bytes += count;
    }
  } finally { fs.closeSync(fd); }
  return { bytes, sha256: digest.digest('hex'), realPath: fs.realpathSync(file) };
}
const canonical = (value) => {
  const name = path.resolve(value).replaceAll('\\', '/');
  return ts.sys.useCaseSensitiveFileNames ? name : name.toLowerCase();
};
const encode = (value) => value === undefined ? { $undefined: true }
  : Array.isArray(value) ? value.map(encode)
  : value && typeof value === 'object' ? Object.fromEntries(Object.entries(value).map(([key, part]) => [key, encode(part)]))
  : value;
const decode = (value) => value && typeof value === 'object' && value.$undefined === true ? undefined
  : Array.isArray(value) ? value.map(decode)
  : value && typeof value === 'object' ? Object.fromEntries(Object.entries(value).map(([key, part]) => [key, decode(part)]))
  : value;
const stringify = (value) => JSON.stringify(encode(value));
const equal = (a, b) => stringify(a) === stringify(b);
function write(name, value) { fs.writeFileSync(path.join(out, name), JSON.stringify(value, null, 2) + '\n'); }
function phase(name) { console.log(JSON.stringify({ phase: name, memory: process.memoryUsage() })); }
const observed = new Map();
const rawInputs = new Map();
function resultSummary(method, value) {
  return method === 'readFile' && typeof value === 'string'
    ? { textSha256: hash(value), utf8Bytes: Buffer.byteLength(value) }
    : encode(value);
}
function observe(method, args, value) {
  if (method === 'readFile' && typeof value === 'string') {
    const file = path.resolve(args[0]);
    if (!rawInputs.has(file)) rawInputs.set(file, physicalFile(file));
  }
  const key = stringify([method, args]);
  const summary = resultSummary(method, value);
  const prior = observed.get(key);
  if (prior && !equal(prior.result, summary)) throw new Error(`Input changed during audit: ${method} ${args[0]}`);
  if (!prior) observed.set(key, { method, args: encode(args), result: summary });
  return value;
}
function tracked(base) {
  const host = { ...base };
  for (const method of ['readFile', 'fileExists', 'directoryExists', 'getDirectories', 'readDirectory', 'realpath']) {
    if (typeof base[method] === 'function') host[method] = (...args) => observe(method, args, base[method](...args));
  }
  host.writeFile = () => { throw new Error('Compiler writes are forbidden in audit modes'); };
  return host;
}
function recheckObservations(records) {
  const differences = [];
  for (const record of records) {
    const fn = ts.sys[record.method];
    if (typeof fn !== 'function') throw new Error(`Cannot replay observation ${record.method}`);
    const actual = resultSummary(record.method, fn(...decode(record.args)));
    if (!equal(actual, record.result)) differences.push({ ...record, actual });
  }
  return differences;
}
function recheckRawInputs(records) {
  const differences = [];
  for (const [file, expected] of records) {
    let actual;
    try { actual = physicalFile(file); } catch (error) { actual = { error: error.message }; }
    if (!equal(actual, expected)) differences.push({ file, expected, actual });
  }
  return differences;
}
function diagnostic(d) {
  return { code: d.code, category: d.category, file: d.file?.fileName,
    start: d.start, length: d.length, message: ts.flattenDiagnosticMessageText(d.messageText, '\n'),
    relatedInformation: d.relatedInformation?.map(diagnostic) };
}
function optionsRecord(options) {
  return Object.fromEntries(Object.keys(options).sort().map((key) => [key,
    key === 'configFile' ? { fileName: options.configFile?.fileName, textSha256: options.configFile ? hash(options.configFile.text) : undefined }
      : encode(options[key]) ]));
}
const parseHost = tracked({ ...ts.sys, onUnRecoverableConfigFileDiagnostic: (d) => { throw new Error(ts.flattenDiagnosticMessageText(d.messageText, '\n')); } });
const parsed = ts.getParsedCommandLineOfConfigFile(project, undefined, parseHost);
if (!parsed) throw new Error('Original config did not parse');
const originalOptions = parsed.options; // Never reparse a generated/extended partition tsconfig.
if (canonical(originalOptions.configFilePath) !== canonical(project)) throw new Error('Original configFilePath was not retained');
const header = {
  mode, project, root, compilerVersion: ts.version, compilerPath,
  compilerSha256: physicalFile(compilerPath).sha256,
  compilerCliSha256: physicalFile(path.join(path.dirname(compilerPath), '_tsc.js')).sha256,
  scriptSha256: hash(fs.readFileSync(fileURLToPath(import.meta.url))),
  nodeVersion: process.version, execArgv: process.execArgv, nodeOptions: process.env.NODE_OPTIONS,
  originalRootNames: parsed.fileNames, originalOptions: optionsRecord(originalOptions),
  projectReferences: parsed.projectReferences ?? [], configDiagnostics: parsed.errors.map(diagnostic),
  checked: false, standardTscPassed: false,
};
write('config.json', header);
phase('config-parsed');
if (parsed.errors.length) throw new Error('Config diagnostics exist; retain config.json and stop');
if (mode === 'config') {
  const io = [...observed.values()];
  const differences = [...recheckObservations(io), ...recheckRawInputs([...rawInputs])];
  write('io-observations.json', io);
  write('raw-inputs.json', [...rawInputs]);
  write('terminal.json', { status: differences.length ? 'INPUT_DRIFT' : 'CONFIG_INVENTORY_COMPLETE', checked: false, differences });
  if (differences.length) process.exitCode = 1;
} else {
  if (originalOptions.noEmit !== true || originalOptions.noCheck === true) throw new Error('Unexpected original noEmit/noCheck contract; do not change flags to continue');
  let baseline;
  let candidate;
  let options = originalOptions;
  let roots = parsed.fileNames;
  if (mode === 'shape') {
    const baselinePath = path.resolve(argument('--baseline', ''));
    baseline = JSON.parse(fs.readFileSync(baselinePath, 'utf8'));
    if (baseline.status !== 'GRAPH_AUDIT_COMPLETE') throw new Error('Baseline graph did not finish cleanly');
    if (!equal(baseline.header.originalRootNames, parsed.fileNames) || !equal(baseline.header.originalOptions, optionsRecord(originalOptions))) throw new Error('Original config/options/root order changed');
    if (baseline.header.compilerSha256 !== header.compilerSha256 || baseline.header.compilerCliSha256 !== header.compilerCliSha256) throw new Error('Compiler bytes changed');
    const stale = [...recheckObservations(baseline.ioObservations), ...recheckRawInputs(baseline.rawInputs)];
    if (stale.length) { write('baseline-drift.json', stale); throw new Error('Baseline inputs/resolution environment changed'); }
    candidate = baseline.plan.partitions.find((part) => part.id === argument('--partition'));
    if (!candidate) throw new Error('Unknown candidate partition');
    if (baseline.plan.blockers.length) throw new Error('Baseline has unresolved structural blockers; review before any shape check');
    roots = candidate.rootNames;
    // Only this metadata destination differs. This mode never writes build state.
    options = { ...originalOptions, tsBuildInfoFile: path.join(out, `${candidate.id}.tsbuildinfo`) };
    const { tsBuildInfoFile: ignoredActual, ...actual } = optionsRecord(options);
    const { tsBuildInfoFile: ignoredOriginal, ...original } = optionsRecord(originalOptions);
    void ignoredActual; void ignoredOriginal;
    if (!equal(actual, original)) throw new Error('Non-build-info compiler option changed');
  }
  const host = tracked(ts.createCompilerHost(options));
  // Preserve resolver behavior: no resolveModuleNames/resolveTypeReferenceDirectives override.
  phase('program-construction-start');
  const program = ts.createProgram({ rootNames: roots, options, host,
    projectReferences: parsed.projectReferences, configFileParsingDiagnostics: parsed.errors });
  phase('program-construction-complete');
  for (const name of ['forEachResolvedModule', 'forEachResolvedTypeReferenceDirective',
    'getAutomaticTypeDirectiveNames', 'getAutomaticTypeDirectiveResolutions', 'getFileIncludeReasons',
    'getSourceFileFromReference', 'getLibFileFromReference', 'getCommonSourceDirectory']) {
    if (typeof program[name] !== 'function') throw new Error(`Required pinned compiler API missing: ${name}`);
  }
  const sourceFiles = program.getSourceFiles();
  const aliases = new Map();
  const aliasCollisions = [];
  const fileId = (sf) => canonical(sf.fileName);
  for (const sf of sourceFiles) {
    for (const name of [sf.fileName, sf.path, sf.resolvedPath, sf.originalFileName].filter(Boolean)) {
      const key = canonical(name), prior = aliases.get(key);
      if (prior && prior !== fileId(sf)) aliasCollisions.push({ alias: key, first: prior, second: fileId(sf) });
      else aliases.set(key, fileId(sf));
    }
  }
  const toId = (name) => {
    if (!name) return undefined;
    const known = aliases.get(canonical(name));
    if (known) return known;
    const sf = program.getSourceFile(name);
    return sf && aliases.get(fileId(sf));
  };
  function ambientSyntax(sf) {
    if (sf.scriptKind === ts.ScriptKind.JSON || (sf.flags & ts.NodeFlags.JsonFile)) return [];
    const findings = [];
    function visit(node) {
      if (ts.isModuleDeclaration(node)) {
        if (node.flags & ts.NodeFlags.GlobalAugmentation) findings.push({ kind: 'global-augmentation', pos: node.pos });
        else if (ts.isStringLiteral(node.name)) findings.push({ kind: 'string-named-module-or-augmentation', name: node.name.text, pos: node.pos });
      }
      if (ts.isNamespaceExportDeclaration(node)) findings.push({ kind: 'umd-namespace-export', name: node.name.text, pos: node.pos });
      ts.forEachChild(node, visit);
    }
    visit(sf);
    return findings;
  }
  const includeReasons = program.getFileIncludeReasons();
  const files = sourceFiles.map((sf, index) => {
    const json = sf.scriptKind === ts.ScriptKind.JSON || !!(sf.flags & ts.NodeFlags.JsonFile);
    const external = ts.isExternalModule(sf), commonJS = !!sf.commonJsModuleIndicator;
    return { id: fileId(sf), fileName: sf.fileName, index, textSha256: hash(sf.text),
      utf8Bytes: Buffer.byteLength(sf.text), isJson: json, isDeclaration: sf.isDeclarationFile,
      isExternalModule: external, isCommonJSModule: commonJS,
      isNonModuleScript: !json && !external && !commonJS,
      isJavaScript: sf.scriptKind === ts.ScriptKind.JS || sf.scriptKind === ts.ScriptKind.JSX,
      isDefaultLibrary: program.isSourceFileDefaultLibrary(sf),
      isExternalLibrary: program.isSourceFileFromExternalLibrary(sf),
      hasNoDefaultLib: !!sf.hasNoDefaultLib, impliedNodeFormat: sf.impliedNodeFormat,
      redirectTarget: sf.redirectInfo?.redirectTarget?.fileName,
      compilerModuleAugmentations: (sf.moduleAugmentations ?? []).map((node) => ({ name: node.text, pos: node.pos })),
      ambientSyntax: ambientSyntax(sf), parseDiagnostics: (sf.parseDiagnostics ?? []).map(diagnostic),
      includeReasons: (includeReasons.get(sf.path) ?? []).map((reason) => Object.fromEntries(Object.entries(reason).filter(([, value]) => value == null || ['string', 'number', 'boolean'].includes(typeof value)))) };
  });
  const edges = [];
  const resolutions = [];
  const unresolvedGraphTargets = [];
  function addEdge(from, targetName, kind, name) {
    const to = toId(targetName);
    if (targetName && !to) unresolvedGraphTargets.push({ from, targetName, kind, name });
    if (from && to) edges.push({ from, to, kind, name });
    return to;
  }
  function resolutionRecord(kind, result, name, resolutionMode, fromName) {
    const from = toId(fromName);
    if (fromName && !from) unresolvedGraphTargets.push({ kind, fromName, name, reason: 'Unrepresented containing source file' });
    const value = kind === 'module' ? result.resolvedModule : result.resolvedTypeReferenceDirective;
    const target = value?.resolvedFileName;
    const to = addEdge(from, target, kind, name);
    resolutions.push({ kind, from, fromName, name, resolutionMode,
      resolved: value ? { ...value } : null, targetId: to,
      failedLookupLocations: result.failedLookupLocations ?? [], affectingLocations: result.affectingLocations ?? [],
      diagnostics: (result.resolutionDiagnostics ?? []).map(diagnostic) });
  }
  program.forEachResolvedModule((result, name, resolutionMode, from) => resolutionRecord('module', result, name, resolutionMode, from));
  program.forEachResolvedTypeReferenceDirective((result, name, resolutionMode, from) => resolutionRecord('type-reference', result, name, resolutionMode, from));
  const automaticTypes = [];
  program.getAutomaticTypeDirectiveResolutions()?.forEach((result, name, resolutionMode) => {
    const target = result.resolvedTypeReferenceDirective?.resolvedFileName;
    automaticTypes.push({ name, resolutionMode, resolved: result.resolvedTypeReferenceDirective ?? null, targetId: toId(target) });
    if (target && !toId(target)) unresolvedGraphTargets.push({ kind: 'automatic-type', name, targetName: target });
  });
  for (const sf of sourceFiles) {
    for (const ref of sf.referencedFiles) {
      const target = program.getSourceFileFromReference(sf, ref);
      addEdge(fileId(sf), target?.fileName, 'triple-slash-path', ref.fileName);
    }
    for (const ref of sf.libReferenceDirectives) {
      const target = program.getLibFileFromReference(ref);
      addEdge(fileId(sf), target?.fileName, 'triple-slash-lib', ref.fileName);
    }
  }
  const adjacency = new Map(files.map((file) => [file.id, []]));
  for (const edge of edges) adjacency.get(edge.from)?.push(edge.to);
  function closure(seeds) {
    const seen = new Set(), queue = [...seeds];
    while (queue.length) {
      const id = queue.pop();
      if (!id || seen.has(id)) continue;
      seen.add(id); queue.push(...(adjacency.get(id) ?? []));
    }
    return seen;
  }
  const rootIds = program.getRootFileNames().map((name) => toId(name));
  const allSharedSeeds = files.filter((file) => file.isDeclaration || file.isNonModuleScript || file.isJavaScript || file.ambientSyntax.length || file.compilerModuleAugmentations.length || file.hasNoDefaultLib).map((file) => file.id);
  allSharedSeeds.push(...automaticTypes.map((item) => item.targetId).filter(Boolean));
  const shared = closure(allSharedSeeds);
  const graph = { files, edges, resolutions, automaticTypeNames: program.getAutomaticTypeDirectiveNames(), automaticTypes,
    rootNames: program.getRootFileNames(), rootIds, commonSourceDirectory: program.getCommonSourceDirectory(),
    sharedSeeds: [...new Set(allSharedSeeds)], sharedClosure: files.filter((file) => shared.has(file.id)).map((file) => file.id),
    aliasCollisions, unresolvedGraphTargets };
  write('graph.json', graph);
  phase('graph-inventory-complete');
  let plan;
  let shape;
  if (mode === 'graph') {
    const blockers = [];
    if (parsed.projectReferences?.length) blockers.push('Project references need separate solution-builder equivalence review');
    for (const key of ['composite', 'outFile', 'out', 'declaration', 'declarationMap', 'emitDeclarationOnly', 'noResolve']) {
      if (originalOptions[key]) blockers.push(`Original ${key} requires extra whole-project diagnostic analysis`);
    }
    if (aliasCollisions.length) blockers.push('Compiler path/redirect alias collisions need explicit identity handling');
    if (unresolvedGraphTargets.length) blockers.push('A resolved dependency is not represented in the enumerated source-file graph');
    if (rootIds.some((id) => !id)) blockers.push('One or more original roots did not produce a SourceFile');
    if (files.some((file) => file.parseDiagnostics.length)) blockers.push('Original program has parse diagnostics; retain them before planning checks');
    const allCovered = closure([...rootIds, ...shared]);
    const uncovered = files.filter((file) => !allCovered.has(file.id)).map((file) => file.id);
    if (uncovered.length) blockers.push('The actual Program contains files not explained by captured dependency/ambient closure');
    const originalEntries = parsed.fileNames.map((name, index) => ({ name, id: rootIds[index], index }));
    const isTest = (name) => canonical(name).startsWith(canonical(path.join(root, 'tests')) + '/');
    const fileMap = new Map(files.map((file) => [file.id, file]));
    const targetFixture = canonical(path.join(root, 'tests/fixtures/catalogue/kia-cadillac-staged-delta.json'));
    const rootClosures = new Map(originalEntries.map((entry) => [entry.name, closure([entry.id])]));
    const exclusiveJsonBytes = (entries) => {
      const ids = closure(entries.map((entry) => entry.id));
      return [...ids].reduce((sum, id) => sum + (!shared.has(id) && fileMap.get(id)?.isJson ? fileMap.get(id).utf8Bytes : 0), 0);
    };
    const groups = [];
    const core = originalEntries.filter((entry) => !isTest(entry.name));
    if (core.length) groups.push({ id: 'source-scripts-and-generated', entries: core });
    const tests = originalEntries.filter((entry) => isTest(entry.name));
    const pathological = tests.filter((entry) => rootClosures.get(entry.name).has(targetFixture));
    const ordinary = tests.filter((entry) => !rootClosures.get(entry.name).has(targetFixture));
    // Group only after compiler dependency discovery. File sizes are scheduling hints, not heap limits.
    const maxRoots = 12, maxExclusiveJsonBytes = 4 * 1024 * 1024;
    let batch = [];
    for (const entry of ordinary) {
      if (batch.length && (batch.length >= maxRoots || exclusiveJsonBytes([...batch, entry]) > maxExclusiveJsonBytes)) {
        groups.push({ id: `tests-${groups.filter((item) => item.id.startsWith('tests-')).length + 1}`, entries: batch });
        batch = [];
      }
      batch.push(entry);
    }
    if (batch.length) groups.push({ id: `tests-${groups.filter((item) => item.id.startsWith('tests-')).length + 1}`, entries: batch });
    for (const [index, entry] of pathological.entries()) groups.push({ id: `pathological-kia-cadillac-${index + 1}`, entries: [entry] });
    const partitions = groups.map((group) => {
      const primary = new Set(group.entries.map((entry) => entry.id));
      const rootNames = originalEntries.filter((entry) => primary.has(entry.id) || shared.has(entry.id)).map((entry) => entry.name);
      const rootKeys = new Set(rootNames.map(canonical));
      for (const file of files) if (shared.has(file.id) && !rootKeys.has(canonical(file.fileName))) {
        rootNames.push(file.fileName); rootKeys.add(canonical(file.fileName));
      }
      const expected = closure([...primary, ...shared]);
      return { id: group.id, primaryRoots: group.entries.map((entry) => entry.name), rootNames,
        expectedSourceIds: files.filter((file) => expected.has(file.id)).map((file) => file.id),
        expectedAmbientOrder: files.filter((file) => expected.has(file.id) && shared.has(file.id)).map((file) => file.id),
        estimatedJsonInputBytes: files.filter((file) => expected.has(file.id) && file.isJson).reduce((sum, file) => sum + file.utf8Bytes, 0),
        exclusiveJsonInputBytes: exclusiveJsonBytes(group.entries),
        futureIncrementalState: `<fresh external run directory>/${group.id}.tsbuildinfo`,
        checked: false };
    });
    const assigned = partitions.flatMap((part) => part.primaryRoots);
    const assignedCounts = new Map();
    for (const name of assigned) assignedCounts.set(name, (assignedCounts.get(name) ?? 0) + 1);
    const rootCoverageExact = assigned.length === parsed.fileNames.length && parsed.fileNames.every((name) => assignedCounts.get(name) === 1);
    if (!rootCoverageExact) blockers.push('Original checked-root coverage is not exact');
    const validator = canonical(path.join(root, '.next/types/validator.ts'));
    if (!originalEntries.some((entry) => entry.id === validator)) blockers.push('Expected existing Next validator is absent from original roots; investigate generated input drift');
    if (!partitions.find((part) => part.id === 'source-scripts-and-generated')?.primaryRoots.some((name) => canonical(name) === validator)) blockers.push('Next validator was not retained in the core group');
    const fixture = fileMap.get(targetFixture);
    if (!fixture) blockers.push('Known large fixture was not present in compiler graph; investigate input/coverage change');
    plan = { strategy: 'Conservative shared closure: every declaration file, every non-JSON nonmodule script, all JS, every module/global augmentation or UMD export, and all automatic types; keep original root relative order, append extra shared roots in original SourceFile order',
      blockers, uncoveredFiles: uncovered, rootCoverageExact, originalRootCount: parsed.fileNames.length,
      sharedSeedCount: graph.sharedSeeds.length, sharedClosureCount: shared.size,
      allSharedAmbientContributors: graph.sharedSeeds,
      groupingHints: { maxRoots, maxExclusiveJsonBytes, notMemoryBounds: true },
      pathologicalFixture: { path: targetFixture, utf8Bytes: fixture?.utf8Bytes,
        importingRoots: pathological.map((entry) => entry.name),
        alsoInCore: core.filter((entry) => rootClosures.get(entry.name).has(targetFixture)).map((entry) => entry.name),
        forcedIntoSharedClosure: shared.has(targetFixture) },
      partitions, exhaustiveDiagnosticsEstablished: false, replacementForStandardTsc: false };
    write('candidate-partitions.json', plan);
  } else {
    const failures = [];
    const actualIds = files.map((file) => file.id);
    const expectedIds = candidate.expectedSourceIds;
    const expectedSet = new Set(expectedIds), actualSet = new Set(actualIds);
    const missing = expectedIds.filter((id) => !actualSet.has(id));
    const extra = actualIds.filter((id) => !expectedSet.has(id));
    if (missing.length || extra.length) failures.push('SourceFile closure differs from the original graph restriction');
    if (!equal(actualIds, expectedIds)) failures.push('SourceFile relative order differs from original');
    if (!equal(graph.sharedClosure, candidate.expectedAmbientOrder)) failures.push('Shared ambient/declaration closure or merge order differs');
    if (!equal(graph.rootNames, candidate.rootNames)) failures.push('Actual partition roots differ from planned roots');
    if (!equal(graph.commonSourceDirectory, baseline.graph.commonSourceDirectory)) failures.push('Inferred common source directory differs');
    if (!equal(graph.automaticTypeNames, baseline.graph.automaticTypeNames) || !equal(graph.automaticTypes, baseline.graph.automaticTypes)) failures.push('Automatic type discovery/resolution differs');
    const originalFiles = new Map(baseline.graph.files.map((file) => [file.id, file]));
    const classifications = [];
    const fields = ['textSha256', 'isJson', 'isDeclaration', 'isExternalModule', 'isCommonJSModule', 'isNonModuleScript', 'isJavaScript', 'isDefaultLibrary', 'isExternalLibrary', 'hasNoDefaultLib', 'impliedNodeFormat', 'redirectTarget', 'compilerModuleAugmentations', 'ambientSyntax'];
    for (const file of files) {
      const old = originalFiles.get(file.id);
      if (!old) continue;
      for (const key of fields) if (!equal(file[key], old[key])) classifications.push({ file: file.id, key, original: old[key], actual: file[key] });
    }
    if (classifications.length) failures.push('File identity/classification/ambient syntax changed');
    const normalized = (rows) => rows.map((row) => stringify(row)).sort();
    const oldResolutions = baseline.graph.resolutions.filter((row) => actualSet.has(row.from));
    if (!equal(normalized(resolutions), normalized(oldResolutions))) failures.push('Actual module/type resolution records differ');
    const oldEdges = baseline.graph.edges.filter((edge) => actualSet.has(edge.from));
    if (!equal(normalized(edges), normalized(oldEdges))) failures.push('Actual reference/dependency edges differ');
    if (aliasCollisions.length || unresolvedGraphTargets.length) failures.push('Unresolved graph identity or redirect collision');
    shape = { partition: candidate.id, status: failures.length ? 'STRUCTURAL_DIFFERENCES' : 'STRUCTURAL_PREREQUISITES_MATCH',
      failures, missing, extra, classifications, optionsDifferOnlyByExternalTsBuildInfoFile: true,
      originalConfigFilePath: options.configFilePath, uniqueIncrementalState: options.tsBuildInfoFile,
      originalLibs: options.lib, checked: false, exhaustiveDiagnosticsEstablished: false,
      standardTscPassed: false, note: 'Matching structure is a prerequisite only; this mode never calls semantic/global diagnostics or emits.' };
    write('shape-comparison.json', shape);
  }
  const ioObservations = [...observed.values()];
  const differences = [...recheckObservations(ioObservations), ...recheckRawInputs([...rawInputs])];
  // Shape runs also re-attest all original graph observations, including negative lookups and directory listings.
  if (baseline) differences.push(...recheckObservations(baseline.ioObservations), ...recheckRawInputs(baseline.rawInputs));
  write('io-observations.json', ioObservations);
  write('raw-inputs.json', [...rawInputs]);
  const result = { status: differences.length ? 'INPUT_DRIFT' : mode === 'graph' ? 'GRAPH_AUDIT_COMPLETE' : shape.status,
    header, graph, plan, shape, ioObservations, rawInputs: [...rawInputs], inputDifferences: differences,
    noCheckerInvoked: true, noEmitInvoked: true, originalBuildInfoUntouched: true,
    memory: process.memoryUsage(), resourceUsage: process.resourceUsage(),
    standardTscPassed: false, exhaustiveDiagnosticsEstablished: false };
  write('audit.json', result);
  write('terminal.json', { status: result.status, checked: false, inputDifferences: differences.length,
    planBlockers: plan?.blockers, shapeFailures: shape?.failures,
    standardTscPassed: false, memory: result.memory, resourceUsage: result.resourceUsage });
  phase('audit-terminal');
  if (differences.length || plan?.blockers.length || shape?.failures.length) process.exitCode = 1;
}
