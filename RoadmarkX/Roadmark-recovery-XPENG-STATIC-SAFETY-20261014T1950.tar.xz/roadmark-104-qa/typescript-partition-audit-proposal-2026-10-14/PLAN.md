# Compiler-partition diagnostic audit proposal

Status: review-only. `audit.mjs` has been written but **not executed, syntax-checked, linted, or compiler-validated**. No source/config/fixture/type changes were made. The full standard `tsc --noEmit` command remains unverified after termination. This proposal is a diagnostic route, not permission to replace that release gate.

## Installed implementation inspected

- Original tsconfig: strict, noEmit, ES2022, esnext module, bundler resolution, resolveJsonModule, isolatedModules, allowJs, existing skipLibCheck=true, incremental=true; original DOM/esnext libs, paths, Next plugin and all include patterns remain intact.
- TypeScript 5.9.3 installed package: public configuration parsing and Program APIs, plus exact installed internal resolution/reference APIs around typescript.js lines127230–127345. Internal access is deliberately version-pinned and checked before use, not assumed portable to another compiler.
- `AGENTS.md` requires installed Next guides. Next16.3.8's useTypeScriptCli guide says Next build defaults to the full project-local tsc CLI, including test files and generated types selected by tsconfig. No ignoreBuildErrors, alternative tsconfig, install, or compiler upgrade is proposed.
- Present generated roots include `.next/types/validator.ts`, cache-life.d.ts, routes.d.ts and root-params.d.ts. The validator has real `typeof import(...)` route checks and cannot be discarded as boilerplate.
- Concrete ambient effects include react-dom/index.d.ts augmenting `react` and exporting a UMD namespace, react-dom/server.d.ts declaring globals and a UMD namespace, esbuild/lib/main.d.ts augmenting global WebAssembly.Module and URL, Next cache-life's ambient `next/cache` declaration, and routes' global route helpers. Discovery must include imported declarations, not just authored roots.
- `tests/fixtures/catalogue/kia-cadillac-staged-delta.json` is 8,236,430 bytes and statically imported by kia-cadillac-integration.test.ts. It retains its complete original inferred JSON type in this proposal.

## What the script does, if separately approved

Run modes in separate, measured processes, serially under the assigned heavy slot. Use a new external output directory each time. The explicit `--authorize-compiler-audit` switch is an accidental-execution guard, not a substitute for approval.

1. `config` calls the installed compiler's getParsedCommandLineOfConfigFile on the **original** tsconfig. It records original option values, configFilePath/config-file content, project references and root filename order. It does not create a Program or checker.
2. `graph` constructs the original complete Program with the parsed options and root order. It does not request the checker, global/semantic diagnostics, emit, or incremental output. It can still consume substantial parsing memory, especially for JSON ASTs; successful completion is unproven. If it terminates, retain the partial files/terminal state and stop rather than retrying identical runs automatically.
3. It enumerates `getSourceFiles()` and the compiler's actual resolved module and type-reference caches. This includes type-only imports, import types, exports, CommonJS imports, JSON modules, package IDs, resolution modes, automatic @types, triple-slash path/lib references, redirect identity and file-inclusion reasons. No regex dependency resolver or replacement host resolver is used.
4. Compiler AST traversal identifies global augmentations, string-named modules/augmentations and UMD exports. Every non-JSON nonmodule script is shared. For conservatism, **every declaration file** and all JavaScript files are shared too, with their full transitive closure; JS expando/global-inference subtleties are therefore not silently assumed local. JSON files are excluded only from nonmodule/global classification: their complete real source and AST remain loaded and recorded.
5. Candidate primary roots are exhaustive: all source/scripts/generated/non-test roots in one core group, ordinary test roots (including helpers) in original-order groups of at most12 roots and roughly4MiB exclusive JSON input, and a separate candidate for each root depending on the8.24MB fixture. These are scheduling hints, not memory limits. If that fixture enters shared/core closure, the report says so rather than pretending isolation succeeded.
6. Each candidate includes all shared original roots in their original relative order and then additional shared dependency files in original Program order. The original config is never moved or reparsed through an extends wrapper. The script records every primary-root assignment and fails the planning gate unless coverage is exact and the existing Next validator remains in the core group.
7. `shape` later constructs one candidate Program in a fresh process, under the same original parsed options/configFilePath. Its only option delta is a unique external tsBuildInfoFile destination; no build state is actually read/written by this plain-Program audit. It compares actual file closure/order, shared declaration/ambient order, file hashes/classification, package/module/type resolutions, reference edges, automatic libs/types, and inferred common source directory against the full-graph restriction. Extra/missing files or changed resolution/identity/order prevent a structural-match result.

Compiler host methods return their original results unchanged. Observation records include read text hashes, streamed physical-byte hashes, negative file/directory lookups, directory enumeration and realpath results; these are rechecked before a terminal result. Compiler/API/CLI bytes are pinned. Shape mode rechecks the full original graph's observations too. Source/config/compiler writes are prohibited by the host. Artifacts are confined to the specified external output directory.

Example commands for later review, **not executed**:

```sh
node --max-old-space-size=<approved bound> --max-semi-space-size=1 audit.mjs \
  --authorize-compiler-audit --mode config \
  --project /workspace/scratch/586427eef9f2/roadmark-104/tsconfig.json \
  --out /workspace/scratch/586427eef9f2/roadmark-104-qa/ts-config-audit-UNIQUE

# Same invocation with --mode graph and a different fresh output directory.
# Only after graph review, a fresh shape process adds:
# --mode shape --baseline <graph-output>/audit.json --partition <candidate-id>
```

No heap bound is recommended as a proven solution. Root selects one bounded diagnostic attempt and records the actual exit/signal/RSS. An interrupted audit is not a complete inventory, and a completed graph/shape is not a typecheck.

## Preconditions for an exhaustive partition diagnostic claim

All of the following are necessary, and must be demonstrated rather than assumed:

- The full original graph audit completes and accounts for every originally checked root, all actual transitive inputs, automatic types/libs and generated Next validator. No omitted root, unresolved graph identity, parse/config error or unsupported project-reference/composite/declaration-output dependency remains.
- Every file capable of changing another root's global/module/UMD type environment, plus the full declarations and dependencies it needs, exists in every relevant partition with the same identities and effective merge/overload order. All nonmodule/global contributors are co-checked, so duplicate/conflicting declarations cannot be separated into passing groups.
- Each checked root retains the same complete import/type/reference closure, resolutions, package IDs, conditions, file classification, default libraries and ambient environment as the original program. Root ordering, inferred common source directory, original configFilePath and every semantic compiler option remain the same. Explicitly rooting declaration files can alter their external-library classification or ordering; the shape gate detects that. A failure is a real review issue, not permission to relax the gate silently.
- Every semantic partition uses the original full JSON bytes and inferred types. No stub, cast, generated interface, noCheck, skip-test selection, weaker strict flag, extra skipLibCheck change, different lib or changed resolver is permitted.
- A future checker must run all applicable compiler diagnostic categories over each complete partition: original config/option diagnostics, syntax, globals, semantics, and declaration/emit diagnostics when applicable. It must retain every diagnostic and its file/code/span/related information; deduplicate only for presentation, never to hide a failure. Primary-root union and shared-global checks must be proved complete. Current original skipLibCheck behavior is retained exactly, not broadened.
- Incremental checking, if used later, must preserve incremental=true and use distinct fresh external build-info paths, never the original or another partition's state. Preserve original options/config identity; disallow stale/incompatible state reuse. Pin inputs before/after every process and all processes as a whole. Run serially without another heavy task or source generation.

The script deliberately does **not** implement that semantic checker yet. The first decision is whether actual graph/shape results support any semantically defensible partition. Project references, composite/output-wide diagnostics, unknown redirects, missing dependencies or order changes require additional analysis, not automatic partition execution.

## Why this still does not equal a standard tsc pass

Even when coverage and structural gates pass, partition checks are separate compiler Programs. TypeScript offers no public guarantee that all order-dependent inference/resource-limit diagnostics, lazy checker caches and project-wide diagnostics are interchangeable with a monolithic invocation. A successful partition union can substantiate exhaustive checking under the demonstrated independence assumptions; it is not an observed result of the original command and is not a proof of compiler equivalence for arbitrary programs.

The installed standard CLI also short-circuits some later diagnostics after earlier errors; getPreEmitDiagnostics in a future API runner would collect a differently ordered/sometimes broader set. A clean union is useful diagnostic evidence, but it cannot be relabelled a clean original CLI invocation. Next's default full-project CLI gate remains open until actually completed or separately changed by an explicit authorized decision. No such gate change is proposed here.

The conservative shared-all-declarations strategy and exact order/classification gates may leave no useful partition or may force large roots back into every group. That negative result is valid. The pathological fixture may still exceed the bound in isolation; its type safety must not be weakened to obtain a pass.

## Optional JSON-topology fallback: unimplemented

If real full-graph construction itself cannot finish, a graph-only JSON AST substitute could be assessed separately. It would have to apply only at resolved JSON SourceFile creation, never globally to readFile: tsconfig/package.json reads influence resolution. Real bytes and independently established syntax validity, filenames, scriptKind/JsonFile identity, roots, package identity and import attributes would need preservation. JSON grammar has no TS imports/ambient declarations, but parse diagnostics and inferred exports/types would change; the result could only be a clearly provisional topology aid, validated against real-AST cases. This script contains no stub path, and no semantic partition may ever use one. Reviewer approval is required before implementing even that fallback.
