from pathlib import Path
import json,copy,hashlib
R=Path('/tmp/xpeng-research');d=json.load(open(R/'normalized-evidence-v2.json'));D='2026-10-15'
p={'sources':[],'variants':[],'brandTerms':{},'topLevel':{'reviewAmendment':'Independent review corrections: categorical towing, claim-specific citations, visible unknown price basis, roadside maker FAQ and residual support-extension scope.'}}
def source(key,url,title,publisher,file,kind='secondary_australian_motoring_publication',**kw):p['sources'].append(dict(key=key,url=url,title=title,publisher=publisher,file=file,source_type=kind,checkedOn=D,**kw))
source('l03-width-conflict','https://origin.carexpert.com.au/car-news/2027-xpeng-l03-mid-size-suv-priced-from-under-dollar42000-with-ev-and-erev-options','Earlier L03 launch width and equipment report','CarExpert','web-l03-earlier-width-conflict.json',published_date='2026-09-23')
source('l03-window-conflict','https://www.carsguide.com.au/car-news/new-affordable-2026-xpeng-l03-electric-car-and-extended-range-hybrid-to-undercut-geely-ex5','L03 launch charging-window and dimensions cross-check','CarsGuide','web-l03-earlier-window-conflict.json',published_date='2026-09-23')
source('g6-editorial-conflict','https://www.xpeng.com/au/insight/xpeng_new_g6_worth_considering','New G6 Australian editorial with contradictory range pairings','XPENG Australia','web-g6-editorial-conflicts.json','manufacturer_au_editorial',notes='Exact current configurator governs range. This editorial swaps LR/AWD ranges and Standard Range wheel/range pairings; it is retained as disagreement evidence, not the adopted specification.')
source('g6-generic-dimensions-conflict','https://www.carsguide.com.au/xpeng/g6/car-dimensions/2026','G6 generic year dimensions mixing generations','CarsGuide','g6-carsguide-dimensions.txt','secondary_australian_price_guide')
source('residual-warranty-extension','https://www.carsguide.com.au/car-news/xpeng-to-back-offers-and-extend-warranty-to-every-xpeng-g6-in-australia-after-previous','Reported warranty extension for already-purchased TrueEV G6 vehicles','CarsGuide','web-residual-warranty-support-report.json',published_date='2026-08-25',notes='Report addresses existing owners/already-purchased vehicles. No assertion that an unsold residual VIN automatically qualifies.')
cap=json.load(open(R/'residuals/capture-source-map-v1.json'))['sources']['evc_2024']
source('residual-evc-2024','https://electricvehiclecouncil.com.au/wp-content/uploads/2024/12/1734312344781.pdf','State of Electric Vehicles 2024, G6 reference table','Electric Vehicle Council',cap['path'],'secondary_australian_industry_compilation',capture_section='Page 69; old-generation summary, not a current VIN inspection')
for v in d['variants']:
 q={'id':v['id'],'facts':[]};facts={f['key']:f for f in v['facts']}
 def change(k,**kw):
  f=copy.deepcopy(facts[k]);f.update(kw);q['facts'].append(f);return f
 if v['model']=='New G6':
  change('price_aud',qualifications=['The visible version-card amount does not state tax inclusion or on-road treatment; no before-on-road or driveaway grouping is assigned.'])
  change('range_km',sourceKeys=['g6-config','g6-editorial-conflict'])
  change('length_mm',sourceKeys=['g6-dimensions','g6-generic-dimensions-conflict'])
 if v['model']=='X9':
  change('boot_l',sourceKeys=['x9-config','x9-launch'])
  if v['drive']=='FWD':change('towing_braked_kg',value='Not approved for towing',unit='',label='Towing approval',basis='Braked towing applicability: maker does not approve this version for any towing',comparison='',qualifications=['Categorical manufacturer approval statement, not a numeric kilogram rating. Excluded from numerical towing ranking.','Secondary 1500 kg FWD listings conflict with the current maker configurator and are not adopted.'])
 if v['model']=='L03':
  change('width_mm',sourceKeys=['l03-carexpert','l03-width-conflict'])
  sources=['l03-carexpert','l03-racv'];quals=['CarExpert and RACV explicitly state 10–80%.']
  if 'rwd_standard_range' in v['id']:
   sources.append('l03-window-conflict');quals.append('The earlier CarsGuide Standard Range paragraph says 20–80%; it is not relabelled as a 10–80% claim.')
   change('range_km',sourceKeys=['l03-carexpert','l03-racv','l03-whichcar'])
  change('dc_charge_time_min',sourceKeys=sources,qualifications=quals)
  change('power_kw',sourceKeys=['l03-carexpert','l03-racv','l03-zecar'])
 if v['model']=='G6':
  if v['trim']=='RWD Standard Range':change('zero_to_100_s',sourceKeys=[*facts['zero_to_100_s']['sourceKeys'],'residual-evc-2024'])
  change('warranty',value='Historical 5 years / 120,000 km; later 7-year support reported; confirm this unsold unit',sourceKeys=[*facts['warranty']['sourceKeys'],'residual-warranty-extension'],qualifications=[*facts['warranty']['qualifications'],'CarsGuide reports seven-year private-use support extended to already-purchased TrueEV G6s. That report does not establish this unsold residual unit’s eligibility.'])
  q['facts'].append(dict(key='reported_legacy_warranty_support',value='Reported 7-year / unlimited-km private-use warranty support for already-purchased TrueEV G6 vehicles',sourceKeys=['residual-warranty-extension','residual-anz_faq'],grade='reported',basis='Reported extension for existing owners; unsold residual applicability unresolved',comparison='',reason='Current secondary reporting describes an extension for already-purchased vehicles; the maker FAQ directs documented prior commitments to individual review.',qualifications=['Do not treat this as an automatic warranty promise for an unsold advertised-new residual.','Ask for the written issuer, eligibility, commencement and limits for the exact VIN.']))
  summary=copy.deepcopy(v['summary']);summary['tradeoff']=dict(label='Confirm the residual warranty',text='Seven-year support has been reported for existing TrueEV owners, but the issuer and cover for this unsold residual still need written confirmation.',keys=['warranty','battery_warranty','reported_legacy_warranty_support']);q['fields']={'summary':summary}
 if q['facts']:p['variants'].append(q)
t=copy.deepcopy(d['brandTerms']['roadside_assistance']);t.update(value='7 years from first registration',grade='confirmed',sourceKeys=['residual-anz_faq'],evidenceScope='brand_au_terms',scope='Current XPENG Australia eligible vehicles; inherited by current Gen2 G6, X9 and announced L03 only',reason='Current Australian maker FAQ explicitly states seven years from first registration and links the eligible roadside-assistance programme.',qualifications=['Eligibility, service limits, exclusions and customer costs remain subject to the published programme terms.','No automatic extension to former-importer residuals is inferred.'],roadsideFitment='standard');p['brandTerms']['roadside_assistance']=t
f=R/'research-amendment-v3.json';assert not f.exists();f.write_text(json.dumps(p,indent=2,ensure_ascii=False)+'\n')
pin=lambda x:{'path':str(x),'sha256':hashlib.sha256(x.read_bytes()).hexdigest()};m={'schemaVersion':1,'mode':'xpeng-research-normalization','base':pin(R/'normalized-evidence-v2.json'),'amendments':[pin(f)],'output':str(R/'normalized-evidence-v3.json')};f=R/'normalization-manifest-v3.json';assert not f.exists();f.write_text(json.dumps(m,indent=2)+'\n')
