"""Assemble reviewed research inputs by an immutable manifest; no catalogue imports.

Existing evidence and prior outputs are read-only. Corrections require a new patch
and manifest, not changed historical evidence or regenerated canonical fixtures.
"""
import argparse, copy, hashlib, json
from pathlib import Path

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load_pin(row):
    p=Path(row['path']).resolve()
    assert p.is_file(), str(p)
    assert digest(p)==row['sha256'], ('Changed research input', str(p))
    return json.loads(p.read_text())

ap=argparse.ArgumentParser();ap.add_argument('manifest');args=ap.parse_args()
mp=Path(args.manifest).resolve();m=json.loads(mp.read_text());mh=digest(mp)
assert m['schemaVersion']==1 and m['mode']=='xpeng-research-normalization'
out=Path(m['output']).resolve()
assert out.is_relative_to(Path('/tmp/xpeng-research')) and not out.exists()
data=copy.deepcopy(load_pin(m['base']))
for pin in m['amendments']:
    patch=load_pin(pin)
    for field,value in patch.get('topLevel',{}).items():data[field]=copy.deepcopy(value)
    existing={s['key']:s for s in data['sources']}
    for s in patch.get('sources',[]):
        assert s['key'] not in existing, ('Duplicate source',s['key'])
        data['sources'].append(copy.deepcopy(s));existing[s['key']]=s
    rows={v['id']:v for v in data['variants']}
    for p in patch.get('variants',[]):
        assert p['id'] in rows, ('No patch target',p['id'])
        v=rows[p['id']]
        for k in p.get('removeFields',[]):
            assert k in v,(p['id'],k);del v[k]
        for k,x in p.get('fields',{}).items():v[k]=copy.deepcopy(x)
        for field,key in [('facts','key'),('features','criterion')]:
            for replacement in p.get(field,[]):
                matches=[i for i,x in enumerate(v[field]) if x[key]==replacement[key]]
                assert len(matches)<=1,(p['id'],field,replacement[key])
                if matches:v[field][matches[0]]=copy.deepcopy(replacement)
                else:v[field].append(copy.deepcopy(replacement))
    for v in patch.get('newVariants',[]):
        assert v['id'] not in rows,('Duplicate new identity',v['id'])
        data['variants'].append(copy.deepcopy(v));rows[v['id']]=v
    for key,value in patch.get('brandTerms',{}).items():
        assert key in data['brandTerms'];data['brandTerms'][key]=copy.deepcopy(value)
keys={s['key'] for s in data['sources']}
assert len(keys)==len(data['sources'])
ids=[v['id'] for v in data['variants']];assert len(set(ids))==len(ids)
for v in data['variants']:
    fs=[f['key'] for f in v['facts']];assert len(set(fs))==len(fs),(v['id'],'Duplicate fact')
    cs=[f['criterion'] for f in v['features']];assert len(set(cs))==len(cs),(v['id'],'Duplicate feature')
    for f in v['facts']:
        assert set(f['sourceKeys'])<=keys,(v['id'],f['key'],'Unknown source')
        assert f['grade'] in ['confirmed','check','reported','not_published']
        if f['grade']=='check':assert f.get('condition'),(v['id'],f['key'])
        if f['grade']=='not_published':assert f['value'] is None and len({next(s['url'] for s in data['sources'] if s['key']==k) for k in f['sourceKeys']})>=2
    for feature in v['features']:
        assert set(feature['keys'])<=set(fs)|set(data['brandTerms']), (v['id'],feature['criterion'],'Missing dependency')
for pin in [m['base'],*m['amendments']]:load_pin(pin)
assert digest(mp)==mh
data['assemblyProvenance']={'manifest':str(mp),'manifestSha256':mh,'catalogueFunctionsInvoked':False,'canonicalFixtureCaptured':False}
with out.open('x') as f:json.dump(data,f,indent=2,ensure_ascii=False);f.write('\n')
print(json.dumps({'output':str(out),'sha256':digest(out),'versions':len(ids),'sources':len(keys),'facts':sum(len(v['facts']) for v in data['variants'])}))
