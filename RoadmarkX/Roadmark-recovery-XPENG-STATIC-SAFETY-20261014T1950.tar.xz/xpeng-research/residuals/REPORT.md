# XPENG residual advertised-new findings

Checked 15 October 2026 Australia/Sydney. Research only; no catalogue edits, testing, contact, order, or publication.

## Eligible identities

1. MY2024 G6 Gen1 RWD Standard Range: Patrick Auto Group X1011, VIN L1NNSGHA9SB126574, explicitly Model Year 2024 and New. Current price is POA, so current price remains null/Not published. Historical launch $54,800 excluding on-road costs is a separate price-when-new fact, not a current price for this unit.
   https://www.patrickauto.com.au/new-cars/for-sale/xpeng/g6/2024/standard-range/3714979/
2. MY2025 G6 Gen1 RWD Standard Range: XPENG Kedron 147928, VIN L1NNSGHA2SB147928, New, $45,990 drive-away. Explicit visible Gen1 and public embedded model_year: 2025 / MY2025 description. Build July 2025, compliance September 2025.
   https://www.xpengkedron.com.au/cars/new-arctic-white-2025-xpeng-g6-147928
3. MY2025 G6 Gen1 RWD Long Range: XPENG Kedron 150568, VIN L1NNSGHA2SB150568, New, $47,950 drive-away. Explicit visible Gen1 and public embedded model_year: 2025 / MY2025 description. Build September 2025, compliance April 2026.
   https://www.xpengkedron.com.au/cars/new-silver-frost-2025-xpeng-g6-150568

All three exact pages fetched HTTP 200 at their exact URLs. Their plain-text evidence and whitelisted metadata are adjacent to this report. Ads prove advertised-new status, not physical possession, unsold status at purchase time, delivery promises, or factory order acceptance.

## Important correction and source strength

Australian old-generation SR is 190kW, not the initial 210 kW premise. The former official importer TrueEV's 30 September 2024 announcement confirms190/210 kW,435/570 km WLTP and RWD. The current Dubbo old-G6 table independently exposes the same figures plus66/87.5 kWh LFP/NMC,215/280 kW DC,11 kW AC and5 seats. Kedron's exact MY2025 descriptions themselves give 190 kW/210 kW.

https://www.trueev.com.au/trueev-reveals-xpeng-g6-pricing-and-australian-flagship-showroom-at-sydney-airport/
https://www.xpengdubbo.com.au/models/g6

Dubbo is liveHTTP 200. TrueEV's historical article is web-tool-readable but directHTTP 403. Burwood exposes a matching dealer specification table through web extraction but directHTTP 403. Dubbo and Burwood share a template and should not be presented as independent technical verification. The EVC 2024 report p69 independently corroborates batteries and ranges at old-generation level, not exact MY2025 VIN level. Former xpeng.com.au/g6-specification is now 404; no current maker-hosted former-AU brochure recovered. Do not import foreign-market values.

https://electricvehiclecouncil.com.au/wp-content/uploads/2024/12/1734312344781.pdf

## Warranty

Historical TrueEV launch terms: 5 years/120,000 km vehicle and 8 years/160,000 km battery. Optional extensions are separate, not standard 10-year coverage. Contemporary carsales 1 October 2024 reporting corroborates those historical terms and period prices excluding ORC.

https://www.carsales.com.au/editorial/details/2024-xpeng-g6-undercuts-tesla-model-y-147516/

Current manufacturer terms cannot automatically be assigned to residual units. July 2026 official release limits its scheme to eligible vehicles sold by XPENG ANZ from 1 June 2026; manual p2 further scopes new vehicles imported by XPENG Australia and registered in Australia. Dealer/model year alone does not establish the selling/importing entity, first registration or written warranty eligibility. Record exact residual warranty as unverified unless documentary scope is established. Current TrueEV customer support is review-based, not blanket proof of seven-year eligibility.

https://www.xpeng.com/au/news/019fa2860f529f8481378a02820600b3
https://s-cdn.xpeng.com/commoncms/prod/2026-08-26/93f6d934f5694de2a438fe10b1ff747a.pdf?name=XPENG-ANZ-Warranty-and-Maintenance-Manual-Australia
https://www.xpeng.com/au/insight/FAQ
https://www.xpeng.com/au/faq

## Freshness and census limitations

Many attractive search results were stale. Knox exact ads now 404; Essendon, Osborne Park and Bayford examples now redirect to stock searches; Midland 5148030 and Rockingham X000038 now Demo; Kedron 124643 now SOLD. The result.json logs exact URLs and differences.

Cardiff has live 2025 New Long Range examples, including 148041 explicitly RUN-OUT MODEL, but those add no new trim identity. Generic 2026 Rockingham Long Range listings have no inspected battery/power/series identifiers and remain epoch-ambiguous. No verified current-new MY2024 Long Range or MY2026 Gen1 identity was established. These are census gaps, not exclusion or national-absence claims.

Bounded search-led coverage spans selected official dealer pages in NSW, QLD, VIC and WA. It is not a complete national stock count. Exact unit availability and warranty require dealer confirmation before purchase.

## Deliverables

- result.json: normalized findings and source map
- kedron-2025-sr-147928.txt / kedron-2025-lr-150568.txt: live individual ad text
- corresponding -metadata.json files: bounded MY2025/description/drivetrain/seating evidence
- patrick-2024-sr-retry.txt: live MY2024/New/POA evidence
- dubbo-old-g6-model.txt: current old-generation technical table
- fetch-results-*.json: bounded status and redirect log, no response headers or cookies

## Final core-field additions

result.json now contains all 17 requested core fields per identity, with sources and status. Old-generation boot is reported as 571 L seats up / 1,374 L folded; dimensions 4,753 × 1,920 × 1,650 mm; 0–100 km/h is 6.6 s SR and 6.2 s LR. Dubbo dealer and Australian period/Redbook sources corroborate these. The EVC 2024 table instead gives 6.9 s for SR; this conflict is recorded.

Braked towing is Reported as 1,500 kg from Australian CarsGuide year-specific pages. A period Australian Long Range review separately corroborates 1,500 kg, but no current old-epoch Australian maker tow document was recovered. Keep exact towbar/VIN approval unresolved.

The technical table says 20 minutes for DC 10–80%; the same dealer narrative says less than 20 minutes. Both source wordings are retained. Historical warranty is Reported, not exact-unit coverage confirmation.

The narrow second-price search by Patrick VIN, X1011, dealer/name and MY2024 new status found no second current advertised price. Current price stays Not published / POA; historical $54,800 remains separately labelled price when new.
