# XPENG research/static-candidate safety increment

This increment preserves a frozen unregistered XPENG research/static candidate and the final bounded TypeScript configuration-audit records. Subaru registered-working source is unchanged and reused from its 91-archive recovery. No source archive is duplicated.

XPENG has no canonical capture, completed stage replay or registration in this cut. The feature-free candidate, evidence, V1–V5 normalization history, reconciliation V3, baseline values/receipts, failed wrapper and static reviews through 06/07 are retained. Later phase/review files are outside the exact 19:52 UTC allowlist.

The TypeScript exploration completed original configuration parsing only: no Program, dependency graph, checker or emit. No safe meaningful partition reduction was established, and exploration stopped. Standard TypeScript, build, clean full aggregate and mobile gates remain open. Prior Subaru and historical failed attempts remain in the base.

Exactly 158 XPENG files, the frozen cut manifest and 27 QA/status files are included. The sole existing-path overlay is roadmark-104-qa/work-status.json; its prior and new hashes match the explicit transition. Two warranty-page PNGs are local renders of the retained public warranty PDF. No browser screenshot exists in this cut. Raw browser runtime/profile, raw HTML/RSC and the malformed superseded search capture are excluded by the explicit allowlist; sanitized failure and residual-provenance receipts remain.

Restore using the accompanying combined manifest and the retained Roadmark-VERIFY-SAFE-RECOVERY-20261014.py verifier. It names all 91 original Subaru archives plus this increment in exact order. Download the immutable native versions listed; restore into a new empty directory. The unchanged source remains in roadmark, QA in roadmark-104-qa, and the three XPENG proof roots retain their basenames. Historical workspace/tmp references map to these restored roots.

The new increment was scanned and restored independently. The unchanged base is bound to its previously completed native-version/hash and independent-restoration receipts; this small save does not repeat the entire base archive/tree scan. No old backup, original or source file is deleted or replaced. Specified privacy scans are not a claim that every possible secret can be detected.
