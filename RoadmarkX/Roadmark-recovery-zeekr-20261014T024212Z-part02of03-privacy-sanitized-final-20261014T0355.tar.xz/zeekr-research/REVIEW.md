# Zeekr M1 source review — 14 October 2026

## Buyer result
- Eight current Australian versions are fully researched: 7X RWD / Long Range RWD / Performance AWD; MY26 X RWD / AWD; and 009 7-seat FWD / 7-seat AWD / 6-seat AWD
- All 17 core fields are filled for those eight versions. The three 7X core prices are maker list prices; the two MY26 X national driveaway prices and three 009 before-on-road prices are clearly Reported
- Ten versions stay visible in total. The 7X Black Special Edition remains outgoing with new availability Not confirmed. A distinct original MY24 X AWD record retains the same Perth car’s conflicting New and Dealer used classifications; it is not counted as on-sale new supply
- Corrected 30 equipment rows mirror source-bound power, storage and AC facts. All four 7X calculated home-charge durations are removed. Front storage is separate from rear cargo and occupied-seat space is separate from folded-seat capacity
- Every version has a fact-dependent strength and trade-off. Shared current private-use warranty, battery and roadside policies are stored once, with explicit exceptions for the original X’s uncertain registration/policy history

## Evidence and closure
- The dated packet is `zeekr-2026-10-14.json`; the report-compatible reconciliation is `zeekr-reconciliation-2026-10-14.json`
- 187 specific fact observations, three shared terms, 30 full guarded feature replacements, one new model/version, and 72 source snapshots
- `brand-model-list-reconciliation.json` reconciles the separate CarExpert and CarsGuide brand catalogues. They are not passed off as two complete Australian-market lists; the global published-list registry remains empty
- The inherited X and 009 audit records are included. The inherited 7GT lead is excluded from current orderability: the maker expressly says its interest form is not an order, and the announced Q4 2026 launch / Q1 2027 delivery schedule does not establish open orders
- 8X and 9X are announced PHEVs. Four-seat 009 Grand is an announced future model without a current Australian retail offer. Chinese 85 kWh / 900 V 7X updates are not substituted into current Australian vehicles
- Current-source checking resolves cached outgoing X advertisements: Doncaster’s old RWD detail redirects to stock, and Essendon’s former New ads are now Demo. Perth stock 0247 is the same MY24 AWD, 15 km, build/compliance and colours in both sources, but its New versus Dealer used classification remains unresolved and visible

## Important measurement boundaries
- 009 maker sources agree on 30 minutes for 10–80%, with 150 kW (current page / S3 brochure) versus 205 kW (linked Dato brochure) charger conditions. The duration is Check on its explicit window. Neither station number is vehicle peak
- 009 DC vehicle peak is displayed as two separate secondary claims, 205 kW from CarExpert editorial and 206 kW from JATO. The FWD’s editorial figure is explicitly AWD-sibling evidence. It is unranked, not an estimated interval or selected scalar
- 009 has 574 L rear storage with all seats occupied, supported by explicit maker FWD wording and identical capacities in all three exact brochure columns. Six- and seven-seat counts stay separate. The maker does not establish a VDA/SAE method
- 009 towing is Reported zero from NRMA’s explicit cannot-tow statement, with FWD sibling scope, an older mismatched CHOICE 750 kg observation and CarsGuide’s contradictory unspecified/zero presentation disclosed. Confirm the exact approved vehicle before towing
- 7X range stays labelled WLTP target. Its RWD 460 kW test station is separate from the vehicle’s 450 kW peak. The larger-battery versions have 420 kW vehicle peaks
- The original X retains 470 km ADR 81/02 (NEDC), 315 kW combined power, 362 L original boot and a maker “less than 30 minutes” charging upper bound. The advertised A$58,990 driveaway offer is separate from historical A$62,900 before-on-road pricing
- The current warranty PDF’s commercial-duration table conflicts with its commercial-use application exclusion. Private-use baseline terms remain Confirmed, but the conflict is disclosed and commercial eligibility is not promised. No warranty or roadside period restarts on resale; current 70% battery-retention terms are not assumed for the original X

## Staged coverage and checks
- Research-complete: eight on-sale versions; zero missing core cells, unreviewed core grades, missing summaries, aged/invalid claims or inherited unresolved leads
- C2, C3, C4 and C6 pass in the staged Zeekr report. This is not a claim that overall M1 or C1–C6 is complete
- Ranking coverage: range 100%; price 37.5%; 10–80% time 75%; seats 100%; boot 0%; towing 0%. Reported facts stay visible but unranked; unknown boot measurement methods do not acquire a comparable basis
- C1 remains open pending the two whole-market list reconciliations. C5 remains below the required threshold for four lists. These limitations are recorded, not relaxed
- Focused packet/feature tests: 22 passed. TypeScript check passed. Staged exact before-guards, source closure, feature dependencies, citable claims, portable roundtrips, immutable input checks and the integrated coverage report passed
- No full build or full test suite was run for this brand; root coordinates final milestone gates. All staged checks above passed before root registered the frozen packet at 00:46 UTC on 14 October 2026. These artifacts preserve that successful pre-registration replay and its original before-guards

## What did not work
- The maker’s public configurator HTML exposes an application shell rather than exact prices. Cloud Chromium could not launch because socket creation was denied. No credentials, signed API calls or user computer were used
- Some direct public downloads returned HTTP 403. Available public web extraction is explicitly identified as the capture route. Cached dealer details were never accepted over contradictory fresh redirect, Demo, Sold or Used evidence

The source index and evidence manifest hold source URLs, scope, captures and hashes. Original research/source records are unchanged; no publishing, M2 work, later-brand research or new checkpoint was performed.
