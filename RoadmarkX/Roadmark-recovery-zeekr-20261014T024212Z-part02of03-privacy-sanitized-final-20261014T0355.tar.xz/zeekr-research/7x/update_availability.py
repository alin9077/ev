from pathlib import Path
from html.parser import HTMLParser
import json,hashlib
D=Path('/tmp/zeekr-research/7x'); date='2026-10-14'
class T(HTMLParser):
 def __init__(self):super().__init__();self.a=[];self.skip=0
 def handle_starttag(self,t,a):
  if t in ('script','style'):self.skip+=1
  if t in ('p','div','br','h1','h2','h3','li','tr','td','th','section'):self.a.append('\n')
 def handle_endtag(self,t):
  if t in ('script','style'):self.skip=max(0,self.skip-1)
 def handle_data(self,d):
  if not self.skip:self.a.append(d)
for p in list(D.glob('dealer-*.html'))+[D/'black-mct-used.html']:
 t=T();t.feed(p.read_text());p.with_suffix('.txt').write_text('\n'.join(x.strip() for x in ''.join(t.a).split('\n') if x.strip()))
checks=[
 {'key':'7x_dealer_doncaster_new','url':'https://www.zeekrdoncaster.com.au/stock/new-zeekr-for-sale-doncaster/','publisher':'Zeekr Doncaster','file':'dealer-doncaster-new.html','result':'Direct live NEW filter returned 2 cars, both 009; no 7X of any trim.','liveState':'negative_exact_new_listing_search','count':2,'negativeScope':'This dealer current public new-vehicle list only.'},
 {'key':'7x_dealer_southyarra_new','url':'https://www.zeekrsouthyarra.com.au/stock/new-zeekr-for-sale-south-yarra/','publisher':'Zeekr South Yarra','file':'dealer-southyarra-new.html','result':'Direct live NEW filter returned 4 cars, all 009. Older search snippet said 8 with regular 7X; current source supersedes stale snippet.','liveState':'negative_exact_new_listing_search','count':4,'negativeScope':'This dealer current public new-vehicle list only.'},
 {'key':'7x_dealer_parramatta_stock','url':'https://www.zeekrparramatta.com.au/search/new-used-and-demo-cars','publisher':'Zeekr Parramatta','file':'dealer-parramatta-stock.html','result':'Direct live stock list returned 8 cars, all labelled used/demo. Its three 7Xs are used, with 3400, 8000 and 11000 km. No NEW exact Black edition.','liveState':'negative_exact_new_listing_search','count':8,'negativeScope':'This dealer current published stock list only; its heading is Used and Demo.'},
 {'key':'7x_dealer_solitaire_7x','url':'https://stock.solitaire.com.au/stock/search/?make=Zeekr&model=7X','publisher':'Solitaire Automotive Group / Zeekr Adelaide','file':'dealer-solitaire-7x.html','result':'Direct live make=Zeekr/model=7X filter returns exactly 3 cars, all Demo, stock listing IDs 4104426, 4110688, 4126208. None is a NEW exact Black Edition offer.','liveState':'negative_exact_new_listing_search','count':3,'negativeScope':'This dealer current filtered 7X stock list only.'},
 {'key':'7x_dealer_essendon_removed','url':'https://zeekressendon.com.au/stock/details/OAG-AD-26120161/2026-zeekr-7x-new','publisher':'Zeekr Essendon','file':'dealer-essendon-black-performance.html','result':'Search/web snapshot calls black-colour Performance New, 4000 km, stock 020645; does not name Black Edition. Direct live HTTP fetch redirects to https://zeekressendon.com.au/stock. This removed ad cannot support current availability, even for standard Performance.','liveState':'removed_ad_redirect','finalUrl':'https://zeekressendon.com.au/stock','negativeScope':'Exact cited ad removed; general stock list is not fully enumerated for this check.'},
 {'key':'7x_black_used_carsales','url':'https://www.carsales.com.au/cars/details/2026-zeekr-7x-performance-auto-awd-my26/OAG-AD-25991926/','publisher':'carsales dealer advertisement','file':'black-carsales-used-web-capture.json','result':'Current web fetch explicitly displays Sold and VIC Dealer used; dealer description names LIMITED EDITION - BLACK EDITION (No Longer Available to order). Not a NEW offer; dealer order comment is not treated as nationally authoritative. Direct shell HTTP fetch got 403; full web-tool capture saved.','liveState':'sold_used_listing','negativeScope':'This exact used car only.'},
 {'key':'7x_black_used_mct','url':'https://www.mctmotorsport.com.au/vehicles/69977','publisher':'MCT Motorsport Brisbane','file':'black-mct-used.html','result':'Direct live exact Black Edition description remains accessible; page explicitly Sold, odometer 4897 km. Independent used-car retailer; not current authorised-dealer NEW evidence.','liveState':'sold_used_listing','negativeScope':'This exact used car only.'}
]
queries=[
 'Zeekr 7X "Black Special Edition" "new" stock dealer Australia',
 'Zeekr 7X "Black Edition" "New" dealer Australia',
 'site:carsales.com.au/cars/details "Black Special Edition" "2026" Zeekr',
 '"Zeekr" "7X" "Black Edition" "stock" -site:reddit.com -site:youtube.com -site:linkedin.com -site:carexpert.com.au -site:carsguide.com.au -site:whichcar.com.au -site:carsales.com.au',
 '"Zeekr" "7X" "Black" "New" site:zeekrparramatta.com.au',
 '"Zeekr" "Black Edition" "new" site:zeekrsouthyarra.com.au',
 '"Zeekr" "Black" "stock" site:zeekrdoncaster.com.au',
 '"Zeekr" "7X" "Black Edition" "new-cars"',
 '"Zeekr" "7X" "Black Edition" "in-stock"',
 '"Zeekr 7X" "Black" "New" site:zeekressendon.com.au'
]
supplement={'checkedAt':date,'variantId':'zeekr_7x__black_special_edition_awd__4','purpose':'Bounded search for an exact Black Special Edition advertised NEW by an Australian authorised dealer, including retained outgoing NEW listings.','result':'No qualifying current exact-Black NEW advertisement found.','recommendation':{'buyerState':'Not confirmed','orderState':'not_confirmed','stockState':'not_verified','doNotAssert':['Nationwide no new stock','Definitively sold out','Discontinued','Current factory orders open'],'reason':'Four live authorised-dealer stock scopes found no qualifying exact Black NEW offer. One cached New black-colour Performance ad now redirects and was never exact Black Edition. The two exact Black Edition sale ads found are Sold/used. This supports keeping availability Not confirmed, not asserting nationwide absence.'},'queries':queries,'checks':checks,'limits':['This is a bounded public-listing search, not every Australian dealer and not a physical-stock survey.','Drive original sold-out report could not be directly read; normal and AMP GET both return Site Unavailable (195 bytes). Syndicated copies corroborate existence of the May report but are not treated as maker confirmation of current nationwide stock.','Dealer listing availability is enough for NEW offered-new classification if a qualifying exact edition is found; none was found here.']}
(D/'black-availability.json').write_text(json.dumps(supplement,indent=2)+'\n')
d=json.load(open(D/'evidence.json'))
new=[]
for c in checks:
 p=D/c['file'];new.append({'key':c['key'],'url':c['url'],'title':c['publisher']+' live 7X Black Edition availability check','publisher':c['publisher'],'source_type':'dealer_listing' if 'dealer' in c['key'] else 'dealer_advertisement','published_date':None,'accessed_date':date,'market':'AU','supports':c['result'],'file':'7x/'+c['file'],'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'evidenceScope':c['negativeScope']})
keys={s['key'] for s in d['sources']};d['sources'] += [s for s in new if s['key'] not in keys]
for v in d['variants']:
 if 'black_special' in v['id']:
  v['availability']['reason']=supplement['recommendation']['reason']
  v['availability']['sourceKeys'] += [x['key'] for x in checks]
  v['availability']['evidenceSupplement']='7x/black-availability.json'
  v['availability']['doNotAssert']=supplement['recommendation']['doNotAssert']
 else:
  p=next(x for x in v['facts'] if x['key']=='price_aud');p['sourceKeys']=['7x_price_maker'];p['corroborationOnlySourceKeys']=['7x_price_2026']
d['availabilitySearchSupplement']='7x/black-availability.json'
(D/'evidence.json').write_text(json.dumps(d,indent=2)+'\n')
(D/'source-index.json').write_text(json.dumps(d['sources'],indent=2)+'\n')
print('Saved 7 live checks and supplement; no qualifying exact Black NEW listing found. Updated availability only and Confirmed-price source purity.')
