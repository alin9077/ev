import json,pathlib,hashlib,copy,re
R=pathlib.Path('/tmp/zeekr-research');D='2026-10-14';PID='m1-zeekr-2026-10-14';REVIEWER='Roadmark Zeekr Australian source review'
cars=json.load(open(R/'before.json'));old={c['id']:c for c in cars};prior=json.load(open(R/'features-before.json'))+json.load(open(R/'new-feature-before.json'));effective={c['id']:{} for c in cars}
p={'schemaVersion':1,'id':PID,'brand':'Zeekr','reviewedAt':D,'reviewedBy':REVIEWER,'sources':[],'models':[],'variants':[],'versionGuards':[],'versionUpdates':[],'facts':[],'features':[],'brandTerms':[],'availability':[],'summaries':[]};sources={}
def source(row):
 k=row['key'];s={'id':PID+'-'+k,'url':row['url'],'title':row['title'],'publisher':row['publisher'],'source_type':row.get('source_type',row.get('kind')),'published_date':row.get('published_date'),'accessed_date':D,'market':'AU','supports':row.get('supports',row.get('note'))}
 for key in ['notes','capture_section']:
  if key in row:s[key]=row[key]
 path=row.get('file') or row.get('textFile')
 if path:
  f=pathlib.Path(path);f=f if f.is_absolute() else R/f
  if f.exists():s['capture_sha256']=hashlib.sha256(f.read_bytes()).hexdigest();s['capture_locator']=str(f.relative_to(R))
 if k in sources:
  assert sources[k]==s,k
  return
 p['sources'].append(s);sources[k]=s
pe=json.load(open(R/'normalized-evidence.json'))
terms=json.load(open(R/'terms.json'))
for s in terms['sources']+json.load(open(R/'list-sources.json'))+pe['sources']:source(s)
for row in pe['variants']:
 if row['id'] in old:continue
 mid=row.get('modelId','zeekr_x_original');model=row.get('model','X (original)');drive=row.get('drive','AWD' if 'awd' in row['id'] else 'RWD');src=[sources[k]['id'] for k in row['availability']['sourceKeys']]
 if mid not in [m['id'] for m in p['models']]:p['models'].append({'id':mid,'brand':'Zeekr','model':model,'family_id':'zeekr-x','generation':'Original Australian specification; advertised new/used classification unresolved'})
 v={'id':row['id'],'model_id':mid,'brand':'Zeekr','model':model,'trim':row['trim'],'model_year':row.get('model_year'),'record_state':'outgoing','variant_review_date':D,'source_ids':src,'notes':['Retained outgoing original specification. Zeekr Perth labels stock 0247 New, while Carsales labels the same unit Dealer used. New-vehicle availability is not confirmed and no current factory-order claim is made.'],'price_basis':'','range_cycle':'ADR 81/02 / NEDC','price_aud':None,'range_km':None,'seats':None,'vehicle_class':'passenger','drive':drive}
 p['variants'].append(v)
 c={'id':v['id'],'modelId':mid,'brand':'Zeekr','model':model,'trim':v['trim'],'year':v['model_year'],'generation':p['models'][-1]['generation'],'vehicleClass':'passenger','drive':drive,'availability':'outgoing','availabilityEvidence':{'checkedAt':D,'orderStatus':'unverified','stockStatus':'unverified','sourceIds':src,'qualifications':['Physical stock and factory-order acceptance have not been verified.']},'facts':{}}
 old[c['id']]=c;cars.append(c);effective[c['id']]={}
def ident(c):return {k:c[k] for k in ['id','modelId','brand','model','trim','year','generation','vehicleClass','drive']}
for c in cars:
 if c['id'] not in [v['id'] for v in p['variants']]:p['versionGuards'].append({'variantId':c['id'],'before':ident(c)})
meta={
'price_when_new_aud':['Historical price when new','AUD','Before on-road costs'],'price_aud':['Price','AUD','Before on-road costs'],'range_km':['Range','km','WLTP'],'battery_kwh':['Battery capacity','kWh','Battery capacity; gross/usable unspecified'],'dc_peak_kw':['DC peak charging','kW','Peak DC power'],'dc_charge_time_min':['DC 10–80% charge time','min','10–80%'],'ac_kw':['AC charging power','kW','Maximum AC input'],'seats':['Seats','','Seating capacity'],'boot_l':['Boot volume','L','Rear luggage; all seats in use; method unspecified'],'zero_to_100_s':['0–100 km/h','s','0–100 km/h'],'power_kw':['Motor power','kW','Motor output'],'drive':['Drive type','','Drivetrain'],'length_mm':['Length','mm','Length'],'width_mm':['Width','mm','Width excluding mirrors'],'height_mm':['Height','mm','Height'],'towing_braked_kg':['Braked towing','kg','Maximum braked towing'],'warranty':['Vehicle warranty','','Australian new-vehicle warranty'],'battery_warranty':['Battery warranty','','Australian traction-battery warranty'],'roadside_assistance':['Roadside assistance','','Australian roadside assistance'],
'body_style':['Body style','','Body style'],'frunk_l':['Front storage','L','Front luggage; method unspecified'],'max_total_cargo_l':['Maximum rear cargo','L','Maximum rear cargo; method unspecified'],'rear_cargo_folded_l':['Rear cargo with seats folded','L','Rear luggage; seats folded; method unspecified'],'wheelbase_mm':['Wheelbase','mm','Wheelbase'],'torque_nm':['Torque','Nm','Motor torque'],'dc_test_charger_kw':['DC charging test station','kW','Station output used for charging-time claim'],'dc_source_editorial_peak_kw':['CarExpert editorial DC peak','kW','Reported vehicle peak; CarExpert editorial'],'dc_source_jato_peak_kw':['JATO data DC peak','kW','Reported vehicle peak; JATO via CarExpert'],'towing_source_choice_kg':['CHOICE towing observation','kg','Reported older source braked towing'],'towing_source_nrma_kg':['NRMA towing observation','kg','Reported towing prohibition']}
def fact(c,key,value,sourceKeys,grade='confirmed',reason=None,scope=None,basis=None,comparison=None,condition='',qualifications=None,**extra):
 label,unit,default=meta.get(key,[key,'',key]);scope=scope or ('secondary_or_sibling' if grade=='reported' else 'searched_not_found' if grade=='not_published' else 'exact_au_version')
 ids=[sources[x]['id'] for x in sourceKeys];reason=reason or 'Current Australian maker material explicitly establishes this figure for the named version.'
 f={'key':key,'label':label,'value':value,'unit':unit,'basis':basis or default,'comparisonBasis':default if comparison is None else comparison,'status':{'confirmed':'standard','check':'conditional','reported':'conditional','not_published':'not_verified'}[grade],'sourceIds':ids,'date':D,'market':'AU','scope':'Zeekr '+c['model']+' '+c['trim'],'qualifications':qualifications or ([condition] if condition else []),'issues':[],'buyerGrade':grade,'gradeReview':{'reviewedAt':D,'overlayId':PID,'reason':reason,'evidenceScope':scope,'sourceIds':ids,'sourceLabel':' / '.join(dict.fromkeys(sources[k]['publisher'] for k in sourceKeys))},**extra}
 if condition:f['conditionExplanation']=condition
 if grade=='not_published':f['conditionExplanation']=reason
 if grade=='reported':f['resolvedElsewhere']=True
 assert key not in effective[c['id']], (c['id'],key)
 p['facts'].append({'variantId':c['id'],'before':old[c['id']]['facts'].get(key),'after':f});effective[c['id']][key]=f
 return f
for key in ['warranty','battery_warranty','roadside_assistance']:
 row=terms[key];f=fact(cars[0],key,row['value'],row['sourceKeys'],row['grade'],reason=row['reason'],scope='brand_au_terms',qualifications=row['qualifications'])
 p['facts'].pop();f['scope']='All enumerated official Australian Zeekr X, 7X and 009 versions; private-use baseline with explicit commercial-use and roadside exceptions'
 app=[c for c in cars if not c['id'].startswith('zeekr_x_original')];exceptions=[{'variantId':c['id'],'reason':'The original MY24 vehicle has a conflicting new/used advertisement and unknown original registration policy. Current policy applicability and remaining cover cannot be presumed; original published terms are separately sourced where established.'} for c in cars if c['id'].startswith('zeekr_x_original')]
 p['brandTerms'].append({'key':key,'fact':f,'applicableVariantIds':[c['id'] for c in app],'before':{c['id']:c['facts'].get(key) for c in app},'exceptions':exceptions})
 for c in app:effective[c['id']][key]=f
# Normalized exact-version evidence is deliberately separate from guarded packet representation.
for s in pe['sources']:source(s)
for row in pe['variants']:
 c=old[row['id']]
 if row.get('metadata'):
  a=ident(c);a.update(row['metadata']);p['versionUpdates'].append({'variantId':c['id'],'before':ident(c),'after':a,'reason':row['metadataReason']})
 for rf in row['facts']:
  key=rf['key']
  if key in ['warranty','battery_warranty','roadside_assistance'] and not c['id'].startswith('zeekr_x_original'):continue
  f=fact(c,key,rf['value'],rf['sourceKeys'],rf['grade'],reason=rf.get('reason'),scope=rf.get('scope'),basis=rf.get('basis'),comparison=rf.get('comparison'),condition=rf.get('condition',''),qualifications=rf.get('qualifications'),**({'unit':rf['unit']} if rf.get('unit') else {}))
  if key=='price_aud' and f['value'] is not None:
   rung=rf['priceRung'];basis=f['comparisonBasis'];f['priceEvidence']={'rung':rung,'basisTag':rf.get('basisTag',('Maker’s RRP' if rung==1 else 'Maker’s national price' if rung==2 else 'Maker’s configuration price' if rung==3 else 'Reported by '+sources[rf['sourceKeys'][0]]['publisher'])+' · '+basis.lower()),'sourceKey':'price_aud','sourcePointer':sources[rf['sourceKeys'][0]]['url'],'originalBasis':f['basis'],'rankingEligible':f['buyerGrade'] in ['confirmed','check']}
   if rung>=5:f['priceEvidence']['publisher']=sources[rf['sourceKeys'][0]]['publisher']
 av=row['availability'];ids=[sources[k]['id'] for k in av['sourceKeys']]
 p['availability'].append({'id':PID+'-availability-'+c['id'],'variantId':c['id'],'before':{'availability':c['availability'],'evidence':c['availabilityEvidence']},'after':{'availability':av['state'],'evidence':{'checkedAt':D,'orderStatus':av.get('orderStatus','listed_unconfirmed'),'stockStatus':av.get('stockStatus','unverified'),'sourceIds':ids,'physicalStockVerified':False,'factoryOrderAcceptanceVerified':False,'qualifications':av['qualifications']}},'status':'approved','reviewedBy':REVIEWER,'reviewedAt':D,'evidenceDate':D,'reason':av['reason']})
def feature(c,criterion,value,keys,grade=None,conditions='',reason=None):
 before=next(f for f in prior if f['variant_id']==c['id'] and f['criterion']==criterion);facts=[effective[c['id']][k] for k in keys];ids=list(dict.fromkeys(i for f in facts for i in f['sourceIds']))
 grade=grade or ('reported' if any(f['buyerGrade']=='reported' for f in facts) else 'check' if any(f['buyerGrade']=='check' for f in facts) else 'confirmed')
 after=copy.deepcopy(before)
 for k in ['gradeReviewStatus','confirmation_needed']:after.pop(k,None)
 after.update(status='standard' if grade=='confirmed' else 'conditional',value=value,conditions=conditions,condition_label='Measurement scope' if conditions else '',source_ids=ids,evidence_scope='Reviewed Australian '+c['model']+' '+c['trim'],last_evidence_date=D,reviewed_date=D,verification_state='reviewed_m1_zeekr_2026_10_14',buyerGrade=grade,gradeReview={'reviewedAt':D,'overlayId':PID,'reason':reason or 'Fresh reviewed answer mirrors canonical post-packet facts and their measurement and source qualifications.','evidenceScope':'secondary_or_sibling' if grade=='reported' else 'exact_au_version','sourceIds':ids,'sourceLabel':' / '.join(dict.fromkeys(s['publisher'] for s in p['sources'] if s['id'] in ids))})
 p['features'].append({'variantId':c['id'],'criterion':criterion,'before':before,'after':after,'dependencies':[{'key':f['key'],'expected':f} for f in facts]})
for row in pe['variants']:
 c=old[row['id']];e=effective[c['id']]
 if True:
  feature(c,'performance_rear_motor',f"{e['drive']['value']} · {e['power_kw']['value']} kW",['power_kw','drive'],conditions='Published combined vehicle output; no individual motor outputs have been added together.' if e['drive']['value']=='AWD' else '')
  feature(c,'home_charging',f"Up to {e['ac_kw']['value']} kW AC charging",['ac_kw'],conditions='Requires a suitable supply and installation. No full-charge duration has been estimated from battery capacity.')
  for fr in row.get('features',[]):feature(c,**fr)
 for key in ['warranty','battery_warranty']:pass
 def clause(x):return {'label':x['label'],'text':x['text'],'dependencies':[{'key':k,'expected':e[k]} for k in x['keys']]}
 p['summaries'].append({'variantId':c['id'],'conditions':c.get('configurationEvidence',{}).get('requiredBuyerVisibleConditions',[]),'strength':clause(row['summary']['strength']),'tradeoff':clause(row['summary']['tradeoff'])})
(R/'zeekr-2026-10-14.json').write_text(json.dumps(p,indent=2,ensure_ascii=False)+'\n')
(R/'source-index.json').write_text(json.dumps({'checkedAt':D,'sources':p['sources'],'independentBrandLists':[sources[k] for k in ['model-list-carexpert','model-list-carsguide']],'scope':'Zeekr-only, not a whole-market C1 closure claim'},indent=2,ensure_ascii=False)+'\n')
print('Prepared',len(p['facts']),'specific facts,',len(p['brandTerms']),'shared terms,',len(p['features']),'guarded features,',len(p['sources']),'sources.')
