import json,pathlib,copy
R=pathlib.Path('/tmp/zeekr-research');res={'sources':[],'variants':[]}
for name in ['7x','x','009','outgoing']:
 path=R/name/'evidence.json' if name!='outgoing' else R/'x/outgoing-evidence.json'
 if not path.exists():print('WAITING',path);continue
 p=json.load(open(path));res['sources']+=p['sources']
 for row in p['variants']:
  r=copy.deepcopy(row);r['facts']+=r.pop('extraFacts',[])+r.pop('sourceObservations',[])
  s=r.pop('summaries',r.get('summary',{'strength':r.get('strength',{}),'tradeoff':r.get('tradeoff',{})}));r['summary']={k:{'label':v['label'],'text':v['text'].replace('230kW','230 kW').replace('405km','405 km').replace('365kW','365 kW').replace('100km','100 km'),'keys':v.get('dependencies',v.get('keys'))} for k,v in s.items()}
  for f in r['facts']:
   if f.get('evidenceScope'):f['scope']=f['evidenceScope']
   if f['key'] in ['length_mm','height_mm','width_mm','seats','boot_l'] and f['grade']=='confirmed':f['scope']='explicit_au_range'
   if f['key']=='price_aud' and f.get('priceRung')==1:f['sourceKeys']=[k for k in f['sourceKeys'] if k!='7x_price_2026']
   if f['key']=='boot_l' and name!='outgoing':f['comparison']='';f['qualifications']=f.get('qualifications',[])+['Maker does not establish a VDA/SAE cargo measurement standard; excluded from like-for-like boot ranking.']
   if f['key'] in ['max_total_cargo_l','frunk_l']:f['comparison']=''
  av=r['availability'];av.setdefault('reason','Current maker Australian model page lists all three exact versions with Build & Price links; no physical stock or accepted individual order is verified.');original_av=copy.deepcopy(av);current=av.get('buyerState')=='On sale now' or av.get('state')=='current_or_order_listed';av.update(state='current_or_order_listed' if current else 'outgoing',orderStatus='accepting_orders_advertised' if current and name=='x' else 'listed_unconfirmed' if current else 'unverified',stockStatus='unverified',qualifications=[av['reason'],'No physical stock inspection, accepted individual order, factory allocation or delivery date was verified.'])
  if name=='outgoing':
   reasons={
    'price_aud':'The live Perth dealer offer for stock 0247 is A$58,990 driveaway. The same stock is labelled Dealer used on Carsales, so the offer is Reported without representing it as confirmed new-vehicle supply.',
    'range_km':'The original Australian AWD review and exact dealer specification state 470 km under ADR 81/02 (NEDC). This is separate from WLTP and from the MY26 refresh.',
    'battery_kwh':'The original Australian maker launch states that this X range uses a 66 kWh NCM battery. Gross and usable capacity are not distinguished.',
    'dc_peak_kw':'The original Australian maker launch explicitly gives 150 kW DC charging for the X. This is vehicle capability, not an external station rating.',
    'dc_charge_time_min':'The original Australian maker launch states a 10–80% charge in less than 30 minutes. The published upper bound is preserved as text and is not an exact 30-minute observation.',
    'ac_kw':'The original Australian maker launch explicitly distinguishes 7.2 kW AC for RWD and 11 kW AC for AWD.',
    'seats':'The exact original MY24 AWD RedBook record and Australian range coverage state five seats. Overseas four-seat configurations are outside this source scope.',
    'boot_l':'Australian original-specification sources identify 362 L with the rear seats in place, separately from 1,182 L with them folded. The 404 L MY26 measurement is not imported.',
    'zero_to_100_s':'The original Australian AWD review and exact MY24 guide state a claimed 3.8-second 0–100 km/h time, distinct from the later refresh.',
    'power_kw':'The exact original MY24 RedBook entry explicitly labels 315 kW as Combined Power, corroborated by the Australian AWD review. Individual motor outputs are not added together.',
    'drive':'The original Australian AWD review and exact MY24 entry explicitly identify all-wheel drive.',
    'length_mm':'The exact MY24 guide and original Australian AWD review agree on a 4,432 mm body length.',
    'width_mm':'Original Australian launch coverage distinguishes 1,836 mm excluding mirrors from 2,025 mm including mirrors; the exact MY24 guide agrees on the smaller body width.',
    'height_mm':'The later original AWD review, exact MY24 guide and specific dealer technical sheet agree on 1,572 mm. Earlier preliminary coverage says 1,566 mm; the discrepancy remains qualified and unranked.',
    'towing_braked_kg':'The exact original MY24 AWD guide and dealer technical table explicitly give 1,600 kg braked towing; 750 kg unbraked is a separate rating.',
    'warranty':'The original Australian review and exact MY24 guide establish five years / unlimited kilometres from first registration. This is the original term, not remaining cover for the ambiguously classified Perth vehicle.',
    'battery_warranty':'The original maker Australian launch states eight years / 160,000 km. That source does not establish a retained-capacity threshold, and a later policy is not automatically imported.',
    'price_when_new_aud':'The MY24 guide and May 2025 Australian AWD review record A$62,900 before on-road costs. This is a historical reference, separate from the current specific dealer offer.'}
   for f in r['facts']:
    if f['key'] in reasons:f['reason']=reasons[f['key']]
   r['facts'].append({'key':'roadside_assistance','value':'5 years roadside assistance (original reported term)','grade':'reported','basis':'Original Australian roadside assistance from first registration','comparison':'','sourceKeys':['x-original-carexpert-review'],'reason':'The May 2025 Australian original AWD review explicitly lists five years of roadside assistance. The original policy and registration commencement of the advertised unit are not established.','qualifications':['Reported original new-vehicle term, not five years remaining at resale. First-registration date, eligibility, original programme conditions and remaining cover require confirmation.']})
   r['features']=[{'criterion':'storage','value':'362 L rear boot with the rear seats in place (reported ISO figure)','keys':['boot_l'],'conditions':'This is the original Australian specification, separately reported from the MY26 refresh. Folded-seat and front storage are not included.'}]
   r['summary']['strength']['text']='The original AWD is reported to deliver 315 kW and a 3.8-second 0–100 km/h sprint.'
   r['summary']['tradeoff']={'label':'Original charging ceiling','text':'Its 150 kW DC limit and 11 kW AC charging are the original specification to plan charging around.','keys':['dc_peak_kw','ac_kw']}
   av.update(state='outgoing',orderStatus='unverified',stockStatus='unverified',qualifications=[av['reason'],'Dealer and vehicle-marketplace classifications of the same outgoing unit conflict. New-vehicle availability, physical stock and factory-order acceptance remain unverified; excluded from the on-sale denominator.'])
  if name=='x':
   r['facts'].append({'key':'frunk_l','value':12,'grade':'confirmed','basis':'Front luggage compartment; maker method unspecified','comparison':'','sourceKeys':['x-my26-page'],'reason':'Maker Australian page explicitly gives 12 L front storage separately from 404 L rear boot.','scope':'explicit_au_range'})
   r['facts'].append({'key':'body_style','value':'SUV','grade':'confirmed','basis':'Body style','comparison':'Body style','sourceKeys':['x-my26-page'],'reason':'Maker Australian X page identifies compact electric SUV.'})
   r['features']=[{'criterion':'storage','value':'404 L rear boot with seats in place · 12 L front storage','keys':['boot_l','frunk_l'],'conditions':'Front and rear volumes are separate. Maker cargo measurement standard is unspecified; no combined volume has been calculated.'}]
   if r['trim']=='AWD':r['summary']['tradeoff']={'label':'Charging ceiling','text':'Its 150 kW DC maximum is the charging-power limit to plan around at a rapid charger.','keys':['dc_peak_kw']}
   else:r['summary']['strength']['label']='Road-trip charging'
  if name=='7x':
   black='black_special' in r['id'];drive='AWD' if 'awd' in r['id'] else 'RWD'
   r['metadata']={'year':None if not black else 2026,'generation':'Australian 75/100 kWh 800 V specification' if not black else '2026 Australian Black Special Edition'};r['metadataReason']='The current maker core specification is identified by exact trim and battery; the descriptive inherited MY26 string is not a formal maker model-year. The named 2026 Black edition retains its explicitly reported year.'
   r['facts'].append({'key':'body_style','value':'SUV','grade':'reported' if black else 'confirmed','basis':'Body style','comparison':'Body style','sourceKeys':['7x_black_carexpert'] if black else ['7x_model'],'reason':'Named Australian version is a five-seat SUV.'})
   r['features']=[{'criterion':'storage','value':f"539 L rear boot with seats up · 1,978 L rear cargo with seats folded · {'42' if drive=='AWD' else '62'} L front storage"+(' (reported)' if drive=='AWD' else ' (water capacity)'), 'keys':['boot_l','max_total_cargo_l','frunk_l'],'conditions':'Cargo configurations are separate and not added together. The rear measurement method is unspecified; RWD front volume uses water capacity, while AWD front volume is an Australian review figure.'}]
  if name=='009':
   r['metadata']={'generation':'Australian 116 kWh specification; current six- and seven-seat range'}
   r['metadataReason']='Two simultaneously available maker brochure branches have different test-charger conditions; their file and internal dates do not establish a uniform new model year or powertrain epoch.'
   for f in r['facts']:
    if f['key']=='price_aud':f['reason']='The exact named-trim before-on-road price is published in Australian editorial tables. Current maker page and FWD release omit prices; the linked public configurator exposes only its shell and cloud browser execution was unavailable. Targeted maker release searches produced no higher-rung exact price.'
    if f['key']=='dc_test_charger_kw':f['value']='150 (maker page / S3 brochure); 205 (linked Dato brochure)'
    if f['key']=='towing_braked_kg':f['basis']='Reported braked towing: not permitted to tow (NRMA)';f['comparison']=''
   r['facts'].append({'key':'body_style','value':'People mover','grade':'confirmed','basis':'Body style','comparison':'Body style','sourceKeys':['009_model'],'reason':'Maker Australian 009 model page identifies the exact people-mover body.'})
   r['features']=[{'criterion':'storage','value':'574 L rear luggage with all seats in use','keys':['boot_l','seats'],'conditions':'The same maker luggage capacity is published for the six- and seven-seat versions. Front storage and folded-seat capacity are not included; maker measurement standard is unspecified.'}]
  res['variants'].append(r)
(R/'normalized-evidence.json').write_text(json.dumps(res,indent=2,ensure_ascii=False)+'\n');print('Normalized',len(res['variants']),'versions')
