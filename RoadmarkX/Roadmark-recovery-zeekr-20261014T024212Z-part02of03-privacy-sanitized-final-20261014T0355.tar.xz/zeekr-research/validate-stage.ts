import fs from 'node:fs';
import assert from 'node:assert/strict';
import {catalogue,research,effectiveFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/data.ts';
import {prepareBrandResearch,applyBrandUpdates,applyBrandFeatureUpdates,applyBrandTermFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-updates.ts';
import {loadReportInput} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/load.ts';
import {buildCoverageReport,isOnSale} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/reports.ts';
import {combineM1Reconciliations} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/m1-reconciliation.ts';
import {featureClaim} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/citable.ts';
import {hydratePortablePacks,storePortablePacks} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/portable-packs.ts';
const root='/tmp/zeekr-research/';
const p=JSON.parse(fs.readFileSync(root+'zeekr-2026-10-14.json','utf8'));
const r=JSON.parse(fs.readFileSync(root+'zeekr-reconciliation-2026-10-14.json','utf8'));
const before=JSON.parse(JSON.stringify(catalogue())),rd=JSON.parse(JSON.stringify(research()));
const original=JSON.stringify({before,rd,p});
assert.deepEqual(before.filter(c=>c.brand==='Zeekr'),JSON.parse(fs.readFileSync(root+'before.json','utf8')),'before snapshot must still match current catalogue');
const data=prepareBrandResearch(rd,[p]);const cars=applyBrandUpdates(before,data,[p]);const beforeById=new Map(before.map(c=>[c.id,c]));
const features=cars.flatMap(car=>car.brand==='Zeekr'?applyBrandTermFeatures(car,applyBrandFeatureUpdates(car,effectiveFeatures(beforeById.get(car.id)||car,data),data,[p])):effectiveFeatures(car,data));
for(const car of cars.filter(c=>c.brand==='Zeekr')){
 const rows=features.filter(f=>f.variant_id===car.id);const pack={car,features:rows,sources:data.sources,eligibility:data.update_eligibility.find(r=>r.variant_id===car.id),events:[],configuration:[]};
 const restored=hydratePortablePacks(storePortablePacks({[car.id]:pack}),data.sources)[car.id];assert.deepEqual(JSON.parse(JSON.stringify(restored)),JSON.parse(JSON.stringify(pack)));
 for(const row of p.features.filter((f:any)=>f.variantId===car.id)){
  assert.deepEqual(rows.find(f=>f.criterion===row.criterion),row.after);const claim=featureClaim(restored,row.criterion,row.criterion)!;assert.equal(claim.value,row.after.value);assert.equal(claim.gradeReview?.overlayId,p.id);assert.equal(claim.gradeReviewStatus,undefined);assert.deepEqual(claim.sources.map(s=>s.id),row.after.source_ids);
 }
 if(car.model==='009'){
  assert.equal(typeof car.facts.dc_peak_kw.value,'string');assert.match(String(car.facts.dc_peak_kw.value),/205.*206/);assert.equal(car.facts.dc_peak_kw.buyerGrade,'reported');assert.equal(car.facts.dc_peak_kw.comparisonBasis,'');assert.equal(car.facts.dc_charge_time_min.value,30);assert.match(car.facts.dc_charge_time_min.basis,/10[–-]80/);assert.equal(car.facts.boot_l.value,574);assert.equal(car.facts.seats.value,car.trim.startsWith('6')?6:7);
 }
 if(car.model==='7X'){
  assert.doesNotMatch(rows.find(f=>f.criterion==='home_charging')!.value,/hours|About/);
  assert.doesNotMatch(rows.find(f=>f.criterion==='home_charging')!.conditions,/divided|10\.5|14\.5|3\.5|4\.5/);
 }
 if(car.id.startsWith('zeekr_x_original')){assert.equal(isOnSale(car),false);assert.equal(car.availability,'outgoing');}
}
const input=loadReportInput();input.cars=cars;input.sources=data.sources;input.features=features;input.m1Reconciliation=combineM1Reconciliations(input.m1Reconciliation!,r);
const report=buildCoverageReport(input,'2026-10-14');fs.writeFileSync(root+'staged-report.json',JSON.stringify(report,null,2));fs.writeFileSync(root+'after.json',JSON.stringify(cars.filter(c=>c.brand==='Zeekr'),null,2));fs.writeFileSync(root+'features-after.json',JSON.stringify(features.filter(c=>c.variant_id.startsWith('zeekr_')),null,2));assert.equal(JSON.stringify({before,rd,p}),original,'staging preserves original inputs');
const brand=report.brandProgress.find(x=>x.brand==='Zeekr')!;
console.log(JSON.stringify({researchCompleted:brand.researchCompleted,researchRemaining:brand.researchRemaining,onSaleVersions:brand.onSaleVersions,core:brand.core.map(x=>({key:x.key,grades:x.grades})),currentBodies:brand.currentVersionReviews.map(x=>({model:x.model,versions:x.versions.length})),gaps:report.gaps.filter(x=>x.brand==='Zeekr'),closureIssues:brand.closureIssues,criteria:brand.criteria,features:p.features.length},null,2));
assert.ok(brand.researchCompleted,JSON.stringify(brand.researchRemaining));assert.equal(brand.missingModels,0);assert.equal(brand.unresolvedLeads,0);assert.equal(brand.missingSummaries,0);assert.equal(brand.agedOrInvalidClaims,0);
console.log('PASS: current guards, feature chains/dependencies, citable/portable propagation, immutable inputs, staged report. Global C1-C6 remain separate.');
