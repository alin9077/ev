import urllib.request, concurrent.futures,json,pathlib,hashlib,subprocess
from html.parser import HTMLParser
class Text(HTMLParser):
 def __init__(self):super().__init__();self.parts=[];self.skip=0
 def handle_starttag(self,t,a):
  if t in ['script','style','noscript']:self.skip+=1
  if t in ['p','li','h1','h2','h3','tr','td','br','div']:self.parts.append('\n')
 def handle_endtag(self,t):
  if t in ['script','style','noscript'] and self.skip:self.skip-=1
 def handle_data(self,d):
  if not self.skip:self.parts.append(d)
P=pathlib.Path('/tmp/zeekr-research');(P/'sources').mkdir(exist_ok=True)
urls=[('model-list-maker','https://www.zeekrlife.com/en-au/models/zeekr-7gt/'),('model-list-carexpert','https://www.carexpert.com.au/zeekr'),('model-list-carsguide','https://www.carsguide.com.au/zeekr'),('7gt-timing','https://www.carexpert.com.au/car-news/2027-zeekr-7gt-australian-arrival-timing-locked-in-for-electric-sports-wagon'),('service','https://www.zeekrlife.com/en-au/service/'),('warranty','https://zcms.zeekrlife.com/published/assets/69db768999ef6f7067b88de5729fc40de340be85193f2813f0cc4d4dcce3eac4/Australian-Warranty-Policy.pdf'),('roadside','https://www.datocms-assets.com/130529/1781067092-zeekr-roadside-assistance-t-c-s.pdf')]
def fetch(item):
 key,u=item
 try:
  with urllib.request.urlopen(u,timeout=45) as r:b=r.read();status=r.status;ct=r.headers.get('Content-Type','');final=r.url
  ext='.pdf' if b.startswith(b'%PDF') else '.html';fn=P/'sources'/(key+ext);fn.write_bytes(b)
  if ext=='.pdf':subprocess.run(['pdftotext','-layout',str(fn),str(fn.with_suffix('.txt'))],check=True)
  else:
   h=Text();h.feed(b.decode('utf-8','replace'));txt='\n'.join(t.strip() for t in ''.join(h.parts).splitlines() if t.strip());fn.with_suffix('.txt').write_text('URL: '+u+'\nChecked: 2026-10-14\n\n'+txt)
  return {'key':key,'url':u,'resolvedUrl':final,'checkedAt':'2026-10-14','status':status,'file':str(fn.relative_to(P)),'textFile':str(fn.with_suffix('.txt').relative_to(P)),'sha256':hashlib.sha256(b).hexdigest()}
 except Exception as e:return {'key':key,'url':u,'error':str(e)}
rows=list(concurrent.futures.ThreadPoolExecutor(max_workers=6).map(fetch,urls));(P/'parent-captures.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
