import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const buffer=Buffer.alloc(1024*1024);
export function fileHash(path:string):string {
 const hash=crypto.createHash('sha256'),fd=fs.openSync(path,'r');
 try {let n;while((n=fs.readSync(fd,buffer,0,buffer.length,null))>0)hash.update(buffer.subarray(0,n));}
 finally {fs.closeSync(fd);}
 return hash.digest('hex');
}
export function verifyReplayInputs(root='/tmp/subaru-research/') {
 const manifest=JSON.parse(fs.readFileSync(root+'replay-provenance-manifest.json','utf8'));
 for(const row of manifest.sourceCode)assert.equal(fileHash('/workspace/scratch/586427eef9f2/roadmark-104/'+row.file),row.sha256,'Source/code changed: '+row.file);
 for(const row of manifest.snapshot)assert.equal(fileHash(root+row.file),row.sha256,'Full original snapshot changed: '+row.file);
 return manifest;
}
