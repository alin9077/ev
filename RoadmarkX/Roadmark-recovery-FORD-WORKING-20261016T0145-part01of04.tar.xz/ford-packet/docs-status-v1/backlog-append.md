
- Deferred read-only audit: unknown cargo-method exclusion currently depends on descriptive wording. Inventory equivalent comparison-basis wording and verify actual comparison/ranking behaviour before proposing separately reviewed structured-basis handling; preserve published values and source confidence. No shared-helper change is included in Ford.
