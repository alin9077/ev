# Ford Mustang Mach-E GT AWD (MY23.75 residual)

http://localhost:3000/cars/ford-mustang-mach-e/ford-mustang-mach-e-2023-75-gt-awd
Page updated: 2026-10-14. Individual evidence dates below are retained.

Ford Mustang Mach-E GT AWD (MY23.75 residual), Australian specifications. The six figures below cover listed price, claimed range, DC charging time, cargo space, braked towing and vehicle warranty. Evidence checked 2026-10-15; measurement bases and conditions are shown beside each figure.

## Availability

Ford Mustang Mach-E GT AWD (MY23.75 residual): availability of this exact version — Older / outgoing version; orders: listed_unconfirmed; stock: no_new_stock_verified; basis: Exact Australian version availability; evidence checked 2026-10-15; conditional. Checked 2026-10-15 MY23.75 residual configuration; technical facts use the 18 October 2023 maker specification, not the current MY26 brochure. Confirm the actual vehicle, warranty commencement, open recalls and repair status before signing; listings do not verify physical stock or factory-order acceptance. The MY23.75 GT is advertised in an until-last-unit campaign that includes demonstrator customer categories. Confirm new/demo classification; no exact-MY current numeric price is established. Government recall REC-006732 concerns certain 2023 Mach-E VINs. The two known advertisement VINs could not be checked against the official attachment; no affected or repaired status is claimed. REC-006732 describes potentially detaching rear quarter-glass trim; Ford offers affected owners free authorised-dealer inspection and repair. Confirm exact VIN applicability and completion status; neither is established here.
Source: Ford Australia (AU): https://media.ford.com/content/dam/fordmedia/img/Australia-NewZealand/07-2023/Mach-EFullSpec/Mustang%20Mach-E%20Brochure.pdf (accessed 2026-10-15; published 2023-10-18) | Tait Ford (AU): https://www.taitford.com.au/models/mustang-mach-e (accessed 2026-10-15) | Australian Government Vehicle Recalls (AU): https://www.vehiclerecalls.gov.au/recalls/rec-006732 (accessed 2026-10-15; published 2026-09-28)

## Key facts

Ford Mustang Mach-E GT AWD (MY23.75 residual): published price — Not published; basis: Exact MY23.75 current residual offer price not established; evidence checked 2026-10-15; not published. Tait names MY23.75 GT but shows no numeric price; the separate Q Ford New 2023 GT A$89,000 driveaway ad lacks an established MY suffix and is not bound to this version. Carsales MY23.75 A$97,292 price-when-new is historical guide context, not a current residual offer.
Source: Tait Ford (AU): https://www.taitford.com.au/models/mustang-mach-e (accessed 2026-10-15) | Q Ford (AU): https://www.qford.com.au/cars/new-blue-2023-ford-mustang-mach-e-drx5 (accessed 2026-10-15)

Ford Mustang Mach-E GT AWD (MY23.75 residual): claimed range — 490 km; basis: WLTP combined cycle; evidence checked 2026-10-15; confirmed. Exact named-grade full-charge combined-cycle claim; controlled 23 degrees C without climate or electrical load; real-world range varies.
Source: Ford Australia (AU): https://media.ford.com/content/dam/fordmedia/img/Australia-NewZealand/07-2023/Mach-EFullSpec/Mustang%20Mach-E%20Brochure.pdf (accessed 2026-10-15; published 2023-10-18)

Ford Mustang Mach-E GT AWD (MY23.75 residual): dc 10–80% charging time — 45 min; basis: 10–80% at 150 kW DC charger; evidence checked 2026-10-15; confirmed. Charging duration varies with temperature, state of charge, battery condition and available charger power.
Source: Ford Australia (AU): https://media.ford.com/content/dam/fordmedia/img/Australia-NewZealand/07-2023/Mach-EFullSpec/Mustang%20Mach-E%20Brochure.pdf (accessed 2026-10-15; published 2023-10-18)

Ford Mustang Mach-E GT AWD (MY23.75 residual): cargo behind occupied second row — 402 L; basis: Behind second row, laden to package tray; measurement protocol not stated; evidence checked 2026-10-15; confirmed. Tray height is explicit; VDA or other loading protocol is not established, so this is not used as a like-for-like protocol-matched boot ranking.
Source: Ford Australia (AU): https://media.ford.com/content/dam/fordmedia/img/Australia-NewZealand/07-2023/Mach-EFullSpec/Mustang%20Mach-E%20Brochure.pdf (accessed 2026-10-15; published 2023-10-18)

Ford Mustang Mach-E GT AWD (MY23.75 residual): braked towing — Not published; basis: Australian exact-version braked trailer mass not established; evidence checked 2026-10-15; not published. Maker specification does not establish a braked towing mass. The Driven says not rated for towing in Australia; this categorical statement is not converted to 0 kg.
Source: Ford Australia (AU): https://media.ford.com/content/dam/fordmedia/img/Australia-NewZealand/07-2023/Mach-EFullSpec/Mustang%20Mach-E%20Brochure.pdf (accessed 2026-10-15; published 2023-10-18) | The Driven (AU): https://thedriven.io/2024/01/14/ford-mustang-mach-e-test-drive-is-it-worthy-of-the-galloping-horse-badge/ (accessed 2026-10-15; published 2024-01-14)

Ford Mustang Mach-E GT AWD (MY23.75 residual): vehicle warranty — 5 years / unlimited kilometres base; up to 7 years conditional; basis: Australian Ford new-vehicle warranty policy; evidence checked 2026-10-15; confirmed. Five-year unlimited-kilometre base warranty covers qualifying factory material/workmanship defects under normal Australian use and maintenance; ordinary exclusions and Australian Consumer Law rights remain. Conditional extension to seven years/unlimited kilometres requires eligible Ford warranty commencement on or after 1 September 2026 and every scheduled authorised Ford dealer service within both time and kilometre intervals, including the initial five years and continuing years 6–7; logbook/invoice evidence required. Ford/dealer company cars, demonstrators, service loaners and parts vehicles commence at first Ford/dealer registration; other vehicles at original-owner delivery. An advertised New label or model year does not establish this date or restart cover. Current FAQ body uses warranty commencement from 1 September 2026; its footnote says delivered from that date. Exact retained September policy defines commencement, and this distinction remains visible for residual/demo vehicles. Specific September PDF anchors were retained on 10 October and re-reviewed; fresh PDF retrieval failed. No fresh bytes or new individual entitlement are claimed.
Source: Ford Australia (AU): https://www.ford.com.au/support/how-tos/warranty/warranties-and-coverage/what-is-the-new-vehicle-warranty (accessed 2026-10-15) | Ford Australia (AU): https://www.ford.com.au/content/dam/na/ford/en_au/owners/warranties/ford-new-vehicle-7-year-warranty-sept-2026.pdf (accessed 2026-10-10)

## Does Ford Mustang Mach-E have Apple CarPlay and Android Auto?

Ford Mustang Mach-E GT AWD (MY23.75 residual): Needs confirmation (needs confirmation).

Ford Mustang Mach-E GT AWD (MY23.75 residual): apple carplay and android auto — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-15; needs confirmation. Exact-version equipment research pending.
Source: 

## What real-world range has been measured for Ford Mustang Mach-E?

Ford Mustang Mach-E GT AWD (MY23.75 residual): Needs confirmation (needs confirmation).

Ford Mustang Mach-E GT AWD (MY23.75 residual): independent road-test range — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-15; needs confirmation. Exact-version equipment research pending.
Source: 

## How much does Ford Mustang Mach-E cost to insure?

These benchmarks do not establish the cheaper car for you; check the driver profile, date and tested version before comparing, then obtain quotes for the same cover.

Ford Mustang Mach-E GT AWD (MY23.75 residual): insurance benchmark — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-15; needs confirmation. Exact-version equipment research pending.
Source: 

## What is the driveaway price of Ford Mustang Mach-E?

Ford Mustang Mach-E GT AWD (MY23.75 residual): Needs confirmation (needs confirmation).

Ford Mustang Mach-E GT AWD (MY23.75 residual): driveaway price — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-15; needs confirmation. Exact-version equipment research pending.
Source: 

## How long does Ford Mustang Mach-E take to charge at home?

Ford Mustang Mach-E GT AWD (MY23.75 residual): Needs confirmation (needs confirmation).

Ford Mustang Mach-E GT AWD (MY23.75 residual): home charging — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-15; needs confirmation. Exact-version equipment research pending.
Source: 

## Does Ford Mustang Mach-E use an LFP battery?

Ford Mustang Mach-E GT AWD (MY23.75 residual): Needs confirmation (needs confirmation).

Ford Mustang Mach-E GT AWD (MY23.75 residual): battery chemistry — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-15; needs confirmation. Exact-version equipment research pending.
Source: 

## Can Ford Mustang Mach-E power appliances with V2L?

Ford Mustang Mach-E GT AWD (MY23.75 residual): Needs confirmation (needs confirmation).

Ford Mustang Mach-E GT AWD (MY23.75 residual): vehicle-to-load power — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-15; needs confirmation. Exact-version equipment research pending.
Source: 

## Can this EV qualify for the electric-car FBT exemption?

Eligibility depends on the vehicle, acquisition and employer arrangement; a listed price alone does not confirm an exemption.

Ford Mustang Mach-E GT AWD (MY23.75 residual): fbt eligibility — Exact eligibility needs confirmation; basis: Source audit; evidence checked 2026-10-08; needs confirmation. The listed price alone does not establish FBT eligibility. The May 2026 announcement described proposed changes from April 2027 and April 2029; this audit has not established that those proposals are law. Confirm the current rules, acquisition conditions and taxable value with the ATO and your adviser.
Source: 

Methodology: http://localhost:3000/methodology
Glossary: http://localhost:3000/glossary
