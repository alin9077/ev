# Ford Mustang Mach-E GT AWD

http://localhost:3000/cars/ford-mustang-mach-e/ford-mustang-mach-e-2026-gt-awd
Page updated: 2026-10-14. Individual evidence dates below are retained.

Ford Mustang Mach-E GT AWD, Australian specifications. The six figures below cover listed price, claimed range, DC charging time, cargo space, braked towing and vehicle warranty. Evidence checked 2026-10-15; measurement bases and conditions are shown beside each figure.

## Availability

Ford Mustang Mach-E GT AWD: availability of this exact version — Current listing; orders: listed_unconfirmed; stock: unverified; basis: Exact Australian version availability; evidence checked 2026-10-15; conditional. Checked 2026-10-15 Current named Australian MY26.00 maker configuration; secondary MY26.50 guide labels do not create another version. Confirm the actual vehicle, warranty commencement, open recalls and repair status before signing; listings do not verify physical stock or factory-order acceptance. Government recall REC-006648 concerns certain MY26 Mach-E and Transit VINs; no all-grade, exact-VIN or completed-remedy assertion. REC-006648 describes unintended high-beam activation/deactivation. Ford asks affected owners to arrange dealer work when the resolution is available. Confirm exact VIN applicability and remedy status; no all-grade applicability or completed repair is claimed.
Source: Ford Australia (AU): https://www.ford.com.au/content/dam/Ford/au/nameplate/mach-e/brochure/specs-brochure/fordvf1419-mustang-mach-e-spec-master-05-aug.pdf (accessed 2026-10-15; published 2026-08-05) | Ford Australia (AU): https://www.ford.com.au/showroom/electric/mach-e/ (accessed 2026-10-15) | Ford Australia (AU): https://www.ford.com.au/showroom/electric/mach-e/gt/ (accessed 2026-10-15) | Australian Government Vehicle Recalls (AU): https://www.vehiclerecalls.gov.au/recalls/rec-006648 (accessed 2026-10-15; published 2026-07-01)

## Key facts

Ford Mustang Mach-E GT AWD: published price — A$98,405; basis: Reported by Carsales / RedBook; exact MY26.00 price-when-new guide before on-road costs; evidence checked 2026-10-15; reported. Price-when-new guide for exact MY26.00; includes GST/LCT where applicable and excludes options, dealer delivery, stamp duty and other government charges. It is not a maker quote or a driveaway offer. Current maker price cards did not yield a numeric amount; no location or finance total has been inferred. Unresolved published-price difference: CarExpert dated 29 November 2025 reports A$98,490 before on-road costs; Carsales exact MY26.00 and RedBook MY26.50 show A$98,405. No effective-date supersession is established; both are source-labelled and unranked.
Source: Carsales / RedBook (AU): https://www.carsales.com.au/research/ford/mustang-mach-e/2026/gt/ (accessed 2026-10-15) | Carsales / RedBook (AU): https://www.carsales.com.au/info/price-guide?plainView=true (accessed 2026-10-15) | Ford Australia (AU): https://www.ford.com.au/price/MustangMach-E (accessed 2026-10-15) | CarExpert (AU): https://www.carexpert.com.au/car-news/2026-ford-mustang-mach-e-price-and-specs (accessed 2026-10-15; published 2025-11-29) | RedBook (AU): https://www.redbook.com.au/cars/results/?q=%28C.Make.Ford._.Model.Mustang+Mach-E.%29 (accessed 2026-10-15)

Ford Mustang Mach-E GT AWD: claimed range — 515 km; basis: WLTP combined cycle; evidence checked 2026-10-15; confirmed. Exact named-grade full-charge combined-cycle claim; controlled 23 degrees C without climate or electrical load; real-world range varies.
Source: Ford Australia (AU): https://www.ford.com.au/content/dam/Ford/au/nameplate/mach-e/brochure/specs-brochure/fordvf1419-mustang-mach-e-spec-master-05-aug.pdf (accessed 2026-10-15; published 2026-08-05)

Ford Mustang Mach-E GT AWD: dc 10–80% charging time — 36 min; basis: 10–80% at 150 kW DC charger; evidence checked 2026-10-15; confirmed. Charging duration varies with temperature, state of charge, battery condition and available charger power.
Source: Ford Australia (AU): https://www.ford.com.au/content/dam/Ford/au/nameplate/mach-e/brochure/specs-brochure/fordvf1419-mustang-mach-e-spec-master-05-aug.pdf (accessed 2026-10-15; published 2026-08-05)

Ford Mustang Mach-E GT AWD: cargo behind occupied second row — 402 L; basis: Behind second row, laden to package tray; measurement protocol not stated; evidence checked 2026-10-15; confirmed. Tray height is explicit; VDA or other loading protocol is not established, so this is not used as a like-for-like protocol-matched boot ranking.
Source: Ford Australia (AU): https://www.ford.com.au/content/dam/Ford/au/nameplate/mach-e/brochure/specs-brochure/fordvf1419-mustang-mach-e-spec-master-05-aug.pdf (accessed 2026-10-15; published 2026-08-05)

Ford Mustang Mach-E GT AWD: braked towing — Not published; basis: Australian exact-version braked trailer mass not established; evidence checked 2026-10-15; not published. Maker specification does not establish a braked towing mass. CarsGuide says the 2026 capacity is not yet specified; its zero placeholders are not adopted.
Source: Ford Australia (AU): https://www.ford.com.au/content/dam/Ford/au/nameplate/mach-e/brochure/specs-brochure/fordvf1419-mustang-mach-e-spec-master-05-aug.pdf (accessed 2026-10-15; published 2026-08-05) | CarsGuide (AU): https://www.carsguide.com.au/ford/mustang-mach-e/towing-capacity/2026 (accessed 2026-10-15)

Ford Mustang Mach-E GT AWD: vehicle warranty — 5 years / unlimited kilometres base; up to 7 years conditional; basis: Australian Ford new-vehicle warranty policy; evidence checked 2026-10-15; confirmed. Five-year unlimited-kilometre base warranty covers qualifying factory material/workmanship defects under normal Australian use and maintenance; ordinary exclusions and Australian Consumer Law rights remain. Conditional extension to seven years/unlimited kilometres requires eligible Ford warranty commencement on or after 1 September 2026 and every scheduled authorised Ford dealer service within both time and kilometre intervals, including the initial five years and continuing years 6–7; logbook/invoice evidence required. Ford/dealer company cars, demonstrators, service loaners and parts vehicles commence at first Ford/dealer registration; other vehicles at original-owner delivery. An advertised New label or model year does not establish this date or restart cover. Current FAQ body uses warranty commencement from 1 September 2026; its footnote says delivered from that date. Exact retained September policy defines commencement, and this distinction remains visible for residual/demo vehicles. Specific September PDF anchors were retained on 10 October and re-reviewed; fresh PDF retrieval failed. No fresh bytes or new individual entitlement are claimed.
Source: Ford Australia (AU): https://www.ford.com.au/support/how-tos/warranty/warranties-and-coverage/what-is-the-new-vehicle-warranty (accessed 2026-10-15) | Ford Australia (AU): https://www.ford.com.au/content/dam/na/ford/en_au/owners/warranties/ford-new-vehicle-7-year-warranty-sept-2026.pdf (accessed 2026-10-10)

## Does Ford Mustang Mach-E have Apple CarPlay and Android Auto?

Ford Mustang Mach-E GT AWD: Needs confirmation (needs confirmation).

Ford Mustang Mach-E GT AWD: apple carplay and android auto — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-10; needs confirmation. This exact-trim equipment claim has not yet been researched.
Source: 

## What real-world range has been measured for Ford Mustang Mach-E?

Ford Mustang Mach-E GT AWD: Needs confirmation (needs confirmation).

Ford Mustang Mach-E GT AWD: independent road-test range — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-10; needs confirmation. This exact-trim equipment claim has not yet been researched.
Source: 

## How much does Ford Mustang Mach-E cost to insure?

These benchmarks do not establish the cheaper car for you; check the driver profile, date and tested version before comparing, then obtain quotes for the same cover.

Ford Mustang Mach-E GT AWD: insurance benchmark — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-10; needs confirmation. This exact-trim equipment claim has not yet been researched.
Source: 

## What is the driveaway price of Ford Mustang Mach-E?

Ford Mustang Mach-E GT AWD: Needs confirmation (needs confirmation).

Ford Mustang Mach-E GT AWD: driveaway price — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-10; needs confirmation. This exact-trim equipment claim has not yet been researched.
Source: 

## How long does Ford Mustang Mach-E take to charge at home?

Ford Mustang Mach-E GT AWD: Needs confirmation (needs confirmation).

Ford Mustang Mach-E GT AWD: home charging — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-10; needs confirmation. This exact-trim equipment claim has not yet been researched.
Source: 

## Does Ford Mustang Mach-E use an LFP battery?

Ford Mustang Mach-E GT AWD: Needs confirmation (needs confirmation).

Ford Mustang Mach-E GT AWD: battery chemistry — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-10; needs confirmation. This exact-trim equipment claim has not yet been researched.
Source: 

## Can Ford Mustang Mach-E power appliances with V2L?

Ford Mustang Mach-E GT AWD: Needs confirmation (needs confirmation).

Ford Mustang Mach-E GT AWD: vehicle-to-load power — Needs confirmation; basis: Australian variant research; see conditions; evidence checked 2026-10-10; needs confirmation. This exact-trim equipment claim has not yet been researched.
Source: 

## Can this EV qualify for the electric-car FBT exemption?

Eligibility depends on the vehicle, acquisition and employer arrangement; a listed price alone does not confirm an exemption.

Ford Mustang Mach-E GT AWD: fbt eligibility — Exact eligibility needs confirmation; basis: Source audit; evidence checked 2026-10-08; needs confirmation. The listed price alone does not establish FBT eligibility. The May 2026 announcement described proposed changes from April 2027 and April 2029; this audit has not established that those proposals are law. Confirm the current rules, acquisition conditions and taxable value with the ATO and your adviser.
Source: 

Methodology: http://localhost:3000/methodology
Glossary: http://localhost:3000/glossary
