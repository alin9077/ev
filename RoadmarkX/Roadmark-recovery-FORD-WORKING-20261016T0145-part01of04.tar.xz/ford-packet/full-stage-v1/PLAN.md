# Ford32 bounded full-stage plan v1

Preparation only. One future runtime requires independent readiness, a separate exact root grant and an exclusive heavy slot. No live registration or normal report is included. Full-project TypeScript and release remain UNPASSED; no compiler retry is proposed.

## Frozen facts and selected gate

Use unchanged candidate-v4 typed packet (SHA256 8d728412f21a36aac152357d04793fd38b5efc47438e5210af610f72e868ce00) and only the reviewed reconciliation-v1 successor (SHA256 07531bcbe9d57c9b89647313ced205a60a899dc2aa6c4655db161fec1debdf39). The current maker list is exactly three MY26.00 grades. Three distinct MY23.75 residual rows carry old-epoch facts. The secondary MY26.50 label does not create a seventh identity. The two advertised-New residual rows are eligible on-sale but unresolved for official-list membership; the campaign-only residual GT stays visible/unconfirmed.

The selected runtime passed once: result SHA256 634c0dfe9e55bee49a7ff8408c0ed2d6939660645a45530e8dded7fdf5ca6c42, exit 0, 11.949 seconds, 405080 KiB maximum RSS, empty stderr. Its immutable 24-member output manifest is 694f03460b9684ecd911ce8d23b3f76027e028a0b7495cd48dd7c5b7644c4639. Independent result acceptance is a required separate pinned input before this full-stage manifest may freeze.

The selected pass exercised three existing refreshes plus three actual private-builder additions, 121 fact edits and 18 shared-term applications, three configuration updates, six availability updates and six summary pairs. All 139 packet cells earned their grades; 102 core cells comprise 81 Confirmed, 13 Reported, 7 Not published and 1 Check. Six actual packs contain 414 feature claims. All eleven negative mutations reached intended guards and preserved inputs. There are 294 regular comparisons and nine exact supplemental unknown-cargo tests, with live/written/portable/citable parity and exact producer-owned optional witnesses.

## Reproduce accepted Nissan31 before changing anything

Read the exact 21-file retained storage closure: three recursive indexes, three replacement-car JSON files, base complete-car JSONL and all 14 research streams. Restore retained409/prefix20 once. Assert strict JSON shape before each complete-car and all-field digest. Reproduce accepted corrected21, current22–24, candidate25–31 against Nissan31's accepted complete-car/all14-field artifacts. Record raw producer metadata and the sole composition adjustment of metadata.brand_update_packet_ids.

The before catalogue must be exactly 430 / 353 Tier 1 / 312 on-sale under the actual eligibility functions. Verify the three complete selected cars against the selected before artifact and prove no added ID already exists. Appending the packet must yield exactly 433 / 356 / 314. There must be exactly three changed retained cars, three appended residual cars and 427 complete peers with identical order, identities, facts and digests.

Research assertions cover all fourteen fields. Sources append exactly 27 snapshots, metadata gains three variants and 207 feature rows plus the packet ID, existing variant changes are exactly the guarded configuration/availability edits, and the three actual builder suffixes are exact. All prior context, equipment, feature and update-eligibility rows remain exact, with actual selected-builder additions used as independently retained suffix proofs. Every other research field is unchanged.

Inspect all complete before cars, research, earlier packets and nine raw overlays for any prior reference to the 27 added IDs, including nested reviews and dictionary keys. New source additions must not revive old evidence. No shared helper changes or broad effective-feature replay are allowed.

## Selected replay with complete global context

Retain only three before variants/207 feature rows for the actual zero-fact builder probe. Intercept the real applyAvailabilityCorrections boundary before unknownFacts to observe the actual newVariantCar facts={}, availability and version state. Match exact declared beforeguards. Do not reconstruct or guess a new-car baseline.

Apply the full packet against the reproduced full catalogue, then replay effective-feature, regrading, brand-feature and shared-term consumers only for the six selected cars. Negative mutations use only six variant identities/414 feature rows plus global source and issue context, avoiding full-catalogue cloning. Reproduce all selected complete-car, pack, portable, fact/feature/availability claim, undefined-witness and Markdown artifacts byte-for-byte. Compare selected proof arrays and exact builder evidence; do not accept generic undefined stripping or witness occurrence counts.

Confirm current configuration-wide ranking holds are released only for supported named-grade facts while completeVehicleCountEligible remains false and maker-price holds remain. Reported prices stay unranked. Unknown cargo method and mirror basis remain non-comparable, with boot excluded from rankings. Real selected ranking memberships remain length/range/DC duration five each, seats three, prices/towing/boot zero. Residual GT cannot enter on-sale/current eligibility or any rankings.

## Complete global ranking and C1 structures

For each of seven actual ranking attributes, construct expected complete groups from exact peer entries plus six selected entries. Verify numeric interleaving, rank/tie arithmetic, actual group sorting and insertion-order ties, excluded catalogue traversal order and full unranked alphabetical order. Bind every repeated car to its complete digest. Peer group membership/order and exclusions remain exact even when group sizes alter global order.

Mirror the actual loader's 31 reconciliation import paths without executing the loader. Baseline C1 must exactly equal both the accepted Nissan31 stage output and accepted Nissan normal report: 106 reviewed models / 242 reviewed versions / 187 issues / 65 settled inventory. Expected Ford C1 is 107 / 245 / 186 / 65, still false:
- Append one current maker review and exactly three MY26 reviewed version IDs
- Remove only the three existing Ford version_unreviewed issues
- Insert the two actual selected residual version_unreviewed issues after the existing catalogue-version traversal, preserving complete issue ordering
- Preserve both Ford inventory_unresolved issues and every non-Ford issue/review/disposition exactly
- Preserve all settled-inventory entries; neither Lightning nor the remaining Q3GN epoch question is forced closed
- Append only this reviewed reconciliation's evidence arrays and retain all whole-market published-list gaps

The C1 representation must never relabel a five-row dealer/maker composite as the complete current official list. The residual GT remains outside current-list eligibility. The source identity review retains the Q3GN exact-epoch uncertainty, Lightning official-importer/new-supply uncertainty and current GT guide-price disagreement.

## Closure, limits and outputs

Pin the retained storage, installed Node and runtime packages, transitive local implementation imports, dynamic regrading ledger, registry plus 31 packet files, 31 reconciliation inputs, raw overlays, candidate and identity/reconciliation sources, selected inputs and outputs, reviewer receipts, accepted Nissan stage/normal-report evidence and command files. Inspect the loader source only; production catalogue/data/research/reporting loaders remain blocked.

A proposed single runtime uses Node v24.19.0, 448 MiB old space, 1 MiB semi-space, exposed GC, 420-second timeout and ten-second kill grace, with no automatic retry. The wrapper retains invocation, PID/group, raw wait status, elapsed time, peak RSS and stdout/stderr hashes, plus before/after pins. Only syntax checking has executed during preparation: 64/1 MiB, ten seconds plus two-second kill grace, no imports.

Output complete stage-by-stage car and fourteen-field digests, metadata transitions, storage/read closure, source neutrality, exact selected artifacts/witnesses, complete global rankings, exact expected C1 equality and stage receipt. A later guarded live integration and actual normal report remain separately authorized gates. This stage performs no live edits, registration, canonical recapture, normal report, compiler, build, browser/server, archive, package install or publication.
