# Ford bounded candidate, 15 October 2026

This is a frozen research/typed-data candidate for independent review. It is not applied or execution-approved. No live files, registry, loader, tests, compiler, server, browser, archive or publication were run.

## Proposed buyer change
- Retain three current MY26.00 maker identities. The guide MY26.50 observation does not establish another configuration.
- Add three explicitly older MY23.75 residual grades using old maker technical facts. Select and Premium have exact New-labelled dealer ads; GT has an exact grade campaign with new/demo ambiguity.
- Show source-labelled prices: current Select A$65,990, Premium A$80,490 and GT A$98,405 before on-road costs as Carsales guide observations; GT A$98,490 is retained separately as a CarExpert alternative with unresolved effective-date difference. Residual Select A$59,990 driveaway NSW and Premium A$77,000 driveaway QLD are dealer ads. Residual GT price remains Not published. All Reported prices are unranked.
- Refresh named-grade technical facts and shared base/conditional warranty terms. Do not infer battery capacity-retention cover. Keep cargo protocol, mirror basis and towing limits explicit.
- Remove the obsolete whole-configuration ranking hold for the current three rows using exact guarded dependencies. Frozen source/build history and complete-vehicle-count exclusion remain. Only price_aud, dc_peak_kw and zero_to_100_s scalar holds are released; all maker-price holds stay.

## Open scope
Lightning remains unresolved under manufacturer-or-official-importer eligibility and current new availability. No absence of factory backing is treated as illegal import or proof of exhausted new stock. The unsuffixed New 2025 Select Q3GN lead remains unresolved after bounded exact-page failures. The market reconciliation deliberately leaves both inherited Ford inventory records unresolved. No C1/full-brand/global completion claim is made.

## Provenance and review
The three before rows were selected from retained accepted Nissan31 car artifacts by exact line digests; no broad loader or catalogue hydration. Core facts use current maker linked text or exact older official indexed text; direct old-PDF timeouts are recorded, not claimed as byte success. The September warranty uses exact retained 10 October anchors and original hash, with failed fresh reads explicitly stated. Public rendered factual captures contain no runtime configuration or authenticated material.

Candidate-v1/v2/v3 are superseded preparation artifacts, kept untouched. This candidate includes reviewer source corrections for seats, explicit price basis and alternative citations, old numeric turning circles, true kerb-mass basis, separate roof-height cargo observations, and recall actions. Independent review of this exact frozen candidate is still required. `light-checks.json` describes only bounded Python structure/guard checks; it is not an application, coverage, TypeScript or release PASS.

## Next authorized handoff
Reviewer checks this manifest and both proposed JSON packets. Parent decides whether/when to grant a bounded non-live application validation stage after the heavy slot is available. No compiler retry is proposed. All later changes require a new candidate version and manifest.

Consumer review: cargo method wording is explicitly `method not stated`, recognized by existing ranking and comparison guards. Unknown protocol is not made comparable merely by using an identical label. The residual GT is visible as outgoing with no verified New stock; it does not enter on-sale rankings under the existing availability guard.
