# GWM Australian BEV review — 14 October 2026

## Result
Three advertised versions: ORA 5 SUV Lux and Ultra, plus refreshed 57.7 kWh Ora Lux hatch. The hatch is a separate model/cohort. Manufacturer model years remain unspecified; current SUV build year and dealer-labelled hatch year are not promoted into maker MY claims.

All 51 core cells have current reviews. Private-Victoria driveaway pricing is A$33,990 / A$36,990 for the SUV and A$33,990 for the residual Lux hatch, with exact conditions retained. No physical-stock or factory-order-acceptance promise is made.

## Decisions that matter
- Current 14 October SUV brochure supersedes the earlier combined-body table: Lux has fabric seats and six speakers; Ultra adds leatherette, seat memory, heated/ventilated front seats, heated wheel, panoramic roof, wireless charging, powered tailgate and nine speakers
- SUV range is 435 km WLTC; hatch is 400 km WLTP. Test procedures are not relabelled
- SUV vehicle DC peak is explicitly 120 kW in the Australian launch and braked/unbraked towing is 750 kg. Current brochure charge windows are 10–80% in 30 minutes and 30–80% in 20 minutes
- Hatch 80 kW vehicle peak and zero towing are Reported from exact secondary specifications. Its maker 30–80% / 35-minute claim is retained. The secondary calculated 0.68-hour 10–80% value is separately Reported; direct 10–80% remains Not published
- Minimum/maximum luggage values remain published facts with loading and measurement basis unspecified. No folded-seat basis or cargo ranking is invented
- Warranty is seven years/unlimited km for private use; battery eight years/unlimited km. Commercial, commencement and defect conditions are disclosed
- Current roadside program includes twelve months and service-activated annual renewal up to seven years. Earlier warranty starts, service leeway and exclusions remain visible; an empty EV battery is excluded under the standard terms
- Exact technical omissions receive two-source Not published reviews. Smart Quick Start alone does not establish a no-start-button workflow. Ultra seat memory does not establish cloud or key-linked profiles

## Scope and census
Two complete mixed-powertrain publisher brand directories contain 31 entries, each reconciled to exact Australian scope. This is not a substitute for two whole-market lists. Original 48/63 kWh hatch variants, refreshed GT residuals and the distinct ORA 5 Hatch are unresolved, rather than falsely excluded. Overseas ORA 07/Sport and BEV ute names do not establish current Australian sale. Current Australian Cannon/Alpha diesel/PHEV offerings are not admitted as BEVs. A future-expansion article under an AU URL actually discusses New Zealand.

## Guarded integration
The packet was staged and replayed while unregistered. Root registered the independently approved exact bytes at 09:44 UTC on 14 October 2026; integration checks are running. Two SUV configuration updates preserve exact before states and all immutable source/commercial boundaries. Each releases ten scalar same-key holds with exact current-packet dependencies and retains twenty unrelated legacy holds. Complete-vehicle-count eligibility remains false. The true cargo-method buyer condition remains in both configurations and summaries.

## Evidence and privacy
Source index, full capture hashes, before states, cell matrix, completeness audit and final redaction records accompany the packet. Public PDFs were downloaded in dot’s own cloud browser and rendered locally. Dealer advertisement images are public downloads. No browser screenshot is uploaded; no session cookies, CSRF values, client secrets or challenge identifiers are retained in the persisted captures.

The build-normalized.py and enrich-normalized.py scripts are intermediate working generators; the reviewed normalized-evidence.json plus terms-normalized.json are authoritative final builder inputs. To recreate the packet, run build-packet.py then finish-packet.py. Earlier diagnostic validation logs are not final approval.

## Final replay status
Both the final self-stage and independent replay passed. The full new-version baseline includes canonical price and roadside projections and is bound to the final packet hash. The saved JSON baseline uses a full JSON roundtrip comparison, preserving all serializable rows and values; the earlier undefined-property diagnostic is retained. See registered-immutable-audit.json for the authorized later root registry append. The pre-registration completeness audit and independent replay are preserved byte-for-byte.
