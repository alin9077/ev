"""Build a candidate dated GWM overlay; never edits a registry or historical data."""
import json,pathlib,copy,hashlib,sys,re
R=pathlib.Path('/tmp/gwm-research');D='2026-10-14';BRAND='GWM';PID='m1-gwm-'+D;REVIEWER='Roadmark GWM Australian source review'
def readable(x):
 if isinstance(x,list):return [readable(v) for v in x]
 if isinstance(x,dict):return {k:readable(v) for k,v in x.items()}
 if isinstance(x,str):return re.sub(r'\\u([0-9a-fA-F]{4})',lambda m:chr(int(m.group(1),16)),x)
 return x
load=lambda p:json.loads((R/p).read_text())
cs=load('gwm-live-before.json');old={c['id']:c for c in cs};old_ids=set(old)
prior=load('gwm-feature-before.json')+(load('new-feature-before.json') if (R/'new-feature-before.json').exists() else [])
pe=readable(load('normalized-evidence.json'));terms=readable(load('terms-normalized.json'))
p=dict(schemaVersion=1,id=PID,brand=BRAND,reviewedAt=D,reviewedBy=REVIEWER,sources=[],models=[],variants=[],versionGuards=[],versionUpdates=[],facts=[],features=[],brandTerms=[],availability=[],summaries=[])
sources={};effective={};byid={v['id']:v for v in pe['variants']}
for row in pe['sources']:
 k=row['key']
 if row.get('existingSource'):
  s=copy.deepcopy(row['existingSource']);sources[k]=s
  if not any(x['id']==s['id'] for x in p['sources']):p['sources'].append(s)
  continue
 s={'id':PID+'-'+k,'url':row['url'],'title':row['title'],'publisher':row['publisher'],'source_type':row.get('source_type','manufacturer_au_specification'),'published_date':row.get('published_date'),'accessed_date':row.get('accessed_date',row.get('checkedOn',row.get('checked_on',D))),'market':'AU','supports':row.get('supports',row['title'])}
 for key in ['notes','sourceOriginMarket','access_limitation','capture_section','redactionNote','retrieval','retrievalMethod','retrievedAt','locator','visualReview','published_month','source_capture_note','finalUrl','priorSourceIds','derivation','redactions','rawResponseSha256','retrievalLimitations']:
  if key in row:s[key]=row[key]
 for filekey,loc,hashkey in [('file','capture_locator','capture_sha256'),('textFile','capture_text_locator','capture_text_sha256')]:
  if row.get(filekey):
   f=pathlib.Path(row[filekey]);f=f if f.is_absolute() else R/f;assert f.is_file(),str(f)
   s[loc]=str(f.relative_to(R));s[hashkey]=hashlib.sha256(f.read_bytes()).hexdigest()
 if k in sources:assert sources[k]==s,k
 else:sources[k]=s;p['sources'].append(s)
models=load('gwm-models-before.json');modelids={m['id'] for m in models}
for row in pe['variants']:
 if row['id'] in old:continue
 mid=row['modelId'];gen=row['generation'];av=row['availability'];src=[sources[k]['id'] for k in av['sourceKeys']]
 if mid not in modelids:
  p['models'].append(dict(id=mid,brand=BRAND,model=row['model'],generation=gen,family_id=next((m.get('family_id') for m in models if m['model']==row['model']),row.get('familyId'))));modelids.add(mid)
 v=dict(id=row['id'],model_id=mid,brand=BRAND,model=row['model'],trim=row['trim'],model_year=row.get('modelYear'),record_state=av['state'],variant_review_date=D,source_ids=src,notes=row.get('notes',[]),price_basis='',range_cycle=row.get('rangeCycle','WLTP'),price_aud=None,range_km=None,seats=None,vehicle_class=row.get('vehicleClass','passenger'),drive=row['drive'],brand_update_generation=gen)
 p['variants'].append(v)
 old[v['id']]=dict(id=v['id'],modelId=mid,brand=BRAND,model=v['model'],trim=v['trim'],year=v['model_year'],generation=gen,vehicleClass=v['vehicle_class'],drive=v['drive'],availability=v['record_state'],availabilityEvidence=dict(checkedAt=D,orderStatus='unverified',stockStatus='unverified',sourceIds=src,qualifications=['Physical stock and factory-order acceptance have not been verified.']),facts={})
 cs.append(old[v['id']])
ident=lambda c:{k:c[k] for k in ['id','modelId','brand','model','trim','year','generation','vehicleClass','drive']}
for c in cs:
 effective[c['id']]={}
 if c['id'] in old_ids:p['versionGuards'].append(dict(variantId=c['id'],before=ident(c)))
meta={
'price_aud':('Price','AUD','Before on-road costs'),'promotional_driveaway_aud':('Driveaway offer','AUD','Driveaway'),'range_km':('Range','km','WLTP'),'battery_kwh':('Battery capacity','kWh','Battery capacity; gross/usable unspecified'),'dc_peak_kw':('Peak DC charging acceptance','kW','Peak DC input'),'dc_charge_time_min':('DC 10–80% charge time','min','10–80%'),'ac_kw':('AC charging power','kW','Maximum AC input'),'seats':('Seats','','Seating positions'),'boot_l':('Rear luggage volume','L','Rear luggage; load state and method unspecified'),'zero_to_100_s':('0–100 km/h','s','0–100 km/h'),'power_kw':('Motor power','kW','Motor output'),'drive':('Drive type','','Drivetrain'),'length_mm':('Length','mm','Body length'),'width_mm':('Width','mm','Width; mirror treatment unspecified'),'height_mm':('Height','mm','Body height'),'towing_braked_kg':('Braked towing','kg','Maximum braked towing'),'warranty':('Vehicle warranty','','Australian new-vehicle warranty'),'battery_warranty':('Battery warranty','','Australian traction-battery warranty'),'roadside_assistance':('Roadside assistance','','Australian roadside assistance'),
'wheelbase_mm':('Wheelbase','mm','Wheelbase'),'kerb_weight_kg':('Kerb mass','kg','Kerb mass'),'gvm_kg':('Gross vehicle mass','kg','Gross vehicle mass'),'gross_combination_mass_kg':('Gross combination mass','kg','Gross combination mass'),'ground_clearance_mm':('Ground clearance','mm','Ground clearance'),'towing_unbraked_kg':('Unbraked towing','kg','Maximum unbraked towing'),'towing_unclassified_kg':('Maximum towing (unclassified)','kg','Brake classification unspecified'),'frunk_l':('Front storage','L','Front storage'),'max_total_cargo_l':('Maximum folded cargo','L','Rear cargo with seats folded'),'battery_defect_warranty':('Battery defect warranty','','Australian traction-battery defect warranty'),'warranty_extension':('Warranty extension','','Australian warranty extension'),'charging_offer':('Charging benefit','','Conditional Australian charging offer'),'body_configuration':('Body configuration','','Body configuration'),'payload_kg':('Payload','kg','Published payload'),'turning_circle_m':('Turning circle','m','Turning circle'),'ac_single_phase_kw':('Single-phase AC power','kW','Maximum single-phase AC input'),'battery_usable_kwh':('Usable battery capacity','kWh','Usable battery capacity'),'energy_use_wh_km':('Energy consumption','Wh/km','Manufacturer consumption'),'battery_chemistry':('Battery chemistry','','Battery chemistry'),'dc_test_charger_kw':('DC test charging station','kW','Station output; not vehicle peak'), 'price_when_new_aud':('Historical price when new','AUD','Historical before on-road costs')}
meta.update({'wheel_size_in':('Wheel size','in','Wheel diameter'),'battery_capacity_retention_percent':('Battery capacity threshold','%','Battery capacity guarantee threshold'),'ac_charge_time10to100':('AC 10–100% charge time','min','10–100% AC charging'),'v2l_output_kw':('Vehicle-to-load output','kW','V2L power'),'screen_size_in':('Multimedia display','in','Screen diagonal'),'instrument_display_in':('Instrument display','in','Screen diagonal'),'speaker_count':('Speakers','','Speaker count'),'airbags':('Airbags','','Airbag count'),'wireless_phone_chargers':('Wireless phone chargers','','Charging pad count')})
meta.update({'torque_nm':('Motor torque','Nm','Maximum motor torque'),'battery_voltage_v':('Electrical architecture','V','Nominal electrical system'),'width_with_mirrors_mm':('Width with mirrors','mm','Mirrors extended'),'width_mirrors_folded_mm':('Width with mirrors folded','mm','Mirrors folded'),'running_order_mass_kg':('Running-order mass','kg','Running-order mass; not kerb mass'),'dc_test_station_kw':('DC test charging station','kW','Station rating; not vehicle acceptance'),'ac_charge_time_hours':('AC charging time','h','Specified AC charging window and supply'),'closed_storage_l':('Closed storage compartments','L','Separate closed storage; do not add to published boot')})
for k in ['cargo_open_second_row_up_l','cargo_open_third_row_up_l','cargo_open_seats_folded_l','cargo_max_second_row_up_l','cargo_max_third_row_up_l','cargo_max_seats_folded_l','cargo_front_l','cargo_closed_storage_l']:
 meta[k]=(k.replace('_',' ').replace(' l','').capitalize(),'L','Explicit cargo loading basis')
def fact(c,rf):
 k=rf['key'];grade=rf.get('grade','confirmed');basis=rf.get('basis');oldf=c['facts'].get(k,{})
 label,unit,default=meta.get(k,(oldf.get('label',k.replace('_',' ').capitalize()),oldf.get('unit',''),oldf.get('basis',k.replace('_',' '))))
 src=[sources[x]['id'] for x in rf['sourceKeys']];scope=rf.get('evidenceScope') or ('secondary_or_sibling' if grade=='reported' else 'searched_not_found' if grade=='not_published' else 'exact_au_version')
 f=dict(key=k,label=rf.get('label',label),value=rf['value'],unit=rf.get('unit',unit),basis=basis or default,comparisonBasis=rf.get('comparison',default),status={'confirmed':'standard','check':'conditional','reported':'conditional','not_published':'not_verified'}[grade],sourceIds=src,date=rf.get('date',D),market='AU',scope=rf.get('scope',BRAND+' '+c['model']+' '+c['trim']),qualifications=rf.get('qualifications',[]),issues=[],buyerGrade=grade,gradeReview=dict(reviewedAt=D,overlayId=PID,reason=rf.get('reason','Current Australian manufacturer material establishes this exact-version fact.'),evidenceScope=scope,sourceIds=src,sourceLabel=' / '.join(dict.fromkeys(sources[x]['publisher'] for x in rf['sourceKeys']))))
 if rf.get('condition'):f['conditionExplanation']=rf['condition']
 if grade=='check':assert f.get('conditionExplanation'),(c['id'],k,'Check requires explicit real condition')
 if grade=='not_published':f['conditionExplanation']=f['gradeReview']['reason'];assert f['value'] is None
 if grade=='reported':f['resolvedElsewhere']=True
 for key in ['validUntil','displayValue','roadsideFitment']:
  if rf.get(key) is not None:f[key]=rf[key]
 if k in ['price_aud','promotional_driveaway_aud'] and f['value'] is not None:
  rung=rf['priceRung'];f['priceEvidence']=dict(rung=rung,basisTag=rf.get('basisTag','Maker’s list price' if rung==1 else 'Maker’s national driveaway' if rung==2 else 'Maker’s configuration price' if rung==3 else 'Maker’s state driveaway' if rung==4 else 'Reported by '+sources[rf['sourceKeys'][0]]['publisher'] if rung==5 else 'Dealer advertisement'),sourceKey=k,sourcePointer=rf.get('sourcePointer',sources[rf['sourceKeys'][0]]['url']),originalBasis=rf.get('originalBasis',f['basis']),rankingEligible=rf.get('rankingEligible',grade in ['confirmed','check']))
  if rung>=5:f['priceEvidence']['publisher']=sources[rf['sourceKeys'][0]]['publisher']
  if rung==4:f['priceEvidence']['state']=rf['state']
 assert k not in effective[c['id']],(c['id'],k,'duplicate')
 effective[c['id']][k]=f;p['facts'].append(dict(variantId=c['id'],before=c['facts'].get(k),after=f));return f
for key in ['warranty','battery_warranty','roadside_assistance']:
 t=terms[key];appids=t.get('applicableVariantIds',[c['id'] for c in cs]);apps=[old[i] for i in appids];rf={**t,'key':key,'evidenceScope':'brand_au_terms'}
 f=fact(apps[0],rf);p['facts'].pop();f['scope']=t.get('scope','GWM Australia terms for the explicitly reviewed private-buyer GWM BEV versions; commercial-use and eligibility limits remain disclosed')
 p['brandTerms'].append(dict(key=key,fact=f,applicableVariantIds=appids,before={c['id']:c['facts'].get(key) for c in apps},exceptions=t.get('exceptions',[])))
 for c in apps:effective[c['id']][key]=f
for row in pe['variants']:
 c=old[row['id']]
 if row.get('metadata'):
  a=ident(c);a.update(row['metadata']);p['versionUpdates'].append(dict(variantId=c['id'],before=ident(c),after=a,reason=row['metadataReason']))
 for rf in row['facts']:
  if rf['key'] not in effective[c['id']]:fact(c,rf)
 av=row['availability'];src=[sources[k]['id'] for k in av['sourceKeys']]
 p['availability'].append(dict(id=PID+'-availability-'+c['id'],variantId=c['id'],before=dict(availability=c['availability'],evidence=c['availabilityEvidence']),after=dict(availability=av['state'],evidence=dict(checkedAt=D,orderStatus=av.get('orderStatus','listed_unconfirmed'),stockStatus=av.get('stockStatus','unverified'),sourceIds=src,physicalStockVerified=False,factoryOrderAcceptanceVerified=False,qualifications=av['qualifications'])),status='approved',reviewedBy=REVIEWER,reviewedAt=D,evidenceDate=D,reason=av['reason']))
for row in pe['variants']:
 c=old[row['id']];e=effective[c['id']]
 for fr in row.get('features',[]):
  criterion=fr['criterion']
  if criterion in ['driveaway_price','roadside_assistance']:continue
  m=[f for f in prior if f['variant_id']==c['id'] and f['criterion']==criterion]
  if not m:
   if '--identities-only' in sys.argv:continue
   raise ValueError(('Missing baseline feature',c['id'],criterion))
  before=m[0];deps=[e[k] for k in fr['keys']];ids=list(dict.fromkeys(i for f in deps for i in f['sourceIds']));grade=fr.get('grade') or ('reported' if any(f['buyerGrade']=='reported' for f in deps) else 'check' if any(f['buyerGrade']=='check' for f in deps) else 'confirmed')
  after=copy.deepcopy(before)
  for k in ['gradeReviewStatus','confirmation_needed']:after.pop(k,None)
  after.update(value=fr['value'],status=fr.get('status') or ('standard' if grade=='confirmed' else 'not_verified' if grade=='not_published' else 'conditional'),conditions=(fr.get('conditions') or fr.get('condition') or ''),condition_label='Specific source/fitment condition' if fr.get('conditions',fr.get('condition','')) else '',source_ids=ids,evidence_scope='Reviewed Australian GWM '+c['model']+' '+c['trim'],last_evidence_date=max(f['date'] for f in deps),reviewed_date=D,verification_state='reviewed_m1_gwm_2026_10_14',buyerGrade=grade,gradeReview=dict(reviewedAt=D,overlayId=PID,reason=fr.get('reason','Reviewed equipment answer follows its exact post-packet facts and cited source scope.'),evidenceScope=fr.get('evidenceScope') or ('secondary_or_sibling' if grade=='reported' else 'searched_not_found' if grade=='not_published' else 'exact_au_version'),sourceIds=ids,sourceLabel=' / '.join(dict.fromkeys(s['publisher'] for s in p['sources'] if s['id'] in ids))))
  p['features'].append(dict(variantId=c['id'],criterion=criterion,before=before,after=after,dependencies=[dict(key=f['key'],expected=f) for f in deps]))
 if row.get('summary'):
  def cl(x):return dict(label=x['label'],text=x['text'],dependencies=[dict(key=k,expected=e[k]) for k in x['keys']])
  p['summaries'].append(dict(variantId=c['id'],conditions=row.get('summaryConditions',[]),strength=cl(row['summary']['strength']),tradeoff=cl(row['summary']['tradeoff'])))
(R/'gwm-2026-10-14.json').write_text(json.dumps(p,indent=2,ensure_ascii=False)+'\n')
(R/'gwm-effective-facts.json').write_text(json.dumps(effective,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'newVersions':len(p['variants']),'sources':len(p['sources']),'facts':len(p['facts']),'terms':len(p['brandTerms']),'features':len(p['features']),'summaries':len(p['summaries'])}))
