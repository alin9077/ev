import json,pathlib,hashlib,shutil
R=pathlib.Path('/tmp/gwm-research');REPO=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104');QA=REPO.parent/'roadmark-104-qa';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,o):(R/n).write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n')
copy={'independent-evidence-review.md':QA/'gwm-research-independent-evidence-review.md','independent-review-replay.json':QA/'gwm-independent-review/independent-review-replay.json','independent-review-replay.log':QA/'gwm-independent-review/independent-review-replay.log','independent-review-replay.exit':QA/'gwm-independent-review/independent-review-replay.exit','independent-final-cleanup-delta-check.json':QA/'gwm-independent-review/final-cleanup-delta-check.json','independent-final-capture-privacy-check.json':QA/'gwm-independent-review/final-capture-privacy-check.json'}
for dest,src in copy.items():shutil.copyfile(src,R/dest)
assert (R/'stage-validation.exit').read_text().strip()=='0';assert (R/'independent-review-replay.exit').read_text().strip()=='0'
approved=json.loads((R/'independent-review-replay.json').read_text())['approvedHashes']
for file,h in approved.items():assert sha(R/file)==h,(file,'approved byte drift')
before=json.loads((R/'immutable-data-before.json').read_text());changes=[]
for path,h in before.items():
 current=sha(REPO/path)
 if current!=h:changes.append(dict(path=path,previousSha256=h,currentSha256=current))
assert len(changes)==1 and changes[0]['path']=='data/m1-brand-updates/registry.json',changes
reg=json.loads((REPO/changes[0]['path']).read_text());assert reg['packets'].count('gwm-2026-10-14.json')==1
reg['packets'].remove('gwm-2026-10-14.json');restored=(json.dumps(reg,indent=2,ensure_ascii=False)+'\n').encode();assert hashlib.sha256(restored).hexdigest()==changes[0]['previousSha256']
changes[0].update(reason='Root registered the independently approved exact packet at 09:44 UTC. Removing only the GWM append in memory restores the original registry bytes. Research worker did not edit the registry.',originalRegistryRestoredInMemorySha256=hashlib.sha256(restored).hexdigest())
save('registered-immutable-audit.json',dict(checkedAt='2026-10-14',registrationAt='2026-10-14T09:44:00Z',originalDataFilesUnchanged=len(before)-1,authorizedRootRegistrationChanges=changes,preRegistrationAudit='evidence-completeness-audit.json',preRegistrationAuditPreserved=True,notes='The independently reviewed completeness audit is preserved byte-for-byte as the pre-integration state. This separate audit records the authorized later registry change. Packet and reconciliation remain exactly the approved bytes. Root also updated the report loader to register reconciliation; no research worker shared-code edit.'))
p=R/'integration-readiness.json';j=json.loads(p.read_text());j.update(status='independently-approved-root-registered-integration-checks-running',packetApprovedForGuardedIntegration=True,registered=True,registeredBy='root',registeredAt='2026-10-14T09:44:00Z',selfStageExit=0,independentReplayExit=0,independentReplay='independent-review-replay.json',independentReplaySha256=sha(R/'independent-review-replay.json'),registeredImmutableAudit='registered-immutable-audit.json',requiredNext=['Concluding independent all-artifact hash verification','Root integration validation result','Final immutable recovery backup privacy gate']);save('integration-readiness.json',j)
p=R/'REVIEW.md';s=p.read_text().replace('The packet is staged and unregistered.','The packet was staged and replayed while unregistered. Root registered the independently approved exact bytes at 09:44 UTC on 14 October 2026; integration checks are running.');s+='\n## Final replay status\nBoth the final self-stage and independent replay passed. The full new-version baseline includes canonical price and roadside projections and is bound to the final packet hash. The saved JSON baseline uses a full JSON roundtrip comparison, preserving all serializable rows and values; the earlier undefined-property diagnostic is retained. See registered-immutable-audit.json for the authorized later root registry append. The pre-registration completeness audit and independent replay are preserved byte-for-byte.\n';p.write_text(s)
# Re-scan the newly copied textual review and resulting durable research files.
import re
pat=re.compile(r'(?i)(?:[?&](?:_gl|gclid|fbclid|csrf(?:token)?|access_token|session(?:id)?|token|challenge(?:id)?)=|["\x27]?(?:csrf(?:token)?|access_token|client_secret|session_cookie|cf_chl_[a-z_]+|authorization)["\x27]?\s*[:=]\s*["\x27]?[A-Za-z0-9_./+\-]{8,}|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.)')
scanned=[]
for f in R.rglob('*'):
 if f.is_file() and f.suffix in ['.json','.txt','.log','.md'] and f.name!='artifact-hash-manifest.json':
  assert not pat.search(f.read_text()),str(f);scanned.append(str(f.relative_to(R)))
save('final-privacy-verification.json',dict(checkedAt='2026-10-14',scannedFiles=len(scanned),findings=[],policy='Value-oriented credential/challenge/session query and assignment scan after independent report copies. Source-capture privacy and image provenance remain documented separately.'))
artifacts=[dict(path=str(f.relative_to(R)),bytes=f.stat().st_size,sha256=sha(f))for f in sorted(R.rglob('*'))if f.is_file()and f.name not in ['artifact-hash-manifest.json','final-artifact-verification.json']]
save('artifact-hash-manifest.json',dict(checkedAt='2026-10-14',packetSha256=approved['gwm-2026-10-14.json'],reconciliationSha256=approved['gwm-reconciliation-2026-10-14.json'],files=artifacts,notes='Manifest excludes itself and the subsequent independent final-artifact verification to avoid recursion. All source captures and approved evidence files remain exactly pinned by the independent replay.'))
for name in ['REVIEW.md','integration-readiness.json','registered-immutable-audit.json','final-privacy-verification.json','artifact-hash-manifest.json','stage-validation.log','stage-validation.exit','new-feature-before-manifest.json']:
 shutil.copyfile(R/name,QA/('gwm-research-'+name))
print(json.dumps(dict(status='final sidecars ready for concluding independent hash audit',artifactFiles=len(artifacts),sourceCaptureCount=63,packetSha256=approved['gwm-2026-10-14.json'],registered=True,originalDataFilesUnchanged=len(before)-1,authorizedRegistryChanges=1),indent=2))
