import json,pathlib,copy
R=pathlib.Path('/tmp/gwm-research');p=json.loads((R/'gwm-2026-10-14.json').read_text());old=json.loads((R/'gwm-live-before.json').read_text());ef=json.loads((R/'gwm-effective-facts.json').read_text());pid=p['id'];p['configurationUpdates']=[]
for c in old:
 b=c['configurationEvidence'];a=copy.deepcopy(b)
 release=[k for k in ['price_aud','battery_kwh','ac_kw','dc_peak_kw','boot_l','max_total_cargo_l','towing_braked_kg','towing_unbraked_kg','warranty','battery_warranty'] if k in b.get('requiredNulls',{})]
 deps=[{'key':k,'expected':ef[c['id']][k]}for k in release]
 for k in ['range_km','power_kw','drive','seats','length_mm','width_mm','height_mm','dc_charge_time_min']:
  if k not in release:deps.append({'key':k,'expected':ef[c['id']][k]})
 ids=list(dict.fromkeys(s for d in deps for s in d['expected']['sourceIds']))
 a.update(rankingEligible=True,sourceIds=ids,projectionScope='Current Australian ORA 5 SUV '+c['trim']+' reviewed 14 October 2026. Exact named-grade facts and source-qualified prices may enter like-for-like rankings individually. Manufacturer model year, physical stock, factory-order acceptance and a complete inspected vehicle are not certified.',requiredBuyerVisibleConditions=['Cargo volumes use an unspecified loading and measurement method.'],configurationReview={'overlayId':pid,'reviewedAt':'2026-10-14','historicalBoundaryFields':[],'releasedNulls':[{'key':k,'factKeys':[k]}for k in release]})
 for k in release:a['requiredNulls'].pop(k)
 p['configurationUpdates'].append(dict(variantId=c['id'],before=b,after=a,reason='Fresh exact Australian maker facts replace the obsolete blanket restriction. Each released scalar has exact full current-packet proof; cargo remains a published minimum/maximum with unknown method and no cargo rank. Immutable source identity, original source records, commercial boundaries and remaining holds are preserved.',sourceIds=ids,dependencies=deps))
# Preserve explicit public commercial evidence in the availability snapshots.
for row in p['availability']:
 e=row['after']['evidence'];e['manufacturerAdvertisedNewOffer']=True;e['identifiedNewDealerAdvertisement']=row['after']['availability']=='outgoing';e['factoryBuildSpecificationVerified']=False;e['deliveryToBuyerVerified']=False
# Price display baseline: current fact stays qualified rather than reviving the September observation.
# Source snapshots are recorded once; pre-packet facts/source records remain untouched.
(R/'gwm-2026-10-14.json').write_text(json.dumps(p,indent=2,ensure_ascii=False)+'\n')
print('Finalised candidate:',len(p['facts']),'facts',len(p['features']),'features',len(p['configurationUpdates']),'scope updates')
