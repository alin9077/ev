import json,pathlib,hashlib,re,collections,sys
R=pathlib.Path('/tmp/gwm-research');REPO=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104');QA=REPO.parent/'roadmark-104-qa';D='2026-10-14'
load=lambda f:json.loads((R/f).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,o): (R/n).write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n')
p=load('gwm-2026-10-14.json');e=load('gwm-effective-facts.json');before=load('gwm-live-before.json');norm=load('normalized-evidence.json');core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty','battery_warranty']
packet=REPO/'data/m1-brand-updates/gwm-2026-10-14.json';recon=REPO/'data/m1-gwm-market-reconciliation-2026-10-14.json';assert packet.read_bytes()==(R/'gwm-2026-10-14.json').read_bytes();assert recon.read_bytes()==(R/'gwm-reconciliation-2026-10-14.json').read_bytes()
rows=[dict(variantId=v['id'],model=v['model'],trim=v['trim'],manufacturerModelYear=None,key=k,fact=e[v['id']][k]) for v in norm['variants']for k in core]
gradecounts=dict(collections.Counter(x['fact']['buyerGrade'] for x in rows));save('core-matrix.json',dict(checkedAt=D,packetSha256=sha(packet),coreCells=len(rows),gradeCounts=gradecounts,rows=rows))
source_by_path=collections.defaultdict(list)
for s in p['sources']:
 for k in ['capture_locator','capture_text_locator']:
  if s.get(k):source_by_path[s[k]].append(s['url'])
render={'current/ora5-specs-p16.png':('current/ora5-brochure.pdf',16),'current/ora5-equipment-p17.png':('current/ora5-brochure.pdf',17),'current/ora-hatch-review-17.png':('current/ora-hatch-brochure.pdf',17),'current/ora-hatch-review-18.png':('current/ora-hatch-brochure.pdf',18)}
image_sources={
 'scope/bunbury-71535-photo.jpg': ['https://cdn.images.stock.i-motor.net.au/vehicles/medium/fedea95b-99cf-475f-9bfb-bd86a9e95410-0-dsc-0095.jpg','https://www.bunburygwm.com.au/new-cars/for-sale/gwm/ora/2025/lux/es11/3630927/'],
 'scope/phoenix-c02331-photo.png': ['https://edge.dealerstudio.com.au/photo/29825037/photo/medium-e2549244bd2100ea4ea4ec30df7311dc.png','https://www.phoenixmotors.com.au/cars/new-sun-black-white-roof-2025-gwm-ora-c02331'],
 'scope/phoenix-c44372-photo.png': ['https://edge.dealerstudio.com.au/photo/55738784/photo/medium-39cc7b3ada3258ffa534f9c8c97b1cfc.png','https://www.phoenixmotors.com.au/cars/new-emerald-green-2026-gwm-ora-c44372']
}
captures=[]
for dirname in ['current','scope','spec-check','census']:
 for f in sorted((R/dirname).iterdir()):
  if not f.is_file():continue
  rel=str(f.relative_to(R));istext=f.suffix in ['.json','.txt'];urls=list(source_by_path[rel])+image_sources.get(rel,[])
  if rel in render: urls+=source_by_path[render[rel][0]]
  if istext:
   text=f.read_text();urls+=re.findall(r'https?://[^\s<>"\\\]\)]+',text)
  kind='public downloaded PDF' if f.suffix=='.pdf' else 'local PDF render' if rel in render else 'downloaded public dealer photograph' if f.suffix in ['.jpg','.png'] else 'public-source text snapshot or research extraction'
  item=dict(path=rel,bytes=f.stat().st_size,sha256=sha(f),kind=kind,sourceUrls=list(dict.fromkeys(u.rstrip('.,;')for u in urls)),browserScreenshot=False)
  if rel in render:item.update(parentPdf=render[rel][0],pdfPageNumberOneBased=render[rel][1],renderMethod='Local Poppler rendering, visually inspected; not a browser screenshot')
  captures.append(item)
source_index=dict(checkedAt=D,packetSha256=sha(packet),route='Public web search/open plus dot’s own cloud Chrome for direct linked public PDFs, current configurator and launch text. No user computer, login, CAPTCHA, order or contact submission.',sources=p['sources'],allCaptureFiles=captures,sourcePriorityNotes=['Current SUV brochure edition GWMA 20261014 supersedes the June combined-body table and April launch range/seat-trim wording. April launch is retained only for independently explicit vehicle peak, towing and announced infotainment support.','Current refreshed hatch brochure edition GWMA 20250902 supports technical facts. Its GT column does not establish current GT sale eligibility.','All cited capture hashes refer to final persisted public-content bytes. Before-state source records remain unchanged; no runtime headers or browser session state were collected.'])
save('source-index.json',source_index);save('source-hash-manifest.json',dict(checkedAt=D,root='/tmp/gwm-research',files=captures))
# Scan assignment/query forms, not ordinary public cookie-policy links or discussion of tokens.
pat=re.compile(r'(?i)(?:[?&](?:_gl|gclid|fbclid|csrf(?:token)?|access_token|session(?:id)?|token|challenge(?:id)?)=|["\x27]?(?:csrf(?:token)?|access_token|client_secret|session_cookie|cf_chl_[a-z_]+|authorization)["\x27]?\s*[:=]\s*["\x27]?[A-Za-z0-9_./+\-]{8,}|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.)')
scanned=[];findings=[]
for f in sorted(R.rglob('*')):
 if f.is_file() and f.suffix in ['.json','.txt','.log'] and f.name not in ['source-index.json','source-hash-manifest.json','artifact-hash-manifest.json','redaction-audit.json','final-redaction-transformations.json']:
  scanned.append(str(f.relative_to(R)))
  if pat.search(f.read_text()):findings.append(str(f.relative_to(R)))
assert not findings,findings
save('redaction-audit.json',dict(checkedAt=D,scannedFiles=len(scanned),scannedPaths=scanned,detectedSensitiveCaptureValues=0,policy='Exclude session cookies, challenge identifiers, CSRF values, client secrets, bearer/JWT credentials and runtime tracking identifiers. Retain public site/model/stock identifiers, URLs, VINs already public in dealer advertisements and factual content.',notes=['Public cookie-policy links are not cookies and are retained. Source snapshots contain no request headers, cookie jars or browser storage.','PDFs were downloaded from public maker asset URLs. Their local renders are visual column evidence, not browser screenshots. Dealer photos are public downloaded advertisement images.','Initial direct HTTP transport failures were followed by normal public page reads in dot’s own cloud browser; no access-denial/security-warning or CAPTCHA was bypassed.']))
save('final-redaction-transformations.json',dict(checkedAt=D,finalSensitiveMatches=0,transformations=[dict(scope='scope/*.txt',operation='Capture-time filtering of sensitive/challenge-marker lines before persistence',sourceRecord='scope capture header and manifest.json',removedValueCount=None,originalRawCaptureRetained=False,reason='Original transport/session material was not persisted; exact pre-filter counts are unavailable and are not invented.'),dict(scope='current/*-browser.txt',operation='Visible main/configuration text extraction only; excluded scripts, headers, cookies and unrelated tracking footer links before saving',removedValueCount=None,originalRawCaptureRetained=False),dict(scope='spec-check/*.txt',operation='Public text extraction followed by secret-like assignment/query scan',sourceRecord='spec-check/capture-manifest.json',detectedSecretValues=0),dict(scope='final persisted textual captures and before-state/packet JSON',operation='Final assignment/query/JWT-pattern scan',detectedSecretValues=0)],unchangedFactualEvidence='Public URLs, public site/stock identifiers and vehicle facts are preserved. No final source capture required a further redaction.'))
immutable=load('immutable-data-before.json');changed=[dict(path=f,before=h,after=sha(REPO/f))for f,h in immutable.items()if sha(REPO/f)!=h];assert not changed,changed
retained=[]
for c in before:
 for k,f in c['facts'].items():
  if k not in e[c['id']]:retained.append(dict(variantId=c['id'],key=k,value=f.get('value'),date=f.get('date'),reason='Unchanged historical observation retained with its original date, source and qualification. Not counted as a fresh review; canonical current facts and explicitly refreshed equipment are supplied by this packet.'))
release=[dict(variantId=x['variantId'],releasedKeys=[d['key']for d in x['after']['configurationReview']['releasedNulls']],retainedRequiredNulls=x['after']['requiredNulls'],completeVehicleCountEligible=x['after']['completeVehicleCountEligible'],requiredBuyerVisibleConditions=x['after']['requiredBuyerVisibleConditions'],exactBeforeGuard=True,currentPacketDependencyCount=len(x['dependencies']))for x in p['configurationUpdates']]
extras=[x for x in load('features-after.json')if x.get('gradeReview',{}).get('overlayId')!=p['id']]
save('evidence-completeness-audit.json',dict(checkedAt=D,packetSha256=sha(packet),originalDataFilesUnchanged=len(immutable),originalDataFileChanges=changed,reviewedVersions=3,newVersions=1,coreCells=51,coreGradeCounts=gradecounts,guardedFactEdits=len(p['facts']),brandTerms=3,guardedEquipmentRows=len(p['features']),summaries=3,configurationReleaseAudit=release,retainedHistoricalObservations=retained,remainingNoncoreRows=[dict(variantId=x['variant_id'],criterion=x['criterion'],value=x.get('value'),reason='Outside the supported exact-equipment evidence; left visible without claiming fresh confirmation. Subjective, financial, infrastructure and real-world questions require their own appropriately scoped evidence.')for x in extras],materialCaveats=['Hatch direct 10–80% duration is genuinely not established; maker 30–80% claim and JATO calculated 10–80% value are distinct facts.','Cargo minimum/maximum values have unknown method/loading boundaries and remain unranked.','SUV range is WLTC; hatch range is WLTP. No lab-cycle conversion is made.','Current private-VIC driveaway prices are rung 4 with real buyer/state/build/date conditions. Manufacturer model years remain null.','Battery warranty 70% exclusion is not an unconditional replacement guarantee. Roadside initial inclusion and service/date/use limitations remain explicit.']))
passed='--passed' in sys.argv
save('integration-readiness.json',dict(checkedAt=D,status='self-stage-passed-independent-review-pending'if passed else 'final-self-stage-and-independent-review-running',packetApprovedForGuardedIntegration=False,registered=False,packet=str(packet.relative_to(REPO)),packetSha256=sha(packet),reconciliation=str(recon.relative_to(REPO)),reconciliationSha256=sha(recon),selfStageExit=0 if passed else None,requiredNext=['Independent final-byte evidence and guarded replay approval','Parent-only registry integration and resulting catalogue validation','Final immutable backup privacy gate'],reviewedVersions=3,coreCells=51,sourceSnapshots=len(captures),fullBrandResearchCompleted=False,openCriteria=['C1: residual original hatch and distinct ORA 5 Hatch scope unresolved; whole-market census not claimed','C2: direct hatch DC 10–80% duration not established','C5: unrankable cargo and unresolved direct charge-duration coverage'],notes=['All admitted facts have fresh reviewed grades, including explicit Not published gaps. No fabricated values or blanket residual exclusions.','Narrow legacy-string hold compatibility was independently reviewed by a separate worker; this packet releases only ten exact same-key scalar holds per SUV with current-packet proofs.','Registry edits remain parent-only.']))
md='''# GWM Australian BEV review — 14 October 2026

## Result
Three advertised versions: ORA 5 SUV Lux and Ultra, plus refreshed 57.7 kWh Ora Lux hatch. The hatch is a separate model/cohort. Manufacturer model years remain unspecified; current SUV build year and dealer-labelled hatch year are not promoted into maker MY claims.

All 51 core cells have current reviews. Private-Victoria driveaway pricing is A$33,990 / A$36,990 for the SUV and A$33,990 for the residual Lux hatch, with exact conditions retained. No physical-stock or factory-order-acceptance promise is made.

## Decisions that matter
- Current 14 October SUV brochure supersedes the earlier combined-body table: Lux has fabric seats and six speakers; Ultra adds leatherette, seat memory, heated/ventilated front seats, heated wheel, panoramic roof, wireless charging, powered tailgate and nine speakers
- SUV range is 435 km WLTC; hatch is 400 km WLTP. Test procedures are not relabelled
- SUV vehicle DC peak is explicitly 120 kW in the Australian launch and braked/unbraked towing is 750 kg. Current brochure charge windows are 10–80% in 30 minutes and 30–80% in 20 minutes
- Hatch 80 kW vehicle peak and zero towing are Reported from exact secondary specifications. Its maker 30–80% / 35-minute claim is retained. The secondary calculated 0.68-hour 10–80% value is separately Reported; direct 10–80% remains Not published
- Minimum/maximum luggage values remain published facts with loading and measurement basis unspecified. No folded-seat basis or cargo ranking is invented
- Warranty is seven years/unlimited km for private use; battery eight years/unlimited km. Commercial, commencement and defect conditions are disclosed
- Current roadside program includes twelve months and service-activated annual renewal up to seven years. Earlier warranty starts, service leeway and exclusions remain visible; an empty EV battery is excluded under the standard terms
- Exact technical omissions receive two-source Not published reviews. Smart Quick Start alone does not establish a no-start-button workflow. Ultra seat memory does not establish cloud or key-linked profiles

## Scope and census
Two complete mixed-powertrain publisher brand directories contain 31 entries, each reconciled to exact Australian scope. This is not a substitute for two whole-market lists. Original 48/63 kWh hatch variants, refreshed GT residuals and the distinct ORA 5 Hatch are unresolved, rather than falsely excluded. Overseas ORA 07/Sport and BEV ute names do not establish current Australian sale. Current Australian Cannon/Alpha diesel/PHEV offerings are not admitted as BEVs. A future-expansion article under an AU URL actually discusses New Zealand.

## Guarded integration
The packet is staged and unregistered. Two SUV configuration updates preserve exact before states and all immutable source/commercial boundaries. Each releases ten scalar same-key holds with exact current-packet dependencies and retains twenty unrelated legacy holds. Complete-vehicle-count eligibility remains false. The true cargo-method buyer condition remains in both configurations and summaries.

## Evidence and privacy
Source index, full capture hashes, before states, cell matrix, completeness audit and final redaction records accompany the packet. Public PDFs were downloaded in dot’s own cloud browser and rendered locally. Dealer advertisement images are public downloads. No browser screenshot is uploaded; no session cookies, CSRF values, client secrets or challenge identifiers are retained in the persisted captures.

The build-normalized.py and enrich-normalized.py scripts are intermediate working generators; the reviewed normalized-evidence.json plus terms-normalized.json are authoritative final builder inputs. To recreate the packet, run build-packet.py then finish-packet.py. Earlier diagnostic validation logs are not final approval.
'''
(R/'REVIEW.md').write_text(md)
artifacts=[]
for f in sorted(R.rglob('*')):
 if f.is_file() and f.name!='artifact-hash-manifest.json':artifacts.append(dict(path=str(f.relative_to(R)),bytes=f.stat().st_size,sha256=sha(f)))
save('artifact-hash-manifest.json',dict(checkedAt=D,packetSha256=sha(packet),reconciliationSha256=sha(recon),files=artifacts,notes='Manifest excludes itself. Rebuild after final validation/review records change; source capture hashes are separately immutable.'))
for name in ['REVIEW.md','core-matrix.json','source-index.json','source-hash-manifest.json','redaction-audit.json','final-redaction-transformations.json','evidence-completeness-audit.json','integration-readiness.json','artifact-hash-manifest.json','brand-model-list-reconciliation.json']:
 (QA/('gwm-research-'+name)).write_bytes((R/name).read_bytes())
print(json.dumps(dict(packetSha256=sha(packet),reconciliationSha256=sha(recon),captureFiles=len(captures),coreGrades=gradecounts,unchangedDataFiles=len(immutable),privacyScanFiles=len(scanned),passed=passed),indent=2))
