# Independent GWM evidence and guarded replay review

## Decision
The final dated GWM packet passes independent evidence and guarded-behaviour review for incremental integration. It remains unregistered. This is **not** full GWM research closure or a Tier 1 C1–C6 completion claim. The separate final artifact verification must also pass before registration.

Approved packet SHA256: `76212ed44d9c299a8d646e647bc26ab6026ddcae5de1d5e23fe653d233f79b75`

Approved reconciliation SHA256: `9e5c0a5bfba724b6c890a0a0b6c6bb2c9e4817bb446d1d9be37f29c1ad98f7ab`

The scope is ORA 5 SUV Lux and Ultra plus one separately identified refreshed 57.7 kWh Ora Lux residual hatch. All three manufacturer model years remain null. Neither the SUV offer’s 2026 build condition nor the dealer hatch’s advertised 2025 year is converted into manufacturer model year, an accepted factory order or verified physical stock.

## Source decisions independently checked
- The 14 October Australian SUV brochure’s red dots, dashes and merged cells were visually reviewed. Lux is fabric/6 speakers/manual passenger adjustment/manual tailgate. Ultra has leatherette, three-position driver-seat memory, heated and ventilated front seats, electric passenger adjustment, heated wheel, panoramic roof, 50 W wireless charging, powered tailgate and 9 speakers. Shared equipment includes heat-pump AC and wireless phone mirroring
- The official Australian April launch explicitly establishes vehicle DC acceptance up to 120 kW and 750 kg **braked and unbraked** towing. The current brochure supplies the 10–80%/30-minute charging claim. Its 435 km is WLTC; the hatch’s 400 km is WLTP. No test-cycle conversion or 30–80% substitution is made
- Current SUV prices are A$33,990/A$36,990, maker private-Victoria driveaway offers for the stated base configuration. The 2026-build/order-and-delivery-by-31-October conditions remain. The eligible novated-lease wall charger is a separate conditional benefit
- The retained maker hatch page and Bunbury’s explicitly New stock 71535 support the refreshed Lux residual admission. The full 23.8 MB official hatch brochure was downloaded through dot’s cloud browser and visually checked on PDF pages 17–18. This confirms its heat pump, automatic AC, 360 camera, rear sensors, ISOFIX **presence without an invented count**, and camera-based drowsiness detection
- Hatch 80 kW vehicle peak and zero towing remain Reported secondary figures. Its maker 35-minute claim is 30–80%. The secondary calculated 0.68-hour 10–80% figure is separately labelled Reported; it does not fill or rank as a direct manufacturer/measured charging duration
- Published luggage values are retained without invented VDA, loading height or folded-seat certainty. They remain unranked. Maximum capacity is labelled “Maximum luggage capacity”, not “Maximum folded cargo”
- Vehicle/battery warranty usage exceptions, earlier reported-sold commencement and battery SOH exclusions remain visible. The 70% non-defect clause is not a blanket replacement promise. Roadside has an initial 12 months and eligible-service renewal up to seven years, with date/usage/area conditions and EV out-of-charge exclusion. Included roadside fitment stays separate from the Check evidence grade
- Smart Quick Start alone is not promoted into the no-start-button workflow criterion. Scoped Ultra seat memory does not imply cloud or key-linked profiles. Unknown capabilities remain explicit researched gaps

Primary evidence: [current SUV brochure](https://assets.gwmanz.com/f/256395/x/b36cfaf758/gwma0341-gwm-ora-brochure-au-20261014.pdf), [Australian launch](https://www.gwmanz.com/au/news/gwm-unveils-the-all-new-ora-5-suv-priced-from-just-33-990-driveaway/), [current offers](https://www.gwmanz.com/au/offers/), [retained hatch page](https://www.gwmanz.com/au/models/hatchback/ora/), [hatch brochure](https://assets.gwmanz.com/f/256395/x/6cb11f3ef1/ora_brochure_au.pdf), [Bunbury New advertisement](https://www.bunburygwm.com.au/new-cars/for-sale/gwm/ora/2025/lux/es11/3630927/), [warranty](https://www.gwmanz.com/au/ownership/warranty/), [roadside](https://www.gwmanz.com/au/ownership/roadside-assistance/).

## Guard and actual-output verification
The only production change is the narrow legacy-string recognition in `validateShape` within `brand-configuration-updates.ts`, SHA256 `66e65d559f71bb0ed606e67a01ebeb5ef4d6a1a5d220a280ebbdaa122b256b63`. Nonempty primitive strings are accepted as opaque hold explanations. Exact before-state, retained-text equality, source authority and release-proof rules are unchanged. The implementation worker’s combined guard/feature/parity suite passed 142 tests; TypeScript and targeted lint passed.

The independent final-byte replay verifies:
- 3 exact versions; 251 fact edits; 3 brand terms; 260 reviewed citable facts; 159 equipment rows and 192 exact equipment dependencies
- Two configuration updates, 36 exact current-packet dependencies, and ten **same-key** hold releases per SUV: price, published battery capacity, AC power, DC peak, minimum/maximum luggage, both towing classifications and both warranties
- Twenty unrelated legacy holds retained byte-for-byte on each SUV; original source/build/commercial boundaries and historical feature context unchanged; complete-vehicle-count eligibility still false
- Removing configuration updates, while isolating dependent summaries from that negative fixture, retains the original ranking prohibition. There is no default ranking promotion
- Actual registered-pipeline simulation, current summary visibility, citable source/grade fidelity and exact portable pack roundtrip
- 27 negative mutation classes, including 15 configuration mutations checked at preparation and application; 14 independent ranking source/access/freshness/basis exclusions; 8 attempted promotions of actual secondary facts rejected
- Other brands and Tier 2 unchanged, all previous sources unchanged, all 92 original data files byte-identical, and no input mutation

## Completion limits
C3, C4 and C6 pass for this reviewed brand slice. C1, C2 and C5 do not. Two complete mixed-powertrain publisher directories, containing 31 entries, are reconciled, but are not whole-market C1 lists. Original 48/63 kWh hatch variants, refreshed GT residuals and the distinct ORA 5 Hatch remain unresolved after bounded searches. Overseas model names and local PHEV utes are not admitted as Australian BEVs.

All 51 core cells are reviewed. Every core field is filled for all three versions except direct 10–80% charging time, which is 2/3. Ranking inclusion is price 3/3, range 3/3, charging time 2/3, seats 3/3, boot 0/3 and towing 2/3. The report correctly keeps `researchCompleted` false.

## Diagnostics and final audit
Preserved candidate failures include the initial null charging-time summary dependency and empty guarded summary conditions; both were fixed in data without weakening production guards. Separate harness diagnostics include a stale generated canonical-projection fixture and an initially unisolated no-configuration mutation. Full serialized fixture equality, including price and roadside, is retained. A final semantic cleanup removed one unused newly introduced Ultra profile-null fact; the independent delta check confirms no other packet change.

The bounded independent credential-pattern scan found no matches in all 54 text files among 63 source captures. Binary public PDFs and images have provenance and hashes; this is not an exhaustive security certification. The parent’s final immutable-backup privacy gate remains separate.

Machine evidence is in `gwm-independent-review/independent-review-replay.json`, `final-cleanup-delta-check.json`, `final-capture-privacy-check.json` and the concluding `final-artifact-verification.json`. Full approved hashes are in that final artifact record. No registration, publication or full production-build claim is made by this review.
