import json,re,pathlib
R=pathlib.Path('/tmp/gwm-research');p=json.loads((R/'normalized-evidence.json').read_text());t=json.loads((R/'terms-normalized.json').read_text())
rep={'andfront':'and front','over-the-airupdates':'over-the-air updates','leftnull':'left null','andGT':'and GT','unlimitedkm':'unlimited km','standardterms':'standard terms','excludeEV':'exclude EV','2026build':'2026 build','2025build':'2025 build','80%in':'80% in','100%in':'100% in','maximumvehicle':'maximum vehicle','driverseat':'driver seat','frontseat':'front seat','atleast':'at least','roof/cover':'roof/cover','body/trim':'body/trim','up to6':'up to 6','claimwith':'claim with','first12':'first 12','candidateversion':'candidate version','postpacket':'post-packet','sourcebound':'source-bound','NZsource':'NZ source','currentmaker':'current maker','makerbrochure':'maker brochure','completecurrent':'complete current','actual10':'actual 10','realworld':'real world','only35':'only 35','secondarypeak':'secondary peak','secondaryonly':'secondary only','exactmodel':'exact model','fullmatrix':'full matrix'}
# This pass touches only newly authored prose, never before states or immutable captures.
skip={'id','modelId','familyId','url','file','textFile','sourceKeys','key','keys','criterion','grade','evidenceScope','source_type','priceRung','state','roadsideFitment','status'}
def clean(x,k=''):
 if isinstance(x,str):
  if k in skip or x.startswith(('https:','http:','current/','spec-check/','scope/','/tmp/')):return x
  for a,b in rep.items():x=x.replace(a,b)
  x=re.sub(r'(?<=\d), (?=\d{3}(?:\D|$))',',',x)
  x=re.sub(r'(?<=\d)(?=mm\b)',' ',x)
  x=re.sub(r':(?=[A-Za-z0-9])',': ',x)
  return x
 if isinstance(x,list):return [clean(y,k)for y in x]
 if isinstance(x,dict):return {a:clean(b,a)for a,b in x.items()}
 return x
p=clean(p);t=clean(t)
for v in p['variants']:
 for f in v['facts']:
  if f['key']=='max_total_cargo_l':f['label']='Maximum luggage capacity'
  if f['key']=='ac_kw':f['comparison']='Published AC charging power'
  if f['key']=='dc_test_station_kw':f['label']='Published DC station/rate for charging time'
  if f['key']=='energy_use_kwh_100km':f.update(label='Energy consumption',unit='kWh/100 km')
  if f['key']=='energy_use_wh_km':f.update(label='Energy consumption',unit='Wh/km')
  if f['key']=='ac_charge_0_100_hours':f.update(label='Published AC 0–100% time',unit='h')
  if f['key']=='ac_charge_30_80_hours':f.update(label='Published AC 30–80% time',unit='h')
  if f['key']=='dc_charge_30_80_min':f.update(label='DC 30–80% charging time',unit='min')
  if f['key']=='sos_activation':f['label']='SOS emergency-call activation'
  if f['key']=='charging_offer':f.update(label='Conditional wall-charger offer',value='Complimentary 7 kW wall charger, A$599 RRP including GST; installation excluded')
 if v['trim']=='Ultra':
  for fr in v['features']:
   if fr['criterion']=='driver_profiles_local':fr.update(value='Three-position driver-seat memory and easy-entry function; key-linked or cloud profile recall is not established',keys=['driver_seat_memory_positions'],grade='confirmed',reason='The exact Ultra equipment matrix explicitly lists three driver-seat memory positions and welcome/easy-access function. This answer is scoped to seat memory, not key linkage or cloud recall.')
 v['summary']['strength']['text']=v['summary']['strength']['text'].replace('4,235mm','4,235 mm')
for name,v in [('normalized-evidence.json',p),('terms-normalized.json',t)]: (R/name).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
print('Polished fresh prose and exact measurement labels')
