"""Bounded final verification, retaining registration and the one exact test-only transition."""
import pathlib,json,hashlib,re,subprocess,sys,datetime
R=pathlib.Path('/tmp/subaru-post-registration-review');REPO=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104');QA=REPO.parent/'roadmark-104-qa';Q=QA/'subaru-sequential-checks';D=QA/'brand-feature-paired-snapshot-2026-10-14'
def read(p):return json.loads(pathlib.Path(p).read_text())
def pin(p):
 p=pathlib.Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(262144),b''):h.update(b)
 return {'path':str(p),'sha256':h.hexdigest(),'bytes':p.stat().st_size}
def write(p,value):
 with pathlib.Path(p).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
assert pathlib.Path.cwd()==REPO
mf=R/'registered-inputs.json';mh=pin(mf);assert mh['sha256']=='e8b06b9a80ef79b76b60161d8103589a72464cd6d1722efdcc665a828ff913c4';m=read(mf);assert len(m['executionInputs'])==1235
change=read(D/'change-manifest.json');review=read(D/'independent-review.json');assert pin(D/'independent-review.json')['sha256']=='cc3151327519f6ccfb644d1b760fb32ee680555e1501c8411cbee2ecabc8343c';assert review['status']=='approved_for_root_full_21_test_file_rerun'
target=REPO/'tests/brand-feature-updates.test.ts';before=D/'before-brand-feature-updates.test.ts';after=D/'after-brand-feature-updates.test.ts';assert pin(before)['sha256']==change['beforeSha256']=='621bc163ab584692ec78a9cb7f1e45a1e036a7de3078791231201dc60f098d2c';assert pin(after)['sha256']==pin(target)['sha256']==change['afterSha256']=='e517657e409c8f48f43f443f052570b875eb76bc94891cb8f4b78dfec8cf3056';assert before.read_bytes().count(change['oldExpression'].encode())==1;assert before.read_bytes().replace(change['oldExpression'].encode(),change['newExpression'].encode())==after.read_bytes()
def verify_historical():
 for row in m['executionInputs']:
  if row['path']==str(target):assert row['sha256']==pin(before)['sha256'] and row['bytes']==pin(before)['bytes'];assert pin(target)['sha256']==change['afterSha256']
  else:assert pin(row['path'])==row,row['path']
 assert pin(mf)==mh
verify_historical()
assert not (R/'final-source-inventory.json').exists();subprocess.run([sys.executable,str(QA/'catalogue-snapshot-reuse/hash-inputs.py'),str(R/'final-source-inventory.json')],check=True)
old={r['file']:r for r in read(R/'source-inventory.json')['files']};new={r['file']:r for r in read(R/'final-source-inventory.json')['files']};assert len(old)==len(new)==520;assert set(old)==set(new);assert {p for p in old if old[p]!=new[p]}=={'tests/brand-feature-updates.test.ts'};assert old['tests/brand-feature-updates.test.ts']['sha256']==change['beforeSha256'];assert new['tests/brand-feature-updates.test.ts']['sha256']==change['afterSha256']
terminalNames=['fresh-validation','normal-coverage-asof-2026-10-15','typecheck-736','relevant-tests','brand-feature-isolated-640','brand-feature-paired-640','changed-file-lint'];terminals={n:read(Q/n/'terminal.json') for n in terminalNames};baseline=read(Q/'normal-coverage-asof-2026-10-15/inputs-before.json');paired=read(Q/'brand-feature-paired-640/inputs-before.json');assert len(baseline)==len(paired)==492;assert set(baseline)==set(paired);assert {p for p in baseline if baseline[p]!=paired[p]}=={'tests/brand-feature-updates.test.ts'}
for n in terminalNames:
 t=terminals[n];assert t['inputCount']==492 and t['changedInputs']==[]
 expected=paired if n in ['brand-feature-paired-640','changed-file-lint'] else baseline
 assert read(Q/n/'inputs-before.json')==expected
for rel,h in paired.items():assert pin(REPO/rel)['sha256']==h
for n in ['fresh-validation','normal-coverage-asof-2026-10-15','brand-feature-paired-640','changed-file-lint']:assert terminals[n]['exitCode']==0 and terminals[n]['signal'] is None
assert terminals['typecheck-736']['exitCode']==-9 and terminals['typecheck-736']['signal']==9
for n in ['relevant-tests','brand-feature-isolated-640']:
 assert terminals[n]['exitCode']==1 and terminals[n]['signal'] is None;assert "signal: 'SIGKILL'" in (Q/n/'stdout.log').read_text()
a=(Q/'relevant-tests/stdout.log').read_text();b=(Q/'brand-feature-paired-640/stdout.log').read_text();aa=re.findall(r'^ok \d+ - (.+)$',a,re.M);bb=re.findall(r'^ok \d+ - (.+)$',b,re.M);assert len(aa)==193 and len(bb)==21 and len(set(aa+bb))==214;assert re.findall(r'^not ok \d+ - (.+)$',a,re.M)==['tests/brand-feature-updates.test.ts'];assert not re.findall(r'^not ok ',b,re.M)
for text in [a,b]:
 for k in ['cancelled','skipped','todo']:assert f'# {k} 0\n' in text
fresh=Q/'normal-coverage-asof-2026-10-15/stdout.log';staged=pathlib.Path('/tmp/subaru-staging-plan/candidate/staged-report.json');assert fresh.read_bytes()==staged.read_bytes();assert pin(fresh)['sha256']=='9b6bb08935cc7f569d5d80e1184a547a48eff7f7a4da189b898dc83ca4e0b53d'
parity=R/'fresh-registered-parity-independent-review.json';assert pin(parity)['sha256']=='a5fc44d6441812a5a0799ca5b8a65d0c1356950b82afbe2077519fe59c912cda'
docs=[REPO/'docs/M1_PROGRESS.md',QA/'work-status.json'];assert all(str(p) not in {r['path'] for r in m['executionInputs']} for p in docs)
verify_historical();assert pin(mf)==mh
receipt={'status':'passed_final_subaru_working_integration_gate_review_with_release_gates_open','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'asOf':'2026-10-15','registeredInputManifest':mh,'finalSourceInventory':pin(R/'final-source-inventory.json'),'all1235PostRegistrationPinsPreservedExceptOneReviewedTestHelper':True,'completeSourceInventoryCount':520,'sourcePathsAddedOrRemovedAfterRegistration':0,'productionCodeAndDataUnchangedSinceSuccessfulFreshValidationAndReport':True,'testOnlyTransition':{'target':str(target),'before':pin(before),'after':pin(after),'current':pin(target),'manifest':pin(D/'change-manifest.json'),'independentReview':pin(D/'independent-review.json'),'all21TestBodiesAnd128AssertionCallsUnchanged':True},'gates':{'freshActualStructuralValidation':'passed through unchanged validate.ts entry point with explicit post-import harness GC','normalCoverageCliAt20261015':'passed','completeFreshVersusStagedReportJsonAndBytes':'passed, 1623123 bytes, no filtering or normalization','changedFileLint':'passed for eight listed source/script/test files','relevantTests':'214 distinct tests passed across serial runs: 193 unaffected tests plus the full 21-test brand-feature file','cleanSevenFileAggregateRun':'unpassed; original combined attempt retained with one file-level SIGKILL','completeCurrentTypeScript':'unpassed; full standard tsc736 terminated signal 9 without a successful terminal','currentProductionBuild':'open','broadRegressionAggregate':'open','realDeviceMobileVerification':'open','SubaruC1C5ResearchClosure':'open'},'fullSuitePassClaimed':False,'releaseReady':False,'published':False,'freshFullDataRowForRowLoaderEqualityClaimed':False,'normalReportParityReceipt':pin(parity),'fullFreshReport':pin(fresh),'terminalEvidence':{n:{'terminal':pin(Q/n/'terminal.json'),'stdout':pin(Q/n/'stdout.log'),'stderr':pin(Q/n/'stderr.log'),'inputsBefore':pin(Q/n/'inputs-before.json'),'exitCode':terminals[n]['exitCode'],'signal':terminals[n]['signal'],'elapsedSeconds':terminals[n]['elapsedSeconds'],'maxRssKiB':terminals[n]['maxRssKiB']} for n in terminalNames},'priorFailedTestInterpretation':'Both earlier Node test-runner wrappers exited 1 with no wrapper signal; their brand-feature child file explicitly reported SIGKILL. These remain failed attempts, separate from the later complete 21-test pass. No cause is inferred.','passedTestTitles':{'otherSixFiles':aa,'pairedSnapshotFeatureFile':bb},'documentationUpdates':{'files':[pin(p) for p in docs],'historicalPinScope':'Neither docs/M1_PROGRESS.md nor QA/work-status.json was covered by the immutable 1235-entry post-registration manifest or the 520-file source/data/media/public inventory. Their authorized status-only updates are recorded here as new explicit pins, not silently treated as unchanged historical files.'},'checkScript':pin(__file__)}
out=R/'final-post-registration-gate-addendum.json';write(out,receipt);print(json.dumps(pin(out),indent=2))
