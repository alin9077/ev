"""Verify the exact four-path registration against all immutable pins; prepare report parity inputs."""
import pathlib,json,hashlib,subprocess,sys,datetime
R=pathlib.Path('/tmp/subaru-post-registration-review');REPO=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104');Q=REPO.parent/'roadmark-104-qa';T=Q/'subaru-sequential-checks';OLD=pathlib.Path('/tmp/subaru-staging-review')
def read(p):return json.loads(pathlib.Path(p).read_text())
def pin(p):
 p=pathlib.Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(262144),b''):h.update(b)
 return {'path':str(p),'sha256':h.hexdigest(),'bytes':p.stat().st_size}
assert pathlib.Path.cwd()==REPO
reviewFile=R/'registered-parity-static-review.json';review=read(reviewFile);assert review['status']=='approved_for_exact_registered_report_parity_after_root_slot_release'
required=['registration-inputs.mjs','registered-report-parity.mjs','prepare-registered-inputs.py','registered-report-parity.patch'];assert [pathlib.Path(row['path']).name for row in review['scriptPins']]==required
for row in review['scriptPins']:assert pin(R/pathlib.Path(row['path']).name)==row
old=read(OLD/'independent-replay-inputs.json');assert pin(OLD/'independent-replay-inputs.json')['sha256']=='bee636faa23ece127df7accd9a60f6f336837f8d537920fc0cacf8c37727b834';assert len(old['inputs'])==1214
tr=read(T/'registration-transition.json');assert set(tr['before'])=={'data/m1-brand-updates/registry.json','scripts/reporting/load.ts'};assert set(tr['after'])==set(tr['before'])|{'data/m1-brand-updates/subaru-2026-10-15.json','data/m1-subaru-market-reconciliation-2026-10-15.json'}
assert tr['approvalSha256']==pin(OLD/'subaru-candidate-independent-approval.json')['sha256']=='06cdf4508b1f46daad363b831da1d2697db6c86f54a3c26523209d25052a0f03'
assert tr['after']['data/m1-brand-updates/subaru-2026-10-15.json']=='6a21431aacaee96d10924ec854773c855d64b59d19ab313fa20e2a22f0f39b9c';assert tr['after']['data/m1-subaru-market-reconciliation-2026-10-15.json']=='a58c9d4885128539e47128d1710744a5dacf64e2ad6a2b5cb27198759110b0f4'
inputs={};changed=[]
def add(p,expected=None):
 row=pin(p)
 if expected:assert row['sha256']==expected,(str(p),'hash mismatch')
 if row['path'] in inputs:assert inputs[row['path']]==row
 inputs[row['path']]=row;return row
for row in old['inputs']:
 p=pathlib.Path(row['path']);rel=str(p.relative_to(REPO)) if p.is_relative_to(REPO) else None
 if rel in tr['before']:
  before=T/('registry.json.before' if rel.endswith('registry.json') else 'load.ts.before');assert pin(before)['sha256']==row['sha256']==tr['before'][rel];assert pin(before)['bytes']==row['bytes'];add(before,row['sha256']);after=add(p,tr['after'][rel]);changed.append({'file':rel,'beforeSha256':row['sha256'],'retainedBefore':pin(before),'after':after})
 else:assert pin(p)==row;inputs[row['path']]=row
assert len(changed)==2
for rel,h in tr['after'].items():add(REPO/rel,h)
assert not (R/'source-inventory.json').exists();subprocess.run([sys.executable,str(Q/'catalogue-snapshot-reuse/hash-inputs.py'),str(R/'source-inventory.json')],check=True)
source=read(R/'source-inventory.json');oldsource=read('/tmp/subaru-derived-proof-plan/consumer-current-source-inventory.json');before={r['file']:r for r in oldsource['files']};after={r['file']:r for r in source['files']};assert len(before)==518 and len(after)==520;assert set(after)-set(before)=={'data/m1-brand-updates/subaru-2026-10-15.json','data/m1-subaru-market-reconciliation-2026-10-15.json'};assert not set(before)-set(after)
for file,row in after.items():
 assert row['sha256']==tr['after'].get(file,before.get(file,{}).get('sha256'));assert pin(REPO/file)==dict(path=str(REPO/file),sha256=row['sha256'],bytes=row['bytes']);add(REPO/file,row['sha256'])
for file in [R/'source-inventory.json',R/'prepare-registered-inputs.py',R/'registration-inputs.mjs',R/'registered-report-parity.mjs',R/'registered-report-parity.patch',T/'registration-transition.json',OLD/'independent-replay-inputs.json',OLD/'subaru-candidate-independent-approval.json',OLD/'independent-actual-replay-receipt.json',OLD/'stored-values-verification.json']:add(file)
approval=read(OLD/'subaru-candidate-independent-approval.json')
for key in ['independentActualReplay','independentStoredValues']:
 row=approval['artifacts'][key];assert pin(row['path'])==row;add(row['path'],row['sha256'])
for key in ['actualReplay','storedValues']:
 for name in ['terminal','stdout','stderr']:
  row=approval['measurements'][key][name];assert pin(row['path'])==row;add(row['path'],row['sha256'])
 t=read(approval['measurements'][key]['terminal']['path']);assert t['returncode']==0 and t['signal'] is None
add(reviewFile)
for row in inputs.values():assert pin(row['path'])==row
manifest={'status':'pinned_for_exact_registered_report_parity','asOf':'2026-10-15','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'historicalInputManifest':pin(OLD/'independent-replay-inputs.json'),'historicalInputs':1214,'originalExpectedHashesNotReset':True,'registrationTransition':pin(T/'registration-transition.json'),'independentStaticReview':pin(reviewFile),'changedExistingPaths':changed,'addedPaths':[{'file':f,'sha256':tr['after'][f]} for f in sorted(set(tr['after'])-set(tr['before']))],'sourceInventory':pin(R/'source-inventory.json'),'completeCurrentSourceFiles':520,'executionInputs':sorted(inputs.values(),key=lambda r:r['path']),'freshLoaderValidation':False,'currentFullTypecheckVerified':False,'normalTopLevelReportExecution':False}
out=R/'registered-inputs.json'
with out.open('x') as f:json.dump(manifest,f,indent=2);f.write('\n')
print(json.dumps({'manifest':pin(out),'originalInputPins':1214,'completeCurrentSourceFiles':520,'currentPins':len(inputs),'exactExistingChanges':2,'exactNewFiles':2},indent=2))
