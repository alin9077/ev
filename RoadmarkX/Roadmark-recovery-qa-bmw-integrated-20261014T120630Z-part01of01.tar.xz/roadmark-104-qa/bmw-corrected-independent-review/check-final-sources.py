import json,hashlib,pathlib,re,collections
R=pathlib.Path('/tmp/bmw-research'); Q=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104-qa/bmw-corrected-independent-review'); repo=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104')
def read(p):return json.loads((R/p).read_text())
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(262144),b''):h.update(b)
 return h.hexdigest()
p=read('bmw-2026-10-14.json'); replay=json.loads((Q/'independent-review-replay.json').read_text());manifest=read('source-hash-manifest.json')
sourceById={s['id']:s for s in p['sources']};index=read('source-index.json');assert {s['id'] for s in index}==set(sourceById)
for row in index:
 source=sourceById[row['id']]
 for key,value in row.items(): assert value==(source.get('sourceOriginMarket',source.get('market')) if key=='originMarket' else source.get(key)),(row['id'],key)
captures=set()
for s in p['sources']:
 for key,hashkey in [('capture_locator','capture_sha256'),('capture_text_locator','capture_text_sha256')]:
  if s.get(key):
   rel=s[key];assert (R/rel).resolve().is_relative_to(R); assert sha(R/rel)==s[hashkey]==manifest[rel];captures.add(rel)
assert captures==set(manifest)
for local,staged in [('bmw-2026-10-14.json','data/m1-brand-updates/bmw-2026-10-14.json'),('bmw-reconciliation-2026-10-14.json','data/m1-bmw-market-reconciliation-2026-10-14.json')]: assert sha(R/local)==sha(repo/staged)==replay['approvedHashes'][local]
expected={(r['id'],r['key']):(r['value'],r['grade'],r['basis']) for r in replay['coreRows']}
actual={(r['variantId'],r['key']):(r['value'],r['grade'],r['comparisonBasis']) for r in read('core-matrix.json')['cells']}; assert expected==actual
assert dict(collections.Counter(r['grade'] for r in replay['coreRows']))==read('evidence-completeness-audit.json')['coreGrades']
rec=read('bmw-reconciliation-2026-10-14.json');companion=read('brand-model-list-reconciliation.json');assert rec['publishedLists']==[];assert len(rec['currentVersionReviews'])==6;assert len(companion['allSourceBoundCohortReviews'])==10;assert not companion['wholeMarketClosureEstablished'];assert not companion['fullBrandResidualVersionClosureEstablished']
privacy=read('privacy-review.json');paths=set(privacy['captureFilesScanned'])|captures|{'bmw-2026-10-14.json','bmw-reconciliation-2026-10-14.json','brand-model-list-reconciliation.json','source-index.json','core-matrix.json'}
patterns={'jwt':r'eyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}','bearer':r'(?i)\bBearer\s+[A-Za-z0-9_./+-]{20,}','private_key':r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----','aws_key':r'\bAKIA[0-9A-Z]{16}\b','google_key':r'\bAIza[0-9A-Za-z_-]{30,}\b'}
findings=[];scanned={}
for rel in sorted(paths):
 path=R/rel;assert path.resolve().is_relative_to(R);assert path.exists(),rel
 if path.suffix.lower() not in ['.json','.txt','.html','.md']:continue
 text=path.read_text(errors='replace');scanned[rel]=sha(path)
 for name,pattern in patterns.items():
  if re.search(pattern,text):findings.append({'path':rel,'pattern':name})
assert not findings,findings
images=[]
for path in R.rglob('*.png'):
 rel=str(path.relative_to(R)); sources=[]
 if rel.startswith('census/global-ix4-tech-'): sources=['census/global-ix4-656880.pdf']
 elif rel=='ix/spec-page2.png':sources=['ix/current-spec.pdf']
 elif rel.startswith('compact/'):sources=['compact/'+path.name.split('-p')[0]+'-current.pdf']
 elif path.name=='source-contact-sheet.png':sources=['sedans/bmw_i4_spec.pdf','sedans/bmw_i5_spec.pdf','sedans/bmw_i7_spec.pdf']
 elif rel.startswith('sedans/pdf-renders/'):sources=['sedans/bmw_'+path.name.split('-')[0]+'_spec.pdf']
 assert sources,rel
 images.append({'path':rel,'sha256':sha(path),'role':'local PDF page render/contact sheet, not browser screenshot','sourcePdfs':[{'path':p,'sha256':sha(R/p)} for p in sources]})
for name,h in replay['approvedHashes'].items():assert sha(R/name)==h,name
result={'status':'passed','checkedAt':'2026-10-14','packetSha256':sha(R/'bmw-2026-10-14.json'),'reconciliationSha256':sha(R/'bmw-reconciliation-2026-10-14.json'),'sourceCount':len(p['sources']),'uniqueCitedCaptures':len(captures),'sourceIndexMetadataProjectionMatchesPacket':True,'sourceManifestExactSet':True,'allSourceHashesVerified':True,'stagedFilesEqualReviewedBytes':True,'coreMatrixFullValueGradeBasisParity':True,'privacyTextFilesChecked':len(scanned),'privacyFileHashes':scanned,'privacyFindings':findings,'privacyScope':'Bounded pattern review of public research captures and final artifacts. Not a general security certification. No user personal information was supplied to these public pages; 3000 is a generic example postcode. No browser screenshot was included or uploaded.','images':images,'census':{'currentOrListedVersions':9,'announcedVersions':6,'currentBodyCodeCohorts':10,'runtimeOnSaleCohortReviews':6,'residualCohortsLeftOpen':len(companion['unresolvedResidualCohorts']),'wholeMarketC1Claimed':False},'strictCriteria':read('staged-report.json')['criteria']}
(Q/'final-source-value-privacy-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['privacyFileHashes','strictCriteria']},indent=2))
