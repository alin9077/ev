import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {StringDecoder} from 'node:string_decoder';
import {catalogue,research,effectiveFeatures,pack} from '../roadmark-104/src/lib/data.ts';
import {prepareBrandResearch,applyBrandUpdates,applyBrandFeatureUpdates,applyBrandTermFeatures,brandVersionSnapshot,type BrandUpdatePacket} from '../roadmark-104/src/lib/brand-updates.ts';
import {brandUpdatePackets} from '../roadmark-104/src/lib/brand-update-registry.ts';
import {compiledSource} from '../roadmark-104/tests/helpers/compiled-source.ts';
import {hasEarnedBuyerGrade} from '../roadmark-104/src/lib/evidence-grading.ts';
import {factClaim,featureClaim} from '../roadmark-104/src/lib/citable.ts';
import {storePortablePacks,hydratePortablePacks} from '../roadmark-104/src/lib/portable-packs.ts';
import {coreFacts} from '../roadmark-104/scripts/reporting/reports.ts';
import {rankAttribute} from '../roadmark-104/src/lib/discovery.ts';
import {currentBuyerSummary} from '../roadmark-104/src/lib/selling-points.ts';
import {buyerAvailability} from '../roadmark-104/src/lib/buyer-availability.ts';
import {factFreshness} from '../roadmark-104/src/lib/freshness.ts';

const R='/tmp/bmw-research', Q=path.resolve('../roadmark-104-qa/bmw-corrected-independent-review');
process.on('exit',code=>{fs.mkdirSync(Q,{recursive:true});fs.writeFileSync(path.join(Q,'replay-resource-usage.json'),JSON.stringify({exitCode:code,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()},null,2)+'\n');});
const read=(f:string)=>JSON.parse(fs.readFileSync(path.join(R,f),'utf8'));
const plain=<T>(v:T):T=>JSON.parse(JSON.stringify(v));
const sha=(file:string)=>{const hash=crypto.createHash('sha256'),fd=fs.openSync(file,'r'),buffer=Buffer.alloc(262144);try{let n;while((n=fs.readSync(fd,buffer,0,buffer.length,null)))hash.update(buffer.subarray(0,n));}finally{fs.closeSync(fd);}return hash.digest('hex');};
const digest=(value:unknown)=>{
 const hash=crypto.createHash('sha256');
 const write=(v:any):void=>{if(Array.isArray(v)){hash.update('[');v.forEach((x:any,i:number)=>{if(i)hash.update(',');write(x===undefined?null:x);});hash.update(']');}else if(v&&typeof v==='object'){hash.update('{');let comma=false;for(const key of Object.keys(v)){if(v[key]===undefined)continue;if(comma)hash.update(',');comma=true;hash.update(JSON.stringify(key)+':');write(v[key]);}hash.update('}');}else hash.update(JSON.stringify(v)??'null');};
 write(value);return hash.digest('hex');
};
const packetFile='bmw-2026-10-14.json';
assert(process.env.BMW_APPROVED_PACKET_SHA256,'Final packet hash must be supplied explicitly');
assert.equal(sha(path.join(R,packetFile)),process.env.BMW_APPROVED_PACKET_SHA256,'Final reviewed bytes changed');
const artifacts=[packetFile,'bmw-reconciliation-2026-10-14.json','brand-model-list-reconciliation.json','core-matrix.json','source-index.json','source-hash-manifest.json','evidence-completeness-audit.json','new-feature-before.json','new-feature-before-manifest.json','canonical-baseline-meta.json','replay-snapshot-index.json','replay-snapshot-manifest.json','privacy-review.json','browser-attempts.json','review/browser-source-provenance.json','source-classification-transition.json','historical-source-reclassification/bmw-2026-10-14.before.json'].filter(f=>fs.existsSync(path.join(R,f)));
const approvedHashes=Object.fromEntries(artifacts.map(f=>[f,sha(path.join(R,f))]));
const codeHashes=Object.fromEntries(['src/lib/brand-configuration-updates.ts','src/lib/brand-updates.ts','src/lib/types.ts','src/lib/data.ts','src/lib/brand-update-registry.ts'].map(f=>[f,sha(f)]));
const p=read(packetFile) as BrandUpdatePacket;
const priorCodeReviewFile=path.resolve('../roadmark-104-qa/gac-independent-review/independent-review-replay.json');
const priorCodeReviewSha256=sha(priorCodeReviewFile);const priorCodeReview=JSON.parse(fs.readFileSync(priorCodeReviewFile,'utf8'));
assert.equal(priorCodeReview.status,'passed');assert.deepEqual(codeHashes,priorCodeReview.codeHashes,'Pipeline code changed since pre-BMW independent review');
const transition=read('source-classification-transition.json');
assert.equal(transition.candidatePacketSha256,process.env.BMW_APPROVED_PACKET_SHA256);
assert.equal(sha(path.join(R,transition.approvedBeforePacketPath)),transition.approvedPacketSha256);
const previousPacket=read(transition.approvedBeforePacketPath) as BrandUpdatePacket;
const reverted=structuredClone(p);assert.equal(reverted.sources[70].id,transition.sourceId);assert.equal(reverted.sources[70].source_type,'manufacturer_overseas_reported');reverted.sources[70].source_type=transition.oldSourceType;assert.deepEqual(reverted,previousPacket,'Only authorized source type changed');
assert.equal(digest({...p,features:[]}),transition.candidateCanonicalHash);assert.equal(digest({...previousPacket,features:[]}),transition.originalCanonicalHash);
const originalReview=JSON.parse(fs.readFileSync(path.resolve('../roadmark-104-qa/bmw-independent-review/independent-review-replay.json'),'utf8'));
for(const [file,entry]of Object.entries(transition.baselineArtifacts) as [string,{sha256:string}][]){assert.equal(sha(path.join(R,file)),entry.sha256);assert.equal(entry.sha256,originalReview.approvedHashes[file],'Original baseline bytes changed');}
if(p.variants.length){const manifest=read('new-feature-before-manifest.json');assert.equal(manifest.finalPacketSha256,transition.approvedPacketSha256);assert.equal(manifest.fixtureSha256,sha(path.join(R,'new-feature-before.json')));assert.equal(manifest.baselineGenerationCount,1);const canonical=read('canonical-baseline-meta.json');assert.equal(canonical.canonicalHash,transition.originalCanonicalHash);assert.equal(canonical.featureRows,read('new-feature-before.json').length);assert.deepEqual([...canonical.newIds].sort(),p.variants.map(v=>v.id).sort());}
const basePackets=brandUpdatePackets.filter(q=>q.id!==p.id);assert.equal(brandUpdatePackets.length,basePackets.length+1);assert.deepEqual(brandUpdatePackets.find(q=>q.id===p.id),p,'Registered bytes differ from candidate');
const baselineApi=compiledSource('src/lib/data.ts',{'./brand-update-registry':{brandUpdatePackets:basePackets}}) as {effectiveFeatures:typeof effectiveFeatures};
const baselineFeatures=baselineApi.effectiveFeatures;
assert(process.env.BMW_BASELINE_SNAPSHOT_INDEX,'Corrected replay must retain original complete pre-BMW snapshot');
console.log('Loading immutable current catalogue and final candidate');
const snapshotHashes:Record<string,string>={};
const loadCurrentSnapshot=()=>{
 const indexFile=process.env.BMW_BASELINE_SNAPSHOT_INDEX!;const file=path.resolve(R,indexFile);assert(file.startsWith(R+'/'));snapshotHashes[indexFile]=sha(file);const index=read(indexFile);
 const rows=(locator:string)=>{const f=path.resolve(R,locator);assert(f.startsWith(R+'/'));snapshotHashes[locator]=sha(f);const fd=fs.openSync(f,'r'),buffer=Buffer.alloc(262144),decoder=new StringDecoder('utf8'),result:any[]=[];let pending='';const processLines=()=>{let split;while((split=pending.indexOf('\n'))>=0){const line=pending.slice(0,split);pending=pending.slice(split+1);if(line)result.push(JSON.parse(line));}};try{let n;while((n=fs.readSync(fd,buffer,0,buffer.length,null))){pending+=decoder.write(buffer.subarray(0,n));processLines();}pending+=decoder.end();processLines();if(pending.trim())result.push(JSON.parse(pending));}finally{fs.closeSync(fd);}return result;};
 const rd:any={};for(const [key,entry] of Object.entries(index.research) as [string,{file:string,array:boolean}][]){const list=rows(entry.file);rd[key]=entry.array?list:list[0];(globalThis as {gc?:()=>void}).gc?.();}
 const before=rows(index.cars);const manifest=read('replay-snapshot-manifest.json');assert.equal(before.length,manifest.carCount);assert.deepEqual(Object.keys(snapshotHashes).sort(),Object.keys(manifest.files).sort());for(const [file,hash]of Object.entries(snapshotHashes))assert.equal(hash,manifest.files[file].sha256,'Snapshot generation manifest mismatch');return {rd:rd as ReturnType<typeof research>,before:before as ReturnType<typeof catalogue>};
};
const baselineMode=process.env.BMW_BASELINE_SNAPSHOT_INDEX?'fresh owner current-catalogue snapshot, immutable inputs/full before verified':'independent current catalogue hydration';
const {rd,before}=process.env.BMW_BASELINE_SNAPSHOT_INDEX?loadCurrentSnapshot():{rd:research(),before:catalogue()};
const inputs=digest({rd,before,p});
const isReviewed=(c:any)=>c.brand==='BMW'&&(!c.vehicleClass||['passenger','ute'].includes(c.vehicleClass));
const old=before.filter(isReviewed), existing=new Map(before.map(c=>[c.id,c]));
assert.deepEqual(plain(old),read('bmw-live-before.json'),'Full before vehicles including projections');
assert.deepEqual(plain(rd.sources),read('bmw-source-before.json'),'Full before sources');
assert.equal(p.brand,'BMW');assert.equal(p.reviewedAt,'2026-10-14');
const expectedIds=[...old.map(c=>c.id),...p.variants.map(v=>v.id)].sort();
assert.equal(new Set(expectedIds).size,expectedIds.length);assert.equal(p.versionGuards.length,old.length);
assert.deepEqual(p.availability.map(r=>r.variantId).sort(),expectedIds);
assert.deepEqual(p.summaries.map(r=>r.variantId).sort(),expectedIds);
const sources=new Map(p.sources.map(s=>[s.id,s])),priorSources=new Map(rd.sources.map(s=>[s.id,s]));
const captureFiles=new Set<string>();let captureReferences=0;
for(const s of p.sources){
 let captured=false;
 for(const [locator,hashKey] of [['capture_locator','capture_sha256'],['capture_text_locator','capture_text_sha256']]){
  const f=(s as any)[locator];if(!f)continue;captured=true;const file=path.resolve(R,f);assert(file.startsWith(R+'/'),'Capture traversal');assert.equal(sha(file),(s as any)[hashKey],s.id+' capture hash');captureReferences++;captureFiles.add(f);
 }
 if(!captured){if(priorSources.has(s.id))assert.deepEqual(s,priorSources.get(s.id),'Historical source changed');else{
  assert(s.access_limitation,s.id+' successful new source has no capture');
  assert(!p.facts.some(f=>f.after.sourceIds.includes(s.id)),'Failed source supports fact');
  assert(!p.brandTerms?.some(t=>t.fact.sourceIds.includes(s.id)),'Failed source supports term');
  assert(!p.features?.some(f=>f.after.source_ids.includes(s.id)),'Failed source supports feature');
  assert(!p.availability.some(a=>a.after.evidence.sourceIds.includes(s.id)),'Failed source supports availability');
 }}
}
for(const g of p.versionGuards)assert.deepEqual(g.before,brandVersionSnapshot(existing.get(g.variantId)!));
for(const row of p.facts){assert.deepEqual(row.before??null,plain(existing.get(row.variantId)?.facts[row.after.key]??null),row.variantId+'/'+row.after.key+' before');assert(row.after.sourceIds.every(id=>sources.has(id)));}
for(const term of p.brandTerms??[]){
 assert.deepEqual([...term.applicableVariantIds,...term.exceptions.map(e=>e.variantId)].sort(),expectedIds,term.key+' complete scope');
 for(const id of term.applicableVariantIds)assert.deepEqual(term.before[id]??null,plain(existing.get(id)?.facts[term.key]??null));
 assert.equal(term.fact.buyerGrade,'confirmed');assert.equal(term.fact.gradeReview?.evidenceScope,'brand_au_terms');
}
const data=prepareBrandResearch(rd,[p]),cars=applyBrandUpdates(before,data,[p]),selected=cars.filter(isReviewed);
assert.deepEqual(selected.map(c=>c.id).sort(),expectedIds);

// Source-specific assertions are deliberately independent of generated matrix values.
const independentSourceAssertions:string[]=[];
const verify=(id:string,key:string,value:unknown,grade?:string)=>{
 const fact=selected.find(c=>c.id===id)?.facts[key];assert(fact,id+'/'+key+' exists');assert.deepEqual(fact.value,value,id+'/'+key+' captured value');if(grade)assert.equal(fact.buyerGrade,grade,id+'/'+key+' source grade');independentSourceAssertions.push(id+'/'+key);
};
const ids={ix:'bmw_ix_current__42cf_xdrive45_m_sport__20261010',ix1:'bmw_ix1_current__22hm_xdrive30_m_sport__20261010',ix2:'bmw_ix2_current__82gn_xdrive30_m_sport__20261010',i4:'bmw_i4_current__52hd_edrive35_m_sport_package__20261010',touring:'bmw_i5_touring_current__32hh_m60_xdrive__20261014',sport:'bmw_ix1_current__xdrive30_sport_collection__20261014'};
for(const [alias,values] of Object.entries({ix:{price_aud:155978,range_km:522,battery_usable_kwh:94.8,ac_kw:22,seats:5,boot_l:500},ix1:{price_aud:85362,range_km:410,ac_kw:22,seats:5,boot_l:490},ix2:{price_aud:87446,ac_kw:22,seats:5,boot_l:525},i4:{price_aud:96896,range_km:448,battery_usable_kwh:66.4,ac_kw:11,dc_peak_kw:180,dc_charge_time_min:32,seats:5,boot_l:470,towing_braked_kg:1600},touring:{price_aud:236211,ac_kw:22,dc_peak_kw:205,dc_charge_time_min:30,seats:5,boot_l:570,max_total_cargo_l:1700,towing_braked_kg:2000}}))for(const [key,value]of Object.entries(values))verify(ids[alias as keyof typeof ids],key,value);
for(const id of [ids.ix,ids.ix1,ids.ix2,ids.i4,ids.touring]){const f=selected.find(c=>c.id===id)!.facts.price_aud;assert.equal(f.buyerGrade,'check');assert.equal(f.priceEvidence?.rung,4);assert.equal(f.priceEvidence?.state,'VIC');assert.equal(f.comparisonBasis,'Driveaway');assert.match(f.conditionExplanation!,/VIC|Victoria/i);}
for(const [id,price] of [['bmw_i3_sedan_40_xdrive_na0_au__20261014',106103],['bmw_i3_sedan_50_xdrive_na0_au__20261014',122775]] as const){verify(id,'price_aud',price,'check');verify(id,'seats',5,'confirmed');const f=selected.find(c=>c.id===id)!.facts.price_aud;assert.equal(f.priceEvidence?.rung,4);assert.equal(f.priceEvidence?.state,'VIC');}
verify(ids.ix1,'ac_kw',22,'confirmed');verify(ids.i4,'seats',5,'confirmed');verify(ids.touring,'seats',5,'confirmed');
verify(ids.sport,'price_aud',79900,'check');const sportPrice=selected.find(c=>c.id===ids.sport)!.facts.price_aud;assert.equal(sportPrice.priceEvidence?.rung,2);assert.equal(sportPrice.validUntil,'2027-03-31');assert.match(sportPrice.conditionExplanation!,/Alpine White/);assert.match(sportPrice.conditionExplanation!,/Enhancement/);verify(ids.sport,'range_km',410,'reported');
for(const c of selected){assert.equal(c.facts.battery_warranty.value,'8 years / 160,000 km');assert.match(String(c.facts.roadside_assistance.value),/^8 years \/ unlimited km/);assert.equal(c.facts.roadside_assistance.roadsideFitment,'standard');assert(!/70\s*%/.test(JSON.stringify(c.facts.battery_warranty)),'Invented battery retention threshold');if(c.model==='iX4'){verify(c.id,'towing_braked_kg',null,'not_published');verify(c.id,'ac_kw',22,'check');assert.match(c.facts.ac_kw.conditionExplanation!,/optional/);}}
assert(!p.features?.some(f=>f.criterion==='automatic_seat_climate'&&/climate control|zone climate|zone automatic|air conditioning/i.test(String(f.after.value))),'Cabin climate mislabeled automatic seat climate');
assert(!p.features?.some(f=>f.criterion==='warranty_service'&&!/servic|interval|maintenance/i.test(String(f.after.value))),'Warranty alone mislabeled servicing');
assert(!p.features?.some(f=>f.criterion==='home_charging'&&!/7(?:\.0)?\s*kW|single.phase/i.test(String(f.after.value))),'Maximum AC intake mislabeled 7 kW home charging time');
assert(!p.features?.some(f=>f.criterion==='battery_chemistry'&&!/LFP|NMC|NCA|lithium|chemistry/i.test(String(f.after.value))),'Capacity alone mislabeled chemistry');


assert.deepEqual(cars.filter(c=>!isReviewed(c)),before.filter(c=>!isReviewed(c)),'Other brands including MINI changed');
assert.deepEqual(data.sources.filter(s=>!sources.has(s.id)||priorSources.has(s.id)),rd.sources,'Prior source rows changed');
const baseline=new Map(selected.map(c=>[c.id,baselineFeatures(existing.get(c.id)||c,existing.has(c.id)?rd:data)]));
assert.deepEqual(plain(old.flatMap(c=>baseline.get(c.id)!)),read('bmw-feature-before.json'),'Full existing feature before rows');
if(p.variants.length){
 assert.deepEqual(plain(selected.filter(c=>!existing.has(c.id)).flatMap(c=>baseline.get(c.id)!)),read('new-feature-before.json'),'Full new feature before rows, including price/roadside projections');
}
for(const row of p.features??[])assert.deepEqual(row.before,plain(baseline.get(row.variantId)!.find(f=>f.criterion===row.criterion)),row.variantId+'/'+row.criterion+' feature before');
let configurationDependencies=0;
for(const row of p.configurationUpdates??[]){
 const c=selected.find(c=>c.id===row.variantId)!;
 assert.deepEqual(row.before,existing.get(row.variantId)!.configurationEvidence);assert.deepEqual(c.configurationEvidence,row.after);
 assert.deepEqual(data.variants.find(v=>v.id===row.variantId)!.configuration_evidence,row.after);
 assert.deepEqual(data.feature_evidence_variant_context!.find(v=>v.id===row.variantId)!.configuration_evidence,row.before,'Historical equipment scope');
 assert.equal(row.after.completeVehicleCountEligible,row.before!.completeVehicleCountEligible);
 const mutable=new Set(['rankingEligible','projectionScope','sourceIds','requiredBuyerVisibleConditions','requiredNulls','countContribution','configurationReview']);
 assert.deepEqual(Object.fromEntries(Object.entries(row.after).filter(([k])=>!mutable.has(k))),Object.fromEntries(Object.entries(row.before!).filter(([k])=>!mutable.has(k))),'Frozen source/build fields');
 const oldHolds=row.before!.requiredNulls??{},newHolds=row.after.requiredNulls??{};
 for(const [k,v] of Object.entries(newHolds))assert.deepEqual(v,(oldHolds as any)[k],k+' retained null');
 assert.deepEqual(Object.keys(oldHolds).filter(k=>!Object.hasOwn(newHolds,k)).sort(),row.after.configurationReview!.releasedNulls.map(r=>r.key).sort(),'Explicit scalar releases');
 for(const dep of row.dependencies){assert.deepEqual(c.facts[dep.key],dep.expected);configurationDependencies++;}
}
for(const row of p.availability){if(existing.has(row.variantId)){const c=existing.get(row.variantId)!;assert.deepEqual(row.before,plain({availability:c.availability,evidence:c.availabilityEvidence}));}assert.equal(row.after.evidence.physicalStockVerified,false);assert.equal(row.after.evidence.factoryOrderAcceptanceVerified,false);}
console.log('Checking actual registered pipeline and every reviewed claim');
const actual=compiledSource('src/lib/data.ts',{'./brand-update-registry':{brandUpdatePackets:[...basePackets,p]}}) as {pack:typeof pack};
const packs:Record<string,ReturnType<typeof pack>>={};let factsChecked=0,featuresChecked=0,dependenciesChecked=0,notPublished=0;
const coreRows:any[]=[],projectionRows:any[]=[];
for(const car of selected){
 const runtimeBase=baselineFeatures(car,data);const features=applyBrandTermFeatures(car,applyBrandFeatureUpdates(car,runtimeBase,data,[p]));
 const view=actual.pack(car.id,{data,cars});packs[car.id]=view;assert.deepEqual(pack(car.id,{data,cars}),view,'Live registered pack parity');assert.deepEqual(view.car,car);assert.deepEqual(view.features,features,'Actual feature pipeline including projections');
 for(const {key} of coreFacts){const f=car.facts[key];assert.equal(f?.gradeReview?.overlayId,p.id,car.id+'/'+key+' unreviewed');assert(factFreshness(f,'2026-10-14').fresh,car.id+'/'+key+' stale');coreRows.push({id:car.id,key,value:f.value,grade:f.buyerGrade,basis:f.comparisonBasis,availability:buyerAvailability(car)});}
 for(const f of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===p.id)){
  assert(hasEarnedBuyerGrade(f,data.sources,'2026-10-14'),car.id+'/'+f.key+' earned grade');
  const claim=factClaim(view,f);assert.equal(claim.buyerGrade,f.buyerGrade);assert.deepEqual(claim.sources.map(s=>s.id),f.sourceIds);assert.deepEqual(claim.gradeReview,f.gradeReview);factsChecked++;
  assert(factFreshness(f,'2026-10-14').fresh,car.id+'/'+f.key+' stale');
  if(f.buyerGrade==='not_published'){assert.equal(f.value,null);assert(new Set(f.sourceIds.map(id=>sources.get(id)!.url.split('#')[0])).size>=2,car.id+'/'+f.key+' two distinct searched sources');assert(f.gradeReview!.reason.trim());notPublished++;}
  if(f.buyerGrade==='check')assert(f.conditionExplanation?.trim());
 }
 for(const row of p.features?.filter(f=>f.variantId===car.id)??[]){const f=features.find(f=>f.criterion===row.criterion)!;assert.deepEqual(f,row.after);assert(hasEarnedBuyerGrade(f,data.sources,'2026-10-14'));const claim=featureClaim(view,f.criterion,f.criterion)!;assert.deepEqual(claim.sources.map(s=>s.id),f.source_ids);assert.equal(claim.buyerGrade,f.buyerGrade);featuresChecked++;for(const d of row.dependencies){assert.deepEqual(car.facts[d.key],d.expected);dependenciesChecked++;}}
 const roadside=features.find(f=>f.criterion==='roadside_assistance')!;assert.equal(roadside.status,'standard');assert.equal(roadside.buyerGrade,car.facts.roadside_assistance.buyerGrade);assert.deepEqual(roadside.source_ids,car.facts.roadside_assistance.sourceIds);
 projectionRows.push({id:car.id,price:features.find(f=>f.criterion==='driveaway_price'),roadside});
 const summary=currentBuyerSummary(car.buyerSummary,data.sources,{asOf:'2026-10-14'});assert(summary?.strength?.text&&summary?.tradeoff?.text,car.id+' visible strength/tradeoff');assert(!/evidence first|worth checking in detail/i.test(JSON.stringify(summary)));
 assert.equal(car.year,null,'No model year inferred from publication/arrival date');
 if(/unspecified|not stated/i.test(car.facts.boot_l.comparisonBasis||''))assert.equal(rankAttribute([car],data.sources,'boot_l',{asOf:'2026-10-14'}).groups.length,0,'Unknown cargo measurement ranked');
}
assert.deepEqual(hydratePortablePacks(storePortablePacks(packs),data.sources),packs,'Portable exact parity');
const onSale=selected.filter(c=>buyerAvailability(c)==='on_sale_now');
const ranks=(list:typeof selected)=>Object.fromEntries((['price_aud','range_km','dc_charge_time_min','seats','boot_l','towing_braked_kg'] as const).map(key=>{const r=rankAttribute(list,data.sources,key,{asOf:'2026-10-14'});return[key,{ranked:r.groups.flatMap(g=>g.entries).length,unranked:r.unranked.length,excluded:r.excluded.length}]}));
const rankingGuards:string[]=[],secondaryGuards:string[]=[];
for(const c of selected){
 const ids=new Set(c.facts.range_km.sourceIds);
 const noRank=(name:string,car:any,ss:any[],asOf='2026-10-14')=>{assert.equal(rankAttribute([car],ss,'range_km',{asOf}).groups.length,0,c.id+'/'+name);rankingGuards.push(c.id+'/'+name);};
 noRank('source removed',c,data.sources.filter(s=>!ids.has(s.id)));noRank('source held',c,data.sources.map(s=>ids.has(s.id)?{...s,publication_hold:true}:s));noRank('source inaccessible',c,data.sources.map(s=>ids.has(s.id)?{...s,access_limitation:'Test unavailable'}:s));noRank('source stale',c,data.sources.map(s=>ids.has(s.id)?{...s,accessed_date:'2025-01-01'}:s));noRank('review required',{...c,facts:{...c.facts,range_km:{...c.facts.range_km,gradeReviewStatus:'review_required'}}},data.sources);noRank('basis absent',{...c,facts:{...c.facts,range_km:{...c.facts.range_km,comparisonBasis:''}}},data.sources);noRank('ageing',c,data.sources,'2027-10-15');
 for(const f of Object.values(c.facts).filter(f=>f.gradeReview?.overlayId===p.id&&f.buyerGrade==='reported'&&f.sourceIds.some(id=>/independent|dealer|official_au_safety/.test(sources.get(id)?.source_type||''))))for(const grade of ['confirmed','check'] as const){const promoted={...f,buyerGrade:grade,gradeReview:{...f.gradeReview!,evidenceScope:'exact_au_version' as const}};assert.equal(hasEarnedBuyerGrade(promoted,data.sources,'2026-10-14'),false,c.id+'/'+f.key+' secondary promotion');secondaryGuards.push(c.id+'/'+f.key+'/'+grade);}
}
const foreignSourceIds=new Set(p.sources.filter(s=>(s as any).sourceOriginMarket&&!['AU','Australia','AU/NZ'].includes((s as any).sourceOriginMarket)).map(s=>s.id));
assert.deepEqual([...foreignSourceIds],[transition.sourceId]);const foreignPromotionGuards:any[]=[];
for(const c of selected)for(const fact of Object.values(c.facts).filter(f=>f.gradeReview?.overlayId===p.id&&f.sourceIds.some(id=>foreignSourceIds.has(id)))){
 assert.equal(fact.buyerGrade,'reported');assert(hasEarnedBuyerGrade(fact,data.sources,'2026-10-14'));
 for(const grade of ['confirmed','check'] as const){const promoted={...fact,buyerGrade:grade,gradeReview:{...fact.gradeReview!,evidenceScope:'exact_au_version' as const}};assert.equal(hasEarnedBuyerGrade(promoted,data.sources,'2026-10-14'),false,'Foreign evidence promotion');foreignPromotionGuards.push({id:c.id,key:fact.key,grade});}
}
assert.equal(foreignPromotionGuards.length,8);
console.log('Checking negative mutation and immutable-data guards');
const negativeGuards:string[]=[];
function reject(name:string,edit:(q:BrandUpdatePacket)=>void,featureReplay=false){const q=structuredClone(p);edit(q);assert.throws(()=>{const d=prepareBrandResearch(rd,[q]);const cs=applyBrandUpdates(before,d,[q]);if(featureReplay){const c=cs.find(c=>c.id===q.features![0].variantId)!;applyBrandFeatureUpdates(c,baseline.get(c.id)!,d,[q]);}},undefined,name);negativeGuards.push(name);(globalThis as {gc?:()=>void}).gc?.();}
reject('version drift',q=>q.versionGuards[0].before.trim+=' drift');reject('fact drift',q=>{q.facts.find(f=>f.before)!.before!.value='drift';});reject('brand incomplete scope',q=>q.brandTerms![0].applicableVariantIds.pop());reject('feature before drift',q=>q.features![0].before.value='drift',true);reject('feature dependency drift',q=>q.features![0].dependencies[0].expected.value='drift');reject('summary dependency drift',q=>q.summaries[0].strength.dependencies[0].expected.value='drift');reject('availability drift',q=>q.availability[0].before.availability='outgoing');reject('price basis corruption',q=>{const f=q.facts.find(f=>f.after.key==='price_aud'&&f.after.priceEvidence?.rung===4)!.after;f.comparisonBasis='Before on-road costs';});reject('invalid roadside fitment',q=>(q.brandTerms!.find(t=>t.key==='roadside_assistance')!.fact as any).roadsideFitment='included');reject('roadside metadata on range',q=>(q.facts.find(f=>f.after.key==='range_km')!.after as any).roadsideFitment='optional');reject('source collision',q=>q.sources.push({...rd.sources[0],title:'Changed'}));
if(p.variants.length)reject('new version Tier2 collision',q=>(q.variants[0] as any).vehicle_class='van');
if(p.configurationUpdates?.length){
 reject('configuration before drift',q=>q.configurationUpdates![0].before!.projectionScope+=' changed');reject('configuration frozen build identity',q=>(q.configurationUpdates![0].after as any).sourceIdentity={changed:true});reject('configuration complete-record promotion',q=>q.configurationUpdates![0].after.completeVehicleCountEligible=true);reject('configuration dependency drift',q=>q.configurationUpdates![0].dependencies[0].expected.value='drift');reject('configuration invalid source',q=>q.configurationUpdates![0].sourceIds=['missing-source']);reject('configuration null erasure',q=>(q.configurationUpdates![0] as any).after=null);reject('configuration duplicate target',q=>q.configurationUpdates!.push(structuredClone(q.configurationUpdates![0])));reject('configuration unguarded target',q=>q.versionGuards=q.versionGuards.filter(g=>g.variantId!==q.configurationUpdates![0].variantId));
}
for(const target of foreignPromotionGuards)reject('foreign promotion '+target.id+'/'+target.key+'/'+target.grade,q=>{const f=q.facts.find(r=>r.variantId===target.id&&r.after.key===target.key)!.after;f.buyerGrade=target.grade;f.gradeReview!.evidenceScope='exact_au_version';f.status=target.grade==='confirmed'?'standard':'conditional';if(target.grade==='check')f.conditionExplanation='Synthetic foreign-source promotion guard';});
const reconciliation=read('bmw-reconciliation-2026-10-14.json');assert.equal(reconciliation.publishedLists.length,0,'Brand-only lists must not assert global C1');
for(const review of reconciliation.currentVersionReviews??[])for(const v of review.versions){const c=selected.find(c=>c.id===v.carId)!;assert(c);assert.equal(c.model,v.model);assert.equal(c.trim,v.trim);assert.equal(c.year,v.modelYear);}
const immutable=read('immutable-data-before.json');const immutableRows=Array.isArray(immutable)?immutable.map((r:any)=>[r.path,r.sha256]):Object.entries(immutable);for(const [f,h] of immutableRows){if(f==='data/m1-brand-updates/registry.json'){const registry=JSON.parse(fs.readFileSync(f,'utf8'));assert.equal(registry.packets.pop(),'bmw-2026-10-14.json');assert(!registry.packets.includes('bmw-2026-10-14.json'));assert.equal(crypto.createHash('sha256').update(JSON.stringify(registry,null,2)+'\n').digest('hex'),h,'Only authorized registry append');}else assert.equal(sha(path.join(process.cwd(),f as string)),h,f+' immutable drift');}assert.equal(sha('data/m1-brand-updates/bmw-2026-10-14.json'),process.env.BMW_APPROVED_PACKET_SHA256);
for(const [f,h] of Object.entries(snapshotHashes))assert.equal(sha(path.resolve(R,f)),h,'Current snapshot drift');assert.equal(digest({rd,before,p}),inputs,'Input mutation');for(const [f,h]of Object.entries(approvedHashes))assert.equal(sha(path.join(R,f)),h,'Artifact drift during review');for(const [f,h]of Object.entries(codeHashes))assert.equal(sha(f),h,'Code drift during review');
const result={status:'passed',reviewedAt:'2026-10-14',approvedHashes,codeHashes,priorCodeReviewSha256,baselineMode,snapshotHashes,counts:{versions:selected.length,onSaleVersions:onSale.length,newVersions:p.variants.length,sources:p.sources.length,captureReferences,captureFiles:captureFiles.size,factsChecked,featuresChecked,dependenciesChecked,notPublished,configurationDependencies},rankCountsAll:ranks(selected),rankCountsOnSale:ranks(onSale),coreRows,projectionRows,rankingGuards,secondaryGuards,foreignPromotionGuards,negativeGuards,transition,independentSourceAssertions,actualRegisteredPack:true,portableExactParity:true,fullBeforeVehicles:true,fullBeforeFeatures:true,otherBrandsUnchanged:true,historicalSourcesUnchanged:true,immutableDataUnchangedExceptAuthorizedRegistryAppend:true,liveRegisteredPackParity:true,originalFullBaselineNotRegenerated:true};
fs.mkdirSync(Q,{recursive:true});fs.writeFileSync(path.join(Q,'independent-review-replay.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({...result,coreRows:undefined,projectionRows:undefined},null,2));
