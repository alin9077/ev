# BMW Australian BEV research · 14 October 2026

## Result
The dated, guarded packet reviews 15 named configurations across ten exact model/body cohorts. Seven configurations are added. Manufacturer model years remain null where no formal Australian MY is established.

The current-price ladder uses maker Victorian 3000 driveaway examples for iX1, iX2, iX3 40/50, i4, iX, i5 Touring and i3 40/50. Each preserves its state, selected-option and tax basis. Sport Collection has its own A$79,900 national driveaway offer through 31 March 2027. Other prices remain attributed Reported before-on-road-costs figures when a usable primary price was not recovered. No ex-GST/LCT base price was converted into MRLP.

Nine configurations are current listings; six retain announced arrival status. A configurator or New advertisement is not accepted factory order, physical unsold stock or a delivery commitment. The arriving i3 is the NA0 sedan, separate from the historical I01 hatchback; NA5 iX3 is separate from outgoing G08.

Current BMW BEV terms are five years/unlimited km private-use vehicle cover, eight years/160,000 km battery cover and eight years/unlimited km complimentary roadside. Commercial-use, benefit and incident limits remain in the shared terms. No unpublished battery retention percentage is invented.

## Important open evidence
- Residual/new supply for older iX1/iX2, G08 iX3, i4/i5 and outgoing i7 cohorts remains unresolved. The iX supplement explicitly retains older 40/50/M60 and local generic/administrative 60/M70 leads
- Two brand-wide independent directories are reconciled, but they are not complete whole-market C1 lists. Broad residual inventory scopes remain unresolved
- i3 40 battery: current maker model page says 83.8 kWh; exact 32JB configurator says 82.8 kWh, with no gross/net reconciliation
- i3 50 AC: exact 52JB panel says 11 kW; broader maker page advertises 22 kW maximum capability. Included optional-charger fitment was not recovered
- iX4 local towing is a genuine two-source Not published gap; foreign towing is not silently used as an Australian rating
- Cargo methods/load lines stay explicit. Published volume is not automatically VDA or comparable across families

## Deliverable map
- `bmw-2026-10-14.json`: final staged packet, unregistered
- `bmw-reconciliation-2026-10-14.json`: exact current cohort reviews and honest inherited-inventory dispositions
- `brand-model-list-reconciliation.json`: complete brand-directory and residual/new-family census
- `normalized-evidence.json`: consolidated latest facts, equipment and summary dependencies
- `core-matrix.json` / `.csv`: all 255 core cells with sources, grades and real conditions
- `source-index.json`, `source-hash-manifest.json`, `privacy-review.json`: capture provenance and privacy transformations
- `new-feature-before.json`: full new-row baseline generated only after final canonical price/roadside/offers; validated against final packet hash
- `staged-report.json`, `after.json`, `features-after.json`, `staged-packs.json`: replay outputs, reused for final audit

Family research notes record initial observations and later primary supplements. The consolidated packet and normalized evidence are the final interpretation. The `.initial` census copies preserve the initial research snapshot and are explicitly superseded. No registry, original research dataset or previous registered packet is edited. Local PDF page renders are labelled separately from browser text captures; no unrequested browser screenshots are uploaded.
