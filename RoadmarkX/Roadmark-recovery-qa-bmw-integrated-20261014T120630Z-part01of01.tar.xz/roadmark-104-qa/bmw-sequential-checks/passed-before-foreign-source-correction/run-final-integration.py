import json,os,pathlib,subprocess,time
root=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104'); out=pathlib.Path(__file__).resolve().parent
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=768')
checks=[('integration',['node','--import','tsx','--test','--test-reporter=tap','--test-concurrency=1','tests/brand-added-detail.test.ts','tests/brand-feature-updates.test.ts','tests/brand-updates.test.ts','tests/brand-configuration-updates.test.ts']),('validate',['node','--import','tsx','scripts/validate.ts']),('coverage',['node','--import','tsx','scripts/report-coverage.ts','--json']),('typecheck',['node','node_modules/typescript/bin/tsc','--noEmit']),('lint',['node','node_modules/eslint/bin/eslint.js','scripts/reporting/load.ts'])]
for name,cmd in checks[:1]:
 start=time.monotonic()
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  p=subprocess.Popen(cmd,cwd=root,env=env,stdout=stdout,stderr=stderr)
  pid,status,r=os.wait4(p.pid,0); rc=os.waitstatus_to_exitcode(status); p.returncode=rc
 result={'command':cmd,'exitCode':rc,'signal':-rc if rc<0 else None,'wallSeconds':round(time.monotonic()-start,3),'userSeconds':r.ru_utime,'systemSeconds':r.ru_stime,'maxRssKiB':r.ru_maxrss}
 (out/(name+'.metrics.json')).write_text(json.dumps(result,indent=2)+'\n'); print(name,json.dumps(result),flush=True)
 if rc: raise SystemExit(rc if rc>0 else 128-rc)
