# Independent BMW evidence review

Status: approved for integration at the exact hashes below; this is BMW research readiness, not a global C1–C6 completion claim.
Reviewed against the full DOT-BRIEF-103, 14 October 2026.

## Independently verified source decisions

- Current Australian maker directory distinguishes iX4 50 xDrive and i3 50 xDrive Build & Price links from explicitly Coming Soon iX4 M60, iX3 M60 and i3 M60 interest forms. iX5 60 xDrive is a distinct future lead. Neither presence in the directory nor a generic price-guide row alone proves physical stock or completed factory-order acceptance. MINI and hybrids are outside this BMW BEV slice.
- Exact manufacturer codes and stated production applicability matter. Current i5 guide overview names 62HG/42HG and July 2026 production applicability; inner equipment pages retain older codes. This discrepancy is a standing source note, not a reason to demote every stable body fact. No formal model year should be invented from publication dates.
- June 2026 guides give iX1/iX2 capacity 67 kWh while the current web technical table gives 64.8 kWh without clear gross/usable labels. Preserve these source distinctions. iX's guide explicitly says 94.8 kWh net, separate from 94.3 kWh on the web table. Guide ADR81/02 range and web WLTP range must never be merged.
- Public BMW configurator itemizes a base amount separately from GST and LCT. It is not an Australian tax-inclusive list price. Use the explicitly displayed state MRDP where no higher price rung is published; never derive a tax-inclusive sum. Generic example postcode 3000 is Victoria, not the user's location.
- i5 M60 xDrive Touring G61/32HH still opens a full current Australian configurator even though its marketing page redirects. Independently captured Victoria MRDP A$236,211, selected options A$0. Technical panel gives 442 kW, 3.9 seconds, 22 kW AC, 205 kW DC, 30 minutes explicitly 10–80%, five seats, 5060 × 1900 × 1505 mm, 2000 kg braked at 12%/80 kg towball, 570–1700 L. The battery label alone says gross/net and does not establish which. Expanded selected equipment proves 22 kW AC, Bowers & Wilkins audio, ventilated front seats, Driving Assistant Professional and Parking Assistant Professional included. Generic standard overview says Harman Kardon, so exact selected AU equipment controls.
- Outgoing i7 M70 G70/82EH explicitly redirects to petrol 740 G70/52HZ with an unavailable-model notice. The 740's A$310,353 cannot be reused as an i7 price. This proves the requested configurator model is unavailable, not that every official-dealer residual new vehicle has been sold.
- i4 G26/52HD exact technical configurator establishes five seats and 1600 kg braked towing at 12%/75 kg towball, closing secondary-source gaps. It also gives 750 kg unbraked, 11 kW AC, 180 kW DC and 32 minutes 10–80%. A 22 kW wallbox accessory must not be mistaken for the car's AC intake.
- iX1 U11/22HM expanded exact selected equipment shows AC Charging Professional (22 kW), checked and disabled, A$0, within the default M Sport configuration. Enhancement Package is not selected. This is direct scope-specific 22 kW evidence, stronger than a decoded option code or generic 11/22 kW table.
- Maker luggage litres remain displayable; an unnamed method/load line cannot gain VDA/SAE comparability. Expanded interval values should not be labelled seats-folded without explicit support. Configuration-dependent towing approval and optional towbar equipment remain real conditions.
- Current maker service portal links the supplementary warranty. Its explicit BEV table gives private vehicle five years/unlimited km, commercial hire/reward/instruction five years/200,000 km, battery eight years/160,000 km and BEV roadside eight years/unlimited km. The generic web FAQ says three years roadside; the specific BEV policy controls. Capacity-loss coverage has no numerical retention threshold, so do not invent 70%.
- Unresolved residual-new leads must remain unresolved. A failed search or retained database selector is not proof of exhausted stock, but neither establishes a fresh exact New seller listing. Broad brand research can be ready while strict C1 remains open.

## Equipment-criterion semantics reviewed

The review identified and requested removal of several unsupported mappings while retaining valid underlying facts: cabin air-conditioning zones are not automatic seat heating/ventilation; total AWD system power is not rear-motor-specific hardware; ordinary navigation is not an EV itinerary/arrival-SOC route planner; capacity alone is not cell chemistry. The live pipeline also changes warranty_service to Servicing, so warranty terms alone cannot answer it. Home charging time specifically asks for a single-phase 7 kW duration, which maximum onboard AC intake alone does not answer. Final replay must verify these corrections rather than relying on raw grade labels.

## Browser evidence and limitations

Independent browser captures and source hashes are under the research packet's review directory, with browser-source-provenance.json. These contain rendered public text only, omit generated configuration-share values, and retain no network headers, hidden runtime data or screenshots. No offer, test-drive, purchase or finance application was submitted. One finance-options overlay was inadvertently opened while navigating a changing page and dismissed without selecting a product or submitting information.

i5 G60/62HG failed with DOMSnapshot and Page.getLayoutMetrics protocol timeouts in a fresh tab. No price was retained. This is a browser failure, not evidence of bot detection or Australian unavailability. A first i7 tab likewise timed out; one fresh tab returned the explicit redirect evidence above. Failed reads do not support product facts.

## Final independent verification

- Approved packet SHA256: `f894bcc4732b0170f26447f95c7aca6e1126c40f1b20ed7010b1aa879f92ea7d`
- Approved runtime reconciliation SHA256: `b43b2609765490cf5117e1c0eeb28224424a1ec98d9a21c408fa6673378104d5`
- Fifteen source-bound versions across ten model/body cohorts: nine current/listed and six announced arrivals. Seven rows are new. The companion census preserves all ten cohort reviews; the runtime on-sale-only schema receives six wholly on-sale reviews. Mixed NA5 and arriving cohorts are not falsely counted on sale. Fifteen residual/withheld cohort entries remain open.
- All 255 core cells reviewed: 202 Confirmed, 37 Check, 14 Reported, two Not published (Australian iX4 towing). Nineteen genuine Not published facts overall retain two-source checks.
- Replay checked 868 reviewed facts, 212 explicit equipment answers and 289 equipment dependencies; 105 ranking-withdrawal cases, 22 secondary-promotion guards and 12 packet mutation guards passed. There are no BMW configuration-update rows, so their prior shared tests remain separate rather than being claimed as new BMW coverage.
- Full eight-existing and seven-new vehicle/feature baselines match. All 483 new feature rows, including price and roadside projections, were compared without field filtering. The final canonical hash is `7830bfc2853ce763c7c6b196f9c006202a18d26b518504a094e7414ebb3e3d6c`; the baseline manifest records the final packet hash.
- The actual source pack implementation, with the candidate registry injected only in the test, matches the independent after-state; citable claims and portable packs retain exact parity. Older source rows, MINI/all other brands, all 96 immutable data inputs and the five pipeline code hashes from the earlier GAC approval are unchanged.
- The replay reused the owner's complete, hashed 386-car current snapshot to avoid repeated hydration. Full snapshot hashes and immutable input guards were checked before/after; this is not represented as fresh independent catalogue hydration. Successful replay peak RSS was 793,208 KiB under a 1024 MiB Node heap.
- A preliminary harness expected an old i5 dealer driveaway projection after its canonical price became before-ORC. The harness was corrected to derive after-state from the final canonical car, while retaining all full before-state assertions. No packet or baseline change was made to pass. The failed attempt and resource record remain saved. The unavailable external time executable never launched a replay; process resource usage supplies the measurement.
- Final source audit confirms all 76 source-index metadata projections, exactly 80 cited capture hashes, staged-file byte equality and core-matrix value/grade/basis equality. A bounded pattern scan of 299 public text/metadata files found no flagged credential patterns; this is not a general security certification. All 11 PNGs are local PDF renders/contact sheets with source-PDF hashes; no browser screenshot was uploaded.
- Strict global report: C1–C5 false, C6 true. Unknown cargo measurement keeps every BMW boot figure out of comparable ranking. Secondary prices/seats and Sport Collection sibling claims stay Reported. No formal MY, accepted factory order or physical stock is invented.

### Evidence artifacts

- `bmw-independent-review/independent-review-replay.json`: exact approved hashes, snapshot hashes, counts, full canonical projection rows, guards and rank counts
- `bmw-independent-review/final-source-value-privacy-audit.json`: final captures, matrix, bounded privacy and local-render provenance
- `bmw-independent-review/replay-resource-usage.json`: successful measured resource usage
- `bmw-independent-review/approval.json`: integration decision and complete artifact hashes
