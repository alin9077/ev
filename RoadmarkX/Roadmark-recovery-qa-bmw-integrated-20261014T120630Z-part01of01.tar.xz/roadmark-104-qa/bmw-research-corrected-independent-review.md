# BMW corrected independent approval

Approved packet: `aae1fdc66eebec438c9281809df8e2c436799693e94955e3b08882f1fdefa749`

Approved reconciliation: `b43b2609765490cf5117e1c0eeb28224424a1ec98d9a21c408fa6673378104d5`

This supersedes the earlier f894bcc packet approval. Only one source metadata field changed: the German iX4 source now uses the existing `manufacturer_overseas_reported` classification. Its two seat claims had been correctly displayed as Reported, but the former source type could accept a synthetic promotion to an Australian maker grade. The corrected classification closes that guard gap. The other two overseas towing claims were already blocked by their independent co-source.

## Checks passed on corrected bytes

- Exact one-field packet difference; all facts, features, prices, offers, roadside terms, identities, captures and reconciliation unchanged
- Original eight-existing/seven-new full baselines retained; all 483 new feature rows match, including projections. No fixture or original canonical metadata regenerated
- Original canonical hash `7830bfc2853ce763c7c6b196f9c006202a18d26b518504a094e7414ebb3e3d6c` retained; explicit corrected metadata hash `69d88095523706d015def5c87544239fdc43356bea04294755d0e69e292b8266`
- Actual live registered pack, citable output and portable round-trip exact parity; 868 reviewed facts, 212 equipment answers and 289 dependencies checked
- Eight explicit foreign promotion rejections, 105 ranking-withdrawal cases, 22 secondary-promotion checks and 20 packet mutation guards passed
- All 76 source metadata records and 80 cited capture hashes checked; 299 bounded text/privacy checks with no flagged credential patterns. Eleven local PDF renders/contact sheets retain source-PDF provenance; no browser screenshot uploaded
- Other brands and 95 of 96 original data inputs unchanged. The sole original-input change is the exact authorized BMW registry append. The report loader differs from the archived GAC source by exactly its BMW import and combine argument. The separate test-only snapshot reuse preserves all 21 test names and 128 assertion-start lines
- Successful corrected replay peak RSS: 864,516 KiB, using the complete original hashed 386-car snapshot and a 1024 MiB Node heap

## Scope and limits

The packet covers 15 source-bound BMW versions across ten model/body cohorts: nine current/listed and six announced arrivals. It does not close BMW's broader residual/new-stock census; BMW remains in the report's research-remaining list. Global C1–C5 remain open; C6 passed the staged and prior registered report. Root's fresh corrected full-report check is recorded separately when available. No physical stock, accepted factory order, formal manufacturer model year, foreign Australian towing rating, or comparable cargo method was invented.

The root's 149-test combined pass and validate/coverage/typecheck/lint pass preceded this source-type-only correction. The corrected independent replay is a separate final-byte proof, not a claim that those earlier whole-project checks ran on the new hash.

## Deliverables

`bmw-corrected-independent-review/approval.json` records full artifact hashes. The same directory contains `independent-review-replay.json`, `final-source-value-privacy-audit.json`, `registered-immutable-audit.json` and the measured runtime log. Historical first-pass evidence remains in `bmw-independent-review` and is superseded for packet approval.
