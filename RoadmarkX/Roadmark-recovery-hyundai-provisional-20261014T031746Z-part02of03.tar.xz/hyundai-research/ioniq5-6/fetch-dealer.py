exec(open('/tmp/hyundai-research/ioniq5-6/fetch.py').read().split('with concurrent')[0])
rows=[('kloster-dynamiq-nline','https://www.klosterhyundai.com.au/cars/new-2024-hyundai-ioniq-5-0220580620'),('kloster-epiq','https://www.klosterhyundai.com.au/cars/new-ecotronic-grey-2025-hyundai-ioniq-5-0320437520'),('i5-old-nline-page','https://www.hyundai.com/au/en/cars/eco/2025-ioniq5-n-line.html')]
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as e:res=list(e.map(get,rows))
(P/'fetch-dealer-manifest.json').write_text(json.dumps(res,indent=2))
