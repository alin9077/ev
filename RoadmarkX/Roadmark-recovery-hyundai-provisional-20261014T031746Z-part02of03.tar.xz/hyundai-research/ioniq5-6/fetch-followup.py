exec(open('/tmp/hyundai-research/ioniq5-6/fetch.py').read().split('with concurrent')[0])
rows=[('kloster-i5-index','https://www.klosterhyundai.com.au/search/hyundai/ioniq-5'),('ce-my26','https://www.carexpert.com.au/car-news/2026-hyundai-ioniq-5-price-and-specs-smaller-battery-axed-in-reshuffled-range')]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as e:res=list(e.map(get,rows))
(P/'fetch-followup-manifest.json').write_text(json.dumps(res,indent=2))
