import urllib.request,pathlib,concurrent.futures,json,hashlib,sys,time
P=pathlib.Path('/tmp/hyundai-research/ioniq5-6/sources')
x=json.load(open('/workspace/scratch/586427eef9f2/roadmark-104/data/hyundai-evidence-2026-10-10.json'))
rows=[]
for r in x['sources']:
 if r['id'] not in ['i5_page','i5n_page','i6n_page']: rows.append((r['id'],r['url']))
def get(z):
 k,u=z
 try:
  req=urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'});r=urllib.request.urlopen(req,timeout=65);d=r.read();ext='pdf' if d[:4]==b'%PDF' else ('json' if d.strip()[:1] in (b'[',b'{') else 'html');p=P/(k+'.'+ext);p.write_bytes(d);meta={'key':k,'url':u,'finalUrl':r.url,'status':r.status,'file':str(p),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()};print(k,r.status,len(d),flush=True);return meta
 except Exception as e: print(k,str(e),flush=True);return {'key':k,'url':u,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=10) as e:res=list(e.map(get,rows))
(P/'fetch-manifest.json').write_text(json.dumps(res,indent=2))
