exec(open('/tmp/hyundai-research/ioniq5-6/fetch.py').read().split('with concurrent')[0])
rows=[('kloster-elite26','https://www.klosterhyundai.com.au/cars/new-lucid-blue-2026-hyundai-ioniq-5-0220614974'),('kloster-0220580626','https://www.klosterhyundai.com.au/cars/new-ecotronic-grey-2025-hyundai-ioniq-5-0220580626'),('kloster-0220580622','https://www.klosterhyundai.com.au/cars/new-2024-hyundai-ioniq-5-0220580622'),('cg-premium-spec','https://www.carsguide.com.au/hyundai/ioniq-5/price/2026/n-line-premium-84kwh'),('cg-elite-spec','https://www.carsguide.com.au/car/15330849/hyundai/ioniq-5/suv')]
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as e:res=list(e.map(get,rows))
(P/'fetch-exact-manifest.json').write_text(json.dumps(res,indent=2))
