import json, re, hashlib, html
from pathlib import Path
ROOT=Path('/tmp/hyundai-research/ioniq5-6'); S=ROOT/'sources'; DATE='2026-10-14'
B=json.load(open('/tmp/hyundai-research/before.json')); FB=json.load(open('/tmp/hyundai-research/features-before.json'))
sources={}; searchAudit=[]
def register(key,url,file,title=None,publisher=None,stype=None,note=''):
 p=Path(file);data=p.read_bytes();host=url.split('/')[2] if '://' in url else ''
 typ=stype or ('manufacturer' if host.endswith('hyundai.com') else 'independent_safety_body' if 'ancap' in host else 'secondary')
 pub=publisher or ('Hyundai Australia' if typ=='manufacturer' else 'ANCAP' if 'ancap' in host else host)
 tp=p.with_suffix('.txt'); sources[key]={'key':key,'url':url,'title':title or key.replace('_',' ').replace('-',' '),'publisher':pub,'source_type':typ,'published_date':None,'accessed_date':DATE,'market':'AU','file':str(p),'textFile':str(tp) if tp.exists() else str(p),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'note':note}
 return key
for m in sorted(S.glob('*manifest.json')):
 for r in json.load(open(m)):
  if r.get('status')==200 and r.get('bytes',0)>100:
   register(r['key'],r['url'],r['file'],note='Fresh direct HTTP capture. '+('Redirected to '+r['finalUrl'] if r.get('finalUrl')!=r['url'] else ''))
# Supplemental browser captures and finite search audit captures.
for key,slug in [('i5n-rendered-full','ioniq-5-n'),('i6n-rendered-full','ioniq-6-n')]:
 register(key,'https://www.hyundai.com/au/en/shop/calculator/'+slug,S/(key+'.json'),title='Hyundai '+slug+' rendered price breakdown, NSW 2000',note='Read-only dot cloud browser rendering; illustrative postcode 2000, Sydney City Hyundai. Base/no-cost paint, no accessories or prepaid service; no enquiry submitted.')
webextra={
 'aspley-epiq-nline':('https://www.aspleyhyundai.com.au/all-stock/view/2024-Hyundai-Ioniq-5-Y349362-KMHKR81AUSU349362/34125707','residual-extra-details.web.json'),
 'residual-index-audit':('https://www.autotrader.com.au/for-sale/new/hyundai/ioniq-5','i5-residual-index-details.web.json'),
 'residual-search-audit':('https://www.carsguide.com.au/buy-a-car/new/hyundai/ioniq-6','residual-search3.web.json'),
 'residual-exact-audit':('https://www.autotrader.com.au/for-sale/hyundai/ioniq-5','i5-residual-exacts.web.json'),
}
for key,(url,fn) in webextra.items():
 register(key,url,S/fn,note='Full web-tool capture; target source section identified by URL within capture. Search/marketplace result is a lead, never physical-stock proof.')
for k,title in {'i5_spec':'Hyundai IONIQ 5 MY27 Australian specifications','i5_my26':'Hyundai IONIQ 5 MY26 Australian specifications','i5_old':'Hyundai IONIQ 5 MY25 63/84 kWh Australian technical and grade matrix','i5n_spec':'Hyundai IONIQ 5 N currently linked AU specifications (2024 filename, undated body)','i6n_spec':'2026 Hyundai IONIQ 6 N Australian specifications','ancap-i5':'ANCAP Hyundai IONIQ 5 applicability, explicitly excluding N','ancap-i6':'ANCAP regular IONIQ 6 2022 rating applicability, CE1 pre-N variants'}.items():sources[k]['title']=title
sources['i5n_spec']['note']+=' Fresh bytes identical to archived technical sheet (SHA-256 checked); current page and configurator still link/support N. Not silently rebound to a later formal MY or VIN. Current roof inclusion overrides old optional-roof row.'
sources['i6n_spec']['note']+=' Body explicitly 2026; as-of 2025-11-26. Fresh bytes identical to archived technical sheet.'
# Source-specific fact helpers. All nulls have real two-document text lookups recorded.
def body(k):
 p=Path(sources[k]['textFile']);t=p.read_text(errors='replace')
 try:
  j=json.loads(t)
  if isinstance(j,str):t=j
  elif isinstance(j,dict) and 'content'in j:t='\n'.join(c.get('text','') for c in j['content'])
 except:pass
 return t
TERMS={
 'dc_peak_kw':['peak','maximum DC','350 kW'], 'battery_gross_kwh':['gross','capacity'], 'battery_usable_kwh':['usable','capacity'],
 'boot_l':['cargo','VDA','seats up'], 'max_total_cargo_l':['cargo','maximum','seats folded'], 'frunk_l':['front cargo','Cargo area - front','frunk'],
 'towing_braked_kg':['towing','braked'], 'towing_unbraked_kg':['towing','un-braked'], 'kerb_weight_kg':['kerb','tare'], 'zero_to_100_s':['0-100','0 to 100','acceleration'],
 'phone_key':['Digital Key','phone key'], 'driver_profiles_local':['profile','memory'], 'cloud_profile_transfer':['cloud profile','profile transfer'],
 'passive_unlock':['approach','unlock'], 'automatic_start':['automatic start','push button'], 'automatic_shutdown':['automatic shutdown','power off'], 'walk_away_lock':['walk away','lock'],
 'remote_preconditioning':['remote climate','conditioning'], 'automatic_seat_climate':['Auto Comfort','heated'], 'rear_heated_seats':['heated rear','heated seats'],
 'media_resume':['resume','media'], 'garage_integration':['garage','HomeLink'], 'auto_shift':['automatic gear','auto shift'], 'adas_optional':['optional','SmartSense'],
 'sentry_parked_recording':['sentry','surveillance','recording'], 'dashcam':['dashcam','recording','camera'], 'pet_mode':['pet mode','dog mode'],
 'cabin_overheat_protection':['overheat','cabin protection'], 'phone_contacts':['contacts','phone book'], 'traffic_light_chime':['traffic light','departure'],
 'alert_sound_quality':['chime','alert'], 'supercharger_access':['Supercharger','Tesla'], 'battery_preconditioning_navigation':['preconditioning','navigation','conditioning'],
 'ride_control_subjective':['ride','suspension'], 'interior_fit_finish_subjective':['finish','quality'], 'style_refinement':['refinement','design'],
 'battery_density':['density','Wh/kg'], 'referral_program':['referral','reward'], 'novated_fbt':['FBT','novated'], 'insurance_cost':['insurance','premium'], 'resale_value':['resale','value'],
 'service_network':['service','dealer'], 'real_world_range':['real world','range test'], 'charging_cable':['cable','portable'], 'bidirectional_v2g':['V2G','grid'],
 'v2l':['V2L','Vehicle To Load'], 'ancap_rating':['ANCAP','N'], 'ancap_stars':['ANCAP','N'], 'safety_ancap':['ANCAP','N'],
 'width_including_mirrors_mm':['width','mirrors'], 'turning_circle_m':['turning circle'], 'airbag_count':['airbags','centre'],
 'payload_declared':['payload'], 'tow_ball_max':['tow ball','towing'], 'gcm_kg':['GCM','combined mass'], 'battery_voltage_declared':['voltage'], 'v2l_power_declared':['V2L','output'], 'portable_charging_cable':['portable','cable'],
}
def lookups(key,ss,reason):
 terms=TERMS.get(key.removeprefix('feature_'),[key.removeprefix('feature_').replace('_',' ')])
 out=[]
 for s in ss[:2]:
  text=body(s);hits=[]
  for q in terms:
   ms=list(re.finditer(re.escape(q),text,re.I))
   hits.append({'term':q,'matches':len(ms),'examples':[re.sub(r'\s+',' ',text[max(0,m.start()-65):m.end()+140]) for m in ms[:2]]})
  out.append({'sourceKey':s,'searchedFor':terms,'result':'No compatible exact claim established: '+reason,'matches':hits})
 searchAudit.append({'key':key,'sourceKeys':ss[:2],'searches':out})
 return out

def fact(k,val,ss,grade='confirmed',basis='',comparison='',reason='',condition=None,quals=None,**extra):
 d={'key':k,'value':val,'sourceKeys':list(dict.fromkeys(ss)),'grade':grade,'basis':basis or 'Australian manufacturer specification for the named configuration','comparison':comparison,'reason':reason or 'Fresh Australian maker source explicitly publishes this named-version claim.','qualifications':quals or []}
 if condition:d['condition']=condition
 d.update(extra)
 if grade=='reported':d.setdefault('rankingEligible',False)
 return d

def unknown(k,ss,why):
 return fact(k,None,ss,'not_published',basis='No compatible exact-version claim published in the two sources inspected',reason=why,unsuccessfulSearches=lookups(k,ss,why))

def add(v,f):
 v['facts']=[x for x in v['facts'] if x['key']!=f['key']]+[f]
 return f

def F(v,k,val,ss=None,**kw):return add(v,fact(k,val,ss or [v['_spec']],**kw))
def U(v,k,why,ss=None):return add(v,unknown(k,ss or [v['_spec'],v['_second']],why))
def fmap(v):return {x['key']:x for x in v['facts']}
def feat(v,c,value,keys,grade=None,conditions='',reason=''):
 fs=fmap(v);gs=[fs[k]['grade'] for k in keys]
 g=grade or ('reported' if 'reported'in gs else 'check' if 'check'in gs else 'not_published' if all(x=='not_published' for x in gs) else 'confirmed')
 v['features'].append({'criterion':c,'value':value,'keys':keys,'grade':g,'conditions':conditions,'reason':reason or 'Uses only the listed refreshed source-bound facts.'})

def availability(ss,residual=False,extra=''):
 return {'state':'new_stock_listed' if residual else 'current_or_order_listed','buyerState':'On sale now','sourceKeys':ss,'orderStatus':'not_established' if residual else 'listed_unconfirmed','stockStatus':'new_stock_listed' if residual else 'unverified','qualifications':[('Specific dealer advert is marked New; advertised availability only, no physical inspection, allocation or accepted order.' if residual else 'Current official named model/grade and working price/configuration path; no accepted order, allocation or physical stock verified.'),extra] if extra else [('Specific dealer advert is marked New; advertised availability only, no physical inspection, allocation or accepted order.' if residual else 'Current official named model/grade and working price/configuration path; no accepted order, allocation or physical stock verified.')],'reason':'Exact currently accessible New dealer listing.' if residual else 'Current maker catalogue and active exact configuration pricing path.'}

variants=[]
# Regular MY27, plus genuinely New residual MY25/MY26 configurations.
regs=[]
for idx,b in enumerate([b for b in B if b['modelId']=='hyundai_ioniq_5_my27']):
 regs.append(dict(base=b,grade=['base','elite','premium'][idx],spec='i5_spec',second='i5-page',battery=84,range=[570,530,495][idx],power=[168,168,239][idx],torque=[350,350,605][idx],price=[68200,73200,83700][idx],idx=idx))
residuals=[
 {'id':'hyundai_ioniq_5_my25_residual__63kwh_rwd__20261014','modelId':'hyundai_ioniq_5_my25_residual','trim':'63kWh RWD (MY25 residual new)','year':2025,'grade':'base','battery':63,'range':440,'power':125,'torque':350,'spec':'i5_old','second':'kloster-0220580626','price':58990,'vin':'KMHKR81AUSU348230','stock':'0220580626','odometerKm':12,'priceState':'NSW','identityNote':'Dealer description NE.V5 MY25 125 kW RWD, 19-inch wheels and 2470 kg GVM uniquely match the MY25 Standard Range maker column. Marketplace Epiq/84 kWh label conflicts; direct dealer wins. Dealer display year 2025, build 2024, compliance 2025; formal MY25 retained.'},
 {'id':'hyundai_ioniq_5_my25_residual__dynamiq_n_line_84kwh_rwd__20261014','modelId':'hyundai_ioniq_5_my25_residual','trim':'DYNAMIQ 84kWh RWD with N Line pack (MY25 residual new)','year':2025,'grade':'dynamiq','battery':84,'range':515,'power':168,'torque':350,'spec':'i5_old','second':'kloster-dynamiq-nline','price':65990,'vin':'KMHKR81AUSU343937','stock':'0220580620','odometerKm':21,'priceState':'NSW','identityNote':'Exact dealer New NE.V5 MY25 DYNAMIQ N Line 2WD 168 kW. Display/build year 2024 and compliance 2025 are not formal MY. This source-bound N Line configuration does not prove New availability for bare DYNAMIQ or AWD siblings.'},
 {'id':'hyundai_ioniq_5_my25_residual__epiq_n_line_84kwh_rwd__20261014','modelId':'hyundai_ioniq_5_my25_residual','trim':'EPIQ 84kWh RWD with N Line pack (MY25 residual new)','year':2025,'grade':'epiq','battery':84,'range':515,'power':168,'torque':350,'spec':'i5_old','second':'aspley-epiq-nline','price':69990,'vin':'KMHKR81AUSU349362','stock':'Y349362','odometerKm':None,'priceState':'QLD','identityNote':'Dealer explicitly MY25 EPIQ 2WD N Line, 84 kWh, New clearance; display year 2024 kept separately. Do not use the 123456 km comparison-widget placeholders as odometer evidence. Named configuration does not add its optional mirror/roof equipment as separate catalogue versions.'},
 {'id':'hyundai_ioniq_5_my26_residual__84kwh_rwd__20261014','modelId':'hyundai_ioniq_5_my26_residual','trim':'84kWh RWD (MY26 residual new)','year':2026,'grade':'base','battery':84,'range':570,'power':168,'torque':350,'spec':'i5_my26','second':'kloster-elite26','price':66990,'vin':'KMHKR81AUTU401439','stock':'0220614974','odometerKm':9,'priceState':'NSW','identityNote':'Exact dealer New NE.V6 MY26 base description, 19-inch wheels and six-speaker audio agree with base maker column. CarsGuide markets this same VIN as Elite, conflicting with direct dealer; do not create an Elite residual. Separate McGrath New MY26 base advert is corroboration, not an extra version.'}
]
for r in residuals:regs.append({**r,'base':None,'idx':0})
for r in regs:
 b=r['base']; residual=b is None; g=r['grade'];my=(b['year'] if b else r['year']);awd=(b and b['drive']=='AWD') or False
 v={'id':b['id'] if b else r['id'],'model':'IONIQ 5','trim':b['trim'] if b else r['trim'],'modelYear':my,'drive':'AWD' if awd else 'RWD','modelId':b['modelId'] if b else r['modelId'],'metadata':{},'metadataReason':'Current exact MY27 maker identity retained.' if b else r['identityNote'],'identitySourceKeys':[r['spec'],r['second']],'availability':availability(['i5-page','ioniq-5_api'] if not residual else [r['second']],residual), 'facts':[],'features':[],'_spec':r['spec'],'_second':r['second'],'_grade':g,'_my':my}
 if residual:
  v['isNewIdentity']=True;v['metadata']={'modelId':r['modelId'],'generation':f'NE.V{str(my)[-1]} MY{str(my)[-2:]}; source-bound residual New stock, distinct from current MY27','year':my,'vehicleClass':'passenger','family':'hyundai-ioniq-5-my'+str(my)[-2:]+'-residual','slug':r['id'].split('__')[1]+'-20261014'}
  v['stockEvidence']=[{k:r[k] for k in ['vin','stock','odometerKm']}|{'sourceKey':r['second'],'advertisedCondition':'New','physicallyVerified':False}]
  F(v,'price_aud',r['price'],[r['second']],grade='reported',basis='Current exact New dealer advertised driveaway price',comparison='Dealer driveaway',reason='Maker current selector only prices MY27. Historical launch prices do not establish a current residual RRP; this actual New dealer advert is the highest current exact rung found.',qualifications=[r['identityNote'],'Advertised price, state and exact listed unit only; confirm seller availability and inclusions.'],priceRung=6,basisTag="Dealer's advertised driveaway price",priceTag="Dealer's advertised driveaway price",state=r['priceState'],originalBasis='Dealer Drive Away',rankingEligible=False,sourcePointer='Direct dealer New vehicle advert, displayed Drive Away price')
  F(v,'driveaway_price_aud',r['price'],[r['second']],grade='reported',basis='Exact New dealer advertised driveaway price',comparison='Dealer driveaway',priceRung=6,state=r['priceState'],rankingEligible=False)
  F(v,'source_bound_new_identity',{'formalModelYear':my,'advertisedCondition':'New','vin':r['vin'],'stockNumber':r['stock']},[r['second']],grade='reported',basis='Dealer-advertised individual New unit; not VIN inspection',reason=r['identityNote'])
 else:
  ids=['FFB98D6F-65F1-44A2-ACE7-F33005A9DE92','1E3CB636-286A-4E71-876E-D1AE9AC0C536','910CB538-E4A3-4DCC-8A33-6416D4EE91F7']; pk='price_'+ids[r['idx']]; pd=json.load(open(sources[pk]['file']))
  F(v,'price_aud',pd['mlp'],[pk,'ioniq-5_api'],basis="Maker's recommended list price before on-road costs",comparison='Before on-road costs',reason='Fresh exact-grade price endpoint explicitly labels MLP and separate on-road costs; zero LCT shown for these regular variants.',qualifications=['Base/no-extra-cost paint; optional extras additional.'],priceRung=1,basisTag="Maker's list price",priceTag="Maker's list price",rankingEligible=True,sourcePointer='mlp; mlpFromPIM; onRoadCosts.lct=0',originalBasis='MLP including GST, excluding on-road costs')
  F(v,'driveaway_price_aud',pd['finalDriveAwayPrice'],[pk],grade='check',basis='Maker promotional driveaway price returned for NSW postcode 2000',comparison='Driveaway',condition='Illustrative NSW private-buyer configuration; dealer discount expiry 31 December 2026; options and eligibility must match.',qualifications=['Not established as a national unconditional price; retained as a separate offer, not substituted for higher-rung list price.'],priceRung=4,basisTag="Maker's NSW driveaway offer",state='NSW',rankingEligible=True,sourcePointer='finalDriveAwayPrice; dealerDiscount.expiryDate; postCode')
  F(v,'manufacturer_variant_id',ids[r['idx']],['ioniq-5_api'],basis='Live manufacturer configuration identity')
 # Core physical/technical measurements: only the corresponding maker MY/grade column.
 for k,val,bas,cmp in [
  ('range_km',r['range'],'WLTP combined laboratory range','WLTP'),('battery_kwh',r['battery'],'Manufacturer battery capacity; gross/usable unspecified','Published capacity, gross/usable unspecified'),
  ('ac_kw',10.5,'Maximum onboard AC charging capacity','AC kW'),('length_mm',4655,'Exterior length','Exterior length'),('width_mm',1890,'Exterior width; mirror inclusion unspecified',''),('height_mm',1605,'Exterior height including shark-fin antenna','Height including antenna'),('wheelbase_mm',3000,'Wheelbase','Wheelbase'),('ground_clearance_mm',160,'Manufacturer minimum ground clearance','Minimum ground clearance'),('turning_circle_m',11.98,'Minimum turning circle diameter between kerbs / walls, as labelled',''),('power_kw',r['power'],'Explicit manufacturer total motor output; not summed from component peaks','System power'),('torque_nm',r['torque'],'Explicit manufacturer total torque','System torque'),('boot_l',520,'Rear cargo minimum, VDA; seat/load position unspecified',''),('max_total_cargo_l',1580,'Rear cargo maximum, VDA; seat/load position unspecified',''),('frunk_l',24 if awd else 57,'Manufacturer front cargo volume, VDA; separate from rear luggage area','')]:
  F(v,k,val,basis=bas,comparison=cmp,qualifications=['No seats-up/folded or load-height basis is inferred from minimum/maximum labels.'] if k in ['boot_l','max_total_cargo_l'] else [])
 F(v,'dc_charge_time_min',18,grade='check',basis='DC 10–80% at a suitable 350 kW ultra-rapid station',comparison='DC 10–80%',condition='Approximately 18 minutes with a suitable 800 V charger, battery temperature and electricity supply; station and environmental conditions affect time.',qualifications=['350 kW is charging-station rating, not vehicle maximum DC acceptance.'])
 U(v,'dc_peak_kw','Both sources publish charger-station ratings/times but no explicit vehicle maximum DC acceptance; 350 kW is not promoted.')
 F(v,'ac_charge_time',475 if r['battery']==63 else 650,grade='check',basis='AC 10–100% at 7 kW; minutes',comparison='AC 10–100% at 7 kW',condition='Quoted approximate time at 7 kW supply; source does not promise this time at the onboard 10.5 kW maximum.')
 F(v,'dc_charge_time_at50_kw',58 if r['battery']==63 else 76,grade='check',basis='DC 10–80% at a 50 kW station',comparison='DC 10–80% at 50 kW',condition='Approximate test time; source station rating and battery conditions must match.')
 for k,val in [('towing_braked_kg',750 if r['battery']==63 else 1600),('towing_unbraked_kg',750),('tow_ball_max',100)]:F(v,k,val,grade='check',basis='Manufacturer maximum '+k.replace('_',' '),comparison='Braked towing' if k=='towing_braked_kg' else '',condition='Correctly rated towbar/tow ball and towing equipment required; current MY27 specifies extra-cost Hyundai Genuine towbar fitted by authorised dealer.')
 F(v,'tare_mass_declared',(1965 if r['battery']==63 else (2065 if g=='base' else 2075 if g=='elite' else 2190 if g=='premium' else 2095 if g=='dynamiq' else 2135)),basis='Manufacturer tare mass; not kerb weight')
 # Tare values for old N Line are replaced below from exact source table, never guessed.
 U(v,'kerb_weight_kg','Maker gives tare mass rather than compatible kerb weight; no kerb substitution or GVM-minus-payload calculation.')
 seatss=([r['second']] if residual else [['stock_i5'],['cg-elite-spec'],['stock_premium']][r['idx']])
 F(v,'seats',5,seatss,grade='reported',basis='Exact named advertised Australian version seating capacity',comparison='Seats',reason='Dealer/secondary exact configuration declares five seats; current maker technical matrix does not state total seating count.')
 if not residual:
  zsrc=['demo_i5','cg-elite-spec','cg-premium-spec'][r['idx']]
  F(v,'zero_to_100_s',[7.4,7.4,5.3][r['idx']],[zsrc],grade='reported',basis='Australian secondary specification; named MY27 base/Elite or current N Line Premium grade',comparison='0–100 km/h',reason='Current maker MY27 sheet does not publish acceleration; secondary named-grade specification retained visibly and unranked.',qualifications=['Premium source uses calendar-year 2026 price-guide label; current grade/84 kWh/AWD/495 km matches, but no maker test protocol is established.'] if g=='premium' else [])
 else:U(v,'zero_to_100_s','Exact residual dealer and correct-MY manufacturer sheet do not give an unambiguous 0–100 km/h test; no newer sibling acceleration is carried over.')
 # Equipment matrix, all explicitly checked against the matching MY PDF, not inherited across MY changes.
 top=g in ['premium','epiq']; middle=g in ['elite','dynamiq']; heated=top or middle
 equip={
 'battery_chemistry':'lithium-ion','battery_thermal_management_medium':'liquid','heat_pump':True,'battery_heating':True,
 'ac_connector':'Type 2','dc_connector':'CCS Combo 2','dc_charger_voltage_compatibility':[400,800],
 'front_heated_seats':'3-stage' if heated else False,'front_ventilated_seats':'3-stage' if top else False,'rear_heated_seats':'2-stage rear outboard' if top else False,'heated_steering_wheel':top,
 'auto_comfort_control':(top or (my>=2026 and g=='elite')),'screens_hud':{'instrumentInches':12.3,'multimediaInches':12.3,'headUpDisplay':heated},
 'power_tailgate':heated,'glass_roof':'fixed Vision Roof with power sunshade' if top else False,'audio_system':'Bose 8-speaker audio with external amplifier' if heated else '6-speaker audio',
 'wireless_phone_charging':15,'wireless_charger_cooling':True,'spare_wheel':'Tyre Mobility Kit','phone_projection':'Apple CarPlay and Android Auto; wired/wireless transport not specified in this MY sheet',
 'isofix_locations':'rear outboard','top_tether_anchors':3,'folding_mirrors':'power folding with auto fold','passive_unlock':'power-retractable handles with approach open/unlock',
 'charge_port_operation':'power charge flap open/close','camp_utility_mode':'Utility mode uses the high-voltage battery to power vehicle electronics',
 'adas_standard':'FCA car/pedestrian/cyclist and junction functions; BCA, LKA/LFA, SCC Stop & Go, navigation-based cruise, HDA, rear cross-traffic avoidance, reverse parking collision avoidance',
 'parking_cameras':'Surround View Monitor including 3D surround, rear camera and Blind-Spot View Monitor','remote_summon':'Remote Smart Parking Assist via Smart Key; perpendicular/parallel and forward/reverse parking functions',
 'driver_alerts':'Driver Attention Warning and Leading Vehicle Departure Alert; Intelligent Speed Limit Assist','app_connectivity':'Bluelink connected car service',
 'navigation':'Satellite navigation with live traffic via Bluelink','smart_key_push_button_start':True,
 'energy_consumption':(15.58 if r['battery']==63 else 17.20 if g in ['dynamiq','epiq'] else [16.04,16.99,18.11][r['idx']]),
 'energy_consumption_cycle':'WLTP combined' if my==2025 else 'ADR 81/02 combined (specific footnote); range separately WLTP',
 'wheels':{'diameterInches':19 if g=='base' else 20,'tyres':'235/55R19 105W' if g=='base' else '255/45R20 105W'},
 'front_seat_adjustment':'12-way powered driver/passenger with Relaxion comfort function' if top else '10-way powered driver/passenger' if middle else '10-way powered driver; manual passenger',
 }
 for k,x in equip.items():F(v,k,x,basis='Exact '+str(my)+' Australian '+g+' grade equipment/technical row',comparison='ADR 81/02' if k=='energy_consumption' and my>=2026 else 'WLTP' if k=='energy_consumption' else '')
 if my>=2026:
  F(v,'digital_key2',True)
  F(v,'ota_capability_scope','OTA software update capability',['ioniq-5_api'] if my==2027 else [r['spec']],qualifications=['Capability does not imply every control module can be updated remotely.'])
 else:
  U(v,'digital_key2','Correct MY25 sheet and exact dealer advert do not establish Digital Key 2; current MY27 feature is not inherited.')
  F(v,'ota_capability_scope','OTA software update capability')
 if my<2027:
  F(v,'v2l_power_declared',3.6,basis='Explicit maker V2L output 250 V, 3.6 kW, 15 A; not calculated')
  F(v,'v2l_interior_connector','domestic 3-pin plug output')
  F(v,'portable_charging_cable','ICCB domestic 3-pin input to Type 2, 230 V 10 A',basis='Maker portable emergency charging-cable specification')
 else:
  # The removed MY26 rows are useful sibling evidence, but not current-MY confirmed fitment.
  F(v,'v2l_power_declared',3.6,['i5_my26'],grade='reported',basis='Previous MY26 sibling V2L specification, not current MY27 confirmation',reason='MY27 technical sheet omits the MY26 V2L row; only older sibling output is retained, visibly unranked.',qualifications=['Do not promise MY27 socket/adapter fitment from this older source.'])
  F(v,'portable_charging_cable','MY26 sheet described ICCB domestic 3-pin to Type 2 cable',['i5_my26'],grade='reported',basis='Previous MY26 supplied-cable row; MY27 inclusion not established',reason='MY27 current sheet removed the portable-cable section; no automatic equipment carryover.')
 F(v,'ancap_rating','5 stars, 2021 rating; regular IONIQ 5 variants, N excluded',['ancap-i5'],basis='ANCAP current applicability',reason='Current ANCAP page explicitly all variants except IONIQ 5 N, on-sale September 2021 onwards, expires December 2027.')
 v['summary']={'strength':{'label':'Claimed range and charging','text':f"{r['range']} km WLTP combined range and an approximately 18-minute DC 10–80% claim on a suitable ultra-rapid charger.",'keys':['range_km','dc_charge_time_min']},'tradeoff':{'label':'Fewer seat comforts' if not top else 'Large-car footprint','text':'Front-seat ventilation and rear-seat heating are not fitted.' if not top else 'A 4,655 mm body and 11.98 m published turning circle need room when parking.','keys':['front_ventilated_seats','rear_heated_seats'] if not top else ['length_mm','turning_circle_m']}}
 variants.append(v)
# N evidence refresh: source bytes matched; all inherited fact keys are reconsidered.
sourceMap={'r10_hy_hn_hyundai_ioniq5n_specs':'i5n_spec','r10_hy_hn_hyundai_ioniq6n_specs':'i6n_spec','r10_hy_hn_chullora_ioniq5n_new':'chullora-n','r10_hy_hn_werribee_ioniq6n_new':'stock_i6n','r10_hy_hn_hyundai_ioniq5n_calculator':'ioniq-5-n_api','r10_hy_hn_hyundai_ioniq6n_calculator':'ioniq-6-n_api','r10_hy_hn_ancap_ioniq5':'ancap-i5','r10_hy_hn_ancap_ioniq6_report':'ancap-i6'}
OMIT={'warranty','battery_warranty','vehicle_warranty','battery_warranty_terms','battery_warranty_capacity_threshold','roadside_support_initial','track_use_warranty'}
for b in B:
 if b['id'] not in ['hyundai_ioniq_5_n_84_awd__20261010','hyundai_ioniq_6_n_84_awd__20261010']:continue
 six='6_n' in b['id'];sp='i6n_spec' if six else 'i5n_spec';page='i6n-page' if six else 'i5n-page';api='ioniq-6-n_api' if six else 'ioniq-5-n_api';render='i6n-rendered-full' if six else 'i5n-rendered-full'
 v={'id':b['id'],'model':b['model'],'trim':b['trim'],'modelId':b['modelId'],'modelYear':b['year'],'drive':'AWD','metadata':{},'metadataReason':'Current linked AU N technical identity retained; roof configurations are not additive versions. '+('Printed 2026 maker heading retained.' if six else 'No formal MY assigned from a dealer title or old filename; current Vision Roof selector is separately verified.'),'identitySourceKeys':[sp,page,api,render],'availability':availability([page,api,render]),'facts':[],'features':[],'_spec':sp,'_second':page,'_grade':'n','_my':b['year']}
 for k,old in b['facts'].items():
  if k in OMIT:continue
  ss=[sourceMap[s] for s in old['sourceIds'] if s in sourceMap]
  value=old['value']
  # Visual review of IONIQ 6 N PDF pages 3–9 resolves merged cells, not isolated-line omission.
  if six and k.startswith('equipment_') and value is None:
   value='standard';ss=[sp]
  if value is None:
   U(v,k,{'towing_braked_kg':'Maker towing table says N/A, not a numeric zero capacity; model page supplies no numeric towing rating.','towing_unbraked_kg':'Maker towing table says N/A; no numeric capacity established.','frunk_l':'No numeric front cargo volume published; N/A is preserved separately where maker prints it.','boot_l':'Manufacturer cargo row supplies a volume but no compatible rear seats-up/loading definition.','max_total_cargo_l':'No compatible seats-folded/load-height measurement published.','ancap_rating':'The regular CE1 ANCAP report lists pre-N 53/77.4 kWh variants; it does not establish applicability to this 84 kWh N. No N-specific rating published in inspected sources.','ancap_stars':'No N-specific ANCAP star count is established; regular model rating cannot be inherited.','dc_peak_kw':'Maker lists 350 kW and 50 kW station test times, not an explicit maximum vehicle DC acceptance.','battery_gross_kwh':'84 kWh is not labelled gross in the maker sources.','battery_usable_kwh':'84 kWh is not labelled usable in the maker sources.','kerb_weight_kg':'Tare mass is published, not compatible kerb weight.','airbag_count':'Individual airbag types are listed but a numeric count is not explicitly declared; none is manufactured by counting grouped descriptions.'}.get(k,'No compatible exact N claim established in current-linked technical specification and current model page.'),[sp,'ancap-i6'] if six and k in ['ancap_rating','ancap_stars'] else None)
   continue
  if not ss:raise ValueError((b['id'],k,old['sourceIds']))
  secondary=any(sources[s]['source_type'] not in ['manufacturer','independent_safety_body'] for s in ss)
  grade='reported' if secondary else 'check' if value=='optional' else 'confirmed'
  cond='Optional equipment; inclusion depends on the stated configuration.' if value=='optional' else None
  quals=[q for q in old.get('qualifications',[]) if not any(x in q for x in ['2026-10-10','not a verified MY27','not independently checked','no printed formal MY','Current-linked AU PDF technical statement','options and delivered'])]
  add(v,fact(k,value,ss,grade,basis=old.get('basis',''),comparison=old.get('comparisonBasis',''),reason=('Fresh dealer exact N seating declaration, not a maker seating statement.' if secondary else 'Fresh maker source re-read; byte-identical technical PDF preserves the exact claim. Generic source age or model-year filename alone does not reduce grade.'),condition=cond,quals=quals,sourcePointer='; '.join(q for q in quals if 'sourceId:' in q)))
 # Explicit canonical meanings, no cargo-method or charger-acceptance inventions.
 F(v,'range_km',487 if six else 448,basis='WLTP combined laboratory range',comparison='WLTP')
 F(v,'battery_kwh',84,basis='Published battery capacity; gross/usable unspecified',comparison='Published capacity, gross/usable unspecified')
 F(v,'ac_kw',10.5,basis='Maximum onboard AC charging capacity',comparison='AC kW')
 F(v,'dc_charge_time_min',18,grade='check',basis='Approximate DC 10–80% using a 350 kW station',comparison='DC 10–80%',condition='Suitable charger and battery temperature/environment required; 350 kW is station capability, not vehicle acceptance.')
 F(v,'dc_charge_time_at350_kw',18,grade='check',basis='Approximate DC 10–80% using 350 kW station',comparison='DC 10–80%',condition='Suitable charging conditions; charger rating is not vehicle acceptance.')
 F(v,'dc_charge_time_at50_kw',81 if six else 70,grade='check',basis='Approximate DC 10–80% using 50 kW station',comparison='DC 10–80% at 50 kW',condition='Suitable charging conditions and the stated station output.')
 F(v,'ac_charge_time',684 if six else 650,grade='check',basis='AC 10–100% at '+('7.4 kW' if six else '7 kW')+' supply; minutes',comparison='AC 10–100%',condition='Manufacturer approximate charging time at the stated supply; not a time at maximum onboard AC power.')
 F(v,'boot_l',371 if six else 480,basis='Rear VDA '+('cargo volume' if six else 'minimum volume')+'; seat/load-height definition unspecified',comparison='',qualifications=['Visible manufacturer volume, unranked for normalized seats-up boot comparison; no assumed seating position or load height.'])
 if not six:F(v,'max_total_cargo_l',1540,basis='Rear VDA maximum; folded-seat/load-height definition unspecified',comparison='',qualifications=['Do not relabel maximum as measured seats-folded capacity without source definition.'])
 F(v,'towing_capacity_manufacturer_statement','N/A',basis='Verbatim manufacturer towing-capacity declaration',reason='N/A retained as a statement; does not manufacture 0 kg.')
 if not six:F(v,'frunk_manufacturer_statement','N/A',basis='Maker front cargo declaration; no numeric conversion')
 for k,cmp in [('length_mm','Exterior length'),('height_mm','Exterior height'),('wheelbase_mm','Wheelbase'),('power_kw','Normal total system power'),('torque_nm','Normal total system torque')]:
  fm=fmap(v)[k];fm['basis']={'power_kw':'Explicit manufacturer total power without N Grin Boost; not a sum','torque_nm':'Explicit manufacturer total torque without N Grin Boost; not a sum'}.get(k,'Manufacturer '+cmp.lower());fm['comparison']=cmp
 fmap(v)['width_mm']['basis']='Manufacturer exterior width; mirror inclusion unspecified';fmap(v)['width_mm']['comparison']=''
 F(v,'zero_to_100_s',3.4 if six else 3.5,basis='Manufacturer normal 0–100 km/h acceleration',comparison='0–100 km/h')
 for k in ['boost_power','boost_torque','front_motor_boost_power','rear_motor_boost_power','boost_duration']:
  fm=fmap(v)[k];fm['grade']='check';fm['condition']='N Grin Boost activated; temporary maximum output for 10 seconds.';fm['basis']='Maker explicitly published N Grin Boost '+k.replace('_',' ');fm['comparison']=''
 F(v,'acceleration0_to100_enhanced',3.2 if six else 3.4,grade='check',basis='Manufacturer enhanced 0–100 km/h '+('with N Launch Control' if six else 'with N Grin Boost'),comparison='',condition='Enhanced launch/boost mode and suitable conditions required; kept separate from normal acceleration.')
 F(v,'energy_consumption',18.7 if six else 21.2,basis='ADR 81/02 combined per specific footnote' if six else 'WLTP combined',comparison='ADR 81/02' if six else 'WLTP')
 F(v,'roof','optional tilt-and-slide sunroof' if six else 'Vision Roof fixed glass panel with power sunshade included',[sp,api] if six else [api,render],grade='check' if six else 'confirmed',condition='Sunroof must be selected; not a separate additive version.' if six else None,reason='Current configuration selection controls roof inclusion; old IONIQ 5 N optional-roof statement is superseded for the current named Vision Roof version.')
 if not six:
  for f in v['facts']:
   if f['key'].startswith('equipment_') and 'vision_roof_fixed' in f['key']:
    f.update(value='standard',sourceKeys=[api,render],grade='confirmed',basis='Current N with Vision Roof configuration',reason='Current sole selectable N version explicitly includes Vision Roof; old technical sheet optional status is not used for current inclusion.');f.pop('condition',None)
  nk=next((f['key'] for f in v['facts'] if f['key'].startswith('equipment_224_notes_')),None)
  if nk:F(v,nk,'Source footer notes, not an equipment fitment',reason='This inherited parser row contains footnotes and the legend, not a genuine equipment row; corrected rather than asserting standard equipment.')
 # The maker consumer renderer establishes state driveaway, but labels the MLP component before separately charged LCT.
 price=123728.71 if six else 123076.51
 F(v,'price_aud',price,[render,api],grade='check',basis="Maker's NSW driveaway estimate, postcode 2000",comparison='Driveaway',condition='Sydney City Hyundai, NSW private purchaser with good driving record; base/no-extra-cost paint, no accessories or prepaid servicing. State, dealer, insurer and personal circumstances can alter the estimate.',reason='Rendered consumer price breakdown confirms this final driveaway amount. RRP/national-driveaway/from rungs were not honestly established: raw MLP omits separately shown LCT and conflicting PIM price is not promoted or arithmetically reconstructed.',qualifications=['IONIQ 6 N: Serenity White, no sunroof selected.' if six else 'IONIQ 5 N: included Vision Roof and no-cost Performance Blue.','Estimate includes listed vehicle price, estimated registration, CTP, stamp duty, dealer delivery and applicable LCT. Not an accepted order or firm quote.'],priceRung=4,basisTag="Maker's NSW driveaway estimate",priceTag="Maker's NSW driveaway estimate",state='NSW',rankingEligible=True,sourcePointer='Rendered expanded price breakdown: Estimated drive away price; disclaimer [D]',originalBasis='Manufacturer displayed NSW driveaway estimate')
 F(v,'driveaway_price_aud',price,[render],grade='check',basis="Maker's NSW driveaway estimate",comparison='Driveaway',condition='Same base configuration and NSW postcode 2000 conditions as price_aud.',priceRung=4,basisTag="Maker's NSW driveaway estimate",state='NSW',rankingEligible=True)
 F(v,'manufacturer_list_price_excluding_lct_aud',109551 if six else 109076.23,[render],basis='Rendered Manufacturer List Price Inc GST; LCT displayed separately',reason='Kept as a price component, not normalized consumer RRP.',rankingEligible=False)
 F(v,'rendered_luxury_car_tax_aud',5965.50 if six else 5823.07,[render],basis='Separate LCT component in NSW estimate',rankingEligible=False)
 F(v,'service_interval',{'months':24,'km':30000},[render],grade='check',basis='Pre-paid scheduled-service selector, Year 2/30,000 km and Year 4/60,000 km',condition='Scheduled servicing shown in current calculator; confirm delivered vehicle maintenance schedule and severe-use requirements.')
 # Configuration options remain nested; no double counting of roof toggles.
 ad=json.load(open(sources[api]['file']))[0];opts=[]
 for av in ad['variants']:
  opts.append({'manufacturerVariantId':av['id'],'manufacturerServiceId':av['serviceId'],'label':av['name'],'priceEstimateNSW':av['priceEstimate'],'rawMlpBeforeSeparateLct':av['price'],'sourceKeys':[api],'separateCatalogueVersion':False})
  pref='option_2' if six and 'Sunroof' in av['name'] else 'option_3' if six else 'option_1'
  for tail,value in [('manufacturer_variant_id',av['id']),('manufacturer_service_id',av['serviceId'])]:F(v,pref+'_'+tail,value,[api],basis='Fresh exact maker configuration identifier')
  raw={'price':av['price'],'priceEstimate':av['priceEstimate'],'currency':'AUD','referencePostcode':'2000','dealer':'Sydney City Hyundai','optionPacks':av.get('optionPacks',[]),'status':'state_driveaway_rendered','basis':'Raw MLP is not consumer RRP; renderer separates LCT. Final NSW driveaway is admitted separately; raw option arithmetic is not used.'}
  F(v,pref+'_raw_calculator_price',raw,[api,render],basis='Raw manufacturer API object with rendered price-component interpretation',rankingEligible=False)
 v['configurations']=opts
 # Grouped cells visually checked; current source claims retained even where a past parser missed the dot.
 extra={'driver_profiles_local':'3 local user profiles: Driver 1, Driver 2 and Guest','passive_unlock':'power-retractable handles with approach open/unlock','charge_port_operation':'power charge flap open/close','folding_mirrors':'power folding with auto fold','camp_utility_mode':'Utility mode powers vehicle electronics from high-voltage battery','remote_summon':'Remote Smart Parking Assist via Smart Key: perpendicular, parallel, diagonal and forward/reverse parking functions','power_tailgate':'power open/close with adjustable height/speed and hands-free opening','parking_cameras':'3D Surround View Monitor, rear camera and Blind-Spot View Monitor','driver_alerts':'Driver Attention Warning, Leading Vehicle Departure Alert, Intelligent Speed Limit Assist','adas_standard':'FCA, BCA, LKA/LFA, SCC Stop & Go, HDA, navigation-based cruise, rear cross-traffic avoidance and parking collision avoidance','auto_comfort_control':True,'smart_key_push_button_start':True}
 for k,value in extra.items():F(v,k,value,basis='Current linked AU N specification equipment group',reason='Equipment row/group inspected; IONIQ 6 N merged standard-fitment cells visually checked on PDF pages 3–9 where applicable.')
 F(v,'digital_key2',True,[sp,api] if six else [api],basis='Current named N Digital Key 2 inclusion')
 F(v,'ota_capability_scope','OTA software update capability',[api],qualifications=['Capability does not establish every module or update is remote.'])
 F(v,'app_connectivity','Bluelink connected car service',[sp,api])
 F(v,'navigation','Satellite navigation with live traffic and charging-station POI; charging-stop route algorithm not established')
 if not six:
  F(v,'remote_preconditioning','Bluelink remote cabin climate and start/stop conditioning')
  F(v,'voice_assistant','Server-based natural voice recognition including vehicle control and information commands')
 else:
  # Current 6 N PDF gives Bluelink inclusion, not the older 5 N detailed remote-service matrix.
  F(v,'remote_preconditioning','Bluelink remote climate described on the IONIQ 5 N sibling',['i5n_spec'],grade='reported',basis='Sibling connected-service detail, not current 6 N specific published function',reason='Do not silently inherit the sibling function as confirmed from the Bluelink name alone.')
  F(v,'voice_assistant','Server-based natural voice described on the IONIQ 5 N sibling',['i5n_spec'],grade='reported',basis='Sibling service detail only',reason='Current IONIQ 6 N PDF does not explicitly enumerate the voice function.')
 v['summary']={'strength':{'label':'Performance with seat comfort','text':f"{3.4 if six else 3.5} seconds claimed from 0–100 km/h in normal mode, with heated and ventilated front seats.",'keys':['zero_to_100_s','heated_front_seats','ventilated_front_seats']},'tradeoff':{'label':'Manual front-seat adjustment','text':'The front bucket seats adjust manually, despite their heating and ventilation.','keys':['front_seat_adjustment','heated_front_seats','ventilated_front_seats']}}
 variants.append(v)
# Correct exact technical values after side-by-side matrix review.
for v in variants:
 if v['_grade']!='n':
  if v['_my']==2025:F(v,'tare_mass_declared',1960 if fmap(v)['battery_kwh']['value']==63 else 2085,basis='Correct MY25 Standard Range or N Line RWD column, tare mass; not kerb weight')
  if v['_my']==2026:
   U(v,'ota_capability_scope','Correct MY26 technical sheet and exact dealer advert do not explicitly enumerate OTA scope; current MY27 API is not silently carried back.')
  if v['_my']==2025:
   F(v,'remote_preconditioning','Bluelink remote cabin climate and start/stop conditioning',grade='check',condition='Activated Bluelink, compatible app/device and functioning mobile network required; inclusion does not imply every remote function works offline.')
   F(v,'voice_assistant','Server-based natural voice recognition for vehicle controls and information',grade='check',condition='Bluelink activation and network/device compatibility required.')
  if v['_grade'] in ['premium','epiq']:
   F(v,'driver_memory_positions',2,basis='Two driver seat/mirror memory positions, not cloud profile transfer')
  F(v,'rear_motor_power',165 if v['drive']=='AWD' else fmap(v)['power_kw']['value'],basis='Explicit rear motor output, not a calculated system total')
 if v['_grade']=='n' and 'bluelink_included_period' in fmap(v):
  f=fmap(v)['bluelink_included_period'];f['grade']='check';f['condition']='Five years from first registration; seven years only when qualifying authorised-dealer servicing conditions are met; compatible device, activation and network required.'
 if v.get('isNewIdentity'):
  v['availability']['state']='current_or_order_listed';v['availability']['orderStatus']='unverified'
 # Core negatives are never fabricated from silence. N stars remain null even though regular siblings have a rating.
 if v['_grade']=='n' and '5_n' in v['id']:
  U(v,'ancap_stars','Current ANCAP explicitly excludes IONIQ 5 N; no N star rating is established.',['ancap-i5','i5n_spec'])
 # Each row has canonical string value and dependencies, including full-row unknowns.
 n=v['_grade']=='n'; fm=fmap(v)
 simple={
 'passive_unlock':'passive_unlock','automatic_seat_climate':'auto_comfort_control','heated_steering_wheel':'heated_steering_wheel','folding_mirrors':'folding_mirrors','camp_utility_mode':'camp_utility_mode','remote_summon':'remote_summon','charge_port_operation':'charge_port_operation','ota_capability_scope':'ota_capability_scope','navigation_route_planner':'navigation','adas_standard':'adas_standard','parking_cameras':'parking_cameras','driver_alerts':'driver_alerts','heat_pump':'heat_pump','battery_chemistry':'battery_chemistry','app_connectivity':'app_connectivity','spare_tyre':'spare_wheel','power_tailgate':'power_tailgate','performance_rear_motor':'rear_motor_power',
 'front_heated_seats':'heated_front_seats' if n else 'front_heated_seats','front_ventilated_seats':'ventilated_front_seats' if n else 'front_ventilated_seats',
 'rear_heated_seats':'rear_heated_seats','audio_system':'audio' if n else 'audio_system','carplay_android_auto':'phone_projection','remote_preconditioning':'remote_preconditioning','voice_assistant':'voice_assistant'}
 for c,k in simple.items():
  if k not in fm or fm[k]['value'] is None:continue
  val=fm[k]['value'];label='Not fitted' if val is False else 'Standard' if val is True else str(val) if not isinstance(val,(dict,list)) else '; '.join(val) if isinstance(val,list) else json.dumps(val)
  if c=='performance_rear_motor':label=f'{val} kW rear motor, manufacturer component rating'
  conditions='Close-range key-operated parking assistance; not driverless destination navigation.' if c=='remote_summon' else 'SmartSense assists the driver and does not make the vehicle autonomous.' if c=='adas_standard' else 'Compatible activated Bluelink app/device, subscription and mobile coverage required.' if c in ['app_connectivity','remote_preconditioning','voice_assistant'] else 'Compatible smartphone/device required.' if c=='carplay_android_auto' else ''
  fg='check' if c in ['app_connectivity','remote_preconditioning','voice_assistant','carplay_android_auto'] and fm[k]['grade']=='confirmed' else None
  feat(v,c,label,[k],grade=fg,conditions=conditions)
 if fm.get('digital_key2',{}).get('value') is True:
  feat(v,'phone_key','Digital Key 2',['digital_key2'],grade='check',conditions='Compatible mobile device, Bluelink app and active subscription required; not intended as a permanent physical-key replacement.')
 if 'driver_profiles_local'in fm:feat(v,'driver_profiles_local',fm['driver_profiles_local']['value'],['driver_profiles_local'])
 elif 'driver_memory_positions'in fm:feat(v,'driver_profiles_local','Two driver seat/mirror memory positions; cloud transfer not established',['driver_memory_positions'])
 if n:
  feat(v,'screens_hud','12.3-inch instrument and multimedia screens with head-up display',['instrument_cluster','infotainment_display','head_up_display'])
  feat(v,'glass_roof',fm['roof']['value'],['roof'],conditions='Roof configurations remain nested; optional IONIQ 6 N sunroof must be selected.' if '6_n'in v['id'] else '')
  feat(v,'wireless_charging','15 W Qi wireless phone charging',['wireless_phone_charging'],grade='check',conditions='Compatible Qi device required.')
  if '5_n'in v['id']:feat(v,'safety_ancap','Regular IONIQ 5 ANCAP rating explicitly excludes N',['ancap_rating'],reason='Official safety authority exact exclusion; regular five-star score is not assigned to N.')
  # N 6 V2L current and voltage/current are declared; no power is calculated from them.
  feat(v,'v2l','Interior domestic 3-pin V2L; '+('250 V / 16 A, kW not declared' if '6_n'in v['id'] else 'maker-declared 3.6 kW, 250 V / 15 A'),['v2l_interior_connector','v2l_output_declared'])
 else:
  sc=fm['screens_hud']['value'];feat(v,'screens_hud','12.3-inch instrument and multimedia screens; '+('head-up display fitted' if sc['headUpDisplay'] else 'no head-up display'),['screens_hud'])
  feat(v,'glass_roof','Vision Roof fixed glass with powered sunshade' if fm['glass_roof']['value'] else 'Not fitted',['glass_roof'])
  feat(v,'wireless_charging','15 W Qi wireless charging pad with cooling',['wireless_phone_charging','wireless_charger_cooling'],grade='check',conditions='Compatible Qi-enabled device or adaptor required.')
  feat(v,'safety_ancap',fm['ancap_rating']['value'],['ancap_rating'])
  feat(v,'v2l','MY26 sibling declared 3.6 kW; current MY27 fitment/output not established' if v['_my']==2027 else 'Interior domestic 3-pin V2L, explicitly rated 3.6 kW',['v2l_power_declared'],conditions='No extrapolation from previous MY to current equipment.' if v['_my']==2027 else '')
 feat(v,'child_seats','ISOFIX at rear outboard seats; three rear top-tether anchors',['isofix_locations','top_tether_anchors'])
 feat(v,'storage',f"Rear cargo {fm['boot_l']['value']} L VDA; seats-up/load-height definition not stated"+('; separate front cargo '+str(fm['frunk_l']['value'])+' L' if fm.get('frunk_l',{}).get('value') is not None else ''),['boot_l']+(['frunk_l'] if fm.get('frunk_l',{}).get('value') is not None else []),conditions='Minimum/maximum source labels do not establish seats-up/folded loading method; cargo figures remain unranked on that basis.')
 feat(v,'energy_use',str(fm['energy_consumption']['value'])+' kWh/100 km; '+fm['energy_consumption_cycle']['value'],['energy_consumption','energy_consumption_cycle'],conditions='Published laboratory cycle, not a real-world consumption or electricity-cost promise.')
 feat(v,'home_charging',f"{fm['ac_kw']['value']} kW maximum onboard AC; {fm['ac_charge_time']['basis']}: {fm['ac_charge_time']['value']} minutes",['ac_kw','ac_charge_time'],conditions=fm['ac_charge_time'].get('condition',''))
 feat(v,'driveaway_price',f"A${fm['driveaway_price_aud']['value']:,.2f}; "+fm['driveaway_price_aud']['basis'],['driveaway_price_aud'],conditions=fm['driveaway_price_aud'].get('condition','Dealer-advertised exact residual unit; verify state, inclusions and availability.'))
 if fm.get('portable_charging_cable',{}).get('value') is not None:feat(v,'charging_cable',str(fm['portable_charging_cable']['value']),['portable_charging_cable'])
 criteria=sorted({f['criterion'] for f in FB})
 omitted={'warranty_service','roadside_assistance'}
 existing={f['criterion'] for f in v['features']}
 reasons={
 'automatic_start':'Push-button start is published; automatic walk-in/seat-occupancy start is not established.',
 'automatic_shutdown':'No exact automatic walk-away/shutdown behaviour is published in the two inspected sources.',
 'walk_away_lock':'Active/approach lock-unlock does not establish automatic walk-away locking.',
 'battery_preconditioning_navigation':'Battery heating/conditioning is published, but automatic navigation-triggered battery preconditioning is not explicitly established for this exact version.',
 'traffic_light_chime':'Leading Vehicle Departure Alert does not establish a traffic-signal green-light chime.',
 'adas_optional':'Standard SmartSense is listed; a distinct purchasable optional ADAS package is not established.',
 'safety_ancap':'No N-specific rating applicability is established; regular CE1 53/77.4 kWh rating cannot be transferred to 84 kWh N.',
 'real_world_range':'No reproducible exact-version real-world range test is established in these sources; WLTP is retained separately.',
 'insurance_cost':'No exact buyer-specific insurance premium published; no estimate is invented.',
 'resale_value':'No substantiated future resale value established; no forecast invented.',
 'ride_control_subjective':'Specification hardware is documented separately; no sourced exact-version subjective ride assessment is asserted.',
 'interior_fit_finish_subjective':'Materials are listed, but no sourced exact-version hands-on fit/finish assessment is asserted.',
 'style_refinement':'No sourced exact-version subjective refinement judgement is asserted.',
 'alert_sound_quality':'Safety alerts are documented separately; their subjective sound quality is not established.',
 'novated_fbt':'No claim about this buyer, tax eligibility, delivery date or finance agreement is established; generic leasing links are not eligibility proof.',
 'rear_heated_seats':'Heated rear windshield does not establish heated rear seats; no exact rear-seat heating statement found.',
 'battery_density':'No compatible pack gravimetric/volumetric density published; not calculated from whole-vehicle mass.',
 'bidirectional_v2g':'V2L supply does not establish Australian vehicle-to-grid compatibility or approval.',
 'supercharger_access':'CCS hardware does not establish access to every Tesla Supercharger site or account.'}
 for c in criteria:
  if c in existing or c in omitted:continue
  why=reasons.get(c,'No exact '+c.replace('_',' ')+' claim established in the two inspected source documents; absence of a published claim is not an equipment absence assertion.')
  ss=[v['_spec'],'ancap-i6'] if c=='safety_ancap' and '6_n'in v['id'] else [v['_spec'],v['_second']]
  k='feature_'+c;U(v,k,why,ss);feat(v,c,'Not published',[k],grade='not_published',conditions=why,reason='Two real source-document searches recorded for this exact criterion.')
 # Explicit refresh scope: parent supplies brand terms; nothing else inherits an older non-null claim silently.
 v['warrantyHandling']='Parent merges freshly reviewed brand warranty/battery/roadside terms and N track-use exception.'
