exec(open('/tmp/hyundai-research/ioniq5-6/fetch.py').read().split('with concurrent')[0])
rows=[('kloster-new','https://www.klosterhyundai.com.au/search/new-cars'),('kloster-model','https://www.klosterhyundai.com.au/models/ioniq-5-3'),('aspley-epiq-nline','https://www.aspleyhyundai.com.au/all-stock/view/2024-Hyundai-Ioniq-5-Y349362-KMHKR81AUSU349362/34125707'),('cg-base26','https://www.carsguide.com.au/car/15309338/hyundai/ioniq-5/nsw/liverpool/suv'),('cg-elite26','https://www.carsguide.com.au/car/15123291/hyundai/ioniq-5/nsw/hamilton-east/suv'),('cg-regular6','https://www.carsguide.com.au/car/14861313/hyundai/ioniq-6/sedan')]
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as e:res=list(e.map(get,rows))
(P/'fetch-residual-manifest.json').write_text(json.dumps(res,indent=2))
