"""Prepare an immutable explicit-pin contract, or seal it only after independent review.
No application imports, hydration, feature invocations, original-pin scans, or phase execution.
"""
import argparse, hashlib, json, pathlib, re, shlex
ROOT = pathlib.Path('/tmp/subaru-feature-ranges-v3')
S = pathlib.Path('/tmp/subaru-staging-plan')
C = S / 'candidate'
V = pathlib.Path('/tmp/subaru-staging-continuation-v2')
P = pathlib.Path('/tmp/subaru-derived-proof-plan')
REPO = pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104')
QA = REPO.parent / 'roadmark-104-qa'
CHECKS = QA / 'subaru-derived-staging-checks'
SCRIPTS = ['range-helpers.mjs', 'stage-feature-range.mjs', 'aggregate-feature-ranges.mjs', 'prepare-feature-ranges.py']
DIFFS = ['stage-feature-range.mjs.patch', 'aggregate-feature-ranges.mjs.patch', 'range-helpers.mjs.patch']
NODE = ['node', '--max-old-space-size=320', '--max-semi-space-size=1', '--expose-gc', '--import', 'tsx']
TRUE = ['allOriginalAlgorithmsAssertionsAndCompleteComparisonsPreserved', 'all399CarInputsVerifiedInEveryRange', 'all14ResearchFieldsCheckedBeforeAndAfter', 'original1072AndContinuation48PinsPreserved', 'actualConsumerInvokedForEveryOutputCar', 'exactOriginalOrdinalCoverage', 'all69UniqueCriteriaPerCar', 'all388OtherBrandFeatureSetsUnchanged', 'all11ActualPackFeatureSetsEqual', 'rawByteConcatenationAndFailedPrefixRequired', 'allEightMeasuredTerminalsRequired', 'sourceLineagePinned', 'failedEvidencePreserved', 'manifestSelectsAllPathsAndCommands']
FALSE = ['candidateRegistered', 'freshLoaderValidation', 'currentFullTypecheckVerified', 'registryEditsAuthorized', 'canonicalRecaptured', 'historicalExpectationsReset']

def read(file):
    return json.loads(pathlib.Path(file).read_text())

def pin(file):
    file = pathlib.Path(file)
    h = hashlib.sha256()
    with file.open('rb') as stream:
        for chunk in iter(lambda: stream.read(262144), b''):
            h.update(chunk)
    return {'path': str(file), 'sha256': h.hexdigest(), 'bytes': file.stat().st_size}

def write(file, value):
    file = pathlib.Path(file)
    with file.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
    return pin(file)

def approval_fields(contract, contract_pin):
    fields = {'status': 'approved_for_pinned_subaru_actual_feature_ranges_v3',
              'contractSha256': contract_pin['sha256'],
              'originalStageInputManifestSha256': contract['inputs']['stageManifest']['sha256'],
              'continuationManifestSha256': contract['inputs']['continuationManifest']['sha256'],
              'failedPartial': contract['inputs']['failedPartial'],
              'scriptPins': contract['scriptPins'], 'sourceDiffPins': contract['sourceDiffPins']}
    fields.update({key: True for key in TRUE})
    fields.update({key: False for key in FALSE})
    return fields

def prepare(run_id):
    assert re.fullmatch(r'[a-z0-9][a-z0-9_-]*', run_id)
    run_root = ROOT / 'runs' / run_id
    run_root.mkdir(parents=True, exist_ok=False)
    manifest_file = run_root / 'run-manifest.json'
    stage = read(S / 'stage-inputs.json')
    continuation = read(V / 'continuation-manifest.json')
    cc = read(V / 'continuation-contract.json')
    assert len(stage['executionInputs']) == 1072 and len(cc['executionInputs']) == 48
    original_pins = {row['path']: row for row in stage['executionInputs']}
    inputs = {
        'stageManifest': S / 'stage-inputs.json', 'continuationManifest': V / 'continuation-manifest.json',
        'continuationContract': V / 'continuation-contract.json',
        'continuationReview': pathlib.Path('/tmp/subaru-staging-review/feature-status-v2-continuation-review.json'),
        'originalFeatureScript': V / 'stage-full-feature-stream-subaru.mjs', 'stagedValues': V / 'staged-values.mjs',
        'continuationHelper': V / 'continuation-helpers.mjs', 'stageHelper': S / 'stage-proof-helpers.mjs',
        'proofHelper': P / 'helpers.mjs', 'consumerTransitionHelper': P / 'consumer-transition-helpers.mjs',
        'measuredWrapper': S / 'run-stage-measured.py',
        'standardBuffer': QA / 'catalogue-snapshot-reuse/standard-row-utf8-buffer.mjs',
        'actualConsumer': REPO / 'src/lib/evidence-consumers.ts', 'actualRegistry': REPO / 'src/lib/brand-update-registry.ts',
        'compiledSource': REPO / 'tests/helpers/compiled-source.ts',
        'coreReceipt': C / 'staged-core-receipt.json', 'storageIndex': C / 'staged-storage-index.json',
        'selectedCars': C / 'staged-after.json', 'selectedReceipt': C / 'staged-selected-consumer-receipt.json',
        'actualPacks': C / 'staged-packs.json', 'negativeReceipt': C / 'staged-negative-guards-receipt.json',
        'failedPartial': C / 'staged-all-features.jsonl', 'failedObservation': V / 'feature-attempt1-partial-observation.json',
        'correctedPacket': C / 'subaru-2026-10-15-feature-status-v2.json', 'originalPacket': C / 'subaru-2026-10-15.json',
        'canonicalPacket': C / 'canonical-packet-original.json', 'originalFeatureFixture': C / 'new-feature-before.json',
    }
    for key in ['baselineAcceptance', 'baselineIndex', 'consumerPhaseManifest', 'sourceTransitionReview', 'compositionReview', 'harnessReview']:
        inputs[key] = pathlib.Path(stage[key]['path'])
    acceptance = read(inputs['baselineAcceptance'])
    inputs['baselineFeatureReceipt'] = P / acceptance['phaseReceipts']['fullFeatures']['file']
    base_receipt = read(inputs['baselineFeatureReceipt'])
    inputs['baselineFeatureIndex'] = P / base_receipt['index']['file']
    inputs = {key: pin(file) for key, file in inputs.items()}
    assert inputs['stageManifest']['sha256'] == '0244f1e320dd6f5a0d52b4365e20c3e27e4905caaca4c7cfd2eec5ebb22844be'
    assert inputs['continuationManifest']['sha256'] == '99fae0e573de27661ab6a36031afffb68590a1c8b2ec1e062439e9dd42adad1a'
    assert inputs['failedPartial']['sha256'] == 'a18aa931ef92da538f7c68b77258a3ffafe20ffd5ab50aeb258bd80a1ba0ace4'
    assert inputs['failedPartial']['bytes'] == 5013840
    for key in ['baselineAcceptance', 'baselineIndex', 'consumerPhaseManifest', 'sourceTransitionReview', 'compositionReview', 'harnessReview']:
        assert inputs[key]['sha256'] == stage[key]['sha256']
    for key in ['measuredWrapper', 'stageHelper', 'proofHelper', 'consumerTransitionHelper', 'standardBuffer', 'actualConsumer', 'actualRegistry', 'compiledSource']:
        assert inputs[key]['sha256'] == original_pins[inputs[key]['path']]['sha256'], key
    assert continuation['contract']['sha256'] == inputs['continuationContract']['sha256']
    assert continuation['amendmentReview']['sha256'] == inputs['continuationReview']['sha256']
    assert inputs['baselineFeatureReceipt']['sha256'] == acceptance['phaseReceipts']['fullFeatures']['sha256']
    assert inputs['baselineFeatureIndex']['sha256'] == base_receipt['index']['sha256']
    core = read(inputs['coreReceipt']['path'])
    selected = read(inputs['selectedReceipt']['path'])
    negative = read(inputs['negativeReceipt']['path'])
    assert core['status'] == 'passed_pending_actual_pack_and_complete_report_phases'
    assert selected['status'] == 'passed_pending_negative_guards_and_complete_reports'
    assert negative['status'] == 'passed_pending_complete_reports_and_independent_review'
    assert negative['caseCount'] == len(negative['cases']) == 40
    for key, expected in [('storageIndex', core['storageIndex']), ('selectedCars', core['selectedCars']), ('actualPacks', selected['packFile'])]:
        assert inputs[key] == {'path': expected['file'], 'sha256': expected['sha256'], 'bytes': expected['bytes']}
    terminals = {}
    for key, name in [('core', 'core-feature-status-v2-attempt1'), ('selected', 'selected-feature-status-v2-attempt1'), ('negative', 'negatives-feature-status-v2-attempt1'), ('failed', 'features-feature-status-v2-attempt1')]:
        terminals[key] = {suffix: pin(CHECKS / name / suffix) for suffix in ['terminal.json', 'stdout.log', 'stderr.log']}
        terminal = read(terminals[key]['terminal.json']['path'])
        assert terminal['returncode'] == (-9 if key == 'failed' else 0)
        assert terminal['signal'] == (9 if key == 'failed' else None)
    plan = {'runRoot': str(run_root), 'manifestFile': str(manifest_file), 'measuredWrapper': str(S / 'run-stage-measured.py'),
            'inputStorageIndex': inputs['storageIndex']['path'], 'selectedCars': inputs['selectedCars']['path'],
            'originalPartial': inputs['failedPartial']['path'], 'ranges': []}
    for ordinal in range(8):
        stem = f'range-{ordinal:02d}'
        name = f'feature-ranges-v3-{run_id}-{stem}'
        plan['ranges'].append({'ordinal': ordinal, 'start': ordinal * 50, 'end': min((ordinal + 1) * 50, 399),
            'runName': name, 'output': str(run_root / f'{stem}.jsonl'), 'index': str(run_root / f'{stem}-index.json'),
            'receipt': str(run_root / f'{stem}-receipt.json'), 'terminal': str(CHECKS / name / 'terminal.json'),
            'command': NODE + [str(ROOT / 'stage-feature-range.mjs'), str(manifest_file), str(ordinal)]})
    aggregate_name = f'feature-ranges-v3-{run_id}-aggregate'
    plan['aggregate'] = {'runName': aggregate_name, 'output': str(run_root / 'all-features.jsonl'),
        'receipt': str(run_root / 'aggregate-receipt.json'), 'terminal': str(CHECKS / aggregate_name / 'terminal.json'),
        'finalIndex': str(C / 'staged-all-feature-index.json'), 'finalReceipt': str(C / 'staged-all-feature-receipt.json'),
        'command': NODE + [str(ROOT / 'aggregate-feature-ranges.mjs'), str(manifest_file)]}
    for phase in plan['ranges'] + [plan['aggregate']]:
        for key in ['output', 'index', 'receipt', 'terminal', 'finalIndex', 'finalReceipt']:
            if key in phase:
                assert not pathlib.Path(phase[key]).exists(), phase[key]
        assert not pathlib.Path(phase['terminal']).parent.exists()
    script_pins = [pin(ROOT / name) for name in SCRIPTS]
    diff_pins = [pin(ROOT / 'diffs' / name) for name in DIFFS]
    readme = pin(ROOT / 'README.txt')
    inventory = script_pins + diff_pins + [readme] + list(inputs.values()) + [row for group in terminals.values() for row in group.values()]
    assert len(inventory) == len({row['path'] for row in inventory})
    contract = {'schemaVersion': 1, 'mode': 'bounded-original-subaru-actual-feature-stream', 'asOf': '2026-10-15',
        'candidateId': 'm1-subaru-2026-10-15', 'runId': run_id, 'originalPinCount': 1072, 'continuationPinCount': 48,
        'reviewPath': f'/tmp/subaru-staging-review/feature-ranges-v3-{run_id}-review.json',
        'scriptPins': script_pins, 'sourceDiffPins': diff_pins, 'readme': readme, 'inputs': inputs, 'terminals': terminals,
        'plan': plan, 'executionInputs': inventory}
    contract.update({key: False for key in FALSE})
    contract_pin = write(run_root / 'range-contract.json', contract)
    write(run_root / 'independent-review-required-fields.json', {'status': 'template_only_not_approval',
        'instruction': 'Independent reviewer must establish every required assertion. This file does not authorize execution.',
        'requiredApprovedFields': approval_fields(contract, contract_pin)})
    write(run_root / 'run-manifest.draft.json', {'schemaVersion': 1, 'mode': 'subaru-actual-feature-ranges-v3',
        'status': 'draft_not_execution_authorization', 'asOf': '2026-10-15', 'contract': contract_pin,
        'independentReviewPath': contract['reviewPath'], 'plan': plan})
    print(json.dumps({'contract': contract_pin, 'independentReviewRequired': contract['reviewPath'],
                      'executionAuthorized': False, 'phaseExecutionStarted': False}, indent=2))

def seal(contract_file):
    contract_file = pathlib.Path(contract_file)
    contract = read(contract_file)
    run_root = ROOT / 'runs' / contract['runId']
    assert contract_file == run_root / 'range-contract.json'
    assert len(contract['executionInputs']) == len({row['path'] for row in contract['executionInputs']})
    for expected in contract['executionInputs']:
        assert pin(expected['path']) == expected, expected['path']
    contract_pin = pin(contract_file)
    review = read(contract['reviewPath'])
    for key, expected in approval_fields(contract, contract_pin).items():
        assert review.get(key) == expected, f'Independent approval missing or mismatched: {key}'
    manifest = {'schemaVersion': 1, 'mode': 'subaru-actual-feature-ranges-v3', 'status': 'approved_for_execution',
                'asOf': '2026-10-15', 'contract': contract_pin, 'independentReview': pin(contract['reviewPath']),
                'plan': contract['plan']}
    result = write(run_root / 'run-manifest.json', manifest)
    commands = ['# Explicit external SHA selection; execute one measured phase at a time from the repo.',
                'cd ' + shlex.quote(str(REPO)), 'unset NODE_OPTIONS',
                'export SUBARU_CONTINUATION_MANIFEST_SHA256=' + contract['inputs']['continuationManifest']['sha256'],
                'export SUBARU_FEATURE_RANGES_MANIFEST_SHA256=' + result['sha256']]
    for phase in contract['plan']['ranges'] + [contract['plan']['aggregate']]:
        commands.append(shlex.join(['python3', contract['plan']['measuredWrapper'], phase['runName']] + phase['command']))
    with (run_root / 'launch-commands.txt').open('x') as stream:
        stream.write('\n'.join(commands) + '\n')
    print(json.dumps({'sealedManifest': result, 'phaseExecutionStarted': False}, indent=2))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='action', required=True)
    prepare_parser = sub.add_parser('prepare')
    prepare_parser.add_argument('--run-id', required=True)
    seal_parser = sub.add_parser('seal')
    seal_parser.add_argument('--contract', required=True)
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare(args.run_id)
    else:
        seal(args.contract)
