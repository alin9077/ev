Subaru actual-feature range harness v3: bounded resource lifetime only

Scope and provenance
- The failed original full stream remains failed, unchanged, and retained at
  /tmp/subaru-staging-plan/candidate/staged-all-features.jsonl. Its 5,013,840 bytes,
  SHA a18aa931ef92da538f7c68b77258a3ffafe20ffd5ab50aeb258bd80a1ba0ace4,
  7,176 rows and 104 complete cars are comparison evidence only, never production input.
- No original harness, packet, core, canonical fixture, receipt, source, registry,
  historical expectation or failed log is modified. This is derived-only work.
- The unchanged report script continues consuming the original final index and
  receipt names. Those names are published once only after full aggregate success.
  Its features.file points at a new manifest-selected full stream, never the partial.
- All old release gates remain open; this does not establish fresh loader equality,
  a current full TypeScript pass, normal top-level reporting, or registry authority.

Bounded algorithm difference
The original one-process 399-car loop is divided into eight sequential fresh Node
processes: [0,50), [50,100), [100,150), [150,200), [200,250), [250,300), [300,350),
[350,399). Each range reconstructs the exact proven selected Subaru cars, streams
all 397 baseline cars in their retained original order, and appends the same two
new identities. Every range verifies all 399 complete staged car hashes, every
original baseline-car hash, duplicate/missing identity guards and exact ordinals.
Only actual effectiveFeatures invocation/output is restricted to the chosen range.
The actual compiled consumer factory, hypothetical existing-17-plus-one registry,
explicit derived inputs, 69 features and unique criteria, full pack comparisons,
other-brand accepted-baseline hashes, and StandardRowUtf8Buffer(JSON.stringify
(feature)+'\n') serialization remain the original algorithm.

Every range and the aggregate call original openStagedCore(), retaining its 1,072
original and 48 continuation input pins and original verification algorithms,
before work and through stage.verify() afterward. They load all 14 Research fields
and assert their complete in-memory digests unchanged after work. Packet and full
selected-car objects, all files, passed receipts, source lineage, failed partial,
failed terminal and logs are pinned and checked before and after. Neither old
partial bytes nor successful pack features replace any actual range invocation.

Aggregate proof
- Each of eight exact manifest-selected terminal files must say returncode 0,
  signal null, no inherited NODE_OPTIONS, and the exact phase command. Each range
  receipt/index binds its own inputProof and externally SHA-selected run manifest.
- The aggregate repeats all 399 full-car proofs and all-14 Research immutability,
  requires exact contiguous ordinal identities and 69 rows/unique criteria per car,
  then independently rechecks every output set against the same 11 actual packs
  or 388 accepted other-brand feature digests.
- Every range JSONL is checked against standard serialization and its raw file
  SHA/byte count. The aggregate copies exact raw phase bytes in original order,
  hashes that concatenation, and independently hashes the resulting full file.
- It verifies all 27,531 rows and the failed original's exact raw-byte prefix,
  including the first 104 cars/7,176 rows. The failed terminal remains -9/signal 9;
  no cause is inferred and no evidence is overwritten.
- Phase JSONL/index/receipt/terminal/stdout/stderr pins are rechecked before final
  publication. Aggregate's own measured terminal is created by the wrapper after
  process exit and remains separately required by the parent/final acceptance.

Immutable review and run selection (no self-referential hashes)
1. Finalize this harness and diffs, then prepare once with:
   python3 /tmp/subaru-feature-ranges-v3/prepare-feature-ranges.py prepare --run-id attempt1
   This hashes only explicit listed files and reads metadata. It does not run app
   imports, original-pin scans, Research hydration, consumers, tests or feature work.
   It creates an immutable range-contract.json, a non-authorizing review template,
   and a draft run manifest under /tmp/subaru-feature-ranges-v3/runs/<run-id>/.
2. An independent reviewer inspects the scripts/diffs/contract and writes the exact
   reviewPath in the contract. Approval requires its contract SHA, exact script/diff
   pins, source lineage, failed evidence, and all mandatory proof assertions.
3. Only after approval, the parent seals using:
   python3 /tmp/subaru-feature-ranges-v3/prepare-feature-ranges.py seal --contract <contract-path>
   The sealed manifest pins the immutable contract and independent review. Neither
   the contract nor the review includes the final manifest hash. It is selected
   externally via SUBARU_FEATURE_RANGES_MANIFEST_SHA256 and its exact path is a phase
   command argument. The old SUBARU_CONTINUATION_MANIFEST_SHA256 remains mandatory.
4. Parent runs the pinned original run-stage-measured.py wrapper with each exact
   manifest-selected runName and command, one phase at a time. Sealing writes the
   commands to launch-commands.txt but never executes them. All phases require new
   outputs and their own absent terminal; unsuccessful attempts remain evidence.
5. No feature phase is authorized by preparation or this README. Do not seal or run
   until independent review and the parent allow it. A revised/new run uses another
   reviewed contract and manifest with unique paths, not cloned algorithm scripts.

Review surfaces
- diffs/stage-feature-range.mjs.patch is against the unchanged continuation full
  stream and highlights extraction of shared checks plus ordinal invocation gating.
- diffs/range-helpers.mjs.patch and aggregate-feature-ranges.mjs.patch show entirely
  new shared checks and aggregation code. The originals remain immutable references.
