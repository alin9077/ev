/** Same actual consumer and row encoder as the original full stream, one approved ordinal range. */
import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {StandardRowUtf8Buffer} from '/workspace/scratch/586427eef9f2/roadmark-104-qa/catalogue-snapshot-reuse/standard-row-utf8-buffer.mjs';
import {roots,fileHash,digestRows,openRangeRun,assertProcessCommand,openFeatureInputs,inspectAllCars,verifyFeatureSet,readStagedResearch,writeNew} from './range-helpers.mjs';
assert.equal(process.argv.length,4);const run=openRangeRun(process.argv[2]),ordinal=Number(process.argv[3]);assert(Number.isInteger(ordinal)&&ordinal>=0&&ordinal<8);const range=run.plan.ranges[ordinal];assertProcessCommand(range.command);
for(const file of [range.output,range.index,range.receipt,range.terminal])assert(!fs.existsSync(file),'Range evidence must be new: '+file);
const inputs=openFeatureInputs(run),{stage,packet,index}=inputs;
const require=createRequire(roots.repo+'/package.json'),{brandUpdatePackets}=require('./src/lib/brand-update-registry.ts'),{compiledSource}=require('./tests/helpers/compiled-source.ts');assert.equal(brandUpdatePackets.length,17);assert(!brandUpdatePackets.some(p=>p.id===packet.id));
const forbidden=()=>{throw new Error('Full staged feature stream requires explicit derived inputs')};const factory=compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets:[...brandUpdatePackets,packet]}}).createEvidenceConsumers;const {effectiveFeatures}=factory({sourceResearch:forbidden,research:forbidden,catalogue:forbidden});
assert.equal(typeof global.gc,'function');global.gc();const data=await readStagedResearch(index);global.gc();
const fd=fs.openSync(range.output,'wx'),buffer=new StandardRowUtf8Buffer(),aggregate=crypto.createHash('sha256'),perCar=[];let count=0,bytes=0,matchedUnchanged=0,matchedSubaru=0,inspectedCars;
try{inspectedCars=await inspectAllCars(inputs,(car,carOrdinal,before)=>{
 if(carOrdinal<range.start||carOrdinal>=range.end)return;
 // Actual invocation is mandatory; packs and historical output are comparisons only.
 const features=effectiveFeatures(car,data);const result=verifyFeatureSet(car.id,features,inputs),featureDigest=result.featureDigest;matchedSubaru+=result.matchedSubaru;matchedUnchanged+=result.matchedUnchanged;
 for(const feature of features){const row=buffer.encode(JSON.stringify(feature)+'\n');let written=0;while(written<row.length){const n=fs.writeSync(fd,row,written,row.length-written);assert(n>0);written+=n}aggregate.update(row);bytes+=row.length;count++}
 assert.deepEqual(digestRows([car]),before);perCar.push({ordinal:carOrdinal,id:car.id,carSha256:before.sha256,carBytes:before.bytes,featureRows:featureDigest.rows,featureBytes:featureDigest.bytes,featureSha256:featureDigest.sha256});
 if(perCar.length%25===0){global.gc();console.log('Complete actual feature sets in range',ordinal,perCar.length,process.memoryUsage())}
})}finally{fs.closeSync(fd)}
const expected=index.cars.carHashes.slice(range.start,range.end);assert.equal(perCar.length,range.end-range.start);assert.equal(count,perCar.length*69);assert.equal(matchedSubaru+matchedUnchanged,perCar.length);assert.deepEqual(perCar.map(row=>row.id),expected.map(row=>row.id));assert.deepEqual(perCar.map(row=>row.ordinal),expected.map((_,i)=>range.start+i));
const sha256=aggregate.digest('hex');assert.equal(fileHash(range.output),sha256);assert.equal(fs.statSync(range.output).size,bytes);inputs.finish(data);
const rangeIndex=writeNew(range.index,{schemaVersion:1,mode:'Fresh actual feature invocations for one immutable ordinal range',range,features:{file:range.output,rows:count,bytes,sha256},cars:perCar.length,perCar,inspectedCars,subaruMatched:matchedSubaru,otherCarsExactlyUnchanged:matchedUnchanged,inputProof:inputs.inputProof});
writeNew(range.receipt,{status:'passed_range_pending_measured_terminal_and_aggregate',rangeOrdinal:ordinal,start:range.start,end:range.end,cars:perCar.length,featureRows:count,all399CompleteCarHashesVerified:true,all14ResearchFieldsUnchanged:true,packetObjectUnchanged:true,selectedCarsUnchanged:true,actualConsumerInvocations:perCar.length,actualFeatureSetsCompared:true,inputHashesRechecked:true,index:rangeIndex,inputProof:inputs.inputProof,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log('Actual staged feature range passed; measured terminal and complete aggregate remain pending',ordinal);
