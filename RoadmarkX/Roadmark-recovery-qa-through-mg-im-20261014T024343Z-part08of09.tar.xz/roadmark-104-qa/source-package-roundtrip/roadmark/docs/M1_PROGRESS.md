# M1 progress and completion evidence

M1 is in progress. BYD is research-complete; whole-market completion has not been asserted. The original research snapshot and historical source evidence remain unchanged; new work uses dated overlays. Work stays in Tier 1 and M1.

The first pass applies the authorised price ladder and buyer grading to existing Tier 1 evidence. New brand research, missing-model additions and market closure are separate unfinished work. The original whole-market registry remains empty. A separate dated BYD reconciliation overlay records its verified current versions and resolved inherited audit items; two independent whole-market lists remain to be reconciled.

## Read the current position

- `pnpm report:coverage`: compact headline coverage, all six completion criteria, brands done/remaining and the first missing models
- `pnpm report:coverage --details`: every core grade split, under-half Confirmed patterns, exact gaps, per-brand remaining work, all missing models and reconciliation blockers
- `pnpm report:coverage --json`: complete structured evidence, including registry snapshots and dated current-version reviews
- Add `--as-of YYYY-MM-DD` to reproduce a release check; the default uses the current Australian date
- `pnpm report:stale --details`: exact current claims needing freshness work

The on-sale denominator still includes current/order-listed Tier 1 versions and sourced outgoing new-stock advertisements. It excludes provisional announcements and outgoing versions without that evidence. A listing never proves physical stock or accepted orders. C4 and C6 continue checking all Tier 1 catalogue versions.

## Research completion and coverage qualification

The report distinguishes the research queue from the strict coverage targets. There is no editable “complete” flag.

A brand is **research-complete** when its dated complete current-version list is established, every known model/lead difference is resolved, every on-sale core field has an earned grade (including a completed two-source unsuccessful search), its Tier 1 strengths/trade-offs are supported, and its claims are fresh. Two-source “Not published” gaps allow research to move to the next brand. Missing 10–80% charging time when only 30–80% is published, for example, can be a finished research outcome while C2 and C5 remain open. Whole-market independent-list closure is not required before moving to the next brand.

A brand is separately **coverage-qualified** only when it meets all six criteria:

1. Every current version and inherited audit/lead disposition is reconciled; the two independent market-list snapshots are valid, and all differences relevant to that brand are settled
2. Price is filled for every on-sale version; each other core field is at least 95% filled
3. Every on-sale core cell has an auditable M1 grade; each field below half Confirmed has an explanation, without a grade quota
4. Every Tier 1 version has a supported strength and trade-off
5. Each required ranking includes at least 90% of that brand’s on-sale versions
6. No Tier 1 current claim is aged, invalid or future-dated

The JSON includes each brand’s criteria, current-version reviews, exact blockers, counts, `researchCompleted` and its research-completed-as-of date, plus separate all-six-criteria completion and its as-of date. A fully reconciled exclusion can close an audit lead without adding a vehicle. A brand containing only excluded leads is not presented as a completed on-sale brand. The compact report lists brands done/remaining in the research queue and identifies coverage-qualified brands separately. A new or stale fact, model or version can reopen the relevant criterion.

## C1 registry: dated evidence, never inferred closure

`data/m1-market-reconciliation-2026-10-14.json` has the typed structure declared in `scripts/reporting/m1-reconciliation.ts`:

- `schemaVersion` and `checkedAt`: registry format and check date
- `publishedLists`: complete published Australian new Tier 1 BEV model-list snapshots. Each records its publisher, publication/check dates, original URL, complete model/body entries, an independence key and the reason it is independent
- `currentVersionReviews`: complete official Australian current-version lists, with exact model/body identity, model ID, check date, official URLs and reason. Every version identifies its catalogue ID, exact model, trim and model year. Optional `publishedModelAliases` records source-bound naming equivalences with a reason and URLs; it never relaxes body/trim/year identity
- `listResolutions`: one dated, sourced included/excluded/unresolved disposition for every published-list entry
- `catalogueOnlyDifferences`: a dated, sourced explanation for each reviewed model absent from each independent list
- `inventoryResolutions`: one sourced disposition for every inherited Tier 1 audit record and unverified lead, using its stable record/family ID (or brand-model fallback)

Two URLs from the same publisher or underlying dataset do not count as two independent lists. Snapshot capture must be complete, not cherry-picked to the existing catalogue. Research must establish independence; the report can validate the recorded structure, but it cannot independently prove that a researcher transcribed every published entry.

An included published entry must match the reviewed brand, model, body and vehicle class. Each reviewed version must match its actual catalogue ID, model ID, brand, model, trim and year. An explicit body-style fact, when present, must also match. Missing body evidence is not invented: the researcher must establish the body scope in the cited official current-version review. A sibling body, a different trim, a shared family prefix or a similar name cannot supply another version’s coverage.

Exclusions need a real date, evidence URLs, a reason and one of the supported dispositions: not sold new in Australia; not officially imported; not a BEV; outside Tier 1; not orderable or advertised as new stock; or duplicate of an explicitly matched model/body review. A duplicate must name the valid review. An on-sale catalogue model cannot also be excluded as not sold here. Unknowns remain unresolved.

Registry, version-list and resolution check dates use the 45-day availability window. Publication dates stay distinct. Future or invalid dates, duplicate IDs/resolutions, orphan references, an empty list, an unreviewed actual version, or an unresolved inherited audit item keep C1 open. Valid exclusions and complete current-version reviews must be recorded before the report will remove an inherited lead or unmatched model from its open-work list.

For later research, append the real snapshots/reviews and their source-bound resolutions to a new dated overlay, then update the report loader. Never invent entries to make counts agree, remove unresolved differences, or change the immutable snapshot to close a report.

## C3 earned grades

Coverage uses the shared `hasEarnedBuyerGrade` validator. A historic `standard` or `conditional` status alone no longer earns an M1 grade in the coverage report. A reviewed grade needs its dated overlay, reason, evidence scope and resolvable source citations. The report preserves filled values even when their grading review is unfinished, and shows them as Unreviewed in its split.

“Not published” requires an explicit unsuccessful search with two cited source URLs. A null value or old caveat is not such a search. It counts as a reviewed grade for C3, but it does not count as a filled field for C2. A value on the wrong charging window does not fill DC 10–80% time or earn a review for that requested core field.

The report gives the full Confirmed / Check / Reported / Not published / Unreviewed split for all 17 core fields and explains the recorded evidence patterns below half Confirmed. C3 can pass with a low Confirmed share when every grade is earned and the pattern is explained. It cannot pass by relabelling old statuses or writing a completion flag.

## Behavioural checks

`tests/m1-coverage-tracking.test.ts` covers a genuinely complete synthetic fixture, the empty/incomplete registry, non-independent lists, every-entry and every-version reconciliation, wrong body/trim/model/year/brand matches, sourced exclusions, catalogue-only differences, duplicate/orphan records, stale checks, two-source unsuccessful searches and per-brand completion. Existing coverage-report and freshness tests remain active. These tests verify behaviour rather than pinning historical byte counts.

## Progress snapshot — 14 October 2026

- The initial existing-record pass shows prices on 171 of 268 Tier 1 versions, up by 102; this includes Tier 1 versions outside the narrower on-sale report denominator
- 184 retained-evidence core fills have been applied and independently reviewed, including corrected Kia EV3 and outgoing Geely source attribution
- The initial earned-grade ledger reviews 18,946 facts and 2,703 equipment answers. Fact/source drift withdraws grading without hiding figures; reviewed Tier 1 claims cannot silently regain legacy rankings
- BYD research and its packet are independently reviewed and registered: 13 current versions, 221/221 on-sale core cells reviewed, 11 genuine unpublished core figures, and 14 supported strength/trade-off pairs including an outgoing version. C3/C4/C6 pass for BYD; C1/C2/C5 do not
- The first foundation run found 79 failures, including old fixture-boundary assumptions and an optional-fitment status regression. Historical evidence assertions were retained, separate current-catalogue safety tests were added, and optional equipment keeps its paid-option meaning
- The full foundation/BYD rerun passes 964/964 tests with zero failures or skips. Structural validation, type checking and full ESLint pass. Tesla research is now active; no Tesla packet has yet been approved or registered
- M1 remains open. No C1–C6 completion is asserted by this progress snapshot
