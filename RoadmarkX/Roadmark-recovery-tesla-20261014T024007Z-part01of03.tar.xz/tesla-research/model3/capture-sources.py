import pathlib,json,subprocess,hashlib,concurrent.futures,datetime
D=pathlib.Path('/tmp/tesla-research/model3')
sources=[('racq-rwd','https://media.racq.com.au/articles/car-updates/tesla-introduces-cut-price-model-3'),('redbook-rwd','https://www.redbook.com.au/cars/details/2026-tesla-model-3-rear-wheel-drive-auto/SPOT-ITM-701078?Cr=43'),('carexpert-lr','https://www.carexpert.com.au/car-reviews/2026-tesla-model-3-premium-long-range-rwd-review'),('carexpert-premium','https://www.carexpert.com.au/car-reviews/2026-tesla-model-3-review'),('carexpert-my27','https://www.carexpert.com.au/car-news/tesla-model-3-becomes-australias-cheapest-electric-sedan'),('carsguide-lr','https://www.carsguide.com.au/ev/tesla-model-3-premium-long-range-rwd-100750'),('ac','https://www.tesla.com/en_au/support/charging/wall-connector'),('tow','https://shop.tesla.com/en_au/product/model-3-tow-package?sku=1806541-00-A')]
def fetch(x):
 k,u=x;f=D/(k+'.html');r=subprocess.run(['curl','-L','-s','--max-time','45','-A','Mozilla/5.0','-w','%{http_code}|%{url_effective}','-o',str(f),u],capture_output=True,text=True)
 return dict(key=k,url=u,file=f.name,result=r.stdout,sha256=hashlib.sha256(f.read_bytes()).hexdigest() if f.exists() else None,checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),checked_date_au='2026-10-14')
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:r=list(ex.map(fetch,sources))
json.dump(r,open(D/'source-captures.json','w'),indent=2);print(json.dumps(r,indent=2))
