import json,pathlib,hashlib,copy
r=pathlib.Path('/tmp/tesla-research');original=r/'tesla-2026-10-14.json';raw=original.read_bytes();oldhash='ed099843f37d65d0b8dbbc949b77b5ca01141936c7921cef3b5d24fb2ffdc059'
assert hashlib.sha256(raw).hexdigest()==oldhash,'Stop: starting packet differs from approved version'
h=r/'review-history';h.mkdir(exist_ok=True);(h/('tesla-approved-'+oldhash+'.json')).write_bytes(raw)
p=json.loads(raw);old=copy.deepcopy(p);sources={s['id']:s for s in p['sources']};rows=[]
for c in json.load(open(r/'performance-feature-current.json')):
 assert len(c['features'])==1
 before=c['features'][0];power=c['power'];drive=c['drive'];reported=power['buyerGrade']=='reported';awd=drive['value']=='AWD'
 assert power['buyerGrade'] in ['confirmed','reported'] and drive['buyerGrade']=='confirmed'
 sids=list(dict.fromkeys(power['sourceIds']+drive['sourceIds']));pub=' / '.join(dict.fromkeys(sources[s]['publisher'] for s in sids))
 value=f"{power['value']} kW "+('combined (Reported)' if awd and reported else 'rear motor (Reported)' if reported else 'peak vehicle output')+' · '+('all-wheel drive' if awd else 'rear-wheel drive')
 conditions=[]
 if reported:conditions.append('Power is an Australian secondary report from '+power['gradeReview']['sourceLabel']+', not a Tesla Australia retail power claim.')
 if awd:conditions.append('Power describes the whole vehicle, not the rear motor alone; individual motor outputs have not been added.')
 for t in [power['gradeReview']['reason'],*power.get('qualifications',[]),power.get('conditionExplanation',''),*drive.get('qualifications',[]),before.get('conditions','')]:
  if t and t not in conditions:conditions.append(t)
 after=copy.deepcopy(before);after.update(status='conditional' if reported else 'standard',value=value,conditions=' '.join(conditions),source_ids=sids,evidence_scope=power['scope']+'; '+('Australian secondary or explicit prior-configuration scope as stated in conditions' if reported else 'current exact Australian maker specification'),last_evidence_date=p['reviewedAt'],reviewed_date=p['reviewedAt'],publication_rule='Keep whole-vehicle combined output separate from individual rear-motor output; retain secondary/prior-configuration scope and source conflicts.',verification_state='reviewed_2026-10-14',condition_label='Reported power' if reported else '',buyerGrade=power['buyerGrade'],gradeReview={'reviewedAt':p['reviewedAt'],'overlayId':p['id'],'reason':'Projects the exact reviewed power and drive facts into the shared buyer answer. '+power['gradeReview']['reason'],'evidenceScope':power['gradeReview']['evidenceScope'],'sourceIds':sids,'sourceLabel':pub})
 rows.append({'variantId':c['id'],'criterion':'performance_rear_motor','before':before,'after':after,'dependencies':[{'key':'power_kw','expected':power},{'key':'drive','expected':drive}]})
assert len(rows)==8
p['features']+=rows
for k in old:
 assert (p[k][:8]==old[k] if k=='features' else p[k]==old[k]),k
original.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n');(r/'tesla-performance-features-proposed.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
newhash=hashlib.sha256(original.read_bytes()).hexdigest()
(h/'performance-feature-amendment.json').write_text(json.dumps({'amendedAtAustralianDate':'2026-10-14','previousApprovedRegisteredSha256':oldhash,'newStagedSha256':newhash,'change':'Append eight performance_rear_motor feature replacements; all existing packet sections and eight storage rows remain semantically identical.','dependencyKeys':['power_kw','drive'],'registeredFileChanged':False},indent=2)+'\n')
print(newhash)
