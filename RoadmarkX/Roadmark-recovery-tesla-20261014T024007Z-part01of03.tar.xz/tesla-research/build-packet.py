import json,pathlib,hashlib,copy
R=pathlib.Path('/tmp/tesla-research');D='2026-10-14';PID='m1-tesla-2026-10-14';REVIEWER='Roadmark Tesla Australian source review'
cars=json.load(open(R/'before.json')); old={c['id']:c for c in cars}; effective={}
p={'schemaVersion':1,'id':PID,'brand':'Tesla','reviewedAt':D,'reviewedBy':REVIEWER,'sources':[],'models':[],'variants':[],'versionGuards':[],'versionUpdates':[],'facts':[],'brandTerms':[],'availability':[],'summaries':[]};sources={}
def source(k,url,title,supports,typ='manufacturer_au_specification',publisher='Tesla Australia',file=None,pub=None,**kw):
 s={'id':PID+'-'+k,'url':url,'title':title,'publisher':publisher,'source_type':typ,'published_date':pub,'accessed_date':D,'market':'AU','supports':supports,**kw}
 if file and (R/file).exists():s['capture_sha256']=hashlib.sha256((R/file).read_bytes()).hexdigest();s['capture_locator']=str(file)
 p['sources'].append(s);sources[k]=s
source('m3-product','https://www.tesla.com/en_au/model3','Tesla Model 3 Australian current product specifications','Current complete Australian RWD, Premium RWD, Premium Long Range RWD and Performance list; exact range, acceleration, DC peak, seats and dimensions. Performance 343 kW appears in product performance section; acceleration excludes rollout. Captured JSON specs-table-1040/1041/987 plus exact named headings.',file='model3/model3.html')
source('m3-config','https://www.tesla.com/en_au/model3/design','Tesla Model 3 Australian configurator','Four exact Australian trims and base selection prices incl GST: RWD45900/Premium RWD54900/Premium LR RWD61900/Performance80900. Delivery1400 and order400 extra before government on-roads. Lexicon.m3 options MT367,MT368,MT369,MT381; fee_rules current AU Delivery Fee and Order Fee; browser model list and Price Breakdown verified. Factory orders advertised; no stock inference.',typ='official_configurator',file='model3/design.html')
source('m3-manual','https://www.tesla.com/ownersmanual/model3/en_au/Owners_Manual.pdf','Tesla Model 3 Australian owners manual','Visually checked PDF pages100 (printed98):1000kg braked towing;221(219):dimensions;222(220):594L behind second row,88L frunk,682L total with5 passengers. Width1850 excluding mirrors; 1933 folded/2089 extended. Towing tyres restricted to18/19inch. No numeric battery energy or10–80% time.',typ='manufacturer_au_handbook',file='model3/manual.pdf')
source('m3-tow','https://shop.tesla.com/en_au/product/model-3-tow-package?sku=1806541-00-A','Tesla Australia Model 3 tow package','Compatible with all non-performance2017–2023 and2024+ Model3; up to1000kg. Brake controller required above750kg; Tesla does not supply/fit controller. Excludes Performance.',typ='manufacturer_au_accessory',file='model3/tow.html')
source('ac','https://www.tesla.com/en_au/support/charging/wall-connector','Tesla Australian Wall Connector charging support','AU vehicle charging table establishes11kW on400V three-phase for Model3 and ModelY; footnote explicitly maximum16A/11kW for RWD. Single-phase32A is7.4kW. Installation/supply affects achieved charging, not onboard maximum.',typ='manufacturer_au_support',file='model3/ac.html')
source('m3-racq','https://media.racq.com.au/articles/car-updates/tesla-introduces-cut-price-model-3','RACQ new Australian Model 3 RWD launch','2Oct2026 exact new572km RWD: reported62.5kWh LFP shared with Premium RWD. Used only for battery fact, not overseas equipment assumptions.',typ='secondary_au_motoring_report',publisher='RACQ',pub='2026-10-02',file='model3/racq-rwd.html')
source('m3-redbook-rwd','https://www.redbook.com.au/cars/details/2026-tesla-model-3-rear-wheel-drive-auto/SPOT-ITM-701078?Cr=43','RedBook current Australian Model 3 Rear-Wheel Drive specification','Exact new entry variant matches45900,572km,6.2s and1768kg; table reports62.5kWh high-voltage capacity and208kW motor. Page vehicle launch year2026 is not substituted for MY27. Web extraction read; direct shell capture403 not treated as evidence.',typ='secondary_au_price_specification_guide',publisher='RedBook',file='model3/redbook-rwd-web.json')
source('m3-carsales-lr','https://www.carsales.com.au/cars/details/2026-tesla-model-3-premium-long-range-rear-wheel-drive-auto/SHRM-AD-6550347/','Carsales/RedBook Australian MY27 Model 3 Premium Long Range RWD specification','Generic carsales research listing explicitly MY27 and750km:85.0kWh high-voltage capacity (usable/gross unstated),235kW. Secondary specification only; no advertised stock or manufacturer authorship inferred.',typ='secondary_au_specification_guide',publisher='carsales / RedBook',file='model3/carsales-lr-web.json')
source('m3-carexpert-premium','https://www.carexpert.com.au/car-reviews/2026-tesla-model-3-review','CarExpert Australian Model 3 RWD review','Pre-MY27 520km/6.1s RWD now named Premium RWD:208kW; older60kWh battery not used where newer RACQ62.5kWh shared-pack report is available. No exact current10–80% duration established.',typ='secondary_au_motoring_review',publisher='CarExpert',file='model3/carexpert-premium.html')
source('m3-carexpert-my27','https://www.carexpert.com.au/car-news/tesla-model-3-becomes-australias-cheapest-electric-sedan','CarExpert October Australian MY27 Model 3 update','Complete four named MY27 grades and current prices; new baseRWD shares battery with Premium RWD; Performance now600km. No numeric Performance battery capacity or exact10–80% time supplied. Do not use mistaken blanket160000km battery warranty.',typ='secondary_au_motoring_report',publisher='CarExpert',file='model3/carexpert-my27.html')
source('m3-carsguide-lr','https://www.carsguide.com.au/ev/tesla-model-3-premium-long-range-rwd-100750','CarsGuide Australian Model 3 Premium Long Range RWD review','Checked for10–80% time: only15–85% test on150kW fluctuating charger, not converted.235kW reported.Its embedded75kWh table differs from its narrative82kWh total/78kWh usable, and this February pre-MY27 source is not used for current battery capacity.',typ='secondary_au_motoring_review',publisher='CarsGuide',file='model3/carsguide-lr.html')
source('m3-carsales-perf','https://www.carsales.com.au/cars/details/2026-tesla-model-3-performance-auto-awd/SHRM-AD-6550346/','Carsales/RedBook Australian MY27 Model 3 Performance specification','Exact MY27 / 600 km / 3.1 s / China listing reports 85.0 kWh high-voltage capacity, gross/usable basis unspecified. Its 461 kW, 115 mm clearance and 500 kg towing conflict with current maker statements and are rejected. Generic secondary research listing, not manufacturer/dealer authorship or verified stock.',typ='secondary_au_specification_guide',publisher='carsales / RedBook',file='model3/carsales-performance-web.json')
for s in json.load(open(R/'terms/sources.json')):
 k='terms-'+s['id'].lower(); official=s['type'].startswith('official'); source(k,s['url'],s['title'],s['supports'],typ=('primary_warranty' if s['id']=='T02' else 'manufacturer_au_terms' if official else 'secondary_au_motoring_report'),publisher='Tesla Australia' if official else ('EV Central' if s['id']=='T10' else 'CarExpert'),file='terms/'+s['file'] if s.get('file') else None,pub=s.get('effective_date'))
meta={'price_aud':('Published price','AUD','Before on-road costs'),'range_km':('Claimed range','km','WLTP combined'),'battery_kwh':('Battery capacity','kWh','Reported high-voltage battery capacity; usable/gross not stated'),'dc_peak_kw':('Peak DC charging power','kW','Vehicle DC peak'),'dc_charge_time_min':('DC 10–80% charging time','min','10–80%'),'ac_kw':('AC charging power','kW','Vehicle AC maximum'),'seats':('Seats','','Seating positions'),'boot_l':('Boot capacity','L','Tesla cargo volume behind occupied seats; method unspecified'),'zero_to_100_s':('0–100 km/h','s','0–100 km/h'),'power_kw':('Motor power','kW','Maximum combined motor power'),'drive':('Drive type','','Driven wheels'),'length_mm':('Length','mm','Overall length'),'width_mm':('Width','mm','Overall body width excluding mirrors'),'height_mm':('Height','mm','Overall height'),'towing_braked_kg':('Braked towing','kg','Maximum braked towing'),'warranty':('Vehicle warranty','','Australian new-vehicle warranty'),'battery_warranty':('Battery warranty','','Australian power-battery warranty'),'roadside_assistance':('Roadside assistance','','Australian new-vehicle roadside assistance'),'body_style':('Body style','','Body style'),'rear_display':('Rear touchscreen','','Rear passenger display'),'wheelbase_mm':('Wheelbase','mm','Wheelbase'),'ground_clearance_mm':('Ground clearance','mm','Ground clearance'),'kerb_weight_kg':('Kerb weight','kg','Manufacturer published weight'),'frunk_l':('Front boot','L','Tesla front-trunk volume'),'max_total_cargo_l':('Maximum total cargo','L','Tesla maximum combined cargo volume')}
def ident(c):return {**{k:c[k] for k in ['id','modelId','brand','model','trim','year','generation','drive']},'vehicleClass':c.get('vehicleClass','passenger')}
def fact(c,k,v,keys,grade='confirmed',reason=None,scope='exact_au_version',condition='',basis=None,comparison=None,qualifications=None):
 label,unit,default=meta[k];ids=[sources[x]['id'] for x in keys];b=basis or default
 f={'key':k,'label':label,'value':v,'unit':unit,'basis':b,'comparisonBasis':default if comparison is None else comparison,'status':{'confirmed':'standard','check':'conditional','reported':'conditional','not_published':'not_verified'}[grade],'sourceIds':ids,'date':D,'market':'AU','scope':'Tesla '+c['model']+' '+c['trim'],'qualifications':qualifications or ([condition] if condition else []),'issues':[],'buyerGrade':grade,'gradeReview':{'reviewedAt':D,'overlayId':PID,'reason':reason or 'Current Australian maker material explicitly establishes this figure for the named version.','evidenceScope':scope,'sourceIds':ids,'sourceLabel':' / '.join(dict.fromkeys(sources[x]['publisher'] for x in keys))}}
 if condition:f['conditionExplanation']=condition
 if grade=='reported':f['resolvedElsewhere']=True
 if grade=='not_published':f['conditionExplanation']=reason or b
 p['facts'].append({'variantId':c['id'],'before':old[c['id']]['facts'].get(k),'after':f});effective.setdefault(c['id'],{})[k]=f
 return f
for c in cars:
 p['versionGuards'].append({'variantId':c['id'],'before':ident(c)})
# Source-body scoped identity: long-wheelbase six-seat version is not the five-seat body.
lcar=next(c for c in cars if '__l_premium_' in c['id'])
la=ident(lcar);la.update(model='Model Y L',trim='Premium AWD (six-seat)',year=2027,generation='Long-wheelbase six-seat Model Y L; current Australian MY27 specification')
p['versionUpdates'].append({'variantId':lcar['id'],'before':ident(lcar),'after':la,'reason':'Current Tesla Australian product page names this separately Model Y L, with six seats and its own4969mm body. MY27 October update is independently identified; retain stable legacy ID/modelId while giving this exact body its own current-version review.'})
cars=[{**c,**(la if c['id']==lcar['id'] else {})} for c in cars]
values={
 'tesla_model_3__rear_wheel_drive__3':[45900,572,62.5,175,None,11,5,594,6.2,208,'RWD',4720,1850,1440,1000],
 'tesla_model_3__premium_rwd__2':[54900,520,62.5,175,None,11,5,594,6.1,208,'RWD',4720,1850,1440,1000],
 'tesla_model_3__premium_long_range_rwd__1':[61900,750,85,250,None,11,5,594,5.2,235,'RWD',4720,1850,1440,1000],
 'tesla_model_3__performance_awd__4':[80900,600,85,250,None,11,5,594,3.1,343,'AWD',4724,1850,1431,0]}
keys=list(meta)[:15]
for c in cars:
 if c['id'] not in values:continue
 perf='performance' in c['id'];lr='long_range' in c['id'];base='__rear_wheel_drive__' in c['id']
 for k,v in zip(keys,values[c['id']]):
  sk=['m3-product'];g='confirmed';sc='exact_au_version';reason=None;condition='';b=None;comp=None;quals=[]
  if k=='price_aud':
   sk=['m3-config'];b='Maker configurator base price incl GST; excludes A$1,400 delivery, A$400 order fee and government on-road costs';quals=['A$1,400 delivery fee and A$400 order fee are additional; government on-road costs and optional equipment are extra. No inventory discount, trade-in bonus, petrol saving or financing assumption applied.'];reason='Exact named Australian configurator base price; higher maker list/national driveaway rung not found. Mandatory fees are disclosed separately without changing the published base number.'
  elif k=='range_km' and lr:g='check';condition='750km WLTP with18-inch wheels; Tesla separately lists691km with19-inch wheels.';b='WLTP combined;18-inch wheels'
  elif k=='battery_kwh':
   if perf:sk=['m3-carsales-perf','m3-product'];g='reported';sc='secondary_or_sibling';reason='Current Australian carsales/RedBook generic research listing explicitly identifies MY27 Performance with matching 600 km range and 3.1-second acceleration, and reports 85.0 kWh. Gross/usable basis is unstated. The database’s power, clearance and towing fields conflict with current maker figures and are not used; capacity remains Reported, not maker confirmed.'
   else:
    sk=['m3-carsales-lr'] if lr else ['m3-racq','m3-carexpert-my27'];g='reported';sc='secondary_or_sibling';reason=('Australian carsales/RedBook specification explicitly names MY27 Premium Long Range RWD and publishes85.0kWh; usable/gross basis is not supplied.' if lr else 'RACQ reports62.5kWh for the new572km Australian RWD. CarExpert explicitly states that this shares its battery with current Premium RWD; inheritance to Premium is Reported, not maker confirmation.')
  elif k=='dc_charge_time_min':
   sk=['m3-product','m3-carsguide-lr'] if lr else ['m3-product','m3-carexpert-my27'];g='not_published';sc='searched_not_found';reason='Tesla publishes kilometres added in15minutes, not10–80%. '+('CarsGuide publishes a15–85% session only; no conversion or time estimate made.' if lr else 'The current Australian MY27 CarExpert report gives no exact10–80% duration. Older European estimate is removed rather than transplanted.')
  elif k=='ac_kw':sk=['ac'];sc='explicit_au_range';b='11kW on400V three-phase supply';quals=['Single-phase32A supply is7.4kW;11kW requires suitable three-phase installation.']
  elif k in ['boot_l','width_mm']:sk=['m3-manual'];sc='explicit_au_range';reason='Australian owner manual explicit whole Model3 body table applies to all grades; rear cargo excludes the88L front trunk and uses Tesla method rather than VDA.' if k=='boot_l' else 'Australian owner manual gives1850mm body width excluding mirrors for both rear-drive/Long Range and Performance.'
  elif k=='zero_to_100_s' and perf:g='check';condition='Tesla’s3.1-second claim subtracts rollout.';b='0–100km/h with rollout subtracted';comp='0–100km/h with rollout subtracted'
  elif k=='power_kw' and not perf:
   sk=['m3-carsales-lr'] if lr else ['m3-redbook-rwd'] if base else ['m3-carexpert-premium'];g='reported';sc='secondary_or_sibling';reason='Australian secondary specification reports the named motor output; Tesla Australia does not state a numeric figure for this rear-drive trim.'+('208kW is carried from the Australian520km/6.1s prior RWD now labelled Premium RWD; not inferred from a motor sum.' if not(lr or base) else '')
  elif k=='power_kw' and perf:reason='Current Tesla Australia Performance section explicitly publishes343kW peak power factoring battery/drivetrain capability; no component motor outputs summed.'
  elif k=='towing_braked_kg':
   sk=['m3-manual','m3-tow']+(['m3-product'] if perf else [])
   if perf:b='Towing not permitted on supplied20-inch tyres';comp='Maximum braked towing';reason='Australian manual prohibits towing with tyres outside18/19-inch approved sizes; Performance is supplied20-inch and Tesla AU tow package explicitly excludes Performance. Zero denotes no permitted towing in this configuration, not an inferred mechanical limit.'
   else:g='check';condition='Requires compatible Tesla tow package and approved18/19-inch tyres; brake controller needed above750kg and is not supplied/fitted by Tesla. Plate/hitch limits and vehicle loading govern.';reason='Manual explicitly rates1000kg with trailer brakes; AU accessory page applies to all non-Performance2017–2023/2024+ Model3 and states controller restriction.'
  f=fact(c,k,v,sk,g,reason,sc,condition,b,comp,quals or None)
  if k=='price_aud':f['priceEvidence']={'rung':3,'basisTag':'Maker’s configurator · before on-road costs','sourceKey':'price_aud','sourcePointer':sources['m3-config']['url'],'originalBasis':b,'rankingEligible':True}
 fact(c,'body_style','Sedan',['m3-product'],scope='explicit_au_range')
 fact(c,'frunk_l',88,['m3-manual'],scope='explicit_au_range')
 fact(c,'wheelbase_mm',2875,['m3-manual'],scope='explicit_au_range')
 fact(c,'ground_clearance_mm',128 if perf else 138,['m3-product'])
 fact(c,'kerb_weight_kg',1854 if perf else 1747 if lr else 1768 if base else 1761,['m3-product'])
# Remaining Tesla ModelY facts are imported below from individually reviewed evidence.
y=json.load(open(R/'model-y/packet-ready.json'))
for s in y['sources']:
 typ='official_configurator' if s['key']=='config' else 'manufacturer_au_specification' if s['kind']=='maker' else 'manufacturer_au_homologation' if s['kind']=='maker_filing' else 'secondary_au_motoring_report'
 pub='Tesla Australia' if s['kind']=='maker' else 'Australian Government ROVER / Tesla' if s['kind']=='maker_filing' else 'CarExpert' if s['key'].startswith('ce_') else 'CarsGuide' if s['key'].startswith('cg_') else 'RedBook'
 loc=s.get('file','').split(':')[0]
 source('my-'+s['key'],s['url'],s['title'],(('Prior Australian MY26 source reports RWD 62.5 kWh, retained only as scoped Reported prior-configuration evidence; LR/Performance 79 kWh and old Performance power are not used for MY27.' if s['key']=='ce_y_2026' else s['notes'])+' Examined fields: '+', '.join(s['supports'])),typ=typ,publisher=pub,file='model-y/'+loc,pub=s.get('publishedAt'),capture_section=s.get('file',''))
for c in cars:
 if c['id'] not in y['variants']:continue
 is_l=c['model']=='Model Y L'; perf='performance' in c['id']
 for key,row in y['variants'][c['id']]['facts'].items():
  k='power_kw' if key=='motor_power_kw' else key
  if k in ['warranty','battery_warranty']:continue
  g={'Good':'confirmed','Check':'check','Reported':'reported','Not published':'not_published'}[row['grade']]
  sk=['my-'+s for s in row['sourceKeys']];reason=row['reason'];condition=row.get('condition','');b=row['basis'];comp=None
  scope='secondary_or_sibling' if g=='reported' else 'searched_not_found' if g=='not_published' else 'explicit_au_range' if k in ['ac_kw','boot_l','width_mm'] else 'exact_au_version'
  if k=='price_aud':
   b='Maker configurator base price incl GST; excludes A$1,400 delivery, A$400 order fee and government on-road costs'
   reason='Exact named Australian configurator base price; higher maker list/national driveaway rung not found. Mandatory fees are disclosed separately without changing the published base number.'
   condition='A$1,400 delivery fee and A$400 order fee are additional; government on-road costs and optional equipment are extra.'
  if k=='boot_l':b='Rear cargo behind '+('third row, all six seats occupied' if is_l else 'second row, seats up')+'; Tesla method unspecified'
  if k=='towing_braked_kg':g='check'
  if k=='zero_to_100_s' and perf:g='check';condition='Tesla’s 3.5-second claim subtracts rollout.';b='0–100 km/h with rollout subtracted';comp=b
  if k=='battery_kwh' and g=='not_published':
   row={**row,'value':62.5};g='reported';scope='secondary_or_sibling';sk=['my-ce_y_2026','my-product','my-rb_rwd'];b='Reported MY26 Australian RWD battery capacity; gross/usable basis unspecified'
   reason='CarExpert explicitly reports 62.5 kWh for the prior Australian MY26 RWD with matching 466 km range and 5.9-second acceleration. This is retained only as a prior-configuration secondary report; the current maker page and MY27 RedBook entry do not establish pack capacity or unchanged battery identity.'
   condition='Prior MY26 Australian RWD specification, not confirmed for current MY27 hardware. CarsGuide separately describes 62.5 kWh as an assumption and is not adopted as evidence. No battery capacity is calculated or estimated here.'
  if k=='dc_charge_time_min' and g=='not_published':reason='Current Tesla Australian product page gives range added in 15 minutes, not 10–80%. The exact MY27 RedBook RWD record also supplies no 10–80% duration; no conversion or overseas estimate adopted.'
  f=fact(c,k,row['value'],sk,g,reason,scope,condition,b,comp)
  if k=='price_aud':f['priceEvidence']={'rung':3,'basisTag':'Maker’s configurator · before on-road costs','sourceKey':'price_aud','sourcePointer':sources['my-config']['url'],'originalBasis':b,'rankingEligible':True}
  conflict=(k=='length_mm' and not(is_l or perf)) or (is_l and k in ['height_mm','towing_braked_kg'])
  if conflict:f['issues']=[{'issue_id':PID+'-'+c['id']+'-'+k,'priority':'medium','model_ids':[c['modelId']],'title':'Current Australian maker sources differ','publication_action':condition+' Keep visible as Check and exclude from ranking until clarified.','source_ids':f['sourceIds']}]
 fact(c,'body_style','SUV',['my-product'],scope='explicit_au_range')
 fact(c,'frunk_l',116,['my-dimensions'],scope='explicit_au_range')
 fact(c,'max_total_cargo_l',2539 if is_l else 2138,['my-dimensions'],scope='explicit_au_range',basis='Maximum combined front and rear cargo with only driver and front passenger; Tesla method unspecified')
# Current Model 3 sources do not publish a seats-folded maximum.
for c in cars:
 if c['model']!='Model 3':continue
 fact(c,'max_total_cargo_l',None,['m3-manual','m3-product'],'not_published','Current AU product cargo is 682 L with five occupants; AU manual gives 594 L rear and 88 L front but no seats-folded maximum. The inherited 977 L is not re-established and is not inferred from the 977 mm rear-overhang dimension.','searched_not_found',basis='Maximum combined cargo with rear seats folded; not published in current examined AU maker sources')
# Shared terms are stored once. The three 160,000 km battery exceptions remain explicit per-version facts.
ids=[c['id'] for c in cars]
small=[c['id'] for c in cars if c['id'] in ['tesla_model_3__rear_wheel_drive__3','tesla_model_3__premium_rwd__2','tesla_model_y__premium_rwd__2']]
def term(k,v,sk,app,reason,qualifications):
 f=fact(cars[0],k,v,sk,reason=reason,scope='brand_au_terms',qualifications=qualifications)
 p['facts'].pop();effective[cars[0]['id']].pop(k,None)
 f['scope']='Tesla Australian new Model 3 / Model Y vehicles delivered from 1 January 2026; exact variants explicitly enumerated below'
 t={'key':k,'fact':f,'applicableVariantIds':app,'before':{i:old[i]['facts'].get(k) for i in app},'exceptions':[{'variantId':i,'reason':'Explicit Australian policy exception: this RWD grade receives 8 years / 160,000 km, whichever first, with minimum 70% retention; separate exact-version fact cites the same shared policy.'} for i in ids if i not in app]}
 p['brandTerms'].append(t)
 for i in app:effective.setdefault(i,{})[k]=f
term('warranty','5 years / unlimited kilometres',['terms-t01','terms-t02'],ids,'Australian new-vehicle policy effective 1 January 2026 and current exact product pages establish the basic warranty. The former 4-year / 80,000 km term does not apply to these current new deliveries.',['Normal new-vehicle use; separate component cover, exclusions and owner obligations remain in the linked policy. Commercial-use applicability should be confirmed with Tesla; no unsupported commercial kilometre cap is asserted.'])
term('battery_warranty','8 years / 192,000 km; minimum 70% capacity retention',['terms-t01','terms-t02'],[i for i in ids if i not in small],'Current AU warranty webpage explicitly lists Model 3 Premium Long Range RWD and Performance plus Model Y Premium Long Range AWD, Performance and L under 192,000 km. Whichever time/distance limit occurs first.',['Applies to battery and drive unit, whichever time/distance limit occurs first; minimum 70% battery-capacity retention over the warranty period.'])
for c in cars:
 if c['id'] in small:fact(c,'battery_warranty','8 years / 160,000 km; minimum 70% capacity retention',['terms-t01','terms-t02'],reason='Explicit Australian policy exception for Model 3 Rear-Wheel Drive / Premium Rear-Wheel Drive and Model Y Premium Rear-Wheel Drive. Whichever time/distance limit occurs first.',scope='brand_au_terms',qualifications=['Battery and drive unit; minimum 70% battery-capacity retention over the warranty period.'])
term('roadside_assistance','5 years, while basic warranty is active',['terms-t03','terms-t04','terms-t02'],ids,'AU support and linked roadside policy provide 24/7 assistance while the basic warranty is active; current normal-use basic warranty lasts 5 years. No lifetime, unlimited free towing or physical recovery guarantee inferred.',['Warrantable breakdown transport up to 800 km to the nearest Tesla Service Centre. Flat-tyre and lockout assistance have 80 km transport limits and conditions; tyre repair/replacement, depleted-battery transport and extraction may be chargeable or excluded.'])
for c in cars:
 sk='m3-config' if c['model']=='Model 3' else 'my-config'
 p['availability'].append({'id':PID+'-availability-'+c['id'],'variantId':c['id'],'before':{'availability':old[c['id']]['availability'],'evidence':old[c['id']].get('availabilityEvidence')},'after':{'availability':'current_or_order_listed','evidence':{'checkedAt':D,'orderStatus':'accepting_orders_advertised','stockStatus':'no_new_stock_verified','sourceIds':[sources[sk]['id']],'physicalStockVerified':False,'factoryOrderAcceptanceVerified':False,'qualifications':['Exact named version is selectable in Tesla Australia’s new-vehicle configurator. No order was submitted; accepted factory allocation, delivery timing and physical stock remain unverified.']}},'status':'approved','reviewedBy':REVIEWER,'reviewedAt':D,'evidenceDate':D,'reason':'Complete current Australian new-vehicle configurator version list checked against each existing exact grade.'})
def summary(cid,sl,st,skeys,tl,tt,tkeys,conds=[]):
 def clause(l,t,ks):return {'label':l,'text':t,'dependencies':[{'key':k,'expected':effective[cid][k]} for k in ks]}
 p['summaries'].append({'variantId':cid,'conditions':conds,'strength':clause(sl,st,skeys),'tradeoff':clause(tl,tt,tkeys)})
summary('tesla_model_3__rear_wheel_drive__3','Entry price and range','A$45,900 base price pairs with 572 km WLTP range; A$1,400 delivery, A$400 order fee and on-roads are extra.',['price_aud','range_km'],'Lower charging ceiling','The 175 kW DC peak limits the available fast-charging power.',['dc_peak_kw'])
summary('tesla_model_3__premium_rwd__2','Useful sedan luggage space','Five seats and 594 L behind the second row provide useful everyday luggage space.',['seats','boot_l'],'Long-trip range planning','The 520 km WLTP claim makes charging-stop planning important on long journeys.',['range_km'])
summary('tesla_model_3__premium_long_range_rwd__1','Long-range rear-drive sedan','The 750 km WLTP claim with 18-inch wheels gives this rear-drive sedan substantial claimed touring range.',['range_km','drive','body_style'],'Light-trailer towing','The 1,000 kg braked limit needs the compatible tow package and approved tyres; a separate controller is required above 750 kg.',['towing_braked_kg'],['750 km is with 18-inch wheels; Tesla lists 691 km with 19-inch wheels.'])
summary('tesla_model_3__performance_awd__4','Quick all-wheel-drive sedan','Tesla claims 3.1 seconds to 100 km/h with rollout subtracted, paired with all-wheel drive.',['zero_to_100_s','drive'],'Low clearance','The 128 mm published ground clearance calls for care on steep driveways and rough surfaces.',['ground_clearance_mm'],['The acceleration claim subtracts rollout.'])
summary('tesla_model_y__premium_rwd__2','Family luggage space','Five seats and 822 L behind the second row provide a large stated rear cargo area.',['seats','boot_l'],'Touring range planning','The 466 km WLTP claim makes charging-stop planning important on long trips.',['range_km'])
summary('tesla_model_y__premium_long_range_awd__1','AWD touring range','All-wheel drive pairs with 600 km of claimed WLTP range for family touring.',['drive','range_km'],'Tow-kit requirements','The 1,588 kg braked maximum requires the optional tow package; a separate brake controller is required above 750 kg.',['towing_braked_kg'])
summary('tesla_model_y__performance_awd__3','Quick all-wheel-drive SUV','Tesla claims 3.5 seconds to 100 km/h with rollout subtracted, paired with all-wheel drive.',['zero_to_100_s','drive'],'Higher purchase budget','The A$84,900 base price also needs A$1,400 delivery, A$400 order fee and government on-roads.',['price_aud'],['The acceleration claim subtracts rollout.'])
summary('tesla_model_y__l_premium_awd__4','Six-seat touring layout','Six seats and a 681 km WLTP claim support larger-family touring.',['seats','range_km'],'Luggage with all seats used','With all six seats occupied, the rear cargo area is 420 L behind the third row.',['seats','boot_l'])
rec={'schemaVersion':1,'checkedAt':D,'notes':['Tesla-only current Australian new-car reconciliation. Four Model 3 grades, three five-seat Model Y grades and one long-wheelbase six-seat Model Y L are reviewed separately. No whole-market independent list is invented.','Model S and Model X AU endpoints redirect to the AU home page; AU ordering support lists Model 3 and Model Y only. Current CarExpert Australian Tesla range corroborates their absence. These are not current new-order catalogue omissions. Sources: https://www.tesla.com/en_au/models ; https://www.tesla.com/en_au/modelx ; https://www.tesla.com/en_au/support/ordering-new-vehicle ; https://www.carexpert.com.au/tesla','Roadster is upcoming/reservation-related, not a current configurable new vehicle. Live AU Roadster page has a reveal countdown; reservation agreement explicitly is not a purchase agreement. Sources: https://www.tesla.com/en_au/roadster ; https://www.tesla.com/en_au/roadster/reserve ; '+sources['terms-t13']['url']],'publishedLists':[],'currentVersionReviews':[],'listResolutions':[],'catalogueOnlyDifferences':[],'inventoryResolutions':[{'kind':'lead','inventoryId':'tesla-cybertruck','outcome':'excluded','exclusionReason':'not_orderable_or_new_stock','reviewedAt':D,'reason':'Australian Cybertruck page offers Get Updates; Australian design path returns the informational page. No current Australian new order/configuration or official new stock was established. AU ordering support lists Model 3 and Model Y; current independent Australian range corroborates exclusion. Overseas sales and private imports are not Australian official new availability.','sourceUrls':[sources['terms-t08']['url'],sources['terms-t05']['url'],sources['terms-t09']['url']]}]}
for model,body,mid,sk in [('Model 3','Sedan','tesla_model_3','m3'),('Model Y','SUV','tesla_model_y','my'),('Model Y L','SUV','tesla_model_y','my')]:
 versions=[c for c in cars if c['model']==model]
 rec['currentVersionReviews'].append({'id':PID+'-'+model.lower().replace(' ','-')+'-current','brand':'Tesla','model':model,'bodyStyle':body,'vehicleClass':'passenger','modelId':mid,'checkedAt':D,'officialSourceUrls':[sources[sk+'-product']['url'],sources[sk+'-config']['url']],'reason':'Complete exact current Australian maker version list, checked in both product specification blocks and configurator. Model Y L has a separate six-seat long-wheelbase body identity despite its retained stable legacy modelId; it is not merged into the five-seat body review.','versions':[{'carId':c['id'],'model':c['model'],'trim':c['trim'],'modelYear':c['year']} for c in versions]})
# Clean human-readable prose only; never mutate captured source IDs, URLs or guarded old state.
import re
def prose(s):
 s=s.replace('method unspecified','method unspecified').replace('rather than VDA','with VDA method not stated')
 s=re.sub(r'(?<=[A-Za-z])(?=\d)', ' ', s)
 s=re.sub(r'(?<=\d)(?=(?:km|kWh|kW|mm|kg|min|minutes|inch|litres|L|V|A|s)\b)', ' ',s)
 s=re.sub(r'(?<=;)(?=\S)', ' ',s)
 s=re.sub(r'(?<=[A-Za-z]),(?=\S)', ', ',s)
 s=re.sub(r'(?<=[A-Za-z])\.(?=[A-Za-z0-9])', '. ',s)
 s=s.replace('ModelY','Model Y').replace('baseRWD','base RWD').replace('ExplicitMY','Explicit MY').replace('2Oct','2 Oct').replace('88.2gross/86usable','88.2 gross / 86 usable').replace('3500lb','3,500 lb').replace('T 01:00:00Z','T01:00:00Z')
 s=s.replace('3500lb(1558 kg)', '3,500 lb (1,558 kg)').replace('allY/YL','all Model Y / Model Y L').replace('asCheck','as Check').replace(';19/20/21in','; 19/20/21-inch').replace(';19/20in','; 19/20-inch').replace('explicitlyMY','explicitly MY').replace('PriorMY','Prior MY').replace('fullMY','full MY').replace('six-seatL','six-seat L').replace('MY 27','MY27').replace('MY 26','MY26').replace('A$ 1','A$1')
 return s
fields={'reason','conditionExplanation','publication_action','title','basis','comparisonBasis','scope','supports','text','originalBasis','sourceLabel','generation'}
def clean(o):
 if isinstance(o,dict):
  for k,v in o.items():
   if k in ['before','expected']:continue
   if k in fields and isinstance(v,str):o[k]=prose(v)
   elif k in ['qualifications','conditions','notes'] and isinstance(v,list):o[k]=[prose(t) if isinstance(t,str) else t for t in v]
   else:clean(v)
 elif isinstance(o,list):
  for z in o:clean(z)
clean(p);clean(rec)
# Re-copy dependencies after final prose normalisation so guards remain exact.
for row in p['summaries']:
 for clause in [row['strength'],row['tradeoff']]:
  for d in clause['dependencies']:d['expected']=copy.deepcopy(effective[row['variantId']][d['key']])
feature_rows=[]
for before in json.load(open(R/'features-before.json')):
 if before['criterion']!='storage' or before['model_id']!='tesla_model_3':continue
 cid=before['variant_id'];source_ids=[sources[k]['id'] for k in ['m3-manual','m3-product']]
 after={'variant_id':cid,'model_id':'tesla_model_3','criterion':'storage','status':'standard','value':'594 L rear boot · 88 L front boot · seats-folded maximum Not published','conditions':'Rear figure is behind the second row with seats up. Tesla does not specify the cargo measurement method. Current AU product and manual do not publish a seats-folded maximum; 682 L is combined front/rear cargo with five passengers, not rear-boot volume.','source_ids':source_ids,'evidence_scope':'Current Australian Model 3 owner manual, Cargo Volume table, PDF page 222 (printed page 220), and current AU product page','last_evidence_date':D,'reviewed_date':D,'publication_rule':'Keep rear/front cargo scopes separate; do not publish a seats-folded number without matching evidence.','verification_state':'reviewed_2026-10-14','condition_label':'','usability_notes':[],'buyerGrade':'confirmed','gradeReview':{'reviewedAt':D,'overlayId':PID,'reason':'AU manual explicitly establishes 594 L behind the second row and 88 L front trunk for the Model 3 body. Two current maker sources examined do not publish a folded maximum. Inherited 977 L is removed; 977 appears only as rear overhang in millimetres in the current manual.','evidenceScope':'explicit_au_range','sourceIds':source_ids,'sourceLabel':'Tesla Australia'}}
 feature_rows.append({'variantId':cid,'criterion':'storage','before':before,'after':after,'dependencies':[{'key':k,'expected':copy.deepcopy(effective[cid][k])} for k in ['boot_l','frunk_l','max_total_cargo_l','seats']]})
for before in json.load(open(R/'features-before.json')):
 if before['criterion']!='storage' or before['model_id']!='tesla_model_y':continue
 cid=before['variant_id'];is_l='__l_premium_' in cid;source_ids=[sources[k]['id'] for k in ['my-dimensions','my-product']]
 after={'variant_id':cid,'model_id':'tesla_model_y','criterion':'storage','status':'standard','value':('420 L rear behind occupied third row · 116 L front · 2,539 L combined maximum' if is_l else '822 L rear with second row up · 116 L front · 2,138 L combined maximum'),'conditions':'Maximum is combined front and rear cargo with only the driver and front passenger; it already includes the front trunk. '+('Rear 420 L applies with all six seats occupied.' if is_l else 'Rear 822 L applies with all five seating positions available.')+' Tesla does not specify the cargo measurement method.','source_ids':source_ids,'evidence_scope':'Current Australian Model Y owner manual, Dimensions / Cargo Volume, separately headed five-seat and Model Y L six-seat tables','last_evidence_date':D,'reviewed_date':D,'publication_rule':'Keep rear/front cargo scopes and occupant configuration separate; do not add the front trunk to the already-combined maximum.','verification_state':'reviewed_2026-10-14','condition_label':'','usability_notes':[],'buyerGrade':'confirmed','gradeReview':{'reviewedAt':D,'overlayId':PID,'reason':'AU manual explicitly establishes separate rear, front and maximum combined cargo volumes for the named five-seat or six-seat body. Wording clarifies the combined maximum without changing its supported value.','evidenceScope':'explicit_au_range','sourceIds':source_ids,'sourceLabel':'Tesla Australia'}}
 feature_rows.append({'variantId':cid,'criterion':'storage','before':before,'after':after,'dependencies':[{'key':k,'expected':copy.deepcopy(effective[cid][k])} for k in ['boot_l','frunk_l','max_total_cargo_l','seats']]})
(R/'tesla-features-proposed.json').write_text(json.dumps(feature_rows,ensure_ascii=False,indent=2)+'\n')
p['features']=feature_rows
(R/'tesla-2026-10-14.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
(R/'tesla-reconciliation-2026-10-14.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n')
print('Packet',len(p['sources']),'sources;',len(p['facts']),'facts;',len(p['brandTerms']),'shared terms;',len(p['summaries']),'summaries')
