# Tesla Australian M1 packet — staged for independent review

Checked Australian date: 14 October 2026. Public captures were taken on 13 October 2026 UTC (14 October in Australia). No purchase, enquiry, reservation, sign-in or live publication was performed.

## Deliverables
- `tesla-2026-10-14.json`: guarded packet, currently unregistered
- `tesla-reconciliation-2026-10-14.json`: exact current body/version reviews and Cybertruck lead exclusion
- `source-index.json`: source URLs, capture locators/hashes and visual checks
- `evidence-manifest.json`: local evidence files and SHA-256 hashes
- `staged-report.json`, `after.json`, `stage-validation.log`: importer/report dry run
- `tesla-features-proposed.json`: same eight storage replacements included in packet.features, for the optional guarded feature extension

## Complete current new Australian order list
| Body | Exact current version | Base AUD |
|---|---|---:|
| Model 3 sedan | Rear-Wheel Drive | 45,900 |
| Model 3 sedan | Premium RWD | 54,900 |
| Model 3 sedan | Premium Long Range RWD | 61,900 |
| Model 3 sedan | Performance AWD | 80,900 |
| Model Y five-seat SUV | Premium RWD | 58,900 |
| Model Y five-seat SUV | Premium Long Range AWD | 68,900 |
| Model Y five-seat SUV | Performance AWD | 84,900 |
| Model Y L six-seat long-wheelbase SUV | Premium AWD (six-seat) | 74,900 |

Prices are Tesla's published Australian configurator base values including GST, before on-roads. Each price fact separately discloses A$1,400 delivery and A$400 order fees. No fee was silently added, and no example state driveaway quote, saving, finance assumption or inventory discount was substituted. The configurator is advertised order availability, not physical stock or an accepted factory allocation.

Model Y L keeps its stable original id/modelId but receives a guarded display identity and its own exact six-seat body review. Dry-run reconciliation retains three separate reviews containing 4, 3 and 1 versions, respectively. There are no added variants or modified original model/art files.

## Material evidence decisions
- Brand terms: 5 years/unlimited kilometres basic warranty for new deliveries from 1 January 2026; roadside while basic warranty is active with explicit assistance limits/exclusions. Battery/drive-unit terms are 8 years/192,000 km for five specified grades, with three explicit 160,000 km RWD exceptions; minimum 70% retention and whichever first are retained. Shared terms and source records are stored once.
- All 136 core cells are reviewed. Eight battery figures and seven power figures are Reported where only Australian secondary material supplies them. MY26 carryover reports are openly scoped; they are not maker confirmation of MY27 hardware. No battery energy was estimated, converted from Ah or inferred from range; no motor outputs were summed.
- Current MY27 Model 3 Performance: maker's 343 kW, 128 mm clearance and supplied 20-inch/non-towing configuration override conflicting secondary values. Carsales/RedBook's exact MY27 85 kWh battery figure remains Reported, with its unrelated database discrepancies disclosed.
- Five exact 10–80% charging times remain Not published: all four Model 3 grades and Model Y Premium RWD. Two genuine sources and the exact missing window are recorded for each. Maker kilometres-added-in-15-minutes and a CarsGuide 15–85% test are not converted. Three Model Y AWD grades retain a clearly labelled approximate prior-MY26 Australian family report of 25–30 minutes, unranked as Reported.
- Both Performance acceleration claims preserve rollout subtraction as Check and in the summary conditions.
- Cargo: Model 3 594 L rear/88 L front; five-seat Model Y 822 L rear/116 L front; six-seat Model Y L 420 L behind occupied third row/116 L front. Tesla's method is unspecified, so these figures are excluded from inappropriate boot rankings. Y maximum combined cargo remains 2,138 L / L 2,539 L with only front occupants.
- Model 3's inherited 977 L folded maximum is unsupported by current product/manual evidence. 977 occurs as rear overhang in mm in the manual. Canonical maximum-cargo facts now say Not published, and four exact guarded storage features remove that duplicate claim. No conversion was used to invent a replacement.
- Y source conflicts remain visible Check with cited issues and are unranked: five-seat Premium length 4,790 mm excluding plate bracket vs retail 4,792 mm; L height retail 1,668 mm vs manual 1,664 mm; L manual towing prints 1,558 kg vs accessory 1,588 kg and has ambiguous five-occupant rows. L six-occupant limit 1,043 kg is disclosed. Five-seat Y towing is 1,588 kg with optional kit/controller conditions.
- Model S/X Australian endpoints redirect and current AU ordering material only names Model 3/Y. Cybertruck has Get Updates rather than an AU configuration/order, so the inherited lead is excluded. Roadster remains upcoming/reservation-related; its reservation agreement is not a purchase/order. No overseas model is imported into the catalogue.

## Verification status
Staged importer/application passes against the effective BYD-integrated catalogue, without snapshot regeneration. Report marks Tesla researchCompleted, with no unreviewed core cells, missing summaries, unresolved Tesla leads, missing Tesla models or aged/invalid claims. Global whole-market independent-list reconciliation is not claimed complete; genuine charging and ranking limitations remain visible. Independent evidence review approved packet SHA-256 ed099843f37d65d0b8dbbc949b77b5ca01141936c7921cef3b5d24fb2ffdc059 and reconciliation SHA-256 4f1ec930cfd512fea44d890cc30e62c9b7a64287496910361dc982748eff0576. All eight feature guards and 32 dependency snapshots passed independent checking. The guarded feature-extension integration regression remains the registration gate; root owns registration. Detailed review: /workspace/scratch/586427eef9f2/roadmark-104-qa/tesla-packet-independent-review.md.

Original catalogue/editorial/correction data and Model Y hero/art are untouched. All work in this folder is staged research, not registered delivery.

## Shared power-answer amendment
Root’s cross-surface check found eight retained performance_rear_motor answers saying output not published despite canonical reviewed power figures. The staged amendment appends eight guarded replacements, depending on exact power_kw and drive facts. Seven retain Reported scope and conditions; Model 3 Performance uses maker-confirmed 343 kW peak vehicle output. AWD wording explicitly describes whole-vehicle power, not the rear motor alone.

Previous approved/registered packet SHA-256: ed099843f37d65d0b8dbbc949b77b5ca01141936c7921cef3b5d24fb2ffdc059. The original bytes are preserved in review-history. New staged SHA-256: e45015f156b981e2c6e9e94338c4d548c91a2588d092a7e0b139fe0e0cc45d03. All previous sections and the eight storage rows remain deeply equal. Only eight new feature rows were appended. Registered file was not overwritten by the researcher.

The new guarded feature helper passes eight rows and 16 dependency snapshots against current effective features, with immutable inputs. Full staged packet application against exact pre-Tesla snapshots also passes. Independent amendment review approved the new e45015f156b981e2c6e9e94338c4d548c91a2588d092a7e0b139fe0e0cc45d03 hash. Root owns replacement and final integration.
