import json,pathlib,hashlib,re
P=pathlib.Path('/tmp/kia-research/ev6-ev9'); S=P/'sources'
idx=json.load(open(P/'source-index.json'))
for key,url in [('ev6-carexpert-review','https://www.carexpert.com.au/car-reviews/2026-kia-ev6-review'),('ev9-carexpert-gt-review-web','https://www.carexpert.com.au/car-reviews/2026-kia-ev9-gt-review')]:
 parts=[S/(key+'.txt'),S/(key+'-rest.txt')]
 dest=S/(key+'-full.txt');dest.write_text('\n\n'.join(p.read_text() for p in parts))
 idx=[x for x in idx if x['key']!=key]
 idx.append({'key':key,'url':url,'path':str(dest),'textPath':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'checkedAt':'2026-10-14','captureMethod':'Web retrieval full-page text in two overlapping ranges; raw HTML returned 403; no raw HTML assertion'})
json.dump(idx,open(P/'source-index.json','w'),indent=2)
sources=[]
for x in idx:
 if 'error' in x or x['key'].endswith('-config'):continue
 key=x['key']; maker='kia.com/' in x['url']; name='EV6' if key.startswith('ev6') else 'EV9'
 title=('Kia Australia '+name+' MY'+('27' if name=='EV6' else '26')+' mechanical and feature brochure' if key.endswith('brochure') else 'Kia Australia '+name+' Build & Price '+key.split('_',1)[-1] if maker and ('price' in key or 'colour' in key or 'build' in key) else 'Kia Australia '+name+' current model page' if maker else 'CarExpert 2026 Kia '+name+' '+('GT ' if name=='EV9' else '')+'review' if 'carexpert' in key else 'CarsGuide 2026 Kia EV9 GT review')
 note=''
 if key=='ev9-brochure':note="Current AU maker page links this MY26 document; PDF page 6 retains future inspection footer 'As of 12 February 2027'. Actual capture 14 October 2026. This is not accepted as a publication date or an on-sale date. Current live grade selector and successful exact-GT price API establish current GT listing. Maker specs are admitted for current named AU versions; shared 7/5-seat cargo labels do not establish six-seat GT occupied-seat volume."
 if key=='ev6-brochure':note='Cover, mechanical heading and footer explicitly MY27. Live model-page title also 2027. Earlier indexed 2026 title and secondary 2026 launch coverage do not replace current maker identity. Inspection caveat is retained as standing version note, not blanket per-fact downgrade.'
 if 'carexpert' in key:note='Web full-page text captured in overlapping ranges because direct raw HTML returned HTTP 403. Editorial 350 kW charge-rate claim conflicts with maker station-power wording and is not used as vehicle DC peak.'
 sources.append(dict(key=key,url=x['url'],title=title,publisher='Kia Australia' if maker else 'CarExpert' if 'carexpert' in key else 'CarsGuide',source_type='manufacturer' if maker else 'secondary',published_date=('2026-05-11' if key=='ev6-carexpert-review' else '2026-04-26' if key=='ev9-carsguide-gt-review' else None),accessed_date='2026-10-14',market='AU',file=x['path'],textFile=x['textPath'],sha256=x['sha256'],bytes=pathlib.Path(x['path']).stat().st_size,note=note))
B=json.load(open('/tmp/kia-research/before.json'))
variants=[]
configs=[('EV6','Air RWD','AIR_SR',0),('EV6','GT-Line RWD','GTL_RWD',1),('EV6','GT-Line AWD','GTL_AWD',2),('EV6','GT AWD','GT_AWD',3),('EV9','Air RWD','AIR',0),('EV9','Earth AWD','EARTH',1),('EV9','GT-Line AWD','GTLINE',2),('EV9','GT AWD','GT',3)]
for model,trim,code,i in configs:
 old=next(c for c in B if c['model']==model and c['trim']==trim); m=model.lower(); spec=m+'-brochure';page=m+'-features';pk=m+'_'+code+'_price';colour=m+'_'+code+'_colour';price=json.load(open(S/(pk+'.json')))['dataInfo'][0]['trimInfo'][0]
 facts=[]
 def F(key,value,basis,comparison='',grade='confirmed',sourceKeys=None,reason=None,condition=None,qualifications=None,**extra):
  d=dict(key=key,value=value,sourceKeys=sourceKeys or [spec],grade=grade,basis=basis,comparison=comparison,reason=reason or 'Current maker Australian brochure explicitly publishes this figure for the named version.',qualifications=qualifications or [])
  if condition:d['condition']=condition
  d.update(extra);facts.append(d);return d
 F('price_aud',float(price['rrpprice']),"Maker's recommended retail price before on-road costs",'Before on-road costs',sourceKeys=[pk,m+'_build'],reason='Successful live Kia AU exact-trim pricing API labels this field rrpprice; current named grade is linked from the model page and build selector. RRP is admitted ahead of its separate state driveaway estimate.',priceRung=1,basisTag="Maker's RRP",priceTag="Maker's RRP",rankingEligible=True,sourcePointer='dataInfo[0].trimInfo[0].rrpprice',originalBasis='Kia recommended retail price; excludes on-road costs and optional extras',qualifications=['Base paint/configuration; optional paint and accessories cost extra. The current grade selector and API do not give an MY field; maker current brochure supplies model-year identity.'])
 F('configurator_rrp_aud',float(price['rrpprice']),"Maker's current grade RRP",'Before on-road costs',sourceKeys=[pk],reason='Exact maker API rrpprice, retained separately without obsolete MY-unconfirmed grading.',sourcePointer='dataInfo[0].trimInfo[0].rrpprice')
 F('driveaway_price_aud',float(price['price']),'Maker NSW driveaway estimate, base colour and no accessories','Driveaway',grade='check',sourceKeys=[pk,m+'_build'],reason='Maker API separately lists NSW driveaway estimate. All-state prices differ, so this is not a national driveaway offer.',condition='NSW estimate only; dealer delivery, insurer and buyer circumstances can change actual price. Government, fleet and rental buyers excluded.',qualifications=['Includes RRP, applicable luxury car tax, 12 months registration and estimated CTP, stamp duty and dealer delivery; excludes options and accessories.','This is a configurator estimate, not a limited-time promotional offer.'],priceRung=4,basisTag="Maker's NSW driveaway estimate",state='NSW',rankingEligible=True,sourcePointer='dataInfo[0].trimInfo[0].priceOfferNSW')
 if model=='EV6':
  vals={'range_km':[582,560,522,450][i],'battery_kwh':84,'seats':5,'dc_charge_time_min':18,'ac_kw':10.5,'boot_l':[490,480,480,480][i],'frunk_l':[52,52,20,20][i],'zero_to_100_s':[7.7,7.7,5.3,3.5][i],'power_kw':[168,168,239,478][i],'length_mm':4695,'width_mm':[1880,1890,1890,1890][i],'height_mm':[1550,1550,1550,1545][i],'wheelbase_mm':2900,'ground_clearance_mm':[160,160,160,155][i],'turning_circle_m':[11.6,11.6,11.6,11.9][i],'tare_weight_kg':[2055,2065,2165,2220][i],'towing_braked_kg':1800,'towing_unbraked_kg':750}
 else:
  vals={'range_km':[443,512,505,510][i],'battery_kwh':[76.1,99.8,99.8,99.8][i],'seats':[7,7,7,6][i],'dc_charge_time_min':[20,24,24,24][i],'ac_kw':10.5,'boot_l':333,'frunk_l':[90,52,52,52][i],'max_total_cargo_l':[2318,2318,2318,2393][i],'zero_to_100_s':[8.2,5.3,5.3,4.5][i],'power_kw':[160,282.6,282.6,374][i],'length_mm':[5010,5010,5015,5015][i],'width_mm':1980,'height_mm':[1755,1755,1780,1755][i],'wheelbase_mm':3100,'ground_clearance_mm':177,'turning_circle_m':12.4,'kerb_weight_kg':[2312,2552,2636,2679][i],'tare_weight_kg':[2312,2619,2636,2679][i],'towing_braked_kg':[900,2500,2500,2500][i],'towing_unbraked_kg':[450,750,750,750][i]}
 for key,v in vals.items():
  if key=='range_km': F(key,v,'WLTP combined range','WLTP')
  elif key=='battery_kwh':F(key,v,'Maker published battery energy; gross/usable not specified','Published capacity, gross/usable unspecified')
  elif key=='seats':F(key,v,'Australian standard seating capacity','Seats',sourceKeys=[spec,page])
  elif key=='dc_charge_time_min':F(key,v,'DC 10–80% using a 350 kW charger','DC 10–80%',grade='check',condition='Kia HQ test using a 350 kW DC charging station; battery temperature, ambient conditions and station output affect charging time.',qualifications=['350 kW describes the charging station; it does not establish vehicle peak DC acceptance.'])
  elif key=='ac_kw':F(key,v,'Maximum AC onboard charger capacity; three-phase','AC kW',qualifications=['EV9 additionally states 7 kW single-phase; 11 kW in the timed test row is charging equipment rating.'] if model=='EV9' else ['10.5 kW onboard maximum; 11 kW in the timed test row is charging equipment rating.'])
  elif key=='boot_l':
   if model=='EV6':F(key,v,'VDA rear cargo minimum; seating/load position not explicitly defined','',qualifications=['Maker labels Cargo Area Rear (Min) (L, VDA); current AU PDF does not explicitly state seats-up/load-height method. Do not silently relabel as seats-up for boot rankings.'])
   elif i==3:F(key,v,'Rear cargo with all three rows in use (six seats); measurement standard unspecified','',grade='reported',sourceKeys=['ev9-carexpert-gt-review-web'],reason='Exact Australian EV9 GT road test explicitly says 333 L with all three rows in use. Maker common row is labelled 7 seats up despite GT having six seats; secondary specific configuration resolves occupied-seat volume without assuming its measurement standard.',qualifications=['Maker brochure shared 333 L row is labelled 7 seats up and 828 L row 5 seats up; neither is silently relabelled for six-seat GT.','CarExpert review reports this figure; unranked because secondary evidence and measurement standard unspecified.'])
   else:F(key,v,'VDA rear cargo with seven seats up','VDA; 7 seats up')
  elif key=='max_total_cargo_l':F(key,v,'VDA rear cargo with two seats up (second and third rows folded)','VDA; 2 seats up',qualifications=['Rear cargo only; front storage is separate and not added.'])
  elif key=='frunk_l':F(key,v,'Front cargo compartment; measurement method unspecified','',qualifications=['Separate front cargo, not added to rear boot volume.'])
  elif key=='zero_to_100_s':F(key,v,'Manufacturer approximate 0–100 km/h acceleration','0–100 km/h',grade='check' if model=='EV6' and i==3 else 'confirmed',condition='Approximate 3.5 seconds requires Launch Control.' if model=='EV6' and i==3 else None)
  elif key=='power_kw':F(key,v,'Manufacturer combined system output, explicitly published','Manufacturer combined system output',qualifications=['Published combined system figure; not calculated by summing individual motor maxima.'])
  elif key in ['length_mm','width_mm','height_mm']:F(key,v,'Manufacturer overall body dimension'+('; including roof rails' if key=='height_mm' and model=='EV9' else ''),'Body mm',qualifications=['Mirror-inclusive width not stated.'] if key=='width_mm' else [])
  elif key=='wheelbase_mm':F(key,v,'Wheelbase','Wheelbase mm')
  elif key=='ground_clearance_mm':F(key,v,'Manufacturer minimum ground clearance','Minimum ground clearance mm')
  elif key=='turning_circle_m':F(key,v,'Minimum turning circle diameter','Turning circle diameter m')
  elif key in ['tare_weight_kg','kerb_weight_kg']:F(key,v,'Maker '+('tare' if key.startswith('tare') else 'kerb')+' mass',('Tare mass' if key.startswith('tare') else 'Kerb mass'),qualifications=['The same current maker table lists Earth kerb 2552 kg and tare 2619 kg; retained literally as conflicting distinct published labels, not converted or interchanged.'] if model=='EV9' and i==1 else [])
  else:F(key,v,'Manufacturer '+('braked' if key=='towing_braked_kg' else 'unbraked')+' towing capacity','Braked towing kg' if key=='towing_braked_kg' else 'Unbraked towing kg',qualifications=['Subject to state regulations and approved towbar design.'])
 F('drive','RWD' if (model=='EV6' and i<2) or (model=='EV9' and i==0) else 'AWD','Maker driven wheels','Drive type')
 if model=='EV6':
  F('dc_peak_kw',258,'CarExpert/JATO 84 kWh EV6 family maximum DC rate; carried to current MY27 sibling','',grade='reported',sourceKeys=['ev6-carexpert-review'],reason='Current Australian CarExpert review JATO-powered family specification comparison explicitly reports 258 kW for 84 kWh EV6. Maker MY27 brochure lacks a vehicle peak. Family/sibling carry is Reported and unranked.',qualifications=['CarExpert editorial table incorrectly uses 350 kW station rating; the distinct JATO-powered DC Fast Charging (max kW) family field supplies 258 kW.','Current maker model year is MY27; secondary report describes 2026 facelift family and does not independently certify exact MY27 hardware.'],sourcePointer='Comparative Rating > Battery & Charging > DC Fast Charging (max kW): 258 kW; adjacent family 84 kWh capacity')
  F('kerb_weight_kg',None,'Not published; current maker gives tare, not kerb','',grade='not_published',sourceKeys=[spec,page],reason='Reviewed current maker brochure and live AU model page; neither gives kerb mass. Tare is retained separately and not substituted.')
  if i==0:F('max_total_cargo_l',None,'Not published for exact Air rear-cargo configuration','',grade='not_published',sourceKeys=[spec,page],reason='Maker brochure and AU page omit folded maximum cargo. Secondary 480 L/1250 L common GT-Line table does not resolve the Air 490 L configuration.')
  else:F('max_total_cargo_l',1250,'Rear cargo with rear seats folded; Australian 2026 GT-Line RWD review, sibling carry where applicable','',grade='reported',sourceKeys=['ev6-carexpert-review'],reason='CarExpert exact 84 kWh GT-Line RWD review reports 1250 L VDA rear seats folded. Applied as clearly labelled Reported MY27/family sibling evidence; maker omits this field.',qualifications=['Exact tested trim is 2026 GT-Line RWD; current MY27 and other same 480 L trim applicability is a sibling carry, not maker confirmation.'])
 else:
  F('dc_peak_kw',None,'Vehicle peak DC acceptance not published in current AU maker material','',grade='not_published',sourceKeys=[spec,page,'ev9-carexpert-gt-review-web'],reason='Current AU brochure and model page provide timed charging on a 350 kW station, not vehicle peak. Secondary current GT review mislabels station power as 350 kW; family 210 kW data does not resolve exact battery/grade mapping. No station rating or motor arithmetic is substituted.')
  F('cargo_third_row_folded_l',828,'Rear cargo behind second row with third row folded'+('; VDA, five seats up' if i<3 else '; four seats available, measurement standard unspecified'),'' if i==3 else 'VDA; 5 seats up',grade='reported' if i==3 else 'confirmed',sourceKeys=['ev9-carexpert-gt-review-web'] if i==3 else [spec],reason='Exact GT road test says 828 L with third row folded; occupied four-seat layout follows independently confirmed six-seat 2+2+2 cabin.' if i==3 else None,qualifications=['Maker common 5 Seats Up label does not fit GT; secondary third-row-folded description retained explicitly.'] if i==3 else [])
  F('second_row_layout','Captain chairs, two seats with relaxation and massage' if i==3 else 'Three-seat 60:40 split folding bench','Maker Australian second-row seating','',sourceKeys=[spec,page])
  if i in [1,2]:F('rear_ventilated_seats','Not available' if i==1 else 'Standard: second row','Maker ventilation equipment row','')
 if model=='EV6' and i==3:
  F('electronic_controlled_suspension','Standard, three modes','Maker exact GT equipment','')
  F('e_lsd','Standard','Maker exact GT equipment','',sourceKeys=[page])
 if model=='EV6' and i==2:F('motor_count',2,'Front and rear electric motors','Motor count')
 F('carplay_android_auto_published','Wired and wireless Apple CarPlay and Android Auto' if model=='EV6' else 'Wired Apple CarPlay and Android Auto','Current AU brochure connectivity rows','')
 F('v2l_equipment','Interior socket; exterior adaptor supplied' if (model=='EV6' and i>0) or (model=='EV9' and i>1) else 'Interior socket; exterior adaptor not standard','Current AU brochure V2L equipment rows','')
 F('front_heated_seats_published','Not available' if model=='EV6' and i==0 else 'Standard','Current AU brochure ventilation rows','')
 F('front_ventilated_seats_published','Not available' if model=='EV6' and i==0 else 'Standard','Current AU brochure ventilation rows','')
 F('rear_heated_seats_published','Standard' if (model=='EV6' and i==3) or (model=='EV9' and i>=2) else 'Not available','Current AU brochure ventilation rows','')
 F('child_seat_anchors','3 top tethers and 2 ISOFIX positions' if model=='EV6' else '4 top tethers and 4 ISOFIX positions' if i==3 else '5 top tethers and 4 ISOFIX positions','Current AU brochure child restraint row','')
 factsByKey={f['key']:f for f in facts}
 features=[]
 def feat(criterion,value,keys,grade='confirmed',conditions=''):
  features.append(dict(criterion=criterion,value=value,keys=keys,grade=grade,conditions=conditions,reason='Dated exact-version review replaces unknown equipment answer with source-bound current claims.'))
 boot=vals['boot_l'];frunk=vals['frunk_l']
 if model=='EV6':storage=f'{boot} L VDA rear cargo minimum; {frunk} L separate front storage'+('; rear folded maximum not published for Air' if i==0 else '; 1,250 L rear seats folded reported by CarExpert from GT-Line RWD')
 else:storage=f'333 L rear cargo with {6 if i==3 else 7} seats in use; {vals["max_total_cargo_l"]:,} L VDA rear cargo with two seats up; {frunk} L separate front storage'
 feat('storage',storage,['boot_l','frunk_l','max_total_cargo_l'],'reported' if (model=='EV9' and i==3) or (model=='EV6' and i>0) else 'confirmed','EV6 maker minimum does not define seating/load position; separate cargo figures are not added.' if model=='EV6' else 'GT occupied-seat figure is reported; maker shared row says seven seats up and is not silently relabelled.' if i==3 else '')
 feat('home_charging','Up to 10.5 kW AC onboard charging'+('; 7 kW single-phase' if model=='EV9' else ''),['ac_kw'])
 for criterion,key in [('carplay_android_auto','carplay_android_auto_published'),('v2l','v2l_equipment'),('front_heated_seats','front_heated_seats_published'),('front_ventilated_seats','front_ventilated_seats_published'),('rear_heated_seats','rear_heated_seats_published'),('child_seats','child_seat_anchors')]:feat(criterion,factsByKey[key]['value'],[key])
 if model=='EV6':
  strength={'label':'Quick charging stops','text':'Kia quotes 18 minutes for a 10–80% charge using a 350 kW DC station.','keys':['dc_charge_time_min']}
  if i==0:strength={'label':'Long-range five-seater','text':'The 582 km WLTP range leaves room for longer journeys between charging stops.','keys':['range_km','seats']}
  if i==3:strength={'label':'Launch-control pace','text':'Kia quotes 0–100 km/h in about 3.5 seconds with Launch Control.','keys':['zero_to_100_s']}
  tradeoff={'label':'Five-seat layout','text':'The five-seat cabin cannot take a sixth occupant.','keys':['seats']}
  if i==3:tradeoff={'label':'Range compromise','text':'The GT’s published WLTP range is 450 km, so plan charging around that figure.','keys':['range_km']}
 else:
  strength={'label':'Seven-seat cabin','text':'Seven seats and a 333 L VDA boot with every seat in use suit trips with the whole family.','keys':['seats','boot_l']}
  tradeoff={'label':'Check parking space','text':f'The {vals["length_mm"]:,} mm body needs a long parking space.','keys':['length_mm']}
  if i==0:tradeoff={'label':'Light-trailer limit','text':'The 900 kg braked towing limit restricts trailer choice.','keys':['towing_braked_kg']}
  if i in [1,2]:strength={'label':'Seats and towing','text':'Seven seats combine with a 2,500 kg braked towing rating.','keys':['seats','towing_braked_kg']}
  if i==3:
   strength={'label':'Six seats with pace','text':'The six-seat GT has a maker-quoted 0–100 km/h time of about 4.5 seconds.','keys':['seats','zero_to_100_s']}
   tradeoff={'label':'No seventh seat','text':'The six-seat captain-chair layout cannot take a seventh occupant.','keys':['seats','second_row_layout']}
 qual=['Current Kia AU named grade, working colour-configuration page and successful price endpoint establish a current official order enquiry path; no accepted individual order, allocation, delivery date or physical stock is verified.']
 if model=='EV9':qual.append('Current live grade listing and price are checked 14 October 2026. Brochure MY26 footer says inspections as of 12 February 2027; this conflicting future wording is not treated as current-sale disqualification or a publication date.')
 variants.append(dict(id=old['id'],model=model,trim=trim,modelYear=old['year'],drive=old['drive'],metadata={},metadataReason='Existing exact identity agrees with fresh current AU maker brochure and model page; no ID or MY change needed.',identitySourceKeys=[spec,page,colour],availability=dict(state='current_or_order_listed',buyerState='On sale now',sourceKeys=[page,m+'_build',pk,colour],orderStatus='listed_unconfirmed',stockStatus='unverified',qualifications=qual,reason='Current official maker catalogue, exact grade configurator and live price endpoint; order-listed availability, not physical stock.'),facts=facts,features=features,summary=dict(strength=strength,tradeoff=tradeoff)))
# Exact maker AC time is retained with its published 10–100% window, without conversion to 10–80%.
for variant in variants:
 ev6=variant['model']=='EV6';air=variant['trim']=='Air RWD'
 minutes=455 if ev6 else 420 if air else 545
 published='7h 35m' if ev6 else '7h' if air else '9h 5m'
 fact=dict(key='ac_charge_10_100_min',value=minutes,unit='min',label='AC 10–100% charging time',sourceKeys=[variant['model'].lower()+'-brochure'],grade='check',basis='AC 10–100% using an 11 kW charger; maker publishes approx. '+published,comparison='AC 10–100%',reason='Current exact AU brochure directly publishes this 10–100% time; only hours/minutes unit normalization is applied, no charging-window conversion.',condition='Maker test uses an 11 kW AC charger; supply, battery and ambient conditions affect actual time.',qualifications=['This 10–100% AC duration is separate from DC 10–80% and is not converted between charge windows.'])
 variant['facts'].append(fact)
 home=next(x for x in variant['features'] if x['criterion']=='home_charging')
 home.update(value=home['value']+'; approximately '+published+' for 10–100% using an 11 kW AC charger',keys=['ac_kw','ac_charge_10_100_min'],grade='check',conditions=fact['condition'])
# Canonical driveaway projection accepts this historical schema key for a supplementary current state estimate.
for variant in variants:
 estimate=next(f for f in variant['facts'] if f['key']=='driveaway_price_aud')
 supplemental=dict(estimate)
 supplemental.update(key='promotional_driveaway_aud',basisTag="Maker's NSW driveaway estimate",sourceKey='promotional_driveaway_aud',validUntil=None)
 supplemental['qualifications']=estimate['qualifications']+['Stored as supplementary driveaway price for canonical projection; no discount or time-limited promotion is claimed.']
 variant['facts'].append(supplemental)
# Additional independent charging review, carried transparently across current model years.
for source in sources:
 if source['key']=='ev9-driven-battery-peak':
  source.update(title='The Driven Australian Kia EV9 Earth road-trip review: battery-specific DC charging peaks',publisher='The Driven',source_type='secondary',published_date='2024-08-14',note='Charging section explicitly distinguishes 210 kW for the 99.8 kWh long-range battery and 230 kW for the 76.1 kWh EV9 Air. These are historical Australian specifications carried as Reported to current MY26; they are not newly maker-verified peaks.')
for variant in variants:
 if variant['model']=='EV9':
  air=variant['trim']=='Air RWD';gt=variant['trim']=='GT AWD'
  peak=next(f for f in variant['facts'] if f['key']=='dc_peak_kw')
  peak.update(value=230 if air else 210,grade='reported',basis='Australian review battery-specific vehicle DC maximum; carried from earlier EV9 specification',comparison='',sourceKeys=['ev9-driven-battery-peak']+(['ev9-carexpert-gt-review-web'] if gt else []),reason='The Driven explicitly maps 230 kW to 76.1 kWh Air and 210 kW to 99.8 kWh long-range EV9. Current MY26 maker pack identity matches; prior-year carry remains Reported. '+('GT is an explicitly labelled sibling carry, corroborated only at family level by current CarExpert/JATO 210 kW summary.' if gt else ''),qualifications=['Reported from The Driven, 14 August 2024; current MY26 version is a same-battery-family carry, not exact maker confirmation.','350 kW charging station figures and secondary editorial mislabels are not used as vehicle peak.']+(['GT did not exist in the 2024 source; 210 kW is an explicit 99.8 kWh sibling carry, not an exact-GT measurement.'] if gt else []),sourcePointer='Fast charging speeds, on the right charger; Table of key specifications > Maximum charging speed')
 for feature in variant['features']:
  if feature['value']=='Not available':feature['status']='unavailable'
result=dict(reviewedAt='2026-10-14',familyScope=['EV6','EV9'],sources=sources,variants=variants,warrantyHandling='Parent handles brand vehicle warranty, battery warranty and roadside terms.',familyClosure=dict(EV6=['Air RWD','GT-Line RWD','GT-Line AWD','GT AWD'],EV9=['Air RWD (7 seats)','Earth AWD (7 seats)','GT-Line AWD (7 seats)','GT AWD (6 seats)']),conflicts=[{'subject':'EV9 future footer','resolution':'Current live named order/configurator and successful price endpoint establish current listing. Preserve future inspection text in source and standing availability note; do not mark whole model future or downgrade every unrelated figure.'},{'subject':'EV9 GT cargo','resolution':'Maker shared 7/5-seat rows not relabelled. Exact current Australian GT review supplies Reported 333 L all rows in use and 828 L third row folded; method unspecified/unranked. 2393 L two-seats-up is direct maker.'},{'subject':'DC station power','resolution':'350 kW is station in maker PDFs. EV6 258 kW is Reported CarExpert/JATO family/sibling carry. EV9 230 kW Air and 210 kW 99.8 kWh versions use explicit Australian secondary battery mapping; current MY26 and GT sibling carry remains Reported.'},{'subject':'EV9 Earth tare/kerb','resolution':'Maker lists kerb 2552 and tare 2619 kg; keep source labels explicit, no conversion or silent correction.'}])
json.dump(result,open(P/'normalized-evidence.json','w'),indent=2,ensure_ascii=False)
print('Wrote',len(variants),'variants',len(sources),'sources',sum(len(v['facts']) for v in variants),'facts',sum(len(v['features']) for v in variants),'features')
