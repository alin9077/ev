import urllib.request,subprocess,hashlib,json,pathlib,re,html,concurrent.futures
p=pathlib.Path('/tmp/kia-research/ev6-ev9/sources'); idx=json.load(open(p.parent/'source-index.json'))
r=json.load(open('/tmp/kia-research/research-before.json'))
urls={s['id'].replace('r10_kia_',''):s['url'] for s in r['sources'] if ('r10_kia_ev6' in s['id'] or 'r10_kia_ev9' in s['id']) and any(a in s['id'] for a in ['_price','_build','_colour']) and 'guide' not in s['id']}
def fetch(item):
 key,url=item
 try:
  with urllib.request.urlopen(url,timeout=60) as r: content=r.read();headers=dict(r.headers);final=r.url
  ext='.pdf' if content.startswith(b'%PDF') else '.json' if content[:1] in [b'[',b'{'] else '.html';raw=p/(key+ext);raw.write_bytes(content)
  if ext=='.pdf':subprocess.run(['pdftotext','-layout',str(raw),str(p/(key+'.txt'))],check=True)
  else:(p/(key+'.txt')).write_text(html.unescape(re.sub('<[^>]+>',' ',content.decode())))
  return {'key':key,'url':url,'finalUrl':final,'path':str(raw),'textPath':str(p/(key+'.txt')),'sha256':hashlib.sha256(content).hexdigest(),'checkedAt':'2026-10-14','headers':headers}
 except Exception as e:return {'key':key,'url':url,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
 for item in ex.map(fetch,urls.items()):idx.append(item);print(item['key'],item.get('error','captured'),flush=True)
json.dump(idx,open(p.parent/'source-index.json','w'),indent=2)
