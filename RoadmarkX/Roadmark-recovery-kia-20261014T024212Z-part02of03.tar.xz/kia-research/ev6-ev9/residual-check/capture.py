import json,pathlib,urllib.request,hashlib,concurrent.futures,re,html
P=pathlib.Path('/tmp/kia-research/ev6-ev9/residual-check');R=json.load(open('/workspace/scratch/586427eef9f2/roadmark-104/data/kia-ev6-ev9-evidence-2026-10-10.json'))
json.dump(R['legacy_and_excluded'],open(P/'inherited-legacy.json','w'),indent=2)
urls=[s for s in R['sources'] if s['id'] in ['stock_ev6_air_my26_valley','stock_ev6_gtline_rwd_my26_vonbibra']]
print(urls,flush=True)
def f(x):
 u=x['url'];k=x['id']
 try:
  with urllib.request.urlopen(u,timeout=45) as r:c=r.read();d={'status':r.status,'url':u,'finalUrl':r.url,'headers':dict(r.headers),'checkedAt':'2026-10-14'}
  p=P/(k+'.html');p.write_bytes(c);t=P/(k+'.txt');t.write_text(html.unescape(re.sub('<[^>]+>',' ',c.decode())));d.update(key=k,file=str(p),textFile=str(t),bytes=len(c),sha256=hashlib.sha256(c).hexdigest());return d
 except Exception as e:return {'key':k,'url':u,'error':str(e),'checkedAt':'2026-10-14'}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:r=list(ex.map(f,urls))
json.dump(r,open(P/'source-index.json','w'),indent=2);print(r)
