import json,pathlib,re,hashlib
P=pathlib.Path('/tmp/kia-research/ev6-ev9/residual-check');p=P/'normalized-evidence.json';d=json.load(open(p))
fields={'title','note','value','basis','comparison','reason','qualifications','condition','conditions','label','text','metadataReason','buyerState','notes','familyScope','warrantyHandling','result','conclusion','configuration','summaryConditions','conflicts','originalBasis'}
def clean(s):
 s=re.sub(r'(?<=[a-z])(?=\d)', ' ',s)
 s=re.sub(r'(?<=\d)(?=kWh\b|kW\b|km\b|mm\b|L\b|m\b|s\b|percent\b|October)', ' ',s)
 s=re.sub(r'(?<=[a-z])(?=MY\d)', ' ',s)
 s=re.sub(r'(MY\d{2})(?=[A-Z])',r'\1 ',s)
 s=re.sub(r'([;,])(?=\S)',r'\1 ',s)
 for a,b in {'HTTP403':'HTTP 403','HTTP500':'HTTP 500','exactAir':'exact Air','beforeORC':'before ORC','DealerNew':'Dealer New','NewStock':'New Stock','dealerDA':'dealer driveaway ','Air490':'Air 490','all17':'all 17','No350':'No 350','MY26-specific':'MY26-specific','finiteLeadClosure':'the finite lead closure'}.items():s=s.replace(a,b)
 return s
# Transform prose-only fields; IDs, source keys, URLs, filenames, hashes and locator pointers remain byte-identical.
def walk(x,field=None):
 if isinstance(x,dict):return {k:walk(v,k) for k,v in x.items()}
 if isinstance(x,list):return [walk(v,field) for v in x]
 if isinstance(x,str) and field in fields:return clean(x)
 return x
z=walk(d);p.write_text(json.dumps(z,indent=2,ensure_ascii=False)+'\n')
(P/'normalized-source-index.json').write_text(json.dumps({'checkedAt':'2026-10-14','sources':z['sources']},indent=2,ensure_ascii=False)+'\n')
v=json.load(open(P/'supplement-validation.json'));v['fileSha256']=hashlib.sha256(p.read_bytes()).hexdigest();v['readableStringsNormalized']=True;(P/'supplement-validation.json').write_text(json.dumps(v,indent=2)+'\n');print(v)
