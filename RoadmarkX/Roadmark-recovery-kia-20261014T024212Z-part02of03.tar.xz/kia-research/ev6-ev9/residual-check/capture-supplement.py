import json,pathlib,urllib.request,hashlib,concurrent.futures
from html.parser import HTMLParser
P=pathlib.Path('/tmp/kia-research/ev6-ev9/residual-check')
class Parser(HTMLParser):
 def __init__(self):super().__init__();self.skip=0;self.parts=[]
 def handle_starttag(self,t,a):
  if t in ('script','style'):self.skip+=1
 def handle_endtag(self,t):
  if t in ('script','style'):self.skip=max(0,self.skip-1)
 def handle_data(self,d):
  if not self.skip and d.strip():self.parts.append(d.strip())
def fetch(x):
 k=x['key'];u=x['url'];out=dict(x,checkedAt='2026-10-14')
 try:
  with urllib.request.urlopen(u,timeout=35) as r:c=r.read();out.update(status=r.status,finalUrl=r.url,cacheDate=r.headers.get('Date'),age=r.headers.get('Age'))
  p=P/(k+'.html');p.write_bytes(c);v=Parser();v.feed(c.decode(errors='replace'));t=P/(k+'.txt');t.write_text('\n'.join(v.parts));out.update(file=str(p),textFile=str(t),sha256=hashlib.sha256(c).hexdigest(),bytes=len(c))
 except Exception as e:out['error']=str(e)
 return out
R=json.load(open('/workspace/scratch/586427eef9f2/roadmark-104/data/kia-ev6-ev9-evidence-2026-10-10.json'))
a=[dict(key='my26-'+s['source_id'],url=s['url'],inherited=s) for s in R['rejected_stock_evidence'][:8]]
a +=[{'key':'ev6-my26-carsguide-air','url':'https://www.carsguide.com.au/car/14931368/kia/ev6/suv'},{'key':'ev6-my26-carsguide-gtlrwd','url':'https://www.carsguide.com.au/car/14931371/kia/ev6/suv'},{'key':'ev6-my26-carexpert-news','url':'https://www.carexpert.com.au/car-news/2026-kia-ev6-price-and-specs'},{'key':'ev6-my26-offer-search','url':'https://www.kia.com/au/shopping-tools/offers/car-offers.html'}]
with concurrent.futures.ThreadPoolExecutor(max_workers=12) as ex:r=list(ex.map(fetch,a))
json.dump(r,open(P/'supplement-capture-index.json','w'),indent=2)
for x in r:print(x['key'],x.get('status',x.get('error')),x.get('finalUrl'))
