import json,pathlib,copy
R=pathlib.Path('/tmp/kia-research');out={'reviewedAt':'2026-10-14','sources':[],'variants':[],'familyNotes':{}}
for folder in ['ev3-ev4','ev5-niro','ev6-ev9','ev6-ev9/residual-check']:
 if not (R/folder/'normalized-evidence.json').exists():continue
 f=R/folder/'normalized-evidence.json';p=json.load(open(f));out['sources']+=p['sources'];out['variants']+=p['variants'];out['familyNotes'][folder]={k:v for k,v in p.items() if k not in ['sources','variants']}
# Parent/independent review: a maker measurement stays Confirmed on its explicit method.
# Preserve station/SOC/supply/legal footnotes without treating generic lab/use caveats as options.
reviewed_basis_keys={'dc_charge_time_min','dc_10_80_at_50kw_minutes','ac_10_100_min','ac_charge_time_min','ac_charge_10_100_min','towing_braked_kg','towing_unbraked_kg','towball_download_kg'}
for row in out['variants']:
 for f in row['facts']:
  if f['key'] in reviewed_basis_keys and f.get('grade')=='check':
   if f.get('condition'):f.setdefault('qualifications',[]).append(f.pop('condition'))
   f['grade']='confirmed'
   f['reason']=f.get('reason','')+' The maker figure is Confirmed on its explicitly stated measurement/supply basis; generic laboratory or approved-use qualifications are retained rather than treated as a separate configuration.'
 for f in row.get('features',[]):
  if f['criterion']=='home_charging' and f.get('grade')=='check':
   f['grade']='confirmed';f['reason']=f.get('reason','')+' Published AC timing and supply basis are retained; no charging duration is estimated.'
assert len(out['variants'])==len(set(x['id'] for x in out['variants']))
assert len(out['sources'])==len(set(x['key'] for x in out['sources']))
(R/'normalized-evidence.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(len(out['variants']),'versions',len(out['sources']),'sources')
