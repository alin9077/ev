import pathlib,json,hashlib
R=pathlib.Path('/tmp/kia-research');p=json.load(open(R/'kia-2026-10-14.json'));rows=[]
for s in p['sources']:
 path=R/s['capture_locator'];actual=hashlib.sha256(path.read_bytes()).hexdigest();assert actual==s['capture_sha256'],s['id'];row={'sourceId':s['id'],'url':s['url'],'title':s['title'],'checkedAt':s['accessed_date'],'file':s['capture_locator'],'bytes':path.stat().st_size,'sha256':actual}
 if s.get('capture_text_locator'):
  tp=R/s['capture_text_locator'];th=hashlib.sha256(tp.read_bytes()).hexdigest();assert th==s['capture_text_sha256'];row.update(textFile=s['capture_text_locator'],textSha256=th)
 rows.append(row)
artifacts=[]
for f in ['before.json','research-before.json','features-before.json','new-feature-before.json','normalized-evidence.json','effective-facts.json','kia-2026-10-14.json','kia-reconciliation-2026-10-14.json','brand-model-list-reconciliation.json','source-index.json','staged-report.json','stage-validation.log','REVIEW.md']:
 path=R/f
 if path.exists():artifacts.append({'file':f,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(R/'evidence-manifest.json').write_text(json.dumps({'checkedAt':'2026-10-14','sources':rows,'artifacts':artifacts,'scope':'Captured third-party documents remain outside delivered working repository; only dated source records and packet data are candidates for registration.'},indent=2)+'\n')
print('Verified',len(rows),'source capture hashes and',len(artifacts),'artifact hashes')
