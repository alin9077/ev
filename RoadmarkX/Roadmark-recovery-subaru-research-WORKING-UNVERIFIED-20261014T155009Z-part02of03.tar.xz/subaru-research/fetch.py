import subprocess,json,hashlib
from lxml import html
from pathlib import Path
p=Path('/tmp/subaru-research')
urls={'solterra-specs':'https://www.subaru.com.au/solterra/specs','solterra-model':'https://www.subaru.com.au/solterra','trailseeker-specs':'https://www.subaru.com.au/trailseeker/2026/specs','trailseeker-model':'https://www.subaru.com.au/trailseeker/2026','uncharted-specs':'https://www.subaru.com.au/uncharted/specs','uncharted-model':'https://www.subaru.com.au/uncharted/2026','warranty':'https://www.subaru.com.au/owners/warranty','uncharted-release':'https://www.subaru.com.au/news/the-all-new-all-electric-subaru-uncharted-sev-lands-on-australian-roads','trailseeker-release':'https://www.subaru.com.au/news/all-new-trailseeker-sev'}
meta=[]
for key,url in urls.items():
 raw=subprocess.check_output(['curl','-L','--fail','--max-time','60','-sS',url]); s=html.fromstring(raw)
 for el in s.xpath('//script|//style|//noscript|//form|//input'):el.drop_tree()
 for el in s.iter():
  for attr in list(el.attrib):
   if attr.lower().startswith(('data-','on')): del el.attrib[attr]
 out=html.tostring(s,encoding='unicode'); text='\n'.join(t.strip() for t in s.xpath('//text()') if t.strip())
 (p/(key+'.html')).write_text(out)
 (p/(key+'.txt')).write_text('URL: '+url+'\nHTTP: '+str(200)+'\nChecked: 2026-10-15 Australia/Sydney\n'+text)
 (p/(key+'-links.json')).write_text(json.dumps([{'text':a.text_content().strip(),'href':a.get('href')} for a in s.xpath('//a[@href]')],indent=2))
 meta.append({'key':key,'requestedUrl':url,'finalUrl':url,'status':200,'rawSha256':hashlib.sha256(raw).hexdigest(),'rawRetained':False,'sanitization':'Removed scripts/styles/noscript/forms/input and event/data attributes; no response headers retained','bytes':len(raw)})
 print(key,200,url,len(raw),len(text))
(p/'fetch-metadata.json').write_text(json.dumps(meta,indent=2))
