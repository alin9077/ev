import pathlib,json,hashlib,datetime
R=pathlib.Path('/tmp/subaru-research');repo=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104');buffer=bytearray(1024*1024);v=memoryview(buffer)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while n:=f.readinto(buffer):h.update(v[:n])
 return h.hexdigest()
rows=[]
for root in ['data','src','scripts','tests']:
 for p in sorted((repo/root).rglob('*')):
  if p.is_file() and p.suffix in ['.json','.ts','.tsx','.js','.mjs','.cjs']:rows.append(dict(file=str(p.relative_to(repo)),sha256=sha(p),bytes=p.stat().st_size))
for name in ['package.json','pnpm-lock.yaml','tsconfig.json']:
 p=repo/name
 if p.exists():rows.append(dict(file=name,sha256=sha(p),bytes=p.stat().st_size))
(R/'fresh-capture-inputs.json').write_text(json.dumps(dict(createdAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),mode='Exact source/code inputs verified before and after fresh snapshot capture',sourceCode=rows),indent=2));print(len(rows),'source/code inputs')
