import json,subprocess,hashlib
from pathlib import Path
from lxml import html
R=Path('/tmp/subaru-research'); urls={'solterra-specs':'https://www.subaru.com.au/solterra/specs','trailseeker-specs':'https://www.subaru.com.au/trailseeker/2026/specs','uncharted-specs':'https://www.subaru.com.au/uncharted/specs','solterra-model':'https://www.subaru.com.au/solterra','uncharted-model':'https://www.subaru.com.au/uncharted/2026'}
for key,url in urls.items():
 raw=subprocess.check_output(['curl','-LsS','--fail','--max-time','30',url]); doc=html.fromstring(raw)
 scripts=doc.xpath('//script')
 print(key,[(s.get('id'),s.get('type'),len(s.text or ''),(s.text or '')[:60]) for s in scripts if s.text])
 for s in scripts:
  if s.get('id')=='__NEXT_DATA__':
   data=json.loads(s.text);(R/(key+'-data.json')).write_text(json.dumps(data,indent=2)); print('saved',key,len(s.text))
