import sys,subprocess,time,resource,json,pathlib
name=sys.argv[1];args=sys.argv[2:];R=pathlib.Path('/tmp/subaru-research');t=time.time()
with (R/(name+'.log')).open('w') as f:p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
u=resource.getrusage(resource.RUSAGE_CHILDREN);r=dict(operation=name,exitCode=p.returncode,elapsedSeconds=time.time()-t,maxRssKiB=u.ru_maxrss,userSeconds=u.ru_utime,systemSeconds=u.ru_stime,command=args,meaning='RUSAGE_CHILDREN peak resident set for this serialized invocation; negative exit retains signal number; cause not inferred.')
(R/(name+'-resource-usage.json')).write_text(json.dumps(r,indent=2));(R/(name+'.exit')).write_text(str(p.returncode)+'\n');print(json.dumps(r));sys.exit(p.returncode)
