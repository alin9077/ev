/** Snapshot-backed derivation, never represented as fresh catalogue hydration. */
import fs from 'node:fs';
import crypto from 'node:crypto';
import {StringDecoder} from 'node:string_decoder';
import assert from 'node:assert/strict';
import {readReplaySnapshot,incrementalDigest} from './read-replay-snapshot.ts';
import {prepareBrandResearch,applyBrandUpdates} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-updates.ts';
import {effectiveFeatures,pack} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/data.ts';
import {brandUpdatePackets} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-update-registry.ts';
import {compiledSource} from '/workspace/scratch/586427eef9f2/roadmark-104/tests/helpers/compiled-source.ts';
import {buildCoverageReport} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/reports.ts';
import {storePortablePacks,hydratePortablePacks} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/portable-packs.ts';
const R='/tmp/subaru-research/',P='/tmp/polestar-research/',O=R+'derived-before-v1/';
assert(!fs.existsSync(O+'replay-snapshot-index.json'),'Never overwrite a completed derived baseline');
assert(fs.existsSync(R+'derivation-input-verification.json'),'Run serialized input/code proof before derivation');
const inputVerification=JSON.parse(fs.readFileSync(R+'derivation-input-verification.json','utf8'));
assert.equal(inputVerification.status,'passed');
const hash=(v:any)=>{const h=crypto.createHash('sha256');incrementalDigest(v,h);return h.digest('hex')};
const fileHash=(p:string)=>{const h=crypto.createHash('sha256'),b=Buffer.alloc(1024*1024),fd=fs.openSync(p,'r');try{let n;while((n=fs.readSync(fd,b,0,b.length,null))>0)h.update(b.subarray(0,n));}finally{fs.closeSync(fd)}return h.digest('hex')};
for(const row of inputVerification.executionInputs)assert.equal(fileHash(row.path),row.sha256,'Verified execution input changed: '+row.path);
fs.mkdirSync(O+'replay-snapshot',{recursive:true});
const index:any={research:{},cars:'replay-snapshot/cars.jsonl'};
const counts:Record<string,number>={},researchEquality:any[]=[],carHashes:any[]=[];
const writeRows=(file:string,rows:any[])=>{const fd=fs.openSync(O+file,'w');try{for(const row of rows)fs.writeSync(fd,JSON.stringify(row)+'\n');}finally{fs.closeSync(fd)}counts[file]=rows.length};
const compareRows=(file:string,rows:any[])=>{const fd=fs.openSync(file,'r'),b=Buffer.alloc(65536),decoder=new StringDecoder('utf8');let carry='',row=0,n;try{while((n=fs.readSync(fd,b,0,b.length,null))>0){carry+=decoder.write(b.subarray(0,n));let pos;while((pos=carry.indexOf('\n'))>=0){const line=carry.slice(0,pos);carry=carry.slice(pos+1);assert(row<rows.length,'Extra original row: '+file);assert.equal(line,JSON.stringify(rows[row++]),'Exact current research row mismatch: '+file)}}carry+=decoder.end();assert.equal(carry,'','Incomplete original research line');assert.equal(row,rows.length,'Complete original research row count');}finally{fs.closeSync(fd)}return row};
console.log('Loading immutable complete pre-Polestar snapshot, not calling catalogue()');
let prior:any=readReplaySnapshot(P);
assert.equal(prior.before.length,395);
const beforeDigest=hash(prior);
const packet=JSON.parse(fs.readFileSync(P+'polestar-2026-10-14.json','utf8'));
assert.deepEqual(brandUpdatePackets.at(-1),packet,'Only final approved Polestar packet is appended');
const data=prepareBrandResearch(prior.rd,[packet]);
const cars=applyBrandUpdates(prior.before,data,[packet]);
assert.equal(hash(prior),beforeDigest,'Prior complete snapshot objects remain immutable');
assert.equal(cars.length,397);
const previous=new Map(prior.before.map((c:any)=>[c.id,c]));
assert.equal(new Set(cars.map((c:any)=>c.id)).size,cars.length,'No duplicate current identities');
for(const car of cars){const old:any=previous.get(car.id);const before=old?hash(old):null,after=hash(car);if(car.brand!=='Polestar'){assert(old,'Only Polestar may add a version');assert.equal(after,before,'Unchanged full non-Polestar car: '+car.id)}carHashes.push({id:car.id,brand:car.brand,before,after,unchanged:before===after});}
const currentResearch=R+'capture-phased640-original/replay-snapshot/';
const expectedFields=fs.readdirSync(currentResearch).filter(f=>/^research-.+\.jsonl$/.test(f)).map(f=>f.slice(9,-6)).sort();
assert.equal(expectedFields.length,14);
assert.deepEqual(Object.keys(data).sort(),expectedFields,'Exact full current research field set');
assert.equal(new Set(Object.keys(data)).size,expectedFields.length);
for(const [key,value]of Object.entries(data)){
 const rows=Array.isArray(value)?value:[value],file='replay-snapshot/research-'+key+'.jsonl';
 const count=compareRows(currentResearch+'research-'+key+'.jsonl',rows);researchEquality.push({key,rows:count,exactCurrentRowEquality:true});writeRows(file,rows);index.research[key]={file,array:Array.isArray(value)};console.log('Verified and wrote all research rows',key,count);global.gc?.();
}
writeRows(index.cars,cars);
fs.writeFileSync(O+'per-car-hashes.json',JSON.stringify(carHashes,null,2));
prior=null;previous.clear();global.gc?.();
const tier1=(c:any)=>!c.vehicleClass||['passenger','ute'].includes(c.vehicleClass);
const subaru=cars.filter((c:any)=>c.brand==='Subaru'&&tier1(c));
const originals:Record<string,any>={
 'subaru-live-before.json':subaru,
 'subaru-source-before.json':data.sources,
 'subaru-feature-before.json':subaru.flatMap((c:any)=>effectiveFeatures(c,data)),
 'subaru-models-before.json':data.models.filter((m:any)=>m.brand==='Subaru'),
 'subaru-variants-before.json':data.variants.filter((v:any)=>v.brand==='Subaru'),
};
for(const[name,value]of Object.entries(originals)){const text=JSON.stringify(value,null,2);assert.equal(text,fs.readFileSync(R+'capture-attempt640-original/'+name,'utf8'),'All original completed Subaru file bytes: '+name);fs.writeFileSync(O+name,text)}
assert.equal(subaru.length,9);
console.log('All five original Subaru files byte-identical; checking actual final registered Polestar packs');
const approvedPacks=JSON.parse(fs.readFileSync(P+'staged-packs.json','utf8'));
const actualPacks:Record<string,any>={};
for(const car of cars.filter((c:any)=>c.brand==='Polestar'&&tier1(c))){const actual=pack(car.id,{data,cars});assert.deepEqual(JSON.parse(JSON.stringify(actual)),approvedPacks[car.id],'Actual final registered Polestar pack '+car.id);actualPacks[car.id]=actual;}
assert.deepEqual(Object.keys(actualPacks).sort(),Object.keys(approvedPacks).sort());
assert.equal(Object.keys(actualPacks).length,14);
assert.deepEqual(hydratePortablePacks(storePortablePacks(actualPacks),data.sources),actualPacks,'Derived current Polestar portable equality');
assert.deepEqual(JSON.parse(JSON.stringify(cars.filter((c:any)=>c.brand==='Polestar'&&tier1(c)))),JSON.parse(fs.readFileSync(P+'after.json','utf8')),'All approved actual Polestar car fields');
console.log('All 14 actual packs and portable equality passed; building date-aligned reports');
const reportLoader=compiledSource('scripts/reporting/load.ts',{'../../src/lib/data':{
 research:()=>data,catalogue:()=>cars,loadCatalogueSnapshot:()=>({data,cars}),catalogueSnapshot:()=>({data,cars}),effectiveFeatures,
}}) as any;
const input=reportLoader.loadReportInput();
assert.equal(input.cars,cars);assert.equal(input.sources,data.sources);
const report14=buildCoverageReport(input,'2026-10-14');
assert.deepEqual(JSON.parse(JSON.stringify(report14)),JSON.parse(fs.readFileSync(P+'staged-report.json','utf8')),'Approved Polestar 14 October report exact equality');
const report15=buildCoverageReport(input,'2026-10-15');
assert.deepEqual(JSON.parse(JSON.stringify(report15)),JSON.parse(fs.readFileSync('/workspace/scratch/586427eef9f2/roadmark-104-qa/polestar-sequential-checks/coverage.stdout','utf8')),'Integrated current 15 October report exact equality');
fs.writeFileSync(O+'report-asof-2026-10-14.json',JSON.stringify(report14,null,2));
fs.writeFileSync(O+'report-asof-2026-10-15.json',JSON.stringify(report15,null,2));
for(const row of inputVerification.executionInputs)assert.equal(fileHash(row.path),row.sha256,'Verified execution input changed during derivation: '+row.path);
fs.writeFileSync(O+'replay-snapshot-index.json',JSON.stringify(index,null,2));
fs.writeFileSync(O+'derivation-completeness.json',JSON.stringify({status:'passed',mode:'Snapshot-backed derivation from immutable complete pre-Polestar snapshot through only final registered approved Polestar packet; not fresh catalogue hydration',date:'2026-10-15',timeZone:'Australia/Sydney',priorCars:395,currentCars:cars.length,subaruCars:subaru.length,counts,researchEquality,allCurrentResearchFieldsEqual:true,allNonPolestarCarsUnchanged:true,allFiveOriginalSubaruFilesByteEqual:true,actualPolestarPacksEqual:14,actualPolestarPortableExact:true,approvedPolestarFullCarsEqual:true,reportParityDates:['2026-10-14','2026-10-15'],priorSnapshotObjectsImmutable:true,sourceAndInputVerification:'../derivation-input-verification.json',independentReviewRequiredBeforeCanonicalFixture:true,rootFinalFreshValidationRemainsSeparate:true},null,2));
console.log('Snapshot-backed derivation complete. Independent chain approval required before use as Subaru canonical baseline.');
