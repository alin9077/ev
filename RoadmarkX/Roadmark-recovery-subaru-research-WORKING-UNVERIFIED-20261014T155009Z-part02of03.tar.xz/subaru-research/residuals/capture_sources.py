import urllib.request, hashlib, json, re, html, pathlib, datetime
from html.parser import HTMLParser
from concurrent.futures import ThreadPoolExecutor
ROOT=pathlib.Path('/tmp/subaru-research/residuals')
SOURCES=[
 ('inchcape_new_stock','dealer_reported','https://www.inchcapeautomotive.com.au/stock/new-cars/Subaru/Solterra/'),
 ('inchcape_2025_awd','dealer_reported','https://www.inchcapeautomotive.com.au/new-cars/for-sale/subaru/solterra/2025/awd/e1-1-my26-awd/3993769/'),
 ('inchcape_2025_touring','dealer_reported','https://www.inchcapeautomotive.com.au/new-cars/for-sale/subaru/solterra/2025/awd-touring/e1-1-my26-awd/3884767/'),
 ('reynella_old_touring','dealer_reported','https://www.reynellasubaru.com.au/stock-specials'),
 ('southern_vales_old_awd','dealer_reported','https://www.southernvalesnissan.com.au/stock-specials'),
 ('suttons_old_touring','dealer_reported','https://www.suttonsarncliffenissan.com.au/inventory/cars/t0s8ivp0n3n0/2025-subaru-solterra-awd-touring/UA15868'),
 ('subaru_au_launch_2024','manufacturer_reported','https://www.subaru.com.au/news/all-new-all-electric-subaru-solterra-suv-arrives-in-australia'),
 ('subaru_au_three_models','manufacturer_reported','https://www.subaru.com.au/news/the-all-new-all-electric-subaru-uncharted-sev-lands-on-australian-roads'),
 ('subaru_us_getaway','manufacturer_overseas_reported','https://www.subaru.com/vehicles/getaway/2028.html'),
 ('subaru_au_showroom','manufacturer_reported','https://www.subaru.com.au/showroom'),
 ('carsales_new_stock','aggregator_reported','https://www.carsales.com.au/cars/dealer/new/subaru/solterra/'),
 ('autotrader_my24','aggregator_reported','https://www.autotrader.com.au/for-sale/subaru/solterra/year-2024')
]
class Visible(HTMLParser):
 def __init__(self): super().__init__(); self.skip=0; self.parts=[]; self.links=[]
 def handle_starttag(self,tag,attrs):
  if tag in ('script','style','svg','noscript','iframe','template'): self.skip+=1
  if self.skip:return
  if tag=='a':
   u=dict(attrs).get('href','')
   if '/solterra/' in u.lower() or '/getaway/' in u.lower(): self.links.append(u)
  if tag in ('p','div','br','li','h1','h2','h3','h4','h5','h6','tr','td'):self.parts.append('\n')
 def handle_endtag(self,tag):
  if tag in ('script','style','svg','noscript','iframe','template') and self.skip:self.skip-=1
  if not self.skip and tag in ('p','div','li','h1','h2','h3','h4','h5','h6','tr'):self.parts.append('\n')
 def handle_data(self,data):
  if not self.skip:self.parts.append(data)
def capture(row):
 name,label,url=row
 out={'source_id':name,'source_origin':label,'url':url,'checked_local_date':'2026-10-15','checked_timezone':'Australia/Sydney','retrieved_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'published_date':None}
 try:
  r=urllib.request.urlopen(url,timeout=35); raw=r.read(); final=r.url
  out.update(http_status=r.status,final_url=final,raw_original_excluded_sha256=hashlib.sha256(raw).hexdigest(),raw_original_bytes=len(raw),raw_original_retained=False)
  p=Visible();p.feed(raw.decode('utf-8','replace'))
  lines=[re.sub(r'\s+',' ',v).strip() for v in ''.join(p.parts).split('\n')]; lines=[v for v in lines if v]
  # Plain visible public page text only: no original markup, attributes, hidden fields, scripts, headers or cookies.
  out['visible_lines']=lines;out['public_solterra_links']=sorted(set(x for x in p.links if not re.search(r'token|auth|csrf|session|signature',x,re.I)))
  safe='<!doctype html><html><head><meta charset="utf-8"><title>'+html.escape(name)+' sanitized evidence</title></head><body>\n'+''.join('<p>'+html.escape(s)+'</p>\n' for s in lines)+'\n</body></html>'
  (ROOT/(name+'.sanitized.html')).write_text(safe)
  out['sanitized_file']=name+'.sanitized.html'
 except Exception as e:out['error']=type(e).__name__+': '+str(e)
 return out
with ThreadPoolExecutor(max_workers=6) as ex: rows=list(ex.map(capture,SOURCES))
(ROOT/'source_captures.json').write_text(json.dumps(rows,indent=2))
for row in rows:
 print(row['source_id'],row.get('http_status'),row.get('raw_original_bytes'),row.get('error',''))
 if row['source_id'].startswith('inchcape'):
  print('\n'.join(row.get('public_solterra_links',[])))
