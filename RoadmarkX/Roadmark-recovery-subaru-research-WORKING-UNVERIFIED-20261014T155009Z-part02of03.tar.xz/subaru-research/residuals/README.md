# Subaru residual-new and additional-family research

Checked: **15 October 2026, Australia/Sydney** (UTC 14 October). Research only, Roadmark M1.

## Result

No MY23/MY24/MY25 Australian Solterra was verified as a live **New** dealer-stock advertisement. This is an **unresolved census**, not proof that old stock is exhausted.

Keep these four exact candidate versions separately unresolved for current New availability:
- Solterra E1-1 MY24 AWD
- Solterra E1-1 MY24 AWD Touring
- Solterra E1-1 MY25 AWD
- Solterra E1-1 MY25 AWD Touring

No distinct Australian MY23 version was substantiated. A 2023-build listing explicitly states MY24 (November 2023 build; December 2023 compliance). Do not infer MY23 from calendar/build year.

## Critical false positives

Live Inchcape New advertisements with a **2025** title are actually **MY26**. Two detailed examples:
- Waitara AWD SU017511B: AUD $67,500 drive-away; 16 km; explicit MY26; display vehicle only
- Werribee AWD Touring SU015688D: AUD $71,990 drive-away; 12 km; explicit MY26; display vehicle only

Both also contain inconsistent copied technical prose (160kW/485km alongside 252kW/74.7kWh). Use explicit MY/title/identity, not boilerplate specifications, for matching. The current New stock page returned 16 results, of which the 12 visible detail links all identify MY26. Four undisplayed results and the wider dealer network remain outside this captured subset.

MY24 AWD examples found were Used; MY24 Touring examples Demo/Used; MY25 AWD/Touring examples Used/Demo. Old carsales MY25 New-car-to-order entries are indexed about 1.3 years ago, lack verified current physical stock and carry indicative prices. They cannot establish current residual-new availability.

## Other BEV families

Subaru Australia's dated 4 August 2026 Uncharted launch release explicitly identifies a three-model local SEV range: Solterra, Trailseeker and Uncharted. No fourth officially available Australian BEV family was verified.

Getaway is `manufacturer_overseas_reported`: Subaru Corporation's 2 April 2026 release calls it the fourth global BEV, a U.S. model, scheduled for U.S. introduction in late 2026. That release calls it 2027; the current Subaru of America page redirects to 2028 and says no MSRP is available. Neither establishes Australian availability. Preserve this model-year conflict rather than importing it into an Australian record.

E-Outback evidence is also `manufacturer_overseas_reported`; Subaru Europe explicitly positions its name in the European market. No independent Australian E-Outback offering was found.

## Evidence and provenance

`findings.json` contains compact factual extracts, exact source URLs, source-origin labels, source dates where published, crawl-age caveats, precise price bases and per-candidate outcomes. `source_captures.json` and `additional_captures.json` contain HTTP status, final URLs, raw-response SHA-256 hashes, and visible text from the live source captures. Corresponding `.sanitized.html` files are rebuilt from public visible text only.

No original HTML, response headers, cookies, CSRF fields, script/runtime capabilities, authentication information or browser screenshots are retained. Raw HTTP bytes were hashed in memory and not written as files. A preliminary in-memory connectivity probe was not made into a research file. Failed HTTP requests with no downloaded body have no raw-body hash. Empty or incomplete sanitized captures are explicitly not availability evidence.

`inventory.json` explicitly inventories every created research file, including capture code and this report, with sizes and hashes where not self-referential. Nothing was written outside `/tmp/subaru-research/residuals`; no repository edits, catalogue loading, tests, scans or compression were performed.

## MY26 residual-stock recheck (expanded assignment)

The parent established current official model-year pages as MY27 and asked for separate MY26 residual evidence. `my26_findings.json` and `my26_rechecks.json` record the result:

- MY26 Solterra AWD: live New advert, Berwick SU030584D, AUD $68,363 drive-away, 10km
- MY26 Solterra AWD Touring: live New advert, Eastern Subaru 30633, AUD $73,888 drive-away, odometer not stated
- MY26 Trailseeker AWD: live New advert, Port Lincoln S525487, AUD $68,995 drive-away, odometer not stated
- MY26 Trailseeker AWD Touring: live New advert, Gibbons S203186, AUD $78,416 drive-away, 20km
- MY26 Uncharted AWD with panoramic glass roof: live New advert, Glen Waverley SU017700A, AUD $66,249 drive-away, 7km; roof explicitly fitted in dealer description
- MY26 Uncharted AWD base lead: live New advert, Melbourne City SU021027F, AUD $65,594 drive-away, 13km; absence of panoramic roof is not explicit in text, so exact base-roof matching remains qualified
- Bundoora MY26/2025-build backup SU008255B redirects to generic inventory and cannot be retained as a current specific stock advert

None of the five positive existing-row advertisements says display vehicle only. They remain advertisements, not promises of physical stock or delivery. All dealer publication dates are unstated. Raw responses were fetched on the checked date; all successful detail pages were HTTP 200 without a generic redirect.

Vehicle photographs for the base Uncharted lead were downloaded from public dealer-CDN image URLs embedded in that exact listing to inspect roof configuration. These are dealer photographs, not browser screenshots. Their exact URLs and SHA-256s are retained in `uncharted_base_photo_sources.json`; no browsing/authentication/capability data was retained.

Photo review covered all 15 dealer images for base Uncharted SU021027F. None supplies an unambiguous overhead roof or headliner view; the text/photographs therefore do not close the exact non-panoramic configuration question.
