import subprocess,json,re,hashlib
from pathlib import Path
from lxml import html
R=Path('/tmp/subaru-research'); meta=[]
urls={'solterra-my26-specs':'https://www.subaru.com.au/solterra/2026/specs','trailseeker-current-specs':'https://www.subaru.com.au/trailseeker/specs','uncharted-my26-specs':'https://www.subaru.com.au/uncharted/2026/specs','new-vehicle-warranty':'https://www.subaru.com.au/new-vehicle-warranty','roadside':'https://www.subaru.com.au/roadside-assistance','offers':'https://www.subaru.com.au/offers','price':'https://www.subaru.com.au/vehicle-pricing'}
for key,url in urls.items():
 try: raw=subprocess.check_output(['curl','-LsS','--fail','--max-time','35',url])
 except subprocess.CalledProcessError as e:
  meta.append({'url':url,'errorExit':e.returncode});continue
 doc=html.fromstring(raw); data=[]
 text='\n'.join(t.strip() for t in doc.xpath('//body//text()[not(parent::script) and not(parent::style)]') if t.strip()); (R/(key+'-body.txt')).write_text('URL: '+url+'\nChecked: 2026-10-15 Australia/Sydney\n'+text)
 for s in doc.xpath('//script'):
  t=s.text or ''; m=re.search(r'\bspecs\s*=\s*',t)
  if m:
   obj,_=json.JSONDecoder().raw_decode(t[m.end():]);data.append({'type':'specs','data':obj});continue
  m=re.match(r'ReactDOM\.(?:render|hydrate)\(React.createElement\((\w+),\s*',t)
  if m and m[1] not in ['MegaNav','ClientFooter','SubscribeModal','SubscribePopup']:
   obj,_=json.JSONDecoder().raw_decode(t[m.end():]);data.append({'type':m[1],'data':obj})
 (R/(key+'-public-data.json')).write_text(json.dumps({'url':url,'checkedAt':'2026-10-15','timeZone':'Australia/Sydney','data':data},indent=2))
 meta.append({'file':key+'-public-data.json','url':url,'rawResponseSha256':hashlib.sha256(raw).hexdigest(),'rawRetained':False,'sanitization':'Only JSON public model/specification components; tracking, authentication and runtime scripts excluded; no headers retained'})
 print(key,len(data),flush=True)
(R/'public-data-extraction-manifest-v2.json').write_text(json.dumps(meta,indent=2))
