import subprocess,json,re,hashlib
from pathlib import Path
from lxml import html
R=Path('/tmp/subaru-research'); meta=[]
urls={'solterra-specs':'https://www.subaru.com.au/solterra/specs','trailseeker-specs':'https://www.subaru.com.au/trailseeker/2026/specs','uncharted-specs':'https://www.subaru.com.au/uncharted/specs','solterra-model':'https://www.subaru.com.au/solterra','trailseeker-model':'https://www.subaru.com.au/trailseeker/2026','uncharted-model':'https://www.subaru.com.au/uncharted/2026','uncharted-release':'https://www.subaru.com.au/news/the-all-new-all-electric-subaru-uncharted-sev-lands-on-australian-roads','trailseeker-release':'https://www.subaru.com.au/news/all-new-trailseeker-sev'}
for key,url in urls.items():
 raw=subprocess.check_output(['curl','-LsS','--fail','--max-time','35',url]); doc=html.fromstring(raw); data=[]
 for s in doc.xpath('//script'):
  t=s.text or ''; m=re.search(r'\bspecs\s*=\s*',t)
  if m:
   obj,_=json.JSONDecoder().raw_decode(t[m.end():]);data.append({'type':'specs','data':obj});continue
  m=re.match(r'ReactDOM\.(?:render|hydrate)\(React.createElement\((\w+),\s*',t)
  if m and m[1] not in ['MegaNav','ClientFooter','SubscribeModal','SubscribePopup']:
   obj,_=json.JSONDecoder().raw_decode(t[m.end():]);data.append({'type':m[1],'data':obj})
 (R/(key+'-public-data.json')).write_text(json.dumps({'url':url,'checkedAt':'2026-10-15','timeZone':'Australia/Sydney','data':data},indent=2))
 meta.append({'file':key+'-public-data.json','url':url,'rawResponseSha256':hashlib.sha256(raw).hexdigest(),'rawRetained':False,'sanitization':'Only JSON public model/specification components; tracking, authentication and runtime scripts excluded; no headers retained'})
 print(key,len(data),flush=True)
(R/'public-data-extraction-manifest.json').write_text(json.dumps(meta,indent=2))
