import json, pathlib, hashlib, datetime

ROOT=pathlib.Path('/tmp/mercedes-research')
T=ROOT/'technical'
ASOF='2026-10-15'
sources=[]
records=[]
for f in [T/'primary-capture-manifest-v1.json',T/'more-capture-manifest-v1.json']+list(T.glob('extra*-capture-manifest.json')):
    records.extend(json.loads(f.read_text()))
byid={r['id']:r for r in records}

def source(key, title, publisher, kind, capture=None, file=None, url=None, date=None, notes=None):
    r=byid.get(capture or key,{})
    p=pathlib.Path(file or r.get('path',''))
    s=dict(key=key,url=url or r.get('url'),title=title,publisher=publisher,source_type=kind,checkedOn=ASOF,
           file=str(p),retrievalMethod='Fresh public text HTTP; no login, forms, location or response headers retained')
    if p.is_file():s.update(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)
    if r.get('retrievedAt'):s['retrievedAt']=r['retrievedAt']
    if r.get('status'):s['httpStatus']=r['status']
    if date:s['published_date']=date
    if notes:s['notes']=notes
    sources.append(s)

for k,title in [('eqa','EQA current exact AU technical table'),('cla','CLA electric current exact AU technical tables'),('glc','GLC electric current exact AU technical table'),('eqs','EQS current exact AU technical table'),('g580','G580 current exact AU technical table'),('configurator','Current Australian configurator family navigation')]:
    source(k,title,'Mercedes-Benz Australia','manufacturer_au_specification',k)
source('glb','GLB electric current exact AU technical tables','Mercedes-Benz Australia','manufacturer_au_specification',file=T/'glb-web-extraction-v1.json',url=byid['glb']['url'],notes='Direct HTTP returned an incomplete shell twice; retained web extraction supplies the two exact technical tables. Raw HTTP limitations are preserved separately.')
source('maker-offers','Current Australian offers, primarily demonstrators and finance','Mercedes-Benz Australia','manufacturer_au_specification')
source('maker-ev-guide','Australian guide to electric models, explicitly NEDC ranges','Mercedes-Benz Australia','manufacturer_au_specification',date='2026-04',notes='Exact EQA 250+ range only; older family roster does not establish current census.')
source('cla-carexpert','2026 CLA Australian price and specifications','CarExpert','secondary_australian_motoring_publication',date='2026-05-28')
source('glb-carexpert','2027 GLB Australian price and specifications','CarExpert','secondary_australian_motoring_publication',date='2026-09-04')
source('glb-whichcar','2027 GLB Australian price, specifications and third-row cargo scope','WhichCar / Wheels','secondary_australian_motoring_publication',date='2026-09-04')
source('glc-whichcar','Australian GLC 400 4MATIC pricing and equipment','WhichCar / Wheels','secondary_australian_motoring_publication',date='2026-07-22')
source('glc-exact-guide','2026 GLC 400 4Matic Australian exact grade guide','CarsGuide / Glass’s','secondary_australian_price_guide',notes='Overall width is 2089 mm; mirror treatment is unstated. This is not an established body-width comparison basis. Other generic/overseas dimensions differ.')
source('eqs-carexpert','Updated Australian EQS 400 price and specifications','CarExpert','secondary_australian_motoring_publication',date='2026-09-10')
source('eqs-exact-carsales','2026 Australian EQS400 exact research grade','Carsales / Redbook','secondary_australian_price_guide',notes='Carsales-created specification page, not a dealer advertisement. Exact 112 kWh/270 kW grade; do not use inconsistent gross/tare fields or generic overview range.')
source('eqa-guide','2026 Australian EQ-Class pricing table including exact EQA 250+','CarsGuide / Glass’s','secondary_australian_price_guide')
source('eqa-dimensions','2026 exact EQA 250+ Australian dimensions','CarsGuide / Glass’s','secondary_australian_price_guide')
source('eqa-choice','EQA 250+ public specifications, cargo and towing','CHOICE','secondary_australian_review',notes='Only publicly visible fields used. No member-only content accessed. Height 1620 mm conflicts with current CarsGuide 1624 mm; cargo measurement protocol unstated.')
source('eqa-towing','2026 EQA 250+ Australian towing table','CarsGuide / Glass’s','secondary_australian_price_guide')
source('g580-redbook','2026 G580 exact 117 kWh September-release Australian grade','Redbook','secondary_australian_price_guide',file=T/'g580-eqa-specific-web-v1.json',url='https://www.redbook.com.au/cars/details/2026-mercedes-benz-g-class-g580-with-eq-technology-auto-4matic/SPOT-ITM-697150?Cr=50',notes='Web extraction contains this exact page and a separate EQA page. Use only the G580 section. Price when new excludes government charges.')
source('g580-guide','2026 G-Class Australian price table','CarsGuide / Glass’s','secondary_australian_price_guide')
source('g580-old-guide','2026-named G580 guide carrying older 116 kWh technical specification','CarsGuide / Glass’s','secondary_australian_price_guide',capture='g580-exact-guide',notes='116 kWh/473 km row is not the current 117 kWh/210 kW technical epoch. Its range and towing cannot be promoted to exact-current Confirmed facts.')
source('passenger-warranty','Australian passenger-car warranty Version 3, October 2026','Mercedes-Benz Australia','manufacturer_au_document',file='/tmp/mercedes-review/warranty/statement-2026-10-09.pdf',url='https://www.mercedes-benz.com.au/content/dam/australia/passengercars/services/warranty/mercedes-benz-passenger-car-warranty-statement-2026-10-09.pdf',date='2026-10-09',notes='Applies purchases on/from 1 May 2026. Family-specific battery terms, commercial exclusions, demonstration clocks and virtual mileage retained.')

def fact(key,value,keys,grade='confirmed',basis=None,reason=None,condition=None,comparison=None,**extra):
    f=dict(key=key,value=value,sourceKeys=keys,grade=grade)
    if basis:f['basis']=basis
    if reason:f['reason']=reason
    if condition:f['condition']=condition
    if comparison is not None:f['comparison']=comparison
    f.update(extra)
    if grade!='confirmed':f['rankingEligible']=False
    return f
def reported(key,value,keys,basis=None,reason='Australian secondary specification; not manufacturer-confirmed for this exact current version.',**extra):
    return fact(key,value,keys,'reported',basis,reason,comparison='',**extra)
def missing(key,keys,reason):return fact(key,None,keys,'not_published',reason=reason,comparison='')
def price(value,key,reason=None):
    return reported('price_aud',value,[key],'Reported price before on-road costs',reason or 'Named Australian secondary price after the maker list, national offer, visible configurator and state-driveaway checks did not establish an admissible exact-grade maker amount.',priceRung=5,basisTag='Reported · before on-road costs',label='Reported list price',originalBasis='Source explicitly excludes on-road costs; GST/LCT inclusion not separately inferred')

private='5 years / unlimited kilometres (private use)'
private_scope='Australian passenger vehicles purchased on/from 1 May 2026. Commercial use: 5 years / 200,000 km. Registration-based clock; demonstrators start at retailer registration except WA delivery, with kilometres counted from demonstrator use. Excluded digital extras are not vehicle-warranty coverage.'
def warranties(eqs=False,g580=False):
    years,km=(10,250000) if eqs else (8,160000)
    metric='SOHC' if eqs else 'SOCE'
    return [fact('warranty',private,['passenger-warranty'],basis='Private-use vehicle warranty',qualifications=[private_scope]),
            fact('battery_warranty',f'{years} years / {km:,} km; below 70% {metric}',['passenger-warranty'],basis=f'Whichever occurs first; {metric} retention trigger',qualifications=[('G580 commercial applications are excluded from this HV battery certificate.' if g580 else 'Named family is expressly eligible, subject to the certificate and applicable use.'),'Bidirectional-charging energy throughput is converted to virtual kilometres and added to driven kilometres for the kilometre limit.',private_scope])]

IDS={
'eqa':('mercedes_benz_eqa_current__eqa_250_plus__20261010','EQA','EQA 250+','mercedes_benz_eqa_current','2437022_AU6'),
'cla200':('mercedes_benz_cla_electric_current__cla_200__20261010','CLA electric','CLA 200','mercedes_benz_cla_electric_current','1743112_AU1'),
'cla350':('mercedes_benz_cla_electric_current__cla_350_4matic__20261010','CLA electric','CLA 350 4MATIC','mercedes_benz_cla_electric_current','1743442_AU1'),
'glb250':('mercedes_benz_glb_electric_current__glb_250_plus__20261010','GLB electric','GLB 250+','mercedes_benz_glb_electric_current','2446132_AU1'),
'glb350':('mercedes_benz_glb_electric_current__glb_350_4matic__20261010','GLB electric','GLB 350 4MATIC','mercedes_benz_glb_electric_current','exact second AU technical-table grade; code not decoded from shell'),
'glc':('mercedes_benz_glc_electric_current__glc_400_4matic__20261015','GLC electric','GLC 400 4MATIC','mercedes_benz_glc_electric_current','5406322_AU2'),
'eqs':('mercedes_benz_eqs_current__eqs_400__20261010','EQS','EQS 400','mercedes_benz_eqs_current','2971132_AU1'),
'g580':('mercedes_benz_g_class_electric_current__g_580_with_eq_technology__20261010','G-Class electric','G 580 with EQ Technology','mercedes_benz_g_class_electric_current','4656012_AU1')}
specs={
'eqa':('eqa',140,70,100,35,11,5,'FWD'),
'cla200':('cla',165,58,200,20,11,5,'RWD'),
'cla350':('cla',260,85,320,22,11,5,'AWD'),
'glb250':('glb',200,85,320,22,11,7,'RWD'),
'glb350':('glb',260,85,320,22,11,7,'AWD'),
'glc':('glc',360,94,330,22,11,5,'AWD'),
'eqs':('eqs',270,112,330,25,11,5,'RWD'),
'g580':('g580',432,117,210,29,11,5,'AWD')}
variants=[]
for k,(primary,p,b,dc,tm,ac,seats,drive) in specs.items():
    ident,model,trim,mid,gradecode=IDS[k]
    fs=[fact('battery_kwh',b,[primary],basis='Usable energy content',comparison='Usable capacity'),fact('dc_peak_kw',dc,[primary],basis='Maximum DC charging input',comparison='Peak DC input'),fact('dc_charge_time_min',tm,[primary],basis='10–80% SOC (net), DC',comparison='10–80%'),fact('ac_kw',ac,[primary],basis='Maximum AC charging input',comparison='Maximum AC input'),fact('seats',seats,[primary]),fact('power_kw',p,[primary],basis='Vehicle output')]
    if k in ['cla200','glc','eqs']:
        for f in fs:
            if f['key']=='ac_kw':f.update(grade='check',comparison='',rankingEligible=False,condition='The exact selected AU technical table states 11 kW, while its included SA-84B component states 22 kW three-phase. Hardware applicability is unresolved; neither is invented as an option.',sourceLocator=f'{primary}-current.ssr.json: data.technicalDataSheet and data._qc features, selected {gradecode}')
    if k in ['cla200','eqs']:
        for f in fs:
            if f['key']=='dc_peak_kw':f.update(grade='check',comparison='',rankingEligible=False,condition=('Exact CLA 200 table states 200 kW; selected CLA 200 included SA-693 description states 320 kW. This conflict is not transferred to CLA 350.' if k=='cla200' else 'Exact EQS 400 table states 330 kW; selected SA-693 describes 350 kW but has a malformed wheel title. The disagreement remains unresolved.'),sourceLocator=f'{primary}-current.ssr.json: data.technicalDataSheet and data._qc features, selected {gradecode}')
    common=dict(id=ident,model=model,trim=trim,modelId=mid,generation='Current Australian manufacturer-listed configuration',modelYear=None,modelYearReason='Current maker page does not explicitly decode the formal model year; secondary title years remain source-scoped.',exactManufacturerGrade=gradecode,drive=drive,vehicleClass='passenger',facts=fs,features=[])
    common['availability']=dict(state='announced_provisional' if k=='glc' else 'current_or_order_listed',orderStatus='listed_unconfirmed',stockStatus='unverified',sourceKeys=[primary,'configurator'],reason=('Current maker table/configurator and campaign Coming soon disagree. Keep buyer Not confirmed and outside the on-sale count; no inferred arrival date.' if k=='glc' else 'Named exact Australian mechanical grade appears in the maker technical table and current family configurator. Physical stock and accepted factory orders are unverified.'),qualifications=['This per-car evidence is not a claim that every equipment edition has been enumerated.'])
    variants.append(common)
V={k:variants[i] for i,k in enumerate(specs)}

def add(k,*fs):V[k]['facts'].extend(fs)
def dims(k,vals,src,basis=None):
    for key,val in zip(['length_mm','width_mm','height_mm'],vals):add(k,reported(key,val,[src],basis=basis))
def summary(k,sl,st,sk,tl,tt,tk):V[k]['summary']={'strength':{'label':sl,'text':st,'keys':sk},'tradeoff':{'label':tl,'text':tt,'keys':tk}}

add('eqa',price(86700,'eqa-guide'),fact('range_km',578,['maker-ev-guide'],basis='NEDC',comparison='NEDC'),reported('drive','FWD',['eqa-choice']),reported('zero_to_100_s',8.6,['eqa-choice']),reported('boot_l',340,['eqa-choice'],basis='Rear cargo with seats up; measurement protocol not published'),reported('towing_braked_kg',0,['eqa-towing','eqa-choice'],basis='Secondary sources expressly state zero / no towing',reason='Both Australian secondary sources explicitly state no towing; this is not an inference from a dash. Current maker table does not publish towing.'))
dims('eqa',[4463,1834,1624],'eqa-dimensions')
next(f for f in V['eqa']['facts'] if f['key']=='height_mm')['qualifications']=['CHOICE lists 1620 mm. Current 2026 CarsGuide exact-grade figure 1624 mm is retained as Reported; the discrepancy is not resolved.']
summary('eqa','Five-seat electric SUV','The current maker lists a 70 kWh usable battery and five seats; its Australian editorial gives 578 km on the NEDC cycle.',['battery_kwh','seats','range_km'],'Modest rapid-charging rate','The exact table publishes a 100 kW DC peak and 35 minutes for 10–80% SOC. NEDC range must stay separate from WLTP.',['dc_peak_kw','dc_charge_time_min','range_km'])

for k,pr,ran,acc,tow in [('cla200',72200,470,7.5,1500),('cla350',91300,663,4.9,1800)]:
    add(k,price(pr,'cla-carexpert'),reported('range_km',ran,['cla-carexpert'],basis='WLTP'),reported('drive',specs[k][-1],['cla-carexpert']),reported('zero_to_100_s',acc,['cla-carexpert']),reported('boot_l',405,['cla-carexpert'],basis='Rear cargo; seating and measurement protocol not expressly defined'),reported('towing_braked_kg',tow,['cla-carexpert'],basis='Braked towing'),reported('frunk_l',101,['cla-carexpert'],basis='Separate under-bonnet storage; not added to rear boot'))
    dims(k,[4723,1855,1468],'cla-carexpert')
summary('cla200','Short published charging stop','The exact CLA 200 technical table gives 20 minutes for a 10–80% DC charge.',['dc_charge_time_min'],'Charging hardware needs checking','The selected maker page disagrees on 200 versus 320 kW DC and 11 versus 22 kW AC. Both fields remain unranked.',['dc_peak_kw','ac_kw'])
summary('cla350','Higher-output electric CLA','The maker confirms 260 kW and a 320 kW DC peak; Australian reporting quotes 663 km WLTP.',['power_kw','dc_peak_kw','range_km'],'Cargo figure needs context','The Australian report gives 405 L rear cargo and a separate 101 L frunk; it does not establish a common cargo measurement protocol.',['boot_l','frunk_l'])

for k,pr,ran,acc in [('glb250',74990,570,7.4),('glb350',86200,554,5.5)]:
    add(k,price(pr,'glb-carexpert'),reported('range_km',ran,['glb-carexpert','glb-whichcar'],basis='WLTP'),reported('drive',specs[k][-1],['glb-carexpert']),reported('zero_to_100_s',acc,['glb-carexpert']),missing('boot_l',['glb','glb-whichcar'],'The maker table and exact Australian launch report do not publish cargo with all seven seats in use. The reported 480 L requires the third row folded and must not populate all-seats-up boot.'),missing('towing_braked_kg',['glb','glb-carexpert'],'No exact Australian braked towing value in the maker table or Australian price/specification report. Overseas review numbers are not transferred.'),reported('cargo_third_row_folded_l',480,['glb-whichcar'],basis='Third row folded; measurement method not published'),reported('frunk_l',127,['glb-whichcar'],basis='Separate front storage; not rear boot'))
    dims(k,[4732,1861,1687],'glb-carexpert')
    # Secondary 22 kW does not establish optional equipment or change the exact 11 kW maker table.
    next(f for f in V[k]['facts'] if f['key']=='ac_kw')['qualifications']=['CarExpert reports 22 kW AC for the family, while the exact maker technical table states 11 kW. Exact selected-grade hardware was not captured; this secondary conflict is retained for review without inventing an option.']
    summary(k,'Seven seats and rapid charging','The exact Australian table lists seven seats, an 85 kWh usable battery and a 320 kW DC peak.',['seats','battery_kwh','dc_peak_kw'],'Seven-seat luggage figure is missing','The reported 480 L boot figure requires the third row folded; all-seven-seats-up volume is not published in the checked sources.',['boot_l','cargo_third_row_folded_l'])

add('glc',price(112200,'glc-whichcar'),reported('range_km',630,['glc-whichcar'],basis='WLTP'),reported('drive','AWD',['glc-whichcar']),reported('zero_to_100_s',4.3,['glc-whichcar']),reported('boot_l',570,['glc-whichcar'],basis='Rear seats up; measurement method not published'),missing('towing_braked_kg',['glc','glc-exact-guide'],'Current maker table has no towing rating and exact Australian CarsGuide grade shows a dash. No zero is inferred; overseas 2400 kg is not transferred.'),reported('frunk_l',128,['glc-whichcar'],basis='Separate front storage'),fact('optional_agility_comfort','AIRMATIC and rear-axle steering up to 4.5°',['glc'],basis='Optional Agility & Comfort Package',qualifications=['Not standard-equipment confirmation for the base grade.']))
dims('glc',[4858,2089,1649],'glc-exact-guide','Source labels these overall dimensions; mirror treatment and exact measurement convention are unstated')
summary('glc','Strong published electric output','The current maker table lists 360 kW, 94 kWh usable and a 22-minute 10–80% DC charge.',['power_kw','battery_kwh','dc_charge_time_min'],'Ordering and AC details remain unsettled','Current configurator and Coming soon campaign disagree; the selected hardware text also conflicts with the 11 kW AC table.',['ac_kw'])

add('eqs',price(184900,'eqs-carexpert'),reported('range_km',810,['eqs-carexpert','eqs-exact-carsales'],basis='WLTP, exact Australian EQS 400 secondary specification',reason='Two current exact Australian EQS 400 sources report 810 km WLTP. The maker family headline is not promoted into an exact-grade Confirmed claim; the older 710 km offer is a different 21-inch configuration witness.'),reported('drive','RWD',['eqs-carexpert']),reported('zero_to_100_s',6.2,['eqs-carexpert']),missing('boot_l',['eqs','eqs-exact-carsales'],'The current maker table and exact Australian EQS400 research grade do not publish a seats-up cargo volume. Overseas 610 L and earlier variants are not transferred.'),missing('towing_braked_kg',['eqs','eqs-exact-carsales'],'No braked towing rating in either exact current Australian source. Overseas and earlier EQS values are not transferred.'))
dims('eqs',[5229,1926,1517],'eqs-exact-carsales')
summary('eqs','Long-range reporting and large usable pack','The maker confirms 112 kWh usable; two Australian exact-grade sources report 810 km WLTP. The range remains Reported.',['battery_kwh','range_km'],'Charging specifications disagree','The current maker table gives 330 kW DC and 11 kW AC, while selected component descriptions state 350 and 22 kW.',['dc_peak_kw','ac_kw'])

add('g580',price(252700,'g580-redbook'),missing('range_km',['g580','g580-redbook'],'The exact current maker 117 kWh/210 kW table and matching September-release Australian Redbook grade do not publish range. The 473 km secondary page carries an older 116 kWh specification and is not silently transferred.'),reported('drive','AWD',['g580-redbook']),reported('zero_to_100_s',4.7,['g580-redbook']),reported('boot_l',620,['g580-redbook'],basis='Minimum rear cargo; seating state and measurement protocol not stated'),missing('towing_braked_kg',['g580','g580-redbook'],'Current exact maker and matching 117 kWh Australian Redbook grade do not publish a braked towing value. The older 116 kWh CarsGuide page says zero, but its applicability to the current epoch is unresolved.'),fact('offroad_manoeuvring','G-TURN, G-STEERING and Offroad Crawl',['g580'],basis='Named G580 off-road functions',qualifications=['G-STEERING applies off road at up to 25 km/h; G-TURN and Crawl have operating conditions. This is not a claim of unrestricted public-road use.']))
dims('g580',[4863,1984,1989],'g580-redbook')
summary('g580','Dedicated off-road electric functions','G-TURN, G-STEERING and Offroad Crawl accompany the maker’s published 432 kW output.',['offroad_manoeuvring','power_kw'],'Current range and towing need confirmation','The updated 117 kWh specification has no exact current AU range or towing figure in the two checked sources; older numbers are not assumed.',['battery_kwh','range_km','towing_braked_kg'])

for k,v in V.items():
    v['facts'].extend(warranties(k=='eqs',k=='g580'))
    v['officialSourceUrls']=[s['url'] for s in sources if s['key'] in {specs[k][0],'configurator','passenger-warranty'}]

out=dict(asOf=ASOF,status='Draft normalized passenger evidence for independent review; no source edits, baseline extraction, candidate assembly or registration.',sources=sources,variants=variants,
    scope={'currentMakerPassengerGrades':8,'currentMakerPeopleMoverGrades':1,'retailerCampaignEditions':2,'unresolvedExactCandidates':27,'upcomingFamilies':5,'tier2Excluded':'Cargo eVito and other commercial vans are unchanged; no truck research.'},
    censusFile=str(ROOT/'census/mercedes-census-2026-10-14.json'),
    pending=['Merge eVito technical normalization and separately scoped van warranty.','Merge two City Edition normalizations.','Independent review of numeric conflict display, grading, current eligibility and cargo comparison.','Complete exact current equipment-edition census remains open.','C1 independent complete whole-market lists remain open.'],
    currentVersionReviews=[],
    sourceReviewNotes=['The historical 2026-10-10 evidence JSON remains immutable; 0/45 original raw snapshot paths exist in this checkout or retained recovery chain. These are fresh captures, not reconstructed old bytes.','No hidden JSON price component is admitted as a published visible price. No GST, LCT, registration or on-road amount is derived.','Current maker list/offer/configurator checks did not yield an admissible exact visible price; secondary prices are clearly Reported and unranked.','Confirmed values preserve their published basis. NEDC and WLTP, usable and gross, all-seats-up and folded cargo remain separate.','The current maker technical tables use integer battery values; secondary decimal values are not silently substituted.','Full-version family reviews are deliberately absent while exact editions remain unresolved.'],
    priceLadderAudit={'sourceFile':str(T/'price-ladder-web-v1.json'),'makerList':'No usable current AU full vehicle price list found; exact current model pages and configurator checked.','nationalDriveaway':'Current offers page checked; demonstrator/finance incentives do not create a national new base-grade cash price.','makerConfigurator':'Model pages visibly require a location; configurator response is a price-less shell. Hidden component amounts excluded.','stateDriveaway':'No exact qualifying published state offer selected. User location not invented or submitted.','selectedRung':5,'rankingEligible':False})
(ROOT/'normalized-passenger-draft-v1.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print('Wrote',len(variants),'variants and',len(sources),'source records')
