"""Research-only amendment making retained City source limitations self-contained."""
import json,copy,hashlib
from pathlib import Path
R=Path('/tmp/mercedes-research');p=R/'normalized-evidence-v4.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p):return dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
def write(p,x):
 assert not p.exists();p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');return pin(p)
assert sha(p)=='e41bc682267120bd9043554356c16c63325d7e69bbc28061f7e1a8b750304118'
a=json.loads(p.read_text());b=copy.deepcopy(a);changes=[]
for v in b['variants']:
 if 'city_edition' not in v['id']:continue
 prefix='eqa' if 'eqa_city' in v['id'] else 'eqb'
 selected=[4463,1834,1620] if prefix=='eqa' else [4684,1834,1667]
 guide=[4463,1834,1624] if prefix=='eqa' else [4684,1834,1695]
 carsales=[4465,1849,1622] if prefix=='eqa' else [4687,1834,1703]
 for f in v['facts']:
  if f['grade']!='reported':continue
  old=copy.deepcopy(f);q=f.setdefault('qualifications',[])
  if any('carexpert' in k for k in f['sourceKeys']):q.append('CarExpert’s exact City Edition record is headed 2025 and states a 3 January 2026 release date. This mixed database cohort is retained as Reported; the current retailer campaign does not establish a newly maker-approved specification or the identity of an individual vehicle.')
  elif any('carsales' in k for k in f['sourceKeys']):q.append('Carsales’s exact City Edition research page is labelled 2025. The value belongs to that reported cohort; the live retailer campaign does not verify an individual vehicle’s model year or specification.')
  elif 'city-launch-guide' in f['sourceKeys']:q.append('The source is exact City Edition launch reporting dated 1 July 2025. Present retailer advertising does not establish that every offered vehicle has the same cohort or specification.')
  elif any(k.endswith('exact-guide') for k in f['sourceKeys']):q.append('This is the exact City Edition guide configuration labelled 2026, not a newly confirmed transaction offer or maker specification.')
  if f['key'] in ['length_mm','width_mm','height_mm']:
   i=['length_mm','width_mm','height_mm'].index(f['key']);name=['length','width','height'][i]
   q.append(f'Published {name}: CarExpert {selected[i]:,} mm is the selected Reported value; the 2026 CarsGuide record gives {guide[i]:,} mm and the 2025 Carsales record gives {carsales[i]:,} mm. These source differences remain unresolved; no averaging or mixed-source dimension set is used.')
   f['sourceKeys']=list(dict.fromkeys(f['sourceKeys']+[prefix+'-exact-guide',prefix+'-exact-carsales']))
   if 'retained below' in f.get('reason',''):f['reason']='The selected CarExpert dimension and specific alternate Australian database figures are explicitly attributed in the qualifications. Their differing cohorts and values remain unresolved and unranked.'
  if f!=old:changes.append(dict(variantId=v['id'],key=f['key'],before=old,after=copy.deepcopy(f)))
b['revision']={'supersedes':str(p),'supersededSha256':sha(p),'reason':'Buyer-visible City Edition provenance: make mixed 2025/2026 source cohorts and existing alternate dimensions explicit in fact qualifications; remove current reason references to an absent below section. No fact values, grades, bases, availability states, summaries, sources or audit-only historical records change.','factProseOrSupportingReferenceChanges':len(changes),'availabilityProjectionRequirement':'Assembler copies each already approved availability reason verbatim once into after.evidence.qualifications so it survives the production Car projection.'}
# All changes are confined to declared current fact prose/support and revision.
c=copy.deepcopy(b)
for v in c['variants']:
 for f in v['facts']:
  original=next((x['before'] for x in changes if x['variantId']==v['id'] and x['key']==f['key']),None)
  if original is not None:f.clear();f.update(original)
c['revision']=a['revision'];assert c==a
out=write(R/'normalized-evidence-v5.json',b)
auditp=R/'current-auxiliary-consistency-audit-v4.json';audit=json.loads(auditp.read_text());audit['normalized']=out;audit['revision']={'supersedes':pin(auditp),'reason':'Rebind the unchanged 245 accepted-before fact dispositions and seven summary guards to v5, whose added buyer-facing changes affect only the two new City identities. All original audit entries and before-object hashes remain identical.'};assert audit['beforeFacts']==json.loads(auditp.read_text())['beforeFacts'];ar=write(R/'current-auxiliary-consistency-audit-v5.json',audit)
diff=write(R/'normalized-evidence-v4-to-v5-diff.json',{'before':pin(p),'after':out,'changes':changes,'metadataChanges':['revision'],'audit':ar})
print(json.dumps({'normalized':out,'audit':ar,'diff':diff,'changedFacts':len(changes)},indent=2))
