import json,pathlib,copy
root=pathlib.Path('/tmp/mercedes-research');x=json.loads((root/'normalized-evidence-draft-v3.json').read_text());c=json.loads((root/'city-editions/normalized-city-editions.json').read_text());existing={s['key'] for s in x['sources']}
for s in c['sources']:
 if s['id'] in existing:continue
 host=s['url'].split('/')[2]
 pub='CarsGuide / Glass’s' if 'carsguide' in host else 'CarExpert' if 'carexpert' in host else 'Carsales / Redbook' if 'carsales' in host else 'Mercedes-Benz Ringwood' if 'mbringwood' in host else 'Clear Lease' if 'clearlease' in host else 'Source as identified in capture'
 typ='dealer_advertisement' if 'mbringwood' in host else 'broker_advertisement' if 'clearlease' in host else 'secondary_australian_price_guide'
 x['sources'].append(dict(key=s['id'],url=s['url'],title=s.get('title',s['id']),publisher=pub,source_type=typ,checkedOn=x['asOf'],file=s.get('path'),sha256=s.get('sha256'),bytes=s.get('bytes'),retrievedAt=s.get('capturedAtSystemUTC') or s.get('retrievedAt'),published_date=s.get('publicationDate'),notes=s.get('sourceDateNote') or s.get('use'),captureMetadata=s))
keys={'price':'price_aud','range':'range_km','battery':'battery_kwh','dcPeak':'dc_peak_kw','dcChargingTime':'dc_charge_time_min','acChargingPower':'ac_kw','seats':'seats','bootVolume':'boot_l','acceleration0To100':'zero_to_100_s','motorPower':'power_kw','drive':'drive','length':'length_mm','width':'width_mm','height':'height_mm','brakedTowing':'towing_braked_kg'}
base=next(v for v in x['variants'] if v['trim']=='EQA 250+')
for cv in c['variants']:
 family=cv['identity']['model'];slug=family.lower();trim=family+' 250+ City Edition';facts=[]
 for k,f in cv['coreFacts'].items():
  nf=dict(key=keys[k],value=f['value'],sourceKeys=list(dict.fromkeys(p['sourceId'] for p in f['provenance'])),grade=f['grade'].lower().replace(' ','_'),basis=f.get('basis',''),reason=f.get('note','Exact City Edition secondary source; unranked.'),comparison='',rankingEligible=False,evidenceLocators=f['provenance'],sourceNormalizedDetail=f)
  if k=='price':nf.update(priceRung=5,basisTag='Reported guide price · excludes government charges and options',label='Reported guide price',basis='CarsGuide exact City Edition guide price; stamp duty, other government charges and options excluded',originalBasis=f['basisCaveat'],qualifications=[f['basisCaveat']])
  if k=='dcChargingTime':
   nf['basis']='Reported DC duration in minutes; charge window not published in that source'
   nf['qualifications']=['This is not a verified 10–80% time and must not satisfy strict 10–80% comparable coverage. CarExpert’s separately published 0.58 duration has no time unit, so the sources are not combined.']
  facts.append(nf)
 warranties=copy.deepcopy([f for f in base['facts'] if f['key'] in ['warranty','battery_warranty']])
 for f in warranties:
  f.setdefault('qualifications',[]).append('Applies only where the advertised edition is sold under the current Australian new-vehicle warranty eligibility terms; a campaign does not establish a vehicle’s registration or warranty commencement date.')
  if f['key']=='battery_warranty':f['qualifications']=[q.replace('Named EQA, CLA, GLB or GLC family','Named EQA or EQB family') for q in f['qualifications']]
 facts.extend(warranties)
 summaries={}
 for name,label in [('strength','Compact electric format' if family=='EQA' else 'Seven-seat flexibility'),('tradeoff','Charging and luggage limits' if family=='EQA' else 'Small boot with seven aboard')]:
  s=cv[name];summaries[name]=dict(label=label,text=s['text'],keys=[keys[k] for k in s['dependsOn']])
 v=dict(id=f'mercedes_benz_{slug}_city_edition__{slug}_250_plus_city_edition__20261015',model=family,trim=trim,modelId=f'mercedes_benz_{slug}_city_edition',generation='Australian City Edition; live undated retailer campaign, technical cohort remains source-scoped',modelYear=None,modelYearReason='Exact technical databases use 2025 and 2026 labels inconsistently. No model year is inferred from the live undated campaign.',drive='FWD',vehicleClass='passenger',facts=facts,features=[],summary=summaries,
 availability=dict(state='current_or_order_listed',orderStatus='listed_unconfirmed',stockStatus='unverified',sourceKeys=['city-ringwood']+(['eqb-exact-guide'] if family=='EQB' else []),reason='Exact edition is named in a live Mercedes-Benz Ringwood retailer campaign saying currently available. The campaign is undated, has ©2025 footer and no identified vehicle; this is advertised availability only.',qualifications=['No physical-stock or accepted factory-order claim.','Retailer and broker URLs do not belong in officialSourceUrls.',cv['availabilityCaveat']['conflict']]),
 sourceConflicts=cv['sourceConflicts'],officialSourceUrls=['https://www.mercedes-benz.com.au/content/dam/australia/passengercars/services/warranty/mercedes-benz-passenger-car-warranty-statement-2026-10-09.pdf'])
 x['variants'].append(v)
x['pending']=[p for p in x['pending'] if not p.startswith('Merge two City')]
x['pending'].append('Review EQB City discontinued-configuration versus live undated campaign availability, without stock or factory-order inference.')
x['status']='Complete 11-identity research normalization draft for independent review; no baseline extraction, packet assembly, repository edits or registration.'
x['priceLadderAudit']['selectedBasisPolicy']='Explicit before-on-road news prices retain that label; guide prices that only exclude government charges/options retain that narrower basis. No reported price is ranked.'
(root/'normalized-evidence-draft-v4.json').write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
print('Merged',len(x['variants']),'identities and',len(x['sources']),'source records')
