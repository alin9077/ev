import json,pathlib,hashlib
root=pathlib.Path('/tmp/mercedes-research');x=json.loads((root/'normalized-evidence-draft-v2.json').read_text());vs={v['trim']:v for v in x['variants']}
def ff(trim,key):return next(f for f in vs[trim]['facts'] if f['key']==key)
for trim in ['EQA 250+','G 580 with EQ Technology']:
 f=ff(trim,'price_aud')
 if trim=='EQA 250+':
  f.update(basis='CarsGuide 2026 exact-grade guide price; stamp duty, other government charges and options excluded',basisTag='Reported guide price · excludes government charges and options',label='Reported guide price',originalBasis='Source excludes stamp duty, other government charges and options; it does not explicitly exclude every on-road charge')
 else:
  f.update(basis='Redbook Price When New; Price Guide excludes government charges',basisTag='Reported price when new · excludes government charges',label='Reported price when new',originalBasis='Price When New $252,700; Price Guide (Excl. Govt. Charges). No all-on-road, GST or LCT basis inferred')
for key in ['drive','zero_to_100_s','boot_l']:
 f=ff('EQA 250+',key);f['reason']='CHOICE publicly visible specification is explicitly a 2025 EQA 250+ cohort. This is Reported earlier-cohort carryover, not an exact current maker confirmation.'
 f.setdefault('qualifications',[]).append('Current manufacturer technical table does not publish this field; later equipment or specification changes are not assumed absent.')
ff('EQA 250+','towing_braked_kg')['reason']='2026 CarsGuide exact EQA 250+ table explicitly publishes 0 kg braked. CHOICE’s earlier 2025 page separately states No Towing categorically. Zero is sourced from CarsGuide, not derived from a dash or from the categorical label.'
s=next(s for s in x['sources'] if s['key']=='eqa-choice');s['published_date']='2025 model cohort; page date not stated';s['notes']+=' Earlier-cohort carryover must be labelled Reported.'
s=next(s for s in x['sources'] if s['key']=='glb');s['retrievalMethod']='Fresh web-tool page extraction; direct HTTP twice returned an incomplete shell and is not the source of these technical facts.';s.pop('retrievedAt',None);s.pop('httpStatus',None)
legacy=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104/data/mercedes-passenger-evidence-2026-10-10.json')
x['sources'].append(dict(key='historical-mercedes-evidence',url='https://www.mercedes-benz.com.au/passengercars/buy/new-car/product.html/MBKJXOZ2W2',title='Immutable 10 October 2026 Mercedes audit: exact GLB 350 offer and table conflict',publisher='Roadmark retained audit of Mercedes-Benz Australia',source_type='historical_audit_record',checkedOn='2026-10-10',file=str(legacy),bytes=legacy.stat().st_size,sha256=hashlib.sha256(legacy.read_bytes()).hexdigest(),notes='The original raw snapshots are unavailable. This source preserves an inherited unresolved conflict; it is not a fresh recapture or proof of current stock/order condition.'))
f=ff('GLB 350 4MATIC','ac_kw');f.update(grade='check',comparison='',rankingEligible=False,condition='Exact current GLB 350 technical table states 11 kW. Fresh family equipment advertises a 22 kW on-board charger; the immutable earlier exact GLB 350 offer also conflicted at 22 kW. Original offer raw bytes are unavailable, so this unresolved historical conflict is preserved rather than silently cleared.',sourceKeys=['glb','historical-mercedes-evidence'])
vs['GLC 400 4MATIC']['summary']['tradeoff']=dict(label='AC charging hardware needs checking',text='The current selected maker configuration describes a 22 kW on-board charger while its exact technical table states 11 kW. Neither is assumed to be an option.',keys=['ac_kw'])
f=ff('GLC 400 4MATIC','optional_agility_comfort');f.update(grade='check',condition='Optional Agility & Comfort Package; the description is published, but this is not standard fitment on the base grade.',rankingEligible=False,comparison='')
for trim,v in vs.items():
 for f in v['facts']:
  if f['key']=='battery_warranty' and trim!='129 Mid (MWB)':
   f['qualifications']=[q for q in f.get('qualifications',[]) if not q.startswith('Australian passenger vehicles')]
   f['qualifications'].append('Passenger warranty applies to Australian purchases on/from 1 May 2026. Registration and demonstrator commencement rules apply. The 5-year/200,000-km commercial vehicle limit is vehicle-only, not this battery limit.')
   f['qualifications'].append('Commercial battery scope: '+('G580 excluded.' if trim=='G 580 with EQ Technology' else 'EQS 10 years / 250,000 km.' if trim=='EQS 400' else 'Named EQA, CLA, GLB or GLC family 8 years / 160,000 km.'))
f=ff('129 Mid (MWB)','range_km');f.update(grade='reported',reason='Exact Australian government record names the eight-seat 2024–2026 FL2 Tourer and 430 km NEDC. It is a non-maker government publication under the catalogue policy, so Reported and unranked. An undecoded model year alone is not used as a Check condition.');f.pop('condition',None)
for s in x['sources']:
 m=s.get('captureMetadata',{})
 if not s.get('file') and m.get('rawFailurePath'):s['file']=m['rawFailurePath'];s['source_type']='retrieval_failure';s['notes']='Retained HTTP failure only; not factual evidence.'
 if s['key']=='eqv-global-2024-facelift-maker':s['source_type']='manufacturer_global_document';s['notes']='Overseas/global context only; not promoted to an Australian current catalogue fact.'
 if s['key']=='evito-historical-au-dealer-brochure':s['source_type']='manufacturer_au_historical_document_retailer_mirror'
x['pending']=[p for p in x['pending'] if not p.startswith('Reviewer decision on exact FL2')]
x['reviewAmendments']=['Vehicle-price guide exclusions kept literal rather than expanded to all on-road costs.','EQA CHOICE facts explicitly identified as 2025 carryover.','GLB 350 inherited and fresh-family AC conflict retained as Check; GLB 250 exact applicability remains under review.','Tourer government range Reported; labelled technical-table 93 kWh shown Check against selected 90 kWh.','Battery commercial scope separated from vehicle commercial warranty.','GLC summary dependencies narrowed to the sourced hardware issue.']
(root/'normalized-evidence-draft-v3.json').write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
print('Wrote reviewed amendments:',len(x['variants']),'variants')
