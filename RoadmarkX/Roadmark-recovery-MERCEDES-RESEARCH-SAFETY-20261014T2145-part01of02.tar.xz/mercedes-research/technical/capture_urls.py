import urllib.request,urllib.error,json,re,hashlib,datetime,pathlib,sys
root=pathlib.Path('/tmp/mercedes-research/technical');items=json.load(open(sys.argv[1]));manifest=[]
for key,url in items.items():
 entry={'id':key,'url':url,'retrievedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Public read-only request. No account, form, location or response headers retained.'}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=25) as r:data=r.read();entry.update({'status':r.status,'finalUrl':r.url})
  ext='.pdf' if url.endswith('.pdf') else '.json' if data[:1] in [b'{',b'['] else '.html';dest=root/(key+'.raw'+ext);dest.write_bytes(data);entry.update({'path':str(dest),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
  if ext=='.html':
   ssr=[]
   for n,m in enumerate(re.finditer(r'<script\b[^>]*>(.*?)</script>',data.decode('utf-8',errors='replace'),re.S)):
    t=m.group(1)
    if 'window.ssrData' in t:
     q=re.search(r'\]\s*=\s*',t)
     try:ssr.append({'scriptIndex':n,'data':json.JSONDecoder().raw_decode(t[q.end():])[0]})
     except Exception as e:entry.setdefault('parseFailures',[]).append(str(e))
   (root/(key+'.ssr.json')).write_text(json.dumps(ssr,indent=2,ensure_ascii=False));entry['ssrCount']=len(ssr)
  print(key,entry['status'],len(data),entry.get('ssrCount'),flush=True)
 except Exception as e:
  entry['error']=repr(e)
  if isinstance(e,urllib.error.HTTPError):
   raw=e.read();dest=root/(key+'.error.raw');dest.write_bytes(raw);entry.update({'status':e.code,'rawFailurePath':str(dest),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
  print(key,repr(e),flush=True)
 manifest.append(entry);(root/(pathlib.Path(sys.argv[1]).stem+'-capture-manifest.json')).write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
