import urllib.request, urllib.error, json, re, hashlib, datetime, pathlib
root=pathlib.Path('/tmp/mercedes-research/technical')
paths={
'eqa':'/passengercars/models/suv/eqa/overview.html',
'cla':'/passengercars/models/saloon/cla-electric/overview.html',
'glb':'/passengercars/models/suv/glb-electric/overview.html',
'glc':'/passengercars/models/suv/glc-electric/overview.html',
'eqs':'/passengercars/models/saloon/eqs/overview.html',
'g580':'/passengercars/models/suv/g-class-electric/overview.html',
'configurator':'/passengercars/configurator.html',
'offers':'/passengercars/buy/current-offers.html',
'warranty':'/content/dam/australia/passengercars/services/warranty/mercedes-benz-passenger-car-warranty-statement-2026-10-09.pdf'}
manifest=[]
for key,path in paths.items():
 url='https://www.mercedes-benz.com.au'+path; checked=datetime.datetime.now(datetime.timezone.utc).isoformat();entry={'id':key,'url':url,'retrievedAt':checked,'scope':'Public Australian maker page; no account, form or location submitted; response headers not retained'}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=35) as r: data=r.read();entry.update({'status':r.status,'finalUrl':r.url,'contentType':r.headers.get('Content-Type')})
  ext='.pdf' if path.endswith('.pdf') else '.html';dest=root/(key+'-current.raw'+ext);dest.write_bytes(data);entry.update({'path':str(dest),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
  if ext=='.html':
   ssr=[]
   for n,m in enumerate(re.finditer(r'<script\b[^>]*>(.*?)</script>',data.decode('utf-8',errors='replace'),re.S)):
    t=m.group(1)
    if 'window.ssrData' in t:
     q=re.search(r'\]\s*=\s*',t)
     try:ssr.append({'scriptIndex':n,'data':json.JSONDecoder().raw_decode(t[q.end():])[0]})
     except Exception as e:entry.setdefault('parseFailures',[]).append(str(e))
   (root/(key+'-current.ssr.json')).write_text(json.dumps(ssr,indent=2,ensure_ascii=False));entry['ssrCount']=len(ssr)
  print(key,entry['status'],len(data),entry.get('ssrCount'))
 except Exception as e:entry['error']=repr(e);print(key,repr(e))
 manifest.append(entry);(root/'primary-capture-manifest-v1.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
