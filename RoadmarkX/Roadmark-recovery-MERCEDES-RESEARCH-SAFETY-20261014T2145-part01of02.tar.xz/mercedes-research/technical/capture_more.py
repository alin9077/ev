import urllib.request,json,re,hashlib,datetime,pathlib
root=pathlib.Path('/tmp/mercedes-research/technical')
urls={
'glb-retry':'https://www.mercedes-benz.com.au/passengercars/models/suv/glb-electric/overview.html',
'cla-config':'https://www.mercedes-benz.com.au/passengercars/mercedes-benz-cars/car-configurator.html/start/CCci/AU/en/tc/C174',
'cla-carexpert':'https://www.carexpert.com.au/car-news/2026-mercedes-benz-cla-price-and-specs',
'glb-carexpert':'https://www.carexpert.com.au/car-news/2027-mercedes-benz-glb-price-and-specs-new-generation-seven-seat-suv-gains-eqb-replacing-ev-option',
'glc-whichcar':'https://www.whichcar.com.au/news/mercedes-benz-glc-400-4matic-first-electric-australia',
'eqs-carexpert':'https://www.carexpert.com.au/car-news/mercedes-benz-eqs-prices-updated-electric-limo-now-australias-longest-range-ev',
'evito-tourer':'https://www.mercedes-benz.com.au/vans/models/evito/tourer/overview.html',
'eqa-stock-current':'https://www.mercedes-benz.com.au/passengercars/buy/new-car/product.html/MBYYKRLZJW'}
manifest=[]
for key,url in urls.items():
 entry={'id':key,'url':url,'retrievedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Public webpage only; no form, location, account or headers saved'}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=30) as r:data=r.read();entry.update({'status':r.status,'finalUrl':r.url})
  dest=root/(key+'.raw.html');dest.write_bytes(data);entry.update({'path':str(dest),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
  ssr=[]
  for n,m in enumerate(re.finditer(r'<script\b[^>]*>(.*?)</script>',data.decode('utf-8',errors='replace'),re.S)):
   t=m.group(1)
   if 'window.ssrData' in t:
    q=re.search(r'\]\s*=\s*',t)
    try:ssr.append({'scriptIndex':n,'data':json.JSONDecoder().raw_decode(t[q.end():])[0]})
    except Exception as e:entry.setdefault('parseFailures',[]).append(str(e))
  (root/(key+'.ssr.json')).write_text(json.dumps(ssr,indent=2,ensure_ascii=False));entry['ssrCount']=len(ssr)
  print(key,entry['status'],len(data),entry.get('ssrCount'),flush=True)
 except Exception as e:entry['error']=repr(e);print(key,repr(e),flush=True)
 manifest.append(entry);(root/'more-capture-manifest-v1.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
