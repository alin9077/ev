import json,pathlib,hashlib
root=pathlib.Path('/tmp/mercedes-research');p=root/'normalized-passenger-draft-v1.json';x=json.loads(p.read_text());asof=x['asOf']
child=json.loads((root/'people-movers/normalized-facts.json').read_text())
srcs=json.loads((root/'people-movers/sources.json').read_text())['sources']
existing={s['key'] for s in x['sources']}
for s in srcs:
 if s['id'] in existing:continue
 kind=s.get('sourceType','')
 typ='manufacturer_au_document' if kind=='manufacturer' else 'government_au_specification' if 'government' in kind else 'secondary_australian_price_guide'
 x['sources'].append(dict(key=s['id'],url=s['url'],title=s.get('title',s['id']),publisher=s.get('publisher',''),source_type=typ,checkedOn=asof,file=s.get('path') or s.get('rawPath'),sha256=s.get('sha256'),bytes=s.get('bytes'),retrievedAt=s.get('retrievedAt'),published_date=s.get('publishedDate'),notes=s.get('applicability'),captureMetadata=s))
path=pathlib.Path('/tmp/mercedes-review/warranty/vans-warranty.html')
x['sources'].append(dict(key='vans-warranty',url='https://www.mercedes-benz.com.au/vans/services/warranty.html',title='Australian eVito and eVito Tourer warranty',publisher='Mercedes-Benz Vans Australia',source_type='manufacturer_au_specification',checkedOn=asof,file=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),notes='Exact named Tourer terms differ from passenger-car unlimited-kilometre warranty. No battery retention threshold published.'))
keys={'range':'range_km','battery':'battery_kwh','dcPeak':'dc_peak_kw','dc10to80':'dc_charge_time_min','acCharging':'ac_kw','seats':'seats','boot':'boot_l','zeroTo100':'zero_to_100_s','power':'power_kw','drive':'drive','length':'length_mm','width':'width_mm','height':'height_mm','brakedTowing':'towing_braked_kg'}
fs=[]
for f in child['vehicles'][0]['fields']:
 fs.append(dict(key=keys[f['field']],value=f['value'],sourceKeys=list(dict.fromkeys(e['sourceId'] for e in f['evidence'])),grade=f['status'].lower().replace(' ','_'),basis=f['measurementBasis'],reason=f['reason'],comparison='',rankingEligible=False,evidenceLocators=f['evidence'],alternatives=f.get('alternatives',[])))
 if f['status']=='Check':fs[-1]['condition']=f['reason']
for f in fs:
 if f['key']=='battery_kwh':
  f['value']=93;f['basis']='93 kWh usable as labelled in exact current technicalDetails; selected ME4 says 90 kWh usable';f['condition']='The exact same current configuration publishes 93 kWh usable in technicalDetails and 90 kWh usable for selected ME4. The displayed number is attributed to the table, not a resolution of the conflict.'
 if f['grade']=='confirmed' and f['key'] not in ['width_mm','height_mm']:
  f['rankingEligible']=True
  f['comparison']={'dc_peak_kw':'Peak DC input','ac_kw':'Maximum AC input','towing_braked_kg':'Braked towing'}.get(f['key'],'')
fs += [dict(key='price_aud',value=137515,sourceKeys=['evito-guide'],grade='reported',priceRung=5,basisTag='Reported · excludes government charges and options',label='Reported list price',basis='CarsGuide 2026 exact Tourer 129 MWB catalogue amount; government charges and options excluded',originalBasis='Source excludes stamp duty, other government charges and options; GST/LCT basis is not inferred',comparison='',rankingEligible=False,reason='Visible exact secondary Tourer price after maker current page and VOC failed to publish an admissible visible exact-grade cash price. Hidden net/gross components are excluded.'),
dict(key='warranty',value='5 years / 250,000 km',sourceKeys=['vans-warranty'],grade='confirmed',basis='Whichever occurs first; exact eVito/eVito Tourer vehicle warranty',qualifications=['Clock starts at first registration. Demonstrator coverage starts when first registered as a demonstrator. Passenger-car unlimited-kilometre terms do not apply.']),
dict(key='battery_warranty',value='8 years / 160,000 km',sourceKeys=['vans-warranty','evito-tourer'],grade='confirmed',basis='Whichever occurs first; exact eVito Tourer high-voltage battery warranty',qualifications=['The current named warranty page and Tourer model overview do not publish a capacity-retention threshold. No passenger 70% term is inherited. Optional service-plan coverage is not standard battery warranty.'])]
v=dict(id='mercedes_benz_evito_tourer_current__129_mid_mwb__20261015',model='eVito Tourer',trim='129 Mid (MWB)',modelId='mercedes_benz_evito_tourer_current',generation='Current Australian VOC national type 44770323-AEF',modelYear=None,modelYearReason='Exact current VOC does not decode a formal model year. Linked MY2025 PDF and 2026 secondary guide remain source-scoped.',drive='FWD',vehicleClass='passenger',bodyType='people_mover',facts=fs,features=[],
 availability=dict(state='current_or_order_listed',orderStatus='listed_unconfirmed',stockStatus='unverified',sourceKeys=['evito-tourer','evito-voc-models'],reason='Current manufacturer passenger Tourer page links a configurator returning this exact eight-seat national type. It is not a complete version list or evidence of physical stock or accepted factory orders.',qualifications=['People-mover configuration only; cargo eVito is a different unchanged Tier2 entry.']),
 summary=dict(strength=dict(label='Eight-seat electric people mover',text='The current exact configuration confirms eight seats including the driver, 150 kW, front-wheel drive and 110 kW DC charging.',keys=['seats','power_kw','drive','dc_peak_kw']),tradeoff=dict(label='Battery and luggage details conflict',text='The current maker response says both 93 and 90 kWh usable. Its several cargo figures lack matched seating states, so all-seats-up luggage space remains unresolved.',keys=['battery_kwh','boot_l'])),
 officialSourceUrls=['https://www.mercedes-benz.com.au/vans/models/evito/tourer/overview.html','https://voc.mercedes-benz.com/voc/api/au_en/models?models=VITO&bodyTypes=COMBI&fuelTypes=E','https://www.mercedes-benz.com.au/vans/services/warranty.html'])
x['variants'].append(v)
x['pending']=[p for p in x['pending'] if not p.startswith('Merge eVito')]
x['pending'].append('Reviewer decision on exact FL2 government NEDC applicability and current 93/90 kWh table display.')
x['excludedResearchCandidates']=[{'name':'EQV 300 MWB','reason':'Current exact-grade manufacturer offering and advertised-new eligibility unresolved; technical evidence retained separately without a catalogue entry.','evidenceFile':str(root/'people-movers/normalized-facts.json')}]
(root/'normalized-evidence-draft-v2.json').write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
print('Merged',len(x['variants']),'variants and',len(x['sources']),'sources')
