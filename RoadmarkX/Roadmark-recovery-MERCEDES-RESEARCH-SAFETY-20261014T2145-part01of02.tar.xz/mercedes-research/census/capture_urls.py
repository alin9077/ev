import urllib.request, json, hashlib, datetime, concurrent.futures, pathlib
from html.parser import HTMLParser
root=pathlib.Path('/tmp/mercedes-research/census')
class Text(HTMLParser):
 def __init__(self):super().__init__();self.parts=[];self.hide=0
 def handle_starttag(self,t,a):
  if t in ['script','style']:self.hide+=1
 def handle_endtag(self,t):
  if t in ['script','style']:self.hide=max(0,self.hide-1)
 def handle_data(self,d):
  if not self.hide and d.strip():self.parts.append(d.strip())
def capture(item):
 k,u=item; meta={'id':k,'requested_url':u,'retrieved_date':'2026-10-14','retrieved_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only Australian Mercedes BEV model census source capture; public HTTP, no login, no stock or order acceptance inferred'}
 try:
  with urllib.request.urlopen(u,timeout=35) as r:
   b=r.read();meta.update(status=r.status,final_url=r.url,headers=dict(r.headers),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
  p=root/(k+'.raw.html');p.write_bytes(b);meta['raw_path']=str(p)
  if b[:1] in [b'{',b'[']: (root/(k+'.json')).write_bytes(b)
  else:
   p=Text();p.feed(b.decode('utf-8',errors='replace'));(root/(k+'.txt')).write_text('\n'.join(p.parts))
 except Exception as e:meta.update(error=repr(e));(root/(k+'.failure.txt')).write_text(repr(e))
 (root/(k+'.metadata.json')).write_text(json.dumps(meta,indent=2));return meta
if __name__=='__main__':
 urls=json.load(open('/tmp/mercedes-research/census/capture_urls.json'))
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
  for m in ex.map(capture,urls.items()):print(json.dumps(m))
