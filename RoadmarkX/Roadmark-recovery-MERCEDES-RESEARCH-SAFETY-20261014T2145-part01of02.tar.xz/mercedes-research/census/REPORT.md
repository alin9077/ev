# Australian Mercedes-Benz BEV census audit, 14 October 2026

## Useful result

The current manufacturer surface establishes eight exact passenger/SUV mechanical grades across six families, plus one exact eVito Tourer people-mover configuration. This is an evidence-backed current-listed set, not a fully closed all-version census and not proof of physical stock or accepted factory orders.

- EQA 250+
- CLA 200 electric; CLA 350 4MATIC electric
- GLB 250+ electric; GLB 350 4MATIC electric
- GLC 400 4MATIC electric, with an unresolved manufacturer launch-status conflict
- EQS 400
- G 580 with EQ Technology
- eVito Tourer 129 Mid (MWB, FWD), exact national type 44770323-AEF, eight seats including driver

Source: current Australian manufacturer technical tables and configurator, plus the Australian VOC response. Parent captures are under `/tmp/mercedes-research/technical`. Full structured evidence is in `mercedes-census-2026-10-14.json`.

Do not substitute global CLA 250+ for the current AU technical table's CLA 200. Do not substitute GLC 350 e PHEV for electric GLC 400 4MATIC. G580 is not marketed locally under an EQG model name in the checked primary source.

## Exact editions cannot be collapsed away

Mercedes-Benz Ringwood's live EQA/EQB City Edition campaign explicitly names both EQA 250+ City Edition and EQB 250+ City Edition and says currently available. This is a retailer-authored web advertisement. It carries no date/expiry or vehicle identity and its footer is ©2025. Retain both edition identities with an undated-current-web-ad qualifier; no claim of stock or factory supply follows.

https://event.mbringwood.com.au/eqa-eqb-city-edition/

Clear Lease separately advertises those editions, with immediate-delivery language and a July2025 campaign start. It is a broker/leasing-partner offer, not a second dealer physical-stock verification.

https://www.clearlease.com.au/mercedes-benz-eqa-eqb-city-edition

Other exact edition leads remain open: EQA/EQB 250+ Night Edition, G580 Offroad, G580 Edition ONE, and GLC400 Limited Edition. Current official mechanical-grade tables do not close the equipment-edition census. CarsGuide2026 G-Class pricing and Carsales/Redbook2025 identify G580 Offroad separately; do not silently merge it into base G580.

## Residuals and false positives

The Carsales EQE new index and exact Maybach EQS680 SHRM listing explicitly say they are generic listings created by Carsales, not the dealer/manufacturer. They are discovery evidence only. Their new-to-order label does not independently establish dealer advertising, supply or order acceptance.

- https://www.carsales.com.au/cars/new/mercedes-benz/eqe/
- https://www.carsales.com.au/cars/details/2025-mercedes-benz-eqs-maybach-eqs680-auto-4matic/SHRM-AD-6500441/

CarsGuide EQB250+ Night Edition and EQV300 MWB pages likewise have no identified dealer, VIN or stock number. Keep them as unresolved catalogue leads.

- https://www.carsguide.com.au/car/14862627/mercedes-benz/eqb250/suv
- https://www.carsguide.com.au/car/14992651/mercedes-benz/eqv/people-mover

The official EQB250+ product path MB2RJ6VMXC is a previously condition-conflicted NEW_CARS/CPO/DEMO offer. Fresh web extraction is skeletal. Do not upgrade it to new condition.

A new EQA350 exact dealership lead says first registered owner, but already-started warranty and blocked fresh page retrieval prevent resolving condition. The advertisement is not proof of new status. Both web cache miss and parent HTTP403 are retained.

https://www.pattersoncheney.com.au/all-stock/view/2024-Mercedes-Benz-EQA/34177018

Older EQA250/EQA350, EQB250/EQB350, EQC400 variants, EQE sedan/SUV variants and outgoing EQS variants remain bounded unresolved candidates. Used/demo units and old launch articles do not establish current advertised-new status. Failure to find a valid new ad is not evidence that no Australian new residuals exist. EQS580 SUV is only a secondary/global candidate; Australian availability was not established.

## People movers

The current official eVitoTourer page and van configurator advertise the electric passenger model. Its exact fresh Australian VOC response returns eVitoTourer129Mid, not a list of multiple grades. Do not call that endpoint's single configuration an exhaustive version enumeration. Page copy still inconsistently says eight occupants versus eight plus driver; the exact configuration is eight including driver.

https://www.mercedes-benz.com.au/vans/models/evito/tourer/overview.html
https://voc.mercedes-benz.com/voc/api/au_en/models?models=VITO&bodyTypes=COMBI&fuelTypes=E

The official EQV URL remains live with family highlights and enquiry copy, but has no technicalDataSheet/grade list and EQV is absent from current passenger configurator navigation. EQV300MWB is supported by secondary exact catalogues/broker adverts; current primary exact-grade offering and supply remain unresolved.

https://www.mercedes-benz.com.au/passengercars/models/van/eqv/overview.html

EQV and eVitoTourer are included as passenger people movers. Cargo eVito/eSprinter and other vans/light-commercials/trucks are excluded.

## Upcoming only

The current manufacturer electric grid labels C-Class electric, GLA electric, Mercedes-AMG GT4-Door electric and VLE Coming soon. Keep them outside the current-offering set. The legacy future CLA Shooting Brake page is also not a verified current Australian offering.

https://www.mercedes-benz.com.au/passengercars/models/electric.html

GLC is different: technical/configurator current-listing evidence exists, while a manufacturer campaign says Coming soon. Preserve that conflict instead of quietly picking one.

## Independent whole-market cross-checks

Separately published broad Australian lists were found, but none closes current October2026 exact-version completeness:

1. AAA Electric Vehicle Index: search extraction says latest Q2 2026 and all BEVs offered as new on collection date. Fresh open returns an empty text shell, so detailed current table was not independently revalidated
   https://www.aaa.asn.au/research-data/electric-vehicle/
2. Electric Car Advice Australia2026: broad current/future brand/model inventory. Mercedes row includes EQA/EQB/EQC/EQE/EQS/EQV/G580/CLA, but misses current GLB/GLC. Family-only discovery, not exact-version truth
   https://electriccaradviceaustralia.com.au/australian-ev-market-guide-50-car-brands-models-2026/
3. RAC WA complete EV guide across linked categories: published February2025/byline December2024. Independently published but stale for this audit
   https://rac.com.au/horizons/drive/electric-cars-australia
4. EVC current catalogue expressly says not exhaustive and website refresh. Its 2025 report has exact Mercedes tables but web fetch exceeds20MB limit; excerpts are not a new full capture
   https://electricvehiclecouncil.com.au/evs-available/
   https://electricvehiclecouncil.com.au/wp-content/uploads/2025/10/State-of-EVs_2025_141025-2.pdf

C1 must remain open. The sources are separate publishers, not a claim that every underlying datum was independently collected.

## Capture/provenance limits

All work was read-only web/text HTTP research. No browser, tests, repository/source edits, cloud tasks or user computer were used. Research files and scripts only were written under `/tmp/mercedes-research/census`.

Initial official-electric HTTP capture succeeded. Later direct worker HTTP requests returned proxy403 errors; the failure metadata is preserved. Parent's ordinary HTTP route independently succeeded for key primary/retailer pages and its captures are reused. There was no bypass of a denied action.

Web search/open snapshots are sometimes cached and inconsistent: the EQE new-index search says recent while open resolves a2025 snapshot. Fresh request date is not equivalent to publisher update date. The executor clock differs from the conversation clock; raw HTTP response dates/executor timestamps are retained separately from the task's as-of date.
