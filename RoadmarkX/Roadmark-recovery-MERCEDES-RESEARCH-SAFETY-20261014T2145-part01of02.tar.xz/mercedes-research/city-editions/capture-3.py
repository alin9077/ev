import urllib.request, urllib.error, json, pathlib, hashlib, datetime, concurrent.futures
from html.parser import HTMLParser
class Extract(HTMLParser):
 def __init__(self):super().__init__();self.skip=0;self.parts=[]
 def handle_starttag(self,t,a):
  if t in ['script','style','noscript']: self.skip+=1
 def handle_endtag(self,t):
  if t in ['script','style','noscript']: self.skip=max(0,self.skip-1)
 def handle_data(self,d):
  if not self.skip and d.strip():self.parts.append(d.strip())
def text(b):
 e=Extract();e.feed(b.decode('utf-8',errors='replace'));return '\n'.join(e.parts)

p=pathlib.Path('/tmp/mercedes-research/city-editions')
items={
'eqa-exact-carexpert-linked':'https://www.carexpert.com.au/mercedes-benz/eqa/2025-city-edition-suv-fwd-electric-jsgsswaf20260121',
'eqb-exact-carexpert-linked':'https://www.carexpert.com.au/mercedes-benz/eqb/2025-city-edition-suv-fwd-electric-jsgswffs20260121'
}
def capture(k,u):
 d={'id':k,'url':u,'checkedDate':'2026-10-14','capturedAtSystemUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only public HTTP; no forms, accounts, leads or state changes'}
 try:
  with urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=40) as r:
   b=r.read();d.update(status=r.status,finalUrl=r.url)
  f=p/(k+'.raw.html');f.write_bytes(b);d.update(path=str(f),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
  f=p/(k+'.raw.txt');f.write_text(text(b));d['textPath']=str(f)
 except Exception as e:
  d['error']=repr(e)
  if isinstance(e,urllib.error.HTTPError):
   b=e.read();f=p/(k+'.error.raw');f.write_bytes(b);d.update(status=e.code,path=str(f),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 return d
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 rows=list(ex.map(lambda a:capture(*a),items.items()))
(p/'capture-manifest-3.json').write_text(json.dumps(rows,indent=2))
for r in rows: print(r['id'],r.get('status'),r.get('bytes'),r.get('error'))
for k in ['city-carexpert','city-carsales','maker-ev-guide']:
 b=(p.parent/'technical'/(k+'.raw.html')).read_bytes()
 (p/(k+'.derived.txt')).write_text(text(b))
