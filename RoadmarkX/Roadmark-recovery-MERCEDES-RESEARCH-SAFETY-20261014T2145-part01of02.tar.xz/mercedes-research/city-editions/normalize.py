import pathlib,json,hashlib,re
P=pathlib.Path('/tmp/mercedes-research/city-editions'); T=P.parent/'technical'; D='2026-10-14'
source_rows=[]
for name in ['capture-manifest.json','capture-manifest-2.json','capture-manifest-3.json']:
 source_rows.extend(json.loads((P/name).read_text()))
needed=['city-ringwood','city-clearlease','city-carexpert','city-carsales','maker-ev-guide','eqa-guide']
for mf in T.glob('*manifest*.json'):
 for row in json.loads(mf.read_text()):
  if row.get('id') in needed and not any(x['id']==row['id'] for x in source_rows):source_rows.append(row)
for s in source_rows:
 s['checkedDate']=D
 s['type']='secondary_exact_grade' if 'exact' in s['id'] else 'secondary'
 if s['id']=='city-ringwood':s['type']='authorised_retailer_campaign';s['publicationDate']=None;s['sourceDateNote']='Undated page; copyright 2025 is not a publication date.'
 if s['id']=='city-clearlease':s['type']='leasing_partner_campaign';s['publicationDate']=None;s['sourceDateNote']='Campaign says available from July 2025; footer copyright 2040 is not valid freshness evidence.'
 if s['id']=='maker-ev-guide':s['type']='maker_generic_model_guide';s['publicationDate']=None;s['use']='Context only; generic EQA 250+ / EQB 250+ statements not promoted to City Edition Confirmed.'
 if s['id']=='city-launch-guide':s['publicationDate']='2025-07-01'
 if s['id']=='city-carexpert':s['publicationDate']='2025-07-01'
 if s['id']=='city-carsales':s['publicationDate']='2025-07-02'
 if 'carexpert' in s['id'] and 'exact' in s['id']:
  s['sourceDateNote']='Exact City Edition database. Generic feature URL links a page headed 2025, stating release on 3 January 2026. Retrieval does not establish a new maker-approved 2026 specification.'
  s['modelYearLabel']='2025'
 if 'carsales' in s['id'] and 'exact' in s['id']:s['modelYearLabel']='2025';s['publicationDate']=None
 if 'guide' in s['id'] and 'exact' in s['id']:s['modelYearLabel']='2026';s['publicationDate']=None
 if s.get('path'):
  p=pathlib.Path(s['path']);s['sha256Verified']=hashlib.sha256(p.read_bytes()).hexdigest()==s['sha256']
  textpath=p.with_suffix('.txt')
  if textpath.exists():s['textPath']=str(textpath)
  if (P/(s['id']+'.derived.txt')).exists():s['textPath']=str(P/(s['id']+'.derived.txt'))
source_map={s['id']:s for s in source_rows}
def ev(src,field):
 s=source_map[src];t=pathlib.Path(s.get('textPath','/nonexistent'))
 lines=t.read_text().splitlines() if t.exists() else []
 hits=[i+1 for i,l in enumerate(lines) if field.lower() in l.lower()]
 return {'sourceId':src,'sourceField':field,'textLines':hits,'rawSha256':s['sha256']}
def fact(value,unit,src,field,basis=None,note=None):
 o={'value':value,'unit':unit,'grade':'Reported','rankingEligible':False,'checkedDate':D,'provenance':[ev(src,field)]}
 if basis:o['basis']=basis
 if note:o['note']=note
 return o
variants=[]
for model,seats,rng,boot,acc,length,height,price,minutes in [('eqa',5,578,340,8.6,4463,1620,80700,35),('eqb',7,564,130,8.9,4684,1667,86300,32)]:
 ce=model+'-exact-carexpert-linked'; cg=model+'-exact-guide'; cs=model+'-exact-carsales'
 f={
 'price':fact(price,'AUD',cg,'From','reported_guide_msrp_excludes_stamp_duty_other_government_charges_options','CarsGuide reports manufacturer-suggested retail price excluding government charges and options; this is secondary reporting, not a maker-confirmed current offer.'),
 'range':fact(rng,'km','city-launch-guide','A 70.5kWh battery','NEDC','Exact City Edition launch reporting dated 1 July 2025. Do not relabel as WLTP or use for real-world range.'),
 'battery':fact(70.5,'kWh',ce,'Useable Battery','usable','Gross capacity is not published in the two exact City sources checked: CarExpert and carsales. No gross/usable conversion.'),
 'dcPeak':fact(100,'kW',ce,'Mode 4 Max kW Supplied To Vehicle','peak_dc'),
 'dcChargingTime':fact(minutes,'minutes',cs,'DC Charging Time (at Max kW)','dc_at_max_kw_window_not_published','State-of-charge window is not supplied with these minutes; not a validated DC 10–80% value. CarExpert supplies 10–80% separately but its duration 0.58 has no displayed time unit. Do not combine sources or convert it.'),
 'acChargingPower':fact(11,'kW',ce,'Mode 3 Max kW Supplied To Vehicle','maximum_ac'),
 'seats':fact(seats,'people',ce,'Seating','standard_capacity','Exact City database seating configuration: '+('2+3' if model=='eqa' else '2+3+2')+'.'),
 'bootVolume':fact(boot,'L',ce,'Rear Seat Up to Lower Window (L)','VDA_rear_seats_up_to_lower_window','All seating rows upright on the source '+str(seats)+'-seat configuration; luggage volume to lower window. '+('Do not substitute the carsales 495 L min figure, which does not identify its seating-row position.' if model=='eqb' else 'carsales independently lists 340 L minimum but does not specify its measuring method.')),
 'acceleration0To100':fact(acc,'seconds',ce,'Acceleration 0 To 100 km/h','0_100_kmh'),
 'motorPower':fact(140,'kW',ce,'Maximum Power (kW)','maximum_motor_power'),
 'drive':fact('FWD',None,ce,'Driven Wheels','front_wheel_drive'),
 'length':fact(length,'mm',ce,'Overall Length (mm)','overall_length','Conflicting exact-source dimensions are retained below; dealer confirmation needed.'),
 'width':fact(1834,'mm',ce,'Overall Width (mm)','body_width_excluding_mirrors','Source separately gives 2020 mm including mirrors; retain measurement distinction.'),
 'height':fact(height,'mm',ce,'Overall Height (mm)','overall_height','Conflicting exact-source dimensions are retained below; no averaging or unlabelled selection.'),
 'brakedTowing':fact(750,'kg',ce,'Gross Trailer Weight Braked (kg)','braked_trailer_mass','Secondary exact-grade rating only; confirm Australian delivered vehicle rating and approved tow equipment before relying on it.')}
 f['price']['rankingGroup']=None
 f['price']['basisCaveat']='The guide expressly excludes stamp duty, other government charges and options; it does not expressly exclude every on-road charge. Do not assign to before-on-road or driveaway ranking groups from this wording.'
 f['price']['launchPriceAlternative']={'value':80700 if model=='eqa' else 85400,'unit':'AUD','basis':'before_on_road_costs','grade':'Reported','rankingEligible':False,'sourceId':'city-launch-guide','publicationDate':'2025-07-01','note':'Historical exact City launch price, kept separate from current guide wording.'}
 f['battery']['grossCapacity']={'value':None,'grade':'Not published','reason':'Neither exact City CarExpert nor exact City carsales publishes a labelled gross battery capacity.','searchedSources':[ce,cs]}
 f['dcChargingTime']['validated10To80Minutes']=None
 f['dcChargingTime']['missingWindow']={'grade':'Not published','reason':'carsales publishes minutes without a charging window; CarExpert publishes a 10–80% window with unitless duration 0.58. No single verified source establishes minutes and window together.','searchedSources':[cs,ce]}
 f['dcChargingTime']['separateWindowEvidence']={'startPercent':10,'endPercent':80,'rawDuration':'0.58','timeUnit':None,'grade':'Reported','rankingEligible':False,'provenance':[ev(ce,'Mode 4 State of Charge Starts At'),ev(ce,'Mode 4 State of Charge Ends At'),ev(ce,'Mode 4 Duration')]}
 f['range']['corroboration']=[ev(cs,'Electric Driving Range km (ADR)'),ev('city-carexpert','Both the EQA 250')]
 f['seats']['corroboration']=[ev(cg,'Body Type')]
 f['motorPower']['corroboration']=[ev(cg,'Maximum power')]
 conflicts=[]
 if model=='eqa':
  conflicts.append({'fields':['length','width','height'],'selectedSource':ce,'selected':[4463,1834,1620],'alternatives':[{'sourceId':cg,'values':[4463,1834,1624]},{'sourceId':cs,'values':[4465,1849,1622]}],'unit':'mm','decision':'Retain exact CarExpert values as Reported with explicit conflict; no geometry can be called maker-confirmed. Use one coherent source set rather than blend dimensions.'})
  strength={'text':'Five seats and a reported 578 km NEDC range in a 4,463 mm-long body','dependsOn':['seats','range','length'],'scope':'Exact City Edition secondary evidence; NEDC and disputed length remain labelled.'}
  tradeoff={'text':'Reported boot space is 340 L with the rear seats up, and DC charging peaks at 100 kW','dependsOn':['bootVolume','dcPeak'],'scope':'Exact City Edition secondary evidence; boot measured by VDA to the lower window.'}
 else:
  f['price']['note']+=' The selected configuration explicitly says discontinued September 2026. It is a reported guide price for that configuration, not evidence of current factory-order availability.'
  conflicts.extend([
   {'fields':['price'],'selectedSource':cg,'selected':86300,'unit':'AUD','basis':'reported_guide_msrp_excludes_stamp_duty_other_government_charges_options','alternatives':[{'sourceId':'city-launch-guide','value':85400,'sourceDate':'2025-07-01','basis':'before_on_road_costs'},{'sourceId':'city-clearlease','value':85400,'sourceDate':'campaign_from_July_2025'},{'sourceId':cs,'value':85400,'basis':'price_when_new'}],'decision':'Use the latest named guide figure only with its discontinued-configuration warning. Retain launch and campaign prices; do not infer an actual transaction price or calculate tax treatment.'},
   {'fields':['range'],'selected':564,'basis':'NEDC','selectedSource':'city-launch-guide','alternatives':[{'sourceId':cg,'value':415,'basis':'not_stated'}],'decision':'Do not reconcile by changing cycles or treating 415 km as WLTP. The explicit NEDC source remains the selected Reported measure.'},
   {'fields':['length','width','height'],'selectedSource':ce,'selected':[4684,1834,1667],'alternatives':[{'sourceId':cg,'values':[4684,1834,1695]},{'sourceId':cs,'values':[4687,1834,1703]}],'unit':'mm','decision':'Retain exact CarExpert dimensions as Reported; conflicts unresolved. No averaging.'},
   {'fields':['bootVolume'],'selected':130,'selectedSource':ce,'basis':'VDA_rear_seats_up_to_lower_window','alternative':{'sourceId':cs,'value':495,'basis':'minimum_load_space_seating_position_and_method_not_stated'},'decision':'495 L is not admitted as all-seven-seats-up boot volume; never label it VDA or all seats upright.'}
  ])
  strength={'text':'The reported seven-seat layout gives flexibility for extra passengers','dependsOn':['seats'],'scope':'Exact City Edition secondary evidence; no space or adult-comfort claim.'}
  tradeoff={'text':'With all seven seats in use, reported VDA luggage space is only 130 L','dependsOn':['seats','bootVolume'],'scope':'CarExpert exact City configuration, rear seats up to the lower window.'}
 variants.append({'identity':{'make':'Mercedes-Benz','model':model.upper(),'version':'250+ City Edition','separateFromBaseGrade':True},'availabilityCaveat':{'detailedStateLimit':'current_or_order_listed','basis':'Ringwood live retailer campaign names the edition; no physical-unit assertion and no evidence that factory orders are accepted. Parent owns availability and family closure.','sourceId':'city-ringwood','conflict':('Exact CarsGuide 2026 configuration says Discontinued Sep 2026. Keep this separate from live retailer campaign and historic 2025 supply.' if model=='eqb' else 'Historical City launch and current retailer campaign do not close the full current maker version list.')},'coreFacts':f,'sourceConflicts':conflicts,'strength':strength,'tradeoff':tradeoff,'coverage':{'coreFields':15,'reportedNumericOrCategoricalFields':15,'confirmedFields':0,'rankingEligibleFields':0,'validatedDC10To80TimePresent':False,'unresolvedSubfields':['gross_battery_capacity','dc_time_with_validated_10_80_window'],'reasonNoConfirmed':'No captured current Australian maker material ties these technical fields to the exact City Edition. Secondary exact-grade facts are preserved rather than withheld.'}})
result={'schema':'roadmark-m1-research-city-editions-v1','checkedDate':D,'scope':'Research normalization only; no repository edits, tests, hydration, browser, cloud tasks, accounts, forms or leads. Warranty, census and final availability are parent-owned.','selectedFactPolicy':'All selected facts are secondary exact-grade Reported and unranked. Numeric DC duration without a verified window does not satisfy strict DC 10–80% coverage. No generic-grade price/equipment transfer.','sources':source_rows,'variants':variants,'unadmittedEvidence':[{'source':'EVC State of EVs 2025, October report','url':'https://electricvehiclecouncil.com.au/wp-content/uploads/2025/10/State-of-EVs_2025_141025-2.pdf','reason':'Web open failed because 20,840,910-byte PDF exceeds tool limit; parent explicitly prohibited whole-market PDF fetch in current slot. Search excerpts mention 35 min and 10–80% for City Editions, but no raw PDF reviewed; do not silently use them to close the charging-window gap.','failureCapture':str(P/'evc-web-open-failure.json'),'discoveryCapture':str(P/'dc-window-search.json')},{'sourceId':'maker-ev-guide','reason':'Generic EQA 250+ and EQB 250+ maker guide is context only; not proof of current exact City technical configuration.'},{'sourceId':'city-clearlease','reason':'Weekly finance examples, fleet discounts, tax assertions and campaign stock wording are not used as technical or new-vehicle transaction prices.'}],'validation':{'rawHashesVerified':all(s.get('sha256Verified') for s in source_rows),'sourceCount':len(source_rows),'coreFactsPerVariant':{v['identity']['model']:len(v['coreFacts']) for v in variants}}}
(P/'normalized-city-editions.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
(P/'sources.json').write_text(json.dumps(source_rows,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(result['validation']))
