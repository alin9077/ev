# Mercedes EQA / EQB City Edition evidence

Checked 14 October 2026. Research-only output; no repository source changes or tests.

## Main result

`normalized-city-editions.json` contains 15 non-warranty core fields for each separate City Edition identity, with source IDs, raw hashes, extracted-text line locators, measurement bases and conflicts. `sources.json` contains the 16-source manifest. All raw-source hashes were verified locally. The accompanying captures include successful public HTTP responses and the failed EVC PDF web open.

All selected values are **Reported and unranked**. The charging-time number is preserved, but the strict 10–80% field remains unresolved for both models. Gross battery capacity is Not published after the exact City CarExpert and carsales sources were checked. No value is inherited from a base grade as Confirmed.

| Field | EQA 250+ City Edition | EQB 250+ City Edition |
|---|---|---|
| Guide price | A$80,700 | A$86,300 |
| Explicit historical before-on-road launch price | A$80,700, July 2025 | A$85,400, July 2025 |
| Range | 578 km NEDC | 564 km NEDC |
| Battery | 70.5 kWh usable | 70.5 kWh usable |
| DC peak | 100 kW | 100 kW |
| DC duration | 35 min, window not supplied | 32 min, window not supplied |
| Validated 10–80% time | Not published / unresolved | Not published / unresolved |
| AC maximum | 11 kW | 11 kW |
| Seats | 5 | 7 |
| Rear-seat-up boot, VDA to lower window | 340 L | 130 L |
| 0–100 km/h | 8.6 s | 8.9 s |
| Motor power / drive | 140 kW / FWD | 140 kW / FWD |
| Selected coherent CarExpert dimensions | 4463 × 1834 × 1620 mm | 4684 × 1834 × 1667 mm |
| Braked towing | 750 kg | 750 kg |

The guide-price footer excludes stamp duty, other government charges and options. That wording does **not** establish exclusion of every on-road charge. Both selected guide prices retain their literal basis and have no price ranking group. They must remain separate from the explicitly before-on-road 2025 news prices.

## Material conflicts

1. The exact 2026 CarsGuide EQB City configuration says **Discontinued Sep 2026**. Ringwood's live retailer campaign names both City Editions but is undated and does not prove physical stock or accepted factory orders. Final availability and family closure remain with the parent.
2. Current EQB guide price A$86,300 differs from the July 2025 launch's A$85,400. Do not infer current supply or a transaction price from either.
3. EQB CarsGuide reports 415 km with no stated cycle, while the exact launch article explicitly reports 564 km NEDC. Do not relabel 415 km as WLTP.
4. Exact-source dimensions disagree. EQA: CarExpert 4463/1834/1620 mm; CarsGuide 4463/1834/1624; carsales 4465/1849/1622. EQB: CarExpert 4684/1834/1667; CarsGuide 4684/1834/1695; carsales 4687/1834/1703. No averaging or maker-confirmed claim.
5. EQB carsales gives 495 L minimum load volume without seating-row position or measuring method. It is not admitted as all-seven-seats-up volume. CarExpert explicitly gives 130 L rear-seats-up VDA and a 2+3+2 configuration.
6. CarExpert provides a 10–80% window and unitless duration 0.58. carsales supplies 35 min EQA and 32 min EQB but no window. The captures are kept separate; no conversion or merging. EVC search excerpts mention 35 min / 10–80%, but the raw 20.8 MB PDF was not reviewed and was not fetched under the parent's large-scan restriction.

## Source-scoped buyer text

EQA strength: Five seats and a reported 578 km NEDC range in a 4,463 mm-long body

EQA trade-off: Reported boot space is 340 L with the rear seats up, and DC charging peaks at 100 kW

EQB strength: The reported seven-seat layout gives flexibility for extra passengers

EQB trade-off: With all seven seats in use, reported VDA luggage space is only 130 L

These statements depend only on the selected secondary facts. They carry no market-wide superlative, tax advice, equipment transfer or physical-stock claim.
