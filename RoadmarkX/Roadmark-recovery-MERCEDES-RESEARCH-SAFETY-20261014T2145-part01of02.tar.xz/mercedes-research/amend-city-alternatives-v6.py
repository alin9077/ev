"""Research-only amendment surfacing separately scoped City alternatives."""
import json,copy,hashlib
from pathlib import Path
R=Path('/tmp/mercedes-research');p=R/'normalized-evidence-v5.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p):return dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
def write(p,x):
 assert not p.exists();p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');return pin(p)
assert sha(p)=='9a16d4b8648710bdd32f082bdb622b75e9f950507eb738d3ad3fc7d408d19b90'
a=json.loads(p.read_text());b=copy.deepcopy(a);changes=[]
for v in b['variants']:
 if 'city_edition' not in v['id']:continue
 prefix='eqa' if 'eqa_city' in v['id'] else 'eqb'
 for f in v['facts']:
  old=copy.deepcopy(f)
  if f['key']=='price_aud':
   selected='80,700' if prefix=='eqa' else '86,300'; ce='81,600' if prefix=='eqa' else '86,300'; cs='80,700' if prefix=='eqa' else '85,400'
   f['qualifications'] += [f'Selected: the 2026 CarsGuide configuration reports A${selected}, with stamp duty, other government charges and options excluded. This named guide amount is retained with that literal basis; it is not presented as a transaction offer.',f'Alternative: CarExpert’s exact City record reports prices starting at A${ce} before on-road costs. Its heading is 2025 and its release date is 3 January 2026. '+('This amount differs from the selected CarsGuide amount.' if prefix=='eqa' else 'Its amount matches CarsGuide, but its before-on-road-costs basis is different and is not transferred to the selected guide price.'),f'Historical alternative: the exact 2025 Carsales record gives Price when new A${cs} beside Price Guide (base price incl GST & LCT). That published tax wording is retained without deriving tax components, on-road treatment or a current price.',f'Historical launch reporting dated 1 July 2025 lists A${cs} before on-road costs. No arithmetic reconciliation, sibling-price transfer or claim of agreement across different price bases is made.']
   f['sourceKeys']=list(dict.fromkeys(f['sourceKeys']+[prefix+'-exact-carexpert-linked',prefix+'-exact-carsales','city-launch-guide']))
  elif f['key']=='range_km' and prefix=='eqb':
   f['qualifications'].append('The selected 564 km is explicitly NEDC in July 2025 City launch reporting. The exact 2026 CarsGuide record separately states 415 km without a test cycle. It is not relabelled WLTP, reconciled with NEDC or substituted for the selected published cycle.')
   f['sourceKeys']=list(dict.fromkeys(f['sourceKeys']+['eqb-exact-guide']))
  elif f['key']=='boot_l':
   f['qualifications'].append('CarExpert’s selected 340 L is VDA luggage volume with the rear seats up to the lower window in its five-seat configuration. Carsales’s 2025 record independently lists 340 L minimum without publishing that measurement method; the matching number does not establish a shared protocol.' if prefix=='eqa' else 'CarExpert’s selected 130 L is VDA luggage volume with the rear seats up to the lower window in its 2+3+2 seven-seat configuration. Carsales’s 2025 record separately gives 495 L minimum without identifying the seating-row position or measurement method. The 495 L is not treated as all-seven-seats-up cargo or VDA.')
   f['sourceKeys']=list(dict.fromkeys(f['sourceKeys']+[prefix+'-exact-carsales']))
  if f!=old:changes.append(dict(variantId=v['id'],key=f['key'],before=old,after=copy.deepcopy(f)))
b['revision']={'supersedes':str(p),'supersededSha256':sha(p),'reason':'Batch the remaining exact City source alternatives into buyer-visible qualifications: guide, CarExpert and Carsales price amounts and distinct bases; EQB unknown-cycle range; separately scoped Carsales cargo. Selected values, grades, bases, comparison eligibility and every source record remain unchanged.','factQualificationOrSupportingReferenceChanges':len(changes),'availabilityProjectionRequirement':a['revision']['availabilityProjectionRequirement']}
c=copy.deepcopy(b)
for v in c['variants']:
 for f in v['facts']:
  orig=next((x['before'] for x in changes if x['variantId']==v['id'] and x['key']==f['key']),None)
  if orig is not None:f.clear();f.update(orig)
c['revision']=a['revision'];assert c==a
out=write(R/'normalized-evidence-v6.json',b)
ap=R/'current-auxiliary-consistency-audit-v5.json';audit=json.loads(ap.read_text());audit['normalized']=out;audit['revision']={'supersedes':pin(ap),'reason':'Rebind unchanged accepted-before fact dispositions and summary guards to v6. This amendment affects only buyer qualifications/support for the two new City identities; all 245 before entries and seven summary guards are unchanged.'}; ar=write(R/'current-auxiliary-consistency-audit-v6.json',audit)
diff=write(R/'normalized-evidence-v5-to-v6-diff.json',{'before':pin(p),'after':out,'changes':changes,'metadataChanges':['revision'],'audit':ar})
print(json.dumps({'normalized':out,'audit':ar,'diff':diff,'changedFacts':len(changes)},indent=2))
