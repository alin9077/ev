"""Research-only JSON amendment and audit; no repo, packet or production execution."""
import copy, hashlib, json
from collections import Counter
from pathlib import Path
ROOT=Path('/tmp/mercedes-research')
PREV=ROOT/'normalized-evidence-v3.json'
BEFORE=Path('/tmp/mercedes-staging-plan/baseline-preparation/extractions/baseline-v2/selected-complete-before-cars.json')
ACCEPT=Path('/tmp/mercedes-staging-plan/baseline-preparation/reviews/baseline-v2-output-acceptance.json')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def objsha(x): return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def pin(p): return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
def write(p,x):
 assert not p.exists(),p
 p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
 return pin(p)
assert sha(PREV)=='946154a7da104056ea3368d137b78735324faf26164e64caec73eafc5c562ece'
assert sha(ACCEPT)=='feb366eb9b3f35f99a07000c5e05c3fcbf406b15aee2330aa00f31a3bfe3e7a8'
a=json.loads(PREV.read_text()); b=copy.deepcopy(a); before=json.loads(BEFORE.read_text())
old={c['id']:c for c in before}; changes=[]
for v in b['variants']:
 facts={f['key']:f for f in v['facts']}; tourer='evito_tourer' in v['id']; eqs=v['model']=='EQS'; city='city_edition' in v['id']
 warranty=facts['warranty']; battery=facts['battery_warranty']; metric='SOHC' if eqs else 'SOCE'
 term_rows=[
  ('warranty_years',5,'years','Vehicle warranty duration','Private-use vehicle warranty duration' if not tourer else 'Vehicle warranty duration; whichever occurs first with 250,000 km',warranty),
  ('warranty_km',250000 if tourer else 'Unlimited','km','Vehicle warranty distance','Vehicle warranty distance; whichever occurs first with 5 years' if tourer else 'Private-use vehicle warranty distance; 5-year duration applies',warranty),
  ('battery_warranty_years',10 if eqs else 8,'years','Battery warranty duration','High-voltage battery duration; whichever occurs first with the published distance limit',battery),
  ('battery_warranty_km',250000 if eqs else 160000,'km','Battery warranty distance','High-voltage battery distance; whichever occurs first with the published duration',battery),
  ('battery_retention_pct',None if tourer else 70,'%' if tourer else '% '+metric,'Battery retention remedy threshold','Capacity-retention threshold not published in the checked Tourer sources' if tourer else 'Remedy trigger below 70% '+metric+' during eligible high-voltage battery coverage',battery),
 ]
 for key,value,unit,label,basis,core in term_rows:
  assert key not in facts
  f={'key':key,'label':label,'value':value,'unit':unit,'sourceKeys':copy.deepcopy(core['sourceKeys']),'grade':'not_published' if value is None else 'confirmed','basis':basis,'comparison':'','rankingEligible':False,'evidenceScope':'searched_not_found' if value is None else 'brand_au_terms','qualifications':copy.deepcopy(core.get('qualifications',[]))}
  if value is None:
   f['reason']='The current Australian eVito/eVito Tourer warranty page and current Tourer model overview were both checked and publish 8 years / 160,000 km, but neither publishes a capacity-retention percentage. No passenger-car retention threshold is transferred.'
  else:
   f['reason']='Current Australian manufacturer warranty terms expressly cover this named family; this auxiliary field preserves the same eligibility and commencement conditions as the reviewed warranty statement.'
  if key.startswith('battery_') and not tourer:
   f['qualifications'].append('Retention uses '+metric+' as named in the October 2026 certificate, not an interchangeable generic state-of-health metric. Owner charging, use, maintenance and software obligations apply; statutory rights remain additional.')
  if key in ['warranty_years','warranty_km'] and not tourer:
   f['qualifications'].append('Private-use terms shown. The separate commercial vehicle limit is 5 years / 200,000 km, whichever occurs first; battery terms are separately governed by their certificate.')
  v['facts'].append(f); changes.append({'variantId':v['id'],'action':'add_current_auxiliary_fact','key':key,'after':copy.deepcopy(f)})
 # Current table witnesses replace current-looking obsolete canonical-null prose.
 if v['id'] in old:
  for key in ['attributed_ac_table_kw','attributed_dc_table_kw']:
   if key not in old[v['id']]['facts']: continue
   target='ac_kw' if key=='attributed_ac_table_kw' else 'dc_peak_kw'; core=facts[target]
   f=copy.deepcopy(core);f['key']=key;f['label']='Manufacturer AC table claim' if target=='ac_kw' else 'Manufacturer DC table claim'
   f['unit']='kW';f['basis']='Attributed exact Australian technical-table '+('AC' if target=='ac_kw' else 'DC')+' input claim';f['comparison']='';f['rankingEligible']=False
   f['qualifications']=copy.deepcopy(core.get('qualifications',[]))+['Supplementary attribution of the same published table value shown in '+target+'. This row is not a separate resolved hardware capability or a second comparable measurement.']
   if core['grade']=='confirmed':
    f['reason']='The exact CLA 350 Australian technical table publishes 11 kW AC. A selected CLA 200 equipment disagreement is not transferred to this different exact grade.'
   else:
    f['reason']='The current maker technical-table value is displayed with its specific unresolved source disagreement, matching the current core field.'
   v['facts'].append(f);changes.append({'variantId':v['id'],'action':'add_current_auxiliary_fact','key':key,'after':copy.deepcopy(f)})
 # Remove obsolete framing that described a now freshly captured maker disagreement only as secondary.
 if 'glb_electric' in v['id']:
  f=facts['ac_kw'];q=copy.deepcopy(f['qualifications'])
  f['qualifications']=['The current maker technical table gives 11 kW and its current family equipment text advertises 22 kW. Exact selected-grade hardware applicability remains unresolved; no optional charger is invented. Historical exact-grade witnesses retain their original scope and missing-raw limitation in the condition.']
  changes.append({'variantId':v['id'],'action':'refresh_current_qualification','key':'ac_kw','before':q,'after':copy.deepcopy(f['qualifications'])})
  # Attributed copy gets the same current qualification, retaining its separate supplementary sentence.
  f2=next(f for f in v['facts'] if f['key']=='attributed_ac_table_kw')
  f2['qualifications']=copy.deepcopy(f['qualifications'])+[f2['qualifications'][-1]]
  next(x for x in changes if x.get('variantId')==v['id'] and x.get('key')=='attributed_ac_table_kw')['after']=copy.deepcopy(f2)
assert sum(len(v['facts']) for v in b['variants'])==258
# Every original before object is accounted for, including unchanged unresolved research.
new={v['id']:v for v in b['variants']}; audit=[]
for c in before:
 refreshed={f['key']:f for f in new[c['id']]['facts']}
 for key,f in c['facts'].items():
  if key in refreshed: disposition='dated_guarded_current_overlay';reason='The exact accepted before object must be guarded unchanged; the new fact replaces its current display.'
  elif key=='manufacturer_model_code':
   disposition='retain_historical_identity_unchanged';reason='Retain the accepted October 10 maker observation and its original sources/date. This is excluded from newly reviewed or freshly captured fact claims.'
   if 'glb_350' in c['id']: reason+=' Fresh GLB material does not decode 2446442_AU1; no fresh-source attribution is asserted.'
  else:
   assert f['value'] is None,(c['id'],key)
   disposition='retain_dated_unresolved_research_unchanged';reason='No non-null current claim conflicts with this separately scoped unresolved auxiliary field. This amendment does not represent a fresh search or make it Not published.'
   if key=='roadside_assistance':reason+=' Old generic warranty qualifications remain dated historical context; they do not establish roadside coverage or override current scoped warranty facts. Current coverage projections are separately checked during staging.'
  audit.append({'variantId':c['id'],'key':key,'disposition':disposition,'reason':reason,'beforePointer':'/'+str(before.index(c))+'/facts/'+key,'beforeObjectSha256':objsha(f),'originalValue':f['value'],'originalDate':f['date'],'originalSourceIds':f['sourceIds'],'newFactKey':key if key in refreshed else None})
assert len(audit)==245
summaries=[{'variantId':c['id'],'beforeObjectSha256':objsha(c['buyerSummary']),'action':'replace_whole_summary','newSummary':copy.deepcopy(new[c['id']]['summary']),'reason':'Production summaryFor constructs a new summary; applyBrandUpdates replaces buyerSummary. No old strength, tradeoff, conditions, freshness or source guard is merged.'} for c in before]
b['status']='Frozen research candidate for independent exact-artifact review. Eleven identities, 17 core-field slots each, plus scoped auxiliary facts. Accepted before extraction is separately pinned; no packet assembly, source edit or registration has occurred.'
b['revision']={'supersedes':str(PREV),'supersededSha256':sha(PREV),'reason':'One batch consistency amendment: 55 scoped current warranty auxiliary facts, seven current attributed charging-table facts, and two GLB current-source qualification clarifications. All original before objects and historical observations remain immutable.','addedFacts':62,'existingFactQualificationsChanged':2,'sourceValuesChanged':False,'availabilityChanged':False,'summariesChanged':False}
# Enforce all prior values and everything except declared fields unchanged.
check=copy.deepcopy(b)
for v in check['variants']:
 orig=next(x for x in a['variants'] if x['id']==v['id']);n=len(orig['facts']);v['facts']=v['facts'][:n]
 if 'glb_electric' in v['id']:
  next(f for f in v['facts'] if f['key']=='ac_kw')['qualifications']=copy.deepcopy(next(f for f in orig['facts'] if f['key']=='ac_kw')['qualifications'])
check['status']=a['status'];check['revision']=a['revision'];assert check==a
out=write(ROOT/'normalized-evidence-v4.json',b)
report={'status':'static_research_consistency_audit_pending_independent_review','asOf':b['asOf'],'normalized':out,'priorNormalized':pin(PREV),'acceptedBeforeCars':pin(BEFORE),'baselineOutputAcceptance':pin(ACCEPT),'hashConvention':'SHA256 of UTF-8 JSON with sorted keys, compact separators and ensure_ascii=false; original file pin is also retained.','counts':dict(Counter(x['disposition'] for x in audit)),'everyAcceptedBeforeFactAccountedFor':len(audit)==245,'beforeFacts':audit,'summaries':summaries,'currentSharedTerms':{'brandTermsInNormalized':b.get('brandTerms',{}),'action':'No new shared terms; explicit per-variant warranty facts preserve passenger, EQS, G580, City eligibility and Tourer differences. Existing shared-term projection ordering and absence of reintroduced stale text must be checked in the actual consumer run.'},'currentFactSupportCounts':{'facts':258,'directSources':len({k for v in b['variants'] for f in v['facts'] for k in f['sourceKeys']}),'newAuxiliaryFacts':62},'requiredConsumerChecks':['All seven retained manufacturer_model_code objects retain exact unchanged object hashes and historical dates/sources; GLB350 is not newly decoded.','All five warranty auxiliary fields agree with each current scoped core warranty statement; Unlimited renders as a string and remains unranked.','No newly overlaid charging fact says canonical null. CLA350 attributed AC is Confirmed 11 without default CLA200 conflict transfer.','Current GLB battery auxiliaries are 8 years / 160000 km / 70% SOCE, not unknown.','Tourer battery retention remains Not published after two named maker sources; no passenger 70% inheritance.','No old buyerSummary clause or condition survives complete replacement.','Shared-term projections do not reintroduce obsolete GLB omission, generic SoH, or old canonical-null wording after the overlay.','Every unmodified auxiliary fact, all historical sources and original before objects remain byte-for-byte or structural-value unchanged as applicable.','City reported DC durations still do not satisfy strict 10–80 coverage.'],'originalDataEdited':False,'packetAssembled':False}
r=write(ROOT/'current-auxiliary-consistency-audit-v4.json',report)
diff=write(ROOT/'normalized-evidence-v3-to-v4-diff.json',{'before':pin(PREV),'after':out,'changes':changes,'metadataChanges':['status','revision'],'audit':r})
print(json.dumps({'normalized':out,'audit':r,'diff':diff,'counts':report['counts']},indent=2))
