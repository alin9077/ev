import fs from 'node:fs';
import assert from 'node:assert/strict';
import {factClaim,featureClaim} from '../roadmark-104/src/lib/citable.ts';
import {formatFact} from '../roadmark-104/src/lib/compare.ts';
import type {Pack} from '../roadmark-104/src/lib/types.ts';
const root='/workspace/scratch/586427eef9f2/roadmark-104-qa';
const packs=JSON.parse(fs.readFileSync(`${root}/hyundai-reviewed-stage-packs.json`,'utf8')) as Record<string,Pack>;
let facts=0,features=0;
for(const pack of Object.values(packs)) {
 const sources=new Map(pack.sources.map(s=>[s.id,s]));
 for(const f of Object.values(pack.car.facts).filter(f=>f.gradeReview?.overlayId==='m1-hyundai-2026-10-14')) {
  const c=factClaim(pack,f,'2026-10-14');
  assert.equal(c.value,f.buyerGrade==='not_published'?'Not published':formatFact(f,'2026-10-14'));
  assert.equal(c.basis,f.basis);assert.equal(c.status,f.status);assert.equal(c.evidenceDate,f.date);assert.equal(c.validUntil,f.validUntil);
  assert.deepEqual(c.priceEvidence,f.priceEvidence);assert.deepEqual(c.gradeReview,f.gradeReview);
  assert.deepEqual(c.sources.map(s=>s.url),f.sourceIds.map(i=>sources.get(i)!.url));facts++;
 }
 for(const f of pack.features.filter(f=>f.gradeReview?.overlayId==='m1-hyundai-2026-10-14')) {
  const c=featureClaim(pack,f.criterion,f.criterion,'2026-10-14')!;
  assert.equal(c.value,String(f.value));assert.equal(c.status,f.status);assert.equal(c.evidenceDate,f.last_evidence_date);assert.equal(c.validUntil,f.validUntil);
  assert.deepEqual(c.gradeReview,f.gradeReview);assert.deepEqual(c.sources.map(s=>s.url),f.source_ids.map(i=>sources.get(i)!.url));features++;
 }
}
console.log(JSON.stringify({facts,features,exactFormattedValues:true,statuses:true,evidenceDates:true,offerDeadlines:true,priceEvidence:true,sourceUrls:true,gradeReviews:true}));
