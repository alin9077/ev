import fs from 'node:fs';
import assert from 'node:assert/strict';
import {catalogue,research,pack,effectiveFeatures} from '../roadmark-104/src/lib/data.ts';
import {applyBrandUpdates,prepareBrandResearch,applyBrandFeatureUpdates,applyBrandTermFeatures,type BrandUpdatePacket} from '../roadmark-104/src/lib/brand-updates.ts';
import {factClaim,featureClaim} from '../roadmark-104/src/lib/citable.ts';
import {loadReportInput} from '../roadmark-104/scripts/reporting/load.ts';
import {buildCoverageReport,coreFacts} from '../roadmark-104/scripts/reporting/reports.ts';
import {combineM1Reconciliations} from '../roadmark-104/scripts/reporting/m1-reconciliation.ts';
import {storePortablePacks,hydratePortablePacks} from '../roadmark-104/src/lib/portable-packs.ts';
import {compiledSource} from '../roadmark-104/tests/helpers/compiled-source.ts';
import {brandUpdatePackets} from '../roadmark-104/src/lib/brand-update-registry.ts';
const root='/workspace/scratch/586427eef9f2/roadmark-104-qa';
const path=process.argv[2] || '/tmp/hyundai-research/hyundai-2026-10-14.json';
const reconPath=process.argv[3] || '/tmp/hyundai-research/hyundai-reconciliation-2026-10-14.json';
const p=JSON.parse(fs.readFileSync(path,'utf8')) as BrandUpdatePacket;
const old=research(), before=catalogue();
const immutableOld=structuredClone(old), immutableBefore=structuredClone(before), immutablePacket=structuredClone(p);
assert(!brandUpdatePackets.some(o=>o.id===p.id),'Packet already registered; use clean pre-packet branch');
const prepared=prepareBrandResearch(old,[p]);
const after=applyBrandUpdates(before,prepared,[p]);
const stagedData=compiledSource('src/lib/data.ts',{'./brand-update-registry':{brandUpdatePackets:[...brandUpdatePackets,p]}}) as {pack:typeof pack};
const built: Record<string,ReturnType<typeof pack>>={};
const newFeatureBaselines: unknown[]=[];
let claims=0,features=0,offers=0;
for(const car of after.filter(c=>c.brand===p.brand&&['passenger','ute'].includes(c.vehicleClass||'passenger'))) {
 const original=before.find(c=>c.id===car.id);
 const starting=effectiveFeatures(original||car,original?old:prepared);
 if(!original)newFeatureBaselines.push(...starting);
 const final=applyBrandTermFeatures(car,applyBrandFeatureUpdates(car,starting,prepared,[p]));
 for(const def of coreFacts)assert.equal(car.facts[def.key]?.gradeReview?.overlayId,p.id,`${car.id} ${def.key} not freshly reviewed`);
 const base=stagedData.pack(car.id,{data:prepared,cars:after});
 assert.deepEqual(base.features,final,`${car.id} real registered pack path differs from explicit staged replay`);
 const ids=new Set([...base.sources.map(s=>s.id),...final.flatMap(f=>f.source_ids)]);
 const view={...base,features:final,sources:prepared.sources.filter(s=>ids.has(s.id))};built[car.id]=view;
 const offer=car.facts.price_aud?.comparisonBasis==='Driveaway' ? car.facts.price_aud : car.facts.promotional_driveaway_aud;
 if(offer?.gradeReview?.overlayId===p.id&&offer.value!==null){
   const f=final.find(f=>f.criterion==='driveaway_price')!;
   assert.deepEqual(f.source_ids,offer.sourceIds);
   assert.deepEqual(f.gradeReview,offer.gradeReview);
   assert.equal(f.buyerGrade,offer.buyerGrade);
   if(offer.validUntil)assert.equal(f.validUntil,offer.validUntil,`${car.id} projected offer deadline metadata`);
   const claim=featureClaim(view,'driveaway_price','Driveaway price')!;
   assert.deepEqual(claim.sources.map(s=>s.id),offer.sourceIds);
   if(offer.validUntil){
     assert.equal(claim.validUntil,offer.validUntil);
     const expires=featureClaim(view,'driveaway_price','Driveaway price',offer.validUntil)!;
     const next=new Date(`${offer.validUntil}T00:00:00Z`);next.setUTCDate(next.getUTCDate()+1);
     const expired=featureClaim(view,'driveaway_price','Driveaway price',next.toISOString().slice(0,10))!;
     assert.equal(expired.value,expires.value);
     assert.match(expired.sentence,/expired|ended/i);
   }
   offers++;
 }
 for (const row of p.features?.filter(f=>f.variantId===car.id)??[]) {
   const f=final.find(f=>f.criterion===row.criterion)!;assert.deepEqual(f,row.after);
   const claim=featureClaim(view,f.criterion,f.criterion)!;assert.equal(claim.value,String(f.value));
   assert.deepEqual(claim.gradeReview,f.gradeReview);assert.deepEqual(claim.sources.map(s=>s.id),f.source_ids);features++;
 }
 for(const f of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===p.id)) {
  const claim=factClaim(view,f);assert.equal(claim.buyerGrade,f.buyerGrade);
  assert.deepEqual(claim.gradeReview,f.gradeReview);assert.deepEqual(claim.sources.map(s=>s.id),f.sourceIds);claims++;
 }
}
const hyd=hydratePortablePacks(storePortablePacks(built),prepared.sources);
assert.deepEqual(hyd,built);
assert.deepEqual(old,immutableOld,'original research object mutated');assert.deepEqual(before,immutableBefore,'original catalogue object mutated');assert.deepEqual(p,immutablePacket,'candidate packet object mutated');
assert.deepEqual(old.sources, research().sources);assert.deepEqual(before,catalogue());
assert.deepEqual(after.filter(c=>c.brand!==p.brand||!['passenger','ute'].includes(c.vehicleClass||'passenger')),before.filter(c=>c.brand!==p.brand||!['passenger','ute'].includes(c.vehicleClass||'passenger')));
assert.equal(after.length,before.length+p.variants.length);
const broken=structuredClone(p);broken.facts.find(f=>f.before)!.before!.value='changed';
assert.throws(()=>applyBrandUpdates(before,prepared,[broken]),/before snapshot changed/);
const brokenSource=structuredClone(p);const retained=brokenSource.sources.find(s=>old.sources.some(o=>o.id===s.id));
if(retained){retained.title+=' changed';assert.throws(()=>prepareBrandResearch(old,[brokenSource]),/source snapshot changed/)}
else {const changed=structuredClone(old.sources[0]);changed.title+=' changed';brokenSource.sources.push(changed);assert.throws(()=>prepareBrandResearch(old,[brokenSource]),/source snapshot changed/)}
const brokenIdentity=structuredClone(p);brokenIdentity.versionGuards[0].before.trim+=' changed';
assert.throws(()=>applyBrandUpdates(before,prepared,[brokenIdentity]),/identity|version|snapshot/i);
const brokenAvailability=structuredClone(p);brokenAvailability.availability[0].before.availability='changed';
assert.throws(()=>applyBrandUpdates(before,prepared,[brokenAvailability]),/snapshot|availability/i);
const brokenTerm=structuredClone(p);const term=brokenTerm.brandTerms![0];term.before[term.applicableVariantIds[0]]!.value='changed';
assert.throws(()=>applyBrandUpdates(before,prepared,[brokenTerm]),/before snapshot changed/);
const brokenSummary=structuredClone(p);brokenSummary.summaries[0].strength.dependencies[0].expected.value='changed';
assert.throws(()=>applyBrandUpdates(before,prepared,[brokenSummary]),/dependency changed/);
const brokenFeature=structuredClone(p);
if(brokenFeature.features?.length){
 const row=brokenFeature.features.find(x=>before.some(c=>c.id===x.variantId))!;row.before.conditions+=' changed';
 const c=after.find(c=>c.id===row.variantId)!,b=before.find(c=>c.id===row.variantId)!;
 assert.throws(()=>applyBrandFeatureUpdates(c,effectiveFeatures(b,old),prepared,[brokenFeature]),/before snapshot changed/);
 const dep=structuredClone(p);dep.features![0].dependencies[0].expected.value='changed';
 assert.throws(()=>applyBrandUpdates(before,prepared,[dep]),/dependency changed/);
}
const wholeMissing=p.features?.find(x=>x.after.buyerGrade==='not_published');
if(wholeMissing){
 const missingShape=structuredClone(p);missingShape.features!.find(x=>x.variantId===wholeMissing.variantId&&x.criterion===wholeMissing.criterion)!.after.value='Unknown';
 assert.throws(()=>applyBrandUpdates(before,prepared,[missingShape]),/Not published|grade|feature|evidence/i);
 const missingDependency=structuredClone(p);const row=missingDependency.features!.find(x=>x.variantId===wholeMissing.variantId&&x.criterion===wholeMissing.criterion)!;
 row.dependencies=row.dependencies.filter(d=>d.key!==`feature_${row.criterion}`);
 assert.throws(()=>applyBrandUpdates(before,prepared,[missingDependency]),/dependency|feature|Not published|evidence/i);
}
const missingFact=p.facts.find(x=>x.after.buyerGrade==='not_published');
if(missingFact){
 const falseNull=structuredClone(p);falseNull.facts.find(x=>x.variantId===missingFact.variantId&&x.after.key===missingFact.after.key)!.after.value='Not published';
 assert.throws(()=>applyBrandUpdates(before,prepared,[falseNull]),/grade|Not published|evidence|fact/i);
}
fs.writeFileSync(`${root}/${p.brand.toLowerCase()}-audit-new-feature-baselines.json`,JSON.stringify(newFeatureBaselines,null,2));
fs.writeFileSync(`${root}/${p.brand.toLowerCase()}-reviewed-stage-packs.json`,JSON.stringify(built,null,2));
console.log(JSON.stringify({versions:Object.keys(built).length,citableFacts:claims,reviewedFeatures:features,canonicalOfferProjections:offers,actualPackPipelineMatches:true,portableExactRoundtrip:true,immutableInputObjects:true,allOtherBrandsUnchanged:true,negativeFactSourceIdentityAvailabilityTermFeatureSummaryGuards:true}));
const reconciliation=JSON.parse(fs.readFileSync(reconPath,'utf8'));
const reportInput=loadReportInput();
reportInput.cars=after;reportInput.sources=prepared.sources;
reportInput.features=reportInput.features.filter(f=>!built[f.variant_id]).concat(Object.values(built).flatMap(p=>p.features));
reportInput.m1Reconciliation=combineM1Reconciliations(reportInput.m1Reconciliation!,reconciliation);
const report=buildCoverageReport(reportInput,'2026-10-14');
const brand=report.brandProgress.find(b=>b.brand===p.brand)!;
// A completed research pass need not hit C1–C6 target thresholds.
console.log('BRAND_PROGRESS',JSON.stringify(brand));
for(const k of ['missingSummaries','agedOrInvalidClaims'] as const)assert.equal(brand[k],0,k);
// Preserve unresolved identity review honestly while the exact six-seat advertisement is blocked.
if(brand.missingModels||brand.unresolvedLeads||reconciliation.inventoryResolutions?.some((r:{outcome:string})=>r.outcome==='unresolved'))assert.equal(brand.researchCompleted,false);
assert(brand.closureIssues.some(i=>i.code==='inventory_unresolved'&&i.reference==='record:hyundai-ioniq-9'),'Known residual identity blocker must remain visible');
assert.equal(brand.onSaleVersions,p.versionGuards.length+p.variants.length);
const carIds=Object.keys(built);
const independentReport={brand,gaps:report.gaps.filter(g=>g.brand===p.brand),rankings:report.rankings.map(r=>({key:r.key,brandRanked:r.rankedIds.filter(i=>carIds.includes(i)),groups:r.groups})),note:'Brand-only list review does not establish global C1 closure.'};
fs.writeFileSync(`${root}/${p.brand.toLowerCase()}-independent-stage-report.json`,JSON.stringify(independentReport,null,2));
console.log(JSON.stringify({researchCompleted:brand.researchCompleted,missingModels:brand.missingModels,unresolvedLeads:brand.unresolvedLeads,missingSummaries:brand.missingSummaries,agedOrInvalidClaims:brand.agedOrInvalidClaims,onSaleVersions:brand.onSaleVersions}));
