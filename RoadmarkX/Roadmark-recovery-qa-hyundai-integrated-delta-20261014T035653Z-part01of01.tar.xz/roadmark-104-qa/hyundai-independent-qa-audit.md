# Independent Hyundai M1 review

Reviewed 14 October 2026. **Approved for guarded integration of the 21 established Tier 1 versions at the exact hashes below. Hyundai research is not complete.** The unresolved MY26 six-seat IONIQ 9 advertisement is not admitted by this approval. No Toyota research, M2, publishing or registry edit is part of this review.

## Approved immutable artifacts

| Artifact | SHA-256 |
|---|---|
| `/tmp/hyundai-research/hyundai-2026-10-14.json` | `99d93286d74881a571bd7b544c242bacd486c8800f5c19c8e747bf117f7a0d28` |
| `/tmp/hyundai-research/hyundai-reconciliation-2026-10-14.json` | `aa45114f3aa6fbd7153d5ce87970060a6b0dc6b0de274fb923a610e74f661be4` |

Both hashes matched before and after the successful independent runtime replay. Changes require a new review.

## Scope and unresolved identity

The packet reviews 15 existing passenger versions and adds six separately sourced residual-New configurations: INSTER MY26 Extended Range 49; IONIQ 5 MY25 base 63, DYNAMIQ N Line RWD 84 and EPIQ N Line RWD 84; IONIQ 5 MY26 base RWD 84; and IONIQ 9 MY26 Calligraphy AWD seven-seat. Current factory families are INSTER, KONA Electric, IONIQ 5, IONIQ 5 N, IONIQ 6 N, ELEXIO and IONIQ 9. Formal model year, build year, body, drivetrain, trim, seating and optional packages remain distinct. Optional packages do not inflate the core version count.

Carsales `OAG-AD-25622863` remains unresolved: its indexed MY26 six-seat New description has no verified current original-dealer/stock/VIN match, and the exact page is CAPTCHA-blocked with approval pending. The bounded alternate-source search did not settle it. It is neither included nor labelled sold/absent. The reconciliation deliberately retains `record:hyundai-ioniq-9` as `inventory_unresolved`. The report's `missingModels=0` and `unresolvedLeads=0` do **not** imply closure: `researchCompleted=false` and the explicit inventory closure issue remain visible and are asserted by the reviewer test.

Archived stock URLs and identities were recovered and compared with the family closure records. Demo, Used, Sold, redirects, unavailable and blocked pages remain distinct. The regular IONIQ 6 lead is finitely excluded after disabled/nonselectable maker records and bounded residual checks; this does not assert nationwide absence. STARIA Lounge is hybrid. Both STARIA Load commercial rows and the MIGHTY truck remain unchanged.

## Checks passed

- Read both governing M1 documents fully. Reviewed current AU maker technical tables, configurator captures, warranty/roadside terms, original dealer captures, secondary claims and historical evidence. Independently checked 236 numeric expectations, with 19 visually inspected PDF pages retained among 22 rendered pages.
- Independently froze 630 repository-file hashes and captured the live pre-packet catalogue, sources and 1,242 Hyundai equipment rows with all eight earlier packets applied. Researcher and reviewer before snapshots agree. Six new-version equipment baselines were independently regenerated during final replay.
- Strict complete identity, source, Fact, shared-term, availability, equipment-before and summary/equipment dependency snapshots pass. All 357 core cells are freshly reviewed; the two INSTER null-to-MY27 changes leave no old Confirmed Fact silently carried forward. The completeness audit accounts for all 4,121 inherited non-null facts and known equipment.
- All 282 whole-row missing equipment replacements use exact `Not published`, `not_verified`, earned two-source searches and their own null `feature_<criterion>` dependency. Search captures distinguish a missing claim from failed retrieval. Historical source-feature context remains separate from current availability.
- Actual `src/lib/data.ts` compiled with an in-memory registry override matches the explicit guarded replay. All 5,314 reviewed Facts and 844 direct equipment replacements preserve source/grade dependencies. A further transport check covers all 886 reviewed equipment rows including canonical projections: exact formatted values, statuses, evidence dates, deadlines, price evidence, source URLs and grade reviews pass. Portable storage/hydration is deeply identical.
- All 21 canonical price/offer projections preserve provenance and grading. Published deadlines are tested on the final eligible day and following day: historical amounts remain visible with expiry identified.
- Negative mutations to Fact/source/identity/availability/shared-term/equipment-before guards and summary/equipment dependencies are rejected. Wrong whole-row missing text, missing exact null dependency and a non-null Not-published Fact are rejected. Input objects are deeply unchanged; other brands, lower tiers and their ordering remain identical.
- All 151 packet source snapshots equal the source index. All 300 raw/text locator hash references, 387 source-manifest entries and 34 artifact-manifest entries pass the final hash audit. Failed captures elsewhere in the research archive remain labelled failures and are not evidence of absence.
- All 85 original data files and original supplied files remain byte-identical. The only changed pre-existing files among the 630-file baseline are the parent's authorized README/progress documentation and publication-date separation in `src/lib/citable.ts` and `src/app/glossary/page.tsx`. The associated new metadata/test/backlog files are recorded in `hyundai-final-hash-audit.json`. Thus this review does not falsely claim the entire application was unchanged. The reviewer edited no application, data or registry file.

## Factual qualifications retained

1. **Prices.** Eleven current maker list prices take precedence. IONIQ 5 N, IONIQ 6 N and both MY27 IONIQ 9 configurations use explicitly rendered NSW driveaway estimates at Check: visible MLP excludes separately displayed LCT, and neither component addition nor unexplained PIM values become retail RRP. All six residuals use exact dealer-ad prices at Reported after higher current rungs were searched. IONIQ 9's historical $119,750 launch price remains separate from its current $129,836 advertised total. INSTER/KONA/ELEXIO promotional eligibility and 31 December deadline remain explicit. Supplementary IONIQ 5 NSW calculator observations openly lack full campaign eligibility; they are not called national offers or substituted for canonical RRP. A generated calculator expiry without an actual offer is not a deadline.
2. **Charging and output.** Exact 10–80% windows are preserved: INSTER 30 minutes at a 120 kW station; KONA 43 at 350 kW; IONIQ 5/N and IONIQ 6 N 18 at 350 kW; ELEXIO 38 at 150 kW; IONIQ 9 24 at 350 kW. Station ratings never become vehicle peaks. INSTER/KONA have separately labelled charging-capacity rows; ELEXIO/IONIQ 9 secondary peak claims remain Reported, and nine IONIQ 5/N/6 N peaks remain genuinely unpublished. Generic test/environment/towbar caveats do not automatically downgrade exact maker figures. N normal and temporary boost/launch outputs remain separate; no motor component sums are used.
3. **Cargo and measurement.** ELEXIO's detailed 506 L VDA rear-boot table resolves the generic 504 L teaser, whose discrepancy is retained. IONIQ 9's 338 L behind row three is distinct from 908 L behind row two. KONA's 407 L rear and 27 L front are not summed into rear boot. INSTER/KONA/IONIQ 5/N/6 N VDA minimum figures lack an explicit comparable load state and remain unranked. Unknown methods remain unranked even if a seats-up label exists. No invented usable battery, kerb/payload arithmetic or speculative operating-cost/range values are introduced.
4. **Policy.** Standard vehicle cover is five years/unlimited km; the eligible seven-year service-linked extension is separate and conditional. Battery cover is eight years/160,000 km with the published 70% floor and operating/maintenance conditions. BEV roadside duration is 24 months with qualifying service renewal and exclusions; generic 12-month teasers do not override the EV policy. IONIQ 9 gets its own explicit fact: the published weight limit means included towing is unavailable at its stated kerb weight and recovery can be at the driver's expense, while other roadside benefits remain. N noncompetitive track-day coverage and competition exclusions are separately qualified.
5. **Availability.** Factory listings establish named configurations, not accepted orders. Exact New advertisements establish advertised stock, not physical stock. All six residuals retain unverified factory-order status. Frankston stock 320476710 supports only the exact current base MY27 IONIQ 5 advertised identity, not Elite/Premium stock.

## Honest C1–C6 result

| Criterion | Result | Reason |
|---|---|---|
| C1 | Fail/open | Whole-market two-list closure is unproven, and the specific IONIQ 9 inventory identity remains unresolved |
| C2 | Fail | 336/357 cells filled; DC peak 12/21, acceleration 15/21 and braked towing 15/21 are below 95%; price is 21/21 |
| C3 | Pass | Core split: 292 Confirmed, 4 Check, 40 Reported, 21 Not published, 0 Unreviewed |
| C4 | Pass | All 21 dependency-bound strength/tradeoff pairs are substantive |
| C5 | Fail | Four ranking fields remain below 90%, without forced grades or measurement bases |
| C6 | Pass | Zero aged/invalid claims as of 14 October; source/offer dates retain their actual meaning |

Below-half-Confirmed patterns are DC peak (station ratings, missing vehicle limits and secondary/sibling evidence), seats (dealer declarations where maker totals are not explicit) and acceleration (secondary exact-version figures and genuine gaps). No quota is pursued.

Ranking admission: range 21/21; price 15/21; DC time 21/21; seats 5/21; boot 5/21; towing 15/21. All remaining exclusions and source-specific reasons are in `hyundai-independent-stage-report.json`. `done=false` and `researchCompleted=false` remain intentional.

## Reproduction

From `roadmark-104`, before registering this packet:

```sh
python ../roadmark-104-qa/review-hyundai-packet.py
node --import tsx ../roadmark-104-qa/review-hyundai-importer.ts
node --import tsx ../roadmark-104-qa/review-hyundai-citable-transport.ts
python ../roadmark-104-qa/review-hyundai-hashes.py
```

Final logs: `hyundai-packet-final-review.log`, `hyundai-importer-final-stage.log`, `hyundai-citable-transport.log`, `hyundai-final-hash-audit.log`. Decision: `hyundai-independent-approval.json`. Both replay hash brackets and the independent live/new-feature snapshots are retained. Preliminary notes/logs are historical and superseded by this exact-hash review. This evidence approval does not claim a full application test-suite rerun or remove the pending CAPTCHA authorization requirement.
