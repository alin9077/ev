import pathlib,json,hashlib,sys
R=pathlib.Path('/tmp/hyundai-research');Q=pathlib.Path(__file__).parent;repo=Q.parent/'roadmark-104'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
errors=[]
def ck(ok,msg):
 if not ok:errors.append(msg)
p=json.load(open(R/'hyundai-2026-10-14.json'));idx=json.load(open(R/'source-index.json'))['sources'];rows=[]
ck(len(idx)==len(p['sources']),'source index length')
for a,b in zip(idx,p['sources']):
 a=dict(a);ck(a.pop('packetId',None)==p['id'],'source index packet ID');ck(a==b,'source index snapshot '+b['id'])
 for loc,h in [('capture_locator','capture_sha256'),('capture_text_locator','capture_text_sha256')]:
  if not b.get(loc):continue
  f=R/b[loc];ck(f.is_file(),'missing '+str(f))
  if f.is_file():ck(f.stat().st_size>0 and sha(f)==b[h],'invalid source '+str(f));rows.append({'path':b[loc],'bytes':f.stat().st_size,'sha256':sha(f)})
manifestCounts={}
for name in ['source-hash-manifest.json','artifact-hash-manifest.json']:
 entries=json.load(open(R/name))['files'];manifestCounts[name]=len(entries)
 for e in entries:
  f=R/e['path'];ck(f.is_file(),'missing manifest file '+str(f))
  if f.is_file():ck(f.stat().st_size==e['bytes'] and sha(f)==e['sha256'],'manifest changed '+str(f))
b=json.load(open(Q/'hyundai-immutable-baseline.json'));changed=[];missing=[]
allowed={'README.md','docs/M1_PROGRESS.md','src/lib/citable.ts','src/app/glossary/page.tsx'}
for path,h in b['files'].items():
 f=repo/path
 if not f.is_file():missing.append(path);continue
 if sha(f)!=h:changed.append({'path':path,'before':h,'after':sha(f)})
ck(not missing,'baseline files missing '+str(missing));ck(all(x['path'] in allowed for x in changed),'unexpected original-input change '+str(changed))
data=[path for path in b['files'] if path.startswith('data/')]
ck(all((repo/path).is_file() and sha(repo/path)==b['files'][path] for path in data),'original data changed')
authorizedAdditions=['docs/BACKLOG.md','src/lib/publication-metadata.ts','tests/publication-review-dates.test.ts']
res={'packetSha256':sha(R/'hyundai-2026-10-14.json'),'reconciliationSha256':sha(R/'hyundai-reconciliation-2026-10-14.json'),'sourceSnapshots':len(idx),'sourceHashReferences':len(rows),'manifestCounts':manifestCounts,'baselineFiles':len(b['files']),'originalDataFiles':len(data),'originalDataUnchanged':all((repo/path).is_file() and sha(repo/path)==b['files'][path] for path in data),'knownAuthorizedChanges':changed,'knownAuthorizedAdditions':[{'path':x,'sha256':sha(repo/x)} for x in authorizedAdditions if (repo/x).is_file()],'missing':missing,'errors':errors}
(Q/'hyundai-final-hash-audit.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2));sys.exit(bool(errors))
