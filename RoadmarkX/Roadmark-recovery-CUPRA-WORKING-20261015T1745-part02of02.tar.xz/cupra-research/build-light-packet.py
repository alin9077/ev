import json, pathlib, hashlib, re
R=pathlib.Path('/tmp/cupra-research'); P=pathlib.Path('/tmp/cupra-packet'); S=R/'sources'; checked='2026-10-15'
def put(path,obj): path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
urls={
 'maker-models':'https://www.cupraofficial.com.au/',
 'maker-tavascan':'https://www.cupraofficial.com.au/cars/tavascan',
 'maker-my255':'https://www.cupraofficial.com.au/content/dam/countries/au/cupra-website/travascan/brochure/au-cupra-tavascan-my25-5-brochure-mar-2026.pdf',
 'maker-born':'https://www.cupraofficial.com.au/cars/born',
 'maker-raval':'https://www.cupraofficial.com.au/our-dna/garage/cupra-urbanrebel-concept-car',
 'maker-warranty':'https://www.cupraofficial.com.au/owners/warranty',
 'maker-warranty-terms':'https://www.cupraofficial.com.au/content/dam/countries/au/cupra-website/documents/CUPRA-5-Year-New-Vehicle-Warranty-Terms-and-Conditions-09-24.pdf',
 'maker-roadside':'https://www.cupraofficial.com.au/owners/roadside-assist',
 'maker-roadside-terms':'https://www.cupraofficial.com.au/content/dam/countries/au/cupra-website/documents/CUPRA-Roadside-Assist-Terms-and-Conditions.pdf',
 'maker-chargefox':'https://www.cupraofficial.com.au/shopping/offers/chargefox-tcs',
 'carexpert-my26':'https://www.carexpert.com.au/car-news/cupra-launching-its-cheapest-ev-yet-in-australia-undercutting-tesla-model-y',
 'goauto-my26':'https://www.goauto.com.au/new-models/cupra/tavascan/cheaper-tavascan-broadens-cupra-ev-range/2026-06-30/99713.html',
 'goauto-diary':'https://www.goauto.com.au/new-car-diary/2026.html',
 'zecar-my26':'https://zecar.com/reviews/cupra-tavascan-price-specs',
 'redbook-v':'https://www.redbook.com.au/cars/details/2026-cupra-tavascan-v-auto-my26/SPOT-ITM-696454?Cr=0',
 'redbook-endurance':'https://www.redbook.com.au/cars/details/2026-cupra-tavascan-endurance-auto-my26/SPOT-ITM-696452?Cr=2',
 'redbook-vz':'https://www.redbook.com.au/cars/details/2026-cupra-tavascan-vz-auto-awd-my26/SPOT-ITM-696453?Cr=104',
 'carexpert-born':'https://www.carexpert.com.au/car-news/cupras-first-ev-wont-return-to-australia-any-time-soon',
 'carexpert-tavascan-list':'https://www.carexpert.com.au/cupra/tavascan',
 'goauto-raval':'https://www.goauto.com.au/future-models/cupra/raval/cupra-raval-id-polo-could-get-awd-after-all/2026-05-29/99367.html',
 'recall':'https://www.vehiclerecalls.gov.au/recalls/rec-006687',
 'alto-v':'https://www.alto.com.au/stock/details/OAG-AD-26298148/2026-cupra-tavascan-new',
 'alto-vz':'https://www.alto.com.au/stock/details/OAG-AD-26280028/2026-cupra-tavascan-new',
 'alto-extreme':'https://www.altogroup.com.au/stock/details/OAG-AD-26314648/2026-cupra-tavascan-new',
 'alto-endurance-old':'https://www.alto.com.au/stock/details/OAG-AD-26158631/2025-cupra-tavascan-new',
 'carsguide-v':'https://www.carsguide.com.au/car/15332963/cupra/tavascan/suv'
}
extracts={
 'carexpert-my26':{'published':'2026-06-30','scope':'Australian MY26 announced lineup','grades':['V','Endurance','VZ'],'priceBeforeOrcAud':[55490,66490,75490],'rangeWltpKm':[414,520,509],'batteryKwh':[58,77,77],'batteryBasis':'not explicitly net/gross','chemistry':['LFP','NMC',None],'powerKw':[140,210,250],'drive':['RWD','RWD','AWD'],'dcPeakKw':[105,135,135],'arrival':'Australia August 2026','changes':['10.25-inch instruments','physical steering-wheel buttons','Endurance Interior Package standard','Endurance and VZ launch control'],'extremePackAud':8000,'v2l':'AU availability unconfirmed','onePedalDrive':'AU availability unconfirmed'},
 'goauto-my26':{'published':'2026-06-30','scope':'Australian MY26 announced lineup','grades':['V','Endurance','VZ'],'priceBeforeOrcAud':[55490,66490,75490],'vzExtremePackTotalBeforeOrcAud':83490,'vPowerKw':140,'vBatteryKwh':58,'vChemistry':'LFP','vRangeWltpKm':414,'vDcPeakKw':105,'vDc10to80Minutes':26,'arrival':'first customer deliveries from late August 2026','ordering':'would open ahead of first deliveries; no observed accepted-order transaction'},
 'goauto-diary':{'scope':'October 2026 Australian new-car release diary','model':'Cupra Tavascan - V','release':'August 2026','descriptionScope':'MY26 update','powerKw':140,'batteryKwh':58,'rangeWltpKm':414,'availabilityMeaning':'Reported released; not physical stock or maker order acceptance'},
 'carexpert-born':{'published':'2026-07-28','scope':'Australian product plan, attributed to Cupra Australia product head','born':'no current plans to reintroduce; currently unavailable in Australia','bevFocus':['Tavascan','upcoming Raval'],'ravalTiming':'likely 2027, not a confirmed delivery commitment','limitations':'Does not prove all residual dealer stock exhausted'},
 'carexpert-tavascan-list':{'scope':'current Australian model showroom list','named':['V','Endurance','VZ','VZ Extreme Package'],'identityTreatment':'Extreme Package is an option package, not fourth core grade','priceTreatment':'Do not use V zero-price placeholder or mixed driveaway values'},
 'goauto-raval':{'published':'2026-05-29','scope':'future model report','australianArrival':'2027 reported','localGradesOrOrderAcceptance':'not established'},
 'recall':{'published':'2026-08-05','recall':'REC-006687','campaign':'94S9','model':'Cupra Tavascan','modelYears':'2024–2026','affectedUnits':318,'variantScope':'all variants within affected model set; VIN list determines vehicles','defect':'Calibration can misdirect high beam when advanced full beam assist operates, causing glare','instruction':'Affected drivers should avoid advanced full beam assist until rectified','remedy':'free dealer software update','limitations':'No whole-range stop-driving claim; no specific candidate VIN status or completion inferred'}
}
for grade,slug,battery,ran,power,drive,accel,tow,price in [('V','redbook-v',61,414,140,'RWD',8.6,1000,55490),('Endurance','redbook-endurance',82,520,210,'RWD',6.8,1000,66490),('VZ','redbook-vz',82,509,250,'AWD',5.5,1800,75490)]:
 extracts[slug]={'scope':'2026 CUPRA Tavascan '+grade+' MY26 Australian guide','releaseMonth':'July 2026','priceWhenNewExcludingGovernmentChargesAud':price,'highVoltageBatteryCapacityKwh':battery,'batteryBasis':'not explicitly net/gross','rangeWltpKm':ran,'powerKw':power,'drive':drive,'acceleration0to100Seconds':accel,'lengthMm':4644,'widthMm':1861,'widthMirrorBasis':'not stated in retained guide field','heightMm':1598,'wheelbaseMm':2766,'seats':5,'bootMinLitres':540,'bootMaxLitres':1550,'bootMeasurementProtocol':'not stated','brakedTowingKg':tow,'unbrakedTowingKg':750,'maxTowballKg':75,'fastChargeMinutes':28 if grade=='Endurance' else None,'fastChargeSocWindow':'not stated'}
for slug,facts in extracts.items():
 put(S/(slug+'-facts.json'),{'sourceId':slug,'url':urls[slug],'checkedAt':checked,'captureMethod':'Sanitized factual transcription from public web tool page' if not slug.startswith('redbook') else 'Sanitized factual transcription from public search-indexed exact guide. Direct web open was unavailable; do not describe this as a successful live full-page GET.','facts':facts})
# Narrow inherited audit selection. Avoid unrelated VAG contents or legacy raw snapshots.
oldPath=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104/data/vw-skoda-cupra-evidence-2026-10-10.json')
old=json.loads(oldPath.read_text()); narrow={}
for section in ['records','older_model_year_records','dealer_evidence','model_gaps','held_configuration_records']:
 narrow[section]=[{k:r[k] for k in ['id','make','family','model','grade','trim','model_year','record_role','condition_status','strict_new_exact_trim_usable','status','claim','source_ids'] if k in r} for r in old.get(section,[]) if r.get('make','').lower()=='cupra' or r.get('id','').startswith('cupra')]
put(R/'inherited-audit-extract.json',{'source':str(oldPath),'scope':'CUPRA identity fields only; older evidence is background, not a new check','sections':narrow})
indexPath=pathlib.Path('/tmp/kgm-packet/full-stage-v1/output/car-digest-comparison.json'); index=json.loads(indexPath.read_text())['candidate28']; selected=[r for r in index if re.search('cupra|tavascan|born',r['id'],re.I)]
assert not selected
put(R/'retained-selection-proof.json',{'acceptedIndex':str(indexPath),'indexSha256':hashlib.sha256(indexPath.read_bytes()).hexdigest(),'stage':'candidate28','acceptedRows':len(index),'identitySearch':'case-insensitive CUPRA, Tavascan or Born in exact retained digest IDs','selected':selected,'baselineSelectionPath':str(R/'retained-before-cars.json'),'baselineSelectionMethod':'Prior single-pass line streaming of retained after448/cars.jsonl, checking brand/model/id; no full catalogue hydration','result':'CUPRA has no complete accepted catalogue rows. This is an audit-only addition proposal, not a refresh of existing cars.'})
conflicts=[
 {'id':'my26-battery-basis','fields':['batteryKwh'],'scope':'all three MY26 grades','observations':{'Australian launch reports':[58,77,77],'RedBook exact MY26 high-voltage capacity':[61,82,82]},'disposition':'Show Australian launch-report value as Reported with unknown capacity basis; retain alternatives. No invented gross/usable reconciliation, no battery ranking or battery-dependent derived claim.'},
 {'id':'my26-height','fields':['heightMm'],'scope':'all three MY26 grades','observations':{'Zecar MY26 table':1597,'RedBook exact MY26':1598},'disposition':'Prefer exact MY26 guide figure as Reported, disclose alternate 1597; no authoritative resolution or ranking.'},
 {'id':'my26-v2l','fields':['v2l'],'scope':'Australian MY26','observations':{'CarExpert':'local availability unconfirmed','Zecar':'3.6 kW listed'},'disposition':'Hold positive V2L equipment claim; not a core fact.'},
 {'id':'alto-condition','fields':['stockCondition','physicalStock'],'scope':'specific Alto ads only','observations':['Current MY26 V, VZ and Extreme Pack ads: New category and 10 km','Current MY26 ads retain Demonstrator sale heading; V also has generic AWD prose against structured RWD. Old Endurance conflict is historical only; its exact ad now redirects.'],'disposition':'No clean new-stock or accepted-order proof from these ads. Does not veto MY26 catalogue visibility from release evidence.'}
]
history=[
 {'scope':'MY25.5 Endurance/VZ maker brochure, March 2026','rangeWltpKm':[531,505],'vzExtremeRangeWltpKm':477,'brakedTowingKg':[1000,1200],'batteryKwh':[77,77],'powerKw':[210,250],'dcPeakKw':135,'acKw':11,'lengthMm':4644,'widthExcludingMirrorsMm':1861,'widthIncludingMirrorsMm':2108,'heightMm':1597,'seats':5,'bootSeatsUpLitres':540,'bootFoldedToRoofLitres':1550,'protocol':'boot protocol unstated','disposition':'Preserve dated technical reference; do not relabel MY26 or add duplicate current grades solely because brochure remains linked.'},
 {'scope':'Maker versions-and-equipment page, unscoped older numbers','rangeWltpKm':[534,499],'vzExtremeRangeWltpKm':463,'disposition':'Dated/unscoped observations. Not automatically a present MY26 contradiction.'}
]
warranty={'vehicle':{'years':5,'distance':'unlimited km','grade':'Confirmed','start':'original retail delivery for new vehicles; first Agent registration for demonstrators','conditions':['vehicles sold and used in Australia','required maintenance and proper use','manufacturing-defect coverage and stated exclusions; no extra commercial kilometre cap invented']},'battery':{'years':8,'kilometres':160000,'limit':'whichever first','grade':'Confirmed','capacityTrigger':'below 70% of initial net usable energy capacity, measured by authorised Agent','remedyFloors':[{'years':3,'km':60000,'percent':78},{'years':5,'km':100000,'percent':74},{'years':8,'km':160000,'percent':70}],'conditions':['new or reconditioned replacement components allowed','proper care/charging/maintenance; unapproved modifications, accident-related damage and removed batteries excluded','BEV terms used; PHEV capacity exclusion not inherited']},'roadside':{'years':5,'grade':'Confirmed','start':'warranty start','conditions':'CUPRA Assist eligibility, maintenance, roadworthiness, registration, geography and benefit limits apply; not an unlimited service promise'},'sources':['maker-warranty','maker-warranty-terms','maker-roadside','maker-roadside-terms']}
put(P/'brand-terms.json',warranty)
coreKeys=['price','range','battery','dcPeak','dc10to80','ac','seats','boot','acceleration','power','drive','length','width','height','brakedTowing','vehicleWarranty','batteryWarranty']
def fact(value,unit,source,basis=None,grade='Reported',note=None,conflict=None):
 o={'value':value,'unit':unit,'grade':grade,'sourceIds':source if isinstance(source,list) else [source],'checkedAt':checked,'rankEligible':False}
 if basis:o['basis']=basis
 if note:o['note']=note
 if conflict:o['conflictId']=conflict
 return o
candidates=[]
for grade,slug,price,ran,batt,power,drive,dc,accel,tow in [('V','v',55490,414,58,140,'RWD',105,8.6,1000),('Endurance','endurance',66490,520,77,210,'RWD',135,6.8,1000),('VZ','vz',75490,509,77,250,'AWD',135,5.5,1800)]:
 rb='redbook-'+slug
 core={
 'price':fact(price,'AUD',['carexpert-my26','goauto-my26'],'before_on_road_costs',note='Reputable Australian publication price, ladder rung 5. No offer deducted or driveaway total derived.'),
 'range':fact(ran,'km',['carexpert-my26',rb],'WLTP reported for named MY26 grade',note='Generic laboratory caveat is standing methodology, not a Check downgrade.'),
 'battery':fact(batt,'kWh',['carexpert-my26','zecar-my26'],'published capacity; net/gross not established',conflict='my26-battery-basis'),
 'dcPeak':fact(dc,'kW',['carexpert-my26','zecar-my26'],'maximum DC power'),
 'dc10to80':fact(26 if slug=='v' else None,'minutes',['goauto-my26','zecar-my26'] if slug=='v' else [rb,'zecar-my26'],'DC 10–80% state of charge',grade='Reported' if slug=='v' else 'Not published',note='26-minute 10–80% claim is explicit for V.' if slug=='v' else ('Exact MY26 guide lists 28-minute fast charging without SOC window; Zecar MY26 has no Endurance 10–80 duration. Do not turn 28 minutes into a 10–80 claim.' if slug=='endurance' else 'Exact MY26 guide leaves fast-charge time blank; Zecar MY26 does not give VZ 10–80 duration. Two-source stop.')),
 'ac':fact(11,'kW','zecar-my26','maximum AC power'),
 'seats':fact(5,'seats',rb),
 'boot':fact(540,'L',[rb,'zecar-my26'],'minimum boot / seats-up context; VDA/SAE not published',note='No boot-basis ranking. Maker MY25.5 also lists seats-up 540 L but is retained separately.'),
 'acceleration':fact(accel,'seconds',rb,'0–100 km/h',note='Exact Australian MY26 guide; Zecar calls V 8.6 seconds EU specification and did not confirm local performance at publication.' if slug=='v' else None),
 'power':fact(power,'kW',['carexpert-my26',rb],'combined maximum system power' if slug=='vz' else 'maximum motor power'),
 'drive':fact(drive,None,['carexpert-my26',rb]),
 'length':fact(4644,'mm',[rb,'zecar-my26']),
 'width':fact(1861,'mm',[rb,'zecar-my26'],'mirror basis unstated in exact MY26 sources',note='Do not silently inherit MY25.5 mirror basis as current-maker MY26 evidence.'),
 'height':fact(1598,'mm',rb,conflict='my26-height',note='Zecar MY26 table gives 1597 mm. Neither source establishes the reason.'),
 'brakedTowing':fact(tow,'kg',rb,'braked maximum',note='MY26 exact-guide value. MY25.5 VZ maker 1200 kg is a different year scope, not silently substituted.' if slug=='vz' else 'Confirm actual vehicle/load/towbar limits before towing.'),
 'vehicleWarranty':fact({'years':5,'kilometres':'unlimited'},None,['maker-warranty','maker-warranty-terms'],'brand Australian terms','Confirmed','Inherited with actual start/use/maintenance conditions in brand-terms.json.'),
 'batteryWarranty':fact({'years':8,'kilometres':160000,'capacityTriggerPercent':70},None,['maker-warranty','maker-warranty-terms'],'BEV high-voltage battery; whichever first','Confirmed','Authorised test and proper-use conditions; trigger versus staged remedy kept distinct in brand-terms.json.')
 }
 assert list(core)==coreKeys
 strength={'v':'Reported 26-minute 10–80% charging, with a 540 L boot.','endurance':'Reported 520 km WLTP range and a 540 L boot.','vz':'Reported 250 kW all-wheel drive and 0–100 km/h in 5.5 seconds.'}[slug]
 trade={'v':'Reported range is 414 km WLTP, below the Endurance’s 520 km.','endurance':'Reported braked towing is limited to 1,000 kg.','vz':'Reported price is A$75,490 before on-road costs.'}[slug]
 candidates.append({'proposedId':'cupra-tavascan-my26-'+slug,'brand':'CUPRA','model':'Tavascan','version':grade,'modelYear':'MY26','powertrain':'BEV','vehicleClass':'passenger','proposedAdmission':'visible new-version candidate; parent source/candidate/staging gates pending','availability':{'proposedBuyerState':'On sale now','grade':'Reported','detail':'Australian MY26 release announced for late August 2026; current October GoAuto diary marks V/MY26 released in August, with exact MY26 guides and current advertised/order-listing presence. This supports current-release catalogue visibility, not a witnessed accepted order or physical-stock claim.','sourceIds':['carexpert-my26','goauto-my26','goauto-diary',rb],'makerExactCurrentOrderAcceptanceVerified':False,'physicalStockVerified':False,'stockConditionGate':'specific Alto New/Demonstrator conflicts remain held'},'coreFacts':core,'strength':{'text':strength,'dependsOn':['dc10to80','boot'] if slug=='v' else ['range','boot'] if slug=='endurance' else ['power','drive','acceleration']},'tradeoff':{'text':trade,'dependsOn':['range'] if slug=='v' else ['brakedTowing'] if slug=='endurance' else ['price']},'standingNote':'Named Australian MY26 versions are supported by current secondary release/guide evidence. The maker landing remains explicitly Tavascan 2025 with MY25.5 technical brochure. Confirm exact delivered specification before signing; this does not demote every fact to Check.'})
put(P/'candidate-facts.json',{'schema':'light_research_proposal_v1','checkedAt':checked,'notProductionCatalogue':True,'coreFactsPerVersion':17,'candidates':candidates})
identity={'checkedAt':checked,'existingCompleteCUPRARows':0,'makerFullMenu':['Terramar','Tavascan','Formentor','Ateca (sold out)','Leon','Leon Sportstourer','Born (sold out)'],'makerBEVModelReconciliation':[{'model':'Tavascan','decision':'Propose MY26 V/Endurance/VZ as visible Reported current-release rows','sourceIds':['maker-tavascan','carexpert-my26','goauto-my26','goauto-diary','carexpert-tavascan-list']},{'model':'Born','decision':'Not current factory-order offering; no new row. Maker sold out/unavailable to order and July AU product statement no reintroduction plan. No assertion of nationwide residual-stock exhaustion.','sourceIds':['maker-born','carexpert-born']},{'model':'Raval','decision':'Upcoming AU model, reportedly 2027; no AU exact grade, price or open-order proof. Keep arrival lead, not full current version. Do not import global specifications.','sourceIds':['maker-raval','goauto-raval','carexpert-born']}],'proposedCurrentGrades':['MY26 V','MY26 Endurance','MY26 VZ'],'excludedDuplicateGrades':['Interior Package: MY26 included equipment, not a separate grade','Extreme Pack: VZ option, not a separate fourth grade','Black Edition: global announcement is not AU admission evidence','Born VZ/facelift: overseas or evaluation material is not new AU order evidence'],'residualMY255Disposition':'Historical technical reference retained separately. Alto old Endurance exact ad now redirects to generic stock, so no current exact residual-new offer is established there. Its earlier New/Demonstrator and drive-description ambiguity is historical only. No residual row proposed, without claiming national stock exhaustion.','C1Status':'OPEN: two independent Australian publications agree on MY26 trio, but current maker page still publishes two 2025 grades; independent brand/model closure cannot be marked complete. Secondary current version evidence supports visibility while this gap remains.','availabilityRationale':'Reported release/current listing is sufficient for visible candidate admission; clean physical-stock evidence is not a prerequisite. On-sale proposal is an inference from release diary plus exact current guides and current listings, not observed factory-order acceptance.','conflicts':conflicts,'historicalScopedObservations':history,'brandTermsPath':'brand-terms.json','recallScope':'REC-006687/94S9, 318 affected Tavascan 2024–2026 vehicles by VIN; do not apply blanket stop-driving or unverified completion status.','sourceUrls':urls}
put(P/'identity-review.json',identity)
# Independent review refinements, including current exact CarExpert grade guides.
ceUrls={
 'v':'https://www.carexpert.com.au/cupra/tavascan/2026-v-suv-rwd-electric-jskawogk20260630',
 'endurance':'https://www.carexpert.com.au/cupra/tavascan/2026-endurance-suv-rwd-electric-jsgoffao20260630',
 'vz':'https://www.carexpert.com.au/cupra/tavascan/2026-vz-suv-4x4-electric-jsgoffas20260630'
}
for slug,usable,maximum,price,dc,tow in [('v',58,61,55490,105,1000),('endurance',77,82,66490,135,1000),('vz',77,82,75490,135,1200)]:
 sid='carexpert-guide-'+slug;urls[sid]=ceUrls[slug]
 put(S/(sid+'-facts.json'),{'sourceId':sid,'url':ceUrls[slug],'checkedAt':checked,'captureMethod':'Sanitized factual transcription from successful public web page open; scripts, runtime config and headers not requested or retained','facts':{'scope':'2026 Australian exact grade record; June 2026 identifier, new grade prices and 10.25-inch cluster match refreshed MY26 lineup','identityMarkers':{'priceBeforeOrcAud':price,'instrumentClusterInches':10.25},'usableBatteryKwh':usable,'maximumBatteryKwh':maximum,'capacityLabels':'Useable Battery and Maximum Battery, not inferred from subtraction','acKw':11,'dcPeakKw':dc,'mode4DurationUnlabelled':0.43 if slug=='v' else 0.47,'mode4SocStart':10,'mode4SocEnd':80,'durationCaution':'Unit not printed in extracted Duration label. Do not convert into minutes or use calculated-duration fields.','bootRearSeatUpToLowerWindowLitres':540,'bootRearSeatDownLitres':1550,'bootProtocol':'not specified','lengthMm':4644,'widthMm':1861,'widthIncludingMirrorsMm':2108,'heightMm':1597,'brakedTowingKg':tow,'releaseDateCaution':'Guide says 2 June; RedBook July and launch diary August reflect differing release-date conventions. Use dated launch/diary for actual arrival statement.'}})
 for c in candidates:
  if c['proposedId'].endswith('-'+slug):
   f=c['coreFacts']
   f['battery']['basis']='usable capacity, explicitly labelled in current CarExpert grade guide'
   f['battery']['sourceIds']=[sid,'carexpert-my26']
   f['battery'].pop('conflictId',None)
   f['battery']['note']='Guide explicitly separates usable '+str(usable)+' kWh from maximum '+str(maximum)+' kWh. RedBook capacity field remains retained as its own unlabelled basis; no manufacturer confirmation or gross relabelling inferred.'
   f['ac']['sourceIds']=[sid,'zecar-my26']
   f['boot']['basis']='rear seats up to lower window; VDA/SAE protocol not published'
   f['boot']['sourceIds']=[sid,'redbook-'+slug]
   f['boot']['note']='Current secondary guide supplies loading boundary; protocol remains unspecified. No boot ranking.'
   f['width']['basis']='overall body width excluding mirrors; 2108 mm separately including mirrors'
   f['width']['sourceIds']=[sid,'redbook-'+slug]
   f['width']['note']='Current grade guide contrasts 1861 mm overall width and 2108 mm including mirrors; Reported evidence.'
   f['height']['note']='Exact current CarExpert and Zecar give1597 mm, whereas exact MY26 RedBook gives1598 mm. Difference unresolved.'
   if slug=='v':
    c['tradeoff']={'text':'Its reported WLTP range is 414 km.','dependsOn':['range']}
   else:
    f['dc10to80']['sourceIds'].append(sid)
    f['dc10to80']['note']+=' Additional CarExpert current grade guide lists Mode4 duration0.47 with10–80 SOC, but omits the duration unit; do not infer minutes.'
   if slug=='vz':
    f['brakedTowing']['conflictId']='my26-vz-towing'
    f['brakedTowing']['sourceIds']=['redbook-vz',sid]
    f['brakedTowing']['note']='Unresolved current-source conflict: exact MY26 RedBook1800 kg versus refreshed CarExpert VZ1200 kg. Display source-labelled alternatives; no authoritative single limit, ranking or towing-dependent summary.'
    f['brakedTowing']['alternativeReportedValue']=1200
    f['brakedTowing']['comparisonHold']=True
for cf in conflicts:
 if cf['id']=='my26-battery-basis':
  cf['status']='RESOLVED_AT_REPORTED_SOURCE_BASIS'
  cf['observations']['Current CarExpert explicit usable capacity']=[58,77,77]
  cf['observations']['Current CarExpert explicit maximum capacity']=[61,82,82]
  cf['disposition']='Use explicitly labelled current-guide usable capacity as Reported; retain earlier unlabelled observations. This supplies a basis rather than an invented reconciliation. No Confirmed promotion or Reported ranking.'
 if cf['id']=='my26-height': cf['observations']['Current exact CarExpert guides']=1597
conflicts.append({'id':'my26-vz-towing','fields':['brakedTowing'],'scope':'refreshed Australian MY26 VZ only','observations':{'RedBook exact MY26':1800,'CarExpert June2026 exact VZ record with75490price and10.25instrument cluster':1200},'disposition':'Hold authoritative/comparative towing claim. Keep source-labelled reported alternatives and dealer confirmation item. Older MY25.5 brochure is not the reason for this current conflict.'})
identity['sourceUrls']=urls
identity['conflicts']=conflicts
identity['reviewRefinements']=['V summary uses only own facts; no unguarded sibling comparison','Maker model-list URL matches captured homepage','Current CarExpert exact-grade guides now establish usable battery, boot loading boundary and mirror distinction at Reported only','Current VZ towing conflict added independently of historical MY25.5 data']
put(P/'identity-review.json',identity)
put(P/'candidate-facts.json',{'schema':'light_research_proposal_v2','checkedAt':checked,'notProductionCatalogue':True,'coreFactsPerVersion':17,'candidates':candidates})

# Each file in the deliverable is a sanitized source extract, a published PDF, or an explicit proposal.
manifest={'schema':'cupra_light_source_admission_v1','checkedAt':checked,'status':'READY_FOR_INDEPENDENT_SOURCE_REVIEW_NOT_ACCEPTED_OR_INTEGRATED','scope':'CUPRA Australian new BEV identity, sources, core facts and residual/arrival disposition only','roots':[str(R),str(P)],'entryPoints':['identity-review.json','candidate-facts.json','brand-terms.json'],'proposedVersionCount':3,'currentProductionCountsUnchanged':{'catalogue':427,'tier1':350,'onSaleTier1':309},'beforeSelectionProof':str(R/'retained-selection-proof.json'),'constraints':{'liveRepositoryFilesChanged':False,'catalogueHydration':False,'compilerAttempts':0,'buildServerBrowserArchiveStarted':False,'userComputerUsed':False,'rawRuntimeConfigOrHeadersPersisted':False,'credentialOrClientKeyUsedPrintedSaved':False},'validationStatus':'No live addition or heavy validation. Current full-project TypeScript remains UNPASSED after parent-reported unknown-cause SIGKILLs; this research does not change that status.','reviewQuestions':['Accept Reported current-release/on-sale admission for MY26 trio while explicit current maker-list gap remains open?','Accept explicitly usable Reported batteries and disputed height/VZ towing with current source conflicts retained and rankings held?','Keep Endurance/VZ DC10–80 Not published after two exact current sources, preserving unspecified-window 28-minute Endurance observation separately?','Confirm MY25.5 technical references/Born/Raval/recall stay separately scoped.'],'files':[]}
for root in [R,P]:
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.name!='source-admission-manifest.json':
   b=p.read_bytes();manifest['files'].append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
put(P/'source-admission-manifest.json',manifest)
print('Packet:',len(candidates),'candidates;',len(manifest['files']),'bounded files; production unchanged')
