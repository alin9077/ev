import urllib.request, urllib.parse, json, pathlib, sys, subprocess, hashlib
from html.parser import HTMLParser

BASE=pathlib.Path('/tmp/cupra-research/sources')
class SafeText(HTMLParser):
    def __init__(self):
        super().__init__(); self.skip=0; self.text=[]; self.links=[]; self.a=None
    def handle_starttag(self,t,a):
        if t in ('script','style','noscript','iframe'): self.skip+=1
        if not self.skip and t=='a': self.a={'url':dict(a).get('href',''),'text':''}
    def handle_endtag(self,t):
        if t in ('script','style','noscript','iframe'): self.skip=max(0,self.skip-1)
        if not self.skip and t=='a' and self.a: self.links.append(self.a); self.a=None
    def handle_data(self,d):
        if not self.skip and d.strip():
            self.text.append(d.strip())
            if self.a: self.a['text']+=d.strip()+' '

def capture(slug,url):
    p={'url':url,'checkedAt':'2026-10-15','method':'Unauthenticated public GET, no credential or authorization headers. Visible text/ordinary links only; scripts/runtime/config discarded in memory before persistence. No raw headers, cookies, tokens or client keys persisted.'}
    try:
        with urllib.request.urlopen(url,timeout=30) as r: data=r.read(); p['responseStatus']=r.status; p['finalUrl']=r.url
        if data.startswith(b'%PDF'):
            # A published maker document is a source artifact, not runtime configuration.
            dest=BASE/(slug+'.pdf');dest.write_bytes(data)
            subprocess.run(['pdftotext','-layout',str(dest),str(BASE/(slug+'.txt'))],check=True)
            p['kind']='published_pdf';p['pdfSha256']=hashlib.sha256(data).hexdigest()
        else:
            s=SafeText();s.feed(data.decode('utf8',errors='replace'))
            (BASE/(slug+'.txt')).write_text('\n'.join(s.text)+'\n')
            links=[{'text':a['text'].strip(),'url':urllib.parse.urljoin(url,a['url'])} for a in s.links if a['url'].startswith(('https://www.cupra','https://www.carexpert','https://zecar','https://www.goauto','/'))]
            (BASE/(slug+'-links.json')).write_text(json.dumps(links,indent=2)+'\n')
            p['kind']='sanitized_visible_text'
        print(slug,'OK',flush=True)
    except Exception as e:
        p['failureType']=type(e).__name__;p['failureMessage']=str(e)
        print(slug,p['failureType'],p['failureMessage'],flush=True)
    (BASE/(slug+'-provenance.json')).write_text(json.dumps(p,indent=2)+'\n')

if __name__=='__main__': capture(sys.argv[1],sys.argv[2])
