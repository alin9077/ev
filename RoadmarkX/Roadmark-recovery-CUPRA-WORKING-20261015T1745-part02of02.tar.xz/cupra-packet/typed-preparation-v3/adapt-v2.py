from pathlib import Path
import json,hashlib
A=Path('/tmp/cupra-packet/typed-preparation-v2');B=Path('/tmp/cupra-packet/typed-preparation-v3');R=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def pin(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
for p in json.loads((A/'source-pins.json').read_text()):assert pin(p['path'])==p
for name in ['assembly-input.json','base-research-input.json','cupra-market-reconciliation-v2.json','admission-audit-v2.json','static-input-audit.json','v1-to-v2-provenance.json']:
 with (B/name).open('xb') as f:f.write((A/name).read_bytes())
for name in ['materialize.mts','run.py','prepare-command.py']:
 text=(A/name).read_text().replace('typed-preparation-v2','typed-preparation-v3')
 if name=='prepare-command.py':
  text=text.replace("files.update(O.glob('*'));", "files.update(O.glob('*'));files.update(Path('/tmp/cupra-packet/typed-preparation-v2').glob('*'));" )
  text=text.replace("'package.json','pnpm-lock.yaml'", "'package.json','pnpm-lock.yaml','tsconfig.json'")
 with (B/name).open('x') as f:f.write(text)
with (B/'v2-to-v3-provenance.json').open('x') as f:json.dump(dict(status='v2_preserved_superseded_before_execution',v2PreparedManifest=pin(A/'prepared-command.json'),v2SourcePins=pin(A/'source-pins.json'),originalV2PinsStillPass=True,changes=['Pin tsconfig.json because the tsx runtime can consume it. The repository configuration has no extends clause. No packet, reconciliation, admission, fact, source, guard or buyer-text change.'],tsconfig=pin(R/'tsconfig.json'),typescriptCompilerAttempted=False),f,indent=2);f.write('\n')
