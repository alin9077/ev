from pathlib import Path
import json,hashlib,copy
A=Path('/tmp/cupra-packet/typed-preparation-v1');B=Path('/tmp/cupra-packet/typed-preparation-v2')
def pin(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(p):return json.loads(Path(p).read_text())
def write(name,x):
 with (B/name).open('x') as f:f.write(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
for p in read(A/'source-pins.json'):assert pin(p['path'])==p
input=read(A/'assembly-input.json');p=input['packetWithoutAvailability'];pid=p['id']
replacements={'October2026':'October 2026','Mode4 duration0.47 with10–80':'Mode 4 duration 0.47 with 10–80%',' /160,000':' / 160,000','below70%':'below 70%','least78% at3yr/60,000km,74% at5yr/100,000km,70% at8yr/160,000km':'least 78% at 3 years / 60,000 km, 74% at 5 years / 100,000 km, and 70% at 8 years / 160,000 km','late-August2026':'late August 2026','describes2025':'describes 2025','explicitly2025':'explicitly 2025','reported2027':'reported 2027','July2026':'July 2026','retained69':'retained 69','DC10–80':'DC 10–80','MY26:1598':'MY26: 1598','Zecar:1597':'Zecar: 1597',':1200 kg':': 1200 kg','source-labelled1598/1597':'source-labelled 1598/1597'}
def refine(x):
 if isinstance(x,dict):return {k:refine(v) for k,v in x.items()}
 if isinstance(x,list):return [refine(v) for v in x]
 if isinstance(x,str) and not x.startswith(('https:','http:','/tmp/','/workspace/')):
  for a,b in replacements.items():x=x.replace(a,b)
 return x
input=refine(input);p=input['packetWithoutAvailability']
for row in p['facts']:
 f=row['after']
 if f['issues']:
  f['gradeReview']['reason']='Current exact Australian secondary sources disagree on this measurement. Retain both source-labelled observations as Reported, with the narrow conflict visible and normalized comparison held.'
facts={(x['variantId'],x['after']['key']):x['after'] for x in p['facts']}
for summary in p['summaries']:
 for side in ['strength','tradeoff']:
  for dep in summary[side]['dependencies']:dep['expected']=copy.deepcopy(facts[summary['variantId'],dep['key']])
recallId=pid+'-government-recall-006687'
recallSource=dict(id=recallId,url='https://www.vehiclerecalls.gov.au/recalls/rec-006687',title='Australian Government vehicle recall REC-006687 / CUPRA campaign 94S9',publisher='Australian Government Vehicle Recalls',source_type='government_au_vehicle_recall',published_date='2026-08-05',accessed_date='2026-10-15',market='AU',supports='VIN-scoped safety context only; not current-release, stock or order evidence.',retainedCaptures=[pin('/tmp/cupra-research/sources/recall-facts.json')],retrievalMethod='Public read-only government page; sanitized factual transcription retained.',contextRole='VIN-scoped safety notice, separate from version-admission evidence')
p['sources'].append(recallSource)
warning='Safety recall context: Australian Government REC-006687 / CUPRA campaign 94S9 covers 318 VIN-identified Tavascan vehicles from 2024–2026. Affected drivers must not use advanced full beam assist until rectified; the remedy is a free dealer software update. Check the actual vehicle VIN with CUPRA against the recall. No candidate vehicle is assumed affected or remedied, and this is not a whole-range stop-driving notice.'
for plan in input['availabilityPlans']:
 plan['after']['evidence']['sourceIds'].append(recallId)
 plan['after']['evidence']['qualifications'].append(warning)
 plan['reason']+=' The government source supports only the separate VIN-scoped safety qualification.'
write('assembly-input.json',input)
write('base-research-input.json',read(A/'base-research-input.json'))
write('cupra-market-reconciliation-v2.json',refine(read(A/'cupra-market-reconciliation-v1.json')))
admission=refine(read(A/'admission-audit-v1.json'));admission['recallBuyerVisiblePath']=dict(path='availabilityEvidence.qualifications',sourceId=recallId,warning=warning,releaseSupportSourceIdsUnchanged=True,detailAndCitableOutputProof='Required in later selected consumer preflight; not claimed by preparation')
write('admission-audit-v2.json',admission)
audit=refine(read(A/'static-input-audit.json'));audit.update(sourceRecords=16,recallContextSources=1,recallBuyerVisibleQualifications=3,preparationVersion=2)
write('static-input-audit.json',audit)
for name in ['materialize.mts','run.py','prepare-command.py']:
 text=(A/name).read_text().replace('typed-preparation-v1','typed-preparation-v2').replace('cupra-market-reconciliation-v1.json','cupra-market-reconciliation-v2.json').replace('admission-audit-v1.json','admission-audit-v2.json')
 if name=='materialize.mts':
  text=text.replace("assert.equal(car.availabilityEvidence?.factoryOrderAcceptanceVerified,false);","assert.equal(car.availabilityEvidence?.factoryOrderAcceptanceVerified,false);\n assert(car.availabilityEvidence?.sourceIds.includes('m1-cupra-2026-10-15-government-recall-006687'));\n assert(car.availabilityEvidence?.qualifications?.some(text=>text.includes('REC-006687')&&text.includes('318')&&text.includes('must not use advanced full beam assist')&&text.includes('free dealer software update')&&text.includes('No candidate vehicle is assumed affected or remedied')));")
 if name=='prepare-command.py':
  text=text.replace("files.update(O.glob('*'));", "files.update(O.glob('*'));files.update(Path('/tmp/cupra-packet/typed-preparation-v1').glob('*'));" )
 with (B/name).open('x') as f:f.write(text)
write('v1-to-v2-provenance.json',dict(status='v1_preserved_superseded_before_execution',v1PreparedManifest=pin(A/'prepared-command.json'),v1SourcePins=pin(A/'source-pins.json'),originalV1PinsStillPass=True,changes=['Add the official VIN-scoped government recall citation and full warning to existing buyer-visible availability qualifications; keep source context distinct from release evidence.','Readable buyer-text spacing and conflict-specific grade-review reasons; no numeric values, grades, identity, price, source conflict or warranty meaning changed.'],unchanged=dict(originalSourceV3Manifest=pin('/tmp/cupra-packet/source-review-v3/source-admission-manifest.json'),zeroRowBaseline=pin('/tmp/cupra-research/retained-before-cars.json'),sourceV3Captures=True,acceptedProductionHistory=True),sourceReviewV1HistoricalLimitation='The earlier light source-preparation v1 bytes were overwritten before v2 freeze. No reconstruction is claimed. This typed-preparation v1 is a separate later artifact and is preserved.'))
print(json.dumps(dict(prepared=str(B),v1Preserved=True,executed=False)))
