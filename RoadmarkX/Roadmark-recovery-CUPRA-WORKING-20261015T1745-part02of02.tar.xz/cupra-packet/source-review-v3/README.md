# CUPRA source/admission review v3, 15 October 2026

## Decision proposed

Add three visible, source-labelled MY26 Tavascan candidates: V, Endurance and VZ. The Australian launch reports name all three; the current GoAuto release diary records the V/MY26 update as released in August. Exact current guides and listings corroborate identities. Proposed **On sale now — Reported** is a release/listing inference, not observed factory acceptance or physical-stock proof. Independent source approval and later candidate/staging gates are still required.

No existing CUPRA complete rows were found in the accepted 427-row digest index. This is an audit-only addition proposal. Production stays 427 catalogue / 350 Tier 1 / 309 on-sale Tier 1.

## Prices and facts

| MY26 version | Reported price before ORC | Reported WLTP | Reported DC maximum | Reported braked towing |
|---|---:|---:|---:|---:|
| V | A$55,490 | 414 km | 105 kW | 1,000 kg RedBook/Zecar / 1,200 kg CarExpert; unresolved |
| Endurance | A$66,490 | 520 km | 135 kW | 1,000 kg |
| VZ | A$75,490 | 509 km | 135 kW | 1,800 kg RedBook / 1,200 kg CarExpert; unresolved |

The 51 core-fact slots comprise 43 Reported, 6 Confirmed inherited warranty facts, and 2 Not published DC 10–80 times. V has an explicit reported 26-minute 10–80 claim. Endurance's exact guide says 28-minute fast charging without an SOC window; that is not a 10–80 figure. VZ has no exact current 10–80 duration in the two checked sources.

Current CarExpert grade guides explicitly label 58/77/77 kWh usable capacity and 61/82/82 kWh maximum, resolving the earlier basis ambiguity at Reported only. The RedBook capacity labels are retained as originally published, without relabelling them gross. Height 1,598 mm in MY26 RedBook versus 1,597 mm in current CarExpert/Zecar remains unresolved. Current towing disagreements exist for V (RedBook/Zecar 1,000 kg versus CarExpert 1,200 kg) and VZ (RedBook 1,800 kg versus CarExpert 1,200 kg). V2 incorrectly transcribed the CarExpert V value as 1,000; v3 corrects it after an independent reopen, preserving v2 unchanged. Source-labelled alternatives stay visible, with authoritative/comparative towing claims held.

Current CarExpert grade guides supply the boot boundary (rear seats up to the lower window, 540 L) and mirror distinction (1,861 mm body width, 2,108 mm including mirrors). Boot VDA/SAE protocol remains unstated. V's reported 8.6-second acceleration carries the secondary EU/local caveat and is not used in summary copy. V's trade-off uses its own range only. V2L and one-pedal local equipment claims remain held. CarExpert's Endurance/VZ Mode4 duration 0.47 has an explicit 10–80 SOC window but lacks a printed time unit; it is retained without a guessed minute conversion.

## Model/version boundaries

- Maker menu inspected in full: Terramar, Tavascan, Formentor, Ateca (sold out), Leon, Leon Sportstourer, Born (sold out)
- Tavascan maker landing explicitly describes 2025 and links an MY25.5 brochure. Its Endurance/VZ 531/505 km and VZ 1,200 kg towing are retained as dated references, not blended into MY26
- Interior Package is included equipment for MY26, not another grade; Extreme Pack remains an option on VZ
- Born is unavailable to order on the maker site; a July Australian product statement says there are no current reintroduction plans. No national residual-stock exhaustion claim
- Raval remains an upcoming Australian lead, reported for 2027, without exact local versions/order evidence. No global-only grades imported
- Current manufacturer version-list incompleteness remains a C1 gap; no national-best claim

## Stock, terms and safety

Three current exact Alto MY26 ads say New/10 km but retain a demonstrator-sale heading. They do not prove clean physical new stock. The old Endurance exact URL now redirects to generic stock; its former condition conflict is historical.

Brand-wide 5-year/unlimited-km vehicle and 8-year/160,000-km BEV battery terms are Confirmed with actual start/use/maintenance conditions. The 70% capacity trigger is distinct from the staged 78/74/70% restoration floors. Demonstrators do not receive a restarted new-car warranty. The current Chargefox offer is non-cash and conditional, never a price deduction.

Government campaign REC-006687 / 94S9 covers 318 VIN-scoped Tavascan 2024–2026 vehicles. Affected owners should not use advanced full beam assist until the free software remedy is completed. No blanket stop-driving, exact-candidate applicability or completion assertion.

## Review files

- `identity-review.json`: admissions, differences, source URLs and narrow conflicts
- `candidate-facts.json`: 17 core slots per named version, provenance and strength/trade-off dependencies
- `brand-terms.json`: inherited terms and actual conditions
- `dealer-observations.json`: current exact-ad versus historical/redirect disposition
- `source-admission-manifest.json`: bounded file hashes and constraints
- `/tmp/cupra-research/sources`: sanitized visible text, allowlisted factual JSON, published PDFs and no-value provenance

No live files edited, catalogue hydration, compiler, build, browser, server or archive. This does not change the current project's UNPASSED TypeScript status after the parent's two unexplained SIGKILL attempts.

## Revision provenance

Mutable v1 preparation was overwritten before freezing; its original bytes are not claimed retained and its old 81-pin check does not apply to later packets. Frozen v2 remains unchanged and unaccepted because the independent reviewer found the V towing transcription error. This v3 uses a corrected, versioned source extract and requires its own review. Original public text/PDF captures and accepted production history were not changed.
