/** Prepared bounded materialization only. No catalogue loader or compiler. */
import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import type { BrandUpdatePacket } from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-updates';
import type { AvailabilityCorrection } from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/availability-corrections';
import type { Car, Research } from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/types';
import type { M1MarketReconciliation } from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/m1-reconciliation';
const repo='/workspace/scratch/586427eef9f2/roadmark-104';
const dir='/tmp/cupra-packet/typed-preparation-v1';
const out=dir+'/output';
assert.equal(process.cwd(),repo);
assert.equal(process.argv[2],'--root-execution-granted');
assert(!fs.existsSync(out),'Output must be a fresh versioned directory');
const read=(path:string)=>JSON.parse(fs.readFileSync(path,'utf8'));
const hash=(path:string)=>crypto.createHash('sha256').update(fs.readFileSync(path)).digest('hex');
const pin=(path:string)=>({path,bytes:fs.statSync(path).size,sha256:hash(path)});
const pins=read(dir+'/source-pins.json');
function checkPins(){for(const p of pins){assert.equal(fs.statSync(p.path).size,p.bytes,p.path);assert.equal(hash(p.path),p.sha256,p.path);}}
checkPins();
const input=read(dir+'/assembly-input.json');
const base:Research=read(dir+'/base-research-input.json');
const seed:BrandUpdatePacket=input.packetWithoutAvailability;
const before:Car[]=read(input.zeroRowBaselinePath);
const reconciliation:M1MarketReconciliation=read(dir+'/cupra-market-reconciliation-v1.json');
const snapshots={input:structuredClone(input),base:structuredClone(base),before:structuredClone(before),reconciliation:structuredClone(reconciliation)};
assert.deepEqual(before,[]);
assert.deepEqual(base.variants,[]);
assert.equal(base.criteria.length,69);
assert.equal(seed.variants.length,3);
assert.equal(seed.models.length,1);
assert.equal(seed.versionGuards.length,0);
assert.equal(seed.versionUpdates.length,0);
assert.equal(seed.availability.length,0);
assert.equal(seed.facts.length,45);
assert(seed.facts.every(row=>row.before===null));
assert.equal(seed.brandTerms?.length,3);
assert(seed.brandTerms?.every(term=>Object.values(term.before).length===3&&Object.values(term.before).every(value=>value===null)));
assert.deepEqual(reconciliation.currentVersionReviews,[]);
assert.deepEqual(reconciliation.publishedLists,[]);
assert.equal(reconciliation.inventoryResolutions.find(row=>row.inventoryId==='cupra-tavascan')?.outcome,'unresolved');
assert.equal(reconciliation.inventoryResolutions.find(row=>row.inventoryId==='cupra-born')?.outcome,'excluded');
const receipt=read('/tmp/cupra-research/retained-selection-proof.json');
assert.equal(hash(receipt.acceptedIndex),receipt.indexSha256);
const accepted=read(receipt.acceptedIndex)[receipt.stage];
assert.equal(accepted.length,427);
assert(accepted.every((row:{id:string})=>!/cupra|tavascan|born/i.test(row.id)));
const require=createRequire(repo+'/package.json');
const {prepareBrandResearch,applyBrandUpdates}=require('./src/lib/brand-updates.ts') as typeof import('/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-updates');
const {availabilitySnapshot}=require('./src/lib/availability-corrections.ts') as typeof import('/workspace/scratch/586427eef9f2/roadmark-104/src/lib/availability-corrections');
const {hasEarnedBuyerGrade}=require('./src/lib/evidence-grading.ts') as typeof import('/workspace/scratch/586427eef9f2/roadmark-104/src/lib/evidence-grading');
const {buyerAvailability}=require('./src/lib/buyer-availability.ts') as typeof import('/workspace/scratch/586427eef9f2/roadmark-104/src/lib/buyer-availability');
// The real addition producer creates the Car with facts:{} and validates all null
// before guards internally. It also supplies the actual availability before state.
// No manually assembled Car or post-unknown placeholder is used as a fact guard.
const seedResearch=prepareBrandResearch(base,[seed]);
const seedCars=applyBrandUpdates(before,seedResearch,[seed]);
assert.equal(seedCars.length,3);
const generatedAvailability=seedCars.map(car=>({variantId:car.id,before:availabilitySnapshot(car)}));
const packet:BrandUpdatePacket=structuredClone(seed);
packet.availability=input.availabilityPlans.map((plan:{variantId:string;after:AvailabilityCorrection['after'];reason:string}):AvailabilityCorrection=>{
 const generated=generatedAvailability.find(row=>row.variantId===plan.variantId);
 assert(generated);
 return {id:`${packet.id}-${plan.variantId}-availability`,variantId:plan.variantId,before:structuredClone(generated.before),after:structuredClone(plan.after),status:'approved',reviewedBy:packet.reviewedBy,reviewedAt:packet.reviewedAt,evidenceDate:packet.reviewedAt,reason:plan.reason};
});
const finalResearch=prepareBrandResearch(base,[packet]);
const cars=applyBrandUpdates(before,finalResearch,[packet]);
assert.deepEqual(cars.map(car=>car.id),packet.variants.map(row=>row.id));
assert.equal(finalResearch.models.length,base.models.length+1);
assert.deepEqual(finalResearch.models.slice(0,base.models.length),base.models);
assert.equal(finalResearch.feature_evidence.length,207);
assert.equal(finalResearch.trim_equipment.length,3);
assert.equal(finalResearch.update_eligibility.length,3);
assert.equal(finalResearch.feature_evidence_variant_context?.length,3);
const core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','length_mm','width_mm','height_mm','towing_braked_kg','zero_to_100_s','power_kw','drive','warranty','battery_warranty'];
const gradeCounts:Record<string,number>={};
for(const car of cars){
 assert.equal(buyerAvailability(car),'on_sale_now');
 assert.equal(car.availabilityEvidence?.orderStatus,'listed_unconfirmed');
 assert.equal(car.availabilityEvidence?.stockStatus,'unverified');
 assert.equal(car.availabilityEvidence?.physicalStockVerified,false);
 assert.equal(car.availabilityEvidence?.factoryOrderAcceptanceVerified,false);
 assert.equal(car.year,2026);
 assert.equal(Object.keys(car.facts).length,25);
 assert(car.buyerSummary?.strength&&car.buyerSummary?.tradeoff);
 for(const key of core){const f=car.facts[key];assert(f);assert(hasEarnedBuyerGrade(f,finalResearch.sources,packet.reviewedAt));gradeCounts[f.buyerGrade!]=(gradeCounts[f.buyerGrade!]??0)+1;}
 assert(hasEarnedBuyerGrade(car.facts.roadside_assistance,finalResearch.sources,packet.reviewedAt));
 assert.equal(car.facts.roadside_assistance.buyerGrade,'confirmed');
 assert.equal(car.facts.height_mm.issues.length,1);
 assert.equal(car.facts.height_mm.comparisonBasis,'');
 assert.equal(car.facts.boot_l.comparisonBasis,'');
 if(car.trim!=='MY26 Endurance'){
  assert.equal(car.facts.towing_braked_kg.issues.length,1);
  assert.equal(car.facts.towing_braked_kg.comparisonBasis,'');
  const visible=car.facts.towing_braked_kg.qualifications.join(' ');
  assert(visible.includes('CarExpert')&&visible.includes('1200')&&visible.includes('RedBook'));
 }
 const rows=finalResearch.feature_evidence.filter(row=>row.variant_id===car.id);
 assert.equal(rows.length,69);assert.equal(new Set(rows.map(row=>row.criterion)).size,69);
 assert(rows.every(row=>row.value==='Needs confirmation'&&row.status==='not_verified'&&row.source_ids.length===0));
}
assert.deepEqual(gradeCounts,{reported:43,confirmed:6,not_published:2});
assert.deepEqual(input,snapshots.input);assert.deepEqual(base,snapshots.base);assert.deepEqual(before,snapshots.before);assert.deepEqual(reconciliation,snapshots.reconciliation);
checkPins();
fs.mkdirSync(out);
function write(name:string,value:unknown){fs.writeFileSync(out+'/'+name,JSON.stringify(value,null,2)+'\n',{flag:'wx'});return pin(out+'/'+name);}
const packetPin=write('cupra-2026-10-15-candidate-v1.json',packet);
const afterPin=write('selected-after-cars.json',cars);
const researchPin=write('selected-after-research.json',finalResearch);
const provenance=write('builder-guard-provenance.json',{
 schema:'cupra_actual_addition_builder_provenance_v1',sourceManifest:pin('/tmp/cupra-packet/source-review-v3/source-admission-manifest.json'),
 zeroRowBaseline:pin(input.zeroRowBaselinePath),zeroRowSelectionProof:pin('/tmp/cupra-research/retained-selection-proof.json'),
 producer:{script:pin(dir+'/materialize.mts'),implementation:pin(repo+'/src/lib/brand-updates.ts'),availabilitySnapshot:pin(repo+'/src/lib/availability-corrections.ts'),method:'prepareBrandResearch(base,[seed]) then applyBrandUpdates([],seedResearch,[seed]); actual addition producer validates 45 version-fact and 9 term null guards and supplies availabilitySnapshot(seedCar). Final guarded packet re-applied through prepareBrandResearch/applyBrandUpdates to the original zero-row baseline.'},
 generatedAvailabilityBefore:generatedAvailability,
 factBeforeProof:{manualCarBaseline:false,newVariantCarInitialFacts:'empty object inside actual producer',versionFactNullGuardsValidated:45,sharedTermNullGuardsValidated:9,unknownFactsAddedOnlyAfterReviewedFactApplication:true,baselineRowsUnchanged:0},
 noExistingModelOrAliasChanges:true,noCurrentOfficialListClosure:true,allInputPinsPassed:true,fullCatalogueHydration:false,compilerAttempted:false,
 scope:'Only three proposed additions in an isolated zero-CUPRA fixture using real retained criteria and retained-plus-registered models. This is neither selected consumer parity nor a full-project validation.'
});
const result=write('materialization-result.json',{
 status:'PASSED_BOUNDED_ADDITION_MATERIALIZATION',candidate:packetPin,afterCars:afterPin,afterResearch:researchPin,guardProvenance:provenance,
 identities:cars.map(car=>({id:car.id,trim:car.trim,year:car.year,drive:car.drive,buyerAvailability:buyerAvailability(car)})),
 newModels:1,newVariants:3,versionFactNullGuards:45,brandTermNullGuards:9,coreFactCells:51,coreGradeCounts:gradeCounts,roadsideConfirmedCells:3,generatedFeatureRows:207,summaryClauses:6,availabilityGuards:3,
 narrowHolds:{height:3,towing:2,bootProtocol:3,dc10to80NotPublished:2},inputPins: pins.length,existingRows:0,originalZeroRowProofUnchanged:true,C1:'OPEN: no complete current maker MY26 list or two independent whole-market lists',currentProjectTypeScript:'UNPASSED; no compiler attempt',selectedActualConsumerParity:'NOT RUN',fullStage:'NOT RUN',liveApplied:false
});
write('candidate-manifest-v1.json',{status:'FROZEN_FOR_INDEPENDENT_TYPED_CANDIDATE_REVIEW',files:[packetPin,afterPin,researchPin,provenance,result,pin(dir+'/cupra-market-reconciliation-v1.json'),pin(dir+'/admission-audit-v1.json'),pin(dir+'/prepared-command.json'),pin(dir+'/source-pins.json')]});
console.log(JSON.stringify({result:result.path,candidate:packetPin,coreGradeCounts:gradeCounts,generatedFeatureRows:207,liveApplied:false}));
