from pathlib import Path
import json,hashlib
A=Path('/tmp/cupra-packet/typed-preparation-v3');B=Path('/tmp/cupra-packet/typed-preparation-v4')
def pin(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
for p in json.loads((A/'source-pins.json').read_text()):assert pin(p['path'])==p
names=['assembly-input.json','base-research-input.json','cupra-market-reconciliation-v2.json','admission-audit-v2.json','static-input-audit.json','v1-to-v2-provenance.json','v2-to-v3-provenance.json','materialize.mts','run.py','prepare-command.py']
for name in names:
 text=(A/name).read_text().replace('must not use advanced full beam assist','should not use advanced full beam assist')
 if name in ['materialize.mts','run.py','prepare-command.py']:text=text.replace('typed-preparation-v3','typed-preparation-v4')
 if name=='prepare-command.py':text=text.replace("files.update(O.glob('*'));", "files.update(O.glob('*'));files.update(Path('/tmp/cupra-packet/typed-preparation-v3').glob('*'));" )
 with (B/name).open('x') as f:f.write(text)
with (B/'v3-to-v4-provenance.json').open('x') as f:json.dump(dict(status='v3_preserved_superseded_before_execution',v3PreparedManifest=pin(A/'prepared-command.json'),v3SourcePins=pin(A/'source-pins.json'),originalV3PinsStillPass=True,changes=['Match the government advisory precisely: affected drivers should not use advanced full beam assist, replacing overly strong must not in buyer-visible qualifications, admission warning and preservation assertion. No other source, fact, grade, admission or guard change.'],source='https://www.vehiclerecalls.gov.au/recalls/rec-006687',typescriptCompilerAttempted=False),f,indent=2);f.write('\n')
