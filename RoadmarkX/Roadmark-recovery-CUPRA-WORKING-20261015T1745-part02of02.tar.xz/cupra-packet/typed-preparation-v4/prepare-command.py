from pathlib import Path
import json,hashlib,re
O=Path('/tmp/cupra-packet/typed-preparation-v4');S=Path('/tmp/cupra-packet/source-review-v3');R=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(name,x):
 with (O/name).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
source=json.loads((S/'source-admission-manifest.json').read_text())
files=set(Path(p['path']) for p in source['files']);files.add(S/'source-admission-manifest.json')
files.update(O.glob('*'));files.update(Path('/tmp/cupra-packet/typed-preparation-v3').glob('*'));files.update(Path('/tmp/cupra-packet/typed-preparation-v2').glob('*'));files.update(Path('/tmp/cupra-packet/typed-preparation-v1').glob('*'));files.add(Path('/tmp/cupra-review/source-review-v3-accepted.json'))
audit=json.loads((O/'static-input-audit.json').read_text());files.update(Path(x['path']) for x in audit['modelAndCriteriaInputs']);files.add(Path(audit['registry']['path']))
receipt=json.loads(Path('/tmp/cupra-research/retained-selection-proof.json').read_text());files.add(Path(receipt['acceptedIndex']))
registry=json.loads((R/'data/m1-brand-updates/registry.json').read_text())
for p in registry['packets']:files.add(R/'data/m1-brand-updates'/p)
files.update(R/p for p in ['src/lib/brand-updates.ts','src/lib/availability-corrections.ts','src/lib/evidence-grading.ts','src/lib/buyer-availability.ts','src/lib/types.ts','scripts/reporting/m1-reconciliation.ts','package.json','pnpm-lock.yaml','tsconfig.json'])
# Static closure only. No TypeScript, runtime import, compiler or catalogue loader.
queue=[f for f in files if f.suffix in ['.ts','.tsx','.mts']];seen=set()
while queue:
 f=queue.pop()
 if f in seen:continue
 seen.add(f)
 for spec in re.findall(r'''(?:from\s*|import\s*\(?\s*|require\(\s*)["']([^"']+)["']''',f.read_text()):
  if not spec.startswith(('.',str(R))):continue
  root=(f.parent/spec).resolve() if spec.startswith('.') else Path(spec)
  choices=[root,Path(str(root)+'.ts'),Path(str(root)+'.tsx'),Path(str(root)+'.json'),root/'index.ts']
  hit=next((p for p in choices if p.is_file()),None)
  if hit:
   files.add(hit)
   if hit.suffix in ['.ts','.tsx','.mts']:queue.append(hit)
assert not [p for p in files if p.name in ['catalogue.ts','research.ts'] and p.parent==R/'src/lib']
write('source-pins.json',[pin(f) for f in sorted(files)])
m=dict(status='prepared_not_executed',script=pin(O/'materialize.mts'),sourcePins=pin(O/'source-pins.json'),assemblyInput=pin(O/'assembly-input.json'),baseResearch=pin(O/'base-research-input.json'),reconciliation=pin(O/'cupra-market-reconciliation-v2.json'),wrapper=pin(O/'run.py'),command=['node','--max-old-space-size=256','--max-semi-space-size=1','--import','tsx',str(O/'materialize.mts'),'--root-execution-granted'],workdir=str(R),timeoutSeconds=90,killGraceSeconds=10,automaticRetry=False,rootExecutionGrantRequired=True,exclusiveHeavySlotRequired=True,outputDirectory=str(O/'output'),scope='Only actual addition-builder materialization for three new MY26 Tavascan versions against retained zero-CUPRA rows, real 69 criteria and unchanged retained-plus-registered models. Actual null fact guards, producer-generated availability snapshots, earned core grades and generated 207 feature rows. No full catalogue, compiler, tests, build, browser, live edits, registry change, publication or automatic retry. This does not run selected consumer parity or full-stage validation.',currentProjectTypeScript='UNPASSED; no retry')
write('prepared-command.json',m)
write('root-grant-template.json',dict(authorized=False,exclusiveHeavySlotGranted=False,action='run_single_cupra_addition_materialization',preparedManifestSha256=pin(O/'prepared-command.json')['sha256'],command=m['command'],automaticRetry=False,note='Template only. Independent readiness review and root exclusive-slot grant required.'))
print(json.dumps(dict(manifest=pin(O/'prepared-command.json'),sourcePinCount=len(files),executed=False),indent=2))
