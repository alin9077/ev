import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import readline from 'node:readline';
import assert from 'node:assert/strict';
const root='/tmp/skoda-research';
const manifestPath='/tmp/mercedes-staging-plan/consumer-preparation/v5/manifests/report-v5.json';
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const mBytes=fs.readFileSync(manifestPath);
assert.equal(sha(mBytes),'70564bf4cdc4e367d59d98fe49026af93727532937470111b26fa4fb3b3c5bde');
const m=JSON.parse(mBytes), anchors=m.anchors;
const pins=new Map(m.inputPins.map(p=>[`${p.anchor}\0${p.file}`,p]));
const readRefs=[];
const locate=ref=>path.join(anchors[ref.anchor],ref.file);
function readSmall(ref){
 const pin=pins.get(`${ref.anchor}\0${ref.file}`);assert(pin);
 const bytes=fs.readFileSync(locate(ref));assert.equal(sha(bytes),pin.sha256);
 readRefs.push({...ref,actualSha256:sha(bytes)});return JSON.parse(bytes);
}
const receipt=readSmall(m.coreReceipt);let index=readSmall(receipt.storageIndex);
const topIndex=index, selected=new Map();let baseline;
while(true){
 const d=index.cars; const replacements=readSmall(d.replacements);
 for(const car of replacements)if(['Skoda','Škoda'].includes(car.brand)&&!selected.has(car.id))selected.set(car.id,car);
 if(d.baseline.format==='storage-index')index=readSmall(d.baseline);
 else{baseline=d.baseline;break;}
}
const input=readline.createInterface({input:fs.createReadStream(locate(baseline)),crlfDelay:Infinity});
for await(const line of input){if(!line.includes('Skoda')&&!line.includes('Škoda'))continue;const car=JSON.parse(line);if(['Skoda','Škoda'].includes(car.brand)&&!selected.has(car.id))selected.set(car.id,car);}
const cars=[...selected.values()],digests=[];
for(const car of cars){
 const bytes=Buffer.from(JSON.stringify(car)+'\n'),expected=topIndex.cars.carHashes.find(r=>r.id===car.id);
 assert(expected);assert.equal(sha(bytes),expected.afterSha256);assert.equal(bytes.length,expected.bytes);
 digests.push({id:car.id,sha256:sha(bytes),bytes:bytes.length,acceptedIndexRow:expected});
}
const sourceIds=new Set(cars.flatMap(c=>Object.values(c.facts).flatMap(f=>f.sourceIds||[])));
const sources=[];const sourceRef=topIndex.research.sources;
const src=readline.createInterface({input:fs.createReadStream(locate(sourceRef)),crlfDelay:Infinity});
for await(const line of src){const s=JSON.parse(line);if(sourceIds.has(s.id))sources.push(s);}
fs.writeFileSync(path.join(root,'retained-before-cars.json'),JSON.stringify(cars,null,2)+'\n',{flag:'wx'});
fs.writeFileSync(path.join(root,'retained-before-sources.json'),JSON.stringify(sources,null,2)+'\n',{flag:'wx'});
const report={schemaVersion:1,status:'selected_unchanged_skoda_rows_from_accepted_derived_storage',brand:'Skoda',asOf:'2026-10-15',manifest:{path:manifestPath,sha256:sha(mBytes)},readAndVerifiedSmallRefs:readRefs,streamedOriginalRows:baseline,sourceRef,selectedCarDigests:digests,carCount:cars.length,sourceCount:sources.length,productionCatalogueLoaderCalls:0,newCanonicalCapture:false,limits:'This is a selected unchanged-car reuse of accepted derived storage. The later approved EQA-only correction and Leapmotor/Mazda packets do not touch Škoda peers; this selected extraction is the unchanged Skoda part of the derived pre-Skoda chain. No fresh whole-catalogue export or broad input rehash was performed.'};
fs.writeFileSync(path.join(root,'retained-before-selection-receipt.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({cars:cars.map(c=>({id:c.id,model:c.model,trim:c.trim,year:c.year,drive:c.drive,availability:c.availability,coreKeys:Object.keys(c.facts).slice(0,25)})),sources:sources.length}));
