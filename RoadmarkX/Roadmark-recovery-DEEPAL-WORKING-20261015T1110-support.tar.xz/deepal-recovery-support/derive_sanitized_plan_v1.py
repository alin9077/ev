from capture_v2 import C,load,dump
source=load(C/'source-package.json');proof=load(C/'proof-packages-v2.json')['archives'];assert proof
dump(C/'ARCHIVE-PLAN-sanitized-v1.json',{'archives':[source]+proof,'scope':'Exact source unchanged; copy-sanitized proof replacements only; final plan adds one unique support archive with these archive identities unchanged'})
