#!/usr/bin/env python3
"""Exact whole-file pattern semantics for new members; proven content/rule cache for old source."""
import sys,pathlib,json,hashlib,importlib.util,lzma,tarfile,re,datetime,inspect
from capture_v2 import C,R,BASE,OLD,SANBASE,load,dump,pin,check,safe,CHUNK
LEAPMOTOR=C.parent/'leapmotor-working-20261015T0155';MAZDA=C.parent/'mazda-working-20261015T0405'
A=R/'privacy-audit-20261014T0355';sys.path.insert(0,str(A))
spec=importlib.util.spec_from_file_location('residual',A/'final_residual_scan_memory_bounded.py');scan=importlib.util.module_from_spec(spec);spec.loader.exec_module(scan)
ENGINE_PINS={'final_residual_scan_memory_bounded.py':'db71353ba5fe98021f68cd9aeaae6eb4e1878627fb4985278b11457baf837238','chunked_lower_find.py':'6de208f633b05ef1cb894ca8e896c4a489bb093eb1339134c4b1d7158263ec1f','audit_scan.py':'54ee0827089ad8202a24c6769a4178dee28fe96b85f1fd8a627a15703c15f3b2','runtime_token_scan.py':'4ea9c6be9b292bbe126fcc2f8d7b3254a1dc941c49d78b263c9203d0025f9c46'}
class ByteSearch:
 def __init__(self,values):
  self.values=list(values);assert all(self.values);self.tail=b'';self.total=0;self.keep=max(map(len,self.values))-1;self.next=[0]*len(self.values);self.matches=set()
 def feed(self,b):
  data=self.tail+b;base=self.total-len(self.tail)
  for i,v in enumerate(self.values):
   pos=max(0,self.next[i]-base)
   while True:
    q=data.find(v,pos)
    if q<0:break
    end=base+q+len(v)
    if end>self.total:self.matches.add((base+q,end))
    self.next[i]=end;pos=q+len(v)
  self.total+=len(b);self.tail=data[-self.keep:] if self.keep else b''
def verified_seed_values():
 provenance=load(C/'SEED-PROVENANCE.json')
 for r in provenance['metadataPins']:check(pathlib.Path(r['path']),r)
 want={(r['archive'],r['member']):r for r in provenance['historicalSeedMembers']};seen=set()
 def verify_seed(a,m,b):
  key=(a['filename'],m.name);assert key not in seen;seen.add(key);r=want[key];assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
 code=inspect.getsource(scan.source_values);needle='b=t.extractfile(m).read();s=b.decode'
 assert code.count(needle)==1
 code=code.replace(needle,'b=t.extractfile(m).read();verify_seed(a,m,b);s=b.decode')
 scope=dict(scan.__dict__);scope['verify_seed']=verify_seed;exec(compile(code,str(A/'final_residual_scan_memory_bounded.py'),'exec'),scope)
 result=scope['source_values']();assert seen==set(want)
 # Receipt records identities/counts only, never extracted values. Decisions remain unchanged.
 import os,time
 receiptDir=C/'seed-read-invocations';receiptDir.mkdir(exist_ok=True);record={'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'processId':os.getpid(),'exactPinnedMembersReadAndVerified':len(seen),'historicalArchives':len({a for a,m in seen}),'memberIdentityListPin':pin(C/'SEED-PROVENANCE.json'),'noExtractedValuesPersisted':True,'scope':'Targeted historical seed reconstruction only, not a full base privacy scan or restore'};assert record['exactPinnedMembersReadAndVerified']==200 and record['historicalArchives']==21;dump(receiptDir/f'{os.getpid()}-{time.time_ns()}.json',record)
 return result

def base_current_variants():
 known,benign,seeds,errors=verified_seed_values();assert not errors;historical=scan.variants_for(known);assert len(known)==55 and len(historical)==373
 san=load(SANBASE/'RUNTIME-SANITATION-REPORT.json');sensitive={}
 for r in san['files']:
  p=pathlib.Path('/tmp')/r['path'];check(p,{'bytes':r['originalBytes'],'sha256':r['originalSHA256']});sensitive[r['path']]=p.read_bytes()
 preliminary=load(A/'MERCEDES-RESEARCH-SAFETY-PRELIMINARY-TREE-REPORT.json');values=set()
 for f in preliminary['unclassifiedRuntimeCandidates']:
  assert f['layer']=='plain' and f['field'] in {'nonce','_wpnonce','apiKey'};s=sensitive[f['member']].decode();v=s[f['valueCharStart']:f['valueCharEnd']];assert len(v)==f['valueLength'];values.add(v.encode())
 extra={'mercedes-research/people-movers/evito-redbook-2026.error.raw':{'cookie','cid','e'},'mercedes-research/people-movers/evans-2023-au-maker-brochure-mirror.error.raw':{'cN','cH','cRay','md','mdrd'}}
 for n,fields in extra.items():
  s=sensitive[n].decode()
  for field in fields:
   ms=list(re.finditer(r'''["']?'''+re.escape(field)+r'''["']?\s*:\s*(["'])(.*?)\1''',s));assert ms
   for m in ms:values.add(m[2].encode())
  for m in re.finditer(r'''__cf_chl_(?:f_|rt_)?tk=([^&#"'\\\s<>]+)''',s):values.add(m[1].encode())
 forms=scan.variants_for({v:[] for v in values});assert len(values)==20 and len(forms)==128
 return set(historical)|set(forms),benign,{'historicalValues':55,'historicalForms':373,'mercedesValues':20,'mercedesForms':128,'originalSeedMembers':seeds}
def inherited_current_variants():
 forms,benign,counts=base_current_variants();values=set();inventory=load(LEAPMOTOR/'JSON-SANITIZER-CANDIDATES-v1.json')
 assert len(inventory['candidateFiles'])==19 and inventory['candidateLocations']==51
 for r in inventory['candidateFiles']:
  p=pathlib.Path(r['originalPath']);check(p,{'bytes':r['originalBytes'],'sha256':r['originalSHA256']});j=json.loads(p.read_text())
  for z in r['locations']:
   assert z['pointer'].endswith('/headers/Set-Cookie');v=j
   for part in z['pointer'].split('/')[1:]:v=v[part.replace('~1','/').replace('~0','~')]
   assert isinstance(v,str) and len(v)==z['valueLength'];name,sep,cookie=v.split(';',1)[0].partition('=');assert sep and cookie;values.update([v.encode(),cookie.encode()])
 newforms=scan.variants_for({v:[] for v in values});assert len(values)==26 and len(newforms)==171
 counts.update(leapmotorCookieAndHeaderValues=len(values),leapmotorCookieForms=len(newforms));return forms|set(newforms),benign,counts

def inherited_seed_sets():
 inherited,benign,counts=inherited_current_variants();headers=set();bare=set();pairs=set();inventory=load(MAZDA/'JSON-SANITIZER-CANDIDATES-v1.json');diagnosis=load(MAZDA/'INDEPENDENT-MAZDA-COOKIE-COLLISION-DIAGNOSIS-v1.json')
 assert len(inventory['candidateFiles'])==8 and inventory['candidateLocations']==8
 for r in inventory['candidateFiles']:
  p=pathlib.Path(r['originalPath']);check(p,{'bytes':r['originalBytes'],'sha256':r['originalSHA256']});j=json.loads(p.read_text())
  for z in r['locations']:
   assert z['pointer']=='/headers/Set-Cookie';v=j['headers']['Set-Cookie'];assert isinstance(v,str) and len(v)==z['valueLength']
   pair=v.split(';',1)[0];name,sep,cookie=pair.partition('=');assert sep and cookie
   assert (name=='EPiStateMarker' and len(cookie)==4 and isinstance(json.loads(cookie),bool)) or (name=='cg_ab_variant' and len(cookie) in (7,11))
   headers.add(v.encode());bare.add(cookie.encode());pairs.add(pair.encode())
 assert len(headers)==len(bare)==len(pairs)==3
 formValues=set();mapping=load(MAZDA/'HTML-FORM-TOKEN-SANITATION-MAPPING.json');assert mapping['fileCount']==13 and mapping['locationCount']==13
 for r in mapping['files']:
  p=pathlib.Path(r['originalPath']);check(p,{'bytes':r['originalBytes'],'sha256':r['originalSHA256']});b=p.read_bytes()
  for z in r['ranges']:
   assert z['field']=='__RequestVerificationToken';v=b[z['byteStart']:z['byteEndExclusive']];assert len(v)==155;formValues.add(v)
 assert len(formValues)==13
 variant=lambda values:set(scan.variants_for({v:[] for v in values}))
 public=variant(bare);headerforms=variant(headers);pairforms=variant(pairs);tokenforms=variant(formValues);oldMazda=variant(headers|bare);blocking=set(inherited)|headerforms|pairforms|tokenforms;allforms=blocking|public
 counts.update(mazdaCookieAndHeaderValues=len(headers|bare),mazdaCookieForms=len(oldMazda),mazdaPublicBareValues=len(bare),mazdaPublicBareForms=len(public),mazdaCompleteHeaderValues=len(headers),mazdaCompleteHeaderForms=len(headerforms),mazdaCookiePairValues=len(pairs),mazdaCookiePairForms=len(pairforms),mazdaFormTokenValues=len(formValues),mazdaFormTokenForms=len(tokenforms))
 return allforms,blocking,public,benign,counts

def seed_sets():
 forms,blocking,public,benign,counts=inherited_seed_sets()
 from audi_scan_additions_v3 import audi_values
 extra,more=audi_values(scan.variants_for);counts.update(more)
 from deepal_scan_additions_v2 import deepal_values
 deepal,more=deepal_values(scan.variants_for);counts.update(more)
 return forms|extra|deepal,blocking|extra|deepal,public,benign,counts

def current_variants():
 forms,blocking,public,benign,counts=seed_sets();return forms,benign,counts

def classify_exact_matches(search,blocking_search,public_search,blocking_context):
 blocked=[];collisions=[]
 for start,end in sorted(search.matches):
  overlap=any(start<b and a<end for a,b in blocking_search.matches)
  if (start,end) in public_search.matches and not overlap and not blocking_context:collisions.append((start,end))
  else:blocked.append((start,end))
 assert len(blocked)+len(collisions)==len(search.matches)
 return blocked,collisions

def source_cache():
 for name,h in ENGINE_PINS.items():assert pin(A/name)['sha256']==h,name
 paths={'source-capture.json':'e19d8591f50488582baffc52257e48fac0c7e842a09c5061fff286c09ff6fef9','INDEPENDENT-STREAM-HASH-RECEIPT.json':'390be1d1f11df5315a6ff780c776bf8e5fba1d086b5c4de90198afa6d1e330a5','INDEPENDENT-XPENG-REGISTERED-VERIFICATION.json':'2281e2a468d0b1dbc336ebf3ef686116ab1111300f252e7ae5f27b6702ccb86a'}
 for n,h in paths.items():assert pin(OLD/n)['sha256']==h,n
 v=load(OLD/'INDEPENDENT-XPENG-REGISTERED-VERIFICATION.json');part=v['privacyVerification']['parts'][0];rp=A/'XPENG-REGISTERED-WORKING-NEW-ARCHIVE-PART01-RESIDUAL-REPORT.json';assert pin(rp)==part['report'];raw=load(rp);assert raw['status']=='clean' and raw['regularFilesScanned']==657 and raw['recognizedBenignRuntimeCandidateCount']==0
 assert not any(raw[k] for k in ['exactValueMatches','primaryHeaderCandidates','unclassifiedRuntimeCandidates','errors']);assert part['archiveSHA256']=='958ab268995fb3b59c64b1fd177e3faceec38ad74bb145b94f77004c4ec9aed5' and part['resources']['exitCode']==0 and '--no-patterns' not in part['resources']['command']
 rows={r['path']:r for r in load(OLD/'INDEPENDENT-STREAM-HASH-RECEIPT.json')['newFiles'] if r['path'].startswith('roadmark/')};assert len(rows)==657
 for r in load(OLD/'source-capture.json')['files']:assert rows['roadmark/'+r['path']]=={'path':'roadmark/'+r['path'],'bytes':r['bytes'],'sha256':r['sha256']}
 rows.pop('roadmark/SOURCE-FILE-MANIFEST.json');assert len(rows)==656
 return rows,{'priorInputPins':paths,'rulePins':ENGINE_PINS,'priorReport':pin(rp),'priorSourceArchiveSHA256':part['archiveSHA256'],'priorBenignRuntimeExceptions':0,'key':'exact archive member path + bytes + SHA256 + complete unchanged engine/rules; new known values always scanned'}
def scan_patterns(b,name,primary,runtime,benign):
 ps,_,_=primary(b,name);scan.release_memory();us=[];bc=0
 if b.startswith((b'\xff\xfe',b'\xfe\xff')):s=b.decode('utf-16',errors='replace')
 elif b[:1024].count(b'\x00')>len(b[:1024])//5:s=None
 else:s=b.decode('utf8',errors='replace')
 if s is not None:
  candidates=runtime(s)
  for f in candidates:
   if f['layer']=='plain':
    v=s[f['valueCharStart']:f['valueCharEnd']]
    if v in benign:bc+=1;continue
   elif any(g['layer']=='plain' and g['field']==f['field'] for g in candidates):continue
   us.append(f)
 return ps,us,bc

def main():
 ap=pathlib.Path(sys.argv[1]);report=pathlib.Path(sys.argv[2]);assert not report.exists();planPath=pathlib.Path(sys.argv[3]);assert planPath.parent.resolve()==C and planPath.name in ('ARCHIVE-PLAN-sanitized-v1.json','ARCHIVE-PLAN.json');plan=load(planPath);a=next(r for r in plan['archives'] if r['file']==str(ap));check(ap,a);expected={r['path']:r for r in a['memberFiles']};cache,provenance=source_cache();forms,blocking,public,benign,counts=seed_sets();primary,runtime=scan.patterns();scan.release_memory();rows=[];findings=[];prim=[];rt=[];codeClassified=[];templateClassified=[];bc=0;collisionTotal=0;seen=set()
 with lzma.open(ap,'rb') as stream:
  with tarfile.open(fileobj=stream,mode='r|') as t:
   for m in t:
    safe(m.name);assert m.isfile() and m.name not in seen and m.name in expected;seen.add(m.name);e=expected[m.name];cached=cache.get(m.name)==e;h=hashlib.sha256();search=ByteSearch(forms);blockingSearch=ByteSearch(blocking);publicSearch=ByteSearch(public);parts=[] if not cached else None
    with t.extractfile(m) as f:
     while b:=f.read(CHUNK):h.update(b);search.feed(b);blockingSearch.feed(b);publicSearch.feed(b);parts.append(b) if parts is not None else None
    actual={'path':m.name,'bytes':search.total,'sha256':h.hexdigest()};assert actual==e
    ps=[];us=[]
    if not cached:
     data=b''.join(parts);del parts;ps,us,bcount=scan_patterns(data,m.name,primary,runtime,benign);from audi_scan_additions_v3 import code_context;ps,classified=code_context(ps,data,m.name);codeClassified.extend(classified);from deepal_scan_additions_v2 import code_context as deepal_code_context,template_context;ps,classified=deepal_code_context(ps,data,m.name);codeClassified.extend(classified);us,classified=template_context(us,data,m.name);templateClassified.extend(classified);del data;prim.extend({'member':m.name,**r} for r in ps);rt.extend({'member':m.name,**r} for r in us);bc+=bcount
    unresolved,collisions=classify_exact_matches(search,blockingSearch,publicSearch,bool(ps or us));collisionTotal+=len(collisions)
    findings.extend({'member':m.name,'byteStart':a,'byteEndExclusive':z} for a,z in unresolved)
    rows.append({**actual,'exactMatchesObserved':len(search.matches),'classifiedPublicLexicalCollisions':len(collisions),'unresolvedExactMatches':len(unresolved),'patternVerdict':'exact-prior-source-cache' if cached else 'current-full-unchanged-scanner'});scan.release_memory()
  while stream.read(CHUNK):pass
 assert seen==set(expected);result={'status':'clean' if not(findings or prim or rt) else 'review-required','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':ap.name,'archivePin':pin(ap),'members':rows,'regularFilesScanned':len(rows),'bytesScanned':sum(r['bytes'] for r in rows),'targetedHistoricalSeedReadDependency':{'receipt':pin(C/'TARGETED-SEED-READ-DEPENDENCY.json'),'exactPinnedMembersReadAndVerified':200,'historicalArchives':21,'baseChainOverlaps':9,'fullBaseScanOrRestorePerformed':False},'currentByteSearchForEveryMember':True,'chunkBytes':CHUNK,'patternCacheProvenance':provenance,**counts,'exactValueMatches':findings,'classifiedPublicLexicalCollisions':collisionTotal,'classificationRule':'Only exact pinned Mazda public bare forms, with no overlap with blocking inherited/header/cookie-pair/form-token searches and no primary/runtime context in this member; every original byte search retained','classifiedExactCodeHeaderCandidates':codeClassified,'classifiedExactTemplateRuntimeCandidates':templateClassified,'primaryHeaderCandidates':prim,'unclassifiedRuntimeCandidates':rt,'recognizedBenignRuntimeCandidateCount':bc,'errors':[],'limitations':['No decryption','No recursive unpacking of embedded compressed/proprietary content','Standalone base64 variants do not cover arbitrary wrapping/alignment','No universal secret-free claim']};dump(report,result);print(json.dumps({'status':result['status'],'members':len(rows),'cachedPatterns':sum(r['patternVerdict']=='exact-prior-source-cache' for r in rows),'findings':len(findings)+len(prim)+len(rt)}));sys.exit(0 if result['status']=='clean' else 2)
if __name__=='__main__':main()
