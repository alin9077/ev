#!/usr/bin/env python3
"""Bind immutable metadata and completed phases; no archive or source payload reads."""
import ast, datetime, hashlib, json, pathlib, resource, stat, sys
sys.dont_write_bytecode=True
P=pathlib.Path
C=P(__file__).resolve().parent
OUT=C/'INDEPENDENT-DEEPAL-REPLAY-INPUTS-v1.json'
LIMIT=268435456

def need(value,message):
    if not value: raise AssertionError(message)

def identity(path):
    s=path.lstat();need(stat.S_ISREG(s.st_mode) and not any(p.is_symlink() for p in path.parents),'nonregular metadata input')
    return [s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev]

def pin(path):
    path=P(path);before=identity(path);h=hashlib.sha256();count=0
    with path.open('rb') as f:
        while block:=f.read(65536): h.update(block);count+=len(block)
    need(identity(path)==before and count==before[0],'unstable metadata input')
    return {'path':str(path),'bytes':count,'sha256':h.hexdigest()}

def load(path): return json.loads(P(path).read_bytes())

def main():
    need(resource.getrlimit(resource.RLIMIT_AS)==(LIMIT,LIMIT),'256 MiB ceiling absent')
    need(not OUT.exists(),'preserve prior input binding')
    names={
      'scope':'FROZEN-CAPTURE-SCOPE.json','initialIdentities':'INDEPENDENT-DEEPAL-INITIAL-IDENTITIES-v1.json',
      'sourceCapture':'source-capture.json','proofCapture':'proof-capture-v2.json',
      'sourcePackage':'source-package.json','proofPackages':'proof-packages-v2.json',
      'supportInventory':'SUPPORT-MEMBER-INVENTORY.json','supportReuse':'SUPPORT-REUSE-MAPPING.json','supportPackage':'support-package.json',
      'restorePlan':'RESTORE-PLAN.json','archivePlan':'ARCHIVE-PLAN.json','initialArchivePlan':'ARCHIVE-PLAN-initial.json',
      'freshRestoreManifest':'FRESH-ONLY-RESTORE-MANIFEST.json','privacyGate':'ALL-ARCHIVE-PRIVACY-GATE.json',
      'application':'APPLICATION-ASSERTION-CONTRACT.json','dependencyMap':'INHERITED-DEPENDENCY-RECONSTRUCTION-v1.json',
      'dependencyProposal':'INDEPENDENT-DEEPAL-DEPENDENCY-PROPOSAL-v1.json','dependencyReview':'INDEPENDENT-DEEPAL-DEPENDENCY-REVIEW-v1.json',
      'copySanitation':'COPY-SANITATION-MAPPING-v2.json','keyApprovals':'PROSE-KEY-RENAME-APPROVALS.json','symlinks':'SYMLINK-RECONSTRUCTION.json',
      'seedProvenance':'SEED-PROVENANCE.json','inheritedLocalSeedScope':'INHERITED-LOCAL-SEED-READ-SCOPE.json','imageProvenance':'IMAGE-PROVENANCE.json',
      'originalProofCapture':'proof-capture-v1.json','originalProofPackages':'proof-packages.json','sanitizedArchivePlan':'ARCHIVE-PLAN-sanitized-v1.json',
      'runtimeClassification':'INDEPENDENT-DEEPAL-RUNTIME-CLASSIFICATION-v3.json','runtimeApproval':'APPROVED-DEEPAL-RUNTIME-REMEDIATION.json',
      'supportSyntaxClassification':'INDEPENDENT-DEEPAL-SUPPORT-SYNTAX-CLASSIFICATION-v1.json',
      'additiveInventory':'ADDITIVE-DEEPAL-FIELD-INVENTORY-v2.json','additiveInventoryReview':'INDEPENDENT-DEEPAL-ADDITIVE-INVENTORY-SCRIPT-REVIEW-v1.json',
      'privacyAdapterContract':'DEEPAL-PRIVACY-ADAPTER-CONTRACT.json','copyParity':'INDEPENDENT-DEEPAL-COPY-PARITY-v1.json'}
    metadata={key:pin(C/name) for key,name in names.items()}
    need(load(metadata['privacyGate']['path'])['result']=='PASS' and load(metadata['copyParity']['path'])['result']=='PASS','final gates unavailable')
    need(metadata['privacyAdapterContract']['sha256']=='b5b491c4a3f27b3db94cff1ac7cd17079327f69829d64002fe69b95042405555','final privacy adapter contract differs')
    scripts=[]
    for path in sorted(C.glob('*.py')):
        ast.parse(path.read_bytes());scripts.append(pin(path))
    need(any(r['path']==str(C/'independent_deepal_recovery_v3.py') and r['sha256']=='152c4a4c734e534e664c9e0dc439844ead0ce5b44f10202d47116239765b62d3' for r in scripts),'reviewed final checker absent')
    scan_specs=[(f'scan-fresh-{i:02d}',False,0 if i==1 else 2,'initialArchivePlan','privacy_v1.py') for i in range(1,4)]
    scan_specs += [(f'scan-sanitized-{i:02d}',True,0,'sanitizedArchivePlan' if i<4 else 'archivePlan','privacy_v3.py') for i in range(1,5)]
    scans=[];scan_terminals=set()
    for name,final,expected,plan_key,engine in scan_specs:
        rp,tp=C/(name+'.json'),C/(name+'.resources.json');report,term=load(rp),load(tp);command=term['command']
        need(term['exitCode']==expected and not term['timedOut'] and term['addressSpaceLimitBytes']==LIMIT,'unexpected scan terminal')
        need(len(command)==5 and P(command[1])==C/engine and command[3]==str(rp) and command[4]==metadata[plan_key]['path'],'scanner command/plan binding differs')
        need(report['status']==('clean' if expected==0 else 'review-required'),'scanner status differs')
        scans.append({'archive':report['archive'],'report':pin(rp),'terminal':pin(tp),'command':command,'archivePlan':metadata[plan_key],'expectedExitCode':expected,'finalCoverage':final})
        scan_terminals.add(str(tp))
    phases=[]
    for path in sorted(C.glob('*.resources.json')):
        if str(path) in scan_terminals:continue
        value=load(path);command=value['command'];code=value['exitCode']
        need(not any(P(a).name.startswith('privacy_v') and P(a).suffix=='.py' for a in command),'unaccounted production scanner attempt')
        allowed_failure=path.name=='independent-runtime-review-v1.resources.json' and code==1
        allowed_review=path.name.startswith('support-pattern-preflight-') and code==2
        need(code==0 or allowed_failure or allowed_review,'unreviewed failed preparatory phase')
        phases.append({'phase':path.name.removesuffix('.resources.json'),'terminal':pin(path),'command':command,'expectedExitCode':code})
    counts={key:len(list((C/folder).glob('*.json'))) for key,folder in [('historical','seed-read-invocations'),('audi','audi-seed-read-invocations'),('deepal','deepal-seed-read-invocations')]}
    need(counts=={'historical':7,'audi':7,'deepal':4},'unexpected seed invocation counts before replay')
    result={'result':'APPROVED_PINNED_FRESH_REPLAY_INPUTS','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'metadata':metadata,'scriptPins':scripts,'phaseCommands':phases,'scanReports':scans,'expectedScanInvocations':counts,'noSourceArchiveOrSeedPayloadReads':True,'postSealMetadataBindingOnly':True}
    for row in list(metadata.values())+scripts:need(pin(row['path'])==row,'input changed while binding')
    with OUT.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({'result':result['result'],'metadataPins':len(metadata),'scriptPins':len(scripts),'phaseTerminals':len(phases),'scanAttempts':len(scans),'seedInvocations':counts,'outputPin':pin(OUT)}))

if __name__=='__main__':main()
