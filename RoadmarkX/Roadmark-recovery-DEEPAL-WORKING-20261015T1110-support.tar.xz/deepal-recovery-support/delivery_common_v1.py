#!/usr/bin/env python3
"""Small identity helpers; no payload extraction, scanning or source embedding."""
import datetime
import hashlib
import json
import os
import pathlib
import stat

C = pathlib.Path(__file__).resolve().parent
BASE = C.parent / 'audi-working-20261015T0800'
D = C / 'deliverables'
STEM = 'DEEPAL-WORKING-20261015'
CHUNK = 65536
LIMIT = 268435456
DOCS = [D / ('Roadmark-RECOVERY-' + kind + '-' + STEM + suffix) for kind, suffix in
        [('INDEX', '.md'), ('MANIFEST', '.json'), ('VERIFICATION', '.json')]]
DOCS.append(D / 'Roadmark-DEEPAL-M1-UPDATE-20261015.md')
ACTIVE = D / ('Roadmark-RECOVERY-ACTIVE-STATE-' + STEM + '.json')
BASE_MANIFEST = BASE / 'deliverables/Roadmark-RECOVERY-MANIFEST-AUDI-WORKING-20261015.json'
BASE_TERMINAL = BASE / 'FINAL-AUDI-UPLOAD-RECEIPTS.json'
RECOVERY = 'INDEPENDENT-DEEPAL-RECOVERY-VERIFICATION-v1.json'
GATE = 'ALL-ARCHIVE-PRIVACY-GATE.json'
DEPENDENCY = 'INHERITED-DEPENDENCY-RECONSTRUCTION-v1.json'
COUNT_KEYS = ('archiveCount', 'logicalFiles', 'logicalBytes', 'freshFiles', 'freshBytes',
              'fullSourceFiles', 'baseArchivesReused')
INHERIT_KEYS = ('sourceSanitation', 'originalRawCaptureReplayCompatibility',
               'missingHistoricalCaptureProvenance', 'priorToyotaBrowserScreenshotExclusions',
               'sourcePackagingExclusions', 'historicalExclusions', 'lastPassedRecovery',
               'optionalReconstruction', 'partialOutputRetention', 'reusedVerifier',
               'cleanupCandidatesExcludedFromRestore', 'cleanupListLibraryFileId',
               'exactDuplicateProvenance')
DELIVERY_SCRIPTS = ('delivery_common_v1.py', 'build_documents_v1.py',
                    'independent_deepal_documents_v1.py', 'build_active_receipt_v1.py',
                    'finalize_upload_receipt_v1.py', 'preupload_gate_v1.py',
                    'scan_documents_v1.py')

def ck(value, message):
    if not value:
        raise AssertionError(message)

def load(path):
    return json.loads(pathlib.Path(path).read_text())

def dump(path, value):
    with pathlib.Path(path).open('x') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def pin(path):
    path = pathlib.Path(path)
    before = path.lstat()
    ck(stat.S_ISREG(before.st_mode) and not any(p.is_symlink() for p in path.parents),
       'not an ordinary unlinked file: ' + str(path))
    digest, size = hashlib.sha256(), 0
    with path.open('rb') as handle:
        while block := handle.read(CHUNK):
            digest.update(block)
            size += len(block)
    after = path.lstat()
    ck((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
       (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
       'file changed during pin: ' + str(path))
    ck(size == before.st_size, 'short file read')
    return {'bytes': size, 'sha256': digest.hexdigest()}

def check(path, expected):
    actual = pin(path)
    ck(actual == {key: expected[key] for key in ('bytes', 'sha256')}, 'pin differs: ' + str(path))
    return actual

def ref(path):
    path = pathlib.Path(path)
    return {'path': path.relative_to(C).as_posix() if path.is_relative_to(C) else str(path), **pin(path)}

def replay_metadata(name):
    inputs = load(C / 'INDEPENDENT-DEEPAL-REPLAY-INPUTS-v1.json')
    selected = inputs['metadata'][name]
    path = pathlib.Path(selected['path'])
    ck(path.is_absolute() and path.is_relative_to(C), 'selected current metadata must be inside this checkpoint')
    check(path, selected)
    return path, load(path)

def safe_member(name):
    path = pathlib.PurePosixPath(name)
    ck(name and not path.is_absolute() and '..' not in path.parts and str(path) == name and '\\' not in name,
       'unsafe member path')

def file_map(rows):
    result = {}
    for row in rows:
        safe_member(row['path'])
        ck(row['path'] not in result, 'duplicate member')
        ck(isinstance(row['bytes'], int) and row['bytes'] >= 0 and len(row['sha256']) == 64, 'invalid pin')
        result[row['path']] = row
    return result

def native(phase, expected=None):
    request = load(C / ('library-' + phase + '-request.json'))['uploads']
    result = load(C / ('library-' + phase + '-results.json'))['results']
    witnesses = [json.loads(line) for line in (C / ('library-' + phase + '-verified.jsonl')).read_text().splitlines()]
    ck(len(request) == len(result) == len(witnesses), 'native phase lengths differ')
    rows = []
    for wanted, value, witness in zip(request, result, witnesses):
        path = pathlib.Path(wanted['local_path'])
        ck(value['status'] == 'succeeded' and value['local_metadata_applied'] and
           value['local_path'] == str(path) and value['file_name'] == path.name, 'native upload not verified')
        ck(witness['verified'] and witness['filename'] == path.name and
           witness['library_file_id'] == value['library_file_id'] and
           witness['version'] == value['current_version_number'], 'native witness differs')
        ck(os.getxattr(path, 'user.library-file-id').decode() == value['library_file_id'] and
           os.getxattr(path, 'user.library-file-version').decode() == str(value['current_version_number']),
           'local native identity differs')
        actual = {key: witness[key] for key in ('bytes', 'sha256')}
        if expected is None:
            ck(actual == pin(path), 'persisted document bytes differ')
        else:
            ck(path.name in expected and actual == expected[path.name] and
               path.stat().st_size == actual['bytes'], 'persisted archive pin differs')
        rows.append({'filename': path.name, 'library_file_id': value['library_file_id'],
                     'file_id': value['file_id'], 'version': value['current_version_number'], **actual})
    ck(len({row['filename'] for row in rows}) == len(rows) and
       len({row['library_file_id'] for row in rows}) == len(rows), 'duplicate native identity')
    if expected is not None:
        ck(set(expected) == {row['filename'] for row in rows}, 'native archive set differs')
    return rows

def final_archives(plan):
    expected = {row['filename']: {key: row[key] for key in ('bytes', 'sha256')} for row in plan['newArchives']}
    persisted = {row['filename']: row for row in native('archives', expected)}
    result = []
    for item in plan['archivesInRestoreOrder']:
        row = {key: value for key, value in item.items() if key not in ('file', 'memberFiles', 'allMembersVerified')}
        if row.get('new'):
            row.update({key: persisted[row['filename']][key] for key in ('library_file_id', 'file_id', 'version')})
        ck(row['library_file_id'] and row['file_id'] and isinstance(row['version'], int), 'archive native identity absent')
        result.append(row)
    ck([row['restoreOrder'] for row in result] == list(range(1, len(result) + 1)), 'restore order differs')
    ck(len(result) == plan['archiveCount'] and len({row['filename'] for row in result}) == len(result), 'archive count differs')
    return result

def no_embedded_source(value):
    if isinstance(value, dict):
        ck(not {'verificationSupportFiles', 'postSealCompactEvidence', 'scriptText', 'sourceText'} & set(value),
           'recursive evidence or executable text field')
        if 'filename' in value and 'text' in value:
            ck(not str(value['filename']).endswith(('.py', '.js', '.ts', '.sh')), 'executable text embedded')
        for child in value.values():
            no_embedded_source(child)
    elif isinstance(value, list):
        for child in value:
            no_embedded_source(child)

def seed_summary():
    summaries = {}
    for kind, directory in [('historical', 'seed-read-invocations'), ('audi', 'audi-seed-read-invocations')]:
        rows = []
        for path in sorted((C / directory).glob('*.json')):
            value = load(path)
            if kind == 'historical':
                ck(value['exactPinnedMembersReadAndVerified'] == 200 and value['historicalArchives'] == 21 and
                   value['noExtractedValuesPersisted'], 'historical seed receipt scope differs')
            else:
                ck(value['distinctValues'] == 6 and value['variantForms'] == 37 and
                   value['payloadReadOperations'] == 6 and value['uniqueOriginalFiles'] == 4 and
                   value['noValuesOrValueDigestsPersisted'], 'Audi seed receipt scope differs')
            rows.append({**ref(path), 'completedAt': value['completedAt'], 'processId': value['processId']})
        summaries[kind] = {'asOf': max((r['completedAt'] for r in rows), default=None),
                           'completedInvocations': len(rows), 'receiptReferences': rows,
                           'noExtractedValuesOrValueDigests': True}
        if kind == 'historical':
            summaries[kind].update(uniquePinnedMembers=200, uniqueHistoricalArchives=21,
                                   targetedPinnedMemberReads=200 * len(rows))
        else:
            summaries[kind].update(distinctValues=6, variantForms=37, uniqueOriginalFiles=4,
                                   payloadReadOperations=6 * len(rows))
    scope = load(C / 'INHERITED-LOCAL-SEED-READ-SCOPE.json')
    ck(scope['result'] == 'EXACT_UNCHANGED_SELECTOR_ACCOUNTING_SPECIFICATION' and len(scope['files']) == 48 and
       scope['payloadValueReadsPerSuccessfulInvocation'] == scope['streamingIntegrityReadsPerSuccessfulInvocation'] == 48,
       'inherited local seed accounting scope differs')
    count = summaries['historical']['completedInvocations']
    ck(count == summaries['audi']['completedInvocations'], 'incomplete paired seed ledgers')
    summaries['inheritedLocal'] = {'specification': ref(C / 'INHERITED-LOCAL-SEED-READ-SCOPE.json'),
                                  'completedInvocations': count, 'uniqueOriginalFiles': 48,
                                  'payloadValueReads': 48 * count, 'streamingIntegrityReads': 48 * count,
                                  'accountingMethod': 'Derived from reviewed selector control flow and paired seed completion ledgers; not separate per-file instrumentation',
                                  'noValuesOrValueDigestsPersisted': True}
    return summaries

def check_seed_summary(value, complete=False):
    actual = seed_summary()
    for kind in ('historical', 'audi'):
        selected, current = value[kind], actual[kind]
        refs = selected['receiptReferences']
        cutoff = selected['asOf']
        wanted = [row for row in current['receiptReferences'] if cutoff and row['completedAt'] <= cutoff]
        ck(refs == wanted and selected['completedInvocations'] == len(refs), 'seed as-of scope differs')
        for key, item in selected.items():
            if key not in ('asOf', 'completedInvocations', 'receiptReferences', 'targetedPinnedMemberReads', 'payloadReadOperations'):
                ck(current[key] == item, 'seed fixed scope differs')
        total = 'targetedPinnedMemberReads' if kind == 'historical' else 'payloadReadOperations'
        ck(selected[total] == len(refs) * (200 if kind == 'historical' else 6), 'seed total differs')
        if complete:
            ck(selected == current, 'terminal omits a seed invocation')
    inherited = value['inheritedLocal']
    count = value['historical']['completedInvocations']
    ck(count == value['audi']['completedInvocations'] and inherited ==
       {**actual['inheritedLocal'], 'completedInvocations': count, 'payloadValueReads': 48 * count,
        'streamingIntegrityReads': 48 * count}, 'inherited local seed totals differ')
    if complete:
        ck(value == actual, 'terminal seed account is incomplete')
    return {kind: {key: item for key, item in data.items() if key != 'receiptReferences'} for kind, data in value.items()}

def privacy(name, paths):
    value = load(C / name)
    ck(value['result'] == 'PASS' and not value['findings'] and not value['errors'] and
       value['currentCompletePatternScan'] and value['allKnownValueForms'], 'document privacy gate failed')
    ck(value['audiRuntimeValues'] == 6 and value['audiRuntimeForms'] == 37 and
       value['audiOriginalPayloadReadOperations'] == 6, 'current residual coverage differs')
    seen = {}
    for row in value['files']:
        ck(row['filename'] not in seen and row['exactValueMatches'] == row['primaryCandidates'] == row['runtimeCandidates'] == 0,
           'duplicate privacy member or unresolved finding')
        ck(row['exactMatchesObserved'] == row['classifiedPublicLexicalCollisions'], 'privacy accounting differs')
        seen[row['filename']] = {key: row[key] for key in ('bytes', 'sha256')}
    ck(seen == {path.name: pin(path) for path in paths}, 'privacy input set or pins differ')
    return ref(C / name)
