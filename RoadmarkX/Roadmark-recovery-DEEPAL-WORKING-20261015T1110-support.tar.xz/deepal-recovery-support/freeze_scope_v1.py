from capture_v2 import *
inventory=P('/tmp/deepal-packet/final-freeze-v1/inventory.json')
check(inventory,{'sha256':'0015b872cf9f596261596a1fcd767d4a869c9b4d9b1b7dbd8502f76c2ac7b30a'})
v=load(inventory)
assert v['noFurtherPayloadEdits'] and v['metadataOnlyInventory'] and not v['contentCaptureOrPrivacyScanPerformed']
assert v['totalFiles']==len(v['files'])==715 and v['symlinkCount']==0
assert sum(r['bytes'] for r in v['files'])==v['regularFileBytes']==40967430
review=P('/tmp/deepal-review/FINAL-RETENTION-ACCEPTANCE.json')
reviewPin={'bytes':3416,'sha256':'b4fe8d590b540f2332042787e9cf9ccd696ad62689322fa6a1f911851578cf3b'}
check(review,reviewPin)
files={}
for row in v['files']:
 p=P(row['path']);ident=identity(p);assert row['kind']=='file' and ident[0]==row['bytes'] and ident[1]==row['mtimeNs']
 assert str(p) not in files
 files[str(p)]={'path':str(p),'bytes':ident[0],'mtimeNsAtFreeze':ident[1]}
pins=v['sourceAndStatusAfterPins']+v['knownSanitizedSupport']['files']+[v['independentDocsReadback'],v['finalRuntimeAcceptance']]
assert len(v['sourceAndStatusAfterPins'])==11
for row in pins:
 p=P(row['path']);got,ident=check(p,row);assert str(p) in files and files[str(p)]['mtimeNsAtFreeze']==ident[1]
 files[str(p)].update(got)
for row in [{'path':str(inventory),**pin(inventory)},v['preparer'],{'path':str(review),**reviewPin}]:
 p=P(row['path']);got,ident=check(p,row);assert str(p) not in files
 files[str(p)]={'path':str(p),**got,'mtimeNsAtFreeze':ident[1]}
assert len(files)==718
for row in v['excluded']:assert row['path'] not in files
safeSupport=v['knownSanitizedSupport'];assert safeSupport['rawOriginalExcluded'] and safeSupport['rawOriginalContentMayNotBeReadOrCaptured']
changed=sorted(P(row['path']).relative_to(W/'roadmark-104').as_posix() for row in v['sourceAndStatusAfterPins'] if P(row['path']).is_relative_to(W/'roadmark-104'))
assert len(changed)==10
pack=module('packager',W/'roadmark-104/scripts/package-source.py');sourceFiles=list(pack.source_files(W/'roadmark-104'))
base=load(BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-AUDI-WORKING-20261015.json');old={r['path']:r for r in base['files']}
overlay=sorted(restpath(P(p)) for p in files if restpath(P(p)) in old and not restpath(P(p)).startswith('roadmark/'))
assert overlay==['roadmark-104-qa/work-status.json']
state='Registered Deepal working cut; 151 scoped tests (144 relevant plus 7 safety), separate 14 overlapping focused citable checks, full-project cold TypeScript, structural validation and one actual normal report with strict saved-report comparison independently passed. Earlier staging and comparison failures and the corrected VW test fixture remain retained. Current-source preview started, but cloud-browser loopback reachability was refused; no UI screenshot or mobile pass. Full aggregate suite, production build, strict M1 closure and release remain open.'
(C/'WORKING-STATE.txt').open('x').write(state+'\n')
q={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'freezeMetadata':{'path':str(inventory),**pin(inventory)},'authorRetention':v,'authorInventory':{'path':str(inventory),**pin(inventory)},'finalRetentionReview':{'path':str(review),**reviewPin},'roots':v['payloadRoots']+['/tmp/deepal-research',str(W/'roadmark-104-visual-qa-20261015')],'files':sorted(files.values(),key=lambda x:x['path']),'knownPinsVerified':len({r['path'] for r in pins})+3,'sourceChangedPaths':changed,'expectedSourceFiles':len(sourceFiles),'expectedNonSourceOverlay':overlay,'workingResult':state,'openGates':['M1 strict closure','Full-project aggregate suite','Production build','Browser UI and real-device mobile verification','Release/M2'],'scopeMethod':'Exact715-file author inventory plus separately pinned inventory/preparer/final review; no recursive research or broad QA capture','metadataOnlySymlinks':[],'noDeletion':True,'noSymlinkTraversal':True,'rawDeepalOriginalReadRecoveryRefetchForbidden':True}
dump(C/'FROZEN-CAPTURE-SCOPE.json',q)
print(json.dumps({'files':len(files),'bytes':sum(r['bytes'] for r in files.values()),'sourceFiles':len(sourceFiles),'sourceDeltaPaths':len(changed),'metadataOnlyLinks':0}))
