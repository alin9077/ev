#!/usr/bin/env python3
"""Bind exact frozen result metadata; no product execution or research-body reads."""
import datetime, hashlib, json, pathlib, resource, stat, sys
sys.dont_write_bytecode = True
P = pathlib.Path
C = P(__file__).resolve().parent
W = C.parents[2]
LIMIT = 256 * 1024 * 1024

def core(row):
    return {key: row[key] for key in ('bytes', 'sha256')}

def identity(path):
    path = P(path); s = path.lstat()
    assert stat.S_ISREG(s.st_mode) and not any(p.is_symlink() for p in path.parents)
    return [s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_ino, s.st_dev]

def pin(path):
    path = P(path); before = identity(path); data = path.read_bytes()
    assert identity(path) == before and len(data) == before[0]
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def load(path):
    return json.loads(P(path).read_bytes())

def rest(path):
    path = P(path)
    if path.is_relative_to('/tmp'): return path.relative_to('/tmp').as_posix()
    if path.is_relative_to(W / 'roadmark-104'): return 'roadmark/' + path.relative_to(W / 'roadmark-104').as_posix()
    assert path.is_relative_to(W / 'roadmark-104-qa') or path.is_relative_to(W / 'roadmark-104-visual-qa-20261015')
    return path.relative_to(W).as_posix()

def pointer(value, field):
    for key in field.split('/')[1:]:
        key = key.replace('~1', '/').replace('~0', '~')
        value = value[int(key)] if isinstance(value, list) else value[key]
    return value

def main():
    assert resource.getrlimit(resource.RLIMIT_AS) == (LIMIT, LIMIT)
    inventory_path = P('/tmp/deepal-packet/final-freeze-v1/inventory.json')
    inventory_pin = pin(inventory_path)
    assert inventory_pin['sha256'] == '0015b872cf9f596261596a1fcd767d4a869c9b4d9b1b7dbd8502f76c2ac7b30a'
    inventory = load(inventory_path)
    ids = {r['path']: r['identity'] for r in load(C / 'INDEPENDENT-DEEPAL-INITIAL-IDENTITIES-v1.json')['files']}
    captured = {r['originalPath']: r for r in load(C / 'proof-capture-v1.json')['files']}
    assert len(captured) == len(ids) == 718 and set(captured) == set(ids)
    assertions, retained, documents = [], {}, {}
    def add(row):
        path = row['path']; assert path in ids, 'application pin outside frozen selection: ' + path
        captured_row = captured[path]
        assert core(row) == {'bytes': captured_row['originalBytes'], 'sha256': captured_row['originalSHA256']}
        entry = {'path': rest(path), **core(row)}
        assert entry['path'] not in retained or retained[entry['path']] == entry
        retained[entry['path']] = entry
    def read(path):
        path = str(path); assert path in ids and path.endswith('.json')
        assert identity(path) == ids[path]
        p = pin(path); add(p); value = load(path)
        assert identity(path) == ids[path] and pin(path) == p
        documents[path] = value
        return value
    def refs(value):
        if isinstance(value, dict):
            if all(k in value for k in ('path', 'bytes', 'sha256')): add(value)
            for child in value.values(): refs(child)
        elif isinstance(value, list):
            for child in value: refs(child)
    def exact(path, field, expected):
        path = str(path); value = documents.get(path)
        if value is None: value = read(path)
        assert pointer(value, field) == expected, path + field
        assertions.append({'restorePath': rest(path), 'pointer': field, 'expected': expected})
    def fields(path, names):
        path = str(path); value = documents.get(path)
        if value is None: value = read(path)
        for name in names: exact(path, '/' + name, value[name])
    def passed_check(step):
        assert step['passed'] and step['exitCode'] == 0
        refs(step)
        rp, tp = step['result']['path'], step['terminal']['path']
        result, terminal = read(rp), read(tp)
        for field in ('passed', 'pinsPassed', 'scopePassed'): exact(rp, '/' + field, True)
        exact(rp, '/exitCode', 0); exact(tp, '/exitCode', 0); exact(tp, '/watchdogFired', False)
        assert result['manifestSha256'] == step['manifest']['sha256']
        for stream in ('stdout', 'stderr'):
            path = str(P(tp).parent / (stream + '.log')); row = captured[path]
            add({'path': path, 'bytes': row['originalBytes'], 'sha256': terminal[stream + 'Sha256']})
    add(inventory_pin)
    for row in inventory['sourceAndStatusAfterPins'] + inventory['knownSanitizedSupport']['files']:
        add(row)
    review_root = P('/tmp/deepal-review')
    specs = {
      'BEHAVIOURAL-144-ACCEPTANCE.json': ['status', 'passed', 'exitCode', 'exactTests', 'exactFiles'],
      'LIVE-BRAND-SAFETY-ACCEPTANCE.json': ['status', 'passed', 'exitCode', 'exactTestTitles'],
      'FULL-PROJECT-TYPESCRIPT-V2-ACCEPTANCE.json': ['status', 'passed', 'exitCode', 'fullProjectTypecheckPassed', 'independentlyDecodedRootCount', 'installedTypeScriptVersion', 'currentSevenRegistrationTargetsAndCorrectedTestHashesExact', 'currentLiveCacheHashUnchanged', 'originalConfigExact', 'stdoutEmpty', 'stderrEmpty'],
      'STRUCTURAL-VALIDATION-ACCEPTANCE.json': ['status', 'passed', 'exitCode', 'structuralResult'],
      'VW-CITABLE-FOCUSED-CHECKS-ACCEPTANCE.json': ['status', 'aggregateAccepted'],
      'FIRST-FIVE-CHECKS-ACCEPTANCE.json': ['status', 'originalFailed143TestAggregatePreserved'],
      'NORMAL-REPORT-AND-COMPARISON-ACCEPTANCE.json': ['status', 'independentFullWrittenExpectationReconstructionPassed', 'peerBrandsExact', 'completePeerCarsExact', 'peerWithinGroupOrderExact', 'productionGroupOrderExact', 'allGroupCountChangesFromSelectedDeepal', 'allRemainingPeerAndGlobalLeavesAccounted', 'reportRunCount', 'noAdditionalBroadFeatureReplay', 'counts', 'globalReviewedCore', 'deepal'],
      'DOCS-STATUS-V3-READBACK.json': ['status', 'allLiveAfterHashesMatch', 'exactPriorStatusHistoryAndProgressPrefixPreserved', 'reviewerSourceEdits'],
      'FINAL-RETENTION-ACCEPTANCE.json': ['status', 'scope', 'verification', 'releaseBoundary']}
    reviews = {}
    for name, names in specs.items():
        path = review_root / name; value = read(path); refs(value); fields(path, names); reviews[name] = value
        assert value['status'] == ('accepted_frozen_exact_retention_scope' if name.startswith('FINAL-') else 'accepted')
    assert reviews['BEHAVIOURAL-144-ACCEPTANCE.json']['exactTests'] == 144
    assert len(reviews['LIVE-BRAND-SAFETY-ACCEPTANCE.json']['exactTestTitles']) == 7
    five = reviews['FIRST-FIVE-CHECKS-ACCEPTANCE.json']['checks']; assert len(five) == 5
    focused = reviews['VW-CITABLE-FOCUSED-CHECKS-ACCEPTANCE.json']['checks']; assert len(focused) == 2
    for step in five + focused: passed_check(step)
    focused_manifest = focused[1]['manifest']['path']; read(focused_manifest); exact(focused_manifest, '/expectedTests', 14)
    ts = reviews['FULL-PROJECT-TYPESCRIPT-V2-ACCEPTANCE.json']; passed_check(ts)
    assert ts['fullProjectTypecheckPassed'] and ts['independentlyDecodedRootCount'] == 361
    normal = reviews['NORMAL-REPORT-AND-COMPARISON-ACCEPTANCE.json']
    assert normal['reportRunCount'] == 1 and normal['counts'] == {'catalogue': 427, 'tierOne': 350, 'onSale': 309}
    for key in ('normalResult', 'comparatorResult'):
        path = normal[key]['path']; read(path)
        for field in ('passed', 'pinsPassed', 'scopePassed'): exact(path, '/' + field, True)
        exact(path, '/exitCode', 0)
    for key in ('normalTerminal', 'comparatorTerminal'):
        path = normal[key]['path']; read(path); exact(path, '/exitCode', 0); exact(path, '/watchdogFired', False)
        terminal = documents[path]
        for stream in ('stdout', 'stderr'):
            p = str(P(path).parent / (stream + '.log')); row = captured[p]
            add({'path': p, 'bytes': row['originalBytes'], 'sha256': terminal[stream + 'Sha256']})
    path = normal['semanticResult']['path']; semantic = read(path)
    fields(path, ['passed', 'normalReportSha256', 'baselineSha256', 'exhaustiveDifferences', 'allNormalLeavesAccounted', 'peerBrandObjectsExact', 'peerRankRelativeOrderWithinMeasurementGroupsExact', 'groupOrderEqualsActualProducer', 'peerCompleteCarDigestsExact', 'globalC1EqualsAcceptedStage', 'ordinaryProductionReportRanSeparately', 'normalReportSubstituted', 'broadFeatureReplay', 'defaultLoaderCalls', 'counts'])
    assert semantic['passed'] and semantic['allNormalLeavesAccounted'] and not semantic['normalReportSubstituted'] and not semantic['broadFeatureReplay']
    path = normal['emptyExpectedDiff']['path']; read(path); exact(path, '', [])
    failures = inventory['retainedFailures']; assert len(failures) == 4
    for failure in failures:
        refs(failure); path = failure['terminal']['path']; value = read(path)
        assert value['exitCode'] != 0
        exact(path, '/exitCode', value['exitCode'])
        if 'result' in failure:
            path = failure['result']['path']; value = read(path); exact(path, '/passed', False)
    preview = W / 'roadmark-104-visual-qa-20261015'
    path = preview / 'visual-qa-blocker-receipt.json'; read(path)
    for field in ('appRendered', 'phoneViewportVerified', 'protectedHeroVisuallyInspected'): exact(path, '/' + field, False)
    exact(path, '/screenshots', []); exact(path, '/changedOriginalFiles', []); exact(path, '/verifiedCurrentSourceFiles', 352)
    path = preview / 'stop-receipt.json'; read(path); exact(path, '/exitCode', 0); exact(path, '/sourceWrites', False)
    for path in captured:
        if P(path).parent == preview:
            row = captured[path]; add({'path': path, 'bytes': row['originalBytes'], 'sha256': row['originalSHA256']})
    for path in documents: assert identity(path) == ids[path]
    result = {'schemaVersion': 1, 'result': 'APPROVED_EXACT_CAPTURED_APPLICATION_ASSERTIONS', 'preparedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'generator': pin(__file__), 'finalFreeze': inventory_pin, 'assertions': assertions, 'retainedPins': sorted(retained.values(), key=lambda r: r['path']), 'summary': {'scopedTests': 151, 'relevantTests': 144, 'isolatedSafetyTests': 7, 'separateOverlappingFocusedCitableTests': 14, 'fullProjectTypeScriptRoots': 361, 'normalReportRuns': 1, 'retainedExecutedFailureBoundaries': 4, 'previewScreenshots': 0, 'mobilePassClaimed': False}, 'scope': 'Exact frozen reviewer/result metadata; assertions execute against captured archive bytes during fresh independent replay', 'noProductExecution': True, 'noSourceOrResearchBodyHashSweep': True, 'noRawDeepalOriginalReads': True, 'noReleaseOrAggregateSuiteClaim': True, 'noCodeEmbedding': True}
    output = C / 'APPLICATION-ASSERTION-CONTRACT.json'
    with output.open('x') as stream: json.dump(result, stream, indent=2); stream.write('\n')
    print(json.dumps({'result': result['result'], 'assertions': len(assertions), 'retainedPins': len(retained), 'pin': pin(output)}))

if __name__ == '__main__': main()
