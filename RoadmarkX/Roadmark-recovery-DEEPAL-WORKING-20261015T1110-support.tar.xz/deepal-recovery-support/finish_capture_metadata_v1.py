from capture_v2 import *
sc=load(C/'source-capture.json');pc=load(C/'proof-capture-v1.json');scope=load(C/'FROZEN-CAPTURE-SCOPE.json');old={r['path']:r for r in load(BASE/'source-capture.json')['files']};cur={r['path']:r for r in sc['files']};delta={n for n,r in cur.items() if n not in old or (r['originalBytes'],r['originalSHA256'])!=(old[n]['originalBytes'],old[n]['originalSHA256'])};assert delta==set(scope['sourceChangedPaths']) and set(old)<=set(cur) and len(cur)==scope['expectedSourceFiles']
approvals=load(C/'PROSE-KEY-RENAME-APPROVALS.json');renames=[]
for r in pc['changedFiles']:
 assert not r.get('redactedPointers')
 if r.get('metadataKeyRename'):
  matches=[a for a in approvals['files'] if a['restorePath']==r['path']];assert len(matches)==1;a=matches[0]
  for k in ['bytes','sha256','originalBytes','originalSHA256']:assert r[k]==a[k]
  renames.append({k:r[k] for k in ['path','originalPath','bytes','sha256','originalBytes','originalSHA256','metadataKeyRename']})
 else:assert r['bytes']==r['originalBytes'] and r['sha256']==r['originalSHA256']
assert len(renames)==len(approvals['files'])
dump(C/'COPY-SANITATION-MAPPING.json',{'result':'EXACT_REVIEWED_PROSE_KEYS_ONLY' if renames else 'NO_NEW_TRANSFORMATIONS','files':renames,'locationCount':len(renames),'approvalScope':'Exact independent ordinary-prose classification only; all originals and expected pins unchanged','originalExpectedPinsUnchanged':True,'exactValueAndOutsideKeyBytesUnchanged':True,'independentClassification':pin(C/'PROSE-KEY-RENAME-APPROVALS.json'),'originalReplayLimitation':'Any renamed copied receipt has a distinct retained hash and cannot silently satisfy its original expected whole-file pin; intact originals or separately reviewed manifests are required.'})
allrows={'roadmark/'+r['path']:r for r in sc['files']};allrows.update({r['path']:r for r in pc['files']});links=[]
for r in scope['metadataOnlySymlinks']:
 p=P(r['path']);assert p.is_symlink() and os.readlink(p)==r['target'];target=P(r['resolvedTarget']);n=restpath(target)
 if target==W/'roadmark-104/node_modules':
  q={**r,'restoreLinkPath':restpath(p),'restoreTargetPath':'roadmark/node_modules','reconstruction':'Install dependencies from the retained lockfile inside the restored project before recreating the link to restoreTargetPath; do not reuse the original workspace-absolute target','dependencyTreeExcluded':True,'retainedMembers':[]}
 else:
  refs=[{'path':k,'bytes':v['bytes'],'sha256':v['sha256'],'originalBytes':v['originalBytes'],'originalSHA256':v['originalSHA256']} for k,v in allrows.items() if k==n or k.startswith(n+'/')];assert refs,'Missing exact retained link target: '+str(p)
  q={**r,'restoreLinkPath':restpath(p),'restoreTargetPath':n,'reconstruction':'After exact retained member verification, link restoreLinkPath to restoreTargetPath inside the new restore root; remap original absolute targets and retain them only as provenance','retainedMembers':sorted(refs,key=lambda x:x['path'])}
 links.append(q)
assert len(links)==0 and not scope['metadataOnlySymlinks']
dump(C/'SYMLINK-RECONSTRUCTION.json',{'result':'EXACT_METADATA_AND_MEMBER_MAPPING','links':links,'noTraversalOrDependencyCapture':True,'noUniqueRegularEvidenceOmitted':True,'targetBytesBoundByIndependentFreshReplay':True})
print(json.dumps({'sourceFiles':len(cur),'sourceChangedPaths':len(delta),'newProofFiles':len(pc['changedFiles']),'copyKeyRenames':len(renames),'metadataOnlyLinks':len(links)}))
