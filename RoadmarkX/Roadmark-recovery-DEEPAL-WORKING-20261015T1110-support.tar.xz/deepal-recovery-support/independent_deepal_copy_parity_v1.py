#!/usr/bin/env python3
"""Independently verify approved copied bytes; never open mutable raw originals."""
import datetime, hashlib, html.parser, json, pathlib, resource, stat, sys
sys.dont_write_bytecode = True
P = pathlib.Path
C = P(__file__).resolve().parent
OUT = C / 'INDEPENDENT-DEEPAL-COPY-PARITY-v1.json'
MARKER = b'[REDACTED-RUNTIME-VALUE]'

def need(value, message):
    if not value: raise AssertionError(message)

def identity(path):
    path=P(path); s=path.lstat()
    need(stat.S_ISREG(s.st_mode) and not any(p.is_symlink() for p in path.parents), 'nonregular path')
    return [s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev]

def pinbytes(data): return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def sizehash(row): return {k:row[k] for k in ('bytes','sha256')}
def read(path, expected=None):
    path=P(path); before=identity(path); data=path.read_bytes()
    need(identity(path)==before and len(data)==before[0], 'unstable read')
    if expected: need(pinbytes(data)==sizehash(expected), 'file pin mismatch')
    return data

def metadata(path):
    path=P(path); need(path.parent==C and path.suffix=='.json', 'metadata outside checkpoint')
    data=read(path); return json.loads(data), {'path':str(path),**pinbytes(data)}

class Visible(html.parser.HTMLParser):
    def __init__(self): super().__init__(convert_charrefs=True); self.depth=0; self.nodes=[]
    def handle_starttag(self,tag,attrs):
        if tag.lower() in ('script','style','template'): self.depth+=1
    def handle_endtag(self,tag):
        if tag.lower() in ('script','style','template') and self.depth: self.depth-=1
    def handle_data(self,data):
        if not self.depth: self.nodes.append(data)

def visible(data):
    p=Visible(); p.feed(data.decode('utf8')); p.close()
    return '\n'.join(' '.join(n.split()) for n in p.nodes if n.strip()).encode('utf8')

def json_changes(old,new,values,path=''):
    need(type(old)==type(new),'JSON type changed')
    changes=[]
    if isinstance(old,dict):
        need(list(old)==list(new),'JSON keys/order changed')
        for key in old: changes+=json_changes(old[key],new[key],values,path+'/'+key.replace('~','~0').replace('/','~1'))
    elif isinstance(old,list):
        need(len(old)==len(new),'JSON list length changed')
        for i,(a,b) in enumerate(zip(old,new)): changes+=json_changes(a,b,values,path+'/'+str(i))
    elif old!=new:
        need(isinstance(old,str),'non-string JSON value changed')
        expected=old
        for value in values: expected=expected.replace(value.decode('utf8'),MARKER.decode('ascii'))
        need(expected==new,'JSON change beyond approved opaque values')
        changes.append({'pointer':path,'oldCharacters':len(old),'newCharacters':len(new),'onlyApprovedOpaqueValueReplacements':True})
    return changes

def main():
    need(resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456),'256 MiB ceiling absent')
    need(len(sys.argv)==5 and not OUT.exists(),'exact arguments and fresh output required')
    classification,cp=metadata(sys.argv[1]); approval,ap=metadata(sys.argv[2]); final,fp=metadata(sys.argv[3]); mapping,mp=metadata(sys.argv[4])
    need(approval['classificationPin']==sizehash(cp) and approval['copyOnly'],'approved classification absent')
    need(mapping['classificationPin']==sizehash(cp),'mapping classification differs')
    initial,ip=metadata(C/'proof-capture-v1.json')
    need(ip['sha256']=='4f3bb452ef1d6cdedd2cf2f7ded3c20436ae01cf1fae4130eb1c714fb5d633b6','initial capture pin differs')
    before={r['path']:r for r in initial['files']}; after={r['path']:r for r in final['files']}; mapped={r['path']:r for r in mapping['files']}
    files=classification['files']; wanted={r['member'] for r in files}
    need(len(wanted)==len(files)==len(mapped) and set(mapped)==wanted and set(before)==set(after),'member scope differs')
    need(mapping['fileCount']==len(wanted) and mapping['locationCount']==sum(len(f['ranges']) for f in files),'mapping counts differ')
    results=[]
    for f in files:
        name=f['member']; a=before[name]; z=after[name]; mr=mapped[name]
        need(a['payloadPath']==f['capturedPayloadPath']==mr['preservedCapturedOriginal'],'preserved capture locator differs')
        need(sizehash(a)==f['originalPin'] and sizehash(z)==f['proposedSanitizedPin'],'capture pin differs')
        need(a['originalPath']==z['originalPath'] and a['sourceIdentity']==z['sourceIdentity'],'original metadata changed')
        need(all(a[k]==z[k] for k in ('originalBytes','originalSHA256')),'original expectation changed')
        need(mr['ranges']==f['ranges'] and sizehash(mr)==f['proposedSanitizedPin'],'mapping differs')
        source=P(f['capturedPayloadPath']); dest=P(z['payloadPath'])
        need(source.is_relative_to(C/'selected-proof-sanitized-v1') and dest.is_relative_to(C) and source!=dest,'copy locator escaped exact captured scope')
        old=read(source,f['originalPin']); new=read(dest,f['proposedSanitizedPin'])
        need(f['ranges']==sorted(f['ranges'],key=lambda r:r['byteStart']),'range order differs')
        oi=ni=0; extracted=[]
        for r in f['ranges']:
            a0,a1=r['byteStart'],r['byteEndExclusive']; b0,b1=r['proposedByteStart'],r['proposedByteEndExclusive']
            need(oi<=a0<a1<=len(old) and ni<=b0<b1<=len(new),'range bounds differ')
            need(old[oi:a0]==new[ni:b0] and new[b0:b1]==MARKER,'outside-range or replacement bytes differ')
            need(r['replacement']==MARKER.decode('ascii'),'replacement differs')
            extracted.append(old[a0:a1]); oi,ni=a1,b1
        need(old[oi:]==new[ni:],'final outside-range segment differs')
        parity={'everyOutsideRangeByteUnchanged':True,'replacementRanges':len(f['ranges'])}
        if name.endswith('.html'):
            one,two=visible(old),visible(new); need(one==two,'visible factual text changed')
            need(pinbytes(one)==sizehash(f['visibleProjection']),'approved visible projection differs')
            parity.update(visibleFactualTextUnchanged=True,visibleProjection=pinbytes(one))
        elif name.endswith('.json'):
            changes=json_changes(json.loads(old),json.loads(new),extracted)
            need(changes,'expected JSON value change absent')
            parity.update(jsonStructureAndOtherValuesUnchanged=True,changedStringLeaves=changes)
        else: raise AssertionError('unreviewed copied file format')
        results.append({'member':name,'originalPin':f['originalPin'],'copiedPin':f['proposedSanitizedPin'],**parity})
        del old,new,extracted
    for name in set(before)-wanted: need(before[name]==after[name],'unrelated captured record changed')
    need([r['path'] for r in initial['changedFiles']]==[r['path'] for r in final['changedFiles']],'changed member order differs')
    result={'result':'PASS','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputPins':{'classification':cp,'approval':ap,'finalProofCapture':fp,'copySanitation':mp,'initialProofCapture':ip},'files':results,'filesChecked':len(results),'rangeCount':sum(len(f['ranges']) for f in files),'unrelatedCaptureRecordsUnchanged':len(before)-len(results),'mutableOriginalReads':0,'rawDeepalApiManagerReads':0,'seedOrArchiveReads':0,'valuesOrValueDigestsPersisted':False,'copiesModified':False}
    with OUT.open('x') as stream: json.dump(result,stream,indent=2); stream.write('\n')
    print(json.dumps({'result':'PASS','files':len(results),'ranges':result['rangeCount']}))

if __name__=='__main__': main()
