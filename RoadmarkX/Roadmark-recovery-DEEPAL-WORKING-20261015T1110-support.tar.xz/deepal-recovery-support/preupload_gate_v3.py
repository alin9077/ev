#!/usr/bin/env python3
"""Bind final fresh checks before preparing the archive upload request."""
from delivery_common_v3 import *

def main():
    gate, verification, plan = load(C / GATE), load(C / RECOVERY), load(C / 'RESTORE-PLAN.json')
    ck(gate['result'] == verification['result'] == 'PASS', 'fresh gates not passed')
    ck(gate['freshMembers'] == plan['freshFiles'] and gate['freshBytes'] == plan['freshBytes'] and
       gate['unclassifiedFindings'] == gate['errors'] == 0, 'fresh privacy accounting differs')
    ck(plan['source']['bytes'] < 15000000 and plan['fullSourceFiles'] == 688 and
       plan['baseArchivesReused'] == 125, 'source/base scope differs')
    ck(load(C / 'ARCHIVE-PLAN.json')['archives'] == plan['newArchives'], 'final archive pointers differ')
    uploads = []
    for row in plan['newArchives']:
        check(row['file'], row)
        uploads.append({'local_path': row['file'], 'purpose': 'create_library_file', 'library_artifact_type': 'other'})
    dump(C / 'PREUPLOAD-GATE.json', {'result': 'PASS', 'privacy': ref(C / GATE),
                                    'independentRecovery': ref(C / RECOVERY),
                                    'restorePlan': ref(C / 'RESTORE-PLAN.json'),
                                    'newArchives': len(uploads), 'sourceUnderStrict15000000': True,
                                    'noBaseRestoreOrFullBaseScan': True,
                                    'targetedSeedDependency': ref(C / 'TARGETED-SEED-READ-DEPENDENCY.json'),
                                    'rawDeepalOriginalReadRecoveryRefetchForbidden': True})
    dump(C / 'library-archives-request.json', {'uploads': uploads})
    print('PASS: verified final archives ready for ordered prepared persistence')

if __name__ == '__main__':
    main()
