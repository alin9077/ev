#!/usr/bin/env python3
"""Narrow two-HTML review; proposed substitutions remain in memory, no seed reads."""
import datetime, hashlib, html, html.parser, importlib.util, json, pathlib, re, resource, stat, sys
sys.dont_write_bytecode = True
P = pathlib.Path
C = P(__file__).resolve().parent
A = C.parents[1] / 'privacy-audit-20261014T0355'
OUT = C / 'INDEPENDENT-DEEPAL-RUNTIME-CLASSIFICATION-v2.json'
MARKER = b'[REDACTED-RUNTIME-VALUE]'

def ident(p):
    s=p.lstat(); assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents)
    return [s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev]
def read(p, expected=None):
    p=P(p); before=ident(p); b=p.read_bytes(); assert ident(p)==before and len(b)==before[0]
    pin={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
    if expected: assert pin=={k:expected[k] for k in ('bytes','sha256')}
    return b,pin
def load(p):return json.loads(read(p)[0])
class Visible(html.parser.HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=True);self.depth=0;self.text=[]
    def handle_starttag(self,tag,attrs):
        if tag.lower() in ('script','style','template'):self.depth+=1
    def handle_endtag(self,tag):
        if tag.lower() in ('script','style','template') and self.depth:self.depth-=1
    def handle_data(self,data):
        if not self.depth:self.text.append(data)
def visible(b):
    p=Visible();p.feed(b.decode('utf-8'));return '\n'.join(' '.join(x.split()) for x in p.text if x.strip()).encode()
def main():
    assert resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456) and not OUT.exists()
    pc=load(C/'proof-capture-v1.json');by={r['path']:r for r in pc['files']}
    report_names=['scan-fresh-02.json','scan-fresh-03.json'];reports=[load(C/n) for n in report_names]
    names=['deepal-research/home.html','deepal-research/recall/manufacturer-ota.html']
    assert [r['status'] for r in reports]==['review-required','review-required']
    engine=load(C.parent/'audi-working-20261015T0800/INDEPENDENT-AUDI-CHECKER-PATTERN-PREFLIGHT-v1.json')['enginePins']
    for name,digest in engine.items():assert read(A/name)[1]['sha256']==digest
    sys.path.insert(0,str(A));sp=importlib.util.spec_from_file_location('deepal_runtime_review',A/'final_residual_scan_memory_bounded.py');module=importlib.util.module_from_spec(sp);sp.loader.exec_module(module);primary,runtime=module.patterns()
    refs_names=[n for n in by if n.startswith('deepal-research/source-index-review-') and n.endswith('.json')]
    refs_names += ['deepal-research/sources/home-receipt.json','deepal-research/recall/capture-manifest.json','deepal-research/recall/download-receipts.json','deepal-research/recall/recall-findings.json']
    reference_docs={n:json.loads(read(by[n]['payloadPath'],by[n])[0]) for n in refs_names}
    def production_candidates(text):
        candidates=runtime(text)
        return [f for f in candidates if f['layer']=='plain' or not any(g['layer']=='plain' and g['field']==f['field'] for g in candidates)]
    def inspect_layers(text,candidates):
        windows=[];low=text.lower()
        for marker in runtime.__globals__['markers']:
            offset=0
            while True:
                offset=low.find(marker,offset)
                if offset<0:break
                windows.append((max(0,offset-1024),min(len(text),offset+12288)));offset+=len(marker)
        for marker in ['\\u00','\\x','&#']:
            offset=0
            while True:
                offset=text.find(marker,offset)
                if offset<0:break
                windows.append((max(0,offset-1024),min(len(text),offset+12288)));offset+=len(marker)
        merged=[]
        for a,z in sorted(windows):
            if merged and a<=merged[-1][1]:merged[-1]=(merged[-1][0],max(z,merged[-1][1]))
            else:merged.append((a,z))
        plain=[f for f in candidates if f['layer']=='plain'];results=[]
        for f in candidates:
            if f['layer']=='plain':continue
            start=f['sourceWindowStart'];ends=[z for a,z in merged if a==start];assert len(ends)==1
            source=text[start:ends[0]];decoded=source
            if f['layer']=='html-entities':decoded=html.unescape(source)
            else:
                assert f['layer'].startswith('escaped-level-')
                for _ in range(int(f['layer'].rsplit('-',1)[1])):
                    decoded=re.sub(r'\\u([0-9a-fA-F]{4})|\\x([0-9a-fA-F]{2})',lambda m:chr(int(m.group(1) or m.group(2),16)),decoded)
                    decoded=decoded.replace('\\"','"').replace("\\'","'").replace('\\n','\n').replace('\\r','\r').replace('\\t','\t').replace('\\\\','\\')
            value=decoded[f['valueCharStart']:f['valueCharEnd']];assert len(value)==f['valueLength']
            same=[g for g in plain if g['field']==f['field'] and text[g['valueCharStart']:g['valueCharEnd']]==value]
            assert same,'Distinct decoded-layer value requires separate review'
            results.append({'rawFinding':f,'classification':'Decoded representation independently equals an already retained plain candidate value or syntax','matchingPlainSourceRanges':[{'charStart':g['valueCharStart'],'charEndExclusive':g['valueCharEnd'],'byteStart':len(text[:g['valueCharStart']].encode()),'byteEndExclusive':len(text[:g['valueCharEnd']].encode())} for g in same],'decodedValuePersisted':False,'distinctDecodedValueOutsidePlainCandidates':False})
        return results
    raw_views=[]
    for member in names:
        payload,_=read(by[member]['payloadPath'],by[member]);text=payload.decode('utf-8')
        raw_views.append({'member':member,'originalPin':{k:by[member][k] for k in ('bytes','sha256')},'rawDetectorCandidates':runtime(text)})
    raw_path=C/'INDEPENDENT-DEEPAL-RUNTIME-RAW-CANDIDATES-v2.json'
    with raw_path.open('x') as f:json.dump({'files':raw_views,'rawCandidatesUnmodified':True,'valuesOrValueDigestsPersisted':False,'seedReads':0},f,indent=2);f.write('\n')
    files=[];reads=[];value_groups={}
    for name,report in zip(names,reports):
        row=by[name];b,pin=read(row['payloadPath'],row);reads.append({'member':name,'copiedPayloadPath':row['payloadPath'],**pin});s=b.decode('utf-8')
        assert pin=={'bytes':row['originalBytes'],'sha256':row['originalSHA256']}
        all_raw=runtime(s);layer_evidence=inspect_layers(s,all_raw);raw=production_candidates(s);recorded=[{k:v for k,v in f.items() if k!='member'} for f in report['unclassifiedRuntimeCandidates'] if f['member']==name]
        assert raw==recorded and not primary(b,name)[0]
        ranges=[];benign=[]
        for f in raw:
            start,end=f['valueCharStart'],f['valueCharEnd'];a,z=len(s[:start].encode()),len(s[:end].encode())
            assert len(s[start:end])==f['valueLength']
            if f['field']=='token':
                value=s[start:end]
                assert re.search(r'^\s*\+\s*token\b',value) and 'xmlhttp.send' in value and '</script>' in value and '<script' in value
                benign.append({'exactFinding':f,'originalByteStart':a,'originalByteEndExclusive':z,'classification':'JavaScript query concatenation, Boolean argument, XHR-send call and script-tag boundary; not a literal credential value','matchedSyntaxSha256':hashlib.sha256(b[a:z]).hexdigest()})
            else:
                assert f['field'] in ('__RequestVerificationToken','nonce')
                ranges.append({'field':f['field'],'originalCharStart':start,'originalCharEndExclusive':end,'byteStart':a,'byteEndExclusive':z,'source':'unchanged runtime detector','classification':'Request verification value' if f['field']=='__RequestVerificationToken' else 'Per-response script nonce'})
        if name.endswith('home.html'):
            hidden=[]
            for m in re.finditer(r'<input\b[^>]*>',s,re.I):
                attr=re.search(r'\bname\s*=\s*([\'"])(.*?)\1',m.group(),re.I);value=re.search(r'\bvalue\s*=\s*([\'"])(.*?)\1',m.group(),re.I)
                if attr and value and attr.group(2)=='ufprt':hidden.append((value.start(2)+m.start(),value.end(2)+m.start()))
            assert len(hidden)==1
            start,end=hidden[0];assert end-start==176
            ranges.append({'field':'ufprt','originalCharStart':start,'originalCharEndExclusive':end,'byteStart':len(s[:start].encode()),'byteEndExclusive':len(s[:end].encode()),'source':'Exact adjacent hidden-input review','classification':'Opaque form-routing/request-control value'})
            query=list(re.finditer(r'[?&](mitb_clt\w+)=([^\s\'"]+)',s));assert len(query)==1 and len(query[0].group(2))==120
            m=query[0];start,end=m.span(2)
            ranges.append({'field':m.group(1),'originalCharStart':start,'originalCharEndExclusive':end,'byteStart':len(s[:start].encode()),'byteEndExclusive':len(s[:end].encode()),'source':'Exact adjacent bot-control script URL review','classification':'Opaque per-response mitigation query value'})
        for index,r in enumerate(ranges):
            value=b[r['byteStart']:r['byteEndExclusive']];value_groups.setdefault(value,[]).append({'member':name,'capturedPayloadPath':row['payloadPath'],'originalPin':pin,'field':r['field'],'byteStart':r['byteStart'],'byteEndExclusive':r['byteEndExclusive']})
        ranges.sort(key=lambda x:x['byteStart']);assert all(a['byteEndExclusive']<=z['byteStart'] for a,z in zip(ranges,ranges[1:]))
        proposed=b;shift=0
        for r in ranges:
            assert r['byteEndExclusive']-r['byteStart']==len(s[r['originalCharStart']:r['originalCharEndExclusive']].encode())
            r['replacement']='[REDACTED-RUNTIME-VALUE]';r['proposedByteStart']=r['byteStart']+shift;r['proposedByteEndExclusive']=r['proposedByteStart']+len(MARKER);shift+=len(MARKER)-(r['byteEndExclusive']-r['byteStart'])
        for r in reversed(ranges):proposed=proposed[:r['byteStart']]+MARKER+proposed[r['byteEndExclusive']:]
        # Verify every unchanged segment independently of replacement construction.
        op=np=0
        for r in ranges:
            assert b[op:r['byteStart']]==proposed[np:r['proposedByteStart']]
            assert proposed[r['proposedByteStart']:r['proposedByteEndExclusive']]==MARKER
            op,np=r['byteEndExclusive'],r['proposedByteEndExclusive']
        assert b[op:]==proposed[np:] and visible(b)==visible(proposed)
        ps,_,_=primary(proposed,name);proposed_raw=runtime(proposed.decode('utf-8'));proposed_layers=inspect_layers(proposed.decode('utf-8'),proposed_raw);rs=production_candidates(proposed.decode('utf-8'));assert not ps and len(rs)==len(benign)
        for old,new in zip(benign,rs):
            assert new['field']=='token';a=len(proposed.decode()[:new['valueCharStart']].encode());z=len(proposed.decode()[:new['valueCharEnd']].encode())
            assert proposed[a:z]==b[old['originalByteStart']:old['originalByteEndExclusive']]
            old['proposedFinding']=new;old['proposedByteStart']=a;old['proposedByteEndExclusive']=z
        lexical=[]
        for f in report['exactValueMatches']:
            if f['member']!=name:continue
            a,z=f['byteStart'],f['byteEndExclusive'];part=b[a:z]
            if part in (b'true',b'false'):kind='Public Boolean literal in code or markup'
            else:
                assert part==b'control'
                kind='CSS form-control class' if b[a-5:z]==b'form-control' else 'Visible public OTA factual prose word'
                if kind.startswith('Visible'):assert a in (34821,35436)
            assert not any(a<r['byteEndExclusive'] and r['byteStart']<z for r in ranges)
            offset=sum(len(MARKER)-(r['byteEndExclusive']-r['byteStart']) for r in ranges if r['byteEndExclusive']<=a)
            assert proposed[a+offset:z+offset]==part
            lexical.append({'originalByteStart':a,'originalByteEndExclusive':z,'proposedByteStart':a+offset,'proposedByteEndExclusive':z+offset,'classification':kind,'unchangedPublicLexicalSpan':True})
        references=[]
        def walk(value,path,member):
            if isinstance(value,dict):
                for k,v in value.items():walk(v,path+'/'+str(k).replace('~','~0').replace('/','~1'),member)
            elif isinstance(value,list):
                for i,v in enumerate(value):walk(v,path+'/'+str(i),member)
            elif value==pin['sha256']:references.append({'member':member,'pointer':path})
        for member,value in reference_docs.items():walk(value,'',member)
        files.append({'member':name,'originalPath':row['originalPath'],'capturedPayloadPath':row['payloadPath'],'originalIdentity':row['sourceIdentity'],'originalPin':pin,'proposedSanitizedPin':{'bytes':len(proposed),'sha256':hashlib.sha256(proposed).hexdigest()},'ranges':ranges,'rangeCount':len(ranges),'charToByteMethod':'Decode exact read_bytes with UTF-8; prefix UTF-8 encoding lengths; no newline translation','everyOutsideRangeByteUnchanged':True,'visibleFactualTextUnchanged':True,'visibleProjection':{'bytes':len(visible(b)),'sha256':hashlib.sha256(visible(b)).hexdigest(),'method':'HTML text nodes excluding script/style/template content; normalize interword whitespace'},'originalRawRuntimeCandidates':all_raw,'originalDecodedRepresentationEvidence':layer_evidence,'proposedRawRuntimeCandidates':proposed_raw,'proposedDecodedRepresentationEvidence':proposed_layers,'productionDuplicateRepresentationFilterUnchanged':True,'benignRuntimeSyntax':benign,'publicLexicalMatches':lexical,'sourcePinReferences':references,'sourcePinReferenceMetadataMembers':refs_names,'originalExpectedPinsMustRemainUnchanged':True,'originalReplayLimitation':'A redacted copy cannot satisfy the retained original whole-file hash; exact mapping must remain explicit','proposedRawPatternCounts':{'primary':len(ps),'runtime':len(rs)},'proposedPayloadPersisted':False})
    assert [f['rangeCount'] for f in files]==[4,1] and sum(len(f['publicLexicalMatches']) for f in files)==19 and sum(len(f['benignRuntimeSyntax']) for f in files)==1
    variant_forms=module.variants_for({value:[] for value in value_groups})
    additive={'distinctValues':len(value_groups),'variantForms':len(variant_forms),'rangeValueExtractions':sum(len(v) for v in value_groups.values()),'uniqueCapturedPayloadFiles':len({r['capturedPayloadPath'] for group in value_groups.values() for r in group}),'sources':[{'id':'deepal-value-'+str(i),'ranges':group} for i,group in enumerate(value_groups.values(),1)],'variantsFunctionUnchanged':True,'URLComponentRepresentationIncluded':True,'knownFormsBlockingAcrossEveryFreshMemberRequired':True,'generalURLDecodedRuntimeCoverageClaimed':False,'genericUfprtOrMitigationFieldDetectionAdded':False,'scope':'Exact observed value variants only, in addition to unchanged existing pattern detectors; no generic detection claim for other ufprt or mitigation-query values'}
    result={'schemaVersion':1,'result':'REVIEWED_PROPOSAL_REQUIRES_ROOT_APPROVAL_BEFORE_COPY_SANITATION_OR_ADJUDICATION','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'summary':{'htmlFiles':2,'proposedRuntimeValueRanges':5,'originalRuntimeCandidates':4,'additionalSupportedControlValues':2,'benignRuntimeSyntaxCandidates':1,'publicLexicalSpans':19,'sourcePinReferences':sum(len(f['sourcePinReferences']) for f in files)},'additiveSeedProposal':additive,'rawCandidateReceipt':{'path':str(raw_path),**read(raw_path)[1]},'enginePins':engine,'rawReports':[{'path':str(C/n),**read(C/n)[1]} for n in report_names],'payloadReads':reads,'metadataReferenceReads':[{'member':n,**{k:by[n][k] for k in ('bytes','sha256')}} for n in refs_names],'seedReads':0,'historicalArchiveReads':0,'rawDeepalApiManagerReads':0,'originalsOrCapturedCopiesModified':False,'rawReportsModified':False,'sanitizedPayloadWritten':False,'credentialValuesOrValueDigestsPersisted':False,'onlyBenignSyntaxDigestPersisted':True,'automaticExemptionsGranted':False,'generator':{'path':str(P(__file__)),**read(__file__)[1]}}
    with OUT.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({'result':result['result'],'summary':result['summary'],'receipt':{'path':str(OUT),**read(OUT)[1]}}))
if __name__=='__main__':main()
