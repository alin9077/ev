import pathlib,json
from capture_v2 import C,BASE,load,dump,pin
basepath=BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-AUDI-WORKING-20261015.json'
assert pin(basepath)=={'bytes':3164815,'sha256':'7aa4e370c9c08df69663204e1c07ef61dddbe06bbabb0d94e33d2bb9866e59db'}
base=load(basepath);scope=load(C/'FROZEN-CAPTURE-SCOPE.json');source=load(C/'source-package.json');delta=load(C/'proof-packages-v2.json')['archives']+[load(C/'support-package.json')];sc=load(C/'source-capture.json');pc=load(C/'proof-capture-v2.json');oldsource={r['path']:r for r in load(BASE/'source-capture.json')['files']};current={r['path']:r for r in sc['files']}
changed={n for n,r in current.items() if n not in oldsource or (r['originalBytes'],r['originalSHA256'])!=(oldsource[n]['originalBytes'],oldsource[n]['originalSHA256'])}
assert changed==set(scope['sourceChangedPaths']);assert set(oldsource)<=set(current);assert len(current)==scope['expectedSourceFiles']
assert len(base['archivesInRestoreOrder'])==126 and len(base['files'])==11158
ars=[];replaced=0
for a in base['archivesInRestoreOrder']:
 if a['group'].startswith('source-'):ars.append(source);replaced+=1
 else:ars.append({**a,'new':False})
assert replaced==1
ars+=delta
for i,a in enumerate(ars,1):a['restoreOrder']=i
old={f['path']:f for f in base['files']};merged={n:r for n,r in old.items() if not n.startswith('roadmark/')};fresh={}
for a in [source]+delta:
 for f in a['memberFiles']:
  assert f['path'] not in fresh;fresh[f['path']]=f;merged[f['path']]=f
for r in pc['files']:assert merged[r['path']]=={k:r[k] for k in ['path','bytes','sha256']}
assert (set(old)&set(fresh))-{n for n in old if n.startswith('roadmark/')}==set(scope['expectedNonSourceOverlay'])
r={'status':'PLANNED_PENDING_FRESH_PRIVACY_AND_INDEPENDENT_RESTORE','archivesInRestoreOrder':ars,'files':list(merged.values()),'newFiles':list(fresh.values()),'newArchives':[source]+delta,'source':source,'baseManifest':str(basepath),'baseManifestPin':pin(basepath),'fullSourceFiles':len(current),'sourceChangedPaths':sorted(changed),'baseArchivesReused':125,'archiveCount':len(ars),'logicalFiles':len(merged),'logicalBytes':sum(r['bytes'] for r in merged.values()),'freshFiles':len(fresh),'freshBytes':sum(r['bytes'] for r in fresh.values()),'scopeOriginalFiles':len(pc['files']),'workingResult':scope['workingResult'],'openGates':scope['openGates'],'sourceFullCloneCreated':False}
dump(C/'RESTORE-PLAN.json',r);dump(C/'ARCHIVE-PLAN.json',{'archives':[source]+delta});dump(C/'FRESH-ONLY-RESTORE-MANIFEST.json',{'archivesInRestoreOrder':[source]+delta,'files':list(fresh.values())});print(json.dumps({k:v for k,v in r.items() if k in ['archiveCount','logicalFiles','logicalBytes','freshFiles','freshBytes','fullSourceFiles','sourceChangedPaths','baseArchivesReused']}))
