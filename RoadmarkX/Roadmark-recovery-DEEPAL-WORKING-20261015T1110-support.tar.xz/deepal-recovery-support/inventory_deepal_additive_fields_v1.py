#!/usr/bin/env python3
"""Exact-list, no-atime, bounded inventory of two additive raw-byte field shapes.

No source payloads, detectors, archives, or earlier receipts are edited. Values
are never decoded, copied into reports, hashed separately, or persisted.
"""
import datetime
import hashlib
import json
import mmap
import os
from pathlib import Path
import re
import resource
import stat
import sys

sys.dont_write_bytecode = True
C = Path(__file__).absolute().parent
OUT = C / 'ADDITIVE-DEEPAL-FIELD-INVENTORY-v1.json'
JOURNAL = C / 'ADDITIVE-DEEPAL-FIELD-INVENTORY-v1.events.jsonl'
LIMIT = 256 * 1024 * 1024
MANIFESTS = (
    ('source-capture.json', 'files', 688, 550652,
     '2f0d6adfa7de21bff8bc1e986cc6208fe677c7f947218515ee9adb57d5d97e90'),
    ('proof-capture-v1.json', 'changedFiles', 708, 1535619,
     '4f3bb452ef1d6cdedd2cf2f7ded3c20436ae01cf1fae4130eb1c714fb5d633b6'),
)
WS = b' \t\n\r\f'
INPUT = re.compile(rb'<input(?=[\t\n\f\r />])', re.I)
TAG_MARK = re.compile(rb'''["'>]''')
ATTR = re.compile(rb'''([^\t\n\f\r />=\x00"'<]+)(?:[\t\n\f\r ]*=[\t\n\f\r ]*(?:"([^"]*)"|'([^']*)'|([^\t\n\f\r >]+)))?''')
LABELS = re.compile(rb'ufprt|mitb_clt[A-Za-z0-9_]+')
QUERY = re.compile(rb'(?:\?|&(?:amp;|#0*38;|#[xX]0*26;)?)(mitb_clt[A-Za-z0-9_]+)=([^\x00-\x20\x7f&\x23\x22\x27<>]*)')
MAX_RECORDS = 100000  # Fails closed; never a silent truncation.


class InventoryError(Exception):
    pass


def need(test, code):
    if not test:
        raise InventoryError(code)


def identity(s):
    return [s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_ino, s.st_dev]


def safe_open(path):
    """Validate only exact path ancestors, never enumerate a directory."""
    path = Path(path)
    need(path.is_absolute() and '..' not in path.parts, 'NONCANONICAL_PATH')
    for ancestor in reversed(path.parents):
        need(stat.S_ISDIR(ancestor.lstat().st_mode), 'NON_DIRECTORY_OR_SYMLINK_ANCESTOR')
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode), 'NON_REGULAR_OR_SYMLINK_FILE')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NOATIME | os.O_CLOEXEC)
    try:
        need(identity(os.fstat(fd)) == identity(before), 'OPEN_IDENTITY_CHANGED')
    except BaseException:
        os.close(fd)
        raise
    return fd, identity(before)


def stream_pin(fd):
    os.lseek(fd, 0, os.SEEK_SET)
    h = hashlib.sha256()
    count = 0
    while True:
        block = os.read(fd, 65536)
        if not block:
            break
        count += len(block)
        h.update(block)
    return {'bytes': count, 'sha256': h.hexdigest()}


def finish_read(fd, path, before):
    need(identity(os.fstat(fd)) == before, 'FD_IDENTITY_CHANGED')
    need(identity(Path(path).lstat()) == before, 'PATH_IDENTITY_CHANGED')


def read_manifest(name, key, count, size, digest):
    path = C / name
    fd, before = safe_open(path)
    try:
        need(stream_pin(fd) == {'bytes': size, 'sha256': digest}, 'MANIFEST_PIN_MISMATCH')
        os.lseek(fd, 0, os.SEEK_SET)
        with os.fdopen(os.dup(fd), 'rb') as f:
            data = json.load(f)
        need(len(data[key]) == count, 'MANIFEST_ENTRY_COUNT_MISMATCH')
        finish_read(fd, path, before)
        return data[key], {'name': name, 'listKey': key, 'entries': count,
                           'bytes': size, 'sha256': digest, 'identity': before}
    finally:
        os.close(fd)


def span_eq(data, span, literal, insensitive=False):
    a, z = span
    if z - a != len(literal):
        return False
    # Only fixed, public syntax or field names are ever copied, never values.
    part = data[a:z]
    return (part.lower() if insensitive else part) == literal


def tag_end(data, start):
    quote = None
    for token in TAG_MARK.finditer(data, start):
        byte = data[token.start()]
        if quote is not None:
            if byte == quote:
                quote = None
        elif byte in (34, 39):
            quote = byte
        else:
            return token.start() + 1
    return None


def attrs(data, start, end):
    result = {}
    pos = start
    while pos < end - 1:
        while pos < end - 1 and data[pos] in WS + b'/':
            pos += 1
        if pos == end - 1:
            break
        m = ATTR.match(data, pos, end - 1)
        if m is None:
            return result, False
        field = next((name for name in ('name', 'type', 'value')
                      if span_eq(data, m.span(1), name.encode('ascii'), True)), None)
        if field:
            # HTML uses the first occurrence of a duplicate attribute name.
            value = next((m.span(i) for i in (2, 3, 4) if m.start(i) != -1), None)
            result.setdefault(field, {'nameSpan': m.span(1), 'valueSpan': value,
                                      'attributeSpan': m.span(),
                                      'quoteForm': 'double' if m.start(2) != -1 else
                                                   'single' if m.start(3) != -1 else
                                                   'unquoted' if m.start(4) != -1 else 'absent'})
        pos = m.end()
    return result, True


def shapes(data):
    candidates = []
    diagnostics = []
    pos = 0
    while True:
        m = INPUT.search(data, pos)
        if m is None:
            break
        end = tag_end(data, m.end())
        if end is None:
            diagnostics.append({'code': 'UNTERMINATED_INPUT_TAG', 'byteStart': m.start()})
            break
        values, parsed = attrs(data, m.end(), end)
        if not parsed:
            diagnostics.append({'code': 'UNPARSED_INPUT_TAG', 'byteStart': m.start(),
                                'byteEndExclusive': end})
        name, kind, value = (values.get(n) for n in ('name', 'type', 'value'))
        if name and name['valueSpan'] and span_eq(data, name['valueSpan'], b'ufprt'):
            if parsed and kind and kind['valueSpan'] and span_eq(data, kind['valueSpan'], b'hidden', True) and value and value['valueSpan']:
                a, z = value['valueSpan']
                candidates.append({'fieldClass': 'hidden-input-ufprt', 'fieldName': 'ufprt',
                                   'byteStart': a, 'byteEndExclusive': z,
                                   'valueBytes': z-a,
                                   'shapeProof': {'tagByteStart': m.start(), 'tagByteEndExclusive': end,
                                                  'nameByteRange': list(name['valueSpan']),
                                                  'typeByteRange': list(kind['valueSpan']),
                                                  'valueAttributeByteRange': list(value['attributeSpan']),
                                                  'valueQuoteForm': value['quoteForm'],
                                                  'nameEqualsUfprt': True, 'typeEqualsHiddenCaseInsensitive': True,
                                                  'firstAttributeOccurrenceSemantics': True}})
            else:
                diagnostics.append({'code': 'UFPRT_INPUT_REQUIRES_REVIEW', 'byteStart': m.start(),
                                    'byteEndExclusive': end, 'nameByteRange': list(name['valueSpan'])})
        pos = end
        need(len(candidates) + len(diagnostics) <= MAX_RECORDS, 'SHAPE_RECORD_LIMIT')
    for m in QUERY.finditer(data):
        a, z = m.span(2)
        candidates.append({'fieldClass': 'mitigation-query-parameter',
                           'fieldNamePattern': 'mitb_clt[A-Za-z0-9_]+',
                           'byteStart': a, 'byteEndExclusive': z, 'valueBytes': z-a,
                           'shapeProof': {'parameterByteStart': m.start(), 'parameterByteEndExclusive': m.end(),
                                          'nameByteRange': list(m.span(1)),
                                          'queryBoundaryByteRange': [m.start(), m.start(1)],
                                          'nameMatchesApprovedPattern': True, 'hasEqualsDelimiter': True,
                                          'valueTerminatedAtQueryFragmentQuoteWhitespaceMarkupBoundaryOrEOF': True}})
        need(len(candidates) + len(diagnostics) <= MAX_RECORDS, 'SHAPE_RECORD_LIMIT')
    candidates.sort(key=lambda r: (r['byteStart'], r['byteEndExclusive'], r['fieldClass']))
    labels = []
    covered_names = {tuple(c['shapeProof']['nameByteRange']) for c in candidates}
    for m in LABELS.finditer(data):
        labels.append({'fieldClass': 'ufprt-label' if m.end()-m.start() == 5 else 'mitigation-query-name-label',
                       'byteStart': m.start(), 'byteEndExclusive': m.end(),
                       'coveredByShapeCandidate': m.span() in covered_names})
        need(len(labels) <= MAX_RECORDS, 'LABEL_RECORD_LIMIT')
    return candidates, labels, diagnostics


def fixtures():
    # Entirely public, deliberately tiny parser fixtures, never realistic tokens.
    cases = [
        (b'<input name="ufprt" type="hidden" value="a">', 1, 0, [b'a']),
        (b"<INPUT value='b>c' NAME='ufprt' TYPE='HIDDEN'>", 1, 0, [b'b>c']),
        (b'<input type=hidden name=ufprt value=d>', 1, 0, [b'd']),
        (b'<input type=text name=ufprt value=e>', 0, 0, []),
        (b'<input type=hidden name=UFPRT value=f>', 0, 0, []),
        (b'<input type=hidden name=ufprt value="">', 1, 0, [b'']),
        (b'<input type=hidden name=ufprt value="g" value="h">', 1, 0, [b'g']),
        (b'<input data-note="x>y" type=hidden name=ufprt value="i">', 1, 0, [b'i']),
        (b'/public?mitb_clt1=j&x=y#z', 0, 1, [b'j']),
        (b'/public?x=y&amp;mitb_clt_k=l#z', 0, 1, [b'l']),
        (b'/public?x=y&#38;mitb_clt2=m"', 0, 1, [b'm']),
        (b'/public?x=y&#x26;mitb_clt3=n\' ', 0, 1, [b'n']),
        (b'?mitb_clt=o ?mitb_clt4= ?mitb_clt5=p%26q', 0, 2, [b'', b'p%26q']),
        (b'<input type=hidden name=ufprt value="r"><input name=ufprt type=hidden value="r">?mitb_clt6=s&mitb_clt7=s', 2, 2, [b'r', b'r', b's', b's']),
    ]
    for data, hidden, query, expected in cases:
        cs, _, _ = shapes(data)
        need(sum(x['fieldClass'] == 'hidden-input-ufprt' for x in cs) == hidden, 'FIXTURE_HIDDEN_COUNT')
        need(sum(x['fieldClass'] == 'mitigation-query-parameter' for x in cs) == query, 'FIXTURE_QUERY_COUNT')
        need([data[x['byteStart']:x['byteEndExclusive']] for x in cs] == expected, 'FIXTURE_BYTE_RANGES')
    return {'cases': len(cases), 'passed': True, 'publicTinyFixtureBytesOnly': True}


def event(f, data):
    f.write(json.dumps(data, sort_keys=True) + '\n')
    f.flush()
    os.fsync(f.fileno())


def main():
    if sys.argv[1:] == ['--fixtures-only']:
        print(json.dumps(fixtures(), sort_keys=True))
        return
    need(not sys.argv[1:], 'UNEXPECTED_ARGUMENTS')
    need(resource.getrlimit(resource.RLIMIT_AS) == (LIMIT, LIMIT), 'ADDRESS_SPACE_LIMIT_REQUIRED')
    need(not OUT.exists() and not JOURNAL.exists(), 'OUTPUT_ALREADY_EXISTS')
    result = {'schemaVersion': 1, 'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'result': 'INCOMPLETE', 'scope': 'Exact pinned source files and changed proof files only',
              'fieldShapes': ['hidden input named ufprt', 'query parameter named mitb_clt[A-Za-z0-9_]+'],
              'semantics': {'rawBytesOnly': True, 'byteRangesHalfOpen': True,
                            'inputTagAndAttributeNamesASCIIInsensitive': True, 'ufprtNameValueCaseSensitive': True,
                            'mitigationNameCaseSensitive': True, 'HTMLAmpersandQueryBoundariesIncluded': True,
                            'escapedOrEncodedMarkupDecodingNotClaimed': True,
                            'uncoveredRawFieldLabelsRequireReview': True,
                            'fixedOverlapApproximationUsed': False},
              'manifests': [], 'files': [], 'credentialValuesOrValueDigestsPersisted': False,
              'payloadCopiesWritten': False, 'payloadsModified': False, 'originalDetectorModified': False,
              'rawOriginalReads': 0, 'archiveReads': 0, 'directoryEnumerations': 0,
              'noAtimeRequiredWithoutFallback': True, 'mmapAccess': 'ACCESS_READ one file at a time',
              'pinHashMethod': 'Full-file SHA256 via 65536-byte streaming before read-only mmap',
              'identityFields': ['size', 'mtime_ns', 'ctime_ns', 'inode', 'device']}
    active = None
    with JOURNAL.open('x') as journal:
        event(journal, {'kind': 'started', 'startedAt': result['startedAt']})
        try:
            result['fixtures'] = fixtures()
            targets = {}
            for spec in MANIFESTS:
                rows, meta = read_manifest(*spec)
                result['manifests'].append(meta)
                for index, row in enumerate(rows):
                    path = row['payloadPath']
                    pin = {key: row[key] for key in ('bytes', 'sha256')}
                    need(isinstance(path, str) and isinstance(pin['bytes'], int) and pin['bytes'] >= 0,
                         'INVALID_MANIFEST_ENTRY')
                    need(isinstance(pin['sha256'], str) and re.fullmatch(r'[0-9a-f]{64}', pin['sha256']) is not None,
                         'INVALID_MANIFEST_PIN')
                    if path not in targets:
                        targets[path] = {'expectedPin': pin, 'members': []}
                    need(targets[path]['expectedPin'] == pin, 'SHARED_PAYLOAD_PIN_CONFLICT')
                    targets[path]['members'].append({'manifest': spec[0], 'listKey': spec[1],
                                                     'index': index, 'member': row['path']})
            result['declaredEntries'] = sum(spec[2] for spec in MANIFESTS)
            result['uniquePayloadPaths'] = len(targets)
            for path, target in targets.items():
                active = {'capturedPayloadPath': path, 'members': target['members']}
                fd, before = safe_open(path)
                try:
                    pin = stream_pin(fd)
                    need(pin == target['expectedPin'], 'CAPTURED_PAYLOAD_PIN_MISMATCH')
                    need(pin['bytes'] == before[0], 'PAYLOAD_SIZE_MISMATCH')
                    if pin['bytes']:
                        with mmap.mmap(fd, 0, access=mmap.ACCESS_READ) as data:
                            candidates, labels, diagnostics = shapes(data)
                    else:
                        candidates, labels, diagnostics = [], [], []
                    finish_read(fd, path, before)
                    rec = {**active, 'pin': pin, 'identityBefore': before, 'identityAfter': before,
                           'pinVerified': True, 'identityStable': True,
                           'candidates': candidates, 'fieldLabels': labels, 'parserDiagnostics': diagnostics}
                    result['files'].append(rec)
                    event(journal, {'kind': 'file', **rec})
                finally:
                    os.close(fd)
                active = None
            summary = {'entriesCovered': sum(len(f['members']) for f in result['files']),
                       'uniquePayloadsScanned': len(result['files']),
                       'bytesScanned': sum(f['pin']['bytes'] for f in result['files']),
                       'candidateFiles': sum(bool(f['candidates']) for f in result['files']),
                       'candidateRanges': sum(len(f['candidates']) for f in result['files']),
                       'hiddenUfprtRanges': sum(c['fieldClass'] == 'hidden-input-ufprt' for f in result['files'] for c in f['candidates']),
                       'mitigationQueryRanges': sum(c['fieldClass'] == 'mitigation-query-parameter' for f in result['files'] for c in f['candidates']),
                       'rawFieldLabels': sum(len(f['fieldLabels']) for f in result['files']),
                       'uncoveredRawFieldLabels': sum(not x['coveredByShapeCandidate'] for f in result['files'] for x in f['fieldLabels']),
                       'parserDiagnostics': sum(len(f['parserDiagnostics']) for f in result['files'])}
            need(summary['entriesCovered'] == result['declaredEntries'], 'INCOMPLETE_SCOPE_COVERAGE')
            result['summary'] = summary
            result['result'] = 'INVENTORY_COMPLETE_REQUIRES_CLASSIFICATION'
        except BaseException as e:
            result['failure'] = {'exceptionType': type(e).__name__,
                                 'code': str(e) if isinstance(e, InventoryError) else 'NONINVENTORY_EXCEPTION_DETAILS_SUPPRESSED',
                                 'activePayload': active}
            result['result'] = 'FAILED_RETAINED_PARTIAL_INVENTORY'
        result['endedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        event(journal, {'kind': 'terminal', 'result': result['result'],
                        'summary': result.get('summary'), 'failure': result.get('failure')})
    with OUT.open('x') as f:
        json.dump(result, f, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())
    print(json.dumps({'result': result['result'], 'summary': result.get('summary'),
                      'failure': result.get('failure'), 'reportPath': str(OUT)}, sort_keys=True))
    if result['result'].startswith('FAILED'):
        sys.exit(1)


if __name__ == '__main__':
    main()
