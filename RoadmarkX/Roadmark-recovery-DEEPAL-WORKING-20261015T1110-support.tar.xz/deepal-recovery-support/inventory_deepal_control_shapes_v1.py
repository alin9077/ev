#!/usr/bin/env python3
"""Exact raw-byte two-field inventory over pinned captured source/proof payloads."""
import datetime, hashlib, json, mmap, pathlib, re, resource, stat, sys
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent
OUT=C/'DEEPAL-CONTROL-SHAPE-INVENTORY-v1.json'
TAG=re.compile(rb'<input\b[^<>]*>',re.I)
ATTR=re.compile(rb'''(?P<key>[A-Za-z_:][A-Za-z0-9_:.-]*)\s*=\s*(?:"(?P<d>[^"<>]*)"|'(?P<s>[^'<>]*)'|(?P<u>[^\s>]+))''')
QUERY=re.compile(rb'(?:\?|&(?:amp;)?)(?P<key>mitb_clt[0-9]+)=(?P<value>[^&\s\'"<>\\]+)',re.I)
def identity(p):
    z=p.lstat();assert stat.S_ISREG(z.st_mode) and not any(q.is_symlink() for q in p.parents)
    return [z.st_size,z.st_mtime_ns,z.st_ctime_ns,z.st_ino,z.st_dev]
def metadata(p):
    p=P(p);before=identity(p);b=p.read_bytes();assert identity(p)==before
    return json.loads(b),{'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def find(data):
    result=[]
    for tag in TAG.finditer(data):
        attrs={}
        for a in ATTR.finditer(data,tag.start(),tag.end()):
            key=a.group('key').lower();which=next(n for n in ('d','s','u') if a.group(n) is not None)
            attrs[key]=(a.start(which),a.end(which))
        if not all(k in attrs for k in (b'name',b'type',b'value')):continue
        a,z=attrs[b'name'];ta,tz=attrs[b'type']
        if z-a!=5 or tz-ta!=6 or data[a:z].lower()!=b'ufprt' or data[ta:tz].lower()!=b'hidden':continue
        a,z=attrs[b'value'];result.append({'field':'ufprt','shape':'raw-byte hidden input value','byteStart':a,'byteEndExclusive':z,'valueBytes':z-a,'alreadyExplicitlyRedacted':data[a:min(z,a+9)].lower()==b'[redacted'})
    for q in QUERY.finditer(data):
        a,z=q.span('value');result.append({'field':q.group('key').decode('ascii').lower(),'shape':'raw-byte mitigation query value','byteStart':a,'byteEndExclusive':z,'valueBytes':z-a,'alreadyExplicitlyRedacted':data[a:min(z,a+9)].lower()==b'[redacted'})
    return sorted(result,key=lambda r:(r['byteStart'],r['field']))
def fixtures():
    cases=[]
    for offset in (0,65530,65535,65536,65540,131070):
        payload=b'x'*offset+b'<input value="example-fixture-value" type="hidden" name="ufprt">';rows=find(payload)
        assert len(rows)==1 and rows[0]['byteStart']==offset+14 and payload[rows[0]['byteStart']:rows[0]['byteEndExclusive']]==b'example-fixture-value';cases.append({'fixture':'hidden-field boundary','offset':offset,'passed':True})
    values=[(b"<INPUT TYPE='HIDDEN' VALUE='example-fixture-value' NAME='UFPRT'>",1),(b'<input name=ufprt type=hidden value=example-fixture-value>',1),(b'<input name="ufprt" type="text" value="example-fixture-value">',0),(b'<input name="other" type="hidden" value="example-fixture-value">',0),(b'?mitb_clt744=example-fixture-value&next=1',1),(b'&amp;mitb_clt12=example-fixture-value"',1),(b'?other=example-fixture-value',0),(b'?mitb_clt744=[REDACTED-RUNTIME-VALUE]',1)]
    for i,(payload,count) in enumerate(values):assert len(find(payload))==count;cases.append({'fixture':'exact shape or negative','index':i,'passed':True})
    payload=b'<input data-padding="'+b'x'*10000+b'" name="ufprt" type="hidden" value="example-fixture-value">';assert len(find(payload))==1;cases.append({'fixture':'complete tag exceeds8192bytes','passed':True})
    return cases
def main():
    assert resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456) and not OUT.exists()
    fixture_results=fixtures();sc,sp=metadata(C/'source-capture.json');pc,pp=metadata(C/'proof-capture-v1.json');proposal,rp=metadata(C/'INDEPENDENT-DEEPAL-RUNTIME-CLASSIFICATION-v2.json')
    selected=[{'member':'roadmark/'+r['path'],**{k:r[k] for k in ('bytes','sha256','payloadPath')}} for r in sc['files']]
    selected += [{'member':r['path'],**{k:r[k] for k in ('bytes','sha256','payloadPath')}} for r in pc['changedFiles']]
    assert len(selected)==len({r['member'] for r in selected})==1396
    known={(f['member'],r['field'],r['byteStart'],r['byteEndExclusive']) for f in proposal['files'] for r in f['ranges'] if r['field']=='ufprt' or r['field'].startswith('mitb_clt')}
    rows=[];bytes_checked=0
    for r in selected:
        path=P(r['payloadPath']);before=identity(path);assert before[0]==r['bytes'];digest=hashlib.sha256();found=[]
        with path.open('rb') as stream:
            if before[0]:
                with mmap.mmap(stream.fileno(),0,access=mmap.ACCESS_READ) as data:
                    for start in range(0,len(data),65536):digest.update(data[start:start+65536])
                    found=find(data)
        assert identity(path)==before and digest.hexdigest()==r['sha256'],r['member']
        bytes_checked+=r['bytes']
        for f in found:
            entry={'member':r['member'],'filePin':{'bytes':r['bytes'],'sha256':r['sha256']},**f}
            entry['alreadyInReviewedRangeProposal']=(r['member'],f['field'],f['byteStart'],f['byteEndExclusive']) in known
            rows.append(entry)
    result={'schemaVersion':1,'result':'COMPLETE_WITH_ADDITIONAL_REVIEW_REQUIRED' if any(not r['alreadyInReviewedRangeProposal'] and not r['alreadyExplicitlyRedacted'] for r in rows) else 'PASS_NO_ADDITIONAL_UNREVIEWED_SUPPORTED_SHAPES','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCapture':sp,'proofCapture':pp,'classification':rp,'filesChecked':len(selected),'bytesChecked':bytes_checked,'sourceFiles':len(sc['files']),'proofFiles':len(pc['changedFiles']),'matches':rows,'matchCount':len(rows),'additionalUnreviewedMatches':sum(not r['alreadyInReviewedRangeProposal'] and not r['alreadyExplicitlyRedacted'] for r in rows),'boundaryFixtures':fixture_results,'matchingMethod':'One complete read-only mmap-backed captured payload at a time; exact complete-file byte regex, not streaming overlap approximation','supportedSemantics':['Raw-byte input tags delimited by angle brackets with case-insensitive exact name ufprt and type hidden; quoted or unquoted attribute values; no artificial tag-length cutoff','Raw-byte query parameter mitb_clt followed by decimal digits, after question mark, ampersand or literal amp-entity; value ends at ampersand, ASCII whitespace, quote, angle bracket or backslash'],'limitations':['No arbitrary HTML entity, JavaScript escape, URL or embedded-format decoding in this additive shape inventory','Regex-defined raw-byte shapes are not a complete HTML parser or a general request-control detector','Unchanged existing detectors and known-value variants are separate gates'],'noRawApiManagerOriginalReads':True,'onlyCapturedPayloadPathsRead':True,'originalsOrCapturedPayloadsModified':False,'valuesOrValueDigestsPersisted':False,'seedReads':0,'historicalArchiveReads':0,'newClassificationsGranted':False}
    with OUT.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({'result':result['result'],'files':len(selected),'bytes':bytes_checked,'matches':len(rows),'additionalUnreviewed':result['additionalUnreviewedMatches']}))
if __name__=='__main__':main()
