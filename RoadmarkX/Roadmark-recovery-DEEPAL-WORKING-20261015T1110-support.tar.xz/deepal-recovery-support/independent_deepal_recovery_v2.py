#!/usr/bin/env python3
"""Independent current-cut streaming replay; no inherited archive replay or restore tree."""
import copy, datetime, hashlib, json, lzma, pathlib, resource, stat, sys, tarfile, time, traceback
sys.dont_write_bytecode = True
P = pathlib.Path
C = P(__file__).resolve().parent
R = C.parents[1]
W = R.parent
BASE = C.parent / 'audi-working-20261015T0800'
LABEL = 'DEEPAL-WORKING-20261015T1110'
LIMIT, CHUNK = 268435456, 65536
OUT = C / 'INDEPENDENT-DEEPAL-RECOVERY-VERIFICATION-v1.json'
REPLAY = C / 'INDEPENDENT-NEW-MEMBER-REPLAY-MANIFEST-v1.json'
START = time.monotonic()
RESULT = {'result': 'IN_PROGRESS'}

def ck(value, message):
    if not value: raise AssertionError(message)

def load(path): return json.loads(P(path).read_bytes())
def encoded(value): return (json.dumps(value, indent=2) + '\n').encode()
def core(row): return {key: row[key] for key in ('path', 'bytes', 'sha256')}
def original(row): return {'bytes': row['originalBytes'], 'sha256': row['originalSHA256']}
def sizehash(row): return {key: row[key] for key in ('bytes', 'sha256')}
def dump(path, value):
    with P(path).open('x') as stream: json.dump(value, stream, indent=2); stream.write('\n')
def identity(path):
    path = P(path); s = path.lstat()
    ck(stat.S_ISREG(s.st_mode) and not any(p.is_symlink() for p in path.parents), 'nonregular or symlink path ' + str(path))
    return [s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_ino, s.st_dev]
def pin(path):
    path = P(path); before = identity(path); digest = hashlib.sha256(); count = 0
    with path.open('rb') as stream:
        while block := stream.read(CHUNK): digest.update(block); count += len(block)
    ck(identity(path) == before and count == before[0], 'unstable file ' + str(path))
    return {'bytes': count, 'sha256': digest.hexdigest()}
def check(path, expected):
    actual = pin(path); ck(actual == sizehash(expected), 'file pin differs ' + str(path)); return actual
def safe(name):
    path = P(name); ck(name and not path.is_absolute() and '..' not in path.parts and str(path) == name and '\\' not in name, 'unsafe member ' + name)
def rows_map(rows):
    result = {}
    for row in rows:
        safe(row['path']); ck(row['path'] not in result, 'duplicate member ' + row['path']); result[row['path']] = core(row)
    return result
def restore_path(path):
    path = P(path)
    if path.is_relative_to('/tmp'): name = path.relative_to('/tmp').as_posix()
    elif path.is_relative_to(W / 'roadmark-104'): name = 'roadmark/' + path.relative_to(W / 'roadmark-104').as_posix()
    else:
        ck(path.is_relative_to(W / 'roadmark-104-qa') or path.is_relative_to(W / 'roadmark-104-visual-qa-20261015'), 'unexpected selected root')
        name = path.relative_to(W).as_posix()
    safe(name); return name
def pointer(value, field):
    if field == '': return value
    ck(field.startswith('/'), 'invalid JSON pointer')
    for key in field.split('/')[1:]:
        key = key.replace('~1', '/').replace('~0', '~'); value = value[int(key)] if isinstance(value, list) else value[key]
    return value
def terminal(path, command, expected_exit=0):
    path = P(path); invocation = path.with_name(path.stem + '.invocation.json')
    actual, started = load(path), load(invocation)
    ck(actual['command'] == started['command'] == command, 'terminal command differs ' + path.name)
    ck(actual['exitCode'] == expected_exit and not actual['timedOut'], 'terminal outcome differs ' + path.name)
    ck(actual['addressSpaceLimitBytes'] == started['addressSpaceLimitBytes'] == LIMIT, 'terminal ceiling differs')
    ck(actual['wallLimitSeconds'] == started['wallLimitSeconds'] == 600 and actual['childPid'] == started['childPid'], 'terminal bounds differ')
    ck(actual['maxRssKiB'] > 0, 'missing RSS')
    return {'receipt': {'path': str(path), **pin(path)}, 'invocation': {'path': str(invocation), **pin(invocation)}, 'command': command, 'exitCode': expected_exit, 'addressSpaceLimitBytes': LIMIT, 'maxRssKiB': actual['maxRssKiB'], 'wallSeconds': actual['wallSeconds']}
def seed_ledgers(scan_entries, provenance_pin):
    terminals = [(P(row['terminal']['path']), load(row['terminal']['path'])) for row in scan_entries]
    declared = {str(path) for path, value in terminals}
    for path in C.glob('*.resources.json'):
        value = load(path); command = value.get('command', [])
        if any(P(arg).name.startswith('privacy_v') and P(arg).suffix == '.py' for arg in command):
            ck(str(path) in declared, 'unaccounted production scan attempt')
    ck(all(value['exitCode'] in (0, 2) for path, value in terminals), 'partial failed seed invocation requires separate exact accounting')
    historical, audi = [], []
    classification_path = BASE / 'INDEPENDENT-AUDI-RUNTIME-BATCH-CLASSIFICATION-v1.json'
    check(classification_path, {'bytes': 720844, 'sha256': '4bb97b40446fad1a43e08b498ebdab7e1c82af35470de5b83419932047f3eb5a'})
    classification = load(classification_path); by = {row['member']: row for row in classification['files']}; reads = []
    for group in classification['newValueSources']:
        source = group['sources'][0]; row = by[source['member']]
        reads.append({'valueGroup': group['id'], 'path': row['originalPath'], 'pin': row['originalPin'], 'byteStart': source['byteStart'], 'byteEndExclusive': source['byteEndExclusive'], 'payloadReadOperations': 1})
    ck(len(reads) == 6 and len({r['path'] for r in reads}) == 4, 'Audi seed metadata differs')
    for folder, output in [('seed-read-invocations', historical), ('audi-seed-read-invocations', audi)]:
        for path in sorted((C / folder).glob('*.json')):
            value = load(path)
            if folder == 'seed-read-invocations':
                ck(value['exactPinnedMembersReadAndVerified'] == 200 and value['historicalArchives'] == 21 and value['noExtractedValuesPersisted'], 'historical seed scope differs')
                ck(value['memberIdentityListPin'] == sizehash(provenance_pin), 'historical seed provenance differs')
            else:
                ck(value['distinctValues'] == 6 and value['variantForms'] == 37 and value['payloadReadOperations'] == 6 and value['uniqueOriginalFiles'] == 4, 'Audi seed counts differ')
                ck(value['reads'] == reads and value['classificationReceiptPin'] == pin(classification_path), 'Audi seed exact reads differ')
                ck(value['noValuesOrValueDigestsPersisted'] and not value['generalURLDecodedRuntimeCoverageClaimed'], 'Audi seed privacy boundary differs')
            when = datetime.datetime.fromisoformat(value['completedAt'])
            matches = [(p, t) for p, t in terminals if t['childPid'] == value['processId'] and datetime.datetime.fromisoformat(t['startedAt']) <= when <= datetime.datetime.fromisoformat(t['endedAt'])]
            ck(len(matches) == 1, 'seed receipt lacks one matching production terminal')
            output.append({'receipt': {'path': str(path), **pin(path)}, 'terminal': str(matches[0][0]), 'processId': value['processId'], 'completedAt': value['completedAt']})
        for path, value in terminals:
            if value['exitCode'] in (0, 2): ck(sum(r['terminal'] == str(path) for r in output) == 1, 'successful scanner seed receipt missing or duplicate')
    return historical, audi

def main():
    ck('--sole-child-slot-authorized' in sys.argv, 'sole heavy slot release required')
    ck(resource.getrlimit(resource.RLIMIT_AS) == (LIMIT, LIMIT), '256 MiB ceiling absent')
    ck(not OUT.exists() and not REPLAY.exists(), 'preserve earlier outcomes')
    input_path = C / 'INDEPENDENT-DEEPAL-REPLAY-INPUTS-v1.json'; inputs = load(input_path)
    ck(inputs['result'] == 'APPROVED_PINNED_FRESH_REPLAY_INPUTS', 'reviewed replay input binding absent')
    input_pin = pin(input_path); metadata = inputs['metadata']
    required = {'scope', 'initialIdentities', 'sourceCapture', 'proofCapture', 'sourcePackage', 'proofPackages', 'supportInventory', 'supportReuse', 'supportPackage', 'restorePlan', 'archivePlan', 'initialArchivePlan', 'freshRestoreManifest', 'privacyGate', 'application', 'dependencyMap', 'dependencyProposal', 'dependencyReview', 'copySanitation', 'keyApprovals', 'symlinks', 'seedProvenance', 'inheritedLocalSeedScope', 'imageProvenance'}
    ck(set(metadata) == required, 'replay metadata binding keys differ')
    docs = {}
    for name, row in metadata.items():
        check(row['path'], row); docs[name] = load(row['path'])
    for row in inputs['scriptPins']: check(row['path'], row)
    ck(any(P(row['path']) == P(__file__) and sizehash(row) == pin(__file__) for row in inputs['scriptPins']), 'verifier script not pinned')
    phases = {row['phase']: terminal(row['terminal']['path'], row['command'], row.get('expectedExitCode', 0)) for row in inputs['phaseCommands']}
    ck(len(phases) == len(inputs['phaseCommands']), 'duplicate phase')
    base_path = BASE / 'deliverables/Roadmark-RECOVERY-MANIFEST-AUDI-WORKING-20261015.json'
    check(base_path, {'bytes': 3164815, 'sha256': '7aa4e370c9c08df69663204e1c07ef61dddbe06bbabb0d94e33d2bb9866e59db'})
    check(BASE / 'FINAL-AUDI-UPLOAD-RECEIPTS.json', {'bytes': 192619, 'sha256': 'a8f19be0195ac6375cebdef520011789227e54435464af36860efd5c5440ec87'})
    base = load(base_path); old = rows_map(base['files'])
    ck(len(old) == 11158 and len(base['archivesInRestoreOrder']) == 126, 'closed Audi base counts differ')
    scope, identities = docs['scope'], docs['initialIdentities']
    ck(identities['result'] == 'PASS_EXACT_718_SELECTED_FILE_INITIAL_IDENTITY_BINDING' and identities['identityFields'] == ['size', 'mtimeNs', 'ctimeNs', 'inode', 'device'] and identities['atimeExcluded'], 'independent identity contract differs')
    ids = {r['path']: r['identity'] for r in identities['files']}; frozen = {restore_path(r['path']): r for r in scope['files']}
    ck(len(frozen) == len(scope['files']) == len(ids) == 718, 'frozen scope differs')
    source_capture, proof_capture = docs['sourceCapture'], docs['proofCapture']
    old_source = {r['path']: r for r in load(BASE / 'source-capture.json')['files']}
    current = {r['path']: r for r in source_capture['files']}; captured = {r['path']: r for r in proof_capture['files']}; delta = {r['path']: r for r in proof_capture['changedFiles']}
    ck(len(current) == len(source_capture['files']) == scope['expectedSourceFiles'] == 688 and set(old_source) <= set(current), 'full source inventory differs')
    changed = {n for n, r in current.items() if n not in old_source or original(r) != original(old_source[n])}
    ck(changed == set(scope['sourceChangedPaths']) and len(changed) == 10, 'exact source delta differs')
    state = (C / 'WORKING-STATE.txt').read_text()
    ck(source_capture['state'] == proof_capture['state'] == state == scope['workingResult'] + '\n', 'working result differs')
    ck(source_capture['chunkBytes'] == proof_capture['chunkBytes'] == CHUNK and not source_capture['fullSourceTreeCloned'] and proof_capture['noBroadQaTraversal'], 'capture resource contract differs')
    ck(not source_capture['sourceChangesDuringCapture'] and not proof_capture['sourceChangesDuringCapture'], 'capture stability differs')
    for name, row in current.items():
        safe(name); ck(row['originalPath'] == str(W / 'roadmark-104' / name), 'source locator differs')
        if name in changed:
            expected = frozen['roadmark/' + name]
            ck(original(row) == {'bytes': expected['bytes'], 'sha256': expected['sha256']} == sizehash(row), 'changed source pin or transformation differs')
            ck(row['sourceIdentity'] == ids[row['originalPath']], 'changed source identity differs')
        else:
            prior = old_source[name]
            ck(all(row.get(k, []) == prior.get(k, []) for k in ('bytes', 'sha256', 'originalBytes', 'originalSHA256', 'redactedHeaderPaths', 'redactedPointers', 'redactedHTMLRanges')), 'source sanitation lineage differs')
            ck(row['payloadPath'] == prior['payloadPath'] and row['captureMethod'] == 'exact-original-and-prior-sanitized-hashes', 'prior source reuse differs')
    ck(len(captured) == len(proof_capture['files']) == len(frozen) and len(delta) == len(proof_capture['changedFiles']) == 708 and proof_capture['scope'] == scope, 'proof capture scope differs')
    ck(docs['keyApprovals']['files'] == [] and docs['copySanitation']['result'] == 'NO_NEW_TRANSFORMATIONS' and docs['copySanitation']['files'] == [] and docs['copySanitation']['locationCount'] == 0, 'unexpected current sanitation')
    covered, reused = [], []
    for name, expected in frozen.items():
        row = captured[name]
        ck(row['originalPath'] == expected['path'] and row['sourceIdentity'] == ids[expected['path']], 'proof initial identity differs ' + name)
        ck(original(row)['bytes'] == expected['bytes'], 'frozen original size differs')
        if expected.get('sha256'): ck(original(row)['sha256'] == expected['sha256'], 'frozen original hash differs')
        if name.startswith('roadmark/'):
            source_row = current[name[9:]]
            ck(core(row) == {'path': name, **sizehash(source_row)} and original(row) == original(source_row) and row['captureMethod'] == 'covered-by-full-source' and name not in delta, 'source-covered proof differs'); covered.append(name)
        elif name in delta:
            ck(row == delta[name] and row['archiveAction'] == 'new-delta-member', 'proof delta differs')
            ck(sizehash(row) == original(row) and not row.get('metadataKeyRename') and not row.get('redactedPointers') and not row.get('redactedHTMLRanges'), 'unapproved new proof transformation')
        else:
            ck(core(row) == old[name] and row['archiveAction'] == 'reuse-exact-base-member', 'inherited proof member differs'); reused.append(name)
    links = docs['symlinks']; ck(links['result'] == 'EXACT_METADATA_AND_MEMBER_MAPPING' and links['noTraversalOrDependencyCapture'] and links['links'] == scope['metadataOnlySymlinks'] == [], 'symlink scope differs')
    source_package = docs['sourcePackage']; proof_packages = docs['proofPackages']['archives']; support_package = docs['supportPackage']; support = docs['supportInventory']
    archives = docs['archivePlan']['archives']; initial = docs['initialArchivePlan']['archives']; plan = docs['restorePlan']
    ck(len(initial) == 1 + len(proof_packages) and initial == [source_package] + proof_packages, 'immutable initial archive plan differs')
    ck([{k: v for k, v in r.items() if k != 'restoreOrder'} for r in archives] == [source_package] + proof_packages + [support_package] and archives == plan['newArchives'], 'final archive plan differs')
    generated = {'roadmark/SOURCE-FILE-MANIFEST.json': encoded({'schemaVersion': 1, 'root': 'roadmark', 'files': [core(r) for r in source_capture['files']]})}
    groups, group, group_bytes = [], [], 0
    for row in proof_capture['changedFiles']:
        if group and group_bytes + row['bytes'] > 24000000: groups.append(group); group = []; group_bytes = 0
        group.append(row); group_bytes += row['bytes']
    if group: groups.append(group)
    ck(len(groups) == len(proof_packages), 'proof group count differs')
    for index, (group, archive) in enumerate(zip(groups, proof_packages), 1):
        name = f'recovery-metadata/{LABEL}-part{index:02d}.json'
        value = {'schemaVersion': 1, 'label': LABEL, 'part': index, 'parts': len(groups), 'state': proof_capture['state'], 'files': [{k: r[k] for k in ('path', 'bytes', 'sha256', 'originalBytes', 'originalSHA256')} for r in group], 'restore': 'Overlay after the exact 126-archive Audi chain, replacing its source archive with this full registered Deepal working source. Original raw-capture expected hashes and sanitation mapping remain unchanged.'}
        generated[name] = encoded(value); members = rows_map(group)
        members[name] = {'path': name, 'bytes': len(generated[name]), 'sha256': hashlib.sha256(generated[name]).hexdigest()}
        if index == 1:
            name = 'deepal-safety-support/COPY-SANITATION-MAPPING.json'; generated[name] = P(metadata['copySanitation']['path']).read_bytes()
            members[name] = {'path': name, 'bytes': len(generated[name]), 'sha256': hashlib.sha256(generated[name]).hexdigest()}
        ck(rows_map(archive['memberFiles']) == members and [r['path'] for r in archive['memberFiles']] == list(members), 'proof metadata/member union or order differs')
        ck(archive['filename'] == f'Roadmark-recovery-{LABEL}-part{index:02d}of{len(groups):02d}.tar.xz', 'proof archive name differs')
    source_members = {'roadmark/' + n: {'path': 'roadmark/' + n, **sizehash(r)} for n, r in current.items()}
    name = 'roadmark/SOURCE-FILE-MANIFEST.json'; source_members[name] = {'path': name, 'bytes': len(generated[name]), 'sha256': hashlib.sha256(generated[name]).hexdigest()}
    ck(rows_map(source_package['memberFiles']) == source_members and source_package['bytes'] < 15000000, 'full source membership or strict compressed limit differs')
    reuse = docs['supportReuse']; aliases = reuse['files']
    check(metadata['scope']['path'], support['scopePin'])
    check(metadata['supportReuse']['path'], support['reuseMapping'])
    check(base_path, reuse['baseManifestPin'])
    ck(support['status'] == 'SEALED_UNIQUE_SUPPORT' and reuse['result'] == 'EXACT_BYTE_REUSE', 'support reuse schema differs')
    prefix = 'deepal-recovery-support/'
    retained_paths = {r['payloadPath'] for r in support['files']}; alias_paths = {r['originalPath'] for r in aliases}
    ck(len(retained_paths) == len(support['files']) and len(alias_paths) == len(aliases) and not (retained_paths & alias_paths), 'duplicate support input path')
    ck(support['selectedLocalSupportFiles'] == len(support['files']) - 1 + len(aliases) and support['uniqueNewFiles'] == len(support['files']) and support['exactReusedOrAliasedFiles'] == len(aliases), 'support selection counts differ')
    new_support = rows_map(support['files'])
    for row in support['files']:
        local = P(row['payloadPath']).relative_to(C).as_posix(); safe(local)
        ck(row['path'] == prefix + local, 'support member path differs'); check(row['payloadPath'], row)
    for alias in aliases:
        path = P(alias['originalPath']); ck(path.is_relative_to(C) and path.relative_to(C).as_posix() == alias['localRelativePath'], 'support alias input location differs'); check(path, alias)
        target = alias['retainedMember']
        if alias['kind'] == 'exact-inherited-member': ck(target in old and sizehash(old[target]) == sizehash(alias), 'inherited support reuse differs')
        else: ck(alias['kind'] == 'exact-new-unique-member-alias' and target in new_support and sizehash(new_support[target]) == sizehash(alias), 'new support alias differs')
    scripts = [r for r in support['files'] if P(r['payloadPath']).suffix == '.py']; script_bytes = {(r['bytes'], r['sha256']) for r in scripts}
    ck(len(script_bytes) == len(scripts), 'duplicate executable bytes in new support')
    inherited_script_bytes = {(r['bytes'], r['sha256']) for r in base['files'] if r['path'].endswith('.py')}
    ck(not (script_bytes & inherited_script_bytes), 'inherited executable bytes unnecessarily recopied')
    for row in inputs['scriptPins']:
        if P(row['path']).parent == C: ck(row['path'] in retained_paths | alias_paths, 'current script absent from retained support or exact reuse mapping')
    for path in C.glob('*.py'):
        ck(str(path) in retained_paths | alias_paths, 'local script version absent from support selection ' + path.name)
        actual = pin(path); ck((actual['bytes'], actual['sha256']) in script_bytes | inherited_script_bytes, 'unique script version not retained ' + path.name)
    ck(str(P(__file__)) in retained_paths, 'current verifier missing from unique new support')
    members = rows_map(support['files']); name = f'recovery-metadata/{LABEL}-support.json'; generated[name] = encoded(support)
    members[name] = {'path': name, 'bytes': len(generated[name]), 'sha256': hashlib.sha256(generated[name]).hexdigest()}
    ck(rows_map(support_package['memberFiles']) == members and [r['path'] for r in support_package['memberFiles']] == list(members), 'support metadata/member union differs')
    application = docs['application']; ck(application['result'] == 'APPROVED_EXACT_CAPTURED_APPLICATION_ASSERTIONS' and len(application['assertions']) == 140 and len(application['retainedPins']) == 108, 'application contract differs')
    assertions_by_member = {}
    for assertion in application['assertions']: assertions_by_member.setdefault(assertion['restorePath'], []).append(assertion)
    scan_entries = inputs['scanReports']; scans_by_archive = {}
    for entry in scan_entries:
        check(entry['report']['path'], entry['report']); check(entry['terminal']['path'], entry['terminal']); check(entry['archivePlan']['path'], entry['archivePlan'])
        if entry.get('finalCoverage', True):
            ck(entry['archive'] not in scans_by_archive, 'duplicate final scan coverage'); scans_by_archive[entry['archive']] = entry
    ck(set(scans_by_archive) == {r['filename'] for r in archives}, 'privacy report archive coverage differs')
    baseline_scan = load(BASE / 'scan-final-01.json')
    expected_counts = {k: v for k, v in baseline_scan.items() if k.endswith(('Values', 'Forms')) or k in ('originalSeedMembers', 'audiOriginalPayloadReadOperations')}
    ck(expected_counts['originalSeedMembers'] == 200 and expected_counts['audiRuntimeValues'] == 6 and expected_counts['audiRuntimeForms'] == 37, 'baseline seed counts differ')
    cache_source = {r['path']: r for r in load(C.parent / 'xpeng-registered-working-20261014T2030/source-capture.json')['files']}
    fresh, verified_archives, scan_rows, assertions_checked = {}, [], [], 0
    for index, archive in enumerate(archives, 1):
        path = P(archive['file']); ck(path.parent == R and path.name == archive['filename'], 'fresh archive locator differs'); check(path, archive)
        wanted, actual = rows_map(archive['memberFiles']), {}
        with lzma.open(path, 'rb') as stream:
            with tarfile.open(fileobj=stream, mode='r|') as tar:
                for member in tar:
                    safe(member.name); ck(member.isfile() and member.name in wanted and member.name not in actual and member.name not in fresh, 'unsafe/unexpected/duplicate fresh member')
                    digest, count = hashlib.sha256(), 0
                    collect = member.name in generated or member.name in assertions_by_member
                    parts = [] if collect else None
                    with tar.extractfile(member) as payload:
                        while block := payload.read(CHUNK):
                            digest.update(block); count += len(block)
                            if parts is not None: parts.append(block)
                    row = {'path': member.name, 'bytes': count, 'sha256': digest.hexdigest()}
                    ck(row == wanted[member.name] and count == member.size, 'fresh member bytes differ ' + member.name)
                    actual[member.name] = row; fresh[member.name] = row
                    if parts is not None:
                        data = b''.join(parts)
                        if member.name in generated: ck(data == generated[member.name], 'generated metadata bytes differ')
                        if member.name in assertions_by_member:
                            value = json.loads(data)
                            for assertion in assertions_by_member[member.name]:
                                ck(pointer(value, assertion['pointer']) == assertion['expected'], 'application assertion differs ' + member.name + assertion['pointer']); assertions_checked += 1
            while stream.read(CHUNK): pass
        ck(actual == wanted and list(actual) == list(wanted) and len(actual) == archive['members'], 'fresh member order/coverage differs'); check(path, archive)
        entry = scans_by_archive[path.name]; report = load(entry['report']['path'])
        scan_terminal = terminal(entry['terminal']['path'], entry['command'], entry.get('expectedExitCode', 0))
        ck(entry['expectedExitCode'] == 0 if 'expectedExitCode' in entry else True, 'unresolved privacy terminal')
        expected_plan = metadata['archivePlan'] if archive['filename'] == support_package['filename'] else metadata['initialArchivePlan']
        ck(entry['archivePlan'] == expected_plan and entry['command'][-1] == expected_plan['path'], 'initial/final scan plan binding differs')
        ck(report['status'] == 'clean' and report['archive'] == path.name and report['archivePin'] == sizehash(archive) and rows_map(report['members']) == actual, 'privacy archive/member coverage differs')
        ck(report['regularFilesScanned'] == len(actual) and report['bytesScanned'] == sum(r['bytes'] for r in actual.values()) and report['currentByteSearchForEveryMember'] and report['chunkBytes'] == CHUNK, 'privacy scan totals differ')
        ck(all(not report[k] for k in ('exactValueMatches', 'primaryHeaderCandidates', 'unclassifiedRuntimeCandidates', 'errors')), 'unresolved privacy findings')
        ck(all(report[k] == v for k, v in expected_counts.items()) and report['patternCacheProvenance'] == baseline_scan['patternCacheProvenance'], 'scanner seeds or rule cache differ')
        ck(report['classifiedExactCodeHeaderCandidates'] == [], 'unexpected new code exception')
        for row in report['members']:
            name = row['path']; eligible = name.startswith('roadmark/') and name != 'roadmark/SOURCE-FILE-MANIFEST.json' and name[9:] in cache_source and core(row) == {'path': name, **sizehash(cache_source[name[9:]])}
            ck((row['patternVerdict'] == 'exact-prior-source-cache') == eligible and (eligible or row['patternVerdict'] == 'current-full-unchanged-scanner'), 'pattern cache eligibility differs')
            ck(row['exactMatchesObserved'] == row['classifiedPublicLexicalCollisions'] + row['unresolvedExactMatches'] and row['unresolvedExactMatches'] == 0, 'exact-match accounting differs')
        ck(sum(r['classifiedPublicLexicalCollisions'] for r in report['members']) == report['classifiedPublicLexicalCollisions'], 'public collision totals differ')
        scan_rows.append({'archive': path.name, 'report': entry['report'], 'terminal': scan_terminal, 'archivePlan': expected_plan, 'members': len(actual), 'bytes': sum(r['bytes'] for r in actual.values()), 'classifiedPublicLexicalCollisions': report['classifiedPublicLexicalCollisions']})
        verified_archives.append({'filename': path.name, **pin(path), 'members': len(actual), 'uncompressedBytes': sum(r['bytes'] for r in actual.values())})
        print(json.dumps({'stage': 'fresh-only-independent-replay', 'archive': index, 'members': len(actual), 'result': 'PASS'}), flush=True)
    ck(assertions_checked == len(application['assertions']), 'application assertion replay coverage differs')
    ck(fresh == rows_map(plan['newFiles']) and len(fresh) == plan['freshFiles'] and sum(r['bytes'] for r in fresh.values()) == plan['freshBytes'], 'fresh union differs')
    merged = {n: r for n, r in old.items() if not n.startswith('roadmark/')}; merged.update(fresh)
    ck(merged == rows_map(plan['files']) and len(merged) == plan['logicalFiles'] and sum(r['bytes'] for r in merged.values()) == plan['logicalBytes'], 'logical overlay differs')
    ck((set(old) & set(fresh)) - {n for n in old if n.startswith('roadmark/')} == set(scope['expectedNonSourceOverlay']) == {'roadmark-104-qa/work-status.json'}, 'unexpected non-source overlay')
    expected_archives = [dict(source_package) if r['group'].startswith('source-') else {**r, 'new': False} for r in base['archivesInRestoreOrder']] + copy.deepcopy(proof_packages) + [copy.deepcopy(support_package)]
    for index, row in enumerate(expected_archives, 1): row['restoreOrder'] = index
    ck(sum(r['group'].startswith('source-') for r in base['archivesInRestoreOrder']) == 1, 'base source count differs')
    ck(expected_archives == plan['archivesInRestoreOrder'] and plan['baseArchivesReused'] == 125 and plan['archiveCount'] == len(expected_archives), 'inherited archive identity/order differs')
    ck(docs['freshRestoreManifest'] == {'archivesInRestoreOrder': archives, 'files': list(fresh.values())}, 'fresh restore manifest differs')
    for row in proof_capture['files']: ck(merged[row['path']] == core(row), 'selected proof absent from logical overlay')
    inherited_sanitized = set()
    def inherited_mappings(value):
        if isinstance(value, dict):
            if 'sanitizedBytes' in value and 'sanitizedSHA256' in value and ('restorePath' in value or 'path' in value):
                name = value.get('restorePath') or value['path']; ck(merged[name] == old[name] == {'path': name, 'bytes': value['sanitizedBytes'], 'sha256': value['sanitizedSHA256']}, 'inherited sanitation pin differs'); inherited_sanitized.add(name)
            for child in value.values(): inherited_mappings(child)
        elif isinstance(value, list):
            for child in value: inherited_mappings(child)
    for name in ('sourceSanitation', 'copyOnlySanitation', 'inheritedCopyOnlySanitation', 'originalRawCaptureReplayCompatibility'): inherited_mappings(base[name])
    for row in base['copyOnlySanitation'].get('files', []):
        if row.get('metadataKeyRename'): ck(merged[row['path']] == old[row['path']] == core(row), 'inherited prose-key copy changed')
    proposal, dependency_map, dependency_review = docs['dependencyProposal'], docs['dependencyMap'], docs['dependencyReview']
    check(metadata['dependencyProposal']['path'], dependency_map['proposal']); check(metadata['dependencyReview']['path'], dependency_map['independentBeforeCopyReview'])
    check(metadata['scope']['path'], dependency_map['frozenScope']); check(base_path, dependency_map['baseManifest'])
    dependencies = copy.deepcopy(base['inheritedDependencyReconstruction']['dependencies']); ck(len(dependencies) == 114 and len(proposal['relocationProposals']) == 2, 'dependency scope differs')
    for relocation in proposal['relocationProposals']:
        parts = relocation['memberField'].split('/'); i, j = int(parts[3]), int(parts[5]); record = dependencies[i]; item = record['pins'][j]
        ck(record['originalPath'] == relocation['dependencyOriginalPath'] and item['expected'] == relocation['originalExpected'] and item['member'] == relocation['currentMember'], 'original dependency expectation differs')
        member = relocation['proposedMember']; ck(merged[member['path']] == fresh[member['path']] == member and sizehash(member) == sizehash(item['expected']), 'retained before-copy fresh replay differs')
        item['member'] = copy.deepcopy(member)
    dependencies.extend(copy.deepcopy(proposal['newDependencyRecords']))
    ck(len(dependencies) == len({r['originalPath'] for r in dependencies}) == 119 and dependencies == dependency_map['dependencies'], 'final dependency mapping differs')
    canonical = hashlib.sha256(json.dumps(dependencies, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    ck(canonical == dependency_map['dependenciesCanonicalSha256'] == dependency_review['mappingResults']['proposedDependenciesCanonicalSha256'], 'dependency canonical mapping differs')
    for record in dependencies:
        for item in record['pins']: ck(merged[item['member']['path']] == core(item['member']) and sizehash(item['member']) == sizehash(item['expected']), 'inherited/external dependency member differs')
    for row in application['retainedPins']: ck(merged[row['path']] == core(row), 'mandatory original application pin differs')
    for alias in aliases: ck(sizehash(merged[alias['retainedMember']]) == sizehash(alias), 'support reuse target absent from final logical overlay')
    images = docs['imageProvenance']; ck(len(images['files']) == 4 and images['noNewRenderPerformed'], 'image provenance scope differs')
    for row in images['files']:
        ck(merged[row['image']['path']] == core(row['image']) and merged[row['parentPDF']['path']] == core(row['parentPDF']), 'render or parent PDF pin differs')
        ck(not row['browserScreenshot'] and row['PDFPageOneBased'] > 0, 'image origin claim differs')
    for row in scope['authorRetention']['knownSanitizedSupport']['files']: ck(merged[restore_path(row['path'])] == {'path': restore_path(row['path']), **sizehash(row)}, 'sanitized-only Deepal support differs')
    ck(scope['authorRetention']['knownSanitizedSupport']['rawOriginalExcluded'] and scope['authorRetention']['knownSanitizedSupport']['rawOriginalContentMayNotBeReadOrCaptured'], 'raw Deepal exclusion contract differs')
    gate = docs['privacyGate']
    ck(gate['result'] == 'PASS' and gate['freshMembers'] == len(fresh) and gate['freshBytes'] == sum(r['bytes'] for r in fresh.values()) and len(gate['archives']) == len(archives), 'aggregate privacy union differs')
    ck(gate['classifiedPublicLexicalCollisions'] == sum(r['classifiedPublicLexicalCollisions'] for r in scan_rows) and gate['unclassifiedFindings'] == gate['errors'] == 0, 'aggregate privacy findings differ')
    for row, expected in zip(gate['archives'], scan_rows):
        ck(row['archive'] == expected['archive'] and sizehash(row['reportPin']) == sizehash(expected['report']) and row['members'] == expected['members'] and row['bytes'] == expected['bytes'], 'aggregate privacy report binding differs')
    historical, audi = seed_ledgers(scan_entries, metadata['seedProvenance'])
    ck(len(historical) == inputs['expectedScanInvocations']['historical'] and len(audi) == inputs['expectedScanInvocations']['audi'], 'actual seed invocation count differs')
    local_seeds = docs['inheritedLocalSeedScope']; ck(local_seeds['result'] == 'EXACT_UNCHANGED_SELECTOR_ACCOUNTING_SPECIFICATION' and len(local_seeds['files']) == 48 and local_seeds['payloadValueReadsPerSuccessfulInvocation'] == local_seeds['streamingIntegrityReadsPerSuccessfulInvocation'] == 48, 'local inherited seed scope differs')
    for row in local_seeds['metadataPins']: check(row['path'], row)
    ck(all(r['payloadValueReadsPerSuccessfulInvocation'] == r['streamingIntegrityReadsPerSuccessfulInvocation'] == 1 for r in local_seeds['files']), 'local inherited per-file accounting differs')
    complete_scans = [entry for entry in scan_entries if load(entry['terminal']['path'])['exitCode'] in (0, 2)]
    ck(len(complete_scans) == len(historical) == len(audi), 'complete seed invocation accounting differs')
    RESULT['inheritedLocalSeedExecutions'] = {'specification': metadata['inheritedLocalSeedScope'], 'completedInvocations': len(complete_scans), 'uniqueOriginalFiles': 48, 'payloadValueReads': 48 * len(complete_scans), 'streamingIntegrityReads': 48 * len(complete_scans), 'accountingMethod': 'Derived from immutable reviewed selector control flow and paired seed completion ledgers bound to actual completed scanner terminals; not separate per-file instrumentation', 'failedPartialInvocations': [], 'noValuesOrValueDigestsPersisted': True}
    for row in metadata.values(): check(row['path'], row)
    for row in inputs['scriptPins']: check(row['path'], row)
    check(input_path, input_pin)
    live = []; seen = set()
    for row in source_capture['files'] + proof_capture['files']:
        path = row['originalPath']
        if path in seen: continue
        seen.add(path)
        try: current_identity = identity(path)
        except (OSError, AssertionError): current_identity = None
        if current_identity != row['sourceIdentity']: live.append({'path': path, 'capturedIdentity': row['sourceIdentity'], 'currentIdentity': current_identity, 'classification': 'Later live identity differs from the verified immutable captured cut'})
    dump(REPLAY, {'result': 'PASS', 'method': 'Fresh source/proof/support only; non-materializing64KiB streaming hash/member-order verification to XZ EOF', 'archives': verified_archives, 'files': list(fresh.values()), 'fileCount': len(fresh), 'bytes': sum(r['bytes'] for r in fresh.values()), 'noExtractedTree': True})
    RESULT.update(result='PASS', verificationScope='All fresh members streamed and exact logical overlay verified; no inherited archive replay or restore clone', source={'files': len(current), 'changedPaths': sorted(changed), 'exactPriorReuse': len(current) - len(changed), 'captureCutoff': source_capture['captureCutoff'], 'strictCompressedUnder15000000': True}, proof={'selectedOriginalFiles': len(captured), 'sourceCovered': len(covered), 'reusedBaseMembers': len(reused), 'newDeltaFiles': len(delta), 'newTransformations': 0, 'captureCutoff': proof_capture['captureCutoff']}, support={'inventory': metadata['supportInventory'], 'archive': verified_archives[-1], 'uniquePinnedMembers': len(support['files']), 'uniqueExecutableFiles': len(scripts), 'noRecursiveExecutableText': True}, newArchives=verified_archives, phaseTerminals=phases, privacy={'result': 'PASS', 'reports': scan_rows, 'seedCounts': expected_counts, 'knownValuesPersistedOrPrinted': False, 'blockingOrUnclassifiedFindings': 0, 'newExemptions': 0, 'limitations': ['No decryption or arbitrary embedded-format decoding', 'No universal secret-free claim', 'Targeted URL-component representations only; no general URL-decoded runtime coverage']}, replay={'manifest': {'path': str(REPLAY), **pin(REPLAY)}, 'noDiskExtractedTree': True}, overlay={'baseArchiveCount': 126, 'unchangedBaseArchivesReused': 125, 'combinedArchiveCount': len(expected_archives), 'combinedLogicalFiles': len(merged), 'combinedLogicalBytes': sum(r['bytes'] for r in merged.values()), 'freshFiles': len(fresh), 'freshBytes': sum(r['bytes'] for r in fresh.values()), 'inheritedPayloadReadsByIndependentVerifier': 0}, inheritedSanitation={'exactPreservedMembers': len(inherited_sanitized), 'allOriginalAndSanitizedPinsUnchanged': True}, inheritedDependencyReconstruction={'mapping': metadata['dependencyMap'], 'records': 119, 'priorRecords': 114, 'relocatedPins': 2, 'unchangedInheritedRecords': 112, 'newRecords': 5, 'originalExpectedPinsUnchanged': True, 'freshBeforeCopyVerified': True, 'canonicalSha256': canonical}, application={'contract': metadata['application'], 'assertionCount': assertions_checked, 'mandatoryRetainedPins': len(application['retainedPins']), 'summary': application['summary'], 'workingState': state, 'openGates': scope['openGates']}, targetedHistoricalSeedExecutions={'completedInvocations': len(historical), 'targetedPinnedMemberReads': 200 * len(historical), 'uniquePinnedMembers': 200, 'uniqueHistoricalArchives': 21, 'receipts': historical, 'separateFromFreshMemberReplay': True}, targetedAudiSeedExecutions={'completedInvocations': len(audi), 'originalPayloadReadOperations': 6 * len(audi), 'uniqueOriginalFiles': 4, 'distinctValues': 6, 'variantForms': 37, 'receipts': audi, 'noValuesOrValueDigestsPersisted': True}, sanitizedOnlyDeepalSupport={'files': len(scope['authorRetention']['knownSanitizedSupport']['files']), 'rawOriginalReadRecoveryRefetchForbidden': True, 'rawOriginalRead': False}, postCaptureLiveChanges=live, inputPins=metadata, replayInputManifest={'path': str(input_path), **input_pin}, verifierScript={'path': str(P(__file__)), **pin(__file__)}, noUploadsOrDeletion=True)

if __name__ == '__main__':
    code = 0
    try: main()
    except BaseException as error:
        code = 1; RESULT.update(result='BLOCKED', blocker={'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()})
    RESULT['completedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    RESULT['resources'] = {'wallSeconds': round(time.monotonic() - START, 3), 'maxRssKiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss, 'addressSpaceLimitBytes': resource.getrlimit(resource.RLIMIT_AS)[0], 'chunkBytes': CHUNK, 'noRestoreClone': True}
    dump(OUT, RESULT); print(json.dumps({'result': RESULT['result'], 'resources': RESULT['resources'], 'blocker': RESULT.get('blocker')}), flush=True); sys.exit(code)
