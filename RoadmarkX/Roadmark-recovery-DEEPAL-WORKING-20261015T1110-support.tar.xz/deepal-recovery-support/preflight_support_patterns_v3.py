#!/usr/bin/env python3
"""Raw unchanged-pattern preflight of every new executable since support sealing."""
import ast, datetime, hashlib, importlib.util, json, pathlib, resource, stat, sys
sys.dont_write_bytecode = True
C = pathlib.Path(__file__).resolve().parent
A = C.parents[1] / 'privacy-audit-20261014T0355'
OUT = C / 'DEEPAL-SUPPORT-PATTERN-PREFLIGHT-v3.json'
def read(p):
 def identity():
  s=p.lstat();assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents)
  return [s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev]
 before=identity();b=p.read_bytes();assert identity()==before and len(b)==before[0]
 return b,{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def main():
 assert resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456) and not OUT.exists()
 prior=set();inventories={}
 base=C.parent/'audi-working-20261015T0800'
 manifest=base/'deliverables/Roadmark-RECOVERY-MANIFEST-AUDI-WORKING-20261015.json'
 b,p=read(manifest);inventories[str(manifest)]=p
 for row in json.loads(b)['files']:
  if row['path'].endswith('.py'):prior.add((row['bytes'],row['sha256']))
 old=json.loads(read(base/'INDEPENDENT-AUDI-CHECKER-PATTERN-PREFLIGHT-v1.json')[0]);engines=old['enginePins']
 for name,digest in engines.items():assert read(A/name)[1]['sha256']==digest
 sys.path.insert(0,str(A));spec=importlib.util.spec_from_file_location('replacement_support_preflight',A/'final_residual_scan_memory_bounded.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);primary,runtime=mod.patterns()
 rows=[]
 for p in sorted(C.glob('*.py')):
  b,pin=read(p)
  if (pin['bytes'],pin['sha256']) in prior:continue
  ast.parse(b);ps,_,_=primary(b,p.name);rs=runtime(b.decode('utf-8'));assert read(p)[1]==pin
  rows.append({'filename':p.name,**pin,'primaryFindings':ps,'rawRuntimeFindings':rs,'astValid':True})
 assert pathlib.Path(__file__).name in {r['filename'] for r in rows}
 result={'result':'PASS' if all(not r['primaryFindings'] and not r['rawRuntimeFindings'] for r in rows) else 'REVIEW_REQUIRED','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':rows,'newExecutableFiles':len(rows),'sealedInventoryPins':inventories,'enginePins':engines,'rawPatternsUnchanged':True,'knownValueSearchPerformed':False,'seedReads':0,'historicalArchiveReads':0,'payloadsModified':False,'newClassificationsGranted':False,'scope':'Every new checkpoint executable hash absent from exact inherited manifest; complete support archive privacy scan still required'}
 with OUT.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({'result':result['result'],'files':len(rows),'primaryFindings':sum(len(r['primaryFindings']) for r in rows),'rawRuntimeFindings':sum(len(r['rawRuntimeFindings']) for r in rows)}))
 return 0 if result['result']=='PASS' else 2
if __name__=='__main__':sys.exit(main())
