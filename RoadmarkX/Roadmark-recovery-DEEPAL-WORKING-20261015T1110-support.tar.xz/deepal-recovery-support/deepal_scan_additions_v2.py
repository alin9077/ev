"""Exact reviewed copied-field seeds and pinned syntax classifications, no broad exemption."""
import datetime,json,hashlib,os,time
from capture_v2 import C,P,load,pin,check,identity,dump
REVIEW=C/'INDEPENDENT-DEEPAL-RUNTIME-CLASSIFICATION-v3.json'
REVIEW_PIN={'bytes':52667,'sha256':'b448315960f3e54d72ff0133ca296094bc7ab9503bbc8233ea455a8cd6f2484d'}
def review():
 assert pin(REVIEW)==REVIEW_PIN;d=load(REVIEW);approval=load(C/'APPROVED-DEEPAL-RUNTIME-REMEDIATION.json');assert approval['classificationPin']==REVIEW_PIN and approval['copyOnly'];return d
def deepal_values(variants_for):
 d=review();values=set();reads=[]
 for f in d['files']:
  p=P(f['capturedPayloadPath']);before=identity(p);b=p.read_bytes();assert identity(p)==before and {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}==f['originalPin']
  for r in f['ranges']:
   value=b[r['byteStart']:r['byteEndExclusive']];assert value;values.add(value)
  reads.append({'path':str(p),'pin':f['originalPin'],'payloadReadOperations':1,'valueRanges':len(f['ranges'])})
 forms=set(variants_for({v:[] for v in values}));assert len(values)==6 and len(forms)==41 and len(reads)==5
 folder=C/'deepal-seed-read-invocations';folder.mkdir(exist_ok=True)
 record={'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'processId':os.getpid(),'classificationReceiptPin':REVIEW_PIN,'distinctValues':6,'variantForms':41,'payloadReadOperations':5,'reads':reads,'noValuesOrValueDigestsPersisted':True,'rawDeepalApiManagerOriginalRead':False,'URLComponentRepresentationIncludedByUnchangedVariantsFunction':True,'generalArbitraryDecodedCoverageClaimed':False}
 dump(folder/f'{os.getpid()}-{time.time_ns()}.json',record)
 return forms,{'deepalRuntimeValues':6,'deepalRuntimeForms':41,'deepalOriginalPayloadReadOperations':5}
def template_context(candidates,data,name):
 matches=[r for r in review()['files'] if r['member']==name and r['benignRuntimeSyntax']]
 if not matches:return candidates,[]
 assert len(matches)==1;f=matches[0];actual={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};assert actual==f['proposedSanitizedPin']
 expected=[r['proposedFinding'] for r in f['benignRuntimeSyntax']];assert len(expected)==len({json.dumps(x,sort_keys=True) for x in expected})
 classified=[];blocked=[]
 for candidate in candidates:
  if candidate in expected:
   r=f['benignRuntimeSyntax'][expected.index(candidate)];assert hashlib.sha256(data[r['proposedByteStart']:r['proposedByteEndExclusive']]).hexdigest()==r['matchedSyntaxSha256']
   classified.append({'member':name,'filePin':actual,'finding':candidate,'classification':r['classification']})
  else:blocked.append(candidate)
 assert len(classified)==len(expected) and sorted(json.dumps(r['finding'],sort_keys=True) for r in classified)==sorted(json.dumps(r,sort_keys=True) for r in expected)
 return blocked,classified
def code_context(candidates,data,name):
 approval=load(C/'APPROVED-DEEPAL-RUNTIME-REMEDIATION.json');path=C/'INDEPENDENT-DEEPAL-SUPPORT-SYNTAX-CLASSIFICATION-v1.json';check(path,approval['supportCodeClassificationPin']);d=load(path)
 rows=[r for r in d['exactSupportCodeClassifications'] if r['member']==name]
 if not rows:return candidates,[]
 actual={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};assert all(r['filePin']==actual for r in rows)
 expected=[{k:v for k,v in r['exactFinding'].items() if k!='member'} for r in rows];assert len(expected)==len({json.dumps(r,sort_keys=True) for r in expected})
 classified=[];blocked=[]
 for candidate in candidates:
  if candidate in expected:
   r=rows[expected.index(candidate)];assert hashlib.sha256(data[r['byteStart']:r['byteEndExclusive']]).hexdigest()==r['matchedSyntaxSHA256']
   classified.append({'member':name,'filePin':actual,'finding':candidate,'classification':r['classification']})
  else:blocked.append(candidate)
 assert len(classified)==len(rows) and len({json.dumps(r['finding'],sort_keys=True) for r in classified})==len(classified)
 return blocked,classified
