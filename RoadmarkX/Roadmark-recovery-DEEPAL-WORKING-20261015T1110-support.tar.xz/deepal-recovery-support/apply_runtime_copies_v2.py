"""Apply only approved byte ranges to new copies, preserving every original and pin."""
from capture_v2 import *
review=C/'INDEPENDENT-DEEPAL-RUNTIME-CLASSIFICATION-v3.json';assert pin(review)=={'bytes':52667,'sha256':'b448315960f3e54d72ff0133ca296094bc7ab9503bbc8233ea455a8cd6f2484d'}
approval=load(C/'APPROVED-DEEPAL-RUNTIME-REMEDIATION.json');assert approval['classificationPin']==pin(review) and approval['copyOnly']
d=load(review);assert d['summary']['files']==5 and d['summary']['htmlFiles']==4 and d['summary']['jsonFiles']==1 and d['summary']['proposedRuntimeValueRanges']==9
pc=load(C/'proof-capture-v1.json');by={r['path']:r for r in pc['files']};out=C/'runtime-redacted-copies-v1';out.mkdir(exist_ok=False);mapping=[]
for f in d['files']:
 r=by[f['member']];p=P(r['payloadPath']);check(p,f['originalPin']);ident=identity(p);b=p.read_bytes();assert identity(p)==ident and pin(p)==f['originalPin']
 ranges=f['ranges'];new=b
 for z in reversed(ranges):
  assert z['replacement']=='[REDACTED-RUNTIME-VALUE]';new=new[:z['byteStart']]+z['replacement'].encode()+new[z['byteEndExclusive']:]
 assert {'bytes':len(new),'sha256':sha(new)}==f['proposedSanitizedPin'];a=q=0
 for z in ranges:
  assert b[a:z['byteStart']]==new[q:z['proposedByteStart']]
  assert new[z['proposedByteStart']:z['proposedByteEndExclusive']]==z['replacement'].encode()
  a,q=z['byteEndExclusive'],z['proposedByteEndExclusive']
 assert b[a:]==new[q:]
 dest=out/f['member'];dest.parent.mkdir(parents=True,exist_ok=True);dest.open('xb').write(new);check(dest,f['proposedSanitizedPin']);assert identity(p)==ident
 r.update(**f['proposedSanitizedPin'],payloadPath=str(dest),captureMethod='exact-reviewed-runtime-copy-redaction',redactedRuntimeRanges=ranges,capturedFormat=f['format'])
 mapping.append({'path':f['member'],'originalPath':r['originalPath'],'preservedCapturedOriginal':str(p),'originalBytes':f['originalPin']['bytes'],'originalSHA256':f['originalPin']['sha256'],**f['proposedSanitizedPin'],'ranges':ranges,'everyOutsideRangeByteUnchanged':True,'visibleFactualTextUnchanged':f['visibleFactualTextUnchanged'],'jsonStructureAndOtherValuesUnchanged':f['jsonStructureAndOtherValuesUnchanged'],'format':f['format'],'sourcePinReferences':f['sourcePinReferences']})
pc['changedFiles']=[by[r['path']] for r in pc['changedFiles']];pc['files']=[by[r['path']] for r in pc['files']];pc['copySanitationReview']=pin(review);pc['priorUnchangedCapture']=pin(C/'proof-capture-v1.json')
dump(C/'proof-capture-v2.json',pc)
dump(C/'COPY-SANITATION-MAPPING-v2.json',{'result':'EXACT_REVIEWED_RUNTIME_COPY_REDACTIONS','files':mapping,'locationCount':9,'fileCount':5,'sourcePinReferencedFiles':3,'sourcePinReferences':18,'classificationPin':pin(review),'approvalScope':approval['approvalScope'],'originalExpectedPinsUnchanged':True,'originalsUnchanged':True,'exactOutsideRangeBytesUnchanged':True,'visibleHTMLFactualTextUnchanged':True,'JSONStructureAndUnrelatedValuesUnchanged':True,'originalReplayLimitation':'Five copied captures have new hashes; three have eighteen retained source-pin references. Original expected hashes remain unchanged and cannot be satisfied by sanitized bytes. Original working bytes or a separately reviewed replacement manifest are required for those original-pin checks.','priorNoTransformationMapping':pin(C/'COPY-SANITATION-MAPPING.json'),'alreadySanitizedApiManagerSupport':load(C/'FROZEN-CAPTURE-SCOPE.json')['authorRetention']['knownSanitizedSupport']})
print(json.dumps({'files':5,'ranges':9,'sourcePinReferencedFiles':3,'sourcePinReferences':18,'originalsUnchanged':True}))
