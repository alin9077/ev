#!/usr/bin/env python3
"""Explicit selected proof/QA + full source, exact hash reuse, no full source clone."""
import pathlib,json,hashlib,datetime,importlib.util,stat,sys,os
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent;R=C.parents[1];W=R.parent;OLD=C.parent/'xpeng-registered-working-20261014T2030';BASE=C.parent/'audi-working-20261015T0800';SANBASE=C.parent/'mercedes-research-safety-20261014T2145';CHUNK=65536

def load(p):return json.loads(P(p).read_text())
def dump(p,d):
 with P(p).open('x') as f:json.dump(d,f,indent=2);f.write('\n')
def sha(b):return hashlib.sha256(b).hexdigest()
def identity(p):
 z=p.lstat();assert stat.S_ISREG(z.st_mode) and not any(q.is_symlink() for q in p.parents),str(p);return [z.st_size,z.st_mtime_ns,z.st_ctime_ns,z.st_ino,z.st_dev]
def pin(p):
 h=hashlib.sha256();n=0
 with P(p).open('rb') as f:
  while b:=f.read(CHUNK):h.update(b);n+=len(b)
 return {'bytes':n,'sha256':h.hexdigest()}
def check(p,expected):
 a=identity(p);got=pin(p);assert identity(p)==a and got['bytes']==a[0],str(p)
 for k in ('bytes','sha256'):
  if expected.get(k) is not None:assert got[k]==expected[k],str(p)+' '+k
 return got,a
def module(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
S=module('snapshot',R/'snapshot_recovery_v2.py')
def safe(n):
 p=P(n);assert n and not p.is_absolute() and '..' not in p.parts and str(p)==n and '\\' not in n;return n
def restpath(p):
 p=P(p)
 if p.is_relative_to('/tmp'):return safe(p.relative_to('/tmp').as_posix())
 if p.is_relative_to(W/'roadmark-104'):return 'roadmark/'+safe(p.relative_to(W/'roadmark-104').as_posix())
 if p.is_relative_to(W/'roadmark-104-qa'):return safe(p.relative_to(W).as_posix())
 if p.is_relative_to(W/'roadmark-104-visual-qa-20261015'):return safe(p.relative_to(W).as_posix())
 raise ValueError('Unexpected selected root: '+str(p))
def capture(p,n,old,prior,out,expected):
 original,ident=check(p,expected);metadata_rename=False
 if old and original=={'bytes':old['originalBytes'],'sha256':old['originalSHA256']}:
  check(prior,old);rec={k:v for k,v in old.items() if k not in ('path','sourceMtimeNs','sourceIdentity')};payload=prior;method='exact-original-and-prior-sanitized-hashes'
 else:
  payload=out/n;payload.parent.mkdir(parents=True,exist_ok=True)
  if p.suffix=='.json' or p.suffix.lower()=='.headers':
   b=p.read_bytes();assert identity(p)==ident and len(b)==original['bytes'] and sha(b)==original['sha256'];red=[]
   if p.suffix=='.json':
    original_json=b
    approvals=load(C/'PROSE-KEY-RENAME-APPROVALS.json')['files']
    matches=[r for r in approvals if r['restorePath']==n]
    if matches:
     assert len(matches)==1;approved=matches[0];assert original=={'bytes':approved['originalBytes'],'sha256':approved['originalSHA256']}
     assert approved['oldPointer']=='/authorization' and approved['newPointer']=='/approvalScope'
     assert b.count(b'"authorization":')==1 and b'"approvalScope":' not in b
     renamed=b.replace(b'"authorization":',b'"approvalScope":',1)
     assert {'bytes':len(renamed),'sha256':sha(renamed)}=={'bytes':approved['bytes'],'sha256':approved['sha256']}
     before=json.loads(b);after=json.loads(renamed);value=before.pop('authorization');assert after.pop('approvalScope')==value and before==after
     b=renamed;metadata_rename=True
    b,red=S.sanitize_json(b)
   else:b,red=S.sanitize_headers(b)
   assert not red,'New sensitive-field class requires separate review: '+n
   with payload.open('xb') as f:f.write(b)
  else:
   h=hashlib.sha256();size=0
   with p.open('rb') as src,payload.open('xb') as dst:
    while b:=src.read(CHUNK):dst.write(b);h.update(b);size+=len(b)
   assert (size,h.hexdigest())==(original['bytes'],original['sha256'])
  rec={**pin(payload),'originalBytes':original['bytes'],'originalSHA256':original['sha256']};method='exact-reviewed-copy-only-json-sanitation' if p.suffix=='.json' and red else 'unchanged-full-sanitizer'
  if p.suffix=='.json' and red:rec['redactedPointers']=red
  if metadata_rename:rec['metadataKeyRename']={'oldPointer':'/authorization','newPointer':'/approvalScope','unchangedValueAndOtherBytes':True};method='exact-reviewed-metadata-key-rename'
 assert identity(p)==ident
 return {'path':n,**rec,'originalPath':str(p),'sourceIdentity':ident,'payloadPath':str(payload),'captureMethod':method}
def source():
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();oldcap=load(BASE/'source-capture.json');old={r['path']:r for r in oldcap['files']};pack=module('packager',W/'roadmark-104/scripts/package-source.py');files=list(pack.source_files(W/'roadmark-104'));out=C/'selected-source-changes';out.mkdir(exist_ok=False);rows=[]
 for rel,p in files:
  n=rel.as_posix();r=capture(p,n,old.get(n),P(old[n]['payloadPath']) if n in old else None,out,{});rows.append(r)
 assert [r.as_posix() for r,p in pack.source_files(W/'roadmark-104')]==[r['path'] for r in rows]
 for r in rows:assert identity(P(r['originalPath']))==r['sourceIdentity']
 dump(C/'source-capture.json',{'kind':'streaming-source','captureStartedAt':start,'captureCutoff':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':(C/'WORKING-STATE.txt').read_text(),'files':rows,'sourceChangesDuringCapture':[],'priorSourceManifest':str(BASE/'source-capture.json'),'fullSourceTreeCloned':False,'chunkBytes':CHUNK})
 print(json.dumps({'sourceFiles':len(rows),'reused':sum(r['captureMethod'].startswith('exact-') for r in rows),'changed':sum(not r['captureMethod'].startswith('exact-') for r in rows)}))
def proof():
 scope=load(C/'FROZEN-CAPTURE-SCOPE.json');origcap=load(BASE/'proof-capture-v2.json');old={r['path']:r for r in origcap['files'] if 'originalSHA256' in r};basefiles={r['path']:r for r in load(BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-AUDI-WORKING-20261015.json')['files']};sources={r['path']:r for r in load(C/'source-capture.json')['files']};out=C/'selected-proof-sanitized-v1';out.mkdir(exist_ok=False);rows=[];changed=[];seen=set();start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 for f in scope['files']:
  p=P(f['path']);n=restpath(p);assert n not in seen;seen.add(n);expected={'bytes':f['bytes'],'sha256':f.get('sha256') or f.get('knownSha256')};got,ident=check(p,expected)
  if f.get('mtimeNsAtFreeze') is not None:assert ident[1]==f['mtimeNsAtFreeze'],n
  if n.startswith('roadmark/'):
   r=sources[n.removeprefix('roadmark/')];assert got=={'bytes':r['originalBytes'],'sha256':r['originalSHA256']};rows.append({**r,'path':n,'captureMethod':'covered-by-full-source'});continue
  r=capture(p,n,old.get(n),P(old[n]['payloadPath']) if n in old else None,out,expected)
  if n in basefiles and {'bytes':r['bytes'],'sha256':r['sha256']}=={k:basefiles[n][k] for k in ['bytes','sha256']}:r['archiveAction']='reuse-exact-base-member'
  else:r['archiveAction']='new-delta-member';changed.append(r)
  rows.append(r)
 for r in rows:assert identity(P(r['originalPath']))==r['sourceIdentity'],r['path']
 dump(C/'proof-capture-v1.json',{'kind':'explicit-proof-qa-delta','captureStartedAt':start,'captureCutoff':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':(C/'WORKING-STATE.txt').read_text(),'files':rows,'changedFiles':changed,'sourceChangesDuringCapture':[],'scope':scope,'chunkBytes':CHUNK,'noBroadQaTraversal':True})
 print(json.dumps({'selectedFiles':len(rows),'newDeltaFiles':len(changed),'newBytes':sum(r['bytes'] for r in changed)}))
if __name__=='__main__':{'source':source,'proof':proof}[sys.argv[1]]()
