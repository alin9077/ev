import crypto from 'node:crypto';
import {readReplaySnapshot,incrementalDigest} from '/tmp/polestar-research/read-replay-snapshot.ts';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {catalogue,research,effectiveFeatures,pack} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/data.ts';
import {applyBrandUpdates,prepareBrandResearch,applyBrandFeatureUpdates,applyBrandTermFeatures,type BrandUpdatePacket} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-updates.ts';
import {brandUpdatePackets} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-update-registry.ts';
import {compiledSource} from '/workspace/scratch/586427eef9f2/roadmark-104/tests/helpers/compiled-source.ts';
import {loadReportInput} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/load.ts';
import {buildCoverageReport,coreFacts} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/reports.ts';
import {combineM1Reconciliations} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/m1-reconciliation.ts';
import {storePortablePacks,hydratePortablePacks} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/portable-packs.ts';
import {factClaim,featureClaim} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/citable.ts';
const R='/tmp/polestar-research/';const p=JSON.parse(fs.readFileSync(R+'polestar-2026-10-14.json','utf8')) as BrandUpdatePacket;
assert(!brandUpdatePackets.some(o=>o.id===p.id),'Candidate must remain unregistered');
const newFixture:any[]=JSON.parse(fs.readFileSync(R+'new-feature-before-v2.json','utf8'));
const cleared=structuredClone(p);cleared.features=[];assert.equal(crypto.createHash('sha256').update(JSON.stringify(cleared)).digest('hex'),JSON.parse(fs.readFileSync(R+'canonical-baseline-meta-v2.json','utf8')).canonicalHash,'Amended canonical hash unchanged');
assert.equal(p.variants.length,2,'Two exact MY26 Launch-edition provisional additions');
const tier1=(c:{vehicleClass?:string})=>!c.vehicleClass||['passenger','ute'].includes(c.vehicleClass);
for(const r of JSON.parse(fs.readFileSync(R+'replay-provenance-manifest.json','utf8')).sourceCode){assert.equal(crypto.createHash('sha256').update(fs.readFileSync('/workspace/scratch/586427eef9f2/roadmark-104/'+r.file)).digest('hex'),r.sha256,'Snapshot source/code unchanged: '+r.file)}
for(const r of JSON.parse(fs.readFileSync(R+'replay-provenance-manifest.json','utf8')).snapshot){assert.equal(crypto.createHash('sha256').update(fs.readFileSync(R+r.file)).digest('hex'),r.sha256,'Original full snapshot unchanged: '+r.file)}
console.log('Loading verified snapshot-backed original effective catalogue; source/code hashes match');
const {rd,before}=readReplaySnapshot(R);
console.log('Loaded',before.length,'cars');
const digest=(v:any)=>{const h=crypto.createHash('sha256');incrementalDigest(v,h);return h.digest('hex')};
const prior=digest({rd,before,p});
assert.deepEqual(JSON.parse(JSON.stringify(before.filter(c=>c.brand==='Polestar'&&tier1(c)))),JSON.parse(fs.readFileSync(R+'polestar-live-before.json','utf8')));
assert.deepEqual(JSON.parse(JSON.stringify(rd.sources)),JSON.parse(fs.readFileSync(R+'polestar-source-before.json','utf8')));
const data=prepareBrandResearch(rd,[p]);const cars=applyBrandUpdates(before,data,[p]);
console.log('Applied candidate');
const selected=cars.filter(c=>c.brand===p.brand&&tier1(c));const original=new Map(before.map(c=>[c.id,c]));
const staged=compiledSource('src/lib/data.ts',{'./brand-update-registry':{brandUpdatePackets:[...brandUpdatePackets,p]}}) as {pack:typeof pack};
const packs:Record<string,ReturnType<typeof pack>>={};let factCount=0,featureCount=0;
for(const car of selected){
 console.log('Checking',car.id);
 for(const {key} of coreFacts)assert.equal(car.facts[key]?.gradeReview?.overlayId,p.id,`${car.id} ${key}`);
 const start=effectiveFeatures(car,data);
 if(p.variants.some(v=>v.id===car.id))assert.deepEqual(JSON.parse(JSON.stringify(start)),newFixture.filter((f:any)=>f.variant_id===car.id),'Full new-version baseline includes canonical projections');
 const features=applyBrandTermFeatures(car,applyBrandFeatureUpdates(car,start,data,[p]));
 const view=staged.pack(car.id,{data,cars});assert.deepEqual(view.features,features,`${car.id}: actual pack replay`);packs[car.id]=view;
 for(const f of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===p.id)){const claim=factClaim(view,f);assert.equal(claim.buyerGrade,f.buyerGrade);assert.deepEqual(claim.sources.map(s=>s.id),f.sourceIds);factCount++;}
 for(const row of p.features?.filter(f=>f.variantId===car.id)||[]){const f=features.find(f=>f.criterion===row.criterion)!;assert.deepEqual(f,row.after);const claim=featureClaim(view,f.criterion,f.criterion)!;assert.deepEqual(claim.sources.map(s=>s.id),f.source_ids);assert.equal(claim.gradeReview?.overlayId,p.id);featureCount++;}
 assert.equal(features.find(f=>f.criterion==='roadside_assistance')?.status,'standard','Included Polestar roadside remains standard fitment');
 assert.equal(car.availabilityEvidence.physicalStockVerified,false);assert.equal(car.availabilityEvidence.factoryOrderAcceptanceVerified,false);
}
assert.deepEqual(hydratePortablePacks(storePortablePacks(packs),data.sources),packs,'Portable exact equality');
assert.equal(digest({rd,before,p}),prior,'Input objects unchanged');
assert.deepEqual(cars.filter(c=>c.brand!==p.brand||!tier1(c)),before.filter(c=>c.brand!==p.brand||!tier1(c)),'Other brands and Tier2 unchanged');
if(process.argv.includes('--pack-only')) {
 fs.writeFileSync(R+'after.json',JSON.stringify(selected,null,2));
 fs.writeFileSync(R+'features-after.json',JSON.stringify(Object.values(packs).flatMap(v=>v.features),null,2));
 fs.writeFileSync(R+'staged-packs.json',JSON.stringify(packs,null,2));
 console.log(JSON.stringify({status:'passed',mode:'final feature wording only; full report was generated before wording simplification',versions:selected.length,factCount,featureCount,actualPack:true,portableExact:true,immutableInputs:true}));
 process.exit(0);
}
console.log('Actual pack and portable checks passed; building report');
const reportLoader=compiledSource('scripts/reporting/load.ts',{'../../src/lib/data':{research:()=>rd,catalogue:()=>before,effectiveFeatures}}) as {loadReportInput:typeof loadReportInput};
const input=reportLoader.loadReportInput();input.cars=cars;input.sources=data.sources;input.features=input.features.filter(f=>!packs[f.variant_id]).concat(Object.values(packs).flatMap(v=>v.features));
input.m1Reconciliation=combineM1Reconciliations(input.m1Reconciliation!,JSON.parse(fs.readFileSync(R+'polestar-reconciliation-2026-10-14.json','utf8')));
const report=buildCoverageReport(input,'2026-10-14');const brand=report.brandProgress.find(b=>b.brand==='Polestar')!;
fs.writeFileSync(R+'staged-report.json',JSON.stringify(report,null,2));fs.writeFileSync(R+'after.json',JSON.stringify(selected,null,2));fs.writeFileSync(R+'features-after.json',JSON.stringify(Object.values(packs).flatMap(v=>v.features),null,2));fs.writeFileSync(R+'staged-packs.json',JSON.stringify(packs,null,2));
assert.equal(brand.missingSummaries,0);assert.equal(brand.agedOrInvalidClaims,0);
assert(brand.core.every(row=>row.grades.Unreviewed===0),'No unreviewed core cells');
console.log(JSON.stringify({staged:true,registered:false,versions:selected.length,newVersions:p.variants.length,citableFacts:factCount,features:featureCount,portableExactRoundtrip:true,actualPackPipelineMatches:true,immutableInputs:true,otherBrandsUnchanged:true,brand},null,2));
