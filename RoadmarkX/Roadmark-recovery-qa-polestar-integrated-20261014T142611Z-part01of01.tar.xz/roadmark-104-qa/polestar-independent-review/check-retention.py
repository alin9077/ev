import pathlib,json,hashlib,re
R=pathlib.Path('/tmp/polestar-research');Q=pathlib.Path(__file__).parent
m=json.loads((R/'retention-manifest.json').read_text());rows=m['rows'];assert len(rows)==m['allFilesInventoried']==179
assert len({r['path'] for r in rows})==len(rows)
allow=(R/'retained-files.txt').read_text().splitlines();retain=[r['path']for r in rows if r['action']=='retain-reviewed'];excluded=[r['path']for r in rows if r['action']!='retain-reviewed'];assert len(retain)==170 and len(excluded)==9
assert sorted(allow)==sorted(retain+m['metadataFiles']);assert not(set(allow)&set(excluded));assert all(not pathlib.PurePosixPath(p).is_absolute() and '..' not in pathlib.PurePosixPath(p).parts for p in allow)
assert sorted(p.relative_to(R).as_posix()for p in R.rglob('*')if p.is_file())==sorted([r['path']for r in rows]+m['metadataFiles'])
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(262144),b''):h.update(b)
 return h.hexdigest()
for r in rows:
 p=R/r['path'];assert p.stat().st_size==r['bytes'],r['path'];assert sha(p)==r['sha256'],r['path']
patterns={
 'credential_assignment':r'''(?i)(?:["']?(?:csrf[-_]?token|form_token|sessionid|session_token|access_token|refresh_token|api_key|client_secret)["']?)\s*[:=]\s*["'][A-Za-z0-9_\-/+=.]{12,}["']''',
 'authorization_header':r'(?im)^\s*(?:authorization|proxy-authorization)\s*:\s*(?:bearer|basic)\s+\S+',
 'cookie_header':r'(?im)^\s*(?:set-cookie|cookie)\s*:\s*\S+',
 'jwt':r'\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{12,}\b',
 'signed_capability':r'(?i)(?:X-Amz-Signature|X-Goog-Signature|sig|sharedaccesssignature)=[A-Za-z0-9%/+_-]{20,}',
 'debugger_capability':r'(?i)(?:ws|wss)://[^\s"<>]+/(?:devtools|session)/[^\s"<>]+'
}
findings=[];markup=[];metadataHashes={}
for name in allow:
 p=R/name;text=p.read_text(errors='replace')
 for kind,pat in patterns.items():
  hits=list(re.finditer(pat,text))
  if hits:findings.append({'path':name,'kind':kind,'count':len(hits),'offsets':[h.start()for h in hits[:8]]})
 if p.suffix=='.html':
  for kind,pat in {'active_script':r'(?i)<script(?=[\s/>])','iframe':r'(?i)<iframe(?=[\s/>])','hidden_input':r'''(?i)<input[^>]+type=["']hidden'''}.items():
   if re.search(pat,text):markup.append({'path':name,'kind':kind})
 if name in m['metadataFiles']:metadataHashes[name]=sha(p)
assert not findings,findings;assert not markup,markup
for s in json.loads((R/'polestar-2026-10-14.json').read_text())['sources']:
 for key in ['capture_locator','capture_text_locator']:
  if s.get(key):assert s[key] in allow,s[key]
assert not any(pathlib.Path(p).suffix.lower() in ['.png','.jpg','.jpeg','.webp','.har']for p in allow),'Unexpected image or browser archive needs manual review'
assert all(p in excluded for p in ['config-inspect.json','config-data-TEMP.json','polestar2-specs.html'])
r={'status':'passed','filesInventoried':179,'retainedFiles':170,'retainedMetadataFiles':3,'excludedFiles':excluded,'retainedSensitiveFindings':findings,'retainedHtmlActiveContent':markup,'sourceCapturesAllAllowlisted':True,'browserScreenshotsOrArchivesRetained':False,'allInventoryHashesVerified':True,'allowlistMetadataHashes':metadataHashes,'method':'Independent full-root inventory and hash comparison, all-extension value-aware credential/cookie/session/JWT/signed-capability scan, retained HTML active-content scan; excluded originals were hashed but not persisted. Exact170-file plus3-metadata allowlist only; no root-directory copy.'}
(Q/'privacy-and-retention-review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
