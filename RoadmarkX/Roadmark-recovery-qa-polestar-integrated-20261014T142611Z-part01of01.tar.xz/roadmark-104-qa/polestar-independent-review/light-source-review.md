# Independent Polestar source review — 14 October 2026

This is a preliminary source review, not final packet approval. No catalogue hydration or tests have been run for this review yet.

## Price mapping

- MY27 Polestar 2: independent April reporting gives A$66,400 Long range Single motor, A$71,400 Long range Dual motor and A$85,080 Long range Dual motor with Performance pack, all before on-road costs. A$80,400 should not silently stand in for the packaged Performance row. https://www.goauto.com.au/new-models/polestar/2/entry-variant-axed-from-polestar-2-line-up/2026-04-16/99003.html and https://www.carsguide.com.au/car-news/2027-polestar-2-price-and-specs-locked-in-as-key-2026-tesla-model-3-and-mazda-6e-rival
- MY27 Polestar 4: September coverage aligns coupé and SUV at A$73,900 Rear motor and A$81,750 Dual motor. The Performance configuration is A$95,450, including the prerequisite A$6,500 Plus pack and A$7,200 Performance pack. https://thedriven.io/2026/09/10/polestar-australia-confirms-it-has-cut-prices-for-2027-polestar-4-coupe-to-match-new-electric-suv/ and https://drivingenthusiast.com.au/2026/09/my2027-polestar-4-coupe-suv-prices-aligned-starts-from-73900/
- MY27 Polestar 3: current CarsGuide/Glass's named entries show Rear Motor Plus A$121,250, Dual Motor Plus A$135,650 and Dual Motor Performance A$151,250 before government charges/options. Earlier launch prose gives A$116,700/A$131,100/A$146,700. Chasing Cars still prints the earlier prices in its article and A$151,250 in the tested-car data panel. No rationale for the A$4,550 difference has been established. These are Reported unless direct maker pricing is recovered; do not invent a tax/delivery explanation. https://www.carsguide.com.au/polestar/3/price/2027 and https://www.chasingcars.com.au/reviews/large-suvs/polestar-3-800v-2026-review/

## Current primary-source distinctions

- Polestar 2: three named powertrains, all 82 kWh with up-to-205 kW DC and 28-minute 10–80%. Height differs: ordinary 1,479 mm, Performance 1,473 mm. Pilot and Plus are described as packs; Australian inclusion must come from actual configuration evidence. Heat pump is Climate pack. https://www.polestar.com/au/polestar-2/specifications/
- Polestar 3: current range targets are 603/647/601 km, not earlier launch 604/635/593. Rear motor has 92 kWh and 310 kW DC; Dual/Performance 106 kWh and 350 kW. All have 22-minute 10–80% at high-voltage charging. Explicit 400V fallback is 120 kW, 30 minutes Rear or 32 Dual/Performance. Body heights are 1,622 mm on ordinary suspension and 1,614 mm with air suspension. Rear towing 1,500 kg; Dual/Performance 2,200 kg. https://www.polestar.com/au/polestar-3/specifications/
- Polestar 4 coupé: current source says 620/590 km range targets, 100 kWh, 200 kW DC, 30-minute 10–80%, 11 kW AC standard and 22 kW optional. Performance pack changes dampers/wheels/brakes, not an independently published increased motor output. https://www.polestar.com/au/polestar-4-models/polestar-4-coupe/specifications/
- Polestar 4 SUV and coupé must stay separate body identities; digital inner rear-view mirror is an SUV option requiring Pilot and Plus, whereas the coupé's rear view is camera-based. Neither announced future V2L nor future park-assist software should become currently standard equipment. https://www.polestar.com/au/polestar-4-models/polestar-4-suv/specifications/

## Warranty and source conflicts

- Maker brand FAQ confirms five-year vehicle warranty and eight-year/160,000 km battery cover with a 70% threshold. Its generic text should take precedence over the P2 specifications page's visibly stale MY25+MY26 battery-warranty heading for the MY27 records. https://www.polestar.com/au/support/faq/warranty/
- P2 overview roadside accordion has a five-year heading but three-year body. Current specifications for each model and the Australia-specific assistance manual state five years. Retain the discrepancy in the research record while using the more specific current terms. https://www.polestar.com/au/polestar-2/ and https://www.polestar.com/au/manual/polestar-2/2024/article/c6578af0cf998f71c0a80151751eddd5/
- No manufacturer unlimited-kilometre vehicle-warranty clause has been found in these checked pages. It is widely reported independently, but five years alone is what the primary pages explicitly support. Do not append an unverified mileage qualifier to Confirmed terms.

## Boundaries

Only current maker Australian material can earn Confirmed. Secondary sources and foreign maker material remain Reported, with origin retained. Generic model/dealer listings and expired offers do not close a residual-new census. Brand navigation cannot close whole-market C1. The original before fixtures and source hashes must remain unchanged for final replay.

## Later light-review refinements

- Public AU configuration rules settle Pilot inclusion and cable fitment more precisely than generic specification pack tables. P2 explicitly says Pilot is included for Australia. P3 Plus is mandatory. P3 home-cable code 001226 and P4 home-cable code A01537 are mandatory configuration items, distinct from the separately optional public/home-wallbox cable. The earlier warning about a blanket included charging cable should be read with that distinction.
- P4 Plus summary text mentions 22 kW, but both actual configuration rules only require Plus when selecting separate option 221011. They do not include 221011 when Plus is selected. This agrees with the current specification table.
- The fresh P4 SUV specification now explicitly lists 3.3 kW V2L using an extra adapter and Camping mode, without the older launch article's future-introduction qualifier. Current SUV facts should follow this newer specific evidence. Coupé remains separate; its specification does not list V2L/Camping. The earlier broad caution about future features must not manufacture a permanent caveat for the SUV.
- Bounded seat-count search did not find a direct current AU maker count for P3/P4. Exact MY27 P4 SUV Rear motor Plus Redbook entry publishes five positions; matching-body carried grades must remain Reported. https://www.redbook.com.au/cars/details/2026-polestar-4-rear-motor-plus-auto-my27/SPOT-ITM-699672?Cr=15
- Draft inspection caught P4 Performance range values 500/520 while the draft rationale said carried Dual motor target; acceleration was null but the equipment string printed `None seconds`. These are provisional drafting issues sent to the owner before canonical baseline; final resolution remains to verify.
- Follow-up on the provisional Performance range flag: current public configuration data directly maps `XPFWHE:options` to 500 km for coupé and 520 km for SUV; the matching item title is `22" Performance`. These values have exact configuration evidence and should be retained with that wheel-specific condition. The defect was the draft rationale claiming no separate pack figure and a carried Dual-motor target, rather than the numeric values themselves.
