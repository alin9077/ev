# Polestar M1 independent review — 14 October 2026

Approved for registration at the exact hashes in `approval.json`, pending root's full registered coverage comparison. No production guard change was needed.

- Reviewed 14 exact Australian versions: 9 on-sale MY27 versions, 3 arriving MY27 Polestar 4 SUVs and 2 provisional MY26 Polestar 5 Launch editions. No accepted-order or physical-stock claim is made.
- All 238 core cells reviewed: 195 Confirmed, 26 Reported, 17 Check. No invented unpublished gaps or target-grade quota. Current on-sale coverage is 153/153 core cells. C2/C3/C4/C6 pass; C1/C5 and research closure remain open.
- Independent replay passed first attempt: 858 citable facts, 374 feature edits, 468 feature dependencies, 59 summary dependencies and 267 independently authored source assertions. Actual pack, citations and portable round-trip agree exactly with the complete staged packs.
- Original full 395-car catalogue and research snapshot, original Polestar vehicles/features, historical sources, 459 source/code/input hashes and other brands remain unchanged. Two provisional additions yield 397 total cars. Model Y page, component and scene hashes are included in the preserved code manifest.
- Authorized provenance-only amendment changes 14 base-price metadata entries, with amounts, grades, source scope and ranking unchanged. Original canonical and amended canonical were separately replayed; the complete 138-row new-version fixture remains byte-identical. Original packet/fixture/meta remain retained and v2 is explicit.
- Every base price is Reported and unranked. All 14 opposite-basis mutations reject. Ambiguous or blank basis is never inferred. The WA option-equipped Polestar 2 offer remains separate from the list price.
- 14 packet mutations, 98 ranking-withdrawal tests, 56 secondary-source promotions and 28 synthetic overseas-maker promotions reject. Foreign source type and origin cannot be promoted by setting market to AU.
- Primary current technical conditions are preserved: target WLTP ranges, exact charging windows, P3 400 V limitations, P4 Performance-wheel range, separate optional 22 kW AC/Plus dependency, P5 4+1 seating and conflicting heights. Equipment inclusion follows Australian configurator rules. No standing caveat substitutes for a specific condition.
- Full-root independent privacy review verifies all 179 inventory hashes and the exact 170-file plus 3-metadata backup allowlist. Nine exploratory files remain local-only. No retained credential/session/cookie/signed-runtime capability findings, active HTML scripts, screenshots or browser archives were found. All 53 source capture references are allowlisted.

The successful independent run used Node 704 MiB old space, one MiB semispace, explicit GC and shared hashing buffer: exit 0, 51.5 seconds, peak 789,136 KiB. There were no independent replay failures. Owner failures and versioned correction receipts remain preserved; no SIGKILL cause is inferred.

Whole-market model-list reconciliation and nationwide older-year residual-new census are not closed. Brand model directories, generic new-to-order templates, sold/demo adverts and empty JavaScript inventory shells do not prove absence or completeness.

## Registered closure

The fresh full registered report with explicit `--as-of 2026-10-14` exactly equals the entire approved staged JSON, with no ignored or rewritten fields. All 171 integration tests, structural validation, TypeScript and lint pass. The first integration file-level SIGKILL receipt and the successful 15 October default-date report remain unchanged; the latter differed only in 11 date fields and was followed by a fresh dated run, not normalized. All 459 original source/code/input hashes remain unchanged except the independently verified authorized registry and report-loader additions. See `registered-coverage-parity.json`. Polestar research and review artifacts are now frozen for allowlist-only backup.
