# Polestar M1 source review, 14 October 2026

## Scope and result

Four exact MY27 model/body cohorts contain 12 versions: Polestar 2, Polestar 3, Polestar 4 coupé and Polestar 4 SUV, each with three reviewed configurations. Two exact MY26 Polestar 5 Launch editions are added provisionally. P4 SUV is order-open/arriving; P5's model-market built-to-order option is disabled and its orderability remains unconfirmed. Default configuration delivery estimates are not promises or evidence of physical stock.

All 238 core cells across 14 versions are source-reviewed:195 Confirmed,26 Reported,17 Check. All 14 have a sourced price, equipment answers and a supported strength/trade-off pair. The packet is staged unregistered for independent review; registry/report loader are unchanged by the research worker.

Prices before on-road costs are Reported: P2 AUD 66,400/71,400/85,080; P3 AUD 121,250/135,650/151,250; both P4 bodies AUD 73,900/81,750/95,450; P5 AUD 171,100/193,100. Exact current AU secondary figures are admitted after official numeric quote retrieval failed. P4 Performance price includes required Plus and Performance packs. P3 current guide values differ from older launch/Atlas values; no reason or tax calculation is invented. P2's WA Plus/paint driveaway example and P3's conditional upgrade contribution remain separate offers, not bare prices or deductions.

P5's June Australian secondary review labels its price table 2027, while current official AU public configuration explicitly says MY26. The maker identity controls model year; secondary figures remain Reported and map by exact Launch-edition engine/trim, with October Atlas corroboration. A 2027 delivery estimate never becomes model year. P5 body width 1979 mm is separately established by the AU manual; 2063 mm is mirrors extended. Its specification/configurator height conflict remains visible.

P2 range is WLTP; P3/P4/P5 maker range targets remain Check with target comparison basis. P4 Performance range 500/520 is exact XPFWHE 22-inch wheel configuration, not the ordinary Dual motor 590/600 target. P4 Performance acceleration remains explicitly the motor-level claim without a separate pack-specific test. P3's 800 V 22-minute 10–80% result and 400 V 120 kW 30/32-minute fallback remain separate. Charging stations, vehicle peak acceptance and onboard AC are not conflated. Standard P4 AC is 11 kW; 22 kW is an extra requiring Plus, not automatically included by Plus. Cargo loading boundaries and unknown VDA/SAE method are preserved without sums.

The current AU warranty FAQ provides five-year vehicle cover and eight years/160,000 km battery cover with 70% state-of-health threshold. No unpublished unlimited vehicle-kilometre clause is invented. Current model pages support five-year roadside despite conflicting older page tiles. P5 Apple phone key/CarPlay remain future introduction. P4 SUV rear window, V2L and Camping mode do not transfer to the coupé.

## Census boundary

The MY27 current-source list is complete only for its named cohorts. Nationwide residual-new MY23–26 Polestar 2, earlier Polestar 3 and MY25/26 Polestar 4 supply remains unresolved. Current MY26 offer eligibility is not an exact NEW unit. Empty JavaScript inventory shells and sold/demo advertisements do not prove absence. Broad inventory records stay unresolved. No two independent whole-market lists are claimed; C1 and overall research closure remain open.

## Replay and canonical transition

Initial full live research/catalogue capture contains 395 cars and 12 existing Polestars. Complete original before rows, all source rows and streamed replay snapshot are retained. Subsequent runs are explicitly snapshot-backed and verify 459 source/code hashes plus 21 snapshot hashes. Input mtimes were checked when the after-capture manifest was made; hash equality is used on replay. No historical evidence packet is rewritten.

The original new-version fixture was generated once:138 complete P5 feature rows, original canonical hash 0b1eb2690af2a9f1cd796b44fe9a977c5b2b55acedc698acafa1f4ba9e2591fa. Reviewer then identified that generic publisher-only price provenance would not guard a contradictory comparison-basis mutation. Root explicitly approved a transparent provenance-only amendment. Original packet, fixture, meta and hashes remain untouched. A 14-entry path-level manifest proves only priceEvidence basis labels changed; amounts, grades, sources, scope and ranking eligibility did not. Amended canonical hash 5fc7ddece637b5e8153bc3c125810f680b1dd35b705528429096d0aace88d483. Both complete feature derivations compare equal, with zero field differences and byte-identical 138-row fixtures. The versioned amended fixture is separate, never an overwrite.

Failed runs are preserved, including the initial SIGKILL with measured 402,136 KiB child RSS (cause not established), invalid preorder token validation, and a proof harness's in-memory undefined-versus-persisted-JSON comparison. The proof was corrected to compare the complete persisted JSON representation, with no substantive fields filtered. The valid original fixture run peaked 661,112 KiB; amended proof peaked 674,972 KiB. Full self-stage passed at704 MiB heap/1 MiB semispace: exit0,180.9 seconds,786,156 KiB peak RSS. C2/C3/C4/C6 pass; C1 and C5 remain open. Actual pack/citable/portable equality, complete baseline equality, unchanged input objects and unchanged other-brand cars passed. Independent review remains the integration gate.

## Privacy and recovery

Use retention-manifest.json and retained-files.txt, never a blanket copy of this scratch directory. Every file, including root-level and hidden/extensionless paths, is inventoried and all retained content scanned. Raw exploratory runtime files and raw Chromium logs are local-only exclusions with hashes; originals remain locally intact. Safe public-only configuration extracts preserve original-response hashes and transformation descriptions. Sanitized HTML/text captures exclude scripts, runtime/session capabilities, cookies, hidden forms and CSRF. No browser screenshots, login, checkout, dealer enquiry, CAPTCHA or user-computer activity was part of this research.
