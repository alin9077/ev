# Deferred work

- M4: Profile repeated catalogue/brand-packet replay and large evidence payloads on the expanded catalogue before claiming mobile performance; the through-Kia full suite took 16 minutes, which is a test-runtime measure rather than a mobile benchmark.
