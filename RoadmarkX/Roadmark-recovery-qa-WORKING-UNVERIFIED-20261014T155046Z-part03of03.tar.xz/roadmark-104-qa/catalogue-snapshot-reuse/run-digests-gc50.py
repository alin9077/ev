import os,subprocess,sys,time,json,pathlib,hashlib,datetime
root=pathlib.Path.cwd();qa=root.parent/'roadmark-104-qa/catalogue-snapshot-reuse'
mode=sys.argv[1];out=pathlib.Path(sys.argv[2]).resolve();asof='2026-10-15'
if mode not in ('cars','research'):raise ValueError('Choose cars or research')
out.mkdir(parents=True,exist_ok=False)
harness=['capture-digests-gc50.mjs','run-digests-gc50.py','hash-inputs.py']
def harness_manifest():
 return [{'file':name,'sha256':hashlib.sha256((qa/name).read_bytes()).hexdigest()} for name in harness]
def manifest(name):
 subprocess.run([sys.executable,str(qa/'hash-inputs.py'),str(out/name)],check=True)
 return json.loads((out/name).read_text())
before=manifest('inputs-before.json');before_harness=harness_manifest()
(out/'harness-before.json').write_text(json.dumps(before_harness,indent=2)+'\n')
command=['node','--max-old-space-size=448','--max-semi-space-size=1','--expose-gc','--import','tsx',str(qa/'capture-digests-gc50.mjs'),mode,str(out),asof]
started=time.time();start_iso=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/'stdout.log').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
 process=subprocess.Popen(command,stdout=stdout,stderr=stderr)
 pid,status,usage=os.wait4(process.pid,0)
 code=os.waitstatus_to_exitcode(status);process.returncode=code
after=manifest('inputs-after.json');after_harness=harness_manifest()
(out/'harness-after.json').write_text(json.dumps(after_harness,indent=2)+'\n')
inputs_equal=before['files']==after['files'];harness_equal=before_harness==after_harness
index_file=out/'index.json';index=json.loads(index_file.read_text()) if index_file.exists() else None
outputs_valid=False
if index is not None:
 rows=[index['cars']] if mode=='cars' else list(index['research'].values())
 outputs_valid=True
 for row in rows:
  digest=hashlib.sha256();length=0;count=0;serialized_bytes=0
  with (out/row['digestFile']).open('rb') as source:
   for line in source:
    digest.update(line);length+=len(line);record=json.loads(line)
    if record['index']!=count or len(record['sha256'])!=64 or any(c not in '0123456789abcdef' for c in record['sha256']) or not isinstance(record['serializedBytes'],int) or record['serializedBytes']<1:outputs_valid=False
    serialized_bytes+=record['serializedBytes'];count+=1
  outputs_valid=outputs_valid and digest.hexdigest()==row['digestFileSha256'] and length==row['digestFileBytes'] and count==row['rows'] and serialized_bytes==row['serializedBytes']
result={'status':'passed' if code==0 and inputs_equal and harness_equal and index and outputs_valid else 'failed','mode':mode,'asOf':asof,'command':command,'startedAt':start_iso,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'returncode':code,'signal':-code if code<0 else None,'elapsedSeconds':time.time()-started,'ru_maxrss_kib':usage.ru_maxrss,'ru_utime':usage.ru_utime,'ru_stime':usage.ru_stime,'completeInputHashesUnchanged':inputs_equal,'harnessHashesUnchanged':harness_equal,'terminalIndexPresent':index is not None,'allDigestRecordsComplete':outputs_valid,'fullValueEqualityPending':True,'captureKind':'Fresh full-standard-JSON row digests; not a full-value export','postImportGc':True,'postLoadGc':True,'periodicRowGc':True,'indexFile':'index.json' if index else None}
(out/'terminal.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
sys.exit(0 if result['status']=='passed' else 1)
