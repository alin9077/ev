import os,json,time,pathlib,subprocess
q=pathlib.Path(__file__).resolve().parent
cmd=['node','--expose-gc','--import','tsx','-e','(async()=>{await import("./src/lib/data.ts");global.gc();await import("./scripts/validate.ts");})().catch(e=>{console.error(e);process.exitCode=1})']
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=448 --max-semi-space-size=1');start=time.monotonic()
with (q/'root-validation.stdout').open('w') as o,(q/'root-validation.stderr').open('w') as e:
 p=subprocess.Popen(cmd,cwd='/workspace/scratch/586427eef9f2/roadmark-104',env=env,stdout=o,stderr=e);pid,status,r=os.wait4(p.pid,0);rc=os.waitstatus_to_exitcode(status);p.returncode=rc
m={'command':cmd,'nodeOptions':env['NODE_OPTIONS'],'exitCode':rc,'signal':-rc if rc<0 else None,'wallSeconds':time.monotonic()-start,'userSeconds':r.ru_utime,'systemSeconds':r.ru_stime,'maxRssKiB':r.ru_maxrss}
(q/'root-validation.metrics.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m),flush=True)
