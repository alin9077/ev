import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
const root=process.cwd();
const qa=path.resolve('../roadmark-104-qa/catalogue-snapshot-reuse');
const mode=process.argv[2];
const out=path.join(qa,process.env.CAPTURE_LABEL||mode);fs.mkdirSync(out,{recursive:true});
const started=Date.now();
const baseFile=path.join(root,'data/au_ev_all_variants_2026-10-06.json');
const read=fs.readFileSync;let reads=0;
fs.readFileSync=function(file,...args){if(String(file)===baseFile)reads++;return read.call(fs,file,...args)};
process.on('exit',exitCode=>fs.writeFileSync(path.join(out,'usage.json'),JSON.stringify({mode,exitCode,elapsedMs:Date.now()-started,baseReads:reads,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()},null,2)+'\n'));
const require=createRequire(path.join(root,'src/lib/data.ts'));
let api;
if(mode==='after')api=require('./data.ts');
else {const module={exports:{}};const body=read(path.join(qa,'before-data.cjs'),'utf8');vm.runInThisContext('(function(require,module,exports){'+body+'\n})',{filename:path.join(root,'src/lib/data.ts')})(require,module,module.exports);api=module.exports;}
console.log('Imported',mode,process.memoryUsage());
if(process.argv.includes('--gc-imports')){global.gc?.();console.log('Collected imports',process.memoryUsage());}
const index={mode,research:{},cars:null};
function rows(name,values){const fd=fs.openSync(path.join(out,name),'w');const hash=crypto.createHash('sha256');try{for(let i=0;i<values.length;i++){const text=JSON.stringify(values[i])+'\n';fs.writeSync(fd,text);hash.update(text);if(i%50===0)global.gc?.();}}finally{fs.closeSync(fd)}return{file:name,rows:values.length,sha256:hash.digest('hex')}}
function data(d){for(const[k,v]of Object.entries(d)){const isArray=Array.isArray(v);index.research[k]={...rows('research-'+k+'.jsonl',isArray?v:[v]),array:isArray};console.log('Research',k,index.research[k].rows)} }
if(mode==='after'){const snapshot=api.catalogueSnapshot();console.log('Fresh snapshot loaded',snapshot.cars.length,process.memoryUsage());index.cars=rows('cars.jsonl',snapshot.cars);data(snapshot.data);fs.writeFileSync(path.join(out,'counts.json'),JSON.stringify(api.counts(snapshot),null,2)+'\n');}
else if(mode==='before-cars'){const cars=api.catalogue();console.log('Original catalogue loaded',cars.length,process.memoryUsage());index.cars=rows('cars.jsonl',cars);}
else if(mode==='before-source'){const cars=api.sourceCatalogue();console.log('Original source catalogue loaded',cars.length,process.memoryUsage());index.cars=rows('cars.jsonl',cars);}
else if(mode==='before-research')data(api.research());
else throw Error('Unknown mode');
fs.writeFileSync(path.join(out,'index.json'),JSON.stringify(index,null,2)+'\n');console.log('COMPLETE',mode,'reads',reads,'elapsedMs',Date.now()-started,process.memoryUsage());
