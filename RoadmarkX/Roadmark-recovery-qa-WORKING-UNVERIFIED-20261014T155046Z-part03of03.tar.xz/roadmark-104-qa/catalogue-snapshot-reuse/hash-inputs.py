import pathlib,hashlib,json,sys,datetime
root=pathlib.Path.cwd();files=[]
for dirname in ['src','scripts','tests','data','media','public']:
 for p in sorted((root/dirname).rglob('*')):
  if p.is_file() and p.relative_to(root).as_posix() not in ['public/index.html','public/index-b.html']:files.append(p)
for p in sorted(root.iterdir()):
 if p.is_file() and (p.suffix in ['.ts','.js','.mjs','.json','.yaml','.yml'] or p.name=='pnpm-lock.yaml') and p.name not in ['SOURCE-FILE-MANIFEST.json']:files.append(p)
started=datetime.datetime.now(datetime.timezone.utc).isoformat();rows=[]
for p in sorted(set(files)):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 rows.append({'file':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':h.hexdigest()})
result={'scope':'All files beneath src,scripts,tests,data,media,public except generated public index files, plus root code/json/yaml; excludes node_modules and generated build state','startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':rows}
pathlib.Path(sys.argv[1]).write_text(json.dumps(result,indent=2)+'\n');print(len(rows),'inputs hashed')
