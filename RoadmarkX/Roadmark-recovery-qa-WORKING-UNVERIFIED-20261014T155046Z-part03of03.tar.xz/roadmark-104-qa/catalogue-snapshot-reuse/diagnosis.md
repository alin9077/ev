# Read-only findings and narrow loader patch

## Proven call graph before the patch

Outside a React server request, React.cache does not memoize these calls.

- sourceResearch(): reads and parses the2,038,348-byte original JSON, extends arrays with module-loaded additions/overlays, audits source rows, builds generated unknown-feature rows, validates the refresh registry
- research(): sourceResearch() then prepareBrandResearch()
- sourceCatalogue(): sourceResearch() then full source facts, corrections, availability, effective source features and buyer-summary guards
- catalogue(): sourceResearch().sources; sourceCatalogue(); retained facts; price ladder; regrading; research(); applyBrandUpdates(). This is three original source reads and three graph constructions, not three parses of the74.9MB additions file
- research()+catalogue() consumers create four source graphs. counts() repeats the same pair. scripts/validate.ts therefore made eight original source reads and built two effective catalogues while retaining its first explicit snapshot
- reporting/load.ts made four source reads and one full catalogue, then materialized every effective feature row
- pack() and pairReport() already accept explicit snapshots; their source/fact/feature drift checks remain active. Those boundaries were not expanded

The first catalogue sourceResearch call retains its sources array, not necessarily its entire Research object. Other temporary graphs become eligible for garbage collection at different stages. No claim is made that all three full graphs necessarily remain live simultaneously.

## Allocations that remain

Module-loaded JSON inputs: catalogue additions74,934,307bytes; buyer identity ledger54,962,382; buyer proposal24,074,749; evidence regrading15,226,769; all brand packet/registry JSON47,011,345. These alone total216,209,552 bytes of serialized input. Module imports measured about470MB RSS/374MB heap in the704MiB run; explicit harness-only post-import collection in the448MiB run left262MB heap used. Serialized size is not a heap-size estimate.

The identity resolver reuses expected ledger object references; it does not deep-copy the whole55MB ledger per research call. Most additions are also shared module inputs. Source catalogue corrections deep-clone each car's facts. Buyer summaries simultaneously materialize full effective source features and maps. Regrading and packet application create replacement car/fact wrappers, with unchanged nested evidence often shared. prepareBrandResearch copies arrays and structured-clones each historical configuration context. orderedPackets calls assertReviewedJson for every packet; canonical() builds and discards a full recursively sorted copy. Updated-feature pack reads repeat that packet validation. These remain untouched; no guard was removed or memoized.

## Patch scope

Only three production files changed: src/lib/data.ts, scripts/validate.ts, scripts/reporting/load.ts. One behavioral test file was added. Original raw source, every dated source/packet file, hero and UI are unchanged. sourceCatalogue's extracted private body is byte-identical.

Public sourceResearch/research/sourceCatalogue/catalogue remain zero-argument. catalogueSnapshot returns a caller-scoped complete data/cars pair built from one fresh source read and all existing validations. No caller-supplied Research can enter this builder. counts and report assembly can consume an explicit snapshot, matching existing pack-style caller ownership. Default counts/report loads remain fresh. Request-scoped React cache wrappers remain; no persistent/global derived cache or production GC was added.

## Verified and pending

23 focused actual-source fixture tests pass, no skips. They prove one-read full stage ordering; fresh changes between calls; source/effective boundaries; full source object equality after shared source builder; real packet source guards at preparation and application; fail-closed propagation through15 stages; count/report reuse; validation's malformed-issue rejection before pack calls. Focused eslint passed before the final two validation tests were added; final lint/typecheck and real-data suites remain to be run when the heavy slot is available.

All original/data file hashes match their pre-edit manifests. Independent static review is clean, but complete current-data equality is not yet approved.

Attempt704MiB old-space/1MiB semi-space: signal9 after4.079s, peak572,576KiB, before completed snapshot.

Attempt448MiB old-space/1MiB semi-space with explicit post-import GC: successful397-car snapshot construction at507MB RSS/412MB heap, then signal9 after108.488s, peak558,572KiB during final Research-field export. cars.jsonl is397 complete rows/65,021,562bytes;13 Research fields completed; feature_evidence_variant_context has321/397 complete rows. No terminal index or successful whole-export receipt. This is not a completed full-data pass.

The final field is an array already streamed one row at a time. The next context row was approximately145KB; prior car rows up to2.36MB were already serialized. A giant whole-field JSON.stringify is therefore not the observed structure. Kill cause remains unproven. Do not call either signal9 an established OOM.

Next work needs root/reviewer slot coordination: independent complete-car provenance comparison, fresh complete-research comparison, and unchanged validation/report entry points through an explicitly recorded import-data→post-import-GC→entry-point wrapper if authorized. Avoid arbitrary further heap retries. Any reconstructed proof must label its provenance and cannot be presented as a successful original fresh top-level run.
