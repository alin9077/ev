import assert from 'node:assert/strict';
/** Encoding only: callers still use the unchanged standard JSON serializer. */
export class StandardRowUtf8Buffer {
  #buffer=Buffer.alloc(0);
  get capacity(){return this.#buffer.length}
  encode(text){
    const required=Buffer.byteLength(text,'utf8');
    if(this.#buffer.length<required)this.#buffer=Buffer.allocUnsafe(required);
    const written=this.#buffer.write(text,0,required,'utf8');
    assert.equal(written,required,'The complete standard JSON row must be encoded');
    return this.#buffer.subarray(0,written);
  }
}
