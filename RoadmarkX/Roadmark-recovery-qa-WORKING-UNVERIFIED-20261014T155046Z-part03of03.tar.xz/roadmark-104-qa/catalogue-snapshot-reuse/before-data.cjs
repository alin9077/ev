"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.catalogue = exports.sourceCatalogue = exports.research = exports.sourceResearch = void 0;
exports.readableValue = readableValue;
exports.sourceEffectiveFeatures = sourceEffectiveFeatures;
exports.effectiveFeatures = effectiveFeatures;
exports.pack = pack;
exports.counts = counts;
exports.pickerCatalogue = pickerCatalogue;
const brand_updates_1 = require("./brand-updates");
const brand_update_registry_1 = require("./brand-update-registry");
const retained_fact_fills_1 = require("./retained-fact-fills");
const price_ladder_1 = require("./price-ladder");
const evidence_regrading_1 = require("./evidence-regrading");
const configuration_evidence_1 = require("./configuration-evidence");
const evidence_date_1 = require("./evidence-date");
const research_refresh_2026_10_10_json_1 = __importDefault(require("../../data/research-refresh-2026-10-10.json"));
const research_refresh_1 = require("./research-refresh");
const approved_availability_corrections_json_1 = __importDefault(require("../../data/approved-availability-corrections.json"));
const availability_corrections_1 = require("./availability-corrections");
const node_fs_1 = __importDefault(require("node:fs"));
const approved_feature_corrections_json_1 = __importDefault(require("../../data/approved-feature-corrections.json"));
const feature_corrections_1 = require("./feature-corrections");
const catalogue_additions_1 = require("./catalogue-additions");
const buyer_proposal_1 = require("./buyer-proposal");
const selling_points_1 = require("./selling-points");
const approved_corrections_json_1 = __importDefault(require("../../data/approved-corrections.json"));
const corrections_1 = require("./corrections");
const node_path_1 = __importDefault(require("node:path"));
const react_1 = require("react");
const config_1 = require("./config");
const research_refinement_2026_10_06_json_1 = __importDefault(require("../../data/research-refinement-2026-10-06.json"));
const research_usability_2026_10_06_json_1 = __importDefault(require("../../data/research-usability-2026-10-06.json"));
const research_sales_2026_10_06_json_1 = __importDefault(require("../../data/research-sales-2026-10-06.json"));
const research_completion_2026_10_07_json_1 = __importDefault(require("../../data/research-completion-2026-10-07.json"));
const research_editorial_2026_10_07_json_1 = __importDefault(require("../../data/research-editorial-2026-10-07.json"));
const research_buyer_2026_10_07_json_1 = __importDefault(require("../../data/research-buyer-2026-10-07.json"));
const launch_evidence_1 = require("./launch-evidence");
/** Rows added for buyer questions the supplied criteria did not cover. */
const buyerKeys = new Set(research_buyer_2026_10_07_json_1.default.criteria.map((c) => c.key));
const featureKey = (row) => `${row.variant_id}\0${row.criterion}`;
function firstFeatureIndex(rows) {
    const index = new Map();
    for (const row of rows) {
        const key = featureKey(row);
        if (!index.has(key))
            index.set(key, row);
    }
    return index;
}
// Imported overlays are immutable build inputs. Preserve the previous first-match
// behavior and completion > usability > refinement precedence without repeated scans.
const completionFeatures = firstFeatureIndex(research_completion_2026_10_07_json_1.default.features);
const usabilityFeatures = firstFeatureIndex(research_usability_2026_10_06_json_1.default.features);
const refinementFeatures = firstFeatureIndex(research_refinement_2026_10_06_json_1.default.features);
const editorialFeatures = firstFeatureIndex(research_editorial_2026_10_07_json_1.default.features);
/** Immutable imported overlays, grouped without reordering duplicate field patches. */
function factsByVariant(rows, key) {
    const result = new Map();
    for (const row of rows) {
        const id = String(row[key]);
        const group = result.get(id) || [];
        group.push(row);
        result.set(id, group);
    }
    return result;
}
const refinementFactsByVariant = factsByVariant(research_refinement_2026_10_06_json_1.default.facts, "variant_id");
const completionFactsByVariant = factsByVariant(research_completion_2026_10_07_json_1.default.facts, "variant_id");
const editorialFactsByVariant = factsByVariant(research_editorial_2026_10_07_json_1.default.facts, "variant_id");
const buyerFactsByVariant = factsByVariant(research_buyer_2026_10_07_json_1.default.facts, "variant_id");
const additionsFactsByVariant = factsByVariant(catalogue_additions_1.catalogueAdditions.facts, "variantId");
const addedVariantIds = new Set(catalogue_additions_1.catalogueAdditions.variants.map((variant) => variant.id));
exports.sourceResearch = (0, react_1.cache)(() => {
    const d = JSON.parse(node_fs_1.default.readFileSync(node_path_1.default.join(process.cwd(), "data/au_ev_all_variants_2026-10-06.json"), "utf8"));
    d.models.push(...catalogue_additions_1.catalogueAdditions.models);
    d.variants.push(...catalogue_additions_1.catalogueAdditions.variants);
    d.sources.push(...catalogue_additions_1.catalogueAdditions.sources, ...price_ladder_1.priceLadderSources, ...research_refinement_2026_10_06_json_1.default.sources, ...research_usability_2026_10_06_json_1.default.sources, ...research_sales_2026_10_06_json_1.default.sources, ...research_completion_2026_10_07_json_1.default.sources, ...research_editorial_2026_10_07_json_1.default.sources, ...research_buyer_2026_10_07_json_1.default.sources);
    d.sources = d.sources.map(launch_evidence_1.auditedSource);
    // The warranty terms have their own rows, so this row covers servicing only.
    d.criteria = d.criteria.map((c) => c.key === "warranty_service"
        ? {
            ...c,
            label: "Servicing",
            definition: "Service interval and published service pricing.",
        }
        : c);
    // The supplied counts stay as supplied; the added rows are declared beside them.
    d.criteria.push(...research_buyer_2026_10_07_json_1.default.criteria);
    d.feature_evidence.push(...research_buyer_2026_10_07_json_1.default.features);
    // New exact-trim records retain explicit unknowns until their equipment is researched.
    for (const v of catalogue_additions_1.catalogueAdditions.variants) {
        // Explicit dates scope generated unknowns to newly reviewed offers without
        // re-dating any legacy catalogue evidence.
        const unknownDate = v.unknown_evidence_date ?? catalogue_additions_1.catalogueAdditions.checkedAt;
        if (typeof unknownDate !== "string" || !(0, corrections_1.validDate)(unknownDate))
            throw new Error("Invalid variant unknown-evidence date");
        d.trim_equipment.push({
            variant_id: v.id,
            source_ids: [],
            notes: "Exact-trim equipment research pending",
        });
        for (const criterion of d.criteria)
            d.feature_evidence.push({
                variant_id: v.id,
                model_id: v.model_id,
                criterion: criterion.key,
                status: "not_verified",
                value: "Needs confirmation",
                conditions: "This exact-trim equipment claim has not yet been researched.",
                source_ids: [],
                evidence_scope: "AU exact trim; research pending",
                last_evidence_date: unknownDate,
                reviewed_date: unknownDate,
                verification_state: "unverified",
            });
        d.update_eligibility.push({
            variant_id: v.id,
            model_id: v.model_id,
            documented_family_minimum: null,
            exact_total_known: false,
            exact_total: null,
            scope: "No exact-trim software-update history established.",
            meaning: "Research pending",
            source_ids: [],
            observation_window_start: unknownDate,
            observation_window_end: unknownDate,
        });
    }
    const featurePositions = new Map();
    d.feature_evidence.forEach((feature, index) => {
        const key = featureKey(feature);
        if (!featurePositions.has(key))
            featurePositions.set(key, index);
    });
    for (const patch of catalogue_additions_1.catalogueAdditions.features) {
        const index = featurePositions.get(featureKey(patch)) ?? -1;
        if (index < 0 || d.feature_evidence[index].status !== "not_verified")
            throw new Error("Equipment patch must replace an exact unknown cell");
        d.feature_evidence[index] = patch;
    }
    d.metadata = {
        ...d.metadata,
        added_criterion_count: research_buyer_2026_10_07_json_1.default.criteria.length,
        added_variant_count: catalogue_additions_1.catalogueAdditions.variants.length,
        added_feature_row_count: research_buyer_2026_10_07_json_1.default.features.length + catalogue_additions_1.catalogueAdditions.variants.length * d.criteria.length,
    };
    d.publication_issues = d.publication_issues
        .map((issue) => ({
        ...issue,
        ...research_refinement_2026_10_06_json_1.default.issues.find((patch) => patch.issue_id === issue.issue_id),
    }))
        // Instructions addressed to the researchers are not reader content.
        .map((issue) => ({
        ...issue,
        publication_action: issue.publication_action
            .split(/(?<=[.!?])\s+/)
            .filter((sentence) => !/^Do not\b/.test(sentence))
            .join(" ") || issue.publication_action,
    }));
    (0, research_refresh_1.validateRefreshRegistry)(research_refresh_2026_10_10_json_1.default, d.variants.map((v) => v.id), d.sources);
    return d;
});
/** Public identity/source registry includes only separately reviewed M1 brand packets. */
exports.research = (0, react_1.cache)(() => (0, brand_updates_1.prepareBrandResearch)((0, exports.sourceResearch)(), brand_update_registry_1.brandUpdatePackets));
const descriptors = [
    ["price_aud", "Listed price", "AUD", "price_basis"],
    ["range_km", "Claimed range", "km", "range_cycle"],
    ["seats", "Seats", "", ""],
    ["dc_charge_time_min", "DC charging time", "min", "dc_charge_window"],
    ["ac_kw", "AC charging", "kW", ""],
    ["dc_peak_kw", "Peak DC acceptance", "kW", ""],
    ["battery_kwh", "Battery capacity", "kWh", "battery_basis"],
    ["boot_l", "Cargo behind occupied seats", "L", "boot_basis"],
    ["frunk_l", "Front storage", "L", ""],
    ["max_total_cargo_l", "Maximum folded cargo", "L", "boot_basis"],
    ["zero_to_100_s", "0–100 km/h", "s", ""],
    ["length_mm", "Length", "mm", "length_basis"],
    ["width_mm", "Width", "mm", "width_basis"],
    ["height_mm", "Height", "mm", ""],
    ["wheelbase_mm", "Wheelbase", "mm", ""],
    ["towing_braked_kg", "Braked towing", "kg", ""],
    ["warranty", "Vehicle warranty", "", ""],
    ["battery_warranty", "Battery warranty", "", ""],
];
function applies(issueId, key, v) {
    const map = {
        "V2-01": ["safety_ancap"],
        "V2-02": ["zero_to_100_s"],
        "V2-03": ["length_mm"],
        "V2-04": ["v2l"],
        "V2-05": ["software"],
        "V2-06": ["all"],
        "V2-07": ["all"],
        "V2-08": ["safety_ancap"],
        "V2-09": ["price_aud", "range_km"],
        "V2-10": ["price_aud"],
        "V2-11": ["software", "adas_optional", "remote_summon"],
        "V2-12": [],
        "V2-13": ["dc_charge_time_min", "dc_peak_kw"],
        "V2-14": ["battery_kwh", "software"],
        "V2-15": ["subjective"],
    };
    if (issueId === "V2-02" && !v.id.includes("__l_"))
        return false;
    if (issueId === "V2-06" && v.record_state !== "announced_provisional")
        return false;
    if (issueId === "V2-09" && !v.id.includes("black_special"))
        return false;
    // This issue's driving qualification concerns Model Y L activation;
    // its general software-history caveat is not an ADAS limit on other cars.
    if (issueId === "V2-11" &&
        ["adas_optional", "remote_summon"].includes(key) &&
        !v.id.startsWith("tesla_model_y__l_"))
        return false;
    return map[issueId]?.some((x) => x === "all" || x === key);
}
exports.sourceCatalogue = (0, react_1.cache)(() => {
    const d = (0, exports.sourceResearch)();
    (0, corrections_1.validateFactCorrectionRegistry)(approved_corrections_json_1.default, d.variants.map((variant) => variant.id));
    const cars = d.variants.map((v) => {
        const model = d.models.find((m) => m.id === v.model_id);
        const issues = d.publication_issues.filter((i) => i.model_ids.includes(v.model_id) || i.model_ids.includes("all"));
        const facts = {};
        for (const [key, label, unit, basisKey] of descriptors) {
            const raw = v[key];
            const warranty = ["warranty", "battery_warranty"].includes(key) &&
                raw &&
                typeof raw === "object"
                ? raw
                : null;
            const value = warranty?.years
                ? `${warranty.years} years / ${warranty.km_unlimited ? "unlimited km" : warranty.km ? `${warranty.km.toLocaleString("en-AU")} km` : "distance limit unconfirmed"}${warranty.minimum_retained_capacity_percent ? `; minimum ${warranty.minimum_retained_capacity_percent}% battery retention` : ""}`
                : typeof raw === "number" || typeof raw === "string"
                    ? raw
                    : null;
            let basis = String(v[basisKey] || "Manufacturer claim; supplied Australian variant record");
            if (key === "seats")
                basis = "Occupied seating positions";
            if (key === "zero_to_100_s")
                basis =
                    v.brand === "Tesla" && v.trim.includes("Performance")
                        ? "Manufacturer claim; rollout subtracted"
                        : "Manufacturer claim; timing protocol not fully established";
            // Research notes are internal working text; reader-facing notes come from the editorial overlay.
            const qualifications = [];
            const fieldIssues = issues.filter((i) => applies(i.issue_id, key, v));
            let status = value === null ? "not_verified" : "standard";
            if (v.record_state === "announced_provisional" ||
                (v.model_id === "byd_atto_3_evo" && key === "price_aud") ||
                (v.id.includes("black_special") &&
                    ["price_aud", "range_km"].includes(key)) ||
                (v.id.includes("__l_") && key === "zero_to_100_s"))
                status = value === null ? "not_verified" : "conditional";
            let comparisonBasis = basis;
            // Only normalise explicitly like-for-like manufacturer test cycles; charging and pricing remain conservative.
            if (key === "range_km")
                comparisonBasis = v.range_cycle;
            const fieldReview = v.field_review;
            facts[key] = {
                key,
                label,
                value,
                unit,
                basis,
                comparisonBasis,
                status,
                sourceIds: warranty?.source_ids || v.source_ids,
                date: fieldReview?.[key]?.date ||
                    String(v.specification_evidence_date || v.variant_review_date),
                market: "AU",
                scope: String(v.availability_scope ||
                    `${v.brand} ${v.model} ${v.trim} · ${v.model_year}`),
                qualifications,
                issues: fieldIssues,
            };
        }
        for (const patch of refinementFactsByVariant.get(v.id) || []) {
            const f = facts[patch.key];
            if (f)
                Object.assign(f, {
                    value: patch.value,
                    status: patch.status,
                    date: patch.date,
                    sourceIds: patch.sourceIds,
                    issues: f.issues.filter((i) => i.issue_id !== "V2-07"),
                });
        }
        // 7 October completion pass: sourced values for cells the earlier research left open.
        const completed = (completionFactsByVariant.get(v.id) || []);
        for (const patch of completed) {
            const f = facts[patch.key];
            if (!f)
                continue;
            Object.assign(f, {
                value: patch.value,
                status: patch.status,
                date: patch.date,
                sourceIds: patch.sourceIds,
                resolvedElsewhere: patch.status === "conditional",
                unit: patch.unit ?? f.unit,
                basis: patch.basis ?? f.basis,
                comparisonBasis: patch.key === "range_km"
                    ? f.comparisonBasis
                    : (patch.basis ?? f.comparisonBasis),
            });
        }
        // 7 October editorial pass: one label per measurement basis, plus the cells it rewrote.
        const labels = research_editorial_2026_10_07_json_1.default.basis;
        for (const f of Object.values(facts)) {
            f.basis = labels[f.basis] ?? f.basis;
            f.comparisonBasis = labels[f.comparisonBasis] ?? f.comparisonBasis;
        }
        for (const { variant_id, key, ...patch } of (editorialFactsByVariant.get(v.id) || [])) {
            if (variant_id !== v.id || !facts[key])
                continue;
            Object.assign(facts[key], patch);
            if (patch.basis && key !== "range_km")
                facts[key].comparisonBasis = patch.basis;
            if (patch.status === "conditional")
                facts[key].resolvedElsewhere = true;
        }
        // 7 October buyer pass: measurements the supplied variant records did not carry.
        for (const { variant_id, ...fact } of (buyerFactsByVariant.get(v.id) ||
            [])) {
            if (variant_id !== v.id)
                continue;
            facts[fact.key] = {
                ...fact,
                comparisonBasis: fact.basis,
                market: "AU",
                scope: String(v.availability_scope ||
                    `${v.brand} ${v.model} ${v.trim} · ${v.model_year}`),
                issues: [],
            };
        }
        if (addedVariantIds.has(v.id)) {
            for (const fact of Object.values(facts)) {
                if (fact.value !== null)
                    continue;
                fact.basis = "Exact-trim research pending";
                fact.comparisonBasis = "";
                fact.sourceIds = [];
                fact.qualifications = ["No exact-trim measurement verified yet."];
            }
        }
        // Keep the shared comparison schema complete without inventing missing measurements.
        for (const template of research_buyer_2026_10_07_json_1.default.facts) {
            if (facts[template.key])
                continue;
            facts[template.key] = {
                key: template.key,
                label: template.label,
                value: null,
                unit: template.unit,
                basis: "Exact-trim research pending",
                comparisonBasis: "",
                status: "not_verified",
                sourceIds: [],
                date: catalogue_additions_1.catalogueAdditions.checkedAt,
                market: "AU",
                scope: "Exact Australian trim",
                qualifications: [
                    "No exact-trim measurement has been verified for this field.",
                ],
                issues: [],
            };
        }
        for (const key of Object.keys(facts))
            facts[key] = (0, launch_evidence_1.auditedFact)(facts[key]);
        for (const patch of (additionsFactsByVariant.get(v.id) || [])) {
            if (patch.variantId !== v.id)
                continue;
            const { variantId: _variantId, ...fact } = patch;
            void _variantId;
            facts[fact.key] = fact;
        }
        const refreshedFacts = (0, research_refresh_1.refreshFacts)(v.id, facts, research_refresh_2026_10_10_json_1.default, d.sources);
        const towing = refreshedFacts.towing_braked_kg;
        // Normalize the legacy label before review so published snapshots match the approval input.
        if (towing?.unit === "kg" &&
            towing.comparisonBasis === "Manufacturer figure") {
            towing.comparisonBasis = "Maximum braked towing";
        }
        const correctedFacts = (0, corrections_1.applyCorrections)(v.id, refreshedFacts, approved_corrections_json_1.default, d.sources);
        return {
            id: v.id,
            ...(v.configuration_evidence
                ? { configurationEvidence: v.configuration_evidence }
                : {}),
            researchStage: addedVariantIds.has(v.id) ? "partial" : "established",
            modelId: v.model_id,
            modelFamily: model.family_id,
            vehicleClass: (v.vehicle_class || "passenger"),
            family: v.model_id.startsWith("byd_atto_3")
                ? "byd-atto-3"
                : v.model_id.replaceAll("_", "-"),
            slug: (v.id.split("__").length >= 3
                ? v.id.split("__").slice(1).join("-")
                : v.id).replaceAll("_", "-"),
            brand: v.brand,
            // A generation name must not claim both trims share the same sales status.
            model: v.model_id === "byd_atto_3_legacy" ? "ATTO 3 (legacy FWD)" : v.model,
            trim: v.trim,
            generation: model.generation || "Generation details not verified",
            year: v.model_year,
            availability: v.record_state,
            availabilityEvidence: v.availability_evidence || {
                checkedAt: v.variant_review_date,
                orderStatus: v.record_state,
                stockStatus: "unverified",
                sourceIds: v.source_ids,
            },
            drive: String(v.drive || "Unknown"),
            facts: correctedFacts,
            issues: issues.filter((i) => (!["V2-10", "V2-12", "V2-13", "V2-15"].includes(i.issue_id) &&
                applies(i.issue_id, "all", v)) ||
                (!i.model_ids.includes("all") &&
                    i.issue_id !== "V2-06" &&
                    i.issue_id !== "V2-09") ||
                (i.issue_id === "V2-09" && v.id.includes("black_special"))),
        };
    });
    const availableCars = (0, availability_corrections_1.applyAvailabilityCorrections)((0, research_refresh_1.refreshAvailability)(cars, research_refresh_2026_10_10_json_1.default, d.sources), approved_availability_corrections_json_1.default, d.sources);
    // This index belongs only to this evaluation. Public callers supplying a mutable
    // Research snapshot still get a fresh row selection in effectiveFeatures().
    const featureRows = new Map();
    for (const row of d.feature_evidence) {
        const rows = featureRows.get(row.variant_id) || [];
        rows.push(row);
        featureRows.set(row.variant_id, rows);
    }
    const summaries = (0, selling_points_1.buildBuyerSummaries)(availableCars, cars.flatMap((car) => effectiveFeaturesFromRows(car, d, featureRows.get(car.id) || [])), d.sources, buyer_proposal_1.buyerProposal, { asOf: (0, evidence_date_1.australianEvidenceDate)() });
    return availableCars.map((car) => ({
        ...car,
        buyerSummary: summaries.get(car.id),
    }));
});
/** Dated presentation review happens after immutable summary-dependency validation. */
exports.catalogue = (0, react_1.cache)(() => {
    const sources = (0, exports.sourceResearch)().sources;
    const filled = (0, retained_fact_fills_1.applyRetainedFactFills)((0, exports.sourceCatalogue)(), sources);
    const initial = (0, evidence_regrading_1.applyEvidenceRegrading)(filled.map((car) => (0, price_ladder_1.applyPriceLadder)(car, sources)), sources);
    return (0, brand_updates_1.applyBrandUpdates)(initial, (0, exports.research)(), brand_update_registry_1.brandUpdatePackets).map((car) => ["passenger", "ute"].includes(car.vehicleClass || "passenger")
        ? { ...car, buyerGradesRequired: true }
        : car);
});
const months = "January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Oct|Nov|Dec";
/** Repairs words the research export ran together and drops notes written for the researchers. */
function tidy(input, internalNotes = false) {
    const text = Array.isArray(input) ? input.join(" ") : String(input ?? "");
    return text
        .replace(/Model(3|Y)/g, "Model $1")
        .replace(/\b(old|refreshed|Original)Y\b/g, "$1 Model Y")
        .replace(/(Supervised|FSD)(\d)/g, "$1 $2")
        .replace(new RegExp(`\\b(late|in|before)?(${months})(\\d)`, "g"), "$1 $2 $3")
        .replace(new RegExp(`\\b(late|in)(${months})\\b`, "g"), "$1 $2")
        .replace(/\b(in)(Australia|\d{4})/g, "$1 $2")
        .replace(/\band(IVI|A\$)/g, "and $1")
        .replace(/AndroidAuto/g, "Android Auto")
        .replace(/ComfortDriving/g, "Comfort Driving")
        .replace(/(\d)(kWh|km)\b/g, "$1 $2")
        .replace(/(\d)(Spring|Holiday)/g, "$1 $2")
        .split(/(?<=[.!?])\s+/)
        .filter((sentence) => !internalNotes ||
        !/\bdo not\b|\bcount(ed|s)?\b|famil(y|ies)\b|independently proven|owner ?thread|typo|manifest|→|retained for audit|filename/i.test(sentence))
        .join(" ")
        .replace(/\s{2,}/g, " ")
        .trim();
}
function evidenceLabel(verification) {
    if (/owner/i.test(verification))
        return "Owner reports";
    if (/overseas|global/i.test(verification))
        return "Overseas announcement";
    if (/fleet observation/i.test(verification))
        return "Release notes tracked by an independent Australian fleet log";
    if (/navigation notice/i.test(verification))
        return "Manufacturer navigation notice";
    if (/government/i.test(verification))
        return "Government approval record";
    return "Manufacturer notice";
}
function categoryLabel(category) {
    if (/recall/.test(category))
        return "Recall update";
    if (/map|navigation/.test(category))
        return "Navigation maps";
    if (/overseas/.test(category))
        return "Overseas only";
    if (/hardware|homologation|variant|specification/.test(category))
        return "Model change, not an update";
    if (/app/.test(category))
        return "Phone app";
    if (/unverified|unresolved|owner_reported|lead|candidate/.test(category))
        return "Unconfirmed report";
    if (/dealer/.test(category))
        return "Dealer-installed update";
    return "Software update";
}
function readableValue(value) {
    if (value === null || value === undefined)
        return "Needs confirmation";
    if (typeof value === "boolean")
        return value ? "Listed in research" : "Not listed as available";
    if (Array.isArray(value))
        return value.map(readableValue).join(", ");
    if (typeof value === "object")
        return Object.entries(value)
            .map(([k, v]) => `${k.replaceAll("_", " ")}: ${readableValue(v)}`)
            .join("; ");
    return String(value);
}
/** One effective equipment pipeline for detail pages and claim guards. */
function sourceEffectiveFeatures(car, d = (0, exports.sourceResearch)()) {
    const historical = d.feature_evidence_variant_context?.find((row) => row.id === car.id);
    // Reconstruct source warnings using the original bounded-build scope. A live
    // configuration review must not silently rebase an earlier feature guard.
    const sourceCar = historical
        ? { ...car, configurationEvidence: historical.configuration_evidence }
        : car;
    return effectiveFeaturesFromRows(sourceCar, d, d.feature_evidence.filter((f) => f.variant_id === car.id));
}
function effectiveFeatures(car, d = (0, exports.research)()) {
    const regraded = (0, evidence_regrading_1.applyFeatureRegrading)(car, sourceEffectiveFeatures(car, d), d.sources);
    // Explicit immutable source snapshots have not entered the M1 packet pipeline.
    // Current Tier 1 cars always carry this marker; their guards remain mandatory.
    return (0, brand_updates_1.applyBrandTermFeatures)(car, car.buyerGradesRequired
        ? (0, brand_updates_1.applyBrandFeatureUpdates)(car, regraded, d, brand_update_registry_1.brandUpdatePackets)
        : regraded);
}
function effectiveFeaturesFromRows(car, d, rows) {
    const id = car.id;
    const variant = (d.feature_evidence_variant_context ?? d.variants).find((v) => v.id === id);
    const features = rows.map((f) => {
        // Buyer rows are written for readers already; no inherited qualifications apply.
        if (buyerKeys.has(f.criterion))
            return f;
        const key = featureKey(f);
        const fresh = completionFeatures.get(key) ||
            usabilityFeatures.get(key) ||
            refinementFeatures.get(key);
        if (fresh)
            return { ...f, ...fresh };
        const warnings = d.publication_issues.filter((i) => (i.model_ids.includes(variant.model_id) || i.model_ids.includes("all")) &&
            (applies(i.issue_id, f.criterion, variant) ||
                applies(i.issue_id, f.criterion === "performance_rear_motor"
                    ? "zero_to_100_s"
                    : f.criterion, variant)));
        const blocked = f.status === "not_verified";
        return {
            ...f,
            value: blocked
                ? "Needs confirmation"
                : typeof f.value === "boolean"
                    ? f.value
                        ? "Included"
                        : "Not available in this specification"
                    : readableValue(f.value),
            conditions: [
                f.conditions,
                ...warnings.map((i) => i.publication_action),
            ].join(" "),
            source_ids: [
                ...new Set([...f.source_ids, ...warnings.flatMap((i) => i.source_ids)]),
            ],
        };
    });
    // The editorial pass rewrote every cell; it keeps the evidence trail of the row it replaces.
    for (const [i, f] of features.entries()) {
        const edit = editorialFeatures.get(featureKey(f));
        if (!edit)
            continue;
        const { add_source_ids = [], ...text } = edit;
        features[i] = {
            ...f,
            ...text,
            source_ids: [...new Set([...f.source_ids, ...add_source_ids])],
        };
    }
    for (const [i, feature] of features.entries())
        features[i] = (0, launch_evidence_1.auditedFeature)(feature);
    (0, feature_corrections_1.validateFeatureCorrectionRegistry)(approved_feature_corrections_json_1.default, d.feature_evidence);
    return (0, feature_corrections_1.applyFeatureCorrections)((0, research_refresh_1.refreshFeatures)(features, research_refresh_2026_10_10_json_1.default, d.sources), approved_feature_corrections_json_1.default.filter((edit) => edit.variantId === id), d.sources);
}
/** A build-scoped snapshot avoids recomputing the entire catalogue for every exported trim. */
function pack(id, snapshot) {
    const d = snapshot?.data ?? (0, exports.research)();
    const car = (snapshot?.cars ?? (0, exports.catalogue)()).find((c) => c.id === id);
    if (!car)
        throw new Error("Unknown variant");
    const features = effectiveFeatures(car, d);
    const eligibility = {
        ...d.update_eligibility.find((e) => e.variant_id === id),
    };
    if (id.includes("tesla_model_y__l_"))
        eligibility.documented_family_minimum = null;
    eligibility.scope =
        research_editorial_2026_10_07_json_1.default.eligibility.find((e) => e.variant_id === id)?.scope ??
            eligibility.scope;
    const events = d.update_events
        .filter((e) => e.model_ids.includes(car.modelId))
        .map((e) => ({
        ...e,
        changes: (Array.isArray(e.changes) ? e.changes : [])
            .map((c) => tidy(c))
            .filter(Boolean),
        version: e.version ? tidy(e.version) : e.version,
        notes: tidy(e.notes, true),
        verification: e.verification || "Documented by the cited source",
        evidence_label: evidenceLabel(e.verification || ""),
        category_label: categoryLabel(e.category),
        date_basis: e.date_basis || "Exact release date not established",
    }))
        .sort((a, b) => String(b.release_date || "").localeCompare(String(a.release_date || "")));
    const configuration = d.configuration_history
        .map((c, i) => ({ ...c, ...research_editorial_2026_10_07_json_1.default.configuration[i] }))
        .filter((c) => c.model_id === car.modelId);
    const contextSourceIds = (0, configuration_evidence_1.configurationSourceIds)(car);
    const availableSourceIds = new Set(d.sources.map((source) => source.id));
    for (const sourceId of contextSourceIds) {
        if (!availableSourceIds.has(sourceId))
            throw new Error(`Configuration evidence references missing source ${sourceId}`);
    }
    const sourceIds = new Set([
        ...contextSourceIds,
        ...Object.values(car.facts).flatMap((f) => f.sourceIds),
        ...Object.values(car.facts).flatMap((f) => f.issues.flatMap((issue) => issue.source_ids)),
        ...(car.availabilityEvidence?.sourceIds || []),
        ...(car.buyerSummary?.guardSourceIds || []),
        ...(car.buyerSummary?.strength?.sourceIds || []),
        ...(car.buyerSummary?.tradeoff?.sourceIds || []),
        ...features.flatMap((f) => f.source_ids),
        ...eligibility.source_ids,
        ...events.flatMap((e) => e.source_ids),
        ...car.issues.flatMap((i) => i.source_ids),
        ...configuration.flatMap((c) => c.source_ids),
    ]);
    for (const sourceId of sourceIds) {
        if (!availableSourceIds.has(sourceId))
            throw new Error(`Pack evidence references missing source ${sourceId}`);
    }
    const sources = d.sources
        .filter((s) => sourceIds.has(s.id))
        .map((s) => {
        const url = (0, config_1.safeUrl)(s.url) || "";
        // Shared immutable evidence can be referenced once in React's wire format.
        // Still sanitize any URL whose canonical safe value differs.
        return url === s.url ? s : { ...s, url };
    });
    return { car, features, eligibility, events, configuration, sources };
}
function counts() {
    const d = (0, exports.research)();
    const cars = (0, exports.catalogue)();
    return {
        variants: cars.length,
        families: new Set(cars.map((c) => c.modelFamily || c.family)).size,
        generations: d.models.length,
        criteria: d.criteria.length,
        evidence: d.feature_evidence.length,
        current: cars.filter((c) => c.availability === "current_or_order_listed")
            .length,
        outgoing: cars.filter((c) => c.availability === "outgoing").length,
        provisional: cars.filter((c) => c.availability === "announced_provisional")
            .length,
    };
}
// Selection controls need identity and three filter facts, not the full specifications.
function pickerCatalogue() {
    return (0, exports.catalogue)().map((car) => {
        const { buyerSummary, ...identity } = car;
        void buyerSummary;
        return {
            ...identity,
            facts: Object.fromEntries(["price_aud", "range_km", "seats"].map((key) => [key, car.facts[key]])),
            issues: [],
        };
    });
}
