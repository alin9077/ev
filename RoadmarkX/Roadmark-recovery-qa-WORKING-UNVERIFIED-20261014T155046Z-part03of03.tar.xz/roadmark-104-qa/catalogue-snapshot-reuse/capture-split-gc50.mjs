import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
const [mode,out,asOf]=process.argv.slice(2);
assert(['cars','research'].includes(mode));
assert.equal(asOf,'2026-10-15','This reviewed capture is explicitly scoped to2026-10-15');
assert(!fs.existsSync(path.join(out,'index.json')),'Refuse to overwrite a terminal index');
const root=process.cwd(),started=Date.now();
const require=createRequire(path.join(root,'src/lib/data.ts'));
const read=fs.readFileSync,baseFile=path.join(root,'data/au_ev_all_variants_2026-10-06.json');let baseReads=0;
fs.readFileSync=function(file,...args){if(path.resolve(String(file))===baseFile && args[0]==='utf8')baseReads++;return read.call(fs,file,...args)};
const api=require('./data.ts');
const {australianEvidenceDate}=require('./evidence-date.ts');
assert.equal(australianEvidenceDate(),asOf,'Capture date changed; do not silently change summary freshness');
assert.equal(typeof global.gc,'function','Run this harness with --expose-gc');
global.gc();
console.log('Imported and collected',mode,process.memoryUsage());
function rows(name,values){
 const filename=path.join(out,name),fd=fs.openSync(filename,'wx'),hash=crypto.createHash('sha256');let bytes=0;
 try{for(let i=0;i<values.length;i++){const text=JSON.stringify(values[i])+'\n';fs.writeSync(fd,text);hash.update(text);bytes+=Buffer.byteLength(text);if(i%50===0)global.gc();}}finally{fs.closeSync(fd)}
 return {file:name,array:true,rows:values.length,bytes,sha256:hash.digest('hex')};
}
const index={mode,asOf,source:'Fresh current public entry point; no replay substitutions',research:{}};
if(mode==='cars'){
 const {cars}=api.catalogueSnapshot();
 // Only cars are retained. The unused Research half can be collected before export.
 global.gc();console.log('Fresh catalogue loaded',cars.length,process.memoryUsage());
 index.cars=rows('cars.jsonl',cars);
}else{
 const data=api.research();
 global.gc();console.log('Fresh research loaded',Object.keys(data).length,process.memoryUsage());
 for(const[key,value]of Object.entries(data)){
  const array=Array.isArray(value);
  index.research[key]={...rows('research-'+key+'.jsonl',array?value:[value]),array};
  console.log('Research field written',key,index.research[key].rows);
 }
}
assert.equal(baseReads,1,'Each split phase must hydrate the original source once');
assert.equal(australianEvidenceDate(),asOf,'Capture crossed its reviewed calendar date');
Object.assign(index,{baseReads,elapsedMs:Date.now()-started,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage(),postImportGc:true,postLoadGc:true,periodicRowGc:true});
fs.writeFileSync(path.join(out,'index.json'),JSON.stringify(index,null,2)+'\n',{flag:'wx'});
console.log('COMPLETE',mode,'elapsedMs',index.elapsedMs,'baseReads',baseReads);
