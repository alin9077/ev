import os, subprocess, sys, time, json
qa='/workspace/scratch/586427eef9f2/roadmark-104-qa/catalogue-snapshot-reuse'
name=sys.argv[1]
cmd=sys.argv[2:]
started=time.time()
with open(f'{qa}/{name}.log','w') as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
 pid,status,usage=os.wait4(p.pid,0)
 code=os.waitstatus_to_exitcode(status);p.returncode=code
result={'command':cmd,'returncode':code,'signal':-code if code<0 else None,'elapsedSeconds':time.time()-started,'ru_maxrss_kib':usage.ru_maxrss,'ru_utime':usage.ru_utime,'ru_stime':usage.ru_stime}
open(f'{qa}/{name}-measurement.json','w').write(json.dumps(result,indent=2)+'\n')
open(f'{qa}/{name}.exit','w').write(str(code)+'\n')
print(json.dumps(result,indent=2))
sys.exit(128-code if code<0 else code)
