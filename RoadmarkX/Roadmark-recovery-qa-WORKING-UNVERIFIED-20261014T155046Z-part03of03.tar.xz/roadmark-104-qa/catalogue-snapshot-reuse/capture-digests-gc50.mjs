import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
const [mode,out,asOf]=process.argv.slice(2);
assert(['cars','research'].includes(mode));
assert.equal(asOf,'2026-10-15','This reviewed capture is explicitly scoped to2026-10-15');
assert(!fs.existsSync(path.join(out,'index.json')),'Refuse to overwrite a terminal index');
const root=process.cwd(),started=Date.now();
const require=createRequire(path.join(root,'src/lib/data.ts'));
const read=fs.readFileSync,baseFile=path.join(root,'data/au_ev_all_variants_2026-10-06.json');let baseReads=0;
fs.readFileSync=function(file,...args){if(path.resolve(String(file))===baseFile && args[0]==='utf8')baseReads++;return read.call(fs,file,...args)};
const api=require('./data.ts');
const {australianEvidenceDate}=require('./evidence-date.ts');
assert.equal(australianEvidenceDate(),asOf,'Capture date changed; do not silently change summary freshness');
assert.equal(typeof global.gc,'function','Run this harness with --expose-gc');
global.gc();
console.log('Imported and collected',mode,process.memoryUsage());
function rows(name,values){
 const digestFile='digests-'+name,filename=path.join(out,digestFile),fd=fs.openSync(filename,'wx');
 const aggregate=crypto.createHash('sha256'),digestHash=crypto.createHash('sha256');let serializedBytes=0,digestFileBytes=0;
 try{for(let i=0;i<values.length;i++){
  // Exactly the same full JSON row serialization as every retained capture attempt.
  const text=JSON.stringify(values[i])+'\n';
  const bytes=Buffer.byteLength(text),sha256=crypto.createHash('sha256').update(text).digest('hex');
  aggregate.update(text);serializedBytes+=bytes;
  const row=values[i],identity=row&&typeof row==='object'?Object.fromEntries(['id','variant_id','model_id','criterion'].filter(key=>Object.hasOwn(row,key)).map(key=>[key,row[key]])):null;
  const record=JSON.stringify({index:i,identity,serializedBytes:bytes,sha256})+'\n';
  fs.writeSync(fd,record);digestHash.update(record);digestFileBytes+=Buffer.byteLength(record);
  if(i%50===0)global.gc();
 }}finally{fs.closeSync(fd)}
 return {digestFile,array:true,rows:values.length,serializedBytes,aggregateSha256:aggregate.digest('hex'),digestFileBytes,digestFileSha256:digestHash.digest('hex')};
}
const index={mode,asOf,source:'Fresh current public entry point; no replay substitutions',kind:'Full standard-JSON row digests; full values must be independently matched to the complete oracle before accepting a baseline',research:{}};
if(mode==='cars'){
 const {cars}=api.catalogueSnapshot();
 // Only cars are retained. The unused Research half can be collected before export.
 global.gc();console.log('Fresh catalogue loaded',cars.length,process.memoryUsage());
 index.cars=rows('cars.jsonl',cars);
}else{
 const data=api.research();
 global.gc();console.log('Fresh research loaded',Object.keys(data).length,process.memoryUsage());
 for(const[key,value]of Object.entries(data)){
  const array=Array.isArray(value);
  index.research[key]={...rows('research-'+key+'.jsonl',array?value:[value]),array};
  console.log('Research field written',key,index.research[key].rows);
 }
}
assert.equal(baseReads,1,'Each split phase must hydrate the original source once');
assert.equal(australianEvidenceDate(),asOf,'Capture crossed its reviewed calendar date');
Object.assign(index,{baseReads,elapsedMs:Date.now()-started,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage(),postImportGc:true,postLoadGc:true,periodicRowGc:true});
fs.writeFileSync(path.join(out,'index.json'),JSON.stringify(index,null,2)+'\n',{flag:'wx'});
console.log('COMPLETE DIGEST CAPTURE',mode,'elapsedMs',index.elapsedMs,'baseReads',baseReads);
