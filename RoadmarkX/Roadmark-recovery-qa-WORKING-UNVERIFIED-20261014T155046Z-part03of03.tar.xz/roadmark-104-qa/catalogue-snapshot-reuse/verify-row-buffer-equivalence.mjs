import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {StandardRowUtf8Buffer} from './standard-row-utf8-buffer.mjs';
const qa=path.dirname(new URL(import.meta.url).pathname),source=path.join(qa,'after448/cars.jsonl');
const receipt=path.join(qa,'row-buffer-equivalence.json');
assert(!fs.existsSync(receipt),'Preserve completed equivalence receipt');
const sha=async(file)=>{const h=crypto.createHash('sha256');for await(const b of fs.createReadStream(file))h.update(b);return h.digest('hex')};
const inputs=['standard-row-utf8-buffer.mjs','capture-digests-buffer.mjs','run-digests-buffer.py','capture-digests-gc50.mjs','verify-row-buffer-equivalence.mjs'];
const before={};for(const file of inputs)before[file]=await sha(path.join(qa,file));const sourceHash=await sha(source);
const buffer=new StandardRowUtf8Buffer(),aggregateOriginal=crypto.createHash('sha256'),aggregateBuffer=crypto.createHash('sha256');
let rows=0,totalBytes=0,maxRowBytes=0;const ids=new Set();
function compare(value,label,originalLine){
 const text=JSON.stringify(value)+'\n';if(originalLine!==undefined)assert.equal(text,originalLine+'\n',label+' exact retained standard serialization');
 const encoded=buffer.encode(text),independent=Buffer.from(text,'utf8');
 assert.deepEqual(encoded,independent,label+' every UTF-8 byte');
 assert.equal(encoded.length,Buffer.byteLength(text,'utf8'));
 const stringHash=crypto.createHash('sha256').update(text).digest('hex');
 assert.equal(crypto.createHash('sha256').update(encoded).digest('hex'),stringHash,label+' string vs reusable-buffer SHA256');
 assert.equal(crypto.createHash('sha256').update(encoded).digest('hex'),stringHash,label+' same slice can be hashed twice synchronously');
 return{text,encoded};
}
for await(const line of readline.createInterface({input:fs.createReadStream(source),crlfDelay:Infinity})){
 const row=JSON.parse(line);assert(!ids.has(row.id));ids.add(row.id);
 const {text,encoded}=compare(row,'retained row '+rows,line);
 aggregateOriginal.update(text);aggregateBuffer.update(encoded);totalBytes+=encoded.length;maxRowBytes=Math.max(maxRowBytes,encoded.length);rows++;
}
assert.equal(rows,397);assert.equal(aggregateOriginal.digest('hex'),sourceHash);assert.equal(aggregateBuffer.digest('hex'),sourceHash);
const fixtures=[null,true,false,0,-0,1.25,1e-9,1e21,NaN,Infinity,-Infinity,'','ASCII','汉字 Ελληνικά العربية','é e\u0301','😀 𝄞 🧑🏽‍🚀','\u0000\n\r\t\b\f"\\','\u2028\u2029\ufeff\uffff','\ud800','\udc00','\ud800X\udc00',['a',undefined,,null,NaN],{z:'last',2:'two',1:'one',skip:undefined,a:'first'},{nested:[{emoji:'😀',control:'\n'}]},'x'.repeat(4097)];
for(let i=0;i<fixtures.length;i++)compare(fixtures[i],'fixture '+i);
const oldCapacity=buffer.capacity;const encoded=buffer.encode('x\n');assert.equal(encoded.length,2);assert.equal(buffer.capacity,oldCapacity);
assert.equal(await sha(source),sourceHash,'Retained full car bytes unchanged');for(const file of inputs)assert.equal(await sha(path.join(qa,file)),before[file],'Harness unchanged: '+file);
const result={status:'passed',source,sourceSha256:sourceHash,rows,totalBytes,maxRowBytes,unicodeAndJsonFixtures:fixtures.length,allStandardSerializedBytesEqual:true,allPerRowSha256Equal:true,aggregateSha256Equal:sourceHash,sameSliceHashedTwice:true,growOnlyCapacityRetained:true,inputs:before,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage(),claim:'Exact encoding/hash equivalence only; no fresh catalogue capture or full typecheck claim'};
fs.writeFileSync(receipt,JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result,null,2));
