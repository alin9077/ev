import os,json,time,pathlib,subprocess
q=pathlib.Path(__file__).resolve().parent
cmd=['node','node_modules/typescript/bin/tsc','--noEmit']
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=768 --max-semi-space-size=1');start=time.monotonic()
with (q/'root-typecheck-v2.stdout').open('w') as o,(q/'root-typecheck-v2.stderr').open('w') as e:
 p=subprocess.Popen(cmd,cwd='/workspace/scratch/586427eef9f2/roadmark-104',env=env,stdout=o,stderr=e);pid,status,r=os.wait4(p.pid,0);rc=os.waitstatus_to_exitcode(status);p.returncode=rc
m={'command':cmd,'nodeOptions':env['NODE_OPTIONS'],'exitCode':rc,'signal':-rc if rc<0 else None,'wallSeconds':time.monotonic()-start,'userSeconds':r.ru_utime,'systemSeconds':r.ru_stime,'maxRssKiB':r.ru_maxrss}
(q/'root-typecheck-v2.metrics.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m),flush=True)
