# Catalogue snapshot reuse verification

Scope: only source-loading reuse in data.ts and validation/report consumers. Immutable source, every dated input packet, hero and UI are unchanged. No stale global derived cache or caller-supplied Research builder input.

Before copies and exact data/original hashes were captured before edits. Original data.ts is transpiled without source changes to before-data.cjs. Fresh original-mode runtime resolves all dependencies from the same unchanged repository. No historic snapshot is counted as a fresh prepatch pass.

1. Focused behavioral tests exercise the actual compiled loader against small controlled inputs: one-read order, freshness between top-level calls, unchanged source research after building cars, source/effective separation, every existing guard call propagated, independent packet source-drift check, counts/report reuse.
2. Run fresh postpatch snapshot capture with 704MiB old-space/1MiB semi-space, no overlapping heavy job. Capture every catalogue row and every Research key in JSONL, row counts and SHA256, original-source read count, elapsed time and process.resourceUsage peak RSS.
3. Run exact prepatch catalogue and research independently in fresh processes under the same flags. Compare every complete JSONL byte, not selected brands or field/count pins. Do not declare equality when either capture is incomplete. If original mode fails, report the actual termination; seek approval before any reconstructed phased baseline and label its provenance separately.
4. Run current validation and targeted existing source/fact/feature/configuration mutation guards plus full coverage. Keep every assertion and source check. Verify counts/report output equality independently.
5. Recheck all source/data hashes. Produce changed-file before/after manifest and send independent reviewer the full artifacts. Independent approval is required before this proof can support Subaru baseline transition.

Installed Next guidance consulted: docs/01-app/02-guides/caching-without-cache-components.md and docs/01-app/01-getting-started/06-fetching-data.md. React.cache remains current-request-only; no unstable_cache, use-cache directive, persistent map or cross-request reuse is introduced. CLI cache remains a no-op, so explicit snapshot scope is necessary.

Known memory caveat: original repeatedly parsed source is about2MB, not75MB; 74.9MB catalogue-additions is parsed once per module. Additional module-resident input JSON is identities55MB, proposals24MB, regrading15MB, and packets47MB. Static inputs and temporary guard canonicalizations remain. Reuse has a deterministic call-count benefit; reduction does not establish termination cause or guarantee completion.
