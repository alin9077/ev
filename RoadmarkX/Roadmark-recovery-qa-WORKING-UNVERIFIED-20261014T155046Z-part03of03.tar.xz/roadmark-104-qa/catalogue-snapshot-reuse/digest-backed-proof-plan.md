# Digest-backed multi-phase baseline proof

No capture or oracle run is authorized by this plan alone. Root controls the serialized slot and execution approval.

## Preserved history
All interrupted full-value captures, scripts, partial rows and measured signal-9 receipts remain unchanged. The original pre-Polestar complete snapshot and exact final Polestar packet remain the independent oracle lineage. The original loader, v1 and request-sharing v2 code/diffs and all historical source manifests remain distinct.

## Fresh capture
Use capture-digests-gc50.mjs through run-digests-gc50.py, separately for research and cars, each in a new directory. The harness uses the actual current public entry point, explicit Australian date 2026-10-15, one original-source read, the existing import/load GC boundaries and original every-50-row GC cadence. Standard serialization remains exactly JSON.stringify(row) plus newline. No field is removed, reordered or normalized.

For every row it writes only index, identifying fields, serialized UTF-8 byte count and SHA256. For every field it records the complete row count, total serialized byte count and SHA256 of the concatenated original serialized rows. The metadata digest file has its own byte count and SHA256. The wrapper pins all 515 source/input files and all harness files before and after, checks every metadata row/index/count/hash, and records exit/signal/RSS. A successful capture is not yet full-value equality.

## Independent oracle
1. Verify the full historical source/input chain, seven historically omitted .mjs files against both retained whole-source captures, final Polestar registration, and exact original-to-v1-to-v2 amendments.
2. Derive the complete current 397 cars and all 14 research fields through actual prepareBrandResearch and applyBrandUpdates from the immutable pre-Polestar snapshot and only the exact final approved Polestar packet. Preserve every original input hash.
3. For every fresh car and research row, serialize the complete derived value with the same standard serializer and compare index, identity, exact UTF-8 byte count and SHA256. Also compare every full-field aggregate hash/count/byte count. Require exactly 397 cars, all 14 research keys and no missing/extra/duplicate rows. Do not compare only selected brands or useful facts.
4. Compare all 14 complete pre-fix research fields and all five completed original Subaru before files. Verify every non-Polestar car is unchanged from the original snapshot; check all 14 actual Polestar packs, portable transport, complete approved after cars, and full reports at both 2026-10-14 and 2026-10-15.
5. Recheck every source, harness, phase and historical input hash after the proof. Only then write a complete derived baseline/index and explicit digest-backed multi-phase provenance. Preserve failures; no canonical Subaru fixture may be accepted before independent approval.

## Claim boundary
A passing result proves complete standard-JSON value equality by SHA256 between fresh production results and the full independently derived oracle under identical pinned code/inputs. It does not claim a successful single-process full-value export, a fresh old-loader pass, a diagnosed cause of signal 9, or a full typecheck. Full derived values remain available and citable from the independently verified oracle.
