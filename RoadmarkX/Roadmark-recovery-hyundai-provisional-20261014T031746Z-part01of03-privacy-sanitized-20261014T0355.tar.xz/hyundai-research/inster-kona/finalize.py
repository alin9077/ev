import json,pathlib,hashlib
B=pathlib.Path('/tmp/hyundai-research/inster-kona');p=B/'normalized-evidence.json';d=json.load(open(p));sourceby={s['key']:s for s in d['sources']}
# Preserve direct exact advertised New status for matched MY27 dealer units only.
for i in [4,5]:
 v=d['variants'][i];sk='kona_elite_new_melville' if i==4 else 'kona_premium_new_alan'
 v['availability']['stockStatus']='new_stock_listed';v['availability']['sourceKeys'].append(sk);v['availability']['qualifications'].append('Exact dealer advertisement still says New; '+('Melville 620264022, VIN KMHHC816UTU044027, 8 km, MY27 Electric Elite 64.8 kWh 150 kW.' if i==4 else 'Alan Mance HY2136, VIN KMHHE816UVU045129, 10 km, MY27 Electric Premium.'))
# Public technical PDF table checks and prior identical-source reuse audit.
for s in d['sources']:
 if s['key']=='inster_specs_aug2026':s['visualReview']={'pages':[1,2,3],'note':'Current file identical to 10 Oct verified source; current powertrain/capacity, two-grade dimensions and removed-column distinctions checked.','artifacts':[]}
 elif s['key']=='kona_specs_my27':s['visualReview']={'pages':[1,2],'note':'Current file identical to 10 Oct verified source; MY27 powertrain/capacity and four exact configuration columns checked.','artifacts':[]}
 elif s['key']=='inster_specs_legacy_my26':s['visualReview']={'pages':[2,3],'note':'Legacy Extended Range column independently checked for 49kWh range, dimensions, 17-inch wheels and internal V2L. Equipment heat-pump table inspected as extracted text.','artifacts':[]}
 else:continue
 pattern={'inster_specs_aug2026':'inster-current-*','kona_specs_my27':'kona-*','inster_specs_legacy_my26':'inster-legacy-*'}[s['key']]
 for f in sorted((B/'rendered').glob(pattern)):s['visualReview']['artifacts'].append({'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
leadstates=[
 ('inster_midland_new_620261783','added_residual_new','MY26 AX.V1 Extended Range 49 kWh; exact New stock620261783, VIN KMHB2511UTW080494, 10km, build March2026, $40,990DA. Added separate identity with live legacy technical sheet.'),
 ('inster_base_new_bathurst','removed_exact_listing','Former New MY26 Standard Range stock508567 now redirects to generic New/Used/Demo index. Not evidence of sold status or current exact New availability; no residual SR added from this lead.'),
 ('inster_midland_new_620265048','current_new_battery_unresolved','MY27 AX.V2 New stock620265048 still advertised, four seats, 10km; exact battery/output not in unit fields. No battery inferred from price/VIN.'),
 ('inster_cross_essendon_v1','sold','Exact MY26 AX.V1 Cross stockNHE35516 explicitly SOLD/just sold. Excluded from new availability.'),
 ('inster_cross_v2_new_john','sold','Exact AX.V2 Cross stock0620265495 explicitly SOLD/just sold. Excluded from new availability.'),
 ('inster_v2_new_melville','removed_exact_listing','Exact stock620265034 redirects to generic stock; no exact current-unit evidence.'),
 ('inster_cross_new_darwin','direct_read_blocked','403 on direct request; prior AX.V1 lead not promoted by stale search snippet. No claim of sold status or physical stock.'),
 ('inster_sr_v2_sunco','direct_read_blocked','403 on direct request; indexed AX.V2 MY27 42kWh lead is not a fresh direct stock check.'),
 ('inster_cross_carsales_my27','direct_read_blocked','403 on direct request; indexed MY27 Cross lead does not prove current availability.'),
 ('kona_elite_new_melville','matched_current_new','Exact New MY27 Electric Elite, 64.8kWh/150kW/FWD, stock620264022, VIN KMHHC816UTU044027, 8km. Maker price used; expired dealer campaign not normalized.'),
 ('kona_elite_new_maughan','matched_current_new','Exact New MY27 Electric Elite stock520117543. Dealer 505km wording conflicts with maker 19-inch 444km; exact maker range retained.'),
 ('kona_premium_new_alan','matched_current_new','Exact New MY27 SX2.V3 Electric Premium stockHY2136, VIN KMHHE816UVU045129, 10km, five seats.'),
 ('kona_base_new_country','current_new_battery_unresolved','Exact New MY27 SX2.V3 base Electric stock0220624464, five seats; source does not establish which battery. No battery inferred from VIN/price.'),
 ('kona_sr_new_phil','current_new_battery_unresolved','Exact New MY27 SX2.V3 base Electric stock220624403; battery mapping not established in direct source.'),
 ('kona_er_new_phil','current_new_battery_unresolved','Exact New MY27 SX2.V3 base Electric stock220624504; battery mapping not established in direct source.'),
 ('kona_nline_new_phil','removed_exact_listing','Exact old indexed MY27 N Line stock220624446 returns404. Current maker N Line option remains listed, but this lead is not current stock proof.')]
rec=[]
for sk,state,note in leadstates:
 s=sourceby[sk];rec.append({'lead':sk,'resolution':state,'reason':note,'url':s['url'],'checkedAt':'2026-10-14','status':s.get('status'),'finalUrl':s.get('finalUrl'),'file':s.get('file'),'physicalStockVerified':False,'factoryOrderAcceptanceVerified':False})
rec.extend([{'lead':'current_non_cross_49kwh','resolution':'not_current_factory_configuration','reason':'Current enabled maker API lists only 42kWh base and Cross49 with sunroof; 8Oct CarExpert update confirms Extended Range dropped for MY27. Genuine older MY26 residual is admitted separately.','sourceKeys':['inster_config','inster_2027_news']},{'lead':'current_cross_roof_basket','resolution':'not_current_factory_configuration','reason':'Current enabled maker API supplies only sunroof Cross; 8Oct update confirms roof basket removed. Previously sold MY26 Cross lead does not establish another unsold new roof-basket unit.','sourceKeys':['inster_config','inster_2027_news','inster_cross_essendon_v1']},{'lead':'kona_n_line_option','resolution':'nested_non_additive_configuration','reason':'Live API/specification explicitly names Premium + N Line option pack; four core grade/battery identities plus nested configured Premium details. Not a fifth standalone battery/grade version.','sourceKeys':['kona_current_config','kona_specs_my27','kona_price_4']}])
d['reconciliation']=rec;d['captureFailures']=[s for s in d['sources'] if not s.get('file')];d['sources']=[s for s in d['sources'] if s.get('file')]
# Verify all inherited non-null non-brand cells have a dated review.
b=json.load(open('/tmp/hyundai-research/before.json'));fs=json.load(open('/tmp/hyundai-research/features-before.json'));audit=[]
for v in d['variants']:
 old=next((x for x in b if x['id']==v['id']),None)
 if old:
  needed=[k for k,f in old['facts'].items() if f['value'] is not None and not any(t in k for t in ['warranty','roadside','soh_warranty'])]
  missing=set(needed)-{f['key'] for f in v['facts']};assert not missing,(v['id'],missing)
  known=[x['criterion'] for x in fs if x['variant_id']==v['id'] and x['status']!='not_verified' and x['criterion'] not in ['warranty_service','driveaway_price','roadside_assistance']]
  missing=set(known)-{f['criterion'] for f in v['features']};assert not missing,(v['id'],missing)
  audit.append({'variantId':v['id'],'inheritedNonNullTechnicalCells':len(needed),'reviewed':len(needed),'knownEquipmentRows':len(known),'reviewedEquipmentRows':len(known)})
 core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg']
 assert set(core)<={f['key'] for f in v['facts']},v['id']
 for side in v['summary'].values():assert all(k in {f['key'] for f in v['facts']} for k in side['keys'])
 for f in v['features']:
  assert isinstance(f['value'],str);assert f['keys'];assert all(k in {f['key'] for f in v['facts']} for k in f['keys'])
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');(B/'reconciliation.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n');(B/'validation.json').write_text(json.dumps({'reviewedAt':'2026-10-14','allCore15NonBrandFieldsPresent':True,'brandWarrantyFields':'Parent review','inheritedTechnicalClosure':audit,'identities':len(d['variants']),'facts':sum(len(v['facts']) for v in d['variants']),'equipmentRows':sum(len(v['features']) for v in d['variants']),'sourceCaptures':len(d['sources']),'failedCaptures':len(d['captureFailures']),'leadDecisions':len(rec)},indent=2)+'\n')
manifest=[]
for f in sorted(B.rglob('*')):
 if f.is_file() and f.name!='manifest.json':manifest.append({'path':str(f),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(B/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print((B/'validation.json').read_text())
