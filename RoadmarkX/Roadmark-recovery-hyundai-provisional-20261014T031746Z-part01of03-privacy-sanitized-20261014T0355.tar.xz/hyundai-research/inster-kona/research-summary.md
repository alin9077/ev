# INSTER and KONA Electric M1 review, 14 October 2026

## Result

- Six existing current identities refreshed: MY27 INSTER Standard Range and Cross sunroof, plus four MY27 KONA Electric grade/battery combinations
- One separate genuine residual-New identity added: MY26 INSTER Extended Range 49 kWh FWD, Midland stock 620261783 / VIN KMHB2511UTW080494, advertised New for $40,990 driveaway
- KONA Premium N Line stays an explicitly non-additive configured option, with its own $63,000 MLP/$65,990 national driveaway evidence and retained option-specific specifications
- All 2,173 inherited non-null technical cells outside shared brand terms reviewed; all 76 previously known equipment rows refreshed. Total normalized payload: 2,275 facts and 108 equipment rows
- All 15 non-brand core fields included for all seven identities. Parent supplies the two warranty fields and shared warranty aliases

## Current price ladder

Highest current maker retail MLP: INSTER $37,500/$43,500; KONA Standard $46,000, Extended $50,000, Elite $53,000 and Premium $60,000. Matching national driveaway offers run through 31 December 2026 and are stored separately with exact purchase/delivery/private-buyer conditions. INSTER Cross raw calculation input is $43,499.99 but explicit retail mlpFromPIM is $43,500; the retail field is used without arithmetic.

## Important boundaries

Current INSTER is MY27. The live August PDF and brochure still use MY26 filenames but describe the current two-grade lineup and already omit the earlier internal V2L and emergency cable rows. CarExpert's 8 October update records Hyundai Australia confirmation that MY27 also loses the heat pump. Those deletion facts are Reported. The residual MY26 Extended Range has a distinct live legacy sheet with heat pump, internal V2L and cable; no MY27 feature carryover is used for it.

Maker DC charging capacity rows explicitly publish 120 kW for INSTER and 100 kW for KONA. The separate station-time rows are not used as vehicle acceptance. Canonical timing is DC 10–80% only. INSTER 30 minutes needs the stated 120 kW station; KONA 43 minutes needs the stated 350 kW station.

INSTER brochure explicitly says seating four. KONA seating five remains Reported from fresh exact/current-body dealer evidence. Acceleration remains Reported: INSTER 11.7/10.6 seconds for matching powertrains, KONA MY27 9.9 seconds for 99 kW and 7.6 seconds for 150 kW versions.

Rear minimum cargo remains unranked: 280 L INSTER and 407 L KONA are maker VDA minimum values without an explicit occupied-seat/loading definition. KONA's maker FAQ explicitly labels 1,241 L with rear seats folded, so its rear maximum is associated with that configuration. Front cargo is separate.

INSTER and KONA Standard Range towing cells are dash-marked, not numeric zero. Two-source reviews record no published braked trailer rating rather than inventing 0 kg. Every home-charging row separates maximum AC kW from a stated 240 V timing whose phase/current is unspecified; no 7 kW duration is inferred.

## Dealer lead closure

Nineteen lead/configuration decisions are in reconciliation.json. Midland MY26 Extended Range still says New. Bathurst's old Standard Range and Melville's old AX.V2 unit now redirect to generic stock. Essendon MY26 Cross and John Hughes AX.V2 Cross explicitly say SOLD. The old Phil Gilbert N Line unit returns 404. Three leads remain inaccessible (403) and are not promoted from search snippets. Current KONA Elite/Premium exact New advertisements remain separately recorded; battery-ambiguous base ads are not assigned by price/VIN. No physical stock or factory order acceptance is claimed.

## Files

normalized-evidence.json is the integration handoff. source-index.json retains all attempted capture outcomes. sources/ contains original HTML/JSON/PDF and extracted text; rendered/ contains inspected technical tables. validation.json verifies inherited closure and dependency references. manifest.json hashes the evidence deliverable and all retained local captures. No repository or application/data files were edited.
