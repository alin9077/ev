import urllib.request,urllib.error,hashlib,json,pathlib,subprocess,datetime,concurrent.futures,re
from html.parser import HTMLParser
BASE=pathlib.Path('/tmp/hyundai-research/inster-kona'); SD=BASE/'sources'
class Txt(HTMLParser):
 def __init__(self):super().__init__();self.parts=[];self.skip=0
 def handle_starttag(self,t,a):
  if t in ('script','style'): self.skip+=1
 def handle_endtag(self,t):
  if t in ('script','style'):self.skip=max(0,self.skip-1)
 def handle_data(self,d):
  if not self.skip and d.strip():self.parts.append(d.strip())
def fetch(a):
 key,url,publisher,stype=a
 o={'key':key,'url':url,'title':key.replace('_',' '),'publisher':publisher,'source_type':stype,'published_date':None,'accessed_date':'2026-10-14','market':'AU'}
 try:
  r=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=65);b=r.read();o.update(status=r.status,finalUrl=r.url,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),retrievedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
  ext='pdf' if b[:4]==b'%PDF' else 'json' if url.find('/api/')>=0 else 'html';p=SD/(key+'.'+ext);p.write_bytes(b);o['file']=str(p);tp=SD/(key+'.txt');
  if ext=='pdf':subprocess.run(['pdftotext','-layout',str(p),str(tp)],check=True)
  elif ext=='json':tp.write_text(json.dumps(json.loads(b),ensure_ascii=False,indent=2))
  else:
   h=Txt();h.feed(b.decode(errors='replace'));tp.write_text('\n'.join(h.parts))
  o['textFile']=str(tp);o['textSha256']=hashlib.sha256(tp.read_bytes()).hexdigest()
 except Exception as e:o['error']=str(e)
 print(key,o.get('status',o.get('error')),flush=True);return o
if __name__=='__main__':
 D=json.load(open('/tmp/hyundai-research/research-before.json')); old=json.load(open('/workspace/scratch/586427eef9f2/roadmark-work/roadmark/data/remaining-hyundai-evidence.json'))
 sources=[(s['id'].replace('r10_hy_',''),s['url'],s['publisher'],s['source_type']) for s in D['sources'] if any(t in s['id'] for t in ['inster','kona'])]
 sources+=[('inster_config','https://www.hyundai.com/content/api/au/hyundai/v3/carpricecalculator?postcode=2000&displaypowertrain=true&modelname=inster','Hyundai Australia','official_au_manufacturer'),('kona_config','https://www.hyundai.com/content/api/au/hyundai/v3/carpricecalculator?postcode=2000&displaypowertrain=true&modelname=kona-electric','Hyundai Australia','official_au_manufacturer')]
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:R=list(ex.map(fetch,sources))
 for r in R:
  prior=next((s for s in old['sourceRegistry'] if s['id']==r['key']),None)
  if prior:r['priorSha256']=prior.get('sha256');r['identicalToPrior']=prior.get('sha256')==r.get('sha256')
 (BASE/'source-index.json').write_text(json.dumps(R,indent=2))
