import json,copy,pathlib,hashlib,re
B=pathlib.Path('/tmp/hyundai-research/inster-kona'); S=B/'sources'; DATE='2026-10-14'
base=[x for x in json.load(open('/tmp/hyundai-research/before.json')) if 'inster' in x['id'] or 'kona' in x['id']]
oldfeatures=json.load(open('/tmp/hyundai-research/features-before.json'))
sources=json.load(open(B/'source-index.json'))
sourceby={x['key']:x for x in sources}
for s in sources:
 s['supports']='Fresh read of Australian named model/version evidence; exact scope is recorded in each dependent claim. Dealer advertisements establish advertised condition only, never physical stock.'
 if s.get('identicalToPrior') and s.get('file'):
  s['note']='Fresh source bytes match the 10 October capture SHA256. Existing exact-column assertions and source locators re-reviewed against identical source; new core aliases have explicit basis below.'
 if 'inster_2027_news'==s['key']:s['published_date']='2026-10-08';s['note']='Article updated 8 October 2026 with Hyundai Australia information; originally published 2 October. Model-year and deleted-equipment evidence is secondary, not maker direct.'
 if s.get('error'):s['supports']='Unsuccessful direct read or removed listing; not factual support for a vehicle specification.'
 if s['key']=='kona_config':s['supports']='Disabled legacy configuration with no colours. Not the current SX2.V3/MY27 range. Current configurations use modelname=kona.'

def fact(key,value,basis,src,grade='confirmed',comparison=None,reason=None,**kw):
 d={'key':key,'value':value,'basis':basis,'comparison':basis if comparison is None else comparison,'grade':grade,'sourceKeys':src,'reason':reason or 'Fresh Australian maker source explicitly lists this named version, battery/drivetrain or shared body measurement.','evidenceScope':'secondary_or_sibling' if grade=='reported' else 'searched_not_found' if grade=='not_published' else 'exact_au_version'}
 d.update(kw);return d

def put(v,f):
 v['facts']=[x for x in v['facts'] if x['key']!=f['key']]+[f]
def feature(v,criterion,value,keys,grade='confirmed',conditions='',reason='Current evidence supports the named version equipment and its cited dependencies.',**kw):
 v['features']=[x for x in v['features'] if x['criterion']!=criterion]+[dict(criterion=criterion,value=value,keys=keys,grade=grade,conditions=conditions,reason=reason,**kw)]
def fkeys(v,*need):
 return [x['key'] for x in v['facts'] if all(n.lower() in x.get('label',x['key']).lower() for n in need) and not x['key'].startswith('option_')]

VS=[]
for n,old in enumerate(base):
 inster='inster' in old['id']; cross='cross' in old['id']; spec='inster_specs_aug2026' if inster else 'kona_specs_my27'; conf='inster_config' if inster else 'kona_current_config'; page='inster_page' if inster else 'kona_page'
 v={'id':old['id'],'model':old['model'],'trim':old['trim'],'modelYear':2027,'drive':'FWD','metadata':{'year':2027,'generation':'AX.V2 MY27; current two-grade range, August 2026 linked technical sheet' if inster else 'SX2.V3 MY27; current Australian specification'},'metadataReason':'Current two-grade maker API and August linked brochure match the MY27 lineup reported by CarExpert on 8 October. Source filename MY26 does not establish an older delivered identity; removed internal V2L, heat pump and emergency cable are reviewed separately.' if inster else 'Current official MY27 file, exact four battery/grade combinations; N Line remains a non-additive Premium option.','facts':[],'features':[],'availability':{'state':'current_or_order_listed','sourceKeys':[page,conf,spec],'orderStatus':'listed_unconfirmed','stockStatus':'unverified','qualifications':['Current maker Australian range/configuration listing; no factory order acceptance, physical stock or delivery date independently verified.'],'reason':'Current enabled maker configuration has the named version and selectable paint choices.'}}
 for key,f in old['facts'].items():
  if f['value'] is None or any('warranty' in key or 'roadside' in key or 'soh_warranty' in key for _ in [0]):continue
  sk=[s.replace('r10_hy_','') for s in f['sourceIds']]
  if not sk:raise Exception(('No source',key))
  grade='reported' if any('ancap' in s or ('new_' in s) for s in sk) else 'check' if key.startswith('option_') else 'confirmed'
  quals=[q for q in f['qualifications'] if not any(t in q for t in ['do not backfill','delivered VIN','epoch conflict','not promoted to verified','Ambiguous source-labelled','Cathode chemistry subtype'])]
  nf=fact(key,copy.deepcopy(f['value']),f['basis'],sk,grade,comparison='',label=f['label'],unit=f.get('unit',''),qualifications=quals,reason='Fresh source capture is byte-identical to the prior reviewed exact-column source; claim and column locator retained. Generic build/MY and laboratory caveats do not make this conditional.')
  if key.startswith('option_'):nf['condition']='Only with the separately selected Premium N Line option pack; this is not base Premium standard specification.'
  if f.get('status') in ['unavailable','not_applicable','optional']:nf['status']=f['status']
  if nf.get('status')=='optional':nf['grade']='check';nf['condition']='The cited table marks this item optional; the buyer must select the applicable option.'
  v['facts'].append(nf)
 # Current prices, explicit national offers
 pi=('inster_price_inster_cross' if cross else 'inster_price_inster') if inster else 'kona_price_'+str(n-2)
 price=json.load(open(S/(pi+'.json')));priceval=price['mlpFromPIM']
 put(v,fact('price_aud',priceval,"Maker's list price before on-road costs",[pi],comparison='Before on-road costs',priceRung=1,basisTag="Maker's list price",priceTag="Maker's list price",rankingEligible=True,originalBasis='mlpFromPIM',sourcePointer='mlpFromPIM',qualifications=['Excludes on-road costs and extra-cost paint/options.'],reason='Exact named public maker variant-price endpoint explicitly publishes MLP. mlpFromPIM is the retail list-price field; no pre-LCT arithmetic or component sum.'))
 cfg=json.load(open(S/(conf+'.json')))[0];cv=next(x for x in cfg['variants'] if x['id']==price['variantId']);of=next(o for p in cv['offerPackages'] for o in p['offers'] if o['type']=='Driveaway Offer')
 put(v,fact('promotional_driveaway_aud',float(of['formattedValue'].replace('$','').replace(',','')),'National driveaway offer through 31 December 2026',[conf,pi],'check',comparison='Driveaway',priceRung=2,basisTag='National driveaway offer',priceTag='National driveaway offer',rankingEligible=True,originalBasis=of['formattedValue']+' Driveaway',sourcePointer='variants['+str(cfg['variants'].index(cv))+'].offerPackages > Driveaway Offer',validUntil='2026-12-31',condition=of['disclaimer'],reason='Enabled maker configurator explicitly labels this offer National, names the exact version and states the purchase/delivery window and exclusions.'))
 for key,va,ba,co in [('range_km',old['facts']['range_km']['value'],'WLTP combined','WLTP combined'),('battery_kwh',old['facts']['battery_kwh']['value'],'Published battery capacity; gross/usable not specified','Published capacity, gross/usable unspecified'),('ac_kw',old['facts']['ac_kw']['value'],'Maximum onboard AC charging power','AC kW'),('power_kw',old['facts']['power_kw']['value'],'Manufacturer motor maximum power; single motor','Manufacturer total power'),('drive','FWD','Front-wheel drive','Drive type'),('length_mm',old['facts']['length_mm']['value'],'Manufacturer overall body length','Body mm'),('width_mm',old['facts']['width_mm']['value'],'Manufacturer width; mirror inclusion not specified',''),('height_mm',old['facts']['height_mm']['value'],'Manufacturer height including roof rails','Body mm')]:put(v,fact(key,va,ba,[spec],comparison=co))
 put(v,fact('dc_peak_kw',120 if inster else 100,'Manufacturer-labelled DC charging capacity',[spec],comparison='DC peak kW',reason='Technical sheet explicitly lists Charging capacity in the On-board DC fast charger block, separate from the 50/100/120/350 kW station timing rows. This uses the capacity row directly, not test-station output. No guarantee of sustained power.',qualifications=['Maker calls this DC charging capacity; charging curve and sustained rates are not specified.']))
 put(v,fact('dc_charging_capacity_declared',120 if inster else 100,'Manufacturer-labelled DC charging capacity',[spec],comparison='DC peak kW',label='Published DC charging capacity',unit='kW',reason='Capacity row directly published separately from station timing rows; no use of battery motor-output row.'))
 put(v,fact('dc_charge_time_min',30 if inster else 43,'DC 10–80% on a '+('120' if inster else '350')+' kW station',[spec],'check',comparison='DC 10–80%',condition='Requires the specified '+('120' if inster else '350')+' kW DC station and suitable charging conditions; the separate 50 kW station time is '+('58' if inster else '65')+' minutes.',qualifications=['Station rating is not vehicle acceptance.']))
 # Cargo minimum remains unranked: load/seat configuration not defined
 put(v,fact('boot_l',280 if inster else 407,'VDA rear cargo minimum; seat/load arrangement unspecified',[spec],comparison='',label='Rear cargo, manufacturer minimum',unit='L',evidenceScope='explicit_au_range',qualifications=['Do not relabel this as a verified seats-up loading measurement.']))
 put(v,fact('max_total_cargo_l',1059 if inster else 1241,'VDA rear cargo maximum; seat/load arrangement unspecified',[spec],comparison='',label='Rear cargo, manufacturer maximum',unit='L',evidenceScope='explicit_au_range'))
 if inster:
  put(v,fact('seats',4,'Seating positions',['inster_brochure_aug2026'],comparison='Seats',evidenceScope='explicit_au_range',sourcePointer='Brochure opening interior text: Seating four with ease'))
  put(v,fact('zero_to_100_s',10.6 if cross else 11.7,'Reported 0–100 km/h claim for matching 49/42 kWh powertrain',['inster_2025_launch_ce','inster_2027_news'],'reported',comparison='0–100 km/h',reason='Australian launch report gives 11.7/10.6 seconds; 8 October MY27 report states no further mechanical changes. Current maker sheet omits acceleration; retained as Reported carryover, not Confirmed.'))
  for k,label in [('heat_pump','Heat pump'),('v2l_internal','Interior V2L outlet'),('portable_charge_cable_included','Emergency charging cable included')]:put(v,fact(k,False,label+' deleted for MY27',['inster_2027_news'],'reported',comparison='',reason='CarExpert 8 October update explicitly reports Hyundai Australia confirmation of this MY27 deletion. Current August maker sheet omits the earlier row, but absence alone is not used as proof.',status='unavailable'))
 else:
  put(v,fact('seats',5,'Seating positions',['kona_premium_new_alan' if n==5 else 'kona_elite_new_melville' if n==4 else 'kona_base_new_country'],'reported',comparison='Seats',reason='Exact MY27 Premium/Elite dealer ad or MY27 base body ad explicitly lists five seats. Base battery is unresolved in the dealer source, so that shared-body seating evidence remains Reported. Manufacturer technical sheet/model page do not explicitly print a total.',sourcePointer='Dealer Vehicle Details > Seats'))
  put(v,fact('zero_to_100_s',9.9 if n==2 else 7.6,'Reported 0–100 km/h',['kona_ce_2027'],'reported',comparison='0–100 km/h',reason='CarExpert MY2027 exact powertrain comparison lists 9.9 seconds for 99 kW base and 7.6 seconds for each 150 kW EV grade. Maker technical sheet omits acceleration; Reported and unranked.'))
 if not inster:
  put(v,fact('max_total_cargo_l',1241,'VDA rear cargo with rear seats folded',[spec,page],comparison='VDA, seats folded',label='Rear cargo with seats folded',unit='L',evidenceScope='explicit_au_range',reason='Current maker model-page FAQ explicitly labels 1241 L with rear seats folded; technical sheet identifies the same maximum as VDA. Minimum 407 L remains unranked because its occupied-seat/loading basis is not explicit.'))
 # Towing explicit unknown for unrated versions, never turn dash into zero
 if inster or n==2:
  put(v,fact('towing_braked_kg',None,'No published braked trailer rating',[spec,page],'not_published',comparison='',reason='The exact technical table shows a dash for braked towing and the current model page publishes no applicable rating. No numeric zero or sibling towing limit has been inferred.'))
 else:
  put(v,fact('towing_braked_kg',750,'Maximum braked trailer mass',[spec],comparison='Braked towing kg',qualifications=['Suitable towing hardware is required; respect GVM, axle and towball limits.']))
 put(v,fact('home_charge_time_7kw_h',None,'7 kW home-charging time not published',[spec,page],'not_published',comparison='',reason='Maker technical sheet supplies AC 10–100% timing at 240 V without phase/current; model page does not establish a timed 7 kW charge. Do not treat it as 7 kW or calculate a substitute.'))
 # Refresh every known effective equipment row
 for ofeat in oldfeatures:
  if ofeat['variant_id']!=old['id'] or ofeat['status']=='not_verified' or ofeat['criterion'] in ['driveaway_price','roadside_assistance','warranty_service']:continue
  c=ofeat['criterion']; keys=[];value=ofeat['value'];gr='confirmed';cond=''
  if c=='storage':keys=['boot_l','max_total_cargo_l']+([] if inster else ['frunk_l']);value=('280 / 1,059 L' if inster else '407 / 1,241 L')+' VDA rear cargo minimum / maximum'+('' if inster else ' · separate 27 L VDA front cargo');cond='Rear minimum seat/load arrangement is not explicitly defined; minimum and maximum are not added together.' if inster else '407 L VDA minimum loading basis is not explicitly defined. The maker labels 1,241 L as rear seats folded. Front and rear volumes are separate.'
  elif c=='energy_use':keys=['energy_consumption','range_test_method'];value=str(old['facts']['energy_consumption']['value'])+' kWh/100 km · WLTP combined'
  elif c=='battery_chemistry':keys=['battery_chemistry'];value='Lithium-ion; maker does not specify cathode chemistry'
  elif c=='home_charging':keys=['ac_kw','ac_charge_time10to100','home_charge_time_7kw_h'];value=str(old['facts']['ac_kw']['value'])+' kW onboard AC maximum · '+str(old['facts']['ac_charge_time10to100']['value'])+' minutes for the published AC 10–100% test · 7 kW home timing not published';gr='check';cond='The source states 240 V but does not establish phase/current for the timing; do not treat this as a 7 kW wallbox time.'
  elif c=='spare_tyre':keys=['spare'];value=old['facts']['spare']['value']
  elif c=='safety_ancap':keys=['ancap_rating','ancap_year','ancap_scores','ancap_expiry'];gr='reported';value='4-star ANCAP rating · '+('2025' if inster else '2023')+' test year · current report expiry December 2031';cond='ANCAP body/variant applicability and protocol year apply.'
  elif c=='automatic_seat_climate':keys=fkeys(v,'Auto Comfort Control');value='Auto Comfort Control fitted' if any(x['value'] for x in v['facts'] if x['key'] in keys) else 'Auto Comfort Control not fitted'
  elif c=='front_heated_seats':keys=fkeys(v,'Heated seats');value='Heated front seats fitted' if any(x['value'] for x in v['facts'] if x['key'] in keys) else 'Heated front seats not fitted'
  elif c=='front_ventilated_seats':keys=fkeys(v,'Ventilated seats');value='Ventilated front seats fitted' if any(x['value'] for x in v['facts'] if x['key'] in keys) else 'Ventilated front seats not fitted'
  elif c=='rear_heated_seats':keys=fkeys(v,'Heated outboard');value='Heated rear outboard seats fitted' if any(x['value'] for x in v['facts'] if x['key'] in keys) else 'Heated rear seats not fitted'
  elif c=='heated_steering_wheel':keys=fkeys(v,'Heated steering wheel');keys=[k for k in keys if 'auto_comfort' not in k];value='Heated steering wheel fitted' if any(x['value'] for x in v['facts'] if x['key'] in keys) else 'Heated steering wheel not fitted'
  elif c=='glass_roof':keys=fkeys(v,'Full width glass sunroof');value='Tilt-and-slide glass sunroof fitted' if any(x['value'] for x in v['facts'] if x['key'] in keys) else 'Glass sunroof not fitted'
  elif c=='carplay_android_auto':keys=fkeys(v,'Apple CarPlay');value='Apple CarPlay and Android Auto compatibility';gr='check';cond='Requires a compatible phone and connection; this row does not establish wireless operation.'
  else:raise Exception(('Unmapped feature',c))
  if not keys:raise Exception(('No deps',c,v['id']))
  feature(v,c,value,keys,gr,cond,status=ofeat['status'] if ofeat['status'] in ['unavailable','optional','not_applicable'] else ('conditional' if gr in ['reported','check'] else 'standard'))
 # useful newly resolved features and intrinsic anchors
 ks=fkeys(v,'Personalised User Profile');
 if ks:feature(v,'driver_profiles_local','Three local user profiles: Driver 1, Driver 2 and Guest',ks)
 feature(v,'performance_rear_motor',str(old['facts']['power_kw']['value'])+' kW single front motor · front-wheel drive',['power_kw','drive'])
 if inster:
  feature(v,'heat_pump','Heat pump removed for MY27',['heat_pump'],'reported',reason='CarExpert reports Hyundai Australia confirmation; keep MY27 separate from residual MY26.',status='unavailable')
  feature(v,'charging_cable','Emergency charging cable no longer included for MY27',['portable_charge_cable_included'],'reported',status='unavailable')
  feature(v,'v2l','External V2L up to 3.6 kW with an extra-cost adaptor · no interior V2L outlet',['v2l_output','v2l_adapter_included','v2l_internal'],'reported','External adaptor purchased separately; comply with output and device limits. Interior outlet deletion is reported by CarExpert.')
 if inster:
  st={'label':'Small footprint','text':'At '+str(old['facts']['length_mm']['value'])+' mm long and 1,610 mm wide, it is easy to size up for a tight parking space.','keys':['length_mm','width_mm']}
  tr={'label':'Four seats only','text':'There are four seats, so it cannot carry a fifth occupant.','keys':['seats']}
 elif n==2:
  st={'label':'Useful front storage','text':'A separate 27 L VDA front compartment adds a place for charging gear.','keys':['frunk_l']};tr={'label':'Plan rapid-charge stops','text':'The stated DC 10–80% charge takes 43 minutes on a 350 kW station.','keys':['dc_charge_time_min']}
 elif n==3:
  st={'label':'505 km WLTP range','text':'The 17-inch-wheel configuration is rated for 505 km WLTP combined.','keys':['range_km','wheel_diameter']};tr={'label':'Light towing only','text':'Braked towing is limited to 750 kg.','keys':['towing_braked_kg']}
 elif n==4:
  ks=fkeys(v,'Heated seats');st={'label':'Heated front seats','text':'Heated front seats are included for cold-weather comfort.','keys':ks};tr={'label':'444 km WLTP range','text':'The 19-inch-wheel configuration is rated for 444 km WLTP combined.','keys':['range_km','wheel_diameter']}
 else:
  ks=fkeys(v,'Ventilated seats');st={'label':'Ventilated front seats','text':'Ventilated front seats add warm-weather comfort.','keys':ks};tr={'label':'Light towing only','text':'Braked towing is limited to 750 kg.','keys':['towing_braked_kg']}
 v['summary']={'strength':st,'tradeoff':tr};VS.append(v)

# Genuine residual-New MY26 Extended Range, a distinct epoch and not current factory configuration
legacy={'id':'hyundai_inster_my26_extended_range_49_fwd_residual__20261014','modelId':'hyundai_inster_current','model':'INSTER','trim':'Extended Range 49 kWh FWD (MY26 residual new)','modelYear':2026,'drive':'FWD','isNew':True,'metadata':{'year':2026,'generation':'AX.V1 MY26; residual new dealer advertisement, March 2026 build'},'metadataReason':'Midland exact New advertisement identifies MY26 AX.V1, 49 kWh, stock 620261783 and VIN KMHB2511UTW080494. Do not inherit current MY27 equipment deletions.','availability':{'state':'current_or_order_listed','sourceKeys':['inster_midland_new_620261783','inster_specs_legacy_my26'],'orderStatus':'unverified','stockStatus':'new_stock_listed','qualifications':['Residual New dealer advertisement only: Midland Hyundai WA, stock 620261783, VIN KMHB2511UTW080494, 10 km, build March 2026.','Not a current MY27 factory configuration; physical stock, order acceptance and delivery are unverified.'],'reason':'Fresh direct exact-unit advertisement still says New and shows $40,990 driveaway; no sold marker in the unit record.'},'facts':[],'features':[]}
# Copy only independently checked common non-equipment technical rows from legacy 49kWh sheet, never blanket MY27 feature carryover
spec='inster_specs_legacy_my26'
vals={'range_km':(360,'WLTP combined','WLTP combined'),'battery_kwh':(49,'Published capacity; gross/usable unspecified','Published capacity, gross/usable unspecified'),'dc_peak_kw':(120,'Manufacturer-labelled DC charging capacity','DC peak kW'),'dc_charge_time_min':(30,'DC 10–80% on a 120 kW DC station','DC 10–80%'),'ac_kw':(10.5,'Maximum onboard AC charging power','AC kW'),'boot_l':(280,'VDA rear cargo minimum; loading configuration unspecified',''),'max_total_cargo_l':(1059,'VDA rear cargo maximum; loading configuration unspecified',''),'power_kw':(84.5,'Manufacturer single motor maximum power','Manufacturer total power'),'drive':('FWD','Front-wheel drive','Drive type'),'length_mm':(3825,'Manufacturer body length','Body mm'),'width_mm':(1610,'Manufacturer width; mirror inclusion unspecified',''),'height_mm':(1610,'Manufacturer height including roof rails','Body mm'),'wheelbase_mm':(2580,'Wheelbase','Wheelbase mm'),'ground_clearance_mm':(144,'Ground clearance','Ground clearance mm'),'turning_circle_m':(10.6,'Minimum turning circle between kerbs/walls','Turning circle m'),'torque_nm':(147,'Motor maximum torque','Nm'),'energy_consumption':(15.1,'WLTP combined energy consumption','WLTP kWh/100km'),'battery_chemistry':('Lithium-ion','Maker battery type; cathode chemistry not specified',''),'wheel_diameter':(17,'Standard wheel diameter','Wheel inches'),'tyres':('205/45 R17','Standard tyre size',''),'spare':('Tyre Mobility Kit','No spare wheel; mobility kit supplied',''),'heat_pump':(True,'High-efficiency heat pump fitted to MY26',''),'v2l_internal':(True,'Interior domestic three-pin V2L outlet fitted',''),'v2l_output':(3.6,'Maximum V2L output','V2L kW'),'portable_charge_cable_included':(True,'Portable emergency cable with 230 V 10 A input',''),'ac_charge_time10to100':(275,'AC 10–100% at stated 240 V; phase/current unspecified','AC 10–100%'),'front_heated_seats':(False,'MY26 Extended Range heated front seat fitment',''),'front_ventilated_seats':(False,'MY26 Extended Range ventilated front seat fitment',''),'heated_steering_wheel':(False,'MY26 Extended Range heated steering wheel fitment',''),'glass_roof':(False,'MY26 Extended Range glass sunroof fitment',''),'carplay_android_auto':(True,'Apple CarPlay / Android Auto compatibility',''),'driver_profiles_local':(True,'Three local profiles: Driver 1, Driver 2, Guest',''),'isofix_points':(2,'Rear ISOFIX positions','ISOFIX points'),'top_tether_points':(2,'Rear top-tether positions','Top tether points')}
for k,(val,ba,co) in vals.items():
 f=fact(k,val,ba,[spec],comparison=co,reason='Fresh live legacy MY26 maker sheet explicitly lists the Extended Range/49 kWh column, matched to a genuine MY26 AX.V1 New dealer advertisement. Current MY27 equipment is not inherited.')
 if k in ['dc_charge_time_min','ac_charge_time10to100','v2l_output']:f['grade']='check';f['condition']='Use the stated supply/SOC or output limits; external V2L requires the separately purchased adaptor.' if k=='v2l_output' else 'Timing applies only to the stated supply and state-of-charge window.'
 if val is False:f['status']='unavailable'
 legacy['facts'].append(f)
put(legacy,fact('price_aud',40990,'Dealer advertised driveaway price',['inster_midland_new_620261783'],'reported',comparison='Driveaway',priceRung=6,basisTag='Dealer ad',priceTag='Dealer ad',rankingEligible=False,publisher='Midland Hyundai',originalBasis='$40,990 Drive Away',sourcePointer='Exact stock 620261783: headline and Vehicle Details Price',reason='Current residual New unit is offered at $40,990 driveaway. Removed from current maker configurator; old launch prices are not current price evidence for this residual unit. No higher current applicable price rung found.'))
put(legacy,fact('seats',4,'Seating positions',['inster_midland_new_620261783'],'reported',comparison='Seats',sourcePointer='Vehicle Details > Body Type: SUV, 4 doors, 4 seats',reason='Exact New MY26 unit explicitly lists four seats; no current MY27 body claim is silently transferred.'))
put(legacy,fact('zero_to_100_s',10.6,'Reported 0–100 km/h',['inster_2025_launch_ce'],'reported',comparison='0–100 km/h',reason='Australian launch specification explicitly reports this Extended Range 49 kWh 84.5 kW powertrain; current live legacy maker sheet omits acceleration.'))
put(legacy,fact('towing_braked_kg',None,'No published braked trailer rating',[spec,'inster_midland_new_620261783'],'not_published',comparison='',reason='Legacy maker table gives a dash; exact dealer unit details do not establish a braked towing rating. Do not convert the dash to zero or borrow another model limit.'))
put(legacy,fact('home_charge_time_7kw_h',None,'7 kW home-charging time not published',[spec,'inster_midland_new_620261783'],'not_published',comparison='',reason='The legacy maker gives 240 V 10–100% timing without phase/current; exact dealer unit does not publish a timed 7 kW charge.'))
feature(legacy,'storage','280 / 1,059 L VDA rear cargo minimum / maximum',['boot_l','max_total_cargo_l'],conditions='Rear seat/load arrangement is not defined; minimum and maximum are not added together.')
feature(legacy,'heat_pump','High-efficiency heat pump fitted to MY26',['heat_pump'])
feature(legacy,'charging_cable','Portable emergency charging cable included · 230 V / 10 A input',['portable_charge_cable_included'])
feature(legacy,'v2l','Interior V2L outlet · up to 3.6 kW output',['v2l_internal','v2l_output'],'check','Observe device/output limits; external adaptor is an extra-cost accessory.')
feature(legacy,'home_charging','10.5 kW onboard AC maximum · 275 minutes for the stated 240 V AC 10–100% test · 7 kW time not published',['ac_kw','ac_charge_time10to100','home_charge_time_7kw_h'],'check','Supply phase/current unspecified for maker timing; not a verified 7 kW wallbox time.')
feature(legacy,'energy_use','15.1 kWh/100 km · WLTP combined',['energy_consumption'])
feature(legacy,'battery_chemistry','Lithium-ion; cathode chemistry not stated by maker',['battery_chemistry'])
feature(legacy,'spare_tyre','Tyre Mobility Kit',['spare'])
for c,label in [('front_heated_seats','Heated front seats'),('front_ventilated_seats','Ventilated front seats'),('heated_steering_wheel','Heated steering wheel'),('glass_roof','Glass sunroof')]:feature(legacy,c,label+' not fitted',[c],status='unavailable')
feature(legacy,'carplay_android_auto','Apple CarPlay and Android Auto compatibility',['carplay_android_auto'],'check','Requires compatible phone and connection.')
feature(legacy,'driver_profiles_local','Three local profiles: Driver 1, Driver 2 and Guest',['driver_profiles_local'])
legacy['summary']={'strength':{'label':'Heat pump retained','text':'This residual MY26 Extended Range includes a heat pump and interior V2L outlet.','keys':['heat_pump','v2l_internal']},'tradeoff':{'label':'Four seats only','text':'The exact New dealer advertisement lists four seats, so there is no fifth seating position.','keys':['seats']}}
VS.append(legacy)
# nested Premium N Line pricing on retained option facts
prem=VS[5];pp=json.load(open(S/'kona_price_4.json'))
put(prem,fact('option_0_price_aud',pp['mlpFromPIM'],'MLP for Premium with N Line package',['kona_price_4','kona_current_config'],'check',comparison='Before on-road costs',condition='Requires the separately selected Premium N Line package. Do not add the duplicated optionPacks price to this already configured-version MLP.',label='Premium N Line configured list price',unit='AUD'))
put(prem,fact('option_0_promotional_driveaway_aud',65990,'National Premium N Line driveaway offer',['kona_current_config','kona_price_4'],'check',comparison='Driveaway',condition='Premium N Line configuration with no further options, bought and delivered 1 October–31 December 2026 at participating dealers; excludes fleet/government/rental and combining offers.',label='Premium N Line national driveaway offer',unit='AUD'))
# Source lookup validation, existing non-null closure
for v in VS:
 for f in v['facts']:
  assert all(k in sourceby and sourceby[k].get('file') for k in f['sourceKeys']),(v['id'],f['key'],f['sourceKeys'])
  if f['grade']=='not_published':assert f['value'] is None and len({sourceby[k]['url'] for k in f['sourceKeys']})>=2
  if f['grade']=='check':assert f.get('condition'),(v['id'],f['key'])
 for f in v['features']:
  assert all(k in {f['key'] for f in v['facts']} for k in f['keys']),(v['id'],f)
 for side in ['strength','tradeoff']:assert all(k in {f['key'] for f in v['facts']} for k in v['summary'][side]['keys'])
out={'reviewedAt':DATE,'sources':sources,'variants':VS,'supplementalConfigurations':[{'parentVariantId':prem['id'],'name':'Premium with N Line option pack','additive':False,'makerVariantId':pp['variantId'],'priceAud':pp['mlpFromPIM'],'sourceKeys':['kona_current_config','kona_price_4','kona_specs_my27'],'dependencyKeys':['option_0_price_aud','option_0_promotional_driveaway_aud','option_0_length','option_0_range','option_0_wheel_diameter'],'note':'Configured premium package has 4385 mm length and 444 km WLTP. Existing option_0 equipment/facts refreshed from exact N Line column; not a fifth additive battery/grade identity.'}],'familyNotes':['INSTER current lineup is two MY27 configurations; retain prior exact IDs with metadata updated, not two duplicate new records. MY26 filename retained as source URL, not used to copy equipment from earlier MY26 sheet.','Current INSTER August PDF and brochure are byte-identical to earlier capture and already omit internal V2L/portable charging; new MY27 deletion facts use the 8 Oct CarExpert report.','Residual New MY26 AX.V1 Extended Range is added separately, based on exact unsold New unit and distinct legacy PDF columns.','KONA source modelname=kona-electric is disabled obsolete OS-generation API; current EV versions are under modelname=kona.','KONA four core battery/grade versions plus one nested Premium N Line option. No sum of base-plus-pack plus already-configured API price.','Cargo minimum/maximum remains unranked where loading basis is not stated. All DC timing uses canonical DC 10–80%; capacity rows are not station inference.','Vehicle/battery warranty, roadside and all existing warranty aliases are refreshed by the parent shared brand-terms review.'],'gaps':[{'variantId':v['id'],'key':f['key'],'reason':f['reason'],'sourceKeys':f['sourceKeys']} for v in VS for f in v['facts'] if f['grade']=='not_published']}
(B/'normalized-evidence.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
(B/'source-index.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2)+'\n')
print('Variants',len(VS),'facts',sum(len(v['facts']) for v in VS),'features',sum(len(v['features']) for v in VS))
for v in VS:print(v['id'],len(v['facts']),len(v['features']))
