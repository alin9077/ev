from fetch import *
a=[('kona_current_config','https://www.hyundai.com/content/api/au/hyundai/v3/carpricecalculator?postcode=2000&displaypowertrain=true&modelname=kona','Hyundai Australia','official_au_manufacturer'),('kona_spec_html','https://www.hyundai.com/au/en/cars/eco/kona-electric/specifications','Hyundai Australia','official_au_manufacturer'),('inster_2027_news','https://www.carexpert.com.au/car-news/2027-hyundai-inster-price-cut-lineup-trimmed-in-australia','CarExpert','secondary')]
for v in json.load(open(SD/'inster_config.json'))[0]['variants']:
 a.append(('inster_price_'+v['variantGroup'].replace(' ','_').lower(),'https://www.hyundai.com/content/api/au/hyundai/v3/variantpricecalculator?variantId='+v['id']+'&optionCost=0&postcode=2000','Hyundai Australia','official_au_manufacturer'))
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:R=list(ex.map(fetch,a))
P=BASE/'source-index.json';D=json.load(open(P));P.write_text(json.dumps(D+R,indent=2))
