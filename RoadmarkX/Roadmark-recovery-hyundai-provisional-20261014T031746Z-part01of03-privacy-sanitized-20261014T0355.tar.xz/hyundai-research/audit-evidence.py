import json,pathlib,collections
R=pathlib.Path('/tmp/hyundai-research');B={c['id']:c for c in json.load(open(R/'before.json')) if c['vehicleClass']=='passenger'};F=json.load(open(R/'features-before.json'));P=json.load(open(R/'hyundai-2026-10-14.json'))
updated={(x['variantId'],x['after']['key']):x['after'] for x in P['facts']}
for t in P['brandTerms']:
 for i in t['applicableVariantIds']:updated[(i,t['key'])]=t['fact']
known_missing=[]
for i,c in B.items():
 for k,f in c['facts'].items():
  if f['value'] is not None and (i,k) not in updated:known_missing.append({'variantId':i,'key':k,'value':f['value'],'grade':f.get('buyerGrade')})
features={(x['variantId'],x['criterion']):x for x in P['features']};missing_features=[]
for f in F:
 if f['variant_id'] not in B or f['criterion'] in ['driveaway_price','roadside_assistance']:continue
 if f.get('buyerGrade') in ['confirmed','check','reported'] and f.get('status')!='not_verified' and (f['variant_id'],f['criterion']) not in features:missing_features.append({'variantId':f['variant_id'],'criterion':f['criterion'],'value':f['value'],'grade':f.get('buyerGrade')})
newIds={v['id'] for v in P['variants']};core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty','battery_warranty'];core_missing=[(i,k) for i in list(B)+list(newIds) for k in core if (i,k) not in updated]
rows={'inheritedKnownFacts':sum(f['value'] is not None for c in B.values() for f in c['facts'].values()),'missingKnownFactReviews':known_missing,'missingKnownEquipmentReviews':missing_features,'missingCoreReviews':core_missing,'versionCount':len(B)+len(newIds),'specificFactCount':len(P['facts']),'featureCount':len(P['features']),'sourceCount':len(P['sources']),'newVersionIds':sorted(newIds)}
(R/'evidence-completeness-audit.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n');print(json.dumps(rows,indent=2,ensure_ascii=False));assert not known_missing and not missing_features and not core_missing
