import re
PROSE_KEYS={'reason','condition','conditions','basis','note','supports','residuals','resolution','result','blocker','qualifications','metadataReason','text','searchLimits','warrantyHandling','inheritedReview','status'}
REPLACEMENTS={'AC10hours':'AC 10 hours','OriginalMY26':'Original MY26','base6-way':'base 6-way','copied14-way':'copied 14-way','currentMY27':'current MY27','CurrentMY27':'Current MY27','display119668':'display 119668','driveaway128977':'driveaway 128977','maximum150':'maximum 150','neither404':'neither 404','optionalDSM':'optional DSM','phase16A':'phase 16 A','portable10hour':'portable 10-hour','residualMY26':'residual MY26','returns404':'returns 404','rung4':'rung 4','technical506':'technical 506','web504':'web 504','MLP113204':'MLP 113204','at10.5':'at 10.5','NocturneGrey':'Nocturne Grey','IONIQ9':'IONIQ 9','pre-LCT MLP113':'pre-LCT MLP 113','four months ago; fresh':'four months ago; fresh'}
def prose(s):
 for a,b in REPLACEMENTS.items():s=s.replace(a,b)
 s=re.sub(r'(\d)(January|February|March|April|May|June|July|August|September|October|November|December)',r'\1 \2',s)
 s=re.sub(r'(January|February|March|April|May|June|July|August|September|October|November|December)(\d)',r'\1 \2',s)
 s=re.sub(r'(\d)(kW|kWh|hours?|km|L|kg|A)\b',r'\1 \2',s)
 s=re.sub(r'\b(publication|re-retrieved|stock|VIN)(?=\d)',r'\1 ',s)
 s=s.replace('output is not DC peak.150','output is not DC peak. 150').replace('350kW /','350 kW /')
 return s

def clean(obj,key=''):
 if isinstance(obj,dict):return {k:clean(v,k) for k,v in obj.items()}
 if isinstance(obj,list):return [clean(v,key) for v in obj]
 if isinstance(obj,str) and key in PROSE_KEYS:return prose(obj)
 return obj
