import json,httpx,hashlib,pathlib,concurrent.futures,subprocess
import re,html
D=pathlib.Path('/tmp/hyundai-research/elexio-ioniq9/sources')
def fetch(s):
 key=s.get('key',s.get('id'));url=s['url'];p0=D/(key+'.download');h=D/(key+'.headers');meta=subprocess.check_output(['curl','-sSL','--max-time','90','-D',str(h),'-o',str(p0),'-w','%{http_code}\n%{content_type}\n%{url_effective}',url],text=True).split('\n');status=int(meta[0]);ct=meta[1];final=meta[2];raw=p0.read_bytes();rawtext=raw.decode('utf-8',errors='replace');ext='pdf' if 'pdf' in ct else 'json' if 'json' in ct else 'html';p=D/(key+'.'+ext);p0.rename(p)
 if ext=='pdf':subprocess.run(['pdftotext','-layout',str(p),str(D/(key+'.txt'))]);t=(D/(key+'.txt')).read_text()
 else:t=rawtext if ext=='json' else html.unescape(re.sub('<[^>]+>',' ',re.sub(r'<(script|style)\b[^>]*>.*?</\1>','',rawtext,flags=re.S)));(D/(key+'.txt')).write_text(t)
 return dict(key=key,url=url,title=s.get('title',key.replace('_',' ')),publisher=s.get('publisher','Hyundai Australia' if 'hyundai.com/' in url else 'Dealer' if any(x in key for x in ['keema','werribee','mackay','gilbert']) else 'ANCAP'),source_type='manufacturer' if 'hyundai.com/' in url else 'dealer' if any(x in key for x in ['keema','werribee','mackay','gilbert','stock']) else 'independent',published_date=s.get('publicationDate'),accessed_date='2026-10-14',market='AU',file=str(p),textFile=str(D/(key+'.txt')),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),status=status,finalUrl=final,previousHash=s.get('sha256'),sameAsPrevious=s.get('sha256')==hashlib.sha256(raw).hexdigest())
if __name__=='__main__':
 old=json.load(open('/workspace/scratch/586427eef9f2/roadmark-104/data/remaining-hyundai-evidence.json'))
 ss=[s for s in old['sourceRegistry'] if any(n in s['id'] for n in ['elexio','ioniq9'])]
 out=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
  for s in pool.map(fetch,ss):out.append(s); print(s['key'],s['status'],s['bytes'],s['sameAsPrevious'],flush=True)
 json.dump(out,open(D.parent/'sources.json','w'),indent=2)
