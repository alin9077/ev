from fetch import *
ss=[]
for n in ['elexio','ioniq9']:
 d=json.load(open(D/(n+'_configurator.json')))[0]
 for i,v in enumerate(d['variants']):ss.append(dict(key=n+'_price_'+str(i),url='https://www.hyundai.com/content/api/au/hyundai/v3/variantpricecalculator?variantId='+v['id']+'&optionCost=0&postcode=2000',title='Hyundai Australia '+v['variantGroup']+' price breakdown'))
ss += [dict(key='ioniq9_hopper_n41761',url='https://www.hoppermotorgroup.com.au/cars/new-grey-2026-hyundai-ioniq-9-n41761'),dict(key='ioniq9_specs_my26',url='https://www.hyundai.com/content/dam/hyundai/au/en/models/ioniq-9-2025/docs/Hyundai-IONIQ-9-Specification-Sheet.pdf'),dict(key='ioniq9_sydney_new',url='https://www.sydneycityhyundai.com.au/new-cars/'),dict(key='elexio_carexpert',url='https://www.carexpert.com.au/car-reviews/2026-hyundai-elexio-review',publisher='CarExpert'),dict(key='ioniq9_carexpert',url='https://www.carexpert.com.au/car-reviews/2025-hyundai-ioniq-9-review',publisher='CarExpert')]
out=json.load(open(D.parent/'sources.json'))
for s in ss:
 try:
  r=fetch(s);out.append(r);print(r['key'],r['status'],r['bytes'],r['finalUrl'],flush=True);json.dump(out,open(D.parent/'sources.json','w'),indent=2)
 except Exception as e:print(s,e,flush=True)
