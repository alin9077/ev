import json,pathlib,hashlib,collections
D=pathlib.Path('/tmp/hyundai-research/elexio-ioniq9');x=json.load(open(D/'normalized-evidence.json'));b=json.load(open('/tmp/hyundai-research/before.json'));oldfeatures=json.load(open('/tmp/hyundai-research/features-before.json'))
terms={'warranty','battery_warranty','roadside_assistance','vehicle_warranty_standard','vehicle_warranty_conditional_extended','vehicle_warranty_commercial','battery_warranty_terms','battery_warranty_capacity_threshold','roadside_support_initial'}
source={s['key']:s for s in x['sources']};errors=[];coverage=[]
for s in source.values():
 for pathkey,hashkey in [('file','sha256'),('textFile','textSha256')]:
  p=pathlib.Path(s[pathkey])
  if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=s[hashkey]:errors.append(['bad source hash',s['key'],pathkey])
 if not isinstance(s['supports'],str):errors.append(['source supports not string',s['key']])
for v in x['variants']:
 facts={f['key']:f for f in v['facts']};feat={f['criterion']:f for f in v['features']}
 if len(facts)!=len(v['facts']):errors.append(['duplicate fact',v['id']])
 for f in facts.values():
  if not f['sourceKeys'] or any(k not in source for k in f['sourceKeys']):errors.append(['bad source keys',v['id'],f['key']])
  if any(source[k]['status']!=200 for k in f['sourceKeys']):errors.append(['failed factual source',v['id'],f['key']])
  if f['grade']=='not_published' and (f['value'] is not None or len(set(f['sourceKeys']))<2):errors.append(['bad not published',v['id'],f['key']])
  if f['grade']=='check' and not f.get('condition'):errors.append(['missing condition',v['id'],f['key']])
 for f in feat.values():
  if not isinstance(f['value'],str) or any(k not in facts for k in f['keys']):errors.append(['bad feature',v['id'],f['criterion']])
 for sm in v['summary'].values():
  if not sm['keys'] or any(k not in facts for k in sm['keys']):errors.append(['bad summary',v['id']])
 old=next((z for z in b if z['id']==v['id']),None)
 if old:
  missingfacts=[k for k,z in old['facts'].items() if z['value'] is not None and k not in terms and k not in facts]
  missingfeatures=[r['criterion'] for r in oldfeatures if r['variant_id']==v['id'] and r['status'] not in ['not_verified','not_published'] and r['criterion'] not in feat and r['criterion'] not in ['warranty_service','roadside_assistance','driveaway_price']]
  if missingfacts or missingfeatures:errors.append(['coverage',v['id'],missingfacts,missingfeatures])
  coverage.append(dict(id=v['id'],requiredInheritedNonNullFacts=sum(z['value'] is not None and k not in terms for k,z in old['facts'].items()),missingFacts=missingfacts,missingKnownFeatures=missingfeatures))
report=dict(localResearchValidationOnly=True,packetGuardsRun=False,variantCount=len(x['variants']),sourceCount=len(source),factCount=sum(len(v['facts']) for v in x['variants']),featureCount=sum(len(v['features']) for v in x['variants']),errors=errors,coverage=coverage,unresolvedLeadCount=1,unresolvedLead='OAG-AD-25622863 exact current condition / seller / identity blocked pending specifically approved CAPTCHA',allOtherScopedResearchReadyForParent=True)
json.dump(report,open(D/'validation.json','w'),indent=2)
manifest={str(p.relative_to(D)):hashlib.sha256(p.read_bytes()).hexdigest() for p in D.rglob('*') if p.is_file() and p.name!='sha256-manifest.json'}
json.dump(manifest,open(D/'sha256-manifest.json','w'),indent=2)
print(json.dumps(report,indent=2))
assert not errors
