import json,pathlib,hashlib
R=pathlib.Path('/tmp/hyundai-research');D='2026-10-14';p=json.load(open(R/'hyundai-2026-10-14.json'))
rows=[]
for s in p['sources']:
 for loc,h in [('capture_locator','capture_sha256'),('capture_text_locator','capture_text_sha256')]:
  if s.get(loc):
   f=R/s[loc];assert f.is_file(),s['id'];assert hashlib.sha256(f.read_bytes()).hexdigest()==s[h],s['id']
 rows.append({**s,'packetId':p['id']})
(R/'source-index.json').write_text(json.dumps({'checkedAt':D,'scope':'Hyundai Australian Tier1 dated M1 research. Full captures and extraction sidecars retained. Source publication dates stay unknown unless an actual exact publication date is established; maker footer filenames are not dates. Independent brand directories do not constitute global C1 closure.','sources':rows},indent=2,ensure_ascii=False)+'\n')
captures=[]
for f in sorted(R.rglob('*')):
 if f.is_file() and ('sources' in f.relative_to(R).parts or f.parent.name=='inherited-source-artifacts'):
  captures.append({'path':str(f.relative_to(R)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(R/'source-hash-manifest.json').write_text(json.dumps({'checkedAt':D,'scope':'All permitted full raw source captures, public web retrievals, extraction sidecars and PDF visual-review assets. Failed, blocked and restricted responses remain documented and are not evidence of absence.','files':captures},indent=2,ensure_ascii=False)+'\n')
core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty','battery_warranty'];idx={s['id']:s for s in p['sources']}
ef=json.load(open(R/'hyundai-effective-facts.json'));pe=json.load(open(R/'normalized-evidence.json'));matrix=[]
for v in pe['variants']:
 fields={}
 for k in core:
  f=ef[v['id']][k];fields[k]={key:f.get(key) for key in ['value','unit','basis','comparisonBasis','buyerGrade','status','conditionExplanation','qualifications','date','validUntil']};fields[k]['reviewReason']=f['gradeReview']['reason'];fields[k]['sourceUrls']=[idx[s]['url'] for s in f['sourceIds']]
 matrix.append({'variantId':v['id'],'model':v['model'],'trim':v['trim'],'modelYear':v.get('metadata',{}).get('year',v.get('modelYear',v.get('model_year'))),'availability':v['availability'],'fields':fields})
(R/'core-matrix.json').write_text(json.dumps({'checkedAt':D,'coreFieldCount':17,'rows':matrix},indent=2,ensure_ascii=False)+'\n')
names=['hyundai-2026-10-14.json','hyundai-reconciliation-2026-10-14.json','brand-model-list-reconciliation.json','source-index.json','source-hash-manifest.json','core-matrix.json','before.json','research-before.json','features-before.json','new-feature-before.json','normalized-evidence.json','terms.json','inherited-inventory-audit.json','staged-report.json','REVIEW.md']
for f in sorted(R.rglob('*')):
 if f.is_file() and f.parent!=R and f.name in ['audit.json','residual-closure.json','archive-closure.json','lead-closure.json','REVIEW.md','review-summary.md','price-ladder-review.json']:names.append(str(f.relative_to(R)))
manifest=[]
for n in names:
 f=R/n;assert f.is_file(),n;manifest.append({'path':n,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(R/'artifact-hash-manifest.json').write_text(json.dumps({'checkedAt':D,'files':manifest},indent=2,ensure_ascii=False)+'\n')
print('Validated',len(rows),'packet source entries and hashed',len(captures),'capture files;',len(manifest),'artifact hashes')
