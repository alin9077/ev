import urllib.request, concurrent.futures,json,pathlib,hashlib,subprocess
from html.parser import HTMLParser
class Text(HTMLParser):
 def __init__(self):super().__init__();self.parts=[];self.skip=0
 def handle_starttag(self,t,a):
  if t in ['script','style','noscript']:self.skip+=1
  if t in ['p','li','h1','h2','h3','tr','td','br','div']:self.parts.append('\n')
 def handle_endtag(self,t):
  if t in ['script','style','noscript'] and self.skip:self.skip-=1
 def handle_data(self,d):
  if not self.skip:self.parts.append(d)
P=pathlib.Path('/tmp/hyundai-research');(P/'sources').mkdir(exist_ok=True)
urls=[('roadside-ev-brochure','https://www.hyundai.com/content/dam/hyundai/au/en/documents/2025/Premium-Roadside-Support-Brochures-EV.pdf'),('roadside-ev-terms','https://www.hyundai.com/content/dam/hyundai/au/en/documents/2025/2025-Hyundai-Roadside-Support-Plan-Terms-and-Conditions-Electric-Vehicles.pdf'),('blue-drive-terms','https://www.hyundai.com/content/dam/hyundai/au/en/owning/icare/Blue-Drive-Warranty-Terms-and-Conditions.pdf'),('offers-current','https://www.hyundai.com/au/en/offers'),('staria-page','https://www.hyundai.com/au/en/cars/people-movers-and-commercial/staria')]
def fetch(item):
 key,u=item
 try:
  with urllib.request.urlopen(u,timeout=45) as r:b=r.read();status=r.status;ct=r.headers.get('Content-Type','');final=r.url
  ext='.pdf' if b.startswith(b'%PDF') else '.html';fn=P/'sources'/(key+ext);fn.write_bytes(b)
  if ext=='.pdf':subprocess.run(['pdftotext','-layout',str(fn),str(fn.with_suffix('.txt'))],check=True)
  else:
   h=Text();h.feed(b.decode('utf-8','replace'));txt='\n'.join(t.strip() for t in ''.join(h.parts).splitlines() if t.strip());fn.with_suffix('.txt').write_text('URL: '+u+'\nChecked: 2026-10-14\n\n'+txt)
  return {'key':key,'url':u,'resolvedUrl':final,'checkedAt':'2026-10-14','status':status,'file':str(fn.relative_to(P)),'textFile':str(fn.with_suffix('.txt').relative_to(P)),'sha256':hashlib.sha256(b).hexdigest()}
 except Exception as e:return {'key':key,'url':u,'error':str(e)}
rows=list(concurrent.futures.ThreadPoolExecutor(max_workers=6).map(fetch,urls));(P/'extra-captures.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
