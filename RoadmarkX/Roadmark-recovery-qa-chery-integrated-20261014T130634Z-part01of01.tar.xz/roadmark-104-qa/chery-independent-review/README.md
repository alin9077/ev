# Chery independent review — 14 October 2026

## Decision

The frozen three-version candidate is approved and independently verified after registration and the narrow shared price-provenance guard fix. This is not Chery census closure or M1 completion. The reviewer did not edit or regenerate candidate data, original before fixtures, canonical baseline or source captures.

- Current MY26 Ultimate and dealer-advertised-new MY25.5 Urban/Ultimate remain distinct. Dealer calendar/build year is not substituted for model year, and no physical stock or accepted order is asserted
- All 51 core cells have earned reviews: 34 Confirmed, 3 Check, 11 Reported, 3 Not published. The missing cells are exact-cohort DC 10–80% durations; the maker's 30–80% duration and 130 kW station condition remain separate
- Price ladder is source-labelled: MY26 is a Reported RedBook driveaway guide/price-when-new figure corroborated by a live dealer ad; residual prices are exact dealer ads. The stalled maker postcode quote did not become a fabricated current national offer
- Trim-specific equipment, 58.9 kWh unspecified gross/usable capacity, battery retention threshold, roadside renewal conditions, service schedule and portable-charger conflict were independently inspected
- Nationwide older BX/EX and pre-May MY25 new-supply census remains unresolved. MY27 final grade/orderability and Q future announcements are not silently converted to on-sale versions. C3/C4/C6 pass in the staged report; C1/C2/C5 and research closure remain open

## Independent runtime proof

`independent-review-replay.json` records the complete passing pre-registration replay. It verifies:

- 393 original catalogue vehicles become 395 only through the two explicit Chery additions; all other brands/classes are exactly unchanged
- Full original existing Chery vehicles, all original sources, 69 original existing feature rows and all 138 original new-version feature rows match exactly; the new baseline was generated once
- 321 citable fact instances (312 edits plus 3 terms inherited by 3 versions), 72 guarded equipment answers, 146 exact equipment dependencies and 19 exact summary dependencies
- Actual application pack assembly and citable claim sources/grades, all 51 core-matrix entries, freshness and portable store/hydrate exact equality
- 21 ranking exclusions, 20 secondary-source promotion rejections, 14 mutation categories including the original price-basis corruption case
- Six synthetic direct foreign-maker Confirmed/Check rejections even when source market remains AU, plus two packet-level foreign promotion rejections. No actual foreign sources are used in this Chery packet
- All 27 referenced source-capture files match the manifest exactly. Independent final privacy scan covers 41 current/census text/HTML/JSON captures with zero findings; the only images are two technical PDF page renders, not browser screenshots

`live-before-equality.json` independently proves that the corrected production loader reproduces every one of the original 393 cars and every full research snapshot row exactly. All 102 original data/source files, 16 original snapshot files and input/code hashes were verified before and after. No second full catalogue was retained in memory.

## Measurements and preserved failures

- Final strict replay: exit 0, 17.098 s, 771,676 KiB maximum RSS, 768 MiB Node heap (`replay-04.*`)
- Fresh live-loader equality: exit 0, 100.593 s, 808,620 KiB maximum RSS, root-approved 704 MiB heap with a shared hash buffer and incremental exposed GC (`live-before-02.*`)
- First live-loader attempt: SIGKILL at 29.183 s / 951,324 KiB, no named assertion or Node diagnostic (`live-before-01.*`). Cause is not established
- Initial replay launcher could not find `/usr/bin/time` (exit 127; no application execution); replaced only measurement wrapper with Python resource accounting
- Replay 02 stopped on the reviewer's numeric-versus-string MY25.5 assertion. Corrected only the harness to the final source-backed string identity; original harness preserved
- Replay 03 proved the real shared price-basis guard gap. Its exact negative assertion remains in the passing replay. The patch was independently reviewed; it only rejects explicit contradictory labels in dedicated price provenance and does not infer or change prices

The price-fix worker separately reports 45 touched-file tests and lint passing. The final registered standard TypeScript check now passes, as detailed below. Earlier failures remain preserved; no complete unrelated test suite, production build, phone QA or release is claimed here.

## Approved immutable identities

- Candidate: `7cf2c720143d68e868cb407322b295593db70d53be8bbc61dafe01d7896ef91c`
- Reconciliation: `511a83fe8d5ab0ad6f180facc5265c2b53e330bda3121c5c52fc12b107a6e21c`
- Canonical packet with feature replacements empty: `5eb7230aaf980dc83a53469f2b0a9971e1dbb9d60f3e6c5024b05ca3dab79072`
- Original new-feature fixture: `f15086c76f2a2c4f01f710e3f59b6fdcb9ac7dd6c8ab34f1a929514bf187994c`
- Original full catalogue snapshot: `bb69d751fc6c85f9399e341cb8eaa79d3ea15d1952e54049d5d618781ef73d8e`
- Reviewed price guard: `9939181e02d465717dea6bdcd5f598de155df385c55ce44963fe47bd49af0cd5`

Complete artifact and implementation hashes are in `independent-review-replay.json`; independent capture/privacy evidence is in `independent-metadata-audit.json` and `independent-source-privacy.json`. Failed scripts/logs and reviewer corrections are retained, rather than overwritten.


## Final registration and production checks

The root registered the exact approved packet and reconciliation. Of 102 original input files, 100 are unchanged; only the authorized registry append and two report-loader lines differ. Their original before copies match the captured pre-Chery hashes. No other-brand source bytes changed. See `authorized-registration-delta.json`.

The complete registered coverage JSON is exactly equal to the complete staged report, with no fields omitted or normalized. File bytes differ only by the CLI's single terminal newline. Registered report SHA256: `b6100a73aa7cf5cf2b29bfc65a7021071bf18bb9d7e569cf90b79b0a46579159`. Staged report SHA256: `46f79e298a423ec95aa766acd796df3ee379b2d15b58289ebedf5cc0c55a2a54`. See `registered-coverage-parity.json`.

All final root checks have independently inspected terminal exit 0 receipts:

- Five integration test files: **171/171 pass**, 246.959 s, 920,920 KiB peak RSS; 768 MiB old heap
- Structural validation: 169.281 s, 941,476 KiB; 704 MiB old heap
- Registered coverage: 142.256 s, 834,388 KiB; 704 MiB old heap
- Full standard `tsc --noEmit`: 34.093 s, 888,680 KiB; 768 MiB old heap plus 1 MiB semi-space, with unchanged compiler settings and inputs
- Four changed-file ESLint targets: 3.812 s, 243,536 KiB; same final heap settings

The failed 768 MiB validation attempt ended with SIGKILL and no named diagnostic; the failed 704 MiB typecheck ended with explicit V8 heap exhaustion. Both attempts are retained under the root's sequential-check directory and recorded in `final-integration-receipt.json`. The successful runs supersede their incomplete outcomes without deleting them.

Final registered totals remain 395 catalogue versions, 318 Tier 1 versions and 299 on-sale versions. Chery retains 3 reviewed on-sale versions, 3 exact DC-window gaps, C3/C4/C6 passing and C1/C2/C5 open. No whole-brand census closure is claimed.
