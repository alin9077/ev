# Independent Chery evidence review

Checked 14 October 2026 in dot cloud tools. This is an evidence review, not a claim of brand census or final packet completion. No catalogue has been hydrated during the BMW backup slot.

## Established current MY26 scope

Current Australian model page and 8 April 2026 Australian announcement establish Ultimate as the sole MY26 grade. New E5 is separately labelled Coming Soon on the maker site. Do not substitute its new equipment into MY26, or treat a dealer calendar heading as a model year.

Sources: https://cherymotor.com.au/models/chery-e5-electric-suv ; https://cherymotor.com.au/models/new-e5 ; https://cherymotor.com.au/news/chery-strengthens-ev-value-my26-e5-ultimate-now-priced-37990-driveaway

## Current AU technical source

April 2026 edition 1.15 MY26 Ultimate brochure establishes 58.9 kWh capacity with no gross/usable designation, 430 km WLTP, 155 kW/288 Nm FWD, 6.6 kW single-phase and 10.3 kW three-phase AC, 300 L VDA below cargo cover, 1,079 L folded to roof, 4,424/1,830/1,588 mm dimensions and 750 kg non-braked towing. The station condition is 130 kW, with 30 minutes at 30–80%; neither vehicle DC peak nor 10–80% time follows from this row. Current model page supplies five seats and 7.6 s acceleration.

The brochure explicitly includes trickle equipment; current model-page footnote says not included. This is a real conflict requiring a buyer-visible qualification, not unqualified standard equipment. Dual-zone cabin AC does not establish automatic seat climate; standard heated front and outboard rear seats do not establish ventilation or massage. Broad overseas-image and lab-cycle disclaimers do not demote the Australian technical rows.

Source: https://cherymotor.com.au/sites/default/files/2026-04/233_25_Chery_E5_Spec_Sheet_2025_Rebrand_v115%20%282%29%20%281%29.pdf

## Secondary-source boundary

CarExpert’s 29 March 2026 comparison has a 2026 headline, but its static tables explicitly describe 2025 Chery E5 Ultimate. It predates the MY26 announcement, retains Urban and $40,990, and mixes 61.1 kWh/7.2 s in its table with 58.9 kWh usable in prose. Its 80 kW and 30-minute 10–80% statements cannot be sourced as exact MY26. If carried at all, use explicitly sibling/secondary Reported provenance and disclose the internal discrepancy. A two-source MY26 unsuccessful search should explain this rejection rather than claim no publication exists anywhere.

Source: https://www.carexpert.com.au/car-comparisons/2026-chery-e5-vs-byd-atto-3-spec-battle

Exact MY26 RedBook record does support Reported 750 kg braked towing. Its 30-minute fast-charge figure has no window. Its $37,990 is a driveaway Price When New, not before-on-road list price. Maker April press release is historical; maker October offer currently has no amount in retrieved text. Never silently extend old cash-offer expiry or borrow finance expiry.

Source: https://www.redbook.com.au/cars/details/2026-chery-e5-ultimate-auto-my26/SPOT-ITM-683918/

## Brand terms

Australian new vehicle warranty is seven years/unlimited kilometres from first registration. Taxi, ride-sharing, hire, rental, driving-school and delivery/courier use has a seven-year/150,000 km limit. Demonstrators only retain the balance from first registration.

Source: https://cherymotor.com.au/legal/owners/7-year-new-car-warranty-policy-statement

High-voltage battery terms explicitly publish eight years/unlimited kilometres and protection below 70% residual energy versus delivery, subject to authorised dealer measurement. Repair or replacement may be reconditioned and is at maker discretion; a new-capacity replacement is not promised.

Source: https://cherymotor.com.au/8-year-unlimited-km-battery-warranty-terms-conditions

Roadside assistance starts with 12 complimentary months. Another year is renewed when an authorised dealer performs the scheduled service within a year of the prior service, up to seven years. The maximum duration must not be labelled unconditional prepaid cover.

Source: https://cherymotor.com.au/owners/roadside-assistance

## Pending independent execution

Await stable packet and immutable original baselines. Verify full existing/new features; source capture hashes and privacy; exact canonical dependencies; actual pack/citable/portable equality; other brands and original sources unchanged; ranking/mutation/source-authority negatives; and final packet/reconciliation hashes. Obtain root’s serialized heavy slot before executing, using a 768/1024 MiB Node heap and preserving failed logs plus max RSS.

## Subsequent refinements

The 2 July 2026 CarExpert C5/E5 price/specifications article explicitly identifies the sole current E5 Ultimate and consistent 155 kW/58.9 kWh technical cohort. It publishes 130 kW vehicle DC maximum and 750 kg braked towing; those are admissible as Reported, with the separate maker station condition retained. It does not supply 10–80% duration. It expressly says MY26 E5 lacks front-seat ventilation.

Source: https://www.carexpert.com.au/car-news/2026-chery-c5-and-e5-price-and-specs-hybrid-joins-small-suv-range

For active MY26 pricing, a rung-five RedBook price-guide figure is defensible only with its explicit driveaway/price-when-new label, Reported and unranked, plus the note that a current maker postcode quote could not be obtained. A fresh same-price Brisbane new-car advertisement corroborates the amount without converting it to a maker or national price. MY25.5 prices remain exact dealer advertisements, rung six.

Residual evidence independently inspected: Portside C11257 is explicitly New / MY25.5 Urban / $36,990 driveaway; Wakeling stock 618777 is explicitly New / MY25.5 Ultimate / $39,840 driveaway, despite its 2026 title/build. Dealer prose has technical errors; it supports identity/asking price only. A separate Wakeling 2025 Ultimate URL redirects to generic stock and is rejected. MY25.5 brochure specifies Urban-only 19 L front storage and Ultimate-only heat pump; MY26 brochure omission cannot itself prove no frunk. National BX/EX residual-new census remains unresolved.
