import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {research,catalogue} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/data.ts';
import {brandUpdatePackets} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-update-registry.ts';
const R='/tmp/chery-research',Q=path.resolve('../roadmark-104-qa/chery-independent-review');
assert(!brandUpdatePackets.some(p=>p.brand==='Chery'),'Run before Chery registration');
const manifest=JSON.parse(fs.readFileSync(path.join(R,'replay-snapshot-manifest.json'),'utf8')),index=JSON.parse(fs.readFileSync(path.join(R,'replay-snapshot-index.json'),'utf8'));
const expected=new Map(manifest.files.map((r:any)=>[r.path,r]));
const sha=(file:string)=>{const h=crypto.createHash('sha256'),fd=fs.openSync(file,'r'),buf=Buffer.alloc(262144);try{let n;while((n=fs.readSync(fd,buf,0,buf.length,null)))h.update(buf.subarray(0,n));}finally{fs.closeSync(fd);}return h.digest('hex');};
const sourceHash=sha('src/lib/price-ladder.ts');
const inputHashes=Object.fromEntries(['replay-snapshot-manifest.json','replay-snapshot-index.json','immutable-data-before.json','chery-2026-10-14.json','chery-reconciliation-2026-10-14.json'].map(f=>[f,sha(path.join(R,f))]));
const codeHashes=Object.fromEntries(['src/lib/data.ts','src/lib/price-ladder.ts','src/lib/brand-updates.ts','src/lib/brand-update-registry.ts','src/lib/evidence-grading.ts','src/lib/evidence-regrade-policy.ts'].map(f=>[f,sha(f)]));
const immutable=JSON.parse(fs.readFileSync(path.join(R,'immutable-data-before.json'),'utf8'));
function verifyInputs(){for(const [f,h]of Object.entries(inputHashes))assert.equal(sha(path.join(R,f)),h,f+' input drift');for(const [f,h]of Object.entries(codeHashes))assert.equal(sha(f),h,f+' code drift');for(const [f,h]of Object.entries(immutable))assert.equal(sha(f),h,f+' original source bytes changed');for(const e of manifest.files){const f=path.resolve(R,e.path);assert(f.startsWith(R+'/'));assert.equal(sha(f),e.sha256,e.path+' original snapshot bytes');assert.equal(fs.statSync(f).size,e.bytes);}}verifyInputs();
const rowsHash=(rows:unknown[])=>{const h=crypto.createHash('sha256');for(const row of rows)h.update(JSON.stringify(row)+'\n');return h.digest('hex');};
console.log('Hydrating live pre-Chery catalogue with corrected price guard');const rd=research(),cars=catalogue(),results:any[]=[];
function check(file:string,rows:unknown[]){const e:any=expected.get(file);assert(e,file+' original manifest entry');const actual=rowsHash(rows);assert.equal(actual,e.sha256,file+' complete live/original equality');results.push({path:file,rows:rows.length,sha256:actual});}
check(index.cars,cars);for(const [key,entry]of Object.entries(index.research)as[string,{file:string,array:boolean}][]){const value=(rd as any)[key];check(entry.file,entry.array?value:[value]);}
verifyInputs();
const result={status:'passed',checkedAt:'2026-10-14',liveCatalogueCount:cars.length,priceGuardSha256:sourceHash,originalBeforeCatalogueSha256:(expected.get(index.cars)as any).sha256,allLiveResearchRowsAndCarsEqual:true,originalSourceFilesUnchanged:Object.keys(immutable).length,inputHashes,codeHashes,results,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()};fs.mkdirSync(Q,{recursive:true});fs.writeFileSync(path.join(Q,'live-before-equality.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
