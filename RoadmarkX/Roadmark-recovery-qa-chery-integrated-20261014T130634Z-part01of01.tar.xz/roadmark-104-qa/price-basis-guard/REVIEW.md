# Price provenance consistency guard

## Result

A minimal consistency-only guard is implemented in `src/lib/price-ladder.ts` and independently reviewed. It rejects a nonblank price comparison group when either dedicated retained provenance field (`basisTag` or `originalBasis`) explicitly names the opposite basis. The original Chery candidate remains accepted; changing its current MY26 Reported price from Driveaway to Before on-road costs now rejects with `Price comparison basis contradicts retained price provenance (basisTag)`.

Only three source/test files changed:

- `src/lib/price-ladder.ts`: 27 added lines for explicit-label consistency checking
- `tests/price-ladder.test.ts`: three new behavioral tests and four corrected synthetic basis tags that previously inherited the fixture's before-on-road label despite describing driveaway
- `tests/brand-updates.test.ts`: one new behavioral test exercising the real packet validator for both directions on rungs 3, 5 and 6

No evidence packet, source, frozen candidate, production figure, hero, UI, ladder order or ranking rule was edited. The check does not parse qualifications or source prose, derive a group, fill a blank basis, convert a price, or promote Reported prices. It intentionally leaves mixed, negated, unresolved, unrecognized abbreviation and untranslated labels unclassified. Its conservative scope is not a general price-text classifier.

## Verification

- Before the production change, both new negative-test entry points failed because the contradiction was accepted: `red-tests.log`
- Final price ladder file: 21/21 pass; 2.42 seconds, peak RSS 581,108 KiB: `price-tests-final.log`
- Full brand update file: 24/24 pass at 768 MiB heap; 8.03 seconds, peak RSS 846,864 KiB: `brand-tests-768.log`
- Targeted lint on all three edited files: pass, `lint.exit` is 0
- All 241 active price rows across the 15 registered packets plus the unchanged staged Chery packet remain accepted, including six deliberately blank comparison bases: `retained-prices-check.json`
- The three actual Chery price basis flips all reject; the exact initially failing current MY26 rung-5 mutation is recorded in `retained-prices-check.json`
- All 104 preserved data/source/candidate inputs match their pre-edit hashes: `immutable-check.json`
- Independent Chery reviewer inspected the diff and independently scanned all 241 active prices, finding no blocker. The original full Chery replay remains owned by that reviewer and was pending when this guard was handed back

## Failures and limits, preserved

The first uncapped combined file run returned a file-level `test failed` for `brand-updates.test.ts`, without an assertion diagnostic. The sequential capped complete file run above subsequently passed. See `focused-tests.log` and `brand-tests-768.log`; no root cause is asserted for the first termination.

Full typecheck is **not verified**:

- 768 MiB heap, default incremental tsconfig: signal 9 after 10.56 seconds, peak RSS 951,740 KiB, no diagnostic
- 640 MiB retry: V8 JavaScript heap out of memory, signal 6 after 16.73 seconds, peak RSS 860,928 KiB

Both attempts, exact commands, exits and measured usage are retained in `typecheck-768*` and `typecheck-640*`. No repository-wide test, validation or coverage pass is claimed here. The parent owns the next integrated checks and the independent exact-input replay.

## Preserved artifacts

- `before/`: exact pre-edit source and tests
- `patch.diff`: complete source/test diff
- `before-sha256.json`, `after-sha256.json`: before inputs and final edited file hashes
- `original-failed-replay.log`, `original-failed-reproducer.ts`: original observed Chery failure and reproducer snapshot
- `check-retained-prices.ts`: lightweight real-packet check, without catalogue hydration
- `measure-run.py`: serialized test runner retaining process exit/signal and peak child RSS

The reviewed Chery candidate SHA-256 remains `7cf2c720143d68e868cb407322b295593db70d53be8bbc61dafe01d7896ef91c`.
