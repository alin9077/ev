import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {brandUpdatePackets} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-update-registry.ts';
import {priceCandidateRejection,type PriceCandidate} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/price-ladder.ts';
import type {BrandUpdatePacket} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-updates.ts';
import type {Fact} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/types.ts';
const cheryFile='/tmp/chery-research/chery-2026-10-14.json';
const expectedCheryHash='7cf2c720143d68e868cb407322b295593db70d53be8bbc61dafe01d7896ef91c';
const cheryBytes=fs.readFileSync(cheryFile);
assert.equal(crypto.createHash('sha256').update(cheryBytes).digest('hex'),expectedCheryHash);
const chery=JSON.parse(cheryBytes.toString()) as BrandUpdatePacket;
const candidate=(f:Fact):PriceCandidate=>({variantId:'reviewed-price',value:f.value as number,sourceIds:f.sourceIds,date:f.date,...f.priceEvidence!,comparisonBasis:f.comparisonBasis as PriceCandidate['comparisonBasis'],qualifications:f.qualifications,validUntil:f.validUntil});
const results=[];
for(const packet of [...brandUpdatePackets,chery]){
 let prices=0,guardedMutations=0;
 const groups:Record<string,number>={};
 for(const {after:fact}of packet.facts){
  if(!['price_aud','promotional_driveaway_aud'].includes(fact.key)||fact.value===null)continue;
  const original=candidate(fact),before=JSON.stringify(original);
  assert.equal(priceCandidateRejection(original,original.variantId,packet.sources,packet.reviewedAt),null,packet.id+'/'+fact.key+'/'+fact.priceEvidence?.sourceKey);
  prices++;
  const key=`rung ${original.rung}/${original.comparisonBasis||'Ungrouped'}`;
  groups[key]=(groups[key]??0)+1;
  if(original.comparisonBasis){
   const mutated={...original,comparisonBasis:original.comparisonBasis==='Driveaway'?'Before on-road costs':'Driveaway'} as PriceCandidate;
   const reason=priceCandidateRejection(mutated,mutated.variantId,packet.sources,packet.reviewedAt);
   if(reason?.includes('contradicts retained price provenance'))guardedMutations++;
  }
  assert.equal(JSON.stringify(original),before);
 }
 results.push({packet:packet.id,prices,guardedMutations,groups});
}
const first=chery.facts.find(f=>f.after.key==='price_aud')!.after;
assert.equal(first.priceEvidence!.rung,5);
assert.equal(first.comparisonBasis,'Driveaway');
const mutated={...candidate(first),comparisonBasis:'Before on-road costs'} as PriceCandidate;
const rejection=priceCandidateRejection(mutated,mutated.variantId,chery.sources,chery.reviewedAt);
assert.match(rejection??'',/comparison basis contradicts retained price provenance/);
const result={registeredPackets:brandUpdatePackets.length,pricesChecked:results.reduce((n,r)=>n+r.prices,0),registeredAndCheryPricesAllAccepted:true,cheryOriginalSha256:expectedCheryHash,cheryMutationRejection:rejection,results};
fs.writeFileSync('../roadmark-104-qa/price-basis-guard/retained-prices-check.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
