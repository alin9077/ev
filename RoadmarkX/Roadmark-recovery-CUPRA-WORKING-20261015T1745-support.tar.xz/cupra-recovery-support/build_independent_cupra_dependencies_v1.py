#!/usr/bin/env python3
"""Resolve exact CUPRA requirements from retained metadata, never external payloads."""
import copy,collections
from independent_cupra_common_v1 import *
def main():
 command('build');inv,acc=verify_freeze();check(BASE_MANIFEST,BASE_PIN);base=load(BASE_MANIFEST);old=rows(base['files']);ck(len(old)==13380 and len(base['archivesInRestoreOrder'])==135,'base counts differ');deps=copy.deepcopy(base['inheritedDependencyReconstruction']['dependencies']);ck(len(deps)==181,'inherited record count differs');by={r['originalPath']:r for r in deps};frozen={r['path']:r for r in inv['files']};req={};reads=[]
 names={'manifest.json','source-pins.json','input-pins.json','prepared-command.json','storage-read-closure.json','normal-coverage-asof-2026-10-15.json','report-comparison.json','sequence.json','static-import-closure.json','typescript-failure-context.json'}
 def visit(x,src):
  if isinstance(x,dict):
   if all(k in x for k in ('path','bytes','sha256')) and isinstance(x['path'],str) and x['path'].startswith('/'):
    e=core(x);req.setdefault(tuple(e.values()),{'expected':e,'nominatedBy':[]})['nominatedBy'].append(src)
   for v in x.values():visit(v,src)
  elif isinstance(x,list):
   for v in x:visit(v,src)
 for pstr,r in frozen.items():
  p=P(pstr)
  if pstr.startswith('/tmp/cupra-packet/') and p.name in names:
   ck(r['bytes']<500000,'metadata limit');q=pin(p);ck(q['bytes']==r['bytes'] and identity(p)[1]==r['mtimeNs'],'metadata freeze differs');visit(load(p),pstr);reads.append(q)
 visit(inv['retainedFailures'],str(INV));mapping={};sources=[]
 def addmap(member,m):
  if member in old:mapping[member]=m
 pp=B/'INDEPENDENT-KGM-DEPENDENCY-PROPOSAL-v1.json';prior=load(pp);sources.append(pin(pp))
 for r in prior['resolvedKgmRequirements']:addmap(r['member']['path'],copy.deepcopy(r['mapping']))
 mp=B.parent/'mini-working-20261015T1330/MINI-METADATA-INVENTORY-PROPOSAL-v1.json';md=load(mp);sources.append(pin(mp))
 for r in md['priorChainDependencies']['dependencies']:addmap(r['member'],copy.deepcopy(r['mapping']))
 planpath=B/'RESTORE-PLAN.json';plan=load(planpath);sources.append(pin(planpath))
 for a in plan['newArchives']:
  for r in a['memberFiles']:addmap(r['path'],{'archives':[a['filename']],'partResolution':'Exact single archive','mappingBasisRef':str(planpath),'member':core(r)})
 ap=B.parent/'audi-working-20261015T0800/ARCHIVE-PLAN-v4.json';ad=load(ap);sources.append(pin(ap))
 for a in ad['archives']:
  for r in a['memberFiles']:
   if r['path'] not in mapping:addmap(r['path'],{'archives':[a['filename']],'partResolution':'Exact single archive','mappingBasisRef':str(ap),'member':core(r)})
 archives={a['filename']:a for a in base['archivesInRestoreOrder']};external=[];internal=[];unresolved=[];new=[];existing=[];before=[]
 for r in req.values():
  e=r['expected'];p=P(e['path']);r['nominatedBy']=sorted(set(r['nominatedBy']))
  if str(p) in frozen:internal.append(r);continue
  if p.is_relative_to(W/'roadmark-104'):
   n=rest(p)
   # Historical live-source pins are satisfied only by an exact retained before copy, never current live bytes.
   if n in old and sh(old[n])==sh(e):
    matches=[x for x in inv['files'] if '/before/' in x['path'] and x['path'].endswith('/'+p.relative_to(W/'roadmark-104').as_posix()) and x['bytes']==e['bytes']]
    before.append({'expected':e,'baseMember':old[n],'retainedBeforeCandidates':[x['path'] for x in matches],'nominatedBy':r['nominatedBy']})
   internal.append(r);continue
  logical=p.relative_to('/tmp').as_posix() if p.is_relative_to('/tmp') else p.relative_to(W).as_posix() if p.is_relative_to(W) else None
  matches=[z['member'] for z in by.get(str(p),{}).get('pins',[]) if sh(z['expected'])==sh(e)]
  if logical in old and sh(old[logical])==sh(e):matches.append(old[logical])
  matches={m['path']:m for m in matches}
  if len(matches)!=1:unresolved.append(r);continue
  member=next(iter(matches.values()));ck(member['path'] in mapping,'archive mapping absent '+member['path']);m=mapping[member['path']];ck(set(m['archives'])<=set(archives),'archive mapping not in base');
  if 'member' in m:ck(m['member']==core(member),'mapping member differs')
  row={**r,'member':member,'mapping':m};external.append(row)
  if str(p) in by:
   ck(any(sh(z['expected'])==sh(e) and z['member']==member for z in by[str(p)]['pins']),'existing dependency mismatch');existing.append({'originalPath':str(p),'member':member})
  else:
   x={'originalPath':str(p),'pins':[{'expected':e,'reconstructFrom':'exact inherited recommended-chain member','member':member}]};new.append(x);deps.append(x);by[str(p)]=x
 ck(len(unresolved)==1 and unresolved[0]['expected']=={'path':'/usr/bin/timeout','bytes':47984,'sha256':'6ca1891dfc0b05d7680770c2884c0391b92467c7bb6500a5c84677e6481739f1'},'unmapped non-runtime requirements')
 closure=load(inv['retainedStorageReadClosure']['path']);ck(len(closure)==21 and all(any(r['expected']==e for r in external) for e in closure),'21-file closure not exact')
 scope=load(C/'FROZEN-CAPTURE-SCOPE.json');changed={'roadmark/'+n for n in scope['sourceChangedPaths']};intersections=[{'originalPath':r['originalPath'],'pin':p} for r in base['inheritedDependencyReconstruction']['dependencies'] for p in r['pins'] if p['member']['path'] in changed];ck(not intersections,'inherited relocation requires review')
 for r in deps:
  for p in r['pins']:ck(old[p['member']['path']]==core(p['member']) and sh(p['expected'])==sh(p['member']),'dependency identity mismatch')
 canonical=hashlib.sha256(json.dumps(deps,sort_keys=True,separators=(',',':')).encode()).hexdigest();system={**unresolved[0],'payloadReads':0,'reconstructionCheckRequirement':'Before product-proof rerun verify the exact OS binary in a separately authorized compatible runtime; recovery does not supply it.'}
 inspection={'result':'DEPENDENCY_REQUIREMENTS_INSPECTED','metadataReads':reads,'externalRequirements':external,'internalRequirements':internal,'unresolved':unresolved,'sourceBeforeReferences':before,'noExternalPayloadReads':True,'noArchivePayloadReads':True};dump(C/'INDEPENDENT-CUPRA-DEPENDENCY-INSPECTION-v1.json',inspection)
 out={'schemaVersion':1,'result':'PASS_EXACT_METADATA_ONLY_DEPENDENCY_PROPOSAL','createdAt':now(),'baseManifest':pin(BASE_MANIFEST),'baseDependencyMap':pin(B/'INHERITED-DEPENDENCY-RECONSTRUCTION-v1.json'),'metadataInspection':pin(C/'INDEPENDENT-CUPRA-DEPENDENCY-INSPECTION-v1.json'),'metadataMappingSources':sources,'frozenScope':pin(C/'FROZEN-CAPTURE-SCOPE.json'),'allSixFinalSourceChangedPaths':sorted(changed),'relocationProposals':[],'inheritedPointerIntersections':intersections,'inheritedDependencyRecords':181,'unchangedInheritedRecords':181,'cupraExternalRequirements':len(external),'existingExactRequirements':existing,'resolvedCupraRequirements':external,'newDependencyRecords':new,'proposedDependenciesCount':len(deps),'proposedDependenciesCanonicalSha256':canonical,'referencedArchives':[archives[n] for n in sorted({n for r in external for n in r['mapping']['archives']})],'runtimeSystemDependenciesNotCaptured':[system],'exactRetainedStorageClosureFiles':21,'originalExpectedPathsAndHashesUnchanged':True,'metadataOnly':True,'externalPayloadReads':0,'archivePayloadReads':0,'sourceBeforeReferences':before,'beforeCopiesRequiredForInheritedPointerRelocations':0,'rawDeepalOriginalReads':False,'rawKgmOriginalReads':False};dump(C/'INDEPENDENT-CUPRA-DEPENDENCY-PROPOSAL-v1.json',out)
 for r in reads+sources:check(r['path'],r)
 print(json.dumps({'result':out['result'],'external':len(external),'new':len(new),'final':len(deps),'unmappedNonRuntime':0,'storageClosure':21}))
if __name__=='__main__':main()
