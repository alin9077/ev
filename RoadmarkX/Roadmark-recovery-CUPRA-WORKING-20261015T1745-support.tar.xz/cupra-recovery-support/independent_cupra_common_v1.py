"""Independent CUPRA metadata utilities; no production imports or payload traversal."""
import datetime,hashlib,json,pathlib,resource,stat,sys
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent;B=C.parent/'kgm-working-20261015T1530';W=C.parents[2];R=C.parents[1];LIMIT=268435456;CHUNK=65536
INV=P('/tmp/cupra-packet/final-freeze-v1/inventory.json');ACC=P('/tmp/cupra-review/final-retention-v1-accepted.json')
INV_PIN={'bytes':147107,'sha256':'798f05ab19b2632f0ee091305430c16105e59ae7df3fa316766feb2d54f3ee55'}
ACC_PIN={'bytes':4908,'sha256':'2b024c76cfa72634b74be4ea0d49f966e42a6f185ae2161b506d2a64b32d6f7f'}
BASE_MANIFEST=B/'deliverables/Roadmark-RECOVERY-MANIFEST-KGM-WORKING-20261015.json'
BASE_PIN={'bytes':3246441,'sha256':'09bcfeb302b31331d0d7ed12b18553f0cf71cf0fca4017b97cd53cbafe3edba4'}
def ck(v,m):
 if not v:raise AssertionError(m)
def sh(r):return {k:r[k] for k in ('bytes','sha256')}
def core(r):return {k:r[k] for k in ('path','bytes','sha256')}
def identity(p):
 p=P(p);s=p.lstat();ck(stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents),'unsafe regular path '+str(p));return [s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev]
def pin(p):
 p=P(p);before=identity(p);h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(CHUNK):h.update(b);n+=len(b)
 ck(identity(p)==before and n==before[0],'file mutation '+str(p));return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
def check(p,r):
 q=pin(p);ck(sh(q)==sh(r),'pin differs '+str(p));return q
def load(p):return json.loads(P(p).read_bytes())
def dump(p,x):
 with P(p).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def bounded():ck(resource.getrlimit(resource.RLIMIT_AS)==(LIMIT,LIMIT),'256MiB ceiling absent')
def command(mode):bounded();ck(sys.argv[1:]==[mode,'--sole-child-slot-authorized'],'supported command is '+mode+' --sole-child-slot-authorized')
def safe(n):
 p=P(n);ck(n and not p.is_absolute() and '..' not in p.parts and str(p)==n and '\\' not in n,'unsafe member '+n);return n
def rest(p):
 p=P(p)
 if p.is_relative_to('/tmp'):return safe(p.relative_to('/tmp').as_posix())
 if p.is_relative_to(W/'roadmark-104'):return 'roadmark/'+safe(p.relative_to(W/'roadmark-104').as_posix())
 ck(p.is_relative_to(W/'roadmark-104-qa'),'unexpected restore root '+str(p));return safe(p.relative_to(W).as_posix())
def pointer(x,p):
 if not p:return x
 for k in p.split('/')[1:]:k=k.replace('~1','/').replace('~0','~');x=x[int(k)] if isinstance(x,list) else x[k]
 return x
def rows(rs):
 d={}
 for r in rs:safe(r['path']);ck(r['path'] not in d,'duplicate member');d[r['path']]=core(r)
 return d
def verify_freeze():
 check(INV,INV_PIN);check(ACC,ACC_PIN);i,a=load(INV),load(ACC);ck(i['totalFiles']==len(i['files'])==450 and i['regularFileBytes']==38201419 and i['symlinkCount']==0,'freeze counts differ');ck(a['status']=='accepted' and a['inventory']==pin(INV) and a['inventoryPreparer']==i['preparer'] and a['liveTargetPins']==i['sourceAndStatusAfterPins'],'final acceptance differs');ck((i['acceptedSourcePins'],i['heldOnlySourcePins'],i['allowlistedSourceUnion'])==(86,11,97),'source union differs');ck(a['retentionHistory']['mutableSourceV1OriginalReviewedBytesUnavailable'] and a['retentionHistory']['noReconstructionOfMissingV1BytesClaimed'],'lost v1 limitation missing');return i,a
