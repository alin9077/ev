#!/usr/bin/env python3
"""Add exact call-order and orphan-invocation checks to the preserved scan binding."""
import datetime
from verify_interrupted_scan_metadata_v1 import C,P,ck,load,pin,verify as verify_prior

def verify():
 result=verify_prior()
 script=C/'privacy_v1.py';sp=pin(script);ck({k:sp[k] for k in ('bytes','sha256')}=={'bytes':15310,'sha256':'5c8981f69d021b1ca18a69f95036b7cb25e26e35cf455c513d8ed7c3ad5ea601'},'unchanged selector flow pin differs')
 records=result['completedSeedReconstructions'];times=[datetime.datetime.fromisoformat(load(records[k]['path'])['completedAt']) for k in ('historical','audi','deepal')];ck(times[0]<=times[1]<=times[2],'completed seed stage order differs')
 original=result['invocation']['path'];orphans=[]
 for p in sorted(C.glob('*.resources.invocation.json')):
  iv=load(p);cmd=iv.get('command',[])
  if not any((P(a).name.startswith('privacy_v') or P(a).name.startswith('scan_archive_v')) and P(a).suffix=='.py' for a in cmd):continue
  terminal=p.with_name(p.name.removesuffix('.invocation.json')+'.json')
  if not terminal.exists():orphans.append(str(p))
 ck(orphans==[original],'another scanner has no terminal; reconcile before proceeding')
 result['localSelectorReadInference']={'unchangedControlFlow':sp,'basis':'The unchanged inherited seed selector calls finish before the completed Audi receipt; the historical, Audi and Deepal receipts are ordered and pinned. This establishes completed local reconstruction, not archive scan success.','uniqueLocalSelectors':48,'payloadValueReads':48,'streamingIntegrityReads':48,'perFileInstrumentation':False}
 result['onlyOriginalScannerInvocationLacksTerminal']=True
 return result
