#!/usr/bin/env python3
"""Build four documents after successful archive persistence; no script bodies."""
from delivery_common_v1 import *

def main():
    plan, base, prior = load(C / 'RESTORE-PLAN.json'), load(BASE_MANIFEST), load(BASE_TERMINAL)
    verify_base_snapshot()
    inventory, author_acceptance = author_inputs()
    scope = load(C / 'FROZEN-CAPTURE-SCOPE.json')
    capture = load(C / 'source-capture.json')
    contract = load(C / 'APPLICATION-ASSERTION-CONTRACT.json')
    dependency = load(C / DEPENDENCY)
    recovery, gate = load(C / RECOVERY), load(C / GATE)
    sanitation_path, sanitation = replay_metadata('copySanitation')
    proof_capture_path, proof_capture = replay_metadata('proofCapture')
    adapter, deepal_counters, unused = deepal_adapter()
    classified = load(adapter['classification']['path'])
    deepal_review = {'classification': adapter['classification'], 'additiveInventory': adapter['additiveInventory'],
                     'summary': classified['summary'], 'knownValueSearchCounts': deepal_counters,
                     'pinReferencedCopiedFiles': sum(bool(row['sourcePinReferences']) for row in classified['files']),
                     'originalDetectorCoverageGap': classified['originalDetectorCoverageGap'],
                     'fourHTMLFactualProjectionsUnchanged': all(row['visibleFactualTextUnchanged'] for row in classified['files'] if row['format'] == 'html'),
                     'oneJSONOpaqueQueryOnly': all(row['jsonStructureAndOtherValuesUnchanged'] and
                                                  [leaf['pointer'] for leaf in row['changedJSONLeaves']] == ['/scripts/24'] and
                                                  all(leaf['onlyApprovedOpaqueValueReplacements'] for leaf in row['changedJSONLeaves'])
                                                  for row in classified['files'] if row['format'] == 'json'),
                     'genericDecodedCoverageClaimed': False, 'universalAbsenceClaimed': False}
    ck(deepal_review == base['deepalSanitationReview'] and deepal_review['fourHTMLFactualProjectionsUnchanged'] and deepal_review['oneJSONOpaqueQueryOnly'], 'inherited Deepal factual parity classification differs')
    ck(scope['authorRetention'] == inventory and len(scope['files']) == 453 and len(scope['sourceChangedPaths']) == 6, 'current author frozen scope differs')
    ck(scope['expectedSourceFiles'] == 697 and scope['expectedNonSourceOverlay'] == ['roadmark-104-qa/work-status.json'], 'source/non-source frozen scope differs')
    ck(recovery['result'] == gate['result'] == 'PASS', 'fresh verification not passed')
    application_assertion_scope = application_scope(recovery, contract)
    ck(gate['freshMembers'] == plan['freshFiles'] and gate['freshBytes'] == plan['freshBytes'] and
       gate['unclassifiedFindings'] == gate['errors'] == 0, 'privacy count or finding differs')
    ck(len(base['archivesInRestoreOrder']) == 135 and len(base['files']) == 13380 and
       plan['baseArchivesReused'] == 134 and plan['fullSourceFiles'] == 697, 'base/source counts differ')
    ck(load(BASE / 'INDEPENDENT-KGM-TERMINAL-CLOSURE-v1.json')['result'] ==
       'PASS_TERMINAL_RECOVERY_CLOSURE', 'base terminal closure absent')
    check(BASE_MANIFEST, plan['baseManifestPin'])
    archives = final_archives(plan)
    fresh = [row for row in archives if row.get('new')]
    source = next(row for row in fresh if row['group'].startswith('source-'))
    support = next(row for row in fresh if row['filename'].endswith('-support.tar.xz'))
    support_members = load(C / 'support-package.json')['memberFiles']
    support_map = file_map(support_members)
    support_copy = generated_support_copy(support_members, sanitation)
    support_script_bindings = bind_delivery_scripts()
    ck(source['bytes'] < 15000000 and len(capture['files']) == plan['fullSourceFiles'] == 697, 'source size/file scope differs')
    dep_summary = dependency_summary(dependency)
    summary_row = next(row for row in capture['files'] if row['path'] == 'docs/CUPRA_M1_UPDATE.md')
    summary_path = pathlib.Path(summary_row['payloadPath'])
    check(summary_path, summary_row)
    ck({key: summary_row[key] for key in ('bytes', 'sha256')} ==
       {'bytes': 5684, 'sha256': 'fd32ecf44f017010a6de5e6ba595a04be2e3aee096eada2b15d5e74ffe73cb0c'},
       'frozen author summary differs')
    state = {'label': scope['workingResult'], 'registered': True,
             'integrationIndependentlyAccepted': True, **contract['summary'],
             'targetedCountsNotClaimedDisjoint': True, 'fullProjectTypeScriptPassed': False,
             'structuralValidationPassed': True, 'strictSavedReportComparisonPassed': True,
             'currentCounts': {'catalogue': 430, 'tier1': 353, 'onSale': 312, 'packets': 29},
             'historicalDeepalPreview': {'compactReceipts': 6, 'browserOutcome': 'Cloud-browser loopback reachability refused', 'notCUPRAVisualQA': True},
             'historicalTypeScriptPassesDoNotApplyToCurrentSource': True, 'compilerRetriesPermitted': False, 'currentValidationFactualOnly': True,
             'CUPRAVisualQAPassed': False, 'otherAttemptHistory': inventory['otherAttemptHistory'],
             'currentValidation': inventory['currentValidation'], 'newCUPRACompilerRun': False,
             'currentCUPRARuntimeFailure': False, 'typeScriptFailuresInheritedFromKGM': True,
             'mutableV1Limitation': inventory['mutableV1Limitation'],
             'sourceRetention': {'acceptedV3Pins': 86, 'heldV2OnlyPins': 11, 'unionPins': 97,
                                 'missingOriginalMutableLightV1Pins': 81, 'missingBytesReconstructed': False},
             'fullProjectSuitePassed': False, 'buildPassed': False, 'mobilePassed': False,
             'releaseReady': False, 'published': False, 'milestone': 'M1 open',
             'authorFreezeAt': scope['authorRetention']['frozenAt'],
             'sourceCaptureCutoff': capture['captureCutoff'], 'captureIsFrozenHistoricalCut': True,
             'failedAttempts': scope['authorRetention']['retainedFailures'], 'openGates': scope['openGates']}
    base_ref = {'library_file_id': prior['manifestLibraryFileId'], **pin(BASE_MANIFEST)}
    recovery_summary = {'result': 'PASS', 'receipt': ref(C / RECOVERY),
                        'recoverableReceipt': {'document': DOCS[2].name, 'jsonPointer': '/postSealReceipts/0'},
                        'inputManifest': ref(C / 'INDEPENDENT-CUPRA-REPLAY-INPUTS-v1.json'),
                        'recoverableInputManifest': {'document': DOCS[2].name, 'jsonPointer': '/postSealReceipts/2'},
                        'memberReplayManifest': ref(C / 'INDEPENDENT-NEW-MEMBER-REPLAY-MANIFEST-v1.json'),
                        'applicationContract': ref(C / 'APPLICATION-ASSERTION-CONTRACT.json'),
                        'applicationAssertionCount': len(contract['assertions']),
                        'applicationAssertionScope': application_assertion_scope,
                        'mandatoryRetainedPins': len(contract['retainedPins']),
                        'freshArchiveCount': len(fresh), 'freshMembers': plan['freshFiles'],
                        'freshBytes': plan['freshBytes'], 'archiveStreamsVerifiedThroughXZEOF': True,
                        'retention': 'Exact data-only final receipt is reconstructable from the verification document using its declared serialization'}
    privacy_summary = {'result': 'PASS', 'receipt': ref(C / GATE),
                       'recoverableReceipt': {'document': DOCS[2].name, 'jsonPointer': '/postSealReceipts/1'},
                       'freshMembers': gate['freshMembers'], 'freshBytes': gate['freshBytes'],
                       'unclassifiedFindings': 0, 'errors': 0,
                       'scope': 'Complete unchanged header/runtime patterns and current known-value searches; exact prior-source pattern cache only',
                       'noUniversalSecretFreeClaim': True}
    privacy_summary['rawArchiveOutcomes'] = [{'archive': row['archive'], 'rawScannerStatus': row['rawScannerStatus'],
                                             **{key: value for key, value in row.items() if
                                                isinstance(value, int) and ('Candidate' in key or 'Collision' in key)}}
                                            for row in gate['archives']]
    privacy_summary['rawScannerResultsModified'] = gate['rawScannerResultsModified']
    ck(not privacy_summary['rawScannerResultsModified'], 'raw scanner outcomes were modified')
    privacy_summary['supportOnlySyntaxClassification'] = support_privacy_scope(gate, recovery)
    privacy_summary['classificationCounts'] = {key: value for key, value in gate.items() if
                                              isinstance(value, int) and ('Candidate' in key or 'Collision' in key)}
    manifest = {key: base[key] for key in INHERIT_KEYS}
    manifest.update({'schemaVersion': 9, 'createdAt': now(), 'title': 'Roadmark CUPRA registered working recovery',
                     'status': scope['workingResult'], 'workState': state, 'source': source,
                     'baseRecovery': {'manifest': base_ref, 'manifestLibraryFileId': prior['manifestLibraryFileId'],
                                      'indexLibraryFileId': prior['indexLibraryFileId'],
                                      'activeReceiptLibraryFileId': prior['activeReceiptLibraryFileId'],
                                      'terminalReceiptPin': pin(BASE_TERMINAL),
                                      'terminalClosurePin': pin(BASE / 'INDEPENDENT-KGM-TERMINAL-CLOSURE-v1.json'),
                                      'archives': 135, 'logicalFiles': 13380, 'unchangedArchivesReused': 134,
                                      'priorSource': base['source'], 'priorRecoverySeparatelyPreserved': True,
                                      'priorKGMTypeScriptPassed': False, 'priorKGMReleaseReady': False,
                                      'priorKGMFailureDoesNotEstablishCUPRAPass': True},
                     'archivesInRestoreOrder': archives, 'newArchives': fresh, 'files': plan['files'],
                     'incrementalVerification': {key: plan[key] for key in COUNT_KEYS},
                     'verificationScope': 'Every fresh source, proof and support member verified through XZ EOF. Exact inherited terminal identities and final overlay reused; no full base restore or privacy rescan.',
                     'independentVerification': recovery_summary, 'privacyVerification': privacy_summary,
                     'captureScope': {'receipt': ref(C / 'FROZEN-CAPTURE-SCOPE.json'),
                                      'authorInventory': scope['authorInventory'], 'selectedFiles': len(scope['files']),
                                      'roots': scope['roots'], 'noBroadQaTraversal': True},
                     'sourceCapture': {'receipt': ref(C / 'source-capture.json'), 'cutoff': capture['captureCutoff'],
                                       'files': len(capture['files']), 'fullCloneCreated': False},
                     'sourceChangedPaths': scope['sourceChangedPaths'],
                     'authorFinalAcceptance': {'path': str(AUTHOR_ACCEPTANCE), **AUTHOR_ACCEPTANCE_PIN},
                     'copyOnlySanitation': sanitation,
                     'generatedSupportMetadataCopy': support_copy,
                     'copyOnlySanitationReference': ref(sanitation_path),
                     'deepalSanitationReview': deepal_review,
                     'currentProofCapture': {'receipt': ref(proof_capture_path), 'selectedOriginalFiles': len(proof_capture['files']),
                                             'newDeltaFiles': len(proof_capture['changedFiles'])},
                     'currentRawCaptureReplayLimitation': 'Sanitized copied bytes verify retained hashes only; they cannot silently satisfy original raw expected pins. Original files and expected raw pins remain unchanged.',
                     'inheritedCopyOnlySanitation': base['inheritedCopyOnlySanitation'] + [{'cut': 'KGM', 'mapping': base['copyOnlySanitation']}],
                     'inheritedCurrentRawCaptureReplayLimitation': base['currentRawCaptureReplayLimitation'],
                     'inheritedCurrentCopySourcePinReferenceCounts': base['inheritedCurrentCopySourcePinReferenceCounts'],
                     'inheritedDeepalCopySourcePinReferenceCounts': {'copiedFiles': deepal_review['pinReferencedCopiedFiles'], 'references': deepal_review['summary']['sourcePinReferences']},
                     'symlinkReconstruction': load(C / 'SYMLINK-RECONSTRUCTION.json'),
                     'inheritedLinkAndDuplicateScope': {'priorManifest': base_ref,
                                                       'priorSymlinkReconstructionPointer': '/symlinkReconstruction',
                                                       'priorInheritedScopePointer': '/inheritedLinkAndDuplicateScope'},
                     'inheritedDependencyReconstruction': {'receipt': ref(C / DEPENDENCY),
                                                           'count': dependency['count'],
                                                           'dependencies': dependency['dependencies'],
                                                           'dependenciesCanonicalSha256': dependency['dependenciesCanonicalSha256'],
                                                           'relocatedMemberPointers': dependency['relocatedMemberPointers'], 'newRecords': dependency['newRecords'],
                                                           'originalExpectedPathsAndHashesUnchanged': True},
                     'inheritedDependencyReconstructionHistory': {'baseManifest': base_ref,
                                                                  'jsonPointer': '/inheritedDependencyReconstruction'},
                     'supportArchive': {'archive': support, 'members': support_members,
                                        'codeRetention': 'Each new unique executable retained once as an exact raw member; no executable source text in documents',
                                        'reuseMapping': ref(C / 'SUPPORT-REUSE-MAPPING.json'),
                                        'deliveryScriptBindings': support_script_bindings,
                                        'postSealReceipts': 'Exactly three data-only post-seal receipts are reconstructed once in verification; active receipt references them; no archive contains its own hash or scan result'},
                     'deepalSanitizedSupport': base['deepalSanitizedSupport'],
                     'cupraFactualCaptureProvenance': inventory['knownSanitizedSupport'],
                     'inheritedMINIFactualCaptureProvenance': base['inheritedMINIFactualCaptureProvenance'],
                     'inheritedKGMFactualCaptureProvenance': base['kgmFactualCaptureProvenance'],
                     'currentRawRuntimeExclusion': inventory['rawRuntimeExclusion'],
                     'currentExcludedItems': scope['authorRetention']['excluded'],
                     'inheritedKGMRecoveryBoundaries': {key: base[key] for key in
                         ('generatedSupportMetadataCopy', 'currentRawRuntimeExclusion', 'currentExcludedItems',
                          'currentRawCaptureReplayLimitation', 'rawDeepalOriginalReadRecoveryRefetchForbidden',
                          'rawKgmOriginalReadRecoveryRefetchForbidden')},
                     'mutablePreparationLimitation': inventory['mutableV1Limitation'],
                     'sourceRetention': state['sourceRetention'],
                     'rawDeepalOriginalReadRecoveryRefetchForbidden': True, 'rawKgmOriginalReadRecoveryRefetchForbidden': True, 'rawCupraOriginalReadRecoveryRefetchForbidden': True,
                     'currentImageProvenance': load(C / 'IMAGE-PROVENANCE.json'),
                     'inheritedImageProvenance': {'priorManifest': base_ref, 'jsonPointer': '/currentImageProvenance'},
                     'targetedHistoricalSeedReadDependency': {'scope': load(C / 'TARGETED-SEED-READ-DEPENDENCY.json'),
                                                              'executionsAsOfBuild': seed_summary()},
                     'backupResourceConfiguration': {'localAddressSpaceBytes': LIMIT, 'streamChunkBytes': CHUNK,
                                                     'xzPreset': 6, 'xzThreads': 1, 'xzDictionaryBytes': 8388608,
                                                     'noNewMemoryCapException': True,
                                                     'networkHelperSeparate': 'Official prepared network helper is outside the local compute cap'},
                     'factualSummary': {'filename': DOCS[3].name, 'sourceMember': 'roadmark/docs/CUPRA_M1_UPDATE.md',
                                        **pin(summary_path), 'copiedExactly': True},
                     'restoreInstructions': ['Download only the exact listed native archive identities and versions',
                                             'Verify compressed SHA-256 before restoring into a new empty directory',
                                             'Safely restore regular files in restoreOrder; reject absolute paths, traversal, duplicate archive entries and unexpected types',
                                             'Verify every final logical file against files; sanitized hashes cannot satisfy original raw expected pins',
                                             'Recreate only documented links after exact target checks; install dependencies normally before dependency links',
                                             'Never recover, read or refetch the excluded raw Deepal support-script body or substitute unsafe historical copies',
                                             'Inherited KGM raw runtime was discarded before persistence; do not reconstruct or refetch it',
                                             'Missing original reviewed 81-pin mutable light-v1 preparation bytes are unavailable; do not reconstruct them from the six excluded current unversioned files',
                                             'CUPRA raw runtime was discarded before persistence; do not reconstruct or refetch raw HTML/configuration, headers, cookies, credentials or client-key payloads',
                                             'The source attachment independently restores application source; the full chain adds research, QA and proof history',
                                             'Run project setup and separately permitted fresh checks; current TypeScript, full-suite, build, visual, mobile, M1 and release gates remain open'],
                     'noDeletionOrReplacement': True, 'noPinnedSourceOrStatusMutation': True,
                     'noExecutableSourceTextEmbedded': True})
    no_embedded_source(manifest)
    D.mkdir(exist_ok=True)
    dump(DOCS[1], manifest)
    verification = {'schemaVersion': 9, 'createdAt': manifest['createdAt'], 'result': 'PASS_NEW_ARCHIVES_AND_NATIVE_IDENTITIES',
                    'status': manifest['status'], 'manifest': {'filename': DOCS[1].name, **pin(DOCS[1])},
                    'source': source, 'counts': manifest['incrementalVerification'], 'workState': state,
                    'independentVerification': recovery_summary, 'privacyVerification': privacy_summary,
                    'supportArchive': support, 'dependencyMapping': ref(C / DEPENDENCY),
                    'dependencyCount': dependency['count'], 'dependencyRelocations': dependency['relocatedMemberPointers'],
                    'copyOnlySanitationReference': manifest['copyOnlySanitationReference'],
                    'generatedSupportMetadataCopy': support_copy,
                    'deepalSanitationReview': deepal_review,
                    'currentRawCaptureReplayLimitation': manifest['currentRawCaptureReplayLimitation'],
                    'imageProvenance': manifest['currentImageProvenance'],
                    'inheritedLocalSeedExecutionsAtFreshVerification': recovery['inheritedLocalSeedExecutions'],
                    'sourceChangedPaths': scope['sourceChangedPaths'],
                     'authorFinalAcceptance': {'path': str(AUTHOR_ACCEPTANCE), **AUTHOR_ACCEPTANCE_PIN},
                    'targetedSeedExecutionsAsOfBuild': manifest['targetedHistoricalSeedReadDependency']['executionsAsOfBuild'],
                    'inheritedPolicyManifest': base_ref, 'allInheritedSanitationExclusionsPreserved': True,
                    'originalRawPinsNotInterchangeableWithSanitizedCopies': True,
                    'rawDeepalOriginalReadRecoveryRefetchForbidden': True, 'rawKgmOriginalReadRecoveryRefetchForbidden': True, 'rawCupraOriginalReadRecoveryRefetchForbidden': True,
                    'deepalSanitizedSupport': base['deepalSanitizedSupport'],
                     'cupraFactualCaptureProvenance': inventory['knownSanitizedSupport'],
                     'inheritedMINIFactualCaptureProvenance': base['inheritedMINIFactualCaptureProvenance'],
                     'inheritedKGMFactualCaptureProvenance': base['kgmFactualCaptureProvenance'],
                     'currentRawRuntimeExclusion': inventory['rawRuntimeExclusion'],
                    'noUniversalSecretFreeClaim': True, 'nativeArchiveResultsVerified': True,
                    'remotePayloadRedownloadPerformed': False, 'noExecutableSourceTextEmbedded': True,
                    'resourceConfiguration': manifest['backupResourceConfiguration'], 'openGates': scope['openGates']}
    verification['postSealReceipts'] = post_seal_receipts()
    verification['postSealReceiptReconstruction'] = 'Re-serialize each record with its declared UTF-8 JSON settings, preserve insertion order, append one newline and verify its original byte count and SHA-256. Exactly three records are retained once here: final recovery receipt, final privacy gate and pinned replay-input manifest. Source bodies, logs, full prior manifests and the deterministic replay-member manifest are not embedded.'
    verification['cupraPrivacyAdapter'] = ref(C / 'CUPRA-PRIVACY-ADAPTER-CONTRACT.json')
    no_embedded_source(verification)
    dump(DOCS[2], verification)
    lines = ['# Roadmark CUPRA working recovery — 15 October 2026', '', manifest['status'], '',
             'Author freeze: ' + state['authorFreezeAt'],
             f"Full source: {source['filename']} ({source['bytes']:,} bytes), Library {source['library_file_id']} v{source['version']}",
             f"Recommended chain: {plan['archiveCount']} archives, {plan['logicalFiles']:,} logical files; {plan['baseArchivesReused']} unchanged KGM archives reused",
             f"Fresh replay: {plan['freshFiles']:,} members / {plan['freshBytes']:,} logical bytes", '',
             '151 fresh scoped behavioural and safety tests, changed-file lint, market-view and structural validation passed independently. One actual normal report and exhaustive saved-report comparison passed under an explicit factual-only exception.',
             f"Application proof covers {application_assertion_scope['totalAssertions']} assertions: {application_assertion_scope['freshArchiveAssertions']} fresh and {application_assertion_scope['exactInheritedAssertions']} exactly inherited, plus {application_assertion_scope['mandatoryRetainedPins']} retained pins. The independent verifier reread zero inherited payloads. Historical proofs do not establish a current full-project CUPRA TypeScript pass.",
             'Current counts: 430 catalogue, 353 tier-one, 312 on-sale, 29 registered packets. Three additions and all 427 unchanged peers are accounted for. Current CUPRA full-project TypeScript remains UNPASSED after two inherited KGM SIGKILL terminations whose causes are unknown. Both fresh KGM caches are absent; no new CUPRA compiler run or retry occurred. No compiler retry is permitted by this recovery.',
             'The sole normal report and exact saved comparator explain all 1,429 changed leaves with zero unexplained differences, under the explicit factual-only exception. This does not turn either inherited compiler failure into a pass. Historical TypeScript successes apply only to their historical source snapshots.',
             'Full-stage-v1 and docs-v1 are held unexecuted preparations. Source-v2 retains its towing-transcription hold; corrected source-v3 is independently accepted. Both actual earlier KGM TypeScript failures, their empty logs, scope-failure receipts and independent reviews remain available through the pinned existing chain. No CUPRA runtime failure occurred.',
             'The active/held source union is 97: 86 accepted-v3 pins plus 11 held-v2-only pins. Initial mutable light-v1 preparation was overwritten after its 81-pin review; original reviewed preparation bytes are missing and are not reconstructed. Six current mutable unversioned files remain excluded. Original public captures/PDFs and accepted production history were untouched.',
             'Six historical Deepal preview receipts are preserved; they do not establish CUPRA visual QA. Zero CUPRA UI screenshots and no CUPRA browser, visual, phone or mobile pass. No helper or test changes. Current full aggregate suite, production build, strict M1 closure and release remain open.',
             '## Restore safely',
             *['- ' + line for line in manifest['restoreInstructions']], '',
             'All inherited sanitation exclusions and cleanup restrictions are retained. Five historical Toyota browser screenshots remain excluded; missing Mercedes captures remain unavailable. Restore only the listed approved chain. No deletions or replacement of older recoveries were performed.',
             'Only existing sanitized Deepal api-manager-js.html, api-manager-js.txt and their receipt are retained. The original raw body must never be read, recovered or refetched. Original expected pins remain historical expectations and cannot be silently satisfied by sanitized copies.',
             f"Inherited Deepal copy-only sanitation covered {classified['summary']['proposedRuntimeValueRanges']} exact ranges in {classified['summary']['files']} captures. {deepal_review['pinReferencedCopiedFiles']} copied captures retain {classified['summary']['sourcePinReferences']} original source-pin references unchanged. Four HTML factual projections are unchanged; the one JSON change is only the opaque query at /scripts/24.",
             'The inherited Deepal detector gap is retained explicitly: ' + classified['originalDetectorCoverageGap'] + ' The separately pinned historical Deepal exact two-shape raw-byte inventory supplements it; this is not a new CUPRA field inventory. Generic decoding was not added; generic arbitrary-decoding coverage is not claimed.',
             f"Reviewed Deepal residual searches use {deepal_counters['deepalRuntimeValues']} distinct values and {deepal_counters['deepalRuntimeForms']} supported forms, with {deepal_counters['deepalOriginalPayloadReadOperations']} exact captured-file reads per current scan. Earlier pre-adapter scans remain separately counted.",
             'Two existing public maker MY25.5 PDF-page PNGs are retained with exact file and parent-PDF/text/provenance pins: page 27 Technical and page 28 Full features. The historical technical.png filename shows Full features. These are source-review imagery, with no current MY26 equipment inference and no browser or device pass. Three public PDFs are retained. No new render was performed for recovery; prior image provenance stays in the inherited KGM manifest. This does not authorize reconstruction or refetch of source images, configuration payloads or excluded runtime.',
             f"{dependency['count']} exact dependency reconstruction records include {dependency['relocatedMemberPointers']} before-copy relocations and {dependency['newRecords']} new records. Expected original paths and hashes are unchanged. Install dependencies normally; do not capture excluded dependency trees.",
             f"There are zero source transformations, {support_copy['sourceProofTransformationScope']['proofMetadataKeyRenames']} separately approved proof metadata key renames and zero current generated-support metadata key renames. Each approved copy changes only its exact reviewed root prose key, preserves the value and all outside-key bytes, and cannot satisfy the original expected whole-file pin. Original files and expected pins remain unchanged. Current generated recovery-support metadata uses approvalScope directly. The large preliminary proposal remains local and excluded from support. The inherited KGM generated-support copy mapping and its original-versus-copy hash qualification remain preserved.",
             'Each new unique support executable is retained once as a raw archive member. Reports and documents contain reference-only support identities, compact outcomes and necessary restore mappings, never nested script bodies.',
             'Privacy scope uses unchanged complete patterns and all current known-value forms. Each serial scan reconstructs 200 exact pinned historical seed members across 21 archives, including nine reused-chain archives; six Audi values add 37 forms through six bounded original reads. This is disclosed targeted seed reconstruction, not a full-base rescan. No original raw Deepal body is read. No universal absence guarantee.',
             'Each complete scan also performs 48 inherited local value reads and 48 integrity reads, accounted from reviewed selector control flow and paired completion receipts rather than separate per-file instrumentation.',
             f"Current support syntax approval covers exactly {privacy_summary['supportOnlySyntaxClassification']['exactApprovedSyntaxCandidates']} independently reviewed AST-bound candidates in the exact current support bytes. Any missing, duplicate or unexpected findings block. Prior KGM or MINI support-syntax grants are not reused for changed CUPRA bytes. The original privacy_v1 scanner remains unchanged for ordinary archive and document scans. No payload redaction or extension-wide exemption is added.",
             'Raw scanner outcomes and any exact separately approved syntax classifications remain unchanged. Their archive-by-archive statuses and classification counts are included in the verification document; no finding is silently erased.',
             'The verification document contains the final independent recovery receipt, final privacy gate and pinned replay-input manifest once each as data-only JSON, with exact serialization instructions and original byte/hash pins. Other documents reference these records; no source bodies, logs, full prior manifests or deterministic replay-member manifest are nested into them.',
             'Local package/scan/replay compute cap: 256 MiB; XZ preset 6, one thread, 8 MiB dictionary. The prepared network helper runs separately.', '',
             '## Restore order', '']
    for row in archives:
        lines.append(f"{row['restoreOrder']}. {row['filename']} | {row['library_file_id']} v{row['version']} | {row['bytes']} bytes | SHA-256 {row['sha256']}")
    lines += ['', '## Preserved earlier recovery', 'KGM index: ' + prior['indexLibraryFileId'],
              'KGM manifest: ' + prior['manifestLibraryFileId'], 'KGM active receipt: ' + prior['activeReceiptLibraryFileId'],
              'Affected old-copy cleanup list: ' + base['cleanupListLibraryFileId'] + '; no deletions performed', '']
    with DOCS[0].open('x') as handle:
        handle.write('\n'.join(lines))
    with DOCS[3].open('xb') as handle:
        handle.write(summary_path.read_bytes())
    check(DOCS[3], summary_row)
    dump(C / 'library-documents-request.json', {'uploads': [{'local_path': str(path), 'purpose': 'create_library_file',
                                                           'library_artifact_type': 'report'} for path in DOCS]})
    print(json.dumps({'documents': 4, 'recommendedArchives': len(archives), 'logicalFiles': plan['logicalFiles'],
                      'sourceBytes': source['bytes'], 'noEmbeddedScriptsOrReports': True}))

if __name__ == '__main__':
    main()
