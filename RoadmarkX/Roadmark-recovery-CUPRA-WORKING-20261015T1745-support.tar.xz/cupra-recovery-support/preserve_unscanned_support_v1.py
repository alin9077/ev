#!/usr/bin/env python3
"""Preserve the exact unscanned first support preparation before an approved rebuild."""
import datetime,hashlib,json,os,pathlib,resource,stat,sys
P=pathlib.Path;C=P(__file__).resolve().parent
assert sys.argv[1:]==['preserve','--sole-child-slot-authorized'] and resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456)
def pin(p):
 p=P(p);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents);before=(s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev);h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(65536):h.update(b);n+=len(b)
 s=p.lstat();assert before==(s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev);return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
pp=C/'UNSCANNED-SUPPORT-v1-PRESERVATION-PLAN.json';expected={'bytes':5352,'sha256':'635100fb3c6564296e8dbe73424509fd80a01e4bc18bb33f85b68f40258f545a'};actual=pin(pp);assert {k:actual[k] for k in expected}==expected;q=json.loads(pp.read_bytes());assert q['result']=='ROOT_APPROVED_EXACT_BYTE_PRESERVING_UNSCANNED_SUPPORT_REBUILD' and not q['firstSupportPrivacyScanPerformed'] and not q['firstSupportUploaded']
required={str(C/n) for n in ('SUPPORT-SELECTION-PROPOSAL-v1.json','SUPPORT-SELECTION-v1.json','SUPPORT-MEMBER-INVENTORY.json','SUPPORT-REUSE-MAPPING.json','support-package.json','RESTORE-PLAN.json','ARCHIVE-PLAN.json','FRESH-ONLY-RESTORE-MANIFEST.json')}|{str(C.parents[1]/'Roadmark-recovery-CUPRA-WORKING-20261015T1745-support.tar.xz')};assert {r['original']['path'] for r in q['files']}==required and len(q['files'])==9
assert not (C/'scan-fresh-04.resources.invocation.json').exists() and not (C/'library-archives-results.json').exists(),'support may already have been scanned or uploaded; stop for reconciliation'
dest=C/'preserved-unscanned-support-v1';assert not dest.exists();out=C/'UNSCANNED-SUPPORT-v1-PRESERVATION-RECEIPT.json';assert not out.exists()
for r in q['files']:
 p=P(r['original']['path']);target=P(r['preservedPath']);assert target==dest/p.name and not target.exists() and pin(p)==r['original']
dest.mkdir();moved=[]
try:
 for r in q['files']:
  p=P(r['original']['path']);target=P(r['preservedPath']);assert pin(p)==r['original'] and not target.exists();os.rename(p,target);saved=pin(target);assert {k:saved[k] for k in ('bytes','sha256')}=={k:r['original'][k] for k in ('bytes','sha256')} and not p.exists();moved.append({'original':r['original'],'preserved':saved})
except BaseException:
 with (C/'UNSCANNED-SUPPORT-v1-PRESERVATION-PARTIAL.json').open('x') as f:json.dump({'result':'PARTIAL_PRESERVATION_REQUIRES_RECONCILIATION','plan':actual,'moved':moved},f,indent=2);f.write('\n')
 raise
receipt={'result':'PASS_EXACT_BYTE_PRESERVING_MOVE','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'plan':actual,'files':moved,'movedFiles':len(moved),'unscanned':True,'unuploaded':True,'noBytesDeletedOrModified':True,'sourceProofArchivesScansScriptsPhaseReceiptsLogsUntouched':True,'localOnlySupersededPreparation':True,'activeOutputNamesAbsentReadyForReviewedRebuild':True}
with out.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'result':receipt['result'],'movedFiles':len(moved),'receipt':pin(out)}))
