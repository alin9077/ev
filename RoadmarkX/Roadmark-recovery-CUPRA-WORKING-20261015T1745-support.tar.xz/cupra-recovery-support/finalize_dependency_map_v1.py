#!/usr/bin/env python3
"""Bind reviewed CUPRA metadata dependencies; never infer fresh replay success."""
from independent_cupra_common_v1 import *

def main():
 command('finalize')
 contract_path=C/'CUPRA-RECOVERY-METADATA-FINALIZATION-CONTRACT-v1.json'
 check(contract_path,{'bytes':9692,'sha256':'3387c39537bccc8f79cbce2468c757d4a0cf0a21ca4ca95fa1e5f26d88d523f1'});contract=load(contract_path)
 for name in ('FROZEN-CAPTURE-SCOPE.json','INDEPENDENT-CUPRA-DEPENDENCY-v2-STATIC-REVIEW.json','build_independent_cupra_dependencies_v2.py','independent_cupra_common_v1.py'):check(C/name,contract['inputPins'][name])
 review=load(C/'INDEPENDENT-CUPRA-DEPENDENCY-v2-STATIC-REVIEW.json');ck(review['result']=='PASS_EXACT_TWO_MEMBER_ARCHIVE_ATTRIBUTION_CORRECTION' and review['correctedScript']==pin(C/'build_independent_cupra_dependencies_v2.py'),'dependency correction review differs')
 terminal_path=P(contract['pendingDependencySuccessTerminal']);invocation_path=P(contract['pendingDependencySuccessInvocation']);terminal=load(terminal_path);invocation=load(invocation_path)
 ck(terminal['command']==invocation['command']==contract['requiredDependencySuccessCommand'] and terminal['exitCode']==0 and not terminal['timedOut'],'corrected dependency execution not passed')
 ck(terminal['addressSpaceLimitBytes']==invocation['addressSpaceLimitBytes']==LIMIT and terminal['wallLimitSeconds']==invocation['wallLimitSeconds']==600 and terminal['childPid']==invocation['childPid'] and terminal['startedAt']==invocation['startedAt'] and terminal['maxRssKiB']>0,'corrected dependency bounds differ')
 proposal_path=C/'INDEPENDENT-CUPRA-DEPENDENCY-PROPOSAL-v1.json';proposal=load(proposal_path)
 ck(proposal['result']=='PASS_EXACT_METADATA_ONLY_DEPENDENCY_PROPOSAL','dependency proposal not passed')
 base_path=P(contract['baseDependencyMap']['path']);check(base_path,contract['baseDependencyMap']);base=load(base_path)
 ck(len(base['dependencies'])==proposal['inheritedDependencyRecords']==proposal['unchangedInheritedRecords']==181,'inherited count differs')
 ck(proposal['baseDependencyMap']==pin(base_path),'base dependency pin differs')
 ck(not proposal['relocationProposals'] and not proposal['inheritedPointerIntersections'],'new inherited relocation requires separate reviewed finalizer')
 ck(proposal['originalExpectedPathsAndHashesUnchanged'] and proposal['metadataOnly'] and proposal['externalPayloadReads']==proposal['archivePayloadReads']==0,'dependency operation scope differs')
 dependencies=base['dependencies']+proposal['newDependencyRecords']
 ck(len(dependencies)==proposal['proposedDependenciesCount'] and len({r['originalPath'] for r in dependencies})==len(dependencies),'dependency record multiset differs')
 canonical=hashlib.sha256(json.dumps(dependencies,sort_keys=True,separators=(',',':')).encode()).hexdigest();ck(canonical==proposal['proposedDependenciesCanonicalSha256'],'dependency canonical hash differs')
 scope=load(C/'FROZEN-CAPTURE-SCOPE.json');changed=sorted('roadmark/'+n for n in scope['sourceChangedPaths'])
 ck(proposal['allSixFinalSourceChangedPaths']==changed and len(scope['sourceChangedPaths'])==6,'changed source paths differ')
 ck(proposal['frozenScope']==pin(C/'FROZEN-CAPTURE-SCOPE.json'),'scope pin differs')
 base_manifest=P(contract['baseManifest']['path']);check(base_manifest,contract['baseManifest']);ck(proposal['baseManifest']==pin(base_manifest),'base manifest pin differs');manifest=load(base_manifest)
 ck(manifest['inheritedDependencyReconstruction']['dependencies']==base['dependencies'],'base dependency authorities differ');old=rows(manifest['files'])
 for r in dependencies:
  ck(r['pins'],'empty dependency pin set')
  for p in r['pins']:
   ck(p['expected']['path']==r['originalPath'] and sh(p['expected'])==sh(p['member']),'original expected identity differs')
   ck(old[p['member']['path']]==core(p['member']) and p['member']['path'] not in changed,'inherited member changed')
 q={'schemaVersion':1,'result':'FINAL_LAYOUT_METADATA_BOUND_PENDING_FRESH_ARCHIVE_REPLAY','createdAt':now(),'baseManifest':proposal['baseManifest'],'proposal':pin(proposal_path),'frozenScope':pin(C/'FROZEN-CAPTURE-SCOPE.json'),'count':len(dependencies),'originalExpectedPathsAndHashesUnchanged':True,'relocatedMemberPointers':0,'inheritedRelocatedMemberPointers':base['relocatedMemberPointers']+base.get('inheritedRelocatedMemberPointers',0),'inheritedMapping':pin(base_path),'unchangedInheritedRecords':len(base['dependencies']),'newRecords':len(proposal['newDependencyRecords']),'allSixFinalSourceChangedPathsIntersected':True,'inheritedPointerIntersections':[],'dependenciesCanonicalSha256':canonical,'dependencies':dependencies,'noExternalPayloadOrArchiveReads':True,'metadataFinalizationContract':pin(contract_path),'dependencyProposalExecution':{'terminal':pin(terminal_path),'invocation':pin(invocation_path)}}
 dump(C/'INHERITED-DEPENDENCY-RECONSTRUCTION-v1.json',q)
 print(json.dumps({'result':q['result'],'records':len(dependencies),'newRecords':len(proposal['newDependencyRecords']),'currentRelocations':0}))

if __name__=='__main__':main()
