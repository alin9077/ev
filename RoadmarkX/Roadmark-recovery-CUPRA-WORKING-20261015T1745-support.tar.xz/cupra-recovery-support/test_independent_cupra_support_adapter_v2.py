#!/usr/bin/env python3
"""Exact support hook and fail-closed tests for both approved code members."""
import ast,copy,datetime,hashlib,importlib.util,json,pathlib,resource,sys
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent
assert resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456)
def pin(p):
 b=P(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p):return json.loads(P(p).read_bytes())
base=C/'privacy_v1.py';support=C/'privacy_v3_support.py';before=base.read_bytes();after=support.read_bytes();needle=b'us,classified=template_context(us,data,m.name);';hook=b'from cupra_support_classifications_v2 import code_context as cupra_code_context;ps,classified=cupra_code_context(ps,data,m.name);codeClassified.extend(classified);';guard=b"from verify_cupra_support_contract_v2 import verify as verify_support_contract\nif __name__=='__main__':verify_support_contract()\n";anchor=b'import sys,pathlib,json,hashlib,importlib.util,lzma,tarfile,re,datetime,inspect';assert before.count(needle)==before.count(anchor)==1 and after==before.replace(needle,hook+needle).replace(anchor,guard+anchor)
for p in [base,support,C/'cupra_support_classifications_v2.py']:ast.parse(p.read_bytes())
spec=importlib.util.spec_from_file_location('cupra_exact_support_test',C/'cupra_support_classifications_v2.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);classification=load(C/'INDEPENDENT-CUPRA-SUPPORT-SYNTAX-CLASSIFICATION-v2.json');approved=classification['exactSupportCodeClassifications'];assert len(approved)==12;tests=[]
def passed(name):tests.append({'name':name,'passed':True})
def rejects(name,fn):
 try:fn()
 except AssertionError:passed(name)
 else:raise AssertionError('expected fail-closed rejection: '+name)
for member in sorted({r['member'] for r in approved}):
 own=[r for r in approved if r['member']==member];data=(C/P(member).name).read_bytes();candidates=[{k:v for k,v in r['exactFinding'].items() if k!='member'} for r in own];label=P(member).name+': ';blocked,classified=m.code_context(copy.deepcopy(candidates),data,member);expected=[{'member':r['member'],'filePin':r['filePin'],'finding':{k:v for k,v in r['exactFinding'].items() if k!='member'},'classification':r['classification']} for r in own];assert blocked==[] and classified==expected;passed(label+'exact candidate multiset classified')
 extra={'kind':'unexpected-candidate','location':{'pointer':'','line':1,'charStart':0,'charEnd':1},'confidence':'needs-context','header':'x-unreviewed','valueType':'str','valueLength':0};blocked,classified=m.code_context(candidates+[extra],data,member);assert blocked==[extra] and classified==expected;passed(label+'extra candidate remains blocking');rejects(label+'missing candidate rejected',lambda:m.code_context(candidates[:-1],data,member));rejects(label+'duplicate candidate rejected',lambda:m.code_context(candidates+[candidates[0]],data,member));rejects(label+'wrong whole-file bytes rejected',lambda:m.code_context(candidates,data+b' ',member));wrong=copy.deepcopy(candidates);wrong[0]['location']['charStart']+=1;rejects(label+'wrong location rejected',lambda:m.code_context(wrong,data,member));blocked,classified=m.code_context(candidates,data,'cupra-recovery-support/not-approved.py');assert blocked==candidates and classified==[];passed(label+'unapproved member receives no exemption');real_load=m.load;index=approved.index(own[0])
 for field,value,name in [('byteStart',own[0]['byteStart']+1,'wrong span hash rejected'),('lineSHA256','0'*64,'wrong complete-line hash rejected'),('astStatementSHA256','0'*64,'wrong AST hash rejected')]:
  altered=copy.deepcopy(classification);altered['exactSupportCodeClassifications'][index][field]=value;m.load=lambda p,altered=altered:copy.deepcopy(altered) if P(p)==m.CLASSIFICATION else real_load(p)
  try:rejects(label+name,lambda:m.code_context(candidates,data,member))
  finally:m.load=real_load
 if own[0]['astStatementType']=='LineStatementSequence':
  altered=copy.deepcopy(classification);altered['exactSupportCodeClassifications'][index]['astStatements'][0]['colOffset']+=1;m.load=lambda p:copy.deepcopy(altered) if P(p)==m.CLASSIFICATION else real_load(p)
  try:rejects(label+'wrong shared-line statement identity rejected',lambda:m.code_context(candidates,data,member))
  finally:m.load=real_load
q={'result':'PASS_EXACT_SUPPORT_ONLY_ADAPTER_AND_FAIL_CLOSED_TESTS','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseEngine':pin(base),'supportEngine':pin(support),'supportSyntaxHandler':pin(C/'cupra_support_classifications_v2.py'),'classification':pin(C/'INDEPENDENT-CUPRA-SUPPORT-SYNTAX-CLASSIFICATION-v2.json'),'supportSyntaxApproval':pin(C/'APPROVED-CUPRA-SUPPORT-SYNTAX.json'),'testScript':pin(__file__),'tests':tests,'testCount':len(tests),'exactCandidates':12,'rawPrimaryCandidatesRetained':True,'unexpectedCandidatesRemainBlocking':True,'missingDuplicateWrongMemberOrHashCannotBeClassified':True,'engineChange':'Only exact CUPRA syntax hook; inherited seeds, detector searches and runtime/template handling byte-unchanged','baseSourceProofAndDocumentScansUnchanged':True,'noPayloadRedactions':True,'newBroadExemptions':0,'seedReads':0,'archivePayloadReads':0,'liveSourceWrites':0,'onlyInMemoryFaultInjection':True,'entryGuard':pin(C/'verify_cupra_support_contract_v2.py'),'sourceEntryPoint':pin(C/'scan_archive_v1.py')};out=C/'INDEPENDENT-CUPRA-SUPPORT-ADAPTER-REVIEW-v1.json'
with out.open('x') as f:json.dump(q,f,indent=2);f.write('\n')
print(json.dumps({'result':q['result'],'tests':len(tests),'pin':pin(out)}))
