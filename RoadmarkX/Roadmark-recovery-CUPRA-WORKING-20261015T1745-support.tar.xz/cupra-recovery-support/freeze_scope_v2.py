"""Freeze exactly the accepted CUPRA list and three separately pinned metadata inputs."""
from capture_v1 import *
inventory=P('/tmp/cupra-packet/final-freeze-v1/inventory.json')
inventoryPin={'bytes':147107,'sha256':'798f05ab19b2632f0ee091305430c16105e59ae7df3fa316766feb2d54f3ee55'}
review=P('/tmp/cupra-review/final-retention-v1-accepted.json')
reviewPin={'bytes':4908,'sha256':'2b024c76cfa72634b74be4ea0d49f966e42a6f185ae2161b506d2a64b32d6f7f'}
check(inventory,inventoryPin);check(review,reviewPin);v=load(inventory);acceptance=load(review)
assert v['schemaVersion']==1 and v['noFurtherPayloadEdits'] and v['metadataOnlyInventory'] and not v['contentCaptureOrPrivacyScanPerformed']
assert v['totalFiles']==len(v['files'])==450 and v['symlinkCount']==0
assert sum(r['bytes'] for r in v['files'])==v['regularFileBytes']==38201419
assert (v['acceptedSourcePins'],v['heldOnlySourcePins'],v['allowlistedSourceUnion'])==(86,11,97)
assert v['rawRuntimeExclusion']['locallyPresentExcludedOriginalPaths']==[]
assert not any(v['rawRuntimeExclusion'][k] for k in ['rawRuntimeHTMLOrConfigurationPersisted','rawResponseHeadersOrCookiesPersisted','credentialOrClientKeyPayloadPersisted','readRefetchOrRecoveryAuthorized'])
validation=v['currentValidation']
assert (validation['catalogue'],validation['tier1'],validation['onSale'],validation['scopedTests'])==(430,353,312,151)
assert validation['structuralPassed'] and validation['normalReportAndExhaustiveComparisonPassed'] and validation['factualCoverageOnly']
assert not any(validation[k] for k in ['fullProjectTypecheckPassed','releaseReady','compilerRetriesAuthorized','currentCleanFullSuite','productionBuildVerified','phoneMobileVerified'])
assert acceptance['status']=='accepted' and acceptance['inventory']=={'path':str(inventory),**inventoryPin}
assert acceptance['inventoryPreparer']==v['preparer'] and acceptance['liveTargetPins']==v['sourceAndStatusAfterPins'] and acceptance['allSevenLiveTargetsHashAndByteVerified']
assert acceptance['currentValidation']==validation and not acceptance['releaseAcceptance']
assert acceptance['metadataInventoryVerified']['files']==450 and acceptance['metadataInventoryVerified']['bytes']==38201419
assert acceptance['retentionHistory']['twoActualKgmCompilerFailuresPreservedByPinnedExistingChain'] and acceptance['retentionHistory']['mutableSourceV1OriginalReviewedBytesUnavailable'] and acceptance['retentionHistory']['noReconstructionOfMissingV1BytesClaimed']
assert len(v['publicImageProvenance']['existingPublicPdfPageRenders'])==2 and v['publicImageProvenance']['productBrowserOrPhoneScreenshots']==0
imagePath=C/'IMAGE-PROVENANCE.json';imagePin={'bytes': 4538, 'sha256': 'dab7b32e9b12113f355d2df3aeeac0ca741ce0866267765cb1621dac25b1903e'}
check(imagePath,imagePin);imageRecord=load(imagePath)
assert imageRecord['result']=='AUTHOR_AND_REVIEWER_CLASSIFIED_PUBLIC_PDF_PAGE_RENDERS'
assert imageRecord['authorInventory']=={'path':str(inventory),**inventoryPin} and imageRecord['files']==v['publicImageProvenance']['existingPublicPdfPageRenders']
assert imageRecord['imageExtensionCandidates']==2 and imageRecord['browserScreenshotsIncluded'] is False and imageRecord['newImageBodiesReadOrRendered'] is False
files={};categories={}
for row in v['files']:
 p=P(row['path']);ident=identity(p);assert p.is_absolute()
 assert row['kind']=='file' and ident[0]==row['bytes'] and ident[1]==row['mtimeNs'] and p.lstat().st_mode==row['mode']
 assert str(p) not in files;categories[row['category']]=categories.get(row['category'],0)+1
 files[str(p)]={'path':str(p),'bytes':ident[0],'mtimeNsAtFreeze':ident[1]}
 if row['category'] in ('accepted_source_v3','held_source_v2_only'):
  assert len(row['declaredSha256'])==64 and row['contentHashRecomputedAtFreeze'] is False
  files[str(p)]['knownSha256']=row['declaredSha256']
assert categories=={'packet_commands_qa_and_all_attempt_history':324,'independent_reviews':22,'accepted_source_v3':86,'held_source_v2_only':11,'live_registered_docs_status_target':7}
pins=v['sourceAndStatusAfterPins']+[v[k] for k in ['sourceAllowlist','currentAcceptedSourceManifest','heldSupersededSourceManifest','independentDocsReadback','independentSourceRetentionAcceptance','factualReportAcceptance','currentPacket','currentReconciliation','retainedStorageReadClosure']]
assert len(v['sourceAndStatusAfterPins'])==7
for row in pins:
 p=P(row['path']);assert str(p) in files,'Pin is outside exact frozen files: '+str(p)
 got,ident=check(p,row);assert files[str(p)]['mtimeNsAtFreeze']==ident[1]
 if files[str(p)].get('knownSha256'):assert files[str(p)]['knownSha256']==got['sha256']
 files[str(p)].update(got)
for row in [{'path':str(inventory),**inventoryPin},v['preparer'],{'path':str(review),**reviewPin}]:
 p=P(row['path']);got,ident=check(p,row);assert str(p) not in files
 files[str(p)]={'path':str(p),**got,'mtimeNsAtFreeze':ident[1]}
assert len(files)==453
for row in v['excluded']:assert row['path'] not in files
changed=sorted(P(row['path']).relative_to(W/'roadmark-104').as_posix() for row in v['sourceAndStatusAfterPins'] if P(row['path']).is_relative_to(W/'roadmark-104'))
assert len(changed)==6
basePins={'FINAL-KGM-UPLOAD-RECEIPTS.json':{'bytes':14335,'sha256':'6f546a2ec326bc06377f29625bd2c9c3299373395ef7628d9688a29b72074fa0'},'INDEPENDENT-KGM-TERMINAL-CLOSURE-v1.json':{'bytes':9496,'sha256':'f8cad92d4f00de7768700503214f57b4ce98421abbbac00dc4e89bbc5b661657'},'source-capture.json':{'bytes':555522,'sha256':'9d8f38f9ea38a9d98604ff4ddfb2bde280c3a8e82f16cfccecdcb6e7f7df553f'},'proof-capture-v1.json':{'bytes':876232,'sha256':'8a2c7461076312842b87acb7dc4dc07104f27cd0b6c47f083291a077754eea41'}}
for n,h in basePins.items():check(BASE/n,h)
assert load(BASE/'INDEPENDENT-KGM-TERMINAL-CLOSURE-v1.json')['result']=='PASS_TERMINAL_RECOVERY_CLOSURE'
oldSource={r['path']:r for r in load(BASE/'source-capture.json')['files']};assert len(oldSource)==694
expectedSource=set(oldSource)|set(changed);assert len(expectedSource)==697 and len(set(changed)-set(oldSource))==3
pack=module('packager',W/'roadmark-104/scripts/package-source.py');sourceFiles=list(pack.source_files(W/'roadmark-104'))
assert len(sourceFiles)==len(expectedSource) and {rel.as_posix() for rel,p in sourceFiles}==expectedSource
basepath=BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-KGM-WORKING-20261015.json'
basePin={'bytes':3246441,'sha256':'09bcfeb302b31331d0d7ed12b18553f0cf71cf0fca4017b97cd53cbafe3edba4'}
check(basepath,basePin);base=load(basepath);old={r['path']:r for r in base['files']}
assert len(old)==13380 and len(base['archivesInRestoreOrder'])==135
priorProof={r['path']:r for r in load(BASE/'proof-capture-v1.json')['files']}
overlay=[];reused=[];overlaps=[]
for pstr in sorted(files):
 p=P(pstr);n=restpath(p)
 if n.startswith('roadmark/') or n not in old:continue
 expected={k:files[pstr][k] for k in ['bytes','sha256'] if k in files[pstr]};got,ident=check(p,expected)
 assert ident[1]==files[pstr]['mtimeNsAtFreeze'];files[pstr].update(got);prior=priorProof.get(n);candidate=got
 if prior and got=={'bytes':prior['originalBytes'],'sha256':prior['originalSHA256']}:
  check(P(prior['payloadPath']),prior);candidate={k:prior[k] for k in ['bytes','sha256']}
 baseMember={k:old[n][k] for k in ['bytes','sha256']};overlaps.append({'originalPath':str(p),'member':n,'originalPin':got,'baseMemberPin':baseMember})
 if candidate==baseMember:
  assert prior and got=={'bytes':prior['originalBytes'],'sha256':prior['originalSHA256']},'Unproven original/sanitized provenance: '+n
  reused.append({'originalPath':str(p),'member':n,**baseMember,'originalBytes':got['bytes'],'originalSHA256':got['sha256']})
 else:overlay.append(n)
state='Registered CUPRA29 working cut: 430 catalogue, 353 Tier 1, 312 on sale; 151 scoped tests, structural validation, normal report and exhaustive comparison passed. Current full-project TypeScript and release remain unpassed; the two actual earlier KGM unknown-cause SIGKILLs are inherited evidence, not new CUPRA failures. Original mutable source-v1 preparation bytes are unavailable; accepted v3 and held-only v2 source union is retained without reconstructing missing v1 bytes. No compiler retry, product/browser/phone screenshot, full clean suite, build, mobile verification, strict M1 closure or release acceptance is claimed.'
with (C/'WORKING-STATE.txt').open('x') as f:f.write(state+'\n')
q={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'freezeMetadata':{'path':str(inventory),**inventoryPin},'authorRetention':v,'authorInventory':{'path':str(inventory),**inventoryPin},'finalRetentionReview':{'path':str(review),**reviewPin},'roots':v['payloadRoots'],'files':sorted(files.values(),key=lambda x:x['path']),'knownPinsVerified':len({r['path'] for r in pins})+3,'sourceChangedPaths':changed,'expectedSourceFiles':len(expectedSource),'expectedSourcePaths':sorted(expectedSource),'expectedNonSourceOverlay':sorted(overlay),'baseNonSourceOverlaps':overlaps,'reusedProofMembers':reused,'workingResult':state,'currentValidation':validation,'openGates':acceptance['remainingProductGates']+['Current full-project TypeScript','Full-project aggregate suite','Production build','CUPRA browser UI and real-device mobile verification','Release/M2'],'scopeMethod':'Exact 450-file inventory plus separately pinned inventory/preparer/final review; 97-file public source union: 86 active v3 plus 11 held-only v2; no recursive research or broad QA capture','metadataOnlySymlinks':[],'noDeletion':True,'noSymlinkTraversal':True,'rawCupraOriginalReadRecoveryRefetchForbidden':True,'rawKgmOriginalReadRecoveryRefetchForbidden':True,'rawDeepalOriginalReadRecoveryRefetchForbidden':True,'canonicalSanitizedSourceFiles':97,'rawRuntimeExclusion':v['rawRuntimeExclusion'],'baseInputPins':basePins,'imageProvenance':{'path':str(imagePath),**imagePin},'approvalScope':'Frozen CUPRA working capture and unchanged inherited seed scope only; no compiler retry, raw runtime retrieval or release acceptance'}
dump(C/'FROZEN-CAPTURE-SCOPE.json',q)
print(json.dumps({'files':len(files),'bytes':sum(r['bytes'] for r in files.values()),'sourceFiles':len(sourceFiles),'sourceDeltaPaths':len(changed),'metadataOnlyLinks':0,'exactReusedProofMembers':len(reused),'nonSourceOverlays':len(overlay)}))
