#!/usr/bin/env python3
"""Bind reviewed support-only scanner and gate metadata without source transformations."""
import datetime,hashlib,json,pathlib,resource,sys
P=pathlib.Path;C=P(__file__).resolve().parent
assert sys.argv[1:]==['bind','--sole-child-slot-authorized'] and resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456)
def load(p):return json.loads(P(p).read_bytes())
def pin(p):
 p=P(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(p,q):
 with P(p).open('x') as f:json.dump(q,f,indent=2);f.write('\n')
reviewpath=C/'INDEPENDENT-CUPRA-SUPPORT-ADAPTER-REVIEW-v1.json';review=load(reviewpath);ap=C/'APPROVED-CUPRA-SUPPORT-SYNTAX.json';approval=load(ap);cl=C/'INDEPENDENT-CUPRA-SUPPORT-SYNTAX-CLASSIFICATION-v2.json'
assert review['result']=='PASS_EXACT_SUPPORT_ONLY_ADAPTER_AND_FAIL_CLOSED_TESTS' and review['exactCandidates']==12 and review['testCount']==len(review['tests']) and all(r['passed'] for r in review['tests'])
assert approval['result']=='APPROVED_EXACT_SYNTAX_CLASSIFICATION' and approval['exactCandidates']==12 and approval['classificationPin']=={k:pin(cl)[k] for k in ('bytes','sha256')}
keys={'baseEngine':'privacy_v1.py','supportEngine':'privacy_v3_support.py','supportSyntaxHandler':'cupra_support_classifications_v2.py','classification':cl.name,'supportSyntaxApproval':ap.name}
for k,n in keys.items():assert review[k]==pin(C/n)
assert review['entryGuard']==pin(C/'verify_cupra_support_contract_v2.py') and review['sourceEntryPoint']==pin(C/'scan_archive_v1.py')
q={'result':'APPROVED_CUPRA_SUPPORT_PRIVACY_ADAPTER','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),**{k:pin(C/n) for k,n in keys.items()},'entryGuard':review['entryGuard'],'independentReview':pin(reviewpath),'exactApprovedCandidates':12,'supportArchiveOnly':True,'noDetectorOrKnownValueSearchChanges':True,'sourceProofAndDocumentEngineUnchanged':True,'rawPrimaryFindingsRetained':True,'unmatchedCandidatesRemainBlocking':True,'copyRedactions':0}
cp=C/'CUPRA-SUPPORT-PRIVACY-CONTRACT-v1.json';dump(cp,q)
gate=load(C/'CUPRA-PRIVACY-GATE-CONTRACT-v1.json');assert gate['sourceProofEngine']==pin(C/'scan_archive_v1.py') and gate['unchangedScanner']==pin(C/'privacy_v1.py')
gate['supportEngine']=pin(C/'privacy_v3_support.py');gate['supportPrivacyContract']=pin(cp);gate['independentReview']=pin(reviewpath);gate['approvalScope']='Exact unchanged source/proof entrypoint and separately approved support-only whole-file, span, line and AST syntax classifications. Every byte search and every unmatched detector finding remains unchanged.'
dump(C/'CUPRA-PRIVACY-GATE-CONTRACT-v2.json',gate)
print(json.dumps({'result':'BOUND_APPROVED_EXACT_SUPPORT_CONTRACTS','supportContract':pin(cp),'gateContract':pin(C/'CUPRA-PRIVACY-GATE-CONTRACT-v2.json')}))
