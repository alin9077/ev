#!/usr/bin/env python3
"""Bind two exact failed attempts; preserve interrupted scan as a separate unknown."""
from independent_cupra_common_v1 import *

def terminal(p,expected_command,code):
 p=P(p);ip=p.with_name(p.stem+'.invocation.json');t,iv=load(p),load(ip)
 ck(t['exitCode']==code and not t['timedOut'] and t['command']==iv['command']==expected_command,'terminal outcome differs '+p.name)
 ck(t['childPid']==iv['childPid'] and t['startedAt']==iv['startedAt'] and t['addressSpaceLimitBytes']==iv['addressSpaceLimitBytes']==LIMIT and t['wallLimitSeconds']==iv['wallLimitSeconds']==600 and t['maxRssKiB']>0,'terminal bounds differ '+p.name)
 return {'terminal':pin(p),'invocation':pin(ip),'exitCode':code}

def main():
 command('bind')
 cp=C/'CUPRA-RECOVERY-METADATA-FINALIZATION-CONTRACT-v1.json';check(cp,{'bytes':9692,'sha256':'3387c39537bccc8f79cbce2468c757d4a0cf0a21ca4ca95fa1e5f26d88d523f1'});contract=load(cp)
 for name,r in contract['inputPins'].items():check(C/name,r)
 capture_command=['python3',str(C/'capture_v1.py'),'proof'];dependency_command=['python3',str(C/'build_independent_cupra_dependencies_v1.py'),'build','--sole-child-slot-authorized']
 ck({p.name for p in C.glob('*.resources.json') if load(p)['exitCode']==1}==set(contract['expectedFailedTerminalNames'])=={'capture-proof-v1.resources.json','build-dependencies-v1.resources.json'},'exact failed preparation set differs')
 failed_capture=terminal(C/'capture-proof-v1.resources.json',capture_command,1);corrected_capture=terminal(C/'capture-proof-v1-retry1.resources.json',capture_command,0)
 failed_dependency=terminal(C/'build-dependencies-v1.resources.json',dependency_command,1);corrected_dependency=terminal(contract['pendingDependencySuccessTerminal'],contract['requiredDependencySuccessCommand'],0)
 ck(corrected_dependency['invocation']['path']==contract['pendingDependencySuccessInvocation'],'corrected dependency invocation differs')
 preservation=load(C/'PROOF-RETRY-PRESERVATION-v1.json')
 ck(preservation['result']=='PRESERVED_FAILED_PARTIAL_AND_EXACT_APPROVAL_INPUT' and preservation['preservedFileCount']==len(preservation['preservedFiles'])==86 and preservation['preservedBytes']==sum(r['bytes'] for r in preservation['preservedFiles'])==18646464 and preservation['allMovedPayloadHashesIdentical'] and preservation['noDeletionOrOriginalMutation'],'failed partial preservation differs')
 ck(preservation['failedOutputPreservedAt']==str(C/'selected-proof-sanitized-v1-failed-prose-gate') and sh(preservation['failedTerminal'])==sh(failed_capture['terminal']) and sh(preservation['retryScriptUnchanged'])==sh(pin(C/'capture_v1.py')),'failed capture preservation linkage differs')
 for key in ('priorApprovals','currentApprovals','classification','failedTerminal','retryScriptUnchanged'):check(C/preservation[key]['path'],preservation[key])
 approvals=load(C/'PROSE-KEY-RENAME-APPROVALS.json');classification=load(C/'INDEPENDENT-CUPRA-PROSE-KEY-CLASSIFICATION-v1.json');sanitation=load(C/'COPY-SANITATION-MAPPING.json')
 expected={'cupra-packet/full-stage-v2/syntax-only-check.json','cupra-packet/report-comparison-v1/syntax-only-receipt.json'}
 ck(approvals['result']=='APPROVED_EXACT_ORDINARY_PROSE_KEYS_ONLY' and approvals['sourceProofOriginalsUnchanged'] and approvals['files']==classification['files'] and len(approvals['files'])==2 and {r['restorePath'] for r in approvals['files']}==expected,'exact copy rename approval differs')
 check(C/approvals['classification']['path'],approvals['classification'])
 ck(sanitation['result']=='EXACT_REVIEWED_PROSE_KEYS_ONLY' and sanitation['locationCount']==len(sanitation['files'])==2 and sanitation['originalExpectedPinsUnchanged'] and sanitation['exactValueAndOutsideKeyBytesUnchanged'] and sanitation['independentClassification']==sh(pin(C/'PROSE-KEY-RENAME-APPROVALS.json')),'copy sanitation receipt differs')
 copied={r['path']:r for r in sanitation['files']};captured={r['path']:r for r in load(C/'proof-capture-v1.json')['files']}
 for a in approvals['files']:
  ck(a['oldPointer']=='/authorization' and a['newPointer']=='/approvalScope' and a['proseValueByteExact'] and a['allOtherJSONFieldsIdentical'] and a['allOutsideKeyBytesIdentical'] and a['originalMustRemainUnchanged'],'copy-only scope differs')
  r=copied[a['restorePath']];ck(all(r[k]==a[k] for k in ('originalPath','bytes','sha256','originalBytes','originalSHA256')) and all(captured[r['path']][k]==r[k] for k in r) and r['sha256']!=r['originalSHA256'],'copy pin linkage differs')
  ck(r['metadataKeyRename']=={'oldPointer':'/authorization','newPointer':'/approvalScope','unchangedValueAndOtherBytes':True},'copy transformation differs')
 correction=load(C/'INDEPENDENT-CUPRA-DEPENDENCY-v2-STATIC-REVIEW.json');ck(correction['result']=='PASS_EXACT_TWO_MEMBER_ARCHIVE_ATTRIBUTION_CORRECTION' and correction['priorScript']==pin(C/'build_independent_cupra_dependencies_v1.py') and correction['correctedScript']==pin(C/'build_independent_cupra_dependencies_v2.py') and correction['failedV1AttemptPreserved'] and correction['externalPayloadReads']==correction['archivePayloadReads']==0,'dependency correction review differs')
 proposal_path=C/'INDEPENDENT-CUPRA-DEPENDENCY-PROPOSAL-v1.json';proposal=load(proposal_path);ck(proposal['result']=='PASS_EXACT_METADATA_ONLY_DEPENDENCY_PROPOSAL' and proposal['metadataOnly'] and proposal['externalPayloadReads']==proposal['archivePayloadReads']==0,'corrected dependency proposal differs')
 unknown_path=C/'SCAN-FRESH-01-INTERRUPTION-PRESERVATION-v1.json';unknown=load(unknown_path)
 ck(unknown['result']=='UNKNOWN_INTERRUPTED_NO_TERMINAL_RECEIPT' and unknown['unknownOutcomeNotCountedAsPass'] and unknown['missingOutputs']==['scan-fresh-01.resources.json','scan-fresh-01.json'] and all(not (C/n).exists() for n in unknown['missingOutputs']),'interrupted original was replaced or reclassified')
 ck(unknown['originalInvocation']['path']==str(C/'scan-fresh-01.resources.invocation.json'),'unknown invocation path differs');check(unknown['originalInvocation']['path'],unknown['originalInvocation'])
 for r in unknown['preservedFiles']:check(r['path'],r)
 failures=[
  {**failed_capture,'reason':'Original proof capture stopped on an unclassified prose key. Independent classification subsequently covered exactly two copied prose-key renames; original failed partial capture remains retained.','correctedSuccessfulTerminal':corrected_capture['terminal'],'correctedSuccessfulInvocation':corrected_capture['invocation'],'diagnostic':pin(C/'run-logs/capture-proof-v1.err'),'stdout':pin(C/'run-logs/capture-proof-v1.log'),'verbatimFailureOutputRetained':True,'metadataPreparationOnly':False,'historicalAction':'Proof payload capture with 86 preserved partial output files','partialCapturePreservation':pin(C/'PROOF-RETRY-PRESERVATION-v1.json'),'copyRenameApproval':pin(C/'PROSE-KEY-RENAME-APPROVALS.json'),'copySanitation':pin(C/'COPY-SANITATION-MAPPING.json'),'correctedCaptureMetadata':pin(C/'proof-capture-v1.json'),'noSuccessfulProductValidationClaim':True},
  {**failed_dependency,'reason':'Metadata-only v1 lookup omitted archive-set attribution for two exact historical after448 leaves. Corrected v2 binds the recorded complete three-part set without guessing individual parts.','correctedSuccessfulTerminal':corrected_dependency['terminal'],'correctedSuccessfulInvocation':corrected_dependency['invocation'],'diagnostic':pin(C/'run-logs/build-dependencies-v1.err'),'stdout':pin(C/'run-logs/build-dependencies-v1.log'),'verbatimFailureOutputRetained':True,'metadataPreparationOnly':True,'classificationCorrectionReview':pin(C/'INDEPENDENT-CUPRA-DEPENDENCY-v2-STATIC-REVIEW.json'),'correctedDependencyProposal':pin(proposal_path),'noSuccessfulProductValidationClaim':True}]
 out={'status':'REVIEWED_EXACT_PREPARATORY_FAILURES','recordedAt':now(),'approvalScope':'Exactly two independently reviewed historical exit-1 attempts remain failures; corrected successes are separately bound. The interrupted original privacy scan is UNKNOWN and receives no exit waiver.','metadataFinalizationContract':pin(cp),'failures':failures,'expectedFailedPreparations':2,'allOtherNonzeroOutcomesRemainBlocking':True,'knownRawPreflightReviewRequiredIsSeparatelyExactClassified':True,'bindingOperationMetadataOnly':True,'noPayloadArchiveSeedOrLiveSourceReadsByBinding':True,'failedPartialCapturePayloadsNotRereadByBinding':True,'interruptedScan':{'status':'UNKNOWN_INTERRUPTED_NO_TERMINAL_RECEIPT','preservation':pin(unknown_path),'excludedFromApprovedTerminalFailures':True,'originalOutcomeNotCountedAsPass':True,'retryEvidenceMustBeSeparatelyAccounted':True},'productValidationClaimsUnchanged':load(C/'FROZEN-CAPTURE-SCOPE.json')['currentValidation']}
 target=C/'APPROVED-PREPARATORY-FAILURES.json';dump(target,out)
 print(json.dumps({'result':out['status'],'failedPreparations':len(failures),'interruptedOriginal':'UNKNOWN','pin':pin(target)}))

if __name__=='__main__':main()
