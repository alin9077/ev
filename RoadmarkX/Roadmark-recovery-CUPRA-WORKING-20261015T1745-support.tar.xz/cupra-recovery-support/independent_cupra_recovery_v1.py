#!/usr/bin/env python3
"""Independent fresh-only CUPRA recovery replay, without inherited payload reads."""
import copy,datetime,hashlib,json,lzma,pathlib,resource,stat,sys,tarfile,time,traceback
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent;R=C.parents[1];W=R.parent;BASE=C.parent/'kgm-working-20261015T1530';AUDI=C.parent/'audi-working-20261015T0800';DEEPAL=C.parent/'deepal-working-20261015T1110';LIMIT=268435456;CHUNK=65536;LABEL='CUPRA-WORKING-20261015T1745'
OUT=C/'INDEPENDENT-CUPRA-RECOVERY-VERIFICATION-v1.json';REPLAY=C/'INDEPENDENT-NEW-MEMBER-REPLAY-MANIFEST-v1.json';START=time.monotonic();RESULT={'result':'IN_PROGRESS'}
def ck(v,m):
 if not v:raise AssertionError(m)
def load(p):return json.loads(P(p).read_bytes())
def sh(r):return {k:r[k] for k in ('bytes','sha256')}
def core(r):return {k:r[k] for k in ('path','bytes','sha256')}
def original(r):return {'bytes':r['originalBytes'],'sha256':r['originalSHA256']}
def enc(x):return (json.dumps(x,indent=2)+'\n').encode()
def pb(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(p,x):
 with P(p).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def identity(p):
 p=P(p);s=p.lstat();ck(stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents),'unsafe path '+str(p));return [s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev]
def pin(p):
 p=P(p);before=identity(p);h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(CHUNK):h.update(b);n+=len(b)
 ck(identity(p)==before and n==before[0],'file mutated '+str(p));return {'bytes':n,'sha256':h.hexdigest()}
def check(p,r):
 a=pin(p);ck(a==sh(r),'pin differs '+str(p));return a
def safe(n):
 p=P(n);ck(n and not p.is_absolute() and '..' not in p.parts and str(p)==n and '\\' not in n,'unsafe member '+n)
def rows(rows):
 out={}
 for r in rows:safe(r['path']);ck(r['path'] not in out,'duplicate member');out[r['path']]=core(r)
 return out
def rest(p):
 p=P(p)
 if p.is_relative_to('/tmp'):n=p.relative_to('/tmp').as_posix()
 elif p.is_relative_to(W/'roadmark-104'):n='roadmark/'+p.relative_to(W/'roadmark-104').as_posix()
 else:ck(p.is_relative_to(W/'roadmark-104-qa'),'unexpected selected root');n=p.relative_to(W).as_posix()
 safe(n);return n
def pointer(x,p):
 if not p:return x
 for k in p.split('/')[1:]:k=k.replace('~1','/').replace('~0','~');x=x[int(k)] if isinstance(x,list) else x[k]
 return x
def terminal(path,command,code=0):
 p=P(path);i=p.with_name(p.stem+'.invocation.json');t,iv=load(p),load(i)
 ck(t['command']==iv['command']==command and t['exitCode']==code and not t['timedOut'],'terminal outcome '+p.name)
 ck(t['addressSpaceLimitBytes']==iv['addressSpaceLimitBytes']==LIMIT and t['wallLimitSeconds']==iv['wallLimitSeconds']==600 and t['childPid']==iv['childPid'] and t['maxRssKiB']>0,'terminal bounds '+p.name)
 return {'receipt':{'path':str(p),**pin(p)},'invocation':{'path':str(i),**pin(i)},'command':command,'exitCode':code,'addressSpaceLimitBytes':LIMIT,'maxRssKiB':t['maxRssKiB'],'wallSeconds':t['wallSeconds']}
def seed_ledgers(scans,metadata):
 terminals=[(P(e['terminal']['path']),load(e['terminal']['path'])) for e in scans];declared={str(p) for p,t in terminals}
 for p in C.glob('*.resources.json'):
  t=load(p)
  if any((P(a).name.startswith('privacy_v') or P(a).name=='scan_archive_v1.py') and P(a).suffix=='.py' for a in t.get('command',[])):ck(str(p) in declared,'unaccounted production scan attempt')
 ck(all(t['exitCode'] in (0,2) for p,t in terminals),'partial scan needs separate accounting')
 ap=AUDI/'INDEPENDENT-AUDI-RUNTIME-BATCH-CLASSIFICATION-v1.json';check(ap,{'bytes':720844,'sha256':'4bb97b40446fad1a43e08b498ebdab7e1c82af35470de5b83419932047f3eb5a'});ar=load(ap);by={r['member']:r for r in ar['files']};audi=[]
 for g in ar['newValueSources']:
  s=g['sources'][0];r=by[s['member']];audi.append({'valueGroup':g['id'],'path':r['originalPath'],'pin':r['originalPin'],'byteStart':s['byteStart'],'byteEndExclusive':s['byteEndExclusive'],'payloadReadOperations':1})
 dp=DEEPAL/'INDEPENDENT-DEEPAL-RUNTIME-CLASSIFICATION-v3.json';check(dp,{'bytes':52667,'sha256':'b448315960f3e54d72ff0133ca296094bc7ab9503bbc8233ea455a8cd6f2484d'});dr=load(dp);deepal=[{'path':r['capturedPayloadPath'],'pin':r['originalPin'],'payloadReadOperations':1,'valueRanges':len(r['ranges'])} for r in dr['files']]
 result={}
 for key,folder in [('historical','seed-read-invocations'),('audi','audi-seed-read-invocations'),('deepal','deepal-seed-read-invocations')]:
  out=[]
  for p in sorted((C/folder).glob('*.json')):
   r=load(p)
   if key=='historical':ck(r['exactPinnedMembersReadAndVerified']==200 and r['historicalArchives']==21 and r['noExtractedValuesPersisted'] and r['memberIdentityListPin']==sh(metadata['seedProvenance']),'historical scope differs')
   elif key=='audi':ck(r['distinctValues']==6 and r['variantForms']==37 and r['payloadReadOperations']==6 and r['uniqueOriginalFiles']==4 and r['reads']==audi and r['classificationReceiptPin']==pin(ap) and r['noValuesOrValueDigestsPersisted'] and not r['generalURLDecodedRuntimeCoverageClaimed'],'Audi scope differs')
   else:ck(r['distinctValues']==6 and r['variantForms']==41 and r['payloadReadOperations']==5 and r['reads']==deepal and r['classificationReceiptPin']==pin(dp) and r['noValuesOrValueDigestsPersisted'] and not r['rawDeepalApiManagerOriginalRead'] and r['URLComponentRepresentationIncludedByUnchangedVariantsFunction'],'Deepal scope differs')
   when=datetime.datetime.fromisoformat(r['completedAt']);matched=[(p,t) for p,t in terminals if t['childPid']==r['processId'] and datetime.datetime.fromisoformat(t['startedAt'])<=when<=datetime.datetime.fromisoformat(t['endedAt'])];ck(len(matched)==1,'ledger not uniquely bound');out.append({'receipt':{'path':str(p),**pin(p)},'terminal':str(matched[0][0]),'processId':r['processId'],'completedAt':r['completedAt']})
  ck(len(out)==len(terminals) and {r['terminal'] for r in out}==declared,'seed completion coverage differs');result[key]=out
 local=load(metadata['inheritedLocalSeedScope']['path']);ck(local['result']=='EXACT_UNCHANGED_SELECTOR_ACCOUNTING_SPECIFICATION' and len(local['files'])==48 and local['payloadValueReadsPerSuccessfulInvocation']==local['streamingIntegrityReadsPerSuccessfulInvocation']==48,'local seed scope differs')
 for r in local['files']:ck(r['payloadValueReadsPerSuccessfulInvocation']==r['streamingIntegrityReadsPerSuccessfulInvocation']==1,'local accounting differs')
 for r in local['metadataPins']:check(r['path'],r)
 return result
def main():
 ck(sys.argv[1:]==['replay','--sole-child-slot-authorized'],'only supported mode: replay --sole-child-slot-authorized');ck(resource.getrlimit(resource.RLIMIT_AS)==(LIMIT,LIMIT),'256MiB ceiling absent');ck(not OUT.exists() and not REPLAY.exists(),'preserve prior outcome')
 ip=C/'INDEPENDENT-CUPRA-REPLAY-INPUTS-v1.json';inputs=load(ip);ipin=pin(ip);ck(inputs['result']=='APPROVED_PINNED_FRESH_REPLAY_INPUTS','unapproved replay inputs');metadata=inputs['metadata'];docs={}
 for k,r in metadata.items():check(r['path'],r);docs[k]=load(r['path'])
 for r in inputs['scriptPins']:check(r['path'],r)
 ck(any(P(r['path'])==P(__file__) for r in inputs['scriptPins']),'verifier not pinned');phases={r['phase']:terminal(r['terminal']['path'],r['command'],r.get('expectedExitCode',0)) for r in inputs['phaseCommands']};ck(len(phases)==len(inputs['phaseCommands']),'duplicate phase')
 failure_review=docs['preparatoryFailureReview'];ck(failure_review['status']=='REVIEWED_EXACT_PREPARATORY_FAILURES','failed phase approval absent');approved_failures={r['terminal']['path']:r for r in failure_review['failures']};failed_phases={r['terminal']['path']:r for r in inputs['phaseCommands'] if r.get('expectedExitCode',0)==1};ck(len(approved_failures)==len(failure_review['failures']) and set(approved_failures)==set(failed_phases),'failed phase exact multiset differs')
 for name,r in approved_failures.items():ck(r['exitCode']==failed_phases[name]['expectedExitCode']==1 and r['terminal']==failed_phases[name]['terminal'],'failed phase approval pin differs');check(name,r['terminal'])
 RESULT['preservedPreparatoryFailures']={'review':metadata['preparatoryFailureReview'],'terminalPins':[approved_failures[k]['terminal'] for k in sorted(approved_failures)],'failedPreparations':len(approved_failures),'notProductValidationSuccesses':True}
 basepath=BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-KGM-WORKING-20261015.json';check(basepath,{'bytes':3246441,'sha256':'09bcfeb302b31331d0d7ed12b18553f0cf71cf0fca4017b97cd53cbafe3edba4'});base=load(basepath);old=rows(base['files']);ck(len(old)==13380 and len(base['archivesInRestoreOrder'])==135,'base counts differ');check(BASE/'FINAL-KGM-UPLOAD-RECEIPTS.json',inputs['baseTerminalReceipt'])
 scope,idsdoc=docs['scope'],docs['initialIdentities'];ck(idsdoc['result']=='PASS_EXACT_453_SELECTED_FILE_INITIAL_IDENTITY_BINDING' and idsdoc['identityFields']==['size','mtimeNs','ctimeNs','inode','device'] and idsdoc['atimeExcluded'] and idsdoc['payloadFilesOpened']==0,'initial identities differ');check(metadata['scope']['path'],idsdoc['frozenScope']);ids={r['path']:r['identity'] for r in idsdoc['files']};frozen={rest(r['path']):r for r in scope['files']};ck(len(ids)==len(frozen)==len(scope['files'])==453,'selected scope count differs')
 ck(scope['authorInventory']['sha256']=='798f05ab19b2632f0ee091305430c16105e59ae7df3fa316766feb2d54f3ee55' and scope['finalRetentionReview']['sha256']=='2b024c76cfa72634b74be4ea0d49f966e42a6f185ae2161b506d2a64b32d6f7f','accepted freeze differs')
 ck(scope['rawKgmOriginalReadRecoveryRefetchForbidden'] and scope['rawDeepalOriginalReadRecoveryRefetchForbidden'] and scope['canonicalSanitizedSourceFiles']==97,'raw exclusion differs')
 sc,pc=docs['sourceCapture'],docs['proofCapture'];prior={r['path']:r for r in load(BASE/'source-capture.json')['files']};current={r['path']:r for r in sc['files']};captured={r['path']:r for r in pc['files']};delta={r['path']:r for r in pc['changedFiles']};changed={n for n,r in current.items() if n not in prior or original(r)!=original(prior[n])}
 ck(len(prior)==694 and len(current)==scope['expectedSourceFiles']==697 and set(prior)<=set(current) and len(set(current)-set(prior))==3,'full source membership differs');ck(changed==set(scope['sourceChangedPaths']) and len(changed)==6,'source delta differs')
 state=(C/'WORKING-STATE.txt').read_text();ck(sc['state']==pc['state']==state==scope['workingResult']+'\n' and sc['chunkBytes']==pc['chunkBytes']==CHUNK and not sc['fullSourceTreeCloned'] and pc['noBroadQaTraversal'] and not sc['sourceChangesDuringCapture'] and not pc['sourceChangesDuringCapture'],'capture stability/scope differs')
 for n,r in current.items():
  safe(n);ck(r['originalPath']==str(W/'roadmark-104'/n),'source locator differs')
  if n in changed:ck(original(r)==sh(r)==sh(frozen['roadmark/'+n]) and r['sourceIdentity']==ids[r['originalPath']],'changed source bytes differ')
  else:
   o=prior[n];ck(all(r.get(k,[])==o.get(k,[]) for k in ('bytes','sha256','originalBytes','originalSHA256','redactedHeaderPaths','redactedPointers','redactedHTMLRanges')) and r['payloadPath']==o['payloadPath'] and r['captureMethod']=='exact-original-and-prior-sanitized-hashes','source reuse differs')
 ck(len(captured)==453 and pc['scope']==scope,'proof capture scope differs');ck(docs['copySanitation']['result']=='NO_NEW_TRANSFORMATIONS' and docs['copySanitation']['files']==docs['keyApprovals']['files']==[] and docs['copySanitation']['locationCount']==0,'new payload transformation requires separate adaptation')
 covered=[];reused=[]
 for n,f in frozen.items():
  r=captured[n];ck(r['originalPath']==f['path'] and r['sourceIdentity']==ids[f['path']] and original(r)['bytes']==f['bytes'],'proof original identity differs')
  known=f.get('sha256') or f.get('knownSha256')
  if known:ck(original(r)['sha256']==known,'known frozen pin differs')
  if n.startswith('roadmark/'):
   s=current[n[9:]];ck(core(r)=={'path':n,**sh(s)} and original(r)==original(s) and r['captureMethod']=='covered-by-full-source' and n not in delta,'source-covered proof differs');covered.append(n)
  elif n in delta:ck(r==delta[n] and r['archiveAction']=='new-delta-member' and sh(r)==original(r) and not any(r.get(k) for k in ('metadataKeyRename','redactedPointers','redactedHTMLRanges')),'new proof transformed')
  else:ck(core(r)==old[n] and r['archiveAction']=='reuse-exact-base-member','base proof differs');reused.append(n)
 ck(len(covered)==6 and reused==[] and scope['reusedProofMembers']==[] and len(delta)==447,'CUPRA proof dispositions differ');ck({n for n in frozen if not n.startswith('roadmark/')} & set(old)=={'roadmark-104-qa/work-status.json'},'exact base non-source intersection differs')
 ck(docs['symlinks']['result']=='EXACT_METADATA_AND_MEMBER_MAPPING' and docs['symlinks']['links']==scope['metadataOnlySymlinks']==[] and docs['symlinks']['noTraversalOrDependencyCapture'],'symlink scope differs')
 source,proof,support=docs['sourcePackage'],docs['proofPackages']['archives'],docs['supportPackage'];sinv,sreuse=docs['supportInventory'],docs['supportReuse'];archives=docs['archivePlan']['archives'];plan=docs['restorePlan'];ck(docs['initialArchivePlan']['archives']==[source]+proof and [{k:v for k,v in r.items() if k!='restoreOrder'} for r in archives]==[source]+proof+[support] and archives==plan['newArchives'],'archive order differs')
 generated={'roadmark/SOURCE-FILE-MANIFEST.json':enc({'schemaVersion':1,'root':'roadmark','files':[core(r) for r in sc['files']]})};source_members={'roadmark/'+n:{'path':'roadmark/'+n,**sh(r)} for n,r in current.items()};source_members['roadmark/SOURCE-FILE-MANIFEST.json']={'path':'roadmark/SOURCE-FILE-MANIFEST.json',**pb(generated['roadmark/SOURCE-FILE-MANIFEST.json'])};ck(rows(source['memberFiles'])==source_members and [r['path'] for r in source['memberFiles']]==list(source_members) and source['bytes']<15000000,'source member metadata differs')
 groups=[];g=[];size=0
 for r in pc['changedFiles']:
  if g and size+r['bytes']>24000000:groups.append(g);g=[];size=0
  g.append(r);size+=r['bytes']
 if g:groups.append(g)
 ck(len(groups)==len(proof),'proof groups differ')
 for i,(g,a) in enumerate(zip(groups,proof),1):
  n=f'recovery-metadata/{LABEL}-part{i:02d}.json';v={'schemaVersion':1,'label':LABEL,'part':i,'parts':len(groups),'state':pc['state'],'files':[{k:r[k] for k in ('path','bytes','sha256','originalBytes','originalSHA256')} for r in g],'restore':'Overlay after the exact 135-archive KGM chain, replacing its source archive with this full registered CUPRA working source. Original raw-capture expected hashes remain unchanged; exact copy-only changes are recorded in the retained sanitation mapping.'};generated[n]=enc(v);want=rows(g);want[n]={'path':n,**pb(generated[n])}
  if i==1:n='cupra-safety-support/COPY-SANITATION-MAPPING.json';generated[n]=P(metadata['copySanitation']['path']).read_bytes();want[n]={'path':n,**pb(generated[n])}
  ck(rows(a['memberFiles'])==want and [r['path'] for r in a['memberFiles']]==list(want) and a['filename']==f'Roadmark-recovery-{LABEL}-part{i:02d}of{len(groups):02d}.tar.xz','proof generated metadata differs')
 check(metadata['scope']['path'],sinv['scopePin']);check(metadata['supportReuse']['path'],sinv['reuseMapping']);check(basepath,sreuse['baseManifestPin']);ck(sinv['status']=='SEALED_UNIQUE_SUPPORT' and sreuse['result']=='EXACT_BYTE_REUSE' and sinv['noRecursiveExecutableEmbedding'],'support not sealed')
 aliases=sreuse['files'];new_support=rows(sinv['files']);retained_paths={r['payloadPath'] for r in sinv['files']};alias_paths={r['originalPath'] for r in aliases};ck(len(retained_paths)==len(sinv['files']) and len(alias_paths)==len(aliases) and not retained_paths&alias_paths,'support input duplication');ck(sinv['selectedLocalSupportFiles']==len(sinv['files'])-1+len(aliases) and sinv['uniqueNewFiles']==len(sinv['files']) and sinv['exactReusedOrAliasedFiles']==len(aliases),'support counts differ')
 for r in sinv['files']:
  local=P(r['payloadPath']).relative_to(C).as_posix();safe(local);ck(r['path']=='cupra-recovery-support/'+local,'support locator differs');check(r['payloadPath'],r)
 for r in aliases:
  p=P(r['originalPath']);ck(p.is_relative_to(C) and p.relative_to(C).as_posix()==r['localRelativePath'],'alias locator differs');check(p,r);target=r['retainedMember'];expected=old if r['kind']=='exact-inherited-member' else new_support;ck(r['kind'] in ('exact-inherited-member','exact-new-unique-member-alias') and target in expected and sh(expected[target])==sh(r),'alias identity differs')
 scripts=[r for r in sinv['files'] if P(r['payloadPath']).suffix=='.py'];scriptbytes={(r['bytes'],r['sha256']) for r in scripts};prior_scriptbytes={(r['bytes'],r['sha256']) for r in base['files'] if r['path'].endswith('.py')};ck(len(scriptbytes)==len(scripts) and not scriptbytes&prior_scriptbytes,'duplicate executable bytes')
 for r in inputs['scriptPins']:ck(r['path'] in retained_paths|alias_paths,'script omitted from support')
 ck(str(P(__file__)) in retained_paths,'verifier omitted');want=rows(sinv['files']);n=f'recovery-metadata/{LABEL}-support.json';generated[n]=enc(sinv);want[n]={'path':n,**pb(generated[n])};ck(rows(support['memberFiles'])==want and [r['path'] for r in support['memberFiles']]==list(want),'support metadata differs')
 app=docs['application'];ck(app['result']=='APPROVED_EXACT_CAPTURED_APPLICATION_ASSERTIONS' and app['assertions'] and app['retainedPins'],'application counts differ');ck(app['summary']['scopedTests']==151 and app['summary']['currentCompilerAttempted'] is False and app['summary']['normalReportRuns']==1 and app['summary']['failedTypeScriptAttempts']==2 and app['summary']['fullProjectTypeScriptPassed'] is False and app['summary']['releaseReady'] is False,'application scope differs');assertions={}
 for a in app['assertions']:assertions.setdefault(a['restorePath'],[]).append(a)
 scans=inputs['scanReports'];byarchive={}
 for e in scans:
  for k in ('report','terminal','archivePlan'):check(e[k]['path'],e[k])
  if e['finalCoverage']:ck(e['archive'] not in byarchive,'duplicate final scan');byarchive[e['archive']]=e
 ck(set(byarchive)=={a['filename'] for a in archives},'final scan coverage differs')
 baseline=load(BASE/'scan-fresh-01.json');counter_names=('historicalValues','historicalForms','mercedesValues','mercedesForms','originalSeedMembers','leapmotorCookieAndHeaderValues','leapmotorCookieForms','mazdaCookieAndHeaderValues','mazdaCookieForms','mazdaPublicBareValues','mazdaPublicBareForms','mazdaCompleteHeaderValues','mazdaCompleteHeaderForms','mazdaCookiePairValues','mazdaCookiePairForms','mazdaFormTokenValues','mazdaFormTokenForms','audiRuntimeValues','audiRuntimeForms','audiOriginalPayloadReadOperations','deepalRuntimeValues','deepalRuntimeForms','deepalOriginalPayloadReadOperations');counts={k:baseline[k] for k in counter_names};cache_source={r['path']:r for r in load(C.parent/'xpeng-registered-working-20261014T2030/source-capture.json')['files']}
 gate_contract=docs['privacyGateContract'];ck(gate_contract['status']=='REVIEWED_EXACT_PRIVACY_GATE_CONTRACT','gate contract not approved')
 for k in ('sourceProofEngine','supportEngine'):check(gate_contract[k]['path'],gate_contract[k])
 adapter_review=docs['privacyAdapterReview'];ck(adapter_review['result']=='PASS_EXACT_BYTE_UNCHANGED_PRIVACY_ADAPTATION' and adapter_review['allPatternRulesSelectorsAndSearchesByteUnchanged'] and adapter_review['noSeedOrPayloadReads'],'privacy adapter review differs')
 for r in adapter_review['checks']:
  check(r['script']['path'],r['script']);check(r['previousScript']['path'],r['previousScript']);ck(P(r['previousScript']['path']).read_bytes()==P(r['script']['path']).read_bytes(),'scanner changed')
 ck(gate_contract['sourceProofEngine']==adapter_review['contractEntrypoint'],'scanner gate differs');check(adapter_review['contractGuard']['path'],adapter_review['contractGuard'])
 classification=docs.get('supportSyntaxClassification',{});code_classes=classification.get('exactSupportCodeClassifications',[])
 if code_classes:
  approval=docs['supportSyntaxApproval'];review=docs['supportSyntaxReview'];ck(approval['result']=='APPROVED_EXACT_SYNTAX_CLASSIFICATION' and approval['classificationPin']==sh(metadata['supportSyntaxClassification']) and approval['exactCandidates']==len(code_classes),'syntax approval differs');ck(review['result']=='PASS_EXACT_SUPPORT_ONLY_ADAPTER_AND_FAIL_CLOSED_TESTS' and review['exactCandidates']==len(code_classes) and review['testCount']==len(review['tests']) and all(r['passed'] for r in review['tests']),'support adapter tests differ')
  for k in ('baseEngine','supportEngine','supportSyntaxHandler','classification','supportSyntaxApproval'):check(review[k]['path'],review[k])
  ck(review['baseEngine']==gate_contract['sourceProofEngine'] and review['supportEngine']==gate_contract['supportEngine'] and review['classification']==metadata['supportSyntaxClassification'] and review['supportSyntaxApproval']==metadata['supportSyntaxApproval'],'support adapter bindings differ')
 else:ck(gate_contract['sourceProofEngine']==gate_contract['supportEngine'],'unreviewed support engine')
 preflights=inputs['supportPatternPreflights'];ck(preflights,'support syntax preflight missing');latest=max(preflights,key=lambda r:r['version']);raw=load(latest['report']['path']);tested={(r['bytes'],r['sha256']) for r in raw['files']};ck(all((r['bytes'],r['sha256']) in tested|prior_scriptbytes for r in inputs['scriptPins']),'unscanned new script')
 classified_members={r['member'] for r in code_classes};fresh={};verified=[];scan_rows=[];checked=0
 for index,a in enumerate(archives,1):
  p=P(a['file']);ck(p.parent==R and p.name==a['filename'],'archive locator differs');check(p,a);wanted=rows(a['memberFiles']);actual={}
  with lzma.open(p,'rb') as stream:
   with tarfile.open(fileobj=stream,mode='r|') as tar:
    for member in tar:
     safe(member.name);ck(member.isfile() and member.name in wanted and member.name not in actual and member.name not in fresh,'unsafe/unexpected/duplicate archive member');h=hashlib.sha256();n=0;parts=[] if member.name in generated or member.name in assertions or member.name in classified_members else None
     with tar.extractfile(member) as payload:
      while b:=payload.read(CHUNK):h.update(b);n+=len(b);parts.append(b) if parts is not None else None
     r={'path':member.name,'bytes':n,'sha256':h.hexdigest()};ck(r==wanted[member.name] and n==member.size,'archive member bytes differ '+member.name);actual[member.name]=r;fresh[member.name]=r
     if parts is not None:
      data=b''.join(parts)
      if member.name in generated:ck(data==generated[member.name],'generated metadata byte difference')
      for cl in code_classes:
       if cl['member']==member.name:ck(sh(cl['filePin'])==pb(data) and hashlib.sha256(data[cl['byteStart']:cl['byteEndExclusive']]).hexdigest()==cl['matchedSyntaxSHA256'],'classified syntax exact bytes differ')
      if member.name in assertions:
       x=json.loads(data)
       for assertion in assertions[member.name]:ck(pointer(x,assertion['pointer'])==assertion['expected'],'application assertion differs '+member.name+assertion['pointer']);checked+=1
   while stream.read(CHUNK):pass
  ck(actual==wanted and list(actual)==list(wanted) and len(actual)==a['members'],'archive member/order coverage differs');check(p,a)
  e=byarchive[p.name];q=load(e['report']['path']);t=terminal(e['terminal']['path'],e['command'],0);expected_plan=metadata['archivePlan'] if p.name==support['filename'] else metadata['initialArchivePlan'];engine=gate_contract['supportEngine' if p.name==support['filename'] else 'sourceProofEngine'];ck(e['archivePlan']==expected_plan and e['command']==['python3',engine['path'],a['file'],e['report']['path'],expected_plan['path']],'scan invocation differs')
  ck(q['status']=='clean' and q['archive']==p.name and q['archivePin']==sh(a) and rows(q['members'])==actual and q['regularFilesScanned']==len(actual) and q['bytesScanned']==sum(r['bytes'] for r in actual.values()) and q['currentByteSearchForEveryMember'] and q['chunkBytes']==CHUNK,'scan coverage differs');ck(all(not q[k] for k in ('exactValueMatches','primaryHeaderCandidates','unclassifiedRuntimeCandidates','errors')),'unresolved privacy findings');ck(all(q[k]==v for k,v in counts.items()) and q['patternCacheProvenance']==baseline['patternCacheProvenance'],'unchanged seed/cache counts differ')
  expected_code=[{'member':r['member'],'filePin':r['filePin'],'finding':{k:v for k,v in r['exactFinding'].items() if k!='member'},'classification':r['classification']} for r in code_classes if r['member'] in actual];canon=lambda rs:sorted(json.dumps(r,sort_keys=True) for r in rs);ck(canon(q['classifiedExactCodeHeaderCandidates'])==canon(expected_code) and q['classifiedExactTemplateRuntimeCandidates']==[],'exact syntax multiset differs')
  for r in q['members']:
   n=r['path'];eligible=n.startswith('roadmark/') and n!='roadmark/SOURCE-FILE-MANIFEST.json' and n[9:] in cache_source and core(r)=={'path':n,**sh(cache_source[n[9:]])};ck((r['patternVerdict']=='exact-prior-source-cache')==eligible and (eligible or r['patternVerdict']=='current-full-unchanged-scanner'),'cache eligibility differs');ck(r['exactMatchesObserved']==r['classifiedPublicLexicalCollisions']+r['unresolvedExactMatches'] and r['unresolvedExactMatches']==0,'exact match count differs')
  ck(sum(r['classifiedPublicLexicalCollisions'] for r in q['members'])==q['classifiedPublicLexicalCollisions'],'collision accounting differs');scan_rows.append({'archive':p.name,'report':e['report'],'terminal':t,'archivePlan':expected_plan,'members':len(actual),'bytes':sum(r['bytes'] for r in actual.values()),'classifiedPublicLexicalCollisions':q['classifiedPublicLexicalCollisions'],'classifiedExactCodeHeaderCandidates':len(expected_code),'classifiedExactTemplateRuntimeCandidates':0});verified.append({'filename':p.name,**pin(p),'members':len(actual),'uncompressedBytes':sum(r['bytes'] for r in actual.values())});print(json.dumps({'stage':'fresh-only-independent-replay','archive':index,'members':len(actual),'result':'PASS'}),flush=True)
 ck(checked==len(app['assertions']) and fresh==rows(plan['newFiles']) and len(fresh)==plan['freshFiles'] and sum(r['bytes'] for r in fresh.values())==plan['freshBytes'],'fresh/app union differs');merged={n:r for n,r in old.items() if not n.startswith('roadmark/')};merged.update(fresh);ck(merged==rows(plan['files']) and len(merged)==plan['logicalFiles'] and sum(r['bytes'] for r in merged.values())==plan['logicalBytes'],'logical overlay differs');ck((set(old)&set(fresh))-{n for n in old if n.startswith('roadmark/')}==set(scope['expectedNonSourceOverlay'])=={'roadmark-104-qa/work-status.json'},'non-source overlay differs')
 expected_archives=[dict(source) if r['group'].startswith('source-') else {**r,'new':False} for r in base['archivesInRestoreOrder']]+copy.deepcopy(proof)+[copy.deepcopy(support)]
 for i,r in enumerate(expected_archives,1):r['restoreOrder']=i
 ck(sum(r['group'].startswith('source-') for r in base['archivesInRestoreOrder'])==1 and expected_archives==plan['archivesInRestoreOrder'] and plan['baseArchivesReused']==134 and plan['archiveCount']==len(expected_archives),'base archive/order differs');ck(docs['freshRestoreManifest']=={'archivesInRestoreOrder':archives,'files':list(fresh.values())},'fresh restore manifest differs')
 for r in pc['files']+app['retainedPins']:ck(merged[r['path']]==core(r),'mandatory retained member missing')
 for n in app['forbiddenExecutedTerminals']:ck(n not in merged,'held execution falsely present')
 for r in scope['authorRetention']['sourceAndStatusAfterPins']:ck(merged[rest(r['path'])]=={'path':rest(r['path']),**sh(r)},'accepted live pins differ')
 for r in aliases:ck(sh(merged[r['retainedMember']])==sh(r),'support alias missing')
 inherited=set()
 def inherited_mappings(x):
  if isinstance(x,dict):
   if 'sanitizedBytes' in x and 'sanitizedSHA256' in x and ('restorePath' in x or 'path' in x):
    n=x.get('restorePath') or x['path'];ck(merged[n]==old[n]=={'path':n,'bytes':x['sanitizedBytes'],'sha256':x['sanitizedSHA256']},'inherited sanitation changed');inherited.add(n)
   for v in x.values():inherited_mappings(v)
  elif isinstance(x,list):
   for v in x:inherited_mappings(v)
 for n in ('sourceSanitation','copyOnlySanitation','inheritedCopyOnlySanitation','originalRawCaptureReplayCompatibility'):inherited_mappings(base[n])
 for r in base['copyOnlySanitation'].get('files',[]):
  if r.get('metadataKeyRename'):ck(merged[r['path']]==old[r['path']]==core(r),'inherited prose-key member changed')
 proposal,depmap=docs['dependencyProposal'],docs['dependencyMap'];check(basepath,proposal['baseManifest']);check(metadata['scope']['path'],proposal['frozenScope']);ck(proposal['relocationProposals']==proposal['inheritedPointerIntersections']==[] and proposal['inheritedDependencyRecords']==181 and proposal['cupraExternalRequirements']==146 and proposal['exactRetainedStorageClosureFiles']==21,'dependency proposal differs');dependencies=copy.deepcopy(base['inheritedDependencyReconstruction']['dependencies'])+copy.deepcopy(proposal['newDependencyRecords']);ck(dependencies==depmap['dependencies'] and len(dependencies)==len({r['originalPath'] for r in dependencies})==proposal['proposedDependenciesCount'],'dependency records differ');canonical=hashlib.sha256(json.dumps(dependencies,sort_keys=True,separators=(',',':')).encode()).hexdigest();ck(canonical==proposal['proposedDependenciesCanonicalSha256']==depmap['dependenciesCanonicalSha256'],'dependency canonical hash differs')
 for r in dependencies:
  for p in r['pins']:ck(merged[p['member']['path']]==core(p['member']) and sh(p['member'])==sh(p['expected']),'dependency member differs')
 for r in proposal['resolvedCupraRequirements']:ck(merged[r['member']['path']]==core(r['member']) and sh(r['member'])==sh(r['expected']),'CUPRA external requirement differs')
 runtime=proposal['runtimeSystemDependenciesNotCaptured'];ck(len(runtime)==1 and runtime[0]['expected']=={'path':'/usr/bin/timeout','bytes':47984,'sha256':'6ca1891dfc0b05d7680770c2884c0391b92467c7bb6500a5c84677e6481739f1'} and runtime[0]['payloadReads']==0 and runtime[0]['nominatedBy'] and runtime[0]['reconstructionCheckRequirement'],'external system-runtime boundary differs')
 RESULT['externalRuntimePrerequisites']={'proposal':metadata['dependencyProposal'],'requirements':runtime,'archiveSupplyClaim':False,'installedRuntimeRevalidatedByIndependentReplay':False,'requiredBeforeProductProofRerun':True}
 images=docs['imageProvenance'];author=scope['authorRetention'];ck(images['result']=='AUTHOR_AND_REVIEWER_CLASSIFIED_PUBLIC_PDF_PAGE_RENDERS' and images['files']==author['publicImageProvenance']['existingPublicPdfPageRenders'] and len(images['files'])==2 and not images['newImageBodiesReadOrRendered'] and not images['browserScreenshotsIncluded'],'CUPRA image provenance differs')
 for r in images['files']:
  for k in ('file','sourcePdf','parentProvenance','parentExtractedText'):ck(merged[rest(r[k]['path'])]=={'path':rest(r[k]['path']),**sh(r[k])},'image parent/member pin differs')
 ck((author['acceptedSourcePins'],author['heldOnlySourcePins'],author['allowlistedSourceUnion'])==(86,11,97),'source union differs')
 for r in author['files']:
  if r['category'] in ('accepted_source_v3','held_source_v2_only'):ck(merged[rest(r['path'])]=={'path':rest(r['path']),'bytes':r['bytes'],'sha256':r['declaredSha256']},'source union member differs')
 for r in author['excluded']:ck(rest(r['path']) not in fresh,'excluded path entered fresh cut')
 ck(app['summary']['originalLightV1ReviewedPins']==81 and app['summary']['originalLightV1PreparationBytesAvailable'] is False and app['summary']['missingV1Reconstructed'] is False,'missing v1 improperly reconstructed')
 for r in app['inheritedFailureAssertions']:ck(old[r['member']['path']]==merged[r['member']['path']]==core(r['member']) and not r['inheritedPayloadReread'],'inherited failure binding differs')
 gate=docs['privacyGate'];ck(gate['result']=='PASS' and gate['freshMembers']==len(fresh) and gate['freshBytes']==sum(r['bytes'] for r in fresh.values()) and len(gate['archives'])==len(archives) and gate['unclassifiedFindings']==gate['errors']==0,'privacy gate coverage differs');ck(gate['classifiedPublicLexicalCollisions']==sum(r['classifiedPublicLexicalCollisions'] for r in scan_rows),'aggregate collision differs')
 for r,e in zip(gate['archives'],scan_rows):ck(r['archive']==e['archive'] and sh(r['reportPin'])==sh(e['report']) and r['members']==e['members'] and r['bytes']==e['bytes'],'aggregate scan binding differs')
 ck(gate['classifiedExactCodeHeaderCandidates']==len(code_classes) and gate['classifiedExactTemplateRuntimeCandidates']==0 and gate['initialPlan']==gate['preservedInitialPlan']==sh(metadata['initialArchivePlan']) and gate['finalPlan']==sh(metadata['archivePlan']),'gate plan/classification differs');seeds=seed_ledgers(scans,metadata);ck({k:len(v) for k,v in seeds.items()}==inputs['expectedScanInvocations'],'seed invocation counts differ')
 for r in list(metadata.values())+inputs['scriptPins']:check(r['path'],r)
 check(ip,ipin);live=[];seen=set()
 for r in sc['files']+pc['files']:
  p=r['originalPath']
  if p in seen:continue
  seen.add(p)
  try:now=identity(p)
  except (OSError,AssertionError):now=None
  if now!=r['sourceIdentity']:live.append({'path':p,'capturedIdentity':r['sourceIdentity'],'currentIdentity':now,'classification':'Later live identity differs from verified immutable cut'})
 dump(REPLAY,{'result':'PASS','method':'Fresh source/proof/support only; non-materializing 64KiB streaming hash and member order through XZ EOF','archives':verified,'files':list(fresh.values()),'fileCount':len(fresh),'bytes':sum(r['bytes'] for r in fresh.values()),'noExtractedTree':True});n=len(scans)
 RESULT.update(result='PASS',verificationScope='All fresh members streamed; exact base metadata overlay checked; no inherited archive replay or restore clone',source={'files':len(current),'changedPaths':sorted(changed),'exactPriorReuse':len(current)-len(changed),'captureCutoff':sc['captureCutoff'],'strictCompressedUnder15000000':True},proof={'selectedOriginalFiles':453,'sourceCovered':6,'reusedBaseMembers':0,'newDeltaFiles':447,'newTransformations':0,'captureCutoff':pc['captureCutoff']},support={'inventory':metadata['supportInventory'],'archive':verified[-1],'uniquePinnedMembers':len(sinv['files']),'uniqueExecutableFiles':len(scripts),'noRecursiveExecutableText':True},newArchives=verified,phaseTerminals=phases,privacy={'result':'PASS','reports':scan_rows,'seedCounts':counts,'knownValuesPersistedOrPrinted':False,'blockingOrUnclassifiedFindings':0,'newExemptions':0,'exactPinnedCodeSyntaxClassifications':len(code_classes),'exactPinnedTemplateSyntaxClassifications':0,'limitations':['No decryption or arbitrary embedded-format decoding','No universal secret-free claim','Targeted URL-component representations only; no general URL-decoded runtime coverage']},replay={'manifest':{'path':str(REPLAY),**pin(REPLAY)},'noDiskExtractedTree':True},overlay={'baseArchiveCount':135,'unchangedBaseArchivesReused':134,'combinedArchiveCount':len(expected_archives),'combinedLogicalFiles':len(merged),'combinedLogicalBytes':sum(r['bytes'] for r in merged.values()),'freshFiles':len(fresh),'freshBytes':sum(r['bytes'] for r in fresh.values()),'inheritedPayloadReadsByIndependentVerifier':0},inheritedSanitation={'exactPreservedMembers':len(inherited),'allOriginalAndSanitizedPinsUnchanged':True},inheritedDependencyReconstruction={'mapping':metadata['dependencyMap'],'records':len(dependencies),'priorRecords':181,'relocatedPins':0,'unchangedInheritedRecords':181,'newRecords':len(proposal['newDependencyRecords']),'cupraExternalRequirements':146,'canonicalSha256':canonical},application={'contract':metadata['application'],'assertionCount':checked,'freshArchiveAssertions':checked,'exactInheritedAssertions':0,'mandatoryRetainedPins':len(app['retainedPins']),'summary':app['summary'],'workingState':state,'openGates':scope['openGates']},targetedHistoricalSeedExecutions={'completedInvocations':n,'targetedPinnedMemberReads':200*n,'uniquePinnedMembers':200,'uniqueHistoricalArchives':21,'receipts':seeds['historical'],'separateFromFreshMemberReplay':True},targetedAudiSeedExecutions={'completedInvocations':n,'originalPayloadReadOperations':6*n,'uniqueOriginalFiles':4,'distinctValues':6,'variantForms':37,'receipts':seeds['audi'],'noValuesOrValueDigestsPersisted':True},targetedDeepalSeedExecutions={'completedInvocations':n,'capturedPayloadReadOperations':5*n,'uniqueCapturedPayloadFiles':5,'rangeValueExtractionsPerInvocation':9,'distinctValues':6,'variantForms':41,'receipts':seeds['deepal'],'noValuesOrValueDigestsPersisted':True,'rawDeepalApiManagerOriginalRead':False},inheritedLocalSeedExecutions={'specification':metadata['inheritedLocalSeedScope'],'completedInvocations':n,'uniqueOriginalFiles':48,'payloadValueReads':48*n,'streamingIntegrityReads':48*n,'accountingMethod':'Derived from unchanged selector control flow and completed scanner ledgers; not separate per-file instrumentation','failedPartialInvocations':[],'noValuesOrValueDigestsPersisted':True},preservedInitialScanFailures=[{'report':e['report'],'terminal':e['terminal'],'expectedExitCode':e.get('expectedExitCode',0)} for e in scans if not e['finalCoverage']],rawKgmOriginalReadRecoveryRefetchForbidden=True,rawKgmOriginalRead=False,rawDeepalOriginalReadRecoveryRefetchForbidden=True,rawDeepalOriginalRead=False,postCaptureLiveChanges=live,inputPins=metadata,replayInputManifest={'path':str(ip),**ipin},verifierScript={'path':str(P(__file__)),**pin(__file__)},noUploadsOrDeletion=True)
if __name__=='__main__':
 code=0
 try:main()
 except BaseException as e:code=1;RESULT.update(result='BLOCKED',blocker={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()})
 RESULT['completedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();RESULT['resources']={'wallSeconds':round(time.monotonic()-START,3),'maxRssKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'addressSpaceLimitBytes':resource.getrlimit(resource.RLIMIT_AS)[0],'chunkBytes':CHUNK,'noRestoreClone':True};dump(OUT,RESULT);print(json.dumps({'result':RESULT['result'],'resources':RESULT['resources'],'blocker':RESULT.get('blocker')}),flush=True);sys.exit(code)
