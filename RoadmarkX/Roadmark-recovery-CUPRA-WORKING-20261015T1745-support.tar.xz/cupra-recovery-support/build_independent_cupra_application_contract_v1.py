#!/usr/bin/env python3
"""Pin accepted CUPRA receipt facts for fresh-archive replay; never execute product code."""
from independent_cupra_common_v1 import *
def main():
 command('build');inv,acc=verify_freeze();frozen={r['path']:r for r in inv['files']};extra={str(INV):pin(INV),str(ACC):pin(ACC),inv['preparer']['path']:inv['preparer']};retained={};external={};reads=[];docs={};assertions=[];mapping=load(C/'COPY-SANITATION-MAPPING.json');renames={r['originalPath']:r for r in mapping['files']};ck(mapping['result']=='EXACT_REVIEWED_PROSE_KEYS_ONLY' and len(renames)==2,'exact copy mapping absent')
 def add(r):
  p=r['path'];e=core(r)
  if p not in frozen and p not in extra:external[tuple(e.values())]=e;return
  if p in frozen:ck(frozen[p]['bytes']==r['bytes'],'frozen size mismatch '+p)
  n=rest(p);memberpin=sh(r)
  if p in renames:ck(sh(r)=={'bytes':renames[p]['originalBytes'],'sha256':renames[p]['originalSHA256']},'original receipt pin differs');memberpin=sh(renames[p])
  row={'path':n,**memberpin};ck(n not in retained or retained[n]==row,'retained pin conflict '+p);retained[n]=row
 def refs(x):
  if isinstance(x,dict):
   if all(k in x for k in ('path','bytes','sha256')) and isinstance(x['path'],str) and x['path'].startswith('/'):add(x)
   for v in x.values():refs(v)
  elif isinstance(x,list):
   for v in x:refs(v)
 def read(p):
  p=str(p)
  if p in docs:return docs[p]
  ck(p in frozen or p in extra,'outside selected metadata '+p);a=identity(p);ck(a[0]<500000,'metadata too large '+p)
  if p in frozen:ck(a[:2]==[frozen[p]['bytes'],frozen[p]['mtimeNs']],'metadata changed '+p)
  q=pin(p);add(q);x=load(p);ck(pin(p)==q and identity(p)==a,'unstable metadata');docs[p]=x;reads.append({**q,'identity':a});refs(x);return x
 def exact(p,field,value):
  ck(pointer(read(p),field)==value,'application assertion differs '+str(p)+field);assertions.append({'restorePath':rest(p),'pointer':'/approvalScope'+field[len('/authorization'):] if str(p) in renames and (field=='/authorization' or field.startswith('/authorization/')) else field,'expected':value})
 def fields(p,ns):
  x=read(p)
  for n in ns:exact(p,'/'+n,x[n])
 def terminal(p):
  x=read(p);exact(p,'/exitCode',0)
  for k in ('automaticRetry','watchdogFired','timeoutExitCodeObserved'):
   if k in x:exact(p,'/'+k,False)
  for k in ('rawWaitStatus','elapsedSeconds','maxRssKiB','stdoutSha256','stderrSha256'):
   if k in x:exact(p,'/'+k,x[k])
  for kind in ('stdout','stderr'):
   q=str(P(p).with_name(kind+'.log'))
   if kind+'Sha256' in x and q in frozen:add({'path':q,'bytes':frozen[q]['bytes'],'sha256':x[kind+'Sha256']})
 def run(r):
  refs(r);p=r['result']['path'];x=read(p)
  for k in ('passed','pinsPassed','scopePassed'):exact(p,'/'+k,True)
  exact(p,'/exitCode',0);terminal(r['terminal']['path'])
  if 'manifestSha256' in x:ck(x['manifestSha256']==r['manifest']['sha256'],'command manifest binding differs')
 read(INV);read(ACC)
 for r in inv['sourceAndStatusAfterPins']:add(r)
 fields(INV,['sourceAndStatusAfterPins','acceptedSourcePins','heldOnlySourcePins','allowlistedSourceUnion','rawRuntimeExclusion','mutableV1Limitation','retainedFailures','otherAttemptHistory','currentValidation','publicImageProvenance'])
 fields(ACC,['status','allSevenLiveTargetsHashAndByteVerified','metadataInventoryVerified','publicImages','retentionHistory','currentValidation','releaseAcceptance'])
 v=inv['currentValidation'];ck([v[k] for k in ('catalogue','tier1','onSale','packetCount','scopedTests')]==[430,353,312,29,151],'current counts differ')
 for k in ('fullProjectTypecheckPassed','releaseReady','researchCompleted','compilerRetriesAuthorized','currentCleanFullSuite','productionBuildVerified','phoneMobileVerified'):ck(v[k] is False,'open gate falsely passed '+k)
 # Every frozen reviewer receipt is retained as historical evidence; status is not promoted.
 for r in inv['files']:
  p=P(r['path'])
  if p.parent==P('/tmp/cupra-review') and p.suffix=='.json':
   x=read(p);fields(p,[k for k in x if k not in ('checkedAt','reviewedAt','reviewer')])
 T=P('/tmp/cupra-packet');V=P('/tmp/cupra-review')
 selected=read(V/'selected-preflight-v1-result-accepted.json');ck(selected['status']=='ACCEPTED_SELECTED_ACTUAL_CONSUMERS_ONLY' and selected['checks']['newCars']==3 and selected['checks']['generatedFeatureClaims']==207 and selected['checks']['earnedFactTermClaims']==54,'selected facts differ');ck(selected['CUPRAcriteria']=={'C1':False,'C2':False,'C3':True,'C4':True,'C5':False,'C6':True},'criteria differ')
 stage=read(V/'full-stage-v2-result-accepted.json');ck(stage['status']=='ACCEPTED_DERIVED_FULL_STAGE_ONLY' and stage['stagedCounts']=={'catalogue':430,'tierOne':353,'onSale':312,'packets':29},'full stage differs')
 post=read(V/'post-registration-checks-v1-results-accepted.json');ck(post['behaviouralTestsPassed']==144 and post['liveSafetyTestsPassed']==7 and post['structuralResult']['result']=='PASS','scoped tests differ')
 for r in post['checks']:run(r)
 report=read(V/'report-comparison-v1-results-accepted.json');ck(report['all1429ChangedLeavesIndependentlyReproduced'] and report['expectedDifferences']==0 and report['sourcePinsVerified']==488 and report['extraProofPinsPerCommandVerified']==205 and report['peerBrandObjectsExact']==55 and report['completePeerCarsExact']==427,'comparison facts differ')
 bundle=T/'report-comparison-v1/results-manifest-v1.json';x=read(bundle);fields(bundle,['status','all488SourcePinsExact','all205ExtraProofPinsExact','counts','allNormalLeavesAccounted','currentProjectTypeScript','releaseAcceptanceClaim','normalReportRuns','extraBroadFeatureReplay','automaticRetry']);ck(x['normalReportRuns']==1 and x['automaticRetry'] is False and x['releaseAcceptanceClaim'] is False,'report scope differs')
 for r in x['checks']:run(r)
 p=T/'report-comparison-v1/artifacts/result.json';fields(p,list(read(p)));exact(p,'/passed',True);exact(p,'/exhaustiveDifferences',1429)
 p=T/'report-comparison-v1/artifacts/expected-versus-normal-diff.json'
 if str(p) in frozen:exact(p,'',[])
 p=T/'report-comparison-v1/typescript-failure-context.json';fields(p,list(read(p)))
 for k in ('sourceAllowlist','currentAcceptedSourceManifest','heldSupersededSourceManifest'):add(inv[k])
 retention=read(inv['sourceAllowlist']['path']);ck(len(retention['currentAcceptedSourcePins'])==86 and len(retention['heldOnlySourcePins'])==11 and retention['allowlistedUnionCount']==97,'retention union differs');refs(retention)
 held=['cupra-packet/full-stage-v1/run/terminal.json']+[f'cupra-packet/typed-preparation-v{i}/run/terminal.json' for i in (1,2,3)]+['cupra-packet/docs-status-v1/application/result.json']
 ck(not set(held)&{rest(p) for p in frozen},'held preparation executed')
 check(BASE_MANIFEST,BASE_PIN);old=rows(load(BASE_MANIFEST)['files']);prior_app=load(B/'APPLICATION-ASSERTION-CONTRACT.json');failures=[]
 for ver in (1,2):
  n=f'kgm-packet/full-project-typescript-v{ver}/run/result.json';matches=[a for a in prior_app['assertions'] if a['restorePath']==n and a['pointer'] in ('/passed','/exitCode','/fullProjectTypecheckPassed')];ck({a['pointer']:a['expected'] for a in matches}=={'/passed':False,'/exitCode':-9,'/fullProjectTypecheckPassed':False},'inherited failure facts differ');failures.append({'member':old[n],'assertions':matches,'evidence':pin(B/'APPLICATION-ASSERTION-CONTRACT.json'),'inheritedPayloadReread':False})
 for r in reads:ck(identity(r['path'])==r['identity'] and sh(pin(r['path']))==sh(r),'receipt mutation')
 summary={'catalogue':430,'tierOne':353,'onSale':312,'registeredPackets':29,'selectedVersions':3,'factTermClaims':54,'featureClaims':207,'strictCoreFilled':49,'strictCoreGaps':2,'unchangedCompletePeers':427,'scopedTests':151,'relevantTests':144,'isolatedSafetyTests':7,'fullProjectTypeScriptPassed':False,'failedTypeScriptAttempts':2,'typeScriptFailureCause':'unknown','currentCompilerAttempted':False,'normalReportRuns':1,'normalReportFactualOnlyException':True,'normalReportExplainedLeaves':1429,'unexplainedReportDifferences':0,'acceptedSourcePins':86,'heldOnlySourcePins':11,'allowlistedSourceUnion':97,'originalLightV1ReviewedPins':81,'originalLightV1PreparationBytesAvailable':False,'missingV1Reconstructed':False,'CUPRACriteriaOpen':['C1','C2','C5'],'CUPRAVisualQAPassed':False,'productionBuildPassed':False,'currentFullSuitePassed':False,'releaseReady':False,'mobilePassClaimed':False,'currentSelected':'selected-preflight-v1','currentFullStage':'full-stage-v2','currentReportComparator':'report-comparison-v1','heldUnexecuted':['typed-preparation-v1','typed-preparation-v2','typed-preparation-v3','full-stage-v1','docs-status-v1']}
 out={'schemaVersion':1,'result':'APPROVED_EXACT_CAPTURED_APPLICATION_ASSERTIONS','preparedAt':now(),'generator':pin(__file__),'finalFreeze':pin(INV),'finalAcceptance':pin(ACC),'assertions':assertions,'retainedPins':sorted(retained.values(),key=lambda r:r['path']),'exactMetadataReads':reads,'externalReferencedPins':sorted(external.values(),key=lambda r:(r['path'],r['sha256'])),'forbiddenExecutedTerminals':held,'originalToCopiedReceiptMappings':[renames[n] for n in sorted(renames)],'copySanitationMapping':pin(C/'COPY-SANITATION-MAPPING.json'),'originalReceiptPinsNotClaimedEquivalentToCopies':True,'inheritedFailureAssertions':failures,'summary':summary,'scope':'Fresh archived receipt assertions plus exact inherited failure metadata; no application or inherited payload rerun','noProductExecution':True,'noSourceOrResearchBodyHashSweep':True,'noRawKgmOriginalReads':True,'noCodeEmbedding':True};dump(C/'APPLICATION-ASSERTION-CONTRACT.json',out);print(json.dumps({'result':out['result'],'assertions':len(assertions),'retainedPins':len(retained),'metadataReads':len(reads)}))
if __name__=='__main__':main()
