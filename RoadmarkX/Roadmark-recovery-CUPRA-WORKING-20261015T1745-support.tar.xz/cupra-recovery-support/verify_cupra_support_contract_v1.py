#!/usr/bin/env python3
"""Require exact approved support-only engine identity before seed reconstruction."""
import pathlib,sys
from capture_v1 import C,load,check,pin
from require_privacy_contract_v1 import verified_contract

def verify():
 verified_contract()
 cp=C/'CUPRA-SUPPORT-PRIVACY-CONTRACT-v1.json';q=load(cp)
 assert q['result']=='APPROVED_CUPRA_SUPPORT_PRIVACY_ADAPTER' and q['supportArchiveOnly'] and q['noDetectorOrKnownValueSearchChanges'] and q['exactApprovedCandidates']==12
 for key in ('baseEngine','supportEngine','supportSyntaxHandler','supportSyntaxApproval','classification','independentReview','entryGuard'):
  r=q[key];p=pathlib.Path(r['path']);assert p.parent==C;check(p,r)
 assert q['baseEngine']['path']==str(C/'privacy_v1.py') and q['supportEngine']['path']==str(C/'privacy_v2_support.py') and q['entryGuard']['path']==str(C/'verify_cupra_support_contract_v1.py')
 approval=load(q['supportSyntaxApproval']['path']);assert approval['result']=='APPROVED_EXACT_SYNTAX_CLASSIFICATION' and approval['exactCandidates']==12 and approval['classificationPin']==pin(C/'INDEPENDENT-CUPRA-SUPPORT-SYNTAX-CLASSIFICATION-v1.json')
 review=load(q['independentReview']['path']);assert review['result']=='PASS_EXACT_SUPPORT_ONLY_ADAPTER_AND_FAIL_CLOSED_TESTS' and review['exactCandidates']==12 and all(t['passed'] for t in review['tests'])
 for key in ('baseEngine','supportEngine','supportSyntaxHandler','supportSyntaxApproval','classification'):assert review[key]==q[key]
 assert len(sys.argv)==4 and pathlib.Path(sys.argv[1])==C.parents[1]/'Roadmark-recovery-CUPRA-WORKING-20261015T1745-support.tar.xz' and pathlib.Path(sys.argv[2]).parent==C and pathlib.Path(sys.argv[3])==C/'ARCHIVE-PLAN.json'
 return q
