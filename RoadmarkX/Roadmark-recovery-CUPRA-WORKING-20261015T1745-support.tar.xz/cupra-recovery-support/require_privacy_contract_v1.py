"""Bind independently reviewed exact inherited engine before any scan or seed read."""
from capture_v1 import C,BASE,P,load,check
INHERITED_PIN={'bytes':3148,'sha256':'fd7ec360b07b464716deab02e7aad57c78dcce00d5e94617bd335a84e8d02aba'}
def verified_contract():
 path=C/'CUPRA-PRIVACY-ADAPTER-CONTRACT.json';contract=load(path)
 assert contract['result']=='APPROVED_CUPRA_INHERITED_PRIVACY_ADAPTER'
 inherited=BASE/'KGM-PRIVACY-ADAPTER-CONTRACT.json';check(inherited,INHERITED_PIN)
 assert contract['inheritedContract']=={'path':str(inherited),**INHERITED_PIN}
 prior=load(inherited)
 for key in ['classification','approval','additiveInventory','classificationCounterPointers']:
  assert contract[key]==prior[key],key
 for key,name in [('engine','privacy_v1.py'),('addition','deepal_scan_additions_v2.py'),('audiAddition','audi_scan_additions_v3.py')]:
  item=contract[key];assert item['path']==str(C/name);check(C/name,item);check(BASE/name,prior[key])
  assert (C/name).read_bytes()==(BASE/name).read_bytes(),name+' scanner semantics changed'
 for key in ['engineAdaptationReview','captureScannerAdapterReview']:
  item=contract[key];p=P(item['path']);assert p.parent==C and p.name.startswith('INDEPENDENT-CUPRA-');check(p,item)
  assert str(load(p)['result']).startswith('PASS')
 for key in ['classification','approval','additiveInventory']:check(P(contract[key]['path']),contract[key])
 scope=load(C/'APPROVED-INHERITED-SEED-SCOPE.json')
 assert (scope['historicalPinnedMembers'],scope['historicalArchives'],scope['localSelectors'],scope['audiPayloadReadOperations'],scope['deepalCopiedCaptureSources'])==(200,21,48,6,5)
 assert scope['inMemoryOnly'] and scope['actualRepeatedReadAccounting'] and not scope['broadBaseScanOrClone'] and not scope['rawExcludedPayloadReadRecoveryRefetch']
 return contract
