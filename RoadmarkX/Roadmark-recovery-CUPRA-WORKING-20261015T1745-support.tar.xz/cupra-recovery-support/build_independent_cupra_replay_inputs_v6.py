#!/usr/bin/env python3
"""Bind CUPRA replay inputs after seal and completed fresh privacy scans, metadata only."""
import ast,datetime,hashlib,json,pathlib,re,resource,stat,sys
from verify_interrupted_scan_metadata_v2 import verify as verify_interrupted
P=pathlib.Path;C=P(__file__).resolve().parent;BASE=C.parent/'kgm-working-20261015T1530';LIMIT=268435456;CHUNK=65536;OUT=C/'INDEPENDENT-CUPRA-REPLAY-INPUTS-v1.json'
def ck(v,m):
 if not v:raise AssertionError(m)
def load(p):return json.loads(P(p).read_bytes())
def sh(r):return {k:r[k] for k in ('bytes','sha256')}
def pin(p):
 p=P(p);s=p.lstat();ck(stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents),'unsafe input');before=[s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev];h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(CHUNK):h.update(b);n+=len(b)
 s=p.lstat();ck(before==[s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev] and n==s.st_size,'input mutation');return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
def main():
 ck(sys.argv[1:]==['build','--sole-child-slot-authorized'],'only supported mode: build --sole-child-slot-authorized');ck(resource.getrlimit(resource.RLIMIT_AS)==(LIMIT,LIMIT),'256MiB ceiling absent');ck(not OUT.exists(),'preserve input binding')
 names={'scope':'FROZEN-CAPTURE-SCOPE.json','initialIdentities':'INDEPENDENT-CUPRA-INITIAL-IDENTITIES-v1.json','sourceCapture':'source-capture.json','proofCapture':'proof-capture-v1.json','sourcePackage':'source-package.json','proofPackages':'proof-packages-v1.json','supportInventory':'SUPPORT-MEMBER-INVENTORY.json','supportReuse':'SUPPORT-REUSE-MAPPING.json','supportPackage':'support-package.json','restorePlan':'RESTORE-PLAN.json','archivePlan':'ARCHIVE-PLAN.json','initialArchivePlan':'ARCHIVE-PLAN-initial.json','freshRestoreManifest':'FRESH-ONLY-RESTORE-MANIFEST.json','privacyGate':'ALL-ARCHIVE-PRIVACY-GATE.json','application':'APPLICATION-ASSERTION-CONTRACT.json','dependencyMap':'INHERITED-DEPENDENCY-RECONSTRUCTION-v1.json','dependencyProposal':'INDEPENDENT-CUPRA-DEPENDENCY-PROPOSAL-v1.json','copySanitation':'COPY-SANITATION-MAPPING.json','keyApprovals':'PROSE-KEY-RENAME-APPROVALS.json','symlinks':'SYMLINK-RECONSTRUCTION.json','seedProvenance':'SEED-PROVENANCE.json','inheritedLocalSeedScope':'INHERITED-LOCAL-SEED-READ-SCOPE.json','imageProvenance':'IMAGE-PROVENANCE.json','privacyAdapterContract':'CUPRA-PRIVACY-ADAPTER-CONTRACT.json','privacyAdapterReview':'INDEPENDENT-CUPRA-PRIVACY-ADAPTER-REVIEW-v1.json','privacyGateContract':'CUPRA-PRIVACY-GATE-CONTRACT-v2.json','supportSelection':'SUPPORT-SELECTION-v1.json','rootGrant':'ROOT-CAPTURE-GRANT.json','savingAnnouncement':'SAVING-ANNOUNCEMENT.json','firstPhaseReview':'INDEPENDENT-CUPRA-FIRST-PHASE-STATIC-REVIEW-v1.json'}
 optional={'supportSyntaxClassification':'INDEPENDENT-CUPRA-SUPPORT-SYNTAX-CLASSIFICATION-v2.json','supportSyntaxApproval':'APPROVED-CUPRA-SUPPORT-SYNTAX.json','supportSyntaxReview':'INDEPENDENT-CUPRA-SUPPORT-ADAPTER-REVIEW-v1.json','supportPrivacyContract':'CUPRA-SUPPORT-PRIVACY-CONTRACT-v1.json'}
 for k,n in optional.items():
  if (C/n).exists():names[k]=n
 names['preparatoryFailureReview']='APPROVED-PREPARATORY-FAILURES.json'
 names['interruptedScanPreservation']='SCAN-FRESH-01-INTERRUPTION-PRESERVATION-v1.json';interrupted=verify_interrupted()
 metadata={k:pin(C/n) for k,n in names.items()};gate=load(metadata['privacyGate']['path']);ck(gate['result']=='PASS','privacy gate absent');contract=load(metadata['privacyGateContract']['path']);ck(contract['status']=='REVIEWED_EXACT_PRIVACY_GATE_CONTRACT','gate contract absent');engines={contract[k]['path'] for k in ('sourceProofEngine','supportEngine')}
 scripts=[]
 for p in sorted(C.glob('*.py')):ast.parse(p.read_bytes());scripts.append(pin(p))
 ck(any(r['path']==str(C/'independent_cupra_recovery_v5.py') for r in scripts),'verifier absent')
 final_reports={str(C/r['report']) if not P(r['report']).is_absolute() else r['report'] for r in gate['archives']};scans=[];scan_terminals=set()
 for p in sorted(C.glob('*.resources.json')):
  t=load(p);cmd=t.get('command',[])
  if not any((P(a).name.startswith('privacy_v') or P(a).name.startswith('scan_archive_v')) and P(a).suffix=='.py' for a in cmd):continue
  ck(len(cmd)==5 and cmd[0]=='python3' and cmd[1] in engines,'unreviewed scanner invocation');rp,pp=P(cmd[3]),P(cmd[4]);ck(rp.parent==C and pp in (C/'ARCHIVE-PLAN-initial.json',C/'ARCHIVE-PLAN.json'),'scan locator differs');q=load(rp);code=t['exitCode'];final=str(rp) in final_reports;ck(code in (0,2) and not t['timedOut'] and t['addressSpaceLimitBytes']==LIMIT,'partial/unbounded scanner requires review');ck(q['status']==('clean' if code==0 else 'review-required') and (not final or code==0) and q['archive']==P(cmd[2]).name,'scan outcome differs');key='initialArchivePlan' if pp.name=='ARCHIVE-PLAN-initial.json' else 'archivePlan';expected=contract['sourceProofEngine' if key=='initialArchivePlan' else 'supportEngine'];ck(cmd[1]==expected['path'],'support-only scanner scope differs');scans.append({'archive':q['archive'],'report':pin(rp),'terminal':pin(p),'command':cmd,'archivePlan':metadata[key],'expectedExitCode':code,'finalCoverage':final});scan_terminals.add(str(p))
 ck({r['report']['path'] for r in scans if r['finalCoverage']}==final_reports and len(final_reports)==len(gate['archives']),'final scan terminal coverage differs')
 classes=load(metadata['supportSyntaxClassification']['path'])['exactSupportCodeClassifications'] if 'supportSyntaxClassification' in metadata else [];phases=[];preflights=[];extraFailures={}
 failureFile=P(metadata['preparatoryFailureReview']['path']);f=load(failureFile);ck(f['status']=='REVIEWED_EXACT_PREPARATORY_FAILURES','failed phase approval absent');extraFailures={r['terminal']['path']:r for r in f['failures']};ck(len(extraFailures)==len(f['failures']) and all(r['exitCode']==1 for r in extraFailures.values()),'failed phase approval multiset differs');observedFailures=set()
 for p in sorted(C.glob('*.resources.json')):
  if str(p) in scan_terminals:continue
  t=load(p);code=t['exitCode'];match=re.fullmatch(r'support-preflight-v(\d+)\.resources\.json',p.name);allowed=code==0 or bool(match) and code==2
  if str(p) in extraFailures:ck(pin(p)==extraFailures[str(p)]['terminal'] and code==extraFailures[str(p)]['exitCode'],'failure approval pin differs');allowed=True;observedFailures.add(str(p))
  ck(allowed,'unreviewed preparatory failure '+p.name)
  if match:
   rp=C/('CUPRA-SUPPORT-PATTERN-PREFLIGHT-v'+match.group(1)+'.json');q=load(rp);ck(q['result'] in ('PASS','REVIEW_REQUIRED') and q['rawPatternsUnchanged'] and not q['knownValueSearchPerformed'] and q['seedReads']==q['historicalArchiveReads']==0 and not q['payloadsModified'] and not q['newClassificationsGranted'],'raw preflight scope differs');found=[]
   for row in q['files']:
    ck(row['astValid'] and not row['rawRuntimeFindings'],'unresolved raw runtime/AST finding')
    for finding in row['primaryFindings']:
     member='cupra-recovery-support/'+row['filename'];matches=[r for r in classes if r['member']==member and r['filePin']==sh(row) and r['exactFinding']=={'member':member,**finding}];ck(len(matches)==1,'unapproved exact syntax candidate');found.append(matches[0])
   eligible={('cupra-recovery-support/'+r['filename'],r['bytes'],r['sha256']) for r in q['files']};expected=[r for r in classes if (r['member'],r['filePin']['bytes'],r['filePin']['sha256']) in eligible];canon=lambda rows:sorted(json.dumps(r,sort_keys=True) for r in rows);ck(canon(found)==canon(expected),'raw candidate multiset for exact historical file pins differs');preflights.append({'version':int(match.group(1)),'report':pin(rp),'terminal':pin(p),'newExecutableFiles':q['newExecutableFiles'],'primaryCandidates':len(found),'rawRuntimeCandidates':0})
  phases.append({'phase':p.name.removesuffix('.resources.json'),'terminal':pin(p),'command':t['command'],'expectedExitCode':code})
 ck(observedFailures==set(extraFailures),'approved failed phase absent');ck(preflights,'raw support preflight absent');latest=load(max(preflights,key=lambda r:r['version'])['report']['path']);latest_files={('cupra-recovery-support/'+r['filename'],r['bytes'],r['sha256']) for r in latest['files']};ck(all((r['member'],r['filePin']['bytes'],r['filePin']['sha256']) in latest_files for r in classes) and max(preflights,key=lambda r:r['version'])['primaryCandidates']==len(classes),'latest preflight must contain complete final classification multiset');tested={(r['bytes'],r['sha256']) for r in latest['files']};base=load(BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-KGM-WORKING-20261015.json');prior={(r['bytes'],r['sha256']) for r in base['files'] if r['path'].endswith('.py')};ck(all((r['bytes'],r['sha256']) in tested|prior for r in scripts),'new script absent from final raw preflight');counts={k:len(list((C/d).glob('*.json'))) for k,d in [('historical','seed-read-invocations'),('audi','audi-seed-read-invocations'),('deepal','deepal-seed-read-invocations')]};ck(all(n==len(scans)+1 for n in counts.values()),'seed completion counts differ including exact interrupted reconstruction')
 out={'result':'APPROVED_PINNED_FRESH_REPLAY_INPUTS','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'metadata':metadata,'scriptPins':scripts,'phaseCommands':phases,'scanReports':scans,'interruptedScanAttempts':[interrupted],'expectedScanInvocations':counts,'supportPatternPreflights':preflights,'baseTerminalReceipt':pin(BASE/'FINAL-KGM-UPLOAD-RECEIPTS.json'),'noSourceArchiveOrSeedPayloadReads':True,'postSealMetadataBindingOnly':True}
 for r in list(metadata.values())+scripts:ck(pin(r['path'])==r,'replay input mutated')
 with OUT.open('x') as f:json.dump(out,f,indent=2);f.write('\n')
 print(json.dumps({'result':out['result'],'metadataPins':len(metadata),'scriptPins':len(scripts),'phaseTerminals':len(phases),'scanAttempts':len(scans),'seedInvocations':counts,'outputPin':pin(OUT)}))
if __name__=='__main__':main()
