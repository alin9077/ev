#!/usr/bin/env python3
"""Independent document, native persistence and append-only closure assertions."""
import resource
import sys
import time
import traceback
from delivery_common_v1 import *
from verify_interrupted_scan_metadata_v2 import verify as verify_interrupted

NAMES = {'documents': 'INDEPENDENT-DELIVERY-DOCUMENT-CHECK.json',
         'active': 'INDEPENDENT-ACTIVE-RECEIPT-CHECK.json',
         'persisted-active': 'INDEPENDENT-PERSISTED-ACTIVE-CHECK.json',
         'terminal': 'INDEPENDENT-CUPRA-TERMINAL-CLOSURE-v1.json'}

def check_ref(value):
    path = pathlib.Path(value['path'])
    if not path.is_absolute():
        path = C / path
    check(path, value)

def verify_support_scripts():
    retained = bind_delivery_scripts()
    path = pathlib.Path(__file__); member = 'cupra-recovery-support/' + path.name
    package = load(C / 'support-package.json'); members = file_map(package['memberFiles'])
    ck(member in members, 'versioned document checker absent from exact support archive')
    check(path, members[member])
    replay = load(C / 'INDEPENDENT-CUPRA-REPLAY-INPUTS-v1.json')
    matches = [r for r in replay['scriptPins'] if r['path'] == str(path)]
    ck(len(matches) == 1 and {k: matches[0][k] for k in ('bytes', 'sha256')} == pin(path), 'versioned checker not bound by fresh replay')
    return {**retained, 'additionalCheckerBinding': {'filename': path.name, 'member': member, **pin(path), 'kind': 'exact-new-unique-member'}}

def allowed_seed_scanners():
    names = {'privacy_v1.py', 'scan_archive_v1.py', 'scan_documents_v1.py'}
    path = C / 'CUPRA-SUPPORT-PRIVACY-CONTRACT-v1.json'
    if path.exists():
        contract = load(path)
        ck(contract['result'] == 'APPROVED_CUPRA_SUPPORT_PRIVACY_ADAPTER', 'unapproved support scanner')
        engine = pathlib.Path(contract['supportEngine']['path'])
        ck(engine.parent == C, 'support scanner path differs')
        check(engine, contract['supportEngine'])
        names.add(engine.name)
    return names

def bind_seed_terminals():
    interrupted = verify_interrupted(); unknown_kinds = set()
    terminals = []
    for path in sorted(C.glob('*.resources.json')):
        value = load(path)
        if any(pathlib.Path(part).name.startswith(('privacy_v', 'scan_archive_v', 'scan_documents_v')) and str(part).endswith('.py')
               for part in value.get('command', [])):
            terminals.append((path, value))
    rows = []
    for kind, summary in seed_summary().items():
        if kind == 'inheritedLocal':
            continue
        for row in summary['receiptReferences']:
            when = datetime.datetime.fromisoformat(row['completedAt'])
            matches = [(path, value) for path, value in terminals if value['childPid'] == row['processId'] and
                       datetime.datetime.fromisoformat(value['startedAt']) <= when <= datetime.datetime.fromisoformat(value['endedAt'])]
            receipt_path = C / row['path']
            exact_unknown = {'path': str(receipt_path), **pin(receipt_path)} == interrupted['completedSeedReconstructions'][kind]
            if exact_unknown:
                ck(not matches and kind not in unknown_kinds, 'interrupted receipt has a terminal or duplicate binding')
                unknown_kinds.add(kind)
                if kind == 'historical':
                    ck(load(receipt_path)['memberIdentityListPin'] == pin(C / 'SEED-PROVENANCE.json'), 'interrupted seed provenance pin differs')
                rows.append({'kind': kind, 'receipt': row['path'], 'terminal': None, 'invocation': interrupted['invocation'], 'scanOutcome': interrupted['scanOutcome'], 'successfulScanClaim': False})
                continue
            ck(len(matches) == 1, 'seed receipt lacks one exact terminal interval')
            path, value = matches[0]
            if kind == 'deepal':
                ck(any(pathlib.Path(part).name in tuple(allowed_seed_scanners()) for part in value['command']),
                   'Deepal seed bound to a pre-adapter scan')
            invocation_path = path.with_name(path.stem + '.invocation.json')
            invocation = load(invocation_path)
            ck(value['command'] == invocation['command'] and value['childPid'] == invocation['childPid'] and
               value['addressSpaceLimitBytes'] == invocation['addressSpaceLimitBytes'] == LIMIT and
               value['wallLimitSeconds'] == invocation['wallLimitSeconds'] == 600,
               'seed scanner invocation/terminal contract differs')
            ck(value['exitCode'] in (0, 2) and not value['timedOut'], 'partial failed seed invocation requires separate reviewed accounting')
            if kind == 'historical':
                ck(load(C / row['path'])['memberIdentityListPin'] == pin(C / 'SEED-PROVENANCE.json'), 'seed provenance pin differs')
            rows.append({'kind': kind, 'receipt': row['path'], 'terminal': ref(path),
                         'exitCode': value['exitCode'], 'timedOut': value['timedOut']})
    ck(unknown_kinds == {'historical', 'audi', 'deepal'}, 'exact interrupted completed-stage receipt multiset differs')
    return rows

def documents():
    plan, base, prior = load(C / 'RESTORE-PLAN.json'), load(BASE_MANIFEST), load(BASE_TERMINAL)
    verify_base_snapshot()
    inventory, author_acceptance = author_inputs()
    scope, contract = load(C / 'FROZEN-CAPTURE-SCOPE.json'), load(C / 'APPLICATION-ASSERTION-CONTRACT.json')
    ck(scope['authorRetention'] == inventory and len(scope['files']) == 453, 'current frozen inventory differs')
    ck(scope['expectedSourceFiles'] == 697 and scope['expectedNonSourceOverlay'] == ['roadmark-104-qa/work-status.json'], 'source/non-source frozen scope differs')
    dependency = load(C / DEPENDENCY)
    manifest, verification = load(DOCS[1]), load(DOCS[2])
    ck([row['local_path'] for row in load(C / 'library-documents-request.json')['uploads']] == [str(path) for path in DOCS],
       'document request order differs')
    ck(manifest['schemaVersion'] == verification['schemaVersion'] == 9, 'document schema differs')
    archives = final_archives(plan)
    ck(manifest['archivesInRestoreOrder'] == archives and manifest['newArchives'] ==
       [row for row in archives if row.get('new')], 'native archive chain differs')
    ck(manifest['files'] == plan['files'] and len(file_map(manifest['files'])) == plan['logicalFiles'], 'logical file map differs')
    counts = {key: plan[key] for key in COUNT_KEYS}
    ck(manifest['incrementalVerification'] == verification['counts'] == counts and
       counts['baseArchivesReused'] == 134 and counts['fullSourceFiles'] == 697, 'counts differ')
    source = next(row for row in archives if row['group'].startswith('source-'))
    ck(manifest['source'] == verification['source'] == source and source['bytes'] < 15000000, 'source differs or exceeds limit')
    support = next(row for row in archives if row.get('new') and row['filename'].endswith('-support.tar.xz'))
    ck(manifest['supportArchive']['archive'] == verification['supportArchive'] == support and
       manifest['supportArchive']['members'] == load(C / 'support-package.json')['memberFiles'], 'support identity differs')
    check_ref(manifest['supportArchive']['reuseMapping'])
    ck(manifest['baseRecovery']['manifestLibraryFileId'] == prior['manifestLibraryFileId'] and
       manifest['baseRecovery']['indexLibraryFileId'] == prior['indexLibraryFileId'] and
       manifest['baseRecovery']['activeReceiptLibraryFileId'] == prior['activeReceiptLibraryFileId'] and
       manifest['baseRecovery']['manifest'] == {'library_file_id': prior['manifestLibraryFileId'], **pin(BASE_MANIFEST)},
       'base native identity differs')
    ck(manifest['baseRecovery']['terminalReceiptPin'] == pin(BASE_TERMINAL) and
       manifest['baseRecovery']['archives'] == len(base['archivesInRestoreOrder']) == 135 and
       manifest['baseRecovery']['logicalFiles'] == len(base['files']) == 13380 and
       manifest['baseRecovery']['unchangedArchivesReused'] == 134, 'base terminal/counts differ')
    ck(manifest['baseRecovery']['priorSource'] == base['source'] and manifest['baseRecovery']['priorRecoverySeparatelyPreserved'] and
       manifest['baseRecovery']['priorKGMTypeScriptPassed'] is False and manifest['baseRecovery']['priorKGMReleaseReady'] is False and
       manifest['baseRecovery']['priorKGMFailureDoesNotEstablishCUPRAPass'], 'prior/current source and pass boundary differs')
    for key in INHERIT_KEYS:
        ck(manifest[key] == base[key], 'inherited sanitation/exclusion field differs: ' + key)
    ck(manifest['inheritedCopyOnlySanitation'] == base['inheritedCopyOnlySanitation'] +
       [{'cut': 'KGM', 'mapping': base['copyOnlySanitation']}], 'inherited copy sanitation chain differs')
    ck(manifest['inheritedCurrentRawCaptureReplayLimitation'] == base['currentRawCaptureReplayLimitation'] and
       manifest['inheritedCurrentCopySourcePinReferenceCounts'] == base['inheritedCurrentCopySourcePinReferenceCounts'], 'inherited raw-pin limitations differ')
    ck(manifest['inheritedLinkAndDuplicateScope'] == {'priorManifest': manifest['baseRecovery']['manifest'],
        'priorSymlinkReconstructionPointer': '/symlinkReconstruction',
        'priorInheritedScopePointer': '/inheritedLinkAndDuplicateScope'}, 'inherited link references differ')
    sanitation_path, sanitation = replay_metadata('copySanitation')
    proof_path, proof_capture = replay_metadata('proofCapture')
    ck(manifest['copyOnlySanitation'] == sanitation and
       manifest['symlinkReconstruction'] == load(C / 'SYMLINK-RECONSTRUCTION.json'), 'current transformation/link map differs')
    ck(manifest['copyOnlySanitationReference'] == verification['copyOnlySanitationReference'] == ref(sanitation_path) and
       manifest['currentProofCapture'] == {'receipt': ref(proof_path), 'selectedOriginalFiles': len(proof_capture['files']),
                                         'newDeltaFiles': len(proof_capture['changedFiles'])} and
       manifest['currentRawCaptureReplayLimitation'] == verification['currentRawCaptureReplayLimitation'] ==
       'Sanitized copied bytes verify retained hashes only; they cannot silently satisfy original raw expected pins. Original files and expected raw pins remain unchanged.',
       'selected final sanitation/proof binding or raw-pin limitation differs')
    ck(manifest['generatedSupportMetadataCopy'] == verification['generatedSupportMetadataCopy'] ==
       generated_support_copy(manifest['supportArchive']['members'], sanitation), 'support metadata copy/source-proof distinction differs')
    adapter, deepal_counters, unused = deepal_adapter()
    classified = load(adapter['classification']['path'])
    expected_review = {'classification': adapter['classification'], 'additiveInventory': adapter['additiveInventory'],
                       'summary': classified['summary'], 'knownValueSearchCounts': deepal_counters,
                       'pinReferencedCopiedFiles': sum(bool(row['sourcePinReferences']) for row in classified['files']),
                       'originalDetectorCoverageGap': classified['originalDetectorCoverageGap'],
                       'fourHTMLFactualProjectionsUnchanged': all(row['visibleFactualTextUnchanged'] for row in classified['files'] if row['format'] == 'html'),
                       'oneJSONOpaqueQueryOnly': all(row['jsonStructureAndOtherValuesUnchanged'] and
                                                    [leaf['pointer'] for leaf in row['changedJSONLeaves']] == ['/scripts/24'] and
                                                    all(leaf['onlyApprovedOpaqueValueReplacements'] for leaf in row['changedJSONLeaves'])
                                                    for row in classified['files'] if row['format'] == 'json'),
                       'genericDecodedCoverageClaimed': False, 'universalAbsenceClaimed': False}
    ck(manifest['deepalSanitationReview'] == verification['deepalSanitationReview'] == expected_review and
       expected_review == base['deepalSanitationReview'] and expected_review['fourHTMLFactualProjectionsUnchanged'] and expected_review['oneJSONOpaqueQueryOnly'],
       'copy-parity, original detector gap or final classification summary differs')
    mapping = manifest['inheritedDependencyReconstruction']
    ck(mapping['dependencies'] == dependency['dependencies'] and mapping['count'] == dependency['count'] == len(dependency['dependencies']) and
       mapping['relocatedMemberPointers'] == dependency['relocatedMemberPointers'] and
       mapping['newRecords'] == dependency['newRecords'] and mapping['originalExpectedPathsAndHashesUnchanged'],
       'dependency reconstruction differs')
    canonical = hashlib.sha256(json.dumps(mapping['dependencies'], sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    ck(canonical == mapping['dependenciesCanonicalSha256'] == dependency['dependenciesCanonicalSha256'], 'dependency canonical hash differs')
    ck(manifest['authorFinalAcceptance'] == verification['authorFinalAcceptance'] == {'path': str(AUTHOR_ACCEPTANCE), **AUTHOR_ACCEPTANCE_PIN}, 'author final acceptance identity differs')
    check_ref(mapping['receipt'])
    ck(dependency_summary(dependency) == {key: mapping[key] for key in ('receipt', 'count', 'relocatedMemberPointers', 'newRecords')}, 'dependency summary differs')
    ck(verification['dependencyMapping'] == mapping['receipt'] and verification['dependencyCount'] == dependency['count'] and
       verification['dependencyRelocations'] == dependency['relocatedMemberPointers'], 'verification dependency summary differs')
    state = manifest['workState']
    ck(verification['workState'] == state and manifest['status'] == verification['status'] == scope['workingResult'], 'working status differs')
    expected_summary = {'scopedTests': 151, 'fullProjectTypeScriptPassed': False,
                        'normalReportExplainedLeaves': 1429, 'unexplainedReportDifferences': 0,
                        'releaseReady': False}
    ck(all(contract['summary'].get(key) == value for key, value in expected_summary.items()), 'CUPRA application summary differs')
    for key, value in contract['summary'].items():
        ck(state[key] == value, 'document application fact differs: ' + key)
    ck(state['currentCounts'] == {'catalogue': 430, 'tier1': 353, 'onSale': 312, 'packets': 29} and
       state['historicalDeepalPreview'] == {'compactReceipts': 6, 'browserOutcome': 'Cloud-browser loopback reachability refused', 'notCUPRAVisualQA': True} and
       state['CUPRAVisualQAPassed'] is False and state['otherAttemptHistory'] == inventory['otherAttemptHistory'], 'counts/attempt/preview boundary differs')
    ck(state['registered'] and state['integrationIndependentlyAccepted'] and state['targetedCountsNotClaimedDisjoint'] and
       state['fullProjectTypeScriptPassed'] is False and state['structuralValidationPassed'] and state['strictSavedReportComparisonPassed'] and
       state['historicalTypeScriptPassesDoNotApplyToCurrentSource'] and state['compilerRetriesPermitted'] is False and
       state['currentValidationFactualOnly'], 'accepted factual scope or prior/current TypeScript boundary differs')
    ck(all(state[key] is False for key in ('fullProjectSuitePassed', 'buildPassed', 'mobilePassed', 'releaseReady', 'published')) and
       state['milestone'] == 'M1 open' and state['openGates'] == verification['openGates'] == scope['openGates'], 'open gates falsely closed')
    ck(state['failedAttempts'] == scope['authorRetention']['retainedFailures'] and
       state['authorFreezeAt'] == scope['authorRetention']['frozenAt'], 'retained failures/freeze differs')
    ck(manifest['sourceChangedPaths'] == verification['sourceChangedPaths'] == scope['sourceChangedPaths'] and
       len(scope['sourceChangedPaths']) == 6, 'source delta differs')
    recovery, gate = load(C / RECOVERY), load(C / GATE)
    ck(recovery['result'] == gate['result'] == 'PASS', 'fresh recovery/privacy did not pass')
    application_assertion_scope = application_scope(recovery, contract)
    independent = manifest['independentVerification']
    ck(independent == verification['independentVerification'] and independent['result'] == 'PASS' and
       independent['receipt'] == ref(C / RECOVERY) and independent['applicationAssertionCount'] == len(contract['assertions']) and len(contract['assertions']) > 0 and
       independent['mandatoryRetainedPins'] == len(contract['retainedPins']) and len(contract['retainedPins']) > 0 and
       independent['applicationAssertionScope'] == application_assertion_scope and
       independent['freshMembers'] == plan['freshFiles'] and independent['freshBytes'] == plan['freshBytes'] and
       independent['freshArchiveCount'] == len(plan['newArchives']) and independent['archiveStreamsVerifiedThroughXZEOF'], 'fresh verification summary differs')
    ck(independent['recoverableReceipt'] == {'document': DOCS[2].name, 'jsonPointer': '/postSealReceipts/0'},
       'recoverable independent receipt pointer differs')
    ck(independent['recoverableInputManifest'] == {'document': DOCS[2].name, 'jsonPointer': '/postSealReceipts/2'},
       'recoverable pinned replay-input manifest pointer differs')
    for key, name in [('inputManifest', 'INDEPENDENT-CUPRA-REPLAY-INPUTS-v1.json'),
                      ('memberReplayManifest', 'INDEPENDENT-NEW-MEMBER-REPLAY-MANIFEST-v1.json'),
                      ('applicationContract', 'APPLICATION-ASSERTION-CONTRACT.json')]:
        ck(independent[key] == ref(C / name), 'verification evidence pin differs')
    privacy_summary = manifest['privacyVerification']
    ck(privacy_summary['recoverableReceipt'] == {'document': DOCS[2].name, 'jsonPointer': '/postSealReceipts/1'},
       'recoverable privacy receipt pointer differs')
    ck(privacy_summary == verification['privacyVerification'] and privacy_summary['receipt'] == ref(C / GATE) and
       privacy_summary['result'] == 'PASS' and privacy_summary['freshMembers'] == gate['freshMembers'] == plan['freshFiles'] and
       privacy_summary['freshBytes'] == gate['freshBytes'] == plan['freshBytes'] and
       privacy_summary['unclassifiedFindings'] == gate['unclassifiedFindings'] == 0 and privacy_summary['errors'] == gate['errors'] == 0,
       'privacy summary differs')
    ck(privacy_summary['rawScannerResultsModified'] == gate['rawScannerResultsModified'] is False and
       privacy_summary['classificationCounts'] == {key: value for key, value in gate.items() if
                                                    isinstance(value, int) and ('Candidate' in key or 'Collision' in key)} and
       privacy_summary['rawArchiveOutcomes'] == [{'archive': row['archive'], 'rawScannerStatus': row['rawScannerStatus'],
                                                 **{key: value for key, value in row.items() if
                                                    isinstance(value, int) and ('Candidate' in key or 'Collision' in key)}}
                                                for row in gate['archives']], 'raw scan/adjudication disclosure differs')
    ck(privacy_summary['supportOnlySyntaxClassification'] == support_privacy_scope(gate, recovery), 'support-only syntax disclosure differs')
    ck(verification['inheritedLocalSeedExecutionsAtFreshVerification'] == recovery['inheritedLocalSeedExecutions'],
       'fresh-verification inherited local seed accounting differs')
    images = load(C / 'IMAGE-PROVENANCE.json')
    ck(manifest['currentImageProvenance'] == verification['imageProvenance'] == images and
       images['files'] == inventory['publicImageProvenance']['existingPublicPdfPageRenders'] and len(images['files']) == 2 and
       images['result'] == 'AUTHOR_AND_REVIEWER_CLASSIFIED_PUBLIC_PDF_PAGE_RENDERS' and
       images['filenameInventoryChecked'] is True and images['imageExtensionCandidates'] == 2 and
       images['newImageBodiesReadOrRendered'] is False and images['browserScreenshotsIncluded'] is False and
       images['authorInventory'] == {'path': str(AUTHOR_INVENTORY), **AUTHOR_INVENTORY_PIN}, 'image provenance differs')
    ck([row['pdfPageNumber'] for row in images['files']] == [27, 28] and
       [row['pdfZeroBasedPageIndex'] for row in images['files']] == [26, 27] and
       [row['visibleHeading'] for row in images['files']] == ['Technical', 'Full features'] and
       inventory['publicImageProvenance']['currentMy26EquipmentInference'] is False, 'historical PDF-page qualification differs')
    final_members = file_map(plan['files'])
    for image in images['files']:
        for key in ('file', 'sourcePdf', 'parentProvenance', 'parentExtractedText'):
            item = image[key]
            origin = pathlib.Path(item['path'])
            ck(origin.is_absolute() and origin.is_relative_to('/tmp/cupra-research'), 'image provenance origin outside retained source root')
            restored = origin.relative_to('/tmp').as_posix()
            ck(restored in final_members and {field: final_members[restored][field] for field in ('bytes', 'sha256')} ==
               {field: item[field] for field in ('bytes', 'sha256')}, 'image or parent PDF/text/provenance absent from final restore map')
    ck(manifest['mutablePreparationLimitation'] == state['mutableV1Limitation'] == inventory['mutableV1Limitation'] and
       manifest['sourceRetention'] == state['sourceRetention'] == {'acceptedV3Pins': 86, 'heldV2OnlyPins': 11, 'unionPins': 97,
           'missingOriginalMutableLightV1Pins': 81, 'missingBytesReconstructed': False} and
       state['currentValidation'] == inventory['currentValidation'] and state['newCUPRACompilerRun'] is False and
       state['currentCUPRARuntimeFailure'] is False and state['typeScriptFailuresInheritedFromKGM'] is True,
       'current/inherited failure or missing mutable preparation boundary differs')
    ck(manifest['inheritedKGMRecoveryBoundaries'] == {key: base[key] for key in
       ('generatedSupportMetadataCopy', 'currentRawRuntimeExclusion', 'currentExcludedItems',
        'currentRawCaptureReplayLimitation', 'rawDeepalOriginalReadRecoveryRefetchForbidden',
        'rawKgmOriginalReadRecoveryRefetchForbidden')}, 'inherited KGM restrictions differ')
    ck(manifest['supportArchive']['deliveryScriptBindings'] == bind_delivery_scripts(), 'support executable reuse bindings differ')
    ck(manifest['inheritedImageProvenance'] == {'priorManifest': manifest['baseRecovery']['manifest'], 'jsonPointer': '/currentImageProvenance'}, 'inherited image provenance differs')
    ck(manifest['inheritedDeepalCopySourcePinReferenceCounts'] == {'copiedFiles': expected_review['pinReferencedCopiedFiles'], 'references': expected_review['summary']['sourcePinReferences']}, 'inherited Deepal source-pin counts differ')
    ck(manifest['deepalSanitizedSupport'] == verification['deepalSanitizedSupport'] == base['deepalSanitizedSupport'] and
       manifest['cupraFactualCaptureProvenance'] == verification['cupraFactualCaptureProvenance'] == inventory['knownSanitizedSupport'] and
       manifest['inheritedMINIFactualCaptureProvenance'] == verification['inheritedMINIFactualCaptureProvenance'] == base['inheritedMINIFactualCaptureProvenance'] and
       manifest['inheritedKGMFactualCaptureProvenance'] == verification['inheritedKGMFactualCaptureProvenance'] == base['kgmFactualCaptureProvenance'] and
       manifest['currentRawRuntimeExclusion'] == verification['currentRawRuntimeExclusion'] == inventory['rawRuntimeExclusion'] and
       manifest['currentExcludedItems'] == scope['authorRetention']['excluded'] and
       manifest['rawDeepalOriginalReadRecoveryRefetchForbidden'] and verification['rawDeepalOriginalReadRecoveryRefetchForbidden'] and
       manifest['rawKgmOriginalReadRecoveryRefetchForbidden'] and verification['rawKgmOriginalReadRecoveryRefetchForbidden'] and
       manifest['rawCupraOriginalReadRecoveryRefetchForbidden'] and verification['rawCupraOriginalReadRecoveryRefetchForbidden'], 'Deepal raw-body restriction differs')
    ck(manifest['factualSummary'] == {'filename': DOCS[3].name, 'sourceMember': 'roadmark/docs/CUPRA_M1_UPDATE.md',
                                    'bytes': 5684, 'sha256': 'fd32ecf44f017010a6de5e6ba595a04be2e3aee096eada2b15d5e74ffe73cb0c',
                                    'copiedExactly': True}, 'factual summary reference differs')
    check(DOCS[3], manifest['factualSummary'])
    ck(verification['manifest'] == {'filename': DOCS[1].name, **pin(DOCS[1])}, 'verification manifest binding differs')
    index = DOCS[0].read_text()
    ck(f"Recommended chain: {len(archives)} archives, {plan['logicalFiles']:,} logical files" in index, 'index count differs')
    for row in archives:
        exact = f"{row['restoreOrder']}. {row['filename']} | {row['library_file_id']} v{row['version']} | {row['bytes']} bytes | SHA-256 {row['sha256']}"
        ck(index.count(exact) == 1, 'index exact archive row absent/duplicated')
    for phrase in ('Current support syntax approval covers exactly', 'missing, duplicate or unexpected findings block',
                   'original privacy_v1 scanner remains unchanged', 'grants are not reused for changed CUPRA bytes',
                   f"{application_assertion_scope['totalAssertions']} assertions: {application_assertion_scope['freshArchiveAssertions']} fresh and {application_assertion_scope['exactInheritedAssertions']} exactly inherited",
                   'independent verifier reread zero inherited payloads', '151 fresh scoped',
                   'full-project TypeScript remains UNPASSED', 'two inherited KGM SIGKILL terminations whose causes are unknown',
                   'no new CUPRA compiler run or retry occurred', 'explicit factual-only exception',
                   'Both actual earlier KGM TypeScript failures', 'unexecuted preparations', 'Zero CUPRA UI screenshots',
                   'Historical TypeScript successes apply only to their historical source snapshots',
                   'full-base rescan', 'must never be read, recovered or refetched',
                   f"{dependency['count']} exact dependency reconstruction records", 'strict M1 closure and release remain open',
                   'not a new CUPRA field inventory', 'Two existing public maker MY25.5 PDF-page PNGs', 'No helper or test changes',
                   f"zero source transformations, {manifest['generatedSupportMetadataCopy']['sourceProofTransformationScope']['proofMetadataKeyRenames']} separately approved proof metadata key renames and zero current generated-support metadata key renames",
                   'cannot satisfy the original expected whole-file pin', 'Original files and expected pins remain unchanged',
                   'large preliminary proposal remains local and excluded from support',
                   'original reviewed preparation bytes are missing and are not reconstructed',
                   '86 accepted-v3 pins plus 11 held-v2-only pins', 'Six current mutable unversioned files remain excluded',
                   'No CUPRA runtime failure occurred', '1,429 changed leaves'):
        ck(phrase in index, 'required index limitation absent: ' + phrase)
    for phrase in (classified['originalDetectorCoverageGap'], 'exact two-shape raw-byte inventory',
                   'generic arbitrary-decoding coverage is not claimed',
                   f"{deepal_counters['deepalRuntimeValues']} distinct values and {deepal_counters['deepalRuntimeForms']} supported forms"):
        ck(phrase in index, 'final Deepal search limit disclosure absent')
    seeds = manifest['targetedHistoricalSeedReadDependency']
    ck(seeds['scope'] == load(C / 'TARGETED-SEED-READ-DEPENDENCY.json') and
       seeds['executionsAsOfBuild'] == verification['targetedSeedExecutionsAsOfBuild'], 'seed disclosure differs')
    seed_counts = check_seed_summary(seeds['executionsAsOfBuild'])
    retained_receipts = check_post_seal_receipts(verification['postSealReceipts'])
    ck(verification['cupraPrivacyAdapter'] == ref(C / 'CUPRA-PRIVACY-ADAPTER-CONTRACT.json'),
       'verification privacy adapter differs')
    no_embedded_source(manifest)
    no_embedded_source(verification)
    return {'result': 'PASS', 'documents': [{'filename': path.name, **pin(path)} for path in DOCS],
            'recommendedArchives': len(archives), 'logicalFiles': plan['logicalFiles'], 'freshMembers': plan['freshFiles'],
            'privacyGate': privacy('DELIVERABLE-PRIVACY-GATE.json', DOCS), 'seedCountsAsOfDocumentBuild': seed_counts,
            'inheritedSanitationAndExclusionsPreserved': True, 'dependencies': dependency['count'], 'dependencyRelocations': dependency['relocatedMemberPointers'],
            'sourceSummaryCopiedExactly': True, 'noExecutableSourceTextEmbedded': True,
            'recoverablePostSealReceipts': retained_receipts,
            'noArchivePayloadReread': True, 'broaderReleaseGatesRemainOpen': True}

def active(persisted=False):
    manifest, value = load(DOCS[1]), load(ACTIVE)
    for key in ('status', 'source', 'newArchives', 'baseRecovery', 'workState', 'verificationScope', 'independentVerification', 'generatedSupportMetadataCopy'):
        ck(value[key] == manifest[key], 'active/manifest differs: ' + key)
    ck(value['counts'] == manifest['incrementalVerification'] and value['archivePrivacyGate'] == manifest['privacyVerification'] and
       value['supportArchive'] == manifest['supportArchive']['archive'], 'active summary differs')
    docs = native('documents')
    ck(value['documents'] == docs and value['manifest'] == next(row for row in docs if row['filename'] == DOCS[1].name), 'active document identities differ')
    ck(value['verificationDocument'] == next(row for row in docs if row['filename'] == DOCS[2].name) and
       value['recoverablePostSealReceiptPointers'] == ['/postSealReceipts/0', '/postSealReceipts/1', '/postSealReceipts/2'],
       'active recoverable verification references differ')
    review = load(C / 'INDEPENDENT-DELIVERY-DOCUMENT-CHECK.json')
    ck(review['result'] == 'PASS' and review['documents'] == [{'filename': path.name, **pin(path)} for path in DOCS], 'approved document bytes differ')
    ck(value['preSaveDocumentVerification'] == {'result': 'PASS', 'receipt': ref(C / 'INDEPENDENT-DELIVERY-DOCUMENT-CHECK.json')} and
       value['documentPrivacyGate'] == {'result': 'PASS', 'receipt': privacy('DELIVERABLE-PRIVACY-GATE.json', DOCS)}, 'active document evidence differs')
    ck(value['inheritedDependencyReconstruction'] == dependency_summary(load(C / DEPENDENCY)), 'active dependencies differ')
    for key in ('rawDeepalOriginalReadRecoveryRefetchForbidden', 'rawKgmOriginalReadRecoveryRefetchForbidden', 'rawCupraOriginalReadRecoveryRefetchForbidden', 'allInheritedSanitationExclusionsPreservedInManifest',
                'noSourceOrStatusMutationByBackup', 'noDeletionOrReplacement', 'noExecutableSourceTextEmbedded'):
        ck(value[key] is True, 'active preservation claim absent')
    ck(value['savingAnnouncement'] == saving_announcement(), 'active saving announcement differs')
    no_embedded_source(value)
    result = {'result': 'PASS', 'activeReceipt': pin(ACTIVE), 'documents': docs,
              'recommendedArchives': value['counts']['archiveCount'], 'logicalFiles': value['counts']['logicalFiles'],
              'activePrivacyGate': privacy('ACTIVE-PRIVACY-GATE.json', [ACTIVE]),
              'seedCountsAsOfActiveBuild': check_seed_summary(value['seedReadExecutionsAsOfBuild']),
              'noArchivePayloadReread': True, 'broaderReleaseGatesRemainOpen': True}
    if persisted:
        before = load(C / 'INDEPENDENT-ACTIVE-RECEIPT-CHECK.json')
        ck(before['result'] == 'PASS' and before['activeReceipt'] == pin(ACTIVE), 'persisted active bytes differ')
        rows = native('active')
        ck(len(rows) == 1 and rows[0]['filename'] == ACTIVE.name, 'persisted active native identity differs')
        result.update(persistedActive=rows[0], preSaveCheck=ref(C / 'INDEPENDENT-ACTIVE-RECEIPT-CHECK.json'))
    return result

def closure():
    target = C / 'FINAL-CUPRA-UPLOAD-RECEIPTS.json'
    earlier = C / 'FINAL-CUPRA-UPLOAD-RECEIPTS-before-persistence-check.json'
    final, previous, manifest = load(target), load(earlier), load(DOCS[1])
    allowed = {'createdAt', 'delivery', 'deliveryConfirmation', 'activePersistenceCheck'}
    ck({key: value for key, value in final.items() if key not in allowed} ==
       {key: value for key, value in previous.items() if key not in allowed}, 'terminal append changed immutable fields')
    archive_pins = {row['filename']: {key: row[key] for key in ('bytes', 'sha256')} for row in manifest['newArchives']}
    archives, docs, active_rows = native('archives', archive_pins), native('documents'), native('active')
    ck(final['files'] == archives + docs + active_rows and len(active_rows) == 1 and len(docs) == 4, 'terminal native set differs')
    wanted = {'source': manifest['source']['library_file_id'],
              **{key: next(row['library_file_id'] for row in docs if row['filename'] == path.name)
                 for key, path in zip(('index', 'manifest', 'verification', 'summary'), DOCS)}}
    delivery = load(C / 'DELIVERY-CONFIRMATION.json')
    ck(delivery['libraryFileIds'] == wanted and delivery['channel'] == 'chatgpt' and delivery['messageId'] and delivery['sentAt'] and
       delivery['acceptedSendDoesNotProveOpened'], 'accepted delivery identity differs')
    ck(final['deliveryConfirmation'] == {'receipt': ref(C / 'DELIVERY-CONFIRMATION.json'), **delivery} and
       final['activePersistenceCheck'] == {'result': 'PASS', 'receipt': ref(C / 'INDEPENDENT-PERSISTED-ACTIVE-CHECK.json')}, 'terminal closure refs differ')
    persisted = load(C / 'INDEPENDENT-PERSISTED-ACTIVE-CHECK.json')
    ck(persisted['result'] == 'PASS' and persisted['persistedActive'] == active_rows[0], 'persisted active check differs')
    for key, field in [('source', 'sourceLibraryFileId'), ('index', 'indexLibraryFileId'), ('manifest', 'manifestLibraryFileId'),
                       ('verification', 'verificationLibraryFileId'), ('summary', 'summaryLibraryFileId')]:
        ck(final[field] == wanted[key], 'terminal primary native ID differs')
    ck(final['activeReceiptLibraryFileId'] == active_rows[0]['library_file_id'] and
       final['archiveLibraryFileIds'] == [row['library_file_id'] for row in archives], 'terminal archive/active IDs differ')
    for phase in ('archives', 'documents', 'active'):
        for value in final['phaseReferences'][phase].values():
            check_ref(value)
    no_embedded_source(final)
    return {'result': 'PASS_TERMINAL_RECOVERY_CLOSURE', 'currentFinalReceipt': pin(target),
            'preservedInitialFinalReceipt': pin(earlier), 'persistenceCheck': ref(C / 'INDEPENDENT-PERSISTED-ACTIVE-CHECK.json'),
            'newNativeFiles': len(final['files']), 'recommendedArchives': len(manifest['archivesInRestoreOrder']),
            'logicalFiles': len(manifest['files']), 'sourceLibraryFileId': wanted['source'], 'activeReceipt': active_rows[0],
            'acceptedDelivery': {'receipt': ref(C / 'DELIVERY-CONFIRMATION.json'), 'messageId': delivery['messageId'],
                                 'sentAt': delivery['sentAt'], 'libraryFileIds': wanted},
            'targetedSeedReadExecutions': check_seed_summary(final['targetedSeedReadExecutionSummary'], complete=True),
            'changedFinalReceiptFieldsOnly': sorted(key for key in set(final) | set(previous) if final.get(key) != previous.get(key)),
            'noArchivePayloadReadsOrUploadsOrDeletion': True, 'broaderApplicationReleaseGatesRemainOpen': True}

def main():
    started = time.monotonic()
    ck(len(sys.argv) == 3 and sys.argv[2] == '--sole-child-slot-authorized',
       'Usage: independent_cupra_documents_v2.py {documents,active,persisted-active,terminal} --sole-child-slot-authorized')
    mode = sys.argv[1]
    ck(mode in NAMES, 'unknown check mode; closure is not a supported command mode')
    output = C / NAMES[mode]
    ck(not output.exists(), 'preserve prior result; use a separately reviewed retry')
    code = 0
    try:
        ck('--sole-child-slot-authorized' in sys.argv and resource.getrlimit(resource.RLIMIT_AS) == (LIMIT, LIMIT),
           'sole-slot 256 MiB verification contract absent')
        retained = verify_support_scripts()
        result = documents() if mode == 'documents' else active(mode == 'persisted-active') if mode in ('active', 'persisted-active') else closure()
        result['supportScriptBinding'] = retained
        result['seedTerminalBindings'] = bind_seed_terminals()
    except BaseException as error:
        code = 1
        result = {'result': 'BLOCKED', 'blocker': {'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()}}
    result.update(checkedAt=now(), verifierScript=pin(pathlib.Path(__file__)),
                  resources={'wallSeconds': round(time.monotonic() - started, 3),
                             'maxRssKiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                             'addressSpaceLimitBytes': resource.getrlimit(resource.RLIMIT_AS)[0], 'chunkBytes': CHUNK})
    dump(output, result)
    print(json.dumps({'mode': mode, 'result': result['result'], 'blocker': result.get('blocker'), 'resources': result['resources']}))
    raise SystemExit(code)

if __name__ == '__main__':
    main()
