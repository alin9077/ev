#!/usr/bin/env python3
"""Verify one preserved interrupted scan without inventing its missing outcome."""
import datetime,hashlib,json,pathlib,stat
P=pathlib.Path;C=P(__file__).resolve().parent
PRESERVED='SCAN-FRESH-01-INTERRUPTION-PRESERVATION-v1.json'
PRESERVED_PIN={'bytes':2839,'sha256':'838dc036ea1d536cccdcb00d687d087c8808f2c3694173850b0be07caa5717eb'}
def ck(v,m):
 if not v:raise AssertionError(m)
def load(p):return json.loads(P(p).read_bytes())
def pin(p):
 p=P(p);s=p.lstat();ck(stat.S_ISREG(s.st_mode) and not any(x.is_symlink() for x in p.parents),'unsafe interruption metadata');before=(s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev);b=p.read_bytes();s=p.lstat();ck(before==(s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev),'interruption metadata changed');return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def verify():
 p=C/PRESERVED;actual=pin(p);ck({k:actual[k] for k in ('bytes','sha256')}==PRESERVED_PIN,'preserved interruption pin differs');q=load(p)
 ck(q['result']=='UNKNOWN_INTERRUPTED_NO_TERMINAL_RECEIPT' and q['unknownOutcomeNotCountedAsPass'] and q['matchingPriorScannerOrRunnerVisible'] is False,'interrupted outcome differs')
 ck(q['missingOutputs']==['scan-fresh-01.resources.json','scan-fresh-01.json'],'unknown output set differs')
 for name in q['missingOutputs']:ck(not (C/name).exists(),'original unknown result appeared; reconcile instead of overriding')
 expected=[C/'scan-fresh-01.resources.invocation.json',C/'run-logs/scan-fresh-01.log',C/'run-logs/scan-fresh-01.err']
 ck([r['path'] for r in q['preservedFiles']]==list(map(str,expected)),'preserved file scope differs')
 for r in q['preservedFiles']:ck(pin(r['path'])==r,'preserved file pin differs')
 ck(q['originalInvocation']==q['preservedFiles'][0],'original invocation binding differs');iv=load(q['originalInvocation']['path'])
 wanted=['python3',str(C/'scan_archive_v1.py'),str(C.parents[1]/'Roadmark-recovery-source-CUPRA-WORKING-20261015T1745.tar.xz'),str(C/'scan-fresh-01.json'),str(C/'ARCHIVE-PLAN-initial.json')]
 ck(iv['command']==wanted and iv['addressSpaceLimitBytes']==268435456 and iv['wallLimitSeconds']==600,'original invocation differs')
 ck(iv['childPid']==iv['processGroup'] and iv['processSerializationEstablished'] and not iv['unknownPriorValidationProcessMayOverlap'],'original serialization differs')
 folders={'historical':'seed-read-invocations','audi':'audi-seed-read-invocations','deepal':'deepal-seed-read-invocations'};records={};start=datetime.datetime.fromisoformat(iv['startedAt']);observed=datetime.datetime.fromisoformat(q['recordedAt'])
 ck(set(q['completedSeedReadAccountingBeforeRetry'])==set(folders.values()),'interrupted ledger folders differ')
 for key,folder in folders.items():
  rows=q['completedSeedReadAccountingBeforeRetry'][folder];ck(len(rows)==1,'interrupted completed reconstruction count differs');r=rows[0];rp=P(r['path']);ck(rp.parent==C/folder and pin(rp)==r,'interrupted ledger pin differs');v=load(rp);when=datetime.datetime.fromisoformat(v['completedAt']);ck(v['processId']==iv['childPid'] and start<=when<=observed,'interrupted ledger invocation/time differs');records[key]=r
 return {'preservation':actual,'invocation':q['originalInvocation'],'scanOutcome':'UNKNOWN_INTERRUPTED_NO_TERMINAL_RECEIPT','successfulScanClaim':False,'completedSeedReconstructions':records,'observedAt':q['recordedAt'],'startedAt':iv['startedAt'],'processId':iv['childPid'],'terminal':None,'report':None,'payloadArchiveOrSeedReads':0}
