#!/usr/bin/env python3
"""Bind exact initial five-field identities without opening selected payloads."""
from independent_cupra_common_v1 import *
def main():
 command('freeze');p=C/'FROZEN-CAPTURE-SCOPE.json';scope=load(p);records=[]
 for r in scope['files']:
  ident=identity(r['path']);ck(ident[:2]==[r['bytes'],r['mtimeNsAtFreeze']],'frozen identity differs');records.append({'path':r['path'],'identity':ident})
 ck(len(records)==len({r['path'] for r in records})==453,'selected count differs')
 out={'result':'PASS_EXACT_453_SELECTED_FILE_INITIAL_IDENTITY_BINDING','createdAt':now(),'frozenScope':pin(p),'identityFields':['size','mtimeNs','ctimeNs','inode','device'],'atimeExcluded':True,'metadataOnly':True,'payloadFilesOpened':0,'files':records};dump(C/'INDEPENDENT-CUPRA-INITIAL-IDENTITIES-v1.json',out);print(json.dumps({'result':out['result'],'files':453,'payloadFilesOpened':0}))
if __name__=='__main__':main()
