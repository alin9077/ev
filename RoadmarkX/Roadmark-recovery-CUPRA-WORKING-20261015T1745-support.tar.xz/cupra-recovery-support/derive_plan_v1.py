import pathlib,json
from capture_v1 import C,BASE,load,dump,pin
basepath=BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-KGM-WORKING-20261015.json'
assert pin(basepath)=={'bytes':3246441,'sha256':'09bcfeb302b31331d0d7ed12b18553f0cf71cf0fca4017b97cd53cbafe3edba4'}
base=load(basepath);scope=load(C/'FROZEN-CAPTURE-SCOPE.json');source=load(C/'source-package.json');delta=load(C/'proof-packages-v1.json')['archives']+[load(C/'support-package.json')];sc=load(C/'source-capture.json');pc=load(C/'proof-capture-v1.json');oldsource={r['path']:r for r in load(BASE/'source-capture.json')['files']};current={r['path']:r for r in sc['files']}
changed={n for n,r in current.items() if n not in oldsource or (r['originalBytes'],r['originalSHA256'])!=(oldsource[n]['originalBytes'],oldsource[n]['originalSHA256'])}
assert changed==set(scope['sourceChangedPaths']);assert set(oldsource)<=set(current);assert len(current)==scope['expectedSourceFiles']
assert len(base['archivesInRestoreOrder'])==135 and len(base['files'])==13380
ars=[];replaced=0
for a in base['archivesInRestoreOrder']:
 if a['group'].startswith('source-'):ars.append(source);replaced+=1
 else:ars.append({**a,'new':False})
assert replaced==1
ars+=delta
for i,a in enumerate(ars,1):a['restoreOrder']=i
old={f['path']:f for f in base['files']};merged={n:r for n,r in old.items() if not n.startswith('roadmark/')};fresh={}
for a in [source]+delta:
 for f in a['memberFiles']:
  assert f['path'] not in fresh;fresh[f['path']]=f;merged[f['path']]=f
for r in pc['files']:assert merged[r['path']]=={k:r[k] for k in ['path','bytes','sha256']}
assert (set(old)&set(fresh))-{n for n in old if n.startswith('roadmark/')}==set(scope['expectedNonSourceOverlay'])
r={'status':'PLANNED_PENDING_FRESH_PRIVACY_AND_INDEPENDENT_RESTORE','archivesInRestoreOrder':ars,'files':list(merged.values()),'newFiles':list(fresh.values()),'newArchives':[source]+delta,'source':source,'baseManifest':str(basepath),'baseManifestPin':pin(basepath),'fullSourceFiles':len(current),'sourceChangedPaths':sorted(changed),'baseArchivesReused':134,'archiveCount':len(ars),'logicalFiles':len(merged),'logicalBytes':sum(r['bytes'] for r in merged.values()),'freshFiles':len(fresh),'freshBytes':sum(r['bytes'] for r in fresh.values()),'scopeOriginalFiles':len(pc['files']),'workingResult':scope['workingResult'],'openGates':scope['openGates'],'sourceFullCloneCreated':False}
dump(C/'RESTORE-PLAN.json',r);dump(C/'ARCHIVE-PLAN.json',{'archives':[source]+delta});dump(C/'FRESH-ONLY-RESTORE-MANIFEST.json',{'archivesInRestoreOrder':[source]+delta,'files':list(fresh.values())});print(json.dumps({k:v for k,v in r.items() if k in ['archiveCount','logicalFiles','logicalBytes','freshFiles','freshBytes','fullSourceFiles','sourceChangedPaths','baseArchivesReused']}))
