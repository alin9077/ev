#!/usr/bin/env python3
"""Small identity helpers; no payload extraction, scanning or source embedding."""
import datetime
import hashlib
import json
import os
import pathlib
import stat

C = pathlib.Path(__file__).resolve().parent
BASE = C.parent / 'kgm-working-20261015T1530'
D = C / 'deliverables'
STEM = 'CUPRA-WORKING-20261015'
CHUNK = 65536
LIMIT = 268435456
DOCS = [D / ('Roadmark-RECOVERY-' + kind + '-' + STEM + suffix) for kind, suffix in
        [('INDEX', '.md'), ('MANIFEST', '.json'), ('VERIFICATION', '.json')]]
DOCS.append(D / 'Roadmark-CUPRA-M1-UPDATE-20261015.md')
ACTIVE = D / ('Roadmark-RECOVERY-ACTIVE-STATE-' + STEM + '.json')
BASE_MANIFEST = BASE / 'deliverables/Roadmark-RECOVERY-MANIFEST-KGM-WORKING-20261015.json'
BASE_TERMINAL = BASE / 'FINAL-KGM-UPLOAD-RECEIPTS.json'
RECOVERY = 'INDEPENDENT-CUPRA-RECOVERY-VERIFICATION-v1.json'
GATE = 'ALL-ARCHIVE-PRIVACY-GATE.json'
DEPENDENCY = 'INHERITED-DEPENDENCY-RECONSTRUCTION-v1.json'
COUNT_KEYS = ('archiveCount', 'logicalFiles', 'logicalBytes', 'freshFiles', 'freshBytes',
              'fullSourceFiles', 'baseArchivesReused')
INHERIT_KEYS = ('sourceSanitation', 'originalRawCaptureReplayCompatibility',
               'missingHistoricalCaptureProvenance', 'priorToyotaBrowserScreenshotExclusions',
               'sourcePackagingExclusions', 'historicalExclusions', 'lastPassedRecovery',
               'optionalReconstruction', 'partialOutputRetention', 'reusedVerifier',
               'cleanupCandidatesExcludedFromRestore', 'cleanupListLibraryFileId',
               'exactDuplicateProvenance')
DELIVERY_SCRIPTS = ('delivery_common_v1.py', 'build_documents_v1.py',
                    'independent_cupra_documents_v1.py', 'build_active_receipt_v1.py',
                    'finalize_upload_receipt_v1.py', 'preupload_gate_v1.py',
                    'scan_documents_v1.py')

def ck(value, message):
    if not value:
        raise AssertionError(message)

def load(path):
    return json.loads(pathlib.Path(path).read_text())

def dump(path, value):
    with pathlib.Path(path).open('x') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def pin(path):
    path = pathlib.Path(path)
    before = path.lstat()
    ck(stat.S_ISREG(before.st_mode) and not any(p.is_symlink() for p in path.parents),
       'not an ordinary unlinked file: ' + str(path))
    digest, size = hashlib.sha256(), 0
    with path.open('rb') as handle:
        while block := handle.read(CHUNK):
            digest.update(block)
            size += len(block)
    after = path.lstat()
    ck((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
       (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
       'file changed during pin: ' + str(path))
    ck(size == before.st_size, 'short file read')
    return {'bytes': size, 'sha256': digest.hexdigest()}

def check(path, expected):
    actual = pin(path)
    ck(actual == {key: expected[key] for key in ('bytes', 'sha256')}, 'pin differs: ' + str(path))
    return actual

def ref(path):
    path = pathlib.Path(path)
    return {'path': path.relative_to(C).as_posix() if path.is_relative_to(C) else str(path), **pin(path)}

def verify_base_snapshot():
    expected = {
        BASE_MANIFEST: {'bytes': 3246441, 'sha256': '09bcfeb302b31331d0d7ed12b18553f0cf71cf0fca4017b97cd53cbafe3edba4'},
        BASE_TERMINAL: {'bytes': 14335, 'sha256': '6f546a2ec326bc06377f29625bd2c9c3299373395ef7628d9688a29b72074fa0'},
        BASE / 'INDEPENDENT-KGM-TERMINAL-CLOSURE-v1.json': {'bytes': 9496, 'sha256': 'f8cad92d4f00de7768700503214f57b4ce98421abbbac00dc4e89bbc5b661657'}}
    for path, wanted in expected.items():
        check(path, wanted)
    manifest, terminal = load(BASE_MANIFEST), load(BASE_TERMINAL)
    ck(len(manifest['archivesInRestoreOrder']) == 135 and len(manifest['files']) == 13380 and
       manifest['workState']['fullProjectTypeScriptPassed'] is False and
       manifest['workState']['releaseReady'] is False, 'historical KGM status/counts differ')
    ck(load(BASE / 'INDEPENDENT-KGM-TERMINAL-CLOSURE-v1.json')['result'] == 'PASS_TERMINAL_RECOVERY_CLOSURE',
       'historical KGM terminal closure absent')
    ck(terminal['sourceLibraryFileId'] == manifest['source']['library_file_id'], 'historical KGM source identity differs')
    return {str(path.relative_to(BASE)): wanted for path, wanted in expected.items()}

def replay_metadata(name):
    inputs = load(C / 'INDEPENDENT-CUPRA-REPLAY-INPUTS-v1.json')
    selected = inputs['metadata'][name]
    path = pathlib.Path(selected['path'])
    ck(path.is_absolute() and path.is_relative_to(C), 'selected current metadata must be inside this checkpoint')
    check(path, selected)
    return path, load(path)

def json_pointer(value, path):
    ck(isinstance(path, str) and path.startswith('/'), 'invalid classification counter pointer')
    for part in path.split('/')[1:]:
        part = part.replace('~1', '/').replace('~0', '~')
        value = value[int(part)] if isinstance(value, list) else value[part]
    return value

def deepal_adapter():
    from require_privacy_contract_v1 import verified_contract
    contract = verified_contract()
    classification = load(contract['classification']['path'])
    approval = load(contract['approval']['path'])
    ck(approval['classificationPin'] == {key: contract['classification'][key] for key in ('bytes', 'sha256')} and approval['copyOnly'], 'copy-only approval differs')
    ck(classification['additiveInventory'] == contract['additiveInventory'] and approval['additiveInventoryPin'] ==
       {key: contract['additiveInventory'][key] for key in ('bytes', 'sha256')}, 'additive inventory identity differs')
    pointers = contract['classificationCounterPointers']
    ck(set(pointers) == {'deepalRuntimeValues', 'deepalRuntimeForms', 'deepalOriginalPayloadReadOperations'}, 'counter pointer set differs')
    counters = {key: json_pointer(classification, pointer) for key, pointer in pointers.items()}
    ck(counters == {'deepalRuntimeValues': 6, 'deepalRuntimeForms': 41, 'deepalOriginalPayloadReadOperations': 5}, 'inherited Deepal counter scope differs')
    expected_reads = [{'path': row['capturedPayloadPath'], 'pin': row['originalPin'], 'payloadReadOperations': 1,
                       'valueRanges': len(row['ranges'])} for row in classification['files']]
    ck(len(expected_reads) == counters['deepalOriginalPayloadReadOperations'] and len({row['path'] for row in expected_reads}) == len(expected_reads), 'Deepal exact read map differs')
    return contract, counters, expected_reads

POST_SEAL_SERIALIZATION = {'encoding': 'UTF-8', 'indent': 2, 'ensure_ascii': True, 'sort_keys': False,
                           'separators': [',', ': '], 'trailingNewline': True}
POST_SEAL_RESULTS = {RECOVERY: 'PASS', GATE: 'PASS',
                     'INDEPENDENT-CUPRA-REPLAY-INPUTS-v1.json': 'APPROVED_PINNED_FRESH_REPLAY_INPUTS'}

def reject_embedded_bodies(value):
    no_embedded_source(value)
    if isinstance(value, dict):
        ck(not ({'archivesInRestoreOrder', 'files'} <= set(value)), 'full prior manifest embedded')
        ck('postSealReceipts' not in value, 'nested post-seal receipt envelope')
        for key, item in value.items():
            ck(not (key.lower() in ('scripttext', 'sourcetext', 'body', 'content', 'stdout', 'stderr', 'log', 'traceback', 'text', 'code') and
                    isinstance(item, str) and item), 'script or log body embedded')
            reject_embedded_bodies(item)
    elif isinstance(value, list):
        for item in value:
            reject_embedded_bodies(item)
    elif isinstance(value, str):
        ck(len(value) < 8192 and not any(marker in value for marker in ('\ndef ', '\nclass ', '#!/usr/', '<script', '<html')),
           'source-like or oversized text body embedded')

def reserialize_receipt(record):
    reject_embedded_bodies(record)
    return (json.dumps(record, indent=2, ensure_ascii=True, sort_keys=False, separators=(',', ': '), allow_nan=False) + '\n').encode('utf-8')

def post_seal_receipts():
    rows = []
    for name, required_result in POST_SEAL_RESULTS.items():
        path = C / name
        original = path.read_bytes()
        record = json.loads(original)
        ck(record['result'] == required_result, 'data-only receipt result differs from exact filename allowlist')
        rebuilt = reserialize_receipt(record)
        ck(rebuilt == original, 'receipt does not follow declared exact serialization')
        rows.append({'filename': name, **pin(path), 'serialization': POST_SEAL_SERIALIZATION, 'record': record})
    return rows

def check_post_seal_receipts(rows):
    ck([row['filename'] for row in rows] == list(POST_SEAL_RESULTS), 'post-seal receipt set/order differs')
    for row in rows:
        ck(row['serialization'] == POST_SEAL_SERIALIZATION and row['record']['result'] == POST_SEAL_RESULTS[row['filename']],
           'receipt serialization or exact filename result differs')
        rebuilt = reserialize_receipt(row['record'])
        expected = {'bytes': len(rebuilt), 'sha256': hashlib.sha256(rebuilt).hexdigest()}
        ck(expected == {key: row[key] for key in ('bytes', 'sha256')} == pin(C / row['filename']) and
           rebuilt == (C / row['filename']).read_bytes(), 'reconstructed receipt bytes or pin differ')
    return [{'filename': row['filename'], 'bytes': row['bytes'], 'sha256': row['sha256']} for row in rows]

def safe_member(name):
    path = pathlib.PurePosixPath(name)
    ck(name and not path.is_absolute() and '..' not in path.parts and str(path) == name and '\\' not in name,
       'unsafe member path')

def file_map(rows):
    result = {}
    for row in rows:
        safe_member(row['path'])
        ck(row['path'] not in result, 'duplicate member')
        ck(isinstance(row['bytes'], int) and row['bytes'] >= 0 and len(row['sha256']) == 64, 'invalid pin')
        result[row['path']] = row
    return result

def native(phase, expected=None):
    request = load(C / ('library-' + phase + '-request.json'))['uploads']
    result = load(C / ('library-' + phase + '-results.json'))['results']
    witnesses = [json.loads(line) for line in (C / ('library-' + phase + '-verified.jsonl')).read_text().splitlines()]
    ck(len(request) == len(result) == len(witnesses), 'native phase lengths differ')
    rows = []
    for wanted, value, witness in zip(request, result, witnesses):
        path = pathlib.Path(wanted['local_path'])
        ck(value['status'] == 'succeeded' and value['local_metadata_applied'] and
           value['local_path'] == str(path) and value['file_name'] == path.name, 'native upload not verified')
        ck(witness['verified'] and witness['filename'] == path.name and
           witness['library_file_id'] == value['library_file_id'] and
           witness['version'] == value['current_version_number'], 'native witness differs')
        ck(os.getxattr(path, 'user.library-file-id').decode() == value['library_file_id'] and
           os.getxattr(path, 'user.library-file-version').decode() == str(value['current_version_number']),
           'local native identity differs')
        actual = {key: witness[key] for key in ('bytes', 'sha256')}
        if expected is None:
            ck(actual == pin(path), 'persisted document bytes differ')
        else:
            ck(path.name in expected and actual == expected[path.name] and
               path.stat().st_size == actual['bytes'], 'persisted archive pin differs')
        rows.append({'filename': path.name, 'library_file_id': value['library_file_id'],
                     'file_id': value['file_id'], 'version': value['current_version_number'], **actual})
    ck(len({row['filename'] for row in rows}) == len(rows) and
       len({row['library_file_id'] for row in rows}) == len(rows), 'duplicate native identity')
    if expected is not None:
        ck(set(expected) == {row['filename'] for row in rows}, 'native archive set differs')
    return rows

def final_archives(plan):
    expected = {row['filename']: {key: row[key] for key in ('bytes', 'sha256')} for row in plan['newArchives']}
    persisted = {row['filename']: row for row in native('archives', expected)}
    result = []
    for item in plan['archivesInRestoreOrder']:
        row = {key: value for key, value in item.items() if key not in ('file', 'memberFiles', 'allMembersVerified')}
        if row.get('new'):
            row.update({key: persisted[row['filename']][key] for key in ('library_file_id', 'file_id', 'version')})
        ck(row['library_file_id'] and row['file_id'] and isinstance(row['version'], int), 'archive native identity absent')
        result.append(row)
    ck([row['restoreOrder'] for row in result] == list(range(1, len(result) + 1)), 'restore order differs')
    ck(len(result) == plan['archiveCount'] and len({row['filename'] for row in result}) == len(result), 'archive count differs')
    return result

def no_embedded_source(value):
    if isinstance(value, dict):
        ck(not {'verificationSupportFiles', 'postSealCompactEvidence', 'scriptText', 'sourceText'} & set(value),
           'recursive evidence or executable text field')
        if 'filename' in value and 'text' in value:
            ck(not str(value['filename']).endswith(('.py', '.js', '.ts', '.sh')), 'executable text embedded')
        for child in value.values():
            no_embedded_source(child)
    elif isinstance(value, list):
        for child in value:
            no_embedded_source(child)

def seed_summary():
    summaries = {}
    for kind, directory in [('historical', 'seed-read-invocations'), ('audi', 'audi-seed-read-invocations')]:
        rows = []
        for path in sorted((C / directory).glob('*.json')):
            value = load(path)
            if kind == 'historical':
                ck(value['exactPinnedMembersReadAndVerified'] == 200 and value['historicalArchives'] == 21 and
                   value['noExtractedValuesPersisted'], 'historical seed receipt scope differs')
            else:
                ck(value['distinctValues'] == 6 and value['variantForms'] == 37 and
                   value['payloadReadOperations'] == 6 and value['uniqueOriginalFiles'] == 4 and
                   value['noValuesOrValueDigestsPersisted'], 'Audi seed receipt scope differs')
            rows.append({**ref(path), 'completedAt': value['completedAt'], 'processId': value['processId']})
        summaries[kind] = {'asOf': max((r['completedAt'] for r in rows), default=None),
                           'completedInvocations': len(rows), 'receiptReferences': rows,
                           'noExtractedValuesOrValueDigests': True}
        if kind == 'historical':
            summaries[kind].update(uniquePinnedMembers=200, uniqueHistoricalArchives=21,
                                   targetedPinnedMemberReads=200 * len(rows))
        else:
            summaries[kind].update(distinctValues=6, variantForms=37, uniqueOriginalFiles=4,
                                   payloadReadOperations=6 * len(rows))
    scope = load(C / 'INHERITED-LOCAL-SEED-READ-SCOPE.json')
    ck(scope['result'] == 'EXACT_UNCHANGED_SELECTOR_ACCOUNTING_SPECIFICATION' and len(scope['files']) == 48 and
       scope['payloadValueReadsPerSuccessfulInvocation'] == scope['streamingIntegrityReadsPerSuccessfulInvocation'] == 48,
       'inherited local seed accounting scope differs')
    count = summaries['historical']['completedInvocations']
    ck(count == summaries['audi']['completedInvocations'], 'incomplete paired seed ledgers')
    summaries['inheritedLocal'] = {'specification': ref(C / 'INHERITED-LOCAL-SEED-READ-SCOPE.json'),
                                  'completedInvocations': count, 'uniqueOriginalFiles': 48,
                                  'payloadValueReads': 48 * count, 'streamingIntegrityReads': 48 * count,
                                  'accountingMethod': 'Derived from reviewed selector control flow and paired seed completion ledgers; not separate per-file instrumentation',
                                  'noValuesOrValueDigestsPersisted': True}
    contract, counters, expected_reads = deepal_adapter()
    deepal_rows = []
    for path in sorted((C / 'deepal-seed-read-invocations').glob('*.json')):
        value = load(path)
        ck(value['classificationReceiptPin'] == {key: contract['classification'][key] for key in ('bytes', 'sha256')} and
           value['distinctValues'] == counters['deepalRuntimeValues'] and value['variantForms'] == counters['deepalRuntimeForms'] and
           value['payloadReadOperations'] == counters['deepalOriginalPayloadReadOperations'] and value['reads'] == expected_reads,
           'Deepal seed receipt identity/count/read scope differs')
        ck(value['noValuesOrValueDigestsPersisted'] and not value['rawDeepalApiManagerOriginalRead'] and
           value['URLComponentRepresentationIncludedByUnchangedVariantsFunction'] and not value['generalArbitraryDecodedCoverageClaimed'],
           'Deepal raw-body or decoding boundary differs')
        deepal_rows.append({**ref(path), 'completedAt': value['completedAt'], 'processId': value['processId']})
    summaries['deepal'] = {'asOf': max((row['completedAt'] for row in deepal_rows), default=None),
                           'completedInvocations': len(deepal_rows), 'receiptReferences': deepal_rows,
                           'classification': contract['classification'], 'adapterContract': ref(C / 'CUPRA-PRIVACY-ADAPTER-CONTRACT.json'),
                           'distinctValues': counters['deepalRuntimeValues'], 'variantForms': counters['deepalRuntimeForms'],
                           'uniqueOriginalFiles': len(expected_reads),
                           'payloadReadOperations': counters['deepalOriginalPayloadReadOperations'] * len(deepal_rows),
                           'noValuesOrValueDigestsPersisted': True, 'rawDeepalApiManagerOriginalRead': False,
                           'historicalPreAdapterScansCountedInPriorReceipts': True}
    return summaries

def check_seed_summary(value, complete=False):
    actual = seed_summary()
    for kind in ('historical', 'audi'):
        selected, current = value[kind], actual[kind]
        refs = selected['receiptReferences']
        cutoff = selected['asOf']
        wanted = [row for row in current['receiptReferences'] if cutoff and row['completedAt'] <= cutoff]
        ck(refs == wanted and selected['completedInvocations'] == len(refs), 'seed as-of scope differs')
        for key, item in selected.items():
            if key not in ('asOf', 'completedInvocations', 'receiptReferences', 'targetedPinnedMemberReads', 'payloadReadOperations'):
                ck(current[key] == item, 'seed fixed scope differs')
        total = 'targetedPinnedMemberReads' if kind == 'historical' else 'payloadReadOperations'
        ck(selected[total] == len(refs) * (200 if kind == 'historical' else 6), 'seed total differs')
        if complete:
            ck(selected == current, 'terminal omits a seed invocation')
    inherited = value['inheritedLocal']
    count = value['historical']['completedInvocations']
    ck(count == value['audi']['completedInvocations'] and inherited ==
       {**actual['inheritedLocal'], 'completedInvocations': count, 'payloadValueReads': 48 * count,
        'streamingIntegrityReads': 48 * count}, 'inherited local seed totals differ')
    selected, current = value['deepal'], actual['deepal']
    refs = selected['receiptReferences']
    cutoff = selected['asOf']
    wanted = [row for row in current['receiptReferences'] if cutoff and row['completedAt'] <= cutoff]
    expected = {**current, 'asOf': cutoff, 'completedInvocations': len(refs), 'receiptReferences': wanted,
                'payloadReadOperations': current['uniqueOriginalFiles'] * len(refs)}
    ck(refs == wanted and selected == expected, 'Deepal seed as-of boundary or accounting differs')
    if complete:
        ck(value == actual, 'terminal seed account is incomplete')
    return {kind: {key: item for key, item in data.items() if key != 'receiptReferences'} for kind, data in value.items()}

def privacy(name, paths):
    value = load(C / name)
    ck(value['result'] == 'PASS' and not value['findings'] and not value['errors'] and
       value['currentCompletePatternScan'] and value['allKnownValueForms'], 'document privacy gate failed')
    ck(value['audiRuntimeValues'] == 6 and value['audiRuntimeForms'] == 37 and
       value['audiOriginalPayloadReadOperations'] == 6, 'current residual coverage differs')
    contract, counters, unused = deepal_adapter()
    ck(all(value[key] == number for key, number in counters.items()) and
       value['deepalAdapterContract'] == ref(C / 'CUPRA-PRIVACY-ADAPTER-CONTRACT.json') and
       value['privacyEngine'] == contract['engine'], 'inherited Deepal document residual coverage differs')
    seen = {}
    for row in value['files']:
        ck(row['filename'] not in seen and row['exactValueMatches'] == row['primaryCandidates'] == row['runtimeCandidates'] == 0,
           'duplicate privacy member or unresolved finding')
        ck(row['exactMatchesObserved'] == row['classifiedPublicLexicalCollisions'], 'privacy accounting differs')
        seen[row['filename']] = {key: row[key] for key in ('bytes', 'sha256')}
    ck(seen == {path.name: pin(path) for path in paths}, 'privacy input set or pins differ')
    ck(value['rawDeepalOriginalReadRecoveryRefetchForbidden'] and value['rawKgmOriginalReadRecoveryRefetchForbidden'] and
       value['rawCupraOriginalReadRecoveryRefetchForbidden'], 'raw-original recovery restriction absent from document scan')
    return ref(C / name)


AUTHOR_INVENTORY = pathlib.Path('/tmp/cupra-packet/final-freeze-v1/inventory.json')
AUTHOR_ACCEPTANCE = pathlib.Path('/tmp/cupra-review/final-retention-v1-accepted.json')
AUTHOR_INVENTORY_PIN = {'bytes': 147107, 'sha256': '798f05ab19b2632f0ee091305430c16105e59ae7df3fa316766feb2d54f3ee55'}
AUTHOR_ACCEPTANCE_PIN = {'bytes': 4908, 'sha256': '2b024c76cfa72634b74be4ea0d49f966e42a6f185ae2161b506d2a64b32d6f7f'}
CUPRA_SUMMARY_PIN = {'bytes': 5684, 'sha256': 'fd32ecf44f017010a6de5e6ba595a04be2e3aee096eada2b15d5e74ffe73cb0c'}

def author_inputs():
    check(AUTHOR_INVENTORY, AUTHOR_INVENTORY_PIN)
    check(AUTHOR_ACCEPTANCE, AUTHOR_ACCEPTANCE_PIN)
    inventory, acceptance = load(AUTHOR_INVENTORY), load(AUTHOR_ACCEPTANCE)
    ck(acceptance['status'] == 'accepted' and acceptance['inventory'] == {'path': str(AUTHOR_INVENTORY), **AUTHOR_INVENTORY_PIN}, 'author acceptance does not bind final inventory')
    metadata = acceptance['metadataInventoryVerified']
    ck(inventory['noFurtherPayloadEdits'] and inventory['totalFiles'] == metadata['files'] == 450 and
       inventory['regularFileBytes'] == metadata['bytes'] == 38201419 and inventory['symlinkCount'] == metadata['symlinks'] == 0,
       'author frozen scope differs')
    ck(inventory['sourceAndStatusAfterPins'] == acceptance['liveTargetPins'] and len(acceptance['liveTargetPins']) == 7 and
       acceptance['allSevenLiveTargetsHashAndByteVerified'], 'author seven-target pins differ')
    history = acceptance['retentionHistory']
    attempts = inventory['retainedFailures']['attempts']
    ck(len(attempts) == 2 and history['twoActualKgmCompilerFailuresPreservedByPinnedExistingChain'] and
       all(row['cause'] == 'unknown' and row['freshCacheAbsentAtPreparation'] and row['fullProjectTypecheckPassed'] is False
           and row['exitCode'] == -9 and row['rawWaitStatus'] == 9 for row in attempts), 'inherited compiler failure cause/cache boundary differs')
    ck(inventory['currentValidation'] == acceptance['currentValidation'] and
       inventory['currentValidation']['fullProjectTypecheckPassed'] is False and inventory['currentValidation']['releaseReady'] is False and
       inventory['currentValidation']['compilerRetriesAuthorized'] is False and inventory['currentValidation']['factualCoverageOnly'] is True and
       inventory['currentValidation']['scopedTests'] == 151 and inventory['currentValidation']['normalReportAndExhaustiveComparisonPassed'] is True,
       'current factual-only validation exception differs')
    ck((inventory['acceptedSourcePins'], inventory['heldOnlySourcePins'], inventory['allowlistedSourceUnion']) == (86, 11, 97) and
       history['heldSourceV2Preserved'] and history['mutableSourceV1OriginalReviewedBytesUnavailable'] and
       history['noReconstructionOfMissingV1BytesClaimed'] and inventory['mutableV1Limitation'] and
       len([row for row in inventory['excluded'] if row.get('category') == 'excluded_mutable_unversioned_preparation']) == 6,
       'held/missing source preparation boundary differs')
    ck(acceptance['recoveryBoundaries']['noCompilerRetryAuthorized'] and
       not acceptance['recoveryBoundaries']['rawRuntimeCredentialSessionRecoveryAuthorized'], 'recovery permission boundary differs')
    return inventory, acceptance

def dependency_summary(dependency):
    ck(dependency['count'] == len(dependency['dependencies']) and dependency['count'] >= 164 and
       dependency['originalExpectedPathsAndHashesUnchanged'], 'dependency count or original expected-pin boundary differs')
    canonical = hashlib.sha256(json.dumps(dependency['dependencies'], sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    ck(canonical == dependency['dependenciesCanonicalSha256'], 'dependency mapping canonical hash differs')
    return {'receipt': ref(C / DEPENDENCY), 'count': dependency['count'],
            'relocatedMemberPointers': dependency['relocatedMemberPointers'], 'newRecords': dependency['newRecords']}

def saving_announcement():
    value = load(C / 'SAVING-ANNOUNCEMENT.json')
    ck(value['messageId'] == 'Sentinel_208f961a10308191a71bab609a35c9c9' and
       value['sentAt'] == '2026-10-15T17:46:16.619001Z', 'saving announcement identity differs')
    return ref(C / 'SAVING-ANNOUNCEMENT.json')


def support_privacy_scope(gate, recovery):
    archive_rows = [row for row in gate['archives'] if row['archive'].endswith('-support.tar.xz')]
    ck(len(archive_rows) == 1, 'support privacy receipt missing or duplicated')
    support_row = archive_rows[0]
    header_count = gate['classifiedExactCodeHeaderCandidates']
    template_count = gate['classifiedExactTemplateRuntimeCandidates']
    ck(template_count == 0 and support_row['classifiedExactCodeHeaderCandidates'] == header_count and
       all(row['classifiedExactCodeHeaderCandidates'] == row['classifiedExactTemplateRuntimeCandidates'] == 0
           for row in gate['archives'] if row is not support_row), 'classification escaped support-only scope')
    report_path = pathlib.Path(support_row['report'])
    ck(report_path.parent == C, 'support scan report is outside current checkpoint')
    check(report_path, support_row['reportPin'])
    report = load(report_path)
    ck(report['status'] == 'clean' and not any(report[key] for key in
       ('exactValueMatches', 'primaryHeaderCandidates', 'unclassifiedRuntimeCandidates', 'errors',
        'classifiedExactTemplateRuntimeCandidates')), 'support report has unresolved findings')
    if header_count == 0:
        ck(not report['classifiedExactCodeHeaderCandidates'] and recovery['privacy']['exactPinnedCodeSyntaxClassifications'] == 0 and
           recovery['privacy']['exactPinnedTemplateSyntaxClassifications'] == 0, 'unexpected clean-support classifications')
        return {'exactApprovedSyntaxCandidates': 0, 'unresolvedCandidates': 0, 'scanReport': ref(report_path),
                'scope': 'No support syntax classification used', 'documentScannerUnchanged': True,
                'payloadRedactions': 0, 'fileExtensionExemption': False}
    contract_path = C / 'CUPRA-SUPPORT-PRIVACY-CONTRACT-v1.json'
    contract = load(contract_path)
    ck(contract['result'] == 'APPROVED_CUPRA_SUPPORT_PRIVACY_ADAPTER' and contract['supportArchiveOnly'] and
       contract['noDetectorOrKnownValueSearchChanges'] and contract['exactApprovedCandidates'] == header_count,
       'current CUPRA support-only adapter not approved')
    fields = ('supportEngine', 'supportSyntaxHandler', 'supportSyntaxApproval', 'classification', 'baseEngine', 'independentReview')
    for key in fields:
        location = pathlib.Path(contract[key]['path'])
        ck(location.parent == C, 'support adapter dependency is not current CUPRA: ' + key)
        check(location, contract[key])
    adapter, unused_counters, unused_reads = deepal_adapter()
    ck(contract['baseEngine'] == adapter['engine'], 'support hook changed document/archive base scanner')
    review = load(contract['independentReview']['path'])
    ck(review['result'] == 'PASS_EXACT_SUPPORT_ONLY_ADAPTER_AND_FAIL_CLOSED_TESTS' and
       review['exactCandidates'] == header_count and review['testCount'] == len(review['tests']) and review['testCount'] > 0 and
       all(row['passed'] is True for row in review['tests']) and
       all(review[key] == contract[key] for key in fields if key != 'independentReview'), 'current support review differs')
    approval, classification = load(contract['supportSyntaxApproval']['path']), load(contract['classification']['path'])
    classification_pin = {key: contract['classification'][key] for key in ('bytes', 'sha256')}
    ck(approval['result'] == 'APPROVED_EXACT_SYNTAX_CLASSIFICATION' and approval['classificationPin'] == classification_pin and
       approval['exactCandidates'] == header_count and approval['detectorsAndValueSearchesUnchanged'] and
       approval['rawFindingCountsRetained'] and approval['payloadRedactions'] == 0, 'current support syntax approval differs')
    ck(classification['result'] == 'INDEPENDENT_BENIGN_SYNTAX_PROPOSAL_REQUIRES_ROOT_APPROVAL' and
       classification['primaryCandidates'] == header_count and classification['rawRuntimeCandidates'] == 0 and
       classification['candidateMultisetMustMatchExactly'] and classification['wholeFilePinRequired'] and
       classification['allUnexpectedCandidatesBlock'] and classification['noDetectorChanges'] and classification['noPayloadEdits'],
       'current support classification boundary differs')
    rows = classification['exactSupportCodeClassifications']
    ck(len(rows) == header_count and all(row['member'].startswith('cupra-recovery-support/') and row['astValid'] and
       row['isHeaderValueOrCredential'] is False and row['fileExtensionExemption'] is False and
       row['payloadChangeProposed'] is False for row in rows), 'support syntax member/scope differs')
    member_map = file_map(report['members'])
    ck(all(row['filePin'] == {key: member_map[row['member']][key] for key in ('bytes', 'sha256')} for row in rows),
       'whole-file support pins differ from scanned members')
    expected = [{'member': row['member'], 'filePin': row['filePin'],
                 'finding': {key: value for key, value in row['exactFinding'].items() if key != 'member'},
                 'classification': row['classification']} for row in rows]
    canonical = lambda items: sorted(json.dumps(row, sort_keys=True, separators=(',', ':')) for row in items)
    ck(len(set(canonical(expected))) == header_count and canonical(report['classifiedExactCodeHeaderCandidates']) == canonical(expected),
       'missing, duplicate or unexpected support syntax classifications')
    ck(recovery['privacy']['exactPinnedCodeSyntaxClassifications'] == header_count and
       recovery['privacy']['exactPinnedTemplateSyntaxClassifications'] == 0 and
       recovery['inputPins']['supportPrivacyContract'] == {'path': str(contract_path), **pin(contract_path)},
       'fresh replay did not bind exact current support adapter')
    return {'contract': ref(contract_path), **{key: contract[key] for key in fields}, 'scanReport': ref(report_path),
            'exactApprovedSyntaxCandidates': header_count, 'unresolvedCandidates': 0,
            'scope': 'Only independently reviewed and explicitly approved AST-bound candidates in exact current CUPRA support bytes',
            'rawFindingsAndCountsRetained': True, 'payloadRedactions': 0, 'documentScannerUnchanged': True,
            'fileExtensionExemption': False, 'unexpectedMissingOrDuplicateFindingsBlock': True}


def source_proof_transformation_scope(sanitation):
    approvals_path = C / 'PROSE-KEY-RENAME-APPROVALS.json'
    approvals = load(approvals_path)
    ck(sanitation['independentClassification'] == pin(approvals_path) and approvals['approvalScope'] and
       sanitation['originalExpectedPinsUnchanged'] is True and sanitation['exactValueAndOutsideKeyBytesUnchanged'] is True,
       'copy-only proof sanitation lacks exact approval binding or unchanged-byte scope')
    files = sanitation['files']
    ck(sanitation['locationCount'] == len(files) == len(approvals['files']), 'copy-only proof rename count differs')
    approved = {row['restorePath']: row for row in approvals['files']}
    ck(len(approved) == len(files), 'duplicate proof rename approval')
    for row in files:
        safe_member(row['path'])
        ck(row['path'].startswith(('cupra-packet/', 'cupra-review/', 'cupra-research/')) and
           row['path'] in approved, 'source or unapproved payload transformation')
        item = approved[row['path']]
        ck(all(row[key] == item[key] for key in ('bytes', 'sha256', 'originalBytes', 'originalSHA256')) and
           row['sha256'] != row['originalSHA256'] and
           item['oldPointer'] == '/authorization' and item['newPointer'] == '/approvalScope' and
           row['metadataKeyRename'] == {'oldPointer': '/authorization', 'newPointer': '/approvalScope',
                                      'unchangedValueAndOtherBytes': True},
           'proof transformation exceeds exact approved root prose-key rename')
    ck(sanitation['result'] == ('EXACT_REVIEWED_PROSE_KEYS_ONLY' if files else 'NO_NEW_TRANSFORMATIONS'),
       'unexpected source/proof transformation class requires independent delivery-adapter review')
    return {'sourceTransformations': 0, 'proofMetadataKeyRenames': len(files),
            'approval': ref(approvals_path), 'originalsAndExpectedPinsUnchanged': True,
            'valueAndOutsideKeyBytesUnchanged': True,
            'restoreQualification': sanitation['originalReplayLimitation']}


def generated_support_copy(support_members, sanitation):
    transformation = source_proof_transformation_scope(sanitation)
    members = file_map(support_members)
    ck('cupra-recovery-support/CUPRA-METADATA-INVENTORY-PROPOSAL-v1.json' not in members,
       'large metadata proposal must stay local and excluded from compact support')
    ck(not (C / 'PROPOSAL-SUPPORT-COPY-MAPPING-v1.json').exists(),
       'unexpected generated-support transformation requires independent delivery-adapter review')
    return {'sourceOrProofTransformations': transformation['proofMetadataKeyRenames'],
            'sourceProofTransformationScope': transformation, 'generatedSupportMetadataKeyRenames': 0,
            'originalProposalExcludedFromSupport': True, 'originalLeftUnchangedLocally': True,
            'scope': 'Current generated recovery-support metadata uses approvalScope directly; only separately reviewed exact proof prose-key copies may differ from original bytes',
            'inheritedMapping': {'baseManifest': {'path': str(BASE_MANIFEST), **pin(BASE_MANIFEST)},
                                 'jsonPointer': '/generatedSupportMetadataCopy'},
            'restoreQualification': 'Inherited generated support copies and any approved current proof copies have distinct hashes and cannot satisfy their original expected whole-file pins'}


def application_scope(recovery, contract):
    application = recovery['application']
    selected_path, selected_contract = replay_metadata('application')
    ck(selected_path == C / 'APPLICATION-ASSERTION-CONTRACT.json' and selected_contract == contract,
       'application contract differs from pinned replay metadata')
    ck(application['assertionCount'] == len(contract['assertions']) > 0 and
       application['freshArchiveAssertions'] + application['exactInheritedAssertions'] == application['assertionCount'] and
       application['mandatoryRetainedPins'] == len(contract['retainedPins']) > 0 and
       recovery['overlay']['inheritedPayloadReadsByIndependentVerifier'] == 0, 'application proof qualification differs')
    ck(contract['summary']['fullProjectTypeScriptPassed'] is False and contract['summary']['releaseReady'] is False,
       'application proof falsely closes current TypeScript or release gate')
    result = {'totalAssertions': application['assertionCount'], 'freshArchiveAssertions': application['freshArchiveAssertions'],
              'exactInheritedAssertions': application['exactInheritedAssertions'], 'mandatoryRetainedPins': application['mandatoryRetainedPins'],
              'inheritedPayloadReadsByIndependentVerifier': 0,
              'qualification': 'Fresh CUPRA factual evidence and exactly identified inherited KGM failure evidence only; no current full-project TypeScript, visual, mobile, build, full-suite or release pass is implied'}

    for key in ('inheritedAssertionContract', 'inheritedAssertionReplay'):
        if application['exactInheritedAssertions']:
            item = application[key]
            location = pathlib.Path(item['path'])
            ck(location.parent in (BASE, BASE.parent / 'deepal-working-20261015T1110'), 'inherited assertion evidence outside accepted chain')
            check(location, item)
            if key == 'inheritedAssertionReplay':
                ck(load(location)['result'] == 'PASS', 'inherited assertion replay did not pass')
            result[key] = item
    return result


def bind_delivery_scripts():
    package = load(C / 'support-package.json')
    members = file_map(package['memberFiles'])
    reused = load(C / 'SUPPORT-REUSE-MAPPING.json')['files']
    base_members = file_map(load(BASE_MANIFEST)['files'])
    bindings = []
    for name in DELIVERY_SCRIPTS:
        path = C / name
        direct = 'cupra-recovery-support/' + name
        candidates = [row for row in reused if row['originalPath'] == str(path)]
        ck(not (direct in members and candidates) and len(candidates) <= 1, 'duplicate support script identity')
        if direct in members:
            member, expected, kind = direct, members[direct], 'exact-new-unique-member'
        else:
            ck(len(candidates) == 1, 'support script absent from unique archive or exact reuse map: ' + name)
            record = candidates[0]
            member = record['retainedMember']
            expected = members.get(member, base_members.get(member))
            ck(expected is not None and {key: expected[key] for key in ('bytes', 'sha256')} ==
               {key: record[key] for key in ('bytes', 'sha256')}, 'support reused script pin differs')
            kind = record['kind']
        check(path, expected)
        bindings.append({'filename': name, 'member': member, **pin(path), 'kind': kind})
    ck(len({(row['bytes'], row['sha256']) for row in members.values()}) == len(members),
       'support package contains duplicate member bytes')
    return {'archive': package['filename'], 'scripts': len(DELIVERY_SCRIPTS), 'bindings': bindings,
            'noExecutableSourceTextEmbedded': True}
