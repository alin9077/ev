#!/usr/bin/env python3
"""Copy four exact inherited no-value metadata records, never seed payloads."""
from capture_v1 import *
PINS={
 'SEED-PROVENANCE.json':{'bytes':56058,'sha256':'a46652dae5a4d8b21cc49009e56b7ed5b0c0c92f1d3f8a1fc87186590e4e73dc'},
 'INHERITED-LOCAL-SEED-READ-SCOPE.json':{'bytes':19206,'sha256':'ec7ca6740a680ec669b8b0b79cdc49d278863ec3c33216c25e6977df8162ea17'},
 'TARGETED-SEED-READ-DEPENDENCY.json':{'bytes':675,'sha256':'6e1960053fec6fbc467cad08f32db01a80f3dce222616c7eafe78188ae1acf51'},
 'OFFICIAL-HELPER-INTEGRITY.json':{'bytes':1132,'sha256':'70e44e15a5dddae9c1b5727bcb565217f671bff622606e76de43eed2989f8e04'}}
for name,expected in PINS.items():
 original=BASE/name;got,before=check(original,expected);b=original.read_bytes();assert identity(original)==before and {'bytes':len(b),'sha256':sha(b)}==got
 with (C/name).open('xb') as f:f.write(b)
 check(C/name,expected)
prior=BASE/'APPROVED-INHERITED-SEED-SCOPE.json';expected={'bytes':670,'sha256':'d41ac4d42faeb6c4ca505658c25772265e5601799a85a825433f0b1685c6d686'};check(prior,expected)
dump(C/'APPROVED-INHERITED-SEED-SCOPE.json',{'status':'ROOT_APPROVED_UNCHANGED_KGM_SEED_SCOPE','priorScope':{'path':str(prior),**expected},'historicalPinnedMembers':200,'historicalArchives':21,'localSelectors':48,'audiPayloadReadOperations':6,'deepalCopiedCaptureSources':5,'inMemoryOnly':True,'actualRepeatedReadAccounting':True,'broadBaseScanOrClone':False,'rawExcludedPayloadReadRecoveryRefetch':False,'approvalScope':'Parent confirmed unchanged inherited in-memory seed scope for the frozen CUPRA working backup only'})
dump(C/'PROSE-KEY-RENAME-APPROVALS.json',{'files':[],'approvalScope':'No new source or proof key renames approved; unexpected sensitive-field candidates block capture'})
print(json.dumps({'exactMetadataCopies':len(PINS),'seedPayloadReads':0}))
