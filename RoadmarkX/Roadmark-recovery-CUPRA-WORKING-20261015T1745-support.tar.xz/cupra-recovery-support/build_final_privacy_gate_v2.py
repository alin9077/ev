"""Aggregate exact scan reports only after a reviewed engine contract is supplied."""
from capture_v1 import *
from verify_interrupted_scan_metadata_v1 import verify as verify_interrupted
interrupted=verify_interrupted()
assert len(sys.argv)==2,'Supply the independently reviewed exact privacy gate contract JSON'
contractPath=P(sys.argv[1]);assert contractPath.is_absolute() and contractPath.parent==C
contract=load(contractPath)
assert contract['status']=='REVIEWED_EXACT_PRIVACY_GATE_CONTRACT' and contract['approvalScope']
engines={}
for key in ['sourceProofEngine','supportEngine']:
 rec=contract[key];p=P(rec['path']);assert p.parent==C and p.suffix=='.py';check(p,rec);engines[key]=p
ars=load(C/'ARCHIVE-PLAN.json')['archives'];initial=load(C/'ARCHIVE-PLAN-initial.json')['archives'];assert [{k:v for k,v in a.items() if k!='restoreOrder'} for a in ars[:-1]]==initial and len(ars)==len(initial)+1
rows=[];allmembers={};reports=[]
for i,a in enumerate(ars,1):
 stem='scan-fresh-01-retry1' if i==1 else f'scan-fresh-{i:02d}';report=C/(stem+'.json');metric=C/(stem+'.resources.json');q=load(report);m=load(metric)
 plan=C/('ARCHIVE-PLAN-initial.json' if i<=len(initial) else 'ARCHIVE-PLAN.json')
 engine=engines['sourceProofEngine' if i<=len(initial) else 'supportEngine']
 assert m['command']==['python3',str(engine),a['file'],str(report),str(plan)]
 assert m['addressSpaceLimitBytes']==268435456 and not m['timedOut'] and m['exitCode']==0
 assert q['status']=='clean' and q['archivePin']=={k:a[k] for k in ('bytes','sha256')}
 assert q['chunkBytes']==65536 and q['currentByteSearchForEveryMember']
 assert not any(q[k] for k in ('exactValueMatches','primaryHeaderCandidates','unclassifiedRuntimeCandidates','errors'))
 got={r['path']:{k:r[k] for k in ('path','bytes','sha256')} for r in q['members']};want={r['path']:r for r in a['memberFiles']}
 assert got==want and len(got)==len(q['members'])==q['regularFilesScanned']
 assert sum(r['bytes'] for r in got.values())==q['bytesScanned'] and not(set(allmembers)&set(got));allmembers.update(got);reports.append(q)
 rows.append({'archive':a['filename'],'report':str(report),'reportPin':pin(report),'terminalPath':str(metric),'terminalPin':pin(metric),'terminal':m,'members':len(got),'bytes':q['bytesScanned'],'cachedPatternMembers':sum(r['patternVerdict']=='exact-prior-source-cache' for r in q['members']),'classifiedPublicLexicalCollisions':q['classifiedPublicLexicalCollisions'],'classifiedExactCodeHeaderCandidates':len(q['classifiedExactCodeHeaderCandidates']),'classifiedExactTemplateRuntimeCandidates':len(q['classifiedExactTemplateRuntimeCandidates']),'rawScannerStatus':q['status']})
assert allmembers=={r['path']:r for r in load(C/'FRESH-ONLY-RESTORE-MANIFEST.json')['files']}
gate={'result':'PASS','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archives':rows,'freshMembers':len(allmembers),'freshBytes':sum(r['bytes'] for r in allmembers.values()),'currentKnownValuesAcrossAllMembers':True,'exactCachedPatternVerdictsOnly':True,'classifiedPublicLexicalCollisions':sum(r['classifiedPublicLexicalCollisions'] for r in rows),'classifiedExactCodeHeaderCandidates':sum(r['classifiedExactCodeHeaderCandidates'] for r in rows),'classifiedExactTemplateRuntimeCandidates':sum(r['classifiedExactTemplateRuntimeCandidates'] for r in rows),'unclassifiedFindings':0,'errors':0,'rawScannerResultsModified':False,'preservedInitialPlan':pin(C/'ARCHIVE-PLAN-initial.json'),'initialPlan':pin(C/'ARCHIVE-PLAN-initial.json'),'finalPlan':pin(C/'ARCHIVE-PLAN.json'),'contract':{'path':str(contractPath),**pin(contractPath)},'limitations':'Complete specified known-value and unchanged pattern scans; no universal secret-free guarantee, decryption, or recursive arbitrary-format decoding.'}
required=['historicalValues','historicalForms','mercedesValues','mercedesForms','leapmotorCookieAndHeaderValues','leapmotorCookieForms','mazdaCookieAndHeaderValues','mazdaCookieForms','mazdaPublicBareValues','mazdaPublicBareForms','mazdaFormTokenValues','mazdaFormTokenForms','audiRuntimeValues','audiRuntimeForms','deepalRuntimeValues','deepalRuntimeForms','deepalOriginalPayloadReadOperations']
keys=required+contract.get('additionalUnchangedCounterKeys',[]);assert len(keys)==len(set(keys))
for k in keys:
 gate[k]=reports[0][k];assert all(q[k]==gate[k] for q in reports)
gate['preservedInterruptedAttempts']=[interrupted];dump(C/'ALL-ARCHIVE-PRIVACY-GATE.json',gate);print(json.dumps({'result':'PASS','archives':len(ars),'freshMembers':len(allmembers)}))
