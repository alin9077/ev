#!/usr/bin/env python3
"""Build and independently validate an exact compact support allowlist."""
import ast
from independent_cupra_common_v1 import *
EXCLUDED={'CUPRA-METADATA-INVENTORY-PROPOSAL-v1.json','SUPPORT-SELECTION-PROPOSAL-v1.json','SUPPORT-SELECTION-v1.json','SUPPORT-MEMBER-INVENTORY.json','SUPPORT-REUSE-MAPPING.json','support-package.json','ARCHIVE-PLAN.json','RESTORE-PLAN.json','FRESH-ONLY-RESTORE-MANIFEST.json','ALL-ARCHIVE-PRIVACY-GATE.json','INDEPENDENT-CUPRA-REPLAY-INPUTS-v1.json','INDEPENDENT-CUPRA-RECOVERY-VERIFICATION-v1.json','INDEPENDENT-NEW-MEMBER-REPLAY-MANIFEST-v1.json'}
FOLDERS={'phase-logs','run-logs','seed-read-invocations','audi-seed-read-invocations','deepal-seed-read-invocations'}
def propose():
 paths=set()
 for p in C.iterdir():
  if p.name in EXCLUDED or p.name.startswith('library-') or p.name.startswith('NATIVE-'):continue
  if p.is_file():ck(p.suffix in {'.py','.json','.txt','.md','.log','.err','.patch','.diff'},'unexpected support type');paths.add(p)
 for name in FOLDERS:
  folder=C/name
  if folder.exists():
   for p in folder.iterdir():ck(p.is_file() and not p.is_symlink(),'unexpected support folder member');paths.add(p)
 records=[]
 for p in sorted(paths):records.append({**pin(p),'localRelativePath':p.relative_to(C).as_posix(),'identity':identity(p)})
 ck({p.name for p in C.glob('*.py')}<={r['localRelativePath'] for r in records},'script omitted')
 out={'status':'PENDING_INDEPENDENT_EXACT_SUPPORT_ALLOWLIST_REVIEW','createdAt':now(),'files':records,'excludedDirectNames':sorted(EXCLUDED),'excludedFolders':['selected-source-changes','selected-proof-sanitized-v1','selected-proof-sanitized-v2','post-seal-run','deliverables'],'scope':'Only checkpoint support and closed logs; exact byte deduplication by sealer, no source/evidence trees or archive reads','approvalScope':'Root-authorized compact support with exact prior byte reuse; no recursively embedded executable text','selectionBuilder':pin(__file__),'noDeletedOrModifiedInputs':True,'rawPreliminaryProposalExcluded':True};dump(C/'SUPPORT-SELECTION-PROPOSAL-v1.json',out);print(json.dumps({'result':out['status'],'files':len(records),'bytes':sum(r['bytes'] for r in records)}))
def review():
 pp=C/'SUPPORT-SELECTION-PROPOSAL-v1.json';proposal=load(pp);ck(proposal['status']=='PENDING_INDEPENDENT_EXACT_SUPPORT_ALLOWLIST_REVIEW' and proposal['rawPreliminaryProposalExcluded'],'proposal differs');selected={}
 for r in proposal['files']:
  p=P(r['path']);ck(p.is_absolute() and p.is_relative_to(C),'outside checkpoint');n=p.relative_to(C).as_posix();ck(n==r['localRelativePath'] and n not in selected and n not in EXCLUDED and not n.startswith('library-'),'invalid support member');ck(len(P(n).parts)==1 or len(P(n).parts)==2 and P(n).parts[0] in FOLDERS,'unapproved support folder');check(p,r);ck(identity(p)==r['identity'],'support identity differs');selected[n]={'path':str(p),'localRelativePath':n,**sh(r)}
 scripts={p.name for p in C.glob('*.py')};ck(scripts<={*selected},'script omitted')
 for n in scripts:ast.parse((C/n).read_bytes())
 required={'APPROVED-CUPRA-CAPTURE-SCOPE.json','IMAGE-PROVENANCE.json','SAVING-ANNOUNCEMENT.json','ROOT-CAPTURE-GRANT.json','APPLICATION-ASSERTION-CONTRACT.json','INDEPENDENT-CUPRA-INITIAL-IDENTITIES-v1.json','INDEPENDENT-CUPRA-DEPENDENCY-PROPOSAL-v1.json','INHERITED-DEPENDENCY-RECONSTRUCTION-v1.json','independent_cupra_recovery_v2.py','build_independent_cupra_replay_inputs_v1.py'};ck(required<={*selected},'required support absent')
 pfs=[(int(p.stem.rsplit('v',1)[1]),p,load(p)) for p in C.glob('CUPRA-SUPPORT-PATTERN-PREFLIGHT-v*.json')];ck(pfs,'raw preflight absent');_,fp,raw=max(pfs);ck(raw['rawPatternsUnchanged'] and not raw['knownValueSearchPerformed'] and raw['seedReads']==raw['historicalArchiveReads']==0 and not raw['payloadsModified'] and not raw['newClassificationsGranted'],'preflight scope differs');ck(all(r['astValid'] and not r['rawRuntimeFindings'] for r in raw['files']),'raw runtime candidate')
 check(BASE_MANIFEST,BASE_PIN);prior={(r['bytes'],r['sha256']) for r in load(BASE_MANIFEST)['files'] if r['path'].endswith('.py')};tested={(r['bytes'],r['sha256']) for r in raw['files']};ck(all((selected[n]['bytes'],selected[n]['sha256']) in tested|prior for n in scripts),'new script not preflighted')
 candidates=[{'member':'cupra-recovery-support/'+r['filename'],'filePin':sh(r),'finding':f} for r in raw['files'] for f in r['primaryFindings']];cp=None
 if candidates:
  cp=C/'INDEPENDENT-CUPRA-SUPPORT-SYNTAX-CLASSIFICATION-v1.json';ap=C/'APPROVED-CUPRA-SUPPORT-SYNTAX.json';classes=load(cp)['exactSupportCodeClassifications'];approval=load(ap);ck(approval['result']=='APPROVED_EXACT_SYNTAX_CLASSIFICATION' and approval['classificationPin']==sh(pin(cp)) and approval['exactCandidates']==len(classes)==len(candidates),'root syntax approval differs')
  for c in candidates:ck(len([r for r in classes if r['member']==c['member'] and r['filePin']==c['filePin'] and r['exactFinding']=={'member':c['member'],**c['finding']}])==1,'unclassified syntax candidate')
 else:ck(raw['result']=='PASS','raw preflight not passed')
 q=pin(pp);selected[pp.name]={**q,'localRelativePath':pp.name};out={'schemaVersion':1,'status':'REVIEWED_EXACT_SUPPORT_ALLOWLIST','reviewedAt':now(),'approvalScope':proposal['approvalScope'],'proposal':q,'files':[selected[n] for n in sorted(selected)],'review':{'exactFilePinsAndLstatIdentityChecked':True,'noSymlinksOutsideCheckpointOrPayloadTrees':True,'allCurrentExecutableFilesIncluded':len(scripts),'rawPreliminaryProposalExcluded':True,'supportProposalIncludedOnce':True,'rawCodePreflight':pin(fp),'exactClassifiedCodeCandidates':len(candidates),'classification':pin(cp) if cp else None,'noNewClassificationsGranted':True,'noPayloadArchiveOrSeedReads':True,'selectionSelfRetainedBySealer':True}};dump(C/'SUPPORT-SELECTION-v1.json',out);print(json.dumps({'result':out['status'],'files':len(selected),'scripts':len(scripts)}))
if __name__=='__main__':
 bounded();ck(len(sys.argv)==3 and sys.argv[1] in ('propose','review') and sys.argv[2]=='--sole-child-slot-authorized','Usage: propose|review --sole-child-slot-authorized');{'propose':propose,'review':review}[sys.argv[1]]()
