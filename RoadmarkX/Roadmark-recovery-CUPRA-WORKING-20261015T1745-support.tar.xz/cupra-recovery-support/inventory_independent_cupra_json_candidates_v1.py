#!/usr/bin/env python3
"""Exact frozen-JSON sanitizer candidate inventory, without values or payload mutation."""
import ast,re
from independent_cupra_common_v1 import *
def main():
 command('inventory');scope=load(C/'FROZEN-CAPTURE-SCOPE.json');engine=R/'snapshot_recovery_v2.py';source=engine.read_bytes();tree=ast.parse(source);fn=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='sanitize_json'];ck(len(fn)==1,'sanitizer missing');ns={'json':json};exec(compile(ast.Module(body=fn,type_ignores=[]),str(engine),'exec'),ns);san=ns['sanitize_json'];findings=[];reads=[];tested=0;total=0;maxbytes=0
 for r in scope['files']:
  p=P(r['path'])
  if p.suffix!='.json':continue
  ck(r['bytes']<24000000,'per-file bound');before=identity(p);ck(before[:2]==[r['bytes'],r['mtimeNsAtFreeze']],'frozen metadata changed');data=p.read_bytes();ck(identity(p)==before and len(data)==before[0],'unstable JSON');original={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};expected=r.get('sha256') or r.get('knownSha256');ck(not expected or expected==original['sha256'],'known pin differs');tested+=1;total+=len(data);maxbytes=max(maxbytes,len(data));out,red=san(data);reads.append({'path':str(p),**original,'candidatePointers':red})
  if not red:continue
  obj=json.loads(data)
  for ptr in red:
   value=pointer(obj,ptr);kind='string' if isinstance(value,str) else type(value).__name__;row={'path':str(p),'restorePath':rest(p),'filePin':original,'pointer':ptr,'valueType':kind,'valueCharacters':len(value),'valueUtf8Bytes':len(value.encode()),'valuePrintedOrPersisted':False,'semanticIndicators':{k:k in value.casefold() for k in ('syntax','only','check','preparation','approval','scope','execution','run','tests')},'httpCredentialPrefixObserved':bool(re.search(r'(?i)(?:bearer|basic)\s+[A-Za-z0-9+/=_-]{12,}',value)),'longOpaqueSequenceObserved':bool(re.search(r'[A-Za-z0-9+/_=-]{24,}',value)),'classification':'REQUIRES_EXACT_PROSE_OR_SENSITIVE_CLASSIFICATION'}
   if ptr=='/authorization' and data.count(b'"authorization":')==1 and b'"approvalScope":' not in data:
    copied=data.replace(b'"authorization":',b'"approvalScope":',1);a=json.loads(data);b=json.loads(copied);v=a.pop('authorization');ck(b.pop('approvalScope')==v and a==b,'copy changed unrelated fields');after,remaining=san(copied);ck(not remaining and after==copied,'rename does not clear exact sanitizer');row['proposedCopyOnlyKeyRename']={'oldPointer':'/authorization','newPointer':'/approvalScope','originalBytes':len(data),'originalSHA256':original['sha256'],'bytes':len(copied),'sha256':hashlib.sha256(copied).hexdigest(),'proseValueByteExact':True,'allOtherJSONFieldsIdentical':True,'allOutsideKeyBytesIdentical':True,'sanitizerCandidatesAfterRename':0}
   findings.append(row)
  del data,out,obj
 result={'result':'EXACT_FROZEN_JSON_CANDIDATES_INVENTORIED','createdAt':now(),'scope':pin(C/'FROZEN-CAPTURE-SCOPE.json'),'sanitizer':pin(engine),'sanitizerFunctionASTUnchanged':True,'jsonFiles':tested,'jsonBytes':total,'largestJsonBytes':maxbytes,'candidateLocations':len(findings),'candidateFiles':len({r['path'] for r in findings}),'files':findings,'readAccounting':reads,'rawValuesOrValueDigestsPersisted':False,'sourceOrCopyWrites':0,'seedReads':0,'archiveReads':0,'detectorExemptions':0,'partialProofPreserved':True,'rootApprovalRequiredBeforeRename':True};dump(C/'INDEPENDENT-CUPRA-JSON-CANDIDATE-INVENTORY-v1.json',result);print(json.dumps({k:result[k] for k in ('result','jsonFiles','jsonBytes','largestJsonBytes','candidateLocations','candidateFiles','sourceOrCopyWrites','seedReads','archiveReads')}))
if __name__=='__main__':main()
