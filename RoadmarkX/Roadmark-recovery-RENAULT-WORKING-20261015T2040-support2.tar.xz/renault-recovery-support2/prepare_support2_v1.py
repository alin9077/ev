#!/usr/bin/env python3
"""Copy one exact append-only metadata selection without changing sealed support."""
import shutil
from capture_v1 import *
def main():
 sp=C/'SUPPORT2-SELECTION-v1.json';selection=load(sp);prior=load(C/'SUPPORT-MEMBER-INVENTORY.json');old={r['originalPath'] for r in prior['files']};old.update(r['originalPath'] for r in load(C/'SUPPORT-REUSE-MAPPING.json')['files']);out=C/'support2-staging-v1';out.mkdir(exist_ok=False);rows=[]
 inputs=list(selection['files'])+[{'originalPath':str(sp),'localRelativePath':sp.name,**pin(sp)}];seen=set()
 for r in inputs:
  p=P(r['originalPath']);assert str(p) not in old;name=r['localRelativePath'];safe(name);assert name not in seen;seen.add(name);got,before=check(p,r);dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True)
  with p.open('rb') as src,dest.open('xb') as dst:shutil.copyfileobj(src,dst,CHUNK)
  check(dest,got);assert identity(p)==before;rows.append({'path':'renault-recovery-support2/'+name,'payloadPath':str(dest),'originalPath':str(p),**got})
 dump(C/'SUPPORT2-MEMBER-INVENTORY.json',{'result':'EXACT_APPEND_ONLY_SECOND_SUPPORT_SELECTION','files':rows,'selection':{'path':str(sp),**pin(sp)},'fourEarlierArchivesUnchanged':True,'seedReads':0,'archivePayloadReads':0});dump(C/'SUPPORT2-PATTERN-SELECTION-v1.json',{'files':rows});print(json.dumps({'newSupportMembers':len(rows),'bytes':sum(r['bytes'] for r in rows)}))
if __name__=='__main__':main()
