#!/usr/bin/env python3
"""Independent metadata-only delivery checks; never opens archive or seed payloads."""
import datetime, hashlib, json, os, pathlib, resource, stat, sys, time
P=pathlib.Path;C=P(__file__).resolve().parent;B=C.parent/'cupra-working-20261015T1745';D=C/'deliverables';LIMIT=256*1024*1024;DATE='20261015'
NAMES={'documents':'INDEPENDENT-RENAULT-DOCUMENT-CHECK-v1.json','active':'INDEPENDENT-RENAULT-ACTIVE-CHECK-v1.json','persisted':'INDEPENDENT-RENAULT-PERSISTED-CHECK-v1.json','terminal':'INDEPENDENT-RENAULT-TERMINAL-CLOSURE-v1.json'}
DOCS=[D/f'Roadmark-RECOVERY-INDEX-RENAULT-WORKING-{DATE}.md',D/f'Roadmark-RECOVERY-MANIFEST-RENAULT-WORKING-{DATE}.json',D/f'Roadmark-RECOVERY-VERIFICATION-RENAULT-WORKING-{DATE}.json',D/f'Roadmark-RENAULT-M1-UPDATE-{DATE}.md'];ACTIVE=D/f'Roadmark-RECOVERY-ACTIVE-STATE-RENAULT-WORKING-{DATE}.json'
BASE_PIN={'bytes':3476229,'sha256':'d1eaf85b9254160820f9f98e622cb6ad821b8d85a8c7bf1dd8e237d4faa6b12b'}

def ck(v,msg):
 if not v:raise AssertionError(msg)
def load(p):return json.loads(P(p).read_bytes())
def sh(x):return {k:x[k] for k in ('bytes','sha256')}
def identity(p):
 p=P(p);s=p.lstat();ck(stat.S_ISREG(s.st_mode) and not any(x.is_symlink() for x in p.parents),'unsafe file');return (s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev)
def pin(p):
 p=P(p);ck(p.suffix not in ['.xz','.gz','.zip','.pdf','.png'],'metadata-only checker cannot open archive/image payload');before=identity(p);b=p.read_bytes();ck(identity(p)==before,'metadata mutation');return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def check(p,r):
 got=pin(p);ck(sh(got)==sh(r),'metadata hash differs '+str(p));return got
def checkref(r):return check(P(r['path']) if P(r['path']).is_absolute() else C/r['path'],r)
def bypath(rows):
 result={r['path']:{k:r[k] for k in ['path','bytes','sha256']} for r in rows};ck(len(result)==len(rows),'duplicate metadata member');return result
def pair(p):
 p=P(p);t=load(p);i=load(p.with_name(p.stem+'.invocation.json'));ck(all(t[k]==i[k] for k in ['command','childPid','startedAt','addressSpaceLimitBytes','wallLimitSeconds']),'terminal/invocation binding');ck(t['exitCode']==0 and not t['timedOut'] and t['addressSpaceLimitBytes']==LIMIT and t['wallLimitSeconds']==600,'unsuccessful or unbounded phase');return t

def retained():
 inv=load(C/'SUPPORT-MEMBER-INVENTORY.json');extra=load(C/'SUPPORT2-MEMBER-INVENTORY.json');inv={'files':inv['files']+extra['files']};reuse=load(C/'SUPPORT-REUSE-MAPPING.json');kept={r['originalPath']:sh(r) for r in inv['files']};kept.update({r['originalPath']:sh(r) for r in reuse['files']})
 own=[r for r in inv['files'] if r['originalPath']==str(P(__file__).resolve())];ck(len(own)==1 and sh(own[0])==sh(pin(__file__)),'document checker absent or changed after sealing');return kept

def embedded(records):
 found={}
 for r in records:
  f=r['file'];ck(f['path'] not in found,'duplicate embedded evidence');b=r['utf8'].encode('utf8');ck({'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}==sh(f),'embedded metadata bytes differ');checkref(f);found[f['path']]=sh(f)
 return found

def dictionaries(value):
 if isinstance(value,dict):
  yield value
  for v in value.values():yield from dictionaries(v)
  if value.get('type')=='text' and isinstance(value.get('text'),str):
   try:parsed=json.loads(value['text'])
   except (ValueError,TypeError):pass
   else:yield from dictionaries(parsed)
 elif isinstance(value,list):
  for v in value:yield from dictionaries(v)

def native(phase, expected):
 upper={'archives':'ARCHIVE','documents':'DOCUMENT','active':'ACTIVE'}[phase];ident=load(C/f'{upper}-UPLOAD-IDENTITIES.json')['files'];by={r['filename']:r for r in ident};ck(len(by)==len(ident) and set(by)==set(expected),'native identity filename set');ck(len({r['library_file_id'] for r in ident})==len(ident),'duplicate native Library identity')
 request=load(C/f'library-{phase}-request.json')['uploads'];normalized=load(C/f'library-{phase}-results.json');results=normalized['results'];rawpath=C/f'library-{phase}-provider-results.json';rawpin=pin(rawpath);raw=load(rawpath);returned=list(dictionaries(raw));ck(not (isinstance(raw,dict) and raw.get('isError') is True),'provider response is error');ck(any(d.get('bytes')==rawpin['bytes'] and d.get('sha256')==rawpin['sha256'] for d in dictionaries(normalized)),'normalized results lack exact raw-provider pin');witness=[json.loads(s) for s in (C/f'library-{phase}-verified.jsonl').read_text().splitlines()];ck(len(request)==len(results)==len(witness)==len(ident),'native provider/witness count')
 for q,r,w in zip(request,results,witness):
  p=P(q.get('workspace_path',q.get('local_path','')));name=p.name;ck(name in expected and r['status']=='succeeded' and r['local_metadata_applied'] and r['local_path']==str(p) and r['file_name']==name,'provider successful upload binding');a=by[name];ck(a['localPath']==str(p) and sh(a)==sh(expected[name]),'identity hash binding');ck(a['library_file_id']==r['library_file_id'] and a['file_id']==r['file_id'] and a['version']==r['current_version_number'],'provider identity differs');ck(any(d.get('library_file_id')==a['library_file_id'] and d.get('file_id')==a['file_id'] and d.get('file_name',d.get('name'))==name and d.get('current_version_number',d.get('version'))==a['version'] for d in returned),'normalized identity absent from exact raw provider response');ck(w['verified'] and w['filename']==name and w['library_file_id']==a['library_file_id'] and w['version']==a['version'] and sh(w)==sh(a),'native witness differs');ck(os.getxattr(p,'user.library-file-id').decode()==a['library_file_id'] and os.getxattr(p,'user.library-file-version').decode()==str(a['version']),'local Library identity differs')
  if phase=='archives':ck(p.stat().st_size==a['bytes'],'persisted archive size differs')
  else:check(p,a)
 return ident

def seed_accounting(name,passes):
 a=load(C/name);ck(a['status']=='EXPLICIT_STAGE_AND_TERMINAL_ACCOUNTING' and a['noSeedValuesReadByThisAccounting'],'seed accounting scope');phases=a['phases'];ck(len(phases)==passes+1,'scan attempt count differs');zero=[x for x in phases if x['knownZeroSeedPreconditionFailure']];ck(len(zero)==1 and zero[0]['invocation']['path']=='scan-fresh-03.resources.invocation.json' and zero[0]['outcome']=='NONZERO_OR_TIMEOUT','known-zero failure not exact');checkref(zero[0]['knownZeroReview']);ck(sh(zero[0]['knownZeroReview'])=={'bytes':5234,'sha256':'e52b66ef43ebb122c0c056e4116da7ac8b32b7c67f8f2d8ad6e01ec4f2502b29'},'known-zero authority differs');successful={p['invocation']['path']:p for p in phases if p['outcome']=='PASS'};ck(len(successful)==passes,'not every other scan passed')
 for p in phases:checkref(p['invocation']);checkref(p['terminal'])
 for p in successful.values():pair(C/p['terminal']['path'])
 for kind,unit,folder,key in [('historical',200,'seed-read-invocations','exactPinnedMembersReadAndVerified'),('audi',6,'audi-seed-read-invocations','payloadReadOperations'),('deepal',5,'deepal-seed-read-invocations','payloadReadOperations')]:
  s=a['stages'][kind];ck(s['completedInvocations']==passes and s['perCompletedInvocationOperations']==unit and s['totalCompletedOperations']==passes*unit and len(s['records'])==passes,'stage operation counts');seen=set()
  for r in s['records']:
   checkref(r['receipt']);d=load(C/r['receipt']['path']);ph=r['phaseInvocation']['path'];ck(ph in successful and ph not in seen,'seed stage phase mismatch');seen.add(ph);p=successful[ph];ck(d[key]==unit and d['processId']==p['pid'] and p['start']<=d['completedAt']<=p['end'] and r['scanOutcome']=='PASS' and r['phaseTerminal']==p['terminal'],'completed seed stage/terminal binding')
  ck({str(p.relative_to(C)) for p in (C/folder).glob('*.json')}=={r['receipt']['path'] for r in s['records']},'uncounted seed ledger')
 local=a['inheritedLocal'];ck(local['completedInvocationsProvedByAudiLedger']==passes and local['totalProvedValueReads']==local['totalProvedIntegrityReads']==passes*48 and not local['unknownPartialLocalReadsPossibleForPhasesWithoutAudiCompletion'],'local seed operation basis differs');ck(a['inheritedCupraAccounting']['originalInterruptedScanOutcome']=='UNKNOWN' and a['inheritedCupraAccounting']['completedStageReadAccountingPreservedSeparately'],'inherited interrupted accounting changed');return a

def privacy_gate(name,paths,receipt):
 g=load(C/name);ck(g['status']=='clean' and not g['findings'] and not g['errors'] and g['fileCount']==len(paths),'document privacy gate not clean');ck(bypath(g['files'])==bypath([pin(p) for p in paths]),'privacy gate file identity differs');t=pair(C/receipt);ck(str(C/name) in t['command'],'privacy terminal report binding');selection=next(P(x) for x in t['command'] if x.endswith('.json') and x!=str(C/name));check(selection,g['selectionPin']);return pin(C/name)

def documents():
 kept=retained();p=load(C/'RESTORE-PLAN-v2.json');basepath=B/'deliverables/Roadmark-RECOVERY-MANIFEST-CUPRA-WORKING-20261015.json';check(basepath,BASE_PIN);base=load(basepath);prior=load(B/'FINAL-CUPRA-UPLOAD-RECEIPTS.json');scope=load(C/'FROZEN-CAPTURE-SCOPE.json');m=load(DOCS[1]);v=load(DOCS[2]);ind=load(C/'INDEPENDENT-RENAULT-RECOVERY-VERIFICATION-v1.json');ck(ind['result']=='PASS_EXACT_FRESH_ONLY_RENAULT_RECOVERY' and ind['freshArchiveCount']==5 and ind['sourceProjectFiles']==700 and ind['capturedOriginalsRehashed']==608,'independent recovery not accepted');pair(C/'independent-recovery-v2.resources.json');checkref(ind['memberReplayManifest']);replay=load(C/'INDEPENDENT-NEW-MEMBER-REPLAY-MANIFEST-v1.json');ck(bypath(replay['files'])==bypath(p['newFiles']),'fresh member replay differs from restore plan')
 fresh=load(C/'ARCHIVE-PLAN-v2.json')['archives'];nativeids=native('archives',{a['filename']:a for a in fresh});ids={r['filename']:r for r in nativeids};old=[dict(a) for a in base['archivesInRestoreOrder'] if a['filename']!=base['source']['filename']];ck(len(old)==137 and len(fresh)==5,'prior/fresh archive scope');expected=[]
 for i,a in enumerate(old+fresh,1):
  x={k:z for k,z in a.items() if k!='memberFiles'};x['restoreOrder']=i
  if i<=137:x['new']=False
  else:x.update({k:ids[a['filename']][k] for k in ['library_file_id','file_id','version']})
  expected.append(x)
 expectednew=[{**{k:v for k,v in a.items() if k!='memberFiles'},**{k:ids[a['filename']][k] for k in ['library_file_id','file_id','version']}} for a in fresh];expectedsource={**{k:v for k,v in p['source'].items() if k!='memberFiles'},**{k:ids[p['source']['filename']][k] for k in ['library_file_id','file_id','version']}};ck(m['source']==expectedsource and m['newArchives']==expectednew,'standalone source or fresh native archive records differ');ck(ind['acceptedFinalRetentionScope']=='accepted_metadata_only_final_retention_freeze' and ind['preservedOutcomes']['recoveryVerifierPreconditionFailures']==1,'metadata-only acceptance or failed replay history differs')
 ck(m['archivesInRestoreOrder']==expected,'restore archive order or native identity differs');expectedfiles={n:r for n,r in bypath(base['files']).items() if not n.startswith('roadmark/')};expectedfiles.update(bypath(replay['files']));ck(bypath(m['files'])==expectedfiles,'restored logical member set differs');counts={'fullSourceFiles':700,'sourceArchiveMembers':701,'archiveCount':142,'logicalFiles':len(expectedfiles),'logicalBytes':sum(x['bytes'] for x in expectedfiles.values()),'freshFiles':len(replay['files']),'freshBytes':sum(x['bytes'] for x in replay['files']),'baseArchivesReused':137};ck(m['counts']==v['counts']==counts and all(p[k]==val for k,val in counts.items()),'document restore counts differ');ck(v['independent']==ind and m['currentValidation']==v['currentValidation']==scope['currentValidation'],'verification facts differ');ck(m['workState']==scope['workingResult'] and m['copyOnlySanitation']==load(C/'COPY-SANITATION-MAPPING.json'),'working state or copy maps differ');ck(len(m['copyOnlySanitation']['files'])==10 and m['fullProjectTypeScriptPassed'] is False and m['releaseReady'] is False and v['fullProjectTypeScriptPassed'] is False and v['releaseReady'] is False,'broader release boundary changed')
 for k in ['sourceLibraryFileId','manifestLibraryFileId','activeReceiptLibraryFileId']:ck(m['baseRecovery'][k]==prior[k],'base recovery identity differs')
 for k in ['manifest','finalReceipt','terminalReceipt']:checkref(m['baseRecovery'][k])
 for k in ['captureScope','independentVerification','freshSupportReuse','dependencyClosure']:checkref(m[k])
 closure=load(C/'INDEPENDENT-RENAULT-REFERENCE-CLOSURE-v1.json');dp=closure['inheritedDependencyProposal'];dep=m['inheritedDependencyReconstruction'];checkref(dep['receipt']);ck(dep['count']==len(dep['dependencies'])==291 and dep['dependencies']==dp['dependencies'] and dep['dependenciesCanonicalSha256']==dp['canonicalSha256'] and dep['relocatedMemberPointers']==0 and dep['newRecords']==15 and dep['originalExpectedPathsAndHashesUnchanged'],'dependency reconstruction continuity differs')
 ck(len(m['currentPreparationLimitations'])==3 and 'unavailable' in m['currentPreparationLimitations'][0] and 'reconstructed copy' in m['currentPreparationLimitations'][1] and 'before opening an archive' in m['currentPreparationLimitations'][2] and v['limitations']==m['inheritedBoundaries']+m['currentPreparationLimitations'],'current preparation history limitations missing')
 ck(m['currentImageProvenance']==load(C/'IMAGE-PROVENANCE.json') and m['currentRawRuntimeExclusion']==scope['rawRuntimeExclusion'],'image/exclusion provenance differs')
 post=embedded(v['postSealEvidence']);recoverable={**kept,**post};required=['INDEPENDENT-RENAULT-RECOVERY-VERIFICATION-v1.json','INDEPENDENT-NEW-MEMBER-REPLAY-MANIFEST-v1.json','independent-recovery-v2.resources.json','independent-recovery-v2.resources.invocation.json','ARCHIVE-UPLOAD-IDENTITIES.json','ARCHIVE-NATIVE-READBACK-v1.json','INDEPENDENT-RENAULT-REFERENCE-CLOSURE-v1.json','SUPPORT-REUSE-MAPPING.json']
 for n in required:ck(recoverable.get(str(C/n))==sh(pin(C/n)),'missing exact recoverable metadata '+n)
 scans=m['privacyVerification'];ck(scans==v['privacyReports'] and len(scans)==5,'privacy reference list differs');seen=set()
 for s in scans:
  ck(s['archive'] in ids and s['archive'] not in seen,'duplicate/missing privacy archive');seen.add(s['archive']);checkref(s['report']);checkref(s['terminal']);checkref(s['invocation']);t=pair(s['terminal']['path']);g=load(s['report']['path']);ck(g['status']=='clean' and g['archive']==s['archive'] and g['archivePin']==sh(ids[s['archive']]),'archive privacy identity mismatch');ck(s['report']['path'] in t['command'],'archive privacy terminal target');
  for key in ['report','terminal','invocation']:ck(recoverable.get(s[key]['path'])==sh(s[key]),'postseal scan evidence missing')
 for folder in ['seed-read-invocations','audi-seed-read-invocations','deepal-seed-read-invocations']:
  for q in (C/folder).glob('*.json'):
   d=load(q)
   # Document scan ledgers are generated after the verification document and retained by active receipt.
   if any(load(s['terminal']['path'])['childPid']==d['processId'] and load(s['terminal']['path'])['startedAt']<=d['completedAt']<=load(s['terminal']['path'])['endedAt'] for s in scans):ck(recoverable.get(str(q))==sh(pin(q)),'archive seed ledger not recoverable')
 index=DOCS[0].read_text();ck('pending new-file persistence' not in index and scope['workingResult'] in index,'index identity/status unresolved')
 for a in expected:ck(f"{a['restoreOrder']}. {a['filename']} | {a['bytes']} bytes | SHA-256 {a['sha256']} | Library {a['library_file_id']}" in index,'index archive identity missing')
 sr=next(r for r in load(C/'source-capture.json')['files'] if r['path']=='docs/RENAULT_M1_UPDATE.md');check(sr['payloadPath'],sr);ck(DOCS[3].read_bytes()==P(sr['payloadPath']).read_bytes()+('\n\n## Recovery note\n\n'+scope['workingResult']+'\n').encode(),'summary not exact captured author text plus disclosed note');privacy_gate('DELIVERABLE-PRIVACY-GATE.json',DOCS,'scan-documents-v1.resources.json');a=seed_accounting('SEED-READ-ACCOUNTING-after-docs-v1.json',6)
 return {'documents':[pin(x) for x in DOCS],'counts':counts,'nativeArchiveIdentities':nativeids,'postSealByteExactRecords':len(post),'seedCompletedInvocations':6,'knownZeroSeedPreconditionFailure':1,'currentValidation':scope['currentValidation'],'originalRenaultReportOutcome':'UNKNOWN','freshRenaultReportOutcome':'PASSED','fullProjectTypeScriptPassed':False,'releaseReady':False}

def active():
 kept=retained();p=load(C/'RESTORE-PLAN-v2.json');scope=load(C/'FROZEN-CAPTURE-SCOPE.json');a=load(ACTIVE);doccheck=load(C/NAMES['documents']);ck(doccheck['result']=='PASS_INDEPENDENT_RENAULT_DOCUMENTS','document check absent');checkref(a['independentDocuments']);checkref(a['independentRecovery']);ars=native('archives',{x['filename']:x for x in load(C/'ARCHIVE-PLAN-v2.json')['archives']});docs=native('documents',{x.name:pin(x) for x in DOCS});ck(a['files']==ars+docs and len(a['files'])==9,'active native file list differs');ck(a['sourceLibraryFileId']==next(x['library_file_id'] for x in ars if x['filename']==p['source']['filename']),'active source identity');ck(a['counts']=={k:p[k] for k in ['archiveCount','logicalFiles','freshFiles','fullSourceFiles','baseArchivesReused']} and a['currentValidation']==scope['currentValidation'] and a['workingResult']==scope['workingResult'],'active facts differ');ck(a['originalRenaultReportOutcome']=='UNKNOWN' and a['freshRenaultReportOutcome']=='PASSED' and a['inheritedCupraInterruptedScanOutcome']=='UNKNOWN' and not a['fullProjectTypeScriptPassed'] and not a['releaseReady'],'active history boundary differs');checkref(a['baseContinuity']['finalReceipt']);checkref(a['baseContinuity']['terminalReceipt']);ck(a['baseContinuity']['archiveReuse']==137 and a['baseContinuity']['priorInterruptedScanAccountingUnchanged'] and a['baseContinuity']['missingMutableCupraV1BytesNotReconstructed'],'active prior continuity differs');late=embedded(a['lateMetadata']);ver=load(DOCS[2]);recoverable={**kept,**embedded(ver['postSealEvidence']),**late};need=['INDEPENDENT-RENAULT-DOCUMENT-CHECK-v1.json','independent-documents-v1.resources.json','independent-documents-v1.resources.invocation.json','DELIVERABLE-PRIVACY-GATE.json','scan-documents-v1.resources.json','scan-documents-v1.resources.invocation.json','SEED-READ-ACCOUNTING-after-docs-v1.json','DOCUMENT-UPLOAD-IDENTITIES.json','DOCUMENT-NATIVE-READBACK-v1.json']
 for n in need:ck(recoverable.get(str(C/n))==sh(pin(C/n)),'active late evidence missing '+n)
 ck(a['seedReadAccountingAsOfActivePreparation']==load(C/'SEED-READ-ACCOUNTING-after-docs-v1.json'),'active seed snapshot differs');privacy_gate('ACTIVE-PRIVACY-GATE.json',[ACTIVE],'scan-active-v1.resources.json');seed_accounting('SEED-READ-ACCOUNTING-after-active-v1.json',7)
 return {'active':pin(ACTIVE),'files':ars+docs,'counts':a['counts'],'lateByteExactRecords':len(late),'seedCompletedInvocations':7,'knownZeroSeedPreconditionFailure':1,'fullProjectTypeScriptPassed':False,'releaseReady':False}

def persisted():
 retained();f=load(C/'FINAL-RENAULT-UPLOAD-RECEIPTS.json');p=load(C/'RESTORE-PLAN-v2.json');ars=native('archives',{x['filename']:x for x in load(C/'ARCHIVE-PLAN-v2.json')['archives']});docs=native('documents',{x.name:pin(x) for x in DOCS});act=native('active',{ACTIVE.name:pin(ACTIVE)});ck(f['files']==ars+docs+act and len(f['files'])==10 and len({r['library_file_id'] for r in f['files']})==10,'final persisted file identities differ');ck(f['archiveLibraryFileIds']==[r['library_file_id'] for r in ars] and f['activeReceiptLibraryFileId']==act[0]['library_file_id'],'final active/archive IDs differ');by={r['filename']:r for r in f['files']}
 for key,path in [('indexLibraryFileId',DOCS[0]),('manifestLibraryFileId',DOCS[1]),('verificationLibraryFileId',DOCS[2]),('summaryLibraryFileId',DOCS[3])]:ck(f[key]==by[path.name]['library_file_id'],'final document pointer differs')
 ck(f['sourceLibraryFileId']==by[p['source']['filename']]['library_file_id'] and f['counts']=={k:p[k] for k in ['archiveCount','logicalFiles','logicalBytes','freshFiles','freshBytes','fullSourceFiles','baseArchivesReused']},'final source/counts differ')
 for key in ['independentRecovery','documentCheck','activeCheck']:checkref(f[key]);ck(load(f[key]['path'])['result'].startswith('PASS_'),'final independent acceptance missing')
 ck(f['seedReadAccounting']==seed_accounting('SEED-READ-ACCOUNTING-after-active-v1.json',7) and not f['fullProjectTypeScriptPassed'] and not f['releaseReady'],'final seed or release boundary differs');return {'finalReceipt':pin(C/'FINAL-RENAULT-UPLOAD-RECEIPTS.json'),'files':f['files'],'counts':f['counts'],'nativeIdentityChecks':'provider results, exact local metadata witnesses and Library identity xattrs; archive payload not reopened','seedCompletedInvocations':7,'knownZeroSeedPreconditionFailure':1,'deliveryConfirmed':False,'fullProjectTypeScriptPassed':False,'releaseReady':False}

def terminal():
 r=persisted();delivery=load(C/'DELIVERY-CONFIRMATION.json');f=load(C/'FINAL-RENAULT-UPLOAD-RECEIPTS.json');wanted={f[k] for k in ['sourceLibraryFileId','summaryLibraryFileId','indexLibraryFileId','manifestLibraryFileId','verificationLibraryFileId']};ck(delivery['status']=='accepted' and delivery['message_id'] and set(delivery['library_file_ids'])==wanted,'exact five requested parent attachment identities required');r.update(delivery=pin(C/'DELIVERY-CONFIRMATION.json'),deliveryConfirmed=True);return r

def main():
 ck(len(sys.argv)==2 and sys.argv[1] in NAMES,'documents|active|persisted|terminal mode required');resource.setrlimit(resource.RLIMIT_AS,(LIMIT,LIMIT));mode=sys.argv[1];output=C/NAMES[mode];ck(not output.exists(),'immutable independent output exists');started=time.monotonic();result=globals()[mode]();out={'schemaVersion':1,'result':'PASS_INDEPENDENT_RENAULT_'+mode.upper(),'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checkerScript':pin(__file__),**result,'scope':{'archivePayloadReads':0,'seedPayloadReads':0,'noExcludedRawRead':True,'noUploadOrExternalMutation':True,'noCompilerBuildOrUiExecution':True},'resources':{'wallSeconds':round(time.monotonic()-started,3),'maxRssKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'addressSpaceLimitBytes':LIMIT}}
 with output.open('x') as f:json.dump(out,f,indent=2);f.write('\n')
 print(json.dumps({'result':out['result'],'output':pin(output)}))
if __name__=='__main__':main()
