#!/usr/bin/env python3
"""Audit actual frozen status and shape fields without any archive or seed reads."""
import pathlib,json,hashlib,datetime,resource
C=pathlib.Path(__file__).resolve().parent;B=C.parent/'cupra-working-20261015T1745';W=C.parents[2]
resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456));pins=[];checks=[]
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p):
 p=pathlib.Path(p);pins.append(pin(p));return json.loads(p.read_bytes())
def ck(v,name):
 checks.append({'check':name,'passed':bool(v)})
def sh(r):return {k:r[k] for k in ['bytes','sha256']}
def rows(rs):return {r['path']:sh(r) for r in rs}
def logical(p):
 p=pathlib.Path(p)
 if p.is_relative_to('/tmp'):return p.relative_to('/tmp').as_posix()
 if p.is_relative_to(W/'roadmark-104'):return 'roadmark/'+p.relative_to(W/'roadmark-104').as_posix()
 return p.relative_to(W).as_posix()
inv=load('/tmp/renault-packet/final-freeze-v1/inventory.json');a=load('/tmp/renault-review/final-retention-v1-accepted.json');scope=load(C/'FROZEN-CAPTURE-SCOPE.json');cap=load(C/'proof-capture-v1.json');sourcecap=load(C/'source-capture.json');sp=load(C/'source-package.json');proof=load(C/'proof-packages-v1.json')['archives'];support=load(C/'support-package.json');prior=load(B/'source-package.json');base=load(B/'deliverables/Roadmark-RECOVERY-MANIFEST-CUPRA-WORKING-20261015.json');bt=load(B/'INDEPENDENT-CUPRA-TERMINAL-CLOSURE-v1.json')
ck(a['status']=='accepted_metadata_only_final_retention_freeze','exact accepted metadata-only status literal');ck(a['inventory']==pins[0] and a['preparer']==inv['preparer'] and a['liveTargetPins']==inv['sourceAndStatusAfterPins'],'inventory preparer and eight live target identity relationships')
ck(len(inv['files'])==inv['totalFiles']==605 and sum(r['bytes'] for r in inv['files'])==inv['regularFileBytes']==41791599,'author605 file and byte totals');ck(len(scope['files'])==len(cap['files'])==608,'frozen/captured608 shape');ck(len(sourcecap['files'])==scope['expectedSourceFiles']==700 and sp['members']==len(sp['memberFiles'])==701 and sp['bytes']<15000000,'source700+manifest count and strict size')
changed={logical(r['path']):sh(r) for r in inv['sourceAndStatusAfterPins'] if pathlib.Path(r['path']).is_relative_to(W/'roadmark-104')};expected=rows(prior['memberFiles']);expected.pop('roadmark/SOURCE-FILE-MANIFEST.json');ck(len(expected)==697 and len(changed)==7,'prior697 and exact seven source changes');expected.update(changed);src=rows(sp['memberFiles']);src.pop('roadmark/SOURCE-FILE-MANIFEST.json');ck(src==expected and len(src)==700,'source overlay exact declared metadata');ck(len(cap['changedFiles'])==601 and len({r['path'] for r in cap['changedFiles']})==601,'proof601 delta uniqueness')
maps=load(C/'COPY-SANITATION-MAPPING.json');approvals=load(C/'PROSE-KEY-RENAME-APPROVALS.json');ck(len(maps['files'])==10 and maps['files']==approvals['files'] and maps['originalExpectedPinsUnchanged'] and maps['originalsUnchanged'] and not maps['secretMaterialChanged'],'exact ten copy-only mapping shape')
cv=a['validationScope'];facts={'catalogue':430,'tier1':353,'onSale':312,'packetCount':30,'retainedRefreshes':4,'additions':0,'unchangedPeers':426,'reviewedCore':68,'filledCore':64,'confirmed':61,'check':1,'reported':2,'notPublished':4,'scopedTests':151};ck(all(cv[k]==v for k,v in facts.items()),'actual accepted factual counts');ck(all(cv[k] is False for k in ['fullProjectTypecheckPassed','releaseReady','researchCompleted','currentCleanFullSuite','productionBuildVerified','phoneMobileVerified','publicationAuthorized']),'all unpassed validation boundaries');attempt=cv['reportAttempts'];ck(attempt['totalKnownNormalReportInvocations']==2 and attempt['originalAttemptOutcome']=='UNKNOWN' and attempt['originalAttemptTerminalAbsent'] and attempt['freshActualNormalReportOutcome']=='PASSED' and not attempt['automaticRetry'],'normal report attempt accounting shape')
by={r['originalPath']:r for r in cap['files']}
def copied(name):
 r=by[name];p=pathlib.Path(r['payloadPath']);ck(sh(pin(p))==sh(r),'captured metadata hash '+logical(name));return load(p)
u=copied('/tmp/renault-packet/report-comparison-v2-interruption-record-v2/record.json');ck(u['status']=='UNKNOWN_INTERRUPTED_WITHOUT_TERMINAL_EVIDENCE' and u['interruptionCause']=='unknown' and u['exitCode'] is None and u['terminationSignal'] is None and not u['successClaim'] and not u['failureClaim'] and not u['reportOutputPresent'],'original report UNKNOWN actual record shape')
report=copied('/tmp/renault-packet/report-comparison-v4/results-manifest-v1.json');review=copied('/tmp/renault-review/report-comparison-v4-results-v1.json');ck(len(report['checks'])==2 and all(x['passed'] for x in report['checks']) and review['status']=='accepted' and review['allGatesSerialExitZeroEmptyStderrNoWatchdog'],'fresh report separate accepted shape')
for x in report['checks']:
 t=copied(x['terminal']['path']);ck(t['exitCode']==0 and not t['watchdogFired'],'fresh report successful terminal '+x['name'])
gates=copied('/tmp/renault-packet/post-registration-checks-v6/results-manifest-v1.json');ck(len(gates['checks'])==5 and all(x['passed'] and x['exitCode']==0 for x in gates['checks']) and sum(x['expectedTests'] or 0 for x in gates['checks'])==151,'five scoped gates 151 tests actual shape')
for x in gates['checks']:
 t=copied(x['terminal']['path']);ck(t['exitCode']==0 and not t['watchdogFired'],'scoped successful terminal '+x['name'])
ck(len(inv['retainedFailures']['preparationFailurePaths'])==6 and all(p in by for p in inv['retainedFailures']['preparationFailurePaths']),'six original preparation failures exist in capture metadata');kgm=inv['retainedFailures']['compilerAttempts'];ck(len(kgm)==2 and all(r['exitCode']==-9 and r['cause']=='unknown' and not r['fullProjectTypecheckPassed'] for r in kgm),'both KGM compiler outcome fields')
closure=load(C/'INDEPENDENT-RENAULT-REFERENCE-CLOSURE-v1.json');dp=closure['inheritedDependencyProposal'];ck(closure['result']=='PASS_EXACT_METADATA_ONLY_REFERENCE_CLOSURE' and len(closure['requirements'])==957,'reference closure literal and957 records');ck(dp['inheritedRecords']==276 and dp['newRecords']==15 and dp['proposedRecords']==len(dp['dependencies'])==291 and not dp['newPinVariants'] and not dp['inheritedChangedSourceIntersections'],'291 dependency proposal shape');ck(hashlib.sha256(json.dumps(dp['dependencies'],sort_keys=True,separators=(',',':')).encode()).hexdigest()==dp['canonicalSha256'],'dependency canonical hash')
si=load(C/'SUPPORT-MEMBER-INVENTORY.json');ck(len(si['files'])==130 and support['members']==131,'sealed first support count');oldunknown=[r for r in bt['seedTerminalBindings'] if r.get('scanOutcome')=='UNKNOWN_INTERRUPTED_NO_TERMINAL_RECEIPT'];ck(len(oldunknown)==3 and all(r['terminal'] is None and not r['successfulScanClaim'] for r in oldunknown),'inherited CUPRA interrupted three stage bindings')
for directory,key,count in [('seed-read-invocations','exactPinnedMembersReadAndVerified',200),('audi-seed-read-invocations','payloadReadOperations',6),('deepal-seed-read-invocations','payloadReadOperations',5)]:
 ds=[load(p) for p in sorted((C/directory).glob('*.json'))];ck(len(ds)==4 and all(x[key]==count for x in ds),'current four completed '+directory+' ledger shape')
for p in sorted(C.glob('scan-fresh-*.json')):
 if '.resources.' in p.name:continue
 d=load(p);ck(d['status']=='clean' and not any(d[k] for k in ['exactValueMatches','primaryHeaderCandidates','unclassifiedRuntimeCandidates','errors']) and d['regularFilesScanned']==len(d['members']),'clean privacy report shape '+p.name)
result={'result':'PASS_METADATA_STATUS_AND_SHAPE_AUDIT' if all(r['passed'] for r in checks) else 'METADATA_ASSERTION_REVIEW_REQUIRED','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script':pin(pathlib.Path(__file__).resolve()),'checks':checks,'inputPins':pins,'limits':'This checks metadata predicates only. It does not verify archive or original source payload bytes, replace independent fresh replay, or authorize release. Five-archive extension and new future documents must be checked when created.','archivePayloadReads':0,'seedPayloadReads':0,'originalLiveSourceReads':0,'fullProjectTypeScriptPassed':False,'releaseReady':False}
out=C/'INDEPENDENT-RENAULT-METADATA-ASSERTION-AUDIT-v1.json'
with out.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'result':result['result'],'checks':len(checks),'failures':[x['check'] for x in checks if not x['passed']],'output':pin(out)}))
