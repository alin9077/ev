#!/usr/bin/env python3
"""Package only the separately approved append-only support supplement."""
import json
from capture_v1 import C,R,load,dump
from package_v1 import pack
if __name__=='__main__':
 inv=load(C/'SUPPORT2-MEMBER-INVENTORY.json');label='RENAULT-WORKING-20261015T2040';metadata={'recovery-metadata/'+label+'-support2.json':(json.dumps(inv,indent=2)+'\n').encode()};a=pack(R/f'Roadmark-recovery-{label}-support2.tar.xz',inv['files'],metadata);dump(C/'support2-package.json',a);print(json.dumps({'members':a['members'],'bytes':a['bytes'],'sha256':a['sha256']}))
