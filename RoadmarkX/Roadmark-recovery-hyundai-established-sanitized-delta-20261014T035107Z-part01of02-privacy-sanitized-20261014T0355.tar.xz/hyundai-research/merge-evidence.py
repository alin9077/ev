import json,pathlib,copy,re
R=pathlib.Path('/tmp/hyundai-research');D='2026-10-14';before={c['id']:c for c in json.load(open(R/'before.json'))};terms=json.load(open(R/'terms.json'))['Hyundai']
x={'reviewedAt':D,'sources':[],'variants':[],'familyNotes':{}}
for name in ['inster-kona','ioniq5-6','elexio-ioniq9']:
 e=json.load(open(R/name/'normalized-evidence.json'))
 for s in e['sources']:
  s=copy.deepcopy(s)
  for field in ['file','path','textFile','textPath']:
   if s.get(field):
    f=pathlib.Path(s[field]);f=f if f.is_absolute() else R/name/f
    if f.exists():s[field]=str(f.relative_to(R))
  x['sources'].append(s)
 x['familyNotes'][name]={k:v for k,v in e.items() if k not in ['sources','variants']}
 for row in e['variants']:
  r=copy.deepcopy(row);r['brand']='Hyundai';r['modelId']=r.get('modelId',before.get(r['id'],{}).get('modelId'));r['model']=r.get('model',before.get(r['id'],{}).get('model'));r['trim']=r.get('trim',before.get(r['id'],{}).get('trim'));r['drive']=r.get('drive',before.get(r['id'],{}).get('drive'))
  if r['availability'].get('stockStatus')=='advertised_new':r['availability']['stockStatus']='new_stock_listed'
  if r['id'] not in before and r['availability'].get('stockStatus')=='new_stock_listed':r['availability']['orderStatus']='unverified'
  # Canonical driveaway equipment is projected from a reviewed Fact, never directly replaced.
  # Preserve the N-family regular IONIQ 5's exact NSW offer and expiry from its sourced alias.
  if name=='ioniq5-6' and r['model']=='IONIQ 5' and r.get('modelYear')==2027:
   alias=next(f for f in r['facts'] if f['key']=='driveaway_price_aud')
   limit='Full campaign eligibility terms were not captured. This is an illustrative NSW private-buyer calculator observation, not a verified national campaign; confirm the exact buyer and vehicle eligibility with the dealer.'
   alias['qualifications']=list(dict.fromkeys(alias.get('qualifications',[])+[limit]));alias['condition']+=' '+limit;alias['rankingEligible']=False
   if not any(f['key']=='promotional_driveaway_aud' for f in r['facts']):
    offer=copy.deepcopy(alias);offer['key']='promotional_driveaway_aud';r['facts'].append(offer)
  if r['id']=='hyundai_ioniq_5_my27__84kwh_rwd__20261010':
   r['availability']['sourceKeys']=list(dict.fromkeys(r['availability']['sourceKeys']+['stock_i5']))
   r['availability']['stockStatus']='new_stock_listed'
   r['availability']['qualifications'].append('Frankston New advertisement 320476710 identifies MY27 NE.V7 base 2WD, VIN KMHKR81AUVU417505 and 37 km; this supports advertised New stock for this exact base version only, not physically inspected stock or accepted orders.')
   r['availability']['reason']+=' A fresh exact base-version dealer New advertisement separately establishes advertised stock.'
  # Shared current terms govern existing historical aliases too; never leave stale monetary/equipment claims silently graded current.
  b=before.get(r['id'],{})
  aliases=[]
  for key,old in b.get('facts',{}).items():
   if key in ['warranty','battery_warranty','roadside_assistance','warranty_extension'] or old.get('value') is None:continue
   if not any(z in key for z in ['warranty','roadside_support_initial']):continue
   aliases.append(key)
   scope='brand_au_terms';grade='confirmed';cond='';sourceKeys=['warranty','warranty-terms'];reason='Fresh current Australian maker policy explicitly supports this retained warranty component; first-registration, use and component exceptions are preserved in the shared canonical terms.';qual=terms['battery_warranty' if 'battery' in key else 'warranty']['qualifications']
   if 'extended' in key or key=='vehicle_warranty':grade='check';cond=terms['extension']['condition'];reason='Retained combined/extended warranty component includes real first-registration and exclusive-servicing requirements, rather than unconditional seven-year cover.'
   if 'roadside' in key:sourceKeys=['roadside','roadside-ev-terms'];qual=terms['roadside_assistance']['qualifications'];reason='Current maker EV-specific roadside terms confirm this 24-month initial duration; generic 12-month page copy is not applied to BEVs.'
   r['facts']=[f for f in r['facts'] if f['key']!=key]
   r['facts'].append({'key':key,'value':old['value'],'label':old['label'],'unit':old.get('unit',''),'basis':old.get('basis','Australian policy component'),'comparison':old.get('comparisonBasis',''),'grade':grade,'scope':scope,'condition':cond,'reason':reason,'sourceKeys':sourceKeys,'qualifications':qual})
  if r['model'] in ['IONIQ 5 N','IONIQ 6 N']:
   t=terms['nTrack'];r['facts'].append({'key':'warranty_track_use','value':t['value'],'grade':t['grade'],'sourceKeys':t['sourceKeys'],'condition':t['condition'],'reason':t['reason'],'scope':'exact_au_version','comparison':''})
  if r['model']=='IONIQ 9':
   r['facts'].append({'key':'roadside_towing_weight_limit_kg','label':'Roadside included-towing weight boundary','value':2500,'unit':'kg','grade':'check','sourceKeys':['roadside-ev-terms'],'condition':'Included towing requires vehicle weight strictly below 2,500 kg at breakdown. Above this boundary or where specialist equipment is required, recovery can be at the driver’s expense.','reason':'Current maker EV roadside policy has a real 2,500 kg towing limitation material to this large SUV; it is not a free-recovery promise.','basis':'Actual weight at breakdown, strict less-than boundary','comparison':''})
  x['variants'].append(r)
# Merge identical reused source keys; reject different source declarations under the same key.
out={}
for s in x['sources']:
 if s['key'] in out:assert out[s['key']]==s,('Conflicting source key',s['key'])
 out[s['key']]=s
x['sources']=list(out.values())
for r in x['variants']:
 keys=[f['key'] for f in r['facts']];assert len(keys)==len(set(keys)),(r['id'],'duplicate facts',[k for k in keys if keys.count(k)>1])
 if not r.get('metadata'):r.pop('metadata',None)
ids=[r['id'] for r in x['variants']];assert len(ids)==len(set(ids))
(R/'normalized-evidence.json').write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
print(len(x['variants']),'versions',len(x['sources']),'family sources',sum(len(v['facts']) for v in x['variants']),'specific facts',sum(len(v.get('features',[])) for v in x['variants']),'equipment replacements')
