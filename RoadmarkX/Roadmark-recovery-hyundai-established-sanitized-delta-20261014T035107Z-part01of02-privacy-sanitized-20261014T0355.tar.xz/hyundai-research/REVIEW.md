# Hyundai Australian M1 research review

Checked 14 October 2026. The frozen packet is independently approved for guarded integration of the 21 established versions. No application, original research fixture or registry has been changed by this research task. Research completion remains withheld while one exact six-seat residual advertisement is unresolved.

## Established version scope

21 exact Tier 1 versions are supported: 15 current factory configurations and six separately guarded residual-New identities. The current range comprises INSTER, KONA Electric, ELEXIO, IONIQ 5, IONIQ 5 N, IONIQ 6 N and IONIQ 9. Factory listings do not verify accepted orders; dealer New advertisements do not verify physical stock. The packet contains 5,254 specific facts, three shared brand-term definitions, 844 full before-guarded equipment replacements and 21 dependency-bound strength/tradeoff pairs. All 4,121 inherited non-null facts, all inherited known equipment and all 357 core review cells are accounted for; the two INSTER model-year changes retain no unreviewed old Confirmed equipment.

The six additions are INSTER MY26 Extended Range 49 kWh; IONIQ 5 MY25 63 kWh RWD, DYNAMIQ 84 kWh RWD N Line and EPIQ 84 kWh RWD N Line; IONIQ 5 MY26 base 84 kWh RWD; and IONIQ 9 MY26 Calligraphy AWD seven-seat. Distinct model years and configurations are not merged into the current factory list. Optional roof, Digital Side Mirror and N Line configurations do not inflate core version counts.

STARIA Load Electric vans and MIGHTY Electric truck rows remain untouched. STARIA Lounge is listed as hybrid, despite an incorrect thumbnail. Nexo is fuel-cell electric rather than battery-only. IONIQ 3's Australian cancellation has a dated manufacturer-spokesperson report. Regular IONIQ 6's inherited lead receives a finite source-bound disposition; old disabled configurator identities and inaccessible advertisements are not evidence of current orders or a nationwide absence claim.

## Material buyer findings

- Current INSTER is formal MY27 AX.V2, with two factory configurations. The maker-linked technical PDF retains an MY26 filename; the current configuration list and manufacturer-attributed model-year report resolve the identity while the filename context is retained. The separately evidenced MY26 AX.V1 Extended Range is not silently folded into this update.
- Direct original-dealer descriptions resolve several residual IONIQ 5 marketplace badge errors. The MY25 base is 63 kWh/125 kW/440 km with 750 kg braked towing. The DYNAMIQ and EPIQ N Line RWD versions are 515 km, not the unoptioned 530 km grades. The exact MY26 residual is the base 84 kWh RWD, not the marketplace's Elite badge.
- Current maker list prices take precedence where their consumer basis is clear. IONIQ 5 N, IONIQ 6 N and IONIQ 9 calculator backend MLP fields conflict with tax-inclusive semantics. Their visible expanded NSW driveaway totals are retained at the applicable state-estimate rung, with postcode/configuration conditions. No pre-LCT field or sum is relabelled consumer RRP. Exact residual dealer prices remain Reported and unranked; historical launch prices remain separately labelled price-when-new context.
- National offers retain exact eligibility and purchase/delivery deadlines. No expiry is fabricated for ordinary state driveaway estimates. The three regular IONIQ 5 supplemental NSW calculator observations retain the API's 31 December expiry but explicitly lack captured full campaign eligibility terms; they are unranked, and do not displace their higher-rung canonical maker RRP. Factory and dealer prices preserve their source scope rather than promising every buyer the same final price.
- Canonical charge times use exactly 10–80%. Published station ratings remain station ratings: ELEXIO's 122 kW battery output is not a vehicle DC charging peak, and IONIQ 9's 350 kW figure describes the charger. Unpublished vehicle acceptance stays an honest gap or source-labelled secondary claim. Exact published times retain charging conditions as qualifications without automatic grade downgrades.
- Cargo keeps the published method and load state. ELEXIO's 506 L seats-up VDA specification conflicts with a 504 L web teaser; both are documented. IONIQ 9's minimum is 338 L behind the third row, distinct from 908 L with the third row folded. Minimum/maximum values without a stated seating/load method remain unranked. Frunk and underfloor volumes are not added to rear luggage space.
- Hyundai's standard private cover is five years/unlimited km; the extension up to seven years requires qualifying first registration and authorised-dealer servicing. HV battery cover is eight years/160,000 km with a conditional below-70% SOH remedy. Commercial-use, component and competition exceptions remain explicit. The N non-competitive track-day clarification does not cover racing or timed competition.
- Current EV-specific roadside terms provide 24 months initial assistance and qualifying service renewals. Included towing requires vehicle weight strictly below 2,500 kg at breakdown. IONIQ 9's minimum published kerb mass already exceeds that boundary, so its version-specific roadside fact makes driver-paid towing explicit. Generic 12-month page copy is retained as conflict context rather than overriding the EV policy.

## Outstanding research closure

Carsales OAG-AD-25622863 is an indexed MY26 IONIQ 9 six-seat New lead in Ionosphere Green. The index was crawled last month and does not establish its current status. Its seller, stock number and VIN are not established; no similar Nocturne Grey vehicle is joined to it. The exact page is CAPTCHA-protected and specific approval remains pending. No CAPTCHA was attempted, and the lead is neither admitted nor falsely marked sold/absent.

The typed reconciliation deliberately leaves the inherited IONIQ 9 model resolution open. Sound data for the 21 established versions can be reviewed independently of brand research closure. No next-brand progression or Hyundai research-complete claim is made.

## Validation status

The final full stage passes before/source/identity/dependency guards, canonical equipment propagation, citable/portable parity and immutable-input/other-brand checks, including the final availability corrections. Independent actual data.ts replay and negative-drift review also pass. This covers 5,314 citable facts, 844 guarded equipment rows, 886 total reviewed feature projections and portable deep equality. Fact, identity, source, availability, shared-term, equipment, summary and exact-dependency drift tests reject stale input. Independent checks verify all 85 original data files remain unchanged. All 21 versions have both summaries; aged/invalid claims and unreviewed core grades are zero.

ResearchCompleted remains false with one current-version/known-model disposition open. The report's missingModels and unresolvedLeads counters are both zero because this retained blocker is represented by the inherited IONIQ 9 record, not a newly fabricated lead ID; closureIssues explicitly contains inventory_unresolved for record:hyundai-ioniq-9. No zero-counter completion claim is made.

Strict criteria are C1 false, C2 false, C3 true, C4 true, C5 false and C6 true. C2 has 21 honest null gaps: nine DC vehicle-peak fields, six acceleration fields and six braked-towing fields. Every one has a completed source-labelled review. All 21 exact-window charging-time fields are published. C5 ranking eligibility remains 15/21 for price, 5/21 for seats, 5/21 for cargo and 15/21 for towing; secondary/dealer evidence and method-incompatible values remain unranked. Range and exact-window DC time rank for 21/21. Both independent model directories are complete Hyundai brand lists, not two whole-market published lists; they do not close global C1.

## Approved packet hashes

- `hyundai-2026-10-14.json`: `99d93286d74881a571bd7b544c242bacd486c8800f5c19c8e747bf117f7a0d28`
- `hyundai-reconciliation-2026-10-14.json`: `aa45114f3aa6fbd7153d5ce87970060a6b0dc6b0de274fb923a610e74f661be4`

Approval is for factual guarded integration only. Hyundai research completion is withheld for the exact unresolved lead described above. The final source index has 151 source snapshots and 387 hashed full capture/extraction/visual/search files. The independent audit and machine-readable decision are separate review artifacts; the closing artifact manifest is checked again after this document is frozen.

## Deliverables

- `hyundai-2026-10-14.json`: guarded data packet
- `hyundai-reconciliation-2026-10-14.json` and `brand-model-list-reconciliation.json`: exact cohort and directory decisions, with the unresolved lead retained
- `core-matrix.json`: 17 reviewed fields for every established version, including source URLs, units, basis, grades and limitations
- `source-index.json`, `source-hash-manifest.json` and `artifact-hash-manifest.json`: capture locators and exact hashes
- Family normalized evidence, numeric/source audits, original-dealer and inherited-lead dispositions, and full permitted captures under the three family folders
- `ioniq9-sixseat-lead/closure.json`: bounded exact-ad search result and remaining evidence/permission requirement

Failed, redirected, blocked and restricted responses remain documented. Publication dates are not guessed from retrieval dates, model-year filenames or future footers. Original research and other brands remain immutable.
