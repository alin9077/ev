import json,pathlib,hashlib
B=pathlib.Path('/tmp/hyundai-research/inster-kona');p=B/'normalized-evidence.json';d=json.load(open(p));changes=[];equipment=[]
for v in d['variants']:
 for f in v['facts']:
  if ('charge_time' not in f['key'] and 'charging_time' not in f['key']) or f['grade']!='check' or f['key'].startswith('option_'):continue
  old=f.get('condition','')
  f['grade']='confirmed'
  if f.get('status')=='conditional':f['status']='standard'
  if old:
   f.setdefault('qualifications',[])
   if old not in f['qualifications']:f['qualifications'].append(old)
  f.pop('condition',None)
  f['reason']='Exact Australian maker timing is Confirmed for its explicitly stated supply and state-of-charge window. Station rating and laboratory/usage caveats qualify the test claim without lowering its grade. The result is not a promise of real-world speed or a different supply.'
  changes.append({'variantId':v['id'],'key':f['key'],'oldGrade':'check','newGrade':'confirmed'})
 for f in v['features']:
  if f['criterion']!='home_charging' or f['grade']!='check':continue
  # This mixed row explicitly states published AC timing and that the separate 7 kW timing is not published.
  # It does not claim the quoted source time is a 7 kW wallbox measurement.
  f['grade']='confirmed';f['status']='standard'
  f['reason']='The row accurately reports the maker AC maximum and source-scoped 240 V 10–100% timing, while explicitly identifying the separately searched 7 kW timing as Not published. Stated test supply is retained as a qualification rather than an automatic Check downgrade; no 7 kW duration is inferred.'
  equipment.append({'variantId':v['id'],'criterion':f['criterion'],'oldGrade':'check','newGrade':'confirmed'})
d['finalGradingReview']={'reviewedAt':'2026-10-14','reason':'Generic station/laboratory/usage qualifications do not reduce exact maker timing grades. Genuine N Line optional-configuration timing facts remain Check.','facts':changes,'features':equipment}
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
vp=B/'validation.json';val=json.load(open(vp));val['finalGradingReview']=d['finalGradingReview'];vp.write_text(json.dumps(val,ensure_ascii=False,indent=2)+'\n')
mp=B/'research-summary.md';s=mp.read_text();note='\n## Final grade review\n\nExact maker charging times are Confirmed for their published station/supply and SOC window. Eight previously Check timing facts were corrected, along with seven mixed home-charging equipment rows. Station, test and unspecified phase/current qualifications remain, and the independent 7 kW timing gap remains Not published. Four Premium N Line optional-configuration timing facts remain Check.\n';
if '## Final grade review' not in s:mp.write_text(s+note)
M=[]
for f in sorted(B.rglob('*')):
 if f.is_file() and f.name!='manifest.json':M.append({'path':str(f),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(B/'manifest.json').write_text(json.dumps(M,indent=2)+'\n')
print('Corrected facts:',len(changes),'equipment:',len(equipment));print('Normalized SHA256:',hashlib.sha256(p.read_bytes()).hexdigest())
for v in d['variants']:
 remaining=[f['key'] for f in v['facts'] if ('charge_time' in f['key'] or 'charging_time' in f['key']) and f['grade']=='check'];
 if remaining:print('Retained genuine optional Check:',v['id'],remaining)
