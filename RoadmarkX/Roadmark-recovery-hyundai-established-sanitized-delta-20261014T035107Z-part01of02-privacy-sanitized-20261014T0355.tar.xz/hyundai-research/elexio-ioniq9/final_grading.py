"""M1 correction: operating conditions qualify an exact maker claim, not its evidence grade."""
import copy
CHARGE_KEYS={'dc_charge_time_min','ac_charge0to100_at7_kw','ac_charge10to100','dc_charge10to80_at50_kw','dc_charge10to80_at150_kw','dc_charge10to80_at350_kw'}
TOW_KEYS={'towing_braked_kg','towing_unbraked_kg','towball_maximum'}
def correct(packet):
 changes=[]
 for v in packet['variants']:
  changed=set()
  for f in v['facts']:
   charging=f['key'] in CHARGE_KEYS
   towing=v['model']=='ELEXIO' and f['key'] in TOW_KEYS
   if f['grade']!='check' or not (charging or towing):continue
   f['grade']='confirmed'
   condition=f.pop('condition',None)
   if condition and condition not in f['qualifications']:f['qualifications'].append(condition)
   f['reason']=('Exact Australian maker-published charging time at the stated supply rating and state-of-charge window. Lab, battery-temperature and supply caveats qualify use of the figure; they do not weaken its evidence grade.' if charging else 'Exact Australian maker-published towing or towball limit. Required rated towbar equipment and normal load/use limits are retained as qualifications; they do not weaken the evidence grade.')
   changed.add(f['key']);changes.append({'variantId':v['id'],'fact':f['key'],'from':'check','to':'confirmed'})
  facts={f['key']:f for f in v['facts']}
  for row in v['features']:
   if row['grade']=='check' and changed.intersection(row['keys']) and all(facts[k]['grade']=='confirmed' for k in row['keys']):
    row['grade']='confirmed';row['reason']='Exact maker-published facts support this equipment statement. Specified charging supply and state-of-charge window remain explicit operating qualifications, not evidence uncertainty.'
    conditions=[q for k in row['keys'] for q in facts[k].get('qualifications',[]) if ('SOC' in q or 'Timing uses' in q or 'temperature' in q)]
    if conditions:row['conditions']='; '.join(dict.fromkeys(conditions))
    changes.append({'variantId':v['id'],'feature':row['criterion'],'from':'check','to':'confirmed'})
 packet['finalGradingCorrection']={'date':'2026-10-14','scope':'Exact published charging-time claims and ELEXIO rated towing limits; qualifications preserved; genuine conflicts, options, sibling and secondary evidence unchanged.','changes':changes}
 return packet
