import json,copy,pathlib,hashlib,re,collections
D=pathlib.Path('/tmp/hyundai-research/elexio-ioniq9');B=json.load(open('/tmp/hyundai-research/before.json'));F=json.load(open('/tmp/hyundai-research/features-before.json'));S=json.load(open(D/'sources.json'))
DATE='2026-10-14';scope=[b for b in B if b['model'] in ['ELEXIO','IONIQ 9']]
TERMS={'warranty','battery_warranty','roadside_assistance','vehicle_warranty_standard','vehicle_warranty_conditional_extended','vehicle_warranty_commercial','battery_warranty_terms','battery_warranty_capacity_threshold','roadside_support_initial'}
sourceMap={s['key']:s for s in S}
for s in S:
 s['supports']=['Australian named-version technical/equipment evidence' if 'specs' in s['key'] else 'Named-version public listing or current model scope'];s['textSha256']=hashlib.sha256(pathlib.Path(s['textFile']).read_bytes()).hexdigest()
 if 'carexpert' in s['key'] or 'carsales_review' in s['key']:s['source_type']='secondary';s['supports']=['Published Australian editorial technical figures; Reported only']
 if any(w in s['key'] for w in ['keema','werribee','mackay','gilbert','hopper','sydney_','essendon']):s['source_type']='dealer'
 if s['key']=='ioniq9_german_specs':s['market']='CZ';s['source_type']='manufacturer';s['supports']=['Foreign sibling specification; not Australian exact-version evidence']
 if s['status']!=200:s['supports']=[];s['note']='Failed or blocked fetch; capture retained as search-limit evidence only, never factual support.'
 if s.get('sameAsPrevious'):s['note']='Fresh 14 October 2026 HTTP retrieval is SHA256-identical to the preserved 10 October 2026 source. Original exact-column row locators remain applicable; this is a new observation, not an edited old source.'
 if s['key']=='ioniq9_specs_my26':s['title']='Hyundai Australia IONIQ 9 original MY26-era specification, DSM optional';s['published_date']=None;s['note']='Original Australian launch-era PDF; metadata creation date 12 August 2025, not an asserted publication date. Unlike MY27 file it includes optional Digital Side Mirrors. Read 14 October 2026 for separately admitted residual MY26 identity.'
 if 'specs' in s['key']:
  s['visualReviewPages']=[1,2,5,6] if s['key']!='elexio_specs' else [1,2,5,6]
  s['technicalScope']='AU named grade and explicitly merged range rows'

def sourcekeys(old):return [s.removeprefix('r10_hy_') for s in old]
def fact(k,val,src,basis='',comparison='',grade='confirmed',reason='',condition='',qualifications=None,**extra):
 f=dict(key=k,value=val,sourceKeys=src,grade=grade,basis=basis,comparison=comparison,reason=reason or ('Current Australian maker source explicitly supports this named version or merged range row.' if grade in ['confirmed','check'] else 'Published secondary or sibling evidence; shown as Reported and excluded from numerical rankings.'),qualifications=qualifications or [])
 if condition:f['condition']=condition
 f.update(extra);return f

def npfact(k,src,reason,label=None,unit=None):
 f=fact(k,None,src,'Not published after review of two distinct relevant sources','',grade='not_published',reason=reason)
 if label:f['label']=label
 if unit:f['unit']=unit
 return f

def inherited(a):
 out={}
 for k,o in a['facts'].items():
  if k in TERMS or o['value'] is None:continue
  sk=sourcekeys(o['sourceIds']);assert all(s in sourceMap for s in sk),(k,sk)
  quals=[q for q in o.get('qualifications',[]) if not q.startswith('sourceId:') and not any(t in q for t in ['Current-linked technical sheet only','epoch','delivered VIN','actual driving range','Laboratory WLTP claim'])]
  ptr='; '.join(q for q in o.get('qualifications',[]) if q.startswith('sourceId:'))
  grade='reported' if any(sourceMap[s]['source_type'] not in ['manufacturer'] for s in sk) else 'confirmed'
  basis=o['basis']
  if any(t in basis for t in ['visually','Visually','Exact named','Exact column','Exact grade','Exact current']):basis='Australian maker exact-grade or explicitly shared specification row'
  ff=fact(k,copy.deepcopy(o['value']),sk,basis,'',grade=grade,reason='Freshly retrieved source supports the unchanged original exact-version row; source locators retained. Grade reviewed under M1 without generic model-year or delivered-build penalty.',qualifications=quals,label=o['label'],unit=o.get('unit',''),sourcePointer=ptr)
  if k.startswith('equipment_'):
   ff['sourcePointer']=ptr;ff['reason']='Fresh current Australian equipment matrix is byte-identical to the previously audited capture; exact named-grade/seat column and published standard/unavailable/optional cell retained.'
  if o.get('status') in ['unavailable','optional','not_applicable']:ff['fitment']=o['status']
  out[k]=ff
 return out

# Core basis labels, conservative scopes, and concrete conditions are set explicitly.
def common(a):
 e=a['model']=='ELEXIO';name='elexio' if e else 'ioniq9';sp='elexio_specs' if e else 'ioniq9_specs_my27';page=name+'_page';ix=0 if ('base' in a['id'] or '_7_seat' in a['id']) else 1
 d=inherited(a)
 def put(k,v,src=None,basis='',comp='',grade='confirmed',condition='',reason='',**kw):d[k]=fact(k,v,src or [sp],basis,comp,grade,reason,condition,**kw)
 put('drive','FWD' if e else 'AWD',[name+'_configurator',sp],'Driven wheels for exact AU configuration','Drive type')
 put('drive_type','FWD' if e else 'AWD',[name+'_configurator',sp],'Driven wheels for exact AU configuration','Drive type')
 put('range_km',562 if e and ix==0 else 546 if e else 600,[sp],'WLTP combined range for standard named-grade wheels','WLTP')
 put('battery_kwh',88.1 if e else 110.3,[sp],'Manufacturer-stated battery capacity; gross/usable not specified','Published capacity, gross/usable unspecified')
 for k in ['battery_gross_kwh','battery_usable_kwh']:
  d[k]=npfact(k,[sp,page],'The current Australian specification and live model page state nominal capacity without establishing this gross/usable subdivision; no inference from nominal energy.')
 t=38 if e else 24;kw=150 if e else 350
 cond=f'Maker timing uses a {kw} kW DC station at the stated 10–80% state-of-charge window; battery temperature, electricity supply and charger conditions affect time.'
 put('dc_charge_time_min',t,[sp,page],f'Maker DC 10–80% at a {kw} kW charging station','DC 10–80%','check',cond,qualifications=[f'{kw} kW is station output, not vehicle peak DC acceptance.'])
 put('ac_kw',10 if e else 10.5,[sp],'Maximum onboard AC charging power','AC kW')
 put('dc_peak_kw',150 if e else 233,['elexio_carsales_review' if e else 'ioniq9_carexpert'],'Australian editorial maximum DC vehicle charging rate','',grade='reported',reason=('carsales explicitly describes a maximum 150 kW DC rate. Hyundai AU PDF itself states a 150 kW station and 122 kW battery power-output row; neither maker row is promoted to a vehicle peak.' if e else 'CarExpert Australian Calligraphy road test explicitly publishes maximum DC charge rate 233 kW. Current MY27 maker sheet omits vehicle maximum, so this launch-era family/sibling figure remains Reported and unranked.'),sourcePointer='Battery / charging section: explicit maximum DC charge rate',qualifications=['Secondary maximum is kept separate from maker timed-test station rating.'])
 if e:
  put('seats',5,['elexio_keema_base' if ix==0 else 'elexio_keema_elite'],'Exact New dealer vehicle seating count','',grade='reported',reason='Exact original Keema advertisement explicitly lists five seats. Current maker specification and live page reviewed do not explicitly give a total seat count; dealer-only evidence remains Reported.')
  d['zero_to_100_s']=npfact('zero_to_100_s',[sp,'elexio_carexpert'],'Hyundai Australian specification omits 0–100 km/h; CarExpert explicitly says Hyundai does not quote a time and its EV5 comparison is an estimate, not ELEXIO evidence. No guessed acceleration imported.',unit='s')
  put('boot_l',506,[sp,page],'Rear cargo behind second row; VDA; rear seats in normal use','VDA rear seats up',qualifications=['Technical sheet and model-page cargo section say 506 L; another same-page paragraph says 504 L. Use the dedicated technical specification and retain discrepancy without substituting 504 L.'])
  put('max_total_cargo_l',1540,[sp,page],'VDA maximum rear cargo with rear seats folded','VDA rear seats folded')
  put('frunk_l',0,[sp],'No front cargo compartment: manufacturer dash in Frunk Space row','',qualifications=['Zero denotes no front storage compartment; not a separately measured volume.'])
  put('power_kw',160,[sp],'Manufacturer-published total motor power','Manufacturer combined system output')
  put('height_mm',1695,[sp],'Body height including roof rails','Body mm',qualifications=['Includes roof rails. The 1673 mm height in some dealer data is not substituted.'])
  put('tare_mass_declared',2105,[sp],'Published tare declaration; shared table labels internally questionable','',grade='check',condition='Maker lists 2105 kg tare beside 2080–2105 kg kerb range; retained as a source declaration, not a normalized exact-trim mass.',reason='Fresh technical table retains the potential shared mass-label inconsistency.')
  put('energy_consumption',18.2,[sp],'Combined energy consumption; ADR 81/02 footnote','ADR 81/02 combined',qualifications=['The energy-consumption footnote is ADR 81/02; WLTP range is a separate claim.'])
 else:
  put('seats',7 if ix==0 else 6,[sp],'Manufacturer exact-seat configuration','Seats')
  put('zero_to_100_s',5.2,['ioniq9_carexpert'],'Australian Calligraphy claimed 0–100 km/h, reported by CarExpert','',grade='reported',reason='Australian CarExpert launch-era Calligraphy road test explicitly reports claimed 5.2 seconds; current MY27 sheet omits acceleration, so MY27 carry remains Reported.')
  put('boot_l',338,[sp,page],'Rear cargo behind third row in use, minimum VDA','VDA rear seats up')
  put('max_total_cargo_l',2419,[page],'Maker maximum cargo with second and third rows folded; measurement method not specified in paragraph','',qualifications=['No VDA/SAE method is attached to this maximum in the live paragraph; unranked on cargo measurement basis.'])
  put('frunk_l',52,[page],'Separate front storage; measurement method unspecified','')
  put('power_kw',314,[sp],'Explicit manufacturer Maximum power - total row','Manufacturer combined system output',qualifications=['This is an explicitly published combined total, not an arithmetic sum of motor maxima.'])
  put('energy_consumption',206,[sp],'WLTP combined energy consumption','WLTP Wh/km')
 for k,v in {'length_mm':4615 if e else 5060,'width_mm':1875 if e else 1980,'height_mm':1695 if e else 1790,'wheelbase_mm':2750 if e else 3130,'ground_clearance_mm':160 if e else 174}.items():
  if k=='height_mm' and e:continue
  put(k,v,[sp],'Maker Australian overall body dimension' if k!='ground_clearance_mm' else 'Minimum ground clearance','Body mm',qualifications=['Mirror-inclusive span not established.'] if k=='width_mm' else [])
 towcondition='Requires additional-cost Hyundai genuine towbar and towball fitted by an authorised dealer; obey vehicle, towbar and local limits.' if e else ''
 for k,v in [('towing_braked_kg',1250 if e else 2500),('towing_unbraked_kg',750),('towball_maximum',100 if e else 125)]:put(k,v,[sp],'Manufacturer towing limit','Braked towing kg' if k=='towing_braked_kg' else '',grade='check' if e else 'confirmed',condition=towcondition,qualifications=['Occupants, luggage, accessories and towball load must remain within all vehicle and axle limits; maximum payload and towing are not asserted simultaneously.'])
 d['kerb_weight_kg']=npfact('kerb_weight_kg',[sp,page],'Maker specification and model page publish a broad family kerb range, not an exact seating/grade kerb figure. Tare is not silently substituted.')
 for k in ['digital_key']:
  if k in d:d[k]['grade']='check';d[k]['condition']='Requires a compatible mobile device, Bluelink app installation and an active Bluelink subscription.';d[k]['qualifications']+=['Convenience aid, not a permanent physical-key replacement.']
 if 'portable_charge_time_source_declaration' in d:
  d['portable_charge_time_source_declaration']['grade']='check';d['portable_charge_time_source_declaration']['condition']='Source declaration is internally inconsistent with domestic 230 V / 12 A cable rating; do not use the 10-hour / three-phase 16 A text as a portable-charge expectation.';d['portable_charge_time_source_declaration']['reason']='Preserved conflicting maker declaration, not a resolved charging specification.'
  d['portable_charge_time_min']=npfact('portable_charge_time_min',[sp,page],'Maker portable-charge row is internally inconsistent; neither reviewed source resolves a domestic-cable charge time. No rate calculation substitutes for a published result.',unit='min')
 # All raw equipment cells are current exact model-year. Compatibility is an operating condition, not uncertain fitment.
 for k,ff in d.items():
  if k.startswith('dc_charge10to80_'):
   ff['grade']='check';ff['condition']='Published 10–80% timing requires the stated DC station rating and suitable battery, supply and temperature conditions; actual time can vary.'
  if k.startswith('equipment_') and any(q in k for q in ['digital_key','wireless_charg']):ff['qualifications']+=['Requires compatible device; equipment fitment itself is confirmed by the matrix.']
 price=json.load(open(D/'sources'/f'{name}_price_{ix}.json'))
 put('price_aud',price['mlpFromPIM'],[f'{name}_price_{ix}',name+'_configurator'],'Manufacturer consumer list price before on-road costs','Before on-road costs',reason='Current exact variant price API separates consumer mlpFromPIM from pre-LCT calculation mlp and on-road charges. Use the consumer MLP field; never add raw calculation inputs or present pre-LCT mlp as retail.',priceRung=1,basisTag="Maker's list price",sourcePointer='mlpFromPIM',rankingEligible=True)
 daprice=price['finalDriveAwayPrice'];dacond=('Eligible new stock without options, purchased and delivered 1 October–31 December 2026 at participating Hyundai dealers; excludes fleet, government, rental and combined offers.' if e else 'Illustrative NSW postcode 2000 estimate for default paint/interior and no added options; actual buyer circumstances and dealer delivery can change on-road costs.')
 put('promotional_driveaway_aud',daprice,[f'{name}_price_{ix}',name+'_configurator'],'National maker driveaway campaign' if e else 'Maker NSW driveaway estimate, no options','Driveaway',grade='check',condition=dacond,priceRung=2 if e else 4,basisTag="Maker's national driveaway offer" if e else "Maker's NSW driveaway estimate",rankingEligible=True,sourcePointer='finalDriveAwayPrice; offerPackages target National' if e else 'finalDriveAwayPrice; postCode 2000',state=None if e else 'NSW',validUntil='2026-12-31' if e else None,qualifications=[] if e else ['Not a promotion: dealerDiscount is zero; generated expiry metadata does not establish an offer deadline.'])
 if not e:
  d['price_aud']=copy.deepcopy(d['promotional_driveaway_aud']);d['price_aud']['key']='price_aud';d['price_aud']['sourceKeys'].append('ioniq9_calculator_rendered'+('7' if ix==0 else '6'));d['price_aud']['reason']='Rendered maker calculator explicitly displays this estimated NSW driveaway total. The visible MLP line is pre-LCT, and the unlabelled consumer meaning of mlpFromPIM is not assumed. No higher-rung full retail total established.'
  d['price_aud']['sourcePointer']='Expanded price breakdown: Estimated drive away price; [D] conditions; API postCode 2000'
 alias='current_driveaway_campaign' if e else 'official_driveaway_estimate_postcode2000';d[alias]=copy.deepcopy(d['promotional_driveaway_aud']);d[alias]['key']=alias
 return d

def equipment(a,d,legacy=False):
 e=a['model']=='ELEXIO';ix=0 if ('base' in a['id'] or '_7_seat' in a['id']) else 1;out=[]
 def add(c,v,ks,grade=None,cond='',status=None):
  if any(k not in d for k in ks):raise ValueError((c,ks))
  grades={d[k]['grade'] for k in ks};g=grade or ('reported' if 'reported'in grades else 'check' if 'check'in grades else 'confirmed')
  if g=='check' and not cond:cond='; '.join(dict.fromkeys(d[k].get('condition','') for k in ks if d[k].get('condition')))
  r=dict(criterion=c,value=v,keys=ks,grade=g,conditions=cond,reason='Fresh review binds each statement to its exact post-review source-backed facts.')
  if status:r['status']=status
  out.append(r)
 auto=next(k for k in d if k.startswith('equipment_') and 'auto_comfort_control' in k)
 for c,k in [('front_heated_seats','heated_front_seats'),('front_ventilated_seats','ventilated_front_seats'),('heated_steering_wheel','heated_steering_wheel')]:add(c,'Standard' if d[k]['value'] else 'Not available',[k],status=None if d[k]['value'] else 'unavailable')
 add('automatic_seat_climate','Automatic driver-seat heating/ventilation and heated-steering-wheel control' if d[auto]['value']=='standard' else 'Not available',[auto],status=None if d[auto]['value']=='standard' else 'unavailable')
 if not e:add('rear_heated_seats','Heated second-row outboard seats',['heated_second_row_outboard_seats'])
 add('adas_standard',', '.join(d['adas_standard']['value']),['adas_standard'],cond='Driver-assistance systems require attentive driving and have operating limits.')
 add('safety_ancap',f"5-star ANCAP ({2024 if e else 2025} protocols): adult {88 if e else 84}%, child 86%, vulnerable road users 77%, safety assist 85%",['ancap_rating','ancap_scores'],grade='reported',cond='Independent ANCAP assessment and applicability dates; Reported under M1 maker-source grading.')
 add('storage','506 L VDA behind the second row; 1540 L VDA with rear seats folded; no front cargo compartment' if e else '338 L VDA behind the third row; 908 L VDA behind the second row; 52 L separate front compartment',['boot_l','max_total_cargo_l','front_cargo_compartment'] if e else ['boot_l','cargo_behind_second_row','frunk_l'],cond='ELEXIO dedicated specification says 506 L; conflicting 504 L introductory web copy is not used.' if e else 'Front storage method not separately stated; front and rear volumes are not added.')
 add('carplay_android_auto','Wired and wireless Apple CarPlay and Android Auto',['wired_wireless_car_play_android_auto'])
 add('energy_use','18.2 kWh/100 km combined, ADR 81/02' if e else '206 Wh/km combined, WLTP',['energy_consumption'])
 add('battery_chemistry',str(d['battery_chemistry']['value']),['battery_chemistry'])
 home='ac_charge0to100_at7_kw' if e else 'ac_charge10to100';cond='Timing uses 7 kW AC supply and 0–100% SOC.' if e else 'Timing uses 10.5 kW AC supply and 10–100% SOC; this is not a 7 kW home-charge estimate.'
 d[home]['grade']='check';d[home]['condition']=cond+' Battery, supply and ambient conditions affect time.'
 add('home_charging','Up to 10 kW AC; approximately 13 hours 0–100% on 7 kW supply' if e else 'Up to 10.5 kW AC; approximately 10 hours 10–100% at 10.5 kW',['ac_kw',home])
 add('spare_tyre','Tyre mobility kit; no spare wheel',['tyre_mobility_kit','spare_wheel'] if e else ['spare_wheel_type'])
 add('screens_hud','27-inch infotainment display and head-up display' if e else '12.3-inch infotainment, 12.3-inch instrument display and head-up display',['infotainment_screen','head_up_display'] if e else ['infotainment_screen','instrument_cluster','head_up_display'])
 add('audio_system','Six speakers' if e else 'Bose 14-speaker audio with external amplifier',['speaker_count'] if e else ['audio'])
 add('power_tailgate','Standard hands-free power tailgate' if d['power_tailgate']['value'] else 'Not available',['power_tailgate'],status=None if d['power_tailgate']['value'] else 'unavailable')
 add('wireless_charging',f"{d['wireless_phone_charging_pads']['value']} wireless phone charging pad"+('s' if ix else '') if e else 'Cooled wireless phone-charging pad',['wireless_phone_charging_pads'] if e else ['wireless_phone_charging'],cond='Requires a compatible Qi-enabled device or adapter.')
 add('phone_key',str(d['digital_key']['value']),['digital_key'])
 add('app_connectivity','Bluelink connected services',['bluelink'],cond='Bluelink functions require activation, mobile coverage and compatible device; see applicable service term.')
 if e:
  add('v2l','Interior V2L socket; maker maximum 250 V / 16 A / 4 kW',['v2l_output_declared','v2l_interior_outlet'])
  add('child_seats','Two ISOFIX and three top-tether anchor points',['isofix_count','top_tether_count'])
  add('charging_cable','Portable emergency charging cable is not standard',['portable_emergency_cable'],status='unavailable')
  add('folding_mirrors','Heated power-adjustable and power-folding exterior mirrors',['heated_power_folding_exterior_mirrors'])
  add('camp_utility_mode','Camping mode',['camping_mode'])
 else:
  add('heat_pump','Standard heat-pump system',['heat_pump'])
  add('glass_roof','Panoramic sunroof with opening front panel, fixed rear panel and power sunshade',['panoramic_sunroof'])
  add('v2l','Exterior V2L adaptor supplied; Australian output rating not established',['v2l_exterior_adapter','v2l_power'])
  add('child_seats',f"Second row: two ISOFIX and {d['second_row_top_tether_count']['value']} top tethers; third row: two ISOFIX and two top tethers",['second_row_isofix_count','second_row_top_tether_count','third_row_isofix_count','third_row_top_tether_count'])
  add('folding_mirrors','Power-folding exterior mirrors',['power_folding_exterior_mirrors'])
  add('ota_capability_scope','Over-the-air update capability',['ota_updates'],cond='Subject to connectivity; published capability does not promise future features.')
 return out

variants=[]
for a in scope:
 d=common(a)
 if a['model']=='IONIQ 9':
  # Preserve a reviewed null for the missing V2L rating used by mixed equipment prose.
  d['v2l_power']=npfact('v2l_power',['ioniq9_specs_my27','ioniq9_page'],'The current Australian sheet and page establish exterior adaptor fitment but neither states an exact AU V2L maximum power rating.',unit='kW')
 v=dict(id=a['id'],model=a['model'],trim=a['trim'],modelYear=a['year'],drive=a['drive'],metadata={},metadataReason='Existing identity agrees with fresh current maker PDF/calculator; unchanged source bytes and exact named-grade scope reviewed.',identitySourceKeys=['elexio_specs','elexio_configurator'] if a['model']=='ELEXIO' else ['ioniq9_specs_my27','ioniq9_configurator'],availability=dict(state='current_or_order_listed',buyerState='On sale now',sourceKeys=['elexio_page','elexio_configurator'] if a['model']=='ELEXIO' else ['ioniq9_page','ioniq9_configurator'],orderStatus='listed_unconfirmed',stockStatus='unverified',qualifications=['Current official named configuration and active public price/colour selection establish current listing. No accepted order, allocation or physical inventory verification.'],reason='Active maker configuration, not just a surviving disabled or empty API record.'),facts=list(d.values()),features=equipment(a,d))
 v['facts']=list(d.values())
 if a['model']=='ELEXIO':
  v['availability']['sourceKeys']+=['elexio_keema_base' if 'base' in a['id'] else 'elexio_keema_elite'];v['availability']['stockStatus']='new_stock_listed';v['availability']['qualifications']+=['Exact Keema New advertisement checked separately; advertisement is not a physical-stock check.']
  isbase='base' in a['id'];v['summary']=dict(strength=dict(label='Long-range family SUV',text=f"The {562 if isbase else 546} km WLTP range and 506 L VDA boot provide a useful combination of distance and luggage space.",keys=['range_km','boot_l']),tradeoff=dict(label='Comfort features omitted' if isbase else 'Longer charging stops',text='The base grade omits heated and ventilated front seats and a power tailgate.' if isbase else 'Its stated 10–80% DC stop takes around 38 minutes using a 150 kW station.',keys=['heated_front_seats','ventilated_front_seats','power_tailgate'] if isbase else ['dc_charge_time_min']))
 else:
  seats=a['facts']['seats']['value'];v['summary']=dict(strength=dict(label='Three-row flexibility',text=f"{seats} seats and 2500 kg braked towing suit larger groups and a braked trailer.",keys=['seats','towing_braked_kg']),tradeoff=dict(label='Large footprint',text='At 5060 mm long and 1980 mm wide, it needs a generously sized parking space.',keys=['length_mm','width_mm']))
 variants.append(v)

# Residual MY26 is a new identity, with original-era Australian evidence. Never inherit MY27 confirmation blindly.
base=next(v for v in variants if 'ioniq_9' in v['id'] and '_7_seat' in v['id']);new=copy.deepcopy(base)
new['id']='hyundai_ioniq_9_my26_calligraphy_awd_7_seat__20261014';new['new']=True;new['isNew']=True;new['modelYear']=2026;new['modelId']='hyundai_ioniq_9_current';new['generation']='ME.V1 MY26; residual New advertised identity';new['metadata']={};new['metadataReason']='Fresh original Sydney City Hyundai advertisement explicitly names MY26, seven seats, New, stock 0420429479 and VIN KMHMY815RTA023381. Added separately from current MY27; original-era AU PDF reviewed.';new['identitySourceKeys']=['ioniq9_sydney_0420429479','ioniq9_specs_my26']
new['availability']=dict(state='current_or_order_listed',buyerState='On sale now',sourceKeys=['ioniq9_sydney_0420429479'],orderStatus='listed_unconfirmed',stockStatus='new_stock_listed',qualifications=['Residual MY26 advertised New at Sydney City Hyundai, stock 0420429479, VIN KMHMY815RTA023381, 15 km. This establishes a public New listing, not physical availability or accepted orders.','MY27 current factory configuration does not prove MY26 factory-orderability.'],reason='Exact live original dealer advertisement, including identity and New condition.')
# Include substantive current buyer fields and original-era maker equipment; no duplicate raw equipment history expansion.
oldfacts={f['key']:f for f in new['facts']};nd={}
for k,f in oldfacts.items():
 if k.startswith('equipment_') or k in ['manufacturer_variant_id','official_driveaway_estimate_postcode2000','promotional_driveaway_aud','price_aud']:continue
 z=copy.deepcopy(f);z['sourceKeys']=[('ioniq9_specs_my26' if s=='ioniq9_specs_my27' else s) for s in z['sourceKeys']]
 if 'ioniq9_specs_my26' in z['sourceKeys']:
  z['reason']='Independently rechecked original Australian MY26-era PDF row, not a MY27-only inheritance. Text comparison confirms this exact source claim unchanged; optional DSM is handled separately.';z['sourcePointer']=z.get('sourcePointer','').replace('ioniq9_specs_my27','ioniq9_specs_my26')
 if 'ioniq9_configurator' in z['sourceKeys']:
  if k in ['drive','drive_type']:z['sourceKeys']=['ioniq9_specs_my26'];z['reason']='Original-era maker PDF explicitly identifies AWD.'
  elif k=='battery_conditioning':z['grade']='reported';z['reason']='Current Australian MY27 calculator explicitly supplies battery conditioning; carried as sibling Reported evidence only for MY26.';z['comparison']=''
  else:continue
 if 'ioniq9_page' in z['sourceKeys'] and 'ioniq9_specs_my26' not in z['sourceKeys']:
  # Page now represents MY27. Treat isolated page-only numbers as sibling when retained on residual.
  if z['value'] is not None:z['grade']='reported';z['reason']='Live AU MY27 family page carried to residual MY26 as sibling evidence; not silently Confirmed.';z['comparison']=''
 nd[k]=z
nd['price_aud']=fact('price_aud',119750,['ioniq9_carexpert'],'Published Australian MY26 launch list price, before on-road costs','Before on-road costs',grade='reported',reason='CarExpert Australian launch-era Calligraphy review explicitly gives $119,750 before on-road costs. Residual MY26 is separately advertised New; current MY27 API price is not transplanted.',priceRung=5,basisTag='Reported by CarExpert (MY26 launch list)',publisher='CarExpert',sourcePointer='How much does the Hyundai Ioniq 9 cost? > 2025 Calligraphy AWD',rankingEligible=False,qualifications=['Original publication7August2025; historical launch price-when-new only. Re-accessed14October2026 does not make this a current price. Current exact stock has its own dealer driveaway advertisement.'])
nd['promotional_driveaway_aud']=fact('promotional_driveaway_aud',129836,['ioniq9_sydney_0420429479'],'Exact original dealer New advertisement, Nocturne Grey stock 0420429479','Driveaway',grade='reported',reason='Fresh exact dealer advertisement; no inferred national offer or maker discount.',priceRung=6,basisTag='Dealer ad',publisher='Sydney City Hyundai',sourcePointer='H1 and advertised Drive Away price / NewCondition / stock 0420429479',rankingEligible=False,qualifications=['Specific advertised car; Nocturne Grey paint. Not a national promotion, not an order confirmation.'])
nd['digital_side_mirrors']=fact('digital_side_mirrors','Optional',['ioniq9_specs_my26'],'Original Australian MY26 equipment matrix','',grade='check',condition='Digital Side Mirrors were an extra-cost MY26 option; fitment is not established on stock 0420429479.',fitment='optional')
nd['price_when_new_aud']=copy.deepcopy(nd['price_aud']);nd['price_when_new_aud']['key']='price_when_new_aud'
nd['price_aud']=copy.deepcopy(nd['promotional_driveaway_aud']);nd['price_aud']['key']='price_aud';nd['price_aud']['reason']='Current exact original dealer New advertisement is the highest applicable current-price rung established for residual MY26. Historical launch list price is retained separately and not substituted for current buying cost.'
# Recreate known automatic-climate control fact without copying an opaque MY27 equipment ID.
nd['automatic_seat_climate_equipment']=fact('automatic_seat_climate_equipment','standard',['ioniq9_specs_my26'],'MY26 Australian Auto Comfort Control row')
new['features']=[copy.deepcopy(f) for f in base['features'] if f['criterion']!='automatic_seat_climate']
for f in new['features']:
 if any(k not in nd for k in f['keys']):raise ValueError(('new feature missing',f))
 if any(nd[k]['grade']=='reported' for k in f['keys']):f['grade']='reported';f['conditions']+=' MY26 sibling or secondary scope is explicitly retained.'
new['features'].append(dict(criterion='automatic_seat_climate',value='Automatic driver-seat heating/ventilation and heated-steering-wheel control',keys=['automatic_seat_climate_equipment'],grade='confirmed',conditions='',reason='Original-era AU MY26 matrix explicitly supplies this feature.'))
new['facts']=list(nd.values());variants.append(new)

closure=[dict(model='ELEXIO',currentVersions=['ELEXIO FWD 88.1 kWh','Elite FWD 88.1 kWh'],sourceKeys=['elexio_specs','elexio_configurator'],status='Current family resolved; two versions',residuals='Same MY26 identities cover new base/Elite ads. No separate AWD/dual-motor grade: maker FWD table overrides erroneous brochure prose.'),dict(model='IONIQ 9',currentVersions=['MY27 Calligraphy AWD 7-seat 110.3 kWh','MY27 Calligraphy AWD 6-seat 110.3 kWh'],addedResiduals=['MY26 Calligraphy AWD 7-seat 110.3 kWh'],sourceKeys=['ioniq9_specs_my27','ioniq9_configurator','ioniq9_sydney_0420429479'],status='Current family resolved; residual six-seat lead still blocked',residuals='MY26 seven-seat exact New confirmed. Werribee six-seat DSM N41761 has a redirected/removed original and indexed SOLD page; Phil Gilbert MY26 220621292 Demo. Separate Carsales MY26 six-seat green OAG-AD-25622863 requires direct-status verification before admission.')]
leads=[dict(key='ioniq9_werribee_old6',result='Exact former New URL now redirects to generic /search/new-cars; not proof of current New',sourceKeys=['ioniq9_werribee_old6']),dict(key='ioniq9_hopper_n41761',result='Indexed original-page capture explicitly SOLD, crawl labelled four months ago; fresh direct original URL returns404. No current exact New admission; neither404 nor index-age alone establishes present ownership.',sourceKeys=['ioniq9_hopper_n41761','ioniq9_hopper_sold_web'],stock='N41761',vin='KMHMY815RTA022152'),dict(key='ioniq9_philgilbert_my26',result='New URL redirects to Demo; 2013 km and registration GDH48K; excluded from New',sourceKeys=['ioniq9_philgilbert_my26'],stock='220621292',vin='KMHMY815RTA023389'),dict(key='ioniq9_essendon_demo',result='Current Demo MY27, excluded as residual New evidence',sourceKeys=['ioniq9_essendon_demo']),dict(key='elexio_mackay_elite',result='Current Demo; no new distinct identity',sourceKeys=['elexio_mackay_elite']),dict(key='ioniq9_sydney_0420429479',result='Current exact original New MY26 seven-seat; new catalogue identity admitted',sourceKeys=['ioniq9_sydney_0420429479'],stock='0420429479',vin='KMHMY815RTA023381'),dict(key='ioniq9_carsales_25622863',url=sourceMap['ioniq9_carsales_25622863']['url'],result='Search capture reports MY26 six-seat Ionosphere Green New; exact original retrieval 403 and dot cloud browser DataDome CAPTCHA. No source price/current seller/stock verification. Held, not admitted and not declared absent.',sourceKeys=['ioniq9_carsales_25622863'],blocker='Specific CAPTCHA completion requires authorization; parent notified.')]
conflicts=[dict(id='elexio_dc_source_scope',resolution='122 kW battery power output is not DC peak.150 kW maker station row is not vehicle acceptance. carsales independently publishes maximum150 kW; retained Reported, unranked.'),dict(id='elexio_boot_504_506',resolution='Use dedicated current maker technical506 L VDA and matching cargo section; preserve introductory web504 discrepancy.'),dict(id='elexio_base_seats',resolution='Technical base6-way driver and cloth/no heated seats wins over configurator copied14-way/leather prose.'),dict(id='ioniq9_portable_charge',resolution='Copied portable10hour three-phase16A row conflicts with230V12A domestic cable. Keep portable time unknown; canonical AC10hours explicitly at10.5kW.'),dict(id='ioniq9_price_lct',resolution='Rendered MY27 calculator visibly labels pre-LCT MLP113204.85/114743.31 and separate LCT, but does not display119668/121668 as full consumer RRP. Use explicit NSW estimated driveaway128977.72/131077.71 at rung4. Retain raw API capture; currentMY27 price is not copied to residualMY26.'),dict(id='ioniq9_model_year_dsm',resolution='OriginalMY26 sheet has optionalDSM; currentMY27 sheet omits it. Keep original-year residual identity and equipment source separate.')]
for s in S:
 s['supports']='. '.join(s['supports']) if isinstance(s['supports'],list) else s['supports']

packet=dict(reviewedAt=DATE,familyScope='Hyundai ELEXIO and IONIQ 9 Australian Tier1 M1',sources=S,variants=variants,warrantyHandling='Parent owns current brand warranty, battery warranty, roadside terms and aliases; no duplicate writes here.',targetedSixSeatLeadClosure='/tmp/hyundai-research/ioniq9-sixseat-lead/closure.json',familyClosure=closure,residualLeads=leads,conflicts=conflicts,searchLimits=['Carsales six-seat residual OAG-AD-25622863 exact-page status blocked by DataDome CAPTCHA; no attempt made without permission.','No accepted orders or physical stock checked.'],integrity=dict(inheritedReview='Every non-null effective fact outside parent-owned brand-term fields is freshly mapped, including equipment_* rows. Exact PDF/configurator hashes match prior captures; individual locators preserved.',baseline='/tmp/hyundai-research/before.json',featuresBaseline='/tmp/hyundai-research/features-before.json'))
from final_grading import correct
packet=correct(packet)
from prose_cleanup import clean
packet=clean(packet)
json.dump(packet,open(D/'normalized-evidence.json','w'),indent=2,ensure_ascii=False)
print('Wrote',D/'normalized-evidence.json',len(variants),'variants',len(S),'sources',sum(len(v['facts']) for v in variants),'facts',sum(len(v['features']) for v in variants),'features')
