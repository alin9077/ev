# ELEXIO and IONIQ 9 M1 research handoff — 14 October 2026

Technical and current-price research is ready for parent integration. One residual identity lead remains explicitly unresolved.

- Five admitted identities: ELEXIO MY26 base/Elite; IONIQ 9 MY27 seven/six seats; separately sourced residual-New IONIQ 9 MY26 seven seats.
- Residual New seven-seat: Sydney City Hyundai stock 0420429479, VIN KMHMY815RTA023381, 15 km, original advertisement $129,836 driveaway. This is advertised New, not physically verified stock or accepted factory orders.
- Current IONIQ 9 prices: rendered NSW calculator estimates $128,977.72 seven-seat and $131,077.71 six-seat. The visible MLP excludes separate LCT; API mlpFromPIM is not promoted to an inferred full consumer RRP. The MY26 historical $119,750 launch list is price_when_new_aud, not current canonical price.
- ELEXIO current MLP $58,990 / $61,990; supplemental national driveaway $57,990 / $60,990 under published October–December 2026 conditions.
- Full inherited non-null fact coverage outside parent-owned terms, and known-feature coverage, passed local research validation. Current PDF/configurator originals are fresh captures, byte-identical to the earlier audited versions. No packet guards or repository writes performed.
- DC peak remains secondary Reported; station power is separate. ELEXIO 122 kW battery power output is not charging acceptance. Canonical times are38 min /24 min 10–80% on 150 kW /350 kW stations. Exact maker times are Confirmed, with operating qualifications retained.
- ELEXIO cargo: dedicated technical 506 L VDA behind second row; retain web 504 L conflict. IONIQ 9: 338 L VDA behind third row /908 L behind second row. Unknown-method front/maximum cargo stays unranked.
- Original MY26 IONIQ 9 PDF independently reviewed, including optional Digital Side Mirrors; current MY27 sheet cannot silently confirm changed-MY equipment.
- Phil Gilbert 220621292 is now Demo. Werribee 3848460 redirects generic; matching Hopper N41761 indexed page says SOLD, with current original 404. These are not admitted as current exact New.

## Remaining blocker
Carsales OAG-AD-25622863: last-month indexed New VIC MY26 six-seat Ionosphere Green, December 2025 build /January 2026 compliance. Exact status/seller/VIN remains inaccessible behind DataDome CAPTCHA. Separate resolver exhausted 30 permitted searches without a unique original dealer match. No CAPTCHA attempted, no current New admission, and no inference of sold/withdrawn. Root is seeking narrowly scoped approval.

See normalized-evidence.json, validation.json, sources.json, source captures and sha256-manifest.json in this folder. Detailed targeted lead closure remains /tmp/hyundai-research/ioniq9-sixseat-lead/closure.json. Parent handles all warranty/battery/roadside fields and aliases.

Final M1 grading review: exact published DC/AC charge-time aliases and ELEXIO rated towing/towball figures are Confirmed. Dependent home-charging equipment is Confirmed. The IONIQ 9 portable-time conflict, optional DSM, conditional prices and secondary/sibling claims retain their prior grades.
