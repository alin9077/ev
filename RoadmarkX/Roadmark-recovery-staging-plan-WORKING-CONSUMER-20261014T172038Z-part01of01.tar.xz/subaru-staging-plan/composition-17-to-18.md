# Subaru hypothetical 17-to-18 composition

This separate staging proof preserves the accepted pre-Subaru 16-to-17 derivation and every expected retained value. It does not register Subaru or repair production metadata.

Let P be the actual pinned 17-packet registry ending with final Polestar, Q the unregistered final Subaru candidate, and F the unchanged actual prepareBrandResearch. The accepted complete baseline is the proved value for F(S,P). The raw actual F(F(S,P),[Q]) is preserved with all 14 full-field digests and complete raw metadata bytes. The only derived change is metadata.brand_update_packet_ids, evaluated with the production expression over the explicitly hypothetical ordered P+Q.

The independently reviewed production loop is metadata-independent. Its ordered accumulated models, variants, sources and criteria transformation composes across the boundary. Context projection is checked idempotent on the actual accepted value. Safe-integer added-variant and added-feature counters telescope. The invocation-scoped packet-ID assignment alone requires the explicit hypothetical full-list expression. Raw output is rechecked afterward, and every other field/reference and metadata property/order is unchanged.

The Subaru-specific harness asserts exactly 17 unchanged registered packets, complete accepted IDs equal their prefix, no Subaru registry entry, two candidate identities, 138 newly generated base feature rows, exactly 18 unique chronological hypothetical IDs, and exact candidate ID/date. Complete packet file bytes and production source remain pinned separately. This rule does not draw packet IDs from an expected future result.

Current-stage outputs are new candidate values. Full input immutability and all non-Subaru car/feature equality must hold; independent replay compares every resulting field and pack. No future full-loader parity exists yet. The root's eventual fresh integrated comparison remains a distinct release gate, as does the complete TypeScript check.

Execution requires independent approval of this document and the exact harness hash, accepted-baseline pins, and root's serialized-slot release. This preparation is not approval or evidence that a canonical fixture has been generated.
