"""Fail-closed immutable pins for explicit derived-only Subaru staging.
Preparation only: stage-inputs.json is created and reviewed after baseline acceptance.
"""
import hashlib,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parent
PROOF=pathlib.Path('/tmp/subaru-derived-proof-plan')
REPO=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104')

def file_hash(path):
 digest=hashlib.sha256()
 with pathlib.Path(path).open('rb') as source:
  while chunk:=source.read(262144):digest.update(chunk)
 return digest.hexdigest()

def verify_stage_inputs():
 path=ROOT/'stage-inputs.json'
 manifest_hash=file_hash(path)
 manifest=json.loads(path.read_text())
 assert manifest['schemaVersion']==1
 assert manifest['mode']=='derived-only-subaru-staging'
 assert manifest['asOf']=='2026-10-15'
 assert manifest['registeredPacketCount']==17 and manifest['candidateRegistered'] is False
 assert manifest['candidateId']=='m1-subaru-2026-10-15'
 assert manifest['freshLoaderValidation'] is False and manifest['currentFullTypecheckVerified'] is False
 assert manifest['registryEditsAuthorized'] is False
 pins=manifest['executionInputs']; assert len({p['path'] for p in pins})==len(pins)
 expected={p['path']:p['sha256'] for p in pins}
 for row in pins:
  file=pathlib.Path(row['path']); assert file.is_absolute()
  assert file_hash(file)==row['sha256'],'Pinned stage input changed: '+str(file)
  if 'bytes' in row:assert file.stat().st_size==row['bytes']
 for name in ['stage_inputs.py','build-packet-derived-v2.py']:
  assert str(ROOT/name) in expected,'Missing mandatory stage harness pin: '+name
 artifacts={}
 for key in ['baselineAcceptance','baselineIndex','consumerPhaseManifest','sourceTransitionReview']:
  row=manifest[key]; file=pathlib.Path(row['path'])
  assert expected[str(file)]==row['sha256'],'Artifact must belong to the complete stage pin list: '+key
  artifacts[key]=json.loads(file.read_text())
 acceptance,index,consumer=artifacts['baselineAcceptance'],artifacts['baselineIndex'],artifacts['consumerPhaseManifest']
 assert acceptance['status']=='accepted_derived_only_baseline_for_subaru_staging'
 assert acceptance['acceptedIndexSha256']==manifest['baselineIndex']['sha256']
 assert acceptance['asOf']==index['asOf']=='2026-10-15'
 assert index['schemaVersion']==2 and index['acceptance']=='accepted_derived_only'
 assert index['cars']['rows']==397 and len(index['research'])==14
 assert index['originalSubaruCars']==9 and index['proposedSubaruCars']==11
 assert index['consumerPhaseManifestSha256']==manifest['consumerPhaseManifest']['sha256']
 assert index['reviewedSourceTransitionSha256']==manifest['sourceTransitionReview']['sha256']
 for key in ['freshV2Capture','finalLoaderEquivalence','currentFullTypecheckVerified','subaruRegistrationAuthorized']:assert index[key] is False
 assert consumer['mode']=='derived-only-reviewed-consumer-transition'
 assert artifacts['sourceTransitionReview']['status']=='approved_for_consumer_phase_pin_transition'
 registry=REPO/'data/m1-brand-updates/registry.json'
 assert str(registry) in expected,'Registered prefix must be pinned in its complete original representation'
 assert file_hash(path)==manifest_hash,'Stage pin manifest changed during verification'
 return {'manifestSha256':manifest_hash,'acceptedIndexSha256':manifest['baselineIndex']['sha256'],'baselineAcceptanceSha256':manifest['baselineAcceptance']['sha256'],'sourceTransitionReviewSha256':manifest['sourceTransitionReview']['sha256'],'mode':manifest['mode']}
