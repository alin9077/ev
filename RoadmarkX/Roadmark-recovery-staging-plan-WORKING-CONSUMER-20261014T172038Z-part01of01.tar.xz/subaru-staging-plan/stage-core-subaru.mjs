/** Complete Subaru core application, retaining exact full values by referenced originals plus exact replacements. */
import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
import {roots,readJson,fileHash,readRows,readResearch,locate,digestRows} from '/tmp/subaru-derived-proof-plan/helpers.mjs';
import {StandardRowUtf8Buffer} from '/workspace/scratch/586427eef9f2/roadmark-104-qa/catalogue-snapshot-reuse/standard-row-utf8-buffer.mjs';
import {openSubaruStageInputs,candidateFile,writeCandidate} from './stage-proof-helpers.mjs';
import {composeSubaruResearch,verifyRawOutputUnchanged} from './compose-subaru-research.mjs';
const proof=openSubaruStageInputs(),packetFile=candidateFile('subaru-2026-10-15.json'),packetSha256=fileHash(packetFile),packet=readJson(packetFile),canonicalMeta=readJson(candidateFile('canonical-baseline-meta.json'));
assert.equal(canonicalMeta.stageInputManifestSha256,proof.manifestSha256);assert.equal(canonicalMeta.generationCount,1);assert.equal(canonicalMeta.baselineGenerationCount,1);
const generatedPins=['subaru-2026-10-15.json','canonical-baseline-meta.json',...['canonical','newFeatureFixture','selectedCars','rawMetadata','compositionTransition'].map(key=>canonicalMeta[key].file.split('/').at(-1))].map(name=>({file:candidateFile(name),sha256:fileHash(candidateFile(name))}));
for(const key of ['canonical','newFeatureFixture','selectedCars','rawMetadata','compositionTransition'])assert.equal(fileHash(canonicalMeta[key].file),canonicalMeta[key].sha256);
const cleared=structuredClone(packet);cleared.features=[];assert.deepEqual(cleared,readJson(candidateFile('canonical-packet-original.json')));assert.deepEqual(digestRows([cleared]),canonicalMeta.canonicalDigest);assert.equal(packet.variants.length,2);
const require=createRequire(roots.repo+'/package.json');const {prepareBrandResearch,applyBrandUpdates}=require('./src/lib/brand-updates.ts');
assert.equal(typeof global.gc,'function');global.gc();
let beforeData=await readResearch(proof.index),before=await readRows(locate(proof.index.cars));assert.equal(before.length,397);assert.deepEqual(digestRows(before),{rows:proof.index.cars.rows,bytes:proof.index.cars.bytes,sha256:proof.index.cars.sha256});
const researchDigests=Object.fromEntries(Object.entries(beforeData).map(([key,value])=>[key,digestRows(Array.isArray(value)?value:[value])])),beforeCarHashes=before.map(car=>({id:car.id,brand:car.brand,...digestRows([car])}));
assert.equal(new Set(before.map(car=>car.id)).size,397);
for(const[key,digest]of Object.entries(researchDigests)){const row=proof.index.research[key];assert.deepEqual(digest,{rows:row.rows,bytes:row.bytes,sha256:row.sha256})}
const raw=prepareBrandResearch(beforeData,[packet]),composed=composeSubaruResearch(beforeData,packet,raw),data=composed.data;
let cars=applyBrandUpdates(before,data,[packet]);assert.equal(cars.length,399);assert.equal(new Set(cars.map(car=>car.id)).size,399);assert.deepEqual(cars.map(car=>car.id),[...before.map(car=>car.id),...packet.variants.map(variant=>variant.id)]);
const tier1=car=>!car.vehicleClass||['passenger','ute'].includes(car.vehicleClass),selected=cars.filter(car=>car.brand==='Subaru'&&tier1(car));assert.equal(selected.length,11);
assert.equal(JSON.stringify(selected,null,2)+'\n',fs.readFileSync(candidateFile('canonical-selected-cars.json'),'utf8'),'Final full packet preserves every serialized canonical car field and order');
const oldById=new Map(beforeCarHashes.map(row=>[row.id,row])),carHashes=[];
for(const car of cars){const current=digestRows([car]),old=oldById.get(car.id);if(car.brand!=='Subaru'||!tier1(car)){assert(old);assert.equal(current.sha256,old.sha256,'Complete non-Subaru or lower-tier car equality: '+car.id);assert.equal(current.bytes,old.bytes)}carHashes.push({id:car.id,brand:car.brand,beforeSha256:old?.sha256??null,afterSha256:current.sha256,bytes:current.bytes})}
for(let i=0;i<before.length;i++)assert.deepEqual({id:before[i].id,brand:before[i].brand,...digestRows([before[i]])},beforeCarHashes[i],'Complete original input car unchanged');
assert.deepEqual(Object.keys(beforeData).sort(),Object.keys(proof.index.research).sort());for(const[key,value]of Object.entries(beforeData))assert.deepEqual(digestRows(Array.isArray(value)?value:[value]),researchDigests[key],'Complete original Research unchanged: '+key);
verifyRawOutputUnchanged(raw,composed.rawFieldDigests);assert.equal(fileHash(packetFile),packetSha256);
const selectedFile=writeCandidate('staged-after.json',selected),rawMetadata=writeCandidate('staged-raw-metadata.json',raw.metadata);
beforeData=null;before=null;cars=null;global.gc();console.log('Complete 399-car core application and unchanged-input checks passed; unneeded full-car bindings released',process.memoryUsage());
const buffer=new StandardRowUtf8Buffer();
function writeRows(name,rows){const file=candidateFile(name);assert(!fs.existsSync(file));const fd=fs.openSync(file,'wx'),hash=crypto.createHash('sha256');let bytes=0,count=0;try{for(const value of rows){const row=buffer.encode(JSON.stringify(value)+'\n');let written=0;while(written<row.length){const n=fs.writeSync(fd,row,written,row.length-written);assert(n>0);written+=n}hash.update(row);bytes+=row.length;count++;if(count%50===0)global.gc()}}finally{fs.closeSync(fd)}const sha256=hash.digest('hex');assert.equal(fileHash(file),sha256);assert.equal(fs.statSync(file).size,bytes);return{anchor:'stage',file:'candidate/'+name,rows:count,bytes,sha256}}
const research={};assert.equal(Object.keys(data).length,14);assert.deepEqual(Object.keys(data).sort(),Object.keys(proof.index.research).sort());
for(const[key,value]of Object.entries(data)){const array=Array.isArray(value),digest=digestRows(array?value:[value]),prior=proof.index.research[key];research[key]=digest.sha256===prior.sha256?{...prior}:{...writeRows('staged-research-'+key+'.jsonl',array?value:[value]),array};assert.deepEqual({rows:research[key].rows,bytes:research[key].bytes,sha256:research[key].sha256},digest);global.gc()}
const transition=writeCandidate('staged-composition-transition.json',{...composed.transition,rawMetadata,independentReviewSha256:proof.manifest.compositionReview.sha256});
const rawIndex={schemaVersion:1,mode:'Exact actual one-packet Research result with complete reconstructible values',research:{...research,metadata:{anchor:'stage',file:'candidate/staged-raw-metadata.json',format:'json',array:false,rows:1,bytes:rawMetadata.bytes,sha256:rawMetadata.sha256,serializedRowsDigest:composed.rawFieldDigests.metadata}}};
writeCandidate('staged-raw-research-index.json',rawIndex);
verifyRawOutputUnchanged(raw,composed.rawFieldDigests);for(const row of generatedPins)assert.equal(fileHash(row.file),row.sha256,'Generated input changed: '+row.file);proof.verify();
const index=writeCandidate('staged-storage-index.json',{schemaVersion:1,mode:'Derived-only staged complete values with unchanged baseline references and exact Subaru replacements',asOf:'2026-10-15',research,cars:{mode:'baseline-with-complete-replacements-and-appended-identities',baseline:proof.index.cars,replacements:{anchor:'stage',file:'candidate/staged-after.json',format:'json',sha256:selectedFile.sha256,bytes:selectedFile.bytes,rows:11},newIds:packet.variants.map(v=>v.id),rows:399,carHashes},stageInputManifestSha256:proof.manifestSha256,packetSha256,canonicalBaselineMetaSha256:fileHash(candidateFile('canonical-baseline-meta.json')),freshLoaderValidation:false,currentFullTypecheckVerified:false,candidateRegistered:false});
writeCandidate('staged-core-receipt.json',{status:'passed_pending_actual_pack_and_complete_report_phases',mode:'Actual core brand functions with explicitly reviewed hypothetical registry composition; derived-only',asOf:'2026-10-15',beforeCars:397,afterCars:399,subaruCars:11,newSubaruCars:2,allCompleteInputCarsAnd14ResearchFieldsUnchanged:true,allNonSubaruAndLowerTierCarsExactlyUnchanged:true,allCanonicalSelectedCarsExactlyEqual:true,rawSinglePacketOutputPreserved:true,compositionTransition:transition,storageIndex:index,selectedCars:selectedFile,packetSha256,generatedPins,stageInputManifestSha256:proof.manifestSha256,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()});
console.log('Complete Subaru core phase passed; actual packs, portable, mutations and full report remain pending');
