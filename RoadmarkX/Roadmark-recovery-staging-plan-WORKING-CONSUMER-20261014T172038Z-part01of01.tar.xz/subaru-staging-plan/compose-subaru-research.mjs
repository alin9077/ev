/** Subaru-only, explicitly hypothetical 17→18 staging composition. Never a production metadata repair. */
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {roots,readJson,fileHash,digestRows} from '/tmp/subaru-derived-proof-plan/helpers.mjs';
export function composeSubaruResearch(base,packet,raw){
 const registryFile=roots.repo+'/data/m1-brand-updates/registry.json',registry=readJson(registryFile);
 assert.equal(registry.schemaVersion,1);assert.equal(registry.packets.length,17);assert.equal(new Set(registry.packets).size,17);
 assert.equal(registry.packets.at(-1),'polestar-2026-10-14.json');assert(!registry.packets.some(name=>name.startsWith('subaru-')));
 assert.equal(packet.id,'m1-subaru-2026-10-15');assert.equal(packet.brand,'Subaru');assert.equal(packet.reviewedAt,'2026-10-15');assert.equal(packet.variants.length,2);
 const headers=[];
 for(const name of registry.packets){let full=readJson(roots.repo+'/data/m1-brand-updates/'+name);headers.push({id:full.id,reviewedAt:full.reviewedAt});full=null;global.gc?.()}
 assert.deepEqual(base.metadata.brand_update_packet_ids,headers.map(p=>p.id),'Complete accepted metadata equals the exact registered 17-packet prefix');
 const hypotheticalHeaders=[...headers,{id:packet.id,reviewedAt:packet.reviewedAt}];
 assert.equal(new Set(hypotheticalHeaders.map(p=>p.id)).size,18);
 for(let i=0;i<hypotheticalHeaders.length;i++){const date=hypotheticalHeaders[i].reviewedAt;assert(/^\d{4}-\d{2}-\d{2}$/.test(date));assert.equal(new Date(date+'T00:00:00Z').toISOString().slice(0,10),date);if(i)assert(date>=hypotheticalHeaders[i-1].reviewedAt)}
 const context=base.feature_evidence_variant_context;assert(Array.isArray(context));
 assert.equal(JSON.stringify(context),JSON.stringify(context.map(({id,model_id,record_state,configuration_evidence})=>({id,model_id,record_state,...(configuration_evidence?{configuration_evidence:structuredClone(configuration_evidence)}:{})}))), 'Accepted context projection is idempotent');
 for(const value of [base.metadata.added_variant_count,base.metadata.added_feature_row_count,base.variants.length,base.feature_evidence.length,raw.metadata.added_variant_count,raw.metadata.added_feature_row_count,raw.variants.length,raw.feature_evidence.length])assert(Number.isSafeInteger(value)&&value>=0);
 assert.deepEqual(raw.metadata.brand_update_packet_ids,[packet.id]);
 assert.equal(raw.metadata.added_variant_count,base.metadata.added_variant_count+raw.variants.length-base.variants.length);
 assert.equal(raw.metadata.added_feature_row_count,base.metadata.added_feature_row_count+raw.feature_evidence.length-base.feature_evidence.length);
 assert.equal(raw.variants.length-base.variants.length,2);assert.equal(raw.feature_evidence.length-base.feature_evidence.length,138);
 const productionFile=roots.repo+'/src/lib/brand-updates.ts';assert(fs.readFileSync(productionFile,'utf8').includes('result.metadata.brand_update_packet_ids = packets.map((packet) => packet.id);'));
 const rawFieldDigests=Object.fromEntries(Object.entries(raw).map(([key,value])=>[key,digestRows(Array.isArray(value)?value:[value])]));
 const hypotheticalPacketIds=hypotheticalHeaders.map(p=>p.id),data={...raw,metadata:{...raw.metadata,brand_update_packet_ids:hypotheticalPacketIds}};
 assert.deepEqual(Object.keys(data),Object.keys(raw));assert.deepEqual(Object.keys(data.metadata),Object.keys(raw.metadata));
 for(const key of Object.keys(raw))if(key!=='metadata')assert.equal(data[key],raw[key],'No complete field other than metadata is replaced');
 for(const key of Object.keys(raw.metadata))if(key!=='brand_update_packet_ids')assert.equal(JSON.stringify(data.metadata[key]),JSON.stringify(raw.metadata[key]),'No other metadata property changes');
 assert.equal(Object.keys(raw).length,14);assert.deepEqual(Object.keys(raw).sort(),Object.keys(base).sort());
 return {data,rawFieldDigests,transition:{mode:'Hypothetical Subaru staged composition only; registered 17-packet prefix is unchanged',registeredRegistrySha256:fileHash(registryFile),productionSha256:fileHash(productionFile),registeredPacketIds:headers.map(p=>p.id),hypotheticalPacketIds,rawMetadata:raw.metadata,derivedMetadata:data.metadata,onlyChangedPath:'metadata.brand_update_packet_ids',rawFieldDigests,freshLoaderValidation:false,currentFullTypecheckVerified:false,candidateRegistered:false}};
}
export function verifyRawOutputUnchanged(raw,expected){assert.deepEqual(Object.keys(raw).sort(),Object.keys(expected).sort());for(const[key,value]of Object.entries(raw))assert.deepEqual(digestRows(Array.isArray(value)?value:[value]),expected[key],'Complete raw single-packet result unchanged: '+key)}
