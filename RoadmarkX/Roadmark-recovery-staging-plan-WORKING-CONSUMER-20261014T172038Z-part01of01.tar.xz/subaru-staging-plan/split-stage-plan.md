# Subaru staging after independent derived-baseline acceptance

Prepared 2026-10-15 Australia/Sydney (2026-10-14 UTC). Preparation only. No packet, canonical fixture, application or test has run under this plan.

## Gates
- Require independently accepted complete baseline: 397 exact car values, all 14 Research fields, all five original Subaru files, actual Polestar packs and portable parity, all 27,393 actual feature rows, and both complete dated reports.
- Pin that accepted index, all measured terminal receipts and the reviewed consumer-source transition. Preserve the original 747-pin provenance and every failed attempt; do not reset expectations.
- Root releases the heavy slot explicitly for each serialized phase. No registry or report-loader production edit is part of staging.
- The candidate remains 11 Subaru versions with two new MY27 Solterra identities; residual census gaps remain explicit.
- Fresh normal-loader equivalence and the current complete TypeScript check remain separate gates. Derived replay must not claim either.

## Packet preparation and canonical fixture
- Create versioned scripts outside the frozen research capture. Reuse the frozen normalized facts, terms, reconciliations and exact existing Subaru before files without modifying them.
- Create the initial candidate with the two identities and all final canonical source, price, fact, availability, term and summary content. The original feature-free canonical packet is retained before the first new-version fixture generation.
- Run actual production prepareBrandResearch/applyBrandUpdates on the accepted values. Preserve the complete raw one-packet metadata output.
- Independently verify a separate 17-to-18 composition proof: the accepted 17 IDs equal the whole pinned registry prefix; all 18 are unique and chronological; the candidate is the sole appended packet; the production loop is metadata independent; the added counters telescope; context projection is idempotent; only metadata.brand_update_packet_ids is composed from that explicit packet list. No other field is changed and no general metadata repair is introduced in production.
- Canonical new-version effective features use the actual reviewed createEvidenceConsumers with all fallback loader callbacks throwing. Exactly two new cars and all 138 feature rows are retained, together with complete canonical packet bytes and hash, source/input pins and a generation-count-one receipt.
- Rebuild the final candidate using the retained original feature rows. Its feature-free complete value must equal the full original canonical packet. Any later correction requires a separately retained explicit transition and independent complete diffs, never baseline regeneration to hide a mismatch.

## Serial phase A: full core application
- Low-dependency actual brand-update functions only; do not import data.ts or the consumer module while retaining all 397 baseline cars.
- Read and verify all 397 baseline car rows and all 14 complete Research fields. Apply the final candidate through actual prepareBrandResearch/applyBrandUpdates.
- Assert 399 complete resulting cars, exactly 11 selected Subaru versions, no duplicate IDs, all prior identities preserved except explicitly reviewed metadata transitions, and exact full unchanged non-Subaru/Tier 2/3 values.
- Compare every original input car, all 14 Research fields, the original packet and source artifacts after application for mutation. Preserve full selected 11 cars, exact per-car hashes for the whole population, complete resulting Research field digests and the raw/composed metadata transition.
- Store outputs as references to unchanged accepted JSONLs plus exact changed values, or as a bounded row stream. A partial export is not a completed receipt.

## Serial phase B: canonical and selected actual consumers
- Import only actual createEvidenceConsumers, portable and citable functions. Provide throwing defaults and explicit complete Research plus the 11 proved cars.
- Compare all 138 canonical new-version feature rows to the immutable original fixture. Apply full candidate projections through the actual consumer module compiled with the exact prior registry plus candidate; the production function bodies and guards remain unchanged.
- Verify every full actual pack, fact and feature source closure, every updated citable grade/source ID, equipment semantics, availability flags, and the complete portable roundtrip. All 187 core cells must carry the candidate review.
- Compare all original selected car and Research inputs before/after. Independently exercise negative guards for source/fact/before-value drift, invalid projection dependencies, foreign/secondary promotion, price-basis contradiction, and other-brand mutation. Keep mutation attempts isolated from originals.

## Serial phase C: complete feature/report replay
- Generate actual features for all 399 cars in original catalogue order using the same reviewed consumer factory with the prior registry plus candidate; retain one car at a time, synchronous bounded writes and per-car/full digests.
- Prove all unchanged brands' full features equal the accepted baseline stream, and all 11 Subaru feature sets equal actual selected packs. Exactly 399 x 69 rows are expected.
- Feed every proved car, all current sources and the complete actual feature stream through the actual report loader and coverage builder at as-of 2026-10-15. Add the exact Subaru reconciliation only; preserve every prior reconciliation.
- Retain full staged report, full selected after values, full features and actual packs. Assert Subaru has no unreviewed core fields, missing summaries or aged/invalid claims, while retaining genuine Not published and census gaps.

## Independent completion and release
The independent reviewer must accept every measured terminal, full value equality and negative guard before root considers integration. Root alone owns registry/report integration and final fresh production validation. The Model Y hero is outside all changes. M1 remains open; no M2 work or milestone completion is authorized by this plan.
