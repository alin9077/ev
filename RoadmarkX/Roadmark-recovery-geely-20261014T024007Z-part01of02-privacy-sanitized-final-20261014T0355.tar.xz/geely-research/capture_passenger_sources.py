import urllib.request,concurrent.futures,json,pathlib
from html.parser import HTMLParser
class Text(HTMLParser):
 def __init__(self):super().__init__();self.parts=[];self.skip=0
 def handle_starttag(self,t,a):
  if t in ['script','style','noscript']:self.skip+=1
  if t in ['p','li','h1','h2','h3','tr','td','br','div']:self.parts.append('\n')
 def handle_endtag(self,t):
  if t in ['script','style','noscript'] and self.skip:self.skip-=1
 def handle_data(self,d):
  if not self.skip:self.parts.append(d)
p=pathlib.Path('/tmp/geely-research'); doc=json.load(open(p/'passenger-evidence.json'))
new=[dict(key='ex5_frunk_current',url='https://henryman.net/2026/03/22/2026-geely-ex5-review/',title='2026 Geely EX5 review',publisher='Henry Man, The Connected',kind='independent_au_reviewer',checkedAt='2026-10-14',note='Explicit no frunk under bonnet; review covers updated Extended Range and pricing. Use Reported0, not inferred from maker omission.'),dict(key='ex5_frunk_old',url='https://www.exhaustnotes.com.au/2026-geely-ex5-inspire-car-review/',title='2026 Geely EX5 Inspire review,21January2026',publisher='Exhaust Notes Australia',kind='reputable_au_motoring_publication',checkedAt='2026-10-14',note='Review identifies60.22kWh410km outgoing model; explicit no frunk; boot302/410/1877.')]
doc['sources']+=new
for r in doc['variants']:
 if r['model']=='EX5':
  r['extraFacts']['frunk_l']=0;r['extraFacts']['frunk_grade']='reported';r['extraFacts']['frunk_sourceKey']='ex5_frunk_current' if 'Extended' in r['trim'] else 'ex5_frunk_old'
keys=['ex2_press_price','ex5_price_current','ex5_price_other','ex5_price_old','ex2_seats','ex5_seats','ex5_tow','ex5_tow_second','ex2_tow','ex2_tow_second','ex5_old_dc_time','ex2_dc_second','lineup_carexpert','lineup_carsguide','lineup_carbroker','ex5_future','ex5_current_dealer','ex5_er_inspire_new','ex5_er_complete_new','ex2_current_dealer','outgoing_complete_generic','outgoing_inspire_generic','ex5_frunk_current','ex5_frunk_old']
def fetch(s):
 try:
  with urllib.request.urlopen(s['url'],timeout=25) as r:body=r.read().decode('utf-8','replace')
  h=Text();h.feed(body); txt='\n'.join(t.strip() for t in ''.join(h.parts).splitlines() if t.strip()); path=p/'sources'/f"{s['key']}.txt";path.write_text('URL: '+s['url']+'\nChecked: 2026-10-14\n\n'+txt)
  return s['key'],str(path),len(txt)
 except Exception as e:return s['key'],None,str(e)
res=list(concurrent.futures.ThreadPoolExecutor(max_workers=8).map(fetch,[s for s in doc['sources'] if s['key'] in keys]))
for key,path,n in res:
 if path:next(s for s in doc['sources'] if s['key']==key)['textFile']=path
 print(key,path,n)
(p/'passenger-evidence.json').write_text(json.dumps(doc,indent=2,ensure_ascii=False)+'\n')
