import json, urllib.request, concurrent.futures, pathlib, datetime, hashlib
base=pathlib.Path('/tmp/geely-research/riddara')
sources=[
('riddara-network','https://www.riddara.com/our-network'),
('riddara-newsroom','https://www.riddara.com/newsroom'),
('riddara-original-au-expansion','https://www.riddara.com/newsroom/20240423'),
('riddara-2025-strategy','https://www.riddara.com/newsroom/20250304'),
('riddara-2025-conference','https://www.riddara.com/newsroom/20250225'),
('carexpert-riddara-current','https://www.carexpert.com.au/riddara'),
('carexpert-2024-australia-announcement','https://www.carexpert.com.au/car-news/riddara-chinese-electric-ute-brand-confirmed-for-australia'),
('carsales-phev-only','https://www.carsales.com.au/editorial/details/2026-geely-riddara-rd6-to-be-phev-only-for-australia-149343/'),
('carsales-nz-launch','https://www.carsales.com.au/editorial/details/2026-geely-riddara-rd6-electric-ute-draws-closer-150196/'),
('carsales-v6-2028','https://www.carsales.com.au/editorial/details/v6-hybrid-locked-in-for-new-geely-ute-151856/'),
('geely-artarmon-current-range','https://www.geelyartarmon.com.au/models/'),
('geely-epping-2027-expansion','https://www.geelyepping.com.au/news/geely-auto-australia-accelerates-expansion-with-three-models'),
('geely-nz-riddara-configurator','https://www.geely.nz/configurator/riddara'),
]
def get(s):
 name,url=s
 try:
  r=urllib.request.urlopen(url,timeout=35); b=r.read(); path=base/(name+'.html'); path.write_bytes(b)
  return dict(id=name,url=url,final_url=r.url,status=r.status,checked_at='2026-10-14',retrieved_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),capture=str(path))
 except Exception as e:return dict(id=name,url=url,checked_at='2026-10-14',error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex: results=list(ex.map(get,sources))
(base/'capture_manifest.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
