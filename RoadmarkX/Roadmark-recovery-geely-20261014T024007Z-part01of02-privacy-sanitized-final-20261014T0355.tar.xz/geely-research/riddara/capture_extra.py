exec(open('/tmp/geely-research/riddara/capture_sources.py').read().split('with concurrent.futures.ThreadPoolExecutor')[0])
extra=[
('carexpert-new-ute-2026','https://www.carexpert.com.au/car-news/geely-readying-all-new-plug-in-hybrid-ute-to-rival-ranger-and-hilux-with-australian-development'),
('evcentral-king-kong-2026','https://evcentral.com.au/another-potential-electric-ute-for-australia-geelys-new-riddara-king-kong-ev-takes-aim-at-workhorse-market/'),
('carsguide-nz-launch','https://www.carsguide.com.au/car-news/geelys-2026-shark-6-rivalling-electric-ute-closes-in-on-oz-riddara-rd6-lands-in-new'),
('drivingenthusiast-rd6-exclusion','https://drivingenthusiast.com.au/2026/05/geely-acquires-radar-auto-riddara-rd6-not-likely-for-australia/'),
('riddara-south-africa-launch','https://www.riddara.com/newsroom/20260916'),
]
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex: results=list(ex.map(get,extra))
(base/'capture_extra_manifest.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
