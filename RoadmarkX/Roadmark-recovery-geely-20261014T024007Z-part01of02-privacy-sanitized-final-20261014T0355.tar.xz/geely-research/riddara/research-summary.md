# Geely / Riddara Australian ute eligibility

Checked: 2026-10-14. Scope: current official-new Australian battery-electric utes only. No repository files modified.

## Result

Resolve held lead `geely-riddara-rd6-bev` as **not sold new here**, meaning excluded from the current official Australian new-order BEV catalogue on the evidence checked. Zero eligible Australian Riddara versions were found. Buyer-facing availability, if the held lead remains visible: **Not confirmed**. Do not say globally discontinued: RD6 is currently retailed in New Zealand and other markets.

Suggested one-line reason: **No official Australian new-order offer; current Australian reporting says the existing RD6 is not the local ute solution, while Geely is developing a different future ute. New Zealand sales and earlier export intentions do not establish Australian availability.**

No Australian prices, trims, or 17-core-fact variant records should be created for this excluded lead. This is an eligibility exclusion, not 17 technical gaps; global and NZ figures must not be imported into Australian coverage or rankings.

## Decisive sources

1. **CarExpert current Riddara model catalogue** (secondary Australian model list, checked 14 October 2026)
   - https://www.carexpert.com.au/riddara
   - The page explicitly describes official Australian retail presence as unconfirmed and RD6 as unavailable/pre-launch. Its RD6 badge says “Discontinued”; retain the more accurate local availability explanation rather than infer that manufacturing stopped.
   - Capture: `web-current-absence.json`. Direct HTML request returned 403, but the web reader retrieved the article.

2. **CarExpert, 4 May 2026, Geely readying all-new plug-in hybrid ute** (secondary first-hand interview with Australian manufacturer executive)
   - https://www.carexpert.com.au/car-news/geely-readying-all-new-plug-in-hybrid-ute-to-rival-ranger-and-hilux-with-australian-development
   - Geely Australia managing director Alex Gu discusses a new dual-cab under development and identifies the existing RD6 as unsuitable for the intended Australian proposition. The article distinguishes the future project from the existing car-based electric/PHEV ute. It does not announce an open order book.
   - Capture: `web-critical-reconciliation.json`.

3. **EV Central, 16 September 2026, King Kong EV** (independent Australian publication, recent corroboration)
   - https://evcentral.com.au/another-potential-electric-ute-for-australia-geelys-new-riddara-king-kong-ev-takes-aim-at-workhorse-market/
   - Says no Australian launch for King Kong EV is on the public agenda and repeats that Geely prioritised a new Riddara PHEV over the existing battery-electric RD6. This is also a reason to exclude the newly surfaced King Kong family from current Australian BEV variants.
   - Capture: `web-critical-reconciliation.json`, plus `evcentral-king-kong-2026.html` if capture manifest shows success.

4. **Geely Artarmon current model menu** (Australian authorised dealer, primary retail-network corroboration)
   - https://www.geelyartarmon.com.au/models/
   - Current range lists EX2, EX5 and Starray EM-i. No RD6, Econ or King Kong offer. Absence from one dealer list alone is not conclusive; used with the explicit independent evidence above.
   - Capture: `geely-artarmon-current-range.html`.

5. **Geely Epping reproduction of manufacturer September 2026 product announcement** (Australian dealer-hosted manufacturer material)
   - https://www.geelyepping.com.au/news/geely-auto-australia-accelerates-expansion-with-three-models
   - Reports the 2027 Australian expansion across named SUV/sedan products and includes a current/future model menu with no Riddara ute. This is corroboration only, not a claim that no unannounced model can ever arrive.
   - Capture: `geely-epping-2027-expansion.html`.

## Official evidence and announcement reconciliation

- **23 April 2024 manufacturer release:** https://www.riddara.com/newsroom/20240423
  - Names Australia among planned expansion markets, but gives no Australian retailer, order opening, launch date, price or version list. The release itself labels the described configurations Chinese domestic versions. This explains the later “confirmed for Australia” headlines without treating them as a current Australian offer.
  - Capture: `riddara-original-au-expansion.html` and `web-primary-reconciliation.json`.

- **Current manufacturer global RD6 / Econ pages and network:** https://www.riddara.com/rd6-4wd ; https://www.riddara.com/rd6-econ ; https://www.riddara.com/our-network
  - Establish these are real global products. Retrieved country selectors do not provide an Australian retail link. The network list is visibly incomplete compared with the maker's other launch announcements, so do not use its omission as proof by itself.
  - Captures: `web-global-models.json`, `riddara-network.html`.

- **Current official New Zealand configurator:** https://www.geely.nz/configurator/riddara
  - Lists RD6 Pro and identifies Geely New Zealand / NordEast Vehicle Distributors. It is a genuine NZ offer, not Australian orderability. No NZ pricing or specification has been carried into Australian records.
  - Capture: `geely-nz-riddara-configurator.html`.

- **CarsGuide, 25 August 2025:** https://www.carsguide.com.au/car-news/geelys-2026-shark-6-rivalling-electric-ute-closes-in-on-oz-riddara-rd6-lands-in-new
  - NZ launch coverage includes a Geely Auto Australia spokesperson's statement that no Australian introduction decision had been made. This directly counters reading NZ deliveries as Australian arrival.
  - Capture: `web-current-absence.json` and `web-critical-reconciliation.json`.

- **Carsales, 26 August 2025:** https://www.carsales.com.au/editorial/details/2026-geely-riddara-rd6-electric-ute-draws-closer-150196/
  - Speculates about possible Australian timing/pricing but expressly says Australian arrival is not officially confirmed. Neither speculative Australian prices nor NZ specs qualify as Australian facts.
  - Capture: `carsales-nz-launch.html`.

- **Carsales, 24 April 2026:** https://www.carsales.com.au/editorial/details/v6-hybrid-locked-in-for-new-geely-ute-151856/
  - Reports a future larger hybrid ute, with possible 2028 launch. This is not an orderable RD6 BEV and does not establish Australian launch timing as confirmed.
  - Capture: `carsales-v6-2028.html`.

## Related overseas products

- **RD6 Econ BEV:** No Australian official offer found. Global manufacturer product exists. Manufacturer launch releases concern the Philippines/Thailand/Malaysia/Pakistan and South Africa, not Australia. Use current AU retail/model-list absence plus the maker's market-scoped releases. Do not create Australian trims from those regional lineups.
  - https://www.riddara.com/newsroom/20251008
  - https://www.riddara.com/newsroom/20260916
  - Captures: `web-global-models.json`, `riddara-south-africa-launch.html`.
- **Radar King Kong EV:** Newly surfaced China-market relative; EV Central explicitly says Australian launch is not on the agenda. Exclude from current on-sale AU catalogue. Avoid treating it as a proven exact alias for every RD6 Econ build.
- **RD6 PHEV / future larger hybrid ute:** Outside this BEV catalogue and not evidence for an on-sale RD6 BEV.

## Limitations / rejected evidence

- Geely main Australian website returned a Vercel 403 access denial. Preserved in `geely-correct-headers.txt` and `geely-correct-home.html`. No absence claim is based on an inaccessible page. Parent's passenger researcher independently encountered the same block.
- Search surfaced ccarprice's nominal Australian price, generic service pages, and a 2026 industry brand forecast including Riddara. These do not identify an actual official Australian new-order offer and were not admitted.
- No direct order submission, enquiry, dealer contact, account action, or publishing occurred.
- HTML captures and web reader JSON are source snapshots, not public deliverables. `capture_manifest.json` and `capture_extra_manifest.json` list successes/errors and hashes. Checked date for decisions is 2026-10-14.
