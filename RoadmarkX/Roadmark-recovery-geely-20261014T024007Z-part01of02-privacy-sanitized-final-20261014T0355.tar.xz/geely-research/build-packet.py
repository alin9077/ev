import json,pathlib,hashlib,copy
R=pathlib.Path('/tmp/geely-research'); D='2026-10-14'; PID='m1-geely-2026-10-14'; REVIEWER='Roadmark Geely Australian source review'
cars=json.load(open(R/'before.json')); old={c['id']:c for c in cars}; prior=json.load(open(R/'features-before.json')); effective={c['id']:{} for c in cars}
p={'schemaVersion':1,'id':PID,'brand':'Geely','reviewedAt':D,'reviewedBy':REVIEWER,'sources':[],'models':[],'variants':[],'versionGuards':[],'versionUpdates':[],'facts':[],'features':[],'brandTerms':[],'availability':[],'summaries':[]};sources={}
def source(row):
 k=row['key'];s={'id':PID+'-'+k,'url':row['url'],'title':row['title'],'publisher':row['publisher'],'source_type':row['source_type'],'published_date':row.get('published_date'),'accessed_date':D,'market':'AU','supports':row['supports']}
 for key in ['notes','capture_section']: 
  if key in row:s[key]=row[key]
 if row.get('file'):
  f=R/row['file']
  if f.exists():s['capture_sha256']=hashlib.sha256(f.read_bytes()).hexdigest();s['capture_locator']=row['file']
 p['sources'].append(s);sources[k]=s
terms=json.load(open(R/'terms/evidence.json'))
for s in terms['sources']:source(s)
def ident(c):return {k:c[k] for k in ['id','modelId','brand','model','trim','year','generation','vehicleClass','drive']}
for c in cars:p['versionGuards'].append({'variantId':c['id'],'before':ident(c)})
meta={
'price_aud':['Price','AUD','Before on-road costs'], 'range_km':['Range','km','WLTP'], 'battery_kwh':['Battery capacity','kWh','Battery capacity; gross/usable unspecified'], 'dc_peak_kw':['DC peak charging','kW','Peak DC power'], 'dc_charge_time_min':['DC 10–80% charge time','min','10–80%'], 'ac_kw':['AC charging power','kW','Maximum AC input'], 'seats':['Seats','','Seating capacity'], 'boot_l':['Boot volume','L','Rear luggage; seats up; method unspecified'], 'zero_to_100_s':['0–100 km/h','s','0–100 km/h'], 'power_kw':['Motor power','kW','Motor output'], 'drive':['Drive type','','Drivetrain'], 'length_mm':['Length','mm','Length'], 'width_mm':['Width','mm','Width excluding mirrors'], 'height_mm':['Height','mm','Height'], 'towing_braked_kg':['Braked towing','kg','Maximum braked towing'], 'warranty':['Vehicle warranty','','Australian new-vehicle warranty'], 'battery_warranty':['Battery warranty','','Australian traction-battery warranty'], 'roadside_assistance':['Roadside assistance','','Australian roadside assistance'],
'body_style':['Body style','','Body style'], 'frunk_l':['Front storage','L','Front luggage; method unspecified'],'max_total_cargo_l':['Maximum total cargo','L','Maximum cargo; method unspecified'],'rear_cargo_folded_l':['Rear cargo with seats folded','L','Rear luggage; seats folded; method unspecified'],'boot_expanded_l':['Expanded rear luggage','L','Rear luggage expanded; method unspecified'],'wheelbase_mm':['Wheelbase','mm','Wheelbase'],'ground_clearance_mm':['Ground clearance','mm','Minimum ground clearance'],'tare_mass_kg':['Tare mass','kg','Tare mass'],'dc_30_80_min':['DC 30–80% charging time','min','30–80%'],'battery_capacity_basis':['Battery capacity basis','','Capacity terminology'],'consumption_kwh_100km':['Energy consumption','kWh/100km','WLTP combined'],'towing_unbraked_kg':['Unbraked towing','kg','Maximum unbraked towing']}
def fact(c,key,value,sourceKeys,grade='confirmed',reason=None,scope=None,basis=None,comparison=None,condition='',qualifications=None,**extra):
 label,unit,default=meta.get(key,[key,'',key]);scope=scope or ('secondary_or_sibling' if grade=='reported' else 'searched_not_found' if grade=='not_published' else 'exact_au_version')
 ids=[sources[x]['id'] for x in sourceKeys];reason=reason or 'Current Australian maker material explicitly establishes this figure for the named version.'
 f={'key':key,'label':label,'value':value,'unit':unit,'basis':basis or default,'comparisonBasis':default if comparison is None else comparison,'status':{'confirmed':'standard','check':'conditional','reported':'conditional','not_published':'not_verified'}[grade],'sourceIds':ids,'date':D,'market':'AU','scope':'Geely '+c['model']+' '+c['trim'],'qualifications':qualifications or ([condition] if condition else []),'issues':[],'buyerGrade':grade,'gradeReview':{'reviewedAt':D,'overlayId':PID,'reason':reason,'evidenceScope':scope,'sourceIds':ids,'sourceLabel':' / '.join(dict.fromkeys(sources[k]['publisher'] for k in sourceKeys))},**extra}
 if condition:f['conditionExplanation']=condition
 if grade=='not_published':f['conditionExplanation']=reason
 if grade=='reported':f['resolvedElsewhere']=True
 p['facts'].append({'variantId':c['id'],'before':old[c['id']]['facts'].get(key),'after':f});effective[c['id']][key]=f
 return f
# The brand policy is one stored observation, explicitly applied to every known Geely version.
for key in ['warranty','battery_warranty','roadside_assistance']:
 row=terms[key];sk=['warranty-terms','warranty-page'] if key!='roadside_assistance' else ['roadside-terms','roadside-page']
 f=fact(cars[0],key,row['value'],sk,grade=row['grade'],reason=row['reason'],scope='brand_au_terms',condition=row.get('condition',''),qualifications=row['qualifications'])
 p['facts'].pop();f['scope']='All enumerated Australian new Geely EX5 and EX2 versions; private-use terms with explicit commercial-use qualifications'
 p['brandTerms'].append({'key':key,'fact':f,'applicableVariantIds':[c['id'] for c in cars],'before':{c['id']:c['facts'].get(key) for c in cars},'exceptions':[]})
 for c in cars:effective[c['id']][key]=f
# Passenger evidence importer appended below once the researched matrix is complete.
pe=json.load(open(R/'passenger-evidence.json'))
for row in pe['sources']:
 s={**row,'source_type':row['kind'],'supports':row['note']}
 s['title']=s['title'].replace('EX 5','EX5').replace('EX 2','EX2')
 if not s.get('file') and row.get('textFile'):s['file']=row['textFile']
 if row['key']=='ex5_tow':s['title']='Geely EX5 Gets New Variant With 750 kg Tow Rating, 2 September 2026'
 if row['key']=='ex2_press_price':s['supports']='Maker Australian September release: RRP A$26,490/A$30,990 before on-roads; its AC table says 6 kW versus 6.6 kW in the July specification guide. This conflict is retained explicitly. Battery values 35.3/47.1 kWh have lower precision than the exact guide.'
 if s.get('file'):s['file']=str(pathlib.Path(s['file']).relative_to(R)) if pathlib.Path(s['file']).is_absolute() else s['file']
 source(s)
for row in pe['variants']:
 c=old[row['id']]; ex2=c['model']=='EX2'; er='Extended Range' in c['trim']; guide='ex2_guide' if ex2 else 'ex5_er_guide' if er else 'ex5_old_guide'
 # Remove only generic model-year warnings from the display identity; retain the stable version IDs.
 if not ex2:
  a=ident(c);a.update(year=None,generation='Australian '+('68.39 kWh Extended Range specification' if er else 'outgoing 60.22 kWh specification'))
  p['versionUpdates'].append({'variantId':c['id'],'before':ident(c),'after':a,'reason':'The freshly checked Australian guide identifies the battery/grade specification. Dealer MY labels do not establish a uniform formal model year; keep that year unassigned rather than embedding a per-fact generic confirmation warning.'})
 for rowf in row['facts']:
  if rowf['grade']=='defer_to_parent':continue
  key='drive' if rowf['key']=='drive_type' else rowf['key']; sk=rowf['sourceKeys'];grade=rowf['grade'];reason=rowf.get('reason') or None;condition='';quals=[];comparison=None;basis=rowf['basis'];scope=None
  if key in ['length_mm','width_mm','height_mm','boot_l'] and grade=='confirmed':scope='explicit_au_range'
  if key=='seats':
   reason='Australian secondary material reports five seating positions. The maker specification guide does not explicitly enumerate the seating count; this remains Reported across the same body, including the sibling grade.'
  if key=='boot_l':comparison='';reason='Maker Australian body dimensions table explicitly gives luggage space with the second row up. The separate expanded/folded figures are not substituted for the seats-up volume; no VDA or SAE method is established, so no boot ranking is claimed.'
  if key=='battery_kwh':comparison='Battery capacity; gross/usable unspecified';reason='Exact maker Australian grade table states this capacity without describing it as gross, nominal or usable. No conversion or usable-capacity assumption is made.'
  if key=='price_aud':
   comparison='Before on-road costs';quals=['AUD advertised list price excluding on-road costs; registration, stamp duty, compulsory insurance, delivery/dealer fees and options must be confirmed in a written quote. No discount, finance offer or stock saving has been applied.']
   reason=('Geely Auto Australia media-release reproduction on the authorised Essendon dealer website explicitly gives RRP for both named EX2 grades before on-road costs. This is manufacturer editorial pricing, not a dealer unit advertisement.' if ex2 else 'Freshly checked reputable Australian '+('CarExpert report gives current Extended Range list prices. Maker list/national driveaway/configurator/state-driveaway rungs were sought but no readable current maker price was established; maker site returns 403. Lower-rung dealer advertisements are not substituted.' if er else 'CarsGuide price guide lists the outgoing 60.22 kWh grade. This is a reported reference price, not a live new-stock quotation or evidence that the outgoing grade can now be ordered.'))
  if key=='dc_charge_time_min' and grade=='not_published':
   if ex2:
    sk=['ex2_guide','ex2_dc_second','evcentral_ex2','evcentral_method'];reason='The Australian EX2 guide publishes no 10–80% duration. The Australian Chasing Cars Inspire review gives 25 minutes for 30–80% and only an expectation for 10–80%; EV Central uses calculated charging data without an exact-grade claim/test basis. No window conversion, estimate or sibling duration has been substituted.'
   else:
    sk=['ex5_er_guide','evcentral_ex5','evcentral_method'];reason='The current Australian Extended Range brochure publishes 20 minutes for 30–80%, not 10–80%. EV Central gives a 30-minute calculated figure and mixes current battery/range with outgoing specifications; its linked methodology describes derived charging data. No converted/estimated duration or outgoing 60.22 kWh claim is substituted.'
  if key=='dc_charge_time_min' and grade=='reported':reason='The Driven Australian review of the outgoing 60.22 kWh EX5 explicitly reports Geely confirmation of approximately 28 minutes for 10–80%. This stays Reported and is not carried to the current 68.39 kWh versions.'
  if key=='towing_braked_kg':reason='Australian secondary sources explicitly report no rated towing capacity (0 kg) for these currently marketed Australian configurations. Maker towing-preparation hardware is not a numeric rating; newly filed 750 kg homologation variants are not established as current named retail grades.' if not ex2 else 'The Driven reports Australian approval data showing 0 kg braked towing, corroborated by CarsGuide. The exact Australian maker retail specification does not give towing kilograms, so this stays Reported, not maker-confirmed.'
  if ex2 and key=='ac_kw':
   sk=['ex2_guide','ex2_press_price'];grade='check';comparison='';condition='The detailed July 2026 Australian specification guide gives 6.6 kW, but the newer 3 September 2026 maker release table gives 6 kW. Confirm the delivered car’s AC limit; the discrepancy has not been resolved.';reason='Retain the detailed exact-grade maker specification as the labelled best-supported figure, while explicitly preserving the newer maker-table discrepancy. It is not silently explained away as rounding.'
  f=fact(c,key,rowf['value'],sk,grade,reason,scope,basis,comparison,condition,quals or None)
  if ex2 and key=='ac_kw':f['issues']=[{'issue_id':PID+'-'+c['id']+'-ac-conflict','priority':'medium','model_ids':[c['modelId']],'title':'Australian maker AC charging figures differ','publication_action':condition+' Keep visible as Check and unranked.','source_ids':f['sourceIds']}]
  if key=='price_aud':
   f['priceEvidence']={'rung':rowf['priceRung'],'basisTag':('Maker’s RRP' if ex2 else 'Reported by '+sources[sk[0]]['publisher'])+' · before on-road costs','sourceKey':'price_aud','sourcePointer':sources[sk[0]]['url'],'originalBasis':basis,'rankingEligible':grade=='confirmed'}
   if rowf['priceRung']==5:f['priceEvidence']['publisher']=sources[sk[0]]['publisher']
 fact(c,'body_style','Hatchback' if ex2 else 'SUV',[guide],scope='explicit_au_range',reason='Exact Australian maker specification guide establishes the body configuration reviewed here.')
 fact(c,'wheelbase_mm',2645 if ex2 else 2750,[guide],scope='explicit_au_range')
 fact(c,'ground_clearance_mm',(134 if 'complete' in c['id'] else 136) if ex2 else (148 if 'complete' in c['id'] else 168),[guide])
 if ex2:
  fact(c,'frunk_l',70,[guide],scope='explicit_au_range',comparison='')
  fact(c,'rear_cargo_folded_l',1320,[guide],scope='explicit_au_range',comparison='')
 else:
  fact(c,'boot_expanded_l',410,[guide],scope='explicit_au_range',comparison='',reason='The maker publishes this separately as expanded rear luggage; its physical measurement configuration and VDA/SAE method are not defined in the guide.')
  fact(c,'max_total_cargo_l',1877,[guide],scope='explicit_au_range',basis='Rear luggage with second row down; maker method unspecified',comparison='',reason='The guide labels 1,877 L as rear luggage with the second row down. This is not a computed combined front/rear total, and no VDA/SAE method is established.')
  # Retain the distinct 30–80% observation without letting it fill the requested 10–80% field.
  dr=row['alternateDcTime'];fact(c,'dc_30_80_min',dr['value'],dr['sourceKeys'],dr['grade'],reason='The source explicitly states this separate 30–80% window; no conversion to 10–80% is made.')
  frunk=row.get('extraFacts',{}).get('frunk_sourceKey','')
  if frunk in sources:fact(c,'frunk_l',0,[frunk],'reported',reason='Australian secondary review explicitly says the vehicle has no front luggage compartment. Zero records absent storage, not an inferred measurement from the maker guide.')
 av=row['availability'];ids=[sources[k]['id'] for k in av['sourceKeys']];on=av['state']=='on_sale_now'
 p['availability'].append({'id':PID+'-availability-'+c['id'],'variantId':c['id'],'before':{'availability':c['availability'],'evidence':c['availabilityEvidence']},'after':{'availability':'current_or_order_listed' if on else 'outgoing','evidence':{'checkedAt':D,'orderStatus':'listed_unconfirmed' if on else 'unverified','stockStatus':('unverified' if ex2 and 'complete' in c['id'] else 'new_stock_listed') if on else 'no_new_stock_verified','sourceIds':ids,'physicalStockVerified':False,'factoryOrderAcceptanceVerified':False,'qualifications':((['Current Australian Complete version is on the authorised dealer model/quote list. The page’s captured NEW unit advertisements are Inspire, so exact Complete new stock is unverified. No factory-order acceptance or delivery date was verified.'] if ex2 and 'complete' in c['id'] else ['Current Australian named version is on the authorised dealer model list and advertised as new. No physical stock inspection, accepted factory allocation, order or delivery date was verified.']) if on else ['Superseded 60.22 kWh version is retained as outgoing, outside the on-sale denominator. No live exact retained-new dealer advertisement was established. Generic carsales catalogue listings explicitly say they were not created by the dealer or manufacturer; used and demonstrator cars do not count as new supply.'])}},'status':'approved','reviewedBy':REVIEWER,'reviewedAt':D,'evidenceDate':D,'reason':av['reason']})
# Reviewed text answers depend on the exact post-packet canonical values.
def feature(c,criterion,value,keys,grade='confirmed',conditions='',reason=None):
 before=next(f for f in prior if f['variant_id']==c['id'] and f['criterion']==criterion)
 facts=[effective[c['id']][k] for k in keys];ids=list(dict.fromkeys(i for f in facts for i in f['sourceIds']))
 after=copy.deepcopy(before)
 for k in ['gradeReviewStatus']:after.pop(k,None)
 after.update(status='standard' if grade=='confirmed' else 'conditional',value=value,conditions=conditions,condition_label='Measurement scope' if conditions else '',source_ids=ids,evidence_scope='Reviewed Australian '+c['model']+' '+c['trim'],last_evidence_date=D,reviewed_date=D,verification_state='reviewed_m1_geely_2026_10_14',buyerGrade=grade,gradeReview={'reviewedAt':D,'overlayId':PID,'reason':reason or 'Fresh reviewed answer mirrors the exact canonical post-packet facts and retains measurement and source qualifications.','evidenceScope':'secondary_or_sibling' if grade=='reported' else 'exact_au_version','sourceIds':ids,'sourceLabel':' / '.join(dict.fromkeys(s['publisher'] for s in p['sources'] if s['id'] in ids))})
 p['features'].append({'variantId':c['id'],'criterion':criterion,'before':before,'after':after,'dependencies':[{'key':f['key'],'expected':f} for f in facts]})
for c in cars:
 e=effective[c['id']];ex2=c['model']=='EX2';er='Extended Range' in c['trim']
 feature(c,'performance_rear_motor',f"Single {'rear' if ex2 else 'front'} motor · {e['power_kw']['value']} kW · {e['drive']['value']}",['power_kw','drive'])
 if ex2:feature(c,'storage','375 L rear luggage with second row up · 70 L frunk · 1,320 L rear with seats folded',['boot_l','frunk_l','rear_cargo_folded_l'],conditions='Maker luggage method is unspecified; front and rear figures are separate, and no combined maximum has been calculated.')
 else:
  # Include no-frunk only when an explicit, newly checked secondary report was captured.
  keys=['boot_l','boot_expanded_l','max_total_cargo_l'];text='302 L rear luggage with second row up · 410 L expanded · 1,877 L rear with seats folded';grade='confirmed'
  if 'frunk_l' in e:keys.append('frunk_l');text+=' · no frunk (reported)';grade='reported'
  feature(c,'storage',text,keys,grade,conditions='The maker labels expanded storage separately without defining its configuration; VDA/SAE method is unspecified. The folded figure is rear luggage, not a calculated combined total.')
  feature(c,'home_charging','Up to 11 kW AC charging',['ac_kw'],conditions='Requires a suitable supply and installation. The previous full-charge durations were estimates and are removed; no charging time has been calculated from battery capacity.')
# Each retained version gets a fresh, source-dependent strength and trade-off.
def summary(c,sl,st,skeys,tl,tt,tkeys):
 def clause(l,t,ks):return {'label':l,'text':t,'dependencies':[{'key':k,'expected':effective[c['id']][k]} for k in ks]}
 p['summaries'].append({'variantId':c['id'],'conditions':c.get('configurationEvidence',{}).get('requiredBuyerVisibleConditions',[]),'strength':clause(sl,st,skeys),'tradeoff':clause(tl,tt,tkeys)})
for c in cars:
 e=effective[c['id']];ex2=c['model']=='EX2';complete='complete' in c['id'];er='Extended Range' in c['trim']
 if ex2:
  if complete:summary(c,'Low entry price','A$26,490 RRP before on-road costs gives an accessible entry to this rear-drive hatchback.',['price_aud','drive','body_style'],'Shorter trip range','The 252 km WLTP claim makes regular charging access important for longer trips.',['range_km'])
  else:summary(c,'Extra everyday luggage space','A 70 L frunk supplements the 375 L rear luggage area with the second row up.',['frunk_l','boot_l'],'Modest fast-charging peak','The 80 kW DC peak limits how much charging power it can accept on a rapid charger.',['dc_peak_kw'])
 else:
  summary(c,'Useful claimed range',f"The {e['range_km']['value']} km WLTP claim gives this front-drive SUV useful distance between planned charges.",['range_km','drive','body_style'],'Modest fast-charging peak','The 100 kW DC ceiling limits the power it can accept at a rapid charger.',['dc_peak_kw'])
# Brand-scoped model-list review; the separate whole-market C1 list reconciliation remains open.
r={'schemaVersion':1,'checkedAt':D,'notes':['Geely-only current Australian new-car reconciliation: EX5 Complete/Inspire Extended Range and EX2 Complete/Inspire. The two retained 60.22 kWh EX5 grades remain outgoing without verified new-stock advertisements and are excluded from the on-sale denominator.','CarExpert, CarsGuide and Carbroker current brand model lists were independently checked against the manufacturer-authored Australian guides and authorised retail network. Those brand-only pages are not misrepresented as complete whole-market model lists. See source-index and REVIEW for every difference.'],'publishedLists':[],'currentVersionReviews':[],'listResolutions':[],'catalogueOnlyDifferences':[],'inventoryResolutions':[]}
for model,mid,body,sk in [('EX5','geely_ex5','SUV',['ex5_er_guide','ex5_current_dealer']),('EX2','geely_ex2_launch','Hatchback',['ex2_guide','ex2_press_price','ex2_current_dealer'])]:
 ids=[row['id'] for row in pe['variants'] if row['model']==model and row['availability']['state']=='on_sale_now']
 r['currentVersionReviews'].append({'id':PID+'-'+model.lower()+'-current','brand':'Geely','model':model,'bodyStyle':body,'vehicleClass':'passenger','modelId':mid,'checkedAt':D,'officialSourceUrls':[sources[k]['url'] for k in sk],'reason':'Complete current exact Australian version list established by maker-authored specification and current authorised-dealer range, cross-checked against independent current model lists. Dealer MY labels do not establish a new drivetrain version.','versions':[{'carId':i,'model':model,'trim':old[i]['trim'],'modelYear':None} for i in ids]})
r['inventoryResolutions'].append({'kind':'record','inventoryId':'geely-ex2','outcome':'included','modelReviewId':PID+'-ex2-current','reviewedAt':D,'reason':'The inherited EX2 record maps to the complete current Australian Complete/Inspire version list, with fresh maker guide, RRP release and authorised dealer new-model evidence.','sourceUrls':[sources[k]['url'] for k in ['ex2_guide','ex2_press_price','ex2_current_dealer']]})
rd=json.load(open(R/'riddara/resolution.json'))
r['inventoryResolutions'].append({'kind':'lead','inventoryId':rd['existingLeadId'],'outcome':'excluded','exclusionReason':'not_sold_new_in_australia','reviewedAt':D,'reason':rd['reason'],'sourceUrls':rd['primaryEvidenceUrls']+rd['independentEvidenceUrls']})
for x in pe['currentModelClosure']['excluded']:
 r['notes'].append(x['name']+': '+x['reason']+'. Evidence: '+ '; '.join(sources[k]['url'] for k in ['lineup_carexpert','lineup_carsguide','future_models','ex5_future','ex5_tow']))
for x in rd['relatedExcludedProducts']:r['notes'].append(x['model']+': '+x['reason']+'. Evidence: '+'; '.join(x['sources']))
(R/'geely-2026-10-14.json').write_text(json.dumps(p,indent=2,ensure_ascii=False)+'\n')
(R/'geely-reconciliation-2026-10-14.json').write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
(R/'source-index.json').write_text(json.dumps({'checkedAt':D,'sources':p['sources'],'independentBrandLists':[sources[k] for k in pe['currentModelClosure']['independentLists']],'riddaraBundle':'riddara/bundle-manifest.json'},indent=2,ensure_ascii=False)+'\n')
print('Prepared',len(p['facts']),'specific facts,',len(p['brandTerms']),'shared terms,',len(p['features']),'guarded features,',len(p['sources']),'sources.')
