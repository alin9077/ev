#!/usr/bin/env python3
"""Independent fresh-only streaming replay; never restores or opens base archives."""
import datetime
import hashlib
import html.parser
import json
import lzma
import os
import pathlib
import resource
import stat
import sys
import tarfile
import time
import traceback

sys.dont_write_bytecode = True
P = pathlib.Path
C = P(__file__).resolve().parent
R = C.parents[1]
W = R.parent
BASE = C.parent / 'skoda-working-20261015T0520'
CHUNK = 65536
LIMIT = 268435456
LABEL = 'AUDI-WORKING-20261015T0800'
OUT = C / 'INDEPENDENT-AUDI-RECOVERY-VERIFICATION-v4.json'
REPLAY = C / 'INDEPENDENT-NEW-MEMBER-REPLAY-MANIFEST-v4.json'
START = time.monotonic()
RESULT = {'result': 'IN_PROGRESS'}

def ck(value, message):
    if not value:
        raise AssertionError(message)

def load(path):
    return json.loads(P(path).read_text())

def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()

def encoded_json_key(name):
    """Canonical JSON key spelling, without embedding header-shaped source text."""
    return json.dumps(name).encode() + b':'

def dump(path, value):
    with P(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())

def identity(path):
    path = P(path)
    row = path.lstat()
    ck(stat.S_ISREG(row.st_mode) and not any(p.is_symlink() for p in path.parents), 'unsafe regular file ' + str(path))
    return [row.st_size, row.st_mtime_ns, row.st_ctime_ns, row.st_ino, row.st_dev]

def pin(path):
    before = identity(path)
    digest = hashlib.sha256()
    count = 0
    with P(path).open('rb') as stream:
        while block := stream.read(CHUNK):
            digest.update(block)
            count += len(block)
    ck(before == identity(path) and count == before[0], 'changed during read ' + str(path))
    return {'bytes': count, 'sha256': digest.hexdigest()}

def check(path, expected):
    actual = pin(path)
    ck(all(actual[key] == expected[key] for key in ('bytes', 'sha256') if expected.get(key) is not None), 'pin differs ' + str(path))
    return actual

def core(row):
    return {key: row[key] for key in ('path', 'bytes', 'sha256')}

def original(row):
    return {'bytes': row['originalBytes'], 'sha256': row['originalSHA256']}

def safe(name):
    path = pathlib.PurePosixPath(name)
    ck(bool(name) and not path.is_absolute() and '..' not in path.parts and '\\' not in name and str(path) == name, 'unsafe member ' + name)

def rows_map(rows):
    result = {}
    for row in rows:
        safe(row['path'])
        ck(row['path'] not in result, 'duplicate member ' + row['path'])
        result[row['path']] = core(row)
    return result

def restore_path(path):
    path = P(path)
    if path.is_relative_to('/tmp'):
        name = path.relative_to('/tmp').as_posix()
    elif path.is_relative_to(W / 'roadmark-104'):
        name = 'roadmark/' + path.relative_to(W / 'roadmark-104').as_posix()
    elif path.is_relative_to(W / 'roadmark-104-qa'):
        name = path.relative_to(W).as_posix()
    else:
        raise AssertionError('unexpected original path ' + str(path))
    safe(name)
    return name

def terminal(path, command, limit=LIMIT, expected_exit=0):
    path = P(path)
    invocation = path.with_name(path.stem + '.invocation.json')
    actual, started = load(path), load(invocation)
    ck(actual['command'] == started['command'] == command, 'terminal command differs ' + path.name)
    ck(actual['exitCode'] == expected_exit and not actual['timedOut'], 'terminal failed ' + path.name)
    ck(actual['addressSpaceLimitBytes'] == started['addressSpaceLimitBytes'] == limit, 'terminal memory differs ' + path.name)
    ck(actual['wallLimitSeconds'] == started['wallLimitSeconds'] == 600 and actual['childPid'] == started['childPid'], 'terminal bounds differ ' + path.name)
    ck(actual['maxRssKiB'] > 0, 'missing RSS ' + path.name)
    return {'receipt': pin(path), 'invocation': pin(invocation), 'command': command, 'exitCode': expected_exit, 'addressSpaceLimitBytes': limit, 'maxRssKiB': actual['maxRssKiB'], 'wallSeconds': actual['wallSeconds']}

def pointer(value, path):
    if path == '':
        return value
    ck(path.startswith('/'), 'invalid JSON pointer')
    for key in path.split('/')[1:]:
        key = key.replace('~1', '/').replace('~0', '~')
        value = value[int(key)] if isinstance(value, list) else value[key]
    return value

def seed_invocations():
    provenance = pin(C / 'SEED-PROVENANCE.json')
    terminals = []
    for path in sorted(C.glob('*.resources.json')):
        value = load(path)
        command = value.get('command', [])
        if any(P(part).name.startswith(('privacy_v', 'scan_documents_v')) and P(part).suffix == '.py' for part in command):
            terminals.append((path, value))
    result = []
    for path in sorted((C / 'seed-read-invocations').glob('*.json')):
        value = load(path)
        ck(value['exactPinnedMembersReadAndVerified'] == 200 and value['historicalArchives'] == 21 and value['noExtractedValuesPersisted'], 'seed invocation count/scope differs')
        ck(value['memberIdentityListPin'] == provenance, 'seed invocation identity-list pin differs')
        when = datetime.datetime.fromisoformat(value['completedAt'])
        matches = [(p, row) for p, row in terminals if row['childPid'] == value['processId'] and datetime.datetime.fromisoformat(row['startedAt']) <= when <= datetime.datetime.fromisoformat(row['endedAt'])]
        ck(len(matches) == 1, 'seed invocation lacks one matching actual terminal')
        result.append({'receipt': path.name, **pin(path), 'record': value, 'terminal': matches[0][0].name, 'terminalPin': pin(matches[0][0])})
    for path, row in terminals:
        if row['exitCode'] in (0, 2):
            ck(sum(item['terminal'] == path.name for item in result) == 1, 'successful scanner has missing/duplicate actual seed receipt')
    return result

def audi_seed_invocations():
    proposal_path = C / 'INDEPENDENT-AUDI-RUNTIME-BATCH-CLASSIFICATION-v1.json'
    check(proposal_path, {'bytes': 720844, 'sha256': '4bb97b40446fad1a43e08b498ebdab7e1c82af35470de5b83419932047f3eb5a'})
    proposal = load(proposal_path)
    by = {row['member']: row for row in proposal['files']}
    expected_reads = []
    for group in proposal['newValueSources']:
        source = group['sources'][0]
        row = by[source['member']]
        expected_reads.append({'valueGroup': group['id'], 'path': row['originalPath'], 'pin': row['originalPin'], 'byteStart': source['byteStart'], 'byteEndExclusive': source['byteEndExclusive'], 'payloadReadOperations': 1})
    ck(len(expected_reads) == 6 and len({row['path'] for row in expected_reads}) == 4, 'Audi seed read contract differs')
    terminals = []
    for path in sorted(C.glob('*.resources.json')):
        value = load(path)
        if any(P(part).name.startswith(('privacy_v', 'scan_documents_v')) and P(part).suffix == '.py' and P(part).name not in ('privacy_v2.py', 'scan_documents_v2.py') for part in value.get('command', [])):
            terminals.append((path, value))
    result = []
    for path in sorted((C / 'audi-seed-read-invocations').glob('*.json')):
        value = load(path)
        ck(value['distinctValues'] == 6 and value['variantForms'] == 37 and value['payloadReadOperations'] == 6 and value['uniqueOriginalFiles'] == 4, 'Audi seed actual counts differ')
        ck(value['reads'] == expected_reads and value['noValuesOrValueDigestsPersisted'] and not value['generalURLDecodedRuntimeCoverageClaimed'], 'Audi seed scope differs')
        ck(value['classificationReceiptPin'] == pin(proposal_path), 'Audi seed classification pin differs')
        when = datetime.datetime.fromisoformat(value['completedAt'])
        matches = [(p, row) for p, row in terminals if row['childPid'] == value['processId'] and datetime.datetime.fromisoformat(row['startedAt']) <= when <= datetime.datetime.fromisoformat(row['endedAt'])]
        ck(len(matches) == 1, 'Audi seed invocation lacks one matching actual terminal')
        result.append({'receipt': path.name, **pin(path), 'record': value, 'terminal': matches[0][0].name, 'terminalPin': pin(matches[0][0])})
    for path, row in terminals:
        if row['exitCode'] in (0, 2):
            ck(sum(item['terminal'] == path.name for item in result) == 1, 'scanner missing/duplicating Audi seed receipt')
    return result

def visible_projection(data):
    class Projection(html.parser.HTMLParser):
        def __init__(self):
            super().__init__(convert_charrefs=True)
            self.hidden = 0
            self.fragments = []
        def handle_starttag(self, tag, attrs):
            if tag in ('script', 'style'):
                self.hidden += 1
        def handle_endtag(self, tag):
            if tag in ('script', 'style'):
                self.hidden -= 1
                ck(self.hidden >= 0, 'unbalanced script/style projection')
        def handle_data(self, value):
            if not self.hidden:
                self.fragments.append(value)
    parser = Projection()
    parser.feed(data.decode('utf-8'))
    parser.close()
    ck(parser.hidden == 0, 'unclosed projection exclusion')
    return '\n'.join(parser.fragments).encode()

def verify_runtime_sanitation(proof_capture):
    proposal_path = C / 'INDEPENDENT-AUDI-RUNTIME-BATCH-CLASSIFICATION-v1.json'
    check(proposal_path, {'bytes': 720844, 'sha256': '4bb97b40446fad1a43e08b498ebdab7e1c82af35470de5b83419932047f3eb5a'})
    proposal = load(proposal_path)
    clarification = load(C / 'INDEPENDENT-AUDI-RUNTIME-BATCH-CLARIFICATION-v1.json')
    ck(clarification['originalReceipt']['sha256'] == pin(proposal_path)['sha256'] and clarification['computedNumericFieldsUnchanged']['newRuntimeVariantForms'] == 37, 'form-count clarification differs')
    mapping = load(C / 'COPY-SANITATION-MAPPING-v2.json')
    ck(mapping['fileCount'] == proposal['fileCount'] == 33 and mapping['locationCount'] == proposal['proposedRangeCount'] == 47, 'runtime sanitation scope differs')
    ck(mapping['classification'] == pin(proposal_path) and mapping['originalExpectedPinsUnchanged'] and mapping['factualProjectionUnchanged'] and mapping['outsideDeclaredRangesUnchanged'], 'runtime mapping assurances differ')
    current = {row['path']: row for row in proof_capture['files']}
    prior = {row['path']: row for row in load(C / 'proof-capture-v1.json')['files']}
    by = {row['member']: row for row in proposal['files']}
    ck(len(mapping['files']) == len(by) and {row['member'] for row in mapping['files']} == set(by), 'runtime map member set differs')
    for row in mapping['files']:
        name = row['member']
        approved = by[name]
        ck(all(value == approved[key] for key, value in row.items() if key != 'sanitizedPayloadPath'), 'runtime map changed approval ' + name)
        path = C / 'selected-proof-runtime-sanitized-v2' / name
        ck(row['sanitizedPayloadPath'] == str(path), 'runtime copy destination differs')
        expected = {**prior[name], 'payloadPath': str(path), **approved['proposedSanitizedPin'], 'captureMethod': 'exact-approved-runtime-range-copy-redaction', 'runtimeSanitation': True}
        ck(current[name] == expected and original(current[name]) == approved['originalPin'], 'runtime capture row differs')
        source = P(approved['originalPath'])
        ck(identity(source) == approved['originalIdentity'], 'runtime original identity differs')
        check(source, approved['originalPin'])
        check(path, approved['proposedSanitizedPin'])
        original_bytes, sanitized = source.read_bytes(), path.read_bytes()
        ck(identity(source) == approved['originalIdentity'], 'runtime original changed during parity check')
        parts, previous = [], 0
        for span in approved['ranges']:
            a, z = span['byteStart'], span['byteEndExclusive']
            ck(previous <= a < z <= len(original_bytes), 'runtime ranges overlap/outside file')
            parts.extend((original_bytes[previous:a], span['replacement'].encode()))
            ck(sanitized[span['sanitizedByteStart']:span['sanitizedByteEndExclusive']] == span['replacement'].encode(), 'runtime replacement differs')
            previous = z
        parts.append(original_bytes[previous:])
        ck(b''.join(parts) == sanitized, 'bytes outside runtime ranges changed')
        for span in approved['outsideSegments']:
            before = original_bytes[span['originalByteStart']:span['originalByteEndExclusive']]
            after = sanitized[span['sanitizedByteStart']:span['sanitizedByteEndExclusive']]
            ck(before == after and hashlib.sha256(before).hexdigest() == span['sha256'], 'outside-range segment differs')
        if name.endswith('.html'):
            before, after = visible_projection(original_bytes), visible_projection(sanitized)
            ck(before == after and len(before) == approved['factualProjection']['bytes'] and hashlib.sha256(before).hexdigest() == approved['factualProjection']['sha256'], 'visible text projection changed')
        check(source, approved['originalPin'])
        check(path, approved['proposedSanitizedPin'])
    for name, row in current.items():
        if name not in by:
            ck(row == prior[name], 'unapproved additional proof mutation ' + name)
    ck(proof_capture['copyRuntimeSanitation'] == {'files': 33, 'ranges': 47, 'classification': pin(proposal_path), 'originalExpectedPinsUnchanged': True}, 'runtime capture summary differs')
    return by, proposal

def scanner_fixture_evidence(retained_paths):
    outcomes = []
    for version, expected_result, expected_code, digest in (
        (1, 'FAIL', 2, 'bf1757a8a617e3c784940d0552aee19c6f1512a637ffbde28584c7358f58c405'),
        (2, 'PASS', 0, '8e1cd39bbd67db07a68d8a8c30e3bf1e0045c629102d89f2cc3445315542ddc1'),
    ):
        path = C / f'INDEPENDENT-AUDI-SCANNER-FIXTURE-v{version}.json'
        check(path, {'bytes': 7767, 'sha256': digest})
        value = load(path)
        ck(value['result'] == expected_result and len(value['checks']) == 15, 'scanner fixture outcome differs')
        ck(sum(row['result'] == 'FAIL' for row in value['checks']) == (1 if version == 1 else 0), 'scanner fixture negative history differs')
        metric_prefix = 'independent-scanner-fixture' + ('-v2' if version == 2 else '')
        metric_path = C / (metric_prefix + '.resources.json')
        metric = load(metric_path)
        invocation = load(C / (metric_prefix + '.resources.invocation.json'))
        fixture_script = C / f'independent_audi_scanner_fixture_v{version}.py'
        command = ['python3', '-B', str(fixture_script)]
        ck(metric['command'] == invocation['command'] == command and metric['exitCode'] == expected_code and not metric['timedOut'], 'scanner fixture terminal differs')
        ck(metric['addressSpaceLimitBytes'] == invocation['addressSpaceLimitBytes'] == LIMIT and metric['wallLimitSeconds'] == invocation['wallLimitSeconds'] == 600 and metric['childPid'] == invocation['childPid'], 'scanner fixture bounds differ')
        ck(value['rawPrimaryFindings'] == value['classifiedExactCodeFindings'] == 10 and value['unclassifiedPrimaryFindings'] == value['runtimeFindings'] == 0, 'scanner fixture candidate scope differs')
        ck(value['audiDistinctValues'] == 6 and value['audiVariantForms'] == 37 and value['originalPayloadReadOperations'] == 6 and value['uniqueOriginalFiles'] == 4, 'scanner fixture seed scope differs')
        ck(not value['productionPayloadsModified'] and not value['valuesOrValueDigestsPersisted'] and value['historicalArchivesRead'] == 0 and not value['productionSeedReceiptDirectoriesModified'], 'scanner fixture isolation differs')
        ledger_path = P(value['fixtureSeedReadReceipt']['path'])
        ck(ledger_path.is_relative_to(C / f'independent-scanner-fixture-data-v{version}'), 'fixture seed ledger not isolated')
        check(ledger_path, value['fixtureSeedReadReceipt']['pin'])
        ledger = load(ledger_path)
        when = datetime.datetime.fromisoformat(ledger['completedAt'])
        ck(ledger['processId'] == metric['childPid'] and datetime.datetime.fromisoformat(metric['startedAt']) <= when <= datetime.datetime.fromisoformat(metric['endedAt']), 'fixture seed ledger not bound to actual terminal')
        ck(ledger['distinctValues'] == 6 and ledger['variantForms'] == 37 and ledger['payloadReadOperations'] == 6 and ledger['uniqueOriginalFiles'] == 4 and ledger['noValuesOrValueDigestsPersisted'], 'fixture ledger scope differs')
        check(fixture_script, value['fixturePin'])
        for filename, expected_pin in value['inputPins'].items():
            safe(filename)
            check(C / filename, expected_pin)
            ck(str(C / filename) in retained_paths, 'tested fixture input missing from support')
        evidence = [path, ledger_path, fixture_script] + [C / (metric_prefix + suffix) for suffix in ('.log', '.err', '.resources.json', '.resources.invocation.json')]
        ck(all(str(item) in retained_paths for item in evidence), 'unique fixture code/failure/read ledger missing from support')
        outcomes.append({'fixture': version, 'result': expected_result, 'report': {'path': path.name, **pin(path)}, 'terminal': {'path': metric_path.name, **pin(metric_path)}, 'isolatedLedger': {'path': ledger_path.relative_to(C).as_posix(), **pin(ledger_path)}, 'originalPayloadReadOperations': 6, 'uniqueOriginalFiles': 4, 'historicalArchiveReads': 0})
    return {'fixtures': outcomes, 'fixtureOnlyOriginalPayloadReadOperations': 12, 'uniqueOriginalFiles': 4, 'separateFromProductionScanCounters': True, 'otherDiagnosticPayloadReadsNotClaimedIncluded': True}

def support_adjudication_evidence(contract, retained_paths):
    for row in contract.values():
        check(row['path'], row)
        ck(row['path'] in retained_paths, 'adjudication evidence missing from support')
    grant = load(contract['rootGrant']['path'])
    ck(grant['classificationReceiptSHA256'] == contract['classification']['sha256'] and grant['exactRuntimeSyntaxCandidates'] == 3 and grant['exactFiles'] == 2, 'exact support adjudication approval differs')
    ck(grant['strictSeparateReportAdjudication'] and grant['allDetectorSearchesAndRawResultsUnchanged'] and grant['extraMissingDuplicateOrPinMismatchBlocks'], 'support adjudication approval bounds differ')
    fixture = load(contract['fixture']['path'])
    ck(fixture['result'] == 'PASS' and fixture['checks'] and all(row['result'] == 'PASS' for row in fixture['checks']), 'support adjudication fixture failed')
    check(contract['fixtureScript']['path'], fixture['fixturePin'])
    check(contract['helper']['path'], fixture['helperPin'])
    check(contract['classification']['path'], fixture['classificationPin'])
    ck(fixture['seedReads'] == fixture['archivePayloadReads'] == 0, 'unexpected fixture payload reads')
    fixture_terminal = terminal(contract['fixtureTerminal']['path'], ['python3', '-B', contract['fixtureScript']['path']])
    preflight = load(contract['preflight']['path'])
    ck(preflight['result'] == 'PASS' and preflight['seedReads'] == preflight['historicalArchiveReads'] == 0, 'replacement support preflight differs')
    for row in preflight['files']:
        check(C / row['filename'], row)
        ck(str(C / row['filename']) in retained_paths and not row['primaryFindings'] and not row['rawRuntimeFindings'], 'new executable preflight scope differs')
    preflight_terminal = terminal(contract['preflightTerminal']['path'], ['python3', '-B', str(C / 'independent_audi_replacement_support_preflight_v1.py')])
    return {'classification': contract['classification'], 'rootGrant': contract['rootGrant'], 'helper': contract['helper'], 'fixture': contract['fixture'], 'fixtureTerminal': fixture_terminal, 'preflight': contract['preflight'], 'preflightTerminal': preflight_terminal, 'exactRuntimeSyntaxCandidates': 3, 'files': 2, 'seedReads': 0, 'archivePayloadReads': 0, 'rawScannerOutputRetained': True}

def main():
    ck('--sole-child-slot-authorized' in sys.argv, 'sole heavy slot release required')
    ck(resource.getrlimit(resource.RLIMIT_AS) == (LIMIT, LIMIT), '256 MiB process ceiling absent')
    ck(not OUT.exists() and not REPLAY.exists(), 'result already exists; preserve prior attempts')
    review = load(C / 'INDEPENDENT-AUDI-COMMAND-PLAN-REVIEW-v4.json')
    ck(review['result'] == 'PASS_FINAL_ARCHIVE_COMMAND_AND_POINTER_PLAN', 'final static review absent')
    command_path = P(review['commandPlan']['path'])
    ck(command_path.parent == C, 'command plan outside checkpoint')
    check(command_path, review['commandPlan'])
    command_plan = load(command_path)
    scanner_path = P(review['privacyScanner']['path'])
    check(scanner_path, review['privacyScanner'])
    for row in command_plan['scriptPins']:
        check(row['path'], row)
    check(__file__, review['independentVerifier'])
    scope = load(C / 'FROZEN-CAPTURE-SCOPE.json')
    check(C / 'FROZEN-CAPTURE-SCOPE.json', review['frozenScope'])
    frozen_identities = load(C / 'INDEPENDENT-AUDI-FREEZE-IDENTITIES-v1.json')
    ck(frozen_identities['result'] == 'PASS_STATIC_FROZEN_IDENTITY_BINDING', 'independent freeze identities absent')
    check(C / 'INDEPENDENT-AUDI-FREEZE-IDENTITIES-v1.json', review['freezeIdentities'])
    ids = {row['path']: row['identity'] for row in frozen_identities['files']}
    frozen = {restore_path(row['path']): row for row in scope['files']}
    ck(len(frozen) == len(scope['files']) == len(ids), 'duplicate or incomplete frozen identity scope')
    source_capture = load(C / 'source-capture.json')
    proof_capture = load(C / 'proof-capture-v2.json')
    support = load(C / 'SUPPORT-MEMBER-INVENTORY.json')
    support2 = load(C / 'SUPPORT2-MEMBER-INVENTORY-v2.json')
    support3 = load(C / 'SUPPORT3-MEMBER-INVENTORY.json')
    plan = load(C / 'RESTORE-PLAN-v4.json')
    archives = load(C / 'ARCHIVE-PLAN-v4.json')['archives']
    state = (C / 'WORKING-STATE.txt').read_text()
    names = ['FROZEN-CAPTURE-SCOPE.json', 'INDEPENDENT-AUDI-FREEZE-IDENTITIES-v1.json', 'source-capture.json', 'proof-capture-v1.json', 'proof-capture-v2.json', 'source-package.json', 'proof-packages.json', 'proof-packages-v2.json', 'SUPPORT-MEMBER-INVENTORY.json', 'SUPPORT2-MEMBER-INVENTORY-v2.json', 'support-package.json', 'support2-package-v2.json', 'RESTORE-PLAN-v4.json', 'ARCHIVE-PLAN-v4.json', 'FRESH-ONLY-RESTORE-MANIFEST-v4.json', 'ALL-ARCHIVE-PRIVACY-GATE-v4.json', 'COPY-SANITATION-MAPPING.json', 'COPY-SANITATION-MAPPING-v2.json', 'INDEPENDENT-AUDI-RUNTIME-BATCH-CLASSIFICATION-v1.json', 'INDEPENDENT-AUDI-RUNTIME-BATCH-CLARIFICATION-v1.json', 'PROSE-KEY-RENAME-APPROVALS.json', 'APPLICATION-ASSERTION-CONTRACT.json', 'INDEPENDENT-AUDI-SEED-METADATA-CONTRACT-v1.json', 'SYMLINK-RECONSTRUCTION.json']
    names += ['SUPPORT3-MEMBER-INVENTORY.json', 'support3-package.json', 'INHERITED-DEPENDENCY-RELOCATION-v1.json', 'INDEPENDENT-AUDI-INHERITED-DEPENDENCY-RELOCATION-v1.json', 'APPROVED-AUDI-DEPENDENCY-RELOCATION-v1.json']
    input_pins = {name: pin(C / name) for name in names}
    phases = {row['phase']: terminal(row['terminal'], row['command']) for row in command_plan['phaseCommands']}
    ck(len(phases) == len(command_plan['phaseCommands']), 'duplicate phase names')
    base_path = BASE / 'deliverables/Roadmark-RECOVERY-MANIFEST-SKODA-WORKING-20261015.json'
    check(base_path, {'bytes': 3749629, 'sha256': '744c41676bd8b8bbd4b97b78b06ffd3f94fb4e6d24bbb8d7580edc31b5cbc42c'})
    check(BASE / 'FINAL-SKODA-UPLOAD-RECEIPTS.json', {'bytes': 83915, 'sha256': 'e076b33ab248a3e84fc3435118624fae9c7918e48e70b3cbdd0576aae3dcf9ca'})
    base = load(base_path)
    old = rows_map(base['files'])
    old_source = {row['path']: row for row in load(BASE / 'source-capture.json')['files']}
    current = {row['path']: row for row in source_capture['files']}
    captured = {row['path']: row for row in proof_capture['files']}
    delta = {row['path']: row for row in proof_capture['changedFiles']}
    ck(len(current) == len(source_capture['files']) == scope['expectedSourceFiles'], 'full source count differs')
    ck(set(old_source) <= set(current), 'inherited source deletion')
    changed = {name for name, row in current.items() if name not in old_source or original(row) != original(old_source[name])}
    ck(changed == set(scope['sourceChangedPaths']), 'source changed-path allowlist differs')
    ck(source_capture['chunkBytes'] == proof_capture['chunkBytes'] == CHUNK and not source_capture['fullSourceTreeCloned'] and proof_capture['noBroadQaTraversal'], 'capture resource contract differs')
    ck(not source_capture['sourceChangesDuringCapture'] and not proof_capture['sourceChangesDuringCapture'], 'capture stability failed')
    ck(source_capture['state'] == proof_capture['state'] == state == scope['workingResult'] + '\n', 'working state differs')
    reused_source = []
    for name, row in current.items():
        safe(name)
        ck(row['originalPath'] == str(W / 'roadmark-104' / name), 'source locator differs')
        if name in changed:
            expected = frozen['roadmark/' + name]
            ck(original(row)['bytes'] == expected['bytes'], 'changed source size differs')
            if expected.get('sha256') or expected.get('knownSha256'):
                ck(original(row)['sha256'] == (expected.get('sha256') or expected['knownSha256']), 'changed source frozen hash differs')
            ck(original(row) == {key: row[key] for key in ('bytes', 'sha256')}, 'unapproved new source transformation')
        else:
            prior = old_source[name]
            ck(all(row.get(key, []) == prior.get(key, []) for key in ('bytes', 'sha256', 'originalBytes', 'originalSHA256', 'redactedHeaderPaths', 'redactedPointers', 'redactedHTMLRanges')), 'source sanitation lineage differs ' + name)
            ck(row['payloadPath'] == prior['payloadPath'] and row['captureMethod'] == 'exact-original-and-prior-sanitized-hashes', 'source payload reuse differs')
            reused_source.append(name)
    ck(len(captured) == len(proof_capture['files']) == len(frozen) and proof_capture['scope'] == scope and len(delta) == len(proof_capture['changedFiles']), 'proof scope differs')
    runtime_rows, runtime_proposal = verify_runtime_sanitation(proof_capture)
    covered, reused, renamed = [], [], []
    approvals = load(C / 'PROSE-KEY-RENAME-APPROVALS.json')
    approval_rows = approvals['files']
    for name, expected in frozen.items():
        row = captured[name]
        ck(row['originalPath'] == expected['path'] and row['sourceIdentity'] == ids[expected['path']], 'captured frozen identity differs ' + name)
        ck(original(row)['bytes'] == expected['bytes'], 'frozen original size differs')
        if expected.get('sha256') or expected.get('knownSha256'):
            ck(original(row)['sha256'] == (expected.get('sha256') or expected['knownSha256']), 'frozen original hash differs ' + name)
        if name.startswith('roadmark/'):
            source_row = current[name[9:]]
            ck(core(row) == {'path': name, 'bytes': source_row['bytes'], 'sha256': source_row['sha256']} and original(row) == original(source_row) and row['captureMethod'] == 'covered-by-full-source' and name not in delta, 'source-covered proof differs')
            covered.append(name)
        elif name in delta:
            ck(row == delta[name] and row['archiveAction'] == 'new-delta-member', 'new delta membership differs')
            if name in runtime_rows:
                ck(row.get('runtimeSanitation') and core(row) == {'path': name, **runtime_rows[name]['proposedSanitizedPin']}, 'runtime sanitation final member differs')
            elif row.get('metadataKeyRename'):
                matches = [entry for entry in approval_rows if entry.get('restorePath', entry.get('path')) == name]
                ck(len(matches) == 1, 'unapproved key rename ' + name)
                check(row['payloadPath'], row)
                copied = P(row['payloadPath']).read_bytes()
                ck(copied.count(encoded_json_key('approvalScope')) == 1 and encoded_json_key('authorization') not in copied, 'copied key shape differs')
                raw = copied.replace(encoded_json_key('approvalScope'), encoded_json_key('authorization'), 1)
                ck({'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()} == original(row), 'inverse rename does not reconstruct frozen bytes')
                before, after = json.loads(raw), json.loads(copied)
                value = before.pop('authorization')
                ck(after.pop('approvalScope') == value and before == after, 'rename changed value or non-key fields')
                ck(not row.get('redactedPointers') and not row.get('redactedHTMLRanges'), 'additional unapproved sanitation')
                renamed.append(name)
            else:
                ck({key: row[key] for key in ('bytes', 'sha256')} == original(row) and not row.get('redactedPointers') and not row.get('redactedHTMLRanges'), 'unapproved proof transformation ' + name)
        else:
            ck(core(row) == old[name] and row['archiveAction'] == 'reuse-exact-base-member', 'inherited proof pin differs')
            reused.append(name)
    ck(len(renamed) == len(approval_rows), 'approval rename coverage differs')
    source_package = load(C / 'source-package.json')
    proof_packages = load(C / 'proof-packages-v2.json')['archives']
    original_proof_packages = load(C / 'proof-packages.json')['archives']
    support_package = load(C / 'support-package.json')
    support2_package = load(C / 'support2-package-v2.json')
    support3_package = load(C / 'support3-package.json')
    support_packages = [support_package, support2_package, support3_package]
    support_inventories = [support, support2, support3]
    package_rows = [source_package] + proof_packages + support_packages
    ck(archives == plan['newArchives'] and [{key: value for key, value in row.items() if key != 'restoreOrder'} for row in archives] == package_rows, 'unified fresh archive order differs')
    source_metadata = {'schemaVersion': 1, 'root': 'roadmark', 'files': [core(row) for row in source_capture['files']]}
    generated = {'roadmark/SOURCE-FILE-MANIFEST.json': encoded(source_metadata)}
    groups = [[delta[row['path']] for row in archive['memberFiles'] if row['path'] in delta] for archive in original_proof_packages]
    ck(len(groups) == len(proof_packages) == 4 and sum(len(group) for group in groups) == len(delta), 'proof archive grouping differs')
    ck([row['path'] for group in groups for row in group] == list(delta), 'proof member grouping/order differs')
    for index, (group, archive) in enumerate(zip(groups, proof_packages), 1):
        if index == 4:
            ck(archive == original_proof_packages[index - 1], 'unchanged clean proof part 4 differs')
            ck(not (set(runtime_rows) & {row['path'] for row in group}), 'part 4 unexpectedly contains sanitation')
            name = f'recovery-metadata/{LABEL}-part{index:02d}.json'
            meta = {'schemaVersion': 1, 'label': LABEL, 'part': index, 'parts': len(groups), 'state': proof_capture['state'], 'files': [{key: row[key] for key in ('path', 'bytes', 'sha256', 'originalBytes', 'originalSHA256')} for row in group], 'restore': 'Overlay after the exact 119-archive Škoda chain, replacing its source archive with this full registered Audi working source. Original raw-capture expected hashes and sanitation mapping remain unchanged.'}
        else:
            ck(set(runtime_rows) & {row['path'] for row in group}, 'unnecessary replacement proof part')
            name = f'recovery-metadata/{LABEL}-part{index:02d}-sanitized-v2.json'
            meta = {'schemaVersion': 2, 'label': LABEL, 'part': index, 'parts': 4, 'state': proof_capture['state'], 'files': [{key: row[key] for key in ('path', 'bytes', 'sha256', 'originalBytes', 'originalSHA256')} for row in group], 'originalPartPin': {key: original_proof_packages[index - 1][key] for key in ('bytes', 'sha256')}, 'copySanitationMap': 'audi-safety-support/COPY-SANITATION-MAPPING.json', 'originalExpectedHashesUnchanged': True, 'restore': 'Versioned sanitized replacement for this Audi proof part; never combine the superseded original part with the recommended final chain.'}
        generated[name] = encoded(meta)
        wanted_group = rows_map(group)
        wanted_group[name] = {'path': name, 'bytes': len(generated[name]), 'sha256': hashlib.sha256(generated[name]).hexdigest()}
        if index == 1:
            name = 'audi-safety-support/COPY-SANITATION-MAPPING.json'
            generated[name] = (C / 'COPY-SANITATION-MAPPING-v2.json').read_bytes()
            wanted_group[name] = {'path': name, 'bytes': len(generated[name]), 'sha256': hashlib.sha256(generated[name]).hexdigest()}
        ck(rows_map(archive['memberFiles']) == wanted_group, 'proof member/metadata union differs')
        suffix = '' if index == 4 else '-sanitized-v2'
        ck(archive['filename'] == f'Roadmark-recovery-{LABEL}-part{index:02d}of04{suffix}.tar.xz', 'proof archive name differs')
    source_members = {'roadmark/' + name: {'path': 'roadmark/' + name, 'bytes': row['bytes'], 'sha256': row['sha256']} for name, row in current.items()}
    source_members['roadmark/SOURCE-FILE-MANIFEST.json'] = {'path': 'roadmark/SOURCE-FILE-MANIFEST.json', 'bytes': len(generated['roadmark/SOURCE-FILE-MANIFEST.json']), 'sha256': hashlib.sha256(generated['roadmark/SOURCE-FILE-MANIFEST.json']).hexdigest()}
    ck(rows_map(source_package['memberFiles']) == source_members and source_package['bytes'] < 15000000, 'full source membership or strict size limit differs')
    all_support_rows = support['files'] + support2['files'] + support3['files']
    ck(len(rows_map(all_support_rows)) == len(all_support_rows), 'support archives overlap')
    for inventory, scope_name, prefix in ((support, 'SUPPORT-SCOPE.json', 'audi-recovery-support/'), (support2, 'SUPPORT2-SCOPE-v2.json', 'audi-recovery-support2/'), (support3, 'SUPPORT3-SCOPE.json', 'audi-recovery-support3/')):
        scope_path = C / scope_name
        check(scope_path, inventory['scopePin'])
        declared = load(scope_path)
        filenames = declared['files']
        ck(len(filenames) == len(set(filenames)), 'duplicate support scope filename')
        for filename in filenames:
            safe(filename)
        ck([row['path'] for row in inventory['files']] == [prefix + filename for filename in filenames], 'support inventory differs from exact scope')
        ck([row['payloadPath'] for row in inventory['files']] == [str(C / filename) for filename in filenames], 'support inventory payload scope differs')
    check(C / 'SUPPORT-MEMBER-INVENTORY.json', support2['originalSupportInventoryPin'])
    expected_prior_inventories = [{'path': str(C / name), **pin(C / name)} for name in ('SUPPORT-MEMBER-INVENTORY.json', 'SUPPORT2-MEMBER-INVENTORY-v2.json')]
    ck(support3['priorSupportInventoryPins'] == expected_prior_inventories, 'support3 prior inventory provenance differs')
    ck(support3['exactByteReuse'] == load(C / 'SUPPORT3-SCOPE.json').get('exactByteReuse', []) == [], 'unexpected support3 aliases')
    aliases = support2['exactByteReuse']
    ck(aliases == load(C / 'SUPPORT2-SCOPE-v2.json').get('exactByteReuse', []), 'support aliases differ from scope')
    available_members = {row['path']: row for row in all_support_rows}
    alias_paths = set()
    for alias in aliases:
        alias_path = P(alias['originalPath'])
        ck(alias_path.parent == C and str(alias_path) not in alias_paths and alias_path.name not in load(C / 'SUPPORT2-SCOPE-v2.json')['files'], 'invalid or duplicate exact-byte support alias')
        alias_paths.add(str(alias_path))
        check(alias_path, alias)
        target = available_members[alias['retainedMember']]
        ck(all(alias[key] == target[key] for key in ('bytes', 'sha256')), 'support alias retained bytes differ')
        ck(alias['reconstruction'] == 'Copy the exact retained member bytes to this historical support filename when reproducing its recorded command', 'support alias reconstruction differs')
    for row in all_support_rows:
        check(row['payloadPath'], row)
    scripts = [row for row in all_support_rows if P(row['payloadPath']).suffix == '.py']
    ck(len({(row['bytes'], row['sha256']) for row in scripts}) == len(scripts), 'duplicate executable bytes in support instead of one exact retained copy')
    retained_paths = {str(P(row['payloadPath'])) for row in all_support_rows}
    RESULT['diagnosticSeedReadExecutions'] = scanner_fixture_evidence(retained_paths)
    RESULT['supportRuntimeAdjudicationEvidence'] = support_adjudication_evidence(review['runtimeCodeAdjudication'], retained_paths)
    for key in ('dependencyRelocation', 'additionalSupportPreflight'):
        for row in review[key].values():
            check(row['path'], row)
            ck(row['path'] in retained_paths, 'new correction evidence missing from support3')
    new_preflight = load(review['additionalSupportPreflight']['report']['path'])
    ck(new_preflight['result'] == 'PASS' and new_preflight['seedReads'] == new_preflight['historicalArchiveReads'] == 0, 'support3 source preflight differs')
    for row in new_preflight['files']:
        check(C / row['filename'], row)
        ck(str(C / row['filename']) in retained_paths and not row['primaryFindings'] and not row['rawRuntimeFindings'], 'support3 executable preflight scope differs')
    RESULT['additionalSupportPreflight'] = {'report': review['additionalSupportPreflight']['report'], 'terminal': terminal(review['additionalSupportPreflight']['terminal']['path'], ['python3', '-B', review['additionalSupportPreflight']['script']['path']])}
    for row in command_plan['scriptPins']:
        if P(row['path']).parent == C:
            ck(row['path'] in retained_paths, 'current unique script missing from support')
    retained_script_pins = {(row['bytes'], row['sha256']) for row in scripts}
    for path in C.glob('*.py'):
        actual = pin(path)
        ck((actual['bytes'], actual['sha256']) in retained_script_pins, 'unique local script version not retained ' + path.name)
    for inventory, package in zip(support_inventories, support_packages):
        members = rows_map(inventory['files'])
        metadata_names = set(rows_map(package['memberFiles'])) - set(members)
        ck(len(metadata_names) == 1, 'support metadata membership differs')
        name = next(iter(metadata_names))
        ck(name.startswith('recovery-metadata/' + LABEL + '-support') and name.endswith('.json'), 'support metadata name differs')
        generated[name] = encoded(inventory)
        members[name] = {'path': name, 'bytes': len(generated[name]), 'sha256': hashlib.sha256(generated[name]).hexdigest()}
        ck(rows_map(package['memberFiles']) == members, 'support member/metadata union differs')
    ck(any(P(row['payloadPath']) == P(__file__) for row in support3['files']), 'current verifier missing from additive support3')
    seed_contract = load(C / 'INDEPENDENT-AUDI-SEED-METADATA-CONTRACT-v1.json')
    ck(seed_contract['result'] == 'PASS_STATIC_EXACT_SEED_METADATA_CONTRACT' and seed_contract['originalSeedReadBlockerResolved'], 'seed exception contract absent')
    check(C / 'SEED-PROVENANCE.json', seed_contract['provenancePin'])
    expected_counts = {key: value for key, value in load(BASE / 'scan-01.json').items() if key.endswith(('Values', 'Forms')) or key == 'originalSeedMembers'}
    expected_counts.update(audiRuntimeValues=6, audiRuntimeForms=37, audiOriginalPayloadReadOperations=6)
    prior_cache = load(BASE / 'scan-01.json')['patternCacheProvenance']
    cache_source = {row['path']: row for row in load(C.parent / 'xpeng-registered-working-20261014T2030/source-capture.json')['files']}
    fresh, verified_archives, scan_rows = {}, [], []
    for index, archive in enumerate(archives, 1):
        path = P(archive['file'])
        ck(path.parent == R and path.name == archive['filename'], 'fresh archive locator differs')
        check(path, archive)
        wanted = rows_map(archive['memberFiles'])
        actual = {}
        with lzma.open(path, 'rb') as stream:
            with tarfile.open(fileobj=stream, mode='r|') as tar:
                for member in tar:
                    safe(member.name)
                    ck(member.isfile() and member.name in wanted and member.name not in actual and member.name not in fresh, 'unsafe/unexpected/duplicate member ' + member.name)
                    digest, count = hashlib.sha256(), 0
                    parts = [] if member.name in generated else None
                    with tar.extractfile(member) as payload:
                        while block := payload.read(CHUNK):
                            digest.update(block)
                            count += len(block)
                            if parts is not None:
                                parts.append(block)
                    row = {'path': member.name, 'bytes': count, 'sha256': digest.hexdigest()}
                    ck(row == wanted[member.name] and count == member.size, 'fresh member hash differs ' + member.name)
                    actual[member.name] = row
                    fresh[member.name] = row
                    if parts is not None:
                        ck(b''.join(parts) == generated[member.name], 'generated metadata bytes differ')
            while stream.read(CHUNK):
                pass
        ck(actual == wanted and list(actual) == list(wanted) and len(actual) == archive['members'], 'member order/coverage differs')
        check(path, archive)
        scan_name = f'scan-final-{index:02d}' + ('-v2' if index == 7 else '')
        report_path = C / (scan_name + '.json')
        report = load(report_path)
        actual_scanner = scanner_path if index == 8 else C / ('privacy_v6.py' if index == 7 else 'privacy_v5.py')
        scan_terminal = terminal(C / (scan_name + '.resources.json'), ['python3', str(actual_scanner), str(path), str(report_path)], expected_exit=2 if index == 7 else 0)
        runtime_adjudication = None
        if index == 7:
            from audi_support_runtime_adjudication_v1 import adjudicate
            runtime_adjudication = adjudicate(report, archive['memberFiles'], {'archive': path.name, **{key: archive[key] for key in ('bytes', 'sha256')}})
        ck(report['status'] == ('review-required' if index == 7 else 'clean') and report['archive'] == path.name and report['archivePin'] == {key: archive[key] for key in ('bytes', 'sha256')} and rows_map(report['members']) == actual, 'privacy coverage differs')
        ck(report['regularFilesScanned'] == len(actual) and report['bytesScanned'] == sum(row['bytes'] for row in actual.values()) and report['currentByteSearchForEveryMember'] and report['chunkBytes'] == CHUNK, 'privacy totals differ')
        ck(all(not report[key] for key in ('exactValueMatches', 'primaryHeaderCandidates', 'errors')), 'unresolved privacy findings')
        ck(index == 7 or not report['unclassifiedRuntimeCandidates'], 'unresolved runtime findings outside exact reviewed support')
        ck(all(report[key] == value for key, value in expected_counts.items()), 'known-value counts differ')
        ck(report['patternCacheProvenance'] == prior_cache and report['originalSeedMembers'] == seed_contract['seedMemberCount'], 'scanner cache or seed coverage differs')
        for row in report['members']:
            name = row['path']
            eligible = name.startswith('roadmark/') and name != 'roadmark/SOURCE-FILE-MANIFEST.json' and name[9:] in cache_source and core(row) == {'path': name, 'bytes': cache_source[name[9:]]['bytes'], 'sha256': cache_source[name[9:]]['sha256']}
            ck((row['patternVerdict'] == 'exact-prior-source-cache') == eligible, 'pattern cache eligibility differs')
            ck(eligible or row['patternVerdict'] == 'current-full-unchanged-scanner', 'unknown pattern verdict')
            ck(row['exactMatchesObserved'] == row['classifiedPublicLexicalCollisions'] + row['unresolvedExactMatches'] and row['unresolvedExactMatches'] == 0, 'exact-match accounting differs')
        ck(sum(row['classifiedPublicLexicalCollisions'] for row in report['members']) == report['classifiedPublicLexicalCollisions'], 'collision sum differs')
        approved_code = [row for row in runtime_proposal['exactSupportCodeClassifications'] if row['member'] in actual]
        expected_code = [{'member': row['member'], 'filePin': row['filePin'], 'finding': {key: value for key, value in row['exactFinding'].items() if key != 'member'}, 'classification': 'Exact independently reviewed noncredential Python key-handling syntax'} for row in approved_code]
        ck(report['classifiedExactCodeHeaderCandidates'] == expected_code, 'exact code classification coverage differs')
        scan_rows.append({'archive': path.name, 'report': pin(report_path), 'terminal': scan_terminal, 'members': len(actual), 'bytes': sum(row['bytes'] for row in actual.values()), 'classifiedPublicLexicalCollisions': report['classifiedPublicLexicalCollisions'], 'targetedHistoricalSeedMembersRead': report['originalSeedMembers'], 'targetedHistoricalSeedArchives': seed_contract['seedArchiveCount'], 'inheritedArchiveOverlap': seed_contract['inheritedArchiveOverlapCount']})
        if runtime_adjudication is not None:
            scan_rows[-1]['runtimeCodeAdjudication'] = runtime_adjudication
        verified_archives.append({'filename': path.name, **pin(path), 'members': len(actual), 'uncompressedBytes': sum(row['bytes'] for row in actual.values())})
        print(json.dumps({'stage': 'fresh-only-independent-replay', 'archive': index, 'members': len(actual), 'result': 'PASS'}), flush=True)
    ck(fresh == rows_map(plan['newFiles']) and len(fresh) == plan['freshFiles'] and sum(row['bytes'] for row in fresh.values()) == plan['freshBytes'], 'fresh union differs')
    merged = {name: row for name, row in old.items() if not name.startswith('roadmark/')}
    merged.update(fresh)
    ck(merged == rows_map(plan['files']) and len(merged) == plan['logicalFiles'] and sum(row['bytes'] for row in merged.values()) == plan['logicalBytes'], 'logical overlay differs')
    ck((set(old) & set(fresh)) - {name for name in old if name.startswith('roadmark/')} == set(scope['expectedNonSourceOverlay']), 'unexpected non-source overlay')
    expected_archives = [dict(source_package) if row['group'].startswith('source-') else {**row, 'new': False} for row in base['archivesInRestoreOrder']] + proof_packages + support_packages
    for index, row in enumerate(expected_archives, 1):
        row['restoreOrder'] = index
    ck(sum(row['group'].startswith('source-') for row in base['archivesInRestoreOrder']) == 1, 'base source archive count differs')
    ck(expected_archives == plan['archivesInRestoreOrder'] and plan['baseArchivesReused'] == len(base['archivesInRestoreOrder']) - 1 and plan['archiveCount'] == len(expected_archives), 'inherited archive identity/order differs')
    ck(load(C / 'FRESH-ONLY-RESTORE-MANIFEST-v4.json') == {'archivesInRestoreOrder': archives, 'files': list(fresh.values())}, 'fresh-only restore manifest differs')
    for row in proof_capture['files']:
        ck(merged[row['path']] == core(row), 'selected proof missing from final overlay')
    inherited_sanitized = []
    def inherited_mappings(value):
        if isinstance(value, dict):
            if 'sanitizedBytes' in value and 'sanitizedSHA256' in value and ('restorePath' in value or 'path' in value):
                name = value.get('restorePath') or value['path']
                ck(merged[name] == old[name] == {'path': name, 'bytes': value['sanitizedBytes'], 'sha256': value['sanitizedSHA256']}, 'inherited sanitation pin differs')
                inherited_sanitized.append(name)
            for child in value.values():
                inherited_mappings(child)
        elif isinstance(value, list):
            for child in value:
                inherited_mappings(child)
    for name in ('sourceSanitation', 'copyOnlySanitation', 'inheritedCopyOnlySanitation', 'originalRawCaptureReplayCompatibility'):
        inherited_mappings(base[name])
    for row in base['copyOnlySanitation'].get('files', []):
        if row.get('metadataKeyRename'):
            ck(merged[row['path']] == old[row['path']] == core(row), 'inherited prose-key copy changed')
    inherited_dependencies = base['inheritedDependencyReconstruction']['dependencies']
    relocation_path = C / 'INHERITED-DEPENDENCY-RELOCATION-v1.json'
    check(relocation_path, {'bytes': 3256, 'sha256': 'd9db45a750c70331cd3f39cf54ffee4e5d6e172b0b6226a81f8f616f669bd3d4'})
    relocation = load(relocation_path)
    for row in relocation['failedReplay'].values():
        check(row['path'], row)
        ck(row['path'] in retained_paths, 'prior failed replay evidence not retained')
    failed_output = load(relocation['failedReplay']['verification']['path'])
    ck(failed_output['result'] == 'BLOCKED' and failed_output['blocker']['message'] == 'inherited dependency member changed', 'prior independent failure history differs')
    prior_terminal = terminal(relocation['failedReplay']['terminal']['path'], ['python3', str(C / 'independent_audi_recovery_v3.py'), '--sole-child-slot-authorized'], expected_exit=1)
    for filename in ('independent-replay.resources.invocation.json', 'independent-replay.err'):
        ck(str(C / filename) in retained_paths, 'prior failure invocation/stderr not retained')
    prior_log = [json.loads(line) for line in P(relocation['failedReplay']['completeFreshMemberReplayLog']['path']).read_text().splitlines()]
    ck(len(prior_log) == 8 and prior_log[-1]['result'] == 'BLOCKED', 'prior failed replay log differs')
    for index, row in enumerate(prior_log[:-1], 1):
        ck(row == {'stage': 'fresh-only-independent-replay', 'archive': index, 'members': archives[index - 1]['members'], 'result': 'PASS'}, 'prior successful archive replay observation differs')
    RESULT['preservedPriorIndependentFailure'] = {'verification': relocation['failedReplay']['verification'], 'terminal': prior_terminal, 'completeFreshMemberReplayLog': relocation['failedReplay']['completeFreshMemberReplayLog'], 'successfulArchiveMemberPassesBeforeMetadataFailure': 7, 'failureNotReclassifiedAsOverallPass': True}
    ck(len(relocation['entries']) == relocation['relocatedDependencyPins'] == 1 and relocation['priorDependencyRecords'] == len(inherited_dependencies) == 114 and relocation['unchangedDependencyPins'] == 113, 'dependency relocation scope differs')
    correction = relocation['entries'][0]
    ck(relocation['originalExpectedPathsAndHashesUnchanged'] and not relocation['payloadChanges'] and correction['originalExpectedUnchanged'], 'dependency original pin changed')
    check(base_path, relocation['history']['baseManifest'])
    ck(relocation['history']['originalMappingField'] == '/inheritedDependencyReconstruction', 'dependency history field differs')
    relocated_count = unchanged_count = 0
    for dependency in inherited_dependencies:
        for item in dependency['pins']:
            member = item['member']
            ck(old[member['path']] == core(member), 'historical dependency member differs from prior manifest')
            if core(member) == correction['historicalMember']:
                target = correction['relocatedMember']
                ck(dependency['originalPath'] == correction['dependencyOriginalPath'] and item['expected'] == correction['originalExpected'], 'dependency relocation original expectation differs')
                ck(merged[member['path']] == correction['currentSourceMember'] and target['path'] != member['path'], 'dependency source replacement differs')
                ck(merged[target['path']] == fresh[target['path']] == target and all(target[key] == member[key] for key in ('bytes', 'sha256')), 'relocated dependency exact fresh member differs')
                candidates = [archive for archive in archives if target['path'] in rows_map(archive['memberFiles'])]
                ck(len(candidates) == 1 and {key: candidates[0][key] for key in ('filename', 'bytes', 'sha256')} == correction['relocatedMemberArchive'], 'relocated dependency archive differs')
                relocated_count += 1
            else:
                ck(merged[member['path']] == core(member), 'unapproved inherited dependency member change')
                unchanged_count += 1
            ck(member['sha256'] == item['expected']['sha256'] and (item['expected'].get('bytes') is None or member['bytes'] == item['expected']['bytes']), 'inherited original dependency expectation differs')
    ck(relocated_count == 1 and unchanged_count == 113, 'dependency relocation coverage differs')
    RESULT['inheritedDependencyRelocation'] = {'mapping': pin(relocation_path), 'priorRecords': 114, 'unchangedPins': unchanged_count, 'relocatedPins': relocated_count, 'originalExpectedPinsUnchanged': True, 'freshBeforeCopyVerified': True}
    links = load(C / 'SYMLINK-RECONSTRUCTION.json')
    ck(links['result'] == 'EXACT_METADATA_AND_MEMBER_MAPPING' and links['noTraversalOrDependencyCapture'] and len(links['links']) == len(scope['metadataOnlySymlinks']) == 7, 'link reconstruction scope differs')
    for row, expected in zip(links['links'], scope['metadataOnlySymlinks']):
        ck(all(row[key] == value for key, value in expected.items()), 'original link metadata differs')
        ck(row['restoreLinkPath'] == restore_path(row['path']), 'restore link location differs')
        if row.get('dependencyTreeExcluded'):
            ck(row['retainedMembers'] == [] and expected['resolvedTarget'] == str(W / 'roadmark-104/node_modules'), 'dependency link mapping differs')
        else:
            target = restore_path(expected['resolvedTarget'])
            ck(row['restoreTargetPath'] == target and row['retainedMembers'], 'link target mapping absent')
            for member in row['retainedMembers']:
                ck(member['path'] == target or member['path'].startswith(target + '/'), 'link member outside target')
                ck(merged[member['path']] == core(member), 'link target member hash differs')
    ck(sum(bool(row.get('dependencyTreeExcluded')) for row in links['links']) == 2, 'dependency link count differs')
    application = load(C / 'APPLICATION-ASSERTION-CONTRACT.json')
    ck(application['result'] == 'APPROVED_EXACT_CAPTURED_APPLICATION_ASSERTIONS', 'application assertion contract absent')
    checked_assertions = []
    for assertion in application['assertions']:
        name = assertion['restorePath']
        row = captured[name]
        check(row['payloadPath'], row)
        actual = pointer(load(row['payloadPath']), assertion['pointer'])
        ck(actual == assertion['expected'], 'application assertion differs ' + name + assertion['pointer'])
        checked_assertions.append({'restorePath': name, 'pointer': assertion['pointer'], 'passed': True})
    original_pin_transformations = []
    for expected in application['retainedPins']:
        if merged[expected['path']] != core(expected):
            row = captured[expected['path']]
            ck(expected['path'] in set(renamed) | set(runtime_rows) and original(row) == {key: expected[key] for key in ('bytes', 'sha256')} and merged[expected['path']] == core(row), 'mandatory original application pin lacks exact approved copy mapping')
            original_pin_transformations.append(expected['path'])
    gate = load(C / 'ALL-ARCHIVE-PRIVACY-GATE-v4.json')
    ck(gate['result'] == 'PASS' and gate['freshMembers'] == len(fresh) and gate['freshBytes'] == sum(row['bytes'] for row in fresh.values()) and len(gate['archives']) == len(archives), 'aggregate privacy union differs')
    ck(gate['classifiedPublicLexicalCollisions'] == sum(row['classifiedPublicLexicalCollisions'] for row in scan_rows) and gate['unclassifiedFindings'] == gate['errors'] == 0, 'aggregate privacy findings differ')
    ck(gate['audiRuntimeValues'] == 6 and gate['audiRuntimeForms'] == 37 and gate['classifiedExactCodeHeaderCandidates'] == 10 and gate['classifiedExactCodeRuntimeCandidates'] == 3, 'aggregate Audi/code scope differs')
    ck(gate['rawRuntimeCandidatesPreserved'] == 3 and not gate['rawScannerResultsModified'] and gate['sixExactCleanReportsReused'], 'raw adjudicated report preservation differs')
    for key, filename in (('supportRuntimeClassification', 'INDEPENDENT-AUDI-SUPPORT-RUNTIME-CLASSIFICATION-v1.json'), ('supportRuntimeApproval', 'APPROVED-AUDI-SUPPORT-ADJUDICATION-v1.json'), ('supportRuntimeFixture', 'INDEPENDENT-AUDI-SUPPORT-RUNTIME-FIXTURE-v2.json'), ('priorFailedSupportScan', 'scan-final-07.json')):
        check(C / filename, gate[key])
    for row, expected in zip(gate['archives'], scan_rows):
        ck(row.get('runtimeCodeAdjudication') == expected.get('runtimeCodeAdjudication'), 'aggregate exact runtime adjudication differs')
        ck(row['archive'] == expected['archive'] and row['reportPin'] == expected['report'] and row['members'] == expected['members'] and row['bytes'] == expected['bytes'], 'aggregate privacy report binding differs')
    actual_seed_reads = seed_invocations()
    ck(len(actual_seed_reads) == review['expectedProductionScanInvocations']['atReplay']['historical'], 'initial/final historical seed invocation accounting differs')
    RESULT['targetedHistoricalSeedExecutions'] = {'completedInvocations': len(actual_seed_reads), 'targetedPinnedMemberReads': 200 * len(actual_seed_reads), 'uniquePinnedMembers': 200, 'uniqueHistoricalArchives': 21, 'receipts': actual_seed_reads, 'separateFromFreshMemberReplay': True}
    actual_audi_reads = audi_seed_invocations()
    ck(len(actual_audi_reads) == review['expectedProductionScanInvocations']['atReplay']['audi'], 'final Audi seed invocation accounting differs')
    RESULT['targetedAudiSeedExecutions'] = {'completedInvocations': len(actual_audi_reads), 'originalPayloadReadOperations': 6 * len(actual_audi_reads), 'uniqueOriginalFiles': 4, 'distinctValues': 6, 'variantForms': 37, 'receipts': actual_audi_reads, 'noValuesOrValueDigestsPersisted': True, 'generalURLDecodedRuntimeCoverageClaimed': False}
    RESULT['runtimeSanitation'] = {'mapping': pin(C / 'COPY-SANITATION-MAPPING-v2.json'), 'classification': pin(C / 'INDEPENDENT-AUDI-RUNTIME-BATCH-CLASSIFICATION-v1.json'), 'files': 33, 'ranges': 47, 'extraBytes': 6, 'everyOutsideRangeByteUnchanged': True, 'originalExpectedPinsUnchanged': True, 'originalRawReplayRequiresIntactOriginalsOrReviewedMappedInputs': True}
    for name, expected in input_pins.items():
        check(C / name, expected)
    for row in command_plan['scriptPins']:
        check(row['path'], row)
    live = []
    seen = set()
    for row in source_capture['files'] + proof_capture['files']:
        if row['originalPath'] in seen:
            continue
        seen.add(row['originalPath'])
        try:
            current_identity = identity(row['originalPath'])
        except (FileNotFoundError, AssertionError):
            current_identity = None
        if current_identity != row['sourceIdentity']:
            live.append({'path': row['originalPath'], 'capturedIdentity': row['sourceIdentity'], 'currentIdentity': current_identity, 'classification': 'Later live-path identity differs from the immutable verified captured cut'})
    dump(REPLAY, {'result': 'PASS', 'method': 'Fresh source/proof/support only; non-materializing 64 KiB streaming SHA256/member-order verification to XZ EOF', 'archives': verified_archives, 'files': list(fresh.values()), 'fileCount': len(fresh), 'bytes': sum(row['bytes'] for row in fresh.values()), 'noExtractedTree': True})
    RESULT.update(result='PASS', verificationScope='All fresh source/proof/support members streamed and exact logical overlay verified. No inherited archive replay or restore clone; scanner targeted historical seed reads are separately accounted.', source={'files': len(current), 'changedPaths': sorted(changed), 'exactPriorReuse': len(reused_source), 'captureCutoff': source_capture['captureCutoff'], 'strictCompressedUnder15000000': True}, proof={'selectedOriginalFiles': len(captured), 'sourceCovered': len(covered), 'reusedBaseMembers': len(reused), 'newDeltaFiles': len(delta), 'exactProseKeyRenames': renamed, 'captureCutoff': proof_capture['captureCutoff']}, support={'inventory': pin(C / 'SUPPORT-MEMBER-INVENTORY.json'), 'archive': verified_archives[-1], 'uniquePinnedMembers': len(support['files']), 'noRecursiveExecutableText': True}, newArchives=verified_archives, phaseTerminals=phases, privacy={'result': 'PASS', 'reports': scan_rows, 'seedCounts': expected_counts, 'targetedSeedReadContract': pin(C / 'INDEPENDENT-AUDI-SEED-METADATA-CONTRACT-v1.json'), 'knownValuesPersistedOrPrinted': False, 'blockingOrUnclassifiedFindings': 0, 'limitations': ['No decryption', 'No recursive arbitrary embedded format decoding', 'Standalone base64 does not cover arbitrary wrapping/alignment', 'No universal secret-free claim']}, replay={'manifest': pin(REPLAY), 'noDiskExtractedTree': True}, overlay={'baseArchiveCount': len(base['archivesInRestoreOrder']), 'unchangedBaseArchivesReused': len(base['archivesInRestoreOrder']) - 1, 'combinedArchiveCount': len(expected_archives), 'combinedLogicalFiles': len(merged), 'combinedLogicalBytes': sum(row['bytes'] for row in merged.values()), 'freshFiles': len(fresh), 'freshBytes': sum(row['bytes'] for row in fresh.values()), 'inheritedPayloadReadsByIndependentVerifier': 0}, inheritedSanitation={'exactPreservedMembers': len(set(inherited_sanitized)), 'allOriginalAndSanitizedPinsUnchanged': True}, application={'contract': pin(C / 'APPLICATION-ASSERTION-CONTRACT.json'), 'assertions': checked_assertions, 'mandatoryRetainedPins': len(application['retainedPins']), 'workingState': state, 'openGates': scope['openGates']}, postCaptureLiveChanges=live, inputPins=input_pins, verifierScript=pin(__file__), noUploadsOrDeletion=True)

    archive_lookup = {row['filename']: row for row in verified_archives}
    RESULT['support']['archive'] = archive_lookup[support_package['filename']]
    RESULT['supports'] = [{'inventory': pin(C / filename), 'archive': archive_lookup[package['filename']], 'uniquePinnedMembers': len(inventory['files']), 'noRecursiveExecutableText': True} for filename, inventory, package in zip(('SUPPORT-MEMBER-INVENTORY.json', 'SUPPORT2-MEMBER-INVENTORY-v2.json', 'SUPPORT3-MEMBER-INVENTORY.json'), support_inventories, support_packages)]
    RESULT['proof']['runtimeSanitizedFiles'] = sorted(runtime_rows)
    RESULT['proof']['originalApplicationPinsSatisfiedThroughExactCopyMapping'] = original_pin_transformations
    RESULT['privacy']['exactCodeContextClassifications'] = 10
    RESULT['privacy']['exactRuntimeCodeContextClassifications'] = 3
    RESULT['privacy']['rawReviewRequiredSupportReportPreserved'] = True
    RESULT['privacy']['limitations'].extend(['Targeted URL-component stock-search fields only; no general URL-decoded runtime coverage', 'Diagnostic original-payload reads are retained separately from production scanner seed-execution totals'])

if __name__ == '__main__':
    code = 0
    try:
        main()
    except BaseException as error:
        code = 1
        RESULT.update(result='BLOCKED', blocker={'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()})
    RESULT['completedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    RESULT['resources'] = {'wallSeconds': round(time.monotonic() - START, 3), 'maxRssKiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss, 'addressSpaceLimitBytes': resource.getrlimit(resource.RLIMIT_AS)[0], 'chunkBytes': CHUNK, 'noRestoreClone': True}
    dump(OUT, RESULT)
    print(json.dumps({'result': RESULT['result'], 'resources': RESULT['resources'], 'blocker': RESULT.get('blocker')}), flush=True)
    sys.exit(code)
