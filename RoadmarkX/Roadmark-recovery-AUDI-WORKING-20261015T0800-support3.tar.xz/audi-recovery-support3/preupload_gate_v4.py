from capture_v2 import *
q=load(C/'ALL-ARCHIVE-PRIVACY-GATE-v4.json');v=load(C/'INDEPENDENT-AUDI-RECOVERY-VERIFICATION-v4.json');r=load(C/'RESTORE-PLAN-v4.json');assert q['result']==v['result']=='PASS';assert q['freshMembers']==r['freshFiles'] and q['freshBytes']==r['freshBytes'];assert q['unclassifiedFindings']==q['errors']==0;assert r['source']['bytes']<15000000;assert r['baseArchivesReused']==118
uploads=[]
for a in r['newArchives']:
 check(P(a['file']),a);uploads.append({'local_path':a['file'],'purpose':'create_library_file','library_artifact_type':'other'})
dump(C/'PREUPLOAD-GATE.json',{'result':'PASS','privacy':pin(C/'ALL-ARCHIVE-PRIVACY-GATE-v4.json'),'independentRecovery':pin(C/'INDEPENDENT-AUDI-RECOVERY-VERIFICATION-v4.json'),'restorePlan':pin(C/'RESTORE-PLAN-v4.json'),'newArchives':len(uploads),'sourceUnderStrict15000000':True,'noBaseRestoreOrFullBaseScan':True,'targetedSeedDependency':pin(C/'TARGETED-SEED-READ-DEPENDENCY.json')});dump(C/'library-archives-request.json',{'uploads':uploads});print('PASS: verified archives ready for ordered prepared persistence')
