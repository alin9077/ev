from package_v1 import *
inv=load(C/'SUPPORT3-MEMBER-INVENTORY.json');metadata={'recovery-metadata/'+LABEL+'-support3.json':(json.dumps(inv,indent=2)+'\n').encode()};a=pack(R/f'Roadmark-recovery-{LABEL}-support3.tar.xz',inv['files'],metadata);dump(C/'support3-package.json',a);print(json.dumps({'support3Members':a['members'],'support3Bytes':a['bytes']}))
