#!/usr/bin/env python3
"""Independent compact documents, active persistence and terminal closure checks."""
import datetime
import hashlib
import json
import os
import pathlib
import resource
import sys
import time
import traceback
from independent_audi_recovery_v4 import C, BASE, CHUNK, LIMIT, ck, load, dump, pin, check, rows_map, seed_invocations, audi_seed_invocations

D = C / 'deliverables'
STEM = 'AUDI-WORKING-20261015'
NAMES = {
    'documents': 'INDEPENDENT-DELIVERY-DOCUMENT-CHECK.json',
    'active': 'INDEPENDENT-ACTIVE-RECEIPT-CHECK.json',
    'persisted-active': 'INDEPENDENT-PERSISTED-ACTIVE-CHECK.json',
    'terminal': 'INDEPENDENT-AUDI-TERMINAL-CLOSURE-v1.json'
}

def native(phase, expected=None):
    result = load(C / f'library-{phase}-results.json')['results']
    request = load(C / f'library-{phase}-request.json')['uploads']
    verified = [json.loads(line) for line in (C / f'library-{phase}-verified.jsonl').read_text().splitlines()]
    ck(len(result) == len(request) == len(verified), 'native phase count differs ' + phase)
    values = []
    for row, wanted, witness in zip(result, request, verified):
        path = pathlib.Path(row['local_path'])
        ck(row['status'] == 'succeeded' and row['local_metadata_applied'] and row['local_path'] == wanted['local_path'], 'native result order/state differs')
        ck(witness['verified'] and witness['filename'] == path.name and witness['library_file_id'] == row['library_file_id'] and witness['version'] == row['current_version_number'], 'native readback identity differs')
        ck(os.getxattr(path, 'user.library-file-id').decode() == row['library_file_id'] and os.getxattr(path, 'user.library-file-version').decode() == str(row['current_version_number']), 'native local identity differs')
        if phase == 'archives':
            wanted_pin = expected[path.name]
            ck({key: witness[key] for key in ('bytes', 'sha256')} == wanted_pin and path.stat().st_size == wanted_pin['bytes'], 'archive persisted pin differs')
            actual = wanted_pin
        else:
            actual = pin(path)
            ck({key: witness[key] for key in ('bytes', 'sha256')} == actual, 'document persisted pin differs')
        values.append({'filename': path.name, 'library_file_id': row['library_file_id'], 'file_id': row['file_id'], 'version': row['current_version_number'], **actual})
    ck(len({row['library_file_id'] for row in values}) == len(values), 'duplicate native file ID')
    return values

def privacy(name, paths):
    report = load(C / name)
    ck(report['result'] == 'PASS' and not report['findings'] and not report['errors'] and report['currentCompletePatternScan'] and report['allKnownValueForms'], 'document privacy failed')
    ck(report['audiRuntimeValues'] == 6 and report['audiRuntimeForms'] == 37 and report['audiOriginalPayloadReadOperations'] == 6, 'document Audi residual coverage differs')
    actual = {path.name: pin(path) for path in paths}
    seen = {}
    for row in report['files']:
        ck(row['filename'] not in seen, 'duplicate document privacy record')
        seen[row['filename']] = {key: row[key] for key in ('bytes', 'sha256')}
        ck(row['exactValueMatches'] == row['primaryCandidates'] == row['runtimeCandidates'] == 0, 'document privacy unresolved finding')
        ck(row['exactMatchesObserved'] == row['classifiedPublicLexicalCollisions'], 'document exact-match accounting differs')
    ck(seen == actual, 'document privacy input pin/coverage differs')
    return pin(C / name)

def seed_summary(summary, actual, complete=False):
    records = {row['receipt']: row for row in actual}
    listed = summary['receipts']
    ck(summary['completedInvocations'] == len(listed) and summary['targetedPinnedMemberReads'] == 200 * len(listed), 'seed summary totals differ')
    ck(summary['uniquePinnedMembers'] == 200 and summary['uniqueHistoricalArchives'] == 21 and summary['noExtractedValues'], 'seed summary scope differs')
    names = set()
    for row in listed:
        ck(row['receipt'] not in names and row['receipt'] in records, 'seed summary receipt missing/duplicate')
        names.add(row['receipt'])
        expected = records[row['receipt']]
        ck(all(row[key] == expected[key] for key in ('bytes', 'sha256', 'record')), 'seed summary receipt bytes or data differ')
    if complete:
        ck(names == set(records), 'final seed summary omits invocation')
    elif summary.get('asOf'):
        cutoff = datetime.datetime.fromisoformat(summary['asOf'])
        ck(names == {row['receipt'] for row in actual if datetime.datetime.fromisoformat(row['record']['completedAt']) <= cutoff}, 'seed as-of boundary differs')
    return {'completedInvocations': len(listed), 'targetedPinnedMemberReads': 200 * len(listed)}

def no_embedded_code(value):
    if isinstance(value, dict):
        ck('verificationSupportFiles' not in value, 'legacy executable support embedding remains')
        if isinstance(value.get('text'), str) and isinstance(value.get('filename'), str):
            ck(not value['filename'].endswith('.py'), 'executable source embedded as document text')
        for child in value.values():
            no_embedded_code(child)
    elif isinstance(value, list):
        for child in value:
            no_embedded_code(child)

def audi_seed_summary(summary, actual, complete=False):
    ck(summary['distinctValues'] == 6 and summary['variantForms'] == 37 and summary['noValuesOrValueDigestsPersisted'], 'Audi summary scope differs')
    records = {row['receipt']: row for row in actual}
    names = set()
    for row in summary['receipts']:
        ck(row['receipt'] not in names and row['receipt'] in records, 'Audi summary receipt missing/duplicate')
        names.add(row['receipt'])
        ck(all(row[key] == records[row['receipt']][key] for key in ('bytes', 'sha256', 'record')), 'Audi summary data differs')
    ck(summary['completedInvocations'] == len(names) and summary['payloadReadOperations'] == 6 * len(names), 'Audi summary totals differ')
    if complete:
        ck(names == set(records), 'final Audi summary omits invocation')
    elif summary.get('asOf'):
        cutoff = datetime.datetime.fromisoformat(summary['asOf'])
        ck(names == {row['receipt'] for row in actual if datetime.datetime.fromisoformat(row['record']['completedAt']) <= cutoff}, 'Audi as-of boundary differs')
    return {'completedInvocations': len(names), 'payloadReadOperations': 6 * len(names), 'uniqueOriginalFiles': 4, 'distinctValues': 6, 'variantForms': 37, 'diagnosticReadsCountedSeparately': True}

def documents():
    plan = load(C / 'RESTORE-PLAN-v4.json')
    scope = load(C / 'FROZEN-CAPTURE-SCOPE.json')
    base = load(BASE / 'deliverables/Roadmark-RECOVERY-MANIFEST-SKODA-WORKING-20261015.json')
    prior = load(BASE / 'FINAL-SKODA-UPLOAD-RECEIPTS.json')
    manifest_path = D / f'Roadmark-RECOVERY-MANIFEST-{STEM}.json'
    verification_path = D / f'Roadmark-RECOVERY-VERIFICATION-{STEM}.json'
    index_path = D / f'Roadmark-RECOVERY-INDEX-{STEM}.md'
    summary_path = D / 'Roadmark-AUDI-M1-UPDATE-20261015.md'
    paths = [index_path, manifest_path, verification_path, summary_path]
    request = load(C / 'library-documents-request.json')['uploads']
    ck([row['local_path'] for row in request] == [str(path) for path in paths], 'document request order differs')
    manifest, verification = load(manifest_path), load(verification_path)
    archive_pins = {row['filename']: {key: row[key] for key in ('bytes', 'sha256')} for row in plan['newArchives']}
    persisted = native('archives', archive_pins)
    native_map = {row['filename']: row for row in persisted}
    archives = []
    for row in plan['archivesInRestoreOrder']:
        expected = {key: value for key, value in row.items() if key not in ('file', 'memberFiles', 'allMembersVerified')}
        if row.get('new'):
            expected.update({key: native_map[row['filename']][key] for key in ('library_file_id', 'file_id', 'version')})
        archives.append(expected)
    ck(manifest['archivesInRestoreOrder'] == archives and len(archives) == plan['archiveCount'], 'complete native archive chain differs')
    ck(manifest['newArchives'] == [row for row in archives if row.get('new')], 'new native archives differ')
    ck(manifest['files'] == plan['files'] and len(rows_map(manifest['files'])) == plan['logicalFiles'], 'logical file map differs')
    counts = {key: plan[key] for key in ('archiveCount', 'logicalFiles', 'logicalBytes', 'freshFiles', 'freshBytes', 'fullSourceFiles', 'baseArchivesReused')}
    ck(manifest['incrementalVerification'] == verification['counts'] == counts, 'document count schema differs')
    source = next(row for row in archives if row['group'].startswith('source-'))
    ck(manifest['source'] == verification['source'] == source and source['bytes'] < 15000000, 'source identity/limit differs')
    support_archive = next(row for row in archives if row['filename'].endswith('-support.tar.xz'))
    ck(manifest['supportArchive']['archive'] == support_archive and manifest['supportArchive']['members'] == load(C / 'support-package.json')['memberFiles'], 'support archive/member references differ')
    ck(verification['supportArchive'] == manifest['supportArchive'], 'verification support differs')
    additive_archive = next(row for row in archives if row['filename'].endswith('-support2-reviewed-v2.tar.xz'))
    ck(manifest['additiveSupportArchive']['archive'] == additive_archive and manifest['additiveSupportArchive']['members'] == load(C / 'support2-package-v2.json')['memberFiles'], 'additive support archive/member references differ')
    ck(verification['additiveSupportArchive'] == manifest['additiveSupportArchive'], 'verification additive support differs')
    corrective_archive = next(row for row in archives if row['filename'].endswith('-support3.tar.xz'))
    ck(manifest['closureSupportArchive']['archive'] == corrective_archive and manifest['closureSupportArchive']['members'] == load(C / 'support3-package.json')['memberFiles'], 'corrective support archive/member references differ')
    ck(verification['closureSupportArchive'] == manifest['closureSupportArchive'], 'verification corrective support differs')
    check(manifest_path, verification['manifestPin'])
    ind, gate = load(C / 'INDEPENDENT-AUDI-RECOVERY-VERIFICATION-v4.json'), load(C / 'ALL-ARCHIVE-PRIVACY-GATE-v4.json')
    ck(ind['result'] == gate['result'] == 'PASS' and manifest['independentVerification'] == verification['independentVerification'] == ind and manifest['privacyVerification'] == verification['privacyVerification'] == gate, 'independent/privacy outcomes differ')
    ck(manifest['status'] == verification['status'] == scope['workingResult'], 'status differs')
    state = manifest['workState']
    ck(state['authorizedFreshSteps'] == 9 and state['targetedTests'] == 190 and state['separateTypingCorrectionFocusedTests'] == 18 and state['targetedCountsNotClaimedDisjoint'], 'scoped checks/tests claims differ')
    ck(state['fullProjectTypeScriptPassed'] and state['typeScriptRoots'] == 361 and state['literalPackageTypeScriptScriptPassed'] is False and 'completeStandardTypeScriptPassed' not in state, 'typecheck qualification differs')
    ck(all(state[key] is False for key in ('fullProjectSuitePassed', 'buildPassed', 'mobilePassed', 'releaseReady', 'published')), 'unpassed release gate claimed')
    ck(state['currentCounts'] == {'catalogue': 427, 'tier1': 350, 'onSale': 309, 'packets': 25} and state['audiScope'] == {'newIdentities': 10, 'refreshedVersions': 7, 'unchangedPeers': 410}, 'application counts differ')
    ck(state['failedAttempts'] == scope['authorRetention']['includedFailures'] and state['sourceDelta'] == scope['sourceChangedPaths'], 'failed-history/source delta differs')
    inherit = ('sourceSanitation', 'originalRawCaptureReplayCompatibility', 'missingHistoricalCaptureProvenance', 'priorToyotaBrowserScreenshotExclusions', 'sourcePackagingExclusions', 'historicalExclusions', 'lastPassedRecovery', 'optionalReconstruction', 'partialOutputRetention', 'reusedVerifier', 'cleanupCandidatesExcludedFromRestore', 'cleanupListLibraryFileId', 'exactDuplicateProvenance')
    ck(all(manifest[key] == base[key] for key in inherit), 'inherited protection/provenance field differs')
    relocation = load(C / 'INHERITED-DEPENDENCY-RELOCATION-v1.json')
    ck(manifest['inheritedDependencyReconstructionHistory'] == {'baseManifestLibraryFileId': prior['manifestLibraryFileId'], 'mapping': base['inheritedDependencyReconstruction']} and manifest['inheritedDependencyRelocations'] == relocation, 'dependency relocation history differs')
    expected_dependencies = json.loads(json.dumps(base['inheritedDependencyReconstruction']))
    matches = 0
    for dependency in expected_dependencies['dependencies']:
        for item in dependency['pins']:
            entry = relocation['entries'][0]
            if item['member'] == entry['historicalMember']:
                ck(dependency['originalPath'] == entry['dependencyOriginalPath'] and item['expected'] == entry['originalExpected'], 'document relocation original expectation differs')
                item['member'] = entry['relocatedMember']
                matches += 1
    ck(matches == 1 and manifest['inheritedDependencyReconstruction'] == expected_dependencies, 'document dependency reconstruction relocation differs')
    for key in ('inheritedDependencyReconstruction', 'inheritedDependencyReconstructionHistory', 'inheritedDependencyRelocations'):
        ck(verification[key] == manifest[key], 'verification dependency reconstruction differs')
    ck(manifest['inheritedCopyOnlySanitation'] == base['inheritedCopyOnlySanitation'] + [{'cut': 'Skoda', 'mapping': base['copyOnlySanitation']}], 'inherited sanitation chain differs')
    ck(manifest['copyOnlySanitation'] == load(C / 'COPY-SANITATION-MAPPING-v2.json') and manifest['symlinkReconstruction'] == load(C / 'SYMLINK-RECONSTRUCTION.json'), 'new transformation/link mapping differs')
    sanitation = manifest['copyOnlySanitation']
    ck(manifest['currentRawCaptureReplayLimitation'] == sanitation['originalReplayLimitation'], 'current raw replay limitation absent')
    reference_counts = {'changedFiles': len(sanitation['files']), 'sourceIndexReferencedFiles': sum(bool(row['sourceIndexReferences']) for row in sanitation['files']), 'sourceIndexReferenceCount': sum(len(row['sourceIndexReferences']) for row in sanitation['files'])}
    ck(manifest['currentCopySourcePinReferenceCounts'] == reference_counts == {'changedFiles': 33, 'sourceIndexReferencedFiles': 30, 'sourceIndexReferenceCount': 79}, 'source-index reference association count differs')
    ck(manifest['baseRecovery']['manifestLibraryFileId'] == prior['manifestLibraryFileId'] and manifest['baseRecovery']['activeReceiptLibraryFileId'] == prior['activeReceiptLibraryFileId'], 'base native provenance differs')
    ck(manifest['baseRecovery']['archives'] == len(base['archivesInRestoreOrder']) and manifest['baseRecovery']['logicalFiles'] == len(base['files']) and manifest['baseRecovery']['unchangedArchivesReused'] == len(base['archivesInRestoreOrder']) - 1, 'base counts differ')
    summary = summary_path.read_text()
    ck(manifest['factualSummary'] == summary and pin(summary_path) == {'bytes': 5694, 'sha256': 'e767ebea754eda19a387fea5dccf069f2da332285fe31e08df92ec21c49c5628'}, 'frozen author summary differs')
    index = index_path.read_text()
    ck('raw scanner reports remain unchanged' in index and 'adjudication accepts only those three candidates' in index, 'exact source-syntax adjudication disclosure missing')
    ck(gate['classifiedExactCodeRuntimeCandidates'] == 3 and gate['rawRuntimeCandidatesPreserved'] == 3 and not gate['rawScannerResultsModified'], 'document raw-result adjudication disclosure differs')
    ck(f"Recommended chain: {len(archives)} archives, {plan['logicalFiles']:,} logical files" in index, 'index archive count differs')
    for row in archives:
        line = f"{row['restoreOrder']}. {row['filename']} | {row['library_file_id']} v{row['version']} | {row['bytes']} bytes | SHA-256 {row['sha256']}"
        ck(index.count(line) == 1, 'index exact restore row absent/duplicate')
    for row in verification['postSealCompactEvidence']:
        path = C / row['filename']
        ck(path.parent == C and path.suffix in ('.json', '.log', '.err'), 'invalid post-seal compact evidence path')
        check(path, row)
        ck(path.read_text() == row['text'], 'post-seal evidence text differs')
    no_embedded_code(manifest)
    no_embedded_code(verification)
    actual = seed_invocations()
    seed = manifest['targetedHistoricalSeedReadDependency']
    ck(seed['scope'] == load(C / 'TARGETED-SEED-READ-DEPENDENCY.json') and verification['targetedHistoricalSeedReadDependency'] == seed, 'seed dependency disclosure differs')
    summary_counts = seed_summary(seed['executedAsOfBuild'], actual)
    actual_audi = audi_seed_invocations()
    ck(manifest['audiRuntimeResidualVerification'] == verification['audiRuntimeResidualVerification'], 'Audi document summary differs')
    audi_counts = audi_seed_summary(manifest['audiRuntimeResidualVerification'], actual_audi)
    gate_pin = privacy('DELIVERABLE-PRIVACY-GATE.json', paths)
    return {'result': 'PASS', 'documents': [{'filename': path.name, **pin(path)} for path in paths], 'nativeArchives': persisted, 'recommendedArchives': len(archives), 'logicalFiles': plan['logicalFiles'], 'freshMembers': plan['freshFiles'], 'privacyGate': gate_pin, 'seedCountsAsOfDocumentBuild': summary_counts, 'actualSeedInvocationsAtCheck': len(actual), 'audiSeedCountsAsOfDocumentBuild': audi_counts, 'actualAudiSeedInvocationsAtCheck': len(actual_audi), 'currentSanitationFiles': 33, 'currentSanitationRanges': 47, 'sourceIndexReferenceAssociations': reference_counts, 'originalRawPinReplayLimitationDisclosed': True, 'noExecutableSourceTextEmbedded': True, 'noArchivePayloadReread': True, 'broaderReleaseGatesRemainOpen': True}

def active(persisted=False):
    manifest = load(D / f'Roadmark-RECOVERY-MANIFEST-{STEM}.json')
    path = D / f'Roadmark-RECOVERY-ACTIVE-STATE-{STEM}.json'
    value = load(path)
    for key in ('status', 'source', 'newArchives', 'baseRecovery', 'workState', 'verificationScope', 'independentVerification', 'supportArchive', 'additiveSupportArchive', 'closureSupportArchive', 'inheritedDependencyReconstruction', 'inheritedDependencyReconstructionHistory', 'inheritedDependencyRelocations', 'targetedHistoricalSeedReadDependency', 'originalRawCaptureReplayCompatibility', 'sourceSanitation', 'copyOnlySanitation'):
        ck(value[key] == manifest[key], 'active/manifest field differs ' + key)
    ck(value['counts'] == manifest['incrementalVerification'], 'active counts differ')
    ck(value['preSaveDocumentVerification'] == load(C / 'INDEPENDENT-DELIVERY-DOCUMENT-CHECK.json') and value['documentPrivacyGate'] == load(C / 'DELIVERABLE-PRIVACY-GATE.json'), 'active document gate differs')
    docs = native('documents')
    ck(value['documents'] == [{key: row[key] for key in ('filename', 'library_file_id', 'version', 'bytes', 'sha256')} for row in docs], 'active document native identities differ')
    ck(value['noSourceOrStatusMutationByBackup'] and value['noDeletionOrReplacement'] and value['noExecutableSourceTextEmbedded'], 'active preservation claims differ')
    no_embedded_code(value)
    gate_pin = privacy('ACTIVE-PRIVACY-GATE.json', [path])
    actual = seed_invocations()
    counts = seed_summary(value['seedReadExecutionsAsOfBuild'], actual)
    actual_audi = audi_seed_invocations()
    audi_counts = audi_seed_summary(value['audiRuntimeResidualVerification'], actual_audi)
    result = {'result': 'PASS', 'activeReceipt': pin(path), 'documents': docs, 'recommendedArchives': value['counts']['archiveCount'], 'logicalFiles': value['counts']['logicalFiles'], 'activePrivacyGate': gate_pin, 'seedCountsAsOfActiveBuild': counts, 'actualSeedInvocationsAtCheck': len(actual), 'noArchivePayloadReread': True, 'broaderReleaseGatesRemainOpen': True}
    result.update(audiSeedCountsAsOfActiveBuild=audi_counts, actualAudiSeedInvocationsAtCheck=len(actual_audi))
    if persisted:
        pre = load(C / 'INDEPENDENT-ACTIVE-RECEIPT-CHECK.json')
        ck(pre['result'] == 'PASS' and pre['activeReceipt'] == pin(path), 'persisted active bytes differ from approved bytes')
        rows = native('active')
        ck(len(rows) == 1 and rows[0]['filename'] == path.name, 'persisted active identity differs')
        result['persistedActive'] = rows[0]
        result['preSaveCheck'] = pin(C / 'INDEPENDENT-ACTIVE-RECEIPT-CHECK.json')
    return result

def closure():
    path = C / 'FINAL-AUDI-UPLOAD-RECEIPTS.json'
    final = load(path)
    old_path = C / 'FINAL-AUDI-UPLOAD-RECEIPTS-before-persistence-check.json'
    old = load(old_path)
    allowed = {'createdAt', 'delivery', 'deliveryConfirmation', 'activePersistenceCheck'}
    ck({key: val for key, val in final.items() if key not in allowed} == {key: val for key, val in old.items() if key not in allowed}, 'terminal append changed prior fields')
    ck(final['deliveryConfirmation'] == load(C / 'DELIVERY-CONFIRMATION.json') and final['activePersistenceCheck'] == load(C / 'INDEPENDENT-PERSISTED-ACTIVE-CHECK.json'), 'terminal delivery/persistence binding differs')
    ck(final['activePersistenceCheck']['result'] == 'PASS' and final['deliveryConfirmation'], 'terminal persistence or delivery absent')
    manifest = load(D / f'Roadmark-RECOVERY-MANIFEST-{STEM}.json')
    archives = native('archives', {row['filename']: {key: row[key] for key in ('bytes', 'sha256')} for row in manifest['newArchives']})
    docs, active_rows = native('documents'), native('active')
    expected = [{key: row[key] for key in ('filename', 'library_file_id', 'version', 'bytes', 'sha256')} for row in archives + docs + active_rows]
    ck(final['files'] == expected and len(expected) == len(archives) + 5, 'terminal native file set differs')
    ck(final['sourceLibraryFileId'] == manifest['source']['library_file_id'] and final['activeReceiptLibraryFileId'] == active_rows[0]['library_file_id'], 'terminal source/active IDs differ')
    actual = seed_invocations()
    counts = seed_summary(final['targetedSeedReadExecutionSummary'], actual, complete=True)
    ck(final['targetedSeedReadExecutionSummary']['asOf'] == max(row['record']['completedAt'] for row in actual), 'final deterministic seed cutoff differs')
    actual_audi = audi_seed_invocations()
    audi_counts = audi_seed_summary(final['audiRuntimeResidualVerification'], actual_audi, complete=True)
    ck(final['audiRuntimeResidualVerification']['asOf'] == max(row['record']['completedAt'] for row in actual_audi), 'final deterministic Audi cutoff differs')
    return {'result': 'PASS_TERMINAL_RECOVERY_CLOSURE', 'currentFinalReceipt': pin(path), 'preservedInitialFinalReceipt': pin(old_path), 'persistenceCheck': pin(C / 'INDEPENDENT-PERSISTED-ACTIVE-CHECK.json'), 'newNativeFiles': len(expected), 'recommendedArchives': len(manifest['archivesInRestoreOrder']), 'logicalFiles': len(manifest['files']), 'sourceLibraryFileId': final['sourceLibraryFileId'], 'activeReceipt': active_rows[0], 'acceptedDelivery': final['deliveryConfirmation'], 'targetedSeedReadExecutions': counts, 'targetedAudiSeedReadExecutions': audi_counts, 'everyActualSeedReceiptBoundToTerminalPidAndInterval': True, 'changedFinalReceiptFieldsOnly': sorted(key for key in set(final) | set(old) if final.get(key) != old.get(key)), 'noArchivePayloadReadsOrUploadsOrDeletion': True, 'broaderApplicationReleaseGatesRemainOpen': True}

if __name__ == '__main__':
    start = time.monotonic()
    mode = sys.argv[1]
    ck(mode in NAMES, 'unknown verification mode')
    output = C / NAMES[mode]
    ck(not output.exists(), 'preserve prior result; choose a reviewed distinct retry path')
    result, code = {}, 0
    try:
        ck('--sole-child-slot-authorized' in sys.argv and resource.getrlimit(resource.RLIMIT_AS) == (LIMIT, LIMIT), 'sole-slot 256 MiB verification contract absent')
        review = load(C / 'INDEPENDENT-AUDI-COMMAND-PLAN-REVIEW-v4.json')
        ck(review['result'] == 'PASS_FINAL_ARCHIVE_COMMAND_AND_POINTER_PLAN', 'final static command review absent')
        check(review['commandPlan']['path'], review['commandPlan'])
        command_plan = load(review['commandPlan']['path'])
        own = [row for row in command_plan['scriptPins'] if row['path'] == str(pathlib.Path(__file__).resolve())]
        ck(len(own) == 1, 'document verifier exact pin absent')
        check(__file__, own[0])
        check(review['independentVerifier']['path'], review['independentVerifier'])
        result = documents() if mode == 'documents' else active(mode == 'persisted-active') if mode in ('active', 'persisted-active') else closure()
    except BaseException as error:
        code = 1
        result = {'result': 'BLOCKED', 'blocker': {'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()}}
    result['checkedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result['verifierScript'] = pin(pathlib.Path(__file__))
    result['resources'] = {'wallSeconds': round(time.monotonic() - start, 3), 'maxRssKiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss, 'addressSpaceLimitBytes': resource.getrlimit(resource.RLIMIT_AS)[0], 'chunkBytes': CHUNK}
    dump(output, result)
    print(json.dumps({'mode': mode, 'result': result['result'], 'resources': result['resources'], 'blocker': result.get('blocker')}), flush=True)
    sys.exit(code)
