from pathlib import Path
import json,hashlib,re,datetime,resource
S=Path('/tmp/subaru-staging-plan');R=Path('/tmp/subaru-research');Q=Path(__file__).parent
load=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();ordered=lambda v:json.dumps(v,ensure_ascii=False,separators=(',',':'))
file=S/'candidate/subaru-initial-2026-10-15.json';expected='1bc824ee2dba493106626a2a57ee7557979a746076d60df6198463b11f029184';assert sha(file)==expected
assert sha(S/'stage-inputs.json')=='0244f1e320dd6f5a0d52b4365e20c3e27e4905caaca4c7cfd2eec5ebb22844be'
p=load(file);assert p['id']=='m1-subaru-2026-10-15' and p['brand']=='Subaru' and p['reviewedAt']=='2026-10-15'
assert [len(p[k]) for k in ['sources','variants','facts','brandTerms','features','summaries']]==[29,2,646,3,239,11]
for name in ['prepare-inputs-attempt1','build-initial-attempt1']:
 t=load(Q.parent/name/'terminal.json');assert t['returncode']==0 and t['signal'] is None
old=load(R/'capture-attempt640-original/subaru-live-before.json');oldby={c['id']:c for c in old};assert len(oldby)==9
new={v['id']:v for v in p['variants']};assert set(new)=={'subaru_solterra_my27__awd__20261015','subaru_solterra_my27__awd_touring__20261015'}
for v in new.values():assert v['model_year']==2027 and v['brand']=='Subaru' and v['vehicle_class']=='passenger' and all(v[k] is None for k in ['price_aud','range_km','seats'])
ids=set(oldby)|set(new);assert len(ids)==11
assert {g['variantId'] for g in p['versionGuards']}==set(oldby)
for g in p['versionGuards']:assert ordered(g['before'])==ordered({k:oldby[g['variantId']][k] for k in ['id','modelId','brand','model','trim','year','generation','vehicleClass','drive']})
sources={s['id']:s for s in p['sources']};assert len(sources)==29
captures=0
for s in sources.values():
 assert s['market']=='AU' and s['accessed_date']=='2026-10-15' and not s.get('sourceOriginMarket')
 for loc,key in [('capture_locator','capture_sha256'),('capture_text_locator','capture_text_sha256')]:
  if loc in s:
   path=(R/s[loc]).resolve();assert path.is_relative_to(R);assert sha(path)==s[key];captures+=1
facts={i:{} for i in ids};norm=load(R/'normalized-evidence.json');normal={v['id']:{f['key']:f for f in v['facts']} for v in norm['variants']}
for r in p['facts']:
 i=r['variantId'];f=r['after'];k=f['key'];assert i in ids and k not in facts[i];facts[i][k]=f
 assert ordered(r['before'])==ordered(oldby[i]['facts'].get(k) if i in oldby else None)
 rf=normal[i][k];assert f['value']==rf['value'] and f['buyerGrade']==rf.get('grade','confirmed')
 assert f['date']=='2026-10-15' and f['gradeReview']['reviewedAt']=='2026-10-15' and f['gradeReview']['overlayId']==p['id']
 assert f['sourceIds']==f['gradeReview']['sourceIds'] and set(f['sourceIds'])<=set(sources)
 if f['buyerGrade']=='check':assert f.get('conditionExplanation')
for term in p['brandTerms']:
 assert set(term['applicableVariantIds'])==ids and term['exceptions']==[]
 for i in ids:
  assert ordered(term['before'][i])==ordered(oldby[i]['facts'].get(term['key']) if i in oldby else None)
  facts[i][term['key']]=term['fact']
core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty','battery_warranty']
for i in ids:assert set(core)<=facts[i].keys()
assert len(p['availability'])==11 and {v['variantId'] for v in p['availability']}==ids
for a in p['availability']:
 assert a['after']['evidence']['physicalStockVerified'] is False and a['after']['evidence']['factoryOrderAcceptanceVerified'] is False
 if a['variantId'] in oldby:assert ordered(a['before'])==ordered({'availability':oldby[a['variantId']]['availability'],'evidence':oldby[a['variantId']]['availabilityEvidence']})
prior={(f['variant_id'],f['criterion']):f for f in load(R/'capture-attempt640-original/subaru-feature-before.json')};assert len(prior)==621
assert len({(f['variantId'],f['criterion']) for f in p['features']})==239
for f in p['features']:
 assert ordered(f['before'])==ordered(prior[(f['variantId'],f['criterion'])]);assert f['variantId'] not in new
 for d in f['dependencies']:assert ordered(d['expected'])==ordered(facts[f['variantId']][d['key']])
for s in p['summaries']:
 for clause in ['strength','tradeoff']:
  assert s[clause]['dependencies']
  for d in s[clause]['dependencies']:assert ordered(d['expected'])==ordered(facts[s['variantId']][d['key']])
# Independently bind every current primary price directly to the exact public maker component.
priceChecks=[]
for i in sorted(ids):
 f=facts[i]['price_aud']
 if 'solterra_my26' in i:assert f['buyerGrade']=='reported' and f['priceEvidence']['rung']==5 and f['priceEvidence']['rankingEligible'] is False;continue
 assert f['buyerGrade']=='confirmed' and f['priceEvidence']['rung']==1
 source=sources[f['sourceIds'][0]];payload=load(R/source['capture_locator']);model=next(c['data'] for c in payload['data'] if c['type']=='ModelLandingPage')
 match=re.search(r'modelVariants\[(\d+)\]\.manufacturersListPrice$',f['priceEvidence']['sourcePointer']);assert match
 variant=model['compareRangeModel']['modelVariants'][int(match[1])]
 assert variant['manufacturersListPrice']==f['value'] and variant['isDriveAway'] is False
 assert variant['year']==('2026' if '_my26' in i else '2027')
 assert f['priceEvidence']['basisTag']=='Maker’s list price before on-road costs'
 priceChecks.append({'id':i,'price':f['value'],'sourceId':source['id'],'componentYear':variant['year']})
for i in ids:
 d=facts[i];assert d['battery_kwh']['value']==74.7 and 'gross/usable' in d['battery_kwh']['basis'];assert d['dc_peak_kw']['value']==150 and d['ac_kw']['value']==22
 assert d['dc_charge_time_min']['value']==30 and d['towing_braked_kg']['value']==1500
 assert d['boot_l']['comparisonBasis']=='' and d['width_mm']['comparisonBasis']==''
 if 'uncharted_my27' in i:assert d['dc_charge_time_min']['buyerGrade']=='check' and '0–80%' in d['dc_charge_time_min']['conditionExplanation']
 if 'solterra' in i:assert d['zero_to_100_s']['value']==5.1 and d['zero_to_100_s']['buyerGrade']=='reported'
 if 'uncharted' in i:assert d['speaker_count']['buyerGrade']=='check'
 assert d['service_plan']['value']=='5-year/75,000 km capped-price servicing program'
assert not (S/'candidate/new-feature-before.json').exists();assert not (S/'candidate/canonical-baseline-meta.json').exists();assert sha(file)==expected
out={'status':'approved_for_once_only_canonical_capture','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'asOf':'2026-10-15','packetSha256':expected,'stageInputManifestSha256':sha(S/'stage-inputs.json'),'versions':11,'originalVersions':9,'newVersions':2,'facts':646,'terms':3,'initialFeatureReplacements':239,'finalFeatureReplacementsExpected':293,'sourceCapturesVerified':captures,'exactBeforeGuardsVerified':True,'coreCells':187,'summaryAndFeatureDependenciesExact':True,'primaryPricesDirectlyMatchedToPublicComponents':priceChecks,'allActualForeignSourceCount':0,'canonicalFixtureAlreadyExists':False,'scope':'Initial candidate only. The final remaining 54 feature replacements and runtime core/pack/portable/negative/full-report checks remain mandatory.','freshLoaderValidation':False,'currentFullTypecheckVerified':False,'registryEditsAuthorized':False,'scriptSha256':sha(__file__),'maxRssKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
with (Q/'receipt.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({'status':out['status'],'receiptSha256':sha(Q/'receipt.json'),'captures':captures,'prices':len(priceChecks)}))
