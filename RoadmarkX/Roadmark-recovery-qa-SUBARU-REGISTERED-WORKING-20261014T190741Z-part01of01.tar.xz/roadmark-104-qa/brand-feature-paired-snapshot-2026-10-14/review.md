# Registered-feature fixture: one paired current snapshot

Applied one test-only replacement in `tests/brand-feature-updates.test.ts`:

```diff
-    current: { data: pipeline.research(), cars: pipeline.catalogue() },
+    current: pipeline.catalogueSnapshot(),
```

No tests, hydration, builds, or typechecks were run for this change. Previous relevant and isolated SIGKILL results remain incomplete. Removing duplicate construction is established from the call graph; successful completion, lower peak memory, and the cause of prior terminations are not established.

## Why this is safe for these tests

The production `catalogue()` already returns `catalogueSnapshot().cars`. The new expression keeps the Research object that was prepared for those exact cars, instead of separately loading and preparing another Research object immediately before the same catalogue pipeline. The `original` object still calls `sourceResearch()` and `sourceCatalogue()` separately, unchanged. The existing promise is still shared only between this file's two registered-data tests; no new persistent cache is introduced.

Before: original source read + sourceCatalogue source read, then a separate current research read/preparation + the catalogue snapshot read/preparation. After: the two original reads remain, followed by one complete current snapshot. This removes one source read/preparation, but neither of the two catalogue builds.

The returned data/cars can now share nested input objects from the same current build. Neither registered test mutates that shared current snapshot. The Tesla test reads packs and constructs its failure case with a new car object, new facts map, and new boot_l fact before setting value to 9999. Other shared nested members are read, not changed. Its `assert.throws` still calls the real pack with the drifted car and current data. The baseline helper replaces features on a new returned pack object and checks source closure; it does not modify the original/current snapshot. The second registered test only selects original/current cars, builds a local expected-feature Map, and performs comparisons. No test asserts that current data and cars originated from independent loads.

For malformed underlying registered inputs, test-setup failure precedence can differ: the old explicit research preparation ran before the current catalogue's raw fact guards, whereas the paired loader uses its existing raw-catalogue-then-prepare order. No assertion in these two tests depends on that setup order. All existing guards still execute in the production snapshot pipeline, and the explicit drift assertion is unchanged. This is not a general claim that two arbitrary independently changing file reads are equivalent; these tests use the pinned, stable registered inputs.

## Coverage retained

- All 21 literal test names and 128 assert call sites are identical; the inventory records their positions and source lines. More strongly, the entire file differs only by the single recorded expression, so complete assertion bodies, fixtures, default arguments, and test options are unchanged.
- The second registered test still calls `sourceEffectiveFeatures(originalCar)` with no data argument and compares it to the explicit original data result. Its fresh public source default check remains intact.
- `tests/catalogue-snapshot.test.ts` still directly exercises public research across caller-order/request-sharing cases, subsequent request refresh, and standalone source/effective entry points. `tests/brand-updates.test.ts` retains its public research/catalogue/pack integration test. This review confirms retained coverage, not a new pass for those tests.
- Production data.ts/evidence-consumers.ts and the source-fixture, catalogue-snapshot, and brand-updates test files have identical before/after hashes in change-manifest.json.

Re-read AGENTS.md and the installed Next 16.3.8 React.cache guidance before applying: request-scoped caching stays unchanged, and the existing no-op-CLI behavior is why explicit file-local reuse is appropriate. Independent review and root-controlled execution follow this static change.
