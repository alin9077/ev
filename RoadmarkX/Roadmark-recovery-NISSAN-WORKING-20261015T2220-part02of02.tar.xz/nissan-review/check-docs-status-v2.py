from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,re
B=Path('/tmp/nissan-packet/docs-status-v2');A=Path('/tmp/nissan-packet/docs-status-v1');Q=Path('/tmp/nissan-review');W=Path('/workspace/scratch/586427eef9f2')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1048576),b''):h.update(c)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def verify(p):assert pin(p['path'])=={k:p[k] for k in ['path','bytes','sha256']},p['path']
m=read(B/'manifest.json');assert pin(B/'manifest.json')['sha256']=='92476cbd6e5655b283bb3f77a1c27052b9ec3033fb6862908dac36ad8a631e68'
assert len(m['proofs'])==846
for p in m['proofs']+[m['applicator'],m['preparer'],m['patch'],m['preservedPreparation']]:verify(p)
proofs={p['path']:p for p in m['proofs']}
for p in read(A/'manifest.json')['proofs']:assert proofs[p['path']]==p
assert not set(w['target'] for w in m['writes'])&set(proofs)
expected=['roadmark-104/docs/NISSAN_M1_UPDATE.md','roadmark-104/docs/M1_PROGRESS.md','roadmark-104-qa/work-status.json'];assert [w['relativePath'] for w in m['writes']]==expected
for w in m['writes']:
 assert Path(w['target'])==W/w['relativePath'] and not Path(w['target']).is_symlink()
 verify(w['after'])
 if w['before']:
  verify(w['before']);verify(w['beforeCopy']);assert Path(w['target']).read_bytes()==Path(w['beforeCopy']['path']).read_bytes()
 else:assert not Path(w['target']).exists()
a=read(m['writes'][2]['beforeCopy']['path']);b=read(m['writes'][2]['after']['path']);changed=set(m['historyPreservation']['changedCurrentFields'])
assert b['workStatusHistory'][:-1]==a['workStatusHistory'] and b['workStatusHistory'][-1]['previous']=={k:a[k] for k in changed if k in a}
assert all(a[k]==b[k] for k in a if k not in changed|{'workStatusHistory'})
assert set(b)==set(a)|{'nissanWorking','nissanResearchStatus','nissanPendingRecovery'}
assert b['nissanWorking']==b['latestWorkingBrandChecks']
assert Path(m['writes'][1]['after']['path']).read_bytes()==Path(m['writes'][1]['beforeCopy']['path']).read_bytes()+(B/'progress-append.md').read_bytes()
assert (B/'buyer-update.md').read_bytes()==(A/'buyer-update.md').read_bytes()==Path(m['writes'][0]['after']['path']).read_bytes()
buyer=(B/'buyer-update.md').read_text();assert len(buyer.split())==599
progress=(B/'progress-append.md').read_text();assert 'Evolve e-4ORCE' in progress and 'The Nissan packet is registry entry 31 and appends 22 sources.' in progress
assert 'The saved-output comparator replays only four prior Nissan packs/276 feature rows' in progress and 'The ordinary normal report performs its inherent full-catalogue feature work.' in progress
assert (B/'apply.py').read_text().replace('docs-status-v2','docs-status-v1')==(A/'apply.py').read_text()
r=read(b['coverageReport']);n=next(x for x in r['brandProgress'] if x['brand']=='Nissan');w=b['nissanWorking'];c=w['coverage'];nc=w['nissanCoverage'];rc=r['reconciliation']
expectedCoverage=dict(catalogue=r['allCatalogueVersions'],tier1=r['tierOneVersions'],onSale=r['onSaleVersions'],registeredPackets=31,coreReviewed=r['grading']['reviewedCoreCells'],coreDenominator=r['grading']['totalCoreCells'],strictGaps=len(r['gaps']),reviewedModels=rc['reviewedModels'],reviewedVersions=rc['reviewedVersions'],c1Issues=len(rc['issues']),settledInventory=len(rc['settledInventory']),unmatchedAuditModels=len(r['missingModels']),unresolvedLeads=len(r['unresolvedLeads']),researchCompletedBrands=len(r['brandsResearchCompleted']),researchRemainingBrands=len(r['brandsResearchRemaining']),rankings={x['key']:x['ranked'] for x in r['rankings']},criteria=[{k:x[k] for k in ['id','pass']} for x in r['criteria']]);assert c==expectedCoverage
assert nc['criteria']==n['criteria'] and nc['rankings']==n['rankings'] and nc['closureIssues']==n['closureIssues'] and nc['coreGrades']=={g:sum(x['grades'][g] for x in n['core']) for g in n['core'][0]['grades']}
assert nc['filled']==sum(x['filled'] for x in n['core'])==68 and nc['reviewed']==sum(x['reviewed'] for x in n['core'])==68 and nc['gaps']==n['coreGaps']==0
assert w['structural']==read('/tmp/nissan-packet/post-registration-checks-v1/run/structural-validation/stdout.log')
assert w['fullTypecheck']['attempts']==read('/tmp/nissan-packet/report-comparison-plan-v2/typescript-failure-context.json')['attempts'] and not w['fullProjectTypecheckPassed'] and not w['releaseReady'] and not w['publicationAuthorized']
assert w['ordinaryReportInherentFeatureWork'] and not w['extraBroadFeatureReplay'];assert w['reportComparison']['selectedReplayScope']=='Saved-output comparator only; the ordinary normal report performs its inherent full-catalogue feature work'
for status in [w,b['nissanResearchStatus']]:
 def visit(x):
  if isinstance(x,dict):
   if set(['path','bytes','sha256']).issubset(x):verify(x)
   for y in x.values():visit(y)
  elif isinstance(x,list):
   for y in x:visit(y)
 visit(status)
cols=[next(x for x in r['core'] if x['key']==k) for k in ['price_aud','range_km','battery_kwh','dc_charge_time_min','seats','boot_l','warranty']]
expectedcells=[f"{x['filledPercent']:.1f}% / {x['confirmedPercent']:.1f}%" for x in cols]
assert '| 312 | '+' | '.join(expectedcells)+f" | {r['pairedOnSalePercent']:.1f}% | {r['inAllRankingsPercent']:.1f}% |" in buyer
assert '**Research done (15):** '+', '.join(r['brandsResearchCompleted'])+'.' in buyer and '**Remaining (41):** '+', '.join(r['brandsResearchRemaining'])+'.' in buyer
assert m['rootGrantRequired'] and not m['automaticRetry'] and not m['heavyChecksAllowed'] and not (B/'application').exists()
d=dict(status='accepted',at=datetime.now(timezone.utc).isoformat(),manifest=pin(B/'manifest.json'),priorReview=pin(Q/'docs-status-v1-findings-v1.json'),all846ProofPinsExact=True,allThreeBeforeGuardsExact=True,reviewedWrites=m['writes'],buyerReportWords=599,buyerReportByteIdenticalToReviewedV1=True,coverageTableAndAllBrandListsMatchActualReport=True,allCurrentStatusCountsCriteriaRankingsAndStructuralDataExact=True,narrowV1CorrectionsResolved=True,progressOriginalBytesPreserved=True,exactPriorCurrentFieldsArchived=True,allUnrelatedHistoryBackupAndLibraryFieldsPreserved=True,priorHistoryEntries=len(a['workStatusHistory']),newHistoryEntries=len(b['workStatusHistory']),properReportVersusComparatorScopeExplicit=True,applicatorReviewed=True,scope='Exactly new buyer update, append-only M1 progress, and history-preserving work-status replacement. No source/helper/test/UI/README/backlog changes.',applied=False,applicationAuthorizedByThisReview=False,currentProjectTypeScript='UNPASSED; no compiler retry',limits='Exact root three-target grant required. Application must be independently read back. Nissan recovery delivery is still pending; no full-suite/build/mobile/release/milestone or publication claim.')
f=Q/'docs-status-v2-findings-v1.json'
with f.open('x') as out:json.dump(d,out,indent=2);out.write('\n')
print(json.dumps(pin(f),indent=2))
