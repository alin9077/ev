from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
R=Path('/workspace/scratch/586427eef9f2/roadmark-104');Q=Path('/tmp/nissan-review')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def verify(p):
 a=pin(p['path']);assert a=={k:p[k] for k in a},p['path'];return a
def write(n,d):
 with (Q/n).open('x') as f:json.dump(d,f,indent=2);f.write('\n')
P=Path('/tmp/nissan-packet/report-comparison-plan-v1');mp=P/'preparation-manifest-v1.json';m=read(mp)
for p in m['files']:verify(p)
for k in ['acceptedPattern','acceptedBaselineReport','acceptedBaselineReview','fullStageManifest','fullStageOutputReview']:verify(m[k])
s=read(P/'syntax-only-receipt.json');assert s['exitCode']==0 and not s['runtimeExecuted'] and not s['importsExecuted'] and s['scriptSha256']==pin(P/'compare-report.mjs')['sha256']
write('report-comparison-plan-v1-findings-v1.json',dict(status='REQUIRES_AMENDMENT_PREPARATION_ONLY',at=datetime.now(timezone.utc).isoformat(),manifest=pin(mp),comparator=pin(P/'compare-report.mjs'),allPreparationPinsExact=True,reviewScope='Full comparator, accepted Renault-to-Nissan diff, deferred manifest preparation and static source-closure scanner; no execution or source changes.',requiredCorrection=dict(location='compare-report.mjs unchanged before-feature loop, around line 176',finding='Loop excludes only roadside_assistance, but Nissan deliberately updates driveaway_price too. Comparing the inherited offer to the accepted new canonical Reported offer will fail.',resolution='Exclude exactly those two reviewed projection criteria, then bind their after facts and canonical features independently to accepted selected-v4 outputs; preserve v1 and freeze amended v2.'),otherwiseReviewed=['Actual accepted Renault30 report and complete before-car/source reconstruction','Complete actual coreCoverage and gradePattern reason inventory','Complete catalogue/inventory/freshness ordered arrays, without broad normalization','Full accepted stage ranking value/basis/digest/group/order/tie bindings and exact C1','Exhaustive expected-versus-normal deep equality and all peer brand objects','One normal report followed separately by saved-output comparator; no automatic retry','Final command/source closure intentionally deferred until application, accepted live readback and scoped results'],runtimeExecuted=False,executionReadiness=False,currentTypeScript='UNPASSED'))
P=Path('/tmp/nissan-packet/post-registration-plan-v1');mp=P/'plan-manifest.json';m=read(mp)
for p in m['files']:verify(p)
for k in ['acceptedFullStage','registrationManifest']:verify(m[k])
O=Path('/tmp/renault-packet/post-registration-checks-v6');sourcepins=read(O/'source-pins.json');closure=read(O/'static-input-closure.json');cache={}
for p in sourcepins+closure['files']+[e['resolved'] for e in closure['edges']]:
 if p['path'] not in cache:cache[p['path']]=verify(p)
 else:assert cache[p['path']]=={k:p[k] for k in cache[p['path']]}
assert len(sourcepins)==255 and len(closure['files'])==168 and len(closure['edges'])==494
inventory=read(P/'test-inventory.reference.json');names=[]
for f,row in inventory.items():verify(row['source']);assert row['count']==len(row['names']);names+=row['names']
assert len(names)==len(set(names))==151
assert (P/'run.reference.py').read_bytes()==(O/'run.py').read_bytes()
assert (P/'test-inventory.reference.json').read_bytes()==(O/'test-inventory.json').read_bytes()
pricecount=0;pricefiles=set();values={}
for b in closure['priceSourcePointerBindings']:
 overlay=read(b['overlay']['path']);row=overlay['candidates'][b['candidateIndex']];assert row['variantId']==b['variantId'] and row['sourcePointer']==b['sourcePointer']
 filename,pointer=row['sourcePointer'].split('#',1);path=R/filename
 if filename not in values:values[filename]=read(path)
 value=values[filename]
 for part in filter(None,pointer.split('/')):
  part=part.replace('~1','/').replace('~0','~');value=value[int(part)] if isinstance(value,list) else value[part]
 if isinstance(value,dict):
  value=next((value[k] for k in ['value','amountAud','amount'] if value.get(k) is not None),None)
  if isinstance(value,dict):value=next((value[k] for k in ['amountAud','amount'] if value.get(k) is not None),None)
 assert value==row['value'];pricecount+=1;pricefiles.add(filename)
assert pricecount==137 and len(pricefiles)==7
assert len(read(R/'data/m1-brand-updates/registry.json')['packets'])==30
assert not (R/'data/m1-brand-updates/nissan-2026-10-15.json').exists()
assert not (R/'data/m1-nissan-market-reconciliation-2026-10-15.json').exists()
d=read('/tmp/nissan-packet/full-stage-v1/output/research-field-digests.json');assert d['candidate31']['sources']['rows']==3831
write('post-registration-plan-v1-findings-v1.json',dict(status='PASS_PREPARATION_REVIEW_ONLY',at=datetime.now(timezone.utc).isoformat(),manifest=pin(mp),allPreparationPinsExact=True,reviewScope='Full plan, future preparer, static closure scanner, accepted byte-identical supervisor and planned commands read; independent read/hash checks only.',acceptedRetainedPins=255,retainedClosureFiles=168,retainedClosureEdges=494,exactCurrentPricePointerValues=137,pricePointerFiles=7,exactDistinctScopedTestInventory=151,behavioralTests=144,liveSafetyTests=7,supervisor=pin(P/'run.reference.py'),supervisorByteIdenticalToAcceptedRenaultV6=True,expectedSourceReferencesGroundedInAcceptedFullStage=3831,finalClosureExpectedButNotYetDerived=dict(files=170,edges=496,packets=31),prerequisites=['Parent releases backup live-source freeze','Exact four-file grant and successful application','Independent live readback with accepted supervisor fields','Actual post-registration source and metadata closure frozen','Independent exact command readiness review and root-exclusive grant'],checks=['Five strictly serial prerequisite-linked bounded gates; no retry','Exact test names and stdout scope checks, empty stderr and before/after pins/stat guards','Existing retained fixture import context and all dynamic registry/price pointer leaves closed','No project compiler, normal report, comparator, broad stage replay, helper/test/UI edits or full-suite claim','Terminal and process-group checks must complete before parent releases heavy slot'],runtimeExecuted=False,executionReadiness=False,liveRegistrationObserved=False,currentTypeScript='UNPASSED'))
print(json.dumps(dict(comparatorReview=pin(Q/'report-comparison-plan-v1-findings-v1.json'),scopedPlanReview=pin(Q/'post-registration-plan-v1-findings-v1.json'),uniquePinsVerified=len(cache),runtimeExecuted=False),indent=2))
