from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
R=Path('/workspace/scratch/586427eef9f2/roadmark-104');B=Path('/tmp/nissan-packet/post-registration-checks-v1');O=Path('/tmp/renault-packet/post-registration-checks-v6');Q=Path('/tmp/nissan-review')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
cache={}
def verify(p):
 if p['path'] not in cache:cache[p['path']]=pin(p['path'])
 a=cache[p['path']];assert a=={k:p[k] for k in a},p['path'];return a
def meta(p):
 p=Path(p)
 if not p.exists():return dict(path=str(p),exists=False)
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
s=read(B/'sequence.json');assert pin(B/'sequence.json')['sha256']=='00f2886e70cb921552fa4b587ad5f76721d0b04744a5ca28c38ba3621d63ff82'
assert s['compilerIncluded'] is False and s['executionAuthorized'] is False and s['normalReportAndComparatorIncluded'] is False and s['noAutomaticRetry'] is True
for p in [s['sourcePins'],s['rootMetadata'],s['registrationManifest'],*s['registrationTargets'],*s['preparation']]:verify(p)
sourcepins=read(s['sourcePins']['path']);assert len(sourcepins)==266
for p in sourcepins:verify(p)
c=read(B/'static-input-closure.json');old=read(O/'static-input-closure.json');assert len(c['files'])==170 and len(c['edges'])==496
for p in c['files']+[e['resolved'] for e in c['edges']]:verify(p)
oldfiles={p['path']:p for p in old['files']};newfiles={p['path']:p for p in c['files']};transitions={p['path']:p for p in s['registrationTargets']}
newtargets={str(R/'data/m1-brand-updates/nissan-2026-10-15.json'),str(R/'data/m1-nissan-market-reconciliation-2026-10-15.json')}
assert set(newfiles)-set(oldfiles)==newtargets and not set(oldfiles)-set(newfiles)
for p in oldfiles:assert newfiles[p]==transitions.get(p,oldfiles[p])
key=lambda e:(e['importer'],e['kind'],e['specifier'],e['resolved']['path'])
oldedges=set(map(key,old['edges']));newedges=set(map(key,c['edges']));assert not oldedges-newedges and len(newedges-oldedges)==2 and {e[3] for e in newedges-oldedges}==newtargets
assert c['priceSourcePointerBindings']==old['priceSourcePointerBindings'] and len(c['priceSourcePointerBindings'])==137 and c['priceSourcePointerFilenames']==old['priceSourcePointerFilenames'] and len(c['priceSourcePointerFilenames'])==7
registry=read(R/'data/m1-brand-updates/registry.json');assert c['registeredPackets']==registry['packets'] and len(c['registeredPackets'])==31
assert c['approvedAssetDynamicReads']['entries']==0 and read(R/'media/approved-assets.json')==[]
metadata=read(s['rootMetadata']['path']);assert len(metadata['configuredRootFilePaths'])==361 and len(metadata['fileMetadata'])==360 and len(metadata['directoryState'])==5
for p in metadata['fileMetadata']+metadata['directoryState']+metadata['postRegistrationTargets']:assert meta(p['path'])==p,p['path']
config=read(R/'tsconfig.json');roots=sorted({str(p.resolve()) for pat in config['include'] for p in R.glob(pat) if p.is_file()});assert roots==metadata['configuredRootFilePaths']
inventory=read(B/'test-inventory.json');names=[]
for row in inventory.values():verify(row['source']);assert row['count']==len(row['names']);names+=row['names']
assert len(names)==len(set(names))==151 and (B/'test-inventory.json').read_bytes()==(O/'test-inventory.json').read_bytes()
assert (B/'run.py').read_bytes()==(O/'run.py').read_bytes()==Path('/tmp/nissan-packet/post-registration-plan-v1/run.reference.py').read_bytes()
plans=read('/tmp/nissan-packet/post-registration-plan-v1/commands.plan.json')['commands'];reviewed=[]
for i,(p,planned) in enumerate(zip(s['sequence'],plans)):
 verify(p);m=read(p['path'])
 for k,v in planned.items():assert m[k]==v,(m['id'],k)
 assert m['sourcePins']==s['sourcePins'] and m['rootMetadata']==s['rootMetadata'] and m['registrationTargets']==s['registrationTargets'] and m['originalConfig']==config
 assert m['automaticRetry'] is False and m['parallelExecutionAllowed'] is False and m['sourceMutationsAuthorized'] is False and m['killAfterSeconds']==10
 assert m['environmentRemovals']==['NODE_OPTIONS','NODE_PATH','NODE_COMPILE_CACHE','TS_NODE_PROJECT','TS_NODE_COMPILER_OPTIONS','TS_NODE_TRANSPILE_ONLY'] and m['environmentOverrides']=={'NODE_DISABLE_COMPILE_CACHE':'1','FORCE_COLOR':'0','ESLINT_USE_FLAT_CONFIG':'true'}
 for a in m['runtimeMetadata']:assert meta(a['path'])==a
 for a in [m['wrapper'],m['testInventory'],*m['extraPins']]:verify(a)
 expectedprior=[] if i==0 else [dict(manifest=s['sequence'][i-1],resultPath=str(B/'run'/plans[i-1]['id']/'result.json'))];assert m['prerequisites']==expectedprior
 assert not Path(m['runOutput']).exists()
 reviewed.append(dict(id=m['id'],manifest=p,command=m['command'],timeoutSeconds=m['timeoutSeconds'],killGraceSeconds=10,watchdogMarginSeconds=20))
assert len(s['sequence'])==len(plans)==5
readback=Q/'registration-v1-live-readback-v1.json';assert read(readback)['status']=='accepted'
d=dict(status='accepted',at=datetime.now(timezone.utc).isoformat(),sequence=pin(B/'sequence.json'),wrapper=pin(B/'run.py'),sourcePins=s['sourcePins'],staticInputClosure=pin(B/'static-input-closure.json'),rootMetadata=s['rootMetadata'],testInventory=pin(B/'test-inventory.json'),registrationManifest=s['registrationManifest'],registrationVerification=pin(readback),priorPlanReview=pin(Q/'post-registration-plan-v1-findings-v1.json'),reviewedCommands=reviewed,sourcePinCount=266,allPinsExact=True,closure=dict(files=170,edges=496,registeredPackets=31,retainedEdgesRemoved=0,addedEdges=[list(e) for e in sorted(newedges-oldedges)],allPriorClosureFilesExactExceptApprovedTransitions=True,priceSourcePointerBindings=137,priceSourceFiles=7,retainedFixtureContextExplicit=True),metadata=dict(configuredRoots=361,unchangedRootStats=360,directoryStates=5,runtimeMetadata=2,registrationTargetStats=4,allExact=True),tests=dict(behavioral=144,liveSafety=7,distinct=151,exactInventoryPinned=True),expectedStructural=dict(variants=430,families=171,generations=194,criteria=69,evidence=29670,current=351,outgoing=43,provisional=36,sourceReferences=3831,publicationIssues=15,approvedExternalAssets=0),supervisorReview=['Byte-identical accepted Renault v6, read in full','Exact root grant, sequence, readiness and independent live-readback binding','Strict serial prerequisites, exclusive lock, no retry, timeout/kill/watchdog, create-only evidence','Exact names/counts/stdout scope, empty stderr, all pins and root/target metadata required before/after','Terminal and empty process-group evidence must precede release of exclusive parent heavy slot'],executionAuthorizedByThisReview=False,runtimeExecuted=False,currentProjectTypeScript='UNPASSED; no project compiler gate or retry',limits='Readiness acceptance only. Root must grant these exact commands and exclusive heavy slot. No normal report, comparator, full-suite, publication or release success is implied.')
f=Q/'post-registration-v1-readiness-v1.json'
with f.open('x') as out:json.dump(d,out,indent=2);out.write('\n')
print(json.dumps(pin(f),indent=2))
