from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,difflib
A=Path('/tmp/nissan-packet/registration-v1');Q=Path('/tmp/nissan-review');R=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def verify(p):
 a=pin(p['path']);assert a=={k:p[k] for k in a},p['path'];return a
m=read(A/'manifest.json');g=read(A/'root-application-grant-v1.json');result=read(A/'application/result.json');started=read(A/'application/started.json')
assert pin(A/'manifest.json')['sha256']=='32a850242cd6c60781ad96a961db78034803d90657d536b3321b76f3f0b1347c'
assert pin(A/'root-application-grant-v1.json')['sha256']=='ea8f2f6f286683c2d3734cc8c5e42dfeec0c94001bcd51742fb965657208a373'
assert g['status']=='root_application_granted' and g['action']=='apply_exact_nissan_registration' and g['backupLiveSourceFreezeReleased'] is True and g['heavyExecutionAuthorized'] is False and g['automaticRetry'] is False
verify(g['manifest']);verify(g['reviewerAcceptance']);verify(m['applicator']);verify(m['patch'])
assert result['passed'] and not result['heavyExecution'] and not result['automaticRetry'] and started['beforeGuardsPassed'] and not started['heavyExecution']
for record in [started,result]:assert record['manifestSha256']==g['manifest']['sha256'] and record['grantSha256']==pin(A/'root-application-grant-v1.json')['sha256']
assert g['allowedTargets']==[w['target'] for w in m['writes']]
expected=[];proofs=[]
for i,w in enumerate(m['writes'],1):
 verify(w['after']);target=Path(w['target']);assert target==R/w['relativePath'] and target.is_file() and not target.is_symlink() and str(target.resolve())==str(target)
 a=pin(target);assert a['bytes']==w['after']['bytes'] and a['sha256']==w['after']['sha256'];assert target.read_bytes()==Path(w['after']['path']).read_bytes()
 if w['beforeCopy']:
  verify(w['beforeCopy']);assert {k:w['beforeCopy'][k] for k in ['bytes','sha256']}==w['before']
 else:assert w['operation']=='create' and w['before'] is None
 journal=read(A/'application'/f'write-{i}.json');assert journal==dict(target=w['target'],sha256=w['after']['sha256']);expected.append(journal);proofs.append(a)
assert result['writes']==expected
assert sorted(p.name for p in (A/'application').iterdir())==['result.json','started.json','write-1.json','write-2.json','write-3.json','write-4.json']
transitions={w['target']:w for w in m['writes']};changed=[]
for p in m['proofs']:
 if p['path'] in transitions:
  w=transitions[p['path']];assert w['before'] is not None and {k:p[k] for k in ['bytes','sha256']}==w['before'];verify(w['beforeCopy']);changed.append(p['path'])
 else:verify(p)
for p in m['unchangedHelperPins']:verify(p)
assert set(changed)=={str(R/'data/m1-brand-updates/registry.json'),str(R/'scripts/reporting/load.ts')}
old=read(m['writes'][0]['beforeCopy']['path']);new=read(R/'data/m1-brand-updates/registry.json');assert len(old['packets'])==30 and new['packets']==old['packets']+['nissan-2026-10-15.json'];assert {k:v for k,v in old.items() if k!='packets'}=={k:v for k,v in new.items() if k!='packets'}
oldload=Path(m['writes'][1]['beforeCopy']['path']).read_text();newload=(R/'scripts/reporting/load.ts').read_text();diff=list(difflib.unified_diff(oldload.splitlines(),newload.splitlines()));changes=[s for s in diff if s.startswith(('+','-')) and not s.startswith(('+++','---'))];assert len(changes)==2 and all(s.startswith('+') and 'nissan' in s.lower() for s in changes)
receipt=dict(status='accepted',at=datetime.now(timezone.utc).isoformat(),manifestSha256=pin(A/'manifest.json')['sha256'],manifest=pin(A/'manifest.json'),applicationReceipt=pin(A/'application/result.json'),rootApplicationGrant=pin(A/'root-application-grant-v1.json'),backupLiveSourceFreezeReleaseExplicitInRootGrant=True,allFourLiveHashesAndBytesMatchAcceptedPayloads=True,liveTargets=proofs,applicationJournal=[pin(p) for p in sorted((A/'application').iterdir())],beforeAfterChainExact=True,proofPins=dict(total=len(m['proofs']),unchanged=len(m['proofs'])-len(changed),onlyReviewedTransitions=changed,allExact=True),unchangedHelperPins=dict(count=len(m['unchangedHelperPins']),allExact=True,pins=m['unchangedHelperPins']),registry=dict(packets=31,first30Unchanged=True,last='nissan-2026-10-15.json'),loaderChanges=changes,acceptedCandidateSha256='6aa651b6932721365dfdee38c92fd19d9dd62cf50cb42ec6c348d495f00c9585',acceptedReconciliationSha256='e7fa1fa5cc7e7b27ae3490bc2a57a3049850f1c45ede1d2de6742f045b06c728',runtimeExecutedByReviewer=False,scopedRuntimePassed=False,normalReportPassed=False,currentProjectTypeScript='UNPASSED; no compiler retry',limits='Registration readback only. Actual post-registration command freeze, independent readiness and exclusive root grant still required for scoped gates.')
f=Q/'registration-v1-live-readback-v1.json'
with f.open('x') as out:json.dump(receipt,out,indent=2);out.write('\n')
print(json.dumps(pin(f),indent=2))
