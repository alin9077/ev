import json,pathlib,hashlib,datetime
# Reuse only the independently written bounded JSON assertions, not production code.
code=pathlib.Path('/tmp/nissan-review/check-typed-v1.py').read_text().split("out={'status':",1)[0].replace("typed-preparation-v1","typed-preparation-v2").replace('len(checks)==117','len(checks)==131')
exec(compile(code,'reviewer-bounded-json-assertions','exec'))
a=json.load(open('/tmp/nissan-packet/typed-preparation-v1/nissan-2026-10-15-candidate.json'));z=p;changes=[]
def diff(a,b,path=''):
 if a==b:return
 if type(a)!=type(b):changes.append((path,a,b));return
 if isinstance(a,dict):
  for k in sorted(a.keys()|b.keys()):
   if k not in a or k not in b:changes.append((path+'/'+k,a.get(k),b.get(k)))
   else:diff(a[k],b[k],path+'/'+k)
 elif isinstance(a,list):
  if len(a)!=len(b):changes.append((path,a,b))
  else:
   for i,(x,y) in enumerate(zip(a,b)):diff(x,y,path+'/'+str(i))
 else:changes.append((path,a,b))
diff(a,z);assert len(changes)==80
for path,old,new in changes:
 parts=path.split('/')
 if parts[1]=='sources':assert parts[-1]=='captureMethod' and 'six-page' in new
 else:
  assert parts[1]=='facts' and parts[3]=='after'
  f=z['facts'][int(parts[2])]['after'];k=f['key']
  if k in ['ac_kw','ac_max_kw_standard']:assert parts[4]=='qualifications' and len(old)==2 and new==old[:1]
  elif k in ['advertised_driveaway_aud','promotional_driveaway_aud']:assert parts[4] in ['basis','gradeReview','priceEvidence','qualifications']
  else:assert k.startswith('warranty_') and parts[4]=='qualifications' and 'published trigger is gauge bars' in new
for name in ['versionGuards','versionUpdates','availability','brandTerms','summaries','models','variants','features','configurationUpdates']:assert a[name]==z[name]
for x,y in zip(a['facts'],z['facts']):
 assert x['variantId']==y['variantId'] and x['before']==y['before']
 for k in ['key','value','unit','comparisonBasis','buyerGrade','date','status','sourceIds','issues','conditionExplanation']:assert x['after'][k]==y['after'][k]
for key in ['nissan-market-reconciliation.json','census-and-dispositions.json']:assert (P/key).read_bytes()==(P.parent/'typed-preparation-v1'/key).read_bytes()
for e in z['facts']:
 f=e['after']
 if f['key'] in ['advertised_driveaway_aud','promotional_driveaway_aud']:
  assert f['priceEvidence']['rung']==5 and f['priceEvidence']['publisher']=='CarExpert' and f['priceEvidence']['sourcePointer'].startswith('https://www.carexpert.com.au/')
out={'status':'PASS — frozen typed v2; separate actual-consumer readiness and explicit parent execution grant required','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest':{'path':str(mp),'sha256':hashlib.sha256(mp.read_bytes()).hexdigest(),'pins':len(checks),'allExact':True},'candidate':m['candidate'],'priorReview':'/tmp/nissan-review/typed-preparation-v1-findings-v2.json','sourceReview':'/tmp/nissan-review/source-review-v3-findings-v1.json','counts':{'retainedVersions':4,'newRows':0,'identityUpdates':0,'factBeforeGuards':176,'sharedTermApplications':12,'effectiveUpdatedCells':188,'coreCells':68,'coreGrades':dict(counts),'sources':22,'availabilityGuards':4,'summaryPairs':4},'amendmentsVerified':['Two ARIYA source metadata rows now accurately describe six-page PDF and visually inspected core tables on pages 1 and 2; roadside remains correctly five pages','Eight offer aliases now designate CarExpert rung 5 publisher/pointer, separately preserving dealer corroboration and maker campaign terms','Six FWD AC fact/alias qualifications no longer include secondary RACV batch-quantity claim; source sidecars retain context','Sixteen capacity alias qualification strings use buyer-readable gauge-bar trigger wording'],'exactDiff':'80 recursive pointers across 32 source/fact objects, limited to reviewed provenance/wording changes; all values, grades, comparison bases, beforeguards, sourceIds, issue holds, shared terms, availability and summaries unchanged','staticChecks':['All131 manifest pins and22 source capture hashes exact','All four identity and availability guards,176 fact guards and12 shared-term applications match accepted baseline','All summary dependencies exact and issue-free','68 core observations have65 Confirmed and3 specific FWD AC Check grades','No new rows, identity updates, feature expansion or configuration rewrites','Census and reconciliation are byte-identical to v1'],'requiredRuntimeChecks':['Apply exact typed v2 through actual selected helpers, not a synthetic-only validator','Verify current list price and Reported expiring offers retain source roles through actual detail/citation/portable consumers','Verify all canonical shared-term fact and feature claims, including self-contained 1 year roadside and all exact policy limits','Verify unknown cargo and unspecified charging-window comparisons have no direct deltas; FWD AC/mass issues block direct ranks while Confirmed core remains eligible','Verify untouched scope, exact source/before-guard refusal cases and full live/written portable parity'],'scopeLimits':['No actual helpers, selected consumers, hydration, compiler, build, server or live edits executed','Current project TypeScript and release remain UNPASSED; no global acceptance','Source v3 and typed v2 are preparation acceptance only']}
f=pathlib.Path('/tmp/nissan-review/typed-preparation-v2-findings-v1.json');f.open('x').write(json.dumps(out,indent=2)+'\n');print(f);print(out['status'])
