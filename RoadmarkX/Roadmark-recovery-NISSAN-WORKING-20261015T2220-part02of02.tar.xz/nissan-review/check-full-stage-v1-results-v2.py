import pathlib,json,hashlib,copy,collections,datetime,builtins
P=pathlib.Path('/tmp/nissan-packet/full-stage-v1');mp=P/'manifest.json';m=json.load(open(mp));om=P/'full-stage-result-manifest-v1.json';o=json.load(open(om));assert hashlib.sha256(om.read_bytes()).hexdigest()=='56e6270a3957adfb19e0e96dd5c0ac095dfb6ce00fe66cb27c42b751425139a2'
for pin in m['pins']+o['outputs']:
 p=pathlib.Path(pin['path']);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 assert p.stat().st_size==pin['bytes'] and h.hexdigest()==pin['sha256'],pin['path']
for name,pin in m['selectedArtifacts'].items():assert hashlib.sha256((P/'output'/name).read_bytes()).hexdigest()==pin['sha256'],name
print('Pins and13 selected artifacts exact')
car=json.load(open(P/'output/car-digest-comparison.json'));old=json.load(open(m['acceptedRenaultCars']['path']));fields=json.load(open(P/'output/research-field-digests.json'));oldfields=json.load(open(m['acceptedRenaultFields']['path']))
assert set(car)==set(old)|{'candidate31'} and set(fields)==set(oldfields)|{'candidate31'}
for key in old:assert car[key]==old[key]
for key in oldfields:assert fields[key]==oldfields[key]
a=car['candidate31'];b=car['candidate30'];assert len(a)==len(b)==430;assert [x['id'] for x in a]==[x['id'] for x in b];selected=set(m['selectedIds']);assert {x['id'] for x,y in zip(a,b) if x!=y}==selected
assert sum(x==y for x,y in zip(a,b))==426
assert set(k for k in fields['candidate31'] if fields['candidate31'][k]!=fields['candidate30'][k])=={'metadata','sources','variants'}
assert fields['candidate31']['sources']['rows']==fields['candidate30']['sources']['rows']+22
A={x['id']:x for x in json.load(open(P/'output/selected-after-cars.json'))};ad={x['id']:x for x in a};bd={x['id']:x for x in b}
for id,c in A.items():
 data=(json.dumps(c,ensure_ascii=False,separators=(',',':'))+'\n').encode();assert ad[id]=={'id':id,'rows':1,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
g=json.load(open(P/'output/global-c1-comparison.json'));base=g['before'];next=g['after'];expected=copy.deepcopy(base);rec=json.load(open(m['reconciliation']['path']));assert base==json.load(open(m['acceptedRenaultC1']['path']))['after']==json.load(open(m['acceptedNormalReport']['path']))['reconciliation']
expected['reviewedModels']+=1;expected['reviewedVersions']+=4;expected['reviewedVersionIds']+=m['selectedIds'];expected['validModelReviewIds'] += [x['id'] for x in rec['currentVersionReviews']]
expected['issues']=[x for x in base['issues'] if not (x['code']=='version_unreviewed' and x.get('reference') in selected) and not(x['code']=='inventory_unresolved' and x.get('reference')=='record:nissan-ariya')]
expected['settledInventory']=next['settledInventory'];assert [x for x in next['settledInventory'] if x!='record:nissan-ariya']==base['settledInventory'];assert len(next['settledInventory'])==65 and next['settledInventory'].count('record:nissan-ariya')==1
for k in ['notes','publishedLists','currentVersionReviews','listResolutions','catalogueOnlyDifferences','inventoryResolutions']:expected['evidence'][k]+=rec[k]
expected['evidence']['checkedAt']=max(base['evidence']['checkedAt'],rec['checkedAt']);expected['registryCheckedAt']=expected['evidence']['checkedAt'];assert next==expected==g['expectedCompleteAfter']
assert next['pass']==False and len(next['issues'])==187
rank=json.load(open(P/'output/global-ranking-comparison.json'));assert len(rank)==7;rankcounts={}
for x in rank:
 key=x['attribute'];old=x['completeOrderedBefore'];new=x['completeOrderedAfter'];sel=x['completeSelectedRecords'];reverse=key in ['range_km','towing_braked_kg','seats']
 for rec,digests in [(old,bd),(new,ad),(sel,ad)]:
  used=[]
  for group in rec['groups']:
   values=[e['fact']['value'] for e in group['entries']];assert values==sorted(values,reverse=reverse)
   for e in group['entries']:
    assert e['carDigest']==digests[e['carId']];assert e['fact']['key']==key;assert e['fact']['comparisonBasis']==group['basis'];assert e['fact']['unit']==group['unit'];assert e['rank']==values.index(e['fact']['value'])+1;assert e['tied']==(values.count(e['fact']['value'])>1);used.append(e['carId'])
    if e['carId'] in selected and digests is ad:assert e['fact']==A[e['carId']]['facts'][key]
  assert len(used)==len(set(used))
  for e in rec['excluded']+rec['unranked']:assert e['carDigest']==digests[e['carId']]
 def kg(group):return (group['vehicleClass'],group['basis'],group['unit'])
 for group in new['groups']:
  oldgroup=builtins.next((z for z in old['groups'] if kg(z)==kg(group)),{'entries':[]})
  def peers(entries):return [{k:v for k,v in e.items() if k not in ['rank','tied']} for e in entries if e['carId'] not in selected]
  assert peers(group['entries'])==peers(oldgroup['entries'])
 for section in ['excluded','unranked']:assert [e for e in new[section] if e['carId'] not in selected]==[e for e in old[section] if e['carId'] not in selected]
 selectedids=[e['carId'] for group in new['groups'] for e in group['entries'] if e['carId'] in selected];assert set(selectedids)==(set() if key=='boot_l' else selected);rankcounts[key]=len(selectedids)
print('All accepted stages and14 fields reproduced;426 peers exact; complete C1 independently derived; global ranking facts/digests/order/rank/ties/peers verified',rankcounts)
