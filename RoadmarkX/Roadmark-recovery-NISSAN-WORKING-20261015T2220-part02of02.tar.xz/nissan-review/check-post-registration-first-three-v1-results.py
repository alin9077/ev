from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,re,os
B=Path('/tmp/nissan-packet/post-registration-checks-v1');Q=Path('/tmp/nissan-review')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def verify(p):a=pin(p['path']);assert a=={k:p[k] for k in a},p['path'];return a
def meta(p):
 p=Path(p)
 if not p.exists():return dict(path=str(p),exists=False)
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
mp=B/'first-three-results-manifest-v1.json';bundle=read(mp);assert pin(mp)['sha256']=='0228971e4b464532b29ea2c9823ea5690af4141645d52dda6082d79a84cae314'
for p in [bundle['sequence'],bundle['grant'],*bundle['outputs']]:verify(p)
s=read(bundle['sequence']['path']);g=read(bundle['grant']['path']);assert g['granted']==s['sequence'][:3] and g['heavySlotExclusive'] and not g['automaticRetry'] and not g['parallelExecutionAllowed']
for key in ['sequence','reviewerAcceptance','registrationVerification']:verify(g[key])
for p in read(s['sourcePins']['path']):verify(p)
metadata=read(s['rootMetadata']['path'])
for p in metadata['fileMetadata']+metadata['directoryState']+metadata['postRegistrationTargets']:assert meta(p['path'])==p
results=[];last=None;pgroups=[];inventory=read(B/'test-inventory.json')
for ref,record in zip(s['sequence'][:3],bundle['gates']):
 verify(ref);m=read(ref['path']);d=B/'run'/m['id'];r=read(d/'result.json');t=read(d/'terminal.json');inv=read(d/'invocation.json');scope=read(d/'scope-verification.json');ap=read(d/'after-pins.json');start=read(d/'started.json')
 assert r['passed'] and r['pinsPassed'] and r['scopePassed'] and r['exitCode']==0 and not r['automaticRetry'] and not r['nextBuildClaim'];assert r['manifestSha256']==ref['sha256']
 assert t['exitCode']==t['rawWaitStatus']==0 and not t['watchdogFired'] and not t['automaticRetry'];assert t['stdoutSha256']==pin(d/'stdout.log')['sha256'] and t['stderrSha256']==pin(d/'stderr.log')['sha256'];assert (d/'stderr.log').stat().st_size==0
 assert inv['manifestSha256']==ref['sha256'] and inv['grantSha256']==bundle['grant']['sha256'] and inv['cwd']==m['repo'] and inv['command']==m['command'];assert inv['supervisedCommand']==['/usr/bin/timeout','--signal=TERM','--kill-after=10s',str(m['timeoutSeconds'])+'s',*m['command']]
 assert inv['beforePinsPassed'] and not inv['automaticRetry'] and not inv['sourceMutationsAuthorized'];assert inv['environmentRemovals']==m['environmentRemovals'] and inv['environmentOverrides']==m['environmentOverrides']
 assert ap['passed'] and ap['count']==284 and scope['passed'] and scope['sourceScopeUnchanged'] and scope['registrationTargetMetadataUnchanged']
 for p in m['extraPins']:verify(p)
 for p in m['runtimeMetadata']:assert meta(p['path'])==p
 assert read(d/'registration-target-metadata-before.json')==metadata['postRegistrationTargets']
 if last:assert inv['at']>last
 last=r['at'];text=(d/'stdout.log').read_text()
 if m['kind']=='market':assert text=='Market view verified without writing\n'
 elif m['kind']=='lint':
  lint=json.loads(text);assert len(lint)==1 and lint[0]['filePath']==str(Path(m['repo'])/'scripts/reporting/load.ts');assert lint[0]['errorCount']==lint[0]['warningCount']==lint[0]['fatalErrorCount']==0 and not lint[0]['messages']
 else:
  names=[name for file in m['testFiles'] for name in inventory[file]['names']];actual=re.findall(r'^# Subtest: (.*)$',text,re.M);assert sorted(actual)==sorted(names) and len(actual)==len(set(actual))==144
  assert len(re.findall(r'^ok \d+ - ',text,re.M))==144
  for label,n in [('tests',144),('pass',144),('fail',0),('cancelled',0),('skipped',0),('todo',0)]:assert re.search(r'^# '+label+' '+str(n)+'$',text,re.M)
  assert not re.search(r'^not ok\b',text,re.M)
 assert record['elapsedSeconds']==t['elapsedSeconds'] and record['maxRssKiB']==t['maxRssKiB'] and record['processGroup']==start['processGroup'] and record['remainingProcesses']==0
 pgroups.append(start['processGroup']);results.append(dict(id=m['id'],manifest=ref,result=pin(d/'result.json'),terminal=pin(d/'terminal.json'),elapsedSeconds=t['elapsedSeconds'],maxRssKiB=t['maxRssKiB'],afterPinCount=284,stdoutHashExact=True,stderrEmpty=True,exactScopePassed=True,processGroup=start['processGroup']))
remaining=[]
for p in Path('/proc').glob('[0-9]*/stat'):
 try:
  txt=p.read_text();fields=txt[txt.rfind(')')+2:].split()
  if int(fields[2]) in pgroups:remaining.append(dict(pid=int(p.parent.name),processGroup=int(fields[2])))
 except (FileNotFoundError,ProcessLookupError,PermissionError):pass
assert not remaining
assert len(bundle['outputs'])==27
receipt=dict(status='accepted_partial_first_three_only',at=datetime.now(timezone.utc).isoformat(),resultManifest=pin(mp),sequence=pin(B/'sequence.json'),rootGrant=bundle['grant'],readiness=pin(Q/'post-registration-v1-readiness-v1.json'),gates=results,all27OutputPinsExact=True,all266SourcePinsStillExact=True,allConfiguredAndTargetMetadataExact=True,exactBehavioralTests=144,failures=0,cancelled=0,skipped=0,todo=0,strictSerialInvocationConfirmed=True,remainingProcesses=remaining,remainingGates=[dict(id=name,runDirectoryExists=(B/'run'/name).exists()) for name in ['live-brand-safety','structural-validation']],noRuntimeExecutedByReviewer=True,currentProjectTypeScript='UNPASSED; no compiler retry',limits='Only market check, one-file lint and 144 behavioral tests accepted. Seven live-safety tests and structural validator are outside this partial result grant. Actual normal report and comparison remain required later.')
f=Q/'post-registration-v1-first-three-results-v1.json'
with f.open('x') as out:json.dump(receipt,out,indent=2);out.write('\n')
print(json.dumps(pin(f),indent=2))
