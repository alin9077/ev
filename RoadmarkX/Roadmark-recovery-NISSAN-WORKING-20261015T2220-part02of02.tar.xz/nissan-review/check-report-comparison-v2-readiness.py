from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
R=Path('/workspace/scratch/586427eef9f2/roadmark-104');B=Path('/tmp/nissan-packet/report-comparison-plan-v2');P=Path('/tmp/nissan-packet/post-registration-checks-v1');Q=Path('/tmp/nissan-review')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for x in iter(lambda:f.read(1048576),b''):h.update(x)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
cache={}
def verify(p):
 if p['path'] not in cache:cache[p['path']]=pin(p['path'])
 assert cache[p['path']]=={k:p[k] for k in ['path','bytes','sha256']},p['path']
def meta(p):
 p=Path(p)
 if not p.exists():return dict(path=str(p),exists=False)
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
s=read(B/'sequence.json');assert pin(B/'sequence.json')['sha256']=='2159949331090de38a86948f14f6a8269f124c239c2ed43ad6624ccb51873cce';assert len(s['sequence'])==2
assert s['normalReportRuns']==1 and not s['normalReportSubstitutionAllowed'] and not s['compilerRetryIncluded'] and not s['extraBroadFeatureReplay'] and not s['executionAuthorized'] and s['noAutomaticRetry'] and not s['fullProjectTypecheckPassed'] and not s['releaseAcceptanceClaim']
for p in [s['sourcePins'],s['rootMetadata'],s['registrationManifest'],s['independentCoverageException'],*s['registrationTargets'],*s['sequence']]:verify(p)
sourcepins=read(s['sourcePins']['path']);assert len(sourcepins)==603;source={p['path']:p for p in sourcepins};assert len(source)==603
for p in sourcepins:verify(p)
n,c=[read(p['path']) for p in s['sequence']]
assert n['extraPins']==c['extraPins'] and len(n['extraPins'])==211
for p in n['extraPins']:verify(p)
allpins={p['path']:p for p in sourcepins+n['extraPins']}
for p in read(P/'source-pins.json'):assert source[p['path']]==p
assert (B/'run.py').read_bytes()==(P/'run.py').read_bytes()
assert pin(B/'compare-report.mjs')['sha256']=='6de62b99383d8197a1a3b6d4509e2f92824b697aa0c085b9a4164a0ecd005283'
metadata=read(s['rootMetadata']['path']);config=read(R/'tsconfig.json')
for p in metadata['fileMetadata']+metadata['directoryState']+metadata['postRegistrationTargets']:assert meta(p['path'])==p
roots=sorted({str(p.resolve()) for pattern in config['include'] for p in R.glob(pattern) if p.is_file()});assert roots==metadata['configuredRootFilePaths'] and len(roots)==361
for m in [n,c]:
 for k in ['sourcePins','rootMetadata','registrationManifest','registrationTargets']:assert m[k]==s[k]
 assert m['originalConfig']==config and m['killAfterSeconds']==10 and not m['automaticRetry'] and not m['parallelExecutionAllowed'] and not m['sourceMutationsAuthorized']
 assert m['environmentRemovals']==read(P/'structural-validation.json')['environmentRemovals'] and m['environmentOverrides']==read(P/'structural-validation.json')['environmentOverrides']
 for p in m['runtimeMetadata']:assert meta(p['path'])==p
 for p in [m['wrapper'],m['testInventory']]:verify(p)
 assert not Path(m['runOutput']).exists()
node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node';base=[node,'--max-old-space-size=448','--max-semi-space-size=1','--import','tsx']
assert n['command']==base+['scripts/report-coverage.ts','--as-of','2026-10-15','--json'] and n['timeoutSeconds']==900 and n['expectedReportCounts']==[430,353,312]
assert c['command']==base+[str(B/'compare-report.mjs')] and c['timeoutSeconds']==180 and c['comparisonResult']==str(B/'artifacts/result.json')
assert c['prerequisites']==[dict(manifest=s['sequence'][0],resultPath=str(B/'normal-coverage-asof-2026-10-15/result.json'))]
scoped=read(P/'sequence.json');assert n['prerequisites']==[dict(manifest=p,resultPath=str(P/'run'/read(p['path'])['id']/'result.json')) for p in scoped['sequence']]
for p in n['prerequisites']:
 verify(p['manifest']);r=read(p['resultPath']);assert r['passed'] and r['exitCode']==0 and r['manifestSha256']==p['manifest']['sha256']
assert read(Q/'post-registration-v1-results-v1.json')['status']=='accepted' and read(Q/'registration-v1-live-readback-v1.json')['status']=='accepted'
normalClosure=read(B/'static-import-closure.json');compClosure=read(B/'comparator-input-closure.json')
assert len(normalClosure['files'])==121 and len(normalClosure['relativeEdges'])==164 and len(compClosure['files'])==124 and len(compClosure['edges'])==144
for closure in [normalClosure,compClosure]:
 for p in closure['files']:verify(p);assert source[p['path']]==p
for e in normalClosure['relativeEdges']:assert e['fromPath'] in source and e['toPath'] in source
for e in normalClosure['explicitJsonReads']:assert e['target'] in source
for e in compClosure['edges']:verify(e['resolved']);assert e['importer'] in source and e['resolved']['path'] in source
registry=read(R/'data/m1-brand-updates/registry.json');assert normalClosure['dynamicRegistryPackets']==compClosure['registeredPackets']==registry['packets'] and len(registry['packets'])==31
assert len(compClosure['retainedStorageFiles'])==21
for p in compClosure['retainedStorageFiles']:verify(p);assert source[p['path']]==p
assert len(compClosure['generatedNormalInputs'])==6 and not compClosure['runtimeExecuted']
assert str(Path('/tmp/nissan-packet/selected-preflight-v4/selected-packs.json')) in source
transition=read(B/'source-transition-provenance.json');changes=transition['onlyHistoricalLiveInputTransitions'];assert len(changes)==2
stage=read(transition['stageManifest']['path']);assert len(stage['pins'])==456;changed={p['historical']['path']:p for p in changes}
for p in stage['pins']:
 if p['path'] in changed:
  change=changed[p['path']];assert change['historical']==p;verify(change['retainedBefore']);verify(change['current']);assert source[p['path']]==change['current']
 else:assert source[p['path']]==p
for path in ['/tmp/nissan-packet/full-stage-v1/full-stage-result-manifest-v1.json','/tmp/nissan-packet/selected-preflight-v4/selected-result-manifest-v1.json']:
 manifest=read(path)
 for p in manifest['outputs']+manifest.get('inputs',[]):verify(p);assert allpins[p['path']]==p
failure=read(B/'typescript-failure-context.json');assert not failure['compilerRetriesAuthorized'] and not failure['releaseAcceptanceClaim'] and len(failure['attempts'])==2
for a in failure['attempts']:assert a['exitCode']==-9 and a['cause']=='unknown' and not a['fullProjectTypecheckPassed'] and not Path(a['freshCachePath']).exists()
assert not (B/'artifacts').exists()
d=dict(status='accepted',at=datetime.now(timezone.utc).isoformat(),sequence=pin(B/'sequence.json'),wrapper=pin(B/'run.py'),comparator=pin(B/'compare-report.mjs'),sourcePins=s['sourcePins'],sourcePinCount=603,extraProofPins=211,allPinsExact=True,normalCommand=s['sequence'][0],comparatorCommand=s['sequence'][1],reviewedCommands=[dict(manifest=ref,command=m['command'],timeoutSeconds=m['timeoutSeconds'],killGraceSeconds=10,watchdogMarginSeconds=20) for ref,m in zip(s['sequence'],[n,c])],registrationVerification=pin(Q/'registration-v1-live-readback-v1.json'),fiveGateAcceptance=pin(Q/'post-registration-v1-results-v1.json'),priorSemanticReview=pin(Q/'report-comparison-plan-v2-findings-v1.json'),staticNormalClosure=pin(B/'static-import-closure.json'),staticComparatorClosure=pin(B/'comparator-input-closure.json'),closureCounts=dict(normalFiles=121,normalImportEdges=164,comparatorFiles=124,comparatorEdges=144,retainedStorageLeaves=21,registeredPackets=31,historicalStagePins=456,approvedLiveTransitions=2),allSelectedAndFullStageOutputsPinned=True,generatedNormalInputContract='Six actual output files bound to normal successful result/terminal/frozen command and checked before/after by saved-output comparator',allConfiguredRootAndTargetMetadataExact=True,sourceTransitionProvenance=pin(B/'source-transition-provenance.json'),typescriptFailureContext=s['independentCoverageException'],semanticChecks=['Unchanged ordinary report runs once; all five accepted gate prerequisites','Comparator reconstructs accepted Renault30 then four selected Nissan updates and426 exact peers','Complete actual core reasons and ordered global arrays, every report leaf accounted','Digest/value/basis/group/order/rank/tie bindings for all ranking records and exact C1','Exactly268 retained feature rows unchanged;8 canonical offer/roadside replacements independently bound','Actual before freshness producers for four cars only; no broad peer feature replay or broad optional-field normalization','Normal failure stops; comparator failure preserves successful normal report and requires separately reviewed recovery'],runtimeExecuted=False,executionAuthorizedByThisReview=False,currentProjectTypeScript='UNPASSED; no compiler retry',limits='Exact readiness acceptance only; root-exclusive grant required. No report/comparator result, full-suite, C1–C6, milestone, publication or release success claimed.')
f=Q/'report-comparison-v2-readiness-v1.json'
with f.open('x') as out:json.dump(d,out,indent=2);out.write('\n')
print(json.dumps(pin(f),indent=2))
