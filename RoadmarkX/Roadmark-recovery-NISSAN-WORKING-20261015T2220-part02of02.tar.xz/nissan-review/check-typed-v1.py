import json,pathlib,hashlib,datetime,collections
P=pathlib.Path('/tmp/nissan-packet/typed-preparation-v1');mp=P/'manifest.json';m=json.loads(mp.read_text());p=json.loads((P/'nissan-2026-10-15-candidate.json').read_text());before={x['id']:x for x in json.load(open('/tmp/nissan-research/retained-before-cars-v1.json'))};checks=[]
for pin in m['pins']:
 b=pathlib.Path(pin['path']).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'];checks.append(pin['path'])
assert len(checks)==117
sources={x['id']:x for x in p['sources']};assert len(sources)==22
for s in sources.values():assert hashlib.sha256(pathlib.Path(s['capturePath']).read_bytes()).hexdigest()==s['captureSha256']
for g in p['versionGuards']:assert g['before']=={k:before[g['variantId']][k] for k in ['id','modelId','brand','model','trim','year','generation','vehicleClass','drive']}
assert len(p['versionGuards'])==4 and not any(p[k] for k in ['models','variants','versionUpdates','features','configurationUpdates'])
effective={}
for e in p['facts']:
 f=e['after'];pair=(e['variantId'],f['key']);assert pair not in effective;assert e['before']==before[e['variantId']]['facts'].get(f['key']);assert set(f['sourceIds'])<=sources.keys();assert f['sourceIds']==f['gradeReview']['sourceIds'];effective[pair]=f
 assert f['date']==p['reviewedAt']==f['gradeReview']['reviewedAt'];assert f['gradeReview']['overlayId']==p['id'];assert f['status']=={'confirmed':'standard','check':'conditional','reported':'conditional','not_published':'not_verified'}[f['buyerGrade']]
 if f['buyerGrade'] in ['confirmed','check']:assert all(sources[s]['publisher']=='Nissan Australia' for s in f['sourceIds'])
 if f['buyerGrade']=='check':assert f['conditionExplanation'] and f['issues']
for t in p['brandTerms']:
 assert set(t['applicableVariantIds'])==before.keys()
 for id in t['applicableVariantIds']:assert t['before'][id]==before[id]['facts'].get(t['key']);effective[(id,t['key'])]=t['fact']
assert len(p['facts'])==176 and len(effective)==188
for a in p['availability']:assert a['before']=={'availability':before[a['variantId']]['availability'],'evidence':before[a['variantId']]['availabilityEvidence']};assert a['after']['availability']==a['before']['availability'];assert not a['after']['evidence']['physicalStockVerified'] and not a['after']['evidence']['factoryOrderAcceptanceVerified']
for s in p['summaries']:
 for k in ['strength','tradeoff']:
  for d in s[k]['dependencies']:assert d['expected']==effective[(s['variantId'],d['key'])] and not d['expected']['issues']
corekeys=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty','battery_warranty']
counts=collections.Counter(effective[(id,k)]['buyerGrade'] for id in before for k in corekeys);assert counts=={'confirmed':65,'check':3}
for id in before:
 for k in ['advertised_driveaway_aud','promotional_driveaway_aud']:
  f=effective[(id,k)];assert f['buyerGrade']=='reported' and f['validUntil']=='2026-10-31' and not f['priceEvidence']['rankingEligible']
 assert effective[(id,'boot_l')]['comparisonBasis']=='Cargo measurement method not stated; seats upright to roof'
 assert effective[(id,'battery_kwh')]['comparisonBasis']=='Usable'
 assert effective[(id,'range_km')]['comparisonBasis']=='WLTP combined'
 assert effective[(id,'width_mm')]['comparisonBasis']=='Excluding mirrors'
 assert effective[(id,'roadside_assistance')]['value']=='1 year'
 assert 'preferred Authorised Servicing Dealer only when the breakdown is within 50 km' in ' '.join(effective[(id,'roadside_assistance')]['qualifications'])
out={'status':'REVIEWED WITH NARROW PROVENANCE/WORDING AMENDMENTS REQUIRED; runtime not executed','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest':{'path':str(mp),'sha256':hashlib.sha256(mp.read_bytes()).hexdigest(),'pins':len(checks),'allExact':True},'candidate':m['candidate'],'sourceReview':'/tmp/nissan-review/source-review-v3-findings-v1.json','counts':{'retainedVersions':4,'newRows':0,'identityUpdates':0,'factBeforeGuards':176,'sharedTermApplications':12,'effectiveUpdatedCells':188,'coreCells':68,'coreGrades':dict(counts),'sources':22,'availabilityGuards':4,'summaryPairs':4},'accepted':['All candidate identity/fact/availability/shared beforeguards match exact accepted baseline objects; all source capture hashes resolve','Core values, bases, dates and grades agree with independently reviewed current sources; no generic caveat downgrade','Primary maker MSRP before on-road costs stays separate from Reported expiring October new/demo offer','Three FWD AC and mass conflicts preserve source alternatives and specific applicability holds, without invented cause or retrofit','Combined WLTP and usable-battery bases remain explicit; cargo and unspecified-start DC windows remain distinct unknown-method groups; mirror states stay separate','Exact current named-grade availability does not claim physical unregistered stock or accepted factory orders, and history stays in before evidence','Base warranty, conditional service-activated extensions, capacity gauge-bar trigger/remedy and all five roadside-page limits retained; roadside value is self-contained 1 year','Four summary pairs have complete exact current fact dependencies and avoid unsupported rank/fastest/leading assertions','Reconciliation includes complete four-grade ARIYA family, with LEAF generations, residual stock widgets and overseas/future candidates separately dispositioned'],'requiredAmendments':['Apply the five-page image-based roadside captureMethod only to roadside PDF source; ARIYA specification PDF sources are two pages','Supplemental rung-5 offer provenance must designate CarExpert as primary publisher and sourcePointer, with Sutherland dealer corroboration separately clear; alternatively use rung 6 for dealer-primary provenance','Use buyer-readable gauge-bar wording in capacity aliases as already used in the canonical capacity term, replacing research instruction about an invented percentage','Keep RACV 400-car launch context in the separately labelled source sidecar rather than in maker-graded AC fact qualifications whose evidence citations exclude RACV'],'scopeLimits':['Static JSON and repository source inspection only; no actual helper, selected consumer, hydration, compiler, build, server or live edit','Current project TypeScript/release remain UNPASSED','Separate selected-consumer readiness and parent execution grant required; no global acceptance']}
path=pathlib.Path('/tmp/nissan-review/typed-preparation-v1-findings-v1.json');path.open('x').write(json.dumps(out,indent=2)+'\n');print(path);print(out['status'])
