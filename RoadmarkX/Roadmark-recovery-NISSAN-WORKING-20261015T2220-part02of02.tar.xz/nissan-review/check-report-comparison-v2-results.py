from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,copy,collections,math
B=Path('/tmp/nissan-packet/report-comparison-plan-v2');Q=Path('/tmp/nissan-review');S=Path('/tmp/nissan-packet/full-stage-v1/output');R=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1048576),b''):h.update(c)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def verify(p):assert pin(p['path'])=={k:p[k] for k in ['path','bytes','sha256']},p['path']
def pct(n,d):return math.floor(n/d*1000+0.5)/10 if d else None
def meta(p):
 p=Path(p)
 if not p.exists():return dict(path=str(p),exists=False)
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
mp=B/'results-manifest-v1.json';bundle=read(mp);assert pin(mp)['sha256']=='a4e35cbd0db106bdbce378675d21151ffe262bd6c21729fc98f78be98e06be81'
for p in [bundle['sequence'],bundle['rootGrant'],bundle['sourcePins'],bundle['slotRelease'],*bundle['files']]:verify(p)
assert len(bundle['files'])==32
seq=read(bundle['sequence']['path']);grant=read(bundle['rootGrant']['path']);assert grant['granted']==seq['sequence'] and grant['heavySlotExclusive'] and not grant['automaticRetry'] and not grant['parallelExecutionAllowed']
for key in ['sequence','reviewerAcceptance','registrationVerification']:verify(grant[key])
for p in read(seq['sourcePins']['path']):verify(p)
metadata=read(seq['rootMetadata']['path'])
for p in metadata['fileMetadata']+metadata['directoryState']+metadata['postRegistrationTargets']:assert meta(p['path'])==p
last=None;gateproof=[];pgroups=[]
for ref,record in zip(seq['sequence'],bundle['checks']):
 verify(ref);m=read(ref['path']);d=Path(m['runOutput']);r=read(d/'result.json');t=read(d/'terminal.json');i=read(d/'invocation.json');a=read(d/'after-pins.json');scope=read(d/'scope-verification.json');start=read(d/'started.json')
 assert r['passed'] and r['exitCode']==0 and r['pinsPassed'] and r['scopePassed'] and r['manifestSha256']==ref['sha256'] and not r['automaticRetry']
 assert t['exitCode']==t['rawWaitStatus']==0 and not t['watchdogFired'] and not t['automaticRetry'];assert t['stdoutSha256']==pin(d/'stdout.log')['sha256'] and t['stderrSha256']==pin(d/'stderr.log')['sha256'] and not (d/'stderr.log').stat().st_size
 assert i['manifestSha256']==ref['sha256'] and i['grantSha256']==bundle['rootGrant']['sha256'] and i['command']==m['command'] and i['cwd']==m['repo'] and i['beforePinsPassed'] and not i['sourceMutationsAuthorized'] and not i['automaticRetry']
 assert i['supervisedCommand']==['/usr/bin/timeout','--signal=TERM','--kill-after=10s',str(m['timeoutSeconds'])+'s',*m['command']]
 assert i['environmentRemovals']==m['environmentRemovals'] and i['environmentOverrides']==m['environmentOverrides'];assert a['passed'] and a['count']==822 and scope['passed'] and scope['sourceScopeUnchanged'] and scope['registrationTargetMetadataUnchanged']
 assert read(d/'registration-target-metadata-before.json')==metadata['postRegistrationTargets']
 for p in m['extraPins']:verify(p)
 for p in m['runtimeMetadata']:assert meta(p['path'])==p
 if last:assert i['at']>last
 last=r['at'];pgroups.append(start['processGroup']);gateproof.append(dict(id=m['id'],manifest=ref,result=pin(d/'result.json'),terminal=pin(d/'terminal.json'),seconds=t['elapsedSeconds'],maxRssKiB=t['maxRssKiB'],afterChecks=822))
release=read(bundle['slotRelease']['path']);assert [g['processGroup'] for g in release['groups']]==pgroups and all(not g['remaining'] for g in release['groups']) and release['heavySlotReleased']
for p in read(B/'artifacts/generated-normal-input-closure.json'):verify(p)
normal=read(B/'normal-coverage-asof-2026-10-15/stdout.log');baseline=read('/tmp/renault-packet/report-comparison-v4/normal-coverage-asof-2026-10-15/stdout.log');before=read(B/'artifacts/selected-before-report.json');after=read('/tmp/nissan-packet/selected-preflight-v4/result.json')['selectedCoverage'];result=read(B/'artifacts/result.json')
assert result['passed'] and result['normalReportSha256']==pin(B/'normal-coverage-asof-2026-10-15/stdout.log')['sha256']=='61b497fb9f1e1f7683b07e9040638c781ff4e8c597ca507f9afd5b2205ad9768'
assert read(B/'artifacts/expected-versus-normal-diff.json')==[]
assert [normal[k] for k in ['allCatalogueVersions','tierOneVersions','onSaleVersions']]==[430,353,312]
selectedCars=read(S/'selected-after-cars.json');ids={c['id'] for c in selectedCars};packs=read(S/'selected-packs.json');digests=read(S/'car-digest-comparison.json');order={r['id']:i for i,r in enumerate(digests['candidate31'])};assert len(order)==430
assert before['brandProgress'][0]==next(x for x in baseline['brandProgress'] if x['brand']=='Nissan')
assert [x for x in normal['brandProgress'] if x['brand']!='Nissan']==[x for x in baseline['brandProgress'] if x['brand']!='Nissan']
expected=copy.deepcopy(baseline);expected['brandProgress']=[after['brandProgress'][0] if x['brand']=='Nissan' else x for x in baseline['brandProgress']]
reasonRows=read(B/'artifacts/global-core-complete-reason-inventory.json');expectedCore=[]
for old,b,a,reasons in zip(baseline['core'],before['core'],after['core'],reasonRows):
 assert old['key']==b['key']==a['key']==reasons['key'];x=copy.deepcopy(old);x['filled']=old['filled']-b['filled']+a['filled'];x['grades']={k:old['grades'][k]-b['grades'][k]+a['grades'][k] for k in old['grades']};x['filledPercent']=pct(x['filled'],312);x['confirmedPercent']=pct(x['grades']['Confirmed'],312);x['reviewed']=312-x['grades']['Unreviewed'];x['reviewedPercent']=pct(x['reviewed'],312);x['gradingPasses']=x['grades']['Unreviewed']==0;x['passes']=x['filled']/312*100>=x['target']
 for phase,cell in [('before',old),('after',x)]:
  rows=reasons[phase+'FullReasons'];assert sum(n for _,n in rows)==312-cell['grades']['Confirmed'];explanation='; '.join(f'{n}: {reason}' for reason,n in sorted(rows,key=lambda r:-r[1])[:2]) if cell['grades']['Confirmed']/312<.5 else None;assert explanation==reasons[phase+'Explanation']
  if phase=='before':assert explanation==old['explanation']
  else:x['explanation']=explanation
 expectedCore.append(x)
expected['core']=expectedCore
coreorder={x['key']:i for i,x in enumerate(expectedCore)};peers=lambda rows:[x for x in rows if x['carId'] not in ids]
expected['gaps']=sorted(peers(baseline['gaps'])+after['gaps'],key=lambda x:(coreorder[x['key']],order[x['carId']]))
expected['summaryGaps']=sorted(peers(baseline['summaryGaps'])+after['summaryGaps'],key=lambda x:order[x['carId']])
# Actual full-stage ranking records are already accepted value/basis/digest/rank controls.
rankstage=read(S/'global-ranking-comparison.json');onsale=set(baseline['rankings'][0]['rankedIds'])|{x['carId'] for x in baseline['rankings'][0]['excluded']};assert len(onsale)==312
newranks=[]
for old in baseline['rankings']:
 stage=next(x for x in rankstage if x['attribute']==old['key']);records=stage['completeOrderedAfter'];groups=[]
 for group in records['groups']:
  entries=[e for e in group['entries'] if e['carId'] in onsale]
  if entries:groups.append(dict(vehicleClass=group['vehicleClass'],basis=group['basis'],unit=group['unit'],count=len(entries),entries=entries))
 groups.sort(key=lambda g:min(order[e['carId']] for e in g['entries']));groups.sort(key=lambda g:(-g['count'],g['basis']))
 ranked=[e['carId'] for g in groups for e in g['entries']];excluded=[{k:v for k,v in e.items() if k!='carDigest'} for e in records['excluded'] if e['carId'] in onsale];assert len(ranked)+len(excluded)==312
 x=copy.deepcopy(old);x.update(ranked=len(ranked),percent=pct(len(ranked),312),rankedIds=ranked,passes=len(ranked)/312>=.9,groups=[{k:v for k,v in g.items() if k!='entries'} for g in groups],excluded=excluded,exclusionReasons=dict(collections.Counter(e['reason'] for e in excluded)));newranks.append(x)
expected['rankings']=newranks
for key in ['missingModels','unresolvedLeads']:
 assert after[key]==[];expected[key]=[x for x in baseline[key] if x['brand']!='Nissan']
c1=read(S/'global-c1-comparison.json');assert baseline['reconciliation']==c1['before'];expected['reconciliation']=c1['after']
expected['pairedOnSale']=baseline['pairedOnSale']-before['pairedOnSale']+after['pairedOnSale'];expected['pairedOnSalePercent']=pct(expected['pairedOnSale'],312)
expected['inAllRankings']=len(set.intersection(*(set(x['rankedIds']) for x in newranks)));expected['inAllRankingsPercent']=pct(expected['inAllRankings'],312)
reviewed=sum(c['reviewed'] for c in expectedCore);expected['grading']=dict(reviewedCoreCells=reviewed,totalCoreCells=5304,reviewedPercent=pct(reviewed,5304));expected['gradeNote']=baseline['gradeNote'].replace(f"{baseline['grading']['reviewedCoreCells']}/{baseline['grading']['totalCoreCells']}",f'{reviewed}/5304')
for key,property,negate in [('brandsResearchCompleted','researchCompleted',False),('brandsResearchRemaining','researchCompleted',True),('brandsDone','done',False),('brandsRemaining','done',True)]:expected[key]=[x['brand'] for x in expected['brandProgress'] if bool(x[property])!=negate]
for key in ['overdue','invalid','excludedHistory']:expected['ageing'][key]=sorted(peers(baseline['ageing'][key])+after['ageing'][key],key=lambda x:(x['kind']=='equipment',order[x['carId']]))
expected['ageing']['dueNext30Days']=baseline['ageing']['dueNext30Days']-before['ageing']['dueNext30Days']+after['ageing']['dueNext30Days']
rc=expected['reconciliation'];core=expectedCore;age=expected['ageing'];ranks=newranks
expected['criteria']=[dict(id='C1',pass_=rc['pass'],detail=f"{rc['reviewedModels']} exact current model lists reviewed; {rc['settledListEntryCount']}/{rc['listEntryCount']} entries settled across {rc['independentListCount']} independent lists; {len(rc['issues'])} blockers. {len(expected['missingModels'])} unmatched audit models; {len(expected['unresolvedLeads'])} unresolved leads.",sources=baseline['criteria'][0]['sources']),dict(id='C2',pass_=all(c['passes'] for c in core),detail=f"{sum(c['passes'] for c in core)}/{len(core)} core fields meet their target; {len(expected['gaps'])} version/field gaps, each with a reason in --details or --json."),dict(id='C3',pass_=all(c['gradingPasses'] and (c['confirmedPercent']>=50 or bool(c['explanation'])) for c in core),detail=f"{reviewed}/5304 core cells have earned reviews; {sum(c['confirmedPercent']<50 for c in core)} fields below half Confirmed have patterns in --details. No grade quota is applied."),dict(id='C4',pass_=not expected['summaryGaps'],detail=f"{353-len(expected['summaryGaps'])}/353 Tier 1 versions have both a supported strength and trade-off ({expected['pairedOnSale']}/312 on sale)."),dict(id='C5',pass_=all(r['passes'] for r in ranks),detail=f"{sum(r['passes'] for r in ranks)}/6 ranking lists reach 90% of on-sale Tier 1 versions; measurement groups stay separate."),dict(id='C6',pass_=not age['overdue'] and not age['invalid'],detail=f"{len(age['overdue'])} aged claims and {len(age['invalid'])} invalid/future/undated claims across all Tier 1 versions, including availability and equipment. Model-year changes still require a recorded review.")]
for x in expected['criteria']:x['pass']=x.pop('pass_')
assert expected==normal,'Independent complete written report expectation differs'
features=read(B/'artifacts/selected-before-features.json');assert len(features)==276;assert sum(f==next(x for x in packs[f['variant_id']]['features'] if x['criterion']==f['criterion']) for f in features if f['criterion'] not in ['roadside_assistance','driveaway_price'])==268
projection=read(B/'artifacts/canonical-replacement-projection-proof.json');assert len(projection)==8
for p in projection:
 f=next(x for x in packs[p['variantId']]['features'] if x['criterion']==p['criterion']);assert p['value']==f['value'] and p['buyerGrade']==f['buyerGrade'] and p['sourceIds']==f['source_ids'] and p['conditions']==f['conditions'] and p['validUntil']==f.get('validUntil')
peerproof=read(B/'artifacts/accepted-peer-car-value-and-basis-proof.json');assert peerproof['peers']==[x for x in digests['candidate31'] if x['id'] not in ids]==[x for x in digests['candidate30'] if x['id'] not in ids] and len(peerproof['peers'])==426
assert result['exhaustiveDifferences']==len(read(B/'artifacts/exhaustive-normal-versus-renault-diff.json'))==1242
nissan=next(x for x in normal['brandProgress'] if x['brand']=='Nissan');assert sum(x['grades']['Confirmed'] for x in nissan['core'])==65 and sum(x['grades']['Check'] for x in nissan['core'])==3 and nissan['researchCompleted'] and not nissan['done']
remaining=[]
for p in Path('/proc').glob('[0-9]*/stat'):
 try:
  t=p.read_text();fields=t[t.rfind(')')+2:].split()
  if int(fields[2]) in pgroups:remaining.append(int(p.parent.name))
 except (FileNotFoundError,ProcessLookupError,PermissionError):pass
assert not remaining
receipt=dict(status='accepted',at=datetime.now(timezone.utc).isoformat(),resultManifest=pin(mp),sequence=bundle['sequence'],rootGrant=bundle['rootGrant'],readiness=pin(Q/'report-comparison-v2-readiness-v1.json'),normalReport=pin(B/'normal-coverage-asof-2026-10-15/stdout.log'),comparatorResult=pin(B/'artifacts/result.json'),gates=gateproof,all32OutputPinsExact=True,all603SourceAnd211ProofPinsExact=True,metadataExact=True,generatedNormalInputsExact=6,independentCompleteWrittenReportExpectationExact=True,completeCoreReasonInventories=17,orderedGlobalArraysAccounted=True,allSixReportRankingsDerivedFromAcceptedFullStage=True,unchangedPeerBrands=55,unchangedCompleteCars=426,unchangedRetainedFeatures=268,canonicalReplacements=8,exhaustiveChanges=1242,expectedDiff=[],counts=dict(catalogue=430,tierOne=353,onSale=312),researchCompletedBrands=15,researchRemainingBrands=41,nissan=dict(onSale=4,coreConfirmed=65,coreCheck=3,researchCompleted=True,done=False,criteria=nissan['criteria']),ranked={x['key']:x['ranked'] for x in normal['rankings']},globalC1=dict(reviewedModels=rc['reviewedModels'],reviewedVersions=rc['reviewedVersions'],issues=len(rc['issues']),settledInventory=len(rc['settledInventory']),pass_=rc['pass']),terminalSlotRelease=bundle['slotRelease'],remainingProcesses=remaining,currentProjectTypeScript='UNPASSED; no compiler retry or release pass',runtimeExecutedByReviewer=False,limits='Independent result acceptance of factual report/comparator only. Global C1–C5 remain open; C6 passes. No milestone, full-suite, publication or release acceptance.')
f=Q/'report-comparison-v2-results-v1.json'
with f.open('x') as out:json.dump(receipt,out,indent=2);out.write('\n')
print(json.dumps(pin(f),indent=2))
