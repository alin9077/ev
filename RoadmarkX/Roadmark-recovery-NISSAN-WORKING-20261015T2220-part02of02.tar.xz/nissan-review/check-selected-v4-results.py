import json,pathlib,collections,copy,hashlib,datetime
P=pathlib.Path('/tmp/nissan-packet/selected-preflight-v4');R=json.load(open(P/'result.json'));A={x['id']:x for x in json.load(open(P/'selected-after-cars.json'))};B={x['id']:x for x in json.load(open('/tmp/nissan-research/retained-before-cars-v1.json'))};C=json.load(open('/tmp/nissan-packet/typed-preparation-v2/nissan-2026-10-15-candidate.json'));packs=json.load(open(P/'selected-packs.json'));stored=json.load(open(P/'portable.json'));claims=json.load(open(P/'claims.json'));features=json.load(open(P/'feature-claims.json'));availability=json.load(open(P/'availability-claims.json'))
assert len(A)==len(B)==len(packs)==len(stored)==4
core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty','battery_warranty'];effective={}
for x in C['facts']:effective.setdefault(x['variantId'],{})[x['after']['key']]=x['after']
for t in C['brandTerms']:
 for id in t['applicableVariantIds']:effective[id][t['key']]=t['fact']
for id,a in A.items():
 b=B[id];assert set(a['facts'])==set(b['facts'])|set(effective[id]);assert packs[id]['car']==a
 for k,f in a['facts'].items():assert f==effective[id].get(k,b['facts'].get(k)),(id,k)
 for k in ['id','modelId','brand','model','trim','year','generation','vehicleClass','drive','configurationEvidence']:assert (k in a)==(k in b) and a.get(k)==b.get(k)
 assert len(packs[id]['features'])==69
 s=copy.deepcopy(stored[id]);sourceids=s.pop('sourceIds');byid={x['id']:x for x in packs[id]['sources']};s['sources']=[byid[x] for x in sourceids]
 for f in s['features']:f.setdefault('variant_id',s['car']['id']);f.setdefault('model_id',s['car']['modelId'])
 assert s==packs[id],id
 for k,f in effective[id].items():
  claim=next(x['claim'] for x in claims if x['variantId']==id and x['key']==k);assert claim['buyerGrade']==f['buyerGrade'];assert [x['id'] for x in claim['sources']]==f['sourceIds'];assert claim['evidenceDate']=='2026-10-15'
 for k in ['roadside_assistance','driveaway_price']:
  f=next(x for x in packs[id]['features'] if x['criterion']==k);c=next(x['claim'] for x in features if x['variantId']==id and x['criterion']==k);source=a['facts']['roadside_assistance' if k=='roadside_assistance' else 'promotional_driveaway_aud']
  assert f['value']==c['value']==('1 year' if k=='roadside_assistance' else 'A$'+format(source['value'],','));assert c['buyerGrade']==source['buyerGrade'];assert [x['id'] for x in c['sources']]==source['sourceIds'];assert all(q in f['conditions'] for q in source['qualifications'])
 assert a['facts']['roadside_assistance']['value']=='1 year'
 e=next(x for x in R['expiryBoundaryProof'] if x['variantId']==id);assert [x['asOf'] for x in e['checks']]==['2026-10-31','2026-11-01'];assert [x['offerExpired'] for x in e['checks']]==[False,True]
 for row in [x for x in R['comparisonProof'] if x['left']==id]:
  left=a['facts'][row['key']];right=A[row['right']]['facts'][row['key']];z=row['result']
  if z['state']=='comparable':assert z['delta']==right['value']-left['value']
  else:assert 'delta' not in z
 assert all('delta' not in x['result'] for x in R['crossBasisProof'])
for row in features:
 f=next(x for x in packs[row['variantId']]['features'] if x['criterion']==row['criterion']);assert [x['id'] for x in row['claim']['sources']]==list(dict.fromkeys(f['source_ids']))
for key,entry in R['rankCounts'].items():
 vals=[A[id]['facts'][key]['value'] for id in entry['ranked']]
 assert vals==sorted(vals,reverse=key in ['range_km','towing_braked_kg','seats']) or len(set(vals))<2,(key,vals)
for row in R['negativeProof']:assert row['rejected'] and row['inputsUnchanged']
assert len(claims)==188 and len(features)==276 and len(availability)==4
assert len(R['comparisonProof'])==190 and len(R['crossBasisProof'])==24
assert collections.Counter(A[id]['facts'][k]['buyerGrade'] for id in A for k in core)=={'confirmed':65,'check':3}
print('PASS independent four-car/effective+untouched facts, written pack/portable, 188 fact claim sources, 276 feature claim sources, canonical values, comparison deltas, expiry and rank ordering')
print('fact sizes',[(id,len(B[id]['facts']),len(A[id]['facts']),len(B[id]['facts'].keys()-effective[id].keys())) for id in A])
print('nonfact top keys changed')
for id in A:print(id,[k for k in set(A[id])|set(B[id]) if A[id].get(k)!=B[id].get(k) and k!='facts'])
