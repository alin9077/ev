import json,pathlib,hashlib,datetime
base=pathlib.Path('/tmp/nissan-packet');checks=[]
for n,expected,count in [(2,'15c1d4da975274fa8228202eb1df4ede9f933b48a029acf968e387d2eff97dcf',88),(3,'2ee81ec084fe7bb72f32da5996900ef510254aea969fee0a2fd85b6edc57899e',98)]:
 p=base/f'source-review-v{n}/manifest.json';assert hashlib.sha256(p.read_bytes()).hexdigest()==expected
 m=json.loads(p.read_text());assert len(m['pins'])==count
 for pin in m['pins']:
  b=pathlib.Path(pin['path']).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256']
 checks.append({'version':n,'manifestPath':str(p),'manifestSha256':expected,'pinsVerified':count,'allExact':True})
a=json.loads((base/'source-review-v1/candidate-facts.json').read_text());z=json.loads((base/'source-review-v3/candidate-facts.json').read_text()); grades={}
for x,y in zip(a['versions'],z['versions']):
 assert x['id']==y['id'] and x['beforeIdentity']==y['beforeIdentity']
 for key in x['core']:
  assert x['core'][key]['value']==y['core'][key]['value'] and x['core'][key]['grade']==y['core'][key]['grade']
  grades[y['core'][key]['grade']]=grades.get(y['core'][key]['grade'],0)+1
 assert y['core']['range']['basis']=='WLTP combined cycle for exact named grade'
 assert y['core']['range']['comparisonBasis']=='WLTP combined'
 assert y['core']['boot']['comparisonBasis']=='Cargo measurement method not stated; seats upright to roof'
 assert y['core']['boot']['rankingEligible']==False
 if y['core']['ac']['grade']=='Check':
  assert y['core']['ac']['contextSourceIds']==['racv-launch-review'] and 'racv-launch-review' not in y['core']['ac']['sourceIds']
terms=json.loads((base/'source-review-v3/brand-terms.json').read_text())
assert 'preferred Authorised Servicing Dealer only when the breakdown is within 50 km of that repairer' in terms['roadside']['conditions'][3]
assert len(terms['roadside']['conditions'])==6 and 'captureProvenance' in terms['roadside']
for name in ['identity-review.json','conflicts-and-history.json','source-index.json','bounded-validation.json']:
 assert (base/'source-review-v1'/name).read_bytes()==(base/'source-review-v3'/name).read_bytes()
assert grades=={'Confirmed':65,'Check':3}
out={'status':'PASS — source/admission amendments only; typed candidate and runtime acceptance pending','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'priorReview':'/tmp/nissan-review/source-review-v1-findings-v1.json','manifestChecks':checks,'coreValuesAndGradesUnchanged':True,'coreGradeCounts':grades,'amendmentsVerified':['Four range bases now WLTP combined cycle with WLTP combined grouping, preserving exact maker values and Confirmed grades','Four cargo methods explicitly unknown and unranked, preserving Confirmed published capacity figures','RACV launch quantity classified as secondary context, not maker-grade AC evidence','Roadside preferred destination restricted to Authorised Servicing Dealer with 50 km breakdown-to-repairer limit','Image-based PDF capture process retained only in provenance'],'unchangedMaterial':['Four retained identities and admissions','All 68 core values and grades','Price, lifecycle, warranty factual source conclusions','Original immutable source versions and baseline objects'],'openRequirements':['Typed candidate must consume v3 exactly with complete before-identity guards and accepted digest/source pins','Buyer-facing conditions should express actual buyer conditions rather than research-process narration','Runtime, all-consumer parity, integration, global acceptance and release remain untested here'],'executionLimits':['No production loader, hydration, compiler, build, test server or live repository edit','No global C1-C6 or release acceptance']}
p=pathlib.Path('/tmp/nissan-review/source-review-v3-findings-v1.json');p.open('x').write(json.dumps(out,indent=2)+'\n');print(p);print(out['status'])
