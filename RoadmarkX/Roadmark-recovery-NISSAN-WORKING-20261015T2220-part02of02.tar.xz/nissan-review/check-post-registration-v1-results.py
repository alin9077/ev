from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re
B=Path('/tmp/nissan-packet/post-registration-checks-v1');Q=Path('/tmp/nissan-review')
def read(p):return json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1048576),b''):h.update(c)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def verify(p):assert pin(p['path'])=={k:p[k] for k in ['path','bytes','sha256']},p['path']
def meta(p):
 p=Path(p)
 if not p.exists():return dict(path=str(p),exists=False)
 s=p.stat();return dict(path=str(p),exists=True,realpath=str(p.resolve()),bytes=s.st_size,mtimeNs=s.st_mtime_ns,mode=s.st_mode,isDirectory=p.is_dir(),isSymlink=p.is_symlink())
mp=B/'results-manifest-v1.json';bundle=read(mp);assert pin(mp)['sha256']=='f9ca8b568bd2f570f19a0eefb3a3f9ee9b6f46b198bcba7298011f8e9b499c07'
for p in [bundle['sequence'],bundle['sourcePins'],*bundle['rootGrants'],*bundle['files']]:verify(p)
assert len(bundle['files'])==45
s=read(bundle['sequence']['path']);grants=[read(p['path']) for p in bundle['rootGrants']];assert grants[0]['granted']==s['sequence'][:3] and grants[1]['granted']==s['sequence'][3:]
for g in grants:
 assert g['status']=='root_execution_granted' and g['heavySlotExclusive'] and not g['automaticRetry'] and not g['parallelExecutionAllowed']
 for k in ['sequence','reviewerAcceptance','registrationVerification']:verify(g[k])
sourcepins=read(s['sourcePins']['path']);assert len(sourcepins)==266
for p in sourcepins:verify(p)
metadata=read(s['rootMetadata']['path'])
for p in metadata['fileMetadata']+metadata['directoryState']+metadata['postRegistrationTargets']:assert meta(p['path'])==p,p['path']
inventory=read(B/'test-inventory.json');tests=[];rows=[];pgroups=[];prior=None;structural=None
for i,(ref,record) in enumerate(zip(s['sequence'],bundle['checks'])):
 verify(ref);m=read(ref['path']);d=B/'run'/m['id'];r=read(d/'result.json');t=read(d/'terminal.json');v=read(d/'invocation.json');a=read(d/'after-pins.json');scope=read(d/'scope-verification.json');started=read(d/'started.json');gp=bundle['rootGrants'][0 if i<3 else 1]
 assert record['manifest']==ref and record['name']==m['id'] and record['passed'] and record['exitCode']==0
 for k in ['result','terminal']:verify(record[k])
 assert r['passed'] and r['exitCode']==0 and r['pinsPassed'] and r['scopePassed'] and not r['automaticRetry'] and r['manifestSha256']==ref['sha256'] and not r['nextBuildClaim']
 assert t['exitCode']==t['rawWaitStatus']==0 and not t['watchdogFired'] and not t['automaticRetry'];assert t['stdoutSha256']==pin(d/'stdout.log')['sha256'] and t['stderrSha256']==pin(d/'stderr.log')['sha256'] and not (d/'stderr.log').stat().st_size
 assert v['manifestSha256']==ref['sha256'] and v['grantSha256']==gp['sha256'] and v['command']==m['command'] and v['cwd']==m['repo'] and v['beforePinsPassed'] and not v['sourceMutationsAuthorized'] and not v['automaticRetry']
 assert v['supervisedCommand']==['/usr/bin/timeout','--signal=TERM','--kill-after=10s',str(m['timeoutSeconds'])+'s',*m['command']]
 assert v['environmentRemovals']==m['environmentRemovals'] and v['environmentOverrides']==m['environmentOverrides']
 assert a['passed'] and a['count']==284 and scope['passed'] and scope['sourceScopeUnchanged'] and scope['registrationTargetMetadataUnchanged']
 assert read(d/'registration-target-metadata-before.json')==metadata['postRegistrationTargets']
 for p in m['runtimeMetadata']:assert meta(p['path'])==p
 for p in m['extraPins']:verify(p)
 if prior:assert v['at']>prior
 prior=r['at'];stdout=(d/'stdout.log').read_text()
 if m['kind']=='market':assert stdout=='Market view verified without writing\n'
 elif m['kind']=='lint':
  lint=json.loads(stdout);assert len(lint)==1 and lint[0]['filePath']==m['repo']+'/scripts/reporting/load.ts' and lint[0]['errorCount']==lint[0]['warningCount']==lint[0]['fatalErrorCount']==0 and not lint[0]['messages']
 elif m['kind']=='tests':
  names=[name for file in m['testFiles'] for name in inventory[file]['names']];observed=re.findall(r'^# Subtest: (.*)$',stdout,re.M);n=m['expectedTests'];assert len(names)==len(set(observed))==len(observed)==n and sorted(names)==sorted(observed);assert len(re.findall(r'^ok \d+ - ',stdout,re.M))==n
  for label,value in [('tests',n),('pass',n),('fail',0),('cancelled',0),('skipped',0),('todo',0)]:assert re.search(r'^# '+label+' '+str(value)+'$',stdout,re.M)
  assert not re.search(r'^not ok\b',stdout,re.M);tests+=observed
 else:
  structural=json.loads(stdout);assert structural['result']=='PASS' and structural['counts']==m['expectedStructuralCounts'] and structural['sourceReferences']==m['expectedSourceReferences']==3831 and structural['publicationIssues']==15 and structural['approvedExternalAssets']==0 and structural['sha256']==m['immutableResearchSha256']
 pgroups.append(started['processGroup']);rows.append(dict(id=m['id'],manifest=ref,result=record['result'],terminal=record['terminal'],seconds=t['elapsedSeconds'],maxRssKiB=t['maxRssKiB'],tests=m.get('expectedTests'),afterPinCount=284,emptyStderr=True,watchdog=False))
assert len(rows)==5 and len(tests)==len(set(tests))==151
release=read(B/'terminal-slot-release-v1.json');assert release['resultsManifest']==pin(mp) and release['heavySlotReleased'] and [x['processGroup'] for x in release['groups']]==pgroups and all(not x['remaining'] for x in release['groups'])
remaining=[]
for p in Path('/proc').glob('[0-9]*/stat'):
 try:
  txt=p.read_text();parts=txt[txt.rfind(')')+2:].split()
  if int(parts[2]) in pgroups:remaining.append(int(p.parent.name))
 except (FileNotFoundError,ProcessLookupError,PermissionError):pass
assert not remaining
receipt=dict(status='accepted',at=datetime.now(timezone.utc).isoformat(),resultManifest=pin(mp),sequence=pin(B/'sequence.json'),rootGrants=bundle['rootGrants'],readiness=pin(Q/'post-registration-v1-readiness-v1.json'),registrationVerification=pin(Q/'registration-v1-live-readback-v1.json'),partialReview=pin(Q/'post-registration-v1-first-three-results-v1.json'),gates=rows,allFiveScopedGatesPassed=True,all45OutputPinsExact=True,all266SourcePinsExact=True,allConfiguredAndTargetMetadataExact=True,perGateAfterChecks=284,strictSerialInvocations=True,behavioralTests=144,liveSafetyTests=7,distinctScopedTests=151,failed=0,cancelled=0,skipped=0,todo=0,structural=structural,terminalSlotRelease=pin(B/'terminal-slot-release-v1.json'),remainingProcesses=remaining,noRuntimeExecutedByReviewer=True,currentProjectTypeScript='UNPASSED; both unknown-cause KGM SIGKILL attempts retained; no compiler retry',normalReportPassed=False,comparatorPassed=False,limits='Accepted five scoped gates only, not full suite or C1–C6/milestone/release pass. Final normal-report/comparator source freeze, readiness review and exact parent-exclusive grant still required.',reviewerDiagnostic='An initial read-only inspection assumed the partial manifest outputs key; full manifest uses files. The corrected inspection verified all45 files. No runtime retry or data change.')
f=Q/'post-registration-v1-results-v1.json'
with f.open('x') as out:json.dump(receipt,out,indent=2);out.write('\n')
print(json.dumps(pin(f),indent=2))
