import json,hashlib,pathlib,datetime
root=pathlib.Path('/tmp/nissan-packet/source-review-v1');mp=root/'manifest.json';m=json.loads(mp.read_text());checks=[]
for p in m['pins']:
 b=pathlib.Path(p['path']).read_bytes(); checks.append({'path':p['path'],'bytesMatch':len(b)==p['bytes'],'sha256Match':hashlib.sha256(b).hexdigest()==p['sha256']})
assert len(checks)==78 and all(x['bytesMatch'] and x['sha256Match'] for x in checks)
cf=json.loads((root/'candidate-facts.json').read_text()); retained={x['id']:x for x in json.load(open('/tmp/nissan-research/retained-before-cars-v1.json'))}
for c in cf['versions']:
 assert all(retained[c['id']][k]==v for k,v in c['beforeIdentity'].items())
 assert len(c['core'])==17
sourceIds={x['sourceId'] for x in json.load(open(root/'source-index.json'))}
assert all(set(f['sourceIds'])<=sourceIds for c in cf['versions'] for f in c['core'].values())
gradeCounts={}
for c in cf['versions']:
 for f in c['core'].values():gradeCounts[f['grade']]=gradeCounts.get(f['grade'],0)+1
assert gradeCounts=={'Confirmed':65,'Check':3}
out={
 'status':'REVIEWED WITH REQUIRED VERSIONED AMENDMENTS; not typed candidate or runtime acceptance',
 'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'manifest':{'path':str(mp),'sha256':hashlib.sha256(mp.read_bytes()).hexdigest(),'pinCount':len(checks),'allPinsPass':True},
 'retainedBeforeProof':'/tmp/nissan-review/retained-before-check-v1.json',
 'sourceRows':len(sourceIds),'coreObservations':68,'sourceGradeSplitSupported':gradeCounts,
 'requiredAmendments':[
  'All four range fields must use WLTP combined cycle / WLTP combined, as the cited August specification explicitly labels combined cycle. Remove maximum-only comparison grouping; preserve numbers and Confirmed grades.',
  'Roadside towing must mean nearest Authorised Servicing Dealer, or preferred Authorised Servicing Dealer only when breakdown is within 50 km of that dealer. Replace overly broad preferred destination wording.',
  'Keep image/text-extraction and other research process notes in provenance; do not copy them into buyer-facing warranty conditions.'
 ],
 'acceptedSemantics':[
  'Exactly four retained MY25 ARIYA identities, complete current maker grade list and no new additions. Original technical epoch and history retained.',
  'Current maker MSRP is 55840/59840/63840/71840 AUD before on-road costs. Current secondary table agrees; its 54840 prose anomaly is not an equal maker-price conflict.',
  'Supplemental 42990/44990/51990/60990 driveaway-from amounts remain Reported from Sutherland Nissan/CarExpert. Maker terms supply scope, not retrieved amounts: private and ABN buyers, new/demo, purchases 1-31 October 2026 and delivery by 30 November, premium paint extra, participating dealers/stock/exclusions apply.',
  'Exact maker 385/385/504/487 km WLTP combined figures remain Confirmed; generic laboratory or delivered-build notes do not lower grades.',
  'Battery 63/63/87/87 kWh is explicitly usable. Width 1850 mm excludes mirrors, 2172 mm includes them, length 4595 and unladen height 1660 are shared body facts.',
  'DC maximum 130 kW is vehicle acceptance, separately published from the station rating. Exact 10-80% times 35/35/40/40 minutes at 130 kW are Confirmed; webpage 45 minutes to 80% has no initial SOC and is separate, not a proven same-window conflict.',
  'FWD AC 7.4 kW standard PDF versus live 22 kW Launch Offer cards warrants configuration Check with alternatives. RACV reports around 400 launch vehicles; it does not establish current remaining allocation or VIN fitment. Evolve 22 kW standard is Confirmed.',
  'Boots 466/466/466/408 L are Confirmed seats-up to-roof declarations but remain unranked with explicit unknown VDA/SAE protocol. Folded 1350/1280 L remains separate.',
  'Braked tow limits 750/750/750/1500 kg are Confirmed with genuine towbar, towball, laden-vehicle and accessories restrictions; generic load conditions do not automatically lower source grade.',
  'Five-year/unlimited base warranty begins first registration or put-in-service, whichever earlier. Ten-year/300000 km service-activated extension remains separately conditional. Capacity cover is eight years/160000 km below nine of twelve gauge bars and remedy restores nine or above, not an invented percentage or separate all-defect term.',
  'One-year roadside base plus service-activated extension remains distinct. All five PDF pages visually reviewed; LEAF-specific rescue wording does not create an ARIYA mobile-charging promise.',
  'Three FWD kerb/GVM values have genuine PDF/web differences of 9 kg, with no cause or VIN supersession inferred. Three-ISOFIX webpage differs from two outboard ISOFIX plus three top tethers in PDF; retain if touched.',
  'Third-generation LEAF Australian introduction remains indefinitely paused under March and October executive reports, not permanently cancelled. Prior-generation LEAF discontinued/residual supply is separate; generic guide-year enquiry widgets and used listings do not establish qualifying new official stock.',
  'Overseas facelift ARIYA, Micra/Juke/Sakura and exploratory Chinese models have no established current Australian grade admission. No national residual-stock exhaustion or factory-order acceptance claimed.'
 ],
 'independentPublicReads':[
  'https://www.nissan.com.au/vehicles/browse-range.html',
  'https://www.nissan.com.au/vehicles/build-a-vehicle.html',
  'https://www.nissan.com.au/vehicles/browse-range/ariya/specs-and-pricing.html',
  'https://www.nissan.com.au/content/dam/Nissan/AU/Files/Brochures/Models/Specsheet/ARIYA%20Spec%20Sheet_r2.pdf',
  'https://www.nissan.com.au/about-nissan/news-and-events/news/2025/july/2025-nissan-ariya-pricing-and-specifications-confirmed-ahead-of-striking-electric-suvs-australian-launch.html',
  'https://www.nissan.com.au/owners-hub/nissan-warranty/new-vehicle-warranty-terms.html',
  'https://www.nissan.com.au/offers.html',
  'https://www.carexpert.com.au/car-news/nissan-ariya-deals-ev-prices-slashed-by-up-to-dollar15000',
  'https://www.racv.com.au/royalauto/car-reviews/nissan/2025-nissan-ariya-review.html',
  'https://www.whichcar.com.au/news/2026-nissan-ariya-update-uk-australian-potential',
  'https://www.carexpert.com.au/car-news/2026-nissan-leaf-new-generation-ev-delayed-indefinitely',
  'https://autotalk.com.au/industry-news/nissan-wants-its-chinese-evs-for-australia-new-leaf-stays-on-hold',
  'https://www.carexpert.com.au/nissan/leaf',
  'https://www.carsguide.com.au/buy-a-car/nissan/leaf/all-variants/ze1-my23-series/nsw/sydney-location',
  'https://www.carsguide.com.au/car-news/nissan-has-several-electric-cars-overseas-including-the-2027-nissan-leaf-and-nissan-juke'
 ],
 'scopeLimits':['Read-only source/admission review plus standalone review receipts; no live repository edits','No production loader, hydration, compiler, tests, build, browser or server run','No global C1-C6 or release acceptance; actual ranking/citation/detail/portable behavior not yet checked'],
 'pinChecks':checks
}
p=pathlib.Path('/tmp/nissan-review/source-review-v1-findings-v1.json');p.open('x').write(json.dumps(out,indent=2)+'\n');print(p);print(out['status']);print('Manifest pins',len(checks),'all exact; core grades',gradeCounts)
