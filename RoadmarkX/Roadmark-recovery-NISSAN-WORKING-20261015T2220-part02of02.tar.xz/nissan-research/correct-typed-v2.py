import json,pathlib,hashlib,copy
O=pathlib.Path('/tmp/nissan-packet/typed-preparation-v1');N=O.parent/'typed-preparation-v2';N.mkdir(exist_ok=False)
def read(p):return json.loads(pathlib.Path(p).read_text())
def pin(p):p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(n,x):(N/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
m=read(O/'manifest.json')
for p in m['pins']:assert pin(p['path'])==p,p['path']
a=read(O/'nissan-2026-10-15-candidate.json');before=copy.deepcopy(a);changes=[]
for s in a['sources']:
 if s['id'].endswith(('ariya_spec_linked','ariya_spec_pdf')):
  old=s['captureMethod'];s['captureMethod']='Published official six-page PDF; core technical tables on pages 1 and 2 visually checked';changes.append({'sourceId':s['id'],'field':'captureMethod','before':old,'after':s['captureMethod']})
for e in a['facts']:
 f=e['after'];old=copy.deepcopy(f)
 if f['key'] in ['advertised_driveaway_aud','promotional_driveaway_aud']:
  f['priceEvidence']['publisher']='CarExpert';f['priceEvidence']['sourcePointer']='https://www.carexpert.com.au/car-news/nissan-ariya-deals-ev-prices-slashed-by-up-to-dollar15000';f['priceEvidence']['basisTag']='Reported by CarExpert · driveaway';f['priceEvidence']['sourceKey']='reported_october_driveaway_aud';f['basis']='CarExpert-reported from driveaway campaign, corroborated by Sutherland Nissan';f['qualifications'][0]='CarExpert reports the exact named-grade from driveaway amounts, corroborated by Sutherland Nissan. Current maker offer text supplies the campaign conditions; its rendered price fields do not provide usable amounts.';f['gradeReview']['reason']='Exact named-grade numerical offer is a CarExpert report corroborated by dealer republication; current maker terms establish campaign conditions, not a directly captured numeric maker price.'
 if f['key'] in ['ac_kw','ac_max_kw_standard']:
  f['qualifications']=[q for q in f['qualifications'] if not q.startswith('The dated RACV')]
 f['qualifications']=[q.replace('do not convert gauge bars to an invented percentage threshold','the published trigger is gauge bars, not a stated percentage') for q in f['qualifications']]
 if f!=old:changes.append({'variantId':e['variantId'],'key':f['key'],'beforeAfterFacts':{'before':old,'after':f}})
# Only amended AC core objects require a reviewed dependency rebind; summary dependencies do not use them.
lookup={(e['variantId'],e['after']['key']):e['after'] for e in a['facts']}
for t in a['brandTerms']:
 for v in t['applicableVariantIds']:lookup[(v,t['key'])]=t['fact']
c=read(O/'core-review.json')
for r in c['versions']:
 for k in r['facts']:r['facts'][k]=copy.deepcopy(lookup[(r['variantId'],k)])
for x,y in zip(before['facts'],a['facts']):
 assert x['before']==y['before'] and x['variantId']==y['variantId'];assert x['after']['value']==y['after']['value'] and x['after']['buyerGrade']==y['after']['buyerGrade'] and x['after']['comparisonBasis']==y['after']['comparisonBasis']
for key in ['versionGuards','versionUpdates','availability','summaries','brandTerms','features','configurationUpdates','models','variants']:assert a[key]==before[key]
put('nissan-2026-10-15-candidate.json',a);put('core-review.json',c)
for n in ['nissan-market-reconciliation.json','census-and-dispositions.json','source-support-map.json','source-amendment.json','static-audit.json']:(N/n).write_bytes((O/n).read_bytes())
receipt=pathlib.Path('/tmp/nissan-review/typed-preparation-v1-findings-v1.json')
put('v1-to-v2-provenance.json',{'priorManifest':pin(O/'manifest.json'),'reviewReceipt':pin(receipt) if receipt.exists() else 'Independent reviewer collaboration findings received 2026-10-15; formal receipt not yet available at preparation','changes':changes,'unchanged':'All values, grades, comparison bases, beforeguards, shared terms, availability, identities, summary objects and reconciliation are byte-equivalent data. No actual helper or consumer execution.'})
(N/'README.md').write_text('Nissan typed preparation v2\n\nFour narrow independent-review corrections only: ARIYA six-page PDF capture description; CarExpert primary rung-5 offer pointer/publisher with dealer corroboration; buyer-readable capacity-alias gauge-bar wording; secondary RACV launch-batch quantity retained only in source context rather than maker-graded buyer fact qualifications.\n\nAll 68 core values/grades (65 Confirmed, three Check), 176 beforeguarded specific updates, 12 shared-term applications, summaries, identities, availability and reconciliation remain unchanged. V1 is preserved. No actual helper/consumer/compiler/full-catalogue or live execution. Separate independent acceptance and runtime grant required.\n')
paths={p['path'] for p in m['pins']}|{str(O/'manifest.json'),'/tmp/nissan-research/correct-typed-v2.py','/tmp/nissan-review/source-review-v1-findings-v1.json','/tmp/nissan-review/source-review-v3-findings-v1.json'}
if receipt.exists():paths.add(str(receipt))
paths.update(str(p) for p in N.iterdir() if p.is_file());put('manifest.json',{'schemaVersion':1,'status':'frozen_prepared_not_executed','asOf':'2026-10-15','candidate':pin(N/'nissan-2026-10-15-candidate.json'),'reconciliation':pin(N/'nissan-market-reconciliation.json'),'baseline':m['baseline'],'beforeProof':m['beforeProof'],'sources':m['sources'],'pins':[pin(p) for p in sorted(paths)],'currentFullProjectTypeScript':'UNPASSED; no retry','nextGate':'Independent typed review, bounded selected actual-consumer readiness and separate explicit root runtime grant'})
for p in m['pins']:assert pin(p['path'])==p
print(json.dumps({'manifest':pin(N/'manifest.json'),'candidate':pin(N/'nissan-2026-10-15-candidate.json'),'changes':len(changes),'pins':len(paths)},indent=2))
