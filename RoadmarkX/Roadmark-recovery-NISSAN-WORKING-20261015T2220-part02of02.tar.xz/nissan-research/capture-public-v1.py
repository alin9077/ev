import urllib.request,urllib.parse,json,pathlib,sys,subprocess,hashlib
from html.parser import HTMLParser
BASE=pathlib.Path('/tmp/nissan-research/sources-v1')
class SafeText(HTMLParser):
 def __init__(self):super().__init__();self.skip=0;self.text=[];self.links=[];self.a=None
 def handle_starttag(self,t,a):
  if t in ('script','style','noscript','iframe','svg'):self.skip+=1
  if not self.skip and t=='a':self.a={'url':dict(a).get('href',''),'text':''}
 def handle_endtag(self,t):
  if t in ('script','style','noscript','iframe','svg'):self.skip=max(0,self.skip-1)
  if not self.skip and t=='a' and self.a:self.links.append(self.a);self.a=None
 def handle_data(self,d):
  if not self.skip and d.strip():
   self.text.append(d.strip())
   if self.a:self.a['text']+=d.strip()+' '
def capture(slug,url):
 assert not (BASE/(slug+'-provenance.json')).exists(),'Immutable capture exists'
 p={'url':url,'checkedAt':'2026-10-15','method':'Unauthenticated public GET. No credential or authorization header used. Only visible text and allowlisted ordinary links persisted; scripts, runtime configuration, attributes, cookies and headers discarded in memory. Published PDF is retained unchanged.'}
 try:
  with urllib.request.urlopen(url,timeout=25) as r:data=r.read();p['responseStatus']=r.status;p['finalUrl']=r.url
  if data.startswith(b'%PDF'):
   dest=BASE/(slug+'.pdf');dest.write_bytes(data);subprocess.run(['pdftotext','-layout',str(dest),str(BASE/(slug+'.txt'))],check=True);p['kind']='published_pdf';p['pdfSha256']=hashlib.sha256(data).hexdigest()
  else:
   s=SafeText();s.feed(data.decode('utf8',errors='replace'));(BASE/(slug+'.txt')).write_text('\n'.join(s.text)+'\n')
   links=[]
   for a in s.links:
    u=urllib.parse.urljoin(url,a['url']);parts=urllib.parse.urlsplit(u)
    if parts.scheme=='https' and parts.netloc in ('www.nissan.com.au','www.carexpert.com.au','www.whichcar.com.au','autotalk.com.au','www.goauto.com.au','www.carsguide.com.au','www.nissan-global.com','australia.nissannews.com') and not parts.query and a['text'].strip():links.append({'text':a['text'].strip(),'url':u})
   (BASE/(slug+'-links.json')).write_text(json.dumps(links,indent=2)+'\n');p['kind']='sanitized_visible_text'
  print(slug,'OK',flush=True)
 except Exception as e:
  p['failureType']=type(e).__name__;p['failureMessage']=str(e);print(slug,p['failureType'],str(e),flush=True)
 with (BASE/(slug+'-provenance.json')).open('x') as f:json.dump(p,f,indent=2);f.write('\n')
if __name__=='__main__':capture(sys.argv[1],sys.argv[2])
