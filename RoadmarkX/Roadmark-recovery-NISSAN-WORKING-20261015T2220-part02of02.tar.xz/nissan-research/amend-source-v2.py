import json,pathlib,hashlib,copy
O=pathlib.Path('/tmp/nissan-packet/source-review-v1');N=O.parent/'source-review-v2';N.mkdir(exist_ok=False)
def pin(p):p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(n,x):(N/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
m=json.loads((O/'manifest.json').read_text())
for p in m['pins']:assert pin(p['path'])==p,p['path']
for p in O.iterdir():
 if p.name not in ('manifest.json','candidate-facts.json','README.md'):(N/p.name).write_bytes(p.read_bytes())
a=json.loads((O/'candidate-facts.json').read_text());changes=[]
for r in a['versions']:
 f=r['core']['range'];before=copy.deepcopy(f);f['basis']='WLTP combined cycle for exact named grade';f['comparisonBasis']='WLTP combined';changes.append({'variantId':r['id'],'field':'range','before':before,'after':f,'reason':'Independent reviewer verified the actual cited table explicitly labels WLTP combined cycle; this is not maximum-only grouping.'})
 f=r['core']['boot'];old=f['comparisonBasis'];f['comparisonBasis']='Cargo measurement method not stated; seats upright to roof';changes.append({'variantId':r['id'],'field':'boot comparisonBasis','before':old,'after':f['comparisonBasis'],'reason':'Explicit unknown-method label compatible with actual comparison/ranking guard recognition; value and confidence unchanged.'})
 f=r['core']['ac']
 if 'racv-launch-review' in f['sourceIds']:
  f['contextSourceIds']=['racv-launch-review'];f['sourceIds'].remove('racv-launch-review');changes.append({'variantId':r['id'],'field':'AC source roles','reason':'Exact current maker base-versus-launch-configuration sources earn Check. Dated RACV launch quantity is secondary context only, not a maker-grade evidence citation.'})
put('candidate-facts.json',a);put('source-amendment.json',{'priorManifest':pin(O/'manifest.json'),'changes':changes,'valuesAndGradesUnchanged':True,'newFetches':0,'reviewedV1Unchanged':True})
(N/'README.md').write_text('Nissan source review v2\n\nSource v1 is preserved byte-for-byte. Corrects four exact range bases to WLTP combined, retaining Confirmed. Declared cargo uses an explicit measurement-method-not-stated basis for comparison guards; values/grades unchanged. RACV launch-batch quantity is labelled contextual secondary evidence, while FWD AC Check is earned by conflicting/applicability-limited exact maker sources. No new fetch, live edit or runtime execution.\n')
paths={p['path'] for p in m['pins']}|{str(O/'manifest.json'),'/tmp/nissan-research/amend-source-v2.py'}|{str(p) for p in N.iterdir() if p.is_file()}
put('manifest.json',{'status':'frozen-source-review-v2','checkedAt':'2026-10-15','prior':pin(O/'manifest.json'),'pins':[pin(p) for p in sorted(paths)]})
print(json.dumps(pin(N/'manifest.json')))
