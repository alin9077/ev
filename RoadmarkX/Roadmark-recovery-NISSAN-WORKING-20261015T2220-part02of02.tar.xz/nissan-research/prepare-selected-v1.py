from pathlib import Path
import json,hashlib,copy
O=Path('/tmp/nissan-packet/selected-preflight-v1');OLD=Path('/tmp/renault-packet/selected-preflight-v5');M=Path('/tmp/nissan-packet/typed-preparation-v2')
def pin(p):p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(n,x):
 with (O/n).open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False);f.write('\n')
s=(OLD/'check.mjs').read_text()
def change(a,b):
 global s
 assert a in s,a[:140];s=s.replace(a,b)
change('four retained Renault Tier 1 rows','four retained Nissan Tier 1 rows');change(str(OLD),str(O));change('/tmp/renault-research/','/tmp/nissan-research/');change("receipt.stage,'candidate29'","receipt.stage,'candidate30'")
change("receipt.checks.find(x=>x.found.id===car.id)?.found","receipt.checks.find(x=>x.expected.id===car.id)?.expected")
change("brandUpdatePackets.length,29","brandUpdatePackets.length,30");change("brandUpdatePackets.at(-1).id,'m1-cupra-2026-10-15'","brandUpdatePackets.at(-1).id,'m1-renault-2026-10-15'");change("prior.brand,'Renault'","prior.brand,'Nissan'")
change('packet.facts.length,92','packet.facts.length,176');change('summary dependency changed:.*\\/range_km$','summary dependency changed:.*\\/dc_charge_time_min$')
change("let earnedCells=0,roadsideRefreshes=0;","let earnedCells=0,roadsideRefreshes=0,driveawayRefreshes=0;")
change("fact.value,'5 years'","fact.value,'1 year'");change("feature.value,'5 years'","feature.value,'1 year'");change("claim.value,'5 years'","claim.value,'1 year'")
old="  }else assert.deepEqual(feature,beforePacks[car.id].features.find(f=>f.criterion===feature.criterion),'Unrelated retained feature changed: '+car.id+'/'+feature.criterion);"
new="""  }else if(feature.criterion==='driveaway_price'){
   const fact=car.facts.promotional_driveaway_aud;
   assert.equal(feature.value,String(fact.value));assert.equal(feature.buyerGrade,'reported');assert.equal(feature.status,'conditional');assert.equal(feature.verification_state,'reviewed_canonical_driveaway_price');assert.deepEqual(feature.source_ids,fact.sourceIds);assert.equal(feature.validUntil,'2026-10-31');
   for(const condition of fact.qualifications)assert(feature.conditions.includes(condition));driveawayRefreshes++;
  }else assert.deepEqual(feature,beforePacks[car.id].features.find(f=>f.criterion===feature.criterion),'Unrelated retained feature changed: '+car.id+'/'+feature.criterion);"""
change(old,new);change("assert.equal(car.year,car.model==='Megane E-Tech'?null:2026);","assert.equal(car.year,2025);");change("assert.equal(car.availabilityEvidence.orderStatus,car.model==='Megane E-Tech'?'listed_unconfirmed':'accepting_orders_advertised');","assert.equal(car.availabilityEvidence.orderStatus,'listed_unconfirmed');assert.equal(car.availabilityEvidence.stockStatus,'unverified');")
a=s.index(' const charge=car.facts.dc_charge_time_min;');b=s.index('\n}\nassert.equal(earnedCells,104)',a)
s=s[:a]+""" const charge=car.facts.dc_charge_time_min;assert.equal(charge.buyerGrade,'confirmed');assert.equal(charge.comparisonBasis,'10–80% at 130 kW DC station');assert.equal(charge.value,car.drive==='AWD'||car.trim.startsWith('Advance+')?40:35);
 assert.equal(car.facts.dc_to_80_start_unspecified_min.comparisonBasis,'Charging window unknown; start SOC not stated');
 assert.equal(car.facts.battery_kwh.comparisonBasis,'Usable');assert.equal(car.facts.battery_kwh.issues.length,0);assert.equal(car.facts.boot_l.comparisonBasis,'Cargo measurement method not stated; seats upright to roof');
 assert.equal(car.facts.width_mm.comparisonBasis,'Excluding mirrors');assert.equal(car.facts.width_mm_including_mirrors.comparisonBasis,'Including mirrors');
 const price=car.facts.price_aud,offer=car.facts.promotional_driveaway_aud;
 assert.equal(price.buyerGrade,'confirmed');assert.equal(price.comparisonBasis,'Before on-road costs');assert.equal(price.priceEvidence.rung,1);assert.equal(price.priceEvidence.rankingEligible,true);
 assert.equal(offer.buyerGrade,'reported');assert.equal(offer.comparisonBasis,'Driveaway');assert.equal(offer.priceEvidence.rung,5);assert.equal(offer.priceEvidence.publisher,'CarExpert');assert.equal(offer.priceEvidence.rankingEligible,false);assert.equal(offer.validUntil,'2026-10-31');assert(!Object.hasOwn(price,'validUntil'));
 if(car.drive==='FWD'){
  for(const key of ['ac_kw','ac_max_kw_standard','kerb_kg','kerb_weight_kg','gvm_kg']){const fact=car.facts[key],claim=factClaim(pack,fact,packet.reviewedAt);assert.equal(fact.buyerGrade,'check');assert(fact.issues.length);assert(claim.qualifications.some(q=>q.includes(key.startsWith('ac_')?'22 kW':'current exact-grade web table')));}
 }else for(const key of ['ac_kw','ac_max_kw_standard','kerb_kg','kerb_weight_kg','gvm_kg'])assert.equal(car.facts[key].buyerGrade,'confirmed');
"""+s[b:]
change('earnedCells,104','earnedCells,188');change("assert.deepEqual(gradeCounts,{reported:2,confirmed:61,not_published:4,check:1});","assert.equal(driveawayRefreshes,4);assert.deepEqual(gradeCounts,{confirmed:65,check:3});")
change("assert.notEqual(o.criterion,'roadside_assistance','Fresh canonical term projection must not inherit optional undefined fields');","assert(!['roadside_assistance','driveaway_price'].includes(o.criterion),'Fresh canonical term/offer projection must not inherit optional undefined fields');")
a=s.index('for(let i=0;i<after.length;i++)for(let j=i;j<after.length;j++){');b=s.index('const reconciliation=readJson(expected.reconciliation.path);',a)
s=s[:a]+"""for(let i=0;i<after.length;i++)for(let j=i;j<after.length;j++){
 const a=after[i],b=after[j],hasFwd=a.drive==='FWD'||b.drive==='FWD';
 for(const key of ['boot_l','max_total_cargo_l','dc_to_80_start_unspecified_min'])pairCheck(a,b,key,'different_basis');
 for(const key of ['ac_kw','kerb_kg','gvm_kg'])pairCheck(a,b,key,hasFwd?'conditional':'comparable');
 for(const key of ['battery_kwh','width_mm','height_mm','dc_charge_time_min','length_mm','range_km','seats','dc_peak_kw','power_kw','zero_to_100_s','towing_braked_kg','price_aud'])pairCheck(a,b,key,'comparable');
 pairCheck(a,b,'promotional_driveaway_aud','conditional');
}
assert.equal(comparisonProof.length,190);
const crossBasisProof=[];
function crossCheck(name,a,b,state,fixture=false){const result=compareFacts(a,b);assert.equal(result.state,state,name);assert(!Object.hasOwn(result,'delta'));crossBasisProof.push({name,leftBasis:a.comparisonBasis,rightBasis:b.comparisonBasis,result,syntheticBasisGuardProbe:fixture});}
for(const car of after){
 crossCheck(car.id+' mirror states',car.facts.width_mm,car.facts.width_mm_including_mirrors,'different_basis');
 crossCheck(car.id+' unknown charge start',car.facts.dc_charge_time_min,car.facts.dc_to_80_start_unspecified_min,'different_basis');
 crossCheck(car.id+' upright versus folded unknown cargo method',car.facts.boot_l,car.facts.max_total_cargo_l,'different_basis');
 crossCheck(car.id+' MSRP versus conditional reported offer',car.facts.price_aud,car.facts.promotional_driveaway_aud,'conditional');
 const unknown={...car.facts.battery_kwh,comparisonBasis:'Battery capacity basis not established'},gross={...car.facts.battery_kwh,comparisonBasis:'Gross'};
 crossCheck(car.id+' usable versus unknown-capacity guard fixture',car.facts.battery_kwh,unknown,'different_basis',true);
 crossCheck(car.id+' usable versus gross-capacity guard fixture',car.facts.battery_kwh,gross,'different_basis',true);
 assert(exclusionReason(car,car.facts.boot_l,data.sources,policy));assert.equal(exclusionReason(car,car.facts.battery_kwh,data.sources,policy),null);
}
assert.equal(crossBasisProof.length,24);assert.deepEqual(new Set(rankCounts.length_mm.ranked),selected);
"""+s[b:]
change("const isRenault=s=>s==='Renault';","const isNissan=s=>s==='Nissan';");change('isRenault','isNissan')
a=s.index("const inherited=readJson('/tmp/nissan-research/inherited-inventory-extract-v1.json')");b=s.index('for(const review of reconciliation.currentVersionReviews)',a)
s=s[:a]+"""const inherited=readJson('/tmp/nissan-research/inherited-inventory-extract-v1.json').rows;
assert.deepEqual(inventory.records,inherited.filter(x=>x.path.startsWith('/records/')).map(x=>x.row));assert.deepEqual(inventory.unverifiedLeads,[]);
assert.equal(inventory.records.length,1);assert.equal(inventory.unverifiedLeads.length,0);
const {inventoryRecordId,buildMarketReconciliation}=require('./scripts/reporting/m1-reconciliation.ts');
assert.deepEqual(inventory.records.map(inventoryRecordId),['nissan-ariya']);
assert.deepEqual(reconciliation.inventoryResolutions.map(r=>[r.kind,r.inventoryId,r.outcome]),[['record','nissan-ariya','included']]);
"""+s[b:]
change('c1.reviewedModels,2','c1.reviewedModels,1');change("c1.settledInventory,['record:renault-scenic-e-tech']","c1.settledInventory,['record:nissan-ariya']")
change("assert.deepEqual(c1.issues.map(i=>i.code),['independent_lists','inventory_unresolved']);assert.equal(c1.issues[1].reference,'record:renault-megane-e-tech');","assert.deepEqual(c1.issues.map(i=>i.code),['independent_lists']);")
change('progress.currentVersionReviews.length,2','progress.currentVersionReviews.length,1');change('c1.issues.length,2','c1.issues.length,1');change('nonRenaultTargets','nonNissanTargets');change('comparisonProof,negativeProof','comparisonProof,crossBasisProof,negativeProof');change('roadsideRefreshes,reportProof','roadsideRefreshes,driveawayRefreshes,reportProof')
assert 'Megane' not in s and 'Scenic' not in s and 'renault' not in s.replace("m1-renault-2026-10-15",'')
(O/'check.mjs').write_text(s);(O/'run.py').write_text((OLD/'run.py').read_text().replace('run_single_selected_renault_preflight','run_single_selected_nissan_preflight'))
packet=json.loads((M/'nissan-2026-10-15-candidate.json').read_text());baseline=json.loads(Path('/tmp/nissan-research/retained-before-cars-v1.json').read_text());ids=[c['id'] for c in baseline]
core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','length_mm','width_mm','height_mm','towing_braked_kg','zero_to_100_s','power_kw','drive','warranty','battery_warranty'];facts={(e['variantId'],e['after']['key']):e['after'] for e in packet['facts']};policy=[];supplemental=[]
for i,vid in enumerate(ids):
 for k in core:
  if k in ['drive','warranty','battery_warranty']:continue
  f=facts[vid,k];eligible=k!='boot_l' and not(k=='ac_kw' and i<3);policy.append({'variantId':vid,'key':k,'eligible':eligible,'value':f['value'],'buyerGrade':f['buyerGrade'],'comparisonBasis':f['comparisonBasis'],'reason':'Use exact known measurement bases; boot measurement method unknown and FWD AC configuration unresolved are excluded without downgrading clean declared numbers.'})
 for k in ['ac_max_kw_standard','kerb_kg','kerb_weight_kg','gvm_kg','advertised_driveaway_aud','promotional_driveaway_aud']:
  f=facts[vid,k];eligible=i==3 and k not in ['advertised_driveaway_aud','promotional_driveaway_aud'];supplemental.append({'variantId':vid,'key':k,'eligible':eligible,'issues':f['issues'],'reason':'FWD maker applicability conflicts and Reported offers stay unranked; Evolve clean AC/mass fields are known-basis declarations.'})
put('expected-review.json',{'packet':pin(M/'nissan-2026-10-15-candidate.json'),'packetSha256':pin(M/'nissan-2026-10-15-candidate.json')['sha256'],'reconciliation':pin(M/'nissan-market-reconciliation.json'),'coreKeys':core,'currentListIds':ids,'bodyByModelId':{'nissan_ariya_my25':'SUV'},'normalizedRankPolicy':policy,'supplementalRankPolicy':supplemental,'rankingIds':{k:[r['variantId'] for r in policy if r['key']==k and r['eligible']] for k in ['length_mm','range_km','price_aud','dc_charge_time_min','towing_braked_kg','seats','boot_l']},'factUpdates':176,'termCells':12,'coreCells':68,'allFeatureClaims':276,'roadsideCanonicalProjections':4,'driveawayCanonicalProjections':4,'expectedOnSaleDelta':0,'fullCatalogueHydration':False,'pairComparisonCases':190,'crossBasisCases':24,'optionalPropertyCount':'No count assumed; exact same-run producer-owned paths required'})
put('adaptation-provenance.json',{'acceptedPattern':pin(OLD/'check.mjs'),'acceptedPatternReadiness':pin('/tmp/renault-review/selected-preflight-v5-readiness-v1.json'),'acceptedPatternResult':pin(OLD/'result.json'),'typedAcceptance':pin('/tmp/nissan-review/typed-preparation-v2-findings-v1.json'),'scope':'Four Nissan retained cars, accepted Renault30 full-car digests, 188 effective cells and 276 feature claims; no loader, runtime or compiler executed','changes':['Exact Nissan guards/current-list/inventory/grade policy','Roadside 1 year and separate Reported expiring driveaway offer canonical features','190 actual self/pair comparisons plus 24 cross-basis probes; synthetic unknown/gross battery basis probes explicitly labelled and never used as catalogue facts','Seven actual selected rejection/immutability checks with first-summary dependency DC duration','Retain exact source/feature/claim/portable optional-property witness checks']})
print(json.dumps({'harness':pin(O/'check.mjs'),'expected':pin(O/'expected-review.json'),'runtimeExecuted':False},indent=2))
