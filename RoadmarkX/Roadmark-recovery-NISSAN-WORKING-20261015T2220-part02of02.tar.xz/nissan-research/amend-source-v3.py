import json,pathlib,hashlib
O=pathlib.Path('/tmp/nissan-packet/source-review-v2');N=O.parent/'source-review-v3';N.mkdir(exist_ok=False)
def pin(p):p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(n,x):(N/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
m=json.loads((O/'manifest.json').read_text())
for p in m['pins']:assert pin(p['path'])==p,p['path']
for p in O.iterdir():
 if p.name not in ('manifest.json','brand-terms.json','README.md','source-amendment.json'):(N/p.name).write_bytes(p.read_bytes())
t=json.loads((O/'brand-terms.json').read_text());q=t['roadside']['conditions'];old=q[3];q[3]='Towing to nearest Authorised Servicing Dealer, or preferred Authorised Servicing Dealer only when the breakdown is within 50 km of that repairer; extra towing, heavy haul, trailer and excess benefit costs may be owner liability';process=q.pop();t['roadside']['captureProvenance']=process
put('brand-terms.json',t);put('source-amendment.json',{'priorManifest':pin(O/'manifest.json'),'changes':[{'field':'roadside towing boundary','before':old,'after':q[3],'reason':'Independent visual review of PDF page 2; preferred destination must remain an Authorised Servicing Dealer.'},{'field':'roadside capture process','reason':'Moved image-based extraction/visual-read process note out of buyer conditions into capture provenance.'}],'valuesAndGradesUnchanged':True,'newFetches':0})
(N/'README.md').write_text('Nissan source review v3\n\nPreserves v1/v2 immutable. V2 corrected exact WLTP combined grouping, explicit unknown cargo-method comparison basis, and secondary AC context roles. V3 narrows preferred towing destination to an Authorised Servicing Dealer within the stated 50 km boundary, and separates capture-process provenance from buyer terms. Values/grades unchanged: 68 core, 65 Confirmed and three AC Check. No live edits or runtime.\n')
paths={p['path'] for p in m['pins']}|{str(O/'manifest.json'),'/tmp/nissan-research/amend-source-v3.py'}|{str(p) for p in N.iterdir() if p.is_file()}
put('manifest.json',{'status':'frozen-source-review-v3','checkedAt':'2026-10-15','prior':pin(O/'manifest.json'),'pins':[pin(p) for p in sorted(paths)]})
print(json.dumps(pin(N/'manifest.json')))
