from pathlib import Path
import json,hashlib,re,sys,ast,shutil
O=Path('/tmp/nissan-packet/selected-preflight-v3');M=Path('/tmp/nissan-packet/typed-preparation-v2');R=Path('/workspace/scratch/586427eef9f2/roadmark-104')
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def put(n,x):
 with (O/n).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
for p in O.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
m=json.loads((M/'manifest.json').read_text());assert pin(M/'manifest.json')['sha256']=='9e5a3e9c71685a235c00483c86c8b3fa79c3bfdf60d1e3c1c297b120d8f99a7a'
files=set()
for p in m['pins']:assert pin(p['path'])==p,p['path'];files.add(Path(p['path']))
files.add(M/'manifest.json');files.add(Path('/tmp/nissan-review/typed-preparation-v2-findings-v1.json'));files.add(Path('/tmp/nissan-research/prepare-selected-v1.py'));files.update(p for p in Path('/tmp/nissan-packet/selected-preflight-v2').iterdir() if p.is_file());files.update(p for p in O.iterdir() if p.is_file());files.update(p for p in Path('/tmp/nissan-packet/selected-preflight-v1').iterdir() if p.is_file())
files.update(Path(p) for p in ['/tmp/xpeng-staging-plan/baseline-io.mjs','/tmp/mercedes-staging-plan/consumer-preparation/v5/feature-json-parity.mjs','/tmp/renault-packet/full-stage-v1/output/car-digest-comparison.json','/tmp/nissan-research/inherited-inventory-extract-v1.json','/tmp/renault-packet/selected-preflight-v5/check.mjs','/tmp/renault-packet/selected-preflight-v5/result.json','/tmp/renault-review/selected-preflight-v5-readiness-v1.json'])
files.update(R/p for p in ['src/lib/evidence-consumers.ts','src/lib/evidence-regrading.ts','src/lib/launch-evidence.ts','src/lib/portable-packs.ts','src/lib/citable.ts','src/lib/compare.ts','src/lib/discovery.ts','src/lib/market-inventory-data.ts','scripts/reporting/reports.ts','scripts/reporting/m1-reconciliation.ts','tests/helpers/compiled-source.ts','src/lib/brand-update-registry.ts','tsconfig.json','data/m1-evidence-regrading-2026-10-13.json','package.json','pnpm-lock.yaml','data/m1-brand-updates/registry.json'])
registry=json.loads((R/'data/m1-brand-updates/registry.json').read_text());assert len(registry['packets'])==30 and registry['packets'][-1]=='renault-2026-10-15.json'
for name in registry['packets']:files.add(R/'data/m1-brand-updates'/name)
anchorsPath=Path('/tmp/mercedes-staging-plan/consumer-preparation/v5/manifests/report-v5.json');storagePath=Path('/tmp/mercedes-staging-plan/staging-preparation/staging-artifacts/canonical-v1/staged-storage-index.json');files.update([anchorsPath,storagePath]);anchors=json.loads(anchorsPath.read_text())['anchors'];storage=json.loads(storagePath.read_text());assert len(storage['research'])==14
storagePins=[]
for k,ref in storage['research'].items():
 root=Path(anchors[ref['anchor']]);p=root/ref['file'];assert p.resolve()==p and p.is_file() and p.is_relative_to(root);actual=pin(p);assert actual['bytes']==ref['bytes'] and actual['sha256']==ref['sha256'];files.add(p);storagePins.append({'field':k,'rows':ref['rows'],**actual})
queue=[p for p in files if p.suffix in ['.ts','.tsx','.mts','.mjs'] and (p.is_relative_to(R) or p.parent==O)];seen=set();edges=[];bare=set()
while queue:
 p=queue.pop()
 if p in seen:continue
 seen.add(p)
 for spec in re.findall(r'''(?:from\s*|import\s*\(?\s*|require\(\s*)["']([^"']+)["']''',p.read_text()):
  if spec.startswith('node:'):continue
  if spec.startswith('@/'):root=R/'src'/spec[2:]
  elif spec.startswith(('./src/','./tests/','./scripts/')) and p.parent==O:root=R/spec
  elif spec.startswith('.'):root=(p.parent/spec).resolve()
  elif spec.startswith('/'):root=Path(spec)
  else:bare.add(spec);continue
  choices=[root,Path(str(root)+'.ts'),Path(str(root)+'.tsx'),Path(str(root)+'.json'),root/'index.ts'];hit=next((x for x in choices if x.is_file()),None)
  assert hit is not None,(str(p),spec)
  files.add(hit);edges.append({'from':str(p),'specifier':spec,'to':str(hit)})
  if hit.suffix in ['.ts','.tsx','.mts','.mjs']:queue.append(hit)
# Pin installed runtime package code without importing it or resolving via executable code.
# tsx runtime loads esbuild, get-tsconfig and resolve-pkg-maps; optional native platform package is included when installed.
packageRoots=set();todo=[R/'node_modules'/x for x in ['tsx','typescript','esbuild']];packageEdges=[]
for spec in bare:
 name='/'.join(spec.split('/')[:2]) if spec.startswith('@') else spec.split('/')[0]
 p=R/'node_modules'/name
 if p.exists():todo.append(p)
 elif name not in ['fs','path','vm','assert','module','crypto','readline','url','util','os','stream','buffer','events','child_process','worker_threads']:raise AssertionError(('unresolved package',spec))
while todo:
 logical=todo.pop();root=logical.resolve()
 if root in packageRoots:continue
 packageRoots.add(root);meta=root/'package.json';assert meta.is_file();obj=json.loads(meta.read_text())
 for p in root.rglob('*'):
  if not p.is_file() or 'node_modules' in p.relative_to(root).parts:continue
  if p.suffix in ['.js','.mjs','.cjs','.json','.node'] or p.name in ['esbuild','tsc','tsserver']:files.add(p)
 for name in set(obj.get('dependencies',{}))|set(obj.get('optionalDependencies',{})):
  dep=root.parent/name
  if dep.exists():todo.append(dep);packageEdges.append({'from':str(root),'name':name,'to':str(dep.resolve())})
  elif name in obj.get('dependencies',{}):raise AssertionError(('missing runtime dependency',str(root),name))
for name in ['node','timeout']:
 p=shutil.which(name);assert p and Path(p).is_file();files.add(Path(p).resolve())
files.add(Path(sys.executable).resolve())
put('input-closure.json',{'status':'Static filesystem resolution only; no runtime imports','retainedStorage':storagePins,'selectedRetention':'Only four selected variants, models, feature-context and feature rows retained by future stream; all fourteen streams hashed. No complete catalogue hydration.','relativeImportEdges':edges,'bareSpecifiers':sorted(bare),'runtimePackageRoots':[str(p) for p in sorted(packageRoots)],'runtimePackageEdges':packageEdges,'dynamicInputs':['Registry JSON and every one of its 30 packet files explicitly pinned','compiledSource loads actual evidence-consumers.ts; seed explicitly pinned with its source import graph','Accepted Renault30 full-car digest index and selected before objects pinned','Fourteen research storage locators validated against accepted anchors and descriptor byte/hash pins','Source-pins.json and prepared-command.json are separately integrity-pinned by wrapper','Runtime outputs and root execution grant are not inputs generated by preparation'],'noImportsExecuted':True})
files.add(O/'input-closure.json');put('source-pins.json',[pin(p) for p in sorted(files)])
prepared={'status':'prepared_not_executed','script':pin(O/'check.mjs'),'sourcePins':pin(O/'source-pins.json'),'packet':m['candidate'],'reconciliation':m['reconciliation'],'expectedReview':pin(O/'expected-review.json'),'wrapper':pin(O/'run.py'),'typedReview':pin('/tmp/nissan-review/typed-preparation-v2-findings-v1.json'),'inputClosure':pin(O/'input-closure.json'),'syntaxOnly':pin(O/'syntax-only-check.json'),'command':[str(Path(shutil.which('node')).resolve()),'--max-old-space-size=448','--max-semi-space-size=1','--import','tsx',str(O/'check.mjs'),'--root-execution-granted'],'workdir':str(R),'timeoutSeconds':180,'killGraceSeconds':10,'automaticRetry':False,'rootExecutionGrantRequired':True,'exclusiveHeavySlotRequired':True,'scope':'Exactly four retained Nissan Tier 1 cars bound to accepted Renault30 full-car digests; four identity/availability guards, 176 fact beforeguards, 12 shared term applications, 188 earned cells, 68 core cells, 276 feature claims, four roadside and four expiring Reported offer projections. Actual source/apply/coverage/current-list/ranking/citable/report/portable consumers, 190 self/pair comparisons plus 24 cross-basis checks, seven intended guard rejections and input immutability. Exact optional-property producer witnesses; no broad undefined normalization. No full catalogue, project compiler, tests, live edits, registration, build, server, browser, archive or automatic retry.','currentProjectTypeScript':'UNPASSED; no retry'}
put('prepared-command.json',prepared);put('root-grant-template.json',{'authorized':False,'exclusiveHeavySlotGranted':False,'action':'run_single_selected_nissan_preflight','preparedManifestSha256':pin(O/'prepared-command.json')['sha256'],'command':prepared['command'],'automaticRetry':False,'note':'Template only; independent readiness and separate root exclusive-slot grant required.'})
print(json.dumps({'manifest':pin(O/'prepared-command.json'),'sourcePins':len(files),'researchStorageBytes':sum(p['bytes'] for p in storagePins),'runtimePackages':len(packageRoots),'executed':False},indent=2))
