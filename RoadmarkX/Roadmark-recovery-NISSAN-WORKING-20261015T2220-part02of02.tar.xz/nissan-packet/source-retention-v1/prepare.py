"""Prepare an exact metadata source allowance without recapture or a payload sweep."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, stat

B = Path('/tmp/nissan-packet/source-retention-v1')
R = Path('/tmp/nissan-research')

def read(path):
    return json.loads(Path(path).read_text())

def pin(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

refs = [
    ('/tmp/nissan-packet/source-review-v1/manifest.json', 'pins'),
    ('/tmp/nissan-packet/source-review-v2/manifest.json', 'pins'),
    ('/tmp/nissan-packet/source-review-v3/manifest.json', 'pins'),
    ('/tmp/nissan-packet/typed-preparation-v2/manifest.json', 'pins'),
    ('/tmp/nissan-packet/report-comparison-plan-v2/source-pins.json', None),
]
declared, origins = {}, {}

def add(item, origin):
    if not Path(item['path']).is_relative_to(R):
        return
    if item['path'] in declared:
        assert declared[item['path']] == item, item['path']
    declared[item['path']] = item
    origins.setdefault(item['path'], []).append(origin)

for path, key in refs:
    data = read(path)
    for item in data if key is None else data[key]:
        add(item, path)
review_path = '/tmp/nissan-review/report-comparison-plan-v2-findings-v1.json'
add(read(review_path)['diagnosticFailureRetained'], review_path)
actual, excluded = [], []
for path in sorted(R.rglob('*')):
    if path.is_dir():
        assert not path.is_symlink()
        continue
    metadata = path.lstat()
    assert stat.S_ISREG(metadata.st_mode) and not path.is_symlink(), str(path)
    if '__pycache__' in path.parts or path.suffix == '.pyc':
        excluded.append(dict(path=str(path), bytes=metadata.st_size, mode=metadata.st_mode,
                             mtimeNs=metadata.st_mtime_ns,
                             reason='Reconstructible Python bytecode; original source retained',
                             deletionAuthorized=False))
        continue
    assert str(path) in declared, str(path)
    item = declared[str(path)]
    assert item['bytes'] == metadata.st_size
    actual.append(dict(**item, mode=metadata.st_mode, mtimeNs=metadata.st_mtime_ns,
                       pinOrigins=origins[str(path)], contentHashRecomputedAtThisPreparation=False))
assert len(actual) == 76 and {item['path'] for item in actual} == set(declared)

source_images = []
for stem, pages, pdf_name, provenance_name, text_name, headings in [
    ('ariya-spec-page', [1, 2], 'ariya-spec-linked.pdf', 'ariya-spec-linked-provenance.json',
     'ariya-spec-linked.txt', ['All-new. All-electric. NISSAN ARIYA; drivetrain, performance and charging tables',
                              'Nissan ARIYA specifications; dimensions and weights/capacities tables']),
    ('roadside-page-', [1, 2, 3, 4, 5], 'roadside-terms-pdf.pdf', 'roadside-terms-pdf-provenance.json',
     'roadside-terms-pdf.txt', [None] * 5),
]:
    base = R / 'sources-v1'
    pdf, provenance, extracted_text = base / pdf_name, base / provenance_name, base / text_name
    provenance_data = read(provenance)
    assert provenance_data['pdfSha256'] == declared[str(pdf)]['sha256']
    for page, heading in zip(pages, headings):
        image = base / f'{stem}{page}.png'
        source_images.append(dict(
            file=declared[str(image)], sourcePdf=declared[str(pdf)],
            sourceUrl=provenance_data['url'], resolvedPublicUrl=provenance_data['finalUrl'],
            parentProvenance=declared[str(provenance)], parentExtractedText=declared[str(extracted_text)],
            pdfPageNumber=page, pdfZeroBasedPageIndex=page - 1,
            printedPageNumber=page if stem == 'roadside-page-' else None,
            visibleHeading=heading,
            kind='Existing local public maker PDF page render; not an application, browser or phone screenshot',
            mappingEvidence='Existing page render and parent PDF were read in the independently accepted source review. ARIYA has six PDF pages; its first two technical-table pages were visually checked. Roadside has five pages, all visually read.',
            newRenderingPerformed=False))
review_image = Path('/tmp/nissan-review/source-review-v1/roadside-page-5.png')
review_meta = review_image.lstat()
independent_image = dict(
    file=pin(review_image), mode=review_meta.st_mode, mtimeNs=review_meta.st_mtime_ns,
    sourcePdf=declared[str(R / 'sources-v1/roadside-terms-pdf.pdf')],
    parentProvenance=declared[str(R / 'sources-v1/roadside-terms-pdf-provenance.json')],
    pdfPageNumber=5, pdfZeroBasedPageIndex=4, printedPageNumber=5,
    visibleHeading='Definitions; footer Page 5 of 5',
    kind='Existing independent-review render of public maker PDF; not a product screenshot',
    mappingEvidence='Reviewer reported rendering and reading page 5 during original source review; existing pixels re-inspected for this mapping. Footer explicitly says Page 5 of 5.',
    targetedImageHashComputedAtThisPreparation=True, newRenderingPerformed=False)

result = dict(
    schemaVersion=1, status='frozen_metadata_allowlist_pending_independent_review',
    preparedAt=datetime.now(timezone.utc).isoformat(), sourceRoot=str(R),
    sourcePins=actual, allowlistedResearchFiles=76,
    sourceRole='Exact union of sanitized public captures, extracted facts, retained before-state, preparation scripts and the accepted read-only diagnostic failure. Old or held evidence retains its original role.',
    authoritativeManifests=[pin(path) for path, key in refs] + [pin(review_path)],
    sourceImages=source_images, independentReviewImages=[independent_image],
    publicPdfDocuments=2, retainedPublicPdfFiles=3,
    duplicatePdfExplanation='Linked and direct ARIYA r2 PDF captures have the same accepted hash; roadside is a separate document.',
    rawRuntimeExclusion=dict(
        rawRuntimeHTMLOrConfigurationPersisted=False, rawResponseHeadersOrCookiesPersisted=False,
        credentialOrClientKeyPayloadPersisted=False, locallyPresentExcludedOriginalPaths=[],
        basis='Capture implementation and per-source provenance declare scripts/configuration and headers/cookies discarded before saving visible text, ordinary query-free allowlisted links or public PDFs. This is a provenance declaration and exact path allowance, not an independent privacy scan or global absence proof.',
        readRefetchOrRecoveryAuthorized=False),
    captureImplementation=declared[str(R / 'capture-public-v1.py')],
    excludedPathsOrClasses=excluded + [dict(
        path='raw runtime HTML/configuration, response headers, cookies, credentials, tokens and client/API key payloads',
        reason='Excluded data classes; do not refetch, reconstruct or copy', deletionAuthorized=False)],
    metadataOnly=True, payloadHashSweepPerformed=False, payloadCopyOrCompressionPerformed=False,
    hashScope='Research hashes reused from accepted manifests; only named manifests, preparer and the single existing independent-review PNG are directly hashed here.',
    privacyScanClaim=False, productBrowserOrPhoneScreenshots=0, newSourceCaptureAuthorized=False,
    sourceFilesUnmodified=True,
    heldHistoryPolicy='Preserve all source/typed/selected/scoped/report/docs versions, original attempts, preparation failures and independent diagnostic history. No old reviewed bytes are overwritten.',
    preparer=pin(__file__))
with (B / 'manifest.json').open('x') as stream:
    json.dump(result, stream, indent=2, ensure_ascii=False)
    stream.write('\n')
print(json.dumps(dict(manifest=pin(B / 'manifest.json'), allowlistedFiles=76,
                      sourceImages=7, independentReviewImages=1, excludedReconstructibleFiles=len(excluded)), indent=2))
