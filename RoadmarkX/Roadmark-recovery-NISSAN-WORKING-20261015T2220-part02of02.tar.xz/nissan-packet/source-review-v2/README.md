Nissan source review v2

Source v1 is preserved byte-for-byte. Corrects four exact range bases to WLTP combined, retaining Confirmed. Declared cargo uses an explicit measurement-method-not-stated basis for comparison guards; values/grades unchanged. RACV launch-batch quantity is labelled contextual secondary evidence, while FWD AC Check is earned by conflicting/applicability-limited exact maker sources. No new fetch, live edit or runtime execution.
