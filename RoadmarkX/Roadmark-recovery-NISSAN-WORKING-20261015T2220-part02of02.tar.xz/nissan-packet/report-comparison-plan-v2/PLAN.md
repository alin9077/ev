# Nissan31 actual normal report and exhaustive comparator plan

Prepared only. No report or comparator runtime is authorized by this plan. The Renault backup live-source freeze still blocks registration until explicitly released. Current full-project TypeScript and release remain UNPASSED after two preserved KGM SIGKILLs of unknown cause; no compiler retry is proposed.

## Prerequisites and separate serial gates

Require exact four-file Nissan31 registration, independent accepted live readback, and all five accepted scoped gates from the actual Renault v6 pattern: market view, loader-only lint, 144 behavioral tests, seven distinct live-safety tests and structural validation. Bind actual post-registration source/import/data/source-pointer closure, configured361 root identities, config/runtime metadata and the four registration targets. Metadata guards do not imply a TypeScript pass. No live-after hashes or command manifests are frozen until these prerequisites exist.

Then request one independent unchanged production command: scripts/report-coverage.ts --as-of 2026-10-15 --json. Use pinned absolute Node,448MiB old space/1MiB semi-space,900-second timeout,10-second kill grace and20-second supervisor margin. Structural validation and this single normal report perform their own inherent broad feature work. They are separate normal checks; no extra broad feature replay is added to comparison.

After that actual report is positively verified, run the separate saved-output comparator under448/1MiB,180-second timeout and10-second grace. The comparator may replay four prior Nissan packs/276 selected raw feature rows to establish exact prior selected coverage and freshness, with complete global source/issue context. It never replays peer features or invokes default catalogue loaders. Both commands require independent readiness and an exact exclusive-slot grant. Preserve command, raw wait status, logs, watchdog state, elapsed time, wait4 peak RSS and before/after pins. No automatic retry.

## Accepted Renault30 baseline and retained reconstruction

Baseline is the actual accepted Renault v4 report, SHA256093e0d243e89173bd39d03d8f5e1948c550df09d37b435b018213f895b9894a6, with430 catalogue/353 Tier1/312 on sale. Restore retained409/prefix20 once through the actual21-file closure. Reconstruct complete cars from accepted written replacements/additions through EQA21, Leapmotor22, Mazda23, Skoda24, Audi25, Deepal26, MINI27, KGM28, CUPRA29 and Renault30. Check every ordered complete-car digest against accepted Renault30 artifacts. Replace only the four Nissan rows with accepted stage values; all426 peers and catalogue order remain exact, and all final car digests equal accepted Nissan31.

Stream all14 retained research descriptors while retaining only the four Nissan variants and276 raw feature rows; retain full source/issue controls. Compose prior source arrays through Renault30 then append22 Nissan sources. Check complete before/after source-array digests. Use accepted source packets, selected outputs and producer-owned optional witnesses without blanket normalization. Exact source-reference and runtime-package closures from the latest accepted checks and selected/full-stage work remain pinned, including dynamic registry packets, sourcePointer JSON references, regrading ledger, compiledSource target and installed TypeScript/tsx/esbuild code.

## Every normal-report leaf accounted for

1. Confirm actual report success, exact date and stdout hash, fixed430/353/312 denominators and unchanged implementation
2. Preserve every complete non-Nissan brandProgress object; replace Nissan's whole object with accepted selected coverage, including criteria, completion and closure reasons
3. Recompute all17 complete coreCoverage/coreFact/gradePattern objects over digest-verified on-sale cars and exact source arrays; prove baseline equality and selected deltas, preserving every ordered reason count and gap
4. Use complete digest-bound stage ranking records for all actual ranking fields. Verify facts, group membership, numeric interleaving, rank/tie values, filtered on-sale insertion order, group sorting, every ranked ID, exclusion, reason count, percentage and pass flag. Peer relative order remains exact
5. Keep summary gaps in Tier1 catalogue order, missing models and unresolved leads in actual inherited inventory traversal, and overdue/invalid/excluded-history arrays in producer order, with all fact/availability phases before features. Replace only selected contributions
6. Require full C1 equality with accepted stage before/after:105→106 models,238→242 versions,192→187 issues,64→65 settled records. Only four version-unreviewed issues plus record:nissan-ariya disappear; all other issues, evidence arrays and order remain exact. No invented LEAF inventory/exclusion IDs. C1 stays false
7. Reconstruct paired-summary totals, all-ranking intersections,17-field grading totals/percentages/note, completed/remaining brand arrays, freshness totals and every C1–C6 detail
8. Deep-equal the complete expected report against the actual output, with zero ignored leaves. Save exhaustive baseline-versus-actual and expected-versus-actual differences, complete reason and array-order proofs
9. Prove input nonmutation and actual ownership for every omitted optional property. Retain exact selected accepted cells/features/comparisons/expiry evidence through its pinned stage and review receipts

Nissan source semantics remain explicit: four MY25 Australian ARIYA launch grades, before-ORC primary MSRP, separately Reported October driveaway offers, WLTP combined range, known usable batteries, exact10–80% durations and separate unknown-start webpage observations. Three FWD AC holds remain, unknown cargo method remains unranked, base roadside text is1year with conditional service extension and dealer-restricted towing. LEAF current-new/residual evidence and paused third generation do not become new catalogue or fabricated inventory identities.

## Stop and preserve

A report failure stops its grant and retains all evidence. A comparator failure preserves the successful report; correct and independently review the comparator without rerunning the normal report. Prior Renault interruptions and successful retry remain historical context, not Nissan attempts. Nissan currently has zero normal report invocations. No compiler, build, server/browser, mobile, publication, complete-project suite or release pass is implied.

## Version2 preparation amendment

Preserve preparation-v1 and its syntax receipt. The only semantic amendment excludes exactly roadside_assistance and driveaway_price from unchanged retained-feature equality, asserts all268 remaining feature rows exact, and independently binds all8 replaced fact/feature projections to accepted selected-v4 objects and their values, source IDs, conditions, status and expiry. No report/comparator runtime has occurred.
