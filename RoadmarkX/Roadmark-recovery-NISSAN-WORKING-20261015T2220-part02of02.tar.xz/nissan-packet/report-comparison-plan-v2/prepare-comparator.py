from pathlib import Path
import difflib,hashlib,json,ast
P=Path('/tmp/nissan-packet/report-comparison-plan-v1');O=Path('/tmp/nissan-packet/report-comparison-plan-v2')
assert hashlib.sha256((P/'preparation-manifest-v1.json').read_bytes()).hexdigest()=='bbbc1f6829ecfd84b7eaded7ff61f29ffd68e6f15bb8868b73d3a97f8d202164'
for pin in json.loads((P/'preparation-manifest-v1.json').read_text())['files']:
 p=Path(pin['path']);assert p.stat().st_size==pin['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==pin['sha256']
old=(P/'compare-report.mjs').read_text();s=old.replace(str(P),str(O))
needle="for(const car of after){assert.equal(car.facts.roadside_assistance.value,'1 year');assert.equal(packs[car.id].features.find(row=>row.criterion==='roadside_assistance').value,'1 year');}"
replacement="""const acceptedSelectedPacks=readJson('/tmp/nissan-packet/selected-preflight-v4/selected-packs.json'),canonicalProjectionProof=[];
assert.equal(selectedResult.roadsideRefreshes,4);assert.equal(selectedResult.driveawayRefreshes,4);
for(const car of after){
 const acceptedPack=acceptedSelectedPacks[car.id],pack=packs[car.id];assert(acceptedPack&&pack);
 for(const [criterion,factKey]of [['roadside_assistance','roadside_assistance'],['driveaway_price','promotional_driveaway_aud']]){
  const fact=car.facts[factKey],feature=pack.features.find(row=>row.criterion===criterion),acceptedFeature=acceptedPack.features.find(row=>row.criterion===criterion);
  assert(fact&&feature&&acceptedFeature);assert.deepEqual(fact,acceptedPack.car.facts[factKey]);assert.deepEqual(feature,acceptedFeature);assert.deepEqual(feature.source_ids,fact.sourceIds);
  for(const condition of fact.qualifications)assert(feature.conditions.includes(condition));
  if(criterion==='roadside_assistance'){
   assert.equal(fact.value,'1 year');assert.equal(fact.unit,'');assert.equal(feature.value,'1 year');assert.equal(feature.buyerGrade,'confirmed');assert.equal(feature.status,'standard');assert.equal(feature.verification_state,'reviewed_brand_au_terms');
  }else{
   assert.equal(feature.value,`A$${Number(fact.value).toLocaleString('en-AU')}`);assert.equal(feature.buyerGrade,'reported');assert.equal(feature.status,'conditional');assert.equal(feature.verification_state,'reviewed_canonical_driveaway_price');assert.equal(fact.validUntil,'2026-10-31');assert.equal(feature.validUntil,fact.validUntil);
  }
  canonicalProjectionProof.push({variantId:car.id,criterion,factKey,acceptedFactAndFeatureExact:true,sourceIds:fact.sourceIds,value:feature.value,buyerGrade:feature.buyerGrade,conditions:feature.conditions,validUntil:feature.validUntil??null});
 }
}
assert.equal(canonicalProjectionProof.length,8);write('canonical-replacement-projection-proof',canonicalProjectionProof);"""
assert s.count(needle)==1;s=s.replace(needle,replacement)
needle="for(const car of before)for(const feature of beforeWrittenFeatures.filter(f=>f.variant_id===car.id&&f.criterion!=='roadside_assistance'))assert.deepStrictEqual(feature,packs[car.id].features.find(f=>f.criterion===feature.criterion));"
replacement="""const refreshedCanonicalCriteria=new Set(['roadside_assistance','driveaway_price']);let unchangedRetainedFeatureRows=0;
for(const car of before)for(const feature of beforeWrittenFeatures.filter(f=>f.variant_id===car.id&&!refreshedCanonicalCriteria.has(f.criterion))){assert.deepStrictEqual(feature,packs[car.id].features.find(f=>f.criterion===feature.criterion));unchangedRetainedFeatureRows++;}
assert.equal(unchangedRetainedFeatureRows,268);"""
assert s.count(needle)==1;s=s.replace(needle,replacement)
with (O/'compare-report.mjs').open('x') as f:f.write(s)
for source,name in [(old,'v1-to-v2-comparator.patch'),(Path('/tmp/renault-packet/report-comparison-v4/compare-report.mjs').read_text(),'renault-to-nissan-comparator.patch')]:
 with (O/name).open('x') as f:f.write(''.join(difflib.unified_diff(source.splitlines(True),s.splitlines(True),fromfile=str(P/'compare-report.mjs') if name.startswith('v1') else '/tmp/renault-packet/report-comparison-v4/compare-report.mjs',tofile=str(O/'compare-report.mjs'))))
for name in ['PLAN.md','prepare-manifests.py','close-comparator-inputs.py','check-syntax.py']:
 t=(P/name).read_text().replace(str(P),str(O))
 if name=='PLAN.md':t+='\n## Version2 preparation amendment\n\nPreserve preparation-v1 and its syntax receipt. The only semantic amendment excludes exactly roadside_assistance and driveaway_price from unchanged retained-feature equality, asserts all268 remaining feature rows exact, and independently binds all8 replaced fact/feature projections to accepted selected-v4 objects and their values, source IDs, conditions, status and expiry. No report/comparator runtime has occurred.\n'
 if name=='prepare-manifests.py':
  t=t.replace("B/'renault-to-nissan-comparator.patch',", "B/'renault-to-nissan-comparator.patch',B/'v1-to-v2-comparator.patch',B/'preparation-manifest-v2.json',")
 if name.endswith('.py'):ast.parse(t)
 with (O/name).open('x') as f:f.write(t)
print('Version2 projection amendment prepared; version1 preserved; no imports/runtime.')
