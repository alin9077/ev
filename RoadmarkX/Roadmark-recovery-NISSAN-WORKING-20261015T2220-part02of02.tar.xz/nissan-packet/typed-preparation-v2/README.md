Nissan typed preparation v2

Four narrow independent-review corrections only: ARIYA six-page PDF capture description; CarExpert primary rung-5 offer pointer/publisher with dealer corroboration; buyer-readable capacity-alias gauge-bar wording; secondary RACV launch-batch quantity retained only in source context rather than maker-graded buyer fact qualifications.

All 68 core values/grades (65 Confirmed, three Check), 176 beforeguarded specific updates, 12 shared-term applications, summaries, identities, availability and reconciliation remain unchanged. V1 is preserved. No actual helper/consumer/compiler/full-catalogue or live execution. Separate independent acceptance and runtime grant required.
