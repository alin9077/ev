"""Static closure for saved-output comparator reads. No JS module execution."""
from pathlib import Path
import re,json,hashlib

def collect(R,B):
 R=Path(R);B=Path(B);seen=set();edges=[];external=set()
 def pin(p):
  p=Path(p);h=hashlib.sha256()
  with p.open('rb') as f:
   for b in iter(lambda:f.read(65536),b''):h.update(b)
  return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
 def visit(p):
  p=Path(p).resolve()
  if p in seen:return
  assert p.is_file(),p;seen.add(p)
  if p.suffix not in ['.ts','.tsx','.mjs','.mts','.js']:return
  text=p.read_text()
  refs=[]
  for spec in re.findall(r'''(?:\bfrom\s*|\bimport\s*\(?\s*|\brequire\s*\(\s*|\bcompiledSource\s*\(\s*)["']([^"']+)["']''',text):refs.append((spec,'import-or-compiled-source'))
  # Literal absolute saved inputs, replacement lists, and implementation excerpts.
  for spec in re.findall(r'''["']((?:/tmp/|/workspace/)[A-Za-z0-9_./-]+\.(?:json|mjs|ts|tsx|log))["']''',text):refs.append((spec,'absolute-saved-input'))
  for spec in re.findall(r'''repo\s*\+\s*["'](/[^"']+\.(?:ts|tsx|json))["']''',text):refs.append((str(R/spec.lstrip('/')),'repo-source-excerpt'))
  for spec in re.findall(r'''["'](data/[A-Za-z0-9_./-]+\.json)["']''',text):refs.append((spec,'declared-data-read'))
  for spec,kind in refs:
   if spec.startswith('@/'):base=R/'src'/spec[2:]
   elif spec.startswith(('src/','tests/','scripts/','data/')):base=R/spec
   elif spec.startswith(('./src/','./tests/','./scripts/')) and p.parent==B:base=R/spec
   elif spec.startswith('.'):base=(p.parent/spec).resolve()
   elif spec.startswith('/'):base=Path(spec)
   else:external.add(spec);continue
   hit=next((f for f in [base,*[Path(str(base)+x) for x in ['.ts','.tsx','.mjs','.js','.json']],base/'index.ts'] if f.is_file()),None)
   assert hit,('Unresolved comparator input',str(p),spec,kind)
   edges.append(dict(importer=str(p),specifier=spec,kind=kind,resolved=pin(hit)));visit(hit)
 visit(B/'compare-report.mjs')
 stage=json.loads(Path('/tmp/nissan-packet/full-stage-v1/manifest.json').read_text());closure=json.loads(Path(stage['storageClosure']['path']).read_text());assert len(closure)==21
 for p in closure:assert pin(p['path'])==p;seen.add(Path(p['path']))
 registry=R/'data/m1-brand-updates/registry.json';seen.add(registry);packets=json.loads(registry.read_text())['packets'];assert len(packets)==31 and packets[-1]=='nissan-2026-10-15.json'
 for name in packets:seen.add(R/'data/m1-brand-updates'/name)
 generated=[str(B/'normal-coverage-asof-2026-10-15'/name) for name in ['stdout.log','terminal.json','result.json','after-pins.json','scope-verification.json','invocation.json']]
 value=dict(status='static_comparator_local_import_and_read_closure',files=[pin(p) for p in sorted(seen)],edges=sorted(edges,key=lambda x:(x['importer'],x['specifier'],x['kind'])),packageOrNodeSpecifiers=sorted(external),retainedStorageFiles=closure,registeredPackets=packets,generatedNormalInputs=generated,generatedNormalBinding='Normal command prerequisite must pass. Comparator verifies stdout against terminal hash, result against exact frozen normal-command hash, positive result and after-pins status, then hashes all six actual generated input files before/after and saves that closure.',dynamicReadBindings=['readCompleteCars and streamRows use the exact accepted anchor manifest and 21-file storage closure','All prior selected replacement files and source-array digests are direct literal inputs above','Actual compiledSource targets and relative source imports are recursively included','All 31 dynamic registry packet reads are pinned','The compile helper reads only the explicit reports.ts source and its traversed import closure'],runtimeExecuted=False)
 with (B/'comparator-input-closure.json').open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 return value['files']
