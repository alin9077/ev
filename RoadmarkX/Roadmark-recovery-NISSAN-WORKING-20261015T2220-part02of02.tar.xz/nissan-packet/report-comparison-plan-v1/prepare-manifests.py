"""Static source/import closure and two-command preparation. No report/compiler execution."""
from pathlib import Path
import hashlib,json,re,sys,ast,runpy
R=Path('/workspace/scratch/586427eef9f2/roadmark-104');B=Path('/tmp/nissan-packet/report-comparison-plan-v1');P=Path('/tmp/nissan-packet/post-registration-checks-v1');A=Path('/tmp/nissan-packet/registration-v1')
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def check(p):assert pin(p['path'])==p,p['path']
def read(p):return json.loads(Path(p).read_text())
def write(n,x):
 with (B/n).open('x')as f:json.dump(x,f,indent=2);f.write('\n')
assert len(sys.argv)==3,'prepare-manifests.py FIVE_GATE_ACCEPTANCE_PATH LIVE_REGISTRATION_ACCEPTANCE_PATH'
fivepin=pin(sys.argv[1]);five=read(sys.argv[1]);assert five['status']=='accepted'
registration=pin(sys.argv[2]);assert read(registration['path'])['status']=='accepted'
sequence=read(P/'sequence.json');assert len(sequence['sequence'])==5 and sequence['compilerIncluded'] is False
expectedNames=['market-view','changed-file-lint','behavioural-suites','live-brand-safety','structural-validation']
proofs={}
def add(p):
 x=pin(p)
 if x['path']in proofs:assert proofs[x['path']]==x
 proofs[x['path']]=x
for p in [fivepin['path'],registration['path'],A/'application/result.json',P/'sequence.json',B/'PLAN.md',B/'compare-report.mjs',B/'prepare-comparator.py',B/'renault-to-nissan-comparator.patch',B/'check-syntax.py',B/'syntax-only-receipt.json',B/'syntax-only-stdout.log',B/'syntax-only-stderr.log',B/'prepare-manifests.py']:add(p)
prerequisites=[]
for expected,row in zip(expectedNames,sequence['sequence']):
 check(row);m=read(row['path']);assert m['id']==expected
 d=P/'run'/expected;r=read(d/'result.json');t=read(d/'terminal.json');assert r['passed']is True and r['exitCode']==t['exitCode']==0 and r['manifestSha256']==row['sha256']
 add(row['path'])
 for name in ['result.json','terminal.json','after-pins.json','scope-verification.json','stdout.log','stderr.log','invocation.json','registration-target-metadata-before.json']:add(d/name)
 prerequisites.append(dict(manifest=row,resultPath=str(d/'result.json')))
# Explicitly preserve both unsuccessful compiler attempts; never require or imply a compiler pass.
failure=Path('/tmp/kgm-packet/report-comparison-v2/typescript-failure-provenance.json');failureData=read(failure);assert failureData['fullProjectTypecheckPassed']is False
add(failure)
for p in failureData['proofPins']:check(p);add(p['path'])
for attempt in failureData['attempts']:
 assert attempt['exitCode']==-9 and attempt['cause']=='unknown' and attempt['fullProjectTypecheckPassed']is False
 assert not Path(attempt['freshCachePath']).exists()
write('typescript-failure-context.json',dict(status='current_full_project_typescript_unpassed',failureProvenance=pin(failure),attempts=failureData['attempts'],compilerRetriesAuthorized=False,releaseAcceptanceClaim=False,currentFiveGateAcceptance=fivepin,scope='Independent factual report/comparison only; original config/root/runtime content guards retained.'))
add(B/'typescript-failure-context.json')
# Static imports only; no parser or project module invocation.
seen=set();edges=[];external=set();explicit=[]
def visit(p):
 p=Path(p).resolve()
 if p in seen:return
 seen.add(p)
 if p.suffix not in ['.ts','.tsx','.js','.mjs']:return
 text=p.read_text()
 for spec in re.findall(r'''(?:\bfrom\s*|\bimport\s*|\brequire\s*\(\s*)["']([^"']+)["']''',text):
  if spec.startswith('@/'):base=R/'src'/spec[2:]
  elif spec.startswith('.'):base=p.parent/spec
  else:external.add(spec);continue
  candidates=[base,*(Path(str(base)+suffix)for suffix in ['.ts','.tsx','.js','.mjs','.json']),*(base/('index'+suffix)for suffix in ['.ts','.tsx','.js','.mjs'])]
  match=next((c.resolve()for c in candidates if c.is_file()),None);assert match,(p,spec)
  assert match.is_relative_to(R);edges.append(dict(fromPath=str(p),specifier=spec,toPath=str(match)));visit(match)
 for rel in re.findall(r'''["'](data/[a-zA-Z0-9_.\-/]+\.json)["']''',text):
  target=R/rel;assert target.is_file();explicit.append(dict(fromPath=str(p),relativePath=rel,target=str(target)));seen.add(target)
entrypoints=['scripts/report-coverage.ts','scripts/reporting/reports.ts','src/lib/brand-update-registry.ts','src/lib/market-inventory-data.ts','scripts/reporting/m1-reconciliation.ts']
for rel in entrypoints:visit(R/rel)
registry=read(R/'data/m1-brand-updates/registry.json');assert len(registry['packets'])==31 and registry['packets'][-1]=='nissan-2026-10-15.json'
seen.add(R/'data/m1-brand-updates/registry.json')
for name in registry['packets']:seen.add(R/'data/m1-brand-updates'/name)
seen.add(R/'node_modules/typescript/lib/typescript.js')
pins={p['path']:p for p in read(P/'source-pins.json')}
for p in pins.values():check(p)
for f in seen:
 x=pin(f)
 if x['path']in pins:assert pins[x['path']]==x
 pins[x['path']]=x
write('static-import-closure.json',dict(entrypoints=entrypoints,relativeEdges=edges,explicitJsonReads=explicit,dynamicRegistryPackets=registry['packets'],packageImports=sorted(external),files=[pin(p)for p in sorted(seen)]));add(B/'static-import-closure.json')
# Accepted full-stage input closure is historical. Exactly registry/load.ts advanced under the accepted four-file registration.
transitions={w['target']:w for w in read(A/'manifest.json')['writes']}
changed=[];stage=read('/tmp/nissan-packet/full-stage-v1/manifest.json')
for p in stage['pins']:
 if p['path']in transitions and transitions[p['path']]['before'] is not None:
  w=transitions[p['path']];assert {k:v for k,v in p.items()if k!='path'}==w['before'];check(w['beforeCopy'])
  replacement=dict(path=w['target'],bytes=w['after']['bytes'],sha256=w['after']['sha256']);check(replacement);pins[p['path']]=replacement;changed.append(dict(historical=p,retainedBefore=w['beforeCopy'],current=replacement))
 else:
  check(p)
  if p['path']in pins:assert pins[p['path']]==p
  pins[p['path']]=p
assert sorted(Path(x['current']['path']).name for x in changed)==['load.ts','registry.json']
write('source-transition-provenance.json',dict(stageManifest=pin('/tmp/nissan-packet/full-stage-v1/manifest.json'),registrationManifest=pin(A/'manifest.json'),onlyHistoricalLiveInputTransitions=changed,allOtherStagePinsUnchanged=True));add(B/'source-transition-provenance.json')
# Every output leaf and selected source result needed by the comparator is directly pinned.
for manifest,key in [('/tmp/nissan-packet/full-stage-v1/full-stage-result-manifest-v1.json','outputs'),('/tmp/nissan-packet/selected-preflight-v4/selected-result-manifest-v1.json','outputs')]:
 add(manifest)
 for p in [*read(manifest)[key],*read(manifest).get('inputs',[])]:check(p);add(p['path'])
for p in ['/tmp/nissan-review/full-stage-v1-results-v1.json','/tmp/nissan-review/selected-preflight-v4-results-v1.json','/tmp/renault-review/report-comparison-v4-results-v1.json','/tmp/renault-packet/report-comparison-v4/normal-coverage-asof-2026-10-15/stdout.log','/tmp/renault-packet/report-comparison-v4/normal-coverage-asof-2026-10-15/terminal.json','/tmp/kgm-packet/full-stage-v1/output/car-digest-comparison.json','/tmp/kgm-packet/full-stage-v1/output/research-field-digests.json','/tmp/kgm-packet/full-stage-v1/output/selected-after-cars.json','/tmp/nissan-research/retained-before-cars-v1.json']:add(p)
comparatorFiles=runpy.run_path(str(B/'close-comparator-inputs.py'))['collect'](R,B)
for p in comparatorFiles:
 check(p)
 if p['path'] in pins:assert pins[p['path']]==p
 pins[p['path']]=p
for p in [B/'close-comparator-inputs.py',B/'comparator-input-closure.json',Path('/tmp/renault-packet/report-comparison-v4/compare-report.mjs'),Path('/tmp/renault-packet/report-comparison-v4/comparator-input-closure.json'),Path('/tmp/renault-review/report-comparison-v4-results-v1.json')]:add(p)
write('source-pins.json',[pins[k]for k in sorted(pins)])
with (B/'run.py').open('xb')as f:f.write((P/'run.py').read_bytes())
ast.parse((B/'run.py').read_text())
base=read(P/'structural-validation.json')
for k in ['id','kind','command','timeoutSeconds','expectedStructuralCounts','expectedSourceReferences','expectedPublicationIssues','expectedApprovedExternalAssets','immutableResearchSha256','runOutput','prerequisites','extraPins']:base.pop(k,None)
base.update(qaRoot=str(B),sourcePins=pin(B/'source-pins.json'),wrapper=pin(B/'run.py'),fullProjectTypecheckPassed=False,releaseAcceptanceClaim=False,independentCoverageException=pin(B/'typescript-failure-context.json'))
commonProofs=[proofs[k]for k in sorted(proofs)]
normal=dict(base,id='normal-coverage-asof-2026-10-15',kind='normal-report',command=['/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','--max-old-space-size=448','--max-semi-space-size=1','--import','tsx','scripts/report-coverage.ts','--as-of','2026-10-15','--json'],timeoutSeconds=900,runOutput=str(B/'normal-coverage-asof-2026-10-15'),prerequisites=prerequisites,extraPins=commonProofs,expectedReportCounts=[430,353,312],asOf='2026-10-15')
write('normal-coverage-asof-2026-10-15.json',normal)
comparison=dict(base,id='report-comparison',kind='comparison',command=['/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','--max-old-space-size=448','--max-semi-space-size=1','--import','tsx',str(B/'compare-report.mjs')],timeoutSeconds=180,runOutput=str(B/'report-comparison'),comparisonResult=str(B/'artifacts/result.json'),prerequisites=[dict(manifest=pin(B/'normal-coverage-asof-2026-10-15.json'),resultPath=str(B/'normal-coverage-asof-2026-10-15/result.json'))],extraPins=commonProofs)
write('report-comparison.json',comparison)
seq=dict(status='frozen_not_executed_requires_review_and_root_grant',sequence=[pin(B/'normal-coverage-asof-2026-10-15.json'),pin(B/'report-comparison.json')],sourcePins=base['sourcePins'],rootMetadata=base['rootMetadata'],qaRoot=str(B),registrationManifest=base['registrationManifest'],registrationTargets=base['registrationTargets'],normalReportRuns=1,normalReportSubstitutionAllowed=False,acceptedFiveChecksAndRegistrationRequired=True,fullProjectTypecheckPassed=False,releaseAcceptanceClaim=False,compilerRetryIncluded=False,independentCoverageException=base['independentCoverageException'],noAutomaticRetry=True,extraBroadFeatureReplay=False,coreReasonReconstruction='Actual production coreCoverage over complete digest-verified cars/sources; actual four-car prior feature controls and accepted selected after controls; no peer features',executionAuthorized=False)
write('sequence.json',seq)
g=read(P/'root-grant-template.json');g.update(sequence=pin(B/'sequence.json'),granted=seq['sequence'],reviewerAcceptance=None,registrationVerification=registration,fullProjectTypecheckPassed=False,releaseAcceptanceClaim=False);write('root-grant-template.json',g)
for m in [normal,comparison]:
 for p in [m['wrapper'],m['sourcePins'],m['rootMetadata'],m['testInventory'],m['registrationManifest'],*read(m['sourcePins']['path']),*m['extraPins']]:check(p)
for p in [B/'normal-coverage-asof-2026-10-15',B/'report-comparison',B/'artifacts']:assert not p.exists()
write('static-verification.json',dict(status='prepared_not_executed',sequence=pin(B/'sequence.json'),sourcePinCount=len(pins),extraProofPins=len(proofs),all21RetainedStorageLeavesClosed=True,all456HistoricalStageInputsClosedExceptTwoAcceptedLiveTransitions=True,allStageAndSelectedOutputManifestLeavesClosed=True,wrapperByteIdenticalToFiveGateWrapper=pin(B/'run.py')['sha256']==pin(P/'run.py')['sha256'],currentProjectTypeScript='UNPASSED',compilerRetriesIncluded=False,onlyPlannedHeavyExecutions=['one normal report','one saved-output comparator'],normalLimits='448/1 MiB;900+10 seconds',comparatorLimits='448/1 MiB;180+10 seconds'))
print(json.dumps(dict(sequence=pin(B/'sequence.json'),normal=pin(B/'normal-coverage-asof-2026-10-15.json'),comparison=pin(B/'report-comparison.json'),sourcePinCount=len(pins),extraProofPins=len(proofs)),indent=2))
