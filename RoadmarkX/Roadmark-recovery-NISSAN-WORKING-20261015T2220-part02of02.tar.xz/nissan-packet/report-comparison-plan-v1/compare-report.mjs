/** One saved normal report versus accepted Renault30; exact core reasons and four selected prior Nissan packs. */
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import path from 'node:path';
import {readJson,fileHash,streamRows,digestRows} from '/tmp/xpeng-staging-plan/baseline-io.mjs';
import {readCompleteCars} from '/tmp/mercedes-staging-plan/staging-preparation/shape-first-v3/read-complete-storage.mjs';
import {assertDeclaredJson} from '/tmp/mercedes-staging-plan/consumer-preparation/v5/feature-json-parity.mjs';
const repo='/workspace/scratch/586427eef9f2/roadmark-104';
const prep='/tmp/nissan-packet/report-comparison-plan-v1';
const qa='/tmp/nissan-packet/report-comparison-plan-v1';
assert.equal(process.cwd(),repo);
const out=qa+'/artifacts';assert(!fs.existsSync(out));fs.mkdirSync(out);
const write=(name,value)=>fs.writeFileSync(out+'/'+name+'.json',JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const require=createRequire(repo+'/package.json'),ts=require('typescript');
const normalPath=qa+'/normal-coverage-asof-2026-10-15/stdout.log';
const baselinePath='/tmp/renault-packet/report-comparison-v4/normal-coverage-asof-2026-10-15/stdout.log';
assert.equal(fileHash(baselinePath),'093e0d243e89173bd39d03d8f5e1948c550df09d37b435b018213f895b9894a6');
const normal=readJson(normalPath),baseline=readJson(baselinePath);
const normalTerminal=readJson(qa+'/normal-coverage-asof-2026-10-15/terminal.json');assert.equal(normalTerminal.exitCode,0);assert.equal(normalTerminal.stdoutSha256,fileHash(normalPath));
const generatedNormalInputs=['stdout.log','terminal.json','result.json','after-pins.json','scope-verification.json','invocation.json'].map(name=>{const file=qa+'/normal-coverage-asof-2026-10-15/'+name;return {path:file,bytes:fs.statSync(file).size,sha256:fileHash(file)};});
const normalResult=readJson(qa+'/normal-coverage-asof-2026-10-15/result.json'),normalAfterPins=readJson(qa+'/normal-coverage-asof-2026-10-15/after-pins.json');
assert.equal(normalResult.passed,true);assert.equal(normalResult.exitCode,0);assert.equal(normalResult.manifestSha256,fileHash(qa+'/normal-coverage-asof-2026-10-15.json'));assert.equal(normalAfterPins.passed,true);
function checkNormalInputs(){for(const pin of generatedNormalInputs){assert.equal(fs.statSync(pin.path).size,pin.bytes);assert.equal(fileHash(pin.path),pin.sha256);}}
checkNormalInputs();write('generated-normal-input-closure',generatedNormalInputs);

function differences(a,b,path=''){
 if(Object.is(a,b))return[];
 if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return[{path,before:a,after:b}];
 const out=[];for(const key of new Set([...Object.keys(a),...Object.keys(b)])){
  const p=path+'/'+key.replaceAll('~','~0').replaceAll('/','~1');
  if(!Object.hasOwn(a,key))out.push({path:p,operation:'add',after:b[key]});
  else if(!Object.hasOwn(b,key))out.push({path:p,operation:'remove',before:a[key]});
  else out.push(...differences(a[key],b[key],p));
 }return out;
}
write('exhaustive-normal-versus-renault-diff',differences(baseline,normal));
const selectedResult=readJson('/tmp/nissan-packet/selected-preflight-v4/result.json');
const selectedAfter=selectedResult.selectedCoverage;
const before=readJson('/tmp/nissan-research/retained-before-cars-v1.json');
const packs=readJson('/tmp/nissan-packet/full-stage-v1/output/selected-packs.json');
const after=readJson('/tmp/nissan-packet/full-stage-v1/output/selected-after-cars.json');
const selectedIds=new Set(before.map(c=>c.id)),modelIds=new Set(before.map(c=>c.modelId));
assert.equal(selectedIds.size,4);assert.equal(selectedResult.otherRetainedFeaturesUnchanged,true);assert.equal(selectedResult.selectedFeatureClaims,276);assert.equal(selectedResult.packetSha256,'6aa651b6932721365dfdee38c92fd19d9dd62cf50cb42ec6c348d495f00c9585');
for(const car of after){assert.equal(car.facts.roadside_assistance.value,'1 year');assert.equal(packs[car.id].features.find(row=>row.criterion==='roadside_assistance').value,'1 year');}
const selectedSnapshots={before:structuredClone(before),after:structuredClone(after),packs:structuredClone(packs),result:structuredClone(selectedResult)};
const acceptedStageDigests=readJson('/tmp/nissan-packet/full-stage-v1/output/car-digest-comparison.json');
const acceptedRenaultDigests=readJson('/tmp/renault-packet/full-stage-v1/output/car-digest-comparison.json');
assert.deepStrictEqual(acceptedStageDigests.candidate30,acceptedRenaultDigests.candidate30);
assert.equal(acceptedStageDigests.candidate31.length,430);
const oldPeerDigests=acceptedStageDigests.candidate30.filter(c=>!selectedIds.has(c.id)),newPeerDigests=acceptedStageDigests.candidate31.filter(c=>!selectedIds.has(c.id));
assert.equal(oldPeerDigests.length,426);assert.deepStrictEqual(newPeerDigests,oldPeerDigests);
write('accepted-peer-car-value-and-basis-proof',{exactCompletePeerCars:426,allPeerValuesBasesUnitsGradesAndIdentitiesUnchanged:true,peers:newPeerDigests});
const manifest=readJson('/tmp/mercedes-staging-plan/consumer-preparation/v5/manifests/report-v5.json');
const index=readJson('/tmp/mercedes-staging-plan/staging-preparation/staging-artifacts/canonical-v1/staged-storage-index.json');
const base={},reads=[];
const stageManifest=readJson('/tmp/nissan-packet/full-stage-v1/manifest.json');
const closure=readJson(stageManifest.storageClosure.path),closureMap=new Map(closure.map(p=>[p.path,p])),readPaths=new Set();
const acceptedInputPins=new Map(manifest.inputPins.map(row=>[row.anchor+'\0'+row.file,row]));
const proof={anchors:manifest.anchors,assertPinned(ref){const pin=acceptedInputPins.get(ref.anchor+'\0'+ref.file),absolute=path.resolve(manifest.anchors[ref.anchor],ref.file),direct=closureMap.get(absolute);assert(pin&&direct);assert.equal(pin.sha256,ref.sha256);assert.equal(pin.bytes,ref.bytes);assert.equal(direct.sha256,ref.sha256);assert.equal(direct.bytes,ref.bytes);readPaths.add(absolute);}};
let restored=await readCompleteCars(proof,stageManifest.storageIndex),completeBefore=restored.cars;restored=null;
const carDigests=cars=>cars.map(car=>({id:car.id,...digestRows([car])}));
assertDeclaredJson(completeBefore,'/prefix20',new Set());assert.deepStrictEqual(carDigests(completeBefore),acceptedRenaultDigests.baseline20);
for(const [key,ref]of Object.entries(index.research))proof.assertPinned(ref);

for(const [key,ref]of Object.entries(index.research)){
 const values=[];
 await streamRows(manifest.anchors,ref,row=>{
  const keep=['variants','feature_evidence_variant_context'].includes(key)?selectedIds.has(row.id):['feature_evidence','trim_equipment','update_eligibility'].includes(key)?selectedIds.has(row.variant_id):key==='models'?modelIds.has(row.id):true;
  if(keep)values.push(row);
 });base[key]=ref.array?values:values[0];reads.push({key,inputRows:ref.rows,retainedRows:values.length,sha256:ref.sha256});
}
assert.equal(base.variants.length,4);assert.equal(base.feature_evidence.length,276);
assert.deepStrictEqual([...readPaths].sort(),[...closureMap.keys()].sort());
function compile(path,relative,overrides={},append=''){
 const filename=repo+'/'+relative,source=fs.readFileSync(path,'utf8')+append;
 const output=ts.transpileModule(source,{fileName:filename,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,esModuleInterop:true}}).outputText;
 const scoped=createRequire(filename),module={exports:{}};
 vm.runInThisContext('(function(require,module,exports){'+output+'\n})',{filename})(id=>Object.hasOwn(overrides,id)?overrides[id]:scoped(id),module,module.exports);return module.exports;
}
// No feature replay for peers. Reconstruct complete cars from already accepted written values.
const {brandUpdatePackets}=require('./src/lib/brand-update-registry.ts');
assert.equal(brandUpdatePackets.length,31);assert.equal(brandUpdatePackets.at(-1).id,'m1-nissan-2026-10-15');
const priorPackets=brandUpdatePackets.slice(0,30),packet=brandUpdatePackets.at(-1);
assert.deepStrictEqual(priorPackets.map(p=>p.id),stageManifest.registeredPacketIds);
const sourceMap=new Map(base.sources.map(source=>[source.id,source]));assert.equal(sourceMap.size,base.sources.length);
for(const p of priorPackets.slice(20))for(const source of p.sources){if(sourceMap.has(source.id))assert.deepStrictEqual(sourceMap.get(source.id),source);else sourceMap.set(source.id,structuredClone(source));}
base.sources=[...sourceMap.values()];
assert.deepStrictEqual(digestRows(base.sources),readJson('/tmp/renault-packet/full-stage-v1/output/research-field-digests.json').candidate30.sources);
const eqa=priorPackets[20];assert.equal(eqa.id,'m1-mercedes-benz-towing-basis-2026-10-15');assert.equal(eqa.facts.length,1);assert.equal(eqa.summaries.length,0);assert.equal(eqa.variants.length,0);assert.equal(eqa.availability.length,0);assert.equal(eqa.versionUpdates.length,0);
const edit=eqa.facts[0],originalEqa=completeBefore.find(car=>car.id===edit.variantId);assert.deepStrictEqual(originalEqa.facts[edit.after.key],edit.before);
completeBefore=completeBefore.map(car=>car.id===edit.variantId?{...car,facts:{...car.facts,[edit.after.key]:structuredClone(edit.after)}}:car);
assertDeclaredJson(completeBefore,'/corrected21',new Set());assert.deepStrictEqual(carDigests(completeBefore),acceptedRenaultDigests.corrected21);
const replacements=[
 ['current22','/tmp/leapmotor-staging/v4-timeout/output/selected-after-cars.json'],
 ['current23','/tmp/mazda-staging/full-v2/output/selected-after-cars.json'],
 ['current24','/tmp/skoda-packet/full-stage-v1/output/selected-after-cars.json'],
 ['candidate25','/tmp/audi-packet/full-stage-v1/output/selected-after-cars.json'],
 ['candidate26','/tmp/deepal-packet/full-stage-v4/output/selected-after-cars.json'],
 ['candidate27','/tmp/mini-packet/full-stage-v2/output/selected-after-cars.json'],
 ['candidate28','/tmp/kgm-packet/full-stage-v1/output/selected-after-cars.json'],
 ['candidate29','/tmp/cupra-packet/full-stage-v2/output/selected-after-cars.json'],
 ['candidate30','/tmp/renault-packet/full-stage-v1/output/selected-after-cars.json'],
];
for(const [stage,file]of replacements){
 const rows=readJson(file),replacementMap=new Map(rows.map(car=>[car.id,car]));assert.equal(rows.length,replacementMap.size);
 const existing=new Set(completeBefore.map(car=>car.id));completeBefore=completeBefore.map(car=>replacementMap.get(car.id)??car);completeBefore.push(...rows.filter(car=>!existing.has(car.id)));
 assertDeclaredJson(completeBefore,'/'+stage,new Set());assert.deepStrictEqual(carDigests(completeBefore),acceptedRenaultDigests[stage]);
}
assert.equal(completeBefore.length,430);assert.deepStrictEqual(completeBefore.filter(car=>selectedIds.has(car.id)),before);
const afterMap=new Map(after.map(car=>[car.id,car])),completeAfter=completeBefore.map(car=>afterMap.get(car.id)??car);
assertDeclaredJson(completeAfter,'/completeAfter',new Set());assert.deepStrictEqual(carDigests(completeAfter),acceptedStageDigests.candidate31);
const beforeSourceSnapshot=digestRows(base.sources),afterSources=[...base.sources,...packet.sources];
assert.deepStrictEqual(digestRows(afterSources),readJson('/tmp/nissan-packet/full-stage-v1/output/research-field-digests.json').candidate31.sources);
const baseSnapshot=structuredClone(base),packetSnapshot=structuredClone(packet);
const {compiledSource}=require('./tests/helpers/compiled-source.ts');
let defaultCalls=0;const forbidden=()=>{defaultCalls++;throw new Error('FORBIDDEN_DEFAULT_LOADER');};
const consumer=compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets:priorPackets}}).createEvidenceConsumers({sourceResearch:forbidden,research:forbidden,catalogue:forbidden});
const {applyFeatureRegrading}=require('./src/lib/evidence-regrading.ts');
const {applyBrandFeatureUpdates,applyBrandTermFeatures}=require('./src/lib/brand-updates.ts');
const {auditedFeature}=require('./src/lib/launch-evidence.ts');
const beforeFeatures=[],producerReceipts=[],frames=new Map(),observations=[];
function observePack(car,pack,phase){
 const pointers=[];
 function visit(value,pointer){
  if(value===undefined){
   const match=pointer.match(/\/features\/(\d+)\/([^/]+)$/);assert(match,'Unexpected undefined outside feature: '+pointer);
   const rowIndex=Number(match[1]),property=match[2],feature=pack.features[rowIndex],descriptor=Object.getOwnPropertyDescriptor(feature,property);
   assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value')&&descriptor.value===undefined);
   const frame=frames.get(phase+'\0'+car.id),sourceRow=frame.input.find(f=>f.criterion===feature.criterion),regraded=frame.regraded.find(f=>f.criterion===feature.criterion),projected=frame.projected.find(f=>f.criterion===feature.criterion);
   assert(sourceRow&&regraded&&projected);assert.deepEqual(feature,projected);
   let producer;
   if(property==='gradeReviewStatus'){
    assert(feature.gradeReview);assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts earned retained-feature branch explicitly sets gradeReviewStatus undefined';
   }else if(property==='condition_label'){
    assert.equal(feature.buyerGrade,'check');assert(!Object.hasOwn(sourceRow,property)||sourceRow[property]===undefined);assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts Check branch retains source optional condition_label';
   }else if(property==='confirmation_needed'){
    assert.equal(feature.criterion,'novated_fbt');
    for(const row of [sourceRow,regraded]){const d=Object.getOwnPropertyDescriptor(row,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);}
    const raw=frame.research.feature_evidence.find(f=>f.variant_id===car.id&&f.criterion===feature.criterion);assert(raw);
    const snap=structuredClone(raw),audited=auditedFeature(raw);assert.deepEqual(raw,snap);
    const d=Object.getOwnPropertyDescriptor(audited,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);
    producer='launch-evidence.ts actual auditedFeature(raw exact novated_fbt row) creates confirmation_needed undefined';
   }else if(['buyerGrade','gradeReview'].includes(property)){
    assert.equal(feature.gradeReviewStatus,'review_required');assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts unmatched retained-feature branch withdraws optional review';
   }else assert.fail('Unclassified optional undefined: '+pointer);
   observations.push({phase,variantId:car.id,pointer,rowIndex,criterion:feature.criterion,property,ownUndefined:true,enumerable:true,producer,sourceProperty:{own:Object.hasOwn(sourceRow,property),valueKind:sourceRow[property]===undefined?'undefined':typeof sourceRow[property]},regradedProperty:{own:Object.hasOwn(regraded,property),valueKind:regraded[property]===undefined?'undefined':typeof regraded[property]},actualFinalProjectionMatched:true});
   pointers.push(pointer);return;
  }
  if(!value||typeof value!=='object')return;
  for(const key of Object.keys(value))visit(value[key],pointer+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));
 }
 visit(pack,'/packs/'+car.id);assertDeclaredJson(pack,'/packs/'+car.id,new Set(pointers));
}
for(const car of before){
 const input=consumer.sourceEffectiveFeatures(car,base),inputSnapshot=structuredClone(input),regraded=applyFeatureRegrading(car,input,base.sources);
 const branded=applyBrandFeatureUpdates(car,regraded,base,priorPackets),projected=applyBrandTermFeatures(car,branded,base.sources);
 assert.deepStrictEqual(input,inputSnapshot);frames.set('before\0'+car.id,{input,regraded,branded,projected,research:base});
 const features=consumer.effectiveFeatures(car,base);assert.equal(features.length,69);assert.deepStrictEqual(features,projected);
 observePack(car,{features},'before');beforeFeatures.push(...features);
 producerReceipts.push({carId:car.id,criteria:69,sourceRows:input.length,actualCanonicalRows:features.length});
}
assert.equal(beforeFeatures.length,276);assert.deepStrictEqual(observations,selectedResult.optionalFeaturePaths.filter(row=>row.phase==='before'));
const beforeFeatureSnapshot=structuredClone(beforeFeatures);
write('selected-before-features',beforeFeatures);
const beforeWrittenFeatures=readJson(out+'/selected-before-features.json');
for(const car of before)for(const feature of beforeWrittenFeatures.filter(f=>f.variant_id===car.id&&f.criterion!=='roadside_assistance'))assert.deepStrictEqual(feature,packs[car.id].features.find(f=>f.criterion===feature.criterion));
assert.deepStrictEqual(base,baseSnapshot);assert.deepStrictEqual(before,selectedSnapshots.before);
const reports=compile(repo+'/scripts/reporting/reports.ts','scripts/reporting/reports.ts',{},'\nexport { coreFact, gradePattern, coreCoverage };\n');
const inventory=require('./src/lib/market-inventory-data.ts').default;
const nissanInventory={...inventory,records:inventory.records.filter(r=>r.brand==='Nissan'),unverifiedLeads:inventory.unverifiedLeads.filter(r=>r.brand==='Nissan')};
const emptyRegistry={schemaVersion:1,checkedAt:'2026-10-15',notes:[],publishedLists:[],currentVersionReviews:[],listResolutions:[],catalogueOnlyDifferences:[],inventoryResolutions:[]};
const selectedBefore=reports.buildCoverageReport({cars:before,sources:base.sources,features:beforeFeatures,inventory:nissanInventory,m1Reconciliation:emptyRegistry},normal.asOf);

const selectedBeforeSnapshot=structuredClone(selectedBefore);
const oldNissan=baseline.brandProgress.find(b=>b.brand==='Nissan');
// Whole written parity plus exact own-undefined ownership from the actual C1 issue producer.

const {buildMarketReconciliation,inventoryRecordId}=require('./scripts/reporting/m1-reconciliation.ts');
const issueFixtureInventory={records:[],unverifiedLeads:[]};
const issueFixture=buildMarketReconciliation(emptyRegistry,[],issueFixtureInventory,normal.asOf);
assert.equal(issueFixture.registryValid,true);assert.equal(issueFixture.independentListCount,0);
assert.deepEqual(issueFixture.issues.map(i=>i.code),['independent_lists','empty_catalogue']);
const liveNissan=selectedBefore.brandProgress.find(b=>b.brand==='Nissan');
const producedIssues=issueFixture.issues.filter(i=>i.code==='independent_lists'),expectedIssues=oldNissan.closureIssues.filter(i=>i.code==='independent_lists'),liveIssues=liveNissan.closureIssues.filter(i=>i.code==='independent_lists');
assert.equal(producedIssues.length,1);assert.equal(expectedIssues.length,1);assert.equal(liveIssues.length,1);
const producedIssue=producedIssues[0],expectedIssue=expectedIssues[0],liveIssue=liveIssues[0];
assert.deepEqual(Object.keys(expectedIssue).sort(),['code','reason']);
assert.deepEqual(Object.keys(producedIssue).sort(),['brand','code','reason','reference']);
assert.deepEqual(Object.keys(liveIssue).sort(),['brand','code','reason','reference']);
const issueOwnership=[];
for(const property of ['brand','reference']){
 const actual=Object.getOwnPropertyDescriptor(liveIssue,property),producer=Object.getOwnPropertyDescriptor(producedIssue,property);
 for(const descriptor of [actual,producer]){assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value'));assert.equal(descriptor.value,undefined);}
 assert.deepEqual(actual,producer);assert(!Object.hasOwn(expectedIssue,property));
 issueOwnership.push({property,ownUndefined:true,enumerable:true,producer:'actual buildMarketReconciliation → add(code,reason) creates both optional own properties; pinned m1-reconciliation.ts'});
}
write('selected-before-c1-issue-producer',{fixtureRegistry:emptyRegistry,fixtureCars:[],fixtureInventory:issueFixtureInventory,asOf:normal.asOf,issue:producedIssue,exactOwnership:issueOwnership});
assert.deepEqual(readJson(out+'/selected-before-c1-issue-producer.json').issue,expectedIssue);
const expectedLiveNissan=structuredClone(oldNissan),issueIndex=expectedLiveNissan.closureIssues.findIndex(i=>i.code==='independent_lists');
assert.equal(issueIndex,liveNissan.closureIssues.findIndex(i=>i.code==='independent_lists'));
expectedLiveNissan.closureIssues[issueIndex]=producedIssue;assert.deepEqual(liveNissan,expectedLiveNissan);
assert.deepStrictEqual(selectedBefore.reconciliation.issues[0],producedIssue);
const beforeReportWritten=structuredClone(selectedBefore),beforeReportOmissions=[];
for(const [pointer,live,clone]of [
 ['/selectedBefore/reconciliation/issues/0',selectedBefore.reconciliation.issues[0],beforeReportWritten.reconciliation.issues[0]],
 ['/selectedBefore/brandProgress/0/closureIssues/0',liveNissan.closureIssues[0],beforeReportWritten.brandProgress[0].closureIssues[0]],
]){
 assert.deepStrictEqual(live,producedIssue);
 for(const property of ['brand','reference']){assert.deepStrictEqual(Object.getOwnPropertyDescriptor(live,property),Object.getOwnPropertyDescriptor(producedIssue,property));beforeReportOmissions.push(pointer+'/'+property);delete clone[property];}
}
assertDeclaredJson(selectedBefore,'/selectedBefore',new Set(beforeReportOmissions));assert.deepStrictEqual(selectedBefore,selectedBeforeSnapshot);
write('selected-before-report',selectedBefore);assert.deepStrictEqual(readJson(out+'/selected-before-report.json'),beforeReportWritten);assert.deepStrictEqual(beforeReportWritten.brandProgress[0],oldNissan);

write('selected-freshness-producer-proof',{reads,actualSelectedFeatureProducers:producerReceipts,before:selectedBefore.ageing,after:selectedAfter.ageing,otherSelectedFeaturesFromAcceptedParity:true});
const peer=(rows,key='carId')=>rows.filter(r=>!selectedIds.has(r[key]));
const deep=(rows,key='carId')=>rows.filter(r=>selectedIds.has(r[key]));
const pct=(n,d)=>d?Math.round(n/d*1000)/10:null;
const catalogueOrder=new Map(completeBefore.map((car,index)=>[car.id,index]));
assert.equal(catalogueOrder.size,430);assert.deepStrictEqual(completeAfter.map(car=>car.id),completeBefore.map(car=>car.id));
const recordOrder=new Map(inventory.records.map((row,index)=>[inventoryRecordId(row),index]));
const leadOrder=new Map(inventory.unverifiedLeads.map((row,index)=>[inventoryRecordId(row),index]));
assert.equal(recordOrder.size,inventory.records.length);assert.equal(leadOrder.size,inventory.unverifiedLeads.length);
function orderedRows(rows,order,key='carId'){
 assert.equal(new Set(rows.map(row=>row[key])).size,rows.length);
 for(const row of rows)assert(order.has(row[key]),'Row lacks producer input identity '+row[key]);
 return [...rows].sort((a,b)=>order.get(a[key])-order.get(b[key]));
}
function orderedAgeing(rows){
 assert.equal(new Set(rows.map(row=>JSON.stringify([row.carId,row.kind,row.key]))).size,rows.length);
 for(const row of rows){assert(catalogueOrder.has(row.carId));assert(['fact','availability','equipment'].includes(row.kind));}
 // Actual freshnessEntries finishes all cars' facts/availability before iterating features.
 // Each already accepted same-car subsequence is preserved by stable sort; peer and Nissan identities are disjoint.
 return [...rows].sort((a,b)=>(a.kind==='equipment'?1:0)-(b.kind==='equipment'?1:0)||catalogueOrder.get(a.carId)-catalogueOrder.get(b.carId));
}
const fullArrayOrderProof=[];

const expected=structuredClone(baseline);
assert.deepEqual([normal.allCatalogueVersions,normal.tierOneVersions,normal.onSaleVersions],[430,353,312]);
assert.equal(normal.asOf,'2026-10-15');
assert.deepEqual(normal.brandProgress.filter(b=>b.brand!=='Nissan'),baseline.brandProgress.filter(b=>b.brand!=='Nissan'));
const newNissan=selectedAfter.brandProgress.find(b=>b.brand==='Nissan');
assert.deepEqual(normal.brandProgress.find(b=>b.brand==='Nissan'),newNissan);
expected.brandProgress=baseline.brandProgress.map(b=>b.brand==='Nissan'?newNissan:b);
const beforeSourceIndex=new Map(base.sources.map(source=>[source.id,source])),afterSourceIndex=new Map(afterSources.map(source=>[source.id,source]));
const reasonCounts=(cars,sources,key)=>{
 const sourceIndex=sources===base.sources?beforeSourceIndex:afterSourceIndex;
 const counts=new Map();for(const car of cars){const cell=reports.coreFact(car,key),grade=reports.existingGrade(cell.fact,reports.hasValue(cell.fact?.value),sources,normal.asOf,sourceIndex);
 if(grade!=='Confirmed'){const reason=cell.ungraded?'Drive value exists without a per-fact grade':reports.gradePattern(cell.fact,cell.issue,grade);counts.set(reason,(counts.get(reason)||0)+1);}}
 return counts;
};
const onSaleBefore=completeBefore.filter(reports.isTierOne).filter(reports.isOnSale),onSaleAfter=completeAfter.filter(reports.isTierOne).filter(reports.isOnSale);
assert.equal(onSaleBefore.length,312);assert.equal(onSaleAfter.length,312);
const completeBeforeCore=reports.coreCoverage(onSaleBefore,base.sources,normal.asOf,beforeSourceIndex);
const completeAfterCore=reports.coreCoverage(onSaleAfter,afterSources,normal.asOf,afterSourceIndex);
assert.deepStrictEqual(completeBeforeCore.core,baseline.core);assert.deepStrictEqual(completeBeforeCore.gaps,baseline.gaps);
expected.core=completeAfterCore.core;expected.gaps=completeAfterCore.gaps;
const explanations=[];
for(const [i,old]of baseline.core.entries()){
 const b=selectedBefore.core[i],a=selectedAfter.core[i],next=expected.core[i];assert.equal(old.key,b.key);assert.equal(a.key,b.key);assert.equal(next.key,old.key);
 assert.equal(next.filled,old.filled-b.filled+a.filled);assert.equal(next.total,old.total);
 for(const grade of Object.keys(old.grades))assert.equal(next.grades[grade],old.grades[grade]-b.grades[grade]+a.grades[grade]);
 const beforeReasons=[...reasonCounts(onSaleBefore,base.sources,old.key)],afterReasons=[...reasonCounts(onSaleAfter,afterSources,old.key)];
 explanations.push({key:old.key,beforeFullReasons:beforeReasons,afterFullReasons:afterReasons,beforeExplanation:old.explanation,afterExplanation:next.explanation,producer:'Actual coreCoverage and gradePattern with complete digest-verified cars, source registry and original catalogue order; no truncated-tail inference'});
}
write('global-core-complete-reason-inventory',explanations);
const groupKey=g=>JSON.stringify([g.vehicleClass,g.basis,g.unit]);
const discoveryPath=repo+'/src/lib/discovery.ts',discoverySource=fs.readFileSync(discoveryPath,'utf8');
const comparatorText='(a, b) =>\n        b.entries.length - a.entries.length || a.basis.localeCompare(b.basis)';
assert.equal(discoverySource.split(comparatorText).length,2);
const groupOrder=vm.runInThisContext('('+comparatorText+')',{filename:discoveryPath+':actual-group-order-excerpt'});
const {attributes}=require('./src/lib/discovery.ts');
const stageRankings=readJson('/tmp/nissan-packet/full-stage-v1/output/global-ranking-comparison.json');
const beforeCarMap=new Map(completeBefore.map(car=>[car.id,car])),afterCarMap=new Map(completeAfter.map(car=>[car.id,car]));
const beforeDigestMap=new Map(acceptedStageDigests.candidate30.map(row=>[row.id,row])),afterDigestMap=new Map(acceptedStageDigests.candidate31.map(row=>[row.id,row]));
const alphabeticalSource='unranked.sort((a, b) =>\n    `${a.car.brand} ${a.car.model} ${a.car.trim}`.localeCompare(\n      `${b.car.brand} ${b.car.model} ${b.car.trim}`,\n    ),\n  );';
assert.equal(discoverySource.split(alphabeticalSource).length,2);
const alphabetical=(a,b)=>{const ac=afterCarMap.get(a.carId),bc=afterCarMap.get(b.carId);return `${ac.brand} ${ac.model} ${ac.trim}`.localeCompare(`${bc.brand} ${bc.model} ${bc.trim}`);};
const rankingBindings=[];
for(const stage of stageRankings){
 const old=stage.completeOrderedBefore,next=stage.completeOrderedAfter,selected=stage.completeSelectedRecords;
 const attribute=attributes.find(row=>row.key===stage.attribute);assert(attribute);
 for(const [phase,records,carMap,digestMap]of [['before',old,beforeCarMap,beforeDigestMap],['after',next,afterCarMap,afterDigestMap],['selected',selected,afterCarMap,afterDigestMap]]){
  for(const row of [...records.groups.flatMap(g=>g.entries),...records.excluded,...records.unranked]){
   assert.deepEqual(row.carDigest,digestMap.get(row.carId));
   if(Object.hasOwn(row,'fact'))assert.deepEqual(row.fact,carMap.get(row.carId).facts[stage.attribute]);
  }
  for(const group of records.groups){
   assert.deepEqual([...group.entries].sort((a,b)=>(Number(a.fact.value)-Number(b.fact.value))*(attribute.direction==='lower'?1:-1)||a.carId.localeCompare(b.carId)),group.entries);
   for(const row of group.entries){
    assert.equal(row.rank,group.entries.findIndex(other=>Number(other.fact.value)===Number(row.fact.value))+1);
    assert.equal(row.tied,group.entries.filter(other=>Number(other.fact.value)===Number(row.fact.value)).length>1);
   }
  }
  rankingBindings.push({attribute:stage.attribute,phase,completeGroups:records.groups.length,completeEntries:records.groups.reduce((n,g)=>n+g.entries.length,0),completeExcluded:records.excluded.length,completeUnranked:records.unranked.length,allCarDigestsAndFactsExact:true,allRankAndTiedFieldsExact:true});
 }
 const buckets=new Map();
 for(const group of old.groups){const entries=group.entries.filter(row=>!selectedIds.has(row.carId));if(entries.length)buckets.set(groupKey(group),{...group,entries});}
 for(const group of selected.groups){const key=groupKey(group),existing=buckets.get(key);if(existing)existing.entries.push(...group.entries);else buckets.set(key,{...group,entries:[...group.entries]});}
 const memberGroup=new Map();for(const [key,group]of buckets)for(const row of group.entries){assert(!memberGroup.has(row.carId));memberGroup.set(row.carId,key);}
 const insertion=[];for(const car of completeAfter){const key=memberGroup.get(car.id);if(key&&!insertion.includes(key))insertion.push(key);}
 const expectedGroups=insertion.map(key=>buckets.get(key));
 for(const group of expectedGroups){group.entries.sort((a,b)=>(Number(a.fact.value)-Number(b.fact.value))*(attribute.direction==='lower'?1:-1)||a.carId.localeCompare(b.carId));group.entries=group.entries.map(row=>({...row,rank:group.entries.findIndex(other=>Number(other.fact.value)===Number(row.fact.value))+1,tied:group.entries.filter(other=>Number(other.fact.value)===Number(row.fact.value)).length>1}));}
 expectedGroups.sort(groupOrder);assert.deepEqual(next.groups,expectedGroups);
 const excludedById=new Map([...old.excluded.filter(row=>!selectedIds.has(row.carId)),...selected.excluded].map(row=>[row.carId,row]));
 assert.deepEqual(next.excluded,completeAfter.filter(car=>excludedById.has(car.id)).map(car=>excludedById.get(car.id)));
 assert.deepEqual(next.unranked,[...old.unranked.filter(row=>!selectedIds.has(row.carId)),...selected.unranked].sort(alphabetical));
 for(const group of old.groups){const nextGroup=next.groups.find(row=>groupKey(row)===groupKey(group));assert.deepEqual(nextGroup?.entries.filter(row=>!selectedIds.has(row.carId)).map(row=>row.carId)??[],group.entries.filter(row=>!selectedIds.has(row.carId)).map(row=>row.carId));}
 assert.deepEqual(next.excluded.filter(row=>!selectedIds.has(row.carId)),old.excluded.filter(row=>!selectedIds.has(row.carId)));
 assert.deepEqual(next.unranked.filter(row=>!selectedIds.has(row.carId)),old.unranked.filter(row=>!selectedIds.has(row.carId)));
}
function projectRecords(records,inputCars){
 const ids=new Set(inputCars.map(car=>car.id)),index=new Map(inputCars.map((car,i)=>[car.id,i]));
 const groups=records.groups.map(g=>({...g,entries:g.entries.filter(row=>ids.has(row.carId))})).filter(g=>g.entries.length);
 groups.sort((a,b)=>Math.min(...a.entries.map(row=>index.get(row.carId)))-Math.min(...b.entries.map(row=>index.get(row.carId))));
 const insertionKeys=groups.map(groupKey);groups.sort(groupOrder);
 return {groups:groups.map(g=>({vehicleClass:g.vehicleClass,basis:g.basis,unit:g.unit,count:g.entries.length})),rankedIds:groups.flatMap(g=>g.entries.map(row=>row.carId)),excluded:records.excluded.filter(row=>ids.has(row.carId)).map(({carDigest,...row})=>row),insertionKeys};
}
const rankingGroupProof=[];
expected.rankings=baseline.rankings.map((old,i)=>{
 const actual=normal.rankings[i],beforeSelected=selectedBefore.rankings[i],afterSelected=selectedAfter.rankings[i],stage=stageRankings.find(row=>row.attribute===old.key);assert(stage);
 assert.equal(actual.key,old.key);assert.equal(beforeSelected.key,old.key);assert.equal(afterSelected.key,old.key);
 const b=projectRecords(stage.completeOrderedBefore,onSaleBefore),a=projectRecords(stage.completeOrderedAfter,onSaleAfter),selectedProjection=projectRecords(stage.completeSelectedRecords,after);
 assert.deepEqual(b.groups,old.groups);assert.deepEqual(b.rankedIds,old.rankedIds);assert.deepEqual(b.excluded,old.excluded);
 assert.deepEqual(selectedProjection.groups,afterSelected.groups);assert.deepEqual(selectedProjection.rankedIds,afterSelected.rankedIds);assert.deepEqual(selectedProjection.excluded,afterSelected.excluded);
 assert.deepEqual(a.excluded,orderedRows([...peer(b.excluded),...afterSelected.excluded],catalogueOrder));
 assert.equal(a.rankedIds.length,old.ranked-beforeSelected.ranked+afterSelected.ranked);
 assert.equal(a.rankedIds.length+a.excluded.length,312);
 const exclusionReasons={};for(const row of a.excluded)exclusionReasons[row.reason]=(exclusionReasons[row.reason]||0)+1;
 fullArrayOrderProof.push({path:'rankings/'+old.key+'/excluded',producer:'Full digest-bound stage exclusions filtered in actual input catalogue order',beforeRows:b.excluded.length,afterRows:a.excluded.length,completeEquality:true});
 rankingGroupProof.push({key:old.key,unchangedPeerMembershipAndRelativeGroupOrder:true,selectedBeforeRanked:beforeSelected.ranked,selectedAfterRanked:afterSelected.ranked,beforeInsertionKeys:b.insertionKeys,afterInsertionKeys:a.insertionKeys,actualProductionGroupComparator:true,completeBeforeAndAfterRecordBindings:true});
 return {...old,ranked:a.rankedIds.length,percent:pct(a.rankedIds.length,312),rankedIds:a.rankedIds,passes:a.rankedIds.length/312>=0.9,groups:a.groups,excluded:a.excluded,exclusionReasons};
});
write('ranking-group-order-and-peer-proof',{sourcePath:discoveryPath,sourceSha256:fileHash(discoveryPath),exactComparatorText:comparatorText,fullStageRecordPath:'/tmp/nissan-packet/full-stage-v1/output/global-ranking-comparison.json',fullStageRecordSha256:fileHash('/tmp/nissan-packet/full-stage-v1/output/global-ranking-comparison.json'),completeBindings:rankingBindings,groups:rankingGroupProof});
assert.deepStrictEqual(peer(normal.gaps),peer(baseline.gaps));assert.deepStrictEqual(deep(normal.gaps),selectedAfter.gaps);assert.deepStrictEqual(normal.gaps,expected.gaps);
assert.deepStrictEqual(orderedRows(baseline.summaryGaps,catalogueOrder),baseline.summaryGaps);
expected.summaryGaps=orderedRows([...peer(baseline.summaryGaps),...selectedAfter.summaryGaps],catalogueOrder);
assert.deepStrictEqual(normal.summaryGaps,expected.summaryGaps);
fullArrayOrderProof.push({path:'summaryGaps',producer:'Tier 1 input-catalogue filter/map order',beforeRows:baseline.summaryGaps.length,afterRows:expected.summaryGaps.length,completeEquality:true});
for(const [key,order]of [['missingModels',recordOrder],['unresolvedLeads',leadOrder]]){
 assert.deepStrictEqual(orderedRows(baseline[key],order,'id'),baseline[key]);
 const peers=baseline[key].filter(row=>row.brand!=='Nissan'),selectedRows=selectedAfter[key];
 assert(selectedRows.every(row=>row.brand==='Nissan'));
 expected[key]=orderedRows([...peers,...selectedRows],order,'id');assert.deepStrictEqual(normal[key],expected[key]);
 fullArrayOrderProof.push({path:key,producer:'Actual inherited inventory filter/map traversal via inventoryRecordId',beforeRows:baseline[key].length,afterRows:expected[key].length,completeEquality:true});
}
const c1=readJson('/tmp/nissan-packet/full-stage-v1/output/global-c1-comparison.json');
assert.deepEqual(baseline.reconciliation,c1.before);expected.reconciliation=c1.after;
expected.pairedOnSale=baseline.pairedOnSale-selectedBefore.pairedOnSale+selectedAfter.pairedOnSale;
expected.pairedOnSalePercent=pct(expected.pairedOnSale,normal.onSaleVersions);
const intersect=rows=>rows[0].rankedIds.filter(id=>rows.every(r=>r.rankedIds.includes(id))).length;
assert.equal(baseline.inAllRankings,intersect(baseline.rankings));expected.inAllRankings=intersect(expected.rankings);expected.inAllRankingsPercent=pct(expected.inAllRankings,normal.onSaleVersions);
const reviewedCoreCells=expected.core.reduce((s,c)=>s+c.reviewed,0),totalCoreCells=normal.onSaleVersions*17;
expected.grading={reviewedCoreCells,totalCoreCells,reviewedPercent:pct(reviewedCoreCells,totalCoreCells)};
expected.gradeNote=baseline.gradeNote.replace(`${baseline.grading.reviewedCoreCells}/${baseline.grading.totalCoreCells}`,`${reviewedCoreCells}/${totalCoreCells}`);
for(const [key,property,negate]of [['brandsResearchCompleted','researchCompleted',false],['brandsResearchRemaining','researchCompleted',true],['brandsDone','done',false],['brandsRemaining','done',true]])expected[key]=expected.brandProgress.filter(b=>negate?!b[property]:b[property]).map(b=>b.brand);
for(const key of ['overdue','invalid','excludedHistory']){
 assert.deepStrictEqual(orderedAgeing(baseline.ageing[key]),baseline.ageing[key]);
 expected.ageing[key]=orderedAgeing([...peer(baseline.ageing[key]),...selectedAfter.ageing[key]]);
 assert.deepStrictEqual(normal.ageing[key],expected.ageing[key]);
 fullArrayOrderProof.push({path:'ageing/'+key,producer:'freshnessEntries fact/availability phase in catalogue order, then feature phase in catalogue order; accepted same-car order retained',beforeRows:baseline.ageing[key].length,afterRows:expected.ageing[key].length,completeEquality:true});
}
write('full-array-producer-order-proof',fullArrayOrderProof);
expected.ageing.dueNext30Days=baseline.ageing.dueNext30Days-selectedBefore.ageing.dueNext30Days+selectedAfter.ageing.dueNext30Days;
const rc=expected.reconciliation,core=expected.core,ranks=expected.rankings,age=expected.ageing;
expected.criteria=[
 {id:'C1',pass:rc.pass,detail:`${rc.reviewedModels} exact current model lists reviewed; ${rc.settledListEntryCount}/${rc.listEntryCount} entries settled across ${rc.independentListCount} independent lists; ${rc.issues.length} blockers. ${expected.missingModels.length} unmatched audit models; ${expected.unresolvedLeads.length} unresolved leads.`,sources:baseline.criteria[0].sources},
 {id:'C2',pass:core.every(c=>c.passes),detail:`${core.filter(c=>c.passes).length}/${core.length} core fields meet their target; ${expected.gaps.length} version/field gaps, each with a reason in --details or --json.`},
 {id:'C3',pass:core.every(c=>c.gradingPasses&&(c.confirmedPercent>=50||!!c.explanation)),detail:`${reviewedCoreCells}/${totalCoreCells} core cells have earned reviews; ${core.filter(c=>c.confirmedPercent!==null&&c.confirmedPercent<50).length} fields below half Confirmed have patterns in --details. No grade quota is applied.`},
 {id:'C4',pass:expected.tierOneVersions>0&&expected.summaryGaps.length===0,detail:`${expected.tierOneVersions-expected.summaryGaps.length}/${expected.tierOneVersions} Tier 1 versions have both a supported strength and trade-off (${expected.pairedOnSale}/${normal.onSaleVersions} on sale).`},
 {id:'C5',pass:ranks.every(r=>r.passes),detail:`${ranks.filter(r=>r.passes).length}/6 ranking lists reach 90% of on-sale Tier 1 versions; measurement groups stay separate.`},
 {id:'C6',pass:age.overdue.length===0&&age.invalid.length===0,detail:`${age.overdue.length} aged claims and ${age.invalid.length} invalid/future/undated claims across all Tier 1 versions, including availability and equipment. Model-year changes still require a recorded review.`}
];
write('expected-versus-normal-diff',differences(expected,normal));
assert.deepEqual(normal,expected,'Every report leaf must equal the explicitly accounted expectation; no ignored global/peer fields');
assertDeclaredJson(completeBefore,'/completeBefore',new Set());assert.deepStrictEqual(carDigests(completeBefore),acceptedStageDigests.candidate30);assertDeclaredJson(completeAfter,'/completeAfter',new Set());assert.deepStrictEqual(carDigests(completeAfter),acceptedStageDigests.candidate31);
assertDeclaredJson(base.sources,'/beforeSources',new Set());assertDeclaredJson(afterSources,'/afterSources',new Set());assert.deepStrictEqual(digestRows(afterSources),readJson('/tmp/nissan-packet/full-stage-v1/output/research-field-digests.json').candidate31.sources);assert.deepStrictEqual(digestRows(base.sources),beforeSourceSnapshot);assert.deepStrictEqual(base,baseSnapshot);assert.deepStrictEqual(packet,packetSnapshot);
assert.deepStrictEqual(before,selectedSnapshots.before);assert.deepStrictEqual(after,selectedSnapshots.after);assert.deepStrictEqual(packs,selectedSnapshots.packs);assert.deepStrictEqual(selectedResult,selectedSnapshots.result);assert.deepStrictEqual(beforeFeatures,beforeFeatureSnapshot);assert.deepStrictEqual(selectedBefore,selectedBeforeSnapshot);assert.equal(defaultCalls,0);
for(const path of ['src/lib/data.ts','src/lib/catalogue.ts','src/lib/research.ts'])assert(!require.cache[repo+'/'+path]);
checkNormalInputs();
fs.writeFileSync(out+'/normal-coverage-formatted.txt',reports.formatCoverageReport(normal)+'\n',{flag:'wx'});
write('result',{passed:true,normalReportSha256:fileHash(normalPath),baselineSha256:fileHash(baselinePath),exhaustiveDifferences:differences(baseline,normal).length,allNormalLeavesAccounted:true,peerBrandObjectsExact:normal.brandProgress.filter(b=>b.brand!=='Nissan').length,peerRankRelativeOrderWithinMeasurementGroupsExact:true,groupOrderEqualsActualProducer:true,peerCompleteCarDigestsExact:426,globalC1EqualsAcceptedStage:true,ordinaryProductionReportRanSeparately:true,normalReportSubstituted:false,selectedOldFeatureProducers:276,peerFeaturesReplayed:0,completeCoreReasonInventory:true,broadFeatureReplay:false,defaultLoaderCalls:0,selectedFreshnessBefore:selectedBefore.ageing,selectedFreshnessAfter:selectedAfter.ageing,counts:{catalogue:430,tierOne:353,onSale:312}});
console.log(JSON.stringify({passed:true,result:out+'/result.json',sha256:fileHash(out+'/result.json')}));
