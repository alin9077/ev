from pathlib import Path
import difflib,ast
O=Path('/tmp/nissan-packet/report-comparison-plan-v1');P=Path('/tmp/renault-packet/report-comparison-v4')
s=(P/'compare-report.mjs').read_text();original=s
s=s.replace('/tmp/renault-packet/report-comparison-v4',str(O)).replace('/tmp/renault-packet','/tmp/nissan-packet').replace('/tmp/renault-research','/tmp/nissan-research').replace('Renault','Nissan').replace('renault','nissan')
s=s.replace('CUPRA29','Renault30').replace('acceptedCupraDigests','acceptedRenaultDigests')
s=s.replace("const baselinePath='/tmp/cupra-packet/report-comparison-v1/normal-coverage-asof-2026-10-15/stdout.log'", "const baselinePath='/tmp/renault-packet/report-comparison-v4/normal-coverage-asof-2026-10-15/stdout.log'")
s=s.replace('66006b9e8b78d5078a98bee9418466630bf4962a9554e3e8e5bfeddebb6f1579','093e0d243e89173bd39d03d8f5e1948c550df09d37b435b018213f895b9894a6').replace('exhaustive-normal-versus-cupra-diff','exhaustive-normal-versus-renault-diff')
s=s.replace('/selected-preflight-v5/','/selected-preflight-v4/').replace('6f89f00f147c45c5e1afdff24f8597da3b980d6f5230cd1ba5fb663754464605','6aa651b6932721365dfdee38c92fd19d9dd62cf50cb42ec6c348d495f00c9585').replace("'5 years'","'1 year'")
s=s.replace("const acceptedRenaultDigests=readJson('/tmp/cupra-packet/full-stage-v2/output/car-digest-comparison.json')", "const acceptedRenaultDigests=readJson('/tmp/renault-packet/full-stage-v1/output/car-digest-comparison.json')")
s=s.replace("readJson('/tmp/cupra-packet/full-stage-v2/output/research-field-digests.json')", "readJson('/tmp/renault-packet/full-stage-v1/output/research-field-digests.json')")
s=s.replace('.candidate30','.candidate31').replace('.candidate29','.candidate30')
s=s.replace('brandUpdatePackets.length,30','brandUpdatePackets.length,31').replace('brandUpdatePackets.slice(0,29)','brandUpdatePackets.slice(0,30)')
s=s.replace(" ['candidate29','/tmp/cupra-packet/full-stage-v2/output/selected-after-cars.json'],", " ['candidate29','/tmp/cupra-packet/full-stage-v2/output/selected-after-cars.json'],\n ['candidate30','/tmp/renault-packet/full-stage-v1/output/selected-after-cars.json'],")
assert "const prep='/tmp/nissan-packet/report-comparison-plan-v1';" in s
assert "const qa='/tmp/nissan-packet/report-comparison-plan-v1';" in s
with (O/'compare-report.mjs').open('x') as f:f.write(s)
with (O/'renault-to-nissan-comparator.patch').open('x') as f:f.write(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile=str(P/'compare-report.mjs'),tofile=str(O/'compare-report.mjs'))))
c=(P/'close-comparator-inputs.py').read_text().replace('/tmp/renault-packet/full-stage-v1','/tmp/nissan-packet/full-stage-v1').replace("len(packets)==30 and packets[-1]=='renault-2026-10-15.json'","len(packets)==31 and packets[-1]=='nissan-2026-10-15.json'").replace('All 30 dynamic registry','All 31 dynamic registry')
ast.parse(c)
with (O/'close-comparator-inputs.py').open('x') as f:f.write(c)
print('Prepared comparator and deferred closure collector only; no runtime imports.')
