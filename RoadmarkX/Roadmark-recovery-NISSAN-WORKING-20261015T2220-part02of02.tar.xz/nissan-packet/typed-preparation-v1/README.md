Nissan typed preparation v1

Four retained ARIYA identities, no additions or identity rewrite. Exact beforeguards, source snapshots, 68 core observations (65 Confirmed / three AC Check), three canonical shared terms and four summary pairs. Maker MSRP uses rung 1 before on-road costs; temporary October dealer-republished amounts use separate Reported offers. Current grade coverage resolves the inherited ARIYA family; LEAF and overseas future models stay separately dispositioned.

Confidence and comparison compatibility are separate. Usable batteries, exact combined WLTP, explicit mirror state and 10–80% window have stated bases. Cargo remains Confirmed declared-to-roof but unknown-method/unranked. FWD AC and masses retain specific current maker applicability disagreements. Warranty and roadside base/conditional policy limits are explicit, without implying actual service eligibility.

Preparation only: no runtime/helper/consumer/compiler/full-loader execution. Independent typed review and separate explicit runtime grant required. Reviewed earlier source versions remain unchanged.
