/** Prepared only: selected actual consumers for exactly four retained Nissan Tier 1 rows. */
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readJson,fileHash,streamRows,digestRows} from '/tmp/xpeng-staging-plan/baseline-io.mjs';
import {assertDeclaredJson} from '/tmp/mercedes-staging-plan/consumer-preparation/v5/feature-json-parity.mjs';
const repo='/workspace/scratch/586427eef9f2/roadmark-104';
const out='/tmp/nissan-packet/selected-preflight-v2';
assert.equal(process.argv[2],'--root-execution-granted');
assert.equal(process.cwd(),repo);
assert(!fs.existsSync(out+'/result.json'));
const pins=readJson(out+'/source-pins.json');
function checkPins(){for(const p of pins){assert.equal(fs.statSync(p.path).size,p.bytes);assert.equal(fileHash(p.path),p.sha256,p.path);}}
checkPins();
const expected=readJson(out+'/expected-review.json');
const packetPath=expected.packet.path;
assert.equal(fileHash(packetPath),expected.packetSha256);
const packet=readJson(packetPath),packetSnapshot=structuredClone(packet);
const accepted=readJson('/tmp/mercedes-staging-plan/consumer-preparation/v5/manifests/report-v5.json');
const index=readJson('/tmp/mercedes-staging-plan/staging-preparation/staging-artifacts/canonical-v1/staged-storage-index.json');
const before=readJson('/tmp/nissan-research/retained-before-cars-v1.json');
const receipt=readJson('/tmp/nissan-research/retained-selection-proof-v1.json');
const acceptedDigests=readJson(receipt.acceptedIndex)[receipt.stage];
assert.equal(fileHash(receipt.acceptedIndex),receipt.indexSha256);
const beforeSnapshot=structuredClone(before),selected=new Set(before.map(c=>c.id)),modelIds=new Set(before.map(c=>c.modelId));
assert.deepEqual([...selected],expected.currentListIds);
assert.equal(before.length,4);assert.equal(acceptedDigests.length,430);assert.equal(receipt.stage,'candidate30');
for(const car of before){
 const recorded=receipt.checks.find(x=>x.expected.id===car.id)?.expected,acceptedRow=acceptedDigests.find(x=>x.id===car.id),actual=digestRows([car]);
 assert(recorded&&acceptedRow);
 for(const p of [recorded,acceptedRow]){assert.equal(actual.sha256,p.sha256);assert.equal(actual.bytes,p.bytes);}
}
const base={},reads=[];
// Stream existing research fields; retain only selected variants/features, never construct the catalogue.
for(const [key,ref]of Object.entries(index.research)){
 const values=[];
 await streamRows(accepted.anchors,ref,row=>{
  const keep=['variants','feature_evidence_variant_context'].includes(key)?selected.has(row.id):['feature_evidence','trim_equipment','update_eligibility'].includes(key)?selected.has(row.variant_id):key==='models'?modelIds.has(row.id):true;
  if(keep)values.push(row);
 });
 base[key]=ref.array?values:values[0];
 reads.push({field:key,inputRows:ref.rows,selectedRows:values.length,sha256:ref.sha256});
}
assert.equal(base.variants.length,4);assert.equal(base.feature_evidence.length,276);
assert.equal(base.feature_evidence_variant_context.length,4);assert.equal(base.criteria.length,69);
const require=createRequire(repo+'/package.json');
const brand=require('./src/lib/brand-updates.ts');
const {prepareBrandResearch,applyBrandUpdates,brandVersionSnapshot,applyBrandFeatureUpdates,applyBrandTermFeatures}=brand;
const {brandUpdatePackets}=require('./src/lib/brand-update-registry.ts');
assert.equal(brandUpdatePackets.length,30);assert.equal(brandUpdatePackets.at(-1).id,'m1-renault-2026-10-15');
for(const prior of brandUpdatePackets){
 assert.notEqual(prior.brand,'Nissan');
 for(const row of [...prior.facts,...prior.variants,...prior.versionGuards,...prior.availability,...prior.summaries,...(prior.features??[]),...(prior.configurationUpdates??[])])assert(!selected.has(row.variantId??row.id));
 for(const term of prior.brandTerms??[])assert(term.applicableVariantIds.every(id=>!selected.has(id)));
}
const baseSnapshot=structuredClone(base);
assert.equal(packet.versionGuards.length,4);assert.equal(packet.facts.length,176);assert.equal(packet.brandTerms.length,3);assert.equal(packet.brandTerms.reduce((n,t)=>n+t.applicableVariantIds.length,0),12);assert.equal(packet.summaries.length,4);assert.equal(packet.availability.length,4);
const data=prepareBrandResearch(base,[packet]);
const dataSnapshot=structuredClone(data);
assert.deepStrictEqual(base,baseSnapshot);assert.deepStrictEqual(before,beforeSnapshot);assert.deepStrictEqual(packet,packetSnapshot);
const after=applyBrandUpdates(before,data,[packet]);
const afterSnapshot=structuredClone(after);
assert.equal(after.length,4);assert.equal(data.variants.length,4);assert.equal(data.feature_evidence.length,276);
assert.deepStrictEqual(base,baseSnapshot);assert.deepStrictEqual(before,beforeSnapshot);assert.deepStrictEqual(data,dataSnapshot);assert.deepStrictEqual(packet,packetSnapshot);
for(const guard of packet.versionGuards)assert.deepEqual(brandVersionSnapshot(before.find(c=>c.id===guard.variantId)),guard.before);
for(const edit of packet.facts){assert.deepEqual(before.find(c=>c.id===edit.variantId).facts[edit.after.key]??null,edit.before);assert.deepEqual(after.find(c=>c.id===edit.variantId).facts[edit.after.key],edit.after);}
for(const term of packet.brandTerms)for(const id of term.applicableVariantIds){assert.deepEqual(before.find(c=>c.id===id).facts[term.key]??null,term.before[id]);assert.deepEqual(after.find(c=>c.id===id).facts[term.key],term.fact);}
for(const car of after){
 const prior=before.find(c=>c.id===car.id);
 assert.deepStrictEqual(car.configurationEvidence,prior.configurationEvidence);
 assert.deepStrictEqual(brandVersionSnapshot(car),brandVersionSnapshot(prior));
}
for(const key of ['variants','models','versionUpdates','features','configurationUpdates'])assert.equal(packet[key].length,0);
for(const edit of packet.availability){
 const b=before.find(c=>c.id===edit.variantId),a=after.find(c=>c.id===edit.variantId);
 assert.deepEqual({availability:b.availability,evidence:b.availabilityEvidence},edit.before);
 assert.deepEqual({availability:a.availability,evidence:a.availabilityEvidence},edit.after);
}
for(const edit of packet.summaries){
 const car=after.find(c=>c.id===edit.variantId);
 for(const side of ['strength','tradeoff']){
  assert.equal(car.buyerSummary[side].label,edit[side].label);assert.equal(car.buyerSummary[side].text,edit[side].text);
  const expectedFreshness=edit[side].dependencies.flatMap(({expected:f})=>[f.date,...f.sourceIds.map(id=>data.sources.find(source=>source.id===id).accessed_date)].map(checkedAt=>({checkedAt,key:f.key,...(f.modelYearChangedAt?{modelYearChangedAt:f.modelYearChangedAt}:{})})));
  assert.deepStrictEqual(car.buyerSummary[side].freshness,expectedFreshness);
  const expectedClauseSourceIds=[...new Set(edit[side].dependencies.flatMap(({expected:f})=>f.sourceIds))];
  assert.deepStrictEqual(car.buyerSummary[side].sourceIds,expectedClauseSourceIds);
  for(const dep of edit[side].dependencies){assert.deepEqual(car.facts[dep.key],dep.expected);assert.notEqual(dep.expected.value,null);assert.equal(dep.expected.issues.length,0);}
 }
 const expectedGuardSourceIds=[...new Set(['strength','tradeoff'].flatMap(side=>edit[side].dependencies.flatMap(({expected:f})=>f.sourceIds)))];
 assert.deepStrictEqual(car.buyerSummary.guardSourceIds,expectedGuardSourceIds);
 assert.deepStrictEqual(car.buyerSummary.expectedSourceSnapshots,packet.sources.filter(source=>expectedGuardSourceIds.includes(source.id)));
 assert.deepStrictEqual(car.buyerSummary.conditions,edit.conditions??[]);
 assert.equal(car.buyerSummary.checkedAt,packet.reviewedAt);
}
// Each selected-only mutation must hit its intended guard and leave its supplied inputs untouched.
const negativeProof=[];
function rejectMutation(name,mutate,pattern){
 const input={cars:structuredClone(before),research:structuredClone(data),packet:structuredClone(packet)};
 mutate(input);const snapshot=structuredClone(input);let error;
 try{applyBrandUpdates(input.cars,input.research,[input.packet]);}catch(caught){error=caught;}
 assert(error instanceof Error,`${name}: intended invalid input was accepted`);assert.match(error.message,pattern,`${name}: wrong rejection path`);
 assert.deepEqual(input,snapshot,`${name}: rejection mutated supplied inputs`);
 negativeProof.push({name,actualError:error.message,expectedErrorPattern:pattern.source,rejected:true,inputsUnchanged:true});
}
rejectMutation('exact identity guard',({packet:p})=>{p.versionGuards[0].before.trim+=' changed';},/Brand update: reviewed version changed:/);
rejectMutation('specific fact beforeguard',({packet:p})=>{p.facts[0].before.qualifications.push('changed beforeguard');},/Brand update: fact before snapshot changed:.*\/price_aud$/);
rejectMutation('shared warranty beforeguard',({packet:p})=>{p.brandTerms[0].before[p.versionGuards[0].variantId].value='changed beforeguard';},/Brand update: fact before snapshot changed:.*\/warranty$/);
rejectMutation('availability beforeguard',({packet:p})=>{p.availability[0].before.evidence.qualifications.push('changed beforeguard');},/Availability correction conflict .*reviewed snapshot changed or variant missing/);
rejectMutation('summary exact dependency',({packet:p})=>{p.summaries[0].strength.dependencies[0].expected.value=999;},/Brand update: summary dependency changed:.*\/dc_charge_time_min$/);
rejectMutation('source exact snapshot',({packet:p})=>{p.sources[0].title+=' changed';},/Brand update: source snapshot changed:/);
rejectMutation('earned grade provenance',({packet:p})=>{p.facts.find(row=>row.after.key==='range_km').after.gradeReview.overlayId='wrong-overlay';},/Brand update: invalid fact or unearned grade: range_km/);
assert.equal(negativeProof.length,7);assert.deepEqual(before,beforeSnapshot);assert.deepEqual(data,dataSnapshot);assert.deepEqual(packet,packetSnapshot);
const {compiledSource}=require('./tests/helpers/compiled-source.ts');
let defaultCalls=0;const forbidden=()=>{defaultCalls++;throw new Error('FORBIDDEN_DEFAULT_CATALOGUE_LOADER');};
const defaults={sourceResearch:forbidden,research:forbidden,catalogue:forbidden};
const factory=packets=>compiledSource('src/lib/evidence-consumers.ts',{'./brand-update-registry':{brandUpdatePackets:packets}}).createEvidenceConsumers(defaults);
const initial=factory(brandUpdatePackets),final=factory([...brandUpdatePackets,packet]);
const {hasEarnedBuyerGrade}=require('./src/lib/evidence-grading.ts');
const {factClaim,featureClaim,makeReport,reportMarkdown}=require('./src/lib/citable.ts');
const {availabilityReportClaim}=require('./src/lib/availability-corrections.ts');
const {buyerAvailabilityText}=require('./src/lib/buyer-availability.ts');
const {isOnSale,isCurrentListEligible,buildCoverageReport}=require('./scripts/reporting/reports.ts');
const {auditedFeature}=require('./src/lib/launch-evidence.ts');
const {applyFeatureRegrading}=require('./src/lib/evidence-regrading.ts');
const beforePacks={},afterPacks={},observations=[],claims=[],featureClaims=[],claimOmissions=[],producerProofs=[],frames=new Map();
for(const [phase,cars,consumer,research,packets]of [['before',before,initial,base,brandUpdatePackets],['after',after,final,data,[...brandUpdatePackets,packet]]])for(const car of cars){
 const input=consumer.sourceEffectiveFeatures(car,research),snap=structuredClone(input),regraded=applyFeatureRegrading(car,input,research.sources);
 assert.deepEqual(input,snap);
 const branded=applyBrandFeatureUpdates(car,regraded,research,packets),projected=applyBrandTermFeatures(car,branded,research.sources);
 frames.set(phase+'\0'+car.id,{input,regraded,branded,projected,research});
 producerProofs.push({phase,variantId:car.id,producer:'Actual sourceEffectiveFeatures -> applyFeatureRegrading -> applyBrandFeatureUpdates -> applyBrandTermFeatures',inputRows:input.length,outputRows:projected.length,inputUnchanged:true});
}
function observePack(car,pack,phase){
 const pointers=[];
 function visit(value,pointer){
  if(value===undefined){
   const match=pointer.match(/\/features\/(\d+)\/([^/]+)$/);assert(match,'Unexpected undefined outside feature: '+pointer);
   const rowIndex=Number(match[1]),property=match[2],feature=pack.features[rowIndex],descriptor=Object.getOwnPropertyDescriptor(feature,property);
   assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value')&&descriptor.value===undefined);
   const frame=frames.get(phase+'\0'+car.id),sourceRow=frame.input.find(f=>f.criterion===feature.criterion),regraded=frame.regraded.find(f=>f.criterion===feature.criterion),projected=frame.projected.find(f=>f.criterion===feature.criterion);
   assert(sourceRow&&regraded&&projected);assert.deepEqual(feature,projected);
   let producer;
   if(property==='gradeReviewStatus'){
    assert(feature.gradeReview);assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts earned retained-feature branch explicitly sets gradeReviewStatus undefined';
   }else if(property==='condition_label'){
    assert.equal(feature.buyerGrade,'check');assert(!Object.hasOwn(sourceRow,property)||sourceRow[property]===undefined);assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts Check branch retains source optional condition_label';
   }else if(property==='confirmation_needed'){
    assert.equal(feature.criterion,'novated_fbt');
    for(const row of [sourceRow,regraded]){const d=Object.getOwnPropertyDescriptor(row,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);}
    const raw=frame.research.feature_evidence.find(f=>f.variant_id===car.id&&f.criterion===feature.criterion);assert(raw);
    const snap=structuredClone(raw),audited=auditedFeature(raw);assert.deepEqual(raw,snap);
    const d=Object.getOwnPropertyDescriptor(audited,property);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);
    producer='launch-evidence.ts actual auditedFeature(raw exact novated_fbt row) creates confirmation_needed undefined';
   }else if(['buyerGrade','gradeReview'].includes(property)){
    assert.equal(feature.gradeReviewStatus,'review_required');assert(Object.hasOwn(regraded,property));assert.equal(regraded[property],undefined);
    producer='evidence-regrading.ts unmatched retained-feature branch withdraws optional review';
   }else assert.fail('Unclassified optional undefined: '+pointer);
   observations.push({phase,variantId:car.id,pointer,rowIndex,criterion:feature.criterion,property,ownUndefined:true,enumerable:true,producer,sourceProperty:{own:Object.hasOwn(sourceRow,property),valueKind:sourceRow[property]===undefined?'undefined':typeof sourceRow[property]},regradedProperty:{own:Object.hasOwn(regraded,property),valueKind:regraded[property]===undefined?'undefined':typeof regraded[property]},actualFinalProjectionMatched:true});
   pointers.push(pointer);return;
  }
  if(!value||typeof value!=='object')return;
  for(const key of Object.keys(value))visit(value[key],pointer+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));
 }
 visit(pack,'/packs/'+car.id);assertDeclaredJson(pack,'/packs/'+car.id,new Set(pointers));
}
function observeClaim(claim,pack,pointer,replay,record=true){
 assert.deepEqual(replay(),claim,'Actual citable producer replay must match');
 const clone=structuredClone(claim),pointers=[];
 function visit(value,path){
  if(value===undefined){
   const match=path.match(/\/sources\/(\d+)\/(limitation|checked)$/);assert(match,'Unclassified citable undefined: '+path);
   const i=Number(match[1]),key=match[2],citation=claim.sources[i],source=pack.sources.find(s=>s.id===citation.id);assert(source);
   const d=Object.getOwnPropertyDescriptor(citation,key);assert(d&&d.enumerable&&Object.hasOwn(d,'value')&&d.value===undefined);
   assert(!source[key==='limitation'?'access_limitation':'full_text_checked_date']);
   pointers.push(path);if(record)claimOmissions.push({pointer:path,sourceId:source.id,property:key,ownUndefined:true,enumerable:true,producer:'Actual citable.ts citations() falsey source-metadata branch; actual factClaim/featureClaim replay matches'});
   delete clone.sources[i][key];return;
  }
  if(!value||typeof value!=='object')return;
  for(const key of Object.keys(value))visit(value[key],path+'/'+key.replaceAll('~','~0').replaceAll('/','~1'));
 }
 visit(claim,pointer);assertDeclaredJson(claim,pointer,new Set(pointers));assert.deepEqual(JSON.parse(JSON.stringify(claim)),clone);return clone;
}
for(const car of before){const pack=initial.pack(car.id,{data:base,cars:before});beforePacks[car.id]=pack;assert.equal(pack.features.length,69);observePack(car,pack,'before');}
let earnedCells=0,roadsideRefreshes=0,driveawayRefreshes=0;const gradeCounts={},availabilityClaims=[];
for(const car of after){
 const pack=final.pack(car.id,{data,cars:after});afterPacks[car.id]=pack;assert.equal(pack.features.length,69);assert.equal(new Set(pack.features.map(f=>f.criterion)).size,69);observePack(car,pack,'after');
 for(const feature of pack.features){
  if(feature.criterion==='roadside_assistance'){
   const fact=car.facts.roadside_assistance;
   assert.equal(feature.value,String(fact.value));assert.equal(feature.buyerGrade,'confirmed');assert.equal(feature.status,'standard');assert.equal(feature.verification_state,'reviewed_brand_au_terms');assert.deepEqual(feature.source_ids,fact.sourceIds);
   for(const condition of fact.qualifications)assert(feature.conditions.includes(condition));assert.equal(fact.value,'1 year');assert.equal(fact.unit,'');assert.equal(feature.value,'1 year');roadsideRefreshes++;
  }else if(feature.criterion==='driveaway_price'){
   const fact=car.facts.promotional_driveaway_aud;
   assert.equal(feature.value,`A$${Number(fact.value).toLocaleString('en-AU')}`);assert.equal(feature.buyerGrade,'reported');assert.equal(feature.status,'conditional');assert.equal(feature.verification_state,'reviewed_canonical_driveaway_price');assert.deepEqual(feature.source_ids,fact.sourceIds);assert.equal(feature.validUntil,'2026-10-31');
   for(const condition of fact.qualifications)assert(feature.conditions.includes(condition));driveawayRefreshes++;
  }else assert.deepEqual(feature,beforePacks[car.id].features.find(f=>f.criterion===feature.criterion),'Unrelated retained feature changed: '+car.id+'/'+feature.criterion);
 }
 for(const fact of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===packet.id)){
  assert(hasEarnedBuyerGrade(fact,data.sources,packet.reviewedAt));const claim=factClaim(pack,fact,packet.reviewedAt);
  assert.equal(claim.buyerGrade,fact.buyerGrade);assert.deepEqual(claim.sources.map(s=>s.id),fact.sourceIds);if(fact.key==='roadside_assistance'){assert.equal(claim.value,'1 year');assert(!claim.qualifications.some(q=>q.includes('text tool')));}
  if(fact.buyerGrade==='not_published'){assert.equal(fact.value,null);assert.equal(claim.value,'Not published');}
  const row={variantId:car.id,key:fact.key,claim};observeClaim(claim,pack,'/claims/'+claims.length+'/claim',()=>factClaim(pack,fact,packet.reviewedAt));claims.push(row);earnedCells++;
 }
 for(const feature of pack.features){
  const claim=featureClaim(pack,feature.criterion,feature.criterion,packet.reviewedAt);assert(claim);assert.deepEqual(claim.sources.map(s=>s.id),[...new Set(feature.source_ids)]);if(feature.criterion==='roadside_assistance'){assert.equal(claim.value,'1 year');assert(!claim.qualifications.some(q=>q.includes('text tool')));}
  observeClaim(claim,pack,'/feature-claims/'+featureClaims.length+'/claim',()=>featureClaim(pack,feature.criterion,feature.criterion,packet.reviewedAt));featureClaims.push({variantId:car.id,criterion:feature.criterion,claim});
 }
 assert.equal(buyerAvailabilityText(car),'On sale now');assert(isOnSale(car));assert(isCurrentListEligible(car,data.sources,packet.reviewedAt));assert.equal(car.year,2025);
 assert.equal(car.availabilityEvidence.orderStatus,'listed_unconfirmed');assert.equal(car.availabilityEvidence.stockStatus,'unverified');
 assert.equal(car.availabilityEvidence.physicalStockVerified,false);assert.equal(car.availabilityEvidence.factoryOrderAcceptanceVerified,false);
 for(const key of expected.coreKeys){const fact=car.facts[key];assert(hasEarnedBuyerGrade(fact,data.sources,packet.reviewedAt));gradeCounts[fact.buyerGrade]=(gradeCounts[fact.buyerGrade]??0)+1;}
 const availability=factClaim(pack,availabilityReportClaim(car),packet.reviewedAt);observeClaim(availability,pack,'/availability-claims/'+availabilityClaims.length+'/claim',()=>factClaim(pack,availabilityReportClaim(car),packet.reviewedAt));availabilityClaims.push({variantId:car.id,claim:availability});
 assert.deepEqual(availability.sources.map(source=>source.id),car.availabilityEvidence.sourceIds);
 const charge=car.facts.dc_charge_time_min;assert.equal(charge.buyerGrade,'confirmed');assert.equal(charge.comparisonBasis,'10–80% at 130 kW DC station');assert.equal(charge.value,car.drive==='AWD'||car.trim.startsWith('Advance+')?40:35);
 assert.equal(car.facts.dc_to_80_start_unspecified_min.comparisonBasis,'Charging window unknown; start SOC not stated');
 assert.equal(car.facts.battery_kwh.comparisonBasis,'Usable');assert.equal(car.facts.battery_kwh.issues.length,0);assert.equal(car.facts.boot_l.comparisonBasis,'Cargo measurement method not stated; seats upright to roof');
 assert.equal(car.facts.width_mm.comparisonBasis,'Excluding mirrors');assert.equal(car.facts.width_mm_including_mirrors.comparisonBasis,'Including mirrors');
 const price=car.facts.price_aud,offer=car.facts.promotional_driveaway_aud;
 assert.equal(price.buyerGrade,'confirmed');assert.equal(price.comparisonBasis,'Before on-road costs');assert.equal(price.priceEvidence.rung,1);assert.equal(price.priceEvidence.rankingEligible,true);
 assert.equal(offer.buyerGrade,'reported');assert.equal(offer.comparisonBasis,'Driveaway');assert.equal(offer.priceEvidence.rung,5);assert.equal(offer.priceEvidence.publisher,'CarExpert');assert.equal(offer.priceEvidence.rankingEligible,false);assert.equal(offer.validUntil,'2026-10-31');assert(!Object.hasOwn(price,'validUntil'));
 if(car.drive==='FWD'){
  for(const key of ['ac_kw','ac_max_kw_standard','kerb_kg','kerb_weight_kg','gvm_kg']){const fact=car.facts[key],claim=factClaim(pack,fact,packet.reviewedAt);assert.equal(fact.buyerGrade,'check');assert(fact.issues.length);assert(claim.qualifications.some(q=>q.includes(key.startsWith('ac_')?'22 kW':'current exact-grade web table')));}
 }else for(const key of ['ac_kw','ac_max_kw_standard','kerb_kg','kerb_weight_kg','gvm_kg'])assert.equal(car.facts[key].buyerGrade,'confirmed');

}
assert.equal(earnedCells,188);assert.equal(featureClaims.length,276);assert.equal(roadsideRefreshes,4);assert.equal(driveawayRefreshes,4);assert.deepEqual(gradeCounts,{confirmed:65,check:3});
assert.equal(after.filter(isOnSale).length,4);assert.equal(after.filter(isOnSale).length-before.filter(isOnSale).length,0);
const {exclusionReason,rankAttribute,attributes}=require('./src/lib/discovery.ts');
const policy={asOf:packet.reviewedAt},rankingProof=[],rankCounts={};
for(const row of expected.normalizedRankPolicy){
 const car=after.find(c=>c.id===row.variantId),fact=car.facts[row.key],reason=exclusionReason(car,fact,data.sources,policy);
 assert.equal(reason===null,row.eligible,'Ranking mismatch '+car.id+'/'+row.key);
 if(fact.buyerGrade==='reported'||fact.issues.length||!fact.comparisonBasis.trim()||fact.value===null||fact.priceEvidence?.rankingEligible===false)assert(reason);
 rankingProof.push({variantId:car.id,key:row.key,eligible:reason===null,reason});
}
for(const row of expected.supplementalRankPolicy){
 const car=after.find(c=>c.id===row.variantId),fact=car.facts[row.key],reason=exclusionReason(car,fact,data.sources,policy);
 assert.deepEqual(fact.issues,row.issues);assert.equal(reason===null,row.eligible,'Supplemental ranking mismatch '+car.id+'/'+row.key);
 rankingProof.push({variantId:car.id,key:row.key,eligible:reason===null,reason,supplemental:true});
}
for(const attribute of attributes){
 const ranks=rankAttribute(after,data.sources,attribute.key,policy),ranked=ranks.groups.flatMap(g=>g.entries.map(e=>e.car.id));
 assert.deepEqual(new Set(ranked),new Set(expected.rankingIds[attribute.key]));assert.equal(ranks.excluded.length,4-ranked.length);
 for(const group of ranks.groups)for(const entry of group.entries){assert.equal(entry.fact.comparisonBasis,group.basis);assert.equal(entry.fact.unit,group.unit);}
 rankCounts[attribute.key]={ranked,excluded:ranks.excluded};
}
for(const o of observations.filter(x=>x.phase==='after')){
 const prior=observations.find(x=>x.phase==='before'&&x.pointer===o.pointer&&x.criterion===o.criterion&&x.property===o.property);
 const a=afterPacks[o.variantId].features[o.rowIndex],b=beforePacks[o.variantId].features[o.rowIndex];assert.equal(a.criterion,b.criterion);
 assert(!['roadside_assistance','driveaway_price'].includes(o.criterion),'Fresh canonical term/offer projection must not inherit optional undefined fields');
 assert(prior,'Unchanged feature omission needs exact before witness: '+o.pointer);
 if(o.property==='gradeReviewStatus')assert.deepEqual(a.gradeReview,b.gradeReview);
}
const {compareFacts}=require('./src/lib/compare.ts');
const comparisonProof=[];
function pairCheck(a,b,key,state){
 const left=a.facts[key],right=b.facts[key],result=compareFacts(left,right);assert.equal(result.state,state,`${a.id}/${b.id}/${key}`);
 if(state==='comparable'){assert.equal(typeof left.value,'number');assert.equal(typeof right.value,'number');assert.equal(result.delta,right.value-left.value);}
 else{assert(!Object.hasOwn(result,'delta'));assert.equal(result.delta,undefined);}
 comparisonProof.push({left:a.id,right:b.id,key,leftBasis:left.comparisonBasis,rightBasis:right.comparisonBasis,result});
}
for(let i=0;i<after.length;i++)for(let j=i;j<after.length;j++){
 const a=after[i],b=after[j],hasFwd=a.drive==='FWD'||b.drive==='FWD';
 for(const key of ['boot_l','max_total_cargo_l','dc_to_80_start_unspecified_min'])pairCheck(a,b,key,'different_basis');
 for(const key of ['ac_kw','kerb_kg','gvm_kg'])pairCheck(a,b,key,hasFwd?'conditional':'comparable');
 for(const key of ['battery_kwh','width_mm','height_mm','dc_charge_time_min','length_mm','range_km','seats','dc_peak_kw','power_kw','zero_to_100_s','towing_braked_kg','price_aud'])pairCheck(a,b,key,'comparable');
 pairCheck(a,b,'promotional_driveaway_aud','conditional');
}
assert.equal(comparisonProof.length,190);
const crossBasisProof=[];
function crossCheck(name,a,b,state,fixture=false){const result=compareFacts(a,b);assert.equal(result.state,state,name);assert(!Object.hasOwn(result,'delta'));crossBasisProof.push({name,leftBasis:a.comparisonBasis,rightBasis:b.comparisonBasis,result,syntheticBasisGuardProbe:fixture});}
for(const car of after){
 crossCheck(car.id+' mirror states',car.facts.width_mm,car.facts.width_mm_including_mirrors,'different_basis');
 crossCheck(car.id+' unknown charge start',car.facts.dc_charge_time_min,car.facts.dc_to_80_start_unspecified_min,'different_basis');
 crossCheck(car.id+' upright versus folded unknown cargo method',car.facts.boot_l,car.facts.max_total_cargo_l,'different_basis');
 crossCheck(car.id+' MSRP versus conditional reported offer',car.facts.price_aud,car.facts.promotional_driveaway_aud,'conditional');
 const unknown={...car.facts.battery_kwh,comparisonBasis:'Battery capacity basis not established'},gross={...car.facts.battery_kwh,comparisonBasis:'Gross'};
 crossCheck(car.id+' usable versus unknown-capacity guard fixture',car.facts.battery_kwh,unknown,'different_basis',true);
 crossCheck(car.id+' usable versus gross-capacity guard fixture',car.facts.battery_kwh,gross,'different_basis',true);
 assert(exclusionReason(car,car.facts.boot_l,data.sources,policy));assert.equal(exclusionReason(car,car.facts.battery_kwh,data.sources,policy),null);
}
assert.equal(crossBasisProof.length,24);assert.deepEqual(new Set(rankCounts.length_mm.ranked),selected);
const reconciliation=readJson(expected.reconciliation.path);
const allInventory=require('./src/lib/market-inventory-data.ts').default;
const isNissan=s=>s==='Nissan';
const inventory={...allInventory,records:allInventory.records.filter(r=>isNissan(r.brand)),unverifiedLeads:allInventory.unverifiedLeads.filter(r=>isNissan(r.brand))};
const inherited=readJson('/tmp/nissan-research/inherited-inventory-extract-v1.json').rows;
assert.deepEqual(inventory.records,inherited.filter(x=>x.path.startsWith('/records/')).map(x=>x.row));assert.deepEqual(inventory.unverifiedLeads,[]);
assert.equal(inventory.records.length,1);assert.equal(inventory.unverifiedLeads.length,0);
const {inventoryRecordId,buildMarketReconciliation}=require('./scripts/reporting/m1-reconciliation.ts');
assert.deepEqual(inventory.records.map(inventoryRecordId),['nissan-ariya']);
assert.deepEqual(reconciliation.inventoryResolutions.map(r=>[r.kind,r.inventoryId,r.outcome]),[['record','nissan-ariya','included']]);
for(const review of reconciliation.currentVersionReviews){
 assert.equal(review.bodyStyle,expected.bodyByModelId[review.modelId]);
 for(const version of review.versions){const car=after.find(c=>c.id===version.carId);assert(car);assert.equal(car.modelId,review.modelId);assert.equal(car.model,review.model);assert.equal(car.model,version.model);assert.equal(car.trim,version.trim);assert.equal(car.year,version.modelYear);}
}
const c1=buildMarketReconciliation(reconciliation,after,inventory,packet.reviewedAt);
assert.equal(c1.reviewedModels,1);assert.equal(c1.reviewedVersions,4);assert.deepEqual(new Set(c1.reviewedVersionIds),selected);
assert.deepEqual(c1.settledInventory,['record:nissan-ariya']);assert.equal(c1.pass,false);
assert.deepEqual(c1.issues.map(i=>i.code),['independent_lists']);
const selectedCoverage=buildCoverageReport({cars:after,sources:data.sources,features:Object.values(afterPacks).flatMap(p=>p.features),inventory,m1Reconciliation:reconciliation},packet.reviewedAt);
assert.equal(selectedCoverage.allCatalogueVersions,4);assert.equal(selectedCoverage.tierOneVersions,4);assert.equal(selectedCoverage.onSaleVersions,4);
const progress=selectedCoverage.brandProgress.find(b=>isNissan(b.brand));assert(progress);assert.equal(progress.currentVersionReviews.length,1);assert.equal(progress.unreviewedCoreGrades,0);assert.equal(progress.missingSummaries,0);assert.equal(progress.criteria.C1,false);
const {storePortablePacks,hydratePortablePacks}=require('./src/lib/portable-packs.ts');
const snapshot=structuredClone(afterPacks),writtenExpected=structuredClone(afterPacks);
const stored=storePortablePacks(afterPacks);
assert.deepStrictEqual(afterPacks,snapshot);
assert.deepEqual(hydratePortablePacks(stored,data.sources),afterPacks);
for(const o of observations.filter(x=>x.phase==='after')){const row=writtenExpected[o.variantId].features[o.rowIndex];assert(Object.hasOwn(row,o.property));assert.equal(row[o.property],undefined);delete row[o.property];}
assert.deepEqual(JSON.parse(JSON.stringify(afterPacks)),writtenExpected);
assert.deepEqual(hydratePortablePacks(JSON.parse(JSON.stringify(stored)),data.sources),writtenExpected);assert.deepEqual(afterPacks,snapshot);
for(const [name,obj]of Object.entries({'selected-after-cars':after,'selected-packs':afterPacks,portable:stored,claims,'feature-claims':featureClaims,'availability-claims':availabilityClaims,'undefined-witnesses':observations,'claim-undefined-witnesses':claimOmissions}))fs.writeFileSync(out+'/'+name+'.json',JSON.stringify(obj,null,2)+'\n',{flag:'wx'});
const writtenPacks=readJson(out+'/selected-packs.json'),hydrated=hydratePortablePacks(readJson(out+'/portable.json'),data.sources);
assert.deepEqual(writtenPacks,writtenExpected);assert.deepEqual(hydrated,writtenExpected);
// Actual citable producers must agree for live packs and serialized/re-hydrated packs.
for(const row of claims){const fact=after.find(c=>c.id===row.variantId).facts[row.key];assert.deepEqual(factClaim(hydrated[row.variantId],fact,packet.reviewedAt),row.claim);}
for(const row of featureClaims)assert.deepEqual(featureClaim(hydrated[row.variantId],row.criterion,row.criterion,packet.reviewedAt),row.claim);
for(const row of availabilityClaims)assert.deepEqual(factClaim(hydrated[row.variantId],availabilityReportClaim(after.find(c=>c.id===row.variantId)),packet.reviewedAt),row.claim);
for(const [name,rows]of [['claims',claims],['feature-claims',featureClaims],['availability-claims',availabilityClaims]]){
 const written=readJson(out+'/'+name+'.json');
 for(let i=0;i<rows.length;i++){
  const pack=afterPacks[rows[i].variantId],replay=()=>name==='claims'?factClaim(pack,after.find(c=>c.id===rows[i].variantId).facts[rows[i].key],packet.reviewedAt):name==='availability-claims'?factClaim(pack,availabilityReportClaim(after.find(c=>c.id===rows[i].variantId)),packet.reviewedAt):featureClaim(pack,rows[i].criterion,rows[i].criterion,packet.reviewedAt);
  const clone=observeClaim(rows[i].claim,pack,'/'+name+'/'+i+'/claim',replay,false);assert.deepEqual(written[i],{...rows[i],claim:clone});
 }
}
const reportProof=[];
for(const car of after){
 const pack=afterPacks[car.id],path='/cars/'+car.family+'/'+car.slug,report=makeReport([pack],path,packet.reviewedAt),markdown=reportMarkdown(report);
 assert.deepEqual(makeReport([hydrated[car.id]],path,packet.reviewedAt),report);assert.equal(reportMarkdown(makeReport([writtenPacks[car.id]],path,packet.reviewedAt)),markdown);
 fs.writeFileSync(out+'/'+car.id+'-report.md',markdown,{flag:'wx'});assert.equal(fs.readFileSync(out+'/'+car.id+'-report.md','utf8'),markdown);
 reportProof.push({variantId:car.id,path,markdownFile:out+'/'+car.id+'-report.md',actualLiveWrittenHydratedReportEqual:true});
}
assert.equal(defaultCalls,0);for(const f of ['src/lib/data.ts','src/lib/catalogue.ts','src/lib/research.ts'])assert(!require.cache[repo+'/'+f]);
assert.deepStrictEqual(base,baseSnapshot);assert.deepStrictEqual(before,beforeSnapshot);assert.deepStrictEqual(data,dataSnapshot);assert.deepStrictEqual(after,afterSnapshot);assert.deepStrictEqual(packet,packetSnapshot);assert.deepStrictEqual(afterPacks,snapshot);checkPins();
const result={status:'selected_actual_consumers_and_exact_serialization_witness_pass',packetSha256:fileHash(packetPath),beforeCars:4,afterCars:4,coreCells:68,coreGradeCounts:gradeCounts,earnedPacketCells:earnedCells,selectedFeatureClaims:featureClaims.length,roadsideRefreshes,driveawayRefreshes,reportProof,otherRetainedFeaturesUnchanged:true,readInputs:reads,currentListProof:c1,selectedCoverage,rankingProof,rankCounts,comparisonProof,crossBasisProof,negativeProof,producerProofs,optionalFeaturePaths:observations,optionalCitationPaths:claimOmissions,inMemoryPortableExact:true,writtenPortableExact:true,writtenClaimReadback:true,livePacksUnchanged:true,productionCatalogueHydration:false,defaultLoaderCalls:defaultCalls,sourceEdits:false,scopeTargetNeutrality:{selectedTierOneOnly:true,tierTwoTargets:0,nonNissanTargets:0,fullCataloguePeerEquality:'NOT RUN; later full-stage gate'},expectedOnSaleDelta:0,fullProjectTypeScript:'UNPASSED; no compiler retry'};
// Written C1/report shape retains only the exact omissions owned by the actual issue producer.
assert.deepEqual(buildMarketReconciliation(reconciliation,after,inventory,packet.reviewedAt),c1);
assert.deepEqual(selectedCoverage.reconciliation,c1);
assert.equal(c1.issues.length,1);assert.equal(c1.issues[0].code,'independent_lists');
assert.deepEqual(Object.keys(c1.issues[0]).sort(),['brand','code','reason','reference']);
const resultSnapshot=structuredClone(result),resultWritten=structuredClone(result),reportOmissions=[];
function reportShape(value,path,clone,parent){
 if(value===undefined){
  assert(/\/(brand|reference)$/.test(path),'Unexpected report undefined: '+path);
  assert.deepEqual(parent,c1.issues[0]);const property=path.split('/').at(-1),descriptor=Object.getOwnPropertyDescriptor(parent,property);
  assert(descriptor&&descriptor.enumerable&&Object.hasOwn(descriptor,'value')&&descriptor.value===undefined);
  reportOmissions.push({pointer:path,property,ownUndefined:true,enumerable:true,producer:'Actual buildMarketReconciliation independent_lists issue via add(code, reason), no brand/reference arguments'});
  return;
 }
 if(!value||typeof value!=='object')return;
 for(const key of Object.keys(value)){
  reportShape(value[key],path+'/'+key.replaceAll('~','~0').replaceAll('/','~1'),clone?.[key],value);
  if(value[key]===undefined)delete clone[key];
 }
}
reportShape(result,'/result',resultWritten,null);
assertDeclaredJson(result,'/result',new Set(reportOmissions.map(x=>x.pointer)));
assert.deepEqual(JSON.parse(JSON.stringify(result)),resultWritten);assert.deepEqual(result,resultSnapshot);
fs.writeFileSync(out+'/report-undefined-witnesses.json',JSON.stringify(reportOmissions,null,2)+'\n',{flag:'wx'});
fs.writeFileSync(out+'/result.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
assert.deepEqual(readJson(out+'/result.json'),resultWritten);assert.deepStrictEqual(result,resultSnapshot);
assert.deepStrictEqual(base,baseSnapshot);assert.deepStrictEqual(before,beforeSnapshot);assert.deepStrictEqual(data,dataSnapshot);assert.deepStrictEqual(after,afterSnapshot);assert.deepStrictEqual(packet,packetSnapshot);assert.deepStrictEqual(afterPacks,snapshot);
console.log(JSON.stringify({status:result.status,result:out+'/result.json',sha256:fileHash(out+'/result.json')}));
