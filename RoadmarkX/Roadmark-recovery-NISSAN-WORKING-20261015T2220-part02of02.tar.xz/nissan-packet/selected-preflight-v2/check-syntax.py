from pathlib import Path
import json,hashlib,subprocess,os,time,ast
from datetime import datetime,timezone
O=Path('/tmp/nissan-packet/selected-preflight-v2');stage=O/'check.mjs'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p in O.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
ast.parse(Path('/tmp/nissan-research/prepare-selected-v1.py').read_text())
cmd=['/usr/bin/timeout','--signal=TERM','--kill-after=2s','10s','node','--max-old-space-size=64','--max-semi-space-size=1','--check',str(stage)]
start=time.monotonic()
with (O/'syntax-only-stdout.log').open('x') as so,(O/'syntax-only-stderr.log').open('x') as se:
 p=subprocess.Popen(cmd,cwd='/workspace/scratch/586427eef9f2/roadmark-104',stdout=so,stderr=se,start_new_session=True)
 _,status,usage=os.wait4(p.pid,0);code=os.waitstatus_to_exitcode(status);p.returncode=code
receipt=dict(at=datetime.now(timezone.utc).isoformat(),command=cmd,exitCode=code,rawWaitStatus=status,elapsedSeconds=time.monotonic()-start,maxRssKiB=usage.ru_maxrss,scriptSha256=sha(stage),stdoutSha256=sha(O/'syntax-only-stdout.log'),stderrSha256=sha(O/'syntax-only-stderr.log'),runtimeExecuted=False,importsExecuted=False,typescriptCompilerAttempted=False,pythonPreparationAstParsed=True,authorizedBy='/root',authorization='Root requested bounded selected Nissan preflight syntax check within 64 MiB old / 1 MiB semi space and 10+2 s; no imports or runtime.',currentProjectTypeScript='UNPASSED; syntax-only check is not a compiler pass')
with (O/'syntax-only-check.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt));assert code==0
