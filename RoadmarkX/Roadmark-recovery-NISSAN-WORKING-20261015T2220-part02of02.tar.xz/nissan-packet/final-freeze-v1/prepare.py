"""Seal the metadata-only Nissan31 retention cut after exact documentary readback."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, stat

B = Path('/tmp/nissan-packet/final-freeze-v1')
W = Path('/workspace/scratch/586427eef9f2')
REV = Path('/tmp/nissan-review')

def read(path):
    return json.loads(Path(path).read_text())

def pin(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())

def metadata_row(path, category):
    path = Path(path)
    metadata = path.lstat()
    assert stat.S_ISREG(metadata.st_mode) and not path.is_symlink(), str(path)
    return dict(path=str(path), category=category, bytes=metadata.st_size,
                mode=metadata.st_mode, mtimeNs=metadata.st_mtime_ns, kind='file')

out = B / 'inventory.json'
assert not out.exists()
readback = REV / 'docs-status-v2-live-readback-v1.json'
assert read(readback)['status'] == 'accepted'
final = REV / 'final-retention-v1-accepted.json'
assert not final.exists()
source_path = Path('/tmp/nissan-packet/source-retention-v1/manifest.json')
source = read(source_path)
assert len(source['sourcePins']) == 76
source_acceptance_path = REV / 'source-retention-v1-findings-v1.json'
source_acceptance = read(source_acceptance_path)
assert source_acceptance['status'] == 'accepted' and source_acceptance['metadataOnly'] is True
assert source_acceptance['payloadHashSweepPerformed'] is False and source_acceptance['privacyScanClaim'] is False
assert source_acceptance['manifest'] == pin(source_path)
source_pins = {item['path']: item for item in source['sourcePins']}
rows, excluded, seen_sources = [], [], set()
roots = [
    ('/tmp/nissan-research', 'sanitized_public_source_and_preparation_history'),
    ('/tmp/nissan-packet', 'packet_qa_and_all_attempt_history'),
    ('/tmp/nissan-review', 'independent_reviews'),
]
for root, category in roots:
    for current, directories, files in os.walk(root, followlinks=False):
        directories.sort()
        files.sort()
        if Path(current) == B:
            directories[:] = []
            continue
        assert not any((Path(current) / name).is_symlink() for name in directories)
        for name in files:
            path = Path(current) / name
            reason = None
            if str(path) == '/tmp/nissan-packet/post-registration-checks-v1/.exclusive-heavy.lock':
                assert path.lstat().st_size == 0
                reason = 'Empty terminal exclusive-slot lock; not reconstruction data'
            elif path.suffix == '.pyc' or '__pycache__' in path.parts:
                reason = 'Reconstructible Python bytecode; original source retained'
            if reason:
                excluded.append(dict(**metadata_row(path, 'excluded_reconstructible'),
                                     reason=reason, deletionAuthorized=False))
                continue
            item = metadata_row(path, category)
            if path.is_relative_to('/tmp/nissan-research'):
                assert str(path) in source_pins, ('Research path outside exact allowance', str(path))
                declared = source_pins[str(path)]
                assert all(item[key] == declared[key] for key in ['bytes', 'mode', 'mtimeNs'])
                item['declaredSha256'] = declared['sha256']
                item['contentHashRecomputedAtFreeze'] = False
                seen_sources.add(str(path))
            rows.append(item)
assert seen_sources == set(source_pins)
for image in source['independentReviewImages']:
    item = metadata_row(image['file']['path'], 'independent_reviews')
    assert all(item[key] == image[key] for key in ['mode', 'mtimeNs'])
    assert item['bytes'] == image['file']['bytes']

registration_path = Path('/tmp/nissan-packet/registration-v1/manifest.json')
docs_path = Path('/tmp/nissan-packet/docs-status-v2/manifest.json')
registration, docs = read(registration_path), read(docs_path)
live = []
for item in registration['writes'] + docs['writes']:
    current = pin(item['target'])
    assert current['bytes'] == item['after']['bytes'] and current['sha256'] == item['after']['sha256']
    live.append(current)
    rows.append(metadata_row(item['target'], 'live_registered_documentary_target'))
assert len(live) == 7 and len({item['path'] for item in rows}) == len(rows)
rows.sort(key=lambda item: item['path'])
state = read(W / 'roadmark-104-qa/work-status.json')
assert state['currentBrand'] == 'Nissan'
assert not state['nissanWorking']['fullProjectTypecheckPassed'] and not state['nissanWorking']['releaseReady']
assert state['nissanResearchStatus']['researchCompleted']
assert state['nissanWorking']['coverage']['catalogue'] == 430
report = read('/tmp/nissan-packet/report-comparison-plan-v2/results-manifest-v1.json')
assert report['reportAttemptAccounting'] == dict(totalNissanNormalInvocations=1,
    normalOutcome='PASSED', savedComparatorInvocations=1, comparatorOutcome='PASSED', automaticRetry=False)
failure_path = Path('/tmp/kgm-packet/report-comparison-v2/typescript-failure-provenance.json')
failure = read(failure_path)
preparation_failures = [item['path'] for item in rows if Path(item['path']).name in
                        ['preparation-failure-v1.json', 'preparation-failure.json',
                         'canonical-projection-diagnostic-failure-v1.json']]
reviewer_diagnostics = [item['path'] for item in rows if item['path'].startswith('/tmp/nissan-review/')
                        and 'diagnostic' in Path(item['path']).name]
previous_base = Path('/workspace/scratch/586427eef9f2/roadmark-recovery-20261014/checkpoints/renault-working-20261015T2040')
previous_base_expected = [
    ('FINAL-RENAULT-UPLOAD-RECEIPTS.json', 195133, '1548c59e11ab2f9d1970348a8cdff91e19500496ad50c06c41e3f43e881bb44c'),
    ('INDEPENDENT-RENAULT-TERMINAL-CLOSURE-v1.json', 16973, '60afb83a27b9c14fe5b00b9e2a6d965a375f4eebfa0a9ac134f3ff84e2ee4ef2'),
    ('delivery_native_adapter_v3.py', 12641, 'f5bec06d762fca6b3d34ea13f7e7f17d2f5353dbbd379a5e1b13e967aabbc474'),
    ('independent_renault_delivery_adapter_v1.py', 20158, '7d4d97bc2b4625df01d39ed57e49e88f472a3b45725213cec2b74afdc691b03b'),
    ('correction_delivery_v2.py', 11899, 'f175e00ef2704462febc4b81017084a4e6f7024c85c6310fb9d7c2343c515ba2'),
    ('independent_renault_delivery_correction_v1.py', 20520, '56b8138ba9dcbf485bb63292583e11cd4567cf8723fd4a23c5ef5af33f722f64'),
]
previous_base_pins = []
for name, size, digest in previous_base_expected:
    item = pin(previous_base / name)
    assert item['bytes'] == size and item['sha256'] == digest
    previous_base_pins.append(item)
previous_receipt = read(previous_base / 'FINAL-RENAULT-UPLOAD-RECEIPTS.json')
previous_closure = read(previous_base / 'INDEPENDENT-RENAULT-TERMINAL-CLOSURE-v1.json')
assert previous_receipt['status'] == 'LOCAL_RECOVERY_VERIFIED_SERVER_CREATE_CONFIRMED_NATIVE_READBACK_UNPASSED_RELEASE_UNPASSED'
assert previous_receipt['nativeByteReadbackVerified'] is False
assert previous_closure['nativeByteReadbackVerified'] is False
assert not previous_receipt['fullProjectTypeScriptPassed'] and not previous_receipt['releaseReady']
result = dict(
    schemaVersion=1,
    status='author_frozen_metadata_exact_allowlist_pending_independent_final_acceptance_and_backup_capture',
    frozenAt=datetime.now(timezone.utc).isoformat(), noFurtherPayloadEdits=True,
    metadataOnlyInventory=True, contentCaptureOrPrivacyScanPerformed=False,
    inventoryHashScope='Only seven exact live targets and named receipts/provenance/immutable predecessor-helper references are hashed. Other payload paths are lstat-only. All 76 research hashes come from accepted prior declarations. Backup owns separately authorized capture, hashing and privacy scan.',
    payloadRoots=[root for root, category in roots], files=rows, totalFiles=len(rows),
    regularFileBytes=sum(item['bytes'] for item in rows), symlinkCount=0,
    sourceAndStatusAfterPins=live,
    excluded=excluded + [dict(path=str(B), reason='Inventory and preparer pinned separately with future final review to avoid circularity', deletionAuthorized=False)],
    sourceAllowlist=pin(source_path), sourceAllowlistedResearchFiles=76,
    sourceRole=source['sourceRole'], rawRuntimeExclusion=source['rawRuntimeExclusion'],
    publicImageProvenance=dict(publicPdfDocuments=2, retainedPublicPdfFiles=3,
        existingPublicPdfPageRenders=source['sourceImages'],
        independentReviewPageRenders=source['independentReviewImages'],
        newRenderAtFreeze=False, productBrowserOrPhoneScreenshots=0),
    privacyBoundary='Source implementation/provenance and exact path allowance are not a content privacy scan or global absence proof. Raw runtime/configuration/header/cookie/credential/token/client-key payload classes remain excluded; no refetch or reconstruction authorized.',
    sourceRetentionAcceptance=pin(source_acceptance_path),
    retainedFailures=dict(compilerProvenance=pin(failure_path), compilerAttempts=failure['attempts'],
        currentFullProjectTypeScript='UNPASSED', compilerRetryAuthorized=False,
        reportAttempts=report['reportAttemptAccounting'],
        preparationFailurePaths=preparation_failures, reviewerDiagnosticPaths=reviewer_diagnostics,
        predecessorRenaultOriginalReportOutcome='UNKNOWN; preserved in the accepted Renault30 recovery chain, distinct from its later fresh pass',
        policy='Preserve all source/typed/selected/scoped/report/docs preparations, original attempts and failed/held/unknown histories. No failed attempt is replaced by a later success.'),
    otherAttemptHistory=dict(
        selected='Versions 1–4 retained. Version 2 preparation referenced a missing /usr/bin/node before runtime; version 3 used actual installed executable and version 4 added untouched-fact and expiry assertions. Only accepted version 4 runtime establishes selected success.',
        sourceAndTyped='Source versions 1–3 and typed versions 1–2 preserve reviewed corrections in range grouping, roadside dealer scope, source roles, provenance and buyer wording.',
        report='Comparator preparation version 1 omitted the driveaway canonical exception. Version 2 corrected it before runtime. A read-only feature-key/fact-key diagnostic failed and is retained. Exactly one granted normal report and one saved comparator passed.',
        reviewer='Reviewer-only full-stage assertion diagnostics and report basis-sort diagnostic remain preserved; they do not represent production retries or data changes.',
        docs='Original two-doc scratch preparation and three-doc v1 remain unchanged; v2 contains narrow clarity/spacing corrections, applied only after independent acceptance and exact root grant.',
        runtimeAutomaticRetries=False),
    currentValidation=dict(catalogue=430, tier1=353, onSale=312, packetCount=31,
        retainedRefreshes=4, additions=0, unchangedPeers=426, reviewedCore=68, filledCore=68,
        confirmed=65, check=3, reported=0, notPublished=0, scopedTests=151,
        structuralPassed=True, normalReportAndExhaustiveComparisonPassed=True,
        reportAttempts=report['reportAttemptAccounting'], fullProjectTypecheckPassed=False,
        releaseReady=False, researchCompleted=True, nissanC1=False, nissanC5=False,
        currentCleanFullSuite=False, productionBuildVerified=False, phoneMobileVerified=False,
        publicationAuthorized=False),
    independentDocsReadback=pin(readback),
    factualReportAcceptance=pin(REV / 'report-comparison-v2-results-v1.json'),
    scopedAcceptance=pin(REV / 'post-registration-v1-results-v1.json'),
    registrationManifest=pin(registration_path), docsManifest=pin(docs_path),
    currentPacket=pin('/tmp/nissan-packet/typed-preparation-v2/nissan-2026-10-15-candidate.json'),
    currentReconciliation=pin('/tmp/nissan-packet/typed-preparation-v2/nissan-market-reconciliation.json'),
    retainedStorageReadClosure=read('/tmp/nissan-packet/full-stage-v1/manifest.json')['storageClosure'],
    externalDependencies='Reuse qualified terminal Renault30 recovery and the earlier prefix20/EQA21/Leap22/Mazda23/Skoda24/Audi25/Deepal26/MINI27/KGM28/CUPRA29 chain. Nissan manifests bind all 21 retained storage leaves and accepted replacement/proof paths. Both KGM compiler failures and the original unknown Renault report remain in the prior chain. Do not broadly recapture earlier sources or rebuild immutable history.',
    previousRecoveryExactExternalReferences=previous_base_pins,
    previousRecoveryExternalReferenceScope='These six immutable files are already retained in the two delivery-only artifacts outside the 142-archive Renault chain; refer to exact pins without duplicating embedded code.',
    previousRecoveryQualification='Renault local replay passed and native upload is host-create-confirmed. Native archive byte readback remains HTTP-403-blocked/nativeByteReadbackVerified=false; this is not fully remote-verified recovery.',
    reconstructionNotes='Retain original logical absolute paths through recovery mapping. No node_modules, generated Next caches, browser-preview snapshot or new canonical catalogue capture is added. Preserve exact source and optional-property witnesses; no regenerated substitute evidence.',
    finalReviewerReceiptPolicy=dict(path=str(final), state='future_separate_acceptance_after_inventory_review',
        includedInPayload=False, reason='Avoid recursive inventory pins; reviewer root otherwise frozen after documentary and source-retention review'),
    preparer=pin(__file__))
with out.open('x') as stream:
    json.dump(result, stream, indent=2, ensure_ascii=False)
    stream.write('\n')
print(json.dumps(dict(inventory=pin(out), files=result['totalFiles'], bytes=result['regularFileBytes'],
                      liveTargets=7, preparationFailures=len(preparation_failures),
                      excludedFiles=len(excluded)), indent=2))
