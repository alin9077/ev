Nissan source review v3

Preserves v1/v2 immutable. V2 corrected exact WLTP combined grouping, explicit unknown cargo-method comparison basis, and secondary AC context roles. V3 narrows preferred towing destination to an Authorised Servicing Dealer within the stated 50 km boundary, and separates capture-process provenance from buyer terms. Values/grades unchanged: 68 core, 65 Confirmed and three AC Check. No live edits or runtime.
