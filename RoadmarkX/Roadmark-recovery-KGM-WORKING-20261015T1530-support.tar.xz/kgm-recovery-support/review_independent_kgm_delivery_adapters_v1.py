#!/usr/bin/env python3
"""Metadata and AST-only receipt for seven manually reviewed delivery adapters."""
import ast
import datetime
import hashlib
import json
import pathlib
import resource
import stat
import sys

C = pathlib.Path(__file__).resolve().parent
CHUNK = 65536
LIMIT = 268435456
OUTPUT = C / 'INDEPENDENT-KGM-DELIVERY-ADAPTER-REVIEW-v1.json'
PINFILE = C / 'DELIVERY-SCRIPT-PINS-v2.json'
PINFILE_EXPECTED = {'bytes': 3230, 'sha256': '406e00c1a1978fce8c8e98cdde351dc7a66ae58aa71dd81f6ff723f9fdc8b4b6'}
NAMES = (
    'delivery_common_v1.py', 'build_documents_v1.py',
    'independent_kgm_documents_v1.py', 'build_active_receipt_v1.py',
    'finalize_upload_receipt_v1.py', 'preupload_gate_v1.py',
    'scan_documents_v1.py',
)

def ck(value, message):
    if not value:
        raise AssertionError(message)

def pin(path):
    before = path.lstat()
    ck(stat.S_ISREG(before.st_mode) and not any(p.is_symlink() for p in path.parents), 'non-regular or linked input')
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as handle:
        while block := handle.read(CHUNK):
            size += len(block)
            digest.update(block)
    after = path.lstat()
    fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    ck(all(getattr(before, key) == getattr(after, key) for key in fields) and size == before.st_size, 'input changed during pin')
    return {'bytes': size, 'sha256': digest.hexdigest()}

def main():
    ck('--sole-child-slot-authorized' in sys.argv, 'exclusive slot flag absent')
    ck(resource.getrlimit(resource.RLIMIT_AS) == (LIMIT, LIMIT), 'fixed address-space limit absent')
    ck(not OUTPUT.exists(), 'create-only review receipt already exists')
    ck(pin(PINFILE) == PINFILE_EXPECTED, 'delivery v2 pins differ from reviewed record')
    pins = json.loads(PINFILE.read_text())
    ck([pathlib.Path(row['path']).name for row in pins['scripts']] == list(NAMES), 'seven-script order differs')
    texts = {}
    checked = []
    for row in pins['scripts']:
        path = pathlib.Path(row['path'])
        ck(path.parent == C and pin(path) == {key: row[key] for key in ('bytes', 'sha256')}, 'reviewed delivery script pin differs')
        source = path.read_text()
        tree = ast.parse(source, filename=str(path))
        ck(not any(isinstance(node, ast.ImportFrom) and node.module and node.module.startswith('independent_mini') for node in ast.walk(tree)), 'historical checker import remains')
        texts[path.name] = source
        checked.append({**row, 'astParse': 'PASS', 'manualStaticReview': 'COMPLETE', 'bodyExecuted': False})
    common = texts['delivery_common_v1.py']
    builder = texts['build_documents_v1.py']
    verifier = texts['independent_kgm_documents_v1.py']
    scanner = texts['scan_documents_v1.py']
    checks = []
    def require(name, conditions):
        ck(all(conditions), name)
        checks.append({'check': name, 'passed': True})
    require('Exact current application pin and 290 fresh, zero inherited, 169 retained boundary', [
        "application = recovery['application']" in common,
        "application['assertionCount'] == 290" in common,
        "application['freshArchiveAssertions'] == 290" in common,
        "application['exactInheritedAssertions'] == 0" in common,
        "application['mandatoryRetainedPins'] == 169" in common,
        'd25b98dea0de16c30289b3aba12867c4887705c68947e0a26e6a824c9a5cfd2e' in common,
        pins['currentApplicationAssertions'] == pins['currentFreshAssertions'] == 290,
        pins['currentInheritedAssertions'] == 0 and pins['mandatoryRetainedPins'] == 169,
    ])
    require('Historical MINI identities and standalone current source scope', [
        "len(manifest['archivesInRestoreOrder']) == 133" in common,
        "len(manifest['files']) == 12781" in common,
        "plan['baseArchivesReused'] == 132" in builder,
        "plan['fullSourceFiles'] == 694" in builder,
        "source['bytes'] < 15000000" in builder,
    ])
    require('Current factual-only validation and open release gates', [
        "'fullProjectTypeScriptPassed': False" in builder,
        "'compilerRetriesPermitted': False" in builder,
        "'currentValidationFactualOnly': True" in builder,
        "'failedTypeScriptAttempts': 2" in verifier,
        "'typeScriptFailureCause': 'unknown'" in verifier,
        "'fullProjectTypeScriptInputs': 201" in verifier,
        "'fullProjectTypeScriptRoots': 361" in verifier,
        "'normalReportExplainedLeaves': 2381" in verifier,
        "'unexplainedReportDifferences': 0" in verifier,
        "'releaseReady': False" in builder,
    ])
    require('Zero source/proof transformations distinct from one support metadata key copy', [
        "'sourceOrProofTransformations': 0" in common,
        "'generatedSupportMetadataKeyRenames': 1" in common,
        "original_member not in members and copy_member in members" in common,
        "'generatedSupportMetadataCopy': support_copy" in builder,
        "generated_support_copy(manifest['supportArchive']['members'], sanitation)" in verifier,
        "'generatedSupportMetadataCopy': manifest['generatedSupportMetadataCopy']" in texts['build_active_receipt_v1.py'],
    ])
    require('Exactly three data-only post-seal receipts and no executable text nesting', [
        "POST_SEAL_RESULTS = {RECOVERY: 'PASS', GATE: 'PASS'," in common,
        "'INDEPENDENT-KGM-REPLAY-INPUTS-v1.json': 'APPROVED_PINNED_FRESH_REPLAY_INPUTS'" in common,
        "verification['postSealReceipts'] = post_seal_receipts()" in builder,
        "check_post_seal_receipts(verification['postSealReceipts'])" in verifier,
        'reject_embedded_bodies(record)' in common,
        pins['postSealDataOnlyReconstructionCount'] == 3,
    ])
    require('Current support classification is exact, support-only and fail closed', [
        "'KGM-SUPPORT-PRIVACY-CONTRACT-v1.json'" in common,
        "'APPROVED_KGM_SUPPORT_PRIVACY_ADAPTER'" in common,
        "canonical(report['classifiedExactCodeHeaderCandidates']) == canonical(expected)" in common,
        "'unexpectedMissingOrDuplicateFindingsBlock': True" in common,
        "'newCodeContextExemptions': 0" in scanner,
        'code_context' not in scanner and 'template_context' not in scanner,
    ])
    require('Native identities and immutable initial-to-terminal closure', [
        "os.getxattr(path, 'user.library-file-id')" in common,
        "os.getxattr(path, 'user.library-file-version')" in common,
        "with preserved.open('xb')" in texts['finalize_upload_receipt_v1.py'],
        "allowed = {'createdAt', 'delivery', 'deliveryConfirmation', 'activePersistenceCheck'}" in texts['finalize_upload_receipt_v1.py'],
        "acceptedSendDoesNotProveOpened" in texts['finalize_upload_receipt_v1.py'],
        "check_seed_summary(final['targetedSeedReadExecutionSummary'], complete=True)" in verifier,
    ])
    require('Current image metadata schema and explicit inherited seed accounting', [
        "images['authorStatement'] == inventory['publicImageProvenance']" in verifier,
        "'imagesGeneratedOrCaptured'" not in verifier,
        "'payloadValueReads': 48 * count" in common,
        "'streamingIntegrityReads': 48 * count" in common,
        "'payloadReadOperations': counters['deepalOriginalPayloadReadOperations'] * len(deepal_rows)" in common,
        "value['wallLimitSeconds'] == invocation['wallLimitSeconds'] == 600" in verifier,
    ])
    for row in checked:
        ck(pin(pathlib.Path(row['path'])) == {key: row[key] for key in ('bytes', 'sha256')}, 'reviewed script changed before receipt')
    ck(pin(PINFILE) == PINFILE_EXPECTED, 'v2 pin manifest changed before receipt')
    result = {
        'result': 'PASS_STATIC_SEVEN_DELIVERY_ADAPTER_REVIEW',
        'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'deliveryScriptPins': {'path': str(PINFILE), **PINFILE_EXPECTED},
        'scripts': checked,
        'checks': checks,
        'blockingIssuesInReviewedDeliveryScripts': [],
        'scope': 'Seven delivery script ASTs and complete manual static review only; not execution of their bodies or fresh recovery verification',
        'externalInterfaceFinding': {
            'location': 'independent_kgm_recovery_v1.py:192',
            'finding': 'Image provenance fields were initially read at the wrong level',
            'disposition': 'Verifier owner corrected the unexecuted replay script to use authorStatement; corrected line was inspected',
            'separateReplayReviewRequired': True,
        },
        'supportEngineNamingConstraint': {
            'location': 'independent_kgm_documents_v1.py:43-45',
            'requiredFilenamePrefix': 'privacy_v',
            'basis': 'Verifier owner confirmed final support engine uses this prefix; dynamic engine allowlist alone does not widen terminal discovery',
            'finalSelectedEngineMustMatch': True,
        },
        'deliveryScriptBodiesExecuted': False,
        'payloadReads': 0,
        'rawOriginalReads': 0,
        'archiveReads': 0,
        'uploadsPerformed': False,
        'sourceOrProofEdits': False,
        'limits': {'addressSpaceBytes': LIMIT, 'streamingHashChunkBytes': CHUNK},
        'reviewScript': {'path': str(pathlib.Path(__file__)), **pin(pathlib.Path(__file__))},
    }
    with OUTPUT.open('x') as handle:
        json.dump(result, handle, indent=2)
        handle.write('\n')
    print(json.dumps({'result': result['result'], 'receipt': str(OUTPUT), **pin(OUTPUT)}))

if __name__ == '__main__':
    main()
