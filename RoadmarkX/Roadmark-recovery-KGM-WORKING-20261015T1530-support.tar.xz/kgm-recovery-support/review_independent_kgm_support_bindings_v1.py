#!/usr/bin/env python3
"""Bind approved support engine, exact output-version adapter and final executable set."""
import ast,datetime,hashlib,json,pathlib,resource,stat
P=pathlib.Path;C=P(__file__).resolve().parent;assert resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456)
def load(p):return json.loads(P(p).read_bytes())
def pin(p):
 p=P(p);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents);before=[s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev];b=p.read_bytes();s=p.lstat();assert before==[s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev];return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def check(rec):assert pin(rec['path'])==rec
reviewPath=C/'INDEPENDENT-KGM-SUPPORT-ADAPTER-REVIEW-v1.json';assert pin(reviewPath)['sha256']=='d113aa28540c9f63fa36f35793eafe4dbe7f24b9ee81e0a5b4b472f232b6b960';review=load(reviewPath);assert review['result']=='PASS_EXACT_SUPPORT_ONLY_ADAPTER_AND_FAIL_CLOSED_TESTS' and review['exactCandidates']==3 and review['testCount']==len(review['tests'])==21 and all(t['passed'] for t in review['tests'])
cp=C/'KGM-SUPPORT-PRIVACY-CONTRACT-v1.json';contract=load(cp);assert contract['result']=='APPROVED_KGM_SUPPORT_PRIVACY_ADAPTER' and contract['exactApprovedCandidates']==3 and contract['noDetectorOrKnownValueSearchChanges'] and contract['supportArchiveOnly'] and contract['sourceProofAndDocumentEngineUnchanged'];assert contract['independentReview']==pin(reviewPath)
for key in ('baseEngine','supportEngine','supportSyntaxHandler','supportSyntaxApproval','classification'):assert contract[key]==review[key];check(contract[key])
approval=load(contract['supportSyntaxApproval']['path']);assert approval['result']=='APPROVED_EXACT_SYNTAX_CLASSIFICATION' and approval['exactCandidates']==3 and approval['classificationPin']=={k:contract['classification'][k] for k in ('bytes','sha256')} and approval['detectorsAndValueSearchesUnchanged']
gp=C/'KGM-PRIVACY-GATE-CONTRACT-v1.json';gate=load(gp);assert gate['status']=='REVIEWED_EXACT_PRIVACY_GATE_CONTRACT' and gate['sourceProofEngine']==contract['baseEngine'] and gate['supportEngine']==contract['supportEngine'] and gate['supportPrivacyContract']==pin(cp) and gate['independentReview']==pin(reviewPath)
before=(C/'privacy_v1.py').read_bytes();after=(C/'privacy_v2_support.py').read_bytes();needle=b'us,classified=template_context(us,data,m.name);';hook=b'from kgm_support_classifications_v2 import code_context as kgm_code_context;ps,classified=kgm_code_context(ps,data,m.name);codeClassified.extend(classified);';assert before.count(needle)==1 and after==before.replace(needle,hook+needle)
diffPath=C/'SUPPORT-PREFLIGHT-V2-ADAPTER-DIFF.json';diff=load(diffPath);check(diff['before']);check(diff['after']);a=P(diff['before']['path']).read_bytes();b=P(diff['after']['path']).read_bytes();old=b'KGM-SUPPORT-PATTERN-PREFLIGHT-v1.json';new=b'KGM-SUPPORT-PATTERN-PREFLIGHT-v2.json';assert a.count(old)==1 and b==a.replace(old,new,1)
failures=load(C/'APPROVED-PREPARATORY-FAILURES.json');assert failures['status']=='REVIEWED_EXACT_PREPARATORY_FAILURES' and len(failures['failures'])==3
for row in failures['failures']:check(row['terminal']);assert load(row['terminal']['path'])['exitCode']==row['exitCode']==1
scripts=[]
for p in sorted(C.glob('*.py')):ast.parse(p.read_bytes());scripts.append(pin(p))
out={'result':'PASS_EXACT_SUPPORT_BINDINGS_AND_EXECUTABLE_FREEZE','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'supportContract':pin(cp),'gateContract':pin(gp),'supportTestReview':pin(reviewPath),'preflightAdapterDiff':pin(diffPath),'preflightOnlyOutputFilenameChanged':True,'engineOnlyExactApprovedSyntaxHook':True,'knownValueAndDetectorRulesUnchanged':True,'preparatoryFailures':pin(C/'APPROVED-PREPARATORY-FAILURES.json'),'currentReplayInputBuilder':pin(C/'build_independent_kgm_replay_inputs_v3.py'),'currentReplayVerifier':pin(C/'independent_kgm_recovery_v2.py'),'scriptCount':len(scripts),'scripts':scripts,'identityFields':['size','mtimeNs','ctimeNs','inode','device'],'noPayloadArchiveOrSeedReads':True,'finalRawPreflightRequiredBeforeSeal':True,'failureBindingDiffs':[pin(C/'phase-logs/replay-input-builder-v3-exact.diff'),pin(C/'phase-logs/replay-verifier-v2-exact.diff')]}
target=C/'INDEPENDENT-KGM-EXECUTABLE-FREEZE-v1.json'
with target.open('x') as h:json.dump(out,h,indent=2);h.write('\n')
print(json.dumps({'result':out['result'],'scripts':len(scripts),'pin':pin(target)}))
