#!/usr/bin/env python3
"""Accept one exact support proposal after final raw-code preflight; no payload trees."""
import ast,datetime,hashlib,json,pathlib,resource,stat
P=pathlib.Path;C=P(__file__).resolve().parent;B=C.parent/'mini-working-20261015T1330';LIMIT=268435456;CHUNK=65536
assert resource.getrlimit(resource.RLIMIT_AS)==(LIMIT,LIMIT)
def load(p):return json.loads(P(p).read_bytes())
def sh(r):return {k:r[k] for k in ('bytes','sha256')}
def pin(p):
 p=P(p);s=p.lstat();before=[s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev];assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents);h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(CHUNK):h.update(b);n+=len(b)
 s=p.lstat();assert before==[s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev] and n==s.st_size;return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
proposalPath=C/'SUPPORT-SELECTION-PROPOSAL-v1.json';proposal=load(proposalPath);assert proposal['status']=='PENDING_INDEPENDENT_EXACT_SUPPORT_ALLOWLIST_REVIEW' and proposal['rawPreliminaryProposalExcluded'];out=C/'SUPPORT-SELECTION-v1.json';assert not out.exists()
forbidden={'KGM-METADATA-INVENTORY-PROPOSAL-v1.json','SUPPORT-SELECTION-v1.json','SUPPORT-MEMBER-INVENTORY.json','SUPPORT-REUSE-MAPPING.json','support-package.json','ARCHIVE-PLAN.json','RESTORE-PLAN.json','FRESH-ONLY-RESTORE-MANIFEST.json','ALL-ARCHIVE-PRIVACY-GATE.json'}
folders={'phase-logs','seed-read-invocations','audi-seed-read-invocations','deepal-seed-read-invocations'};selected={}
for r in proposal['files']:
 p=P(r['path']);assert p.is_absolute() and p.is_relative_to(C);local=p.relative_to(C).as_posix();assert local==r['localRelativePath'] and local not in selected and local not in forbidden and not local.startswith('library-')
 assert len(P(local).parts)==1 or len(P(local).parts)==2 and P(local).parts[0] in folders
 assert p.suffix in {'.py','.json','.txt','.md','.log','.err','.patch','.diff'};assert sh(pin(p))==sh(r)
 if 'identity' in r:
  s=p.lstat();assert r['identity']==[s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev]
 selected[local]={'path':str(p),'localRelativePath':local,**sh(r)}
all_scripts={p.name for p in C.glob('*.py')};assert all_scripts<={*selected};assert P(__file__).name in all_scripts
for n in all_scripts:ast.parse((C/n).read_bytes())
required={'APPROVED-KGM-CAPTURE-SCOPE.json','IMAGE-PROVENANCE.json','SAVING-ANNOUNCEMENT.json','KGM-METADATA-INVENTORY-PROPOSAL-support-copy-v1.json','PROPOSAL-SUPPORT-COPY-MAPPING-v1.json','APPLICATION-ASSERTION-CONTRACT.json','INDEPENDENT-KGM-INITIAL-IDENTITIES-v1.json','INDEPENDENT-KGM-DEPENDENCY-PROPOSAL-v1.json','INHERITED-DEPENDENCY-RECONSTRUCTION-v1.json','independent_kgm_recovery_v1.py','build_independent_kgm_replay_inputs_v1.py'};assert required<={*selected}
preflights=[]
for p in C.glob('KGM-SUPPORT-PATTERN-PREFLIGHT-v*.json'):
 v=int(p.stem.rsplit('v',1)[1]);preflights.append((v,p,load(p)))
assert preflights;version,preflightPath,raw=max(preflights);assert raw['rawPatternsUnchanged'] and not raw['knownValueSearchPerformed'] and raw['seedReads']==raw['historicalArchiveReads']==0 and not raw['payloadsModified'] and not raw['newClassificationsGranted'];assert all(r['astValid'] and not r['rawRuntimeFindings'] for r in raw['files'])
base=load(B/'deliverables/Roadmark-RECOVERY-MANIFEST-MINI-WORKING-20261015.json');prior={(r['bytes'],r['sha256']) for r in base['files'] if r['path'].endswith('.py')};tested={(r['bytes'],r['sha256']) for r in raw['files']};assert all((selected[n]['bytes'],selected[n]['sha256']) in tested|prior for n in all_scripts)
candidates=[{'member':'kgm-recovery-support/'+r['filename'],'filePin':sh(r),'finding':f} for r in raw['files'] for f in r['primaryFindings']];classificationPin=None
if candidates:
 cp=C/'INDEPENDENT-KGM-SUPPORT-SYNTAX-CLASSIFICATION-v1.json';ap=C/'APPROVED-KGM-SUPPORT-SYNTAX.json';classes=load(cp)['exactSupportCodeClassifications'];approval=load(ap);assert approval['result']=='APPROVED_EXACT_SYNTAX_CLASSIFICATION' and approval['classificationPin']==sh(pin(cp)) and approval['exactCandidates']==len(classes)==len(candidates)
 for c in candidates:assert len([r for r in classes if r['member']==c['member'] and r['filePin']==c['filePin'] and r['exactFinding']=={'member':c['member'],**c['finding']}])==1
 classificationPin=pin(cp)
else:assert raw['result']=='PASS'
copy=load(C/'PROPOSAL-SUPPORT-COPY-MAPPING-v1.json');assert copy['result']=='PASS_EXACT_GENERATED_METADATA_KEY_COPY' and copy['originalUnchanged'] and copy['proseValueByteExact'] and copy['allOutsideKeyBytesIdentical'] and copy['allOtherJSONFieldsIdentical'] and not copy['sourceOrEvidencePayloadChanged'];assert sh(pin(copy['copy']['path']))==sh(copy['copy']);assert P(copy['copy']['path']).name in selected
pp=pin(proposalPath);selected[proposalPath.name]={'path':str(proposalPath),'localRelativePath':proposalPath.name,**sh(pp)}
result={'schemaVersion':1,'status':'REVIEWED_EXACT_SUPPORT_ALLOWLIST','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'approvalScope':proposal['approvalScope'],'proposal':pp,'files':[selected[k] for k in sorted(selected)],'review':{'exactFilePinsAndLstatIdentityChecked':True,'noSymlinksOutsideCheckpointOrPayloadTrees':True,'allCurrentExecutableFilesIncluded':len(all_scripts),'rawPreliminaryProposalExcluded':True,'supportProposalIncludedOnce':True,'rawCodePreflight':pin(preflightPath),'exactClassifiedCodeCandidates':len(candidates),'classification':classificationPin,'sourceProofTransformations':0,'generatedSupportMetadataKeyRenames':1,'copyMapping':pin(C/'PROPOSAL-SUPPORT-COPY-MAPPING-v1.json'),'noNewClassificationsGranted':True,'noPayloadArchiveOrSeedReads':True,'selectionSelfRetainedBySealer':True}}
with out.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'result':result['status'],'files':len(result['files']),'scripts':len(all_scripts),'pin':pin(out)}))
