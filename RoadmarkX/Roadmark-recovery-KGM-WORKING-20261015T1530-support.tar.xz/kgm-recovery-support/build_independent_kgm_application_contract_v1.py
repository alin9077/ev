#!/usr/bin/env python3
"""Pin accepted KGM application facts for later fresh-archive replay; no product run."""
import datetime, hashlib, json, pathlib, resource, stat, sys
sys.dont_write_bytecode=True
P=pathlib.Path; C=P(__file__).resolve().parent; W=C.parents[2]; LIMIT=268435456
T=P('/tmp/kgm-packet'); R=P('/tmp/kgm-review'); INV=T/'final-freeze-v1/inventory.json'; ACC=R/'final-retention-v1-acceptance.json'
def ck(v,m):
 if not v:raise AssertionError(m)
def sh(r):return {k:r[k] for k in ('bytes','sha256')}
def identity(p):
 p=P(p);s=p.lstat();ck(stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents),'unsafe metadata path');return [s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev]
def data(p):
 a=identity(p);ck(a[0]<500000,'metadata read too large');b=P(p).read_bytes();ck(identity(p)==a and len(b)==a[0],'metadata mutation');return b
def pin(p):
 b=data(p);return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def rest(p):
 p=P(p)
 if p.is_relative_to('/tmp'):return p.relative_to('/tmp').as_posix()
 if p.is_relative_to(W/'roadmark-104'):return 'roadmark/'+p.relative_to(W/'roadmark-104').as_posix()
 ck(p.is_relative_to(W/'roadmark-104-qa'),'unexpected restore root');return p.relative_to(W).as_posix()
def pointer(x,p):
 if not p:return x
 for k in p.split('/')[1:]:k=k.replace('~1','/').replace('~0','~');x=x[int(k)] if isinstance(x,list) else x[k]
 return x
def main():
 ck(resource.getrlimit(resource.RLIMIT_AS)==(LIMIT,LIMIT),'ceiling absent')
 ip,ap=pin(INV),pin(ACC);ck(sh(ip)=={'bytes':116912,'sha256':'475c849164197b932a2a22b0096fa8a71b5b10ea0584a0c183a51dbf76df29bd'},'inventory pin differs');ck(sh(ap)=={'bytes':5246,'sha256':'40263bd910e7db029e9c85de29e746411b7537d8d6238003531cc02ceb0af817'},'review pin differs')
 inv=json.loads(data(INV));acc=json.loads(data(ACC));frozen={r['path']:r for r in inv['files']};ck(len(frozen)==385 and inv['regularFileBytes']==18677159 and inv['symlinkCount']==0,'freeze counts differ');ck(acc['status']=='accepted' and acc['liveAfterPins']==inv['sourceAndStatusAfterPins'],'live pins differ')
 docs={};retained={};assertions=[];reads=[];external={};extra={str(INV):ip,str(ACC):ap}
 def add(r):
  p=r['path']
  if p not in frozen and p not in extra:external[(p,r['bytes'],r['sha256'])]=r;return
  if p in frozen:ck(frozen[p]['bytes']==r['bytes'],'frozen size differs '+p)
  e={'path':rest(p),**sh(r)};ck(e['path'] not in retained or retained[e['path']]==e,'conflicting retained pin '+p);retained[e['path']]=e
 def read(p):
  p=str(p)
  if p in docs:return docs[p]
  ck(p in frozen or p in extra,'outside exact selection '+p);s=identity(p)
  if p in frozen:ck(s[:2]==[frozen[p]['bytes'],frozen[p]['mtimeNs']],'metadata differs from freeze '+p)
  q=pin(p);add(q);x=json.loads(data(p));ck(pin(p)==q and identity(p)==s,'unstable receipt');docs[p]=x;reads.append({'path':p,**sh(q),'identity':s});return x
 def refs(x):
  if isinstance(x,dict):
   if all(k in x for k in ('path','bytes','sha256')):add(x)
   for v in x.values():refs(v)
  elif isinstance(x,list):
   for v in x:refs(v)
 def exact(p,field,value):
  ck(pointer(read(p),field)==value,'application assertion differs '+str(p)+field);assertions.append({'restorePath':rest(p),'pointer':field,'expected':value})
 def fields(p,names):
  x=read(p)
  for n in names:exact(p,'/'+n,x[n])
 def receipt(p,status,names):
  x=read(p);exact(p,'/status',status);fields(p,names);refs(x);return x
 def terminal(p,code=0):
  x=read(p);exact(p,'/exitCode',code);exact(p,'/automaticRetry',False)
  for n in ('watchdogFired','timeoutExitCodeObserved'):
   if n in x:exact(p,'/'+n,False)
  for n in ('stdout','stderr'):add({'path':str(P(p).parent/(n+'.log')),'bytes':frozen[str(P(p).parent/(n+'.log'))]['bytes'],'sha256':x[n+'Sha256']})
  fields(p,['rawWaitStatus','elapsedSeconds','maxRssKiB'])
 def run(step):
  refs(step);p=step['result']['path'];x=read(p)
  for k in ('passed','pinsPassed','scopePassed'):exact(p,'/'+k,True)
  exact(p,'/exitCode',0);terminal(step['terminal']['path']);ck(x['manifestSha256']==step['manifest']['sha256'],'manifest binding differs')
 read(INV);read(ACC)
 for r in inv['sourceAndStatusAfterPins']:add(r)
 fields(INV,['sourceAndStatusAfterPins','retainedFailures','otherAttemptHistory','currentValidation','rawRuntimeExclusion','publicImageProvenance','totalFiles','regularFileBytes','symlinkCount','canonicalSanitizedSourceFiles'])
 fields(ACC,['status','allSevenLiveTargetsRehashedAndExact','bothActualFailedTypeScriptAttemptsAndEmptyLogsRetained','bothFreshTypeScriptCachesAbsent','currentTypeScriptUnpassed','releaseReady','factualReportExceptionExplicit','rawRuntimeExclusion'])
 ck(inv['canonicalSanitizedSourceFiles']==56 and inv['currentValidation']['fullProjectTypecheckPassed'] is False and acc['releaseReady'] is False,'current claims differ')
 s=receipt(R/'selected-preflight-v2-result-review.json','accepted_selected_v2_result',['checks','limits','inputPinsReverified','wrapperPostPinChecks'])
 for k,v in {'completeCars':3,'exactFactTermUpdates':68,'uniqueFactClaims':68,'uniqueFeatureClaims':207,'currentModels':2,'currentVersions':3,'strictCoreFilled':46,'strictCoreGaps':5}.items():ck(s['checks'][k]==v,'selected count differs '+k)
 ck(s['checks']['criteria']=={'C1':False,'C2':False,'C3':True,'C4':True,'C5':False,'C6':True},'KGM criteria differ');terminal(T/'selected-preflight-v2/run/terminal.json')
 s=receipt(R/'full-stage-v1-output-review.json','accepted_bounded_full_stage_v1_result',['checks','limits','allInputPinsReverified'])
 for k,v in {'acceptedStagesBeforeKgm':8,'changedCars':3,'unchangedCompletePeers':424,'fixedCatalogueTierOneOnSale':[427,350,309],'factAndTermClaims':68,'featureClaims':207,'runtimeStorageClosure':21,'globalC1StillFalse':True}.items():ck(s['checks'][k]==v,'stage count differs '+k)
 terminal(T/'full-stage-v1/run/terminal.json');sp=T/'full-stage-v1/output/stage-receipt.json';fields(sp,list(read(sp)))
 s=receipt(R/'registration-v1-application-review.json','accepted',['allFourLiveHashesAndBytesMatchAcceptedPayloads','exactLiveByteReadbackCompared','unchangedHelperAndTestPinsVerified','fourTargets','scope']);ck(s['unchangedHelperAndTestPinsVerified']==8,'helper preservation differs');p=s['applicationReceipt']['path'];exact(p,'/passed',True);fields(p,list(read(p)))
 s=receipt(R/'docs-status-v1-application-review.json','accepted',['allThreeLiveHashesAndBytesMatchAcceptedPayloads','all56ProofPinsStillExact','allThreeIndividualWriteReceiptsExact','progressAppendOnlyAndBeforeSnapshotExact','all57HistoricalStatusFieldsPreserved','allEightPriorHistoryEntriesPreserved','all16SupersededCurrentFieldsArchivedExactly','currentTypeScriptUnpassedAndReleaseFalse','bothFreshTypeScriptCachesAbsent','liveTargets','scope']);p=s['applicationReceipt']['path'];exact(p,'/passed',True);fields(p,list(read(p)))
 s=receipt(R/'post-registration-v1-output-review.json','accepted',['inputPinsReverified','unchangedConfiguredRootStatsReverified','completeRootScope','checks','limits']);ck(s['inputPinsReverified']==201 and s['completeRootScope']==361,'full project input scope differs');ck([r['name'] for r in s['checks']]==['market-view','changed-file-lint','behavioural-suites','live-brand-safety','structural-validation'],'gates differ');ck([r['expectedTests'] for r in s['checks']]==[None,None,144,7,None],'test counts differ')
 for r in s['checks']:run(r)
 for ver,status,field in [(1,'reviewed_failure_not_accepted_as_pass','verification'),(2,'reviewed_second_failure_no_typecheck_pass','verified')]:
  rp=R/f'full-project-typescript-v{ver}-failure-review.json';s=receipt(rp,status,['terminal','result',field]);ck(s[field]['all201InputPinsUnchanged'] and s[field]['freshCacheExists'] is False and s[field]['emptyStdoutAndStderr'],'failure boundary differs');terminal(T/f'full-project-typescript-v{ver}/run/terminal.json',-9)
  p=T/f'full-project-typescript-v{ver}/run/result.json'
  for k,v in {'passed':False,'exitCode':-9,'pinsPassed':True,'scopePassed':False,'coldFullProjectAttempt':True,'fullProjectTypecheckPassed':False,'nextBuildClaim':False,'automaticRetry':False,'furtherAttemptRequiresNewApproval':True}.items():exact(p,'/'+k,v)
  for name in ['after-pins.json','scope-verification.json']:
   p=T/f'full-project-typescript-v{ver}/run'/name;fields(p,list(read(p)))
  cache=T/f'full-project-typescript-v{ver}/run/full-project.tsbuildinfo';ck(not cache.exists(),'fresh compiler cache unexpectedly present')
 p=T/'report-comparison-v2/typescript-failure-provenance.json';fields(p,['status','fullProjectTypecheckPassed','releaseAcceptanceClaim','compilerRetriesAuthorized','priorFailureCause','attempts','currentInputVerification','cacheAbsenceLimit']);ck(read(p)['priorFailureCause']=='unknown','cause relabeled');refs(read(p))
 s=receipt(R/'report-comparison-v2-output-review.json','accepted_independent_factual_coverage_result_typescript_unpassed',['checks','fullProjectTypecheckPassed','releaseAcceptanceClaim','bothFailedTypeScriptAttemptsPreserved','limits']);ck(s['checks']['exhaustiveChangedLeavesIndependentlyRecomputed']==2381 and s['checks']['unexplainedDifferences']==0 and s['checks']['counts']==[427,350,309],'report accounting differs')
 ck(s['checks']['reviewedCoreCells']==5036 and s['checks']['totalCoreCells']==5253 and s['checks']['reviewedPercent']==95.9 and s['checks']['researchCompletedBrands']==14,'coverage counts differ')
 p=T/'report-comparison-v2/root-execution-grant.json';fields(p,['status','fullProjectTypecheckPassed','releaseAcceptanceClaim','independentCoverageException','granted','maximumAttemptsPerCommand']);ck(read(p)['status']=='root_execution_granted' and read(p)['fullProjectTypecheckPassed'] is False,'factual exception grant differs')
 for name in ('normal-coverage-asof-2026-10-15','report-comparison'):
  manifest=T/'report-comparison-v2'/(name+'.json');run({'result':{'path':str(T/'report-comparison-v2'/name/'result.json'),**sh(pin(T/'report-comparison-v2'/name/'result.json'))},'terminal':{'path':str(T/'report-comparison-v2'/name/'terminal.json'),**sh(pin(T/'report-comparison-v2'/name/'terminal.json'))},'manifest':pin(manifest)})
 p=T/'report-comparison-v2/artifacts/result.json';fields(p,list(read(p)));exact(T/'report-comparison-v2/artifacts/expected-versus-normal-diff.json','',[])
 held=['kgm-packet/selected-preflight-v1/run/terminal.json','kgm-packet/report-comparison-v1/normal-coverage-asof-2026-10-15/terminal.json','kgm-packet/report-comparison-v1/report-comparison/terminal.json'];ck(not set(held)&{rest(p) for p in frozen},'held preparation contains execution')
 for r in reads:ck(identity(r['path'])==r['identity'] and sh(pin(r['path']))==sh(r),'metadata changed')
 summary={'catalogue':427,'tierOne':350,'onSale':309,'registeredPackets':28,'selectedVersions':3,'factTermClaims':68,'featureClaims':207,'strictCoreFilled':46,'strictCoreGaps':5,'unchangedCompletePeers':424,'scopedTests':151,'relevantTests':144,'isolatedSafetyTests':7,'fullProjectTypeScriptInputs':201,'fullProjectTypeScriptRoots':361,'fullProjectTypeScriptPassed':False,'failedTypeScriptAttempts':2,'typeScriptFailureCause':'unknown','bothFreshTypeScriptCachesAbsent':True,'normalReportRuns':1,'normalReportFactualOnlyException':True,'normalReportExplainedLeaves':2381,'unexplainedReportDifferences':0,'reviewedCoreCells':5036,'totalCoreCells':5253,'reviewedPercent':95.9,'researchCompletedBrands':14,'canonicalSanitizedSources':56,'globalCriteriaOpen':['C1','C2','C3','C4','C5'],'KGMCriteriaOpen':['C1','C2','C5'],'KGMVisualQAPassed':False,'productionBuildPassed':False,'currentFullSuitePassed':False,'releaseReady':False,'mobilePassClaimed':False,'currentSelected':'selected-preflight-v2','currentFullStage':'full-stage-v1','currentReportComparator':'report-comparison-v2','heldUnexecuted':['selected-preflight-v1','report-comparison-v1']}
 result={'schemaVersion':1,'result':'APPROVED_EXACT_CAPTURED_APPLICATION_ASSERTIONS','preparedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'generator':pin(__file__),'finalFreeze':ip,'finalAcceptance':ap,'assertions':assertions,'retainedPins':sorted(retained.values(),key=lambda r:r['path']),'exactMetadataReads':reads,'externalReferencedPins':sorted(external.values(),key=lambda r:(r['path'],r['sha256'])),'forbiddenExecutedTerminals':held,'summary':summary,'scope':'Exact reviewer/result facts replayed from fresh archive bytes; original tests and product consumers not rerun','noProductExecution':True,'noSourceOrResearchBodyHashSweep':True,'noRawKgmOriginalReads':True,'noCodeEmbedding':True}
 out=C/'APPLICATION-ASSERTION-CONTRACT.json'
 with out.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({'result':result['result'],'assertions':len(assertions),'retainedPins':len(retained),'metadataReadFiles':len(reads),'pin':pin(out)}))
if __name__=='__main__':main()
