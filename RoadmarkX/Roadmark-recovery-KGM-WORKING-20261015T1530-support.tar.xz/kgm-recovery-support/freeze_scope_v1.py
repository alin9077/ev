"""Freeze only the exact accepted KGM metadata inventory and separately named receipts."""
from capture_v1 import *
inventory=P('/tmp/kgm-packet/final-freeze-v1/inventory.json')
inventoryPin={'bytes':116912,'sha256':'475c849164197b932a2a22b0096fa8a71b5b10ea0584a0c183a51dbf76df29bd'}
check(inventory,inventoryPin);v=load(inventory)
assert v['schemaVersion']==1 and v['noFurtherPayloadEdits'] and v['metadataOnlyInventory'] and not v['contentCaptureOrPrivacyScanPerformed']
assert v['totalFiles']==len(v['files'])==385 and v['symlinkCount']==0
assert sum(r['bytes'] for r in v['files'])==v['regularFileBytes']==18677159
assert v['canonicalSanitizedSourceFiles']==56
assert v['rawRuntimeExclusion']['locallyPresentExcludedOriginalPaths']==[]
assert not any(v['rawRuntimeExclusion'][k] for k in ['rawRuntimeHTMLOrConfigurationPersisted','rawResponseHeadersOrCookiesPersisted','credentialOrClientKeyPayloadPersisted','readRefetchOrRecoveryAuthorized'])
assert v['currentValidation']=={'fullProjectTypecheckPassed':False,'releaseReady':False,'compilerRetriesAuthorized':False,'factualCoverageOnly':True,'priorMiniTypeScriptPass':'Historical MINI27 source only'}
review=P('/tmp/kgm-review/final-retention-v1-acceptance.json')
reviewPin={'bytes':5246,'sha256':'40263bd910e7db029e9c85de29e746411b7537d8d6238003531cc02ceb0af817'}
check(review,reviewPin);acceptance=load(review)
assert acceptance['status']=='accepted' and acceptance['currentTypeScriptUnpassed'] and not acceptance['releaseReady']
assert acceptance['bothActualFailedTypeScriptAttemptsAndEmptyLogsRetained'] and acceptance['bothFreshTypeScriptCachesAbsent'] and acceptance['factualReportExceptionExplicit']
assert acceptance['inventory']=={'path':str(inventory),**inventoryPin} and acceptance['preparer']==v['preparer'] and acceptance['liveAfterPins']==v['sourceAndStatusAfterPins']
files={};canonical=[]
for row in v['files']:
 p=P(row['path']);ident=identity(p)
 assert row['kind']=='file' and ident[0]==row['bytes'] and ident[1]==row['mtimeNs'] and p.lstat().st_mode==row['mode']
 assert str(p) not in files
 files[str(p)]={'path':str(p),'bytes':ident[0],'mtimeNsAtFreeze':ident[1]}
 if row['category']=='canonical_sanitized_source_allowlist':
  assert p.is_relative_to('/tmp/kgm-research/sources') and len(row['declaredSha256'])==64 and row['contentHashRecomputedAtFreeze'] is False
  files[str(p)]['knownSha256']=row['declaredSha256'];canonical.append(str(p))
assert len(canonical)==56
pins=v['sourceAndStatusAfterPins']+[v[k] for k in ['sourceAllowlist','independentDocsReadback','factualReportAcceptance','factualException','currentPacket','currentReconciliation','retainedStorageReadClosure']]
assert len(v['sourceAndStatusAfterPins'])==7 and len(v['retainedFailures'])==2
for failure in v['retainedFailures']:
 assert failure['cause']=='unknown' and failure['freshCacheAbsent'] and not failure['fullProjectTypecheckPassed']
 pins.extend(failure[k] for k in ['terminal','result','afterPins','scopeFailure','independentFailureReview'])
for row in pins:
 p=P(row['path']);got,ident=check(p,row)
 assert str(p) in files and files[str(p)]['mtimeNsAtFreeze']==ident[1]
 if files[str(p)].get('knownSha256'):assert files[str(p)]['knownSha256']==got['sha256']
 files[str(p)].update(got)
for row in [{'path':str(inventory),**inventoryPin},v['preparer'],{'path':str(review),**reviewPin}]:
 p=P(row['path']);got,ident=check(p,row);assert str(p) not in files
 files[str(p)]={'path':str(p),**got,'mtimeNsAtFreeze':ident[1]}
assert len(files)==388
for row in v['excluded']:assert row['path'] not in files
changed=sorted(P(row['path']).relative_to(W/'roadmark-104').as_posix() for row in v['sourceAndStatusAfterPins'] if P(row['path']).is_relative_to(W/'roadmark-104'))
assert len(changed)==6
priorSource=load(BASE/'source-capture.json');oldSource={r['path']:r for r in priorSource['files']};assert len(oldSource)==691
expectedSource=set(oldSource)|set(changed);assert len(expectedSource)==694 and len(set(changed)-set(oldSource))==3
pack=module('packager',W/'roadmark-104/scripts/package-source.py');sourceFiles=list(pack.source_files(W/'roadmark-104'))
assert len(sourceFiles)==len(expectedSource) and {rel.as_posix() for rel,p in sourceFiles}==expectedSource
basepath=BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-MINI-WORKING-20261015.json'
basePin={'bytes':3110386,'sha256':'1564e57d37227ff2635d65e85c91fe7a851ccf8f92f08cce290e511bd9335f7c'}
check(basepath,basePin);base=load(basepath);old={r['path']:r for r in base['files']}
assert len(old)==12781 and len(base['archivesInRestoreOrder'])==133
priorProof={r['path']:r for r in load(BASE/'proof-capture-v1.json')['files']}
overlay=[];reused=[];overlaps=[]
for pstr in sorted(files):
 p=P(pstr);n=restpath(p)
 if n.startswith('roadmark/') or n not in old:continue
 expected={k:files[pstr][k] for k in ['bytes','sha256'] if k in files[pstr]};got,ident=check(p,expected)
 assert ident[1]==files[pstr]['mtimeNsAtFreeze'];files[pstr].update(got)
 prior=priorProof.get(n);candidate=got
 if prior and got=={'bytes':prior['originalBytes'],'sha256':prior['originalSHA256']}:
  check(P(prior['payloadPath']),prior);candidate={k:prior[k] for k in ['bytes','sha256']}
 baseMember={k:old[n][k] for k in ['bytes','sha256']}
 overlaps.append({'originalPath':str(p),'member':n,'originalPin':got,'baseMemberPin':baseMember})
 if candidate==baseMember:
  assert prior and got=={'bytes':prior['originalBytes'],'sha256':prior['originalSHA256']},'Unproven original/sanitized provenance: '+n
  reused.append({'originalPath':str(p),'member':n,**baseMember,'originalBytes':got['bytes'],'originalSHA256':got['sha256']})
 else:overlay.append(n)
state='Registered KGM 28 working cut; 151 scoped tests, structural validation and one actual normal report with exact saved-report comparison passed under the explicit factual-only exception. Current full-project TypeScript remains UNPASSED after two unknown-cause SIGKILLs: both fresh caches are absent and the unchanged 201-input/361-root configured scope is retained. The historical MINI TypeScript pass applies only to historical MINI source. No helper or test changes, compiler retry or release acceptance. Full aggregate suite, production build, KGM browser/device visual verification, strict M1 closure and release remain open.'
with (C/'WORKING-STATE.txt').open('x') as f:f.write(state+'\n')
q={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'freezeMetadata':{'path':str(inventory),**inventoryPin},'authorRetention':v,'authorInventory':{'path':str(inventory),**inventoryPin},'finalRetentionReview':{'path':str(review),**reviewPin},'roots':v['payloadRoots'],'files':sorted(files.values(),key=lambda x:x['path']),'knownPinsVerified':len({r['path'] for r in pins})+3,'sourceChangedPaths':changed,'expectedSourceFiles':len(expectedSource),'expectedSourcePaths':sorted(expectedSource),'expectedNonSourceOverlay':sorted(overlay),'baseNonSourceOverlaps':overlaps,'reusedProofMembers':reused,'workingResult':state,'currentValidation':v['currentValidation'],'openGates':['Current full-project TypeScript','M1 strict closure','Full-project aggregate suite','Production build','KGM browser UI and real-device mobile verification','Release/M2'],'scopeMethod':'Exact 385-file author inventory plus separately pinned inventory/preparer/final review; canonical 56-file sanitized source allowlist; no recursive research or broad QA capture','metadataOnlySymlinks':[],'noDeletion':True,'noSymlinkTraversal':True,'rawKgmOriginalReadRecoveryRefetchForbidden':True,'rawDeepalOriginalReadRecoveryRefetchForbidden':True,'canonicalSanitizedSourceFiles':56,'rawRuntimeExclusion':v['rawRuntimeExclusion'],'approvalScope':'Frozen KGM capture and factual-only recovery; no compiler retry, raw runtime retrieval or release acceptance'}
dump(C/'FROZEN-CAPTURE-SCOPE.json',q)
print(json.dumps({'files':len(files),'bytes':sum(r['bytes'] for r in files.values()),'sourceFiles':len(sourceFiles),'sourceDeltaPaths':len(changed),'metadataOnlyLinks':0,'exactReusedProofMembers':len(reused),'nonSourceOverlays':len(overlay)}))
