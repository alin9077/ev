#!/usr/bin/env python3
"""Exact import-only scanner diff and no-value proposal-key classification."""
import ast,datetime,hashlib,json,pathlib,resource
P=pathlib.Path;C=P(__file__).resolve().parent;LIMIT=268435456
assert resource.getrlimit(resource.RLIMIT_AS)==(LIMIT,LIMIT)
def pin(p):
 b=P(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(n,x):
 with (C/n).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
q=json.loads((C/'KGM-PRIVACY-ADAPTER-PROPOSAL-v1.json').read_bytes());checks=[]
for now,old in [('engine','baseEngine'),('audiAddition','baseAudiAddition'),('deepalAddition','baseDeepalAddition')]:
 n,b=P(q[now]['path']),P(q[old]['path']);assert pin(n)==q[now] and pin(b)==q[old];nb,bb=n.read_bytes(),b.read_bytes();needle=b'from capture_v2 import';replacement=b'from capture_v1 import';assert bb.count(needle)==1 and nb==bb.replace(needle,replacement);ast.parse(nb);checks.append({'script':q[now],'previousScript':q[old],'replacementCount':1})
out={'result':'PASS_EXACT_IMPORT_ONLY_PRIVACY_ADAPTATION','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'proposal':pin(C/'KGM-PRIVACY-ADAPTER-PROPOSAL-v1.json'),'checks':checks,'onlyChange':'from capture_v2 import becomes from capture_v1 import','allPatternRulesSelectorsAndSearchesByteUnchanged':True,'historicalSeedMembers':200,'historicalSeedArchives':21,'localSelectors':48,'audiSeedReadsPerInvocation':6,'deepalSeedReadsPerInvocation':5,'noSeedOrPayloadReads':True,'noRuleBroadening':True}
dump('INDEPENDENT-KGM-PRIVACY-ADAPTER-REVIEW-v1.json',out)
p=C/'KGM-METADATA-INVENTORY-PROPOSAL-v1.json';x=json.loads(p.read_bytes());v=x['scopeAuthority']['authorization'];assert v=='Metadata-only planning: small metadata reads, lstat/name/size inventories and creation of this proposal directory/file only';assert 'approvalScope' not in x['scopeAuthority']
out={'result':'EXACT_NONCREDENTIAL_SCOPE_PROSE_KEY_CLASSIFICATION','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'file':pin(p),'pointer':'/scopeAuthority/authorization','valueType':'string','valueUtf8Bytes':len(v.encode()),'valueUtf8SHA256':hashlib.sha256(v.encode()).hexdigest(),'classification':'Ordinary narrative of metadata-only task authority; no credential, token, runtime configuration or authentication data','proposedCopyOnlyKeyRename':{'from':'authorization','to':'approvalScope','objectPointer':'/scopeAuthority'},'valueMustRemainExactlyUnchanged':True,'allOtherFieldsAndBytesMustRemainUnchanged':True,'originalMustRemainLocallyRetained':True,'transformationExecuted':False,'payloadOrCredentialReads':0}
dump('INDEPENDENT-KGM-PROPOSAL-KEY-CLASSIFICATION-v1.json',out)
print(json.dumps({'privacyAdapterReview':pin(C/'INDEPENDENT-KGM-PRIVACY-ADAPTER-REVIEW-v1.json'),'proposalKeyClassification':pin(C/'INDEPENDENT-KGM-PROPOSAL-KEY-CLASSIFICATION-v1.json')}))
