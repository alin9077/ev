"""Seal one exact reviewed support selection; never glob raw or source payload roots."""
from capture_v1 import *
assert len(sys.argv)==2,'Supply the independently reviewed exact support selection JSON'
selectionPath=P(sys.argv[1]);assert selectionPath==C/'SUPPORT-SELECTION-v1.json'
selection=load(selectionPath)
assert selection['status']=='REVIEWED_EXACT_SUPPORT_ALLOWLIST' and selection['approvalScope']
assert selection['files'] and not (C/'SUPPORT-MEMBER-INVENTORY.json').exists()
basepath=BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-MINI-WORKING-20261015.json'
check(basepath,{'bytes':3110386,'sha256':'1564e57d37227ff2635d65e85c91fe7a851ccf8f92f08cce290e511bd9335f7c'})
base=load(basepath);by={}
for r in sorted(base['files'],key=lambda x:x['path']):by.setdefault((r['bytes'],r['sha256']),[]).append(r['path'])
forbidden={'KGM-METADATA-INVENTORY-PROPOSAL-v1.json','SUPPORT-MEMBER-INVENTORY.json','SUPPORT-REUSE-MAPPING.json','support-package.json','ARCHIVE-PLAN.json','RESTORE-PLAN.json','FRESH-ONLY-RESTORE-MANIFEST.json','ALL-ARCHIVE-PRIVACY-GATE.json'}
paths={}
for rec in selection['files']:
 p=P(rec['path']);assert p.is_absolute() and p.is_relative_to(C)
 local=safe(p.relative_to(C).as_posix())
 if 'localRelativePath' in rec:assert rec['localRelativePath']==local
 assert isinstance(rec['bytes'],int) and rec['bytes']>=0 and isinstance(rec['sha256'],str) and len(rec['sha256'])==64 and all(c in '0123456789abcdef' for c in rec['sha256'])
 assert local not in forbidden and p!=selectionPath and not p.is_relative_to(C/'deliverables') and not p.is_relative_to(C/'post-seal-run')
 assert local not in paths and p.is_file() and not p.is_symlink() and not any(q.is_symlink() for q in p.parents)
 assert not local.startswith(('selected-source-changes/','selected-proof-sanitized-v1/'))
 actual,ident=check(p,rec);paths[local]={'path':p,'pin':actual,'identity':ident}
assert 'APPROVED-KGM-CAPTURE-SCOPE.json' in paths and 'IMAGE-PROVENANCE.json' in paths and 'SAVING-ANNOUNCEMENT.json' in paths
assert selectionPath.name not in forbidden
selectionPin,selectionIdentity=check(selectionPath,{})
paths[selectionPath.name]={'path':selectionPath,'pin':selectionPin,'identity':selectionIdentity}
reuse=[];rows=[];seen={}
for local,item in sorted(paths.items()):
 p=item['path'];h=item['pin'];assert identity(p)==item['identity'];key=(h['bytes'],h['sha256'])
 if key in by:
  names=by[key];n=next((x for x in names if 'recovery-support' in x),names[0]);reuse.append({'originalPath':str(p),'localRelativePath':local,'retainedMember':n,**h,'kind':'exact-inherited-member'});continue
 if key in seen:
  reuse.append({'originalPath':str(p),'localRelativePath':local,'retainedMember':seen[key],**h,'kind':'exact-new-unique-member-alias'});continue
 n='kgm-recovery-support/'+local;seen[key]=n;rows.append({'path':n,**h,'payloadPath':str(p)})
assert rows and len(paths)==len(rows)+len(reuse)
mapping={'result':'EXACT_BYTE_REUSE','files':reuse,'baseManifestPin':pin(basepath),'reconstruction':'Map originalPath or localRelativePath to retainedMember after exact hash verification; no source trees or old archives recopied','noDeletion':True}
dump(C/'SUPPORT-REUSE-MAPPING.json',mapping)
rows.append({'path':'kgm-recovery-support/SUPPORT-REUSE-MAPPING.json',**pin(C/'SUPPORT-REUSE-MAPPING.json'),'payloadPath':str(C/'SUPPORT-REUSE-MAPPING.json')})
dump(C/'SUPPORT-MEMBER-INVENTORY.json',{'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SEALED_UNIQUE_SUPPORT','files':rows,'reuseMapping':pin(C/'SUPPORT-REUSE-MAPPING.json'),'selectedLocalSupportFiles':len(paths),'uniqueNewFiles':len(rows),'exactReusedOrAliasedFiles':len(reuse),'selection':{'path':str(selectionPath),**selectionPin},'noRecursiveExecutableEmbedding':True,'postSealReceiptsRetainedExternally':True,'postSealReceiptRetention':'Final independent recovery receipt and final privacy gate are retained once as pinned byte-reconstructible data-only records in the standalone verification document, with references elsewhere.','newUniqueCodeRequiresSeparateReviewedRetention':True,'scopePin':pin(C/'FROZEN-CAPTURE-SCOPE.json'),'approvalScope':selection['approvalScope']})
print(json.dumps({'newSupportMembers':len(rows),'exactReuseOrAliases':len(reuse),'newBytes':sum(r['bytes'] for r in rows)}))
