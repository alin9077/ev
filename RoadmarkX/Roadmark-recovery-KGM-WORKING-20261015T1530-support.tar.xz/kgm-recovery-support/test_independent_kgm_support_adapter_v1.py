#!/usr/bin/env python3
"""Exact support-only hook and ten fail-closed tests; no secret or archive reads."""
import ast,copy,datetime,hashlib,importlib.util,json,pathlib,resource,sys
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent
assert resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456)
def pin(p):
 b=P(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p):return json.loads(P(p).read_bytes())
base=C/'privacy_v1.py';support=C/'privacy_v2_support.py';before=base.read_bytes();after=support.read_bytes();needle=b'us,classified=template_context(us,data,m.name);';hook=b'from kgm_support_classifications_v1 import code_context as kgm_code_context;ps,classified=kgm_code_context(ps,data,m.name);codeClassified.extend(classified);';assert before.count(needle)==1 and after==before.replace(needle,hook+needle)
for p in [base,support,C/'kgm_support_classifications_v1.py']:ast.parse(p.read_bytes())
spec=importlib.util.spec_from_file_location('kgm_exact_support_test',C/'kgm_support_classifications_v1.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);classification=load(C/'INDEPENDENT-KGM-SUPPORT-SYNTAX-CLASSIFICATION-v1.json');approved=classification['exactSupportCodeClassifications'];assert len(approved)==2;member='kgm-recovery-support/capture_v1.py';data=(C/'capture_v1.py').read_bytes();candidates=[{k:v for k,v in r['exactFinding'].items() if k!='member'} for r in approved];tests=[]
def passed(name):tests.append({'name':name,'passed':True})
def rejects(name,fn):
 try:fn()
 except AssertionError:passed(name)
 else:raise AssertionError('expected fail-closed rejection: '+name)
blocked,classified=m.code_context(copy.deepcopy(candidates),data,member);expected=[{'member':r['member'],'filePin':r['filePin'],'finding':{k:v for k,v in r['exactFinding'].items() if k!='member'},'classification':r['classification']} for r in approved];assert blocked==[] and classified==expected;passed('exact approved candidate multiset classified')
extra={'kind':'unexpected-candidate','location':{'pointer':'','line':1,'charStart':0,'charEnd':1},'confidence':'needs-context','header':'x-unreviewed','valueType':'str','valueLength':0};blocked,classified=m.code_context(candidates+[extra],data,member);assert blocked==[extra] and classified==expected;passed('extra candidate remains blocking and unchanged');rejects('missing candidate rejected',lambda:m.code_context(candidates[:1],data,member));rejects('duplicate candidate rejected',lambda:m.code_context(candidates+[candidates[0]],data,member));rejects('wrong whole-file bytes rejected',lambda:m.code_context(candidates,data+b' ',member));wrong=copy.deepcopy(candidates);wrong[0]['location']['charStart']+=1;rejects('wrong candidate location rejected',lambda:m.code_context(wrong,data,member));blocked,classified=m.code_context(candidates,data,'kgm-recovery-support/not-approved.py');assert blocked==candidates and classified==[];passed('unapproved member receives no exemption');real_load=m.load
for field,value,label in [('byteStart',approved[0]['byteStart']+1,'wrong span hash rejected'),('lineSHA256','0'*64,'wrong complete-line hash rejected'),('astStatementSHA256','0'*64,'wrong AST hash rejected')]:
 altered=copy.deepcopy(classification);altered['exactSupportCodeClassifications'][0][field]=value;m.load=lambda p,altered=altered:copy.deepcopy(altered) if P(p)==m.CLASSIFICATION else real_load(p)
 try:rejects(label,lambda:m.code_context(candidates,data,member))
 finally:m.load=real_load
q={'result':'PASS_EXACT_SUPPORT_ONLY_ADAPTER_AND_FAIL_CLOSED_TESTS','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseEngine':pin(base),'supportEngine':pin(support),'supportSyntaxHandler':pin(C/'kgm_support_classifications_v1.py'),'classification':pin(C/'INDEPENDENT-KGM-SUPPORT-SYNTAX-CLASSIFICATION-v1.json'),'supportSyntaxApproval':pin(C/'APPROVED-KGM-SUPPORT-SYNTAX.json'),'testScript':pin(__file__),'tests':tests,'testCount':len(tests),'exactCandidates':2,'rawPrimaryCandidatesRetained':True,'unexpectedCandidatesRemainBlocking':True,'missingDuplicateWrongMemberOrHashCannotBeClassified':True,'engineChange':'Only exact KGM syntax hook; inherited seeds, detector searches and runtime/template handling byte-unchanged','baseSourceProofAndDocumentScansUnchanged':True,'noPayloadRedactions':True,'newBroadExemptions':0,'seedReads':0,'archivePayloadReads':0,'liveSourceWrites':0,'onlyInMemoryFaultInjection':True};out=C/'INDEPENDENT-KGM-SUPPORT-ADAPTER-REVIEW-v1.json'
with out.open('x') as f:json.dump(q,f,indent=2);f.write('\n')
print(json.dumps({'result':q['result'],'tests':len(tests),'pin':pin(out)}))
