#!/usr/bin/env python3
"""Bind only the three reviewed metadata-preparation failures; no general exit waiver."""
import datetime,hashlib,json,pathlib,resource,stat
P=pathlib.Path;C=P(__file__).resolve().parent;assert resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456)
def load(p):return json.loads(P(p).read_bytes())
def pin(p):
 p=P(p);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents);before=[s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev];b=p.read_bytes();s=p.lstat();assert before==[s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev];return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
specs=[
 ('independent-inspect-dependencies-v1.resources.json','Missing guessed metadata locator /tmp/kgm-packet/selected-preflight-v2/manifest.json; replaced by exact accepted-inventory metadata selection','independent-dependency-inspection-v1.resources.json',None),
 ('classify-support-syntax-v2.resources.json','Missing guessed preflight terminal filename after three exact span and AST checks; corrected only to the actual support-preflight-v1.resources.json','classify-support-syntax-v3.resources.json','phase-logs/classify-support-syntax-v2-observed-diagnostic.txt'),
 ('review-metadata-corrections-v1.resources.json','Checker compared full stat including read-mutated atime; narrowed to the approved size, mtime, ctime, inode and device contract','review-metadata-corrections-v2.resources.json','phase-logs/review-metadata-corrections-v1.log')]
failures=[]
assert {p.name for p in C.glob('*.resources.json') if load(p)['exitCode']==1}=={s[0] for s in specs}
for name,reason,corrected,diagnostic in specs:
 p=C/name;t=load(p);ip=p.with_name(p.stem+'.invocation.json');iv=load(ip);assert t['exitCode']==1 and not t['timedOut'] and t['command']==iv['command'] and t['childPid']==iv['childPid'] and t['addressSpaceLimitBytes']==iv['addressSpaceLimitBytes']==268435456 and t['wallLimitSeconds']==iv['wallLimitSeconds']==600
 success=C/corrected;st=load(success);assert st['exitCode']==0 and not st['timedOut'] and st['addressSpaceLimitBytes']==268435456
 if name==specs[0][0]:assert t['command'][:2]==['python','-c'] and '/tmp/kgm-packet' in t['command'][2] and 'selected-preflight-v2/manifest.json' in t['command'][2]
 elif name==specs[1][0]:assert t['command']==['python',str(C/'classify_independent_kgm_support_syntax_v2.py')]
 else:assert t['command']==['python','review_independent_kgm_metadata_corrections_v1.py']
 failures.append({'terminal':pin(p),'invocation':pin(ip),'exitCode':1,'reason':reason,'correctedSuccessfulTerminal':pin(success),'diagnostic':pin(C/diagnostic) if diagnostic else None,'verbatimFailureOutputRetained':name==specs[2][0],'diagnosticRetentionLimitation':None if name==specs[2][0] else 'Verbatim original stdout/stderr was not saved before context compaction; exact invocation and terminal remain retained. No reconstructed traceback is claimed.','metadataPreparationOnly':True,'noSuccessfulProductValidationClaim':True})
out={'status':'REVIEWED_EXACT_PREPARATORY_FAILURES','recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'approvalScope':'Parent directed exact diagnostic binding under root-approved metadata correction scope; only these three retained exit-1 attempts are accepted as historical failed preparations','failures':failures,'expectedFailedPreparations':3,'allOtherNonzeroOutcomesRemainBlocking':True,'knownRawPreflightReviewRequiredIsSeparatelyExactClassified':True,'productTypeScriptStatusUnchanged':'UNPASSED_TWO_UNKNOWN_CAUSE_SIGKILL_ATTEMPTS','classificationCorrectionReview':pin(C/'INDEPENDENT-KGM-METADATA-CORRECTION-REVIEW-v2.json'),'noPayloadArchiveOrSeedReads':True}
target=C/'APPROVED-PREPARATORY-FAILURES.json'
with target.open('x') as h:json.dump(out,h,indent=2);h.write('\n')
print(json.dumps({'result':out['status'],'failedPreparations':len(failures),'pin':pin(target)}))
