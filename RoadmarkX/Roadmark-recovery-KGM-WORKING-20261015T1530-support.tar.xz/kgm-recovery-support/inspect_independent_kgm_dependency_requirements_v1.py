#!/usr/bin/env python3
"""Metadata-only external pin discovery, with no external payload access."""
import collections,hashlib,json,pathlib,resource
P=pathlib.Path;C=P(__file__).resolve().parent;B=C.parent/'mini-working-20261015T1330';W=C.parents[2];LIMIT=268435456
assert resource.getrlimit(resource.RLIMIT_AS)==(LIMIT,LIMIT)
def load(p):return json.loads(P(p).read_bytes())
def sh(r):return {k:r[k] for k in ('bytes','sha256')}
def pin(p):
 b=P(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
base=load(B/'deliverables/Roadmark-RECOVERY-MANIFEST-MINI-WORKING-20261015.json');old={r['path']:r for r in base['files']};inv=load('/tmp/kgm-packet/final-freeze-v1/inventory.json');frozen={r['path']:r for r in inv['files']};deps=base['inheritedDependencyReconstruction']['dependencies'];by={r['originalPath']:r for r in deps}
names={'manifest.json','source-pins.json','input-pins.json','prepared-command.json','storage-read-closure.json','normal-coverage-asof-2026-10-15.json','report-comparison.json','sequence.json','static-import-closure.json'}
paths=[P(r['path']) for r in inv['files'] if r['path'].startswith('/tmp/kgm-packet/') and P(r['path']).name in names]
req={};reads=[]
def visit(x,n):
 if isinstance(x,dict):
  if all(k in x for k in ('path','bytes','sha256')) and isinstance(x['path'],str) and x['path'].startswith('/'):
   e={k:x[k] for k in ('path','bytes','sha256')};key=tuple(e.values());req.setdefault(key,{'expected':e,'nominatedBy':[]})['nominatedBy'].append(str(n))
  for v in x.values():visit(v,n)
 elif isinstance(x,list):
  for v in x:visit(v,n)
for p in paths:
 assert p.stat().st_size<500000;visit(load(p),p);reads.append(pin(p))
external=[];unresolved=[];internal=[]
for r in req.values():
 e=r['expected'];p=P(e['path']);r['nominatedBy']=sorted(set(r['nominatedBy']))
 if str(p) in frozen or p.is_relative_to(W/'roadmark-104'):internal.append(r);continue
 n=p.relative_to('/tmp').as_posix() if p.is_relative_to('/tmp') else p.relative_to(W).as_posix() if p.is_relative_to(W) else None
 matches=[z['member'] for z in by.get(str(p),{}).get('pins',[]) if sh(z['expected'])==sh(e)]
 if n in old and sh(old[n])==sh(e):matches.append(old[n])
 matches={z['path']:z for z in matches}
 if len(matches)==1:r['member']=next(iter(matches.values()));external.append(r)
 else:r['candidateExactMembers']=[z for z in old.values() if sh(z)==sh(e)];unresolved.append(r)
out={'result':'DEPENDENCY_REQUIREMENTS_INSPECTED','metadataReads':reads,'externalRequirements':external,'unresolved':unresolved,'internalRequirements':internal,'inheritedDependencyRecords':len(deps),'archiveSchemaKeys':list(base['archivesInRestoreOrder'][0]),'archiveExample':base['archivesInRestoreOrder'][0],'noExternalPayloadReads':True}
with (C/'INDEPENDENT-KGM-DEPENDENCY-INSPECTION-v1.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
changed={'roadmark/'+P(r['path']).relative_to(W/'roadmark-104').as_posix() for r in inv['sourceAndStatusAfterPins'] if P(r['path']).is_relative_to(W/'roadmark-104')};intersections=[{'dependency':r['originalPath'],'pin':p} for r in deps for p in r['pins'] if p['member']['path'] in changed]
print(json.dumps({'metadataReads':len(reads),'external':len(external),'internal':len(internal),'unresolved':unresolved,'inheritedIntersections':intersections,'archiveSchemaKeys':out['archiveSchemaKeys'],'archiveExample':out['archiveExample']},indent=2))
