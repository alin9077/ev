#!/usr/bin/env python3
"""One independently classified generated-metadata key change in a new copy."""
import pathlib,json,hashlib,resource,datetime
C=pathlib.Path(__file__).resolve().parent
CLASS=C/'INDEPENDENT-KGM-PROPOSAL-KEY-CLASSIFICATION-v1.json'
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(p,d):
 with p.open('x') as f:json.dump(d,f,indent=2);f.write('\n')
assert resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456)
r=CLASS.read_bytes();assert pin(r)['sha256']=='fce6e18f39fc75d06b2d1cb2d329d0a51e2143d7e42134ef3e62876968528c11';v=json.loads(r)
p=pathlib.Path(v['file']['path']);before=p.read_bytes();assert pin(before)=={k:v['file'][k] for k in ['bytes','sha256']}
spec=v['proposedCopyOnlyKeyRename'];old=(json.dumps(spec['from'])+':').encode();new=(json.dumps(spec['to'])+':').encode();assert before.count(old)==1 and new not in before
at=before.index(old);after=before[:at]+new+before[at+len(old):];assert after[:at]==before[:at] and after[at+len(new):]==before[at+len(old):]
a=json.loads(before);b=json.loads(after);obj=spec['objectPointer'].removeprefix('/');value=a[obj].pop(spec['from']);assert b[obj].pop(spec['to'])==value and a==b and pin(value.encode())=={'bytes':v['valueUtf8Bytes'],'sha256':v['valueUtf8SHA256']}
out=C/'KGM-METADATA-INVENTORY-PROPOSAL-support-copy-v1.json'
with out.open('xb') as f:f.write(after)
assert p.read_bytes()==before and out.read_bytes()==after
dump(C/'PROPOSAL-SUPPORT-COPY-MAPPING-v1.json',{'result':'PASS_EXACT_GENERATED_METADATA_KEY_COPY','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'classification':{'path':str(CLASS),**pin(r)},'approvalObservedAt':'2026-10-15T15:58:46Z','original':{'path':str(p),**pin(before)},'copy':{'path':str(out),**pin(after)},'originalPointer':v['pointer'],'copyPointer':spec['objectPointer']+'/'+spec['to'],'changedKeyByteStart':at,'originalKeyByteLength':len(old),'copyKeyByteLength':len(new),'proseValueByteExact':True,'allOutsideKeyBytesIdentical':True,'allOtherJSONFieldsIdentical':True,'originalUnchanged':True,'sourceOrEvidencePayloadChanged':False,'restoreQualification':'Retained support member has the explicitly renamed generated prose key. Original expected bytes/hash remain recorded separately, not silently substituted.'})
print(json.dumps({'result':'PASS','changedGeneratedMetadataKeys':1,'payloadOrSourceChanges':0}))
