#!/usr/bin/env python3
"""Exact inherited requirements and source-before compatibility, metadata only."""
import copy,datetime,hashlib,json,pathlib,resource
P=pathlib.Path;C=P(__file__).resolve().parent;B=C.parent/'mini-working-20261015T1330';W=C.parents[2]
assert resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456)
def load(p):return json.loads(P(p).read_bytes())
def sh(r):return {k:r[k] for k in ('bytes','sha256')}
def core(r):return {k:r[k] for k in ('path','bytes','sha256')}
def pin(p):
 b=P(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
bp=B/'deliverables/Roadmark-RECOVERY-MANIFEST-MINI-WORKING-20261015.json';assert sh(pin(bp))=={'bytes':3110386,'sha256':'1564e57d37227ff2635d65e85c91fe7a851ccf8f92f08cce290e511bd9335f7c'}
base=load(bp);old={r['path']:core(r) for r in base['files']};assert len(old)==12781 and len(base['archivesInRestoreOrder'])==133
priorpath=B/'INHERITED-DEPENDENCY-RECONSTRUCTION-v1.json';prior=load(priorpath);assert prior['dependencies']==base['inheritedDependencyReconstruction']['dependencies'];deps=copy.deepcopy(prior['dependencies']);assert len(deps)==164
sp=C/'FROZEN-CAPTURE-SCOPE.json';scope=load(sp);changed={'roadmark/'+n for n in scope['sourceChangedPaths']};assert len(changed)==6 and scope['expectedSourceFiles']==694
intersections=[{'dependencyIndex':i,'pinIndex':j,'dependencyOriginalPath':r['originalPath'],'originalExpected':p['expected'],'currentMember':p['member']} for i,r in enumerate(deps) for j,p in enumerate(r['pins']) if p['member']['path'] in changed];assert not intersections
ip=C/'INDEPENDENT-KGM-DEPENDENCY-INSPECTION-v1.json';inspection=load(ip)
for r in inspection['metadataReads']:assert pin(r['path'])==r
assert len(inspection['externalRequirements'])==66 and len(inspection['unresolved'])==1
system=inspection['unresolved'][0];assert system['expected']=={'path':'/usr/bin/timeout','bytes':47984,'sha256':'6ca1891dfc0b05d7680770c2884c0391b92467c7bb6500a5c84677e6481739f1'}
mp=B/'MINI-METADATA-INVENTORY-PROPOSAL-v1.json';mini=load(mp);mapping={r['member']:copy.deepcopy(r['mapping']) for r in mini['priorChainDependencies']['dependencies']};mapping_sources=[pin(mp)]
rp=B/'RESTORE-PLAN.json';plan=load(rp);mapping_sources.append(pin(rp))
for a in plan['newArchives']:
 for r in a['memberFiles']:mapping[r['path']]={'archives':[a['filename']],'partResolution':'Exact single archive','mappingBasisRef':str(rp),'member':core(r)}
ap=C.parent/'audi-working-20261015T0800/ARCHIVE-PLAN-v4.json';audi=load(ap);mapping_sources.append(pin(ap))
for a in audi['archives']:
 for r in a['memberFiles']:
  if r['path'] not in mapping:mapping[r['path']]={'archives':[a['filename']],'partResolution':'Exact single archive','mappingBasisRef':str(ap),'member':core(r)}
archives={r['filename']:r for r in base['archivesInRestoreOrder']};by={r['originalPath']:r for r in deps};new=[];existing=[];resolved=[]
for r in inspection['externalRequirements']:
 e=r['expected'];m=r['member'];assert old[m['path']]==core(m) and sh(e)==sh(m);mapping_row=mapping[m['path']];assert set(mapping_row['archives'])<=set(archives)
 if 'member' in mapping_row:assert mapping_row['member']==core(m)
 resolved.append({'expected':e,'member':m,'mapping':mapping_row,'nominatedBy':r['nominatedBy']})
 if e['path'] in by:
  matches=[p for p in by[e['path']]['pins'] if sh(p['expected'])==sh(e)];assert len(matches)==1 and matches[0]['member']==m;existing.append({'originalPath':e['path'],'member':m})
 else:
  row={'originalPath':e['path'],'pins':[{'expected':copy.deepcopy(e),'reconstructFrom':'exact inherited recommended-chain member','member':copy.deepcopy(m)}]};deps.append(row);by[e['path']]=row;new.append(row)
for r in deps:
 for p in r['pins']:assert p['expected']['path']==r['originalPath'] and sh(p['expected'])==sh(p['member']) and old[p['member']['path']]==core(p['member'])
closure=load('/tmp/kgm-packet/full-stage-v1/storage-read-closure.json');assert len(closure)==21
for r in closure:assert any(s['expected']==r for s in resolved)
canonical=hashlib.sha256(json.dumps(deps,sort_keys=True,separators=(',',':')).encode()).hexdigest();referenced=sorted({n for r in resolved for n in r['mapping']['archives']})
out={'schemaVersion':1,'result':'PASS_EXACT_METADATA_ONLY_DEPENDENCY_PROPOSAL','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseManifest':pin(bp),'baseDependencyMap':pin(priorpath),'metadataInspection':pin(ip),'metadataMappingSources':mapping_sources,'frozenScope':pin(sp),'allSixFinalSourceChangedPaths':sorted(changed),'relocationProposals':[],'inheritedPointerIntersections':intersections,'inheritedDependencyRecords':164,'unchangedInheritedRecords':164,'kgmExternalRequirements':len(resolved),'existingExactRequirements':existing,'resolvedKgmRequirements':resolved,'newDependencyRecords':new,'proposedDependenciesCount':len(deps),'proposedDependenciesCanonicalSha256':canonical,'referencedArchives':[archives[n] for n in referenced],'runtimeSystemDependenciesNotCaptured':[{'expected':system['expected'],'nominatedBy':system['nominatedBy'],'reason':'Installed OS timeout binary is environment provenance; no runtime binary capture or dependency installation authorized','payloadReads':0}],'exactRetainedStorageClosureFiles':21,'originalExpectedPathsAndHashesUnchanged':True,'metadataOnly':True,'externalPayloadReads':0,'archivePayloadReads':0,'rawDeepalOriginalReads':False,'rawKgmOriginalReads':False,'beforeCopiesRequiredForInheritedPointerRelocations':0,'note':'All 164 inherited dependency records remain exact. Every 66 KGM external proof/storage requirement resolves by exact member identity and retained archive metadata, including complete numbered sets where older per-part metadata is unavailable. Current source references are bound separately by full-source capture and preserved before-copy provenance.'}
out['runtimeSystemDependenciesNotCaptured'][0]['reconstructionCheckRequirement']='Before rerunning any retained product proof that invokes this binary, locate it in a separately authorized compatible runtime and verify the exact expected length and SHA-256. Missing or different bytes block that product-proof rerun; archive recovery does not claim to supply or satisfy this system binary.'
with (C/'INDEPENDENT-KGM-DEPENDENCY-PROPOSAL-v1.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({'result':out['result'],'prior':164,'externalRequirements':len(resolved),'newRecords':len(new),'final':len(deps),'relocations':0,'canonicalSha256':canonical,'pin':pin(C/'INDEPENDENT-KGM-DEPENDENCY-PROPOSAL-v1.json')}))
