#!/usr/bin/env python3
"""Initial identity capture of exact frozen files, without payload opens."""
import datetime,hashlib,json,pathlib,resource,stat
P=pathlib.Path;C=P(__file__).resolve().parent;LIMIT=268435456
assert resource.getrlimit(resource.RLIMIT_AS)==(LIMIT,LIMIT)
p=C/'FROZEN-CAPTURE-SCOPE.json';b=p.read_bytes();scope=json.loads(b);rows=[]
for r in scope['files']:
 q=P(r['path']);s=q.lstat();assert stat.S_ISREG(s.st_mode) and not any(z.is_symlink() for z in q.parents)
 identity=[s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev];assert identity[:2]==[r['bytes'],r['mtimeNsAtFreeze']];rows.append({'path':str(q),'identity':identity})
assert len(rows)==len({r['path'] for r in rows})==388
out={'result':'PASS_EXACT_388_SELECTED_FILE_INITIAL_IDENTITY_BINDING','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozenScope':{'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'identityFields':['size','mtimeNs','ctimeNs','inode','device'],'atimeExcluded':True,'metadataOnly':True,'payloadFilesOpened':0,'files':rows}
with (C/'INDEPENDENT-KGM-INITIAL-IDENTITIES-v1.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({'result':out['result'],'files':len(rows),'payloadFilesOpened':0}))
