#!/usr/bin/env python3
"""Actual three-candidate whole-file/span/AST proposal, without applying exemptions."""
import ast,datetime,hashlib,json,pathlib,resource,stat
P=pathlib.Path;C=P(__file__).resolve().parent;BASE=C.parent/'mini-working-20261015T1330'
assert resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456)
def pin(p):
 p=P(p);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not any(q.is_symlink() for q in p.parents);a=[s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev];b=p.read_bytes();s=p.lstat();assert a==[s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev];return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p):return json.loads(P(p).read_bytes())
def digest(x):return hashlib.sha256(x).hexdigest()
preflight=C/'KGM-SUPPORT-PATTERN-PREFLIGHT-v1.json';raw=load(preflight);assert raw['result']=='REVIEW_REQUIRED' and raw['seedReads']==raw['historicalArchiveReads']==0 and raw['rawPatternsUnchanged'];rows={r['filename']:r for r in raw['files'] if r['primaryFindings'] or r['rawRuntimeFindings']};assert set(rows)=={'capture_v1.py','review_independent_kgm_support_plan_v1.py'} and len(rows['capture_v1.py']['primaryFindings'])==2 and len(rows['review_independent_kgm_support_plan_v1.py']['primaryFindings'])==1 and not any(r['rawRuntimeFindings'] for r in raw['files'])
priorpath=BASE/'INDEPENDENT-MINI-SUPPORT-SYNTAX-CLASSIFICATION-v1.json';assert pin(priorpath)['sha256']=='ea6372b3f27bd1f5959c9332daec49a52e3f56d76f89979b82970cb9432a3fa4';prior=load(priorpath)['exactSupportCodeClassifications'];assert len(prior)==2;classes=[];reads=[]
for filename,row in rows.items():
 p=C/filename;whole=pin(p);assert {k:whole[k] for k in ('bytes','sha256')}=={k:row[k] for k in ('bytes','sha256')};b=p.read_bytes();text=b.decode('ascii');tree=ast.parse(text);reads.append(whole)
 for index,finding in enumerate(row['primaryFindings']):
  loc=finding['location'];start,end=loc['charStart'],loc['charEnd'];line=text.splitlines()[loc['line']-1].encode();span=b[start:end];member='kgm-recovery-support/'+filename
  common={'member':member,'filePin':{k:whole[k] for k in ('bytes','sha256')},'exactFinding':{'member':member,**finding},'byteStart':start,'byteEndExclusive':end,'matchedSyntaxSHA256':digest(span),'lineSHA256':digest(line),'astValid':True,'isHeaderValueOrCredential':False,'fileExtensionExemption':False,'payloadChangeProposed':False}
  nodes=[n for n in ast.walk(tree) if isinstance(n,ast.stmt) and n.lineno==n.end_lineno==loc['line']]
  if filename=='capture_v1.py':
   approved=prior[index];assert digest(span)==approved['matchedSyntaxSHA256'] and digest(line)==approved['lineSHA256'];assert {k:v for k,v in finding.items() if k!='location'}=={k:v for k,v in approved['exactFinding'].items() if k not in ('location','member')};assert len(nodes)==1;node=nodes[0]
   if index==0:
    assert isinstance(node,ast.Assert) and isinstance(node.test,ast.BoolOp) and isinstance(node.test.op,ast.And);compares=[n for n in ast.walk(node) if isinstance(n,ast.Compare)];calls=[n for n in ast.walk(node) if isinstance(n,ast.Call)];assert len(compares)==2 and len(calls)==1 and isinstance(calls[0].func,ast.Attribute) and calls[0].func.attr=='count' and isinstance(calls[0].func.value,ast.Name) and calls[0].func.value.id=='b'
   else:
    assert isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id=='renamed';call=node.value;assert isinstance(call,ast.Call) and isinstance(call.func,ast.Attribute) and call.func.attr=='replace' and isinstance(call.func.value,ast.Name) and call.func.value.id=='b' and len(call.args)==3 and isinstance(call.args[-1],ast.Constant) and call.args[-1].value==1
   common.update(classification=approved['classification'],astStatementType=type(node).__name__,astStatementSHA256=digest(ast.dump(node,include_attributes=False).encode()),exactMatchedSyntaxAndCompleteLineEqualPriorReviewedCase=True,priorMember=approved['member'],priorFinding=approved['exactFinding'])
  else:
   assert whole['sha256']=='3b3a4bc6bb954d2a24f53bc5863085bb44e8f96b075e29cba15bd8d852a395a3' and (loc['line'],start,end,finding['valueLength'])==(13,1084,1092,6)
   assert all(isinstance(n,(ast.Assign,ast.Assert)) for n in nodes)
   def assignment(name):
    found=[n for n in nodes if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id==name];assert len(found)==1;return found[0]
   old,new=assignment('old'),assignment('new');assert isinstance(old.value,ast.Constant) and old.value.value==b'"'+b'authori'+b'zation'+b'":';assert isinstance(new.value,ast.Constant) and new.value.value==b'"'+b'approvalScope'+b'":'
   lineoffset=sum(len(v) for v in text.splitlines(keepends=True)[:loc['line']-1]);assert lineoffset+old.col_offset<=start and end<=lineoffset+new.end_col_offset
   ordered=sorted(nodes,key=lambda n:n.col_offset);module=ast.Module(body=ordered,type_ignores=[]);identities=[{'type':type(n).__name__,'colOffset':n.col_offset,'endColOffset':n.end_col_offset,'astSHA256':digest(ast.dump(n,include_attributes=False).encode())} for n in ordered]
   common.update(classification='Exact static bytes-literal key replacement and adjacent Python assignment syntax in the independently retained metadata parity checker; not a request header, authentication value or credential',astStatementType='LineStatementSequence',astStatementSHA256=digest(ast.dump(module,include_attributes=False).encode()),astStatements=identities,astStatementCount=len(ordered),matchedSpanInsideBoundedOldAndNewLiteralAssignments=True,exactWholeFileAndEveryStatementOnSharedLineBound=True)
  classes.append(common)
 assert pin(p)==whole
q={'result':'INDEPENDENT_BENIGN_SYNTAX_PROPOSAL_REQUIRES_ROOT_APPROVAL','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'preflightPin':pin(preflight),'preflightTerminalPin':pin(C/'support-pattern-preflight-v1.resources.json'),'priorClassificationPin':pin(priorpath),'newExecutableFiles':raw['newExecutableFiles'],'primaryCandidates':3,'rawRuntimeCandidates':0,'exactSupportCodeClassifications':classes,'enginePins':raw['enginePins'],'noDetectorChanges':True,'noPayloadEdits':True,'noSeedOrArchiveReads':True,'candidateMultisetMustMatchExactly':True,'wholeFilePinRequired':True,'allUnexpectedCandidatesBlock':True,'newFutureScriptsRequireAnotherPreflight':True,'reviewedSourceFileReads':reads,'supersededUnexecutedTwoCandidatePreparer':pin(C/'classify_independent_kgm_support_syntax_v1.py')};out=C/'INDEPENDENT-KGM-SUPPORT-SYNTAX-CLASSIFICATION-v1.json'
with out.open('x') as f:json.dump(q,f,indent=2);f.write('\n')
print(json.dumps({'result':q['result'],'classified':len(classes),'scriptFilesRead':len(reads),'seedOrArchiveReads':0,'pin':pin(out)}))
