#!/usr/bin/env python3
"""Static exact-baseline capture review and independently checked frozen-scope gates."""
import ast,datetime,hashlib,json,pathlib,resource
P=pathlib.Path;C=P(__file__).resolve().parent;B=C.parent/'mini-working-20261015T1330'
assert resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456)
def pin(p):
 b=P(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
old=(B/'capture_v2.py').read_bytes();new=(C/'capture_v1.py').read_bytes()
expected=old.replace(b"BASE=C.parent/'deepal-working-20261015T1110'",b"BASE=C.parent/'mini-working-20261015T1330'").replace(b"BASE/'proof-capture-v2.json'",b"BASE/'proof-capture-v1.json'").replace(b'Roadmark-RECOVERY-MANIFEST-DEEPAL-WORKING-20261015.json',b'Roadmark-RECOVERY-MANIFEST-MINI-WORKING-20261015.json')
assert new==expected
scripts=[C/n for n in ['capture_v1.py','freeze_scope_v1.py','inventory_json_sanitizer_candidates_v1.py']]
for p in scripts:ast.parse(p.read_bytes())
assert pin(scripts[0])['sha256']=='a1d5ca3bb8ee25c3950758120513507ee91ec88cf14226567b30c44200a32b7d'
assert pin(scripts[1])['sha256']=='2c0dffb80d64b1c72427768baf0bcd4a7eb3b7ae39dec3c43a4e20e36741cc4b'
assert pin(scripts[2])['sha256']=='4700b6a5f0e045e94a48b64eb6ffa4c69ead0975a7bb2dedf967a1079dc3cee2'
x={'result':'PASS_STATIC_EXACT_BASELINE_CAPTURE_AND_FROZEN_SCOPE_ADAPTERS','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scripts':[pin(p) for p in scripts],'inheritedCapture':pin(B/'capture_v2.py'),'captureOnlyChanges':['BASE checkpoint DEEPAL to MINI','base proof-capture-v2 to proof-capture-v1','base logical manifest DEEPAL to MINI'],'reviewedFreezeChecks':{'authorInventoryAndSeparateFinalReviewPins':True,'exact385Plus3Selection':True,'canonical56DeclaredSanitizedHashesBound':True,'sevenLiveAndNamedSmallProofPinsBound':True,'noRawKgmOriginalReadRecoveryRefetch':True,'sixChangedPathsAnd694FullSourceSet':True,'sourceMembershipFromExactMini691UnionSixChanged':True,'nonSourceOverlapsDerivedFromExactBaseManifest':True,'originalAndSanitizedIdentityKeptDistinct':True,'noMiniPreviewReuseAssumption':True,'bothFailedTypeScriptAttemptsAndFactualExceptionRetained':True,'newFilesCreateOnly':True},'candidateScannerRulesUnchanged':True,'candidateInventoryNoRawValuesOrValueDigests':True,'scopeExecutionPerformed':False,'capturePerformed':False,'privacyScanPerformed':False,'payloadReads':0}
with (C/'INDEPENDENT-KGM-CAPTURE-ADAPTER-REVIEW-v1.json').open('x') as f:json.dump(x,f,indent=2);f.write('\n')
print(json.dumps(pin(C/'INDEPENDENT-KGM-CAPTURE-ADAPTER-REVIEW-v1.json')))
