"""Only actual independently reviewed and root-approved exact code syntax findings."""
import ast,hashlib,json
from capture_v1 import C,load,check
CLASSIFICATION=C/'INDEPENDENT-KGM-SUPPORT-SYNTAX-CLASSIFICATION-v1.json'
def code_context(candidates,data,name):
 approval=load(C/'APPROVED-KGM-SUPPORT-SYNTAX.json');assert approval['result']=='APPROVED_EXACT_SYNTAX_CLASSIFICATION' and approval['exactCandidates']==2
 check(CLASSIFICATION,approval['classificationPin']);d=load(CLASSIFICATION);assert d['result']=='INDEPENDENT_BENIGN_SYNTAX_PROPOSAL_REQUIRES_ROOT_APPROVAL' and d['primaryCandidates']==2 and d['rawRuntimeCandidates']==0
 assert {r['member'] for r in d['exactSupportCodeClassifications']}=={'kgm-recovery-support/capture_v1.py'}
 rows=[r for r in d['exactSupportCodeClassifications'] if r['member']==name]
 if not rows:return candidates,[]
 assert len(rows)==2;actual={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};assert all(r['filePin']==actual for r in rows);tree=ast.parse(data);lines=data.decode('utf-8').splitlines();expected=[{k:v for k,v in r['exactFinding'].items() if k!='member'} for r in rows];assert len(expected)==len({json.dumps(r,sort_keys=True) for r in expected});classified=[];blocked=[]
 for candidate in candidates:
  if candidate not in expected:blocked.append(candidate);continue
  r=rows[expected.index(candidate)];assert hashlib.sha256(data[r['byteStart']:r['byteEndExclusive']]).hexdigest()==r['matchedSyntaxSHA256'];line=candidate['location']['line'];assert hashlib.sha256(lines[line-1].encode()).hexdigest()==r['lineSHA256'];statements=[n for n in ast.walk(tree) if isinstance(n,ast.stmt) and n.lineno==line and type(n).__name__==r['astStatementType']];assert len(statements)==1;assert hashlib.sha256(ast.dump(statements[0],include_attributes=False).encode()).hexdigest()==r['astStatementSHA256'];classified.append({'member':name,'filePin':actual,'finding':candidate,'classification':r['classification']})
 assert len(classified)==2 and sorted(json.dumps(r['finding'],sort_keys=True) for r in classified)==sorted(json.dumps(r,sort_keys=True) for r in expected)
 return blocked,classified
