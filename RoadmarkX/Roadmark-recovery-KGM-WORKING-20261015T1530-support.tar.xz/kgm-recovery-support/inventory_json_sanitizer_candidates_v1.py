import json,pathlib,hashlib,importlib.util,datetime,sys
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent;R=C.parents[1]
from capture_v1 import check,identity,dump
s=importlib.util.spec_from_file_location('san',R/'snapshot_recovery_v2.py');S=importlib.util.module_from_spec(s);s.loader.exec_module(S)
d=json.loads((C/'FROZEN-CAPTURE-SCOPE.json').read_text());rows=[];seen=0
for r in d['files']:
 p=P(r['path'])
 if p.suffix!='.json':continue
 expected={k:r[k] for k in ['bytes','sha256'] if k in r};actual,ident=check(p,expected);assert ident[1]==r['mtimeNsAtFreeze'];b=p.read_bytes();assert identity(p)==ident and len(b)==actual['bytes'] and hashlib.sha256(b).hexdigest()==actual['sha256'];seen+=1;out,red=S.sanitize_json(b)
 if red:
  j=json.loads(b);loc=[]
  for ptr in red:
   v=j
   for x in ptr.split('/')[1:]:
    x=x.replace('~1','/').replace('~0','~');v=v[int(x)] if isinstance(v,list) else v[x]
   loc.append({'pointer':ptr,'valueType':type(v).__name__,'valueLength':len(v) if isinstance(v,(str,list,dict)) else None,'alreadyExplicitlyRedacted':isinstance(v,str) and v.startswith('[REDACTED')})
  rows.append({'originalPath':str(p),'originalBytes':len(b),'originalSHA256':hashlib.sha256(b).hexdigest(),'sanitizedBytes':len(out),'sanitizedSHA256':hashlib.sha256(out).hexdigest(),'locations':loc})
q={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'REVIEW_REQUIRED' if rows else 'NO_CANDIDATES','jsonFilesChecked':seen,'candidateFiles':rows,'candidateLocations':sum(len(r['locations']) for r in rows),'noLiveWrites':True,'rawValuesOrValueDigestsPersisted':False}
dump(C/'JSON-SANITIZER-CANDIDATES-v1.json',q);print(json.dumps({'jsonFilesChecked':seen,'candidateFiles':len(rows),'candidateLocations':q['candidateLocations']}))
