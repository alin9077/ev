#!/usr/bin/env python3
"""Static metadata-plan/seal review and exact generated-prose copy parity."""
import ast,datetime,hashlib,json,pathlib,resource
P=pathlib.Path;C=P(__file__).resolve().parent;LIMIT=268435456
assert resource.getrlimit(resource.RLIMIT_AS)==(LIMIT,LIMIT)
def load(p):return json.loads(P(p).read_bytes())
def sh(r):return {k:r[k] for k in ('bytes','sha256')}
def pin(p):
 b=P(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
prep=load(C/'KGM-CAPTURE-STATIC-PREPARATION-v1.json');names=['finish_capture_metadata_v1.py','derive_plan_v1.py','finalize_dependency_map_v1.py','prepare_support_inventory_v1.py','build_final_privacy_gate_v1.py'];scripts=[]
for name in names:
 p=C/name;ast.parse(p.read_bytes());scripts.append(pin(p))
copy=load(C/'PROPOSAL-SUPPORT-COPY-MAPPING-v1.json');assert copy['result']=='PASS_EXACT_GENERATED_METADATA_KEY_COPY';a,b=P(copy['original']['path']),P(copy['copy']['path']);assert pin(a)==copy['original'] and pin(b)==copy['copy'];before,after=a.read_bytes(),b.read_bytes();old=b'"authorization":';new=b'"approvalScope":';at=copy['changedKeyByteStart'];assert before.count(old)==1 and after==before[:at]+new+before[at+len(old):] and before[at:at+len(old)]==old and copy['originalKeyByteLength']==len(old) and copy['copyKeyByteLength']==len(new)
x,y=json.loads(before),json.loads(after);value=x['scopeAuthority'].pop('authorization');assert y['scopeAuthority'].pop('approvalScope')==value and x==y
classification=load(copy['classification']['path']);assert pin(copy['classification']['path'])==copy['classification'];assert hashlib.sha256(value.encode()).hexdigest()==classification['valueUtf8SHA256'] and len(value.encode())==classification['valueUtf8Bytes']
for name in ['independent_kgm_recovery_v1.py','build_independent_kgm_replay_inputs_v1.py','finalize_independent_kgm_support_selection_v1.py']:ast.parse((C/name).read_bytes())
result={'result':'PASS_STATIC_EXACT_SUPPORT_AND_PLAN_ADAPTERS','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scripts':scripts,'checks':{'finalPlanExact133ArchiveMiniBaseAnd132Reused':True,'finalPlanFull694SourceAndSixChanged':True,'finalPlanExactFrozenNonSourceOverlay':True,'dependencyFinalizerPreserves164InheritedRecordsAndDynamicReviewedNewCount':True,'dependencyFinalizerChecksCanonicalHashAndEveryExactOldMember':True,'supportSealerConsumesExactReviewedSelectionAndNoPayloadTreeGlobs':True,'supportSealerRejectsRawPreliminaryProposalAndFutureOutputs':True,'supportSealerExactPriorOrNewDuplicateAliasesOnly':True,'supportSealerSelfIncludesSelectionAndReuseMapOnce':True,'privacyGateBindsExactReviewedEnginesAndReportsAndCompletedBoundedTerminals':True,'privacyGateChecksCompleteFreshMemberUnionAndAllCounterAgreement':True,'sourceProofCopyTransformsZero':True,'actualGeneratedMetadataKeyCopyParity':True},'proposalSupportCopy':pin(C/'PROPOSAL-SUPPORT-COPY-MAPPING-v1.json'),'sourceProofTransformations':0,'generatedSupportMetadataKeyRenames':1,'originalProposalUnchanged':True,'outsideKeyBytesAndValueExact':True,'codeExecutionOfReviewedAdapters':False,'payloadArchiveOrSeedReads':0}
out=C/'INDEPENDENT-KGM-SUPPORT-PLAN-ADAPTER-REVIEW-v1.json'
with out.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(pin(out)))
