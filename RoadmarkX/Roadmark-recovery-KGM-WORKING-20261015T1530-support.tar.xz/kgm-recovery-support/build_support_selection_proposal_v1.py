#!/usr/bin/env python3
"""Pin bounded checkpoint support only, before independent allowlist acceptance."""
from capture_v1 import *
import resource
assert resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456)
out=C/'SUPPORT-SELECTION-PROPOSAL-v1.json';assert not out.exists()
excluded={'KGM-METADATA-INVENTORY-PROPOSAL-v1.json','SUPPORT-SELECTION-PROPOSAL-v1.json','SUPPORT-SELECTION-v1.json','SUPPORT-MEMBER-INVENTORY.json','SUPPORT-REUSE-MAPPING.json','support-package.json','ARCHIVE-PLAN.json','RESTORE-PLAN.json','FRESH-ONLY-RESTORE-MANIFEST.json','ALL-ARCHIVE-PRIVACY-GATE.json'}
paths=set()
for p in C.iterdir():
 if p.name in excluded or p.name.startswith('library-'):continue
 if p.is_file():
  assert p.suffix in {'.py','.json','.txt','.md','.log','.err','.patch','.diff'},p.name
  paths.add(p)
for name in ['phase-logs','seed-read-invocations','audi-seed-read-invocations','deepal-seed-read-invocations']:
 folder=C/name
 if folder.exists():
  for p in folder.iterdir():
   assert p.is_file() and not p.is_symlink(),str(p)
   paths.add(p)
rows=[]
for p in sorted(paths):
 h,ident=check(p,{});rows.append({'path':str(p),'localRelativePath':p.relative_to(C).as_posix(),**h,'identity':ident})
assert rows and all(r['localRelativePath'] not in excluded for r in rows)
assert {p.name for p in C.glob('*.py')}<={r['localRelativePath'] for r in rows}
assert {'APPROVED-KGM-CAPTURE-SCOPE.json','IMAGE-PROVENANCE.json','SAVING-ANNOUNCEMENT.json','KGM-METADATA-INVENTORY-PROPOSAL-support-copy-v1.json','PROPOSAL-SUPPORT-COPY-MAPPING-v1.json'}<={r['localRelativePath'] for r in rows}
dump(out,{'status':'PENDING_INDEPENDENT_EXACT_SUPPORT_ALLOWLIST_REVIEW','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':rows,'excludedDirectNames':sorted(excluded),'excludedFolders':['selected-source-changes','selected-proof-sanitized-v1','post-seal-run','deliverables'],'scope':'Only current checkpoint support files, closed phase logs and in-memory-seed completion ledgers; no source/evidence trees, archive reads or private upload results','approvalScope':'Root-approved compact unique support, exact prior reuse, one separately classified generated-prose key copy','selectionBuilder':{'path':str(P(__file__)),**pin(__file__)},'noDeletedOrModifiedInputs':True,'noPayloadContentInspection':True,'rawPreliminaryProposalExcluded':True})
print(json.dumps({'result':'PENDING_INDEPENDENT_REVIEW','supportFiles':len(rows),'bytes':sum(r['bytes'] for r in rows)}))
