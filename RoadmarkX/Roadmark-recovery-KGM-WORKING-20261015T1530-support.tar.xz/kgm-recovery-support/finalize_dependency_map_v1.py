"""Bind independently reviewed metadata dependencies without assuming KGM new counts."""
from capture_v1 import *
proposalPath=C/'INDEPENDENT-KGM-DEPENDENCY-PROPOSAL-v1.json';proposal=load(proposalPath)
assert proposal['result']=='PASS_EXACT_METADATA_ONLY_DEPENDENCY_PROPOSAL'
basepath=BASE/'INHERITED-DEPENDENCY-RECONSTRUCTION-v1.json'
check(basepath,{'bytes':120847,'sha256':'c9dc5c96bce050942bb5b0dd8a458aaaf921435f92648d0b6d9555be84eb490a'});base=load(basepath)
assert len(base['dependencies'])==proposal['inheritedDependencyRecords']==proposal['unchangedInheritedRecords']==164
assert proposal['baseDependencyMap']=={'path':str(basepath),**pin(basepath)}
assert not proposal['relocationProposals'] and not proposal['inheritedPointerIntersections'],'New inherited relocation requires separate reviewed finalizer'
assert proposal['originalExpectedPathsAndHashesUnchanged'] and proposal['metadataOnly'] and proposal['externalPayloadReads']==proposal['archivePayloadReads']==0
dependencies=base['dependencies']+proposal['newDependencyRecords']
assert len(dependencies)==proposal['proposedDependenciesCount'] and len({r['originalPath'] for r in dependencies})==len(dependencies)
canonical=hashlib.sha256(json.dumps(dependencies,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert canonical==proposal['proposedDependenciesCanonicalSha256']
scope=load(C/'FROZEN-CAPTURE-SCOPE.json')
assert proposal['allSixFinalSourceChangedPaths']==['roadmark/'+n for n in scope['sourceChangedPaths']] and len(scope['sourceChangedPaths'])==6
assert proposal['frozenScope']=={'path':str(C/'FROZEN-CAPTURE-SCOPE.json'),**pin(C/'FROZEN-CAPTURE-SCOPE.json')}
baseManifest=BASE/'deliverables/Roadmark-RECOVERY-MANIFEST-MINI-WORKING-20261015.json';assert proposal['baseManifest']=={'path':str(baseManifest),**pin(baseManifest)}
old={r['path']:r for r in load(baseManifest)['files']}
for r in dependencies:
 assert r['pins']
 for p in r['pins']:
  assert p['expected']['path']==r['originalPath']
  assert {k:p['expected'][k] for k in ['bytes','sha256']}=={k:p['member'][k] for k in ['bytes','sha256']}
  assert old[p['member']['path']]=={k:p['member'][k] for k in ['path','bytes','sha256']}
  assert p['member']['path'] not in {'roadmark/'+n for n in scope['sourceChangedPaths']}
q={'schemaVersion':1,'result':'FINAL_LAYOUT_METADATA_BOUND_PENDING_FRESH_ARCHIVE_REPLAY','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseManifest':proposal['baseManifest'],'proposal':{'path':str(proposalPath),**pin(proposalPath)},'frozenScope':{'path':str(C/'FROZEN-CAPTURE-SCOPE.json'),**pin(C/'FROZEN-CAPTURE-SCOPE.json')},'count':len(dependencies),'originalExpectedPathsAndHashesUnchanged':True,'relocatedMemberPointers':0,'inheritedRelocatedMemberPointers':base['relocatedMemberPointers']+base.get('inheritedRelocatedMemberPointers',0),'inheritedMapping':{'path':str(basepath),**pin(basepath)},'unchangedInheritedRecords':len(base['dependencies']),'newRecords':len(proposal['newDependencyRecords']),'allSixFinalSourceChangedPathsIntersected':True,'inheritedPointerIntersections':[],'dependenciesCanonicalSha256':canonical,'dependencies':dependencies,'noExternalPayloadOrArchiveReads':True}
dump(C/'INHERITED-DEPENDENCY-RECONSTRUCTION-v1.json',q)
print(json.dumps({'result':q['result'],'records':len(dependencies),'newRecords':len(proposal['newDependencyRecords']),'currentRelocations':0}))
