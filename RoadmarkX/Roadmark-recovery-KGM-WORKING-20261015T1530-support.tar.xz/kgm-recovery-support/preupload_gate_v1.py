#!/usr/bin/env python3
"""Bind final fresh checks before preparing the archive upload request."""
from delivery_common_v1 import *

def main():
    gate, verification, plan = load(C / GATE), load(C / RECOVERY), load(C / 'RESTORE-PLAN.json')
    ck(gate['result'] == verification['result'] == 'PASS', 'fresh gates not passed')
    ck(gate['freshMembers'] == plan['freshFiles'] and gate['freshBytes'] == plan['freshBytes'] and
       gate['unclassifiedFindings'] == gate['errors'] == 0, 'fresh privacy accounting differs')
    ck(plan['source']['bytes'] < 15000000 and plan['fullSourceFiles'] == 694 and
       plan['baseArchivesReused'] == 132, 'source/base scope differs')
    ck(load(C / 'ARCHIVE-PLAN.json')['archives'] == plan['newArchives'], 'final archive pointers differ')
    verify_base_snapshot()
    author_inputs()
    application_scope(verification, load(C / 'APPLICATION-ASSERTION-CONTRACT.json'))
    support_scope = support_privacy_scope(gate, verification)
    members = file_map(load(C / 'support-package.json')['memberFiles'])
    for name in DELIVERY_SCRIPTS:
        check(C / name, members['kgm-recovery-support/' + name])
    uploads = []
    for row in plan['newArchives']:
        check(row['file'], row)
        uploads.append({'local_path': row['file'], 'purpose': 'create_library_file', 'library_artifact_type': 'other'})
    dump(C / 'PREUPLOAD-GATE.json', {'result': 'PASS', 'privacy': ref(C / GATE),
                                    'independentRecovery': ref(C / RECOVERY),
                                    'restorePlan': ref(C / 'RESTORE-PLAN.json'),
                                    'newArchives': len(uploads), 'sourceUnderStrict15000000': True,
                                    'approvalScope': 'Exact frozen KGM working recovery; no current TypeScript or release pass',
                                    'supportOnlySyntaxClassification': support_scope,
                                    'noBaseRestoreOrFullBaseScan': True,
                                    'targetedSeedDependency': ref(C / 'TARGETED-SEED-READ-DEPENDENCY.json'),
                                    'rawDeepalOriginalReadRecoveryRefetchForbidden': True, 'rawKgmOriginalReadRecoveryRefetchForbidden': True})
    dump(C / 'library-archives-request.json', {'uploads': uploads})
    print('PASS: verified final archives ready for ordered prepared persistence')

if __name__ == '__main__':
    main()
