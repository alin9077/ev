#!/usr/bin/env python3
"""Verify exact narrow metadata filename corrections and preserved failed attempt."""
import ast,datetime,hashlib,json,pathlib,resource,stat
P=pathlib.Path;C=P(__file__).resolve().parent;assert resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456)
def pin(p):
 p=P(p);s=p.lstat();assert stat.S_ISREG(s.st_mode);b=p.read_bytes();assert s==p.lstat();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p):return json.loads(P(p).read_bytes())
pairs=[('classify_independent_kgm_support_syntax_v2.py','classify_independent_kgm_support_syntax_v3.py',[(b'support-pattern-preflight-v1.resources.json',b'support-preflight-v1.resources.json')]),('build_independent_kgm_replay_inputs_v1.py','build_independent_kgm_replay_inputs_v2.py',[(b'support-pattern-preflight-v',b'support-preflight-v'),(b"code==0 or p.name=='independent-inspect-dependencies-v1.resources.json' and code==1 or bool(match) and code==2",b'code==0 or bool(match) and code==2')])]
checks=[]
for old,new,replacements in pairs:
 a=(C/old).read_bytes();b=(C/new).read_bytes();expected=a
 for before,after in replacements:assert expected.count(before)==1;expected=expected.replace(before,after,1)
 assert b==expected;ast.parse(a);ast.parse(b);checks.append({'original':pin(C/old),'corrected':pin(C/new),'exactReplacementCount':len(replacements),'outsideReplacementBytesEqual':True})
failed=C/'classify-support-syntax-v2.resources.json';f=load(failed);assert f['exitCode']==1 and not f['timedOut'] and f['command']==['python',str(C/'classify_independent_kgm_support_syntax_v2.py')]
preflight=C/'support-preflight-v1.resources.json';p=load(preflight);assert p['exitCode']==2 and not p['timedOut'] and str(C/'preflight_support_patterns_v1.py') in p['command']
out={'result':'PASS_EXACT_METADATA_FILENAME_CORRECTIONS','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'failedAttempt':pin(failed),'failedInvocation':pin(C/'classify-support-syntax-v2.resources.invocation.json'),'observedDiagnosticSummary':pin(C/'phase-logs/classify-support-syntax-v2-observed-diagnostic.txt'),'verbatimFailureOutputRetained':False,'actualPreflightTerminal':pin(preflight),'detectorSourceArchiveAndBlockingAssertionsUnchanged':True,'historicalFailureSpecialCaseRemoved':True,'allNonzeroNonPreflightFailuresRequireExactReviewedTerminalPin':True,'noPayloadArchiveOrSeedReads':True}
target=C/'INDEPENDENT-KGM-METADATA-CORRECTION-REVIEW-v1.json'
with target.open('x') as h:json.dump(out,h,indent=2);h.write('\n')
print(json.dumps(pin(target)))
