from capture_v1 import C,load,dump
source=load(C/'source-package.json');proof=load(C/'proof-packages-v1.json')['archives'];assert proof
dump(C/'ARCHIVE-PLAN-initial.json',{'archives':[source]+proof,'scope':'Source and proof only; final plan adds one unique support archive with these archive identities unchanged'})
