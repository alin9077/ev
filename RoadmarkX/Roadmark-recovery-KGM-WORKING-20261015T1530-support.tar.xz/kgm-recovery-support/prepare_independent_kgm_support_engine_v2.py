#!/usr/bin/env python3
"""Prepare literal support-only hook after approval of the actual three-candidate set."""
import ast,hashlib,json,pathlib,resource
P=pathlib.Path;C=P(__file__).resolve().parent
assert resource.getrlimit(resource.RLIMIT_AS)==(268435456,268435456)
def pin(p):
 b=P(p).read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
approval=json.loads((C/'APPROVED-KGM-SUPPORT-SYNTAX.json').read_bytes());assert approval['result']=='APPROVED_EXACT_SYNTAX_CLASSIFICATION' and approval['exactCandidates']==3;assert pin(C/'INDEPENDENT-KGM-SUPPORT-SYNTAX-CLASSIFICATION-v1.json')==approval['classificationPin'];base=C/'privacy_v1.py';assert pin(base)=={'bytes':15310,'sha256':'5c8981f69d021b1ca18a69f95036b7cb25e26e35cf455c513d8ed7c3ad5ea601'};before=base.read_bytes();needle=b'us,classified=template_context(us,data,m.name);';hook=b'from kgm_support_classifications_v2 import code_context as kgm_code_context;ps,classified=kgm_code_context(ps,data,m.name);codeClassified.extend(classified);';assert before.count(needle)==1;after=before.replace(needle,hook+needle);ast.parse(after);out=C/'privacy_v2_support.py'
with out.open('xb') as f:f.write(after)
assert out.read_bytes()==after;print(json.dumps({'result':'PREPARED_EXACT_SUPPORT_HOOK_PENDING_INDEPENDENT_TEST','path':str(out),**pin(out)}))
