"""Three exact approved whole-file/span/line/AST syntax cases, never a broad exemption."""
import ast,hashlib,json
from capture_v1 import C,load,check
CLASSIFICATION=C/'INDEPENDENT-KGM-SUPPORT-SYNTAX-CLASSIFICATION-v1.json'
def code_context(candidates,data,name):
 approval=load(C/'APPROVED-KGM-SUPPORT-SYNTAX.json');assert approval['result']=='APPROVED_EXACT_SYNTAX_CLASSIFICATION' and approval['exactCandidates']==3;check(CLASSIFICATION,approval['classificationPin']);d=load(CLASSIFICATION);assert d['result']=='INDEPENDENT_BENIGN_SYNTAX_PROPOSAL_REQUIRES_ROOT_APPROVAL' and d['primaryCandidates']==3 and d['rawRuntimeCandidates']==0
 counts={n:sum(r['member']==n for r in d['exactSupportCodeClassifications']) for n in {r['member'] for r in d['exactSupportCodeClassifications']}};assert counts=={'kgm-recovery-support/capture_v1.py':2,'kgm-recovery-support/review_independent_kgm_support_plan_v1.py':1};rows=[r for r in d['exactSupportCodeClassifications'] if r['member']==name]
 if not rows:return candidates,[]
 actual={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};assert all(r['filePin']==actual for r in rows);tree=ast.parse(data);lines=data.decode('utf-8').splitlines();expected=[{k:v for k,v in r['exactFinding'].items() if k!='member'} for r in rows];assert len(expected)==len({json.dumps(r,sort_keys=True) for r in expected});classified=[];blocked=[]
 for candidate in candidates:
  if candidate not in expected:blocked.append(candidate);continue
  r=rows[expected.index(candidate)];assert hashlib.sha256(data[r['byteStart']:r['byteEndExclusive']]).hexdigest()==r['matchedSyntaxSHA256'];line=candidate['location']['line'];assert hashlib.sha256(lines[line-1].encode()).hexdigest()==r['lineSHA256']
  if r['astStatementType']=='LineStatementSequence':
   statements=sorted([n for n in ast.walk(tree) if isinstance(n,ast.stmt) and n.lineno==n.end_lineno==line],key=lambda n:n.col_offset);assert len(statements)==r['astStatementCount'];actual_ids=[{'type':type(n).__name__,'colOffset':n.col_offset,'endColOffset':n.end_col_offset,'astSHA256':hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest()} for n in statements];assert actual_ids==r['astStatements'];node=ast.Module(body=statements,type_ignores=[])
  else:
   statements=[n for n in ast.walk(tree) if isinstance(n,ast.stmt) and n.lineno==line and type(n).__name__==r['astStatementType']];assert len(statements)==1;node=statements[0]
  assert hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest()==r['astStatementSHA256'];classified.append({'member':name,'filePin':actual,'finding':candidate,'classification':r['classification']})
 assert len(classified)==len(rows) and sorted(json.dumps(r['finding'],sort_keys=True) for r in classified)==sorted(json.dumps(r,sort_keys=True) for r in expected)
 return blocked,classified
