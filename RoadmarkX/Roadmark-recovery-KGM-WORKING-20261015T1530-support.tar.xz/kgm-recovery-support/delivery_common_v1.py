#!/usr/bin/env python3
"""Small identity helpers; no payload extraction, scanning or source embedding."""
import datetime
import hashlib
import json
import os
import pathlib
import stat

C = pathlib.Path(__file__).resolve().parent
BASE = C.parent / 'mini-working-20261015T1330'
D = C / 'deliverables'
STEM = 'KGM-WORKING-20261015'
CHUNK = 65536
LIMIT = 268435456
DOCS = [D / ('Roadmark-RECOVERY-' + kind + '-' + STEM + suffix) for kind, suffix in
        [('INDEX', '.md'), ('MANIFEST', '.json'), ('VERIFICATION', '.json')]]
DOCS.append(D / 'Roadmark-KGM-M1-UPDATE-20261015.md')
ACTIVE = D / ('Roadmark-RECOVERY-ACTIVE-STATE-' + STEM + '.json')
BASE_MANIFEST = BASE / 'deliverables/Roadmark-RECOVERY-MANIFEST-MINI-WORKING-20261015.json'
BASE_TERMINAL = BASE / 'FINAL-MINI-UPLOAD-RECEIPTS.json'
RECOVERY = 'INDEPENDENT-KGM-RECOVERY-VERIFICATION-v1.json'
GATE = 'ALL-ARCHIVE-PRIVACY-GATE.json'
DEPENDENCY = 'INHERITED-DEPENDENCY-RECONSTRUCTION-v1.json'
COUNT_KEYS = ('archiveCount', 'logicalFiles', 'logicalBytes', 'freshFiles', 'freshBytes',
              'fullSourceFiles', 'baseArchivesReused')
INHERIT_KEYS = ('sourceSanitation', 'originalRawCaptureReplayCompatibility',
               'missingHistoricalCaptureProvenance', 'priorToyotaBrowserScreenshotExclusions',
               'sourcePackagingExclusions', 'historicalExclusions', 'lastPassedRecovery',
               'optionalReconstruction', 'partialOutputRetention', 'reusedVerifier',
               'cleanupCandidatesExcludedFromRestore', 'cleanupListLibraryFileId',
               'exactDuplicateProvenance')
DELIVERY_SCRIPTS = ('delivery_common_v1.py', 'build_documents_v1.py',
                    'independent_kgm_documents_v1.py', 'build_active_receipt_v1.py',
                    'finalize_upload_receipt_v1.py', 'preupload_gate_v1.py',
                    'scan_documents_v1.py')

def ck(value, message):
    if not value:
        raise AssertionError(message)

def load(path):
    return json.loads(pathlib.Path(path).read_text())

def dump(path, value):
    with pathlib.Path(path).open('x') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def pin(path):
    path = pathlib.Path(path)
    before = path.lstat()
    ck(stat.S_ISREG(before.st_mode) and not any(p.is_symlink() for p in path.parents),
       'not an ordinary unlinked file: ' + str(path))
    digest, size = hashlib.sha256(), 0
    with path.open('rb') as handle:
        while block := handle.read(CHUNK):
            digest.update(block)
            size += len(block)
    after = path.lstat()
    ck((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
       (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
       'file changed during pin: ' + str(path))
    ck(size == before.st_size, 'short file read')
    return {'bytes': size, 'sha256': digest.hexdigest()}

def check(path, expected):
    actual = pin(path)
    ck(actual == {key: expected[key] for key in ('bytes', 'sha256')}, 'pin differs: ' + str(path))
    return actual

def ref(path):
    path = pathlib.Path(path)
    return {'path': path.relative_to(C).as_posix() if path.is_relative_to(C) else str(path), **pin(path)}

def verify_base_snapshot():
    expected = {
        BASE_MANIFEST: {'bytes': 3110386, 'sha256': '1564e57d37227ff2635d65e85c91fe7a851ccf8f92f08cce290e511bd9335f7c'},
        BASE_TERMINAL: {'bytes': 16806, 'sha256': '87bfb87d03e9251f3de546ba87601b380493993dcc14ceff59c6ddf60ba0aefd'},
        BASE / 'INDEPENDENT-MINI-TERMINAL-CLOSURE-v1.json': {'bytes': 11529, 'sha256': '3d79ee674b70bb82986906ec67ca3ac8720a929ed9df05b7fed46b4978cd328c'}}
    for path, wanted in expected.items():
        check(path, wanted)
    manifest, terminal = load(BASE_MANIFEST), load(BASE_TERMINAL)
    ck(len(manifest['archivesInRestoreOrder']) == 133 and len(manifest['files']) == 12781 and
       manifest['workState']['fullProjectTypeScriptPassed'] is True and
       manifest['workState']['releaseReady'] is False, 'historical MINI status/counts differ')
    ck(load(BASE / 'INDEPENDENT-MINI-TERMINAL-CLOSURE-v1.json')['result'] == 'PASS_TERMINAL_RECOVERY_CLOSURE',
       'historical MINI terminal closure absent')
    ck(terminal['sourceLibraryFileId'] == manifest['source']['library_file_id'], 'historical MINI source identity differs')
    return {str(path.relative_to(BASE)): wanted for path, wanted in expected.items()}

def replay_metadata(name):
    inputs = load(C / 'INDEPENDENT-KGM-REPLAY-INPUTS-v1.json')
    selected = inputs['metadata'][name]
    path = pathlib.Path(selected['path'])
    ck(path.is_absolute() and path.is_relative_to(C), 'selected current metadata must be inside this checkpoint')
    check(path, selected)
    return path, load(path)

def json_pointer(value, path):
    ck(isinstance(path, str) and path.startswith('/'), 'invalid classification counter pointer')
    for part in path.split('/')[1:]:
        part = part.replace('~1', '/').replace('~0', '~')
        value = value[int(part)] if isinstance(value, list) else value[part]
    return value

def deepal_adapter():
    path = C / 'KGM-PRIVACY-ADAPTER-CONTRACT.json'
    contract = load(path)
    ck(contract['result'] == 'APPROVED_KGM_INHERITED_PRIVACY_ADAPTER', 'current inherited privacy adapter not approved')
    inherited_path = BASE / 'MINI-PRIVACY-ADAPTER-CONTRACT.json'
    inherited_pin = {'bytes': 3200, 'sha256': 'a72617c4d3ff02081707e0f8a03c44f2034ba3b8e18f5111cdcf14973af6e121'}
    ck(contract['inheritedContract'] == {'path': str(inherited_path), **inherited_pin}, 'inherited adapter contract path/pin differs')
    check(inherited_path, inherited_pin)
    inherited = load(inherited_path)
    ck(inherited['result'] == 'APPROVED_MINI_INHERITED_PRIVACY_ADAPTER', 'inherited adapter approval absent')
    for key in ('classification', 'approval', 'additiveInventory', 'classificationCounterPointers'):
        ck(contract[key] == inherited[key], 'inherited privacy scope differs: ' + key)
    script_pairs = (
        ('engine', 'privacy_v1.py', 'privacy_v4.py', {'bytes': 15310, 'sha256': '687d7652ca3c7770b57c56d840c3b8ffee4c551a6aed0b3c14e653b2000b9336'}),
        ('addition', 'deepal_scan_additions_v2.py', 'deepal_scan_additions_v2.py', {'bytes': 4049, 'sha256': 'd37a40015ef947be4ac7af7c45f4310f99951ae3b302980c4ce892c5c035c061'}),
        ('audiAddition', 'audi_scan_additions_v3.py', 'audi_scan_additions_v3.py', {'bytes': 3201, 'sha256': '9741973e27ce22de4bb8127dbe1d0e443e71dade87518fe57703b2575fe22e58'}))
    for key, current_name, previous_name, previous_pin in script_pairs:
        current_path, previous_path = C / current_name, BASE / previous_name
        ck(contract[key]['path'] == str(current_path), 'adapter script path differs: ' + key)
        check(current_path, contract[key]); check(previous_path, previous_pin)
        previous, current = previous_path.read_bytes(), current_path.read_bytes()
        before, after = b'from capture_v2 import', b'from capture_v1 import'
        ck(previous.count(before) == 1 and current == previous.replace(before, after), 'adapter changed beyond one exact import: ' + key)
    for key in ('engineAdaptationReview', 'captureScannerAdapterReview'):
        review_path = pathlib.Path(contract[key]['path'])
        ck(review_path.parent == C and review_path.name.startswith('INDEPENDENT-KGM-'), 'current review path differs')
        check(review_path, contract[key])
        review = load(review_path)
        ck(str(review['result']).startswith('PASS'), 'current independent adaptation review did not pass')
        if key == 'engineAdaptationReview':
            ck(contract[key] == {'path': str(C / 'INDEPENDENT-KGM-PRIVACY-ADAPTER-REVIEW-v1.json'),
                                'bytes': 2547, 'sha256': 'dfed9c274f7e5a672e0268d963fce87afdf3960d0f33ade281d483763de4c9e5'} and
               review['result'] == 'PASS_EXACT_IMPORT_ONLY_PRIVACY_ADAPTATION' and
               all(review[field] for field in ('allPatternRulesSelectorsAndSearchesByteUnchanged', 'noSeedOrPayloadReads', 'noRuleBroadening')),
               'exact current import-only review differs')
    for key in ('classification', 'approval', 'additiveInventory'):
        location = pathlib.Path(contract[key]['path'])
        ck(location.is_absolute() and location.parent == BASE.parent / 'deepal-working-20261015T1110', 'historical Deepal provenance path differs')
        check(location, contract[key])
    classification = load(contract['classification']['path'])
    approval = load(contract['approval']['path'])
    ck(approval['classificationPin'] == {key: contract['classification'][key] for key in ('bytes', 'sha256')} and approval['copyOnly'], 'copy-only approval differs')
    ck(classification['additiveInventory'] == contract['additiveInventory'] and approval['additiveInventoryPin'] ==
       {key: contract['additiveInventory'][key] for key in ('bytes', 'sha256')}, 'additive inventory identity differs')
    pointers = contract['classificationCounterPointers']
    ck(set(pointers) == {'deepalRuntimeValues', 'deepalRuntimeForms', 'deepalOriginalPayloadReadOperations'}, 'counter pointer set differs')
    counters = {key: json_pointer(classification, pointer) for key, pointer in pointers.items()}
    ck(counters == {'deepalRuntimeValues': 6, 'deepalRuntimeForms': 41, 'deepalOriginalPayloadReadOperations': 5}, 'inherited Deepal counter scope differs')
    expected_reads = [{'path': row['capturedPayloadPath'], 'pin': row['originalPin'], 'payloadReadOperations': 1,
                       'valueRanges': len(row['ranges'])} for row in classification['files']]
    ck(len(expected_reads) == counters['deepalOriginalPayloadReadOperations'] and len({row['path'] for row in expected_reads}) == len(expected_reads), 'Deepal exact read map differs')
    return contract, counters, expected_reads

POST_SEAL_SERIALIZATION = {'encoding': 'UTF-8', 'indent': 2, 'ensure_ascii': True, 'sort_keys': False,
                           'separators': [',', ': '], 'trailingNewline': True}
POST_SEAL_RESULTS = {RECOVERY: 'PASS', GATE: 'PASS',
                     'INDEPENDENT-KGM-REPLAY-INPUTS-v1.json': 'APPROVED_PINNED_FRESH_REPLAY_INPUTS'}

def reject_embedded_bodies(value):
    no_embedded_source(value)
    if isinstance(value, dict):
        ck(not ({'archivesInRestoreOrder', 'files'} <= set(value)), 'full prior manifest embedded')
        ck('postSealReceipts' not in value, 'nested post-seal receipt envelope')
        for key, item in value.items():
            ck(not (key.lower() in ('scripttext', 'sourcetext', 'body', 'content', 'stdout', 'stderr', 'log', 'traceback', 'text', 'code') and
                    isinstance(item, str) and item), 'script or log body embedded')
            reject_embedded_bodies(item)
    elif isinstance(value, list):
        for item in value:
            reject_embedded_bodies(item)
    elif isinstance(value, str):
        ck(len(value) < 8192 and not any(marker in value for marker in ('\ndef ', '\nclass ', '#!/usr/', '<script', '<html')),
           'source-like or oversized text body embedded')

def reserialize_receipt(record):
    reject_embedded_bodies(record)
    return (json.dumps(record, indent=2, ensure_ascii=True, sort_keys=False, separators=(',', ': '), allow_nan=False) + '\n').encode('utf-8')

def post_seal_receipts():
    rows = []
    for name, required_result in POST_SEAL_RESULTS.items():
        path = C / name
        original = path.read_bytes()
        record = json.loads(original)
        ck(record['result'] == required_result, 'data-only receipt result differs from exact filename allowlist')
        rebuilt = reserialize_receipt(record)
        ck(rebuilt == original, 'receipt does not follow declared exact serialization')
        rows.append({'filename': name, **pin(path), 'serialization': POST_SEAL_SERIALIZATION, 'record': record})
    return rows

def check_post_seal_receipts(rows):
    ck([row['filename'] for row in rows] == list(POST_SEAL_RESULTS), 'post-seal receipt set/order differs')
    for row in rows:
        ck(row['serialization'] == POST_SEAL_SERIALIZATION and row['record']['result'] == POST_SEAL_RESULTS[row['filename']],
           'receipt serialization or exact filename result differs')
        rebuilt = reserialize_receipt(row['record'])
        expected = {'bytes': len(rebuilt), 'sha256': hashlib.sha256(rebuilt).hexdigest()}
        ck(expected == {key: row[key] for key in ('bytes', 'sha256')} == pin(C / row['filename']) and
           rebuilt == (C / row['filename']).read_bytes(), 'reconstructed receipt bytes or pin differ')
    return [{'filename': row['filename'], 'bytes': row['bytes'], 'sha256': row['sha256']} for row in rows]

def safe_member(name):
    path = pathlib.PurePosixPath(name)
    ck(name and not path.is_absolute() and '..' not in path.parts and str(path) == name and '\\' not in name,
       'unsafe member path')

def file_map(rows):
    result = {}
    for row in rows:
        safe_member(row['path'])
        ck(row['path'] not in result, 'duplicate member')
        ck(isinstance(row['bytes'], int) and row['bytes'] >= 0 and len(row['sha256']) == 64, 'invalid pin')
        result[row['path']] = row
    return result

def native(phase, expected=None):
    request = load(C / ('library-' + phase + '-request.json'))['uploads']
    result = load(C / ('library-' + phase + '-results.json'))['results']
    witnesses = [json.loads(line) for line in (C / ('library-' + phase + '-verified.jsonl')).read_text().splitlines()]
    ck(len(request) == len(result) == len(witnesses), 'native phase lengths differ')
    rows = []
    for wanted, value, witness in zip(request, result, witnesses):
        path = pathlib.Path(wanted['local_path'])
        ck(value['status'] == 'succeeded' and value['local_metadata_applied'] and
           value['local_path'] == str(path) and value['file_name'] == path.name, 'native upload not verified')
        ck(witness['verified'] and witness['filename'] == path.name and
           witness['library_file_id'] == value['library_file_id'] and
           witness['version'] == value['current_version_number'], 'native witness differs')
        ck(os.getxattr(path, 'user.library-file-id').decode() == value['library_file_id'] and
           os.getxattr(path, 'user.library-file-version').decode() == str(value['current_version_number']),
           'local native identity differs')
        actual = {key: witness[key] for key in ('bytes', 'sha256')}
        if expected is None:
            ck(actual == pin(path), 'persisted document bytes differ')
        else:
            ck(path.name in expected and actual == expected[path.name] and
               path.stat().st_size == actual['bytes'], 'persisted archive pin differs')
        rows.append({'filename': path.name, 'library_file_id': value['library_file_id'],
                     'file_id': value['file_id'], 'version': value['current_version_number'], **actual})
    ck(len({row['filename'] for row in rows}) == len(rows) and
       len({row['library_file_id'] for row in rows}) == len(rows), 'duplicate native identity')
    if expected is not None:
        ck(set(expected) == {row['filename'] for row in rows}, 'native archive set differs')
    return rows

def final_archives(plan):
    expected = {row['filename']: {key: row[key] for key in ('bytes', 'sha256')} for row in plan['newArchives']}
    persisted = {row['filename']: row for row in native('archives', expected)}
    result = []
    for item in plan['archivesInRestoreOrder']:
        row = {key: value for key, value in item.items() if key not in ('file', 'memberFiles', 'allMembersVerified')}
        if row.get('new'):
            row.update({key: persisted[row['filename']][key] for key in ('library_file_id', 'file_id', 'version')})
        ck(row['library_file_id'] and row['file_id'] and isinstance(row['version'], int), 'archive native identity absent')
        result.append(row)
    ck([row['restoreOrder'] for row in result] == list(range(1, len(result) + 1)), 'restore order differs')
    ck(len(result) == plan['archiveCount'] and len({row['filename'] for row in result}) == len(result), 'archive count differs')
    return result

def no_embedded_source(value):
    if isinstance(value, dict):
        ck(not {'verificationSupportFiles', 'postSealCompactEvidence', 'scriptText', 'sourceText'} & set(value),
           'recursive evidence or executable text field')
        if 'filename' in value and 'text' in value:
            ck(not str(value['filename']).endswith(('.py', '.js', '.ts', '.sh')), 'executable text embedded')
        for child in value.values():
            no_embedded_source(child)
    elif isinstance(value, list):
        for child in value:
            no_embedded_source(child)

def seed_summary():
    summaries = {}
    for kind, directory in [('historical', 'seed-read-invocations'), ('audi', 'audi-seed-read-invocations')]:
        rows = []
        for path in sorted((C / directory).glob('*.json')):
            value = load(path)
            if kind == 'historical':
                ck(value['exactPinnedMembersReadAndVerified'] == 200 and value['historicalArchives'] == 21 and
                   value['noExtractedValuesPersisted'], 'historical seed receipt scope differs')
            else:
                ck(value['distinctValues'] == 6 and value['variantForms'] == 37 and
                   value['payloadReadOperations'] == 6 and value['uniqueOriginalFiles'] == 4 and
                   value['noValuesOrValueDigestsPersisted'], 'Audi seed receipt scope differs')
            rows.append({**ref(path), 'completedAt': value['completedAt'], 'processId': value['processId']})
        summaries[kind] = {'asOf': max((r['completedAt'] for r in rows), default=None),
                           'completedInvocations': len(rows), 'receiptReferences': rows,
                           'noExtractedValuesOrValueDigests': True}
        if kind == 'historical':
            summaries[kind].update(uniquePinnedMembers=200, uniqueHistoricalArchives=21,
                                   targetedPinnedMemberReads=200 * len(rows))
        else:
            summaries[kind].update(distinctValues=6, variantForms=37, uniqueOriginalFiles=4,
                                   payloadReadOperations=6 * len(rows))
    scope = load(C / 'INHERITED-LOCAL-SEED-READ-SCOPE.json')
    ck(scope['result'] == 'EXACT_UNCHANGED_SELECTOR_ACCOUNTING_SPECIFICATION' and len(scope['files']) == 48 and
       scope['payloadValueReadsPerSuccessfulInvocation'] == scope['streamingIntegrityReadsPerSuccessfulInvocation'] == 48,
       'inherited local seed accounting scope differs')
    count = summaries['historical']['completedInvocations']
    ck(count == summaries['audi']['completedInvocations'], 'incomplete paired seed ledgers')
    summaries['inheritedLocal'] = {'specification': ref(C / 'INHERITED-LOCAL-SEED-READ-SCOPE.json'),
                                  'completedInvocations': count, 'uniqueOriginalFiles': 48,
                                  'payloadValueReads': 48 * count, 'streamingIntegrityReads': 48 * count,
                                  'accountingMethod': 'Derived from reviewed selector control flow and paired seed completion ledgers; not separate per-file instrumentation',
                                  'noValuesOrValueDigestsPersisted': True}
    contract, counters, expected_reads = deepal_adapter()
    deepal_rows = []
    for path in sorted((C / 'deepal-seed-read-invocations').glob('*.json')):
        value = load(path)
        ck(value['classificationReceiptPin'] == {key: contract['classification'][key] for key in ('bytes', 'sha256')} and
           value['distinctValues'] == counters['deepalRuntimeValues'] and value['variantForms'] == counters['deepalRuntimeForms'] and
           value['payloadReadOperations'] == counters['deepalOriginalPayloadReadOperations'] and value['reads'] == expected_reads,
           'Deepal seed receipt identity/count/read scope differs')
        ck(value['noValuesOrValueDigestsPersisted'] and not value['rawDeepalApiManagerOriginalRead'] and
           value['URLComponentRepresentationIncludedByUnchangedVariantsFunction'] and not value['generalArbitraryDecodedCoverageClaimed'],
           'Deepal raw-body or decoding boundary differs')
        deepal_rows.append({**ref(path), 'completedAt': value['completedAt'], 'processId': value['processId']})
    summaries['deepal'] = {'asOf': max((row['completedAt'] for row in deepal_rows), default=None),
                           'completedInvocations': len(deepal_rows), 'receiptReferences': deepal_rows,
                           'classification': contract['classification'], 'adapterContract': ref(C / 'KGM-PRIVACY-ADAPTER-CONTRACT.json'),
                           'distinctValues': counters['deepalRuntimeValues'], 'variantForms': counters['deepalRuntimeForms'],
                           'uniqueOriginalFiles': len(expected_reads),
                           'payloadReadOperations': counters['deepalOriginalPayloadReadOperations'] * len(deepal_rows),
                           'noValuesOrValueDigestsPersisted': True, 'rawDeepalApiManagerOriginalRead': False,
                           'historicalPreAdapterScansCountedInPriorReceipts': True}
    return summaries

def check_seed_summary(value, complete=False):
    actual = seed_summary()
    for kind in ('historical', 'audi'):
        selected, current = value[kind], actual[kind]
        refs = selected['receiptReferences']
        cutoff = selected['asOf']
        wanted = [row for row in current['receiptReferences'] if cutoff and row['completedAt'] <= cutoff]
        ck(refs == wanted and selected['completedInvocations'] == len(refs), 'seed as-of scope differs')
        for key, item in selected.items():
            if key not in ('asOf', 'completedInvocations', 'receiptReferences', 'targetedPinnedMemberReads', 'payloadReadOperations'):
                ck(current[key] == item, 'seed fixed scope differs')
        total = 'targetedPinnedMemberReads' if kind == 'historical' else 'payloadReadOperations'
        ck(selected[total] == len(refs) * (200 if kind == 'historical' else 6), 'seed total differs')
        if complete:
            ck(selected == current, 'terminal omits a seed invocation')
    inherited = value['inheritedLocal']
    count = value['historical']['completedInvocations']
    ck(count == value['audi']['completedInvocations'] and inherited ==
       {**actual['inheritedLocal'], 'completedInvocations': count, 'payloadValueReads': 48 * count,
        'streamingIntegrityReads': 48 * count}, 'inherited local seed totals differ')
    selected, current = value['deepal'], actual['deepal']
    refs = selected['receiptReferences']
    cutoff = selected['asOf']
    wanted = [row for row in current['receiptReferences'] if cutoff and row['completedAt'] <= cutoff]
    expected = {**current, 'asOf': cutoff, 'completedInvocations': len(refs), 'receiptReferences': wanted,
                'payloadReadOperations': current['uniqueOriginalFiles'] * len(refs)}
    ck(refs == wanted and selected == expected, 'Deepal seed as-of boundary or accounting differs')
    if complete:
        ck(value == actual, 'terminal seed account is incomplete')
    return {kind: {key: item for key, item in data.items() if key != 'receiptReferences'} for kind, data in value.items()}

def privacy(name, paths):
    value = load(C / name)
    ck(value['result'] == 'PASS' and not value['findings'] and not value['errors'] and
       value['currentCompletePatternScan'] and value['allKnownValueForms'], 'document privacy gate failed')
    ck(value['audiRuntimeValues'] == 6 and value['audiRuntimeForms'] == 37 and
       value['audiOriginalPayloadReadOperations'] == 6, 'current residual coverage differs')
    contract, counters, unused = deepal_adapter()
    ck(all(value[key] == number for key, number in counters.items()) and
       value['deepalAdapterContract'] == ref(C / 'KGM-PRIVACY-ADAPTER-CONTRACT.json') and
       value['privacyEngine'] == contract['engine'], 'inherited Deepal document residual coverage differs')
    seen = {}
    for row in value['files']:
        ck(row['filename'] not in seen and row['exactValueMatches'] == row['primaryCandidates'] == row['runtimeCandidates'] == 0,
           'duplicate privacy member or unresolved finding')
        ck(row['exactMatchesObserved'] == row['classifiedPublicLexicalCollisions'], 'privacy accounting differs')
        seen[row['filename']] = {key: row[key] for key in ('bytes', 'sha256')}
    ck(seen == {path.name: pin(path) for path in paths}, 'privacy input set or pins differ')
    return ref(C / name)


AUTHOR_INVENTORY = pathlib.Path('/tmp/kgm-packet/final-freeze-v1/inventory.json')
AUTHOR_ACCEPTANCE = pathlib.Path('/tmp/kgm-review/final-retention-v1-acceptance.json')
AUTHOR_INVENTORY_PIN = {'bytes': 116912, 'sha256': '475c849164197b932a2a22b0096fa8a71b5b10ea0584a0c183a51dbf76df29bd'}
AUTHOR_ACCEPTANCE_PIN = {'bytes': 5246, 'sha256': '40263bd910e7db029e9c85de29e746411b7537d8d6238003531cc02ceb0af817'}
KGM_SUMMARY_PIN = {'bytes': 5664, 'sha256': '53b86882ac888233fdf3df09199d398bc2eed1db048c142743b27b0b8550780f'}

def author_inputs():
    check(AUTHOR_INVENTORY, AUTHOR_INVENTORY_PIN)
    check(AUTHOR_ACCEPTANCE, AUTHOR_ACCEPTANCE_PIN)
    inventory, acceptance = load(AUTHOR_INVENTORY), load(AUTHOR_ACCEPTANCE)
    ck(acceptance['status'] == 'accepted' and acceptance['inventory'] == {'path': str(AUTHOR_INVENTORY), **AUTHOR_INVENTORY_PIN}, 'author acceptance does not bind final inventory')
    metadata = acceptance['payloadMetadata']
    ck(inventory['noFurtherPayloadEdits'] and inventory['totalFiles'] == metadata['files'] == 385 and
       inventory['regularFileBytes'] == metadata['bytes'] == 18677159 and inventory['symlinkCount'] == metadata['symlinks'] == 0,
       'author frozen scope differs')
    ck(inventory['sourceAndStatusAfterPins'] == acceptance['liveAfterPins'] and len(acceptance['liveAfterPins']) == 7 and
       acceptance['allSevenLiveTargetsRehashedAndExact'], 'author seven-target pins differ')
    ck(len(inventory['retainedFailures']) == 2 and acceptance['bothActualFailedTypeScriptAttemptsAndEmptyLogsRetained'] and
       acceptance['bothFreshTypeScriptCachesAbsent'] and acceptance['currentTypeScriptUnpassed'] and
       acceptance['factualReportExceptionExplicit'] and acceptance['releaseReady'] is False,
       'failure retention or factual-only boundary differs')
    ck(all(row['cause'] == 'unknown' and row['freshCacheAbsent'] and row['fullProjectTypecheckPassed'] is False
           for row in inventory['retainedFailures']), 'TypeScript failure cause/cache boundary differs')
    ck(inventory['currentValidation'] == {'fullProjectTypecheckPassed': False, 'releaseReady': False,
       'compilerRetriesAuthorized': False, 'factualCoverageOnly': True, 'priorMiniTypeScriptPass': 'Historical MINI27 source only'},
       'current validation exception differs')
    return inventory, acceptance

def dependency_summary(dependency):
    ck(dependency['count'] == len(dependency['dependencies']) and dependency['count'] >= 164 and
       dependency['originalExpectedPathsAndHashesUnchanged'], 'dependency count or original expected-pin boundary differs')
    canonical = hashlib.sha256(json.dumps(dependency['dependencies'], sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    ck(canonical == dependency['dependenciesCanonicalSha256'], 'dependency mapping canonical hash differs')
    return {'receipt': ref(C / DEPENDENCY), 'count': dependency['count'],
            'relocatedMemberPointers': dependency['relocatedMemberPointers'], 'newRecords': dependency['newRecords']}

def saving_announcement():
    value = load(C / 'SAVING-ANNOUNCEMENT.json')
    ck(value['messageId'] == 'Sentinel_086f0b3b994481919051716b2ef10feb' and
       value['sentAt'] == '2026-10-15T15:51:57.786190Z', 'saving announcement identity differs')
    return ref(C / 'SAVING-ANNOUNCEMENT.json')


def support_privacy_scope(gate, recovery):
    archive_rows = [row for row in gate['archives'] if row['archive'].endswith('-support.tar.xz')]
    ck(len(archive_rows) == 1, 'support privacy receipt missing or duplicated')
    support_row = archive_rows[0]
    header_count = gate['classifiedExactCodeHeaderCandidates']
    template_count = gate['classifiedExactTemplateRuntimeCandidates']
    ck(template_count == 0 and support_row['classifiedExactCodeHeaderCandidates'] == header_count and
       all(row['classifiedExactCodeHeaderCandidates'] == row['classifiedExactTemplateRuntimeCandidates'] == 0
           for row in gate['archives'] if row is not support_row), 'classification escaped support-only scope')
    report_path = pathlib.Path(support_row['report'])
    ck(report_path.parent == C, 'support scan report is outside current checkpoint')
    check(report_path, support_row['reportPin'])
    report = load(report_path)
    ck(report['status'] == 'clean' and not any(report[key] for key in
       ('exactValueMatches', 'primaryHeaderCandidates', 'unclassifiedRuntimeCandidates', 'errors',
        'classifiedExactTemplateRuntimeCandidates')), 'support report has unresolved findings')
    if header_count == 0:
        ck(not report['classifiedExactCodeHeaderCandidates'] and recovery['privacy']['exactPinnedCodeSyntaxClassifications'] == 0 and
           recovery['privacy']['exactPinnedTemplateSyntaxClassifications'] == 0, 'unexpected clean-support classifications')
        return {'exactApprovedSyntaxCandidates': 0, 'unresolvedCandidates': 0, 'scanReport': ref(report_path),
                'scope': 'No support syntax classification used', 'documentScannerUnchanged': True,
                'payloadRedactions': 0, 'fileExtensionExemption': False}
    contract_path = C / 'KGM-SUPPORT-PRIVACY-CONTRACT-v1.json'
    contract = load(contract_path)
    ck(contract['result'] == 'APPROVED_KGM_SUPPORT_PRIVACY_ADAPTER' and contract['supportArchiveOnly'] and
       contract['noDetectorOrKnownValueSearchChanges'] and contract['exactApprovedCandidates'] == header_count,
       'current KGM support-only adapter not approved')
    fields = ('supportEngine', 'supportSyntaxHandler', 'supportSyntaxApproval', 'classification', 'baseEngine', 'independentReview')
    for key in fields:
        location = pathlib.Path(contract[key]['path'])
        ck(location.parent == C, 'support adapter dependency is not current KGM: ' + key)
        check(location, contract[key])
    adapter, unused_counters, unused_reads = deepal_adapter()
    ck(contract['baseEngine'] == adapter['engine'], 'support hook changed document/archive base scanner')
    review = load(contract['independentReview']['path'])
    ck(review['result'] == 'PASS_EXACT_SUPPORT_ONLY_ADAPTER_AND_FAIL_CLOSED_TESTS' and
       review['exactCandidates'] == header_count and review['testCount'] == len(review['tests']) and review['testCount'] > 0 and
       all(row['passed'] is True for row in review['tests']) and
       all(review[key] == contract[key] for key in fields if key != 'independentReview'), 'current support review differs')
    approval, classification = load(contract['supportSyntaxApproval']['path']), load(contract['classification']['path'])
    classification_pin = {key: contract['classification'][key] for key in ('bytes', 'sha256')}
    ck(approval['result'] == 'APPROVED_EXACT_SYNTAX_CLASSIFICATION' and approval['classificationPin'] == classification_pin and
       approval['exactCandidates'] == header_count and approval['detectorsAndValueSearchesUnchanged'] and
       approval['rawFindingCountsRetained'] and approval['payloadRedactions'] == 0, 'current support syntax approval differs')
    ck(classification['result'] == 'INDEPENDENT_BENIGN_SYNTAX_PROPOSAL_REQUIRES_ROOT_APPROVAL' and
       classification['primaryCandidates'] == header_count and classification['rawRuntimeCandidates'] == 0 and
       classification['candidateMultisetMustMatchExactly'] and classification['wholeFilePinRequired'] and
       classification['allUnexpectedCandidatesBlock'] and classification['noDetectorChanges'] and classification['noPayloadEdits'],
       'current support classification boundary differs')
    rows = classification['exactSupportCodeClassifications']
    ck(len(rows) == header_count and all(row['member'].startswith('kgm-recovery-support/') and row['astValid'] and
       row['isHeaderValueOrCredential'] is False and row['fileExtensionExemption'] is False and
       row['payloadChangeProposed'] is False for row in rows), 'support syntax member/scope differs')
    member_map = file_map(report['members'])
    ck(all(row['filePin'] == {key: member_map[row['member']][key] for key in ('bytes', 'sha256')} for row in rows),
       'whole-file support pins differ from scanned members')
    expected = [{'member': row['member'], 'filePin': row['filePin'],
                 'finding': {key: value for key, value in row['exactFinding'].items() if key != 'member'},
                 'classification': row['classification']} for row in rows]
    canonical = lambda items: sorted(json.dumps(row, sort_keys=True, separators=(',', ':')) for row in items)
    ck(len(set(canonical(expected))) == header_count and canonical(report['classifiedExactCodeHeaderCandidates']) == canonical(expected),
       'missing, duplicate or unexpected support syntax classifications')
    ck(recovery['privacy']['exactPinnedCodeSyntaxClassifications'] == header_count and
       recovery['privacy']['exactPinnedTemplateSyntaxClassifications'] == 0 and
       recovery['inputPins']['supportPrivacyContract'] == {'path': str(contract_path), **pin(contract_path)},
       'fresh replay did not bind exact current support adapter')
    return {'contract': ref(contract_path), **{key: contract[key] for key in fields}, 'scanReport': ref(report_path),
            'exactApprovedSyntaxCandidates': header_count, 'unresolvedCandidates': 0,
            'scope': 'Only independently reviewed and explicitly approved AST-bound candidates in exact current KGM support bytes',
            'rawFindingsAndCountsRetained': True, 'payloadRedactions': 0, 'documentScannerUnchanged': True,
            'fileExtensionExemption': False, 'unexpectedMissingOrDuplicateFindingsBlock': True}


def generated_support_copy(support_members, sanitation):
    path = C / 'PROPOSAL-SUPPORT-COPY-MAPPING-v1.json'
    check(path, {'bytes': 1565, 'sha256': '301d2aa252954b1d0ccffe298c0c5576c2cb0c91df1a07106c3ffc51b4eea421'})
    mapping = load(path)
    ck(mapping['result'] == 'PASS_EXACT_GENERATED_METADATA_KEY_COPY' and
       all(mapping[key] is True for key in ('proseValueByteExact', 'allOutsideKeyBytesIdentical',
           'allOtherJSONFieldsIdentical', 'originalUnchanged')) and mapping['sourceOrEvidencePayloadChanged'] is False,
       'generated-support copy-only transformation scope differs')
    ck(sanitation['result'] == 'NO_NEW_TRANSFORMATIONS' and sanitation['files'] == [] and sanitation['locationCount'] == 0,
       'source/proof transformation count differs')
    members = file_map(support_members)
    copy_member = 'kgm-recovery-support/KGM-METADATA-INVENTORY-PROPOSAL-support-copy-v1.json'
    original_member = 'kgm-recovery-support/KGM-METADATA-INVENTORY-PROPOSAL-v1.json'
    ck(original_member not in members and copy_member in members and
       {key: members[copy_member][key] for key in ('bytes', 'sha256')} ==
       {key: mapping['copy'][key] for key in ('bytes', 'sha256')}, 'support copy inclusion/original exclusion differs')
    classification = pathlib.Path(mapping['classification']['path'])
    ck(classification.parent == C, 'support copy classification is outside current checkpoint')
    check(classification, mapping['classification'])
    return {'mapping': ref(path), 'classification': mapping['classification'], 'sourceOrProofTransformations': 0,
            'generatedSupportMetadataKeyRenames': 1,
            'retainedMember': {'path': copy_member, **{key: mapping['copy'][key] for key in ('bytes', 'sha256')}},
            'originalExcludedFromSupport': True, 'originalLeftUnchangedLocally': True,
            'copyOnly': True, 'proseValueAndAllOutsideKeyBytesUnchanged': True,
            'scope': 'One explicitly approved generated-support prose key rename to approvalScope; no source or proof transformation',
            'restoreQualification': 'The retained support copy has a distinct hash and cannot satisfy the original expected whole-file pin'}


def application_scope(recovery, contract):
    application = recovery['application']
    check(C / 'APPLICATION-ASSERTION-CONTRACT.json', {'bytes': 140140, 'sha256': 'd25b98dea0de16c30289b3aba12867c4887705c68947e0a26e6a824c9a5cfd2e'})
    ck(application['assertionCount'] == 290 and application['freshArchiveAssertions'] == 290 and application['exactInheritedAssertions'] == 0 and application['mandatoryRetainedPins'] == 169, 'frozen KGM application proof scope differs')
    ck(application['assertionCount'] == len(contract['assertions']) > 0 and
       application['freshArchiveAssertions'] + application['exactInheritedAssertions'] == application['assertionCount'] and
       application['mandatoryRetainedPins'] == len(contract['retainedPins']) > 0 and
       recovery['overlay']['inheritedPayloadReadsByIndependentVerifier'] == 0, 'application proof qualification differs')
    replay_metadata('application')
    result = {'totalAssertions': application['assertionCount'], 'freshArchiveAssertions': application['freshArchiveAssertions'],
              'exactInheritedAssertions': application['exactInheritedAssertions'], 'mandatoryRetainedPins': application['mandatoryRetainedPins'],
              'inheritedPayloadReadsByIndependentVerifier': 0,
              'qualification': 'Fresh KGM factual evidence and exactly identified inherited evidence only; no current full-project TypeScript, visual, mobile, build, full-suite or release pass is implied'}
    for key in ('inheritedAssertionContract', 'inheritedAssertionReplay'):
        if application['exactInheritedAssertions']:
            item = application[key]
            location = pathlib.Path(item['path'])
            ck(location.parent in (BASE, BASE.parent / 'deepal-working-20261015T1110'), 'inherited assertion evidence outside accepted chain')
            check(location, item)
            if key == 'inheritedAssertionReplay':
                ck(load(location)['result'] == 'PASS', 'inherited assertion replay did not pass')
            result[key] = item
    return result
