# M1 progress and completion evidence

M1 is in progress. BYD and Tesla are research-complete; whole-market completion has not been asserted. The original research snapshot and historical source evidence remain unchanged; new work uses dated overlays. Work stays in Tier 1 and M1.

The first pass applies the authorised price ladder and buyer grading to existing Tier 1 evidence. New brand research, missing-model additions and market closure are separate unfinished work. The original whole-market registry remains empty. Separate dated BYD, Tesla, Geely, Zeekr and Jaecoo reconciliation overlays record their verified current versions and resolved inherited audit items; two independent whole-market lists remain to be reconciled.

## Read the current position

- `pnpm report:coverage`: compact headline coverage, all six completion criteria, brands done/remaining and the first missing models
- `pnpm report:coverage --details`: every core grade split, under-half Confirmed patterns, exact gaps, per-brand remaining work, all missing models and reconciliation blockers
- `pnpm report:coverage --json`: complete structured evidence, including registry snapshots and dated current-version reviews
- Add `--as-of YYYY-MM-DD` to reproduce a release check; the default uses the current Australian date
- `pnpm report:stale --details`: exact current claims needing freshness work

The on-sale denominator still includes current/order-listed Tier 1 versions and sourced outgoing new-stock advertisements. It excludes provisional announcements and outgoing versions without that evidence. A listing never proves physical stock or accepted orders. C4 and C6 continue checking all Tier 1 catalogue versions.

## Research completion and coverage qualification

The report distinguishes the research queue from the strict coverage targets. There is no editable “complete” flag.

A brand is **research-complete** when its dated complete current-version list is established, every known model/lead difference is resolved, every on-sale core field has an earned grade (including a completed two-source unsuccessful search), its Tier 1 strengths/trade-offs are supported, and its claims are fresh. Two-source “Not published” gaps allow research to move to the next brand. Missing 10–80% charging time when only 30–80% is published, for example, can be a finished research outcome while C2 and C5 remain open. Whole-market independent-list closure is not required before moving to the next brand.

A brand is separately **coverage-qualified** only when it meets all six criteria:

1. Every current version and inherited audit/lead disposition is reconciled; the two independent market-list snapshots are valid, and all differences relevant to that brand are settled
2. Price is filled for every on-sale version; each other core field is at least 95% filled
3. Every on-sale core cell has an auditable M1 grade; each field below half Confirmed has an explanation, without a grade quota
4. Every Tier 1 version has a supported strength and trade-off
5. Each required ranking includes at least 90% of that brand’s on-sale versions
6. No Tier 1 current claim is aged, invalid or future-dated

The JSON includes each brand’s criteria, current-version reviews, exact blockers, counts, `researchCompleted` and its research-completed-as-of date, plus separate all-six-criteria completion and its as-of date. A fully reconciled exclusion can close an audit lead without adding a vehicle. A brand containing only excluded leads is not presented as a completed on-sale brand. The compact report lists brands done/remaining in the research queue and identifies coverage-qualified brands separately. A new or stale fact, model or version can reopen the relevant criterion.

## C1 registry: dated evidence, never inferred closure

`data/m1-market-reconciliation-2026-10-14.json` has the typed structure declared in `scripts/reporting/m1-reconciliation.ts`:

- `schemaVersion` and `checkedAt`: registry format and check date
- `publishedLists`: complete published Australian new Tier 1 BEV model-list snapshots. Each records its publisher, publication/check dates, original URL, complete model/body entries, an independence key and the reason it is independent
- `currentVersionReviews`: complete official Australian current-version lists, with exact model/body identity, model ID, check date, official URLs and reason. Every version identifies its catalogue ID, exact model, trim and model year. Optional `publishedModelAliases` records source-bound naming equivalences with a reason and URLs; it never relaxes body/trim/year identity
- `listResolutions`: one dated, sourced included/excluded/unresolved disposition for every published-list entry
- `catalogueOnlyDifferences`: a dated, sourced explanation for each reviewed model absent from each independent list
- `inventoryResolutions`: one sourced disposition for every inherited Tier 1 audit record and unverified lead, using its stable record/family ID (or brand-model fallback)

Two URLs from the same publisher or underlying dataset do not count as two independent lists. Snapshot capture must be complete, not cherry-picked to the existing catalogue. Research must establish independence; the report can validate the recorded structure, but it cannot independently prove that a researcher transcribed every published entry.

An included published entry must match the reviewed brand, model, body and vehicle class. Each reviewed version must match its actual catalogue ID, model ID, brand, model, trim and year. An explicit body-style fact, when present, must also match. Missing body evidence is not invented: the researcher must establish the body scope in the cited official current-version review. A sibling body, a different trim, a shared family prefix or a similar name cannot supply another version’s coverage.

Exclusions need a real date, evidence URLs, a reason and one of the supported dispositions: not sold new in Australia; not officially imported; not a BEV; outside Tier 1; not orderable or advertised as new stock; or duplicate of an explicitly matched model/body review. A duplicate must name the valid review. An on-sale catalogue model cannot also be excluded as not sold here. Unknowns remain unresolved.

Registry, version-list and resolution check dates use the 45-day availability window. Publication dates stay distinct. Future or invalid dates, duplicate IDs/resolutions, orphan references, an empty list, an unreviewed actual version, or an unresolved inherited audit item keep C1 open. Valid exclusions and complete current-version reviews must be recorded before the report will remove an inherited lead or unmatched model from its open-work list.

For later research, append the real snapshots/reviews and their source-bound resolutions to a new dated overlay, then update the report loader. Never invent entries to make counts agree, remove unresolved differences, or change the immutable snapshot to close a report.

## C3 earned grades

Coverage uses the shared `hasEarnedBuyerGrade` validator. A historic `standard` or `conditional` status alone no longer earns an M1 grade in the coverage report. A reviewed grade needs its dated overlay, reason, evidence scope and resolvable source citations. The report preserves filled values even when their grading review is unfinished, and shows them as Unreviewed in its split.

“Not published” requires an explicit unsuccessful search with two cited source URLs. A null value or old caveat is not such a search. It counts as a reviewed grade for C3, but it does not count as a filled field for C2. A value on the wrong charging window does not fill DC 10–80% time or earn a review for that requested core field.

The report gives the full Confirmed / Check / Reported / Not published / Unreviewed split for all 17 core fields and explains the recorded evidence patterns below half Confirmed. C3 can pass with a low Confirmed share when every grade is earned and the pattern is explained. It cannot pass by relabelling old statuses or writing a completion flag.

## Behavioural checks

`tests/m1-coverage-tracking.test.ts` covers a genuinely complete synthetic fixture, the empty/incomplete registry, non-independent lists, every-entry and every-version reconciliation, wrong body/trim/model/year/brand matches, sourced exclusions, catalogue-only differences, duplicate/orphan records, stale checks, two-source unsuccessful searches and per-brand completion. Existing coverage-report and freshness tests remain active. These tests verify behaviour rather than pinning historical byte counts.

## Progress snapshot — 14 October 2026

- The initial existing-record pass shows prices on 171 of 268 Tier 1 versions, up by 102; this includes Tier 1 versions outside the narrower on-sale report denominator
- 184 retained-evidence core fills have been applied and independently reviewed, including corrected Kia EV3 and outgoing Geely source attribution
- The initial earned-grade ledger reviews 18,946 facts and 2,703 equipment answers. Fact/source drift withdraws grading without hiding figures; reviewed Tier 1 claims cannot silently regain legacy rankings
- BYD research and its packet are independently reviewed and registered: 13 current versions, 221/221 on-sale core cells reviewed, 11 genuine unpublished core figures, and 14 supported strength/trade-off pairs including an outgoing version. C3/C4/C6 pass for BYD; C1/C2/C5 do not
- The first foundation run found 79 failures, including old fixture-boundary assumptions and an optional-fitment status regression. Historical evidence assertions were retained, separate current-catalogue safety tests were added, and optional equipment keeps its paid-option meaning
- The full foundation/BYD rerun passes 964/964 tests with zero failures or skips. Structural validation, type checking and full ESLint pass. Tesla, Geely/Riddara, Zeekr and Omoda/Jaecoo research are independently reviewed and registered; Kia is now independently reviewed and registered; MG/IM is now registered; Hyundai is integrated with research closure still pending
- Tesla has eight current versions and 136/136 reviewed core cells, with five genuine 10–80% charging gaps. Sixteen guarded feature replacements keep storage and motor-output answers consistent with canonical facts. Current comparisons admit freshly established matching WLTP figures while rejecting unidentified cargo methods. Targeted integration, structural validation, coverage, type checking and lint checks pass
- Geely has four current versions across EX5 Extended Range and EX2; two outgoing EX5 versions remain visible without a current-stock claim. All 68 on-sale core cells are reviewed, including four genuine unpublished 10–80% times. The maker’s EX5 20-minute 30–80% figure remains visible separately and cannot fill the 10–80% field. Sixteen guarded equipment answers follow canonical facts; the EX2 AC-rating conflict is explicit and unranked. Riddara RD6 is resolved as not currently sold new through official Australian supply. Independent source review and 38 focused integration tests pass; global C1/C2/C5 remain open
- Zeekr has eight on-sale versions with every core field filled and reviewed. Two separately labelled outgoing records are retained: 7X Black Edition without verified new supply, and original X AWD with a documented dealer-new versus syndicated-used classification conflict. Thirty guarded equipment answers and ten summary pairs pass independent review. Current validation, coverage, type checking, changed-file lint and 39 integration tests pass; one obsolete live 009 peak-power assertion was updated to distinguish Reported vehicle figures from maker station conditions. C2/C3/C4/C6 pass for the brand; C1/C5 remain open
- The first newly added version exposed an importer problem: it inherited thousands of unrelated equipment-field names as unknown facts. Shared defaults are now limited to buyer fields while every reviewed packet fact is preserved. The new regression fails before the fix and passes after, including with an empty input catalogue. The independently checked outgoing X record has 26 facts and a 24,782-byte compact representation instead of roughly 3 MB of unrelated unknown fields
- Omoda/Jaecoo is reconciled to one current Australian BEV, Jaecoo J5 EV Summit; current Omoda hybrids are excluded and the Chery E5 is not duplicated. Its 17 core fields have 15 Confirmed grades, one Reported acceleration figure and one genuinely unpublished 10–80% duration; the published 28-minute 30–80% figure is kept separately. Five equipment answers remove unsupported estimated charging/cost prose and distinguish cargo measurements. The A$35,990 RRP and conditional A$36,990 October driveaway offer stay separate, with the latter projected from its reviewed fact into the driveaway answer. All 39 focused integration tests and structural/coverage checks pass. C3/C4/C6 pass for the brand; C1/C2/C5 remain open
- Supplemental driveaway offers now use the same price-provenance validation as the main price. Behavioural checks cover preserving the higher-rung list price, current offer terms and deadline, and rejecting missing or withdrawn evidence. The 25 importer/feature tests pass; the newly added exact-version detail also renders with all claim evidence controls
- Projected offer deadlines now survive equipment answers, evidence drawers, citable exports and portable transport. Expired offers keep their sourced amount and grade but show a separate ended-offer label; missing deadlines remain legacy-compatible and invalid dates require confirmation. Stale reports and feature-dependent summaries use the deadline. All 138 targeted tests, type checking and targeted lint pass, with all 78 existing data files unchanged
- The pre-Tesla foundation production build completes all 391 generated routes. Home, discovery, comparison and exact-version route traces include the new runtime ledgers and registered packets. Static generation took 16.5 minutes with one worker; this is a build-time measure, not a mobile-performance result
- The source packager now supports standard tar.xz to retain every source byte under the 15 MB attachment ceiling; ZIP remains an option. The internal foundation trial was 7.35 MB and passed independent extraction/checksum verification. No additional checkpoint has been delivered
- Whole-row equipment answers can now honestly earn “Not published” while retaining the Feature string schema. The canonical answer requires an earned two-source search and its own matching null fact; a known brochure or unrelated missing field cannot stand in for that search. All 63 focused tests, TypeScript and ESLint pass, and independent review found no weakened guards. Kia final residual-version review and integration have passed
- Current availability updates no longer alter the historical feature-warning baseline before exact replay. A small original identity/state context preserves source-layer reconstruction, including new versions and cloned/chained inputs; public availability remains current. All 44 focused tests, TypeScript and full ESLint pass, and an independent actual-pack replay of the staged Kia candidate passes. The URL-sanitization fixture now separately tests immutable source sanitization and rejection of tampered current supporting sources
- Kia is integrated with 27 on-sale versions: 20 current factory versions and seven independently evidenced residual-new versions, including four additions. All 459 core cells have earned reviews, with only the EV3 AWD peak DC acceptance genuinely unpublished. Current maker RRP, exact-year residual prices and policy exceptions stay distinct. The 357 corrected equipment answers and 27 strength/trade-off pairs pass independent actual-pack and portable checks. All 43 integration tests and structural/coverage/type/lint checks pass; C2/C3/C4/C6 pass for the brand, while C1 and C5 remain open. MG/IM research is now complete and independently reviewed. The full suite through Kia ran 1,001 tests: 994 passed and seven stale fixture expectations failed. Test-only corrections preserve original audit checks, strict packet drift rejection and canonical unknown statuses; all 89 affected-file tests now pass, along with TypeScript and lint. This is a full initial run plus a focused repair verification, not a later clean aggregate run
- MG/IM is integrated as separate brand packets for 23 exact versions, including seven new residual identities. The 1,180 specific fact edits, six shared terms and 554 guarded equipment replacements retain distinct warranty extensions, source-labelled combined motor outputs and exact charging windows. Unknown cargo methods are displayed but unranked. All 43 integration tests, seven explicit live-safety tests and validation/coverage/type/lint checks pass. C3/C4/C6 pass for both brands; C1/C2/C5 remain open. Hyundai established versions are now integrated; the unresolved six-seat residual listing keeps research closure open
- Periodic recovery saves are now required by the owner: preserve source, research evidence and progress after each completed brand, with verified manifests and a persistent Library copy. Recovery saves are separate from milestone checkpoints; no checkpoint104 delivery is implied. Never include captured authentication headers in a shared recovery archive; document factual-content-preserving redactions
- Publication metadata now reflects the current generated-page update without advancing unchanged glossary review labels. Seventeen focused tests verify that page dates cannot refresh fact, feature, source or grade-review dates, offer expiry or freshness. Full TypeScript and lint pass; all data and saved Hyundai before snapshots remain unchanged
- M1 remains open. No C1–C6 completion is asserted by this progress snapshot

## Hyundai integration and recovery update — 14 October 2026, 03:55 UTC

- The independently approved Hyundai packet and reconciliation are registered. There are 21 established on-sale versions, including six residual-new additions; all 357 core cells have earned reviews. The packet retains 5,254 specific fact edits, three shared terms, 844 guarded equipment answers and 21 strength/trade-off pairs
- All 43 focused integration tests pass. Structural validation, coverage generation, TypeScript and changed-file lint exit successfully. Current coverage reports 363 catalogue versions, 286 Tier 1 versions and 280 on-sale versions, with 4,006 of 4,760 on-sale core cells reviewed
- Hyundai research completion remains false because Carsales OAG-AD-25622863 may establish a separate six-seat MY26 IONIQ 9. CAPTCHA permission is pending; the unresolved inventory record is retained. Toyota has not started. C3/C4/C6 pass for Hyundai; C1/C2/C5 remain open
- Recovery copies are saved outside the working environment. A backup audit found 17 anonymous public-site response-cookie header files in two provisional Hyundai archives. Sanitized copies are being prepared, and the recommended restore chain will exclude those original archives. No account-login credentials were identified; older files have not been deleted or replaced. This does not change the approved factual packet hashes
- This is an integration and recovery save, not a checkpoint 104 milestone delivery. M1 and real-device mobile verification remain open

## Regression diagnosis — 14 October 2026, 04:49 UTC

- The later full suite was interrupted without a terminal aggregate result. File-level citable/domain failures and a local-review startup timeout were observed; no clean full-suite result is claimed
- Unchanged domain tests passed in isolation (26 tests, 296.76 seconds), so the earlier file failure was not reproduced as an assertion failure. Its original exit signal is unavailable
- Explicit file-local snapshot reuse preserves all original assertions and reduces measured domain wall time to 164.76 seconds. `pairReport` now accepts an optional supplied snapshot without adding a global cache or changing default loader freshness. Citable passes 13 tests, including mutation of a previously successful snapshot failing closed on source drift
- The unchanged review service took 59.90 seconds to validate all 363 vehicles before listening. Its integration-test startup budget is now a documented 120 seconds, preserving eager validation and every origin, claim-binding, persistence and private-queue assertion. This is a test infrastructure allowance, not a performance improvement; service startup remains an open performance issue
- Final patch verification passes 85 distinct focused tests across seven files, full TypeScript and full lint. Independent review confirms unchanged core data/guard/service behavior. Latest production build, broad aggregate regression completion and real-device mobile verification remain open

## Owner-authorized Hyundai deferral — 14 October 2026, 06:10 UTC

The owner instructed us to skip the blocked Hyundai item and continue. The 21 established Hyundai versions remain integrated; the unresolved six-seat MY26 IONIQ 9 listing remains an explicit research gap, not an exclusion or completed audit. Toyota research is now active, followed by the existing sales-order list. This deferral does not waive C1–C6 or authorize M2 before the M1 report and milestone approval.

## Toyota integrated — 14 October 2026, 06:45 UTC

- Six current Toyota configurations are independently reviewed and registered: bZ4X 2WD/AWD, bZ4X Touring AWD and three HiLux BEV cab/body grades. No residual-new original 71.4 kWh bZ4X was verified; C-HR BEV remains a future announcement. Brand-only directories are not counted as whole-market C1 lists
- All 102 core cells are reviewed: 90 Confirmed, four Check, three Reported and five genuinely unpublished gaps. The 600 guarded fact edits, three inherited terms and 339 equipment updates preserve exact price sources, charging conflicts and warranty conditions. Research completion is true; C3/C4/C6 pass, while strict C1/C2/C5 remain open
- Paid Toyota roadside membership now projects as optional equipment while keeping its Confirmed source grade. Explicit fitment metadata, legacy compatibility, source/snapshot guards, portable consistency and withdrawn reused-projection handling pass 56 focused regressions; immutable registered packets remain unchanged
- Root integration passes 44 tests, structural validation, coverage generation, TypeScript and changed-file lint. Global coverage is 363 catalogue versions, 286 Tier 1 and 280 on sale, with 4,024 of 4,760 core cells reviewed. Volkswagen is next; the owner-deferred Hyundai listing remains unresolved
- A new recovery save is being prepared for Toyota research, source and QA. This remains working M1 progress, not checkpoint 104 delivery
