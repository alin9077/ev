# GAC / AION Australia price and ownership terms research

Research cutoff: 2026-10-14. Research only; no repository edits, uploads, screenshots published, stock checks, price conversions, or third-party communications. Local evidence is in `/tmp/gac-research/terms/`; `source-manifest.json` maps primary captures to exact URLs and SHA-256 hashes.

## Final superseding price finding
After this initial worker report, the independent reviewer successfully used the ordinary dot-cloud Chrome configurator and captured all four current exact-grade maker base/MSRP prices. UT Premium/Luxury are A$31,990/A$35,990 and V Premium/Luxury are A$42,590/A$44,590 before on-road fees. These Confirmed rung-1 captures supersede the unresolved-maker-price statements and fallback recommendation below. See `terms/maker-price-browser-provenance.json` and `independent-review/source-review.md`. The original research below is preserved as the earlier evidence-search history.

## Initial findings to use immediately

- Current maker Australian BEV pages cover AION V and AION UT. Both have Premium and Luxury grades. Do not derive manufacturer model year from the website path `/2025` or from secondary MY26 labels.
- Fresh maker Q4 offers differ materially from indexed Q3 snippets and even stale image alt text. Read the saved actual offer images.
- AION V current maker offer is AUD2,000 cashback, orders by 31 October 2026 and delivery by 15 November 2026. It is not a standalone exact-grade vehicle price.
- AION UT current maker campaign headlines **from AUD31,990 driveaway**, Q4 orders. Current maker HTML does not identify the grade next to that headline, and does not establish the Luxury grade price.
- Exact-grade maker MLP/current driveaway remains unverified in this worker's captures. Reported MLP fallback and candidate dealer prices are below. Do not relabel these as maker-confirmed prices.

## Recommended canonical price decisions and ladder evidence

The requested ladder prioritizes current exact-grade maker prices over reported MLP. Maker price was searched first: current model pages, their View Offer pages, live Price Details configurator, launch news, and official expired pre-order PDF. No usable current maker exact-grade MLP was found. The public price configurator fetches its grade prices client-side; a read-only direct request returned `appid invalid`. No authentication/signature workaround was attempted.

| Version | Price fallback | Basis / rung | Source | Date / caveat |
|---|---:|---|---|---|
| AION V Premium | AUD42,590 | Reported MLP / before on-road costs; rung 5 if no higher qualifying capture | S8 | Published 2025-12-03; live capture 2026-10-14; no expiry stated for MLP; not a current maker confirmation |
| AION V Luxury | AUD44,590 | Reported MLP / before on-road costs; rung 5 if no higher qualifying capture | S8 | Same source; no price conversion or cashback deduction |
| AION UT Premium | AUD31,990 | Reported MLP / before on-road costs; rung 5 if no higher qualifying capture | S9 | Published 2026-06-10; avoid conflating same numeric MLP with current Q4 driveaway headline |
| AION UT Luxury | AUD35,990 | Reported MLP / before on-road costs; rung 5 if no higher qualifying capture | S9 | Same source; Q2 driveaway numbers in article expired / historical |

Current maker conditional headline S3: AION UT from AUD31,990 driveaway, orders 1 October–31 December 2026, unless extended; AUD1,000 deposit; state/model/colour/specification may vary. Candidate maker driveaway rung 2/3 for Premium only if another exact-grade source ties it explicitly to Premium. Do not infer the Luxury AUD35,990 driveaway from this headline or from an old offer.

Dealer evidence, not national maker exact-grade price: current GAC Bayside page S10 displays a new Luxury stock JF11394 at AUD36,590 driveaway and an unnamed-grade UT at AUD31,990. Current GAC Cairns page S11 displays named V Premium and Luxury stock prices (saved web capture). These are unit/dealer/location-specific and may involve colour. Do not infer availability, derive unpainted prices, or use as universal maker pricing. The parent should apply its dealer rung only if eligible under the catalogue's policy.

Circular-source warning: searches surface Symply EVs exact-grade Q4 pages; excluded from evidence. Third-party comparison sites and CarExpert showroom auto-generated price footnotes also mix MLP with supposed driveaway and are excluded in favor of the explicit editorial before-ORC tables S8/S9.

## Current offers (maker evidence)

### AION V

- S1 + S2: AUD2,000 cashback at point of sale; order by 2026-10-31, delivery by 2026-11-15; minimum AUD1,000 deposit; fleet, government and rental excluded; no retrospective redemption; cannot combine with GAC vehicle finance. Maker reserves modification/withdrawal. Do not subtract from MLP to invent a canonical advertised price.
- S2 rendered image: separate AUD1,000 novated lease discount, orders 2026-10-01 through 2026-12-31, delivery by 2027-01-31; demonstrators excluded; discount based on driveaway price. Image is headed choose your Q4 offer, so do not assume stacking with cashback.
- S1 actual October hero image advertises a free 22kW EV wall charger. Its footnote excludes installation, guarantees no property suitability, and asks buyers to verify delivery timing. This charger rating is not the vehicle's onboard AC acceptance rating.
- The older indexed 0.99% comparison-rate offer required approval by 2026-09-30 and settlement by 2026-10-31. It is closed to fresh applications at cutoff; final settlement window does not make the offer newly available.

### AION UT

- S3: Q4 national driveaway headline described above, plus 22kW wall charger in live hero asset.
- S4 rendered image: AUD1,000 novated lease offer, orders 2026-10-01 through 2026-12-31, delivery by 2027-01-15; demonstrators excluded; discount based on driveaway price. Do not stack with driveaway campaign unless expressly confirmed.
- **Content conflict**: S3/S4 HTML alt text still says 7% novated lease and/or July–September dates while the actual image shows AUD1,000/Q4. Prefer inspected current image for the captured claim, record the conflict, and avoid asserting 7% is a finance interest rate.

## Warranty (current maker terms; both V grades and both UT grades)

S5 table, page 3, visually verified (`warranty-table.png`): non-commercial vehicle 8 years/unlimited km; traction battery and integrated drive 8 years/200,000km. Commercial vehicle 5 years/150,000km; battery 5 years/300,000km; integrated drive 3 years/300,000km. Starts at first registration; warranty transfers for the remaining term. Commercial use includes rental, fleet, rideshare, taxi, courier, driving-school and security vehicles. Proper maintenance and records are required; all servicing at a GAC dealer is not compulsory for warranty itself.

Battery threshold exact problematic phrase: **“State-of-Health drops ≤30% degradation of its original capacity”**. This wording is ambiguous; do not silently turn it into a verified minimum 70% SOH guarantee. Terms describe repair, replacement or reconditioning and exclude accident/misuse damage.

Internal conflicts: page 4 prose retains the AION V-only 300,000km commercial battery exception while updated table names V & UT; private integrated-drive prose also has a contradictory V exception. Preserve private battery/vehicle terms; flag commercial UT battery and integrated-drive ambiguity if used.

## Roadside assistance (current maker S6, effective 2025-12-15)

Included initially for 12 months. Each annual scheduled service at a GAC service centre adds 12 months, up to five years from first registration; S7 says all scheduled servicing must be at an authorized dealer for renewal. Thus publish “up to 5 years, renewed with authorized servicing,” not unconditional five years. Eligibility requires registered, roadworthy, well-maintained vehicle no older than five years. Digicall Assist provides service. Depleted traction-battery towing goes to the nearest charging station, with charging costs paid by customer. No special purchase offer is required by S6 itself.

## Historical / dead offers

S12 official First 600 pre-order PDF is not current: first 600 UT orders placed 2026-03-12–2026-04-09, delivered by 2026-06-30. Standard-colour Premium AUD30,990 / Luxury AUD35,990 driveaway; premium-colour AUD31,590 / AUD36,590; two-tone AUD31,990 / AUD36,990. GST inclusive, no dealer delivery fee, AUD500 minimum deposit; fleet/government/rental excluded. These are explicit historic driveaway prices, not MLP. Do not retain the AUD30,990 current price or imply those charger/gift/data benefits remain active. Its roadside benefit also required annual dealer servicing.

## Structured source list

- S1 Maker current AION V: https://www.gacgroup.com/en-au/suv/aion-v ; publication date not stated; captured 2026-10-14; `terms/aion-v.html`, `terms/aion-v-visible.txt`, `terms/aion-v-image.webp`. Hero actual asset https://eu-www-resouce-cdn.gacgroup.com/static/AU/tenant/cms/common/202610/1791293768073-%E6%BE%B3%E6%B4%B2%E8%BD%A6%E5%9E%8B%E9%A1%B5-v-pc(1).webp
- S2 Maker V offer: https://www.gacgroup.com/en-au/suv/aion-v/View%20Offer ; publication not stated; captured 2026-10-14; `terms/aion-v-offer.html`, `terms/aion-v-offer-image.webp`; image source https://eu-www-resouce-cdn.gacgroup.com/static/AU/tenant/cms/common/202610/1791358841997-%E6%BE%B3%E6%B4%B2vviewoffer-pc10-7.webp
- S3 Maker UT: https://www.gacgroup.com/en-au/hatchback/aion-ut ; publication not stated; captured 2026-10-14; `terms/aion-ut.html`, `terms/aion-ut-visible.txt`, `terms/aion-ut-assets.json`.
- S4 Maker UT offer: https://www.gacgroup.com/en-au/hatchback/aion-ut/View-Offer ; publication not stated; captured 2026-10-14; `terms/aion-ut-offer.html`, `terms/aion-ut-offer-image.webp`; actual image source https://eu-www-resouce-cdn.gacgroup.com/static/AU/tenant/cms/common/202609/1790761460448-%E6%BE%B3%E6%B4%B2utviewoffer-pc.webp
- S5 Maker current warranty linked by current model and service page: https://eu-www-resouce-cdn.gacgroup.com/static/AU/tenant/cms/material/202608/1787037645132-Warranty-Terms-and-Conditions-FINAL-.pdf ; document date unstated (202608 is asset path, not proof of publication date); `terms/warranty-current.pdf`, `.txt`, `terms/warranty-table.png`. Supersedes older search-index V3.2 URL for present research.
- S6 Maker roadside: https://eu-www-resouce-cdn.gacgroup.com/AU/Roadside_assistance_terms_and_conditons.pdf ; effective 2025-12-15 explicitly; `terms/roadside.pdf`, `terms/roadside.txt`.
- S7 Maker service: https://www.gacgroup.com/en-au/our-service ; undated; `terms/our-service.html`, `.txt` equivalent `our-service-visible.txt`, `terms/our-service-image.webp`.
- S8 Reported V MLP: https://www.carexpert.com.au/car-reviews/2026-gac-aion-v-review-quick-drive ; published 2025-12-03, by Ben Zachariah; `terms/secondary-web-captures.json`. Relevant explicit editorial price table, not automated showroom footer.
- S9 Reported UT MLP: https://www.carexpert.com.au/car-reviews/2026-gac-aion-ut-luxury-review ; published 2026-06-10, by William Stopford; `terms/secondary-web-captures.json`. Explicit before-ORC table.
- S10 Authorized dealer unit prices: https://www.gacbayside.com.au/models/aion-ut ; undated, retrieved 2026-10-14; `terms/secondary-web-captures.json`; unit listings are not stock availability proof or national price.
- S11 Authorized dealer unit prices: https://www.gaccairns.com.au/models/aion-v ; undated, retrieved 2026-10-14; `terms/secondary-web-captures.json`; national offer text can lag current maker Q4 page.
- S12 Maker expired UT offer: https://eu-www-resouce-cdn.gacgroup.com/AU/First_600_units-one_page_with%20T%26Cs_Final_Approved..pdf ; explicit campaign dates above; `terms/ut-first-600-expired.pdf`, `.txt`.

## Bounded limitation

Maker Price Details pages https://www.gacgroup.com/en-au/price/aion-v/2025 and https://www.gacgroup.com/en-au/price/AION%20UT/2025 show a postcode-dependent UI. `terms/aion-v-price.html` preserves it; same-page client code demonstrates grade salePrice fetched at runtime. No grade price was recovered. A natural browser interaction with a clearly labelled representative postcode could resolve this without converting price basis, but must capture grade, registration location and personal/business selection. This research did not supply invented user postcode or submit customer data.
