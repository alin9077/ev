import json
from pathlib import Path
R = Path('/tmp/gac-research')
p = json.loads((R / 'normalized-evidence.json').read_text())
cs = {c['id']: c for c in json.loads((R / 'gac-live-before.json').read_text())}
p['sources'].append(dict(key='v_carexpert_weights', url='https://www.carexpert.com.au/gac/aion-v/2026/features-and-specs', title='CarExpert AION V exact-grade weights and specifications excerpt', publisher='CarExpert', source_type='independent_au_specification', file='current/secondary-supplement-web.txt', supports='Named Premium and Luxury kerb1780kg and GVM2280kg; secondary data kept Reported.'))
for v in p['variants']:
    name = 'ut' if v['model'] == 'AION UT' else 'v'
    spec = name + '_spec'
    owner = name + '_owner'
    keys = {f['key'] for f in v['facts']} | {'warranty', 'battery_warranty', 'roadside_assistance'}
    fd = {f['key']: f for f in v['facts']}
    for k, f in cs[v['id']]['facts'].items():
        if k in keys:
            continue
        n = dict(key=k, value=None, sourceKeys=[spec, owner], grade='not_published', comparison='', reason='The current Australian named-grade specification and Australian-linked owner manual were checked. Neither establishes ' + k.replace('_', ' ') + ' for this exact Australian grade; mixed regional or unspecified equipment coverage is not assigned.')
        if k == 'ground_clearance_mm':
            n.update(value=147 if name == 'ut' else 166, grade='confirmed', sourceKeys=[spec], basis='Minimum ground clearance, unladen', comparison='Unladen ground clearance', reason='Current maker matrix explicitly gives the unladen/empty-load figure; it is not a full-load clearance.')
        if k == 'msrp_aud':
            n = {**fd['price_aud'], 'key': k, 'label': 'Maker base/MSRP', 'reason': 'Same currently published maker exact-grade base/MSRP as canonical price; retained scalar alias is reconciled, not left unknown.'}
            for x in ['priceRung', 'rankingEligible', 'basisTag']:
                n.pop(x, None)
        if k == 'battery_warranty_capacity_threshold':
            n.update(sourceKeys=['warranty', 'service'], reason='Current warranty wording “State-of-Health drops ≤30% degradation of its original capacity” is ambiguous, and the service page does not clarify a minimum retained-capacity percentage. No 70 percent guarantee is inferred.')
        if name == 'v' and k in ['kerb_weight_kg', 'gvm_kg']:
            n.update(value=1780 if k == 'kerb_weight_kg' else 2280, sourceKeys=['v_carexpert_weights'], grade='reported', basis='CarExpert-reported Australian ' + ('kerb mass' if k == 'kerb_weight_kg' else 'gross vehicle mass'), comparison='Kerb mass' if k == 'kerb_weight_kg' else 'Gross vehicle mass', reason='CarExpert exact Premium and Luxury columns report this value. Current maker grade matrix does not state mass, and the owner manual has multiple unidentified regional combinations.')
        if name == 'v' and k == 'tyre_size':
            n.update(value='225/45 R19', sourceKeys=[owner], grade='reported', basis='Australian-linked owner manual tyre table; local delivered fitment to confirm', comparison='Tyre size', reason='The manufacturer-linked owner manual publishes 225/45 R19 but does not separately name Premium/Luxury; retained as Reported range-level manual evidence.')
        if name == 'v' and k == 'android_auto':
            n.update(value=True, sourceKeys=[owner], grade='reported', basis='Android Auto described in the Australian-linked owner manual', comparison='Phone integration', reason='Manual describes Android Auto but current local named-grade matrix only lists CarPlay; owner-manual applicability is Reported rather than silently asserted as exact local-grade maker confirmation.')
        v['facts'].append(n)
    for feat in v['features']:
        if feat['criterion'] == 'carplay_android_auto' and name == 'v':
            feat.update(keys=['apple_carplay', 'android_auto'], grade='reported')
(R / 'normalized-evidence.json').write_text(json.dumps(p, indent=2, ensure_ascii=False) + '\n')
