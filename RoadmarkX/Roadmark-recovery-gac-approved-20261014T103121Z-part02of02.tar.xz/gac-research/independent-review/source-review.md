# Independent GAC source review

Status: final-byte source, guarded replay and artifact verification passed. Approved hashes are in the accompanying machine records.
Reviewed 14 October 2026 against DOT-BRIEF-103 in full.

## Source decisions
- The current Australian maker matrix has AION UT Premium/Luxury and AION V Premium/Luxury. All are FWD. The `/2025` path is not an explicit manufacturer model-year declaration. Existing four MY-null technical identities are appropriate; no separate 2025/2026/2027 cohort has been established.
- Official AU range, CarExpert and CarsGuide full-brand lists agree on the two BEV families. M8/E9 are PHEVs and EMZOOM/GS8 are non-BEVs. Brand-list reconciliation does not prove whole-market C1.
- The 44 kWh UT remains an upcoming lead. The 11 August GoAuto report gives late-2026 arrival, 320 km WLTP and unannounced Australian price/output. The latest census worker found the 24 September CarsGuide December timing. Current maker matrix contains only 60 kWh grades. Hyptec HT and UT Cross lack current Australian retail-grade evidence. A dealer-new label is not independently verified physical stock, and the live dealer reclassification of G000128 as Demo supersedes a stale third-party new listing.
- Current maker values independently checked: UT 430 km WLTP, 60 kWh published capacity, 87 kW vehicle DC acceptance, 11 kW AC, 150 kW, 7.3 seconds, 4270 × 1850 × 1575 mm. V 510 km WLTP, 75.26 kWh published capacity, 180 kW vehicle DC acceptance, 11 kW AC, 150 kW, 4605 × 1854 × 1686 mm. Both have five seats. Gross/usable distinctions are not invented.
- UT maker 24 minutes is 30–80%, never 10–80%. The approximately 34-minute 10–80% secondary figure stays Reported and unranked. V maker 24 minutes explicitly uses 10–80%. V 7.9-second acceleration remains Reported. Towing database zeros alongside unspecified-capacity prose do not establish a zero rating; four towing cells remain Not published after multiple-source searches.
- UT luggage 321/689 L uses the maker's standard volume block method without inventing VDA or loading height. V 427/978 L lacks a named method and load configuration. The reviewer caught and requested correction of the inherited “Maximum folded cargo” label; the candidate owner changed it to expanded/upper published volume. V cargo must remain unranked.
- Exact equipment rows control over secondary shorthand. UT Luxury has driver-seat ventilation, not established passenger-seat ventilation; both front seats are heated. V optional non-full-size spare is not standard. Current ANCAP UT result is five stars, but eCall hardware does not imply active service before its October 2027 target. Generic model-year/laboratory caveats should not demote exact maker figures.
- Current warranty PDF table gives private eight-year unlimited-distance vehicle and eight-year/200,000 km battery coverage. Commercial exceptions and contradictory UT commercial battery/integrated-drive prose are not generalized to private terms. The malformed battery-SOH sentence is not converted into a 70% warranty guarantee.
- Roadside is initially 12 months with eligible annual authorised-service renewal up to five years. Included fitment is separate from the evidence grade and renewal conditions. Out-of-charge towing to a charging station does not include electricity costs.

## Independent maker-price discovery
The reviewer used dot's cloud Chrome public configurator, selected the exact grade and example VIC metropolitan postcode 3000 / Personal registration, and waited for the page's calculation to settle. No login, hidden runtime data, API signing, external submission of user information or manual discount arithmetic was used.

Base/MSRP before on-road fees: UT Premium A$31,990; UT Luxury A$35,990; V Premium A$42,590; V Luxury A$44,590. These direct current maker prices outrank the earlier secondary fallback.

Separate displayed VIC driveaway estimates: UT A$31,990/A$35,990; V A$46,180/A$48,270. UT's displayed purchase subsidy offsets A$2,310/A$2,480 on-road fees; V displays zero subsidy and A$3,590/A$3,680 fees. The page assumes a private 40-year-old with good driving record, metropolitan garaging and 12 months registration/CTP. Standard V white and UT white/beige are included; nonstandard paint adds A$600 and UT two-tone A$1,000. GST treatment is not separately stated in the captured UI. This is not a personalised insurance or delivery quote.

The active Q4 novated offers are separate: UT delivery by 15 January 2027, V by 31 January 2027. V A$2,000 cashback requires order by 31 October and delivery by 15 November 2026, A$1,000 deposit, excludes fleet/government/rental and cannot combine with GAC vehicle finance. No benefit is silently subtracted from MSRP. The 22 kW complimentary wall charger does not change the cars' 11 kW AC limits. Historic first-600 UT pricing and stale image-alt promotion text are not current offers.

Four exact-grade text captures and provenance with hashes are in `/tmp/gac-research/terms/maker-price-browser-provenance.json`. These contain public page text only; no browser screenshots or runtime credentials.

## Main sources
- https://www.gacgroup.com/en-au/configuration/AION%20UT/2025
- https://www.gacgroup.com/en-au/configuration/aion-v/2025
- https://www.gacgroup.com/en-au/price/AION%20UT/2025
- https://www.gacgroup.com/en-au/price/aion-v/2025
- https://www.gacgroup.com/en-au/hatchback/aion-ut
- https://www.gacgroup.com/en-au/suv/aion-v
- https://www.gacgroup.com/en-au/our-service
- https://eu-www-resouce-cdn.gacgroup.com/static/AU/tenant/cms/material/202608/1787037645132-Warranty-Terms-and-Conditions-FINAL-.pdf
- https://eu-www-resouce-cdn.gacgroup.com/AU/Roadside_assistance_terms_and_conditons.pdf
- https://www.ancap.com.au/media-and-gallery/media-releases/7ec1a6
- https://www.goauto.com.au/amp/gac/aion/ut/cheaper-aion-ut-coming-to-australia/2026-08-11/100091.html

## Final guarded replay
The independent replay passed against the approved packet, before registration. Four existing versions and all full serialized before states matched, including canonical projections. No new version was introduced, so a new-version baseline is inapplicable. No configuration scope was changed and no production guard relaxation was required.

Verified 704 specific edits plus three inherited brand terms, 716 citable reviewed facts, 420 exact equipment symbols/values, 114 feature replacements and 182 exact feature dependencies. All four supported strength/trade-off pairs are visible. Actual registered-pipeline simulation and portable pack roundtrip preserve every field. Other brands, previous source rows and 95 pre-existing data files are unchanged.

Eleven negative mutation classes passed: version/fact/feature/availability before-state drift, incomplete brand scope, feature/summary dependency drift, price-basis corruption, roadside fitment misuse, and prior-source collision. Twenty-eight source/freshness/basis ranking exclusions and twenty-eight secondary-evidence promotion rejections passed. The manufacturer-issued generic-manual facts intentionally stay Reported because exact local trim applicability is uncertain; issuer alone does not supply that scope.

All 68 core cells are reviewed: 60 Confirmed, four Reported and four Not published. Current-brand model/version closure is supported; whole-market C1 remains open. C2 fails only on four braked-towing cells in this slice. Ranking inclusion is price 4/4, range 4/4, charging time 2/4, seats 4/4, boot 2/4 and towing 0/4, so C5 remains open. C3, C4 and C6 pass for the GAC slice. Remaining non-core lifestyle/subjective questions are honestly retained as unverified; they are not converted into unsupported negative facts.

Final lightweight verification matched the staged repository packet and reconciliation, all 154 artifact-manifest entries and all 111 capture-manifest entries. A bounded independent credential-value scan found no matches across 99 text captures. Public PDFs and images have provenance and hashes, but this is not an exhaustive security certification; the root's separate recovery privacy gate remains required.

## Diagnostics
The independent runner first encountered environment launch issues in pnpm and the tsx CLI IPC pipe. Direct `node --import=tsx` worked. Its first full replay reached the final immutable audit and encountered a reviewer-harness array-versus-map assumption; the harness was corrected without changing any baseline or product data, then the complete replay passed. Earlier candidate diagnostics preserved by the owner include a rejected null towing dependency in a summary; the final summary uses a supported five-seat constraint. The inaccurate folded-cargo label was corrected before final approval.

Machine records: `independent-review-replay.json`, `final-artifact-verification.json`, `replay.exit` and the separate launch/harness diagnostic logs. The parent owns registry integration, production validation and release decisions.
