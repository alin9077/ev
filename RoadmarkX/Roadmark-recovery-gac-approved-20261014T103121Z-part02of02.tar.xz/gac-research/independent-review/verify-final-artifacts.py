from pathlib import Path
import json,hashlib,re
R=Path('/tmp/gac-research');Q=Path('/workspace/scratch/586427eef9f2/roadmark-104-qa/gac-independent-review');REPO=Path('/workspace/scratch/586427eef9f2/roadmark-104')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
review=json.loads((Q/'independent-review-replay.json').read_text());assert review['status']=='passed'
for name,h in review['approvedHashes'].items():assert sha(R/name)==h,name
for stem,dest in [('gac-2026-10-14.json','data/m1-brand-updates/gac-2026-10-14.json'),('gac-reconciliation-2026-10-14.json','data/m1-gac-market-reconciliation-2026-10-14.json')]:assert sha(R/stem)==sha(REPO/dest)
artifact=json.loads((R/'artifact-hash-manifest.json').read_text());capture=json.loads((R/'source-hash-manifest.json').read_text())
for manifest in [artifact,capture]:
 for row in manifest['files']:
  p=R/row['path'];assert p.resolve().is_relative_to(R.resolve());assert sha(p)==row['sha256'],row['path'];assert p.stat().st_size==row['bytes'],row['path']
patterns={
 'private_key':re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
 'bearer_value':re.compile(r'Bearer\s+[A-Za-z0-9_\-.+/=]{24,}'),
 'jwt_value':re.compile(r'eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}'),
 'secret_assignment':re.compile(r'(?i)(?:access_token|refresh_token|id_token|client_secret|csrf_token|session_token|api_key)\s*[\"\x27]?\s*[:=]\s*[\"\x27][A-Za-z0-9_\-.+/=]{24,}[\"\x27]'),
 'openai_key':re.compile(r'\bsk-(?:proj-)?[A-Za-z0-9_-]{30,}'),
}
scanned=[];matches=[]
for row in capture['files']:
 p=R/row['path']
 if p.suffix.lower() not in ['.json','.txt','.html','.md','.log','.js','.py','.ts']:continue
 txt=p.read_text(errors='replace');scanned.append(row['path'])
 for name,pattern in patterns.items():
  for m in pattern.finditer(txt):matches.append(dict(path=row['path'],pattern=name,line=txt.count('\n',0,m.start())+1))
result=dict(status='passed' if not matches else 'review_required',checkedAt='2026-10-14',packetSha256=review['approvedHashes']['gac-2026-10-14.json'],reconciliationSha256=review['approvedHashes']['gac-reconciliation-2026-10-14.json'],stagedRepoPacketParity=True,artifactManifestEntries=len(artifact['files']),captureManifestEntries=len(capture['files']),textCapturesScanned=len(scanned),patternNames=list(patterns),sensitivePatternMatches=matches,limitations='Bounded credential-value pattern scan of text captures only; public PDF/images retain hashes but are not content-scanned. Not an exhaustive security certification. Root final recovery privacy gate remains separate.',approvedHashes=review['approvedHashes'],allArtifactHashes={row['path']:row['sha256']for row in artifact['files']},allCaptureHashes={row['path']:row['sha256']for row in capture['files']},verificationScriptSha256=sha(Path(__file__)))
(Q/'final-artifact-verification.json').write_text(json.dumps(result,indent=2)+'\n')
assert not matches,str(matches)
print(json.dumps({k:v for k,v in result.items()if k not in ['allArtifactHashes','allCaptureHashes','approvedHashes']},indent=2))
