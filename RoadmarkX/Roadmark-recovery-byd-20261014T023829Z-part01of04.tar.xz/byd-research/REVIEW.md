# BYD independent review targets

Staged, not registered. Australian review date: 14 October 2026. Original evidence is unchanged.

## Exact current prices

- Sealion 7 Premium RWD: A$54,990; rung 3; Before on-road costs; confirmed. https://bydautomotive.com.au/configurator/byd-sealion-7
- Sealion 7 Performance AWD: A$63,990; rung 3; Before on-road costs; confirmed. https://bydautomotive.com.au/configurator/byd-sealion-7
- ATTO 2 Dynamic: A$31,990; rung 3; Before on-road costs; confirmed. https://bydautomotive.com.au/configurator/byd-atto-2
- ATTO 2 Premium: A$35,990; rung 3; Before on-road costs; confirmed. https://bydautomotive.com.au/configurator/byd-atto-2
- ATTO 3 EVO Dynamic FWD: A$41,990; rung 3; Before on-road costs; confirmed. https://bydautomotive.com.au/configurator/byd-atto-3-evo
- ATTO 3 EVO Premium RWD: A$46,990; rung 3; Before on-road costs; confirmed. https://bydautomotive.com.au/configurator/byd-atto-3-evo
- ATTO 3 (legacy FWD) Essential FWD: A$39,990; rung 3; Before on-road costs; confirmed. https://bydautomotive.com.au/configurator/byd-atto-3-evo
- ATTO 3 (legacy FWD) Premium FWD: A$44,990; rung 5; Before on-road costs; reported. https://www.carexpert.com.au/car-reviews/2025-byd-atto-3-review
- SEAL Premium RWD: A$52,990; rung 3; Before on-road costs; confirmed. https://bydautomotive.com.au/configurator/byd-seal
- SEAL Performance AWD: A$61,990; rung 3; Before on-road costs; confirmed. https://bydautomotive.com.au/configurator/byd-seal
- DOLPHIN Essential FWD: A$28,888; rung 2; Driveaway; check. https://bydautomotive.com.au/offers
- DOLPHIN Premium FWD: A$36,990; rung 3; Before on-road costs; confirmed. https://bydautomotive.com.au/configurator/byd-dolphin
- ATTO 1 Essential FWD: A$19,990; rung 2; Driveaway; check. https://bydautomotive.com.au/offers
- ATTO 1 Premium FWD: A$27,990; rung 3; Before on-road costs; confirmed. https://bydautomotive.com.au/configurator/byd-atto-1

## Honest core gaps after two distinct documents

- ATTO 2 Dynamic / towing_braked_kg: Brochure gives no braked rating; handbook gives 750 kg maximum total towing without distinguishing brakes. The separate towing-limit figure is retained, not relabelled braked.
  - https://bydautomotive.com.au/brochures/BYD-ATTO-2-2025.pdf
  - https://bydautomotive.com.au/brochures/BYD-ATTO-2-Owners-Handbook-2025.pdf
- ATTO 2 Premium / towing_braked_kg: Brochure gives no braked rating; handbook gives 750 kg maximum total towing without distinguishing brakes. The separate towing-limit figure is retained, not relabelled braked.
  - https://bydautomotive.com.au/brochures/BYD-ATTO-2-2025.pdf
  - https://bydautomotive.com.au/brochures/BYD-ATTO-2-Owners-Handbook-2025.pdf
- ATTO 3 EVO Dynamic FWD / dc_charge_time_min: Maker brochure gives 41 minutes 0–80%; the Australian WhichCar review gives no Dynamic 10–80% time. No conversion was made after these two checks.
  - https://bydautomotive.com.au/brochures/BYD-ATTO-3-EVO.pdf?v=3
  - https://www.whichcar.com.au/reviews/byd-atto-3-evo-review-australia-premium-dynamic-2026-specs-price
- SEAL Premium RWD / dc_charge_time_min: The current Australian specification sheet and Australian handbook publish no exact 10–80% duration for Premium or Performance. No 30–80% or overseas result was substituted.
  - https://bydautomotive.com.au/brochures/BYD-SEAL-2026.pdf
  - https://bydautomotive.com.au/brochures/BYD-SEAL-Owners-Handbook-2025.pdf
- SEAL Premium RWD / towing_braked_kg: Current Australian brochure and handbook give no numeric braked trailer rating. A towbar accessory or EPB vehicle-towing mode does not establish trailer capacity.
  - https://bydautomotive.com.au/brochures/BYD-SEAL-2026.pdf
  - https://bydautomotive.com.au/brochures/BYD-SEAL-Owners-Handbook-2025.pdf
- SEAL Performance AWD / dc_charge_time_min: The current Australian specification sheet and Australian handbook publish no exact 10–80% duration for Premium or Performance. No 30–80% or overseas result was substituted.
  - https://bydautomotive.com.au/brochures/BYD-SEAL-2026.pdf
  - https://bydautomotive.com.au/brochures/BYD-SEAL-Owners-Handbook-2025.pdf
- SEAL Performance AWD / towing_braked_kg: Current Australian brochure and handbook give no numeric braked trailer rating. A towbar accessory or EPB vehicle-towing mode does not establish trailer capacity.
  - https://bydautomotive.com.au/brochures/BYD-SEAL-2026.pdf
  - https://bydautomotive.com.au/brochures/BYD-SEAL-Owners-Handbook-2025.pdf
- DOLPHIN Essential FWD / dc_charge_time_min: Maker sheet gives DC peak only; EV Central gives a 40–41 minute model-range span without mapping Essential/Premium. An exact-version 10–80% figure was not established after two sources.
  - https://bydautomotive.com.au/brochures/BYD-DOLPHIN-2025.pdf
  - https://evcentral.com.au/cars/byd/dolphin/
- DOLPHIN Premium FWD / dc_charge_time_min: Maker sheet gives DC peak only; EV Central gives a 40–41 minute model-range span without mapping Essential/Premium. An exact-version 10–80% figure was not established after two sources.
  - https://bydautomotive.com.au/brochures/BYD-DOLPHIN-2025.pdf
  - https://evcentral.com.au/cars/byd/dolphin/
- ATTO 1 Essential FWD / towing_braked_kg: Australian brochure and handbook give no numeric braked trailer rating. Handbook warns against towing and excludes trailer-towing damage; unknown is not recorded as zero.
  - https://bydautomotive.com.au/brochures/BYD-ATTO-1-2025.pdf?v=1
  - https://bydautomotive.com.au/brochures/BYD-ATTO-1-Owners-Handbook-2025.pdf
- ATTO 1 Premium FWD / towing_braked_kg: Australian brochure and handbook give no numeric braked trailer rating. Handbook warns against towing and excludes trailer-towing damage; unknown is not recorded as zero.
  - https://bydautomotive.com.au/brochures/BYD-ATTO-1-2025.pdf?v=1
  - https://bydautomotive.com.au/brochures/BYD-ATTO-1-Owners-Handbook-2025.pdf

## Important non-gap qualifications

- ATTO 1 brochure PDF page 2 explicitly prints 30 minutes at 10–80% for both grades and 25/22 minutes at 30–100%. Both observations are retained; conflicting time is Check/unranked.
- ATTO 2 handbook: 750 kg maximum total towing, no brake distinction. Separate Check figure retained; canonical braked capacity remains null.
- SEALION 7 32-minute 10–80% time is Reported from GoAuto, not a current maker time.
- Legacy ATTO 3 approximately 35-minute 10–80% time is Reported from CarExpert; Essential 7 kW AC is explicitly a sibling carry.
- DOLPHIN 7 kW AC and 0 kg braked towing are explicitly Reported from EV Central. The maker sheet publishes neither. Its 40–41 minute charging span remains unmapped to exact grades.
- ATTO 3 EVO Premium 25-minute 10–80% time is Reported from the Australian WhichCar launch review. Both maker 0–80% times remain separate.
- Boot litres are directly Confirmed, but no VDA/SAE ranking method is established. They remain unranked.

## Validation

Isolated prepareBrandResearch/applyBrandUpdates passes. Staged coverage reports BYD researchCompleted=true; C3/C4/C6 pass. Eleven core gaps remain; no unreviewed core grades. C1 still needs independent whole-market lists; C2/C5 remain open.
