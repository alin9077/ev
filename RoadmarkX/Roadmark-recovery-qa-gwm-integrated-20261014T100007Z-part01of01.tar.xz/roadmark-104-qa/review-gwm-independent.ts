import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {catalogue,research,effectiveFeatures,pack} from '../roadmark-104/src/lib/data.ts';
import {prepareBrandResearch,applyBrandUpdates,applyBrandFeatureUpdates,applyBrandTermFeatures,brandVersionSnapshot,type BrandUpdatePacket} from '../roadmark-104/src/lib/brand-updates.ts';
import {brandUpdatePackets} from '../roadmark-104/src/lib/brand-update-registry.ts';
import {compiledSource} from '../roadmark-104/tests/helpers/compiled-source.ts';
import {hasEarnedBuyerGrade} from '../roadmark-104/src/lib/evidence-grading.ts';
import {factClaim,featureClaim} from '../roadmark-104/src/lib/citable.ts';
import {storePortablePacks,hydratePortablePacks} from '../roadmark-104/src/lib/portable-packs.ts';
import {coreFacts} from '../roadmark-104/scripts/reporting/reports.ts';
import {rankAttribute,exclusionReason} from '../roadmark-104/src/lib/discovery.ts';
import {currentBuyerSummary} from '../roadmark-104/src/lib/selling-points.ts';
import {buyerAvailability,statedArrivalTiming} from '../roadmark-104/src/lib/buyer-availability.ts';

const R='/tmp/gwm-research';
const Q=path.resolve('../roadmark-104-qa/gwm-independent-review');
const read=(f:string)=>JSON.parse(fs.readFileSync(path.join(R,f),'utf8'));
const plain=<T>(v:T):T=>JSON.parse(JSON.stringify(v));
const sha=(f:string)=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const digest=(x:unknown)=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
const artifacts=['gwm-2026-10-14.json','gwm-reconciliation-2026-10-14.json','brand-model-list-reconciliation.json','core-matrix.json','source-index.json','source-hash-manifest.json','evidence-completeness-audit.json'].filter(f=>fs.existsSync(path.join(R,f)));
const approvedHashes=Object.fromEntries(artifacts.map(f=>[f,sha(path.join(R,f))]));
assert.equal(approvedHashes['gwm-2026-10-14.json'],'76212ed44d9c299a8d646e647bc26ab6026ddcae5de1d5e23fe653d233f79b75');
assert.equal(approvedHashes['gwm-reconciliation-2026-10-14.json'],'9e5c0a5bfba724b6c890a0a0b6c6bb2c9e4817bb446d1d9be37f29c1ad98f7ab');

const codeHashes=Object.fromEntries(['src/lib/brand-configuration-updates.ts','src/lib/brand-updates.ts','src/lib/types.ts','src/lib/data.ts','tests/brand-configuration-updates.test.ts','tests/brand-feature-updates.test.ts'].map(f=>[f,sha(f)]));
const p=read('gwm-2026-10-14.json') as BrandUpdatePacket;
console.log('Loading current catalogue');
assert(!brandUpdatePackets.some(q=>q.id===p.id),'Review must occur before registration');
const rd=research(),before=catalogue(),inputs=digest({rd,before,p});
const isReviewed=(c:any)=>c.brand==='GWM'&&(!c.vehicleClass||['passenger','ute'].includes(c.vehicleClass));
const old=before.filter(isReviewed);
const existing=new Map(before.map(c=>[c.id,c]));
assert.deepEqual(plain(old),read('gwm-live-before.json'));
assert.deepEqual(plain(rd.sources),read('gwm-source-before.json'));
assert.equal(p.brand,'GWM');assert.equal(p.reviewedAt,'2026-10-14');
const expectedIds=[...old.map(c=>c.id),...p.variants.map(v=>v.id)].sort();
assert.equal(new Set(expectedIds).size,expectedIds.length);
assert.equal(p.versionGuards.length,old.length);
assert.deepEqual(p.availability.map(r=>r.variantId).sort(),expectedIds);
assert.deepEqual(p.summaries.map(r=>r.variantId).sort(),expectedIds);
const sources=new Map(p.sources.map(s=>[s.id,s]));
const priorSources=new Map(rd.sources.map(s=>[s.id,s]));
const captureFiles=new Set<string>();let captureReferences=0;
for(const s of p.sources){
 let captured=false;
 for(const [locator,hashKey] of [['capture_locator','capture_sha256'],['capture_text_locator','capture_text_sha256']]){
  const f=(s as any)[locator];if(!f)continue;captured=true;
  const file=path.resolve(R,f);assert(file.startsWith(R+'/'),'Capture traversal');
  assert.equal(sha(file),(s as any)[hashKey],`${s.id} capture hash`);captureReferences++;captureFiles.add(f);
 }
 if(!captured){if(priorSources.has(s.id))assert.deepEqual(s,priorSources.get(s.id),`${s.id} prior source changed`);else{assert(s.access_limitation,`${s.id} new successful source lacks capture`);assert(!p.facts.some(f=>f.after.sourceIds.includes(s.id)),`${s.id} failed source supports a fact`);assert(!p.brandTerms!.some(t=>t.fact.sourceIds.includes(s.id)),`${s.id} failed source supports a term`);assert(!p.features!.some(f=>f.after.source_ids.includes(s.id)),`${s.id} failed source supports a feature`);assert(!p.availability.some(a=>a.after.evidence.sourceIds.includes(s.id)),`${s.id} failed source supports availability`);}}
}
for(const g of p.versionGuards)assert.deepEqual(g.before,brandVersionSnapshot(existing.get(g.variantId)!));
for(const row of p.facts){assert.deepEqual(row.before??null,plain(existing.get(row.variantId)?.facts[row.after.key]??null),`${row.variantId}/${row.after.key} before`);assert(row.after.sourceIds.every(id=>sources.has(id)));}
for(const term of p.brandTerms!){
 assert.deepEqual([...term.applicableVariantIds,...term.exceptions.map(e=>e.variantId)].sort(),expectedIds,`${term.key} scope`);
 for(const id of term.applicableVariantIds)assert.deepEqual(term.before[id]??null,plain(existing.get(id)?.facts[term.key]??null),`${id}/${term.key} before`);
 assert(['confirmed','check'].includes(term.fact.buyerGrade!));assert.equal(term.fact.gradeReview?.evidenceScope,'brand_au_terms');if(term.fact.buyerGrade==='check')assert(term.fact.conditionExplanation?.trim());
}
console.log('Checking capture and before-state guards');
const data=prepareBrandResearch(rd,[p]),cars=applyBrandUpdates(before,data,[p]),selected=cars.filter(isReviewed);
assert.deepEqual(selected.map(c=>c.id).sort(),expectedIds);
assert.equal(p.configurationUpdates?.length,2);
for(const car of selected){
 const hatch=car.model==='Ora (hatchback)';const ultra=car.trim==='Ultra';
 const expected:Record<string,unknown>={price_aud:ultra?36990:33990,range_km:hatch?400:435,battery_kwh:hatch?57.7:58.33,dc_peak_kw:hatch?80:120,dc_charge_time_min:hatch?null:30,ac_kw:hatch?11:6.6,seats:5,boot_l:hatch?228:362,zero_to_100_s:hatch?9:8,power_kw:hatch?126:150,drive:'FWD',length_mm:hatch?4235:4471,width_mm:hatch?1825:1833,height_mm:hatch?1603:1641,towing_braked_kg:hatch?0:750};
 for(const [key,value] of Object.entries(expected))assert.deepEqual(car.facts[key].value,value,`${car.id}/${key} independent source check`);
 assert.equal(car.facts.range_km.comparisonBasis,hatch?'WLTP':'WLTC');
 assert.equal(car.facts.price_aud.priceEvidence?.rung,4);assert.equal(car.facts.price_aud.priceEvidence?.state,'VIC');
 assert.equal(car.facts.price_aud.buyerGrade,'check');
 if(!hatch){assert.equal(car.facts.price_aud.validUntil,'2026-10-31');assert.equal(car.facts.towing_unbraked_kg.value,750);}
 else{assert.equal(car.facts.dc_peak_kw.buyerGrade,'reported');assert.equal(car.facts.towing_braked_kg.buyerGrade,'reported');assert.equal(car.facts.dc_charge_time_min.buyerGrade,'not_published');}
 assert.equal(car.facts.boot_l.comparisonBasis,'');assert.equal(car.facts.max_total_cargo_l.label,'Maximum luggage capacity');
 assert.equal(car.facts.heat_pump.value,true);assert.equal(car.facts.heat_pump.buyerGrade,'confirmed');
}

let configurationDependencies=0;
for(const row of p.configurationUpdates!){
 const car=selected.find(c=>c.id===row.variantId)!;
 assert.deepEqual(row.before,existing.get(row.variantId)!.configurationEvidence);
 assert.deepEqual(car.configurationEvidence,row.after);
 assert.deepEqual(data.variants.find(v=>v.id===row.variantId)!.configuration_evidence,row.after);
 assert.deepEqual(data.feature_evidence_variant_context!.find(v=>v.id===row.variantId)!.configuration_evidence,row.before,'Historical equipment context changed');
 assert.equal(row.after.rankingEligible,true);assert.equal(row.after.completeVehicleCountEligible,false);
 assert.equal((row.after.countContribution as any)?.completeTechnicalRecords??0,0);
 const originalHolds=row.before!.requiredNulls as Record<string,unknown>;
 const retainedHolds=row.after.requiredNulls as Record<string,unknown>;
 assert.equal(Object.keys(originalHolds).length,30);assert.equal(Object.keys(retainedHolds).length,20);assert.deepEqual(row.after.configurationReview!.releasedNulls.map(r=>r.key).sort(),['price_aud','battery_kwh','ac_kw','dc_peak_kw','boot_l','max_total_cargo_l','towing_braked_kg','towing_unbraked_kg','warranty','battery_warranty'].sort());
 for(const [key,value] of Object.entries(retainedHolds))assert.deepEqual(value,originalHolds[key],`${row.variantId}/${key} retained legacy hold changed`);
 const removed=Object.keys(originalHolds).filter(key=>!Object.hasOwn(retainedHolds,key)).sort();
 assert.deepEqual(removed,row.after.configurationReview!.releasedNulls.map(r=>r.key).sort());
 for(const release of row.after.configurationReview!.releasedNulls){
   assert.equal(release.factKeys.length,1);assert.equal(release.factKeys[0],release.key,'No new or implicit alias release');
   const proof=row.dependencies.find(d=>d.key===release.factKeys[0])!;
   assert(proof,`${release.key} lacks exact dependency`);
   assert(proof.expected.value!==null);assert.equal(proof.expected.gradeReview?.overlayId,p.id);
 }
 for(const key of ['model_year','battery_gross_kwh','battery_usable_kwh','range_wltp_km','factory_build_code','vin','physical_new_stock_quantity','factory_orderability','sos_active','battery_warranty_retention_percent','motor_continuous_power_kw'])assert.deepEqual(retainedHolds[key],originalHolds[key],`${row.variantId}/${key} must remain held`);
 for(const key of ['sourceIdentity','options','pricingBoundary','chargingBoundary','projectionContract'])assert.deepEqual(row.after[key],row.before![key],`${row.variantId}/${key} changed`);
 for(const dep of row.dependencies){assert.deepEqual(car.facts[dep.key],dep.expected);configurationDependencies++;}
} 
assert.deepEqual(cars.filter(c=>!isReviewed(c)),before.filter(c=>!isReviewed(c)),'Other brands or GWM Tier 2 changed');
assert.deepEqual(data.sources.filter(s=>!sources.has(s.id)||priorSources.has(s.id)),rd.sources,'Prior source rows changed');
const baseline=new Map(selected.map(c=>[c.id,effectiveFeatures(existing.get(c.id)||c,existing.has(c.id)?rd:data)]));
assert.deepEqual(plain(old.flatMap(c=>baseline.get(c.id)!)),read('gwm-feature-before.json'));
if(p.variants.length)assert.deepEqual(plain(selected.filter(c=>!existing.has(c.id)).flatMap(c=>baseline.get(c.id)!)),read('new-feature-before.json'));
for(const row of p.features!)assert.deepEqual(row.before,plain(baseline.get(row.variantId)!.find(f=>f.criterion===row.criterion)),`${row.variantId}/${row.criterion} feature before`);
for(const row of p.availability){
 if(existing.has(row.variantId)){const c=existing.get(row.variantId)!;assert.deepEqual(row.before,plain({availability:c.availability,evidence:c.availabilityEvidence}));}
 assert.equal(row.after.evidence.physicalStockVerified,false);assert.equal(row.after.evidence.factoryOrderAcceptanceVerified,false);
}
const actual=compiledSource('src/lib/data.ts',{'./brand-update-registry':{brandUpdatePackets:[...brandUpdatePackets,p]}}) as {pack:typeof pack};
const packs:Record<string,ReturnType<typeof pack>>={};let factsChecked=0,featuresChecked=0,dependenciesChecked=0,notPublished=0;
for(const car of selected){
 console.log('Checking actual pack',car.id);
 for(const {key} of coreFacts)assert.equal(car.facts[key]?.gradeReview?.overlayId,p.id,`${car.id}/${key} unreviewed`);
 const features=applyBrandTermFeatures(car,applyBrandFeatureUpdates(car,baseline.get(car.id)!,data,[p]));
 const view=actual.pack(car.id,{data,cars});packs[car.id]=view;
 assert.deepEqual(view.car,car);assert.deepEqual(view.features,features,'Actual effective feature pipeline differs');
 for(const f of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===p.id)){
  assert(hasEarnedBuyerGrade(f,data.sources,'2026-10-14'),`${car.id}/${f.key} grade`);
  const c=factClaim(view,f);assert.equal(c.buyerGrade,f.buyerGrade);assert.deepEqual(c.sources.map(s=>s.id),f.sourceIds);assert.deepEqual(c.gradeReview,f.gradeReview);factsChecked++;
  if(f.buyerGrade==='not_published'){assert.equal(f.value,null);assert(new Set(f.sourceIds.map(id=>sources.get(id)!.url.split('#')[0])).size>=2);notPublished++;}
  if(f.buyerGrade==='check')assert(f.conditionExplanation?.trim());
 }
 for(const row of p.features!.filter(f=>f.variantId===car.id)){
  const f=features.find(f=>f.criterion===row.criterion)!;assert.deepEqual(f,row.after);assert(hasEarnedBuyerGrade(f,data.sources,'2026-10-14'));
  const claim=featureClaim(view,f.criterion,f.criterion)!;assert.deepEqual(claim.sources.map(s=>s.id),f.source_ids);assert.equal(claim.buyerGrade,f.buyerGrade);featuresChecked++;
  for(const d of row.dependencies){assert.deepEqual(car.facts[d.key],d.expected);dependenciesChecked++;}
  if(f.buyerGrade==='not_published')assert(row.dependencies.some(d=>d.key==='feature_'+row.criterion&&d.expected.value===null));
 }
 const roadside=features.find(f=>f.criterion==='roadside_assistance')!;
 assert.equal(roadside.status,'standard');assert.equal(roadside.buyerGrade,car.facts.roadside_assistance.buyerGrade);assert.deepEqual(roadside.source_ids,car.facts.roadside_assistance.sourceIds);
 assert.equal(featureClaim(view,'roadside_assistance','Roadside')!.status,'standard');
 const visibleSummary=currentBuyerSummary(car.buyerSummary,data.sources,{asOf:'2026-10-14'});assert(visibleSummary?.strength?.text&&visibleSummary?.tradeoff?.text,`${car.id}: actual summary suppressed`);
 assert(car.facts.price_aud.value!==null);assert(car.facts.price_aud.priceEvidence);
 assert(!/Cannon|POER|P.Series|07|Sport|Lightning/.test(car.model+' '+car.trim),'Unproven overseas or PHEV lead entered review');
}
console.log('Checking portable exact roundtrip');
assert.deepEqual(hydratePortablePacks(storePortablePacks(packs),data.sources),packs,'Portable pack roundtrip changes fields');
const rankCounts=Object.fromEntries((['price_aud','range_km','dc_charge_time_min','seats','boot_l','towing_braked_kg'] as const).map(key=>{const r=rankAttribute(selected,data.sources,key,{asOf:'2026-10-14'});return[key,{ranked:r.groups.flatMap(g=>g.entries).length,unranked:r.unranked.length,excluded:r.excluded.length}]}));
assert.deepEqual(Object.fromEntries(Object.entries(rankCounts).map(([key,value])=>[key,value.ranked])),{price_aud:3,range_km:3,dc_charge_time_min:2,seats:3,boot_l:0,towing_braked_kg:2},'Independent expected ranking coverage');
const independentRankingGuards:string[]=[];
for(const row of p.configurationUpdates!){
 const car=selected.find(c=>c.id===row.variantId)!;
 const noRank=(name:string,c:any,ss:any[],asOf='2026-10-14')=>{assert.equal(rankAttribute([c],ss,'range_km',{asOf}).groups.flatMap(g=>g.entries).length,0,`${car.id}/${name}`);independentRankingGuards.push(`${car.id}/${name}`);};
 const sourceIds=new Set(car.facts.range_km.sourceIds);
 noRank('withdrawn source',car,data.sources.filter(s=>!sourceIds.has(s.id)));
 noRank('held source',car,data.sources.map(s=>sourceIds.has(s.id)?{...s,publication_hold:true}:s));
 noRank('inaccessible source',car,data.sources.map(s=>sourceIds.has(s.id)?{...s,access_limitation:'Review fixture: unavailable'}:s));
 noRank('stale source',car,data.sources.map(s=>sourceIds.has(s.id)?{...s,accessed_date:'2025-10-14'}:s));
 noRank('review required',{...car,facts:{...car.facts,range_km:{...car.facts.range_km,gradeReviewStatus:'review_required'}}},data.sources);
 noRank('missing measurement basis',{...car,facts:{...car.facts,range_km:{...car.facts.range_km,comparisonBasis:''}}},data.sources);
 noRank('evidence ageing',car,data.sources,'2027-10-15');
 assert.equal(rankAttribute([car],data.sources,'boot_l',{asOf:'2026-10-14'}).groups.length,0,'Unestablished cargo method ranked');

}
assert.equal(selected.length,3);
assert.equal(selected.filter(c=>buyerAvailability(c)==='on_sale_now').length,3);
assert(selected.every(c=>c.year===null),'Manufacturer model years must remain unverified');
const foreignGradeGuards:string[]=[];
for(const car of selected){
 for(const f of Object.values(car.facts).filter(f=>f.gradeReview?.overlayId===p.id&&f.buyerGrade==='reported')){
  for(const grade of ['confirmed','check'] as const){
   const changed={...f,buyerGrade:grade,gradeReview:{...f.gradeReview!,evidenceScope:'exact_au_version' as const}};
   assert.equal(hasEarnedBuyerGrade(changed,data.sources,'2026-10-14'),false,`${car.id}/${f.key}: secondary evidence promoted`);
   foreignGradeGuards.push(`${car.id}/${f.key}/${grade}`);
  }
 }
}
const pWithoutConfiguration=structuredClone(p);delete pWithoutConfiguration.configurationUpdates;
// New summaries intentionally depend on the reviewed visible conditions; omit them only in this isolated no-configuration negative fixture.
pWithoutConfiguration.summaries=[];
const dataWithoutConfiguration=prepareBrandResearch(rd,[pWithoutConfiguration]);
const carsWithoutConfiguration=applyBrandUpdates(before,dataWithoutConfiguration,[pWithoutConfiguration]);
for(const row of p.configurationUpdates!){
 const c=carsWithoutConfiguration.find(c=>c.id===row.variantId)!;
 assert.deepEqual(c.configurationEvidence,row.before,'Without review, original scope must remain');
 for(const key of ['price_aud','range_km','dc_charge_time_min','seats','boot_l','towing_braked_kg'] as const)assert.equal(rankAttribute([c],dataWithoutConfiguration.sources,key,{asOf:'2026-10-14'}).groups.length,0,'No default configuration promotion');
}
console.log('Checking negative mutations');
const guarded:string[]=[];
function reject(name:string,edit:(q:BrandUpdatePacket)=>void,featureReplay=false){const q=structuredClone(p);edit(q);assert.throws(()=>{const d=prepareBrandResearch(rd,[q]);const cs=applyBrandUpdates(before,d,[q]);if(featureReplay){const c=cs.find(c=>c.id===q.features![0].variantId)!;applyBrandFeatureUpdates(c,baseline.get(c.id)!,d,[q]);}},undefined,name);guarded.push(name);}
reject('version before snapshot',q=>q.versionGuards[0].before.trim+=' changed');
reject('fact before snapshot',q=>{const r=q.facts.find(f=>f.before)!;r.before!.value='changed';});
reject('brand term complete version scope',q=>q.brandTerms![0].applicableVariantIds.pop());
reject('feature before snapshot',q=>q.features![0].before.value='changed',true);
reject('feature post-fact dependency',q=>q.features![0].dependencies[0].expected.value='changed');
reject('summary dependency',q=>q.summaries[0].strength.dependencies[0].expected.value='changed');
reject('availability before snapshot',q=>q.availability[0].before.availability='outgoing');
reject('price ladder basis',q=>{const f=q.facts.find(f=>f.after.key==='price_aud')!.after;f.comparisonBasis=f.priceEvidence!.rung===1?'Driveaway':f.priceEvidence!.rung===2||f.priceEvidence!.rung===4?'Before on-road costs':'';if(f.priceEvidence!.rung>=5)f.buyerGrade='confirmed';});
reject('roadside invalid enum',q=>(q.brandTerms!.find(t=>t.key==='roadside_assistance')!.fact as any).roadsideFitment='included');
reject('roadside metadata on unrelated fact',q=>(q.facts.find(f=>f.after.key==='range_km')!.after as any).roadsideFitment='optional');
reject('existing source collision',q=>q.sources.push({...rd.sources[0],title:rd.sources[0].title+' changed'}));
if(p.variants.length)reject('new version Tier 2 collision',q=>(q.variants[0] as any).vehicle_class='van');
function rejectConfiguration(name:string,edit:(q:BrandUpdatePacket)=>void){const q=structuredClone(p);edit(q);assert.throws(()=>prepareBrandResearch(rd,[q]),/Brand update|Invalid reviewed state/,name+' preparation');assert.throws(()=>applyBrandUpdates(before,data,[q]),/Brand update|Invalid reviewed state/,name+' application');guarded.push(name+' (both stages)');}
rejectConfiguration('configuration full before snapshot',q=>q.configurationUpdates![0].before!.projectionScope+=' changed');
rejectConfiguration('configuration protected source identity',q=>(q.configurationUpdates![0].after as any).sourceIdentity={modelYear:2027});
rejectConfiguration('configuration protected build options',q=>(q.configurationUpdates![0].after as any).options=[]);
rejectConfiguration('configuration historical price boundary',q=>(q.configurationUpdates![0].after as any).pricingBoundary={useForPriceRankings:true});
rejectConfiguration('configuration complete-record promotion',q=>q.configurationUpdates![0].after.completeVehicleCountEligible=true);
rejectConfiguration('configuration complete count promotion',q=>(q.configurationUpdates![0].after as any).countContribution={boundedConfigurationRecords:1,completeTechnicalRecords:1,rankableRecords:1});
rejectConfiguration('configuration dependency drift',q=>q.configurationUpdates![0].dependencies[0].expected.value=1);
rejectConfiguration('configuration explicit source',q=>q.configurationUpdates![0].sourceIds=['missing-source']);
rejectConfiguration('configuration null scope erasure',q=>(q.configurationUpdates![0] as any).after=null);
rejectConfiguration('configuration missing release proof',q=>q.configurationUpdates![0].after.configurationReview!.releasedNulls=[]);
rejectConfiguration('configuration wrong scalar proof',q=>q.configurationUpdates![0].after.configurationReview!.releasedNulls.find(r=>r.key==='dc_peak_kw')!.factKeys=['range_km']);
rejectConfiguration('configuration changed retained legacy hold',q=>(q.configurationUpdates![0].after.requiredNulls as any).model_year+=' changed');
rejectConfiguration('configuration unproven extra legacy release',q=>delete (q.configurationUpdates![0].after.requiredNulls as any).battery_usable_kwh);
rejectConfiguration('configuration duplicate target',q=>q.configurationUpdates!.push(structuredClone(q.configurationUpdates![0])));
rejectConfiguration('configuration unguarded target',q=>q.versionGuards=q.versionGuards.filter(g=>g.variantId!==q.configurationUpdates![0].variantId));
const reconciliation=read('gwm-reconciliation-2026-10-14.json');
assert.equal(reconciliation.publishedLists.length,0,'Brand directories cannot prove whole-market C1');
for(const review of reconciliation.currentVersionReviews)for(const v of review.versions){const c=selected.find(c=>c.id===v.carId)!;assert(c,`${v.carId} reconciliation identity`);assert.equal(c.model,v.model);assert.equal(c.trim,v.trim);assert.equal(c.year,v.modelYear);}
const immutable=read('immutable-data-before.json');
for(const [f,h] of Object.entries(immutable))assert.equal(sha(path.join(process.cwd(),f)),h,`${f} drift`);
let manifestFiles=0;
if(fs.existsSync(path.join(R,'source-hash-manifest.json')))for(const row of read('source-hash-manifest.json').files){const f=path.join(R,row.path);assert.equal(sha(f),row.sha256,row.path);assert.equal(fs.statSync(f).size,row.bytes);manifestFiles++;}
assert.equal(digest({rd,before,p}),inputs,'Input mutation');
for(const [f,h] of Object.entries(approvedHashes))assert.equal(sha(path.join(R,f)),h,'Artifact changed during review');
for(const [f,h] of Object.entries(codeHashes))assert.equal(sha(f),h,'Implementation changed during review');
const result={status:'passed',reviewedAt:'2026-10-14',approvedHashes,codeHashes,counts:{versions:selected.length,newVersions:p.variants.length,sources:p.sources.length,captureReferences,uniqueCaptureFiles:captureFiles.size,manifestFiles,factEdits:p.facts.length,brandTerms:p.brandTerms!.length,citableFacts:factsChecked,features:featuresChecked,dependencies:dependenciesChecked,notPublished,configurationUpdates:p.configurationUpdates!.length,configurationDependencies},rankCounts,foreignGradeGuards,configurationReleases:p.configurationUpdates!.map(r=>({variantId:r.variantId,released:r.after.configurationReview!.releasedNulls,retained:Object.keys(r.after.requiredNulls as object)})),independentRankingGuards,negativeGuards:guarded,actualPackPipeline:true,portableExactRoundtrip:true,otherBrandsUnchanged:true,gwmTier2Unchanged:true,priorSourcesUnchanged:true,immutableDataUnchanged:true,globalC1NotClaimed:true};
fs.mkdirSync(Q,{recursive:true});fs.writeFileSync(path.join(Q,'independent-review-replay.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
