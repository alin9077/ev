# Legacy required-null hold compatibility

## Result and scope

`src/lib/brand-configuration-updates.ts` now accepts a nonempty primitive string as the legacy explanation form of a `requiredNulls` entry, alongside the existing `{value: null, reason, sourceCopyLedgerId?}` form. Only this shape check changed. The string is opaque explanation text: it is never parsed as a fact, coerced to a null, trimmed, rewritten, or copied into a fact record.

A retained legacy string must exactly equal its previous text, including whitespace. Removed legacy entries follow the unchanged release contract: the removed key set must exactly equal the reviewed released-key set, and each release needs one exact current-packet, earned-grade, explicitly sourced fact dependency. Existing aliases and measurement-basis tests remain unchanged. There is no new alias, default ranking promotion, global ranking bypass, or complete-record promotion.

Historical source/build boundaries remain immutable, including unknown metadata. Existing identity, brand, tier, before-state, source snapshot, freshness, grade, count and later-dependency validation are untouched. The small compatibility branch does not alter the source catalogue, any GWM packet, registry, historical snapshot or production type.

## Actual inherited Ora5 example

`tests/fixtures/ora5-legacy-configuration-holds.json` contains the exact 30-string map common to inherited Lux and Ultra SUV records, their two variant IDs, the source filename and its SHA256. The map was checked against both records in the original catalogue-additions JSON. The fixture is 2,954 bytes rather than duplicating the full catalogue or frozen provenance records.

The regression uses those exact hold strings with explicitly synthetic proof to release only `dc_peak_kw` and `towing_braked_kg`, retaining the other 28 entries exactly. Its synthetic 120 kW / 750 kg facts test the guarded update mechanism; they do not constitute approval of a live GWM evidence packet. GWM research and packet ownership remain separate.

## Regression coverage

- Mixed object and legacy string holds, accepted canonical same-key and existing alias releases
- Exact retained whitespace and string preservation, no fact/null generation, no input mutation, frozen historical feature context and deterministic replay
- No configuration update means no ranking promotion, even with a separately confirmed fact
- All 32 prior invalid-update mutations run for both typed-only and mixed legacy inputs, covering identity/source/build/count/type/review/dependency boundaries
- Empty and whitespace-only strings, boxed strings, string arrays, numbers, booleans, bare null/undefined, malformed typed reasons and unexpected typed fields rejected in both before and after snapshots at preparation and catalogue application
- Exact before-text drift, retained-text trimming, string-to-object normalization, newly added holds, removed holds without proof, proof for a hold not actually removed, unrelated fact proof and wrong alias measurement rejected
- Existing independent fact measurement/grade/source/freshness exclusions and later-dependent-fact review checks remain active

## Verification

- Configuration guard + brand feature + correction parity regressions: 142/142 passed (104 configuration cases), exit 0, duration 226.8 seconds
- TypeScript: `node_modules/.bin/tsc --noEmit`, passed
- Targeted lint: `node_modules/.bin/eslint src/lib/brand-configuration-updates.ts tests/brand-configuration-updates.test.ts`, passed
- Focused combined command: `node --import tsx --test --test-concurrency=1 tests/brand-configuration-updates.test.ts tests/brand-feature-updates.test.ts tests/correction-guard-parity.test.ts`; passed
- Initial focused run found two assertions expecting the shape-check error before the stricter plain-JSON check. Boxed strings were correctly rejected; the assertions were corrected to the existing JSON-boundary error. The diagnostic log is retained separately.
- This work does not claim a full test suite, production build or live GWM packet review

## Saved artifacts

- `legacy-configuration-holds-before/`: exact before copies of the two edited files
- `legacy-configuration-holds.patch`: unified patch for two edited files and one new small fixture
- `legacy-configuration-holds-manifest.json`: before/after SHA256 hashes and file sizes
- `legacy-configuration-holds-focused.log` and `.exit`: focused shared guard, feature and parity results
- `legacy-configuration-holds-focused-initial.log`: initial two assertion mismatches
- `legacy-configuration-holds-typecheck.log` and `.exit`
- `legacy-configuration-holds-lint.log` and `.exit`
