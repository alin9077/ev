# Revision 2: JSON-module BOM acceptance

Review-only /tmp revision. The original proposal remains unchanged.

The only helper change is to remove one leading U+FEFF character before JSON.parse, preserving the leading-BOM acceptance identified by independent review. The unmodified text is parsed when the first character is not U+FEFF. A second BOM is not removed.

Add loader regression cases for ordinary JSON, one leading BOM, two leading BOMs, and an embedded BOM in a valid string. The first two must produce equivalent complete objects; the double leading BOM remains a syntax error; the string's embedded character must be retained. Malformed JSON and read errors must still propagate.

The integration calls the reader once at module scope before catalogue(). Fresh-object behavior is acceptable in that concrete consumer scope. There is no assertion of equivalence to cached JSON imports across multiple callers or multiple reader calls.

All validation rules, typed fields, fixture data, complete-object return behavior, existing integration assertions, and the integration patch remain unchanged. No source edits, compiler run, test execution, or helper execution were performed.
