from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

root = Path('/tmp/roadmark-kia-fixture-boundary-review')
repo = Path('/workspace/scratch/586427eef9f2/roadmark-104')
kind = sys.argv[1]
commands = {
    'runtime': ['node', '--import', 'tsx', '--test', '--test-concurrency=1',
                'tests/kia-cadillac-stage.boundary.test.ts'],
    'contract': ['node', 'node_modules/typescript/bin/tsc', '--noEmit', '--strict',
                 '--target', 'ES2022', '--lib', 'ESNext', '--module', 'ESNext',
                 '--moduleResolution', 'Bundler', '--esModuleInterop', '--types',
                 'node', 'tests/helpers/kia-cadillac-stage.ts',
                 'tests/kia-cadillac-stage.contract.test.ts',
                 'tests/kia-cadillac-stage.boundary.test.ts'],
}
command = commands[kind]
stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
target = root / 'receipts' / f'{kind}-wait4-{stamp}'
target.mkdir(exist_ok=False)
paths = [
    root / 'tests/helpers/kia-cadillac-stage.ts',
    root / 'tests/kia-cadillac-stage.boundary.test.ts',
    root / 'tests/kia-cadillac-stage.contract.test.ts',
    root / 'package.json',
    Path(__file__),
    Path('/tmp/roadmark-kia-fixture-boundary-proposal/v2/kia-cadillac-stage.ts'),
    repo / 'tests/kia-cadillac-integration.test.ts',
    repo / 'tests/fixtures/catalogue/kia-cadillac-staged-delta.json',
    repo / 'tsconfig.json',
    repo / 'package.json',
    repo / 'pnpm-lock.yaml',
]

def digest(path):
    hasher = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            hasher.update(block)
    return hasher.hexdigest()

def write_json(name, value):
    (target / name).write_text(json.dumps(value, indent=2) + '\n')

pins = {str(path): digest(path) for path in paths}
write_json('inputs-before.json', pins)
environment = dict(os.environ)
environment['NODE_OPTIONS'] = '--max-old-space-size=256 --max-semi-space-size=1'
environment['TSX_DISABLE_CACHE'] = '1'
write_json('command.json', {
    'argv': command, 'cwd': str(root), 'NODE_OPTIONS': environment['NODE_OPTIONS'],
    'TSX_DISABLE_CACHE': '1', 'timeoutSeconds': 180, 'termGraceSeconds': 10,
    'startedAt': datetime.now(timezone.utc).isoformat(),
})
start = time.monotonic()
term_at = None
kill_sent = False
with (target / 'stdout.log').open('w') as stdout, (target / 'stderr.log').open('w') as stderr:
    process = subprocess.Popen(command, cwd=root, env=environment,
                               stdout=stdout, stderr=stderr, start_new_session=True)
    write_json('process.json', {'pid': process.pid, 'ownedPgid': process.pid})
    while True:
        waited, status, usage = os.wait4(process.pid, os.WNOHANG)
        if waited:
            break
        now = time.monotonic()
        if term_at is None and now - start >= 180:
            os.killpg(process.pid, signal.SIGTERM)
            term_at = now
        elif term_at is not None and not kill_sent and now - term_at >= 10:
            os.killpg(process.pid, signal.SIGKILL)
            kill_sent = True
        time.sleep(0.05)
    code = os.waitstatus_to_exitcode(status)
    process.returncode = code
after = {str(path): digest(path) for path in paths}
write_json('inputs-after.json', after)
changed = [path for path in pins if after[path] != pins[path]]
resources = {
    'source': 'os.wait4', 'maxRssKiB': usage.ru_maxrss,
    'userSeconds': usage.ru_utime, 'systemSeconds': usage.ru_stime,
    'minorFaults': usage.ru_minflt, 'majorFaults': usage.ru_majflt,
    'voluntaryContextSwitches': usage.ru_nvcsw,
    'involuntaryContextSwitches': usage.ru_nivcsw,
}
write_json('resource.json', resources)
receipt = {
    'command': command, 'exitCode': code,
    'signal': -code if code < 0 else None, 'timedOut': term_at is not None,
    'killSent': kill_sent, 'elapsedSeconds': time.monotonic() - start,
    'maxRssKiB': usage.ru_maxrss, 'inputCount': len(pins),
    'changedInputs': changed, 'receiptDirectory': str(target),
    'scope': 'Only review helper, boundary suite, compile fixtures, and listed source pins; not full project validation',
    'endedAt': datetime.now(timezone.utc).isoformat(),
}
write_json('terminal.json', receipt)
print(json.dumps(receipt, indent=2))
print('--- STDOUT ---')
print((target / 'stdout.log').read_text()[-14000:])
print('--- STDERR ---')
print((target / 'stderr.log').read_text()[-5000:])
sys.exit(0 if code == 0 and term_at is None and not changed else 1)
