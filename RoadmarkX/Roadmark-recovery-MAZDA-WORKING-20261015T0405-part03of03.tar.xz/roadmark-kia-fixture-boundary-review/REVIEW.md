# Independent static review of the Kia/Cadillac fixture boundary

## Decision

**Proposal v2 passed bounded runtime validation (20/20) and the isolated three-file compile after correcting one assertion argument-order error in the review-only compile fixture. No blocking defect found for the exact current consumer. Integration and full-project typecheck remain unverified.**

Reviewed exact v2 helper: `/tmp/roadmark-kia-fixture-boundary-proposal/v2/kia-cadillac-stage.ts`, SHA256 `67a1fc0527be36ecbdb02a7b358c2ede257ca5cad8622f79edc001036b3ecd25`. Relative to v1, the only change is reading text first and stripping one leading U+FEFF before JSON.parse. The integration patch is unchanged.

This is approval of an explicitly narrower runtime-validated test contract, not equivalence to the compiler's former fixture-wide inference. On the parent's later explicit authorization, only the prepared runtime boundary suite and isolated three-file compiler check were executed, with the results below. No build, production catalogue hydration, or live source edits occurred. All prepared files are under this review directory. The initial AGENTS filename discovery accidentally traversed parent directories; it did not read their source contents. Subsequent source inspection was limited to the target repository and named proposal.

## Authorized bounded execution receipts

All executed Node checks used max-old-space-size=256 MiB and max-semi-space-size=1 MiB, a 180-second TERM deadline plus 10-second KILL grace, an owned process group, and TSX_DISABLE_CACHE=1. Before/after hashes cover the exact helper, both prepared test files, original fixture, original integration source, and listed package/config inputs. No hashes changed.

- `receipts/runtime-20261015T022248Z`: initial resource-wrapper launch failed with exit 127 because /usr/bin/time is absent. Node and timeout never started. This receipt was preserved. The parent separately authorized one fresh attempt with Python/os.wait4
- `receipts/runtime-wait4-20261015T022508.536529Z`: runtime suite PASSED 20/20; exit 0; no signal or timeout; 0.829 seconds; os.wait4 max RSS 160,512 KiB; all 11 input pins unchanged
- `receipts/contract-wait4-20261015T022517.820186Z`: isolated compile FAILED with exit 2; no signal or timeout; 2.374 seconds; os.wait4 max RSS 174,436 KiB; all 11 input pins unchanged. Diagnostics: contract test line 20 TS2339 (toUpperCase on never), line 29 TS2578 (unused expect-error)
- `receipts/contract-wait4-20261015T022642.131549Z`: separately authorized isolated compile retry PASSED with exit 0 and no diagnostics; no signal or timeout; 2.270 seconds; os.wait4 max RSS 175,480 KiB; all 12 input pins unchanged. It used the versioned corrected contract fixture; helper and runtime suite were unchanged

The two initial compile diagnostics originated in the review's positive assertion: it placed row.value as the actual argument of assert.deepEqual before testing its unknown type. node:assert/strict aliases this to the generic assertion signature, which narrows the first argument to the structured expected value. The real integration places row.value as the expected argument. The parent authorized swapping those arguments in a versioned fixture, then one fresh isolated compile. That retry passed. The original failed fixture and diagnostics are preserved, and the helper and actual source remain unchanged.

Corrected fixture: `tests/kia-cadillac-stage.contract.v2.test.ts`, SHA256 `306f4264462063816c7414156508ff0757b65696e4f870c8683fd7efb9baa56d`. Original failed fixture: `tests/kia-cadillac-stage.contract.test.ts`, SHA256 `6bb38d9a08290f34021b28700b9d5ea02f3d29f6cd80bb644970a71c0a920a32`. The only changed line reverses the two arguments in the positive deepEqual call. Use the corrected version if incorporating this fixture later.

os.wait4 max RSS is the platform's reported maximum for the reaped process/usage record, not a measurement of summed simultaneous memory across the entire process tree. These small checks do not establish the full-project memory outcome.

## Exact operations covered

The live integration file was read in full. Its stage operations are:

- `stage.variants.map` and `v.id` for catalogue lookup: array plus each own string id are checked
- `stage.facts.length` and iteration: array checked; the existing 2,983-fact assertion remains
- `row.variantId` and `row.key` for car/fact lookup: own strings checked
- `row.value` passed only as the expected argument of `assert.deepEqual`: own presence checked and exposed as unknown; the installed node assertion declarations accept unknown
- status, unit, comparisonBasis equality: own strings checked; no new literal/status-enum guarantee is claimed
- sourceIds whole-array equality: own dense string array checked
- qualifications iteration into `f.qualifications.includes(q)`: own dense string array checked; production qualifications are string[]
- `stage.features.length`: array checked; elements remain unknown and the existing length-zero assertion remains

The proposed patch leaves all seven existing integration test bodies and their assertions intact. The new read occurs before `catalogue()` in that file. Nothing in the proposed helper imports production modules.

The structural validator does not claim that variant IDs exist in the catalogue, fact keys resolve, counts are correct, status strings are a supported enum, or features are empty. Those semantic checks remain with the existing integration assertions. Own `value: undefined` is intentionally structurally accepted as unknown, although JSON.parse cannot produce it. Unused root/variant/fact data is outside the typed contract and must be narrowed or added to the validator before future access.

## Mutation, parity and loading

- The helper returns the same object that JSON.parse produced. It never creates a projected object, clones, sorts, filters, freezes, normalizes or writes fixture data
- `Readonly` is a compile-time restriction only. It does not freeze parsed data
- Required root fields and lookup fields must be own properties. Array iteration catches ordinary holes in variants/facts and string arrays
- The assertion helper is reviewed for plain JSON data. It is not a security boundary for arbitrary hostile objects with getters, proxies or modified array prototypes
- At the intended `tests/helpers/kia-cadillac-stage.ts`, the URL `../fixtures/catalogue/kia-cadillac-staged-delta.json` resolves to the original fixture independently of cwd. Moving the helper without the accompanying layout changes the target
- The file remains a runtime dependency. Emitting or relocating this test/helper elsewhere requires retaining the relative fixture layout; the current tsx test runner executes the source tree
- Each reader call synchronously reads and parses a fresh object; it does not preserve shared JSON-module cache identity in the general case. The actual existing integration calls it once at module scope and keeps that object and its references for every assertion, so this difference does not introduce repeated reads or identity changes during that use
- Malformed JSON/read failures propagate. Structural failures happen at the boundary rather than later in an integration assertion
- v2 strips exactly one leading U+FEFF before JSON.parse, matching the ordinary Node JSON-module behavior relevant to the existing tsx consumer. It does not trim general whitespace or embedded characters. Two leading BOMs, or whitespace before a BOM, still fail parsing; a BOM inside a JSON string is preserved. The immutable current fixture starts `7b 0a 20 20` and has no leading BOM

## Prepared evidence fixtures

- `tests/helpers/kia-cadillac-stage.ts`: byte-identical copy of the exact v2 proposal
- `tests/kia-cadillac-stage.boundary.test.ts`: positive and independent negative checks for all consumed containers and fields; own-property checks; sparse arrays; empty string arrays; unknown value payloads; frozen no-mutation and reference preservation; complete real-fixture parity including all mapping rows; byte preservation; temporary module-relative path with spaces; missing/malformed/structurally bad input; fresh objects and updated reads; single-BOM acceptance, double-BOM/whitespace-before-BOM rejection, and preservation of a BOM inside a string
- `tests/kia-cadillac-stage.contract.v2.test.ts`: passing compile-only, never-invoked function. Positive operations mirror the current consumer. Narrow @ts-expect-error checks reject hidden metadata, nested unknown value/features access, numeric qualifications, and mutation through the readonly contract. The numeric-element check is separate from readonly assignment so an error cannot pass merely because the container is readonly. The original `.contract.test.ts` is retained only as failure evidence
- `INPUT-PINS.sha256`: proposal, integration test, fixture and tsconfig pins read at review time
- `V2-INPUT-PINS.sha256`: exact v2 author helper and prepared review snapshot pins

The real fixture and installed dependencies are symlinked read-only-by-convention into the review layout. The runtime suite only reads that real fixture. All write/remove cases target a fresh child directory beneath this review directory, and are cleaned up in finally. The mirror package has no type=module, matching the source package's default package mode. There are no production imports, source/JSON edits, dependency changes, or test-runner changes.

The runtime suite compares the entire returned object with an independent JSON parse, not merely the exposed contract. This tests whole-object data parity, not shared module identity. Frozen-object validation and ordered identity checks cover every nested reference; the small metadata-rich sample additionally checks un-frozen validation does not freeze or replace values.

## Smallest proposed commands after the parent grants the serial slot

1. Bounded runtime boundary tests, no catalogue hydration:

```sh
cd /tmp/roadmark-kia-fixture-boundary-review
node --import tsx --test --test-concurrency=1 tests/kia-cadillac-stage.boundary.test.ts
```

2. Isolated contract and harness compile, no project config edits or JSON imports:

```sh
cd /tmp/roadmark-kia-fixture-boundary-review
node node_modules/typescript/bin/tsc --noEmit --strict --target ES2022 --lib ESNext --module ESNext --moduleResolution Bundler --esModuleInterop --types node tests/helpers/kia-cadillac-stage.ts tests/kia-cadillac-stage.contract.v2.test.ts tests/kia-cadillac-stage.boundary.test.ts
```

This compile intentionally checks only these three files. It is not the project typecheck and cannot clear the aggregate gate. It does not request skipLibCheck or incremental output.

3. After source-edit authorization, the exact helper/patch and approved durable boundary tests are applied, and input pins are checked: run the existing integration test using the actual supported loader, serially:

```sh
cd /workspace/scratch/586427eef9f2/roadmark-104
node --import tsx --test --test-concurrency=1 tests/kia-cadillac-integration.test.ts
```

This third command DOES load production catalogue modules and must wait for the separate parent approval/slot. It should not run against the unchanged source as evidence for the proposal.

4. The full unchanged-project `pnpm typecheck`, applicable lint and aggregate verification still need real exit/signal/resource receipts after source approval. Do not overlap source edits and final verification.

## Type-checking and memory claims

Read repository AGENTS, installed Next AGENTS, and installed Next 16.3.8 docs:

- `node_modules/next/dist/docs/01-app/03-api-reference/05-config/02-typescript.md`
- `node_modules/next/dist/docs/01-app/03-api-reference/05-config/01-next-config-js/typescript.md`
- `node_modules/next/dist/docs/01-app/03-api-reference/05-config/01-next-config-js/useTypeScriptCli.md`

These confirm the CLI checks the complete project selected by tsconfig, including tests and generated type roots; debug build path scoping does not narrow it; ignoreBuildErrors skips checking. No exclusion, skipLibCheck change, ignoreBuildErrors, or test removal is proposed. Existing tsconfig and Next roots remain authoritative for the eventual full gate.

The expected compiler-memory reduction is plausible because this removes a large directly inferred JSON source from its sole reported import path. This review did not independently repeat the broad importer/size inventory. It does not establish that memory falls enough, that the full check terminates, or that earlier SIGKILLs were OOM. The prior explicit lower-heap V8 OOM and unexplained higher-heap SIGKILL outcomes must remain separately described.

Removing the JSON from the compiler graph also removes compiler-time JSON syntax diagnostics for this fixture. The mandatory focused loader/integration tests become the place malformed fixture text is diagnosed. Whole-value comparisons remain; arbitrary unused metadata inference and future nested-value access do not silently retain their former static shape.
