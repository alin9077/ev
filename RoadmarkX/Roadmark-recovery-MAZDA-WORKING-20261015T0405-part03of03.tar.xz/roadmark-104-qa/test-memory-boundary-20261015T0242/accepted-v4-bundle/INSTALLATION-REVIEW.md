# Five-path installation proposal, version 4

Review-only. Do not apply without root's source-edit authorization and matching five-path before pins. Version 3 is retained unchanged; version 4 additionally prefixes five compile-only property accesses with void to avoid the installed no-unused-expressions warning. Their narrow @ts-expect-error checks remain directly attached to exactly the same accesses.

## Exact scope

1. Add tests/helpers/kia-cadillac-stage.ts: verified BOM-aware v2 helper, with only its proposal-only header comment removed
2. Change tests/kia-cadillac-integration.test.ts: replace the static fixture import with the helper import plus one module-scope reader call. Every original assertion and all text from the catalogue() call onward are unchanged
3. Add tests/kia-cadillac-stage.boundary.test.ts: adapt the reviewer's runtime suite. Remove its newly added historical counts (10, 2983 and zero features); retain complete-object equality, dynamic reference/serialization checks and before/after byte comparison. Use a uniquely owned mkdtemp child of os.tmpdir for all malformed-loader files. Copy/mkdir work is inside finally cleanup scope; a killed test can leave temporary files only outside the repository
4. Add tests/typechecks/kia-cadillac-stage.contract.ts: use the corrected passing contract fixture, change the relative helper import for its nested destination, and apply the five void prefixes described above. The unchanged tests/**/*.ts config includes it; the runtime tests/*.test.ts glob does not
5. Change tests/brand-added-detail.test.ts: obtain one catalogueSnapshot(), use its data and pass that same snapshot to pack. Its entire ids/render loop and all assertions are unchanged

The brand test setup is an independently reviewed test-only efficiency improvement. No claim is made that duplicate loading caused any earlier SIGKILL.

## Review artifacts

- after/: exact five proposed installed files
- before/: exact originals for the two existing files; the other three paths must be absent
- five-path-pins.json: exact before/after hashes and existence, reviewed input pins, static text-preservation guards
- installation.patch and patches/: aggregate and individual unified patches
- comment-only.diff: exact removal/rewording of proposal/review-only comments
- review-harness-adaptation.diff: tempdir/count-pin/import-path adaptations before the separate void adjustment
- compile-contract-void.diff: exact five-line compile-only lint adaptation from frozen version 3

No original fixture bytes, app code, public data loaders, configuration, test discovery rules or original integration/render assertions change. The deliberate runtime-validated boundary trade-off remains as previously reviewed: value is unknown, extra metadata remains intact but absent from the typed view, and current consumer equality assertions are preserved. The integration reads once at module scope; no broad JSON-module cache-equivalence claim is made.

Only source preparation and small exact-file metadata/text checks were performed. No proposed helper/test, compiler, lint, build, production hydration or heavy scan was run. The preceding review's passing isolated tests do not validate these newly adapted installation files. After independent review and root authorization, the installed paths still require focused runtime/contract and integration checks, applicable lint, and the unchanged full-project compiler gate. Full-project completion and memory savings remain unproven.
