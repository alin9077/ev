"""One explicitly authorized serial check; preparation alone launches nothing."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

repo = Path('/workspace/scratch/586427eef9f2/roadmark-104')
qa = Path('/workspace/scratch/586427eef9f2/roadmark-104-qa/test-memory-boundary-20261015T0242')
commands = {
    'boundary': ['node', '--import', 'tsx', '--test', '--test-concurrency=1', 'tests/kia-cadillac-stage.boundary.test.ts'],
    'contract': ['node', 'node_modules/typescript/bin/tsc', '--noEmit', '--strict', '--target', 'ES2022', '--lib', 'ESNext', '--module', 'ESNext', '--moduleResolution', 'Bundler', '--esModuleInterop', '--types', 'node', 'tests/helpers/kia-cadillac-stage.ts', 'tests/typechecks/kia-cadillac-stage.contract.ts', 'tests/kia-cadillac-stage.boundary.test.ts'],
    'snapshot': ['node', '--import', 'tsx', '--test', '--test-concurrency=1', 'tests/catalogue-snapshot.test.ts', 'tests/evidence-consumers.test.ts'],
    'market-view': ['node', 'scripts/generate-market-view.mjs', '--check'],
    'kia': ['node', '--import', 'tsx', '--test', '--test-concurrency=1', 'tests/kia-cadillac-integration.test.ts'],
    'brand-detail': ['node', '--import', 'tsx', '--test', '--test-concurrency=1', 'tests/brand-added-detail.test.ts'],
    'targeted-lint': ['pnpm', 'exec', 'eslint', 'tests/helpers/kia-cadillac-stage.ts', 'tests/kia-cadillac-integration.test.ts', 'tests/kia-cadillac-stage.boundary.test.ts', 'tests/typechecks/kia-cadillac-stage.contract.ts', 'tests/brand-added-detail.test.ts'],
    'typecheck': ['pnpm', 'typecheck'],
    'lint': ['pnpm', 'lint'],
    'lint-direct': ['node', 'node_modules/eslint/bin/eslint.js', 'src', 'tests', 'scripts'],
    'typecheck-direct': ['node', 'node_modules/typescript/bin/tsc', '--noEmit'],
}
parser = argparse.ArgumentParser()
parser.add_argument('stage', choices=commands)
parser.add_argument('--heap-mib', type=int, required=True)
parser.add_argument('--semi-space-mib', type=int, required=True)
parser.add_argument('--timeout-seconds', type=int, required=True)
parser.add_argument('--kill-grace-seconds', type=int, required=True)
args = parser.parse_args()
for number in (args.heap_mib, args.semi_space_mib, args.timeout_seconds, args.kill_grace_seconds):
    if number <= 0:
        parser.error('All resource and time bounds must be positive')
stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
target = qa / 'verification' / f'{args.stage}-{stamp}'
target.mkdir(parents=True, exist_ok=False)

def dump(name, value):
    (target / name).write_text(json.dumps(value, indent=2) + '\n')

def digest(path):
    hasher = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            hasher.update(block)
    return hasher.hexdigest()

def input_inventory():
    paths = set()
    for directory in ('src', 'scripts', 'tests', 'data', '.next/types', '.next/dev/types'):
        paths.update(path for path in (repo / directory).rglob('*') if path.is_file())
    for name in ('AGENTS.md', 'tsconfig.json', 'package.json', 'pnpm-lock.yaml', 'next-env.d.ts', 'next.config.ts', 'eslint.config.mjs', 'eslint.config.js'):
        path = repo / name
        if path.exists():
            paths.add(path)
    return {str(path.relative_to(repo)): {'bytes': path.stat().st_size, 'sha256': digest(path)} for path in sorted(paths)}

def generated_cache():
    path = repo / 'tsconfig.tsbuildinfo'
    return {'exists': False} if not path.exists() else {'exists': True, 'bytes': path.stat().st_size, 'sha256': digest(path)}

def check_installed_pins():
    manifest = json.loads((qa / 'accepted-v4-bundle/five-path-pins.json').read_text())
    applied = json.loads((qa / 'APPLIED-RECEIPT.json').read_text())
    expected = {item['path']: item['after'] for item in manifest['paths']}
    expected.update(applied['preserved_guards'])
    for name, pin in expected.items():
        path = repo / name
        if not path.exists() or path.stat().st_size != pin['bytes'] or digest(path) != pin['sha256']:
            raise RuntimeError(f'Preflight pinned source mismatch: {name}')

check_installed_pins()
before = input_inventory()
dump('inputs-before.json', before)
cache_before = generated_cache()
env = dict(os.environ)
env['NODE_OPTIONS'] = f'--max-old-space-size={args.heap_mib} --max-semi-space-size={args.semi_space_mib}'
env['TSX_DISABLE_CACHE'] = '1'
command = commands[args.stage]
dump('command.json', {
    'argv': command, 'cwd': str(repo), 'NODE_OPTIONS': env['NODE_OPTIONS'],
    'TSX_DISABLE_CACHE': '1', 'timeoutSeconds': args.timeout_seconds,
    'killGraceSeconds': args.kill_grace_seconds,
    'supervisorSha256': digest(Path(__file__)),
    'startedAt': datetime.now(timezone.utc).isoformat(),
    'inputScope': 'All src/scripts/tests/data files, existing generated type roots, and named root config/package files; excludes node_modules and generated tsbuildinfo',
    'generatedRootState': {name: (repo / name).exists() for name in ('.next/types', '.next/dev/types')},
    'tsbuildinfoBefore': cache_before,
})
start = time.monotonic()
term_at = None
kill_sent = False
observed_processes = {}
process_observation_errors = []

def observe_owned_tree(root_pid):
    pending = [root_pid]
    visited = set()
    while pending:
        pid = pending.pop()
        if pid in visited:
            continue
        visited.add(pid)
        proc = Path('/proc') / str(pid)
        try:
            children = (proc / 'task' / str(pid) / 'children').read_text().split()
            pending.extend(int(child) for child in children)
            command_line = (proc / 'cmdline').read_bytes().split(b'\0')
            arguments = [part.decode(errors='replace') for part in command_line if part]
            # Record only the requested heap environment, never unrelated environment values.
            node_options = None
            for entry in (proc / 'environ').read_bytes().split(b'\0'):
                if entry.startswith(b'NODE_OPTIONS='):
                    node_options = entry.split(b'=', 1)[1].decode(errors='replace')
                    break
            key = (pid, tuple(arguments))
            if key not in observed_processes:
                observed_processes[key] = {
                    'pid': pid, 'argv': arguments, 'NODE_OPTIONS': node_options,
                    'observedSecondsAfterLaunch': time.monotonic() - start,
                }
        except (FileNotFoundError, ProcessLookupError):
            pass
        except PermissionError as error:
            message = str(error)
            if message not in process_observation_errors:
                process_observation_errors.append(message)

with (target / 'stdout.log').open('w') as stdout, (target / 'stderr.log').open('w') as stderr:
    process = subprocess.Popen(command, cwd=repo, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
    dump('process.json', {'pid': process.pid, 'ownedPgid': process.pid})
    while True:
        observe_owned_tree(process.pid)
        waited, status, usage = os.wait4(process.pid, os.WNOHANG)
        if waited:
            break
        now = time.monotonic()
        if term_at is None and now - start >= args.timeout_seconds:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            term_at = now
        elif term_at is not None and not kill_sent and now - term_at >= args.kill_grace_seconds:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            kill_sent = True
        time.sleep(0.05)
    code = os.waitstatus_to_exitcode(status)
    process.returncode = code
execution_elapsed = time.monotonic() - start
dump('observed-process-tree.json', {
    'processes': list(observed_processes.values()),
    'observationErrors': process_observation_errors,
    'note': 'Sampled only the launched process and its children; transient children may be missed. The terminal signal below belongs to the reaped direct child, not an inferred pnpm descendant signal.',
})
after = input_inventory()
dump('inputs-after.json', after)
changed = [name for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)]
resources = {
    'source': 'os.wait4', 'maxRssKiB': usage.ru_maxrss,
    'userSeconds': usage.ru_utime, 'systemSeconds': usage.ru_stime,
    'minorFaults': usage.ru_minflt, 'majorFaults': usage.ru_majflt,
    'voluntaryContextSwitches': usage.ru_nvcsw, 'involuntaryContextSwitches': usage.ru_nivcsw,
    'note': 'wait4 usage record is not summed simultaneous peak memory of every process in the tree',
}
dump('resource.json', resources)
receipt = {
    'stage': args.stage, 'command': command, 'exitCode': code,
    'signal': -code if code < 0 else None, 'timedOut': term_at is not None,
    'killSent': kill_sent, 'elapsedSeconds': execution_elapsed,
    'maxRssKiB': usage.ru_maxrss, 'inputCount': len(before),
    'changedInputs': changed, 'receiptDirectory': str(target),
    'tsbuildinfoBefore': cache_before, 'tsbuildinfoAfter': generated_cache(),
    'endedAt': datetime.now(timezone.utc).isoformat(),
}
dump('terminal.json', receipt)
print(json.dumps(receipt, indent=2))
print('--- STDOUT ---')
print((target / 'stdout.log').read_text()[-15000:])
print('--- STDERR ---')
print((target / 'stderr.log').read_text()[-7000:])
sys.exit(0 if code == 0 and term_at is None and not changed else 1)
