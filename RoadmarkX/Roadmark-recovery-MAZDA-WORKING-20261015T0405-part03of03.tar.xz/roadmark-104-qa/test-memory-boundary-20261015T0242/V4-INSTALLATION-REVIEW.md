# Independent review of the exact v4 five-path installation bundle

## Decision

Accepted for application after the parent grants the source-edit slot. This is a static review of the exact installation files, not a claim that the newly adapted files have executed successfully. No application source edits, test execution, compiler, lint, build, or catalogue hydration occurred during this review.

- Bundle: `/tmp/roadmark-kia-fixture-boundary-proposal/v4-installation-20261015T0235`
- `installation.patch` SHA256: `f61087ccc9b363a9a0dc93bcd34d5315058a255ce5793c425757f27df212bec4`
- `five-path-pins.json` SHA256: `252fc1a2b234b4609e84d441a377fe7bb5e5488fee5e2179ced61c769c926514`
- Independent receipt: `V4-STATIC-RECEIPT.json` beside this report

All bundle content hashes verified. All five live before states matched the manifest at inspection. Independent reconstruction of the unified patch from before/after snapshots exactly matched installation.patch. Actual fixture hash remains `99e3ae7c37cb1481d75b4eadc7f01e8e7f20480c84f95d20bb4b3023eb2e90cb`.

## Five-path findings

1. `tests/helpers/kia-cadillac-stage.ts`: exact previously validated BOM-aware v2 helper, with only the proposal header comment removed. Same runtime-validated consumed contract; same complete parsed object returned; no cast/projection or compiler JSON import
2. `tests/kia-cadillac-integration.test.ts`: only direct JSON import becomes helper import plus one module-scope read. The entire original file tail from `const all = catalogue();` is byte-identical, including every original count and assertion
3. `tests/kia-cadillac-stage.boundary.test.ts`: retained positive/negative and whole-object/no-mutation/byte-parity checks. Only newly introduced historical counts were removed. Existing root mapping presence/array checks remain, and complete-object equality still covers every mapping row without pinning a new historical count. Failure cases are confined to an owned os.tmpdir mkdtemp directory; all setup after directory creation is inside try/finally. The original real fixture is only read. The new temp path is outside the project, so this exact adapted loader case still needs execution
4. `tests/typechecks/kia-cadillac-stage.contract.ts`: exact corrected passing compile fixture plus the appropriate nested helper import and five void prefixes. Each expect-error remains directly attached to its property access, so it still tests the same type prohibition. Corrected assert.deepEqual places row.value in the expected position, matching the integration. Existing tests/**/*.ts includes this file, while runtime tests/*.test.ts does not execute it
5. `tests/brand-added-detail.test.ts`: setup now calls catalogueSnapshot once, keeps that snapshot, and uses its data. The entire original `const ids = ...` through EOF is byte-identical: same brand/variant IDs, pack calls, renderer, criteria, headings, evidence-count assertions, and NaN check

No source fixture, production implementation, config, runtime test glob, existing assertion, or installed dependency changed. No additional narrowing cast or tsconfig bypass appears.

## Snapshot setup reasoning

The existing implementation at src/lib/data.ts exports catalogueSnapshot as the coherent `{ data, cars }` result of the established source/overlay pipeline. catalogue delegates to that snapshot's cars. Existing pack explicitly accepts a CatalogueSnapshot and uses its data/cars rather than fallback loaders.

Read existing tests/catalogue-snapshot.test.ts and tests/evidence-consumers.test.ts. They cover request-scoped sharing, fresh CLI snapshots, the complete guard sequence, failure propagation, standalone research-data equality, preservation of source data, and explicit snapshots avoiding fallback loaders. This supports the proposed setup's coherence. The change intentionally removes a separate standalone research() load from this rendering test; standalone API behavior remains covered in those tests. Every render assertion remains unchanged.

These facts do not establish that duplicate loading caused any SIGKILL or quantify a performance/memory improvement. Actual production-backed render tests still have to pass.

## Exact application plan, only after source-edit authorization

1. Finish and verify the parent-owned backup. Hold an exclusive source-edit slot. Capture the existing source/fixture/config pins under the parent's normal receipt process
2. Verify the exact patch/pins hashes above and `sha256sum -c BUNDLE-PINS.sha256` from the bundle. Recheck every manifest before state against the live repository: two exact existing files, three absent files. Abort on any mismatch, without force or fuzzy application
3. From `/workspace/scratch/586427eef9f2/roadmark-104`, run `git apply --check /tmp/roadmark-kia-fixture-boundary-proposal/v4-installation-20261015T0235/installation.patch`, then `git apply /tmp/roadmark-kia-fixture-boundary-proposal/v4-installation-20261015T0235/installation.patch`. Do not add to Git, commit, publish, or make opportunistic fixes
4. Verify each of the five installed after hashes/bytes against five-path-pins.json. Verify the actual fixture hash is unchanged, original Kia body and brand ids/render/assertion tail remain identical, and source/config pins outside the five paths are unchanged
5. Freeze source while verification runs. Capture command, environment/resource bounds, exit/signal, stdout/stderr, elapsed time, wait4 resources, and before/after input hashes for each stage. Use fresh receipt directories. Stop on failure; preserve evidence and get direction before a retry or additional change

## Sequential verification commands

These are commands to run later from the live repository after installation. Do not overlap them or the backup/heavy slot. Use the parent's approved resource supervisor; the first two small checks fit the previously used Node256/1 budget with 180s TERM and 10s KILL grace. The production-backed/full checks need their own parent-approved bounds; no hidden heap escalation is implied here. TSX_DISABLE_CACHE=1 may be set by the supervisor to avoid transform-cache writes.

1. Re-run the adapted runtime boundary suite:

```sh
node --import tsx --test --test-concurrency=1 tests/kia-cadillac-stage.boundary.test.ts
```

2. Re-run the exact installed helper/contract/runtime fixture compilation, independently of the full compiler gate:

```sh
node node_modules/typescript/bin/tsc --noEmit --strict --target ES2022 --lib ESNext --module ESNext --moduleResolution Bundler --esModuleInterop --types node tests/helpers/kia-cadillac-stage.ts tests/typechecks/kia-cadillac-stage.contract.ts tests/kia-cadillac-stage.boundary.test.ts
```

3. Recheck the existing snapshot and explicit-consumer contract tests, serially:

```sh
node --import tsx --test --test-concurrency=1 tests/catalogue-snapshot.test.ts tests/evidence-consumers.test.ts
```

4. Run the normal market-view preflight, then each original production-backed affected test in a separate process:

```sh
node scripts/generate-market-view.mjs --check
node --import tsx --test --test-concurrency=1 tests/kia-cadillac-integration.test.ts
node --import tsx --test --test-concurrency=1 tests/brand-added-detail.test.ts
```

5. Lint the exact five paths:

```sh
pnpm exec eslint tests/helpers/kia-cadillac-stage.ts tests/kia-cadillac-integration.test.ts tests/kia-cadillac-stage.boundary.test.ts tests/typechecks/kia-cadillac-stage.contract.ts tests/brand-added-detail.test.ts
```

6. Run the unchanged full-project compiler gate, with original tsconfig and generated roots:

```sh
pnpm typecheck
```

7. If focused checks and full-project typecheck pass, finish the applicable aggregate checks sequentially. The following full test invocation keeps the exact existing root-level runtime test discovery and preflight, changing scheduling to one test file at a time for the constrained serial slot; it does not remove tests or change package.json:

```sh
pnpm lint
node scripts/generate-market-view.mjs --check
node --import tsx --test --test-concurrency=1 tests/*.test.ts
pnpm validate
pnpm build
```

The standard build runs validation again by package design; any output/build mutations should be recorded separately from source pins. Other established project gates remain the parent's responsibility. No isolated contract pass, focused integration pass, or static review may be presented as a completed full-project typecheck or aggregate pass. Historical explicit V8 OOM and unexplained SIGKILL results remain separately described until a new complete receipt exists.
