# Final receipt: test-only fixture boundary and snapshot setup

Status: live five-path application accepted; focused behavior and full standard lint verified. Full-project TypeScript remains blocked by explicit V8 heap OOM. Heavy slot released; no further compiler runs are planned.

## Exact application

The five installed paths match accepted v4 byte-for-byte. Patch SHA256: `f61087ccc9b363a9a0dc93bcd34d5315058a255ce5793c425757f27df212bec4`. Manifest SHA256: `252fc1a2b234b4609e84d441a377fe7bb5e5488fee5e2179ced61c769c926514`.

The complete original Kia assertion body and brand-detail IDs/render/assertion tail remain byte-identical. The fixture is unchanged: `99e3ae7c37cb1481d75b4eadc7f01e8e7f20480c84f95d20bb4b3023eb2e90cb`. No production implementation or config changes were made. The frozen source backup cut excludes this later test-only patch and was not modified by this work.

## Passed

- Installed boundary suite: 20/20
- Installed isolated helper/contract/boundary compilation: exit 0, no diagnostics
- Existing snapshot and explicit-consumer suites: 43/43
- Original Kia integration: 7/7, including all 2,983 fact comparisons
- Brand-detail rendering: 1/1 with every original assertion
- Market-view preflight: verified without writing
- Full standard lint, exactly `eslint src tests scripts`: exit 0, no diagnostics

These are 71 focused runtime tests, with no failures or skips. They are not the aggregate runtime suite.

## Preserved failures and limits

- Initial `pnpm lint` failed in its dependency-status install preflight with ENOENT for `/home/agent/.local/share/pnpm`, before ESLint or TypeScript launched. The parent approved the equivalent direct installed CLI route; no package-manager settings were changed
- Full unchanged-project `tsc --noEmit`, 512 MiB old-space / 1 MiB semi-space: explicit V8 heap OOM, SIGABRT 6, 10.177s, wait4 max RSS 626,068 KiB
- Separately authorized single retry, 640 MiB old-space / 1 MiB semi-space: explicit V8 heap OOM, SIGABRT 6, 18.237s, wait4 max RSS 746,540 KiB

Both compiler attempts used the unchanged project config, including tests and existing generated roots. Neither timed out or received a supervisor kill. V8 heap budgets are not RSS ceilings. No compiler success, measured memory improvement, or cause for older unrelated SIGKILLs is claimed.

All 511 scoped source/test/script/data/config/generated-type inputs remained unchanged before/after and across the verification stages. Existing tsbuildinfo also remained unchanged. No further heap escalation, aggregate suite, validate, or build was run.

## Evidence

- `INDEPENDENT-APPLICATION-RECEIPT.json`: exact live application checks
- `VERIFICATION-STATUS.json`: complete stage results, resource bounds and cross-stage pin comparison
- `VERIFICATION-RESULTS.md`: command distinctions and detailed findings
- `verification/`: immutable per-run command/input/output/resource/terminal receipts, including the pnpm preflight failure and both OOMs

Process-tree observation through /proc could not capture descendants here; the records are empty rather than evidence that no descendants existed. Compiler signals above are from the directly reaped installed TypeScript process.
