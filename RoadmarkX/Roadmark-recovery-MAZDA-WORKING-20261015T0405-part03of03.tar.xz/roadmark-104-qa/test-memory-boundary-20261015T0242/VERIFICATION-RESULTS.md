# Live verification results: accepted v4 five-path installation

Focused validation and full standard lint passed. The full unchanged-project TypeScript check remains blocked by an explicit V8 heap OOM at both the authorized 512 MiB old-space budget and the separately authorized single 640 MiB diagnostic retry.

Every stage used one owned process group, a separately recorded 1 MiB V8 semi-space setting, and serial execution. Runtime tests explicitly used --test-concurrency=1. Heap budgets are not RSS caps. No source/config edits or automatic retries occurred. The only heap increase was a separately authorized single compiler retry from 512 to 640 MiB old-space; semi-space stayed 1 MiB.

## Results

- boundary: exit 0, signal None, 1.111s, wait4 max RSS 157,312 KiB; receipt `boundary-20261015T030234.044185Z`
- contract: exit 0, signal None, 2.317s, wait4 max RSS 171,076 KiB; receipt `contract-20261015T030241.447351Z`
- snapshot: exit 0, signal None, 4.296s, wait4 max RSS 177,808 KiB; receipt `snapshot-20261015T030257.553197Z`
- market-view: exit 0, signal None, 0.152s, wait4 max RSS 46,532 KiB; receipt `market-view-20261015T030308.804467Z`
- kia: exit 0, signal None, 11.617s, wait4 max RSS 554,956 KiB; receipt `kia-20261015T030320.519553Z`
- brand-detail: exit 0, signal None, 163.127s, wait4 max RSS 637,012 KiB; receipt `brand-detail-20261015T030345.479676Z`
- lint: exit 1, signal None, 1.564s, wait4 max RSS 107,844 KiB; receipt `lint-20261015T030647.370911Z`
- lint-direct: exit 0, signal None, 20.743s, wait4 max RSS 410,840 KiB; receipt `lint-direct-20261015T030744.415821Z`
- typecheck-direct: exit -6, signal 6, 10.177s, wait4 max RSS 626,068 KiB; receipt `typecheck-direct-20261015T030817.812003Z`
- typecheck-direct, separately authorized 640 MiB retry: exit -6, signal 6, 18.237s, wait4 max RSS 746,540 KiB; receipt `typecheck-direct-20261015T030931.105777Z`

Boundary tests: 20/20; snapshot/consumer tests: 43/43; original Kia integration: 7/7; brand-detail rendering: 1/1. The installed isolated contract compiled without diagnostics. Market-view preflight verified without writing. Standard full lint used exactly eslint src tests scripts and emitted no diagnostics.

The pnpm lint launch failed in a dependency-status install preflight with ENOENT for /home/agent/.local/share/pnpm before ESLint ran. That failed receipt is retained. The parent separately approved executing the exact installed lint/typecheck script bodies directly; no package-manager settings or dependency installation was performed to work around it.

The installed TypeScript CLI was run as node node_modules/typescript/bin/tsc --noEmit from the live repository with its unchanged tsconfig. It includes the existing tests/**/*.ts and generated type roots. .next/types exists; .next/dev/types is absent and its include remains unchanged. No excludes, skipLibCheck changes, ignoreBuildErrors, or test removals were used.

Full TypeScript failed after 10.177s with SIGABRT (6), explicit allocation-failed / JavaScript-heap-out-of-memory output, and wait4 max RSS 626,068 KiB. The supervisor did not time out or send a kill signal. This is a demonstrated V8 heap OOM for this run; it does not establish the cause of earlier SIGKILLs.

All 511 scoped source/test/script/data/config/generated-type inputs stayed unchanged before and after every stage, with no cross-stage drift. tsconfig.tsbuildinfo also stayed unchanged. The original fixture and all installed accepted after hashes remain preserved.

The separately authorized 640 MiB retry also failed with explicit V8 heap OOM/SIGABRT6, after 18.237s with max RSS 746,540 KiB and no timeout or supervisor kill. Its source and tsbuildinfo pins also remained unchanged. Both failed compiler receipts are preserved. No further heap attempt, aggregate suite, validate, or build was started. The heavy slot is released. No measured memory-improvement claim is supported by these receipts.

Process-tree observation through /proc did not capture descendants in this environment; the stored observations are empty rather than proof that no descendants existed. Terminal signals belong to the directly reaped child. The direct installed CLI route avoids reliance on pnpm-child exit propagation for the compiler result.
