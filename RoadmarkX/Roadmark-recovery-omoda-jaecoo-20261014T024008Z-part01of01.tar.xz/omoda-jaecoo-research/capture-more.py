import urllib.request, concurrent.futures,json,pathlib,hashlib,subprocess
from html.parser import HTMLParser
class Text(HTMLParser):
 def __init__(self):super().__init__();self.parts=[];self.skip=0
 def handle_starttag(self,t,a):
  if t in ['script','style','noscript']:self.skip+=1
  if t in ['p','li','h1','h2','h3','tr','td','br','div']:self.parts.append('\n')
 def handle_endtag(self,t):
  if t in ['script','style','noscript'] and self.skip:self.skip-=1
 def handle_data(self,d):
  if not self.skip:self.parts.append(d)
P=pathlib.Path('/tmp/omoda-jaecoo-research');(P/'sources').mkdir(exist_ok=True)
urls=[('vehicle-terms','https://www.omodajaecoo.com.au/legal/owners/vehicle-warranty-terms-and-conditions'),('battery-terms','https://www.omodajaecoo.com.au/legal/owners/8-yearunlimited-kilometre-high-voltage-battery-warranty-terms-and-conditions'),('roadside-terms','https://www.omodajaecoo.com.au/legal/owners/roadside-assistance-policy'),('ev-technology','https://www.omodajaecoo.com.au/ev-technology'),('carexpert-review','https://www.carexpert.com.au/car-reviews/2026-jaecoo-j5-ev-summit-review'),('racv-review','https://www.racv.com.au/royalauto/transport/electric-vehicles/2026-jaecoo-j5-ev-price-specs-release-date.html'),('zecar-review','https://zecar.com/reviews/2026-jaecoo-j5-ev-review')]
def fetch(item):
 key,u=item
 try:
  with urllib.request.urlopen(u,timeout=45) as r:b=r.read();status=r.status;ct=r.headers.get('Content-Type','');final=r.url
  ext='.pdf' if b.startswith(b'%PDF') else '.html';fn=P/'sources'/(key+ext);fn.write_bytes(b)
  if ext=='.pdf':subprocess.run(['pdftotext','-layout',str(fn),str(fn.with_suffix('.txt'))],check=True)
  else:
   h=Text();h.feed(b.decode('utf-8','replace'));txt='\n'.join(t.strip() for t in ''.join(h.parts).splitlines() if t.strip());fn.with_suffix('.txt').write_text('URL: '+u+'\nChecked: 2026-10-14\n\n'+txt)
  return {'key':key,'url':u,'resolvedUrl':final,'checkedAt':'2026-10-14','status':status,'file':str(fn.relative_to(P)),'textFile':str(fn.with_suffix('.txt').relative_to(P)),'sha256':hashlib.sha256(b).hexdigest()}
 except Exception as e:return {'key':key,'url':u,'error':str(e)}
rows=list(concurrent.futures.ThreadPoolExecutor(max_workers=6).map(fetch,urls));(P/'more-captures.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
