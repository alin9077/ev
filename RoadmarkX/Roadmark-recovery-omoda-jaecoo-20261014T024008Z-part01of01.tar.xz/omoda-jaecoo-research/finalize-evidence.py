import json,pathlib,hashlib
R=pathlib.Path('/tmp/omoda-jaecoo-research');p=R/'source-index.json';idx=json.loads(p.read_text());idx=[r for r in idx if r.get('sourceId')]
rs=json.loads((R/'reconciliation/source-index.json').read_text())
for s in rs['sources']:
 row={**s,'key':'reconciliation-'+s['id']}
 if 'bodyPath' in s:row.update(file='reconciliation/'+s['bodyPath'],textFile='reconciliation/'+s['textPath'])
 idx.append(row)
f=R/'sources/carexpert-review.web.json';t=f.with_name('carexpert-review.txt');t.write_text(json.loads(f.read_text()));idx.append({'key':'carexpert-review','url':'https://www.carexpert.com.au/car-reviews/2026-jaecoo-j5-ev-summit-review','checkedAt':'2026-10-14','file':str(f.relative_to(R)),'textFile':str(t.relative_to(R)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'textSha256':hashlib.sha256(t.read_bytes()).hexdigest(),'captureMethod':'Public web extraction','supports':'Consulted current Australian Summit review; 7.7 s and 30–80% corroboration. No folded cargo claim.','packetCitation':False})
f=R/'sources/evdb-excluded.web.json';idx.append({'key':'evdb-excluded','url':'https://evdbau.com/v/jaecoo-j5','checkedAt':'2026-10-14','error':'Public web open returned 403 Forbidden; not relied upon. Independent reviewer flagged mismatched unsourced battery/AC/tow data, so its proposed 10–80% value is not admissible.','attemptCaptureFile':str(f.relative_to(R)),'attemptCaptureSha256':hashlib.sha256(f.read_bytes()).hexdigest(),'packetCitation':False})
p.write_text(json.dumps(idx,indent=2,ensure_ascii=False)+'\n')
for row in idx:
 if 'file' in row:
  assert hashlib.sha256((R/row['file']).read_bytes()).hexdigest()==row['sha256'],row['key']
  assert hashlib.sha256((R/row['textFile']).read_bytes()).hexdigest()==row['textSha256'],row['key']
files=[]
for f in sorted(R.rglob('*')):
 if f.is_file() and f.name!='evidence-manifest.json' and '__pycache__' not in str(f):files.append({'file':str(f.relative_to(R)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
manifest={'checkedAt':'2026-10-14','scope':'Jaecoo packet and Omoda/Jaecoo-only source-bound model reconciliation','captureBodiesOutsideWorkingSource':True,'successfulIndexedBodies':sum('file' in s for s in idx),'failedIndexedAttempts':sum('file' not in s for s in idx),'files':files}
(R/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k!='files'}));print('files',len(files))
