import fs from 'node:fs';
import assert from 'node:assert/strict';
import {catalogue,research,effectiveFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/data.ts';
import {prepareBrandResearch,applyBrandUpdates,applyBrandFeatureUpdates,applyBrandTermFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-updates.ts';
import {loadReportInput} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/load.ts';
import {buildCoverageReport,isOnSale} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/reports.ts';
import {combineM1Reconciliations} from '/workspace/scratch/586427eef9f2/roadmark-104/scripts/reporting/m1-reconciliation.ts';
import {featureClaim} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/citable.ts';
import {hydratePortablePacks,storePortablePacks} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/portable-packs.ts';
const root='/tmp/omoda-jaecoo-research/';
const p=JSON.parse(fs.readFileSync(root+'jaecoo-2026-10-14.json','utf8'));
const before=JSON.parse(JSON.stringify(catalogue())),rd=JSON.parse(JSON.stringify(research()));
const original=JSON.stringify({before,rd,p});
assert.deepEqual(before.filter(c=>/omoda|jaecoo|chery/i.test(c.brand)),JSON.parse(fs.readFileSync(root+'before.json','utf8')),'before snapshot must still match current catalogue');
const data=prepareBrandResearch(rd,[p]);const cars=applyBrandUpdates(before,data,[p]);const beforeById=new Map(before.map(c=>[c.id,c]));
const features=cars.flatMap(car=>car.brand==='Jaecoo'?applyBrandTermFeatures(car,applyBrandFeatureUpdates(car,effectiveFeatures(beforeById.get(car.id)||car,data),data,[p])):effectiveFeatures(car,data));
for(const car of cars.filter(c=>c.brand==='Jaecoo')){
 const rows=features.filter(f=>f.variant_id===car.id);const pack={car,features:rows,sources:data.sources,eligibility:data.update_eligibility.find(r=>r.variant_id===car.id),events:[],configuration:[]};
 const restored=hydratePortablePacks(storePortablePacks({[car.id]:pack}),data.sources)[car.id];assert.deepEqual(JSON.parse(JSON.stringify(restored)),JSON.parse(JSON.stringify(pack)));
 for(const row of p.features.filter((f:any)=>f.variantId===car.id)){
  assert.deepEqual(rows.find(f=>f.criterion===row.criterion),row.after);const claim=featureClaim(restored,row.criterion,row.criterion)!;assert.equal(claim.value,row.after.value);assert.equal(claim.gradeReview?.overlayId,p.id);assert.equal(claim.gradeReviewStatus,undefined);assert.deepEqual(claim.sources.map(s=>s.id),row.after.source_ids);
 }
 assert.equal(car.facts.price_aud.value,35990);assert.equal(car.facts.price_aud.priceEvidence.rung,1);assert.equal(car.facts.price_aud.comparisonBasis,'Before on-road costs');assert.equal(car.facts.promotional_driveaway_aud.value,36990);assert.equal(car.facts.promotional_driveaway_aud.comparisonBasis,'Driveaway');
 assert.equal(car.facts.dc_charge_time_min.value,null);assert.equal(car.facts.dc_charge_time_min.buyerGrade,'not_published');assert.equal(car.facts.dc_charge_30_80_min.value,28);assert.equal(car.facts.boot_l.value,384);assert.equal(car.facts.boot_to_roof_l.value,480);assert.equal(car.facts.max_total_cargo_l.value,1180);assert.equal(car.facts.ac_kw.value,10.3);assert.equal(car.facts.ac_single_phase_kw.value,6.6);assert.equal(car.facts.warranty.buyerGrade,'confirmed');assert.equal(car.facts.battery_warranty.buyerGrade,'confirmed');assert.equal(car.facts.drive.buyerGrade,'confirmed');assert.equal(isOnSale(car),true);
 assert.doesNotMatch(rows.find(f=>f.criterion==='home_charging')!.value,/hours|About/);assert.doesNotMatch(rows.find(f=>f.criterion==='energy_use')!.value,/14\.8|665/);assert.equal(car.availabilityEvidence.physicalStockVerified,false);
 const offer=rows.find(f=>f.criterion==='driveaway_price')!;assert.equal(offer.value,'A$36,990');assert.equal(offer.buyerGrade,'check');assert.deepEqual(offer.source_ids,car.facts.promotional_driveaway_aud.sourceIds);assert.equal(offer.gradeReview?.overlayId,p.id);assert.match(offer.conditions,/2026-10-31/);assert.match(offer.conditions,/participating dealers/);assert.match(offer.conditions,/metallic paint or options/);
}
fs.writeFileSync(root+'after.json',JSON.stringify(cars.filter(c=>c.brand==='Jaecoo'),null,2));fs.writeFileSync(root+'features-after.json',JSON.stringify(features.filter(c=>c.variant_id.startsWith('jaecoo_')),null,2));assert.equal(JSON.stringify({before,rd,p}),original,'staging preserves original inputs');
if(fs.existsSync(root+'jaecoo-reconciliation-2026-10-14.json')){
 const r=JSON.parse(fs.readFileSync(root+'jaecoo-reconciliation-2026-10-14.json','utf8'));const input=loadReportInput();input.cars=cars;input.sources=data.sources;input.features=features;input.m1Reconciliation=combineM1Reconciliations(input.m1Reconciliation!,r);const report=buildCoverageReport(input,'2026-10-14');fs.writeFileSync(root+'staged-report.json',JSON.stringify(report,null,2));const brand=report.brandProgress.find(x=>x.brand==='Jaecoo')!;
 console.log(JSON.stringify({researchCompleted:brand.researchCompleted,researchRemaining:brand.researchRemaining,onSaleVersions:brand.onSaleVersions,core:brand.core.map(x=>({key:x.key,grades:x.grades})),currentBodies:brand.currentVersionReviews.map(x=>({model:x.model,versions:x.versions.length})),gaps:report.gaps.filter(x=>x.brand==='Jaecoo'),closureIssues:brand.closureIssues,criteria:brand.criteria,features:p.features.length},null,2));
 assert.ok(brand.researchCompleted,JSON.stringify(brand.researchRemaining));assert.equal(brand.missingModels,0);assert.equal(brand.unresolvedLeads,0);assert.equal(brand.missingSummaries,0);assert.equal(brand.agedOrInvalidClaims,0);
}
console.log('PASS: exact current guards, feature chains/dependencies, citable/portable propagation, immutable inputs. Global C1-C6 remain separate.');
