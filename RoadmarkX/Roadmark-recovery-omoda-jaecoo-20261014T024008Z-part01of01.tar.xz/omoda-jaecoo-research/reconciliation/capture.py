import concurrent.futures, urllib.request, urllib.error, hashlib, json, re, pathlib, datetime
from html.parser import HTMLParser
BASE=pathlib.Path('/tmp/omoda-jaecoo-research/reconciliation');(BASE/'sources').mkdir(exist_ok=True)
SOURCES=[
('official-home','https://www.omodajaecoo.com.au/','Omoda Jaecoo Australia','official AU complete model navigation'),
('official-build','https://www.omodajaecoo.com.au/build','Omoda Jaecoo Australia','official AU build model selection'),
('official-j5-ev','https://www.omodajaecoo.com.au/models/jaecoo-j5-bev','Omoda Jaecoo Australia','official AU sole J5 EV Summit grade'),
('official-j5-spec','https://www.omodajaecoo.com.au/sites/default/files/2026-05/Spec25_Jaecoo_J5_Spec_Sheet_AU_BEV_v101_compressed_compressed.pdf','Omoda Jaecoo Australia','official MY26 J5 EV specification identity'),
('official-future-omoda4-7','https://www.omodajaecoo.com.au/campaigns/omoda4-omoda7','Omoda Jaecoo Australia','future Omoda 4 and 7, register interest'),
('official-j7','https://www.omodajaecoo.com.au/models/jaecoo-j7','Omoda Jaecoo Australia','J7 petrol exclusion'),
('official-j7-shs','https://www.omodajaecoo.com.au/models/jaecoo-j7-shs','Omoda Jaecoo Australia','J7 SHS-P plug-in hybrid exclusion'),
('official-j8-shs','https://www.omodajaecoo.com.au/models/jaecoo-j8-shs','Omoda Jaecoo Australia','J8 SHS-P plug-in hybrid exclusion'),
('official-omoda9','https://www.omodajaecoo.com.au/models/omoda-9','Omoda Jaecoo Australia','Omoda 9 SHS-P plug-in hybrid exclusion'),
('carexpert-brand-list','https://www.carexpert.com.au/omoda-jaecoo','CarExpert','independent current Australian combined brand model list'),
('carsguide-jaecoo-list','https://www.carsguide.com.au/jaecoo','CarsGuide','independent current Australian Jaecoo model list'),
('carsguide-omoda-list','https://www.carsguide.com.au/omoda','CarsGuide','independent current Australian Omoda model list, plus older-model index'),
('carexpert-legacy-omoda-list','https://www.carexpert.com.au/omoda','CarExpert','legacy standalone Omoda list, not independent of combined CarExpert list'),
('carexpert-j5','https://www.carexpert.com.au/omoda-jaecoo/jaecoo-j5','CarExpert','published J5 name and version cross-check'),
('carsguide-j5','https://www.carsguide.com.au/jaecoo/j5','CarsGuide','published J5 name and version cross-check'),
('carexpert-future-omoda4-7','https://www.carexpert.com.au/car-news/chery-australia-confirms-omoda-4-and-omoda-7-suvs-to-take-on-hyundai-kona-toyota-rav4','CarExpert','future Australian Omoda 4 and 7 timing and hybrid exclusion'),
('chery-original-omoda-e5','https://cherymotor.com.au/news/chery-reveals-specs-all-electric-omoda-e5','Chery Australia','historical Chery Omoda E5 identity only; not a current Omoda-brand entry'),
('chery-current-e5-identity','https://cherymotor.com.au/models/chery-e5-electric-suv','Chery Australia','current Chery E5 identity only, outside Omoda Jaecoo research scope'),
('carsales-e5-rename','https://www.carsales.com.au/editorial/details/sharper-pricing-and-new-name-for-2025-chery-e5-149472/','Carsales','historical E5 rename provenance only'),
('chery-bunbury-maker-rename','https://www.cherybunbury.com.au/news/chery-introduces-the-updated-c5-model','Chery Bunbury / Chery Australia syndicated release','maker-authored release republished by dealer, E5 rename provenance only'),
]
class Extract(HTMLParser):
 def __init__(self):super().__init__();self.ignore=0;self.out=[];self.title=False;self.titleout=[]
 def handle_starttag(self,t,a):
  if t in ('script','style'):self.ignore+=1
  if t=='title':self.title=True
  if t in ('p','div','h1','h2','h3','h4','li','tr','br','section'):self.out.append('\n')
 def handle_endtag(self,t):
  if t in ('script','style'):self.ignore=max(0,self.ignore-1)
  if t=='title':self.title=False
  if t in ('p','div','h1','h2','h3','h4','li','tr','section'):self.out.append('\n')
 def handle_data(self,d):
  if not self.ignore:self.out.append(d)
  if self.title:self.titleout.append(d)
def one(s):
 id,u,purposepub,purpose=s
 meta=dict(id=id,url=u,publisher=purposepub,purpose=purpose,checkedAt='2026-10-14',captureMethod='urllib HTTP GET',capturedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
 try:
  with urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=45) as r:b=r.read();meta.update(httpStatus=r.status,finalUrl=r.url,contentType=r.headers.get('content-type'),httpLastModified=r.headers.get('last-modified'))
  suffix='pdf' if b.startswith(b'%PDF') else 'html'
  f=BASE/'sources'/f'{id}.{suffix}';f.write_bytes(b)
  meta.update(bodyPath=str(f.relative_to(BASE)),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
  if suffix=='html':
   e=Extract();e.feed(b.decode('utf-8',errors='replace'));txt='\n'.join(' '.join(x.split()) for x in ''.join(e.out).splitlines() if x.strip());tf=f.with_suffix('.txt');tf.write_text(txt);meta['textPath']=str(tf.relative_to(BASE));meta['title']=' '.join(e.titleout)
  else:meta['title']='JAECOO J5 EV Specification Sheet, Model Year 2026'
 except Exception as e:meta.update(error=str(e))
 return meta
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:results=list(ex.map(one,SOURCES))
(BASE/'source-index.json').write_text(json.dumps(dict(checkedAt='2026-10-14',sources=results),indent=2)+'\n')
for r in results:print(r['id'],r.get('httpStatus',r.get('error')),r.get('bytes',0))
