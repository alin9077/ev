# Omoda / Jaecoo Australian BEV identity reconciliation

Checked 14 October 2026. Research only. No repository, catalogue, registry, source-record, or deployment change was made.

## Result

- The complete current Australian maker range establishes one BEV family and one exact grade: Jaecoo J5 EV, EV Summit, MY26. Reuse `jaecoo_j5_ev__ev_summit__1` / `jaecoo_j5_ev`; no version addition or identity rename is needed.
- The official navigation calls the grade Summit, and the exact model page calls it Jaecoo J5 EV Summit. These are the same BEV grade. Preserve the existing catalogue trim EV Summit; do not treat shared petrol/hybrid Summit badges as aliases to the BEV.
- No current Australian Omoda-badged BEV was found in the complete official range. The historically named Omoda E5 was a Chery offering. Current Chery E5 remains a separate Chery catalogue identity and was read only to settle that boundary.
- The canonical inventory contains zero Omoda/Jaecoo audit records and zero Omoda/Jaecoo unverified leads. J5 EV appears in `existingFamiliesExcluded` because it was already catalogued. A string in that array is not an inventory record ID; do not invent an inventory resolution.

Official evidence: [complete maker range](https://www.omodajaecoo.com.au/), [build selection](https://www.omodajaecoo.com.au/build), [J5 EV grade](https://www.omodajaecoo.com.au/models/jaecoo-j5-bev), [linked MY26 specification sheet](https://www.omodajaecoo.com.au/sites/default/files/2026-05/Spec25_Jaecoo_J5_Spec_Sheet_AU_BEV_v101_compressed_compressed.pdf)

## Independent published lists and every difference

Two independent publisher/data families were checked. CarExpert’s model specification page credits JATO Dynamics; CarsGuide credits Glass’s Information Services. The two CarsGuide brand pages are complementary parts of one publisher’s list, not independent of one another.

1. [CarExpert Omoda Jaecoo](https://www.carexpert.com.au/omoda-jaecoo): J5, J7, J8, Omoda 9
2. [CarsGuide Jaecoo](https://www.carsguide.com.au/jaecoo): J5, J7, J8; [CarsGuide Omoda](https://www.carsguide.com.au/omoda): Omoda 9. That Omoda page also has older-model links for 4, 7 and 9; these extras were checked and retained in the transcription

Every current list entry has a disposition:

- J5 includes the catalogued BEV branch; petrol Track/Summit and SHS-H Summit are excluded as non-BEVs
- J7 is petrol or SHS-P plug-in hybrid. The Black Edition is also marked coming soon, and remains a non-BEV
- J8’s listed family covers petrol/hybrid history; the current maker range reviewed shows SHS-P, with no BEV branch
- Omoda 9 is SHS-P, a plug-in hybrid
- CarsGuide’s older-index 9 is another spelling of the already-listed Omoda 9; it creates no additional BEV
- Omoda 4 and 7 are future AU interest-register entries, not current orderable exact BEV grades. Do not label Omoda 4 simply “hybrid”: an overseas BEV exists. [September 2026 reporting](https://www.carexpert.com.au/car-news/chery-australia-confirms-omoda-4-and-omoda-7-suvs-to-take-on-hyundai-kona-toyota-rav4) places Australian launch in 2027 and says local powertrains remain unconfirmed; the [current maker campaign](https://www.omodajaecoo.com.au/campaigns/omoda4-omoda7) still asks for expressions of interest

No current catalogue BEV is absent from either independent list family. Published “J5” is an explicitly scoped family-name alias for the BEV subset, not a reason to rename J5 EV or merge powertrains.

## Other candidates and identity traps

- J6: absent from the current full maker range/build list and both independent current lists. [Dated Australian reporting](https://www.carexpert.com.au/car-news/all-the-new-suvs-coming-to-australia-from-chery-and-omoda-jaecoo-in-2025) quotes Chery saying J6 was not slated locally. A [Carlyst database candidate](https://carlyst.com.au/browse/jaecoo-j6) has zero-price/range placeholders and does not establish an official new Australian retail offer
- Omoda E5 / 5 EV overseas: the [UK range](https://omodaauto.co.uk/models/) is explicitly a foreign offer. It is not a new Australian Omoda record
- Chery Omoda E5: [Chery’s historical announcement](https://cherymotor.com.au/news/chery-reveals-specs-all-electric-omoda-e5), a [maker-authored rename release syndicated by an authorised dealer](https://www.cherybunbury.com.au/news/chery-introduces-the-updated-c5-model), [Carsales rename reporting](https://www.carsales.com.au/editorial/details/sharper-pricing-and-new-name-for-2025-chery-e5-149472/), and the [current Chery product identity](https://cherymotor.com.au/models/chery-e5-electric-suv) settle this brand boundary. No Chery completeness or residual-stock conclusion was made
- CarsGuide’s J5 page contains 2025 and 2027 electric-year guide rows, while CarExpert’s family page groups Track/Summit across powertrains. These database groupings do not establish another exact Australian BEV grade. The current official linked brochure explicitly says Model Year 2026
- A web cache returned the old standalone CarExpert Omoda page, but its direct current HTTP request returned 404. The live combined page is used; the stale page is neither current nor independent

## Historical inventory and stock

The old `omoda-jaecoo-evidence.json` has one existing Jaecoo J5 record and three Chery records. Its Chery BX/EX/MY25.5/MY27 records and exclusions remain a separate Chery concern, not unresolved Omoda/Jaecoo leads. The inherited canonical `chery-e5` record is likewise outside this pass.

Two J5 advertisements in the 10 October evidence are historical observations, not freshly verified stock. A new dated availability update should supersede the previous observation with the current maker’s order-request evidence and stock unverified, while retaining all historical sources unchanged. This identity review makes no physical-stock assertion.

## Reporting format constraint

The existing `PublishedModelList` type only accepts whole-market `australian-new-tier1-bevs` scope, and requires a publication date. These sources are honest brand-only, mixed-powertrain lists; CarsGuide displays no list publication date. The companion reporting-compatible recommendation therefore includes the exact current version review and explanatory notes, with `publishedLists`, `listResolutions`, `catalogueOnlyDifferences`, and `inventoryResolutions` empty. It does not falsely pass whole-market C1. Full source-bound brand-list transcriptions and all dispositions remain in `brand-model-reconciliation.json`.

## Files and verification

- `m1-omoda-jaecoo-market-reconciliation-2026-10-14.recommendation.json`: compatible proposed reconciliation payload; not registered
- `brand-model-reconciliation.json`: complete brand-list snapshots, resolved identities, every exclusion and discrepancy, and official trim alias
- `inherited-inventory-audit.json`: exact inspected inputs with hashes, matching inherited rows, and dispositions
- `source-index.json`: URL, check date, publisher, purpose, title, raw-body path/hash, extracted-text path/hash, and HTTP result for each source
- `sources/`: 25 complete retained HTML/PDF bodies and extracted text; the legacy CarExpert Omoda 404 is recorded as a failed fetch

All retained source-body hashes were verified. All deliverable JSON parses. No source files or catalogue identities were changed. Price, core facts, shared terms, and the new availability fact update are handled separately by the parent J5 research packet.
