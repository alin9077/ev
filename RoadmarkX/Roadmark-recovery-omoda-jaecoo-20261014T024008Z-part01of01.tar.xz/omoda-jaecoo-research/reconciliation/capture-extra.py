import concurrent.futures, json, pathlib
# Load capture helpers without re-fetching the original batch.
p=pathlib.Path('/tmp/omoda-jaecoo-research/reconciliation/capture.py');ns={};exec(p.read_text().split('with concurrent.futures.ThreadPoolExecutor')[0],ns)
more=[
('carexpert-j6-not-slated','https://www.carexpert.com.au/car-news/all-the-new-suvs-coming-to-australia-from-chery-and-omoda-jaecoo-in-2025','CarExpert','historical explicit Australia exclusion for J6; current omission corroborated by AU maker list'),
('carlyst-j6-false-positive','https://carlyst.com.au/browse/jaecoo-j6','Carlyst','J6 candidate discrepancy: database entry is not evidence of official new AU supply'),
('official-uk-omoda-e5','https://omodaauto.co.uk/models/','Omoda UK','non-Australian Omoda E5 / 5 EV exclusion; never transplant UK Knight/Noble grades'),
('carsguide-omoda4','https://www.carsguide.com.au/omoda/4','CarsGuide','older-model index extra, future model with no current Australian grade'),
('carsguide-omoda7','https://www.carsguide.com.au/omoda/7','CarsGuide','older-model index extra, future model with no current Australian grade'),
('carsguide-omoda9-alias','https://www.carsguide.com.au/omoda/9','CarsGuide','older-model index 9 alias compared with current Omoda 9, no extra BEV'),
]
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:r=list(ex.map(ns['one'],more))
p=ns['BASE']/'source-index.json';d=json.loads(p.read_text());d['sources']+=r
for item in d['sources']:item.pop('capturedAt',None)
for item in d['sources']:
 if item['id']=='official-j5-spec':item['textPath']='sources/official-j5-spec.txt'
p.write_text(json.dumps(d,indent=2)+'\n')
for i in r:print(i['id'],i.get('httpStatus',i.get('error')),i.get('bytes',0))
