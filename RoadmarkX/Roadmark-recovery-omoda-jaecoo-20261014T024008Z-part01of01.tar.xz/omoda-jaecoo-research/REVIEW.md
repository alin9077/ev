# Jaecoo M1 review, 14 October 2026

## Result for a buyer

- One current Australian Omoda/Jaecoo-group BEV is established: existing Jaecoo J5 EV EV Summit MY26. No new physical versions or cross-brand renames are introduced.
- Price is A$35,990 maker RRP before registration, CTP, stamp duty and dealer delivery. The maker publishes it in the novated-lease offer terms; the restricted 10% discount is not applied. Separate A$36,990 national driveaway offer is retained with new-stock, participating-dealer, no-paint/options and 1–31 October eligibility.
- Of 17 required core fields, 15 are Confirmed, 0–100 km/h is Reported (7.7 s from RACV), and DC 10–80% time is Not published after two genuine sources. The maker's 28-minute measurement is only 30–80% and stays separately visible. No conversion or estimate fills the gap.
- Boot measurements are distinct: maker VDA 384 L to cover and 480 L to roof; front storage 35 L and folded cargo 1,180 L are independently checked Reported figures. WhichCar currently supports 1,180 L; Zecar's current page does not, so the evidence chain uses WhichCar.
- Five guarded equipment rows correct home charging, energy use, storage, motor layout and battery chemistry. Unsupported capacity/rate charging-time estimates and derived annual electricity cost are removed. Current maker data gives 6.6 kW single-phase / 10.3 kW three-phase, 155 kW FWD, LFP and a 143 Wh/km Australian calculator input with no asserted test basis.

## Files and exact scope

- Packet: `jaecoo-2026-10-14.json`, exact canonical brand `Jaecoo`
- Reporting overlay: `jaecoo-reconciliation-2026-10-14.json`
- Full brand-only published list transcription: `brand-model-list-reconciliation.json` and `reconciliation/REVIEW.md`
- Original effective guards: `before.json`, `features-before.json`, `research-before.json`; these are not regenerated after registration
- `source-index.json` maps every successful capture or failed attempt. `evidence-manifest.json` hashes capture bodies and staged deliverables. Bodies remain outside working source; the packet contains concise facts and citations
- 28 version-specific fact updates, three shared brand terms, one availability correction, one strength/trade-off pair, five feature replacements; no models/variants/version identity changes

## Identity and version closure

CarExpert's combined Omoda Jaecoo list and CarsGuide's separate Jaecoo/Omoda lists are independent publisher/data families (JATO versus Glass's). All listed models are transcribed and reconciled against current maker navigation, build selection and the MY26 sheet. These brand-only mixed-powertrain lists are not whole-market BEV lists, so they are not inserted into the reporting schema's `australian-new-tier1-bevs` list slot. Global C1 stays open.

Omoda 9 SHS-P and Jaecoo petrol/SHS-H/SHS-P variants are excluded from BEV scope. Omoda 4/7 are future interest-only local introductions with unconfirmed AU powertrains, not current orderable BEV grades. Omoda 4's overseas BEV is not mislabeled a hybrid. J6 is not verified in the current official AU range. Chery Omoda E5 is a historical Chery name; the existing Chery E5 remains untouched for its own brand pass. UK Omoda EV names do not justify Australian duplicates. The importer only accepts an exact canonical brand in a packet, so no synthetic group-branded packet is created.

There are no canonical inherited Omoda/Jaecoo inventory records or unresolved leads. J5 is an existing-family exclusion string because already catalogued. Prior NEW dealer advertisements are historical evidence, superseded here by current maker quote/order-request evidence with physical stock and factory acceptance still unverified.

## Policy scope and genuine limitations

Vehicle and traction-battery warranties are Confirmed for the private-buyer baseline: eight years/unlimited km. Vehicle terms explicitly apply eight years/150,000 km to commercial use and state that high-voltage batteries carry the same terms. Battery cover includes the published below-70% capacity threshold and prescribed remedy. The original 12 V battery has a two-year exception. Demonstrators retain original remaining cover. Ordinary warranty maintenance/exclusion terms do not blanket-downgrade these facts.

Roadside is one year included, renewed by each scheduled authorised capped-price service to eight years. The service-renewal requirement and named geographic exclusions are stated explicitly. All known Jaecoo Tier 1 versions are covered by the single brand record; no version-specific policy exception is invented.

DC 10–80% and AC charge duration are genuine two-source gaps. The 30–80% claim is not rescaled, and battery capacity divided by charger power is not used. An unsourced EVDB result flagged during independent review is inconsistent with the current maker battery/AC/tow specification; our direct web open returned 403, and the packet does not rely on it.

The RRP price is the highest permitted rung. Root extended the canonical projection to accept a fully reviewed supplemental `promotional_driveaway_aud` fact while retaining RRP as the primary price. Independent replay confirms the A$36,990 equipment row now carries its fresh offers source, Check grade, exact October eligibility and expiry. No manual driveaway feature replacement is added.

## Verification

`validate-stage.ts` replays only the proposed Jaecoo packet on the current effective catalogue/research, preserves original inputs, validates all guards and dependency chains, checks citable values and portable round trips, and produces `staged-report.json`. Research completion is true with no outstanding family/lead/summary/freshness work. Strict C1/C2/C5 remain false; C3/C4/C6 pass. C2 and charging rankings remain limited by the unavailable 10–80% duration.

Focused brand and feature tests passed (23 in this research stage, then root reported 25/25 after the supplemental-offer projection extension), and direct TypeScript no-emit checking passed. Full builds and full tests were intentionally not run in this research stage. Registration and final integration are root-owned and await independent approval.
