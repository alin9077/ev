# Roadmark working safety recovery — unverified loader / research-only Subaru

Working safety cut, 14 October 2026 UTC. This is not a passed Subaru integration or release checkpoint. The final accompanying index and manifest record the archive, privacy and restoration verification separately from the unfinished application checks.

## Choose the recovery state deliberately

- **Last passed integrated recovery: Polestar.** Keep its separate source, index and manifest. That recovery verified 70 archives and 6,198 restored files. Its source passed 171 focused integration tests, validation, full typecheck and changed-file lint. The fresh report explicitly dated 2026-10-14 matched the staged report; the distinct current-day report was dated 15 October in Australia/Sydney. It did not establish a complete aggregate test/build/mobile/publication pass.
- **This working source: catalogue loader v2.** The request-scoped snapshot-sharing changes have 25 focused tests and independent static review. Complete fresh real-data equality and the full typecheck are still unverified. Failed captures, typecheck attempts, resource measurements and historical scripts remain evidence, not successful checks. Signal 9 alone does not establish its cause. No production performance claim is made.
- **Subaru: research only, unintegrated.** Proposed current and advertised-new residual configurations, citations, normalized evidence and terms are retained. No Subaru packet is registered and no canonical fixture or independent staged/root integration approval exists. The unresolved older Solterra and MY26 Uncharted census questions remain open. M1 remains open.

## What this working copy is intended to preserve

The source state at the eventual freeze; original/v1/v2 loader code and patches; exact source/input manifests; focused and static results; failed and successful terminal/resource receipts; proof and replay scripts; unique partial outputs; the explicitly allowlisted Subaru research files; and a self-contained recovery index linking the unchanged Polestar chain.

An export may be represented by a reconstruction mapping only after exact bytes or an exact prefix have been independently checked against a retained authoritative file. An interrupted export is never upgraded to a completed run merely because some rows can be reconstructed. No local originals are deleted. Privacy and provenance exclusions are recorded explicitly; browser screenshots are excluded.

## Resume work

1. Restore and verify the chosen index/manifest first. Use Polestar when a last-passed source state is needed; select this separately labelled working state only to continue the unfinished loader/Subaru work.
2. Review `QA/catalogue-snapshot-reuse/independent-v2-static-review.json`, the current terminal receipts, `digest-backed-proof-plan.md`, and Subaru's retained readiness/README. Historical status files keep their original timestamps and may describe earlier attempts.
3. Under one explicitly scheduled heavy process, finish fresh cars/research capture and the independent, complete digest-backed oracle comparison. Require all 397 cars, all 14 research fields, full input/harness hashes, complete row/aggregate hashes and terminal success. A successful digest capture by itself is not full equality. Preserve the original pre-Polestar snapshot and exact final Polestar packet as the independent lineage.
4. Finish the full current typecheck and appropriate validation/regression checks. The documented project commands are `pnpm typecheck`, `pnpm validate`, `pnpm report:coverage --as-of 2026-10-15`, and `pnpm lint`; inspect the retained measured runners and project argument conventions before execution. Do not infer a pass from a missing terminal receipt or launch overlapping catalogue jobs. The full aggregate `pnpm test`, `pnpm build`, and mobile/browser QA are separate pending claims.
5. Only after the baseline and loader are independently approved, create the Subaru canonical fixture, stage the candidate, run independent replay, register only the approved bytes, complete root checks and make a new final integrated recovery. Keep the explicit Sydney date 2026-10-15; never normalize away the earlier Polestar date distinction.

## Backup verification is separate from application verification

A later clean privacy scan, exact archive restoration and successful Library save prove preservation of this working state. They do not establish loader correctness, full typechecking, Subaru integration, build success, mobile QA or strict research completion.

## Exact reconstructible partial exports

Three interrupted car exports are stored as exact prefix reconstruction mappings to retained `QA/catalogue-snapshot-reuse/after448/cars.jsonl`: 31,203,073; 41,614,064; and 45,547,876 bytes. Independent byte-for-byte proof checked original and prefix hashes, unchanged file identities and exact lengths. The 65,021,562-byte source is retained in full. All failed-run logs, settings and receipts remain. To optionally reconstruct each omitted export after normal restore, run `independent_reconstruct_prefix.py` beside `INDEPENDENT-PREFIX-RECONSTRUCTION-PROOF.json`, with `--restore-root` pointing to the restored parent and `--candidate` naming the mapping entry. The helper refuses overwriting existing files. These three optional reconstructed copies are outside the manifest normal restored-file count. Nothing is deleted locally.

The latest reusable-buffer attempt ended with signal 9 after 53.866 seconds, peak RSS 572,696 KiB, no terminal index, and all 515 input/harness pins unchanged. Earlier partial export and digest attempts remain distinct. A standalone encoding/hash equivalence check passed on 397 stored rows and 25 fixtures; that is not fresh full-data equality.
