#!/usr/bin/env python3
"""Bounded exact-prefix proof. Reads four approved files; writes checkpoint receipts only."""
import contextlib,datetime,hashlib,json,os,pathlib,resource,stat,sys,time,traceback
C=pathlib.Path(__file__).resolve().parent
Q=C.parents[2]/'roadmark-104-qa/catalogue-snapshot-reuse'
BASE='after448/cars.jsonl'
CANDIDATES=['v2-fresh-cars/cars.jsonl','v2-fresh-cars-gc50/cars.jsonl','v2-fresh-cars-gc50-416/cars.jsonl']
CHUNK=1024*1024
START=time.monotonic()
R={'result':'IN_PROGRESS','scope':'Exact stored-byte prefix reconstruction only; not run completion, parsed row equality, complete fresh data equality, loader correctness, or typecheck','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceRoot':str(Q),'chunkBytes':CHUNK,'parallelWorkers':0,'originalsModifiedOrDeleted':False}
def check(v,msg):
 if not v:raise AssertionError(msg)
def stats(p):
 s=p.lstat();check(stat.S_ISREG(s.st_mode),'Nonregular or symlink input '+str(p))
 return {'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns,'inode':s.st_ino,'device':s.st_dev}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(CHUNK),b''):h.update(b)
 return h.hexdigest()
def main():
 names=[BASE]+CANDIDATES;before={n:stats(Q/n) for n in names};hashes={n:hashlib.sha256() for n in names};lengths={n:0 for n in names};newlines={n:0 for n in names};last={n:None for n in names};mismatch={n:None for n in CANDIDATES};baseprefix={n:hashlib.sha256() for n in CANDIDATES};offset=0
 with contextlib.ExitStack() as stack:
  fs={n:stack.enter_context((Q/n).open('rb')) for n in names}
  while True:
   chunks={n:f.read(CHUNK) for n,f in fs.items()}
   if not any(chunks.values()):break
   b=chunks[BASE]
   for n,data in chunks.items():
    hashes[n].update(data);lengths[n]+=len(data);newlines[n]+=data.count(b'\n')
    if data:last[n]=data[-1]
   for n in CANDIDATES:
    v=chunks[n];prefix=b[:len(v)];baseprefix[n].update(prefix)
    if v!=prefix and mismatch[n] is None:
     mismatch[n]=offset+next((i for i,(x,y) in enumerate(zip(v,prefix)) if x!=y),min(len(v),len(prefix)))
   offset+=len(b)
 after={n:stats(Q/n) for n in names};stable=before==after
 original={n:{'path':n,'bytes':lengths[n],'sha256':hashes[n].hexdigest(),'newlineBytes':newlines[n],'endsWithNewline':last[n]==10,'statBefore':before[n],'statAfter':after[n],'statStable':before[n]==after[n]} for n in names}
 check(all(lengths[n]==before[n]['bytes'] for n in names),'Read size differs from initial stat')
 R['inputs']=original;R['allInputsStatStable']=stable;R['sourceFile']={**original[BASE],'restorePath':'roadmark-104-qa/catalogue-snapshot-reuse/'+BASE}
 mappings=[]
 for n in CANDIDATES:
  exact=mismatch[n] is None and lengths[n]<=lengths[BASE] and baseprefix[n].hexdigest()==hashes[n].hexdigest() and stable
  row={**original[n],'restorePath':'roadmark-104-qa/catalogue-snapshot-reuse/'+n,'exactPrefix':exact,'firstDifferentByteOffset':mismatch[n],'retainedSourcePrefixSHA256':baseprefix[n].hexdigest(),'reconstructable':exact,'omissionAuthorizedByProof':exact,'sourceByteOffset':0,'reconstructionBytes':lengths[n],'runCompletionEstablished':False,'realDataEqualityEstablished':False}
  if exact:
   row['reconstructCommand']="python3 independent_reconstruct_prefix.py --mapping INDEPENDENT-PREFIX-RECONSTRUCTION-PROOF.json --restore-root /absolute/path/to/restored-tree --candidate '"+n+"'"
  mappings.append(row)
 R['mappings']=mappings
 inv=json.loads((C/'LOADER-QA-PROPOSED-INVENTORY.json').read_text());records=inv['files'];lookup={r['path']:r for r in records};potential=[]
 for r in records:
  if '/research-' in r['path'] and not r['path'].startswith('after448/'):
   ref='after448/'+pathlib.PurePosixPath(r['path']).name
   if ref in lookup:
    potential.append({'path':r['path'],'bytes':r['bytes'],'candidateReference':ref,'referenceBytes':lookup[ref]['bytes'],'sameLength':r['bytes']==lookup[ref]['bytes'],'contentRead':False,'exactDuplicateOrPrefixEstablished':False,'mayOmit':False})
 R['researchPartialsMetadataOnlyInventory']=potential
 R['terminalEvidenceRequiredUnchanged']=[{'path':r['path'],'bytes':r['bytes'],'mtimeNs':r['mtimeNs'],'contentReadForThisProof':False} for r in records if r['path'].endswith(('.log','.exit','.stderr','.stdout','terminal.json','metrics.json','measurement.json'))]
 R['scriptSHA256']=sha(pathlib.Path(__file__));R['reconstructionScriptSHA256']=sha(C/'independent_reconstruct_prefix.py')
 R['result']='PASS' if stable and all(r['exactPrefix'] for r in mappings) else 'FAIL'
 check(R['result']=='PASS','At least one input was unstable or not an exact byte prefix')
if __name__=='__main__':
 code=0
 try:main()
 except Exception as e:code=1;R['result']='FAIL';R['error']={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
 u=resource.getrusage(resource.RUSAGE_SELF);R['completedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();R['resources']={'wallSeconds':round(time.monotonic()-START,3),'userSeconds':u.ru_utime,'systemSeconds':u.ru_stime,'maxRssKiB':u.ru_maxrss}
 (C/'INDEPENDENT-PREFIX-RECONSTRUCTION-PROOF.json').write_text(json.dumps(R,indent=2)+'\n')
 print(json.dumps({'result':R['result'],'source':{k:R.get('sourceFile',{}).get(k) for k in ['bytes','sha256']},'mappings':[{k:r[k] for k in ['path','bytes','sha256','exactPrefix','firstDifferentByteOffset']} for r in R.get('mappings',[])],'allInputsStatStable':R.get('allInputsStatStable'),'resources':R['resources'],'error':R.get('error')}),flush=True)
 sys.exit(code)
