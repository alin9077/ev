/** Fresh research-only phase. Kept separate from the interrupted catalogue capture. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
const root=process.cwd(),qa=path.resolve('../roadmark-104-qa/catalogue-snapshot-reuse');
const out=path.join(qa,'after-research-independent');
assert(!fs.existsSync(path.join(out,'index.json')),'Do not overwrite a completed phase');
const pins=JSON.parse(fs.readFileSync('/tmp/subaru-research/derivation-input-verification.json','utf8'));
assert.equal(pins.status,'passed');
const fileHash=(p)=>{const h=crypto.createHash('sha256'),b=Buffer.alloc(262144),fd=fs.openSync(p,'r');try{let n;while((n=fs.readSync(fd,b,0,b.length,null))>0)h.update(b.subarray(0,n));}finally{fs.closeSync(fd)}return h.digest('hex')};
for(const row of pins.executionInputs)assert.equal(fileHash(row.path),row.sha256,'Phase input changed: '+row.path);
fs.mkdirSync(out,{recursive:true});
const start=Date.now(),index={mode:'Fresh research-only phase, separate from interrupted catalogue export',asOf:'2026-10-15',timeZone:'Australia/Sydney',research:{},cars:null};
const require=createRequire(path.join(root,'src/lib/data.ts'));
const api=require('./data.ts');
console.log('Imported actual current data module',process.memoryUsage());global.gc?.();
console.log('Collected import intermediates',process.memoryUsage());
// Serialization is unchanged from capture.mjs: one complete JSON row plus newline per write.
function rows(name,values){const fd=fs.openSync(path.join(out,name),'w');const hash=crypto.createHash('sha256');try{for(let i=0;i<values.length;i++){const text=JSON.stringify(values[i])+'\n';fs.writeSync(fd,text);hash.update(text);if(i%50===0)global.gc?.();}}finally{fs.closeSync(fd)}return{file:name,rows:values.length,sha256:hash.digest('hex')}}
const data=api.research();
console.log('Fresh research loaded',Object.keys(data),process.memoryUsage());
for(const[k,v]of Object.entries(data)){const isArray=Array.isArray(v);index.research[k]={...rows('research-'+k+'.jsonl',isArray?v:[v]),array:isArray};console.log('Research',k,index.research[k].rows);}
assert.equal(Object.keys(index.research).length,14);
for(const row of pins.executionInputs)assert.equal(fileHash(row.path),row.sha256,'Phase input changed during capture: '+row.path);
fs.writeFileSync(path.join(out,'phase-provenance.json'),JSON.stringify({status:'passed',mode:index.mode,asOf:index.asOf,timeZone:index.timeZone,executionInputVerificationSha256:fileHash('/tmp/subaru-research/derivation-input-verification.json'),inputsUnchangedBeforeAndAfter:true,elapsedMs:Date.now()-start,resourceUsage:process.resourceUsage(),memoryUsage:process.memoryUsage()},null,2)+'\n');
fs.writeFileSync(path.join(out,'index.json'),JSON.stringify(index,null,2)+'\n');
console.log('COMPLETE research-only phase',process.memoryUsage());
