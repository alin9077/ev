# Subaru independent source review — 2026-10-15 Australia/Sydney

Status: In progress; not an integration approval. No heavy catalogue replay has run.

## Source identity

- DOT-BRIEF-103.md and M1_PROGRESS.md read fully. M1/Tier 1 only; original snapshot and Model Y hero protected.
- Independent web fetch of official /solterra/specs returns MY27 in heading; older indexed search result returns MY26. Research owner's live HTTP source and current PDF independently agree MY27. Cached search text cannot define current year.
- The three current PDFs retrieved by research owner have 2027 covers. MY26 records remain separately scoped; current MY27 metadata cannot silently overwrite them.
- Uncharted official public specs component lists AWD and AWD with Panoramic Glass Roof; current PDF contains one AWD column with optional roof. Exact configuration naming can include the package while keeping trim semantics explicit.

## Numeric PDF checks

Solterra MY27 PDF pp7–8 visually checked after local rendering:
- AWD 566km / Touring517km explicitly WLTP table label; ADR81/02 generic footer retained as regulatory/source wording, not converted to NEDC
- 74.7kWh, gross/usable unspecified; individual motor ratings167+88kW must not be summed to combined system output
- 150kW DC input supported by separate brochure range-at-glance wording; approx30min10–80%;22kW3phase and7kW1phase
- AC time row says11kW0–100% approx4h while immediately preceding maximum says22kW; don't silently relabel the4h condition
- 4690×1860×1650mm;2850mm wheelbase;212mm ground clearance at kerb
- Seats5; cargo421/410L label 'rear seat up/down' does not state measurement protocol. Do not assign VDA/SAE/roofline. Unknown protocol stays unranked
-1500kg braked,750unbraked,150kg towball; optional towbar required

Trailseeker MY27 PDF pp7–8 text checked:
-533/488km WLTP,74.7kWh,150kW DC,22kW3phase,7kW1phase,approx30min10–80%
- Individual motors167+167kW, marketing combined280kW; no summed334kW system claim
-4845×1860×1675mm;2850wheelbase;211groundclearance; seats5
-609/595L cargo same ambiguous rear-seat-up/down protocol label
-1500kg braked,750unbraked,150towball
- Spare wheel now optional accessory, puncture repair kit standard
- Touring-only1.5kW V2L, panoramic roof, leather-accented trim, advanced park; base synthetic leather

Uncharted MY27 PDF pp6–7 text checked:
-522km WLTP,74.7kWh,150kW DC,22kW3phase,7kW1phase
- Charging row explicitly approx30min0–80%, unlike Solterra/Trailseeker10–80%; compare official live model/spec claims before selecting DC10–80 fact
-4535×1870×1625mm;2750wheelbase;211groundclearance; seats5;403L cargo unknown protocol
-1500braked,750unbraked,150towball
- Standard1.5kW V2L, synthetic leather,10speaker HarmanKardon, wirelessCarPlay/AndroidAuto, twoQi chargers

## Terms and equipment semantics

- https://www.subaru.com.au/new-vehicle-warranty is specific current maker summary:5yr/unlimited private,5yr150,000km named commercial uses;HVbattery8yr160,000km whichever first. No70%SOH promise supported by the summary.
- Current MY27 Solterra PDF lists12mo opt-in roadside. Eligibility:retail/novated lease fewer than5vehicles;fleet/government/rental excluded. This activation condition is not paid optional equipment.
- Legacy MY24 handbook says MY24-onward5yrfree service and5yr roadside. Current MY27 PDF instead capped-price5yr75,000km and12mo roadside. Keep program/year boundaries; no broad inheritance of historical free servicing.
- Public specs payload variants[].features contains copied legacy Solterra5yr service/roadside labels even in Trailseeker/Uncharted, with Solterra/Nov2023 disclaimers. Use exact current specFeatures/PDF/dedicated terms; these old generic labels are not enough for exact current fitment.
- Solterra public specs remote air-conditioning Yes does not establish cellular app connectivity, phone key or remote data services.

## Browser attempt

Own dot cloud CUA only: createBrowserTab('cdp',official Solterra specs) timed out and reset kernel; getState recovery returned CDP get-tabs and refresh-tabs timeouts after50000ms. No manually spawned Chromium, local user computer, CAPTCHA or screenshots used. Official accessible HTTP/PDF evidence review continues.

## Retention

This directory contains only reviewer notes, extracted public PDF text, and local PDF renders. Browser screenshots/session/auth/runtime captures are not retained. No reviewer file is approved for archive until full inventory and hashes are recorded.

## Current model component cross-check

All current default route ModelLandingPage objects explicitly use modelYear2027 and their named modelVariants have manufacturersListPrice:
- Solterra AWD61990/Touring67990
- Trailseeker AWD63990/Touring69990
- Uncharted AWD59990/roof configuration61190
No driveaway/tax conversion was used. /2026 routes are distinct and retain year2026.

Live exact spec tables expand Trailseeker cargo to609/1230L(1694ceiling), Touring595/1216L(1680ceiling); Uncharted403/1089L,1323ceiling withoutroof/1304withroof. Still no VDA/SAE. Live spec tables label4h0–100 at22kW, unlike PDFs'11kW row: do not conceal conflict if a charging-time fact is carried.

## Pre-canonical normalized review corrections

The researcher corrected these issues before the first canonical feature fixture:
- Separate ordinary folded cargo from the actual larger ceiling maximum, preserving both source values and conditions
- Remove unsupported optional-spare wording from MY26 Trailseeker, while retaining the directly supported MY27 optional accessory
- Add numeric V2L output and voltage dependencies to equipment projections
- Support DC vehicle acceptance with explicit model/brochure input claims, in addition to the specification table's charger-output wording
- Retain the roadside membership limit of fewer than five vehicles
- Remove unsubstantiated hands-free/kick-sensor wording from Uncharted's powered tailgate
- Retain the Uncharted audio conflict: specification table marks both speaker rows with a dash, whereas maker model/brochchure/launch material supports 10-speaker Harman Kardon; use Check with both sources

## Capture process review

Several fresh capture processes terminated with signal 9. Their measured exits are preserved; no cause is inferred. A phased harness retains complete source/research/car/feature coverage and preserves all complete brand files from the interrupted attempt. A separate exact phase-key-set verification is required alongside per-row equality. Root has authorized an explicitly labelled provenance-chain fallback, but no derived chain or historical snapshot is to be described as a successful fresh hydration.
