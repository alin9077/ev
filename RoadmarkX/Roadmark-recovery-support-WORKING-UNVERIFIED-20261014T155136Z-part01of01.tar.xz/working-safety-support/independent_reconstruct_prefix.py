#!/usr/bin/env python3
"""Restore a proved prefix into a missing path; never overwrites existing files."""
import argparse,hashlib,json,pathlib,stat
CHUNK=1024*1024
p=argparse.ArgumentParser();p.add_argument('--mapping',required=True);p.add_argument('--restore-root',required=True);p.add_argument('--candidate',required=True);a=p.parse_args()
r=json.loads(pathlib.Path(a.mapping).read_text());assert r['result']=='PASS' and r['allInputsStatStable']
x=next(x for x in r['mappings'] if x['path']==a.candidate);assert x['exactPrefix'] and x['reconstructable']
root=pathlib.Path(a.restore_root).resolve();s=root/r['sourceFile']['restorePath'];d=root/x['restorePath'];assert s.resolve().is_relative_to(root) and d.resolve().is_relative_to(root) and not s.is_symlink() and not d.exists()
pre=s.stat();assert stat.S_ISREG(pre.st_mode);h=hashlib.sha256();size=0
with s.open('rb') as f:
 for b in iter(lambda:f.read(CHUNK),b''):h.update(b);size+=len(b)
assert size==r['sourceFile']['bytes'] and h.hexdigest()==r['sourceFile']['sha256']
d.parent.mkdir(parents=True,exist_ok=True);h=hashlib.sha256();remaining=x['reconstructionBytes']
with s.open('rb') as src,d.open('xb') as dst:
 while remaining:
  b=src.read(min(CHUNK,remaining));assert b;dst.write(b);h.update(b);remaining-=len(b)
assert h.hexdigest()==x['sha256'] and d.stat().st_size==x['bytes']
post=s.stat();assert (pre.st_size,pre.st_mtime_ns,pre.st_ctime_ns,pre.st_ino,pre.st_dev)==(post.st_size,post.st_mtime_ns,post.st_ctime_ns,post.st_ino,post.st_dev)
print(json.dumps({'result':'PASS','reconstructed':x['restorePath'],'bytes':x['bytes'],'sha256':h.hexdigest(),'applicationRunCompletionEstablished':False}))
