import urllib.request,json,pathlib,concurrent.futures
from lxml import html
P=pathlib.Path('/tmp/volvo-research/compact')
urls={f'{f}-{p}':'https://www.volvocars.com/au/'+path for f in ['ex30','ex40','ec40'] for p,path in [('build',f'build/{f}-electric/'),('spec',f'cars/{f}-electric/specifications/'),('overview',f'cars/{f}-electric/')]}
urls['ex30-offer']='https://www.volvocars.com/au/l/offers/ex30-swedish-dream-driveaway/'
def fetch(it):
 key,url=it
 try:
  s=urllib.request.urlopen(url,timeout=40).read().decode();h=html.fromstring(s)
  scripts=h.xpath('//script[@id="__NEXT_DATA__"]/text()')
  if scripts:
   j=json.loads(scripts[0]);print(key,'JSON keys',list(j.keys()),flush=True)
   # Retain factual branches only, removing keys with security/session/runtime fields recursively.
   def clean(o):
    if isinstance(o,dict):
     return {k:clean(v) for k,v in o.items() if not any(x in k.lower() for x in ['cookie','csrf','token','secret','session','apikey','api_key','telemetry','analytics','trace','auth','clientid','client_id'])}
    if isinstance(o,list):return [clean(x) for x in o]
    return o
   (P/(key+'-data.sanitized.json')).write_text(json.dumps(clean(j),indent=2))
  for t in h.xpath('//script|//style|//noscript'):t.getparent().remove(t)
  tx='\n'.join(x.strip() for x in h.xpath('//text()') if x.strip())
  (P/(key+'.txt')).write_text('URL: '+url+'\nChecked: 2026-10-14\nSanitization: visible public text only; scripts, style, session/runtime/security fields excluded.\n\n'+tx)
  return key,len(s),len(tx)
 except Exception as e:return key,str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
 for r in ex.map(fetch,urls.items()):print(r,flush=True)
(P/'source-index.json').write_text(json.dumps(urls,indent=2))
