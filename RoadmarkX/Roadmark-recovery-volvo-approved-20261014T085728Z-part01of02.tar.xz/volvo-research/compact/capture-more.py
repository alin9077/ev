import urllib.request,json,pathlib,concurrent.futures,hashlib
from lxml import html
P=pathlib.Path('/tmp/volvo-research/compact')
urls={
'berwick-ex30-my26-plus':'https://volvocarsberwick.com.au/13702716-1900220-volvo-ex30-2026/',
'berwick-c40-my24':'https://volvocarsberwick.com.au/11048122-1435015-volvo-c40-2023/',
'sy-ex30-cc':'https://volvocarssouthyarra.com.au/13550347-1885378-volvo-ex30crosscountry-2026/',
'sy-ex40-single':'https://volvocarssouthyarra.com.au/13629316-1895759-volvo-ex40-2026/',
'sy-ex40-twin':'https://volvocarssouthyarra.com.au/13629327-1895761-volvo-ex40-2026/',
'carexpert-price-cuts':'https://www.carexpert.com.au/car-news/volvo-slashes-pricing-of-ex30-and-ex40-electric-suvs',
'carexpert-ec40-withdrawal':'https://www.carexpert.com.au/car-news/volvos-compact-ev-crossover-coupe-to-be-axed-in-australia',
'carexpert-ex40-my27-5':'https://www.carexpert.com.au/car-news/2027-volvo-ex40-xc40-updated-with-new-tech-and-looks',
'carsales-ec40':'https://www.carsales.com.au/cars/volvo/ec40/',
'carsales-new-ex30':'https://www.carsales.com.au/cars/dealer/new/volvo/ex30/',
'carsales-new-ex40':'https://www.carsales.com.au/cars/dealer/new/volvo/ex40/',
'carsales-new-c40':'https://www.carsales.com.au/cars/dealer/new/volvo/c40/',
}
def fetch(it):
 key,url=it
 try:
  r=urllib.request.urlopen(url,timeout=35);s=r.read().decode();h=html.fromstring(s)
  for t in h.xpath('//script|//style|//noscript'):t.getparent().remove(t)
  tx='\n'.join(x.strip() for x in h.xpath('//text()') if x.strip())
  (P/(key+'.txt')).write_text('URL: '+url+'\nChecked: 2026-10-14\nSanitization: visible public text only; scripts, style, session/runtime/security fields excluded.\n\n'+tx)
  return key,r.status,r.url,len(tx)
 except Exception as e:return key,str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:
 for r in ex.map(fetch,urls.items()):print(r,flush=True)
j=json.load(open(P/'source-index.json'));j.update(urls);(P/'source-index.json').write_text(json.dumps(j,indent=2))
