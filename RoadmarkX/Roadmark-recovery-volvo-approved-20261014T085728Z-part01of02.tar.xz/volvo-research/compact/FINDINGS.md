# Australian Volvo compact electric family: 14 October 2026

## Result

Ten exact versions are supported: five current MY27 versions and five residual-new MY26 versions. See `normalized-evidence.json` for sourced core facts, equipment, price observations and availability. `family-census.json` records 19 source-bound inclusion, exclusion, announced and unresolved dispositions. There are 57 hashed factual sources.

Current MY27 maker list prices, including GST and before on-road costs:
- EX30 Plus P5 Long Range: $49,990
- EX30 Ultra P5 Long Range: $54,990
- EX30 Cross Country P8 AWD: $62,990
- EX40 Ultra Single Motor Extended Range: $69,990
- EX40 Ultra Twin Motor: $74,990

These are rung 1, Confirmed. Parent-captured selected NSW 2000 maker breakdowns separately list delivery, stamp duty and registration; no LCT line applies to these base configurations. Separate estimated NSW driveaway observations remain available. The $55,990 national offer names Plus Single Extended, so it has not been silently transferred to renamed MY27 P5.

Residual-new MY26 versions:
- EX30 Plus Single Extended: Berwick stock 13702716; advertised MY26, with VIN/model-year label inconsistency retained
- EX30 Ultra Single Extended: Doncaster 12974600; explicit MY26, September 2025 build, May 2026 compliance, New/In stock
- EX30 Cross Country Ultra Twin Performance: Springwood/Cricks HL2495; current New 157 km inventory, exact Carsales stock confirms MY26 and September 2025 build
- EX40 Ultra Single Extended: Perth 6095V, explicit MY26 New/In stock
- EX40 Ultra Twin Performance: Doncaster 13294744, explicit MY26 New/In stock

Exact residual facts are Reported where dealer/secondary or explicit current-sibling carry-forward is necessary. Current maker MY27 prices were not relabelled MY26 list prices.

## Material corrections and qualifications

- Cross Country current AU MY27 manual gives 4233 × 1850 × 1567 mm, 2040 mm mirrors extended, 1953 mm folded, and 190 mm clearance. Generic EX30 body dimensions must not be used for Cross Country
- Current EX30 Ultra has standard 19-inch wheels; 20-inch wheels are optional. MY26 dealer wheel styling differs and is retained separately
- MY27 EX30 Plus DC peak is 134 kW Reported from the exact current secondary. Older AU maker 153 kW and current Ultra 153 kW remain explicit alternatives. Other EX30 153 kW claims remain Reported, with 135 kW Cross Country conflict retained. The maker's 150 kW charging station is not vehicle peak acceptance
- Charging windows are explicit: EX30 10–80% in 28 minutes at a 150 kW station; EX40 10–80% in 28 minutes at a 200 kW station. AC is 0–100% at three-phase 16A, eight hours. Residual carry-forward is marked Reported
- Current maker boot figures are Confirmed: EX30 318 L open seats-up, distinct from 400 L maximum; EX40 410 L open seats-up, distinct from 536 L maximum. Front/closed storage is separate. Common VDA/ISO methodology is not asserted and unlike methods must not rank together
- Manufacturer range statements remain Check where explicitly preliminary/certification-pending. Generic laboratory or model-year caveats alone are standing qualifications, not automatic uncertainty flags
- EX30 recall REC-006633/R10370 applies to specified 2023–24 VINs, with an interim 70% charge limit. Check VIN and completed repair for any older residual. No blanket MY26/MY27 restriction or synthetic 70%-range calculation

## Closed and unresolved census issues

- MY25 Twin Carsales OAG-AD-24247098 maps to Doncaster stock 11966122, whose origin says SOLD and DEMO 1604 km. Exclude it
- MY25 Single Ultra Solitaire stock 51658, VIN YV12ZEL85SS118396, is an unresolved 1.2-year-old New cache. Current inspected Adelaide inventory only displays MY27 stock. No current-origin status was recovered
- MY25 Twin Perth stock 5711V is an unresolved 1.3-year-old New cache. No fresh sale evidence was recovered
- C40 Berwick 11048122 is SOLD on fresh direct fetch. EC40 inspected examples are used; maker build unavailable and AU reporting says discontinued late 2025. No qualifying fresh C40/EC40 New ad found
- XC40 BEV legacy maker/dealer pages persist, but fresh maker build redirects to modelNotFound. No exact qualifying current New unit found. This is bounded search evidence, not proof of zero national residual stock
- EX40 Black Edition and overseas EX30 derivatives are not selectable in current AU maker builds; no fresh exact residual-new Black Edition evidence found
- EX40 MY27.5 facelift is announced for Australia in 2027, with no open-order evidence or final AU pricing/specification. Keep future 11.2-inch screen separate from current MY27's 9-inch screen

Warranty and battery-warranty terms are supplied by the parent brand-wide research. Public ad availability does not imply physical stock verification or factory-order acceptance.

## Final equipment audit

Residual equipment is now mapped feature by feature in `residual-feature-mapping.json`. Exact dealer-supported features are distinguished from explicitly labelled MY27 sibling carry-forward; unsupported inherited claims were removed. MY26 Plus wheel-spoke conflict is omitted rather than resolved by assumption. Current EX40 availability uses only its maker route; MY26 Plus availability explicitly carries the dealer-model-year/VIN conflict. Current Cross Country AC11kW/eight-hour facts cite maker only, and shared maker storage supports318L Confirmed without a common measurement ranking.

## MY26 Ultra charging and price recheck

Exact AU2026 Ultra RWD CarExpert (released5September2025) explicitly lists11kW onboard AC and8hours0–100%; retained Reported with exact-version source. No exact AU MY26Ultra22kW source was recovered. DC153kW is also exact-source Reported; CarExpert0.44-hour10–80% alternative differs fromCarsales/maker28minutes and remains visible. ExactMY26Carsales pages independently corroborate$54,990Ultra and$62,990CrossCountry basepricesincludingGST/LCT. The Marchpricecut article itself says2026, not literalMY26.
