import json,pathlib
p=pathlib.Path('/tmp/volvo-research/compact');a=json.loads((p/'normalized-evidence.json').read_text())
mapout=[]
def set_features(v,groups,note):
 mapping=[]
 for features,sources,scope in groups:
  for name in features:mapping.append({'feature':name,'grade':'reported','sourceKeys':sources,'scope':scope})
 v['equipmentHighlights']={'values':[r['feature'] for r in mapping],'sourceKeys':list(dict.fromkeys(s for r in mapping for s in r['sourceKeys'])),'grade':'reported','note':note,'mapping':mapping}
 mapout.append({'variantId':v['id'],'mapping':mapping})
for v in a['variants']:
 if v['modelYear']==2027 and v['model']=='EX40':
  v['availability']['note']='Current maker sale/quote route for this exact MY27 EX40 version. No factory-order acceptance or physical-stock promise; no unrelated model advertisement used as corroboration.'
 if v['id']=='volvo_ex30_my26_plus_single_motor_extended_range__20261014':
  set_features(v,[(['Adaptive cruise control','Pilot Assist','Harman Kardon Premium Sound','Dual-zone climate control','LED headlights','Wireless phone charging','12.3-inch centre display','Keyless entry','Heat pump','Rear park-assist camera'],['berwick-ex30-my26-plus'],'Exact advertised MY26 stock13702716; dealer specification and description')], 'Only features present in the actual MY26 dealer advertisement retained. Wheel spoke style omitted: description says19-inch5-spoke, highlighted field says19-inch8-spoke.')
  v['availability']['condition']='Dealer explicitly labels MY26, but VIN YV12ZEL9XVS198534 has V model-year character and buildJune2026/complianceAugust2026. Advertised MY26 attribution retained pending VIN/model-year confirmation; do not silently merge with MY27.'
  v['availability']['grade']='check'
 if v['id']=='volvo_ex40_my26_ultra_single_motor_extended_range__20261014':
  set_features(v,[(['Panoramic roof','360-degree camera','Harman Kardon Premium Sound','Pilot Assist','Pixel LED headlights','Heated rear seats'],['ex40-build-product-facts'],'Explicit sibling carry-forward: current MY27 EX40 Ultra maker equipment, not independently established on MY26 stock6095V')], 'Reported sibling equipment only. Exact PerthMY26 ad capture proves New status, MY, seats and price, not this equipment list. Verify unit equipment before contract.')
 if v['id']=='volvo_ex40_my26_ultra_twin_motor_performance__20261014':
  set_features(v,[(['Power panoramic sunroof','Harman Kardon sound','Heated front and rear seats','Heated steering wheel','Pixel LED headlights','360-degree camera','Pilot Assist'],['doncaster-ex40-my26-twin'],'Exact advertised MY26 stock13294744; equipment explicitly retained in dealer factual capture')], 'Only exact dealer-ad equipment retained; unsupported inherited MY27 highlights removed.')
 if v['id']=='volvo_ex30_my26_single_motor_extended_range_ultra__20261014':
  set_features(v,[(v['equipmentHighlights']['values'],['doncaster-ex30-my26-ultra'],'Exact advertised MY26 stock12974600; dealer specification and equipment fields')], 'Exact MY26 dealer-listed equipment only. Do not apply current MY27 wheel style.')
 if v['id']=='volvo_ex30_my26_cross_country_ultra_twin_motor_performance__20261014':
  set_features(v,[(['19-inch wheels','190mm ground clearance'],['cs-cc-my26'],'Exact MY26 AU secondary specification'),(['Panoramic roof','Park Pilot Assist','360-degree camera, 3D view'],['ex30-cc-browser-nsw2000'],'Explicit sibling carry-forward: current MY27 Cross Country selected maker configurator; exact MY26 equipment not independently established by saved dealer capture')], 'Exact MY26 wheel/clearance features separated from Reported MY27 Cross Country sibling carry-forward. Removed unsupported HK/heated-seat claims from this compact list; no MY27V2L transfer.')
  v['tradeOff']='318L minimum boot remains compact; MY26 DC peak claims conflict across sources.'
 if v['id']=='volvo_ex30_my27_cross_country_p8_awd_electric__20261010':
  for f in v['facts']:
   if f['key'] in ['ac_kw','ac_charge_time_hours']:
    f['sourceKeys']=['ex30-spec'];f['grade']='confirmed';f['reason']='Current maker specification explicitly includes P8 AWD Cross Country and shared11kW onboard-charger equipment; P8 charging table gives0–100%eight hours at three-phase16A.'
   if f['key']=='boot_l':
    f.update(grade='confirmed',sourceKeys=['ex30-spec'],value=318,comparison='',basis='Rear seats upright, maker shared open luggage-volume specification',reason='Current maker EX30 specification includes P8 AWD Cross Country and a shared storage block with318L open seats-up volume. No CC exclusion stated; distinct body dimensions are handled by CCmanual, without assuming different luggage volume.');f['qualification']='Maker open volume; maximum400L and frunk7L are distinct bases. No commonVDA/ISO method asserted.';f.pop('condition',None)
(p/'normalized-evidence.json').write_text(json.dumps(a,indent=2)+'\n');(p/'residual-feature-mapping.json').write_text(json.dumps({'checkedAt':'2026-10-14','variants':mapout},indent=2)+'\n')
print('Audited',len(mapout),'residual feature mappings')
