import urllib.request,json,pathlib,concurrent.futures,re
from lxml import html
P=pathlib.Path('/tmp/volvo-research/compact')
urls={
'ex30-summary-plus':'https://www.volvocars.com/au/build/ex30-electric/summary/?pno12=416EL350L246&my=2027&le=&edition=1',
'ex30-ultra-details':'https://www.volvocars.com/au/build/ex30-electric/equipment-level-learn-more/level-4-bev/?pno12=416EL350L246&my=2027&cmy=2027&editionKey=1&le=',
'ex30-cross-country-build':'https://www.volvocars.com/au/build/ex30-electric/?pno12=417EK650E246&my=2027&edition=cross-country',
'berwick-stock':'https://volvocarsberwick.com.au/new-demo-used-cars/?fuels=Electric&makes=Volvo',
}
def fetch(it):
 k,u=it
 try:
  r=urllib.request.urlopen(u,timeout=35);s=r.read().decode();h=html.fromstring(s)
  links=[{'text':a.text_content()[:160],'url':a.get('href')} for a in h.xpath('//a[@href]') if any(t in a.get('href') for t in ['pno12','13702719','13628156','13628155','13549858','13702724','ex40-'])]
  for t in h.xpath('//script|//style|//noscript'):t.getparent().remove(t)
  tx='\n'.join(x.strip() for x in h.xpath('//text()') if x.strip());(P/(k+'.txt')).write_text('URL: '+u+'\nChecked 2026-10-14\nRedactions: visible text only; HTML/scripts/session/security excluded\n\n'+tx)
  (P/(k+'-links.json')).write_text(json.dumps(links,indent=2));return k,len(tx),links[:6]
 except Exception as e:return k,str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 for r in ex.map(fetch,urls.items()):print(r,flush=True)
j=json.load(open(P/'source-index.json'));j.update(urls);(P/'source-index.json').write_text(json.dumps(j,indent=2))
