import urllib.request,re,json,pathlib,concurrent.futures
from lxml import html
P=pathlib.Path('/tmp/volvo-research/compact')
def fetch(f):
 u=f'https://www.volvocars.com/au/build/{f}-electric/'
 s=urllib.request.urlopen(u,timeout=40).read().decode(); h=html.fromstring(s); chunks=[]
 for x in h.xpath('//script/text()'):
  if x.startswith('self.__next_f.push('):
   try:
    d=json.loads(x[len('self.__next_f.push('):-1]);
    if isinstance(d,list) and len(d)>1 and isinstance(d[1],str):chunks.append(d[1])
   except:pass
 data='\n'.join(chunks)
 out={'url':u,'checked_on':'2026-10-14','redactions':'Whitelist of public product facts extracted from page RSC; no original HTML or runtime/session/security fields persisted.','fields':{}}
 dec=json.JSONDecoder()
 for key in ['equipmentLevels','editions','powertrains','engines','modelYear','priceBreakdown','priceSummary','configuration','basePrice','selectedCar','carData','price','pricing']:
  arr=[]
  for m in re.finditer('"'+key+'":',data):
   try:
    val,end=dec.raw_decode(data[m.end():]);
    if key in ['price','pricing'] and not any(x in str(val) for x in ['69990','74990','49990','54990','62990','MLP','List Price']):continue
    if val not in arr:arr.append(val)
   except:pass
  if arr:out['fields'][key]=arr
 # Public factual key names surrounding product prices or selected model IDs, for traceable follow-up
 out['public_price_contexts']=[]
 for term in ['49990','54990','62990','69990','74990',"Manufacturer's List",'MLP']:
  for m in list(re.finditer(re.escape(term),data))[:8]:out['public_price_contexts'].append(data[max(0,m.start()-180):m.end()+200])
 (P/(f+'-build-facts.json')).write_text(json.dumps(out,indent=2)); print(f,[(k,len(v)) for k,v in out['fields'].items()],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:list(ex.map(fetch,['ex30','ex40']))
