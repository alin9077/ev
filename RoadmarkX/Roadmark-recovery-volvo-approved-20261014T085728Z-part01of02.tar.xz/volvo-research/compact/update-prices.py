import json,pathlib,hashlib
p=pathlib.Path('/tmp/volvo-research/compact');a=json.loads((p/'normalized-evidence.json').read_text());idx=json.loads((p/'source-index.json').read_text())
items=[('ex30-plus-browser-nsw2000','https://www.volvocars.com/au/build/ex30-electric/',49990,55972),('ex30-ultra-browser-nsw2000','https://www.volvocars.com/au/build/ex30-electric/?ccid=bH4wLmxldmVsLTQtYmV2X2xlfjAu',54990,61222),('ex30-cc-browser-nsw2000','https://www.volvocars.com/au/build/ex30-electric/?ccid=bH4wLmxldmVsLTQtYmV2X2xlfjAuX2V%2BMC5jcm9zcy1jb3VudHJ5',62990,69622),('ex40-single-browser-nsw2000','https://www.volvocars.com/au/build/ex40-electric/',69990,76972),('ex40-twin-browser-nsw2000','https://www.volvocars.com/au/build/ex40-electric/?ccid=cH4wLkVSLUU=',74990,82222)]
for v,(key,url,mlp,da) in zip(a['variants'][:5],items):
 f=p/(key+'.txt');s={'key':key,'url':url,'title':'Volvo AU selected '+v['trim']+' price breakdown, NSW 2000','publisher':'Volvo Cars Australia','source_type':'manufacturer','checked_on':'2026-10-14','file':str(f),'textFile':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'redactions':'Public visible browser text/accessibility retained; no browser cookies, runtime/session tokens or raw payload retained.'}
 a['sources']=[x for x in a['sources'] if x['key']!=key]+[s];idx[key]=url
 for fact in v['facts']:
  if fact['key']=='price_aud':
   fact.update(value=mlp,grade='confirmed',sourceKeys=[key],basis='Manufacturer recommended list price including GST; before on-road costs',comparison='Before on-road costs',reason='Exact selected MY27 version maker breakdown explicitly separates manufacturer list price including GST, delivery, stamp duty and registration; no LCT line for this base configuration',priceRung=1)
   fact.pop('condition',None)
 v['priceObservations']=[{'value':da,'currency':'AUD','basis':'Manufacturer estimated driveaway, Sydney NSW 2000','grade':'check','sourceKey':key,'condition':'Selected standard configuration; NSW 2000, private owner aged 40, good driving record, premium registration plate assumptions; dealer agreement may differ; not a promotional price','checkedAt':'2026-10-14'}]
 if 'ex30' in v['id']:
  v['equipmentHighlights']['values'].append('Standard 19-inch 5-spoke matt graphite/matt black wheels' if 'cross_country' in v['id'] else 'Standard 19-inch 5-spoke glossy black diamond cut wheels')
  v['equipmentHighlights']['sourceKeys'].append(key)
 if 'ultra_p5' in v['id']:v['equipmentOptions']=[{'name':'20-inch wheels','value':'Optional 20-inch 5-Y-spoke glossy black diamond cut; 19-inch standard','grade':'check','sourceKeys':[key],'condition':'Optional wheel fitment; do not claim standard 20-inch'}]
a['familyNotes']=[x for x in a['familyNotes'] if not x.startswith('MY27 Plus P5 uses')]+['All five current MY27 prices now maker list rung1, confirmed from selected NSW 2000 browser breakdown: EX30 Plus49990/Ultra54990/Cross Country62990; EX40 Single69990/Twin74990. Separate localized driveaway observations retained. National EX30 Plus Single Extended55990 offer is not silently aliased to renamed MY27 P5.']
(p/'normalized-evidence.json').write_text(json.dumps(a,indent=2)+'\n');(p/'source-index.json').write_text(json.dumps(idx,indent=2)+'\n')
with (p/'FINDINGS.md').open('a') as f:f.write('\nAll five current MY27 manufacturer list prices are now confirmed from exact selected NSW 2000 browser breakdowns, which separate delivery/stamp/registration: EX30 Plus $49,990, Ultra $54,990, Cross Country $62,990; EX40 Single $69,990, Twin $74,990. Separate NSW estimated driveaway observations retained. MY27 Ultra EX30 standard wheels confirmed 19-inch, with 20-inch optional.\n')
print('Updated',len(a['variants']),'variants and',len(a['sources']),'sources')
