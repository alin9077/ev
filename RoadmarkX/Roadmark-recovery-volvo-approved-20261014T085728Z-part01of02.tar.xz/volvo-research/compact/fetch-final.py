import urllib.request,json,pathlib,concurrent.futures,hashlib
from lxml import html
P=pathlib.Path('/tmp/volvo-research/compact')
urls={
'doncaster-ex40-my26-twin':'https://volvocarsdoncaster.com.au/13294744-1852787-volvo-ex40-2026/',
'perth-ex40-my26-single':'https://volvocarsperth.com.au/6095v-1743032-volvo-ex40-2025/',
'berwick-ex30-my27-cc':'https://volvocarsberwick.com.au/13702724-1900222-volvo-ex30crosscountry-2026/',
'berwick-ex30-my27-ultra':'https://volvocarsberwick.com.au/13628156-1900219-volvo-ex30-2026/',
'berwick-ex30-my27-plus':'https://volvocarsberwick.com.au/13628155-1900218-volvo-ex30-2026/',
'recall-ex30-2026':'https://www.vehiclerecalls.gov.au/recalls/rec-006633',
'ex40-support-charging':'https://www.volvocars.com/au/support/car/ex40/article/0ed816eed33d98cac0a8cc377bc12bc7-83c0c849d91ad5fac0a8cc3751bbe62b-8664b2fa77a7e089c0a8296870d1a409/',
'ex40-support-towing':'https://www.volvocars.com/au/support/car/ex40/article/0ed816eed33d98cac0a8cc377bc12bc7-70bede2dc073ca71c0a8b0975b1e6fa3-8664b2fa77a7e089c0a8296870d1a409/',
'ex30-au-launch':'https://www.volvocars.com/au/news/electrification/2023-june-small-package/',
'berwick-beige-stock':'https://volvocarsberwick.com.au/new-cars/?base_colours=Beige&doors=5',
}
def fetch(it):
 k,u=it
 try:
  r=urllib.request.urlopen(u,timeout=35);s=r.read().decode();h=html.fromstring(s)
  for a in h.xpath('//a[@href]'):
   if '13702719' in a.get('href'):print('MY26ULTRA URL',a.get('href'),flush=True)
  for t in h.xpath('//script|//style|//noscript'):t.getparent().remove(t)
  tx='\n'.join(x.strip() for x in h.xpath('//text()') if x.strip());(P/(k+'.txt')).write_text('URL: '+u+'\nChecked 2026-10-14\nRedactions: visible text only; HTML/scripts/session/security excluded\n\n'+tx)
  return k,r.status,len(tx)
 except Exception as e:return k,str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
 for r in ex.map(fetch,urls.items()):print(r,flush=True)
j=json.load(open(P/'source-index.json'));j.update(urls);(P/'source-index.json').write_text(json.dumps(j,indent=2))
