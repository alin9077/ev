exec(open('/tmp/volvo-research/compact/fetch-final.py').read().split('with concurrent.futures')[0].split('urls={')[0])
urls={
'cc-support-dimensions':'https://www.volvocars.com/au/support/car/ex30-cross-country/article/0ed816eed33d98cac0a8cc377bc12bc7-e6a7973b2bf222b2c0a8b09757c97ec8-8664b2fa77a7e089c0a8296870d1a409/',
'cc-support-towing':'https://www.volvocars.com/au/support/car/ex30-cross-country/article/0ed816eed33d98cac0a8cc377bc12bc7-70bede2dc073ca71c0a8b0975b1e6fa3-8664b2fa77a7e089c0a8296870d1a409/',
'berwick-ex30-my26-ultra-candidate':'https://volvocarsberwick.com.au/13702719-1900221-volvo-ex30-2026/',
}
def fetch(it):
 k,u=it
 try:
  r=urllib.request.urlopen(u,timeout=35);s=r.read().decode();h=html.fromstring(s)
  for t in h.xpath('//script|//style|//noscript'):t.getparent().remove(t)
  tx='\n'.join(x.strip() for x in h.xpath('//text()') if x.strip());(P/(k+'.txt')).write_text('URL: '+u+'\nChecked 2026-10-14\nRedactions: visible text only; HTML/scripts/session/security excluded\n\n'+tx)
  return k,r.status,len(tx),('SOLD' in tx)
 except Exception as e:return k,str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
 for r in ex.map(fetch,urls.items()):print(r,flush=True)
j=json.load(open(P/'source-index.json'));j.update(urls);(P/'source-index.json').write_text(json.dumps(j,indent=2))
