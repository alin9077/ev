import pathlib,subprocess,json,re,html,sys,hashlib
from html.parser import HTMLParser
R=pathlib.Path('/tmp/volvo-research')
class Text(HTMLParser):
 def __init__(self):super().__init__();self.out=[];self.skip=0
 def handle_starttag(self,t,a):
  if t in ('script','style','noscript'):self.skip+=1
  if t in ('p','div','h1','h2','h3','h4','li','tr','td','br'):self.out.append('\n')
 def handle_endtag(self,t):
  if t in ('script','style','noscript'):self.skip=max(0,self.skip-1)
  if t in ('p','div','li','tr','td'):self.out.append('\n')
 def handle_data(self,d):
  if not self.skip:self.out.append(d)
def capture(url,name):
 p=R/name;p.parent.mkdir(exist_ok=True,parents=True)
 cmd=['curl','-L','-sS','--max-time','60','--retry','1',url]
 r=subprocess.run(cmd,capture_output=True);raw=r.stdout.decode('utf-8',errors='replace');red=[]
 for pattern in [r'(?i)((?:token|longToken|sessionId|session_id|csrfToken)(?:\\?"|\x27)?\s*:\s*(?:\\?"|\x27))[^"\x27\\\n]+',r'eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+',r'(?i)((?:csrf[_-]?token|requestverificationtoken|client_secret|access_token|refresh_token|sessionId|session_id|sessionToken|session_token)["\x27]?\s*[:=]\s*["\x27])[^"\x27\n]+',r'(?i)((?:msockid|sessionid|token|csrf)=)[^&"\s<>\\]+']:
  raw,n=re.subn(pattern,lambda m:(m[1] if m.lastindex else '')+'[REDACTED]',raw)
  if n:red.append({'pattern':pattern,'count':n})
 p.with_suffix('.html').write_text(raw)
 parser=Text();parser.feed(raw);txt=re.sub(r'\n\s*\n+','\n',''.join(parser.out));p.with_suffix('.txt').write_text(txt)
 meta={'url':url,'checkedAt':'2026-10-14','curlExit':r.returncode,'bytes':len(raw.encode()),'rawFactualSha256':hashlib.sha256(raw.encode()).hexdigest(),'redactions':red,'headersStored':False,'error':r.stderr.decode()}
 p.with_suffix('.capture.json').write_text(json.dumps(meta,indent=2)+'\n');print(name,len(raw),r.returncode,red)
if __name__=='__main__':capture(sys.argv[1],sys.argv[2])
