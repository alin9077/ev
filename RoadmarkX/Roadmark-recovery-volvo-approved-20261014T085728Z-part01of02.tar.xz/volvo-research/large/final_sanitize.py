import pathlib,re,json,hashlib
R=pathlib.Path('/tmp/volvo-research/large')
p=re.compile(r'(?i)((?:longToken|token|sessionId|session_id|csrfToken)(?:\\?"|\x27)?\s*:\s*(?:\\?"|\x27))([^"\x27\\\n]+)')
jwt=re.compile(r'eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+')
changes=[]
def clean(s):
 return jwt.sub('[REDACTED]',p.sub(lambda m:m[1]+'[REDACTED]',s))
for f in R.glob('*.html'):
 s=f.read_text()
 def sub(m):
  try:
   a=json.loads(m[1]);a=[clean(x) if isinstance(x,str) else x for x in a]
   return '<script>self.__next_f.push('+json.dumps(a,ensure_ascii=False,separators=(',',':'))+')</script>'
  except:return m[0]
 n=re.sub(r'<script>self\.__next_f\.push\((.*?)\)</script>',sub,s)
 n=clean(n)
 if n!=s:f.write_text(n);changes.append(f.name)
 meta=f.with_suffix('.capture.json')
 if meta.exists():
  d=json.loads(meta.read_text());d['rawFactualSha256']=hashlib.sha256(f.read_bytes()).hexdigest();d['finalSanitization']='Runtime fields redacted both inside decoded Next.js script strings and serialized HTML before preserving source; JWT patterns removed.';meta.write_text(json.dumps(d,indent=2))
for f in R.iterdir():
 if f.suffix not in ['.json','.txt']:continue
 s=f.read_text(errors='ignore');n=clean(s)
 if n!=s:f.write_text(n);changes.append(f.name)
# Source index must always hash sanitized copies.
d=json.load(open(R/'normalized-evidence.json'))
for src in d['sources']:
 src['sha256']=hashlib.sha256(pathlib.Path(src['file']).read_bytes()).hexdigest();src['textSha256']=hashlib.sha256(pathlib.Path(src['textFile']).read_bytes()).hexdigest()
(R/'normalized-evidence.json').write_text(json.dumps(d,indent=2,ensure_ascii=False));(R/'source-index.json').write_text(json.dumps(d['sources'],indent=2,ensure_ascii=False))
a=json.load(open(R/'sanitization-audit.json'));a['finalSanitizedFiles']=changes;a['unredactedRuntimeFieldCandidates']=[]
for f in R.iterdir():
 if f.suffix not in ['.html','.txt','.json']:continue
 s=f.read_text(errors='ignore');bad=[m[2] for m in p.finditer(s) if 'REDACTED' not in m[2]]
 if bad:a['unredactedRuntimeFieldCandidates'].append({'file':f.name,'count':len(bad)})
(R/'sanitization-audit.json').write_text(json.dumps(a,indent=2));print('Final field candidates',a['unredactedRuntimeFieldCandidates'],'rewrites',len(changes))
