# Volvo EX90 and ES90 Australian versions: 14 October 2026

## Result

Eight supported on-sale versions: four current maker-listed MY2027 versions and four MY2026 residual-new versions. Current maker configurators and October all-new-model retail offer establish sale availability. Residual rows have explicit New classifications and stock identifiers. This does not establish physical stock or accepted factory orders.

`normalized-evidence.json` contains the full source-linked facts/features for integration. `source-index.json` contains 27 factual captures with hashes and source URLs. Shared Australian warranty/battery warranty/roadside terms are assigned to the parent researcher and must be merged before checking the 17-core gate. No repository files were changed.

## Current Australian MY2027 catalogue

| Version | Observed maker configuration AUD | Drive | kW / Nm | 0–100 s | WLTP km | Nominal kWh | Seats | Max trailer kg |
|---|---:|---|---|---:|---:|---:|---:|---:|
| EX90 Plus Single Motor | 103,453 | RWD | 245 / 480 | 6.8 | 479 | 92 | 7 | 1,500 |
| EX90 Ultra Twin Motor Performance | 124,991 | AWD | 500 / 870 | 4.2 | 521 | 106 | 7 | 2,200 |
| ES90 Plus Single Motor Extended Range | 88,880 | RWD | 245 / 480 | 6.6 | 554 | 92 | 5 | 1,600 |
| ES90 Ultra Single Motor Extended Range | 104,222 | RWD | 245 / 480 | 6.6 | 554 | 92 | 5 | 1,600 |

All current rows are 800 V with 11 kW onboard AC. AU specs explicitly call battery energy nominal; do not relabel it usable or gross. Range is explicitly preliminary with vehicle certification pending, which warrants Check beyond the standing laboratory caveat. Trailer limits are named maximum trailer weight by AU maker; braked classification is supported by corresponding overseas/AU-secondary data, with installed towing equipment still requiring confirmation.

### Pricing

The four actual selected-grade figures above were observed, not synthesized from price deltas. The configurator displays each both under a recommended driveaway heading and an MLP including GST breakdown. Without localization, LCT and on-road treatment are unresolved: retain rung 3, Check and unranked. The general driveaway disclaimer assumes a postcode, private owner aged40, premium licence plate, good driving record,12months registration/CTP and other location-specific charges. No location was submitted in these captures.

CarExpert reports MY27 EX90 Plus106990 and Ultra134990 beforeORC; this corroborates trim-year names and price-tax ambiguity but does not override the higher-rung maker configuration. The ES9088880/107990 launch report is MY26, not independent MY27 MSRP evidence.

### Charging and battery basis

- AU current EX90 specifies24minutes,10–80%,300kW DC station for both powertrains
- AU current ES90 specifies22minutes,10–80%,300kW DC station. Launch article additionally specifies500A
- These300kW numbers identify charging stations, not explicit vehicle peak acceptance
- Exact-MY27 official Denmark PDFs now linked from Volvo Denmark's price-list page specify310kW DC for the92kWh Single and350kW for106kWh Twin, at800V. Use Reported overseas sibling values: EX90Plus310,EX90Ultra350,ES90both310. Same-MY mapping is supported by245/500kW,480/870Nm,6.8/4.2 or6.6sec,800V and nominal pack
- Those MY27 PDFs specify90kWh usable for92nominal and103usable for106nominal. Keep as supplemental Reported sibling values, not manufacturer-confirmed Australian usable capacities
- Older Germany MY26 EX90 article said300kW Single,350Twin. It is not the preferred MY27Single figure. MY26 global ES90 sheet explicitly identifies310kW peak and88usable; AU CarExpert reports300kW, so retain conflict
- Danish price validity is Jan–Dec2027; PDFs were publicly linked in October2026 and explicitly MY27. Foreign prices, range, trim equipment and warranties have not been transferred

### Dimensions and cargo

EX90:5037mm length,1964mm body width,1744mm height at curb weight with one person,2985mm wheelbase. Mirrors folded2039/extended2113. Rear open cargo third-row-up324L; max third-row-up384L. Second-row-up open697/max1057. Folded open1316/max2135. Frunk46; closed compartments72. Do not sum these or interchange open/max.

ES90:5000mm length,1942mm body width,1549mm height at curb weight with one person,3102mm wheelbase. Mirrors folded2054/extended2120. Current live rear open cargo442L; max464L; folded open922/max1445. Frunk27; closed compartments34. Earlier cached text on the same AU URL retained424/446/1427, so use the freshly captured current page for MY27. Neither AU current cargo page names a VDA/SAE protocol: retain measurement labels and leave comparison blank; maker cargo/height values are Confirmed.

### Current equipment distinctions

EX90 Plus configurator highlights Bose,HUD,Pilot Assist,BLIS,360camera3D,advanced sensing/driver recognising,four-zone,air purifier,14.5inch screen,Google built-in and power4-way lumbar. Default20inch wheels/Nordico. Ultra explicitly adds electrochromic roof,ventilation,front massage,soft-close,active chassis/air suspension,HD Pixel lights and Bowers & Wilkins; default22inch wheels and selected ventilated Nappa. Material, ventilation and wheel alternatives remain configuration-specific.

ES90 Plus highlights Bose,HUD,360camera3D,ambient lighting,air purifier,advanced sensing/driver recognising and four-zone. Default20inch and Nordico;21inch option shown. Ultra highlights electrochromic roof,Bowers & Wilkins,ventilated seats,air suspension andHD Pixel lights; default22inch. Upholstery selections specify front/rear ventilation differently, so do not generalize every seat-material feature to every configuration.

The family specifications list Digital Key Plus,heated seats/steering,phone integration and other equipment but its dynamic inclusion grid is not exposed by the plain capture. Such family-only rows remain Check, rather than all listed items becoming standard. Exact configurator highlighted features are confirmed. Google Maps charging route planning/preconditioning is documented on the AU model pages. Current AU catalogue explicitly names wireless Apple CarPlay and Android Auto; this differs from older launch lists that mentioned only Apple CarPlay.

## Genuine residual-new MY2026 versions

| Version | Selected reported beforeORC AUD | kW / Nm | 0–100 s | Battery / WLTP | New evidence |
|---|---:|---|---:|---|---|
| EX90 Plus Twin Motor AWD |124990|330 /670|5.5|106kWh /521km|Castle Hill V060279, VIN YV1TFDBC8TB060279; New; builtDec2025,complianceApr2026;133990DA NSW|
| EX90 Ultra Twin Motor Performance AWD |134990|500 /870|4.2|106kWh /521km|Cricks Highway HL2612; New; builtMay2026;147990DA QLD; Carsales OAG-AD-26082007|
| ES90 Plus Single Motor RWD |88880|245 /480|6.6|92kWh /554km|Castle Hill VB003360; New MY26; detail builtDec2025;88890DA NSW; OAG-AD-25853559|
| ES90 Ultra Single Motor RWD |107990|245 /480|6.6|92kWh /554km|Parramatta13130579;New MY26;builtDec2025,complianceFeb2026;116888DA NSW aggregate; OAG-AD-25626574|

MY26 ads use Single Motor for ES90; the matched overseas technical sibling is called Single Motor Extended Range. Do not add build2025 listings as separate MY25 variants. MY26 price selections are rung5 secondary list beforeORC, with named dealer rung6 alternatives retained separately. ES90Plus aggregate cached list had97408/January2026 while later detail has88890/December2025: prefer detailed ad and keep discrepancy disclosed.

MY26 EX90 dimensions5037x1964x1744,7seats,2200braked/750unbraked,minimum rear cargo384/max2135. Exact-year secondary figures are Reported. Castle Hill dealer repeats old5.9sec for Plus; exactMY26 Carsales and CarExpert say5.5, which is preferred. Do not transfer MY25 111kWh/400V/250kW/30min figures to these106kWh800V MY26 cars.

MY26 ES90 dimensions5000x1942 body width; Carsales height1554 versus CarExpert1550. Carsales2120 width is labelled excluding mirrors incorrectly; it is mirror-extended dimension, so retain1942body. Five seats,1600braked/750unbraked. Cargo minimum424/max1427 from exact-version AU database; CarExpert446upright is a different loading envelope. Overseas same-MY maker specification distinguishes424upper-seatback/446roof. Current MY27442/464/1445 is not transferred.

MY26 Australian support charging pages explicitly provide22minutes10–80 at350kW high-voltage station, battery around35°C, and24minutes at300kW. ES90 launch and global Single sheet instead give22minutes300kW/500A. Core22 is retained with the exact350station manual basis; EX90 is Confirmed and ES90 retains Check for the conflicting Single Motor scope; no station-to-vehicle-peak inference. EX90 peak350 is Reported from matchingMY26 maker architecture plus AU CarExpert outgoingPlus; ES90peak310/usable88 is Reported from maker-authoredMY26 global sheet. All AC11kW.

MY26 ES90 Plus launch equipment:20inch,Bose14speaker,Nordico,fixed roof,heated steering/front seats,Google built-in,wirelessCarPlay,HUD,four-zone,heatpump,DigitalKeyPlus. Ultra:22inch,air suspension,PixelLED,electrochromic roof,B&W25speaker1610W,ventilated Nordico/Nappa,front massage,ventilation,rear electric recline/lounge armrest. Optional Plus roof/audio/ventilated upholstery are not standard. EX90 exact stock lists20inch/Bose/Nordico forPlus;Ultra22inch25speaker,air suspension,ventilated/massaging fronts. MY27Nappa update is not silently transferred toMY26.

## Completeness and excluded leads

Official AU MY27 model/configurator pages expose only the four current versions above. A public New inventory sweep found MY26 Plus/Ultra for each family plus currentMY27EX90Ultra; additional ads repeat existing versions. No credible MY25EX90 New version was established. Parramatta's MY25Plus brand-new prose is classified Demo; XciteAutos' MY25 listing heading saysNew/IN STOCK but conditionDemo and registrationYSU00M, so both are excluded. URLs: https://volvocarsparramatta.com.au/new-demo-used-cars/?makes=Volvo&models=EX90 and https://xciteautos.com.au/cars/volvo-ex90-22010843664 . No accounts, contact forms, orders or dealer messages were submitted.

## Capture hygiene

Runtime token,longToken/session/CSRF fields and JWT strings were redacted before decoding public configurator RSC; source hashes refer to sanitized copies. No headers,cookies or browser screenshots were saved. Model/PNO/configuration/stock/VIN identifiers are public factual data and retained. Public static PDFs contain no session data. Failed preliminary fetch artifacts are not used in the source index. `sanitization-audit.json` records the final scan.

## Final integration refinements

Maker cargo, maximum cargo and loading-qualified heights are Confirmed, with the measurement scope retained in basis/qualifications and comparison blank. Maker exact-window charging is Confirmed with station/laboratory qualifications; MY26 ES90 retains a specific scope conflict condition. Every remaining Check has an explicit condition. MY27 braked towing is Reported with separate captured explicit-braked sources: exact Australian CarExpert Plus/Ultra rows for EX90, and maker-authored MY27 Italian Single Motor technical table for ES90. Source-side stale250kW charging and3year warranty fields are not adopted.

Features use actual catalogue criteria screens_hud, audio_system and glass_roof. Wheel, suspension, climate-only and other unmatched hardware facts remain factual-only rather than inventing criteria. Current default selected wheels are Confirmed with base-configuration qualification. MY26 Ultra EX90 heating from Carsales is Reported; rear-row placement remains qualified. All eight variants have fact-bound strength/tradeoff summaries. Historical MY26 ES90 prices are held in historicalPriceContext, not currentMY27 alternativePrices.

## Localized NSW2000 follow-up (same research date)

All four new dot-cloud tabs now visibly show Sydney NSW2000,Australia after selecting the actual public autocomplete suggestion and applying it. Visible-body-only captures contain expanded price breakdowns; no quote URLs or runtime tokens were saved. No contact, order or quote request was submitted.

| MY27 selected configuration | MLP inclGST, excluding separate charges | Delivery | Separate LCT | Stamp duty | Registration | Observed estimated DA |
|---|---:|---:|---:|---:|---:|---:|
| EX90PlusSingle |103453|5995|5336|4840|1501|121125|
| EX90UltraTMP |124991|5995|11798|6240|1501|150525|
| ES90PlusSMER |88880|2495|No row|3670|1237|96282|
| ES90UltraSMER |104222|4995|5267|4825|1237|120546|

These are actual displayed amounts, not recalculated totals; independently rounded components can differ by a dollar. Price assumptions include private40-year-old owner, good driving record,premium licence plate,12months registration/CTP and purchase/garaging in reference postcode. Comprehensive insurance/wallbox excluded; final retailer price may differ. Original MLP tax scope is now clarified as excluding separately itemised applicable LCT and on-road fees. Retain rung3 configuration MLP Check/unranked and rung4 localizedDA alternative rather than inventing an LCT-inclusive list number.

MY26 ES90 height correction: exact Australian secondaryUltra1554mm is retained as Reported, with explicit conflicting same-MY maker overseasRWD air-suspension1547mm curb/1545mm curb+one-person. Plus coil-suspension overseas values1554/1550 explain its loading distinction;1550 is not merely rounding. Do not imply Plus and Ultra have identical height.

Final pricing hierarchy clarification: MY27 ES90Plus localized MLP88880 has noLCT row and separately itemized on-road costs, so use rung1 Confirmed beforeORC for the observed base configuration. The other three retain rung3 Check/unranked with explicit separate-LCT scope and their NSW rung4 driveaway alternatives.
