import pathlib,re,json,hashlib
R=pathlib.Path('/tmp/volvo-research/large')
for p in R.glob('*.html'):
 s=p.read_text();count=0
 for pattern in [r'(?i)((?:token|longToken|sessionId|session_id|csrfToken)(?:\\?"|\x27)?\s*:\s*(?:\\?"|\x27))[^"\x27\\\n]+',r'eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+']:
  s,n=re.subn(pattern,lambda m:(m[1] if m.lastindex else '')+'[REDACTED]',s);count+=n
 p.write_text(s)
 meta=json.load(open(p.with_suffix('.capture.json')));meta['supplementaryRedactions']=count;meta['rawFactualSha256']=hashlib.sha256(s.encode()).hexdigest();p.with_suffix('.capture.json').write_text(json.dumps(meta,indent=2))
 chunks=[]
 for m in re.finditer(r'<script>self\.__next_f\.push\((.*?)\)</script>',s):
  try:a=json.loads(m[1]);chunks.extend(x for x in a if isinstance(x,str))
  except Exception as e: print(str(e)[:200])
 if chunks:
  txt='\n'.join(chunks);p.with_name(p.stem+'-rsc.txt').write_text(txt);print(p.name,len(txt),'redacted',count)
