import json,pathlib,hashlib,re,collections
R=pathlib.Path('/tmp/volvo-research');D='2026-10-14';REPO=pathlib.Path('/workspace/scratch/586427eef9f2/roadmark-104');load=lambda p:json.loads((R/p).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=load('volvo-2026-10-14.json');e=load('volvo-effective-facts.json');src={s['id']:s for s in p['sources']};norm=load('normalized-evidence.json');prior={c['id']:c for c in load('volvo-live-before.json')}
core=['price_aud','range_km','battery_kwh','dc_peak_kw','dc_charge_time_min','ac_kw','seats','boot_l','zero_to_100_s','power_kw','drive','length_mm','width_mm','height_mm','towing_braked_kg','warranty','battery_warranty'];rows=[]
for c in norm['variants']:
 fs={}
 for k in core:
  f=e[c['id']][k];fs[k]={x:f.get(x) for x in ['value','unit','basis','comparisonBasis','status','buyerGrade','conditionExplanation','qualifications','date','validUntil']};fs[k].update(reviewReason=f['gradeReview']['reason'],sourceIds=f['sourceIds'],sourceUrls=[src[x]['url'] for x in f['sourceIds']])
 rows.append(dict(variantId=c['id'],model=c['model'],trim=c['trim'],modelYear=c['modelYear'],availability=c['availability'],fields=fs))
(R/'core-matrix.json').write_text(json.dumps(dict(checkedAt=D,coreFieldCount=17,cells=len(rows)*17,rows=rows),indent=2,ensure_ascii=False)+'\n')
for s in p['sources']:
 for l,h in [('capture_locator','capture_sha256'),('capture_text_locator','capture_text_sha256')]:
  if s.get(l):assert sha(R/s[l])==s[h],s['id']
(R/'source-index.json').write_text(json.dumps(dict(checkedAt=D,scope='Volvo Australian Tier1 BEV observations; full brand-only directories are separate from whole-market C1 lists.',sources=p['sources']),indent=2,ensure_ascii=False)+'\n')
captures=[];findings=[];pats=[r'eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]+',r'(?im)^(?:set-cookie|cookie)\s*:',r'(?i)(?:csrf[_-]?token|client_secret|access_token|refresh_token)(?:\\?"|\x27)?\s*[:=]\s*(?:\\?"|\x27)(?!\[REDACTED\])[^"\x27\n]+']
for d in ['compact','large','current','terms','census']:
 for f in sorted((R/d).rglob('*')):
  if not f.is_file() or '__pycache__' in f.parts:continue
  rel=str(f.relative_to(R));captures.append(dict(path=rel,bytes=f.stat().st_size,sha256=sha(f)))
  if f.suffix in ['.txt','.json','.html']:
   t=f.read_text(errors='replace');n=sum(len(re.findall(pat,t)) for pat in pats)
   if n:findings.append(dict(path=rel,matches=n))
assert not findings,findings
red=dict(checkedAt=D,policy='Durable evidence excludes headers, cookies, runtime quote/session/JWT/CSRF/client secrets. Public URLs, ordinary model/configuration/stock IDs and facts retained.',scannedFiles=len(captures),detectedSensitiveCaptureValues=0,notes=['Current capture helper removed escaped and plain runtime token keys plus JWTs. Additional initial HTML redactions are recorded in current/additional-redactions.json.','Family-only visible-text and whitelisted product captures exclude runtime data. Local technical-PDF renders were used for column verification and are not browser screenshots.','Source-level capture hashes always refer to the final sanitized factual snapshot. Original transport metadata may identify a pre-final-redaction byte hash; source index and this manifest are authoritative final-byte hashes.'],familyRedactionLogs=[str(f.relative_to(R))for f in R.rglob('*redact*') if f.is_file() and f.parent!=R]+[str(f.relative_to(R))for f in R.rglob('*sanitization*') if f.is_file()])
(R/'redaction-audit.json').write_text(json.dumps(red,indent=2)+'\n');(R/'source-hash-manifest.json').write_text(json.dumps(dict(checkedAt=D,files=captures),indent=2,ensure_ascii=False)+'\n')
retained=[]
for id,c in prior.items():
 for k,f in c['facts'].items():
  if f['value'] is not None and k not in e[id]:retained.append(dict(variantId=id,key=k,value=f['value'],date=f['date'],reason='Unchanged historical observation with original source/date/qualification; not counted as a fresh review. Canonical core and explicitly updated equipment/factual aliases are reviewed in the dated packet.'))
allf=[f for x in e.values() for f in x.values()];assert all(all(s in src for s in f['sourceIds'])for f in allf)
assert all(f['value'] is None and len(set(src[s]['url'].split('#')[0]for s in f['sourceIds']))>=2 for f in allf if f['buyerGrade']=='not_published')
old=load('immutable-data-before.json');authorizedRegistration=[]
for file,h in old.items():
 if sha(REPO/file)==h:continue
 assert file=='data/m1-brand-updates/registry.json',file
 assert load('integration-readiness.json').get('packetApprovedForGuardedIntegration'),'Registry changed without approval'
 reg=json.loads((REPO/file).read_text());assert reg['packets'][-1]=='volvo-2026-10-14.json'
 reg['packets'].pop();assert hashlib.sha256((json.dumps(reg,indent=2)+'\n').encode()).hexdigest()==h
 authorizedRegistration.append(dict(path=file,previousSha256=h,currentSha256=sha(REPO/file),reason='Root appended the independently approved Volvo packet at 08:54 UTC. Removing exactly that append restores the original bytes. Research worker did not edit the registry.'))
checks=dict(checkedAt=D,originalDataFilesUnchanged=len(old)-len(authorizedRegistration),authorizedRootRegistrationChanges=authorizedRegistration,totalReviewedVersions=len(rows),onSaleVersions=sum(r['availability']['state']=='current_or_order_listed' or r['availability']['state']=='outgoing' and r['availability'].get('stockStatus')=='new_stock_listed' for r in rows),provisionalVersions=sum(r['availability']['state']=='announced_provisional'for r in rows),newVersions=len(p['variants']),coreCells=len(rows)*17,coreGradeCounts=dict(collections.Counter(v[k]['buyerGrade']for v in e.values()for k in core)),allReviewedFactCount=len(allf),guardedFactEdits=len(p['facts']),brandTerms=len(p['brandTerms']),guardedEquipmentRows=len(p['features']),summaries=len(p['summaries']),retainedHistoricalObservations=retained,sourceSnapshots=len(p['sources']),captureFiles=len(captures),allLocallyCapturedSourceHashesMatch=True,allNegativeFactsHaveTwoUsableUrls=True,registeredByResearchTask=False,registeredByRoot=bool(authorizedRegistration),openScope=['Two stale MY25 EX30 New leads; MY26 Plus advertised-year/VIN conflict','EC40/C40/XC40 Recharge residual supply','EX60 current maker Coming2027 versus historical secondary2026 timing; actual accepted orders unverified'],presentationLimitations=['Year-only Coming2027 remains in exact availability qualifications; arrival parser only recognizes month/quarter, so no invented month/quarter is supplied.'])
(R/'evidence-completeness-audit.json').write_text(json.dumps(checks,indent=2,ensure_ascii=False)+'\n')
files=[dict(path=f.name,bytes=f.stat().st_size,sha256=sha(f))for f in sorted(R.iterdir())if f.is_file() and f.name!='artifact-hash-manifest.json'];(R/'artifact-hash-manifest.json').write_text(json.dumps(dict(checkedAt=D,files=files),indent=2)+'\n')
print(json.dumps({k:v for k,v in checks.items() if k!='retainedHistoricalObservations'},indent=2))
