from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urljoin,urlsplit,urlunsplit
import json,hashlib,re
R=Path('/tmp/volvo-research');D='2026-10-14'
def dump(p,d): (R/p).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads((R/p).read_text())
terms={
'warranty':{
'value':'5 years / unlimited km','grade':'confirmed','status':'standard','fitment':'standard','sourceKeys':['terms_volvo_warranty'],'basis':'Australian new passenger vehicle warranty; ordinary private-use baseline','comparison':'','years':5,'kilometres':None,'unlimitedKilometres':True,'checkedAt':D,
'reason':'Current Volvo Australia terms provide five years with unlimited kilometres for eligible private-use new passenger vehicles. The separate commercial-use limit is preserved without downgrading the private-buyer baseline.',
'locator':'terms/warranty.txt lines 65–85, New Car Warranty and Volvo Terms and Conditions; lines 100–134, conditions and exclusions',
'qualifications':[
'Applies to new Volvo passenger vehicles with a retail sale date on or after 1 April 2020, purchased and operated in Australia. Cover runs from first registration and follows the vehicle on sale; a later purchase does not restart the period.',
'Commercial purposes, including but not limited to hire cars, rental vehicles, taxis and transporting goods or people for payment, have a five-year / 150,000 km limit, whichever occurs first.',
'The same page later warns that hire or reward, competition or driver training/instruction may void cover. Commercial-use customers should obtain the applicable written terms; do not promise that the mileage exception removes this qualification.',
'Manufacturing/material defects are covered subject to prescribed maintenance, operating instructions and claim conditions. Normal wear, inadequate maintenance, accident/neglect damage, unauthorised modifications and written-off vehicles are excluded as stated. Australian Consumer Law rights remain.',
'The warranty page contains a generic 15,000 km / 12-month service reference and also says precise service content varies by model. Do not infer a model-specific BEV service interval from this brand warranty page.'
],
'useSpecificLimits':[{'uses':['commercial purposes','hire car','rental vehicle','taxi','transporting goods for payment','transporting people for payment'],'years':5,'kilometres':150000,'whicheverFirst':True,'scopeIsNonExhaustive':True}]
},
'battery_warranty':{
'value':'8 years / 160,000 km; below 70% capacity threshold','grade':'confirmed','status':'standard','fitment':'standard','sourceKeys':['terms_volvo_warranty','terms_volvo_battery'],'basis':'Australian BEV high-voltage lithium-ion battery warranty; original specified capacity','comparison':'','years':8,'kilometres':160000,'capacityThresholdPercent':70,'capacityTriggerOperator':'below','whicheverFirst':True,'checkedAt':D,
'reason':'Current Australian maker warranty and battery pages explicitly provide eight years or 160,000 km, whichever first, and repair or replacement if capacity falls below 70% of its original specification during that period.',
'locator':'terms/warranty.txt lines 87–99, Hybrid and High Voltage Battery Warranty; terms/battery.txt lines 98–101 and 123–125',
'qualifications':[
'The eight-year / 160,000 km term is separate from the 12-volt battery warranty, which the same page limits to three years.',
'Covered faults include battery material/workmanship defects and deviations in battery performance. Natural ageing alone is not a promise of full capacity: the published capacity trigger is below 70% of original specification.',
'Repair may use individual cells or a complete reconditioned battery. The terms say capacity will be the same or better than before the problem occurred; they do not promise restoration to 100%.',
'Battery-care and long-term-parking instructions apply. Negligence or failure to follow the owner manual is excluded, together with applicable general warranty conditions.',
'The battery education page separately describes minimum four-year / 80,000 km parts cover on refurbished batteries purchased outside the original warranty. This is not an automatic extension of new-vehicle battery cover.',
'No Australian EX60-specific ten-year / 240,000 km extension terms are established by these captures. Keep the Australian eight-year baseline; any separately reported extension needs its own evidence, applicability and qualification.'
],
'remedy':{'mayUseReconditionedCellsOrBattery':True,'restorationBasis':'same or better capacity compared with before the problem occurred','restorationTo100PercentPromised':False}
},
'roadside_assistance':{
'value':'5 years included','grade':'confirmed','status':'standard','fitment':'standard','roadsideFitment':'standard','sourceKeys':['terms_volvo_roadside_policy','terms_volvo_roadside_service'],'basis':'Volvo Assistance for new vehicles sold and registered from 1 January 2024; policy limits apply','comparison':'','includedGeneralRoadsideYears':5,'includedMonths':60,'checkedAt':D,
'reason':'The current Australian assistance overview and policy explicitly give five complimentary years for new vehicles sold from 1 January 2024. The eight-year period on the same policy is historical eligibility for 2021–2023 registrations, not the current-new baseline.',
'locator':'terms/roadside.txt lines 64–67 and 166–169, current period and Purchase Information; lines 85–169, benefits and limits; terms/roadside-service.txt lines 62–92',
'qualifications':[
'The policy opening says new vehicles sold from 1 January 2024; Purchase Information specifies sold and registered from that date. Check the original sale/registration cohort for an already-registered demonstrator.',
'Historical eligibility: vehicles sold and registered 1 April 2021–31 December 2023 received eight years; 1 April 2018–31 March 2021 received five years. Do not inherit eight years into current new-car facts.',
'Taxis are excluded from included services and may receive assistance at the driver’s expense. Do not conflate this with the separate commercial vehicle-warranty mileage limit.',
'Included towing applies only below 3,500 kg GVM at breakdown. At or above that threshold towing is at the driver’s expense. Standard destination is the nearest authorised Volvo retailer; a preferred retailer is permitted within 50 km of that nearest retailer, with additional costs borne by the driver.',
'Customer support services for qualifying mechanical disablement more than 100 km from the owner’s registered home and longer than 24 hours cover the driver and up to four passengers. This is not guaranteed support for every occupant of a seven-seat EX90.',
'The full policy provides up to three nights’ accommodation for the specified away-from-home event, handled case by case, and discretionary driver-mobility arrangements. The overview also describes rental-car/alternative-transport options; do not turn these into unconditional fixed entitlements.',
'Flat-tyre help uses a serviceable compatible spare. If a maintained supplied repair kit cannot make a temporary repair, towing to a tyre repairer or retailer is at Volvo’s expense; missing/unmaintained equipment and multiple tyre damage may be excluded.',
'Collision/insurance events, unattended vehicles, specified unsafe/unlawful use and other policy exclusions apply. AWD off-road assistance is limited to one claim a year on a legally trafficable road meeting the stated conditions.',
'The captured policy does not expressly promise traction-battery out-of-charge recovery; its out-of-fuel section describes liquid fuel. Do not manufacture an unlimited EV out-of-charge towing entitlement.'
],
'eligibilityPeriods':[{'soldAndRegisteredFrom':'2024-01-01','soldAndRegisteredThrough':None,'includedYears':5},{'soldAndRegisteredFrom':'2021-04-01','soldAndRegisteredThrough':'2023-12-31','includedYears':8},{'soldAndRegisteredFrom':'2018-04-01','soldAndRegisteredThrough':'2021-03-31','includedYears':5}],
'benefitLimits':{'taxiUseExcluded':True,'includedTowingGvmKgExclusiveMaximum':3500,'preferredRetailerKmFromNearestMaximum':50,'customerSupportMinimumDistanceFromHomeKmExclusive':100,'customerSupportMinimumDisablementHoursExclusive':24,'customerSupportDriverIncluded':True,'customerSupportAdditionalPassengersMaximum':4,'accommodationNightsMaximum':3,'awdOffRoadClaimsPerYearMaximum':1}
}}
dump('terms-normalized.json',terms)
termSources=[]
for stem,key,title in [('warranty','terms_volvo_warranty','Volvo Australia new vehicle and battery warranty terms'),('battery','terms_volvo_battery','Volvo Australia electric-car battery coverage'),('roadside','terms_volvo_roadside_policy','Volvo Australia Assistance Policy'),('roadside-service','terms_volvo_roadside_service','Volvo Australia Assistance service overview')]:
 m=load('terms/'+stem+'.capture.json');p=R/'terms'/stem
 termSources.append({'id':key,'key':key,'title':title,'url':m['url'],'checkedAt':D,'captureDate':D,'sourceType':'manufacturer','publisher':'Volvo Cars Australia','captureFile':stem+'.capture.json','textFile':stem+'.txt','captureSha256':sha(p.with_suffix('.capture.json')),'textSha256':sha(p.with_suffix('.txt')),'factualHtmlFile':stem+'.html','factualHtmlSha256':sha(p.with_suffix('.html')),'captureReportedFactualSha256':m['rawFactualSha256'],'curlExit':m['curlExit'],'httpStatus':None,'httpStatusNote':'Original capture recorded successful curl transport, not an HTTP status. Do not invent 200.','sanitization':'Public visible text and factual source metadata only in normalized outputs. No HTTP headers, cookies, account data or authentication values copied.'})
dump('terms/source-index.json',termSources)
class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.h=None;self.t=[]
 def handle_starttag(self,t,a):
  if t=='a':self.h=dict(a).get('href');self.t=[]
 def handle_endtag(self,t):
  if t=='a' and self.h is not None:self.links.append((' '.join(' '.join(self.t).split()),self.h));self.h=None
 def handle_data(self,d):
  if self.h is not None:self.t.append(d)
def links(stem):
 p=Links();p.feed((R/'census'/f'{stem}.html').read_text());return p.links
sources=[];bykey={}
def source(key,title,path,url=None):
 p=R/path;meta=p.with_suffix('.capture.json');m=json.loads(meta.read_text()) if meta.exists() else {}
 u=url or m['url'];row={'id':key,'key':key,'title':title,'url':u,'checkedAt':D,'textFile':str(p.relative_to(R/'census')) if p.is_relative_to(R/'census') else '../'+str(p.relative_to(R)),'textSha256':sha(p),'textBytes':p.stat().st_size,'sourceType':'manufacturer' if 'volvocars.com/' in u else 'dealer' if 'berwick' in u else 'secondary','captureScope':'Public factual page text; availability limited to statements in this source, not physical stock verification.'}
 if meta.exists():row.update({'captureFile':meta.name if meta.parent==R/'census' else '../'+str(meta.relative_to(R)),'captureSha256':sha(meta),'curlExit':m.get('curlExit'),'captureReportedFactualSha256':m.get('rawFactualSha256'),'httpStatus':None,'httpStatusNote':'Original capture does not record HTTP status; transport success alone is not an HTTP 200 assertion.'})
 sources.append(row);bykey[key]=row;return key
ce=source('census_carexpert_directory','CarExpert Volvo brand directory','census/carexpert.txt')
cg=source('census_carsguide_directory','CarsGuide Volvo brand directory','census/carsguide.txt')
maker=source('census_volvo_current_range','Volvo Australia current range navigation','census/maker-range.txt')
legacy=source('census_volvo_legacy_models','Volvo Australia legacy models; supporting historical powertrain/body evidence','census/maker-legacy.txt')
v60=source('census_carsguide_v60','CarsGuide Volvo V60 motor and body description','census/carsguide-v60.txt')
s60=source('census_carsguide_s60','CarsGuide Volvo S60 motor and body description','census/carsguide-s60.txt')
ex60=source('census_volvo_ex60_overview','Volvo Australia EX60 current overview','current/ex60-overview.txt')
zex60=source('census_zecar_ex60_may2026','Zecar EX60 May 2026 order and delivery report','current/ex60-zecar.txt')
compactIndex=load('compact/source-index.json')
for stem,key,title in [('ex30-build','census_volvo_ex30_build','Volvo Australia EX30 current configurator'),('ex40-build','census_volvo_ex40_build','Volvo Australia EX40 current configurator'),('ex30-cc-browser-nsw2000','census_volvo_ex30_cross_country_selected','Volvo Australia EX30 Cross Country selected current configurator'),('ec40-build','census_volvo_ec40_build','Volvo Australia EC40 unavailable configuration route'),('berwick-c40-my24','census_berwick_c40_sold','Volvo Cars Berwick C40 stock 11048122 sold advertisement')]:source(key,title,'compact/'+stem+'.txt',compactIndex[stem])
li=load('large/source-index.json')
for stem in ['ex90-config','ex90-ultra-config','es90-config','es90-ultra-config']:
 item=next(i for i in li if i['key']=='large_'+stem)
 source('census_volvo_'+stem.replace('-','_'),'Volvo Australia '+stem+' current configurator','large/'+stem+'.txt',item['url'])
def ev(key,loc,claim):return {'sourceKey':key,'sourceUrl':bykey[key]['url'],'textLocator':loc,'claim':claim}
def disposition(name):
 n=name.upper();r={'catalogueFamilies':[],'unresolvedScope':[]}
 if n in ['ES90','EX30','EX40','EX90']:
  r.update(disposition='included_current_maker_bev_family_residual_scope_open',catalogueFamilies=['volvo-'+n.lower()],reason='Current Australian maker range and named configurations establish this battery-electric family. Exact MY27 configurations are listed separately; older residual-New model years are not closed by the directory.',supportingEvidence=[ev(maker,'maker-range.txt lines 18–44','Maker navigation places this family in the Electric group')],unresolvedScope=['Complete residual-New MY26/MY25 version membership is a separate review; do not infer absence from current MY27 configuration menus.'])
  if n=='EX30':r['reason']+=' EX30 Cross Country is separately identified by the maker configuration, although neither publisher gives it a standalone model-directory entry.';r['supportingEvidence'].append(ev('census_volvo_ex30_cross_country_selected','../compact/ex30-cc-browser-nsw2000.txt lines 24–54','EX30 Cross Country, Ultra and P8 AWD Electric are explicitly named'))
 elif n=='EX60':
  r.update(disposition='provisional_bev_arrival_and_order_timing_conflict',catalogueFamilies=['volvo-ex60'],reason='Maker navigation includes EX60 and the current overview names MY2027 with Coming 2027. Zecar’s 21 May 2026 report says orders opened with final-quarter-2026 deliveries. Preserve the newer maker timing and the older reported order-opening evidence; a configurator is not proof of accepted orders or arrival.',supportingEvidence=[ev(ex60,'../current/ex60-overview.txt lines 62–82','Australian model overview says Coming 2027, Electric, SUV and model year 2027'),ev(zex60,'../current/ex60-zecar.txt lines 13–32','Report dated 21 May 2026 states P6 Ultra and P10 Ultra orders open and expected Q4 2026 deliveries')],unresolvedScope=['Current order acceptance and delivery timing are not verified. Do not classify on-sale-now from either directory status or configurator existence.'])
 elif n in ['C40','EC40']:
  r.update(disposition='unresolved_residual_new_bev_nameplate',catalogueFamilies=['volvo-c40','volvo-ec40'],reason='Publisher directory status is not sufficient to settle residual-New Australian supply. The current EC40 build route is unavailable; the examined Berwick C40 advertisement retains New in its title but explicitly says SOLD. That exact sold advertisement is excluded, while the whole-family residual question remains open.',supportingEvidence=[ev('census_volvo_ec40_build','../compact/ec40-build.txt; unavailability message near beginning of page body','EC40 configuration route does not provide a current selectable EC40'),ev('census_berwick_c40_sold','../compact/berwick-c40-my24.txt lines 304–317','C40 Recharge Twin stock 11048122 explicitly marked SOLD despite New title')],unresolvedScope=['No current unsold, exact residual-New C40/EC40 version is established by the evidence in this census. This is not a proof that no residual-new supply exists.'])
 elif n=='XC40':
  r.update(disposition='current_non_bev_subset_excluded_historical_bev_alias_unresolved',catalogueFamilies=['volvo-ex40'],reason='Current maker XC40 is in Mild hybrids (petrol), while EX40 is separately Electric. CarsGuide nevertheless tags XC40 Electric, and CarExpert’s captured reviews identify the former XC40 Recharge electric model and its name change. Exclude the current mild-hybrid XC40 from BEV scope; retain historical XC40 Recharge residual-New scope without treating it as an extra current MY27 EX40 version.',supportingEvidence=[ev(maker,'maker-range.txt lines 18–44','XC40 is in the Mild hybrids (petrol) navigation group; EX40 is Electric'),ev(cg,'carsguide.txt lines 182–186','XC40 current card carries Electric tag'),ev(ce,'carexpert.txt; Volvo reviews, 2024 XC40 Recharge review and 2024 XC40 Recharge Twin review','Directory review descriptions identify older electric XC40 Recharge and an impending name change')],unresolvedScope=['Residual-New XC40 Recharge Single/Twin exact models and model years are not established or excluded by current range-menu absence.'])
 elif n in ['XC60','XC90']:
  r.update(disposition='excluded_current_non_bev_offering',reason=f'Current maker {n} is listed under Plug-in hybrids and Mild hybrids (petrol), with the fully electric family separately named. These documented current hybrid offerings are outside BEV scope; no conclusion about every historical derivative is needed.',supportingEvidence=[ev(maker,'maker-range.txt lines 18–44',f'{n} is listed in the two hybrid groups, not the Electric group')])
 elif n in ['S60','V60']:
  key=s60 if n=='S60' else v60
  r.update(disposition='excluded_documented_non_bev_offering_directory_currency_difference',reason=f'CarsGuide’s {n} motor/fuel description establishes a combustion-based offering: '+('2.0-litre turbo mild-hybrid petrol sedan; its material also discusses a plug-in hybrid' if n=='S60' else '2.0-litre turbo-petrol wagon with PULP fuel and a 48 V mild-hybrid description')+'. CarsGuide treats the directory card as current while CarExpert marks it discontinued. Resolving remaining non-BEV stock is outside this BEV census.',supportingEvidence=[ev(key,'carsguide-s60.txt lines 126–135 and 400–482' if n=='S60' else 'carsguide-v60.txt lines 128–136 and 575–580','Documented engine and fuel type are combustion-based, not a battery-only vehicle'),ev(ce,'carexpert.txt lines 55–62','Publisher marks this model discontinued')])
 elif n=='C30':
  r.update(disposition='historical_bev_capable_nameplate_no_current_new_claim',reason='CarsGuide places C30 among older models. Volvo’s legacy page explicitly lists the 2006–2012 C30 with Electric, Petrol and Diesel, so it cannot be blanket-labelled a non-BEV. This historical global heritage entry supplies no current Australian private-buyer new-order evidence.',supportingEvidence=[ev(legacy,'maker-legacy.txt lines 87–95','C30 legacy model, production 2006–2012, with Electric/Petrol/Diesel listed')],unresolvedScope=['Australian original electric availability and any present residual-New supply are not established by these directory/heritage sources; no current admission or whole-history exclusion is claimed.'])
 elif n in ['CROSS COUNTRY','CX30','122']:
  r.update(disposition='historical_directory_label_identity_not_resolved',reason='CarsGuide lists this exact label among older models, but this directory entry alone does not establish an exact current Australian battery-electric vehicle. '+('Do not silently map the generic Cross Country label to the current EX30 Cross Country; that current body is separately evidenced.' if n=='CROSS COUNTRY' else 'Do not silently correct or expand this label to a different model or assumed alias.'),supportingEvidence=[],unresolvedScope=['Historical label identity/powertrain is not resolved in this bounded census. No current-new claim or categorical non-BEV exclusion follows from the old-model link.'])
 else:
  legacy_map={
  '142':(426,432,'142 sedan, petrol'), '144':(433,439,'144 sedan, petrol'), '145':(440,446,'145 wagon, petrol'),'164':(447,453,'164 sedan, petrol'),
  '240':(411,418,'240 facelift sedan, petrol/diesel'),'242':(368,374,'242 sedan, petrol'),'244':(360,367,'244 sedan, petrol/diesel'),'245':(375,382,'245 wagon, petrol/diesel'),
  '260':(419,425,'260 facelift sedan, petrol'),'262':(383,396,'262C coupe and 262 sedan, petrol'),'264':(397,403,'264 sedan, petrol'),'265':(404,410,'265 wagon, petrol'),
  '360':(339,359,'360 three-door/five-door hatchbacks and sedan, petrol'),'440':(291,298,'440 hatchback, petrol/diesel'),'740':(244,259,'740 sedan and estate, petrol/diesel'),'760':(260,275,'760 sedan and estate, petrol/diesel'),'850':(196,211,'850 sedan and estate, petrol/diesel'),'940':(307,322,'940 sedan and estate, petrol/diesel'),'960':(164,195,'960 sedan/estate and 960/S90/960/V90 successor bodies, petrol/diesel'),
  'C70':(112,125,'C70 convertible and coupe, petrol'),'P1800':(475,481,'P1800/1800, petrol'),'S40':(104,111,'S40 Generation 2 sedan, petrol/diesel; Generation 1 also documented at lines 228–235'),'S70':(212,219,'S70 sedan, petrol/diesel'),'S80':(144,151,'S80 2006–2016 sedan, petrol/diesel'),'S90':(134,143,'S90 2016–2024 sedan, Electric/Petrol, Electric/Diesel, Petrol and Diesel; none labelled Electric alone'),'V40':(79,86,'V40 Generation 2 hatchback, petrol/diesel; Generation 1 wagon also documented at lines 236–243'),'V50':(96,103,'V50 wagon, petrol/diesel'),'V70':(220,227,'V70/V70XC Classic 1996–2000 wagon, petrol/diesel'),'V90':(180,187,'960/V90 Estate 1997–1998, petrol/diesel'),'XC70':(152,159,'XC70 1998–2016 Cross Country, petrol/diesel')}
  a,b,desc=legacy_map[n]
  r.update(disposition='historical_directory_entry_documented_non_bev_bodies',reason='Publisher identifies a discontinued/older model entry. Maker heritage evidence documents '+desc+'. Those specific historical bodies are non-BEV. This bounded evidence does not certify every generation, conversion or possible unsold vehicle under the umbrella name.',supportingEvidence=[ev(legacy,f'maker-legacy.txt lines {a}–{b}',desc)],unresolvedScope=['No current Australian new-BEV supply is established by this historical directory link; no exhaustive historical powertrain or residual-stock conclusion is asserted.'])
 return r

def entry(name,section,sourcekey,line_start,line_end,link,body=None,power=None):
 e={'publishedName':name,'publishedSection':section,'sourceUrl':bykey[sourcekey]['url'],'modelLink':link,'sourceKey':sourcekey,'textLocator':f"{Path(bykey[sourcekey]['textFile']).name} lines {line_start}–{line_end}",'checkedAt':D}
 if body:e['publishedBodyType']=body
 if power:e['publishedPowertrainTag']=power
 e.update(disposition(name));e['sourceKeys']=[sourcekey]+list(dict.fromkeys(x['sourceKey'] for x in e['supportingEvidence']));return e
ce_names=['ES90','EX30','EX40','EX60','EX90','XC40','XC60','XC90','C40','S60','V60','V90']
ce_links={n.replace(' Discontinued',''):urljoin(bykey[ce]['url'],h) for n,h in links('carexpert') if h.startswith('/volvo/')}
ce_entries=[entry(n,'current_cards' if i<8 else 'discontinued_cards',ce,47+i if i<8 else 55+(i-8)*2,47+i if i<8 else 56+(i-8)*2,ce_links[n]) for i,n in enumerate(ce_names)]
cg_current=[('C40',141,145,'SUV','Electric'),('Ec40',146,150,'SUV','Electric'),('Es90',151,156,'Sedan','Electric'),('EX30',157,162,'SUV','Electric'),('EX40',163,167,'SUV','Electric'),('Ex90',168,172,'SUV','Electric'),('S60',173,177,'Sedan','Hybrid'),('V60',178,181,'Wagon',None),('XC40',182,186,'SUV','Electric'),('XC60',187,192,'SUV','Hybrid'),('XC90',193,198,'SUV','Hybrid')]
cg_older=(R/'census/carsguide.txt').read_text().splitlines()[199:234]
cgl=links('carsguide');cg_entrylinks=[urljoin(bykey[cg]['url'],h) for n,h in cgl if n=='Explore details' and h.startswith('/volvo/')]
cgoldlinks={n:urljoin(bykey[cg]['url'],h) for n,h in cgl if n in cg_older and h.startswith('/volvo/')}
cg_entries=[entry(n,'current_cards',cg,a,b,cg_entrylinks[i],body,power) for i,(n,a,b,body,power) in enumerate(cg_current)]
cg_entries += [entry(n,'older_models',cg,200+i,200+i,cgoldlinks[n]) for i,n in enumerate(cg_older)]
assert len(cg_entries)==46 and len(cg_entrylinks)==11 and len(cg_older)==35 and len(ce_entries)==12
maker_models=[('EX90','Electric','SUV',31,'https://www.volvocars.com/au/cars/ex90-electric/'),('EX60','Electric','SUV',33,'https://www.volvocars.com/au/cars/ex60-electric/'),('EX40','Electric','SUV',34,'https://www.volvocars.com/au/cars/ex40-electric/'),('EX30','Electric','SUV',35,'https://www.volvocars.com/au/cars/ex30-electric/'),('ES90','Electric','Sedan',37,'https://www.volvocars.com/au/cars/es90-electric/'),('XC90','Plug-in hybrids','SUV',39,'https://www.volvocars.com/au/cars/xc90-hybrid/'),('XC60','Plug-in hybrids','SUV',40,'https://www.volvocars.com/au/cars/xc60-hybrid/'),('XC90','Mild hybrids (petrol)','SUV',42,'https://www.volvocars.com/au/cars/xc90/'),('XC60','Mild hybrids (petrol)','SUV',43,'https://www.volvocars.com/au/cars/xc60/'),('XC40','Mild hybrids (petrol)','SUV',44,'https://www.volvocars.com/au/cars/xc40/')]
mlinks={urljoin(bykey[maker]['url'],h) for n,h in links('maker-range')}
assert all(u in mlinks for _,_,_,_,u in maker_models)
maker_entries=[entry(n,group,maker,line,line,url,body,group) for n,group,body,line,url in maker_models]
# Current maker navigation XC40 is explicitly only the mild-hybrid product; historical alias is documented separately.
maker_entries[-1].update(disposition='excluded_current_non_bev_offering',reason='This exact maker navigation link is the current XC40 mild-hybrid petrol product, outside the BEV catalogue. Historical XC40 Recharge aliases are a separate unresolved scope under the publisher entries.',catalogueFamilies=[])
versions=[]
for model,body,trim,power,key,loc in [
('EX30','SUV','Plus','P5 Long Range Electric','census_volvo_ex30_build','../compact/ex30-build.txt lines 134–157'),('EX30','SUV','Ultra','P5 Long Range Electric','census_volvo_ex30_build','../compact/ex30-build.txt lines 134–157'),('EX30 Cross Country','SUV','Ultra','P8 AWD Electric','census_volvo_ex30_cross_country_selected','../compact/ex30-cc-browser-nsw2000.txt lines 24–56'),('EX40','SUV','Ultra','Single Motor Extended Range','census_volvo_ex40_build','../compact/ex40-build.txt lines 126–151'),('EX40','SUV','Ultra','Twin Motor','census_volvo_ex40_build','../compact/ex40-build.txt lines 126–151'),('EX90','SUV','Plus','Single Motor','census_volvo_ex90_config','../large/ex90-config.txt lines 70–96'),('EX90','SUV','Ultra','Twin Motor Performance','census_volvo_ex90_ultra_config','../large/ex90-ultra-config.txt lines 70–96'),('ES90','Sedan','Plus','Single Motor Extended Range','census_volvo_es90_config','../large/es90-config.txt lines 71–97'),('ES90','Sedan','Ultra','Single Motor Extended Range','census_volvo_es90_ultra_config','../large/es90-ultra-config.txt lines 71–97')]:
 versions.append({'model':model,'bodyStyle':body,'trim':trim,'powertrain':power,'modelYear':2027,'checkedAt':D,'sourceKey':key,'sourceUrl':bykey[key]['url'],'textLocator':loc,'availabilityScope':'Current maker named configuration; physical stock and accepted order not asserted','residualModelYearsClosed':False})

reconciliation={
'schemaVersion':1,'checkedAt':D,'brand':'Volvo','scope':'Source-bound Australian Volvo Tier 1 model-directory reconciliation, with all named entries in the two independent publisher directories and maker current powertrain navigation transcribed. Not an app packet and not whole-market C1 closure.',
'globalPublishedLists':[],
'brandPublishedLists':[
{'id':'volvo-carexpert-brand-directory-20261014','publisher':'CarExpert','datasetAttribution':'CarExpert brand editorial directory. No JATO attribution appears in this captured directory text; do not assert a specific underlying supplier.','sourceKey':ce,'sourceUrl':bykey[ce]['url'],'observedAt':D,'sourcePublicationDate':None,'scope':'Mixed-powertrain Volvo brand directory, current and explicitly discontinued model cards','sourceLabelCounts':{'currentModels':8,'discontinuedModels':4},'transcribedCounts':{'currentCards':8,'discontinuedCards':4},'currentPublishedNames':ce_names[:8],'discontinuedPublishedNames':ce_names[8:],'evidenceCaptures':['carexpert.txt','carexpert.capture.json'],'entries':ce_entries},
{'id':'volvo-carsguide-brand-directory-20261014','publisher':'CarsGuide','datasetAttribution':"CarsGuide / Glass’s Information Services and other sources as attributed in the footer; separate publication from CarExpert, with no claim of disjoint upstream records.",'sourceKey':cg,'sourceUrl':bykey[cg]['url'],'observedAt':D,'sourcePublicationDate':None,'scope':'Mixed-powertrain Volvo brand directory, all current cards and all older-model links','sourceLabelCounts':{'currentModels':11,'olderModels':35,'electricCurrentModels':7},'transcribedCounts':{'currentCards':11,'olderLinks':35},'currentPublishedNames':[x[0] for x in cg_current],'olderPublishedNames':cg_older,'evidenceCaptures':['carsguide.txt','carsguide.capture.json'],'attributionLocator':'carsguide.txt lines 464–465','entries':cg_entries}],
'makerCurrentRange':{'sourceKey':maker,'sourceUrl':bykey[maker]['url'],'checkedAt':D,'textLocator':'maker-range.txt lines 18–44','transcribedCounts':{'electricEntries':5,'plugInHybridEntries':2,'mildHybridEntries':3,'uniqueNameplates':8,'powertrainSpecificEntries':10},'entries':maker_entries},
'currentSourceBoundBEVFamilies':['EX30','EX40','EX90','ES90'],'separatelyNamedBodyConfiguration':['EX30 Cross Country'],'currentNamedConfigurationCount':9,'currentNamedConfigurations':versions,
'completeDirectoryAccounting':{'carexpertEntries':12,'carsguideEntries':46,'makerCurrentPowertrainEntries':10,'everyPublishedEntryHasDisposition':True,'everyPublishedEntryHasExactModelLink':True,'everyPublishedEntryHasTextLocator':True,'historicalLabelsAutomaticallyExcludedAsNonBev':False,'makerLegacySourceRole':'Supporting exact historical body/powertrain descriptions only, not represented as an Australian current-new model census.'},
'closureConclusion':{'publisherDirectoryTranscriptionComplete':True,'brandCurrentAndResidualVersionClosure':False,'globalC1Closure':False,'reason':'The current maker MY27 named configurations are established, but independent directories disagree over current status and powertrain aliases. EX60 order/delivery timing, C40/EC40 and XC40 Recharge residual-New scope, and older MY26/MY25 versions require separate exact-source decisions. A sold example or missing current menu never proves absence of all residual-new supply.'},
'differences':[
{'subject':'EX60','difference':'CarExpert current; CarsGuide older; maker Electric menu includes it.','resolution':'Keep provisional arrival/order scope. Current maker says Coming 2027; May report says orders open with Q4 2026 deliveries.','sourceKeys':[ce,cg,maker,ex60,zex60]},
{'subject':'C40 and EC40','difference':'C40 discontinued in CarExpert but current Electric in CarsGuide; Ec40 current Electric only in CarsGuide.','resolution':'No on-sale inference from directory. Exact Berwick C40 ad is SOLD; full residual-New scope remains unresolved.','sourceKeys':[ce,cg,'census_volvo_ec40_build','census_berwick_c40_sold']},
{'subject':'XC40 and EX40','difference':'CarsGuide current XC40 card is tagged Electric; maker current XC40 is mild-hybrid and EX40 is Electric.','resolution':'Separate current mild-hybrid exclusion, current EX40 BEV configurations and historical XC40 Recharge residual-New scope.','sourceKeys':[ce,cg,maker]},
{'subject':'EX30 Cross Country','difference':'Neither publisher gives Cross Country a standalone current EX30 family card. CarsGuide has a separate generic Cross Country old-model link.','resolution':'Include the exact maker EX30 Cross Country Ultra P8 AWD configuration under EX30; do not silently equate the generic historical Cross Country label.','sourceKeys':[ce,cg,'census_volvo_ex30_cross_country_selected']},
{'subject':'S60 and V60','difference':'Current cards in CarsGuide; discontinued in CarExpert.','resolution':'Documented motor/fuel descriptions establish combustion-based hybrids/petrol, outside BEV scope. Non-BEV residual stock status is not adjudicated.','sourceKeys':[ce,cg,s60,v60]},
{'subject':'V90','difference':'CarExpert discontinued; CarsGuide older.','resolution':'Retain exact historical scope. Maker evidence for 960/V90 Estate is petrol/diesel, without treating that as proof covering every later V90 generation.','sourceKeys':[ce,cg,legacy]},
{'subject':'Historical C30','difference':'Older-model link could be wrongly blanket-excluded as non-BEV.','resolution':'Maker legacy page explicitly includes Electric for 2006–2012 C30; record historical electric lead without current Australian new-sale evidence.','sourceKeys':[cg,legacy]},
{'subject':'122 / CX30 / Cross Country labels','difference':'Historical directory labels do not establish exact current BEV identity.','resolution':'Preserve labels and unresolved identity scope rather than silently rewriting names or inventing non-BEV histories.','sourceKeys':[cg]}],
'unresolvedScope':[
{'subject':'EX60','neededEvidence':'Current Australian order acceptance and reconciled delivery timing.','status':'provisional_coming_2027_with_older_order_open_report'},
{'subject':'C40 / EC40','neededEvidence':'An exact current unsold New advertisement or maker/importer statement that explicitly settles residual-New availability.','status':'unresolved_no_absence_inference'},
{'subject':'XC40 Recharge legacy electric','neededEvidence':'Exact current residual-New version evidence distinct from current mild-hybrid XC40 and EX40 successor.','status':'unresolved_no_absence_inference'},
{'subject':'MY26 / MY25 residual cohorts','neededEvidence':'Integrate the separate exact version/year reviews without extrapolating from MY27 menus.','status':'separate_worker_review_pending_in_this_artifact'},
{'subject':'C30 and older model labels','neededEvidence':'Only required if a credible current Australian new-sale lead emerges; historical directory links alone do not establish current supply.','status':'historical_not_current_new_evidence'}],
'limitations':[
'Brand directories are not whole-market C1 publishedLists, and the maker list is not independent of itself. They prove complete transcription of their own captured lists only.',
'Publisher cards can combine multiple model years, fuels and bodies. Electric or Hybrid tags are not exact current version lists or live stock evidence.',
'Historical maker heritage material is used only for the explicit bodies, production periods and powertrains it names. It is not evidence that every generation was non-BEV or that Australia received each historical electric vehicle.',
'No dealer contact, purchase, factory-order acceptance or physical stock verification occurred in this research.',
'All sources were checked 14 October 2026. Captures without HTTP metadata are not assigned a fabricated successful status code.'
],
'sourceIndexFile':'source-index.json','sourceKeys':[s['id'] for s in sources],
'sanitization':'Normalized artifacts contain public factual text, ordinary model/configuration/stock URLs, source hashes and locators only. No headers, cookies, credentials, personal or runtime authentication data included.'}
dump('census/source-bound-reconciliation.json',reconciliation);dump('census/source-index.json',sources)
print(json.dumps({'terms':len(terms),'termSources':len(termSources),'carexpert':len(ce_entries),'carsguide':len(cg_entries),'makerEntries':len(maker_entries),'namedConfigurations':len(versions),'censusSources':len(sources)}))
