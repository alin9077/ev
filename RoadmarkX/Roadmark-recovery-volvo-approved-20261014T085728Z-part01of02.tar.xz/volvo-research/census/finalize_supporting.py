from pathlib import Path
import json,hashlib,re
R=Path('/tmp/volvo-research');P=R/'census';D='2026-10-14'
def read(p):return json.loads(p.read_text())
def write(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
d=read(P/'source-bound-reconciliation.json');idx=read(P/'source-index.json');compact=read(R/'compact/source-index.json');large=read(R/'large/source-index.json')
facts=[]
for stem in ['ex30','ex40']:
 p=R/'compact'/f'{stem}-build-facts.json';src=read(p)
 facts.append({'sourceKey':'census_volvo_'+stem+'_model_year_fields','sourceUrl':src['url'],'checkedAt':D,'captureFile':'../compact/'+p.name,'captureSha256':h(p),'locator':'fields.modelYear','selectedScalarModelYear':src['fields']['modelYear'][0],'otherListedModelYears':src['fields']['modelYear'][1],'scope':'The scalar selected model-year field is distinct from the generic model-year choices. No additional year/version is admitted solely because it appears among choices.'})
for stem in ['ex90-config','ex90-ultra-config','es90-config','es90-ultra-config']:
 p=R/'large'/f'{stem}-rsc.txt';s=p.read_text();src=next(x for x in large if x['key']=='large_'+stem)
 facts.append({'sourceKey':'census_volvo_'+stem.replace('-','_')+'_model_year_fields','sourceUrl':src['url'],'checkedAt':D,'captureFile':'../large/'+p.name,'captureSha256':h(p),'locator':'Whitelisted product modelYear and commercialModelYear fields from selected configuration response','modelYearValues':sorted(set(re.findall(r'"modelYear"\s*:\s*"?(\d{4})',s))),'commercialModelYearValues':sorted(set(re.findall(r'"commercialModelYear"\s*:\s*"?(\d{4})',s))),'scope':'Only public product year fields retained here; original response runtime data are not copied.'})
for stem in ['ex30-ultra-selected','ex40-twin-selected']:
 p=R/'compact'/f'{stem}.html';s=p.read_text();src=read(p.with_suffix('.capture.json'))
 facts.append({'sourceKey':'census_volvo_'+stem.replace('-','_')+'_model_year_fields','sourceUrl':src['url'],'checkedAt':D,'captureFile':'../compact/'+p.name,'captureSha256':h(p),'locator':'Whitelisted product modelYear fields and public configuration my query values','modelYearValues':sorted(set(re.findall(r'(?:\\?\")modelYear(?:\\?\")\s*:\s*(?:\\?\")?(\d{4})',s))),'configurationQueryModelYears':sorted(set(re.findall(r'my=(\d{4})',s))),'scope':'Only public product year fields retained; no runtime or authentication fields copied.'})
facts.append({'sourceKey':'census_volvo_ex30_cc_model_year_route','sourceUrl':compact['ex30-cross-country-build'],'checkedAt':D,'locator':'Exact captured public configuration route, my=2027, edition=cross-country; body/powertrain selected in separate browser text','configurationQueryModelYear':'2027','scope':'MY2027 identity route is considered with the selected EX30 Cross Country Ultra P8 AWD browser capture, not the unselected generic HTML fallback.'})
write(P/'configuration-identity-facts.json',facts)
for f in facts:
 idx.append({'id':f['sourceKey'],'key':f['sourceKey'],'title':'Volvo AU selected configuration public model-year identity fields','url':f['sourceUrl'],'checkedAt':D,'textFile':'configuration-identity-facts.json','textSha256':h(P/'configuration-identity-facts.json'),'sourceType':'manufacturer','captureScope':'Public product-year fields only, whitelisted from identified existing captures. Use matching sourceKey object in shared JSON.'})
for v in d['currentNamedConfigurations']:
 if v['model']=='EX30 Cross Country':k='census_volvo_ex30_cc_model_year_route'
 elif v['model']=='EX30':k='census_volvo_ex30_model_year_fields' if v['trim']=='Plus' else 'census_volvo_ex30_ultra_selected_model_year_fields'
 elif v['model']=='EX40':k='census_volvo_ex40_model_year_fields' if v['powertrain']=='Single Motor Extended Range' else 'census_volvo_ex40_twin_selected_model_year_fields'
 else:k=v['sourceKey']+'_model_year_fields'
 v['modelYearEvidence']={'sourceKey':k,'textLocator':'configuration-identity-facts.json object with matching sourceKey','modelYear':2027}
d['sourceKeys']=[x['id'] for x in idx]
d['brandPublishedLists'][0]['countMethod']='Eight unbadged current cards and four explicitly Discontinued cards counted in captured directory; the page does not display an aggregate numeric current count.'
# An exact text locator is preferable to a vague location.
for block in d['brandPublishedLists']+[d['makerCurrentRange']]:
 for e in block['entries']:
  for ev in e.get('supportingEvidence',[]):
   if ev['sourceKey']=='census_volvo_ec40_build':ev['textLocator']='../compact/ec40-build.txt line 122'
write(P/'source-bound-reconciliation.json',d);write(P/'source-index.json',idx)
# Validate every local indexed hash and all machine-readable source references.
keys={x['id'] for x in idx};assert len(keys)==len(idx)
for x in idx:
 p=P/x['textFile'];assert p.exists() and h(p)==x['textSha256'],x['id']
for block in d['brandPublishedLists']+[d['makerCurrentRange']]:
 for e in block['entries']:
  assert e['modelLink'].startswith('https://') and e['sourceKey'] in keys
  assert all(k in keys for k in e['sourceKeys'])
  assert e['textLocator'] and e['checkedAt']==D and e['reason']
for v in d['currentNamedConfigurations']:assert v['modelYearEvidence']['sourceKey'] in keys
terms=read(R/'terms-normalized.json');ts=read(R/'terms/source-index.json');tk={x['id'] for x in ts};assert len(tk)==4
for v in terms.values():assert set(v['sourceKeys']).issubset(tk)
for x in ts:
 assert h(R/'terms'/x['textFile'])==x['textSha256']
 assert h(R/'terms'/x['captureFile'])==x['captureSha256']
 assert h(R/'terms'/x['factualHtmlFile'])==x['factualHtmlSha256']
result={'checkedAt':D,'allJsonParses':True,'allSourceKeysResolve':True,'allIndexedTextHashesMatch':True,'allTermsCaptureHashesMatch':True,'publisherEntries':58,'makerPowertrainEntries':10,'currentConfigurations':9,'censusSources':len(idx),'termsSources':4,'brandClosureClaimed':False,'globalC1Claimed':False}
write(P/'validation.json',result);print(json.dumps(result))
