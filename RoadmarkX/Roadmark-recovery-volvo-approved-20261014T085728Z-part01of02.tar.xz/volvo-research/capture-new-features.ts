import fs from 'node:fs';
import {catalogue,research,effectiveFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/data.ts';
import {prepareBrandResearch,applyBrandUpdates} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/brand-updates.ts';
const root='/tmp/volvo-research/';const p=JSON.parse(fs.readFileSync(root+'volvo-2026-10-14.json','utf8'));const data=prepareBrandResearch(research(),[p]);const cars=applyBrandUpdates(catalogue(),data,[p]);const ids=new Set(p.variants.map((v:any)=>v.id));
fs.writeFileSync(root+'new-feature-before.json',JSON.stringify(cars.filter(c=>ids.has(c.id)).flatMap(c=>effectiveFeatures(c,data)),null,2));console.log('Captured generated before-features for',ids.size,'new versions');
