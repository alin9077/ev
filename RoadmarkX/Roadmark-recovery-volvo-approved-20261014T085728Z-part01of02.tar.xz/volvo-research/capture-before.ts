import fs from 'node:fs';
import {catalogue,research,effectiveFeatures} from '/workspace/scratch/586427eef9f2/roadmark-104/src/lib/data.ts';
const root='/tmp/volvo-research/', r=research(), all=catalogue(), cars=all.filter(c=>c.brand==='Volvo'&&(c.vehicleClass===undefined||['passenger','ute'].includes(c.vehicleClass)));
fs.writeFileSync(root+'volvo-live-before.json',JSON.stringify(cars,null,2));
fs.writeFileSync(root+'volvo-source-before.json',JSON.stringify(r.sources,null,2));
fs.writeFileSync(root+'volvo-feature-before.json',JSON.stringify(cars.flatMap(c=>effectiveFeatures(c,r)),null,2));
fs.writeFileSync(root+'volvo-models-before.json',JSON.stringify(r.models.filter(c=>c.brand==='Volvo'),null,2));
fs.writeFileSync(root+'volvo-variants-before.json',JSON.stringify(r.variants.filter(c=>c.brand==='Volvo'),null,2));
console.log(cars.map(c=>({id:c.id,model:c.model,trim:c.trim,year:c.year,availability:c.availability,drive:c.drive,facts:Object.keys(c.facts).length})));
