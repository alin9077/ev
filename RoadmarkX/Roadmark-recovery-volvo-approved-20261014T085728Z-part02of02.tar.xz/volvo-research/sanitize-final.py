import pathlib,re,json,hashlib,html
R=pathlib.Path('/tmp/volvo-research');sha=lambda b:hashlib.sha256(b).hexdigest();changes=[]
for f in list(R.rglob('*.html'))+list(R.rglob('*rsc.txt'))+list(R.rglob('*decoded.txt')):
 b=f.read_bytes();t=b.decode('utf-8',errors='replace');before=t;counts={}
 patterns=[('configuration-runtime-attribute',r'(?i)(data-cce-token\s*=\s*["\x27])[^"\x27]*(?=["\x27])',r'\1[REDACTED]'),('escaped-configuration-runtime-attribute',r'(?i)(data-cce-token\s*=\s*\\["\x27])[^"\x27\\]*(?=\\["\x27])',r'\1[REDACTED]')]
 for name,pat,rep in patterns:
  t,n=re.subn(pat,rep,t);counts[name]=n
 if f.name in ['es90-plus-my26-new.html','es90-ultra-my26-new.html']:
  t,n=re.subn(r'<script\b[^>]*>.*?</script\s*>','<!-- Ephemeral anti-bot cookie/challenge script removed; access-block status retained. -->',t,flags=re.I|re.S);counts['anti-bot-script']=n
 if t!=before:
  f.write_text(t);changes.append(dict(path=str(f.relative_to(R)),priorSha256=sha(b),sanitizedSha256=sha(f.read_bytes()),transformations=counts,reason='Remove ephemeral runtime configuration identifiers or anti-bot cookie/challenge script; no vehicle facts, public source URL or ordinary configuration/stock ID removed.'))
  mf=f.with_suffix('.capture.json')
  if mf.exists():
   m=json.loads(mf.read_text());m['preFinalSanitizationSha256']=m.get('rawFactualSha256');m['rawFactualSha256']=sha(f.read_bytes());m.setdefault('redactions',[]).append({'finalSanitization':counts});mf.write_text(json.dumps(m,indent=2)+'\n')
(R/'final-redaction-transformations.json').write_text(json.dumps(dict(checkedAt='2026-10-14',changes=changes,rawValuesLogged=False),indent=2)+'\n');print('Sanitized',len(changes),'captures; no raw values logged')
