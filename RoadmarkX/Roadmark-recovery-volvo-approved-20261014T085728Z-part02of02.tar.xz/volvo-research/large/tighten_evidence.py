import pathlib,json,hashlib
R=pathlib.Path('/tmp/volvo-research/large');p=R/'normalized-evidence.json';d=json.loads(p.read_text())
# New narrowly used towing references. No other potentially stale secondary fields adopted.
def add(key,url,title,file,pub,kind='secondary',notes=''):
 f=R/file;t=f.with_suffix('.txt')
 if f.suffix=='.json':
  v=json.loads(f.read_text());t.write_text(v if isinstance(v,str) else json.dumps(v,ensure_ascii=False))
 if not t.exists():t=f
 d['sources'].append(dict(key=key,url=url,title=title,source_type=kind,status=200,final_url=url,checked_on='2026-10-14',file=str(f),textFile=str(t),sha256=hashlib.sha256(f.read_bytes()).hexdigest(),textSha256=hashlib.sha256(t.read_bytes()).hexdigest(),redactions='Public rendered factual text or static PDF. No runtime cookies, session or authentication data.',publisher=pub,notes=notes))
add('large_ex90-my27-plus-towing','https://www.carexpert.com.au/volvo/ex90/2027-plus-suv-rwd-electric-jskf58af20260701','Exact AU MY27 EX90 Plus:1500kg braked','current-towing-web.json','CarExpert',notes='Only explicit braked towing row used; stale/conflicting250kW charging and3yr warranty fields rejected.')
add('large_ex90-my27-ultra-towing','https://www.carexpert.com.au/volvo/ex90/2027-ultra-suv-4x4-electric-jsgo5w8m20260701','Exact AU MY27 EX90 Ultra:2200kg braked','current-towing-web.json','CarExpert',notes='Only explicit braked towing row used; stale/conflicting250kW charging field rejected.')
pdf=R/'es90-my27-it.pdf'
file='es90-my27-it.pdf' if pdf.exists() and pdf.read_bytes()[:4]==b'%PDF' else 'es90-my27-towing-web.json'
add('large_es90-my27-it','https://asset.moto.it/pricelist/auto/f264770a8981f3c719abf7b5d50c77c3/listino-apr-26.pdf','Volvo Italia MY2027 ES90 technical table, page21',file,'Volvo Car Italia, public Moto.it mirror','manufacturer','Same-year245kW92kWh800V Single Motor Extended Range sibling; table explicitly names braked/unbraked1600/750kg. Overseas scope remains Reported.')
allowed={x['criterion'] for x in json.load(open('/tmp/volvo-research/volvo-feature-before.json'))}
mp={'head_up_display':'screens_hud','premium_audio':'audio_system','panoramic_roof':'glass_roof'}
for v in d['variants']:
 current=v['modelYear']==2027; isx=v['model']=='EX90';ultra=v['trim'].startswith('Ultra');v['additionalFactOnlyCriteria']=[]
 by={f['key']:f for f in v['facts']}
 for k in ['boot_l','max_total_cargo_l','height_mm']:
  if current:
   f=by[k];f['grade']='confirmed';f['qualifications']=[f['reason']];f['reason']='Exact Australian maker value; specified loading and measurement basis is retained without treating method scope as uncertainty.';f['comparison']='';f.pop('condition',None)
 f=by['dc_charge_time_min']
 if current or isx:
  f['grade']='confirmed';f['qualifications']=[f['reason']];f['reason']='Exact Australian maker10–80% time with stated station/test basis. Generic charging variation is a standing qualification.';f.pop('condition',None)
 else:
  f['condition']='MY26 support table applies at compatible350kW high-voltage station and battery approximately35°C; confirm exact Single Motor applicability because AU launch says22min at300kW/500A.'
 if current:
  f=by['towing_braked_kg'];f['grade']='reported';f['basis']='Explicit braked towing capacity, exact AU MY27 secondary' if isx else 'Explicit braked towing capacity, matched overseas MY27 sibling'
  f['sourceKeys']=['large_ex90-my27-'+('ultra' if ultra else 'plus')+'-towing'] if isx else ['large_es90-my27-it']
  f['reason']='Exact Australian MY27 CarExpert row explicitly labels braked capacity, consistent with AU maker trailer maximum.' if isx else 'Volvo Italia MY27 technical table explicitly labels1600kg braked for same245kW92kWh800V Single Motor Extended Range. AU maker separately publishes the same unclassified trailer maximum; overseas sibling scope retained.'
  f['qualifications']=['Tow equipment and loaded vehicle/trailer limits must be checked; AU maker maximum is not independently labelled braked.'];f['comparison']='Braked towing';f.pop('condition',None)
  by['range_km']['condition']='Manufacturer states range is preliminary and vehicle certification is pending.'
  by['price_aud']['condition']='Unlocalized selected-grade display; LCT/on-road treatment unresolved, no postcode supplied. Not an established complete driveaway price.'
 mapped=[]
 for ft in v['features']:
  c=ft['criterion'];new=mp.get(c,c)
  if new not in allowed:
   v['additionalFactOnlyCriteria'].append(c);continue
  if new!=c:
   ft['criterion']=new;oldkey='feature_'+c;newkey='feature_'+new;ft['keys']=[newkey]
   if oldkey in by:by[oldkey]['key']=newkey
  mapped.append(ft)
 v['features']=mapped
 for f in v['facts']:
  if f['grade']=='check' and not f.get('condition'):f['condition']=f['reason']
  if f['key'] in ['boot_l','max_total_cargo_l','height_mm']:f['comparison']=''
 for ft in v['features']:
  if ft['grade']=='check':ft['condition']=ft.get('condition') or ft['reason']
 # Fact-bound summaries, with no subjective ride claims or unqualified price rankings.
 if isx and ultra:
  strength={'label':'Seven-seat performance','text':'500kW, AWD and a4.2-second0–100km/h claim with seven seats','keys':['power_kw','drive','zero_to_100_s','seats']}
  trade={'label':'Large body','text':'5037mm long and1964mm wide excluding mirrors','keys':['length_mm','width_mm']}
 elif isx and current:
  strength={'label':'Seven-seat electric layout','text':'Seven seats,245kW and a479km preliminary WLTP claim','keys':['seats','power_kw','range_km']}
  trade={'label':'Rear-drive towing limit','text':'RWD and1500kg reported braked towing, versus2200kg for the Ultra','keys':['drive','towing_braked_kg']}
 elif isx:
  strength={'label':'Seven seats with AWD','text':'330kW, AWD and2200kg reported braked towing','keys':['power_kw','drive','towing_braked_kg','seats']}
  trade={'label':'Residual-year source scope','text':'MY26 specifications are reported and apply to identified residual-new stock','keys':['power_kw','battery_kwh','price_aud']}
 elif ultra:
  strength={'label':'Ventilated-seat cabin','text':'Ventilated seats and upgraded premium audio are documented for Ultra','keys':['feature_front_ventilated_seats','feature_audio_system']}
  trade={'label':'Five-seat rear-drive layout','text':'Five seats and RWD; no Australian twin-motor version is listed','keys':['seats','drive']}
 else:
  strength={'label':'Range and rear-seat space','text':'554km WLTP claim, five seats and3102mm wheelbase','keys':['range_km','seats','wheelbase_mm']}
  trade={'label':'Ventilation is optional','text':'Front-seat ventilation requires the optional ventilated upholstery','keys':['feature_front_ventilated_seats']}
 v['summary']={'strength':strength,'tradeoff':trade}
# exact-source closure and each Check condition
keys={s['key'] for s in d['sources']}
for v in d['variants']:
 facts={f['key'] for f in v['facts']}
 for obj in v['facts']+v['features']:
  assert all(s in keys for s in obj['sourceKeys'])
  if obj['grade']=='check':assert obj.get('condition')
 for s in v['summary'].values():assert all(k in facts for k in s['keys']),(v['id'],s)
 assert all(f['criterion'] in allowed for f in v['features'])
p.write_text(json.dumps(d,indent=2,ensure_ascii=False));(R/'source-index.json').write_text(json.dumps(d['sources'],indent=2,ensure_ascii=False))
print('Stable:',len(d['sources']),'sources; all Check conditions populated; feature criteria valid; summaries reference exact facts')
