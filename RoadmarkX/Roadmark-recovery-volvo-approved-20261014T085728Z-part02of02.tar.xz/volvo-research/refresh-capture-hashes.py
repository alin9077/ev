import pathlib,json,hashlib
R=pathlib.Path('/tmp/volvo-research');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();changed=[]
def walk(x,base):
 if isinstance(x,list):
  for v in x:walk(v,base)
 if not isinstance(x,dict):return
 for key,hashkeys in [('file',['sha256']),('textFile',['textSha256','text_sha256']),('factualHtmlFile',['factualHtmlSha256']),('captureFile',['captureSha256'])]:
  if not isinstance(x.get(key),str):continue
  p=pathlib.Path(x[key]);p=p if p.is_absolute() else base/p
  if p.is_file():
   for hk in hashkeys:
    if hk in x:x[hk]=sha(p)
   if key=='textFile' and 'sha256'in x and x.get('file')==x[key]:x['sha256']=sha(p)
   if key=='captureFile' and 'captureReportedFactualSha256'in x:
    m=json.loads(p.read_text());x['captureReportedFactualSha256']=m.get('rawFactualSha256',x['captureReportedFactualSha256'])
 for v in x.values():walk(v,base)
for d in ['compact','large','terms','census']:
 for f in (R/d).glob('*.json'):
  if f.name.endswith('.capture.json'):continue
  try:x=json.loads(f.read_text())
  except:continue
  old=json.dumps(x,sort_keys=True);walk(x,f.parent)
  if json.dumps(x,sort_keys=True)!=old:f.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n');changed.append(str(f.relative_to(R)))
print('Refreshed',len(changed),'source-index/normalized files')
