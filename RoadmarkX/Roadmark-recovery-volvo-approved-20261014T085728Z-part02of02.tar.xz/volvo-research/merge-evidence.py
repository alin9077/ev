import json,pathlib,copy
R=pathlib.Path('/tmp/volvo-research');D='2026-10-14';load=lambda p:json.loads((R/p).read_text())
parts={k:load(k+'/normalized-evidence.json') for k in ['compact','large','current']};sources=[];variants=[]
for name,p in parts.items():sources+=p['sources'];variants+=p['variants']
if (R/'terms/source-index.json').exists():
 t=load('terms/source-index.json');t=t if isinstance(t,list) else t['sources']
 for x in t:
  x['file']=str(R/'terms'/x['textFile']);x['textFile']=x['file'];x['source_type']=x.get('sourceType','manufacturer');x['checked_on']=D
 sources+=t
if (R/'census/source-index.json').exists():
 t=load('census/source-index.json');t=t if isinstance(t,list) else t['sources']
 for x in t:
  if x.get('textFile') and not pathlib.Path(x['textFile']).is_absolute():x['textFile']=str(R/'census'/x['textFile'])
  x['file']=x.get('textFile',x.get('file'));x.setdefault('publisher','Volvo Cars Australia' if 'volvocars.com/au/' in x['url'] else 'CarExpert' if 'carexpert' in x['url'] else 'CarsGuide' if 'carsguide' in x['url'] else 'zecar' if 'zecar' in x['url'] else 'Volvo authorised retailer');x['source_type']=x.get('sourceType',x.get('source_type','secondary'));x['checked_on']=D
 sources+=t
ids=set();uniq=[]
for s in sources:
 if s['key'] not in ids:ids.add(s['key']);uniq.append(s)
sources=uniq
for x in sources:
 if 'manufacturer' in x.get('source_type','') and 'volvocars.com/au/' not in x['url']:
  x['source_type']='manufacturer_overseas_reported'
  x['sourceOriginMarket']='DE' if 'germany' in x['key'] else 'DK' if '-dk' in x['key'] else 'IT' if '-it' in x['key'] else 'global'
  x['notes']='Australian research application only; source originates in '+x['sourceOriginMarket']+'. Its technical claims are Reported overseas/sibling scope, never AU primary confirmation.'
before={c['id']:c for c in load('volvo-live-before.json')};allowed={f['criterion'] for f in load('volvo-feature-before.json')}
def add(v,k,value,keys,grade='confirmed',basis='',reason='Current exact-version evidence.',**kw):
 f=dict(key=k,value=value,sourceKeys=keys,grade=grade,basis=basis,comparison='',reason=reason,**kw);v['facts'].append(f);return f
for v in variants:
 if v['id'] in before:v['generation']=before[v['id']]['generation']
 v['facts']=[f for f in v['facts'] if f['key'] not in ['price_driveaway_nsw2000_aud','feature_driveaway_price']]
 v['features']=[f for f in v.get('features',[]) if f['criterion']!='driveaway_price']
 v.setdefault('familyId','volvo-'+v['model'].lower());v.setdefault('features',[])
 for f in v['facts']:
  if f['key']=='price_aud' and f.get('priceRung')==1:f['comparison']='Before on-road costs'
  if f['key']=='front_boot_l':f['key']='frunk_l'
  if f['key']=='electrical_architecture_v':f['key']='battery_voltage_v'
  if f.get('grade')=='check' and not f.get('condition'):f['condition']=f['reason']
  if f.get('grade')=='reported':f.setdefault('qualifications',[]).append('Reported secondary or named sibling scope; confirm exact Australian model year/build before contract.')
 av=v['availability']
 if v['modelYear']==2026:av['state']='outgoing'
 if av.get('orderStatus')=='not_confirmed':av['orderStatus']='unverified'
 if av['state']=='on_sale_now':av['state']='current_or_order_listed' if v['id'] in before else 'outgoing'
 av['stockStatus']='new_stock_listed' if av['state']=='outgoing' else 'unverified'
 av.setdefault('orderStatus','listed_unconfirmed');av.setdefault('qualifications',[av.get('note','Current public offer/configuration observed; no physical inventory or accepted factory order verified.')]);av.setdefault('reason',av.get('note','Exact Australian advertised version.'))
 if 'equipmentHighlights' in v:
  eq=v['equipmentHighlights'];values=eq['values'];grade=eq.get('grade','confirmed');sr=eq['sourceKeys']
  mapping={'audio_system':['sound','audio'],'parking_cameras':['camera'],'adas_standard':['pilot assist','adaptive cruise','lane change','blis'],'power_tailgate':['tailgate'],'remote_preconditioning':['pre-conditioning'],'glass_roof':['roof'],'screens_hud':['display'],'front_heated_seats':['heated front seats'],'front_ventilated_seats':['ventilat'],'rear_heated_seats':['heated rear'],'heated_steering_wheel':['heated steering'],'heat_pump':['heat pump']}
  for crit,needles in mapping.items():
   matches=[x for x in values if any(n in x.lower() for n in needles)]
   if not matches:continue
   val='; '.join(matches);k='equipment_'+crit;add(v,k,val,sr,grade,basis='Exact grade equipment highlights' if grade=='confirmed' else 'Explicit sibling/advertised equipment highlights',reason=eq.get('note','Selected version equipment.'));v['features'].append(dict(criterion=crit,value=val,keys=[k],grade=grade))
  # Preserve remaining supported highlight list as factual equipment, not an invented criterion.
  add(v,'equipment_highlights','; '.join(values),sr,grade,basis='Selected grade highlights, not a complete equipment matrix',reason=eq.get('note','Selected equipment highlights.'))
 # Supplemental public driveaway examples are usable buyer facts, not silently discarded research notes.
 observations=v.get('priceObservations',[])+[x for x in v.get('alternativePrices',[]) if 'driveaway' in x.get('basis','').lower()]
 if v['model']=='EX40' and v['modelYear']==2026:
  observations=[dict(value=87157 if v['drive']=='RWD' else 82231,basis='Dealer advertised driveaway WA, stock6095V' if v['drive']=='RWD' else 'Dealer advertised driveaway VIC, stock13294744',grade='reported',sourceKey='perth-ex40-my26-single' if v['drive']=='RWD' else 'doncaster-ex40-my26-twin')]
 if v['model']=='EX60':observations=[dict(value=95872 if v['drive']=='RWD' else 112881,basis='Manufacturer estimated driveaway, Sydney NSW2000',grade='check',sourceKey='ex60-p6-equipment-browser' if v['drive']=='RWD' else 'ex60-p10-browser-nsw2000',condition='NSW2000 reference postcode, private owner aged40, good driving record and premium licence plate; selected base configuration. Exact retailer agreement may differ. This is an estimate, not a promotion.')]
 if observations and not any(f['key']=='promotional_driveaway_aud' for f in v['facts']):
  x=observations[0];grade=x.get('grade','reported');srcs=x.get('sourceKeys',[x.get('sourceKey')]);rung=x.get('priceRung',4 if grade=='check' else 6)
  add(v,'promotional_driveaway_aud',x['value'],srcs,grade,basis=x['basis'],reason='Exact separately scoped driveaway observation; main price remains the highest applicable ladder rung.',label='Illustrative driveaway estimate' if rung==4 else 'Advertised dealer driveaway',condition=x.get('condition','Exact advertised unit and location; confirm current offer, registration, options and final retailer terms.'),qualifications=x.get('qualifications',[])+['Supplemental price, separate from the main list/configuration figure. No on-road costs were calculated by Roadmark.'],priceRung=rung,state='NSW' if rung==4 else x.get('state',''),rankingEligible=False)
  v['facts'][-1]['comparison']='Driveaway'
 fs={f['key']:f for f in v['facts']}
 for crit,key,val in [('storage','boot_l',f"{fs['boot_l']['value']} L rear luggage: {fs['boot_l']['basis']}"),('home_charging','ac_kw',f"Up to {fs['ac_kw']['value']} kW on-board AC charging"),('warranty_service','warranty','5-year / unlimited-kilometre private-use vehicle warranty; separate use and maintenance conditions apply')]:
  if crit not in [x['criterion'] for x in v['features']]:v['features'].append(dict(criterion=crit,value=val,keys=[key]))
 for fr in v['features']:
  if fr['criterion'] not in allowed:raise Exception(('Invalid feature criterion',v['id'],fr['criterion']))
  deps=[fs[k] for k in fr['keys'] if k in fs]
  if fr.get('grade')=='check' and not fr.get('condition'):fr['condition']=' '.join(f.get('condition','') for f in deps).strip() or fr.get('reason')
 if not v.get('summary') or v['model'] in ['EX90','ES90']:
  f=fs;power=f['power_kw']['value'];acc=f['zero_to_100_s']['value'];boot=f['boot_l']['value'];width=f['width_mm']['value']
  if v['model']=='EX30':
   strength=dict(label='Compact performance',text=f"A {f['length_mm']['value']} mm body with {power} kW and a quoted {acc}-second 0–100 km/h time.",keys=['length_mm','power_kw','zero_to_100_s'])
   trade=dict(label='Rear luggage',text=f"The seats-up rear boot is {boot} L on the stated open-volume measurement; front storage is separate.",keys=['boot_l','frunk_l'])
  elif v['model']=='EX40':
   strength=dict(label='Space and performance',text=f"Five seats, a {boot} L open rear boot and {power} kW of motor power.",keys=['seats','boot_l','power_kw'])
   trade=dict(label='Home charging ceiling',text=f"On-board AC charging tops out at {f['ac_kw']['value']} kW; a higher-rated home charger cannot raise that vehicle limit.",keys=['ac_kw'])
  else:
   strength=dict(label='Space and power',text=f"{f['seats']['value']} seats with {power} kW and a {boot} L boot on the stated loading basis.",keys=['seats','power_kw','boot_l'])
   trade=dict(label='Size to plan for',text=f"The body is {f['length_mm']['value']} mm long and {width} mm wide before mirrors; check parking space carefully.",keys=['length_mm','width_mm'])
  v['summary']=dict(strength=strength,tradeoff=trade)
 # Price observations are preserved separately with full scope. Avoid treating optional or conditional totals as headline list prices.
 for k in ['strength','tradeOff']:v.pop(k,None)
 # Stable factual aliases remove a fresh value beside an old contradictory unknown in buyer detail.
 if 'frunk_l' in fs and 'cargo_front_l' in before.get(v['id'],{}).get('facts',{}):
  a=copy.deepcopy(fs['frunk_l']);a['key']='cargo_front_l';v['facts'].append(a)
 if 'dc_test_station_kw' not in fs and v['model'] in ['EX30','EX40']:
  a=copy.deepcopy(fs['dc_charge_time_min']);a.update(key='dc_test_station_kw',value=150 if v['model']=='EX30' else 200,basis='Station rating associated with cited DC charging time; not vehicle peak',comparison='');v['facts'].append(a)
 if v['model']=='EX30' and 'Cross Country' in v['trim'] and v['modelYear']==2027:
  add(v,'width_with_mirrors_mm',2040,['cc-support-dimensions'],basis='Mirrors extended; Cross Country-specific AU MY27 manual');add(v,'width_mirrors_folded_mm',1953,['cc-support-dimensions'],basis='Mirrors folded; Cross Country-specific AU MY27 manual');add(v,'ground_clearance_mm',190,['cc-support-dimensions'],basis='At kerb weight plus one person; Cross Country-specific')
 # Normalise any encoded Unicode separator strings provided in family JSON.
 for f in v['facts']:
  for k,val in list(f.items()):
   if isinstance(val,str):f[k]=val.replace('\\u2013','–').replace('\\u00b0','°')
for v in variants:
 assert len({f['key'] for f in v['facts']})==len(v['facts']),v['id']
 for f in v['facts']:assert all(k in ids for k in f['sourceKeys']),(v['id'],f['key'],f['sourceKeys'])
out=dict(checkedAt=D,sources=sources,variants=variants,familyNotes={k:p.get('familyNotes',{}) for k,p in parts.items()})
(R/'normalized-evidence.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');print(len(variants),len(sources))
