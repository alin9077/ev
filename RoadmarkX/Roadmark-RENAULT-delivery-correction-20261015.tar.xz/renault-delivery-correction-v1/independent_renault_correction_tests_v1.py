#!/usr/bin/env python3
"""Controlled metadata-only tests of the two exact zero-read failures and canonical retry."""
import ast,copy,datetime,hashlib,importlib.util,json,pathlib,resource,sys
sys.dont_write_bytecode=True
C=pathlib.Path(__file__).resolve().parent;LIMIT=268435456;resource.setrlimit(resource.RLIMIT_AS,(LIMIT,LIMIT))
def pin(p):
 p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def imported(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def main():
 checker=C/'independent_renault_delivery_correction_v1.py';assert pin(checker)['sha256']=='56b8138ba9dcbf485bb63292583e11cd4567cf8723fd4a23c5ef5af33f722f64';m=imported('correction_checker_test',checker);h=imported('correction_helper_test',C/m.HELPER);assert pin(C/m.HELPER)['sha256']==m.HELPER_SHA;reviews=m.zero_reviews();rows=[]
 for name,d in reviews.items():
  rows.append({'invocation':{'path':name,**m.sh(d['failedInvocation'])},'terminal':{'path':pathlib.Path(d['failedTerminal']['path']).name,**m.sh(d['failedTerminal'])},'knownZeroReview':{'path':m.ZEROS[name][0],**m.sh(pin(C/m.ZEROS[name][0]))},'knownZeroSeedPreconditionFailure':True,'outcome':'NONZERO_OR_TIMEOUT'})
 tests=[]
 def case(name,mutation=None,expected=False):
  r=copy.deepcopy(rows)
  if mutation:mutation(r)
  try:m.validate_two_zero(r);got=True
  except AssertionError:got=False
  assert got is expected,(name,got);tests.append({'case':name,'expectedAccepted':expected,'actualAccepted':got,'result':'PASS'})
 case('two-exact-pinned-zero-failures',expected=True)
 case('missing-second-zero',lambda r:r.pop())
 case('duplicate-zero',lambda r:r.append(copy.deepcopy(r[0])))
 case('generic-other-failure',lambda r:r[1]['invocation'].update(path='scan-unreviewed.resources.invocation.json'))
 case('altered-failure-terminal-pin',lambda r:r[1]['terminal'].update(sha256='0'*64))
 case('altered-review-pin',lambda r:r[1]['knownZeroReview'].update(sha256='0'*64))
 case('failure-promoted-to-pass',lambda r:r[1].update(outcome='PASS'))
 case('unclassified-zero-flag',lambda r:r[1].update(knownZeroSeedPreconditionFailure=False))
 plan=json.loads((C/'ACTIVE-SCAN-RETRY-PLAN-v1.json').read_bytes());real_load=h.load;captured=[];h.dump=lambda path,value:captured.append((path,value))
 def retry_case(name,mutator=None,expected=False):
  p=copy.deepcopy(plan)
  if mutator:mutator(p)
  h.load=lambda path:p if pathlib.Path(path)==C/'ACTIVE-SCAN-RETRY-PLAN-v1.json' else real_load(path)
  try:h.validate_retry(True);got=True
  except AssertionError:got=False
  assert got is expected,(name,got);tests.append({'case':name,'expectedAccepted':expected,'actualAccepted':got,'result':'PASS'})
 retry_case('exact-canonical-one-argument-retry',expected=True)
 retry_case('original-wrong-output-parent',lambda p:p['command'].__setitem__(3,p['oldOutputArgument']))
 retry_case('changed-selection-path',lambda p:p['command'].__setitem__(2,str(C/'other.json')))
 retry_case('changed-active-candidate-pin',lambda p:p['activeCandidate'].update(sha256='0'*64))
 retry_case('changed-failure-review-pin',lambda p:p['failureReview'].update(sha256='0'*64))
 retry_case('resource-name-reuses-failure',lambda p:p.update(resourceReceipt=str(C/'scan-active-v1.resources.json')))
 assert len(captured)==1 and captured[0][1]['scannerExecuted'] is False and captured[0][1]['seedReads']==0
 original=ast.parse((C/m.A.BASE).read_bytes())
 for name,count in [('active',2),('persisted',1)]:
  fn=copy.deepcopy(next(n for n in original.body if isinstance(n,ast.FunctionDef) and n.name==name));changes=0
  for n in ast.walk(fn):
   if isinstance(n,ast.Constant) and n.value=='scan-active-v1.resources.json':n.value=m.RETRY;changes+=1
   elif isinstance(n,ast.Constant) and n.value=='SEED-READ-ACCOUNTING-after-active-v1.json':n.value=m.ACCOUNTING;changes+=1
  assert changes==count;ns=dict(m.M.__dict__);exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),str(C/m.A.BASE)+'#exact-active-retry-accounting','exec'),ns);actual=getattr(m.M,name).__code__;expected=ns[name].__code__;assert actual.co_code==expected.co_code and actual.co_consts==expected.co_consts;tests.append({'case':name+'-only-exact-literal-adaptations','result':'PASS'})
 result={'result':'PASS_EXACT_DELIVERY_CORRECTION_METADATA_TESTS','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checker':pin(checker),'helper':pin(C/m.HELPER),'testScript':pin(__file__),'canonicalPlan':pin(C/'ACTIVE-SCAN-RETRY-PLAN-v1.json'),'testCount':len(tests),'cases':tests,'canonicalValidationRecordedInMemoryOnly':True,'futureNinePassAccountingAndArchiveReplay':'NOT_EXECUTED_IN_THIS_METADATA_TEST','scope':{'metadataAndSealedSourceOnly':True,'archivePayloadReads':0,'seedPayloadReads':0,'retryExecuted':False,'noActualValidationOutputWritten':True,'noPriorOutputMutation':True},'resources':{'addressSpaceLimitBytes':LIMIT,'maxRssKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
 out=C/'INDEPENDENT-RENAULT-DELIVERY-CORRECTION-TESTS-v1.json'
 with out.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({'result':result['result'],'tests':len(tests),'output':pin(out)}))
if __name__=='__main__':main()
