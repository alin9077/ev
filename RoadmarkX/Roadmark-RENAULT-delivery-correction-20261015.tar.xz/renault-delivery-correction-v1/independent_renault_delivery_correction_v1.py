#!/usr/bin/env python3
"""Exact second precondition-failure correction; previous accepted document scope is unchanged."""
import ast,copy,datetime,hashlib,importlib.util,json,lzma,pathlib,resource,sys,tarfile,time
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent
ADAPTER='independent_renault_delivery_adapter_v1.py';ADAPTER_SHA='7d4d97bc2b4625df01d39ed57e49e88f472a3b45725213cec2b74afdc691b03b'
HELPER='correction_delivery_v2.py';HELPER_SHA='f175e00ef2704462febc4b81017084a4e6f7024c85c6310fb9d7c2343c515ba2'
COUNTER='build_seed_accounting_v1.py';COUNTER_SHA='a41688c728873fb4e40deba7cf4857020cf61b8aed688b6789b1f396d85bc73d'
ARTIFACT='Roadmark-RENAULT-delivery-correction-20261015.tar.xz'
ACCOUNTING='SEED-READ-ACCOUNTING-after-active-v2.json'
RETRY='scan-active-retry1.resources.json';MODE=None;REPLAY=None
ZEROS={'scan-fresh-03.resources.invocation.json':('INDEPENDENT-RENAULT-SCAN03-FAILURE-REVIEW-v1.json',5234,'e52b66ef43ebb122c0c056e4116da7ac8b32b7c67f8f2d8ad6e01ec4f2502b29'),'scan-active-v1.resources.invocation.json':('INDEPENDENT-RENAULT-ACTIVE-SCAN-FAILURE-REVIEW-v1.json',10772,'5a5b4085cda0feb0e34483aa311171a9c96d7677249756b1081c8b12010f737d')}
def imported(name,filename,sha):
 p=C/filename;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
A=imported('retained_delivery_adapter',ADAPTER,ADAPTER_SHA);M=A.M;ck=A.ck;load=A.load;pin=A.pin;sh=A.sh;check=A.check;checkref=A.checkref;pair=A.pair

def zero_reviews():
 out={}
 for invocation,(name,size,sha) in ZEROS.items():
  p=C/name;check(p,{'bytes':size,'sha256':sha});d=load(p);checkref(d['failedInvocation']);checkref(d['failedTerminal']);i=load(d['failedInvocation']['path']);t=load(d['failedTerminal']['path']);ck(P(d['failedInvocation']['path']).name==invocation and d['failureBoundary']['seedPayloadReads']==0 and d['failureBoundary']['archivePayloadReads']==0,'known-zero authority scope differs');ck(t['exitCode']==1 and not t['timedOut'] and all(t[k]==i[k] for k in ['command','childPid','startedAt','addressSpaceLimitBytes','wallLimitSeconds']),'known-zero actual terminal differs');out[invocation]=d
 return out

def validate_two_zero(rows):
 reviews=zero_reviews();by={r['invocation']['path']:r for r in rows};ck(len(rows)==len(by)==2 and set(by)==set(ZEROS),'only two exact known-zero failures permitted')
 for name,r in by.items():
  review=reviews[name];f=C/ZEROS[name][0];ck(r['outcome']=='NONZERO_OR_TIMEOUT' and r['knownZeroSeedPreconditionFailure'] is True,'known-zero outcome differs');ck(sh(r['knownZeroReview'])==sh(pin(f)) and P(r['knownZeroReview']['path']).name==f.name,'known-zero review pin differs');checkref(r['knownZeroReview']);ck(sh(r['invocation'])==sh(review['failedInvocation']) and sh(r['terminal'])==sh(review['failedTerminal']),'known-zero pair differs')
 return True

def adapted_seed_validator():
 tree=ast.parse((C/A.BASE).read_bytes());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='seed_accounting');counts={'attempts':0,'zeros':0,'oldref':0,'oldpin':0}
 class Change(ast.NodeTransformer):
  def visit_Compare(self,n):
   if ast.unparse(n)=='len(phases) == passes + 1':counts['attempts']+=1;n.comparators[0].right=ast.Constant(value=2)
   return self.generic_visit(n)
  def visit_Expr(self,n):
   call=n.value
   if isinstance(call,ast.Call) and isinstance(call.func,ast.Name):
    if call.func.id=='ck' and len(call.args)==2 and isinstance(call.args[1],ast.Constant):
     if call.args[1].value=='known-zero failure not exact':counts['zeros']+=1;call.args[0]=ast.Call(func=ast.Name(id='validate_two_zero',ctx=ast.Load()),args=[ast.Name(id='zero',ctx=ast.Load())],keywords=[])
     elif call.args[1].value=='known-zero authority differs':counts['oldpin']+=1;return ast.copy_location(ast.Pass(),n)
    if call.func.id=='checkref' and len(call.args)==1 and ast.unparse(call.args[0])=="zero[0]['knownZeroReview']":counts['oldref']+=1;return ast.copy_location(ast.Pass(),n)
   return self.generic_visit(n)
 fn=Change().visit(fn);ck(counts=={'attempts':1,'zeros':1,'oldref':1,'oldpin':1},'sealed seed validator adaptation changed');ns=dict(M.__dict__);ns['validate_two_zero']=validate_two_zero;exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),str(C/A.BASE)+'#two-exact-zeros','exec'),ns);return ns['seed_accounting']
VALIDATE_SEEDS=adapted_seed_validator()

def seed_accounting(name,passes):
 ck(name==ACCOUNTING and passes==7,'only after-active scope is adapted');d=VALIDATE_SEEDS(name,9);successful={r['invocation']['path'] for r in d['phases'] if r['outcome']=='PASS'};ck('scan-delivery-correction-v1.resources.invocation.json' in successful and 'scan-active-retry1.resources.invocation.json' in successful,'correction/retry seed passes missing');return d

def accounting():
 output=C/ACCOUNTING;ck(not output.exists(),'immutable accounting exists');reviews=zero_reviews();counter=imported('sealed_stage_counter',COUNTER,COUNTER_SHA);saved=sys.argv;sys.argv=[str(C/COUNTER),str(output)]
 try:counter.main()
 finally:sys.argv=saved
 d=load(output);target=[r for r in d['phases'] if r['invocation']['path']=='scan-active-v1.resources.invocation.json'];ck(len(target)==1 and target[0]['outcome']=='NONZERO_OR_TIMEOUT' and target[0]['knownZeroSeedPreconditionFailure'] is False,'exact second failed phase absent or already modified');r=target[0];review=reviews['scan-active-v1.resources.invocation.json'];ck(sh(r['invocation'])==sh(review['failedInvocation']) and sh(r['terminal'])==sh(review['failedTerminal']),'second failure pins differ');r['knownZeroSeedPreconditionFailure']=True;r['knownZeroReview']={'path':ZEROS['scan-active-v1.resources.invocation.json'][0],**sh(pin(C/ZEROS['scan-active-v1.resources.invocation.json'][0]))};unknown=d['inheritedLocal']['unknownPartialLocalReadsPossibleForPhasesWithoutAudiCompletion'];ck(len(unknown)==1 and unknown[0]==r['invocation'],'other unknown partial reads may not be removed');d['inheritedLocal']['unknownPartialLocalReadsPossibleForPhasesWithoutAudiCompletion']=[]
 d['secondKnownZeroCorrection']={'checker':pin(__file__),'originalCounter':pin(C/COUNTER),'failureReview':pin(C/ZEROS['scan-active-v1.resources.invocation.json'][0]),'onlyOutcomeRefinement':'Known output-parent assertion before seed_sets; all actual stage receipts and other phase outcomes unchanged','priorDocumentAccountingUnchanged':pin(C/'SEED-READ-ACCOUNTING-after-docs-v1.json')}
 # This is the new output prepared in this invocation, before any acceptance or persistence.
 output.write_text(json.dumps(d,indent=2)+'\n');seed_accounting(ACCOUNTING,7);print(json.dumps({'output':pin(output),'successfulPasses':9,'knownZeroFailures':2,'attempts':11}))

def correction_metadata():
 invpath=C/'DELIVERY-CORRECTION-MEMBER-INVENTORY-v1.json';inv=load(invpath);ck(inv['status']=='EXACT_DELIVERY_ONLY_CORRECTION' and inv['outsideRecoveryArchiveSet'] is True and inv['unchangedRecoveryArchiveCount']==142,'correction inventory scope differs');rows=inv['files'];ck(len({r['originalPath'] for r in rows})==len(rows) and len({r['path'] for r in rows})==len(rows),'duplicate correction members')
 for r in rows:
  p=P(r['originalPath']);ck((p.parent==C or (p.parent==C/'run-logs' and p.suffix=='.log')) and r['path']=='renault-delivery-correction-v1/'+p.name,'correction path outside namespace');check(p,r)
 own=[r for r in rows if r['originalPath']==str(P(__file__).resolve())];ck(len(own)==1 and sh(own[0])==sh(pin(__file__)),'correction checker retention differs');ck(pin(C/HELPER)['sha256']==HELPER_SHA and any(r['originalPath']==str(C/HELPER) and r['sha256']==HELPER_SHA for r in rows),'correction delivery helper missing/changed')
 expected=[{'path':r['path'],'originalPath':r['originalPath'],**sh(r)} for r in rows]+[{'path':'renault-delivery-correction-v1/'+invpath.name,'originalPath':str(invpath),**sh(pin(invpath))}];sel=C/'DELIVERY-CORRECTION-PRIVACY-SELECTION-v1.json';selection=load(sel);ck(selection['files']==[{'localPath':r['originalPath'],**sh(r)} for r in expected],'correction privacy selection/order differs');M.privacy_gate('DELIVERY-CORRECTION-PRIVACY-GATE-v1.json',[P(r['localPath']) for r in selection['files']],'scan-delivery-correction-v1.resources.json');t=pair(C/'scan-delivery-correction-v1.resources.json');ck(t['command']==['python3','scan_documents_v1.py',str(sel),str(C/'DELIVERY-CORRECTION-PRIVACY-GATE-v1.json')],'correction scan command differs')
 package=load(C/'DELIVERY-CORRECTION-PACKAGE-v1.json');ck(package['filename']==ARTIFACT and package['file']==str(C.parents[1]/ARTIFACT) and package['members']==expected and package['memberCount']==len(expected) and package['uncompressedBytes']==sum(r['bytes'] for r in expected),'correction package members differ');ck(package['localFullMemberReplayAndXzEof']=='PASS' and package['outsideRecoveryArchiveSet'] is True and package['unchangedRecoveryArchiveCount']==142,'correction package proof/scope differs');ck(package['privacyGate']==pin(C/'DELIVERY-CORRECTION-PRIVACY-GATE-v1.json') and package['selection']==pin(sel) and package['packager']==pin(C/HELPER),'correction package dependency differs');t=pair(C/'package-delivery-correction-v1.resources.json');ck(t['command']==['python3',HELPER,'package'],'correction package terminal command differs');return inv,package,expected

def replay_correction(package,expected):
 global REPLAY
 if REPLAY is not None:return REPLAY
 if MODE=='active':
  p=P(package['file']);before=M.identity(p);h=hashlib.sha256();total=0
  with p.open('rb') as f:
   while b:=f.read(65536):total+=len(b);h.update(b)
  ck({'bytes':total,'sha256':h.hexdigest()}==sh(package),'correction archive compressed hash differs');got=[]
  with tarfile.open(p,'r:xz') as tar:
   for m in tar:
    ck(m.isfile() and not m.issym() and not m.islnk(),'correction nonregular member');f=tar.extractfile(m);mh=hashlib.sha256();n=0
    while b:=f.read(65536):n+=len(b);mh.update(b)
    got.append({'path':m.name,'bytes':n,'sha256':mh.hexdigest()})
  ck(got==[{k:r[k] for k in ['path','bytes','sha256']} for r in expected],'correction member bytes differ')
  with lzma.open(p,'rb') as f:
   while f.read(65536):pass
  ck(M.identity(p)==before,'correction archive changed during replay');REPLAY={'result':'PASS_EXACT_DELIVERY_CORRECTION_MEMBERS_AND_XZ_EOF','package':pin(C/'DELIVERY-CORRECTION-PACKAGE-v1.json'),'archive':{'path':str(p),**sh(package)},'members':len(expected),'uncompressedBytes':sum(r['bytes'] for r in expected),'nativeByteReadbackVerified':False}
 else:
  receipt=load(C/M.NAMES['active']);ck(receipt['checkerScript']==pin(__file__) and receipt['knownZeroSeedPreconditionFailure']==2 and receipt['seedCompletedInvocations']==9 and receipt['nativeByteReadbackVerified'] is False,'prior active correction acceptance differs');t=pair(C/'independent-active-v1.resources.json');ck(t['command']==['python3',P(__file__).name,'active'],'prior correction acceptance command differs');r=receipt['correctionArtifactReplay'];ck(r['result']=='PASS_EXACT_DELIVERY_CORRECTION_MEMBERS_AND_XZ_EOF' and r['package']==pin(C/'DELIVERY-CORRECTION-PACKAGE-v1.json') and r['archive']=={'path':package['file'],**sh(package)} and r['members']==len(expected),'prior correction replay binding differs');REPLAY=r
 return REPLAY

def retained():
 kept=A.retained();inv,package,expected=correction_metadata();ck(not(set(kept)&{r['originalPath'] for r in inv['files']}),'correction duplicates retained original paths');kept.update({r['originalPath']:sh(r) for r in expected});replay_correction(package,expected);return kept

def correction_native(expected):
 ip=C/'DELIVERY-CORRECTION-UPLOAD-IDENTITIES.json';d=load(ip);ck(d['status']=='CREATE_CONFIRMED_NATIVE_BYTE_READBACK_UNPASSED' and d['acceptanceScope']==A.SCOPE and d['nativeByteReadbackVerified'] is False and d['normalizer']==pin(C/HELPER),'correction native scope/helper differs');ck(d['nativeMaterializationAttemptsForThisArtifact']==0 and d['originalAccessDenial']==A.denial()['response'],'correction access boundary differs');ck(len(d['files'])==1,'correction native count differs');x=d['files'][0];ck(x['filename']==ARTIFACT and x['localPath']==expected['file'] and sh(x)==sh(expected),'correction local byte identity differs');qp=C/'library-correction-host-create-request.json';rp=C/'library-correction-provider-results.json';q=load(qp);raw=load(rp);ck(q['files']==[expected['file']] and raw.get('isError') is False and len(raw['structuredContent']['results'])==1,'correction host request/provider scope differs');ck(d['exactHostRequest']==pin(qp) and d['exactProviderResponse']==pin(rp),'correction raw receipt pins differ');r=raw['structuredContent']['results'][0];ck(r['operation']=='create_library_file' and r['status']=='succeeded' and r['path']=='/'+ARTIFACT and r['file_name']==ARTIFACT and r['file_size_bytes']==x['bytes'],'correction provider tuple differs');ck(x['library_file_id']==r['library_file_id'] and x['file_id']==r['file_id'] and type(x['version']) is int and x['version']==r['current_version_number'],'correction native identifiers differ');ck(x['library_file_id'].startswith('libfile_') and x['file_id'].startswith('file_'),'correction identifier form differs');attrs=[{'name':'user.library-file-version','value':str(x['version'])}];ck(r['xattrs']==d['returnedXattrsApplied']==attrs and set(A.os.listxattr(x['localPath']))=={z['name'] for z in attrs} and all(A.os.getxattr(x['localPath'],z['name']).decode()==z['value'] for z in attrs),'correction returned/local xattrs differ');ck(all(x[k] is v for k,v in {'providerCreateConfirmed':True,'localBytesVerified':True,'createReceiptAndLocalIdentityVerified':True,'nativeByteReadbackVerified':False}.items()) and x['verificationBasis']=='EXACT_SERVER_CREATE_TUPLE_AND_LOCAL_HASH','correction create/readback flags differ');ck(M.identity(P(x['localPath']))[0]==x['bytes'],'correction local file size differs');return x

def adapt_phase_functions():
 tree=ast.parse((C/A.BASE).read_bytes())
 for name,count in [('active',2),('persisted',1)]:
  fn=copy.deepcopy(next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name));changed=0
  for node in ast.walk(fn):
   if isinstance(node,ast.Constant) and node.value=='scan-active-v1.resources.json':node.value=RETRY;changed+=1
   elif isinstance(node,ast.Constant) and node.value=='SEED-READ-ACCOUNTING-after-active-v1.json':node.value=ACCOUNTING;changed+=1
  ck(changed==count,'active/persisted literal adaptation differs');exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),str(C/A.BASE)+'#exact-active-retry-accounting','exec'),M.__dict__)
adapt_phase_functions();M.retained=retained;M.seed_accounting=seed_accounting

def correction_checks(mode,result):
 reviews=zero_reviews();d=reviews['scan-active-v1.resources.invocation.json'];check(M.ACTIVE,d['immutableActiveCandidate']);ck(load(M.ACTIVE)['seedReadAccountingAsOfActivePreparation']==load(C/'SEED-READ-ACCOUNTING-after-docs-v1.json'),'as-of-seven-pass active snapshot changed');inv,p,expected=correction_metadata();artifact=correction_native(p);replay_correction(p,expected);t=pair(C/'normalize-correction-v1.resources.json');ck(t['command']==['python3',HELPER,'normalize'],'correction native normalization terminal differs');t=pair(C/RETRY);ck(t['command']==['python3','scan_documents_v1.py',str(C/'ACTIVE-PRIVACY-SELECTION-v1.json'),str(C/'ACTIVE-PRIVACY-GATE.json')],'exact canonical corrected scan command differs');seed_accounting(ACCOUNTING,7);t=pair(C/'seed-accounting-after-active-v2.resources.json');ck(t['command']==['python3',P(__file__).name,'accounting'],'correction accounting command differs')
 prior=load(C/M.NAMES['documents']);A.scoped_receipt(prior);ck(prior['checkerScript']==pin(C/ADAPTER) and prior['seedCompletedInvocations']==7 and prior['knownZeroSeedPreconditionFailure']==1,'historical document acceptance upgraded');allids=[r['library_file_id'] for r in result['files']]+[result['supplementalArtifactIdentity']['library_file_id'],artifact['library_file_id']];ck(len(allids)==len(set(allids)),'correction identity collision')
 result.update({'seedCompletedInvocations':9,'knownZeroSeedPreconditionFailure':2,'scanAttemptsAccounted':11,'activeCandidatePreservedAsOfSevenPasses':True,'correctionArtifactReplay':REPLAY,'correctionArtifactIdentity':artifact,'correctionOutside142ArchiveRecoverySet':True,'correctionHelper':pin(C/HELPER),'priorAcceptedDocumentChecker':pin(C/ADAPTER),'exactKnownZeroReviews':[pin(C/ZEROS[x][0]) for x in sorted(ZEROS)],'correctedActiveScan':{'terminal':pin(C/RETRY),'invocation':pin(C/'scan-active-retry1.resources.invocation.json'),'report':pin(C/'ACTIVE-PRIVACY-GATE.json')},'correctedSeedAccounting':pin(C/ACCOUNTING),'correctionRetentionInventory':pin(C/'DELIVERY-CORRECTION-MEMBER-INVENTORY-v1.json')})
 if mode in ['persisted','terminal']:
  final=load(C/'FINAL-RENAULT-UPLOAD-RECEIPTS.json');corr=final['deliveryCorrection'];ck(corr['artifact']==artifact and corr['nativeByteReadbackVerified'] is False and corr['outsideRecoveryArchiveSet'] is True and corr['unchangedRecoveryArchiveCount']==142 and corr['successfulSeedPasses']==9 and corr['knownZeroFailures']==2,'final correction scope/identity differs');ck(corr['checker']==pin(__file__) and corr['helper']==pin(C/HELPER),'final correction helper pins differ');ck(corr['knownZeroReviews']==result['exactKnownZeroReviews'] and corr['accounting']==pin(C/ACCOUNTING),'final failure/accounting pointers differ');kept={**retained(),**M.embedded(final['correctionLateMetadata'])}
  required=['ACTIVE-PRIVACY-GATE.json',ACCOUNTING,'DELIVERY-CORRECTION-PACKAGE-v1.json','DELIVERY-CORRECTION-PRIVACY-SELECTION-v1.json','DELIVERY-CORRECTION-PRIVACY-GATE-v1.json','DELIVERY-CORRECTION-UPLOAD-IDENTITIES.json','library-correction-host-create-request.json','library-correction-provider-results.json','INDEPENDENT-RENAULT-ACTIVE-CHECK-v1.json']
  for stage in ['scan-active-retry1','scan-delivery-correction-v1','package-delivery-correction-v1','normalize-correction-v1','seed-accounting-after-active-v2','independent-active-v1']:
   required.extend([stage+'.resources.json',stage+'.resources.invocation.json','run-logs/'+stage+'.stdout.log','run-logs/'+stage+'.stderr.log'])
  for n in required:ck(kept.get(str(C/n))==sh(pin(C/n)),'final correction evidence missing '+n)
  for folder in ['seed-read-invocations','audi-seed-read-invocations','deepal-seed-read-invocations']:
   for q in (C/folder).glob('*.json'):
    info=load(q)
    if any((lambda t:info['processId']==t['childPid'] and t['startedAt']<=info['completedAt']<=t['endedAt'])(pair(C/(s+'.resources.json'))) for s in ['scan-delivery-correction-v1','scan-active-retry1']):ck(kept.get(str(q))==sh(pin(q)),'correction/retry seed ledger not retained')
 return result

def main():
 global MODE
 ck(len(sys.argv)==2 and sys.argv[1] in ['accounting','active','persisted','terminal'],'accounting|active|persisted|terminal only');resource.setrlimit(resource.RLIMIT_AS,(M.LIMIT,M.LIMIT));MODE=sys.argv[1]
 if MODE=='accounting':accounting();return
 A.MODE=MODE;out=C/M.NAMES[MODE];ck(not out.exists(),'immutable independent output exists');start=time.monotonic();result=getattr(M,MODE)();result=A.extra_checks(MODE,result);result=correction_checks(MODE,result)
 record={'schemaVersion':3,'result':'PASS_INDEPENDENT_RENAULT_'+MODE.upper(),'acceptanceScope':A.SCOPE,'nativePersistenceStatus':'CREATE_CONFIRMED_NATIVE_BYTE_READBACK_UNPASSED','nativeByteReadbackVerified':False,'blockedReadbackEvidence':A.denial(),'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checkerScript':pin(__file__),'sealedBaseChecker':pin(C/A.BASE),'deliveryAdapter':pin(C/A.DELIVERY),'correctionScope':'Only exact second known-zero precondition failure, new canonical active retry, and unique correction artifact; no prior success upgraded',**result,'scope':{'oldRecoveryArchivePayloadReads':0,'originalDeliverySupplementPayloadReads':0,'correctionArchiveReplay':MODE=='active','seedPayloadReads':0,'noExcludedRawRead':True,'noNativeReadbackAttempt':True,'noUploadOrExternalMutation':True},'resources':{'wallSeconds':round(time.monotonic()-start,3),'maxRssKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'addressSpaceLimitBytes':M.LIMIT}}
 with out.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
 print(json.dumps({'result':record['result'],'successfulSeedPasses':9,'knownZeroFailures':2,'nativeByteReadbackVerified':False,'output':pin(out)}))
if __name__=='__main__':main()
