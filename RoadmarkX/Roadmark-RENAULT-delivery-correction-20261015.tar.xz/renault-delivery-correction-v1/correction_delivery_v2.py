#!/usr/bin/env python3
"""Append-only delivery correction: no recovery archive or delivered document changes."""
import ast,hashlib,importlib.util,io,json,lzma,os,pathlib,resource,subprocess,sys,tarfile
sys.dont_write_bytecode=True
P=pathlib.Path;C=P(__file__).resolve().parent;R=C.parents[1];LIMIT=268435456
resource.setrlimit(resource.RLIMIT_AS,(LIMIT,LIMIT))
ARTIFACT='Roadmark-RENAULT-delivery-correction-20261015.tar.xz'
PRIOR='delivery_native_adapter_v3.py';PRIOR_SHA='f5bec06d762fca6b3d34ea13f7e7f17d2f5353dbbd379a5e1b13e967aabbc474'
SCOPE='DOCUMENT_CONTENT_AND_SERVER_CREATE_IDENTITY_ONLY'
def load(p):return json.loads(P(p).read_bytes())
def pin(p):
 p=P(p);h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(65536):h.update(b);n+=len(b)
 return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
def sh(r):return {k:r[k] for k in ['bytes','sha256']}
def identity(p):
 p=P(p);s=p.lstat();assert p.is_file() and not p.is_symlink() and not any(q.is_symlink() for q in p.parents);return [s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_ino,s.st_dev]
def check(p,r):
 a=identity(p);got=pin(p);assert identity(p)==a and sh(got)==sh(r);return got
def dump(p,d):
 with P(p).open('x') as f:json.dump(d,f,indent=2);f.write('\n')
def prior():
 p=C/PRIOR;assert pin(p)['sha256']==PRIOR_SHA;s=importlib.util.spec_from_file_location('retained_delivery',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def validate_retry(write):
 plan=load(C/'ACTIVE-SCAN-RETRY-PLAN-v1.json');cmd=plan['command'];assert plan['cwd']==str(C) and cmd==['python3','scan_documents_v1.py',str(C/'ACTIVE-PRIVACY-SELECTION-v1.json'),str(C/'ACTIVE-PRIVACY-GATE.json')]
 for k in ['scanner','boundedRunner','selection','activeCandidate','failureReview','exactPreviousInvocation']:check(plan[k]['path'],plan[k])
 previous=load(plan['exactPreviousInvocation']['path'])['command'];assert previous[:3]==cmd[:3] and previous[3]==plan['oldOutputArgument'] and plan['onlyChangedArgumentIndex']==3 and cmd[3]==plan['newOutputArgument'] and previous[3]!=cmd[3]
 assert P(cmd[2]).parent.resolve()==C and P(cmd[3]).parent.resolve()==C and not P(cmd[3]).exists();assert plan['resourceReceipt']==str(C/'scan-active-retry1.resources.json');assert plan['stdout']==str(C/'run-logs/scan-active-retry1.stdout.log') and plan['stderr']==str(C/'run-logs/scan-active-retry1.stderr.log')
 for n in ['scan-active-retry1.resources.json','scan-active-retry1.resources.invocation.json','run-logs/scan-active-retry1.stdout.log','run-logs/scan-active-retry1.stderr.log']:assert not (C/n).exists()
 assert plan['addressSpaceLimitBytes']==LIMIT and plan['wallLimitSeconds']==600;selected=load(cmd[2])['files'];assert len(selected)==1 and selected[0]['localPath']==plan['activeCandidate']['path'] and sh(selected[0])==sh(plan['activeCandidate'])
 record={'result':'PASS_CANONICAL_RETRY_INVOCATION_PATH_CONTRACT_WITHOUT_EXECUTION','plan':pin(C/'ACTIVE-SCAN-RETRY-PLAN-v1.json'),'helper':pin(__file__),'cwd':str(C),'command':cmd,'selectedCandidate':plan['activeCandidate'],'onlyChangedArgumentIndex':3,'scannerParentContractSatisfied':True,'oldFailureOverwritten':False,'scannerExecuted':False,'seedReads':0}
 if write:dump(C/'ACTIVE-SCAN-RETRY-PLAN-VALIDATION-v1.json',record)
 else:assert load(C/'ACTIVE-SCAN-RETRY-PLAN-VALIDATION-v1.json')==record
 return plan

def retry():
 p=validate_retry(False);command=['python3','run_bounded_v1.py',P(p['resourceReceipt']).name,'--sole-heavy-slot',*p['command']]
 with P(p['stdout']).open('x') as out,P(p['stderr']).open('x') as err:r=subprocess.run(command,cwd=C,stdout=out,stderr=err,check=False)
 print(json.dumps({'phase':'scan-active-retry1','exitCode':r.returncode,'terminal':p['resourceReceipt']}));sys.exit(r.returncode)

def package():
 selection=C/'DELIVERY-CORRECTION-PRIVACY-SELECTION-v1.json';gate=C/'DELIVERY-CORRECTION-PRIVACY-GATE-v1.json';rows=load(selection)['files'];g=load(gate);assert g['status']=='clean' and not g['findings'] and not g['errors'] and g['selectionPin']==sh(pin(selection));want={r['localPath']:sh(r) for r in rows};assert len(want)==len(rows) and {r['path']:sh(r) for r in g['files']}==want
 out=R/ARTIFACT;assert not out.exists();members=[]
 with tarfile.open(out,'w:xz',preset=0) as t:
  for r in rows:
   p=P(r['localPath']);check(p,r);b=p.read_bytes();assert {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}==sh(r);name='renault-delivery-correction-v1/'+p.name;assert name not in {x['path'] for x in members};ti=tarfile.TarInfo(name);ti.size=len(b);ti.mode=0o644;ti.mtime=0;t.addfile(ti,io.BytesIO(b));members.append({'path':name,'originalPath':str(p),**sh(r)})
 got=[]
 with tarfile.open(out,'r:xz') as t:
  for m in t:
   assert m.isfile();b=t.extractfile(m).read();got.append({'path':m.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 assert got==[{k:r[k] for k in ['path','bytes','sha256']} for r in members]
 with lzma.open(out,'rb') as f:
  while f.read(65536):pass
 dump(C/'DELIVERY-CORRECTION-PACKAGE-v1.json',{'filename':ARTIFACT,'file':str(out),**sh(pin(out)),'members':members,'memberCount':len(members),'uncompressedBytes':sum(r['bytes'] for r in members),'privacyGate':pin(gate),'selection':pin(selection),'localFullMemberReplayAndXzEof':'PASS','outsideRecoveryArchiveSet':True,'unchangedRecoveryArchiveCount':142,'packager':pin(__file__)})
 print(json.dumps({'artifact':ARTIFACT,'members':len(members),'bytes':out.stat().st_size}))

def normalize():
 qpath=C/'library-correction-host-create-request.json';rpath=C/'library-correction-provider-results.json';q=load(qpath);raw=load(rpath);p=load(C/'DELIVERY-CORRECTION-PACKAGE-v1.json');assert q['files']==[p['file']] and raw.get('isError') is False and len(raw['structuredContent']['results'])==1;r=raw['structuredContent']['results'][0];local=P(p['file']);check(local,p)
 assert r['operation']=='create_library_file' and r['status']=='succeeded' and r['path']=='/'+ARTIFACT and r['file_name']==ARTIFACT and r['file_size_bytes']==p['bytes'];assert r['library_file_id'].startswith('libfile_') and r['file_id'].startswith('file_') and type(r['current_version_number']) is int;attrs=[{'name':'user.library-file-version','value':str(r['current_version_number'])}];assert r['xattrs']==attrs
 for x in attrs:os.setxattr(local,x['name'],x['value'].encode())
 assert set(os.listxattr(local))=={x['name'] for x in attrs} and all(os.getxattr(local,x['name']).decode()==x['value'] for x in attrs);check(local,p)
 a={'filename':ARTIFACT,'localPath':str(local),**sh(p),'library_file_id':r['library_file_id'],'file_id':r['file_id'],'version':r['current_version_number'],'providerCreateConfirmed':True,'localBytesVerified':True,'createReceiptAndLocalIdentityVerified':True,'nativeByteReadbackVerified':False,'verificationBasis':'EXACT_SERVER_CREATE_TUPLE_AND_LOCAL_HASH'}
 dump(C/'DELIVERY-CORRECTION-UPLOAD-IDENTITIES.json',{'status':'CREATE_CONFIRMED_NATIVE_BYTE_READBACK_UNPASSED','acceptanceScope':SCOPE,'nativeByteReadbackVerified':False,'files':[a],'exactHostRequest':pin(qpath),'exactProviderResponse':pin(rpath),'normalizer':pin(__file__),'returnedXattrsApplied':attrs,'nativeMaterializationAttemptsForThisArtifact':0,'originalAccessDenial':pin(C/'library-archives-materialize-provider-results.json')});print(json.dumps({'createConfirmed':1,'nativeByteReadbackVerified':False}))

def final():
 out=C/'FINAL-RENAULT-UPLOAD-RECEIPTS.json';assert not out.exists();m=prior();fin=m.mod('finisher');source=(C/'finalize_delivery_v2.py').read_bytes();tree=ast.parse(source);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='final');changes=[n for n in ast.walk(fn) if isinstance(n,ast.Constant) and n.value=='SEED-READ-ACCOUNTING-after-active-v1.json'];assert len(changes)==1;changes[0].value='SEED-READ-ACCOUNTING-after-active-v2.json';adapted=ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[]));exec(compile(adapted,str(C/'finalize_delivery_v2.py')+'#exact-accounting-v2-adaptation','exec'),fin.__dict__);fin.final();d=m.annotate(load(out));d['status']='LOCAL_RECOVERY_VERIFIED_SERVER_CREATE_CONFIRMED_NATIVE_READBACK_UNPASSED_RELEASE_UNPASSED';ids=load(C/'DELIVERY-CORRECTION-UPLOAD-IDENTITIES.json');assert len(ids['files'])==1 and ids['nativeByteReadbackVerified'] is False
 checker=C/'independent_renault_delivery_correction_v1.py';members=load(C/'DELIVERY-CORRECTION-MEMBER-INVENTORY-v1.json')['files'];matches=[r for r in members if r['originalPath']==str(checker)];assert len(matches)==1;check(checker,matches[0])
 d['deliveryCorrection']={'status':'EXACT_SECOND_KNOWN_ZERO_AND_CANONICAL_RETRY_CLOSURE','helper':pin(__file__),'checker':pin(checker),'artifact':ids['files'][0],'artifactIdentityReceipt':pin(C/'DELIVERY-CORRECTION-UPLOAD-IDENTITIES.json'),'package':pin(C/'DELIVERY-CORRECTION-PACKAGE-v1.json'),'memberInventory':pin(C/'DELIVERY-CORRECTION-MEMBER-INVENTORY-v1.json'),'privacyGate':pin(C/'DELIVERY-CORRECTION-PRIVACY-GATE-v1.json'),'failureReview':pin(C/'INDEPENDENT-RENAULT-ACTIVE-SCAN-FAILURE-REVIEW-v1.json'),'canonicalRetryPlan':pin(C/'ACTIVE-SCAN-RETRY-PLAN-v1.json'),'canonicalRetryValidation':pin(C/'ACTIVE-SCAN-RETRY-PLAN-VALIDATION-v1.json'),'successfulSeedPasses':9,'knownZeroFailures':2,'knownZeroReviews':[pin(C/'INDEPENDENT-RENAULT-ACTIVE-SCAN-FAILURE-REVIEW-v1.json'),pin(C/'INDEPENDENT-RENAULT-SCAN03-FAILURE-REVIEW-v1.json')],'accounting':pin(C/'SEED-READ-ACCOUNTING-after-active-v2.json'),'unchangedRecoveryArchiveCount':142,'unchangedActiveCandidateAsOfSnapshot':load(C/'ACTIVE-SCAN-RETRY-PLAN-v1.json')['activeCandidate'],'activeSnapshotPredatesCorrection':True,'unchangedPriorDocumentAcceptance':pin(C/'INDEPENDENT-RENAULT-DOCUMENT-CHECK-v1.json'),'outsideRecoveryArchiveSet':True,'nativeByteReadbackVerified':False}
 names=['ACTIVE-SCAN-RETRY-PLAN-VALIDATION-v1.json','ACTIVE-PRIVACY-GATE.json','DELIVERY-CORRECTION-MEMBER-INVENTORY-v1.json','DELIVERY-CORRECTION-PRIVACY-SELECTION-v1.json','DELIVERY-CORRECTION-PRIVACY-GATE-v1.json','DELIVERY-CORRECTION-PACKAGE-v1.json','DELIVERY-CORRECTION-UPLOAD-IDENTITIES.json','library-correction-host-create-request.json','library-correction-provider-results.json','SEED-READ-ACCOUNTING-after-active-v2.json','INDEPENDENT-RENAULT-ACTIVE-CHECK-v1.json','ACTIVE-UPLOAD-IDENTITIES.json','ACTIVE-NATIVE-READBACK-v1.json','library-active-host-create-request.json','library-active-provider-results.json','library-active-results.json','library-active-verified.jsonl','DELIVERY-CONFIRMATION.json']
 stages=['scan-delivery-correction-v1','package-delivery-correction-v1','normalize-correction-v1','scan-active-retry1','seed-accounting-after-active-v2','independent-active-v1','normalize-active-v1']
 for stage in stages:names.extend([stage+'.resources.json',stage+'.resources.invocation.json','run-logs/'+stage+'.stdout.log','run-logs/'+stage+'.stderr.log'])
 paths={C/n for n in names};terms=[load(C/(n+'.resources.json')) for n in ['scan-delivery-correction-v1','scan-active-retry1']]
 for folder in ['seed-read-invocations','audi-seed-read-invocations','deepal-seed-read-invocations']:
  for p in (C/folder).glob('*.json'):
   a=load(p)
   if any(a['processId']==t['childPid'] and t['startedAt']<=a['completedAt']<=t['endedAt'] for t in terms):paths.add(p)
 d['correctionLateMetadata']=[{'file':pin(p),'utf8':p.read_text()} for p in sorted(paths)];d['delivery']='Exact five working files already accepted in the recorded parent attachment message; closure retains native byte-readback as unpassed.'
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'finalCorrectionPrepared':True,'successfulSeedPasses':9,'knownZeroPreconditionFailures':2,'nativeByteReadbackVerified':False}))
if __name__=='__main__':
 mode=sys.argv[1]
 if mode=='validate-retry':validate_retry(True)
 elif mode=='retry':retry()
 elif mode=='package':package()
 elif mode=='normalize':normalize()
 elif mode=='final':final()
 else:raise ValueError('unsupported correction-only mode')
