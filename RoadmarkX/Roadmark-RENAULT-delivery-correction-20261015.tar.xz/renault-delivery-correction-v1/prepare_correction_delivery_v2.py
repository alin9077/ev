#!/usr/bin/env python3
"""Immutable exact-text preparation from the retained unexecuted v1 draft."""
import ast,hashlib
from pathlib import Path
C=Path(__file__).resolve().parent
p=C/'correction_delivery_v1.py';b=p.read_bytes();assert hashlib.sha256(b).hexdigest()=='767dd7068c3fab09db40e9c6a3031b51b865c398f9b86c82f28a46f4745e6d86';s=b.decode()
def replace(a,b):
 global s
 assert s.count(a)==1,repr(a);s=s.replace(a,b,1)
replace('import hashlib,importlib.util,io,json,lzma,os,pathlib,resource,subprocess,sys,tarfile','import ast,hashlib,importlib.util,io,json,lzma,os,pathlib,resource,subprocess,sys,tarfile')
replace("out=C/'FINAL-RENAULT-UPLOAD-RECEIPTS.json';assert not out.exists();prior().build('final');d=load(out);ids=load(C/'DELIVERY-CORRECTION-UPLOAD-IDENTITIES.json');assert len(ids['files'])==1 and ids['nativeByteReadbackVerified'] is False\n d['seedReadAccounting']=load(C/'SEED-READ-ACCOUNTING-after-active-v2.json')", "out=C/'FINAL-RENAULT-UPLOAD-RECEIPTS.json';assert not out.exists();m=prior();fin=m.mod('finisher');source=(C/'finalize_delivery_v2.py').read_bytes();tree=ast.parse(source);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='final');changes=[n for n in ast.walk(fn) if isinstance(n,ast.Constant) and n.value=='SEED-READ-ACCOUNTING-after-active-v1.json'];assert len(changes)==1;changes[0].value='SEED-READ-ACCOUNTING-after-active-v2.json';adapted=ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[]));exec(compile(adapted,str(C/'finalize_delivery_v2.py')+'#exact-accounting-v2-adaptation','exec'),fin.__dict__);fin.final();d=m.annotate(load(out));d['status']='LOCAL_RECOVERY_VERIFIED_SERVER_CREATE_CONFIRMED_NATIVE_READBACK_UNPASSED_RELEASE_UNPASSED';ids=load(C/'DELIVERY-CORRECTION-UPLOAD-IDENTITIES.json');assert len(ids['files'])==1 and ids['nativeByteReadbackVerified'] is False\n checker=C/'independent_renault_delivery_correction_v1.py';members=load(C/'DELIVERY-CORRECTION-MEMBER-INVENTORY-v1.json')['files'];matches=[r for r in members if r['originalPath']==str(checker)];assert len(matches)==1;check(checker,matches[0])")
replace("'helper':pin(__file__),'artifactIdentity':ids['files'][0]","'helper':pin(__file__),'checker':pin(checker),'artifact':ids['files'][0]")
replace("'successfulSeedPasses':9,'knownZeroPreconditionFailures':2,'unchangedActiveCandidateAsOfSnapshot'","'successfulSeedPasses':9,'knownZeroFailures':2,'knownZeroReviews':[pin(C/'INDEPENDENT-RENAULT-ACTIVE-SCAN-FAILURE-REVIEW-v1.json'),pin(C/'INDEPENDENT-RENAULT-SCAN03-FAILURE-REVIEW-v1.json')],'accounting':pin(C/'SEED-READ-ACCOUNTING-after-active-v2.json'),'unchangedRecoveryArchiveCount':142,'unchangedActiveCandidateAsOfSnapshot'")
replace("'outside142ArchiveRecoverySet':True","'outsideRecoveryArchiveSet':True")
replace("'SEED-READ-ACCOUNTING-after-active-v1.json','SEED-READ-ACCOUNTING-after-active-v2.json'","'SEED-READ-ACCOUNTING-after-active-v2.json'")
ast.parse(s);out=C/'correction_delivery_v2.py';out.open('x').write(s);print(len(out.read_bytes()),hashlib.sha256(out.read_bytes()).hexdigest())
