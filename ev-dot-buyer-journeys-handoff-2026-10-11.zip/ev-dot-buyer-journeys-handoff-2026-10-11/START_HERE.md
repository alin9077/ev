# EV Side by Side handoff for DOT

Prepared 11 October 2026, Australia/Sydney.

## Start here

1. Extract this whole archive into a working directory.
2. Open the `project` directory as the implementation workspace.
3. Give DOT the text in `project/docs/DOT_START_PROMPT.md`.
4. DOT should read `project/docs/DOT_IMPLEMENTATION_HANDOFF.md` for the implementation goal, Phase 1 scope, acceptance criteria and verification steps.
5. `project/docs/EV_BUYER_JOURNEYS.md` contains the full ranked buyer catalogue, questions, current flows, proposed flows and gap analysis.

## Implementation goal

Help Australian EV buyers move from their circumstances to a useful shortlist and a concrete purchase-verification plan. Provide optional suitability guidance, discovery by needs and direct comparison of known cars. Support any two or three researched variants and a saved/exportable record of reasons, compromises and outstanding checks. Preserve the dedicated Model Y editorial path, evidence and working shared links. Complete and verify Phase 1 of the handoff across the Next application, static public build and supported portable experience.

## Included

The project source, pinned package manifest and lockfile, research data and overlays, assets, tests, build scripts, existing generated HTML previews, historical QA/documentation, the new buyer report, implementation handoff and DOT prompt are included. The project is a working-tree snapshot based on commit ca598cdc4074ee27fe4b3db8dd8b60a343ce8deb; the three new handoff/research documents are additional uncommitted files.

Existing generated previews and historical QA reports are reference material, not proof that new implementation work has passed checks. Rebuild from shared sources after making changes. Some old architecture/master-plan descriptions are stale; use the current code and new handoff to establish task scope.

## Setup

Use Node 24 if available (repository minimum Node 22) and pnpm 11.19.0. From `project`, install with `pnpm install --frozen-lockfile`, then follow `README.md` and the handoff. Read `AGENTS.md` and the relevant installed Next.js guides before application coding.

Dependencies, caches, Git history and prior ZIP archives are excluded. Installation may require network access. Included hosting metadata describes the existing project; it is not an instruction to publish. Publication is outside the implementation assignment.

## Integrity

`MANIFEST.json` lists the byte size and SHA-256 hash of every other archive file. Archive integrity and packaged file hashes were verified during preparation. No application implementation or fresh application test run was performed as part of packaging.
